# Il Faro di Brina

Un gioco a piattaforme 2D realizzato con **Leo**, il linguaggio con le parole chiave in italiano.

Brina, la pinguina guardiana della costa gelata, deve riaccendere il vecchio faro: la sua luce si è
spezzata in **7 frammenti** sparsi tra lava, spuntoni, slime e pipistrelli. A ogni frammento
raccolto la lanterna in cima al faro si illumina un po' di più.

## Come si gioca

- **Frecce** (o A/D) per camminare, **Spazio** (o Z) per saltare (tenuto più a lungo, salto più alto).
- Raccogli i 7 frammenti di luce (1000 punti l'uno): con tutti e 7 il faro si accende e **vinci**.
- Salta in testa agli slime e al pipistrello per sconfiggerli (punti extra).
- Il fungo dà un **super salto** per qualche secondo: serve per la stella polare (+500).
- Il cuore ridà una vita. Lava e spuntoni ne tolgono una.
- **Perdi** se finisci le 3 vite o se scadono i 150 secondi. "Ricomincia" riparte da capo.

Il livello è largo 2560 px e la telecamera segue Brina: pontile, zattera sulla lava, ascensore,
una piattaforma che gira in tondo e, in fondo, la scala fino al balcone del faro.

## Come si apre

- In **Leo Studio**: `leo studio il_faro_di_brina` (o aprire la cartella dalla schermata dei giochi:
  è un progetto-gioco perché contiene `gioco.json`). La scena `Scena1` si apre nel palco di
  Leo Giochi; il codice è in `Scena1.leo`.
- Per giocare subito: `leo il_faro_di_brina` (edizione Giochi o Suite).
- Per controllare il codice: `leo controlla il_faro_di_brina`.

## File

- `Scena1.maschera` – la scena: attori, posizioni e le loro dinamiche (comportamenti a blocchi).
- `Scena1.leo` – le regole del gioco scritte in Leo.
- `progetto.toml`, `gioco.json` – il progetto e il marcatore di progetto-gioco.
- `schermata.png`, `schermata_vittoria.png` – schermate prese dal gioco vero.

## Funzioni di Leo usate

- **Dinamiche del motore di gioco** nella maschera: Giocatore, Gravità, Piattaforma (ferma, che va
  avanti e indietro, che segue un percorso), Raccoglibile, Potenziamento (super salto), Nemico che
  pattuglia o vola, Ruota; Punteggio con Traguardo, Vite e Timer di gioco con "Quando arriva a zero";
  Telecamera che segue il giocatore, Sfondo che scorre, Particelle (neve, fuochi d'artificio).
- **Eventi in Leo** (`quando ... fai`): `Scena1.apertura`, `Brina.raccoglie Frammento`,
  `Brina.raccoglie Cuore`, `Brina.potere`, `Brina.potere_finito`, `Brina.sconfigge`, `Brina.colpito`,
  `Tempo.cambio`, `Punti.traguardo`, `Punti.cambio`, con i dati dell'evento (`evento["vite"]`, ...).
- **Linguaggio**: `costante`, `variabile`, `funzione`, liste, testi con `{...}`, `se ... altrimenti`,
  `dopo 2500 millisecondi fai`, `massimo`/`minimo`.
- **Metodi degli attori**: `Telecamera1.scuoti_schermo`, `Fuochi.scoppia`, `Brina.esulta`,
  `Contatore.pulsa`, proprietà come `testo`, `visibile`, `colore_riempimento`.
