# Caso: sentinella_integrita

_Relazione generata il 2026-11-07T23:36:34 con Leo Sicurezza._

## 1. Sentinella d'integrità

- **Esito:** sigillo creato: 7 file
- **Ingressi:** cartella = ../sito_da_sorvegliare, sigillo = sigillo.txt
- **Ora:** 2026-11-07T23:36:32
- **Nota:** Impronta SHA-256 di ogni file, firmata con HMAC.

## 2. Sentinella d'integrità

- **Esito:** Cartella intatta: 7 file, nessuna differenza.
- **Ingressi:** cartella = ../sito_da_sorvegliare, sigillo = sigillo.txt
- **Ora:** 2026-11-07T23:36:33
- **Nota:** Confronto con il sigillo del 2026-11-07 23:36:32.

## 3. Sentinella d'integrità

- **Esito:** DIFFERENZE: 1 modificati, 2 aggiunti, 1 tolti (5 intatti), 1 sospetti.
- **Ingressi:** cartella = ../sito_da_sorvegliare, sigillo = sigillo.txt
- **Ora:** 2026-11-07T23:36:34
- **Nota:** Confronto con il sigillo del 2026-11-07 23:36:32.

## 4. Sentinella d'integrità

- **Esito:** SIGILLO ALTERATO
- **Ingressi:** cartella = ../sito_da_sorvegliare, sigillo = sigillo.txt
- **Ora:** 2026-11-07T23:36:34
- **Nota:** La firma HMAC del sigillo non corrisponde: fotografia non affidabile.

