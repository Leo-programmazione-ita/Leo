# Sentinella d'integrità: uno strumento difensivo realizzato con Leo Sicurezza

È uno strumento **difensivo** scritto interamente in **Leo**. Fa una «fotografia» di una cartella (per esempio i file di un sito): calcola l'**impronta SHA-256** di ogni file e la sigilla con una **firma HMAC**. Più avanti la confronta con la cartella com'è adesso e dice che cosa è stato **modificato**, **aggiunto** o **tolto**. Segnala anche i file **travestiti**, cioè quelli il cui contenuto non corrisponde all'estensione. Se qualcuno ritocca il sigillo per nascondere una modifica, la firma non torna più e la sentinella dà l'allarme.

![Rapporto delle differenze](schermata_rapporto.png)

## Che cosa fa

- **Fotografia sigillata** (`leo fotografa.leo`): scrive `sigillo.txt` con una riga per file (percorso, impronta, byte, data) e la firma HMAC di tutte le righe. La chiave segreta si crea da sola la prima volta in `chiave.segreta`, leggibile solo da te (permessi 600).
- **Controllo** (`leo .`): verifica prima la firma del sigillo, poi confronta impronte, dimensioni e date. Stampa le differenze e scrive `rapporto.html`.
- **File sospetti**: per ogni file nuovo o cambiato controlla che il contenuto vero corrisponda all'estensione. Un «offerta.jpg» che inizia come un programma di Windows viene segnato in rosso.
- **Taccuino del caso**: la cartella è un **caso** del *Banco del perito* di Leo Sicurezza (`caso.json`, `taccuino.json`). Ogni fotografia e ogni controllo diventa un'evidenza nel taccuino e `relazione.md` è la relazione in Markdown, generata dal Banco.

Lo strumento legge soltanto la cartella sorvegliata: non cambia, non sposta e non cancella niente.

## Come si usa

1. In `impostazioni.leo` scrivi la cartella da sorvegliare (`CARTELLA`).
2. Quando la cartella è sicuramente a posto: `leo fotografa.leo`.
3. Ogni volta che vuoi controllare: `leo .` e poi apri `rapporto.html`.

La cartella sorvegliata sta fuori dal progetto e il Banco si usa con `importa python`. Per questo Leo chiede i permessi «file» e «codice», oppure si danno con `--permetti file,codice`.

Per una prova completa ci sono `crea_prova.leo` (crea un piccolo sito finto in `../sito_da_sorvegliare`) e `altera_prova.leo` (simula un intruso). Questi due script usano `crea_cartella` ed `elimina_file`, che sono funzioni della categoria Sistema: si eseguono con Leo Suite. La sentinella invece gira con Leo Sicurezza.

## Come è fatto

| File | Contenuto |
|---|---|
| `principale.leo` | il controllo (`leo .`) |
| `fotografa.leo` | crea il sigillo |
| `sentinella.leo` | sigillo (scrittura, lettura, firma), chiave segreta, controllo, annotazioni nel taccuino |
| `controlli.leo` | differenze leggibili, file travestiti, riassunto e pagina HTML, con 4 blocchi `verifica` |
| `impostazioni.leo` | cartella, sigillo e rapporto (`pubblica costante`) |
| `caso.json`, `taccuino.json` | il caso del Banco del perito, creato con `banco_studio.crea_progetto_caso` |
| `crea_prova.leo`, `altera_prova.leo`, `cartella_prova.leo` | la prova |
| `prova_esecuzione.txt`, `rapporto_esempio.html`, `relazione_esempio.md`, `schermata_rapporto.png` | i risultati veri della prova e la schermata (Playwright) |

## Funzioni di Leo usate

- **Forense**: `impronta_albero` (SHA-256, dimensione e data di ogni file), `confronta_alberi` (aggiunti, tolti, cambiati, uguali, intatta) ed `estensione_coerente` (il vero tipo del file dai primi byte).
- **Sicurezza dei dati**: `firma_hmac`, `verifica_hmac` (confronto a tempo costante) e `testo_casuale_sicuro` per la chiave.
- **Difesa**: `rendi_file_privato` (permessi 600 sulla chiave).
- **Banco del perito** (`leo/grafica/web/banco_studio.py`), usato da Leo con `importa python "leo.grafica.web.banco_studio" come banco`: `crea_progetto_caso`, `salva_evidenza` ed `esporta_markdown`.
- **Linguaggio**: `importa "file.leo" come nome`, `pubblica costante`, `prova … cattura come e`, `altrimenti se`, testi su più righe `"""…"""` con `{…}`, `.dividi`, `.unisci`, `.sostituisci`, `verifica` e `aspettati`.

## Prova di funzionamento

`leo controlla .` dà «Tutto in ordine: nessun problema in 8 file» e `leo verifica .` dà «4 verifiche: 4 riuscite». Le prove sono state fatte in una cartella temporanea. L'output completo è in `prova_esecuzione.txt`:

```
$ leo .                         # dopo l'intrusione
  MODIFICATO: index.html  cambiato: dimensione, data, contenuto (41 byte -> 76 byte)
  SOSPETTO: img/offerta.jpg  nuovo file, 56 byte - ATTENZIONE: il contenuto è «EXE», non «jpg»
  AGGIUNTO: js/aggiornamento.js  nuovo file, 27 byte
  TOLTO: chi_siamo.html  non c'è più
DIFFERENZE: 1 modificati, 2 aggiunti, 1 tolti (5 intatti), 1 sospetti.

$ (qualcuno ritocca una riga del sigillo per nascondere la modifica)
$ leo .
ALLARME: il sigillo sigillo.txt è stato alterato (la firma non torna).
```

## Note

In Leo Sicurezza `leggi_opzioni`, `esiste`, `leggi_json`, `scrivi_json` e `crea_cartella` non ci sono, perché appartengono alla categoria Sistema. Per questo le impostazioni sono un file Leo (`impostazioni.leo`), il sigillo è un file di testo a colonne e l'esistenza di un file si controlla con `prova … cattura` intorno a `leggi_file`.
