# Serra automatica: realizzata con Leo Robotica (scheda simulata)

È il controllore di una piccola **serra automatica** scritto interamente in **Leo**. Legge l'umidità della terra, la luce e la temperatura da una **Raspberry Pi Pico** e decide con delle **soglie** che cosa accendere: la **pompa** d'irrigazione (un relè), la **ventola** (un motore DC con ponte H) e la **lampada** (un LED). Quando fa troppo caldo o la terra è troppo secca suona il **buzzer** e scrive l'allarme sullo **schermo OLED**.

> **La scheda è SIMULATA.** Tutte le prove sono state fatte con la scheda simulata di Leo Robotica (`collega_scheda(simulata = vero)`), senza hardware. I sensori simulati danno valori plausibili che cambiano col tempo. Con una Pico vera, con il firmware di Leo e i componenti collegati agli stessi piedini, basta togliere `simulata = vero` da `serra.leo`.

![Rapporto della serra](schermata_rapporto.png)

## Che cosa fa

- **Una lettura al secondo** di umidità (GP26), luce (GP27) e temperatura (sensore interno della Pico).
- **Soglie con isteresi** (in `soglie.leo`): la pompa parte sotto il 50% di umidità e si ferma solo sopra il 55%. La ventola parte sopra i 22 °C e si ferma sotto i 21,5 °C. La lampada si accende sotto il 45% di luce. Così relè e motore non scattano avanti e indietro quando il valore balla intorno alla soglia. Anche l'allarme ha la sua isteresi.
- **Allarme**: oltre 22,4 °C o sotto il 46% di umidità suona il buzzer (GP13) e l'OLED scrive «ALLARME!» con il motivo.
- **Registro**: sul terminale compare una riga solo quando qualcosa cambia. Tutte le letture finiscono in `serra_registro.csv`.
- **Rapporto**: `rapporto.html` contiene tre grafici SVG disegnati in Leo. Ognuno ha la sua soglia tratteggiata, la fascia di quando l'attuatore era acceso e i punti rossi degli allarmi.
- **Plancia**: il progetto è anche una **plancia** di Leo Robotica (`plancia.json`, `Finestra1.maschera`, `principale.leo`), creata con `plancia_studio.crea_progetto_plancia` e `salva_plancia`. Contiene la stessa scheda con i tre sensori, il relè, la ventola, la lampada e l'OLED, e due comportamenti a blocchi («quando l'umidità passa la soglia accendi il relè», «quando la temperatura passa la soglia accendi la ventola»). Aperta con `leo .` mostra le letture dal vivo della scheda simulata.

![La plancia aperta con leo .](schermata_plancia.png)

## Come si usa

```
leo serra.leo          # il controllore: 100 letture (circa due minuti), poi il rapporto
leo .                  # la plancia con le letture dal vivo (finestra)
leo verifica .         # le 5 verifiche della logica
```

Il numero di letture e l'intervallo si cambiano in `soglie.leo` (`LETTURE`, `SECONDI`; 0 letture vuol dire senza fine). Nello stesso file ci sono le soglie e i piedini.

## Come è fatto

| File | Contenuto |
|---|---|
| `serra.leo` | il controllore: collega la scheda, legge, comanda gli attuatori, scrive registro e rapporto |
| `logica.leo` | il «cervello» senza scheda: `interruttore` con isteresi, `decidi`, `cambiamenti`, con 5 blocchi `verifica` |
| `soglie.leo` | soglie, piedini, numero di letture (`pubblica costante`) |
| `grafico.leo` | la pagina del rapporto con i grafici SVG |
| `plancia.json`, `Finestra1.maschera`, `principale.leo` | la plancia di Leo Robotica (generati dal ponte della plancia) |
| `prova_esecuzione.txt`, `serra_registro.csv`, `rapporto_esempio.html` | i risultati veri di una prova con la scheda simulata |
| `schermata_rapporto.png`, `schermata_plancia.png` | il rapporto (Playwright) e la plancia aperta con Qt *offscreen* |

## Funzioni di Leo usate

- **Robotica**: `collega_scheda(simulata = vero)`, e sulla scheda `temperatura`, `umidita`, `luce`, `accendi`, `spegni`, `motore` (ponte H, velocità da -100 a 100), `suona` (frequenza e durata), `scrivi_schermo`, `mostra_schermo`, `scollega` e la proprietà `descrizione`.
- **Plancia** (`leo/grafica/web/plancia_studio.py`): `crea_progetto_plancia`, `salva_plancia` (che genera `principale.leo` e `Finestra1.maschera`) e `manifest_espone`. Componenti: sensore, relè, motore DC, LED e OLED.
- **Linguaggio**: `importa "file.leo" come nome`, `pubblica funzione` e `pubblica costante`, liste per comprensione (`[l[campo] per ogni l in letture]` e `… se l[attuatore]`), `per ogni i, x in enumera(...)`, `minimo`, `massimo`, `adesso().formato(...)`, `attendi`, testi su più righe `"""…"""`, il formato numerico `{x:1}`, `verifica` e `aspettati`.

## Prova di funzionamento

`leo controlla .` dà «Tutto in ordine: nessun problema in 5 file» e `leo verifica .` dà «5 verifiche: 5 riuscite». La prova è stata fatta in una cartella temporanea, con `LEO_EDIZIONE=robotica` e la scheda simulata. L'output completo è in `prova_esecuzione.txt`.

## Note

- In Leo Robotica non ci sono `leggi_opzioni` né le funzioni per CSV e JSON, che appartengono alla categoria Sistema. Per questo le impostazioni sono in `soglie.leo` e il CSV si scrive come testo con `scrivi_file`.
- Nella plancia il buzzer non c'è: il generatore della plancia lo farebbe suonare appena la finestra si apre (`Pico1.suona(...)` nell'evento `apertura`). Il buzzer lo comanda solo `serra.leo`, quando serve.
