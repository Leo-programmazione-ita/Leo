# Conti di Casa, realizzata con Leo

È un'app desktop con finestre per tenere i conti della famiglia: entrate e uscite divise per categoria, totali del mese, budget, grafici e andamento dell'anno. È scritta tutta in **Leo**, il linguaggio di programmazione con le parole chiave in italiano.

![Finestra principale](schermata_Principale.png)

## Che cosa fa

- **Nuovo movimento**: data, tipo (Uscita o Entrata), categoria, descrizione e importo in euro. Le categorie cambiano secondo il tipo.
- **Riepilogo del mese**: entrate, uscite e saldo, con il saldo in rosso quando è negativo. Con ◀ ▶ si cambia mese e con «Questo mese» si torna a oggi.
- **Budget mensile**: una barra mostra quanta parte del budget è già spesa e una scritta dice quanto ne resta o di quanto è stato superato.
- **Tabella dei movimenti**, con la ricerca nella descrizione o nella categoria e il pulsante «Elimina selezionato» (prima chiede conferma).
- **In breve**: la spesa media al giorno, la previsione a fine mese e l'uscita più grande.
- **Grafico a barre** delle uscite del mese, divise per categoria.
- **Andamento dell'anno**, in una seconda finestra: il grafico del saldo di ogni mese, una tabella dei 12 mesi, i totali dell'anno e il mese migliore.
- **Esporta per Excel**: scrive `conti_ANNO_MESE.csv` con il separatore `;` e la virgola decimale.

I dati si salvano da soli a ogni modifica nel file **`conti.json`**, nella cartella del progetto. Il file che trovi già lì contiene dati d'esempio (giugno–novembre 2026): per cominciare da zero basta cancellarlo.

## Come si usa

- **In Leo Studio**: premi **Apri** nella barra a sinistra, scegli la cartella `conti_di_casa` e premi **F5** (Esegui). Per vedere e cambiare le finestre apri `Principale.maschera` o `Andamento.maschera` nel disegnatore. Dal terminale lo apri con `leo studio conti_di_casa`.
- **Dal terminale**: entra nella cartella con `cd conti_di_casa` e scrivi `leo .`. Avvialo dalla sua cartella: vedi la nota qui sotto.
- **Prove**: `leo verifica conti_di_casa` esegue le 17 verifiche della logica, e `leo controlla conti_di_casa` cerca gli errori senza eseguire il programma.

## Come è fatto

| File | Contenuto |
|---|---|
| `progetto.toml` | nome, finestra iniziale (`Principale`) ed elenco delle finestre |
| `Principale.maschera` / `.leo` | finestra principale: controlli ed eventi `quando … fai` |
| `Andamento.maschera` / `.leo` | seconda finestra: l'andamento dell'anno |
| `conti.leo` | **tutta la logica**, senza finestre: importi, totali, mesi, ricerca, budget, con 13 blocchi `verifica` |
| `archivio.leo` | lettura e scrittura di `conti.json` ed esportazione CSV, con 4 blocchi `verifica` |
| `conti.json` | i dati |

Gli importi si tengono in **centesimi interi**: così ogni somma torna esatta al centesimo.

## Funzioni di Leo usate

- **Linguaggio**: `variabile`, `costante`, `funzione` e `restituisci`, `se … altrimenti`, `per ogni`, funzioni anonime `funzione (m) … fine`, `prova … cattura come e`, `lancia ErroreValore(...)`, `importa "file.leo"`, testi con `{…}` e il formato `{x:migliaia 2}`, `verifica` e `aspettati` (anche `aspettati errore`).
- **Libreria**: `data()` con `.anno`, `.mese`, `.giorno` e `.formato()`, `oggi()`, `giorni_tra()`, `filtra()`, `mappa()`, `ordina_per(..., decrescente = vero)`, `arrotonda()`, `minimo()`, `leggi_json()` e `scrivi_json()`, `scrivi_tabella(..., excel = vero)`, `leggi_righe()`, `unisci_percorso()`, `cartella_programma()`, `cartella_temporanea()`, `messaggio()`, `domanda()`, `apri_finestra()` e `chiudi_finestra()`.
- **Controlli**: Etichetta, Pulsante (con `stile` "successo", "pericolo", "principale", "contorno"), Riquadro (con angoli arrotondati e ombra), SelettoreData, MenuATendina, CasellaTesto, CasellaImporto, Tabella, Grafico (`svuota`, `aggiungi_valore`), BarraAvanzamento, BarraStato, l'effetto `scuoti()` e gli eventi `apertura`, `clic`, `selezione`, `cambio` e `tasto` (Ctrl+N svuota il modulo).

## Note

- **Avviarla dalla sua cartella.** Quando un progetto parte con `leo cartella` da un'altra cartella, `cartella_programma()` restituisce la cartella da cui l'hai avviato e non quella del progetto. Per questo `conti.json` finirebbe in un'altra cartella. In Leo Studio questo non succede.
- **Parentesi dopo `.testo =`.** Nel codice trovi righe come `ValoreSaldo.testo = (euro(r["saldo"]))`. Le parentesi in più servono perché, senza, Leo legge la riga come testo libero e non riconosce le funzioni che arrivano da un altro file con `importa`.
