# Analisi vendite: realizzato con Leo

Strumento da riga di comando scritto interamente in **Leo**. Legge un file CSV di vendite, lo pulisce e calcola i riepiloghi. Alla fine scrive un **rapporto HTML** con tre grafici SVG e un riassunto sul terminale.

## Contenuto della cartella

| File | Cosa contiene |
|---|---|
| `principale.leo` | il programma: lettura, pulizia, riepiloghi, grafici, pagina HTML |
| `strumenti.leo` | funzioni di supporto (euro, percentuali, mesi, tabelle HTML) con 4 blocchi `verifica` |
| `genera_dati.leo` | crea i dati di prova `dati/vendite_2026.csv` (2.692 righe, 3 negozi, gennaio–giugno 2026) |
| `modello/stile.css` | lo stile del rapporto (si incorpora nella pagina) |
| `rapporto.html`, `rapporto_mercato.html` | rapporti generati: tutti i negozi e solo «Mercato» |
| `rapporto_screenshot.png` | screenshot del rapporto (Playwright) |
| `prova_esecuzione.txt`, `prova_mercato.txt` | quello che il programma ha scritto sul terminale |

## Come si usa

Dalla cartella del progetto:

```
leo genera_dati.leo                         # crea dati/vendite_2026.csv (sempre uguale: seme fisso)
leo .                                       # rapporto.html su tutti i negozi
leo . --negozio Mercato -u rapporto_mercato.html --classifica 3
leo . --file altro.csv                      # un altro CSV con le stesse colonne
leo . --aiuto                               # aiuto delle opzioni, in italiano
leo verifica .                              # esegue i test di strumenti.leo
```

Le colonne richieste sono `scontrino, data (AAAA-MM-GG), negozio, prodotto, categoria, quantita, prezzo_unitario`. Se manca una colonna, il file non esiste o il negozio non c'è, il programma lo spiega ed esce con codice 1.

> Avvialo dalla cartella del progetto: i percorsi relativi partono dalla cartella corrente. Un bug di Leo, descritto nel report, impedisce di usare `cartella_programma()`.

## Le funzioni di Leo usate (tutte verificate nel sorgente)

- **Tabelle** (`leo/libreria/tabelle.py`): `tabella_da_file`, `.togli_duplicati`, `.togli_mancanti`, `.filtra`, `.aggiungi_colonna` (con funzione anonima), `.statistiche`, `.raggruppa` (somma/media), `.ordina`, `.prime`, `.righe`, `.colonna`, `.colonne`, `.valori_diversi`, `.grafico`.
- **Grafici** (`leo/libreria/diagrammi.py`): barre e torta. Si usano le proprietà `tema`, `colori`, `altezza`, `mostra_valori` e `titolo_y`. Con `.svg()` il grafico finisce dentro la pagina.
- **Riga di comando**: `leggi_opzioni` (opzioni brevi e lunghe, `--aiuto` automatico) ed `esci_dal_programma`.
- **Testi e date**: interpolazione `"{x:migliaia 2}"`, `.dividi`, `.sostituisci`, `.unisci`, fette `testo[0..6]`, `data(...)`, `.aggiungi_giorni`, `.formato("GG MESE AAAA")`, `.giorno_settimana`, `.fine_settimana`, `oggi()`, `ora()`.
- **File e web**: `leggi_file`, `scrivi_file`, `crea_cartella`, `esiste`, `nome_file`, `proteggi_html`, `incolonna`.
- **Linguaggio**: `importa "strumenti.leo"`, `funzione`, funzioni anonime, `costante`, `per ogni i, x in enumera(...)`, `ripeti N volte`, `continua`, `verifica ... aspettati`.

## Prova di funzionamento

Il controllo statico non segnala errori: `leo controlla .` restituisce «Tutto in ordine: nessun problema in 3 file». Anche le verifiche passano tutte: `leo verifica .` dà «4 verifiche: 4 riuscite». Questo è l'output di `leo .`:

```
Letto dati/vendite_2026.csv: 2692 righe.
Pulizia: righe doppie tolte 1, righe incomplete tolte 1.

RIEPILOGO (tutti i negozi)
  Incasso totale ......... € 142.733,80
  Pezzi venduti .......... 18.175
  Giorni di apertura ..... 155
  Mese migliore .......... febbraio 2026 (€ 29.240,20)
  Primo vs ultimo mese ... -2,5%
...
Rapporto scritto in rapporto.html
```

L'output completo è in `prova_esecuzione.txt`; il rapporto si vede in `rapporto_screenshot.png`.
