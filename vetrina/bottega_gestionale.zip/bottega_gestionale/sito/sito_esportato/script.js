(function () {
  "use strict";

  function testoCella(td) { return (td ? td.textContent || "" : "").trim(); }

  // --- lista_dati: ricerca + ordinamento ----------------------------------
  function abilitaLista(box) {
    var tabella = box.querySelector("table");
    if (!tabella || !tabella.tBodies.length) return;
    var corpo = tabella.tBodies[0];

    var barra = document.createElement("div");
    barra.className = "leo-lista-barra";
    var input = document.createElement("input");
    input.type = "search";
    input.className = "leo-ricerca";
    input.placeholder = "Cerca…";
    input.setAttribute("aria-label", "Cerca nella tabella");
    barra.appendChild(input);
    box.insertBefore(barra, tabella);

    input.addEventListener("input", function () {
      var q = input.value.toLowerCase();
      var righe = corpo.rows;
      for (var i = 0; i < righe.length; i++) {
        var testo = (righe[i].textContent || "").toLowerCase();
        righe[i].style.display = (q === "" || testo.indexOf(q) !== -1) ? "" : "none";
      }
    });

    var intestazione = tabella.tHead && tabella.tHead.rows.length ? tabella.tHead.rows[0] : null;
    if (!intestazione) return;
    var celle = intestazione.cells;
    for (var c = 0; c < celle.length; c++) {
      (function (indice, th) {
        th.classList.add("leo-ordinabile");
        th.tabIndex = 0;
        var crescente = true;
        function ordina() {
          var righe = Array.prototype.slice.call(corpo.rows);
          righe.sort(function (a, b) {
            var va = testoCella(a.cells[indice]), vb = testoCella(b.cells[indice]);
            var na = parseFloat(va.replace(",", ".")), nb = parseFloat(vb.replace(",", "."));
            var cmp;
            if (!isNaN(na) && !isNaN(nb) && va !== "" && vb !== "") cmp = na - nb;
            else cmp = va.localeCompare(vb);
            return crescente ? cmp : -cmp;
          });
          for (var i = 0; i < righe.length; i++) corpo.appendChild(righe[i]);
          for (var k = 0; k < celle.length; k++) celle[k].removeAttribute("aria-sort");
          th.setAttribute("aria-sort", crescente ? "ascending" : "descending");
          crescente = !crescente;
        }
        th.addEventListener("click", ordina);
        th.addEventListener("keydown", function (e) {
          if (e.key === "Enter" || e.key === " ") { e.preventDefault(); ordina(); }
        });
      })(c, celle[c]);
    }
  }

  // --- modulo_contatti: validazione ---------------------------------------
  var RE_EMAIL = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

  function segnala(campo, errore) {
    var contenitore = (campo.closest && campo.closest("label")) || campo.parentNode;
    var msg = contenitore.querySelector(".leo-errore");
    if (errore) {
      if (!msg) {
        msg = document.createElement("span");
        msg.className = "leo-errore";
        contenitore.appendChild(msg);
      }
      msg.textContent = errore;
      campo.setAttribute("aria-invalid", "true");
    } else if (msg) {
      msg.textContent = "";
      campo.removeAttribute("aria-invalid");
    }
  }

  function abilitaModulo(form) {
    form.addEventListener("submit", function (e) {
      var ok = true, primo = null;
      var campi = form.querySelectorAll("input[name], textarea[name]");
      for (var i = 0; i < campi.length; i++) {
        var campo = campi[i];
        if (campo.type === "hidden") continue;
        var valore = (campo.value || "").trim(), errore = "";
        if (campo.required && valore === "") errore = "Questo campo è obbligatorio.";
        else if (campo.type === "email" && valore !== "" && !RE_EMAIL.test(valore))
          errore = "Inserisci un indirizzo email valido.";
        segnala(campo, errore);
        if (errore && !primo) primo = campo;
        if (errore) ok = false;
      }
      if (!ok) { e.preventDefault(); if (primo) primo.focus(); }
    });
  }

  // --- slider: pulsanti precedente/successivo + puntini ---------------------
  // Senza JS le slide restano tutte scorrevoli (fallback). Qui aggiungiamo i controlli.
  function abilitaSlider(box) {
    var piste = box.querySelector(".slider-piste");
    if (!piste) return;
    var slide = piste.children;
    if (slide.length < 2) return;

    function vaiA(i) {
      if (i < 0) i = 0;
      if (i > slide.length - 1) i = slide.length - 1;
      piste.scrollTo({ left: slide[i].offsetLeft - piste.offsetLeft, behavior: "smooth" });
    }
    function corrente() {
      var x = piste.scrollLeft, best = 0, bd = Infinity;
      for (var i = 0; i < slide.length; i++) {
        var d = Math.abs(slide[i].offsetLeft - piste.offsetLeft - x);
        if (d < bd) { bd = d; best = i; }
      }
      return best;
    }

    var nav = document.createElement("div");
    nav.className = "slider-nav";
    var prec = document.createElement("button");
    prec.type = "button"; prec.textContent = "‹"; prec.setAttribute("aria-label", "Slide precedente");
    var punti = document.createElement("div");
    punti.className = "slider-punti";
    var succ = document.createElement("button");
    succ.type = "button"; succ.textContent = "›"; succ.setAttribute("aria-label", "Slide successiva");
    nav.appendChild(prec); nav.appendChild(punti); nav.appendChild(succ);
    box.appendChild(nav);

    var bottoni = [];
    for (var k = 0; k < slide.length; k++) {
      (function (indice) {
        var b = document.createElement("button");
        b.type = "button";
        b.setAttribute("aria-label", "Vai alla slide " + (indice + 1));
        b.addEventListener("click", function () { vaiA(indice); });
        punti.appendChild(b);
        bottoni.push(b);
      })(k);
    }
    function aggiorna() {
      var c = corrente();
      for (var i = 0; i < bottoni.length; i++)
        bottoni[i].setAttribute("aria-current", i === c ? "true" : "false");
    }
    prec.addEventListener("click", function () { vaiA(corrente() - 1); });
    succ.addEventListener("click", function () { vaiA(corrente() + 1); });
    piste.addEventListener("scroll", function () {
      if (abilitaSlider._t) clearTimeout(abilitaSlider._t);
      abilitaSlider._t = setTimeout(aggiorna, 80);
    });
    aggiorna();
  }

  document.addEventListener("DOMContentLoaded", function () {
    var liste = document.querySelectorAll(".leo-lista");
    for (var i = 0; i < liste.length; i++) abilitaLista(liste[i]);
    var moduli = document.querySelectorAll("form.modulo[data-valida]");
    for (var j = 0; j < moduli.length; j++) abilitaModulo(moduli[j]);
    var slider = document.querySelectorAll("[data-slider]");
    for (var s = 0; s < slider.length; s++) abilitaSlider(slider[s]);
  });
})();
