# Bottega Aurora: un piccolo gestionale realizzato con Leo Suite

È un piccolo **gestionale** per una bottega di paese inventata, scritto in **Leo**. Mette insieme tre progetti che lavorano sugli stessi dati, come fa la Suite:

1. **`magazzino/`**, un **foglio dati** di Leo Dati. Il database `magazzino.db` contiene gli articoli (codice, nome, reparto, pezzi, scorta minima, prezzo, fornitore). Il foglio calcola il valore della merce per reparto e lo **espone** agli altri progetti come interfaccia `dato/tabella`.
2. **`sito/`**, un **sito** di Leo Web con tre **liste dal database**: gli articoli disponibili, quelli quasi finiti e il valore per reparto preso dal foglio dati.
3. **`agente_scorte/`**, l'**agente** che fa girare tutto. Carica le consegne e le vendite che arrivano nella cartella `arrivi/`, aggiorna il database, scrive l'**ordine ai fornitori** per gli articoli sotto la scorta minima, aggiorna il foglio dati e ricostruisce il sito.

![Il sito della bottega dopo un giro dell'agente](schermata_sito.png)

## Come si usa

```
cd magazzino      && leo prepara_database.leo    # una volta: crea magazzino.db (14 articoli)
cd agente_scorte  && leo .                       # un giro dell'agente
                     leo . --sorveglia --secondi 60
cd sito           && leo costruisci.leo          # solo il sito
```

Un giro dell'agente:

- legge ogni CSV in `agente_scorte/arrivi/` (colonne `codice,quantita`). I file che iniziano con `vendite` tolgono pezzi, gli altri sono consegne e ne aggiungono. I codici sconosciuti vanno nel registro come avviso. Poi sposta il file in `arrivi/caricati/`;
- scrive `ordini/ordine_AAAA-MM-GG.csv` (per Excel, con `;`). Contiene per ogni fornitore gli articoli sotto la scorta minima e i pezzi da ordinare per tornare al doppio della scorta;
- riesegue il foglio dati del magazzino (`risultato.db`) e ricostruisce `sito/sito_esportato/`;
- scrive tutto in `agente.log`.

In `agente_scorte/esempi_arrivi/` ci sono una consegna e le vendite di un sabato, da copiare in `arrivi/` per provarlo. L'agente lavora nelle cartelle sorelle (`../magazzino`, `../sito`) e usa i ponti dello Studio con `importa python`. Per questo Leo chiede i permessi «file» e «codice», oppure si danno con `--permetti file,codice`.

## Come è fatto

| Percorso | Contenuto |
|---|---|
| `magazzino/foglio.json`, `principale.leo` | il foglio dati, preparato con il ponte del Foglio di Leo Dati (`dati_studio`): sorgente `magazzino.db`/`articoli`, poi `calcola` (valore = pezzi × prezzo), `raggruppa` per reparto, `ordina` e `grafico`. `principale.leo` è il codice Leo generato dal foglio |
| `magazzino/progetto.toml` | la voce `[[espone]]` `dato/tabella` «valore_magazzino», scritta da `dati_studio.esponi` |
| `magazzino/prepara_database.leo` | crea il database con `apri_database`, `crea_tabella`, `importa_righe` |
| `sito/sito.json` | il modello del sito (progetto creato con `pagine_sito.crea_progetto_sito`), con tre blocchi `lista_dati` di tipo «query» |
| `sito/costruisci.leo`, `sito/sito_esportato/` | l'esportazione con il compilatore di Leo Web (`compila_progetto`, regime statico) e il sito che produce |
| `agente_scorte/principale.leo` | l'agente: Sensi (cartella `arrivi/`), Mani (database, ordini, foglio, sito), registro |
| `agente_scorte/scorte.leo` | i conti senza database (`da_ordinare`, `segno_del_file`, `ordine_per_fornitore`), con 3 blocchi `verifica` |
| `agente_scorte/ordine_esempio.csv`, `prova_esecuzione.txt`, `schermata_sito.png` | i risultati veri della prova e la schermata del sito (Playwright) |

## Funzioni di Leo usate

- **Database**: `e_database`, `apri_database`, `db.crea_tabella` (tipi in italiano, `testo chiave`), `db.importa_righe`, `db.esiste`, `db.esegui` con i parametri `?` (niente SQL injection), `db.conta`, `db.chiudi`.
- **Foglio dati** (`leo/grafica/web/dati_studio.py`): `crea_progetto_dati`, `imposta_sorgente_database`, `salva_foglio`, `esegui`, `esponi` (interconnessione `dato/tabella`).
- **Leo Web** (`pagine_sito`, `compilatore_web`): `crea_progetto_sito`, `salva_sito`, blocchi `lista_dati` e `compila_progetto(..., backend = "statico")`.
- **Sistema**: `leggi_opzioni`, `apri_registro`, `elenca_file`, `leggi_tabella`, `scrivi_tabella(..., excel = vero)`, `sposta_file`, `crea_cartella`, `unisci_percorso`, `attendi`.
- **Linguaggio**: `importa "scorte.leo" come scorte`, `importa python "..." come ...`, `pubblica funzione`, dizionari di liste, il formato `{valore:migliaia 2}`, `verifica` e `aspettati`.

## Prova di funzionamento

`leo controlla .` dà «Tutto in ordine» in tutti e tre i progetti e `leo verifica .` nell'agente dà «3 verifiche: 3 riuscite». La prova è stata fatta su una copia del gestionale in una cartella temporanea, con `LEO_EDIZIONE=suite`. L'output completo è in `prova_esecuzione.txt`:

```
[AVVISO] Codice sconosciuto in consegna_latteria.csv : XXX-999 - riga saltata
[INFO] Caricato consegna_latteria.csv (consegna): 3 righe
[INFO] Caricato vendite_sabato.csv (vendite): 4 righe
[INFO] Ordine scritto in ordini/ordine_2026-11-07.csv: 6 articoli da 5 fornitori
[INFO] Foglio dati aggiornato: 4 categorie in ../magazzino/risultato.db
[INFO] Sito ricostruito in ../sito/sito_esportato/ (5 file)
[INFO] Valore del magazzino: 527,58 €
```

Il `magazzino.db` e il `sito_esportato/` della cartella sono quelli di partenza, prima della prova. La schermata mostra il sito dopo il giro dell'agente.

## Note

- `sito/principale.leo` è il codice **illustrativo** che il costruttore di siti genera dal modello. Per i blocchi `lista_dati` di tipo «query» scrive `tabella_da_database("magazzino.db", "")`: perde la query SQL e il percorso `../magazzino/`. Il sito vero si costruisce con `costruisci.leo`.
- `magazzino/principale.leo` termina con `.mostra()` del grafico, che apre una finestra. Il foglio si usa da Leo Studio oppure attraverso l'agente.
