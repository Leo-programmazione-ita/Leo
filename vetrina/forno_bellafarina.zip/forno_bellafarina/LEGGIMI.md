# Forno Bellafarina: sito vetrina realizzato con Leo Web

Sito vetrina di **3 pagine** per un panificio di paese inventato, il «Forno Bellafarina» di Borgo Fontanelle: *Home*, *I nostri prodotti* e *Orari e contatti*. Le pagine sono scritte in codice Leo con il tipo `pagina` di Leo Web. Il sito è stato esportato con il compilatore di Leo Web.

## Contenuto della cartella

| Percorso | Cosa contiene |
|---|---|
| `pagine/home.leo`, `pagine/prodotti.leo`, `pagine/contatti.leo` | le tre pagine in Leo: `variabile p = pagina(...)`, poi `p.titolo(...)`, `p.galleria(...)`, `p.tabella(...)` e così via |
| `costruisci.leo` | lo script di costruzione, anche questo in Leo (vedi sotto) |
| `sito.json` | il modello del sito, cioè quello che legge il costruttore di Leo Studio. Lo produce `costruisci.leo` |
| `principale.leo`, `progetto.toml` | file del progetto-sito, creati da `pagine_sito.crea_progetto_sito` e da `salva_sito` |
| `immagini/*.svg` | illustrazioni disegnate a mano: vetrina, pagnotta, focaccia, cornetto, crostata |
| **`sito_esportato/`** | **il sito finito**: `index.html`, `prodotti.html`, `contatti.html`, `style.css`, `immagini/`, `sitemap.xml`, `robots.txt` |
| `sito_esportato.zip` | lo stesso sito in un archivio pronto da caricare |
| `anteprima/` | le anteprime a pagina singola prodotte eseguendo i file `pagine/*.leo` |
| `screenshot/` | screenshot Playwright: `index.png`, `prodotti.png`, `contatti.png`, `index_telefono.png` (390 px) |
| `prova_costruzione.txt` | l'output di `leo costruisci.leo` |

## Come si usa

Dalla cartella del progetto:

```
leo costruisci.leo
```

Poi apri `sito_esportato/index.html` nel browser, oppure carica la cartella (o lo zip) su un hosting qualsiasi. Il sito è statico e non usa JavaScript.

`costruisci.leo` lavora in tre passi:

1. **Esegue le pagine.** Importa i tre file `pagine/*.leo`, che sono programmi Leo veri. Ognuno costruisce la sua `pagina(...)` con il motore `leo/libreria/pagine_web.py` e la salva in `anteprima/`.
2. **Ricava il modello.** Rilegge lo stesso codice con `pagine_sito.modello_da_codice`, cioè il parser che Leo Studio usa per sincronizzare codice e costruttore. Poi aggiunge i dati del sito: tema `sabbia`, colori, font e descrizioni SEO. Infine lo salva con `pagine_sito.salva_sito`, che scrive `sito.json` e rigenera `principale.leo`.
3. **Esporta il sito.** Chiama `compilatore_web.compila_progetto(".", "sito_esportato", zip = vero)`, la stessa funzione del menu *Esegui → Esporta sito web* di Leo Studio. Il compilatore produce le pagine HTML con il menu di navigazione, `style.css`, `immagini/`, `sitemap.xml`, `robots.txt` e lo zip.

Il modulo Python del compilatore si chiama da Leo con il ponte Python: `importa python "leo.grafica.web.compilatore_web" come compilatore`.

## Le funzioni di Leo usate (tutte verificate nel sorgente)

- **Leo Web, tipo `pagina`** (`leo/libreria/pagine_web.py`): `pagina`, `.tema("sabbia")`, `.titolo`, `.sottotitolo`, `.sezione`, `.paragrafo`, `.immagine(..., alt = ...)`, `.galleria(..., didascalie = ...)`, `.tabella(..., intestazione = ...)`, `.elenco`, `.elenco_numerato`, `.pulsante`, `.collegamento`, `.citazione`, `.in_fondo`, `.salva`, `.quanti_elementi`.
- **Costruttore di siti** (`leo/grafica/web/pagine_sito.py`): `crea_progetto_sito`, `modello_da_codice`, `salva_sito`. Il modello `sito.json` usa `colori` e `font`, che il compilatore valida in `_variabili_tema`.
- **Compilatore** (`leo/grafica/web/compilatore_web.py`): `compila_progetto`, che passa per `esporta_cartella` e `compila`. Il compilatore sceglie da solo il target *statico*, perché il sito non ha blocchi di dati.
- **Linguaggio**: `importa "file.leo" come nome`, `importa python "..." come ...`, dizionari e liste, `per ogni i, x in enumera(...)`, `è nulla`, `esci_dal_programma`, `leggi_file`, `crea_cartella`.

## Prova di funzionamento

Il controllo statico delle pagine non segnala errori: `leo controlla pagine/` dà «Tutto in ordine: nessun problema in 3 file». Questo è l'output di `leo costruisci.leo`:

```
1) Pagine Leo eseguite: 8 + 8 + 10 elementi HTML (anteprime in anteprima/)
2) pagine/home.leo -> pagina «Forno Bellafarina» con 9 blocchi
2) pagine/prodotti.leo -> pagina «I nostri prodotti» con 9 blocchi
2) pagine/contatti.leo -> pagina «Orari e contatti» con 11 blocchi
   sito.json salvato (e principale.leo rigenerato dal costruttore)
3) Sito esportato in sito_esportato/ — pagine:
   - index.html (statico)
   - prodotti.html (statico)
   - contatti.html (statico)
   file scritti: 6, dinamico: falso, zip: sito_esportato.zip
```

Gli screenshot sono nella cartella `screenshot/`.

> Nota: `leo controlla costruisci.leo` segnala per errore che i moduli `importa python` non si trovano, anche se il programma gira correttamente. È un bug di Leo, descritto nel report.
