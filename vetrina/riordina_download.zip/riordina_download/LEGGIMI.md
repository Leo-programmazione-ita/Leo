# Riordina Download: un agente realizzato con Leo Sistema

È un **agente** scritto interamente in **Leo** che tiene in ordine la cartella Download: guarda i file che arrivano, decide con delle **regole** dove vanno (Fatture, PDF, Immagini, Musica, Archivi...) e li sposta nella sottocartella giusta. Ogni cosa che fa finisce in un **registro**, e l'ultimo giro si può **annullare**.

![Rapporto del riordino](schermata_rapporto.png)

## Che cosa fa

- **Regole in un file**: `regole.json` contiene l'elenco delle regole. Si provano in ordine e vince la prima che combacia. Una regola può guardare l'**estensione**, delle **parole nel nome** (per esempio «fattura», «ricevuta») e la **dimensione minima** in MB.
- **Mai sovrascrivere**: se nella destinazione c'è già un file con lo stesso nome, il nuovo diventa `foto_mare (2).jpg`.
- **Prudenza**: lascia stare i download non finiti (`.part`, `.crdownload`...), i file nascosti e quelli di sistema (`desktop.ini`). I file modificati da meno di 2 minuti aspettano il giro dopo: forse si stanno ancora scaricando.
- **Prova a vuoto** (`--prova`): dice che cosa farebbe, senza spostare niente.
- **Sorveglianza** (`--sorveglia`): resta in ascolto e riordina i nuovi arrivi ogni tot secondi.
- **Annulla** (`--annulla`): rimette nella cartella i file spostati nell'ultimo giro.
- **Registro e rapporto**: nella sottocartella `_riordino/` della cartella riordinata scrive `registro.log` (con data, ora e livello), `storico.csv` (tutti gli spostamenti), `ultimo_giro.json` (per annullare) e `rapporto.html` (la pagina nella schermata qui sopra).

## Come si usa

Dalla cartella del progetto:

```
leo .                              # riordina la cartella Download, una volta
leo . --prova                      # prova a vuoto
leo . --sorveglia --secondi 30     # resta in ascolto
leo . --annulla                    # annulla l'ultimo giro
leo . --cartella ALTRA_CARTELLA    # riordina un'altra cartella
leo . --aiuto                      # tutte le opzioni
leo verifica .                     # le 4 verifiche delle regole
```

L'agente lavora su una cartella fuori dal progetto. Per questo Leo chiede il permesso «file» la prima volta, oppure si concede con `--permetti file`.

Per provarlo senza toccare la vera cartella Download: `leo crea_prova.leo --cartella /tmp/prova/Download` crea 18 file finti e poi `leo . --cartella /tmp/prova/Download --eta 0` li riordina (`--eta 0` toglie l'attesa di 2 minuti).

## Come è fatto

Segue lo schema degli agenti del **Laboratorio di agenti** di Leo Sistema: *Sensi* (quando), *Testa* (decide), *Mani* (fai).

| File | Contenuto |
|---|---|
| `principale.leo` | l'agente: opzioni, Sensi (una volta o in ascolto), Mani (sposta, annota, annulla) e il rapporto HTML |
| `regole.leo` | la Testa: `combacia`, `scegli_regola`, `da_ignorare`, `nome_libero`, `controlla_regole`, con 4 blocchi `verifica` |
| `regole.json` | le regole, da cambiare a piacere |
| `stile.css` | lo stile del rapporto |
| `crea_prova.leo` | crea una finta cartella Download per provarlo |
| `prova_esecuzione.txt` | l'output vero delle prove (riordino, annulla, sorveglianza) |
| `rapporto_esempio.html`, `schermata_rapporto.png` | il rapporto prodotto dalla prova e la sua schermata (Playwright) |

Il Laboratorio genera un agente con una sola Testa e una sola destinazione per volta. Qui servono undici regole con destinazioni diverse, l'annullamento e il rapporto: per questo il programma è scritto a mano, con la stessa struttura.

## Funzioni di Leo usate

- **Sistema e file** (edizione Leo Sistema): `cartella_download`, `elenca_file`, `sposta_file` (con la guardia ai percorsi pericolosi), `crea_cartella`, `esiste`, `unisci_percorso`, `nome_senza_estensione`, `estensione_file`, `dimensione_file`, `dimensione_leggibile`, `data_modifica`, `elimina_file(..., definitivo = vero)`.
- **Programmi**: `leggi_opzioni` (opzioni brevi e lunghe, `--aiuto` in italiano), `apri_registro(..., schermo = vero)` con `.informazione`, `.avviso`, `.errore`, `.dettaglio`, `.ultime_righe`, ed `esci_dal_programma`.
- **Dati**: `leggi_json`, `scrivi_json`, `aggiungi_a_tabella` (CSV), `leggi_file`, `scrivi_file`.
- **Tempo**: `adesso`, `aggiungi_minuti`, `.formato("AAAA-MM-GG hh:mm:ss")`, `attendi`.
- **Permessi**: `--permetti file` per lavorare fuori dalla cartella del programma.
- **Linguaggio**: `importa "regole.leo"`, `funzione`, `costante`, `prova … cattura come e`, `lancia ErroreValore(...)`, `per ogni i, r in enumera(...)`, `continua`, `mentre`, testi su più righe `"""…"""` con `{…}`, `verifica`, `aspettati` e `aspettati errore ErroreValore fai`.

## Prova di funzionamento

`leo controlla .` dà «Tutto in ordine: nessun problema in 3 file» e `leo verifica .` dà «4 verifiche: 4 riuscite». Le prove sono state fatte in una cartella temporanea, con `LEO_EDIZIONE=sistema`. L'output completo è in `prova_esecuzione.txt`:

```
[INFO] Spostato: Fattura_luce_ottobre_2026.pdf -> Documenti/Fatture/Fattura_luce_ottobre_2026.pdf (regola «Fatture e ricevute»)
[AVVISO] Nome già usato in Immagini - lo chiamo foto_mare (2).jpg
[INFO] Spostato: foto_mare.jpg -> Immagini/foto_mare (2).jpg (regola «Immagini»)
...
[INFO] Fatto: 15 file sistemati, 0 in attesa. Rapporto: Download/_riordino/rapporto.html
```

## Note

- **Due date non si confrontano con `<` o `>`**: Leo dà «Non posso confrontare una `data` e una `data`». Per questo l'agente confronta le date come testo `AAAA-MM-GG hh:mm:ss`, che si ordina allo stesso modo.
- **Avvialo dalla sua cartella**: `regole.json` e `stile.css` si cercano nella cartella corrente.
