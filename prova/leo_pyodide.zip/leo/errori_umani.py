"""Messaggi d'errore ancora piu' umani (tema "innovazione").

Tre aggiunte ai messaggi in quattro parti di :mod:`leo.messaggi`:

1. **riga corretta proposta**: quando Leo sa come sistemare la riga
   (correzioni di forma del parser, "forse intendevi `totale`?", parole di
   altri linguaggi come ``print``) mostra la riga gia' corretta;
2. **livello semplice** (per chi inizia, ``--semplice``): frasi brevi e
   dirette, niente gergo, la riga corretta e un piccolo esempio di codice giusto;
3. **consiglio del giorno** facoltativo (``--consiglio``): un trucco di Leo
   diverso ogni giorno.

API:
    CONSIGLI                                   tuple dei consigli
    consiglio_del_giorno(data=None) -> str
    riga_corretta(errore, sorgente) -> tuple[int, str, str] | None   (riga, prima, dopo)
    spiegazione_semplice(errore, sorgente=None) -> str
    costrutto_della_riga(riga) -> str | None      # "scegli", "importa", "catena"...
    arricchisci(testo, errore, sorgente, *, semplice=False, consiglio=False, data=None) -> str
    formatta_umano(errore, sorgente=None, *, semplice=False, consiglio=False,
                   tema=None, colori=False) -> str
"""

from __future__ import annotations

import datetime as _dt
import re
from typing import Any

__all__ = ["CONSIGLI", "ESEMPI_CORRETTI", "ESEMPI_COSTRUTTI", "costrutto_della_riga",
           "consiglio_del_giorno", "riga_corretta",
           "spiegazione_semplice", "arricchisci", "formatta_umano"]

CONSIGLI: tuple[str, ...] = (
    "Scrivi `leo spiega programma.leo` e Leo ti racconta cosa fa il tuo programma.",
    "Nel REPL premi Tab: Leo completa le parole chiave e i nomi delle tue variabili.",
    "`per ogni i in 1..10 fai` conta da 1 a 10, compreso il 10.",
    "Le liste partono da 0: il primo elemento di `voti` è `voti[0]`, l'ultimo è `voti[-1]`.",
    "Dentro un testo puoi mettere i valori tra graffe: \"Ciao {nome}!\".",
    "`totale += 5` è come scrivere `totale = totale + 5`, ma più corto.",
    "Con `prova ... cattura ... fine` il programma non si ferma quando qualcosa va storto.",
    "`leo formatta programma.leo` mette in ordine rientri e spazi del tuo codice.",
    "Nel REPL `:salva mio.leo` salva tutto quello che hai scritto in un file.",
    "`leo sfida` propone piccoli esercizi con la verifica automatica della soluzione.",
    "Dai nomi chiari alle variabili: `prezzo_totale` si capisce meglio di `pt`.",
    "Una funzione fa una cosa sola, e il suo nome dice quale: `calcola_media`.",
    "`chiedi(\"Come ti chiami? \")` aspetta una risposta da tastiera.",
    "Per trasformare un testo in numero usa `intero(testo)` o `decimale(testo)`.",
    "`/` dà sempre un decimale (7 / 2 = 3.5); `//` dà la divisione intera (7 // 2 = 3).",
    "Il resto della divisione si calcola con `%`: `10 % 3` fa 1; `n % 2 == 0` vale per i numeri pari.",
    "Con `ripeti 3 volte ... fine` ripeti qualcosa un numero fisso di volte.",
    "`interrompi` esce da un ciclo, `continua` salta al giro successivo.",
    "Nel REPL `:spiega` racconta l'ultima cosa che hai eseguito.",
    "`scegli voto` con i rami `caso 10 allora`, `caso 6..9 allora` sostituisce una lunga catena di `altrimenti se`.",
    "`importa \"forme.leo\" come f` usa le funzioni di un altro file con il punto: `f.area(2)`.",
    "`[n * n per ogni n in 1..10 se n % 2 == 0]` costruisce una lista in una riga sola.",
    "La catena `|>` passa il valore alla funzione successiva: `voti |> ordina |> stampa`.",
    "`verifica doppio(21) == 42` controlla il programma mentre gira e mostra i valori se il conto non torna.",
    "Scrivi i test dentro il programma con `verifica \"nome\" fai ... fine` e lanciali con `leo verifica`.",
    "`ogni 2 secondi fai ... fine` ripete un blocco nel tempo; `dopo 3 secondi fai` lo fa una volta sola.",
    "`{prezzo:2}` scrive due decimali e `{totale:migliaia}` mette i punti delle migliaia.",
    "Leggi il messaggio d'errore fino in fondo: spesso contiene già la riga corretta.",
)

#: Esempi di codice giusto per ogni tipo di errore (livello semplice).
ESEMPI_CORRETTI: dict[str, tuple[str, str]] = {
    "ErroreNome": ("Prima crea la variabile, poi usala:",
                   'variabile nome = "Ada"\nstampa(nome)'),
    "ErroreSintassi": ("Ogni blocco ha le sue parole e finisce con `fine`:",
                       'se x > 3 allora\n    stampa("grande")\nfine'),
    "ErroreTipo": ("Per unire testo e numeri metti il numero tra graffe:",
                   'variabile anni = 10\nstampa("Ho {anni} anni")'),
    "ErroreValore": ("Controlla che il valore abbia la forma giusta:",
                     'variabile n = intero("42")   # solo cifre'),
    "ErroreIndice": ("Le posizioni partono da 0 e arrivano a lunghezza - 1:",
                     'variabile frutti = ["mela", "pera"]\nstampa(frutti[0])   # mela'),
    "ErroreChiave": ("Controlla che la chiave ci sia prima di usarla:",
                     'se diz.ha("nome") allora\n    stampa(diz["nome"])\nfine'),
    "ErroreDivisione": ("Non si può dividere per zero: controlla prima:",
                        'se b != 0 allora\n    stampa(a / b)\nfine'),
    "ErroreRicorsione": ("Una funzione che chiama se stessa deve sapere quando fermarsi:",
                         'funzione conta(n)\n    se n == 0 allora\n        restituisci 0\n    fine\n'
                         '    restituisci conta(n - 1)\nfine'),
    "ErroreFile": ("Controlla il nome del file e che esista:",
                   'variabile testo = leggi_file("note.txt")'),
}

_FRASI_SEMPLICI: dict[str, str] = {
    "ErroreNome": "Leo non conosce questo nome.",
    "ErroreSintassi": "Leo non capisce come è scritta questa riga.",
    "ErroreTipo": "Stai mescolando cose diverse, come testo e numeri.",
    "ErroreValore": "Questo valore non va bene qui.",
    "ErroreIndice": "Stai cercando una posizione che nella lista non c'è.",
    "ErroreChiave": "Questa chiave non c'è nel dizionario.",
    "ErroreDivisione": "Non si può dividere per zero.",
    "ErroreRicorsione": "Una funzione chiama se stessa senza fermarsi mai.",
    "ErroreFile": "Leo non riesce a usare questo file.",
}

#: Esempi giusti per i costrutti piu' recenti, scelti guardando la riga dell'errore
#: (valgono al posto dell'esempio generico del tipo di errore).
ESEMPI_COSTRUTTI: dict[str, tuple[str, str]] = {
    "scegli": ("`scegli` controlla un valore; ogni ramo comincia con `caso ... allora`:",
               'scegli voto\n    caso 10 allora\n        stampa("ottimo")\n    caso 6..9 allora\n'
               '        stampa("sufficiente")\n    altrimenti\n        stampa("da ripassare")\nfine'),
    "importa": ("`importa` vuole il nome del file tra virgolette o il nome di un modulo:",
                'importa "forme.leo"\nimporta matematica come m\nstampa(m.radice(9))'),
    "verifica": ("`verifica` vuole una condizione e, se serve, un messaggio dopo la virgola:",
                 'verifica doppio(21) == 42, "doppio(21) deve fare 42"'),
    "catena": ("`|>` passa il valore a sinistra come primo argomento della funzione a destra:",
               '[3, 1, 2] |> ordina |> stampa\nvariabile totale = voti |> filtra(funzione (v) restituisci v >= 6 fine)'),
    "compressa": ("Una lista compressa ha l'elemento, `per ogni`, la sequenza e, se serve, `se`:",
                  "variabile pari = [n per ogni n in 1..10 se n % 2 == 0]"),
    "destrutturazione": ("Tanti nomi quanti valori, separati da virgole:",
                         'variabile nome, anni = ["Ada", 36]\na, b = b, a'),
    "aumenta": ("`aumenta` e `diminuisci` vogliono il nome da cambiare e, dopo `di`, di quanto:",
                "aumenta voto di 2\ndiminuisci voto di 1\naumenta voto"),
    "anima": ("`anima` vuole oggetto e proprietà, `a` con il valore finale e, se serve, la durata:",
              'anima Pulsante1.sinistra a 300 in 0.5 secondi\n'
              'anima Pulsante1.alto a 40 in 800 millisecondi con curva "rimbalzo"'),
    "temporizzatore": ("`ogni` ripete e `dopo` aspetta una volta: la durata, l'unità di tempo e `fai`:",
                       'ogni 2 secondi fai\n    stampa("tic")\nfine\n'
                       'dopo 500 millisecondi fai\n    ferma_temporizzatori()\nfine'),
    "test": ("Una verifica ha un nome tra virgolette, `fai`, le aspettative e `fine`:",
             'verifica "doppio di un numero" fai\n    aspettati doppio(21) == 42\n'
             '    aspettati errore ErroreValore fai\n        intero("ciao")\n    fine\nfine'),
    "parallelo": ("`in parallelo fai ... fine` fa partire un lavoro; il risultato arriva con `aspetta`:",
                  'variabile lavoro = in parallelo fai\n    restituisci 6 * 7\nfine\nstampa(aspetta(lavoro))'),
}

_FORSE = re.compile(r"(?i)forse intendevi `([^`]+)`")
_COMPRESSA = re.compile(r"\[[^\]]*\bper\s+ogni\b")
_DESTRUTTURAZIONE = re.compile(r"^\s*(?:(?:crea\s+)?(?:variabile|costante)\s+)?[^\W\d]\w*\s*,\s*[^\W\d]\w*[^=]*=[^=]")
_PAROLA = re.compile(r"[^\W\d]\w*")


def _senza_testi(riga: str) -> str:
    """La riga con i testi svuotati (``"..."`` -> ``""``) e senza il commento finale."""
    risultato, dentro = [], False
    for c in riga:
        if c == '"':
            dentro = not dentro
            risultato.append(c)
            continue
        if not dentro:
            if c == "#":
                break
            risultato.append(c)
    return "".join(risultato)


def costrutto_della_riga(riga: str | None) -> str | None:
    """Il costrutto recente usato nella riga (chiave di :data:`ESEMPI_COSTRUTTI`) o None.

    ``scegli``/``caso`` all'inizio -> ``"scegli"``; ``importa`` -> ``"importa"``;
    ``verifica`` -> ``"verifica"``; ``aumenta``/``diminuisci`` -> ``"aumenta"``;
    ``anima`` -> ``"anima"``; ``ogni``/``dopo`` -> ``"temporizzatore"``;
    ``verifica "..." fai``/``aspettati`` -> ``"test"``; ``in parallelo`` ->
    ``"parallelo"``; ``|>`` -> ``"catena"``; ``[... per ogni ...]``
    -> ``"compressa"``; ``a, b = ...`` -> ``"destrutturazione"``.
    """
    if not riga:
        return None
    codice = _senza_testi(riga)
    parole = codice.split()
    if not parole:
        return None
    prima = parole[0]
    if prima in ("scegli", "caso") and len(parole) > 1 and parole[1][:1] not in ("=", "(", ".", "["):
        return "scegli"
    if prima == "importa" and len(parole) > 1 and parole[1][:1] not in ("=", "(", "."):
        return "importa"
    if prima == "verifica" and len(parole) > 2 and parole[1].startswith('"') and parole[-1] in ("fai", "allora"):
        return "test"
    if prima == "aspettati" and len(parole) > 1 and parole[1][:1] not in ("=", "(", ".", "["):
        return "test"
    if prima in ("ogni", "dopo") and len(parole) > 1 and parole[1][:1] not in ("=", "(", ".", "[", ",") \
            and parole[1] not in ("volta", "fai", "allora"):
        return "temporizzatore"
    if re.search(r"(^|[=(,]\s*)in\s+parallelo\b", codice.strip()):
        return "parallelo"
    if prima == "verifica" and len(parole) > 1 and parole[1][:1] not in ("=", "(", "."):
        return "verifica"
    if prima in ("aumenta", "diminuisci") and len(parole) > 1 and parole[1][:1] not in ("=", "(", ".", "[", "+", "-"):
        return "aumenta"
    if prima == "anima" and len(parole) > 1 and parole[1][:1] not in ("=", "(", ".", "["):
        return "anima"
    if parole[:2] == ["fine", "scegli"]:
        return "scegli"
    if "|>" in codice:
        return "catena"
    if _COMPRESSA.search(codice):
        return "compressa"
    if _DESTRUTTURAZIONE.match(codice):
        return "destrutturazione"
    return None


def consiglio_del_giorno(data: _dt.date | None = None) -> str:
    """Un consiglio diverso per ogni giorno dell'anno (lo stesso per tutto il giorno)."""
    data = data or _dt.date.today()
    return CONSIGLI[data.toordinal() % len(CONSIGLI)]


# ---------------------------------------------------------------------------
# Riga corretta
# ---------------------------------------------------------------------------

def _righe(sorgente: str | None) -> list[str]:
    if not sorgente:
        return []
    return sorgente.lstrip("﻿").replace("\r\n", "\n").replace("\r", "\n").split("\n")


def _da_correzioni(errore: Any, righe: list[str]) -> tuple[int, str, str] | None:
    correzioni = [c for c in (getattr(errore, "correzioni", None) or []) if getattr(c, "riga", 0)]
    if not correzioni:
        return None
    riga = correzioni[0].riga
    if riga < 1 or riga > len(righe):
        return None
    testo = righe[riga - 1]
    try:
        from .forme_parlate import correzione_sospetta
    except ImportError:  # pragma: no cover
        correzione_sospetta = None
    # applica da destra a sinistra quelle sulla stessa riga
    stessa = sorted((c for c in correzioni if c.riga == riga), key=lambda c: c.colonna, reverse=True)
    nuovo = testo
    for c in stessa:
        inizio = max(0, c.colonna - 1)
        if c.prima and nuovo[inizio:inizio + len(c.prima)] != c.prima:
            return None
        if "\n" in c.dopo:
            return None
        if correzione_sospetta is not None and correzione_sospetta(nuovo, c.colonna, c.prima, c.dopo):
            return None              # parola chiave raddoppiata o infilata, virgola accanto a `più`...
        nuovo = nuovo[:inizio] + c.dopo + nuovo[inizio + len(c.prima):]
    if nuovo == testo:
        return None
    return riga, testo, nuovo


#: "`etichetta` è il tipo di controllo, non il suo nome: nella finestra c'è `Etichetta1`..."
_TIPO_AL_POSTO = re.compile(r"nella finestra c'è `([^`]+)`")


def _da_forse(errore: Any, righe: list[str]) -> tuple[int, str, str] | None:
    """Sostituisce la parola storpiata con quella del "forse intendevi".

    La parola da sostituire e' quella della riga che somiglia di piu' al
    suggerimento (``ErroreVaolre`` -> ``ErroreValore``, ``altrimentise`` ->
    ``altrimenti se``), non per forza quella alla colonna dell'errore: la colonna
    puo' indicare l'inizio dell'istruzione o la parola che viene dopo.
    Se nessuna parola somiglia al suggerimento non si propone nulla.
    """
    suggerimento = getattr(errore, "suggerimento", None) or ""
    m = _FORSE.search(suggerimento) or _TIPO_AL_POSTO.search(suggerimento)
    riga, colonna = getattr(errore, "riga", 0), getattr(errore, "colonna", 0)
    if not m or riga < 1 or riga > len(righe):
        return None
    giusta = m.group(1)
    testo = righe[riga - 1]
    try:
        from .suggerimenti import distanza
    except ImportError:  # pragma: no cover
        return None
    compatta = giusta.replace(" ", "").lower()
    nome = getattr(errore, "nome", None)
    migliore = None
    for p in _PAROLA.finditer(testo):
        prima = testo[:p.start()]
        if prima.count('"') % 2 == 1 or "#" in prima:
            continue
        w = p.group(0)
        if w == giusta:
            continue
        if nome and w == nome and colonna and p.start() <= colonna - 1 < p.end():
            # la parola citata dall'errore, proprio li': anche se non somiglia
            # (`mostra` -> `stampa`, `numero_a_caso` -> `casuale`); la riga poi
            # passa comunque dal parser (proposta_sicura)
            migliore = (-10, p)
            break
        d = distanza(w.lower(), compatta)
        if w == nome:
            d -= 1                       # a parita', la parola citata dall'errore
        if colonna and p.start() <= colonna - 1 < p.end():
            d -= 0.5                     # e poi quella alla colonna dell'errore
        limite = 1 if len(compatta) <= 4 else 2
        if d <= limite and (migliore is None or d < migliore[0]):
            migliore = (d, p)
    if migliore is None:
        return None
    p = migliore[1]
    nuovo = testo[:p.start()] + giusta + testo[p.end():]
    return (riga, testo, nuovo) if nuovo != testo else None


_SI_SCRIVE = re.compile(r"In Leo si scrive `([^`]+)`")


def _da_altri_linguaggi(errore: Any, righe: list[str]) -> tuple[int, str, str] | None:
    """``while x`` -> ``mentre x`` quando il suggerimento dice "In Leo si scrive `mentre`"."""
    m_sugg = _SI_SCRIVE.search(getattr(errore, "suggerimento", None) or "")
    riga = getattr(errore, "riga", 0)
    if not m_sugg or riga < 1 or riga > len(righe):
        return None
    try:
        from .suggerimenti import parola_altro_linguaggio
    except ImportError:  # pragma: no cover
        return None
    leo = m_sugg.group(1)
    testo = righe[riga - 1]
    for m in _PAROLA.finditer(testo):
        prima = testo[:m.start()]
        if prima.count('"') % 2 == 1 or "#" in prima:
            continue
        if parola_altro_linguaggio(m.group(0)) == leo:
            nuovo = testo[:m.start()] + leo + testo[m.end():]
            return riga, testo, nuovo
    return None


def _migliora(errore: Any, sorgente: str | None) -> None:
    """Forme a parole, testo + numero, ``x = 5``...: messaggio e riga (:mod:`leo.forme_parlate`)."""
    try:
        from .forme_parlate import migliora_errore

        migliora_errore(errore, sorgente)
    except Exception:  # noqa: BLE001 - un aiuto in piu' non deve mai rompere il messaggio
        pass


def riga_corretta(errore: Any, sorgente: str | None) -> tuple[int, str, str] | None:
    """La riga dell'errore gia' corretta: ``(numero, riga_sbagliata, riga_corretta)`` o None.

    Punto comune di riga di comando, Leo Studio (pulsante Correggi) e telefono
    (fumetto dell'editor): una riga viene proposta SOLO se, messa nel programma,
    passa il parser (:func:`leo.forme_parlate.proposta_sicura`); altrimenti None.
    """
    righe = _righe(sorgente)
    if not righe:
        return None
    _migliora(errore, sorgente)
    try:
        from .correttore_sicuro import suggerimento_valido
    except ImportError:  # pragma: no cover
        return None
    for fonte in (_da_correzioni, _da_forse, _da_altri_linguaggi):
        try:
            risultato = fonte(errore, righe)
        except Exception:  # noqa: BLE001 - un aiuto in piu' non deve mai rompere il messaggio
            risultato = None
        if not risultato:
            continue
        for candidata in (_completa_parola_mancante(risultato), risultato):
            # validazione centrale: la riga proposta deve passare il parser
            # (nel contesto del programma), altrimenti non si mostra
            try:
                sicura = suggerimento_valido(candidata[2], sorgente=sorgente,
                                             numero=candidata[0], errore=errore)
            except Exception:  # noqa: BLE001
                sicura = False
            if sicura:
                return candidata
        return None          # la fonte giusta ha una proposta sbagliata: meglio nessuna riga
    return None


def _completa_parola_mancante(proposta: tuple[int, str, str]) -> tuple[int, str, str]:
    """Se alla riga corretta manca ancora `allora`/`fai`/`volte` in fondo, lo aggiunge."""
    numero, prima, dopo = proposta
    try:
        from .suggerimenti import prossima_parola

        mancante = prossima_parola(dopo)
    except Exception:  # noqa: BLE001
        mancante = None
    if mancante and mancante[0] in ("allora", "fai", "volte"):
        dopo = dopo.rstrip() + " " + mancante[0]
    return numero, prima, dopo


def _blocco_riga_corretta(proposta: tuple[int, str, str]) -> list[str]:
    numero, _prima, dopo = proposta
    larghezza = len(str(numero))
    return [f"    {numero:>{larghezza}} | {dopo}"]


# ---------------------------------------------------------------------------
# Livello semplice
# ---------------------------------------------------------------------------

def _tipo(errore: Any) -> str:
    return getattr(errore, "tipo", None) or type(errore).__name__


def spiegazione_semplice(errore: Any, sorgente: str | None = None) -> str:
    """Messaggio per chi inizia: frasi brevi, la riga corretta e un esempio giusto.

    Tono sobrio: ``Problema alla riga N.``, poi la riga con il segno, la causa,
    la correzione proposta (o il suggerimento) e un esempio di codice corretto.
    """
    _migliora(errore, sorgente)
    tipo = _tipo(errore)
    riga = getattr(errore, "riga", 0) or 0
    righe = _righe(sorgente)
    parti: list[str] = []
    parti.append(f"Problema alla riga {riga}." if riga else "Problema nel programma.")
    if 1 <= riga <= len(righe) and righe[riga - 1].strip():
        colonna = max(1, getattr(errore, "colonna", 1) or 1)
        lunghezza = max(1, getattr(errore, "lunghezza", 1) or 1)
        testo = righe[riga - 1]
        prefisso = f"    {riga} | "
        parti.append("")
        parti.append(prefisso + testo)
        spazi = "".join("\t" if ch == "\t" else " " for ch in testo[:colonna - 1])
        parti.append(" " * len(prefisso) + spazi + "^" * lunghezza)
    parti.append("")
    tipo_al_posto = _TIPO_AL_POSTO.search(getattr(errore, "suggerimento", None) or "")
    parti.append(_FRASI_SEMPLICI.get(tipo, "Il programma contiene un errore."))
    messaggio = getattr(errore, "spiegazione_semplice", None) or getattr(errore, "messaggio", "") or str(errore)
    if messaggio:
        parti.append(messaggio)
    if tipo_al_posto:
        # `etichetta.testo` mentre il controllo si chiama `Etichetta1`: la frase intera
        try:
            from .messaggi import _suggerimento

            spiegazione = _suggerimento(errore, sorgente)
        except Exception:  # noqa: BLE001
            spiegazione = getattr(errore, "suggerimento", None)
        if spiegazione:
            parti.append(spiegazione)
    proposta = riga_corretta(errore, sorgente)
    if proposta:
        parti.append("")
        parti.append("Correzione proposta:")
        parti.extend(_blocco_riga_corretta(proposta))
    elif not tipo_al_posto:
        suggerimento = getattr(errore, "suggerimento", None)
        if suggerimento:
            parti.append("Suggerimento: " + suggerimento[0].upper() + suggerimento[1:])
    esempio = getattr(errore, "esempio_semplice", None)
    if esempio:
        pass
    elif tipo_al_posto:
        esempio = ("Nel codice si usa il nome del controllo, quello scritto nella finestra:",
                   f'{tipo_al_posto.group(1)}.testo = "Ciao"')
    elif 1 <= riga <= len(righe):
        costrutto = costrutto_della_riga(righe[riga - 1])
        if costrutto is not None:
            esempio = ESEMPI_COSTRUTTI[costrutto]
    esempio = esempio or ESEMPI_CORRETTI.get(tipo)
    if esempio:
        titolo, codice = esempio
        parti.append("")
        parti.append("Esempio giusto. " + titolo)
        parti.extend("    " + r for r in codice.split("\n"))
    return "\n".join(parti)


# ---------------------------------------------------------------------------
# Composizione
# ---------------------------------------------------------------------------

def arricchisci(testo: str, errore: Any, sorgente: str | None, *, semplice: bool = False,
                consiglio: bool = False, data: _dt.date | None = None) -> str:
    """Aggiunge a un messaggio gia' formattato la riga corretta (e il consiglio del giorno).

    Con ``semplice=True`` il messaggio viene sostituito da :func:`spiegazione_semplice`.
    """
    _migliora(errore, sorgente)
    if semplice:
        risultato = spiegazione_semplice(errore, sorgente)
    else:
        risultato = testo
        proposta = riga_corretta(errore, sorgente)
        if proposta:
            risultato += "\n\nRiga corretta proposta:\n" + "\n".join(_blocco_riga_corretta(proposta))
    if consiglio:
        risultato += "\n\nConsiglio del giorno: " + consiglio_del_giorno(data)
    return risultato


def formatta_umano(errore: Any, sorgente: str | None = None, *, semplice: bool = False,
                   consiglio: bool = False, tema: Any = None, colori: bool = False,
                   data: _dt.date | None = None) -> str:
    """Messaggio completo: quello di :func:`leo.messaggi.formatta_errore` piu' le aggiunte."""
    try:
        from .messaggi import formatta_errore

        base = formatta_errore(errore, sorgente, tema=tema, colori=colori)
    except Exception:  # noqa: BLE001
        base = f"{_tipo(errore)}: {getattr(errore, 'messaggio', errore)}"
    return arricchisci(base, errore, sorgente, semplice=semplice, consiglio=consiglio, data=data)
