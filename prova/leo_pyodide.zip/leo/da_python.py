"""Righe scritte "alla Python" tradotte in Leo, per la riga proposta e l'autocorrezione.

Chi arriva da Python scrive ``def f(x):``, ``if x > 0:``, ``for i in range(n):``,
``lambda x: x * 2``, ``f"ciao {nome}"``... Il parser, parola per parola, sa dire
"in Leo si scrive `funzione`", ma una sostituzione di una sola parola lascia
i due punti in fondo (``funzione f(x):``) o una riga ancora sbagliata. Qui si
traduce la riga INTERA:

    def f(x):                   ->  funzione f(x)
    lambda x: x                 ->  funzione (x) restituisci x fine
    if x > 0 and y:             ->  se x > 0 e y allora
    elif x < 0:                 ->  altrimenti se x < 0 allora
    else:                       ->  altrimenti
    while x < 3:                ->  mentre x < 3 fai
    for i in range(n):          ->  per ogni i in 0..n-1 fai
    for i in range(2, 5):       ->  per ogni i in 2..4 fai
    per i in 1..3 fai           ->  per ogni i in 1..3 fai
    try: / except E as e: / finally:  ->  prova / cattura ErroreX come e / infine
    print(f"ciao {n}")          ->  stampa("ciao {n}")
    x = not vero                ->  x = non vero

API:
    traduci_riga(riga) -> (riga_tradotta, motivo) | None
    migliora_errore(errore, sorgente) -> None   (usata da ``esecuzione.analizza``)

Si interviene solo sulle righe che hanno gia' dato un ``ErroreSintassi``: una
riga Leo valida non viene mai toccata. I nomi, i valori e le operazioni
dell'utente restano quelli (si cambiano solo parole e punteggiatura di Python).
"""

from __future__ import annotations

import re
from typing import Any

__all__ = ["traduci_riga", "traduci_espressione", "migliora_errore"]

_NOME = r"[^\W\d]\w*"
_NOMI = rf"{_NOME}(?:\s*,\s*{_NOME})*"

#: Parole di Python (fuori dai testi) -> Leo.
_PAROLE = {
    "and": "e", "or": "o", "not": "non",
    "True": "vero", "False": "falso", "None": "nulla",
}
#: Funzioni predefinite di Python (seguite da ``(``) -> Leo.
_FUNZIONI = {
    "print": "stampa", "len": "lunghezza", "input": "chiedi", "str": "testo", "int": "intero",
    "float": "decimale", "bool": "logico", "abs": "assoluto", "round": "arrotonda", "min": "minimo",
    "max": "massimo", "sum": "somma", "type": "tipo", "enumerate": "enumera",
}
#: Metodi di Python (dopo ``.`` e seguiti da ``(``) -> Leo.
_METODI = {
    "append": "aggiungi", "upper": "maiuscolo", "lower": "minuscolo", "split": "dividi", "strip": "pulisci",
}
#: Eccezioni di Python -> errori di Leo (``None`` = qualunque errore).
_ECCEZIONI = {
    "Exception": None, "BaseException": None,
    "ValueError": "ErroreValore", "ZeroDivisionError": "ErroreDivisione", "IndexError": "ErroreIndice",
    "KeyError": "ErroreChiave", "TypeError": "ErroreTipo", "NameError": "ErroreNome",
    "FileNotFoundError": "ErroreFile", "IOError": "ErroreFile", "OSError": "ErroreFile",
    "RecursionError": "ErroreRicorsione",
}


# ---------------------------------------------------------------------------
# Pezzi della riga: codice, testi, commento
# ---------------------------------------------------------------------------

def _separa(riga: str) -> tuple[str, str, str]:
    """``(rientro, codice, commento)``: il commento parte dal primo ``#`` fuori dai testi."""
    rientro = riga[:len(riga) - len(riga.lstrip(" \t"))]
    resto = riga[len(rientro):]
    virgolette = None
    i = 0
    while i < len(resto):
        c = resto[i]
        if virgolette:
            if c == "\\":
                i += 2
                continue
            if c == virgolette:
                virgolette = None
        elif c in "\"'":
            virgolette = c
        elif c == "#":
            codice = resto[:i]
            spazi = codice[len(codice.rstrip()):]
            return rientro, codice.rstrip(), spazi + resto[i:]
        i += 1
    return rientro, resto.rstrip(), resto[len(resto.rstrip()):]


def _pezzi(codice: str) -> list[tuple[bool, str]]:
    """Il codice diviso in ``(e_testo, pezzo)``: i testi tra virgolette (con
    l'eventuale ``f`` davanti) restano interi."""
    pezzi: list[tuple[bool, str]] = []
    i = inizio = 0
    while i < len(codice):
        c = codice[i]
        prefisso = 0
        if c in "fFrRbB" and i + 1 < len(codice) and codice[i + 1] in "\"'" \
                and (i == 0 or not (codice[i - 1].isalnum() or codice[i - 1] == "_")):
            prefisso = 1
        if c in "\"'" or prefisso:
            q = codice[i + prefisso]
            j = i + prefisso + 1
            while j < len(codice) and codice[j] != q:
                j += 2 if codice[j] == "\\" else 1
            j = min(j + 1, len(codice))
            if inizio < i:
                pezzi.append((False, codice[inizio:i]))
            pezzi.append((True, codice[i:j]))
            i = inizio = j
            continue
        i += 1
    if inizio < len(codice):
        pezzi.append((False, codice[inizio:]))
    return pezzi


def _testo_leo(pezzo: str) -> str:
    """``f"ciao {n}"`` -> ``"ciao {n}"`` (in Leo ogni testo sostituisce le ``{}``);
    ``'ciao'`` -> ``"ciao"``."""
    if pezzo[:1] in "fF" and len(pezzo) > 1:
        pezzo = pezzo[1:]
    if pezzo.startswith("'") and pezzo.endswith("'") and len(pezzo) >= 2 and '"' not in pezzo:
        pezzo = '"' + pezzo[1:-1].replace("\\'", "'") + '"'
    return pezzo


_RE_PAROLA = re.compile(rf"(?<![\w.])({_NOME})")


def _parole(codice: str) -> str:
    """Parole e funzioni di Python in un pezzo di codice senza testi."""
    codice = re.sub(r"\bis\s+not\b", "non è", codice)
    codice = re.sub(r"(?<![\w.])is\b", "è", codice)

    def sostituisci(m: re.Match) -> str:
        parola = m.group(1)
        dopo = codice[m.end():].lstrip()
        if parola in _PAROLE:
            if parola == "not" and dopo.startswith("in") and not dopo[2:3].isalnum():
                return parola                     # `not in`: si lascia (non c'e' una forma sicura)
            return _PAROLE[parola]
        if parola in _FUNZIONI and dopo.startswith("("):
            return _FUNZIONI[parola]
        return parola

    codice = _RE_PAROLA.sub(sostituisci, codice)
    return re.sub(r"\.(\w+)(\s*\()", lambda m: "." + _METODI.get(m.group(1), m.group(1)) + m.group(2), codice)


def _lambda(codice: str) -> str:
    """``lambda x, y: corpo`` -> ``funzione (x, y) restituisci corpo fine``; il
    corpo finisce alla prima ``,`` o parentesi chiusa fuori dalle sue parentesi."""
    while True:
        m = re.search(rf"(?<![\w.])lambda\b\s*({_NOMI})?\s*:", codice)
        if m is None:
            return codice
        profondita = 0
        fine = len(codice)
        virgolette = None
        for j in range(m.end(), len(codice)):
            c = codice[j]
            if virgolette:
                if c == virgolette:
                    virgolette = None
                continue
            if c in "\"'":
                virgolette = c
            elif c in "([{":
                profondita += 1
            elif c in ")]}":
                if profondita == 0:
                    fine = j
                    break
                profondita -= 1
            elif c == "," and profondita == 0:
                fine = j
                break
        corpo = codice[m.end():fine].strip()
        parametri = (m.group(1) or "").strip()
        codice = codice[:m.start()] + f"funzione ({parametri}) restituisci {corpo} fine" + codice[fine:]


def traduci_espressione(codice: str) -> str:
    """Parole, funzioni, testi e ``lambda`` di Python in un pezzo di codice (senza commento)."""
    parti = []
    for e_testo, pezzo in _pezzi(codice):
        parti.append(_testo_leo(pezzo) if e_testo else _parole(pezzo))
    return _lambda("".join(parti))


# ---------------------------------------------------------------------------
# Intervalli: range(...)
# ---------------------------------------------------------------------------

def _argomenti(testo: str) -> list[str] | None:
    """Gli argomenti di una chiamata (il testo tra le parentesi), divisi alle virgole di primo livello."""
    parti, profondita, inizio = [], 0, 0
    for j, c in enumerate(testo):
        if c in "([{":
            profondita += 1
        elif c in ")]}":
            profondita -= 1
            if profondita < 0:
                return None
        elif c == "," and profondita == 0:
            parti.append(testo[inizio:j].strip())
            inizio = j + 1
    parti.append(testo[inizio:].strip())
    return parti if all(parti) else None


def _meno_uno(espressione: str) -> str:
    """``n`` -> ``n-1``, ``10`` -> ``9``, ``n+1`` -> ``n``. Non servono parentesi:
    ``+`` e ``-`` legano piu' di ``..``."""
    espressione = espressione.strip()
    if re.fullmatch(r"-?\d+", espressione):
        return str(int(espressione) - 1)
    m = re.fullmatch(r"(.+?)\s*\+\s*1", espressione)
    if m:
        return m.group(1)
    return f"{espressione} - 1" if " " in espressione else f"{espressione}-1"


def _intervallo(argomenti: list[str]) -> str | None:
    """``range(...)`` di Python -> intervallo di Leo (estremi compresi)."""
    if len(argomenti) == 1:
        da, a, passo = "0", argomenti[0], None
    elif len(argomenti) == 2:
        (da, a), passo = argomenti, None
    elif len(argomenti) == 3:
        da, a, passo = argomenti
    else:
        return None
    numeri = all(re.fullmatch(r"-?\d+", x) for x in (da, a) + ((passo,) if passo else ()))
    if passo is None or passo == "1":
        if numeri and int(a) <= int(da):
            return f"intervallo({da}, {int(a) - 1}, 1)"   # vuoto, come in Python
        return f"{da}..{_meno_uno(a)}"
    if re.fullmatch(r"-\d+", passo):
        fine = str(int(a) + 1) if re.fullmatch(r"-?\d+", a) else f"{a}+1"
        return f"intervallo({da}, {fine}, {passo})"
    return f"intervallo({da}, {_meno_uno(a)}, {passo})"


def _iterabile(testo: str) -> str:
    m = re.fullmatch(r"range\s*\((.*)\)", testo.strip())
    if m:
        argomenti = _argomenti(traduci_espressione(m.group(1)))
        if argomenti:
            intervallo = _intervallo(argomenti)
            if intervallo:
                return intervallo
    return traduci_espressione(testo)


# ---------------------------------------------------------------------------
# Righe intere
# ---------------------------------------------------------------------------

def _condizione(testo: str) -> str:
    """Una condizione; ``a not in b`` (da sola) diventa ``non (a in b)``."""
    testo = testo.strip()
    codice = "".join(p for t, p in _pezzi(testo) if not t)
    m = re.fullmatch(r"(.+?)\s+not\s+in\s+(.+)", testo)
    if m and not re.search(r"\b(and|or)\b", codice) and codice.count(" not ") == 1:
        return f"non ({traduci_espressione(m.group(1))} in {traduci_espressione(m.group(2))})"
    m = re.fullmatch(r"not\s+(.+)", testo)
    if m and not re.search(r"\b(and|or)\b", codice) and re.search(r"==|!=|<|>|\bin\b|\bis\b", codice):
        # `not x == y` in Python e' `not (x == y)`; in Leo `non` vale solo per il valore dopo
        return f"non ({traduci_espressione(m.group(1))})"
    return traduci_espressione(testo)


def _traduci_codice(codice: str) -> tuple[str, str] | None:
    """Il codice (senza rientro ne' commento) tradotto e il motivo, o None."""
    c = codice
    m = re.fullmatch(rf"(?:def|funzione)\s+({_NOME})\s*\((.*)\)\s*(?:->\s*[^:]+)?\s*:", c)
    if m:
        motivo = ("`def ...:` di Python: in Leo si scrive `funzione nome(...)` senza `:`"
                  if c.startswith("def") else "dopo `funzione nome(...)` non vanno i `:`")
        return f"funzione {m.group(1)}({traduci_espressione(m.group(2))})", motivo
    m = re.fullmatch(r"(if|se)\s+(.+?)\s*(?::|allora\s*:?)", c)
    if m:
        return f"se {_condizione(m.group(2))} allora", "in Leo si scrive `se condizione allora` (senza `:`)"
    m = re.fullmatch(r"(elif|altrimenti\s+se)\s+(.+?)\s*(?::|allora\s*:?)", c)
    if m:
        return (f"altrimenti se {_condizione(m.group(2))} allora",
                "`elif ...:` di Python: in Leo si scrive `altrimenti se condizione allora`")
    if re.fullmatch(r"(else|altrimenti)\s*:", c):
        return "altrimenti", "`else:` di Python: in Leo si scrive `altrimenti` (senza `:`)"
    m = re.fullmatch(r"(while|mentre)\s+(.+?)\s*(?::|fai\s*:?)", c)
    if m:
        return f"mentre {_condizione(m.group(2))} fai", "in Leo si scrive `mentre condizione fai` (senza `:`)"
    m = re.fullmatch(rf"(for|per\s+ogni|per)\s+({_NOMI})\s+in\s+(.+?)\s*(?::|fai\s*:?)?", c)
    if m:
        parola = re.sub(r"\s+", " ", m.group(1))
        iterabile = _iterabile(m.group(3))
        nuova = f"per ogni {m.group(2)} in {iterabile} fai"
        if parola == "for":
            motivo = "`for ... in ...:` di Python: in Leo si scrive `per ogni ... in ... fai`"
        elif parola == "per":
            motivo = "dopo `per` manca `ogni`: si scrive `per ogni ... in ... fai`"
        else:
            motivo = "in Leo si scrive `per ogni ... in ... fai` (senza `:`)"
        if re.match(r"range\s*\(", m.group(3).strip()) and iterabile != traduci_espressione(m.group(3)):
            motivo += "; `range(a, b)` diventa `a..b-1` (in Leo gli estremi sono compresi)"
        return nuova, motivo
    if re.fullmatch(r"try\s*:", c):
        return "prova", "`try:` di Python: in Leo si scrive `prova`"
    if re.fullmatch(r"finally\s*:", c):
        return "infine", "`finally:` di Python: in Leo si scrive `infine`"
    m = re.fullmatch(rf"except(?:\s+\(?\s*({_NOME})\s*\)?)?(?:\s+as\s+({_NOME}))?\s*:", c)
    if m:
        tipo = _ECCEZIONI.get(m.group(1)) if m.group(1) else None
        if m.group(1) and m.group(1) not in _ECCEZIONI:
            return None
        nuova = "cattura" + (f" {tipo}" if tipo else "") + (f" come {m.group(2)}" if m.group(2) else "")
        return nuova, "`except ...:` di Python: in Leo si scrive `cattura [TipoErrore] [come nome]`"
    m = re.fullmatch(r"return(?:\s+(.*))?", c)
    if m:
        return ("restituisci" + (f" {traduci_espressione(m.group(1))}" if m.group(1) else ""),
                "`return` di Python: in Leo si scrive `restituisci`")
    if c in ("break", "continue"):
        leo = "interrompi" if c == "break" else "continua"
        return leo, f"`{c}` di Python: in Leo si scrive `{leo}`"
    nuova = traduci_espressione(c)
    if nuova != c:
        return nuova, "forme di Python: " + _motivo_espressione(c)
    return None


def _motivo_espressione(c: str) -> str:
    parti = []
    if re.search(r"(?<![\w.])lambda\b", c):
        parti.append("le funzioni anonime si scrivono `funzione (x) restituisci ... fine`")
    if re.search(r"(?<![\w])[fF][\"']", c):
        parti.append("in Leo ogni testo sostituisce le `{...}`, non serve la `f` davanti")
    for parola, leo in _PAROLE.items():
        if re.search(rf"(?<![\w.]){parola}\b", c):
            parti.append(f"`{parola}` si scrive `{leo}`")
    for parola, leo in _FUNZIONI.items():
        if re.search(rf"(?<![\w.]){parola}\s*\(", c):
            parti.append(f"`{parola}` si scrive `{leo}`")
    for parola, leo in _METODI.items():
        if re.search(rf"\.{parola}\s*\(", c):
            parti.append(f"`.{parola}` si scrive `.{leo}`")
    if any(t and p.lstrip("fF").startswith("'") for t, p in _pezzi(c)):
        parti.append("i testi si scrivono tra virgolette doppie")
    return "; ".join(parti) or "in Leo si scrive diversamente"


def traduci_riga(riga: str) -> tuple[str, str] | None:
    """La riga tradotta in Leo (con lo stesso rientro e lo stesso commento) e il
    motivo, oppure None se non c'e' niente di Python da tradurre."""
    rientro, codice, commento = _separa(riga.rstrip("\r\n"))
    if not codice:
        return None
    try:
        tradotta = _traduci_codice(codice)
    except (re.error, ValueError, IndexError):  # pragma: no cover - mai rompere il messaggio
        return None
    if tradotta is None or tradotta[0] == codice:
        return None
    return rientro + tradotta[0] + commento, tradotta[1]


# ---------------------------------------------------------------------------
# Errori di sintassi
# ---------------------------------------------------------------------------

def migliora_errore(errore: Any, sorgente: str | None) -> None:
    """Se la riga di un ``ErroreSintassi`` e' scritta alla Python, la correzione
    diventa la riga intera tradotta (una sola :class:`~leo.errori.Correzione`,
    usata dalla riga proposta e dall'autocorrezione).

    Per ``per i in ...`` (manca ``ogni``) cambiano anche messaggio e suggerimento."""
    try:
        riga = int(getattr(errore, "riga", 0) or 0)
        if riga < 1 or not sorgente:
            return
        righe = sorgente.lstrip("﻿").replace("\r\n", "\n").replace("\r", "\n").split("\n")
        if riga > len(righe):
            return
        testo = righe[riga - 1]
        tradotta = traduci_riga(testo)
        if tradotta is None:
            return
        nuova, motivo = tradotta
        from .errori import Correzione

        rientro, codice, _ = _separa(testo)
        rientro_n, codice_n, _ = _separa(nuova)
        errore.correzioni = [Correzione(riga, len(rientro) + 1, codice, codice_n, motivo)]
        m = re.match(rf"per\s+({_NOMI})\s+in\b", codice)
        if m and not codice.startswith("per ogni"):
            _riscrivi(errore, "Dopo `per` manca `ogni`.", f"Scrivi `{codice_n}`.", len(rientro) + 1, 3)
            return
        if "In Leo si scrive" in (getattr(errore, "suggerimento", None) or ""):
            return  # il parser ha gia' riconosciuto la parola: messaggio e suggerimento vanno bene
        # messaggi generici del parser ("manca una virgola", "mi aspettavo la fine
        # dell'istruzione") davanti a forme di Python: si dice che cosa c'e' davvero
        for m in _pezzi_codice(codice):
            e_testo, inizio, pezzo = m
            if e_testo and pezzo[:1] in "fF" and pezzo[1:2] in "\"'":
                _riscrivi(errore, "In Leo i testi non hanno la `f` davanti.",
                          "Ogni testo sostituisce da solo le `{...}` con i valori: "
                          f"scrivi `{_testo_leo(pezzo)}`.", len(rientro) + inizio + 1, 1)
                return
            if e_testo:
                continue
            for parola, frase in (("lambda", "Le funzioni anonime si scrivono "
                                              "`funzione (x) restituisci x * 2 fine`."),
                                  ("not", "In Leo si scrive `non`.")):
                w = re.search(rf"(?<![\w.]){parola}\b", pezzo)
                if w:
                    _riscrivi(errore, f"`{parola}` non è una parola di Leo.", frase,
                              len(rientro) + inizio + w.start() + 1, len(parola))
                    return
    except Exception:  # noqa: BLE001 - un aiuto in piu' non deve mai rompere l'errore
        return


def _pezzi_codice(codice: str) -> list[tuple[bool, int, str]]:
    """Come :func:`_pezzi`, con la posizione (0-based) di ogni pezzo."""
    risultato, posizione = [], 0
    for e_testo, pezzo in _pezzi(codice):
        risultato.append((e_testo, posizione, pezzo))
        posizione += len(pezzo)
    return risultato


def _riscrivi(errore: Any, messaggio: str, suggerimento: str, colonna: int, lunghezza: int) -> None:
    errore.messaggio = messaggio
    errore.args = (messaggio,) + tuple(errore.args[1:])
    errore.suggerimento = suggerimento
    errore.colonna = colonna
    errore.lunghezza = lunghezza
