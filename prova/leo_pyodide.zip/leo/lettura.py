"""Lettura di una riga: che cosa ha capito Leo di un comando senza parentesi.

Serve all'editor ("Leo scrive con te"): per ogni comando senza parentesi dice
quali parti sono TESTO (scritte cosi' come sono) e quali sono CALCOLI (tra
parentesi, o valori di un comando come ``avanti lato * 2``), con le posizioni,
e propone le correzioni sicure (``stampa 3 + 4`` -> ``stampa (3 + 4)``).

API pubblica::

    analizza_riga(codice, riga, *, nome_file=None, nomi_noti=(), comandi_noti=(), sinonimi=None)
        -> Lettura | None
    analizza_righe(codice, ...) -> dict[int, list[Lettura]]      # tutte le righe

    Lettura.riga, .colonna, .fine_colonna     # posizioni (righe e colonne da 1)
    Lettura.comando                           # forma canonica: "stampa", "avanti", "Palla.rimbalza"
    Lettura.scritto                           # come e' scritto: "Scrivi", "stampa"
    Lettura.genere                            # testo | valore | senza | metodo | proprieta | utente
    Lettura.parti: list[Pezzo]                # Pezzo(tipo, testo, colonna, lunghezza, valore)
                                              #   tipo: "testo" | "calcolo" | "numero"
    Lettura.avvisi: list[Avviso]              # Avviso(messaggio, colonna, lunghezza, riga_corretta)
    Lettura.descrizione                       # "Scrive: Ciao (nome)" / "Va avanti di 100"...
    Lettura.a_dizionario()                    # per JSON (telefono)

``codice`` e' il sorgente intero (servono le altre righe per sapere quali nomi
sono variabili e funzioni dell'utente); ``riga`` parte da 1. Non solleva mai
eccezioni: se la riga non e' un comando senza parentesi restituisce ``None``.

Esempio::

    >>> l = analizza_riga('variabile nome = "Ada"\\nstampa Ciao (nome)!', 2)
    >>> [(p.tipo, p.testo) for p in l.parti]
    [('testo', 'Ciao '), ('calcolo', '(nome)'), ('testo', '!')]
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any, Iterable

from .comandi import ComandoLetto, Pezzo

__all__ = ["Lettura", "Avviso", "Pezzo", "analizza_riga", "analizza_righe"]


@dataclass
class Avviso:
    """Un consiglio sulla riga, con la riga intera gia' corretta (``None`` se non c'e')."""

    messaggio: str
    colonna: int
    lunghezza: int
    riga_corretta: str | None = None


@dataclass
class Lettura:
    riga: int
    colonna: int
    fine_colonna: int
    comando: str
    scritto: str
    genere: str
    parti: list[Pezzo] = field(default_factory=list)
    avvisi: list[Avviso] = field(default_factory=list)
    descrizione: str = ""

    def a_dizionario(self) -> dict[str, Any]:
        return asdict(self)


_DESCRIZIONI = {
    "stampa": "Scrive", "messaggio": "Mostra il messaggio", "chiedi": "Chiede", "domanda": "Chiede",
    "scrivi_qui": "Scrive sul disegno", "suona": "Suona",
    "avanti": "Va avanti di", "indietro": "Va indietro di", "destra": "Gira a destra di",
    "sinistra": "Gira a sinistra di", "punta_verso": "Si gira verso", "vai_a": "Va al punto",
    "cerchio": "Disegna un cerchio di raggio", "colore": "Usa il colore", "sfondo": "Colora lo sfondo di",
    "spessore": "Usa lo spessore", "riempi": "Riempie con", "velocità": "Usa la velocità",
    "velocita": "Usa la velocità", "attendi": "Aspetta", "apri_finestra": "Apre la finestra",
    "chiudi_finestra": "Chiude la finestra", "suona_file": "Suona il file", "salva_disegno": "Salva il disegno in",
    "casa": "Torna al centro", "penna_su": "Alza la penna", "penna_giu": "Abbassa la penna",
    "penna_giù": "Abbassa la penna", "pulisci_disegno": "Cancella il disegno", "fine_riempi": "Finisce di riempire",
    "nascondi_tartaruga": "Nasconde la tartaruga", "mostra_tartaruga": "Mostra la tartaruga",
    "mostra_disegno": "Mostra il disegno", "colore_casuale": "Sceglie un colore a caso",
    "ferma_suoni": "Ferma i suoni", "aspetta_animazioni": "Aspetta la fine delle animazioni",
}
_UNITA_DESCRIZIONE = {"attendi": "secondi", "destra": "gradi", "sinistra": "gradi", "punta_verso": "gradi",
                      "avanti": "passi", "indietro": "passi"}


def _descrivi(c: ComandoLetto) -> str:
    def pezzi() -> str:
        return "".join(p.testo if p.tipo == "testo" else (
            str(p.valore) if p.tipo == "numero" and p.valore is not None else p.testo) for p in c.pezzi)

    if c.genere == "proprieta":
        return f"Scrive in {c.nome}: {pezzi()}"
    if c.genere == "metodo":
        return f"Esegue {c.nome}" + (f" con {', '.join(p.testo for p in c.pezzi)}" if c.pezzi else "")
    if c.genere == "utente":
        return f"Esegue {c.nome}" + (f" con {', '.join(p.testo for p in c.pezzi)}" if c.pezzi else "")
    base = _DESCRIZIONI.get(c.nome, f"Esegue {c.nome}")
    if c.genere == "testo":
        return f"{base}: {pezzi()}" if c.pezzi else base
    if c.genere == "valore" and c.pezzi:
        valori = ", ".join(str(p.valore) if p.tipo == "numero" else p.testo for p in c.pezzi)
        unita = _UNITA_DESCRIZIONE.get(c.nome)
        if unita and len(c.pezzi) == 1 and c.pezzi[0].tipo == "numero":
            valori += f" {unita}"
        return f"{base} {valori}"
    return base


def _avvisi(c: ComandoLetto, riga_testo: str, lx: Any) -> list[Avviso]:
    """Consigli sicuri: un calcolo scritto come testo (``stampa 3 + 4``) o il nome di una
    variabile nel testo (``stampa Ciao nome``): Leo lo scrive cosi' com'e', ma forse
    volevi il valore. Ogni avviso ha la riga gia' corretta."""
    avvisi: list[Avviso] = []
    if c.genere not in ("testo", "proprieta", "valore", "utente", "metodo"):
        return avvisi
    try:
        defs = lx.definizioni()
        nomi_utente = set(defs.nomi)
    except Exception:
        nomi_utente = set()
    import re

    from .lexer import Lexer, _nomi_liberi
    from .parser import Parser

    for p in c.pezzi:
        if p.tipo != "testo":
            continue
        testo = p.testo
        inizio = p.colonna - 1
        pulito = testo.strip()
        if not pulito:
            continue
        # tutto il pezzo e' un calcolo con un operatore: `stampa 3 + 4`, `stampa x * 2`
        calcolo = False
        if re.search(r"[-+*/^%<>≥≤≠×÷]", pulito):
            try:
                token = Lexer(pulito, tollerante=True, comandi=False).tokenizza()
                if not any(t.tipo.name == "ERRORE" for t in token):
                    albero = Parser([t for t in token if t.tipo.name != "FINE_RIGA"]).espressione_isolata()
                    operazione = type(albero).__name__ in ("Binaria", "Confronto", "Logica")
                    calcolo = operazione and all(n in nomi_utente for n in _nomi_liberi(albero))
            except Exception:
                calcolo = False
        if calcolo:
            a = inizio + (len(testo) - len(testo.lstrip()))
            b = a + len(pulito)
            corretta = riga_testo[:a] + "(" + pulito + ")" + riga_testo[b:]
            avvisi.append(Avviso(f"`{pulito}` è scritto come testo. Per calcolarlo mettilo tra parentesi: "
                                 f"`({pulito})`.", a + 1, len(pulito), corretta))
            continue
        # una variabile del programma nel testo: `stampa Ciao nome`
        for m in re.finditer(r"[^\W\d]\w*", testo):
            parola = m.group(0)
            if parola in nomi_utente and parola not in defs.comandi and parola not in defs.funzioni_valore:
                a = inizio + m.start()
                b = inizio + m.end()
                corretta = riga_testo[:a] + "(" + parola + ")" + riga_testo[b:]
                avvisi.append(Avviso(f"`{parola}` è una tua variabile, ma qui è scritta come testo. "
                                     f"Per scriverne il valore mettila tra parentesi: `({parola})`.",
                                     a + 1, len(parola), corretta))
    return avvisi


def analizza_righe(codice: str, *, nome_file: str | None = None, nomi_noti: Iterable[str] = (),
                   comandi_noti: Iterable[str] = (), sinonimi: Any = None) -> dict[int, list[Lettura]]:
    """Tutti i comandi senza parentesi del codice, per riga (righe da 1). Mai eccezioni."""
    try:
        from .lexer import Lexer
        if sinonimi is None:
            from .sinonimi import carica_sinonimi
            sinonimi = carica_sinonimi()
        codice = (codice or "").replace("\r\n", "\n").replace("\r", "\n")
        lx = Lexer(codice, nome_file or "<editor>", sinonimi=sinonimi, tollerante=True,
                   conserva_commenti=True, nomi_noti=nomi_noti, comandi_noti=comandi_noti)
        lx.tokenizza()
        righe = codice.split("\n")
        risultato: dict[int, list[Lettura]] = {}
        for c in lx.comandi_letti:
            testo_riga = righe[c.riga - 1] if 0 < c.riga <= len(righe) else ""
            lettura = Lettura(c.riga, c.colonna, c.fine_colonna, c.nome, c.scritto, c.genere,
                              list(c.pezzi), [], "")
            try:
                lettura.descrizione = _descrivi(c)
                lettura.avvisi = _avvisi(c, testo_riga, lx)
            except Exception:
                pass
            risultato.setdefault(c.riga, []).append(lettura)
        return risultato
    except Exception:
        return {}


def analizza_riga(codice: str, riga: int, *, nome_file: str | None = None, nomi_noti: Iterable[str] = (),
                  comandi_noti: Iterable[str] = (), sinonimi: Any = None) -> Lettura | None:
    """Il (primo) comando senza parentesi della riga ``riga`` (da 1) di ``codice``, oppure
    ``None``. Per le righe con piu' comandi (``se x allora stampa A altrimenti stampa B fine``)
    usa :func:`analizza_righe`."""
    letture = analizza_righe(codice, nome_file=nome_file, nomi_noti=nomi_noti,
                             comandi_noti=comandi_noti, sinonimi=sinonimi).get(riga)
    return letture[0] if letture else None
