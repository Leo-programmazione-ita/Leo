"""Gestore di pacchetti di Leo: dipendenze Python e Leo di un progetto, isolate e bloccate.

Leo include già tutto ciò che serve per l'uso normale. Questo modulo è per gli
esperti che vogliono una libreria Python dell'ecosistema (``requests``, ``numpy``...)
o un pacchetto Leo scritto da altri::

    leo aggiungi requests "numpy>=2"     # pacchetti Python (PyPI o l'indice indicato)
    leo aggiungi leo:meteo_facile         # pacchetto Leo dal registro
    leo aggiungi ./librerie/geometria     # pacchetto Leo da una cartella o da un .zip
    leo togli requests
    leo sincronizza                       # rifà l'ambiente esattamente come dice leo.lock
    leo pacchetti                         # elenco, con le note su telefono e permessi
    leo pacchetti --verifica              # controlla che l'ambiente corrisponda al blocco

File del progetto:

* ``progetto.toml``: ``[dipendenze]`` (Python, ``nome = "vincolo"``) e
  ``[dipendenze_leo]`` (``nome = "vincolo"`` oppure ``{ percorso = "..." }``);
  facoltativo ``[registro]`` con ``python = "..."`` e ``leo = "..."``.
* ``leo.lock``: versioni esatte di TUTTO (anche le dipendenze indirette) con le
  impronte sha256, i permessi dei pacchetti Leo e le note sul telefono. Va messo
  nel controllo di versione: chi riceve il progetto ottiene gli stessi pacchetti.
* ``.leo/ambiente``: ambiente Python isolato del progetto, creato da solo (mai da
  attivare a mano: Leo lo usa da sé). ``.leo/pacchetti``: i pacchetti Leo estratti.
  La cartella ``.leo`` si può cancellare: ``leo sincronizza`` (o il primo avvio
  del programma) la ricrea uguale.

Strumenti: ``uv`` se c'è (molto più veloce; impronte di tutte le piattaforme),
altrimenti ``venv`` + ``pip`` della libreria standard. Per sicurezza si installano
solo pacchetti già pronti (wheel): nessun ``setup.py`` viene eseguito, a meno di
``--consenti-sorgenti``. Le impronte sono obbligatorie (``--require-hashes``).

Variabili d'ambiente: ``LEO_INDICE`` (cartella di wheel o indirizzo di un indice
Python), ``LEO_INDICE_LEO`` (registro dei pacchetti Leo), ``LEO_UV=0`` (non usare
uv), ``LEO_SINCRONIZZA_AUTO=0`` (non preparare da solo l'ambiente al primo avvio).
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence

from .pacchetti_sicurezza import controlla_impronta, impronta_file, nome_sospetto, normalizza

NOME_BLOCCO = "leo.lock"
CARTELLA_LEO = ".leo"
AMBIENTE = Path(CARTELLA_LEO) / "ambiente"
PACCHETTI_LEO = Path(CARTELLA_LEO) / "pacchetti"
CACHE_RUOTE = Path(CARTELLA_LEO) / "cache" / "ruote"
FORMATO_BLOCCO = 1

#: Pacchetti nativi che il Python del telefono (Chaquopy) sa installare se si ricostruisce
#: il guscio di Leo con quel pacchetto: per gli altri pacchetti nativi non c'è modo.
NATIVI_CHAQUOPY = frozenset("""numpy pandas pillow scipy matplotlib scikit-learn opencv-python cryptography lxml
cffi psutil pyzmq regex grpcio h5py statsmodels shapely pycryptodome pynacl bcrypt kiwisolver contourpy
aiohttp frozenlist multidict yarl ujson orjson msgpack greenlet""".split())


class ErrorePacchetti(Exception):
    """Errore del gestore di pacchetti, con un messaggio in italiano."""

    def __init__(self, messaggio: str, *, suggerimento: str | None = None, codice: int = 1) -> None:
        super().__init__(messaggio)
        self.messaggio = messaggio
        self.suggerimento = suggerimento
        self.codice = codice

    def __str__(self) -> str:
        return self.messaggio + (f"\n{self.suggerimento}" if self.suggerimento else "")


# ===========================================================================
# Progetto: [dipendenze], [dipendenze_leo], [registro]
# ===========================================================================

def radice_progetto(partenza: str | os.PathLike | None = None) -> Path:
    from .ponte_python import trova_radice_progetto

    r = trova_radice_progetto(partenza or os.getcwd())
    if r is None:
        raise ErrorePacchetti("Qui non c'è un progetto Leo (manca `progetto.toml`).",
                              suggerimento="Crea un progetto con `leo nuovo NomeProgetto --testuale` ed entra "
                                           "nella sua cartella.", codice=2)
    return Path(r)


def _leggi_progetto_toml(radice: Path) -> dict:
    from .tomlutil import ErroreToml, carica_toml

    try:
        return carica_toml(radice / "progetto.toml")
    except ErroreToml as e:
        raise ErrorePacchetti(f"`progetto.toml` non è scritto bene: {e}") from None


def dipendenze_dichiarate(radice: Path) -> tuple[dict[str, str], dict[str, Any]]:
    """(``[dipendenze]`` Python, ``[dipendenze_leo]``) di progetto.toml."""
    dati = _leggi_progetto_toml(radice)
    python = dati.get("dipendenze", {}) or {}
    leo = dati.get("dipendenze_leo", {}) or {}
    if not isinstance(python, dict) or not isinstance(leo, dict):
        raise ErrorePacchetti("In `progetto.toml` `[dipendenze]` e `[dipendenze_leo]` devono essere tabelle.")
    for k, v in python.items():
        if not isinstance(v, str):
            raise ErrorePacchetti(f"In `[dipendenze]` il valore di `{k}` deve essere un testo, per esempio "
                                  f"`{k} = \">=1.0\"` oppure `{k} = \"*\"`.")
    for k, v in leo.items():
        if not isinstance(v, (str, dict)):
            raise ErrorePacchetti(f"In `[dipendenze_leo]` il valore di `{k}` deve essere un testo o "
                                  f"`{{ percorso = \"...\" }}`.")
    return dict(python), dict(leo)


def registri(radice: Path, *, indice: str | None = None, indice_leo: str | None = None) -> tuple[str, str]:
    """(indice Python, registro Leo): opzione, poi variabile d'ambiente, poi ``[registro]``."""
    dati = _leggi_progetto_toml(radice).get("registro", {}) or {}
    py = indice or os.environ.get("LEO_INDICE", "").strip() or str(dati.get("python", "") or "")
    leo = indice_leo or os.environ.get("LEO_INDICE_LEO", "").strip() or str(dati.get("leo", "") or "")
    if py and not re.match(r"^https?://", py) and not os.path.isabs(py):
        py = str((radice / py).resolve()) if (radice / py).exists() else py
    if leo and not re.match(r"^https?://", leo) and not os.path.isabs(leo):
        leo = str((radice / leo).resolve()) if (radice / leo).exists() else leo
    return py, leo


def _valore_toml(v: Any) -> str:
    from .tomlutil import _valore

    return _valore(v)


def scrivi_sezione(file: Path, sezione: str, voci: dict[str, Any]) -> None:
    """Riscrive solo la tabella ``[sezione]`` di un file TOML (il resto resta com'è, commenti compresi)."""
    from .tomlutil import _chiave

    testo = file.read_text(encoding="utf-8") if file.exists() else ""
    righe = testo.splitlines()
    inizio = fine = None
    intestazione = re.compile(r"^\s*\[\s*" + re.escape(sezione) + r"\s*\]\s*(#.*)?$")
    for i, riga in enumerate(righe):
        if inizio is None and intestazione.match(riga):
            inizio = i
        elif inizio is not None and re.match(r"^\s*\[", riga):
            fine = i
            break
    if inizio is not None and fine is None:
        fine = len(righe)
    nuove = [f"[{sezione}]"] + [f"{_chiave(k)} = {_valore_toml(v)}" for k, v in sorted(voci.items())]
    if inizio is None:
        if not voci:
            return
        while righe and not righe[-1].strip():
            righe.pop()
        righe += ["", *nuove]
    else:
        # i commenti della sezione (righe che iniziano con #) restano
        commenti = [r for r in righe[inizio + 1:fine] if r.strip().startswith("#")]
        coda = [""] if fine < len(righe) else []
        righe[inizio:fine] = ([*nuove[:1], *commenti, *nuove[1:], *coda] if voci else [])
    nuovo = "\n".join(righe).rstrip("\n") + "\n"
    temporaneo = file.with_name(file.name + ".tmp")
    temporaneo.write_text(nuovo, encoding="utf-8", newline="\n")
    os.replace(temporaneo, file)


# ===========================================================================
# Blocco (leo.lock)
# ===========================================================================

def leggi_blocco(radice: str | os.PathLike) -> dict:
    """Il contenuto di ``leo.lock`` (``{}`` se non c'è)."""
    from .tomlutil import ErroreToml, carica_toml

    file = Path(radice) / NOME_BLOCCO
    if not file.is_file():
        return {}
    try:
        dati = carica_toml(file)
    except ErroreToml as e:
        raise ErrorePacchetti(f"`{NOME_BLOCCO}` è rovinato: {e}",
                              suggerimento="Cancellalo e scrivi `leo sincronizza` per ricrearlo.") from None
    if int(dati.get("formato", FORMATO_BLOCCO)) > FORMATO_BLOCCO:
        raise ErrorePacchetti(f"`{NOME_BLOCCO}` è stato creato da una versione di Leo più nuova.",
                              suggerimento="Aggiorna Leo.")
    return dati


def scrivi_blocco(radice: Path, dati: dict) -> None:
    from .tomlutil import scrivi_toml

    intestazione = ("# leo.lock - generato da `leo aggiungi` / `leo sincronizza`: non modificarlo a mano.\n"
                    "# Versioni esatte e impronte sha256 di tutti i pacchetti del progetto.\n\n")
    file = radice / NOME_BLOCCO
    temporaneo = file.with_name(file.name + ".tmp")
    temporaneo.write_text(intestazione + scrivi_toml(dati), encoding="utf-8", newline="\n")
    os.replace(temporaneo, file)


def impronta_dichiarazioni(python: dict, leo: dict) -> str:
    """Impronta delle dipendenze dichiarate: se cambia, il blocco va ricalcolato."""
    testo = json.dumps({"python": {normalizza(k): v for k, v in python.items()}, "leo": leo},
                       sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(testo.encode("utf-8")).hexdigest()[:16]


# ===========================================================================
# Strumenti esterni: uv oppure venv + pip
# ===========================================================================

def trova_uv() -> str | None:
    scelta = os.environ.get("LEO_UV", "").strip()
    if scelta == "0":
        return None
    if scelta and os.path.isfile(scelta):
        return scelta
    return shutil.which("uv")


def _python_ambiente(radice: Path) -> Path:
    amb = radice / AMBIENTE
    return amb / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def _esegui(argomenti: Sequence[str], cartella: Path, *, cosa: str) -> str:
    opzioni: dict[str, Any] = {}
    if os.name == "nt":
        opzioni["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        r = subprocess.run(list(argomenti), cwd=cartella, capture_output=True, text=True, **opzioni)
    except OSError as e:
        raise ErrorePacchetti(f"Non riesco ad avviare `{argomenti[0]}`: {e.strerror or e}.") from None
    if r.returncode != 0:
        raise _errore_strumento((r.stderr or "") + "\n" + (r.stdout or ""), cosa)
    return r.stdout


def _errore_strumento(testo: str, cosa: str) -> ErrorePacchetti:
    """Il messaggio di uv/pip tradotto in una frase italiana (il dettaglio resta sotto)."""
    testo = testo.strip()
    dettaglio = "\n".join(testo.splitlines()[-25:])
    nome = None
    for modello in (r"Because (\S+) was not found", r"No matching distribution found for (\S+)",
                    r"(\S+) was not found in the package registry", r"Could not find a version that satisfies "
                    r"the requirement (\S+)", r"no version of (\S+)"):
        m = re.search(modello, testo, re.I)
        if m:
            nome = m.group(1).strip("`'\".,")
            break
    if "only-binary" in testo.lower() or "has no usable wheels" in testo.lower() or "no wheels" in testo.lower():
        return ErrorePacchetti(
            f"{cosa}: per {('`' + nome + '`') if nome else 'un pacchetto'} non esiste una versione già pronta per "
            "questo computer, solo il codice sorgente da compilare.",
            suggerimento="Compilarlo vuol dire eseguire il suo programma di installazione: se ti fidi, ripeti con "
                         f"`--consenti-sorgenti`.\nDettaglio:\n{dettaglio}")
    if "hash" in testo.lower() and ("mismatch" in testo.lower() or "do not match" in testo.lower()):
        return ErrorePacchetti(
            f"{cosa}: un file scaricato non ha l'impronta sha256 scritta in `leo.lock`: installazione fermata.",
            suggerimento="Qualcuno potrebbe aver cambiato il pacchetto sul registro. Se sei sicuro, ricrea il "
                         f"blocco con `leo sincronizza --aggiorna`.\nDettaglio:\n{dettaglio}")
    if nome:
        return ErrorePacchetti(f"{cosa}: non trovo il pacchetto `{nome}` nel registro (o nessuna sua versione "
                               "va bene con le altre richieste).",
                               suggerimento=f"Controlla il nome e la versione.\nDettaglio:\n{dettaglio}")
    if re.search(r"(connection|network|resolve host|timed out|403|proxy)", testo, re.I):
        return ErrorePacchetti(f"{cosa}: non riesco a raggiungere il registro dei pacchetti.",
                               suggerimento=f"Controlla la connessione o usa `--indice`.\nDettaglio:\n{dettaglio}")
    return ErrorePacchetti(f"{cosa}: operazione non riuscita.", suggerimento=f"Dettaglio:\n{dettaglio}")


def _opzioni_indice(indice: str) -> list[str]:
    if not indice:
        return []
    if os.path.isdir(indice):
        return ["--no-index", "--find-links", indice]
    return ["--index-url", indice]


def _versione_python() -> str:
    return f"{sys.version_info.major}.{sys.version_info.minor}"


def crea_ambiente(radice: Path, *, avvisa: Callable[[str], Any] = print) -> Path:
    """Crea ``.leo/ambiente`` con lo stesso Python di Leo (se manca o è di un'altra versione)."""
    from .ponte_python import ambiente_di_altra_versione

    amb = radice / AMBIENTE
    if amb.exists() and ambiente_di_altra_versione(str(radice)):
        avvisa("L'ambiente del progetto era di un'altra versione di Python: lo ricreo.")
        shutil.rmtree(amb)
    if _python_ambiente(radice).exists():
        return amb
    amb.parent.mkdir(parents=True, exist_ok=True)
    _scrivi_ignora(radice)
    uv = trova_uv()
    if uv:
        _esegui([uv, "venv", "-q", "--python", sys.executable, str(amb)], radice, cosa="Creazione dell'ambiente")
    elif _pip_di_leo():
        # ambiente senza pip (si crea in un attimo): lo gestisce il pip di Leo con `--python`
        _esegui([sys.executable, "-m", "venv", "--without-pip", str(amb)], radice, cosa="Creazione dell'ambiente")
    else:
        _esegui([sys.executable, "-m", "venv", str(amb)], radice, cosa="Creazione dell'ambiente")
    return amb


def _pip_di_leo() -> bool:
    """Il Python di Leo ha un pip che sa lavorare su un altro ambiente (``--python``, pip 22.3+)?"""
    if os.environ.get("LEO_PIP_INTERNO", "").strip() == "1":
        return False
    try:
        import importlib.metadata as im

        numeri = [int(x) for x in re.findall(r"\d+", im.version("pip"))[:2]]
    except Exception:  # noqa: BLE001 - pip assente
        return False
    return tuple(numeri) >= (22, 3)


def _pip(radice: Path) -> list[str]:
    """Il comando pip che lavora sull'ambiente del progetto."""
    python = str(_python_ambiente(radice))
    pip_interno = (radice / AMBIENTE).glob("lib/python*/site-packages/pip") if os.name != "nt" else \
        (radice / AMBIENTE).glob("Lib/site-packages/pip")
    if any(True for _ in pip_interno) or not _pip_di_leo():
        return [python, "-m", "pip"]
    return [sys.executable, "-m", "pip", "--python", python]


def _scrivi_ignora(radice: Path) -> None:
    """``.leo/.gitignore``: la cartella non va nel controllo di versione (leo.lock sì)."""
    cartella = radice / CARTELLA_LEO
    cartella.mkdir(parents=True, exist_ok=True)
    ignora = cartella / ".gitignore"
    if not ignora.exists():
        ignora.write_text("# Creata da Leo: si ricrea con `leo sincronizza`.\n*\n", encoding="utf-8")


# ===========================================================================
# Risoluzione delle dipendenze Python
# ===========================================================================

def _requisito(nome: str, vincolo: str) -> str:
    vincolo = (vincolo or "*").strip()
    if vincolo in ("*", ""):
        return nome
    if re.match(r"^\d", vincolo):
        vincolo = "==" + vincolo
    return nome + vincolo


def _leggi_compilato(testo: str) -> list[dict]:
    """Voci (nome, versione, impronte) dall'uscita di ``uv pip compile --generate-hashes``."""
    voci: list[dict] = []
    testo = re.sub(r"\\\s*\n", " ", testo)
    for riga in testo.splitlines():
        riga = riga.split("#", 1)[0].strip()
        m = re.match(r"^([A-Za-z0-9][A-Za-z0-9._-]*)(?:\[[^\]]*\])?==([^\s;]+)(.*)$", riga)
        if not m:
            continue
        impronte = sorted(set(re.findall(r"--hash=sha256:([0-9a-f]{64})", m.group(3))))
        voci.append({"nome": normalizza(m.group(1)), "versione": m.group(2), "sha256": impronte})
    return voci


def _nome_da_ruota(file: str) -> tuple[str, str] | None:
    m = re.match(r"^([A-Za-z0-9_.]+?)-(\d[^-]*)-.*\.whl$", file)
    if m:
        return normalizza(m.group(1)), m.group(2)
    m = re.match(r"^([A-Za-z0-9_.-]+?)-(\d[A-Za-z0-9_.!+]*)\.(tar\.gz|zip|tar\.bz2)$", file)
    if m:
        return normalizza(m.group(1)), m.group(2)
    return None


def risolvi_python(radice: Path, requisiti: list[str], *, indice: str, consenti_sorgenti: bool,
                   avvisa: Callable[[str], Any] = print) -> tuple[list[dict], str]:
    """Versioni esatte e impronte di tutti i pacchetti (anche indiretti). (voci, strumento)"""
    lavoro = radice / CARTELLA_LEO
    lavoro.mkdir(parents=True, exist_ok=True)
    _scrivi_ignora(radice)
    ingresso = lavoro / "requisiti.in"
    ingresso.write_text("\n".join(requisiti) + "\n", encoding="utf-8")
    if not requisiti:
        return [], "nessuno"
    binari = [] if consenti_sorgenti else ["--only-binary", ":all:"]
    uv = trova_uv()
    if uv:
        uscita = lavoro / "requisiti.compilati.txt"
        _esegui([uv, "pip", "compile", "-q", "--generate-hashes", "--no-header", "--no-annotate",
                 "--python-version", _versione_python(), *binari, *_opzioni_indice(indice),
                 "-o", str(uscita), str(ingresso)], radice, cosa="Calcolo delle versioni")
        return _leggi_compilato(uscita.read_text(encoding="utf-8")), "uv"
    # ripiego: pip scarica i file (anche le dipendenze) in una cartella nuova e se ne calcola l'impronta
    crea_ambiente(radice, avvisa=avvisa)
    temporanea = Path(tempfile.mkdtemp(prefix="scarico_", dir=str(lavoro)))
    try:
        _esegui([*_pip(radice), "download", "-q", "--disable-pip-version-check",
                 "-d", str(temporanea), *(["--only-binary=:all:"] if not consenti_sorgenti else []),
                 *_opzioni_indice(indice), "-r", str(ingresso)], radice, cosa="Calcolo delle versioni")
        cache = radice / CACHE_RUOTE
        cache.mkdir(parents=True, exist_ok=True)
        voci: dict[str, dict] = {}
        for f in sorted(temporanea.iterdir()):
            nv = _nome_da_ruota(f.name)
            if nv is None:
                continue
            voce = voci.setdefault(nv[0], {"nome": nv[0], "versione": nv[1], "sha256": []})
            voce["sha256"] = sorted(set(voce["sha256"]) | {impronta_file(f)})
            os.replace(f, cache / f.name)
        return list(voci.values()), "pip"
    finally:
        shutil.rmtree(temporanea, ignore_errors=True)


def _testo_requisiti_bloccati(voci: Iterable[dict]) -> str:
    righe = []
    for v in voci:
        impronte = v.get("sha256") or []
        if not impronte:
            controlla_impronta("", "", f"Il pacchetto `{v['nome']}`")
        righe.append(f"{v['nome']}=={v['versione']} " + " ".join(f"--hash=sha256:{h}" for h in impronte))
    return "\n".join(righe) + ("\n" if righe else "")


def installa_python(radice: Path, voci: list[dict], *, indice: str, consenti_sorgenti: bool = False,
                    avvisa: Callable[[str], Any] = print) -> None:
    """Rende ``.leo/ambiente`` identico alle ``voci`` del blocco (toglie anche il resto)."""
    crea_ambiente(radice, avvisa=avvisa)
    file = radice / CARTELLA_LEO / "requisiti.lock.txt"
    file.write_text(_testo_requisiti_bloccati(voci), encoding="utf-8")
    binari = [] if consenti_sorgenti else ["--only-binary", ":all:"]
    uv = trova_uv()
    python = str(_python_ambiente(radice))
    if uv and voci:
        _esegui([uv, "pip", "sync", "-q", "--require-hashes", *binari, *_opzioni_indice(indice),
                 "-p", python, str(file)], radice, cosa="Installazione")
    cache = radice / CACHE_RUOTE
    if voci and not uv:
        sorgenti = (["--find-links", str(cache)] if cache.is_dir() else []) + _opzioni_indice(indice)
        _esegui([*_pip(radice), "install", "-q", "--disable-pip-version-check", "--require-hashes",
                 "--no-deps", *(["--only-binary=:all:"] if not consenti_sorgenti else []), *sorgenti,
                 "-r", str(file)], radice, cosa="Installazione")
    # come `uv pip sync`: via ciò che non è nel blocco
    voluti = {v["nome"] for v in voci} | {"pip", "setuptools", "wheel"}
    in_piu = [d.nome for d in distribuzioni_installate(radice) if d.nome not in voluti]
    if in_piu:
        comando = [uv, "pip", "uninstall", "-q", "-p", python] if uv else [*_pip(radice), "uninstall", "-y", "-q"]
        _esegui([*comando, *in_piu], radice, cosa="Pulizia dell'ambiente")


# ===========================================================================
# Che cosa c'è nell'ambiente (dist-info)
# ===========================================================================

@dataclass
class Distribuzione:
    nome: str
    versione: str
    puro: bool
    moduli: list[str]
    file: list[str]                  # percorsi relativi a site-packages (da RECORD)
    cartella: Path                   # site-packages


def site_packages(radice: Path) -> Path | None:
    from .ponte_python import cartelle_python_progetto

    for c in cartelle_python_progetto(str(radice)):
        if "ambiente" in Path(c).parts:
            return Path(c)
    return None


def distribuzioni_installate(radice: Path) -> list[Distribuzione]:
    sp = site_packages(radice)
    if sp is None:
        return []
    risultato = []
    for info in sorted(sp.glob("*.dist-info")):
        try:
            metadati = (info / "METADATA").read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        nome = re.search(r"^Name:\s*(.+)$", metadati, re.M)
        ver = re.search(r"^Version:\s*(.+)$", metadati, re.M)
        if not nome or not ver:
            continue
        ruota = (info / "WHEEL").read_text(encoding="utf-8", errors="replace") if (info / "WHEEL").exists() else ""
        etichette = re.findall(r"^Tag:\s*(\S+)$", ruota, re.M)
        puro = bool(re.search(r"^Root-Is-Purelib:\s*true", ruota, re.M | re.I)) and bool(etichette) and all(
            e.endswith("-none-any") for e in etichette)
        file: list[str] = []
        if (info / "RECORD").exists():
            for riga in (info / "RECORD").read_text(encoding="utf-8", errors="replace").splitlines():
                rel = riga.split(",", 1)[0].strip()
                if rel and not rel.startswith("..") and not rel.startswith("/"):
                    file.append(rel)
        moduli: list[str] = []
        if (info / "top_level.txt").exists():
            moduli = [m.strip() for m in (info / "top_level.txt").read_text(encoding="utf-8").splitlines()
                      if m.strip()]
        if not moduli:
            for rel in file:
                prima = rel.split("/", 1)[0]
                if prima.endswith((".dist-info", ".data")) or prima == "__pycache__":
                    continue
                prima = re.sub(r"\.(py|pyd|so|pth)$", "", prima.split(".cpython")[0])
                if prima and prima.isidentifier() and prima not in moduli:
                    moduli.append(prima)
        risultato.append(Distribuzione(nome=normalizza(nome.group(1)), versione=ver.group(1).strip(), puro=puro,
                                       moduli=moduli, file=file, cartella=sp))
    return risultato


def nota_telefono(nome: str, puro: bool) -> str:
    if puro:
        return "sì"
    if normalizza(nome) in NATIVI_CHAQUOPY:
        return "solo con un guscio di Leo ricostruito"
    return "no"


# ===========================================================================
# Pacchetti Leo
# ===========================================================================

def _e_percorso(richiesta: str) -> bool:
    return (richiesta.startswith((".", "/", "~")) or "\\" in richiesta or richiesta.endswith(".zip")
            or bool(re.match(r"^[A-Za-z]:", richiesta)) or ("/" in richiesta and not richiesta.startswith("leo:")))


def _risolvi_leo(radice: Path, dichiarate: dict[str, Any], registro: str, *, cartella_tmp: Path,
                 avvisa: Callable[[str], Any]) -> list[dict]:
    """Sceglie le versioni dei pacchetti Leo (con le loro dipendenze Leo) e li prepara in ``cartella_tmp``.

    Restituisce le voci del blocco; ogni pacchetto è già estratto in ``cartella_tmp/<nome>``.
    """
    from . import pacchetti_leo as pl

    scelti: dict[str, dict] = {}
    vincoli: dict[str, list[tuple[str, str]]] = {}
    da_fare: list[tuple[str, Any, str]] = [(n, v, "progetto.toml") for n, v in sorted(dichiarate.items())]
    while da_fare:
        nome, richiesta, chi = da_fare.pop(0)
        pl.controlla_nome_leo(nome, chi)
        if isinstance(richiesta, dict) and richiesta.get("percorso"):
            vincolo = str(richiesta.get("versione", "*"))
        else:
            vincolo = str(richiesta.get("versione", "*") if isinstance(richiesta, dict) else richiesta)
        vincoli.setdefault(nome, []).append((vincolo, chi))
        if nome in scelti:
            if not pl.soddisfa(scelti[nome]["versione"], vincolo):
                elenco = "; ".join(f"`{v}` per {c}" for v, c in vincoli[nome])
                raise ErrorePacchetti(f"Vincoli incompatibili per il pacchetto Leo `{nome}`: {elenco} "
                                      f"(scelta: {scelti[nome]['versione']}).")
            continue
        arrivo = cartella_tmp / nome
        if isinstance(richiesta, dict) and richiesta.get("percorso"):
            origine = Path(str(richiesta["percorso"])).expanduser()
            if not origine.is_absolute():
                origine = (radice / origine).resolve()
            if not origine.exists():
                raise ErrorePacchetti(f"Il pacchetto Leo `{nome}` dovrebbe stare in `{origine}`, che non esiste.")
            if origine.is_dir():
                pl.copia_cartella(origine, arrivo)
            else:
                pl.estrai_archivio(origine.read_bytes(), arrivo, origine=str(origine))
            sha = pl.impronta_locale(origine)
            voce = {"nome": nome, "origine": "percorso", "percorso": str(richiesta["percorso"]), "sha256": sha}
        else:
            scelta = pl.scegli_dal_registro(registro, nome, vincolo)
            pl.scarica_ed_estrai(scelta, scelta.sha256, arrivo, origine=f"`{nome}` {scelta.versione}")
            voce = {"nome": nome, "origine": "registro", "url": scelta.url, "sha256": scelta.sha256}
        d = pl.leggi_descrittore(arrivo, origine=nome)
        if d.nome != nome:
            raise ErrorePacchetti(f"Il pacchetto richiesto come `{nome}` si chiama `{d.nome}` nel suo "
                                  "pacchetto.toml: rifiutato.")
        if not pl.soddisfa(d.versione, vincolo):
            raise ErrorePacchetti(f"Il pacchetto Leo `{nome}` è alla versione {d.versione}, ma serve `{vincolo}`.")
        voce.update({"versione": d.versione, "permessi": d.permessi, "principale": d.principale,
                     "dipendenze": d.dipendenze, "descrizione": d.descrizione})
        scelti[nome] = voce
        for n2, v2 in sorted(d.dipendenze_leo.items()):
            da_fare.append((n2, v2, f"`{nome}`"))
    return [scelti[n] for n in sorted(scelti)]


def _installa_leo_da_blocco(radice: Path, voci: list[dict], *, avvisa: Callable[[str], Any]) -> None:
    """Rende ``.leo/pacchetti`` identico al blocco, controllando ogni impronta."""
    from . import pacchetti_leo as pl

    base = radice / PACCHETTI_LEO
    base.mkdir(parents=True, exist_ok=True)
    voluti = {v["nome"] for v in voci}
    for vecchio in base.iterdir():
        if vecchio.is_dir() and vecchio.name not in voluti:
            shutil.rmtree(vecchio)
    for v in voci:
        nome = v["nome"]
        pl.controlla_nome_leo(nome)
        arrivo = base / nome
        segno = arrivo / ".impronta"
        if arrivo.is_dir() and segno.is_file() and segno.read_text(encoding="utf-8").strip() == v.get("sha256"):
            continue
        if v.get("origine") == "percorso":
            origine = Path(v["percorso"]).expanduser()
            origine = origine if origine.is_absolute() else (radice / origine).resolve()
            if not origine.exists():
                raise ErrorePacchetti(f"Il pacchetto Leo `{nome}` dovrebbe stare in `{origine}`, che non esiste.")
            controlla_impronta(v.get("sha256", ""), pl.impronta_locale(origine), f"Il pacchetto Leo `{nome}`")
            if origine.is_dir():
                pl.copia_cartella(origine, arrivo)
            else:
                pl.estrai_archivio(origine.read_bytes(), arrivo, origine=str(origine))
        else:
            pl.scarica_ed_estrai(v.get("url", ""), v.get("sha256", ""), arrivo, origine=f"Il pacchetto Leo `{nome}`")
        segno.write_text(v["sha256"] + "\n", encoding="utf-8")


def file_pacchetto_leo(modulo: str, cartelle: Sequence[str]) -> str | None:
    """Il file da eseguire per ``importa <modulo>`` se ``<modulo>`` è un pacchetto Leo del progetto."""
    from .ponte_python import trova_radice_progetto

    for c in cartelle:
        radice = trova_radice_progetto(c)
        if radice is None:
            continue
        cartella = os.path.join(radice, ".leo", "pacchetti", modulo)
        if not os.path.isdir(cartella):
            # progetto ricevuto da altri: i pacchetti Leo del blocco si preparano da soli
            if not os.path.isfile(os.path.join(radice, NOME_BLOCCO)):
                return None
            if modulo not in {v.get("nome") for v in leggi_blocco(radice).get("leo", [])}:
                return None
            try:
                prepara_se_serve(radice)
            except ErrorePacchetti as e:
                from .errori import ErroreValore

                raise ErroreValore(f"Non riesco a preparare i pacchetti del progetto: {e.messaggio}",
                                   suggerimento=e.suggerimento or "Scrivi `leo sincronizza`.") from None
            if not os.path.isdir(cartella):
                return None
        for nome in _principale_installato(cartella, modulo):
            percorso = os.path.join(cartella, nome)
            if os.path.isfile(percorso):
                return os.path.abspath(percorso)
        return None
    return None


def _principale_installato(cartella: str, modulo: str) -> list[str]:
    candidati = []
    descrittore = os.path.join(cartella, "pacchetto.toml")
    if os.path.isfile(descrittore):
        try:
            from .tomlutil import carica_toml

            principale = str((carica_toml(descrittore).get("pacchetto") or {}).get("principale", "") or "")
            if principale and ".." not in principale.replace("\\", "/").split("/"):
                candidati.append(principale)
        except Exception:  # noqa: BLE001 - descrittore rovinato: si prova coi nomi soliti
            pass
    return candidati + [f"{modulo}.leo", "principale.leo"]


# ===========================================================================
# Operazioni: aggiungi, togli, sincronizza
# ===========================================================================

@dataclass
class Esito:
    """Che cosa è successo (per la riga di comando e per Leo Studio)."""

    python: list[dict] = field(default_factory=list)
    leo: list[dict] = field(default_factory=list)
    avvisi: list[str] = field(default_factory=list)
    secondi: float = 0.0
    strumento: str = ""


def _conferma_predefinita(domanda: str) -> bool:
    if not sys.stdin or not sys.stdin.isatty():
        return False
    try:
        risposta = input(domanda + " [s/N] ")
    except EOFError:
        return False
    return risposta.strip().lower() in ("s", "si", "sì", "y", "yes")


def _analizza_richiesta(richiesta: str) -> tuple[str, str, str]:
    """``("python"|"leo"|"percorso", nome, vincolo)`` da una richiesta della riga di comando."""
    r = richiesta.strip()
    if r.startswith("python:"):
        r = r[len("python:"):]
        tipo = "python"
    elif r.startswith("leo:"):
        r = r[len("leo:"):]
        tipo = "leo"
    elif _e_percorso(r):
        return "percorso", r, ""
    else:
        tipo = "python"
    m = re.match(r"^([A-Za-z0-9][A-Za-z0-9._-]*)(\[[^\]]*\])?\s*(.*)$", r)
    if not m:
        raise ErrorePacchetti(f"`{richiesta}` non è un nome di pacchetto valido.",
                              suggerimento="Per esempio `leo aggiungi requests` o `leo aggiungi \"numpy>=2\"`.",
                              codice=2)
    nome = m.group(1)
    vincolo = (m.group(3) or "").strip() or "*"
    if not re.match(r"^(\*|[<>=!~^]=?\s*[\w.*]+(\s*,\s*[<>=!~^]=?\s*[\w.*]+)*|\d[\w.]*)$", vincolo):
        raise ErrorePacchetti(f"Vincolo di versione non valido in `{richiesta}`.",
                              suggerimento="Per esempio `requests>=2.31` o `numpy==2.1.0`.", codice=2)
    if tipo == "python" and m.group(2):
        nome += m.group(2)          # extra: requests[socks]
    return tipo, nome, vincolo


def aggiungi(radice: Path, richieste: Sequence[str], *, avvisa: Callable[[str], Any] = print,
             conferma: Callable[[str], bool] = _conferma_predefinita, si_a_tutto: bool = False,
             consenti_sorgenti: bool = False, indice: str | None = None, indice_leo: str | None = None) -> Esito:
    """``leo aggiungi``: annota le richieste in progetto.toml, ricalcola il blocco e installa."""
    if not richieste:
        raise ErrorePacchetti("Scrivi il nome del pacchetto, per esempio `leo aggiungi requests`.", codice=2)
    python, leo = dipendenze_dichiarate(radice)
    nuove_py = dict(python)
    nuove_leo = dict(leo)
    da_confermare: list[str] = []
    for richiesta in richieste:
        tipo, nome, vincolo = _analizza_richiesta(richiesta)
        if tipo == "percorso":
            from . import pacchetti_leo as pl

            origine = Path(nome).expanduser()
            assoluta = origine if origine.is_absolute() else (Path.cwd() / origine)
            if not assoluta.exists():
                raise ErrorePacchetti(f"Non trovo `{nome}`.", codice=2)
            with tempfile.TemporaryDirectory() as t:
                if assoluta.is_dir():
                    d = pl.leggi_descrittore(assoluta, origine=nome)
                else:
                    pl.estrai_archivio(assoluta.read_bytes(), Path(t) / "p", origine=nome)
                    d = pl.leggi_descrittore(Path(t) / "p", origine=nome)
            try:
                relativo = os.path.relpath(assoluta.resolve(), radice)
            except ValueError:                   # altra unità su Windows
                relativo = str(assoluta.resolve())
            nuove_leo[d.nome] = {"percorso": relativo.replace("\\", "/")}
        elif tipo == "leo":
            nuove_leo[nome] = vincolo
        else:
            base = normalizza(re.sub(r"\[.*$", "", nome))
            simile = nome_sospetto(base)
            if simile and base not in {normalizza(k) for k in python}:
                da_confermare.append(f"`{base}` assomiglia molto a `{simile}`, un pacchetto Python molto usato. "
                                     "Chi pubblica pacchetti malevoli usa spesso nomi così per ingannare.")
            for k in list(nuove_py):
                if normalizza(re.sub(r"\[.*$", "", k)) == base:
                    del nuove_py[k]
            nuove_py[nome] = vincolo
    for frase in da_confermare:
        avvisa("Attenzione: " + frase)
    if da_confermare and not si_a_tutto and not conferma("Vuoi installarlo comunque?"):
        raise ErrorePacchetti("Installazione annullata: nessun file è stato cambiato.",
                              suggerimento="Controlla il nome; se è proprio quello giusto ripeti con `--sì`.")
    esito = _aggiorna(radice, nuove_py, nuove_leo, avvisa=avvisa, conferma=conferma, si_a_tutto=si_a_tutto,
                      consenti_sorgenti=consenti_sorgenti, indice=indice, indice_leo=indice_leo,
                      nuovi_leo=set(nuove_leo) - set(leo) | {n for n in nuove_leo if nuove_leo[n] != leo.get(n)})
    file = radice / "progetto.toml"
    scrivi_sezione(file, "dipendenze", nuove_py)
    scrivi_sezione(file, "dipendenze_leo", nuove_leo)
    return esito


def togli(radice: Path, nomi: Sequence[str], *, avvisa: Callable[[str], Any] = print,
          indice: str | None = None, indice_leo: str | None = None) -> Esito:
    """``leo togli``: toglie da progetto.toml, ricalcola il blocco e pulisce l'ambiente."""
    if not nomi:
        raise ErrorePacchetti("Scrivi il nome del pacchetto da togliere, per esempio `leo togli requests`.", codice=2)
    python, leo = dipendenze_dichiarate(radice)
    nuove_py = dict(python)
    nuove_leo = dict(leo)
    for richiesta in nomi:
        nome = re.sub(r"^(python:|leo:)", "", richiesta.strip())
        tolto = False
        for k in list(nuove_py):
            if normalizza(re.sub(r"\[.*$", "", k)) == normalizza(nome) and not richiesta.startswith("leo:"):
                del nuove_py[k]
                tolto = True
        if nome in nuove_leo and not richiesta.startswith("python:"):
            del nuove_leo[nome]
            tolto = True
        if not tolto:
            bloccati = {v["nome"] for v in leggi_blocco(radice).get("python", [])}
            if normalizza(nome) in bloccati:
                raise ErrorePacchetti(f"`{nome}` non è in progetto.toml: c'è perché serve a un altro pacchetto.",
                                      suggerimento="Togli il pacchetto che lo richiede.")
            raise ErrorePacchetti(f"`{nome}` non è tra le dipendenze del progetto.",
                                  suggerimento="Scrivi `leo pacchetti` per vedere l'elenco.")
    esito = _aggiorna(radice, nuove_py, nuove_leo, avvisa=avvisa, conferma=lambda _d: True, si_a_tutto=True,
                      consenti_sorgenti=False, indice=indice, indice_leo=indice_leo, nuovi_leo=set())
    file = radice / "progetto.toml"
    scrivi_sezione(file, "dipendenze", nuove_py)
    scrivi_sezione(file, "dipendenze_leo", nuove_leo)
    return esito


def _aggiorna(radice: Path, python: dict[str, str], leo: dict[str, Any], *, avvisa: Callable[[str], Any],
              conferma: Callable[[str], bool], si_a_tutto: bool, consenti_sorgenti: bool,
              indice: str | None, indice_leo: str | None, nuovi_leo: set[str]) -> Esito:
    """Ricalcola il blocco dalle dipendenze dichiarate e rende l'ambiente identico."""
    from . import permessi_pacchetti as pp

    inizio = time.perf_counter()
    indice_py, registro_leo = registri(radice, indice=indice, indice_leo=indice_leo)
    esito = Esito()
    (radice / CARTELLA_LEO).mkdir(parents=True, exist_ok=True)
    _scrivi_ignora(radice)
    with tempfile.TemporaryDirectory(dir=str(radice / CARTELLA_LEO), prefix="prova_") as t:
        voci_leo = _risolvi_leo(radice, leo, registro_leo, cartella_tmp=Path(t), avvisa=avvisa) if leo else []
        # permessi dei pacchetti Leo nuovi: si mostrano e si chiede conferma
        con_permessi = [v for v in voci_leo if v.get("permessi") and (v["nome"] in nuovi_leo or not nuovi_leo)]
        vecchi = {v["nome"]: set(v.get("permessi", [])) for v in leggi_blocco(radice).get("leo", [])}
        da_chiedere = [v for v in con_permessi if set(v["permessi"]) - vecchi.get(v["nome"], set())]
        for v in da_chiedere:
            avvisa(f"Il pacchetto Leo `{v['nome']}` {v['versione']} chiede questi permessi:")
            for frase in pp.descrivi(v["permessi"]):
                avvisa(f"  - {frase}")
        if da_chiedere and not si_a_tutto and not conferma("Concedi questi permessi?"):
            raise ErrorePacchetti("Installazione annullata: permessi non concessi. Nessun file è stato cambiato.",
                                  suggerimento="Per concederli senza domanda usa `--sì`.")
        # requisiti Python: progetto + pacchetti Leo
        requisiti = [_requisito(n, v) for n, v in sorted(python.items())]
        for v in voci_leo:
            requisiti += [_requisito(n, w) for n, w in sorted(v.get("dipendenze", {}).items())]
        requisiti = list(dict.fromkeys(requisiti))
        if requisiti:
            avvisa("Calcolo le versioni dei pacchetti Python...")
        voci_py, strumento = risolvi_python(radice, requisiti, indice=indice_py,
                                            consenti_sorgenti=consenti_sorgenti, avvisa=avvisa)
        esito.strumento = strumento
        if voci_py:
            avvisa(f"Installo {len(voci_py)} pacchetti Python nell'ambiente del progetto...")
        installa_python(radice, voci_py, indice=indice_py, consenti_sorgenti=consenti_sorgenti, avvisa=avvisa)
        # pacchetti Leo: dalla cartella di prova al posto definitivo
        base = radice / PACCHETTI_LEO
        base.mkdir(parents=True, exist_ok=True)
        for vecchio in base.iterdir():
            if vecchio.is_dir() and vecchio.name not in {v["nome"] for v in voci_leo}:
                shutil.rmtree(vecchio)
        for v in voci_leo:
            arrivo = base / v["nome"]
            if arrivo.exists():
                shutil.rmtree(arrivo)
            shutil.move(str(Path(t) / v["nome"]), str(arrivo))
            (arrivo / ".impronta").write_text(v["sha256"] + "\n", encoding="utf-8")
    diretti = {normalizza(re.sub(r"\[.*$", "", n)) for n in python}
    for v in voci_leo:
        diretti |= {normalizza(n) for n in v.get("dipendenze", {})}
    installate = {d.nome: d for d in distribuzioni_installate(radice)}
    for v in voci_py:
        d = installate.get(v["nome"])
        v["diretto"] = v["nome"] in diretti
        v["puro"] = bool(d.puro) if d else False
        v["telefono"] = nota_telefono(v["nome"], v["puro"])
        v["moduli"] = d.moduli if d else []
        if v["diretto"] and not v["puro"]:
            esito.avvisi.append(f"`{v['nome']}` contiene codice nativo: funziona sul PC e nell'eseguibile, "
                                + ("ma sul telefono solo ricostruendo il guscio di Leo con quel pacchetto."
                                   if v["telefono"] != "no" else "ma non girerà nelle app per il telefono (Android)."))
    indiretti_nativi = [v["nome"] for v in voci_py if not v["diretto"] and not v["puro"]]
    if indiretti_nativi:
        esito.avvisi.append("Pacchetti nativi richiesti da altri (non andranno sul telefono): "
                            + ", ".join(indiretti_nativi) + ".")
    blocco = {
        "formato": FORMATO_BLOCCO,
        "python_versione": _versione_python(),
        "strumento": strumento,
        "impronta_dipendenze": impronta_dichiarazioni(python, leo),
        "python": voci_py,
        "leo": [{k: v[k] for k in ("nome", "versione", "origine", "percorso", "url", "sha256", "permessi",
                                   "principale", "dipendenze") if k in v and (v[k] or k == "permessi")}
                for v in voci_leo],
    }
    scrivi_blocco(radice, blocco)
    esito.python = voci_py
    esito.leo = voci_leo
    esito.secondi = time.perf_counter() - inizio
    for a in esito.avvisi:
        avvisa("Attenzione: " + a)
    return esito


def sincronizza(radice: Path, *, avvisa: Callable[[str], Any] = print, bloccato: bool = False,
                aggiorna: bool = False, consenti_sorgenti: bool = False, indice: str | None = None,
                indice_leo: str | None = None, si_a_tutto: bool = True) -> Esito:
    """``leo sincronizza``: l'ambiente diventa esattamente ``leo.lock``.

    Se ``progetto.toml`` è cambiato dopo il blocco (o il blocco manca), il blocco si
    ricalcola (vietato con ``bloccato``). ``aggiorna`` ricalcola sempre (versioni nuove).
    """
    python, leo = dipendenze_dichiarate(radice)
    blocco = leggi_blocco(radice)
    aggiornato = bool(blocco) and blocco.get("impronta_dipendenze") == impronta_dichiarazioni(python, leo)
    if aggiorna or not aggiornato:
        if bloccato:
            raise ErrorePacchetti(f"`{NOME_BLOCCO}` non corrisponde alle dipendenze di progetto.toml."
                                  if blocco else f"Manca `{NOME_BLOCCO}`.",
                                  suggerimento="Scrivi `leo sincronizza` (senza `--bloccato`) per ricalcolarlo.")
        if blocco and not aggiorna:
            avvisa("Le dipendenze di progetto.toml sono cambiate: ricalcolo il blocco.")
        return _aggiorna(radice, python, leo, avvisa=avvisa, conferma=lambda _d: si_a_tutto, si_a_tutto=si_a_tutto,
                         consenti_sorgenti=consenti_sorgenti, indice=indice, indice_leo=indice_leo,
                         nuovi_leo=set())
    inizio = time.perf_counter()
    indice_py, _registro = registri(radice, indice=indice, indice_leo=indice_leo)
    voci_py = list(blocco.get("python", []))
    for v in voci_py:
        if not v.get("sha256"):
            controlla_impronta("", "", f"Il pacchetto `{v['nome']}`")
    installa_python(radice, voci_py, indice=indice_py, consenti_sorgenti=consenti_sorgenti, avvisa=avvisa)
    _installa_leo_da_blocco(radice, list(blocco.get("leo", [])), avvisa=avvisa)
    return Esito(python=voci_py, leo=list(blocco.get("leo", [])), secondi=time.perf_counter() - inizio,
                 strumento="uv" if trova_uv() else "pip")


def verifica(radice: Path) -> list[str]:
    """Differenze tra l'ambiente e il blocco (lista vuota = tutto a posto)."""
    from . import pacchetti_leo as pl

    problemi: list[str] = []
    blocco = leggi_blocco(radice)
    if not blocco:
        python, leo = dipendenze_dichiarate(radice)
        return [f"Manca `{NOME_BLOCCO}`."] if (python or leo) else []
    python, leo = dipendenze_dichiarate(radice)
    if blocco.get("impronta_dipendenze") != impronta_dichiarazioni(python, leo):
        problemi.append("progetto.toml è cambiato dopo l'ultimo blocco: scrivi `leo sincronizza`.")
    installate = {d.nome: d.versione for d in distribuzioni_installate(radice)}
    for v in blocco.get("python", []):
        if not v.get("sha256"):
            problemi.append(f"`{v['nome']}`: manca l'impronta sha256 nel blocco.")
        if installate.get(v["nome"]) != v["versione"]:
            problemi.append(f"`{v['nome']}`: nel blocco {v['versione']}, installato "
                            f"{installate.get(v['nome'], 'niente')}.")
    voluti = {v["nome"] for v in blocco.get("python", [])} | {"pip", "setuptools", "wheel"}
    for nome in sorted(set(installate) - voluti):
        problemi.append(f"`{nome}` è installato ma non è nel blocco.")
    for v in blocco.get("leo", []):
        cartella = radice / PACCHETTI_LEO / v["nome"]
        if not cartella.is_dir():
            problemi.append(f"Il pacchetto Leo `{v['nome']}` non è installato.")
            continue
        try:
            d = pl.leggi_descrittore(cartella, origine=v["nome"])
        except ErrorePacchetti as e:
            problemi.append(e.messaggio)
            continue
        if d.versione != v.get("versione"):
            problemi.append(f"Il pacchetto Leo `{v['nome']}`: nel blocco {v.get('versione')}, installato {d.versione}.")
        if v.get("origine") == "percorso":
            origine = Path(v["percorso"]).expanduser()
            origine = origine if origine.is_absolute() else (radice / origine).resolve()
            if origine.exists() and pl.impronta_locale(origine) != v.get("sha256"):
                problemi.append(f"Il pacchetto Leo locale `{v['nome']}` è cambiato dopo il blocco: "
                                f"`leo aggiungi {v['percorso']}` per accettare le modifiche.")
    return problemi


def prepara_se_serve(radice: str | os.PathLike, *, avvisa: Callable[[str], Any] | None = None) -> bool:
    """Al primo avvio di un progetto ricevuto da altri: crea l'ambiente da ``leo.lock`` se manca.

    Restituisce True se ha installato qualcosa. Non ricalcola mai il blocco.
    """
    if os.environ.get("LEO_SINCRONIZZA_AUTO", "").strip() == "0" or getattr(sys, "frozen", False):
        return False                         # eseguibile: i pacchetti sono già dentro
    from .piattaforma import e_android

    if e_android():
        return False                         # app per il telefono: pacchetti puri già in .leo/python-*
    radice = Path(radice)
    blocco = leggi_blocco(radice)
    if not blocco:
        return False
    serve = (bool(blocco.get("python")) and site_packages(radice) is None) or any(
        not (radice / PACCHETTI_LEO / v["nome"]).is_dir() for v in blocco.get("leo", []))
    if not serve:
        return False
    scrivi = avvisa or (lambda t: print(t, file=sys.stderr))
    scrivi("Preparo i pacchetti del progetto da leo.lock (solo la prima volta)...")
    python, leo = dipendenze_dichiarate(radice)
    if blocco.get("impronta_dipendenze") != impronta_dichiarazioni(python, leo):
        return False                         # blocco vecchio: serve `leo sincronizza`, che lo dice
    sincronizza(radice, avvisa=scrivi, bloccato=True)
    return True


# ===========================================================================
# Per compila (exe) e apk
# ===========================================================================

@dataclass
class PartiDipendenze:
    """Che cosa includere in un eseguibile o in un'app."""

    radice: Path
    file_leo: list[tuple[Path, str]] = field(default_factory=list)       # (origine, ".leo/pacchetti/...")
    site_packages: Path | None = None
    moduli_python: list[str] = field(default_factory=list)              # per --collect-all
    python_puri: list[tuple[Path, str]] = field(default_factory=list)   # (origine, ".leo/python-<x>/...")
    non_puri: list[str] = field(default_factory=list)
    avvisi: list[str] = field(default_factory=list)

    @property
    def vuote(self) -> bool:
        return not self.file_leo and not self.moduli_python and not self.python_puri


def parti_per_distribuzione(cartella: str | os.PathLike, *, avvisa: Callable[[str], Any] | None = None
                            ) -> PartiDipendenze | None:
    """Le dipendenze del blocco del progetto che contiene ``cartella`` (None se non ce ne sono).

    Se l'ambiente non c'è ancora lo prepara dal blocco (come al primo avvio).
    """
    from .ponte_python import trova_radice_progetto

    r = trova_radice_progetto(cartella)
    if r is None:
        return None
    radice = Path(r)
    blocco = leggi_blocco(radice)
    if not blocco or (not blocco.get("python") and not blocco.get("leo")):
        return None
    parti = PartiDipendenze(radice=radice)
    try:
        prepara_se_serve(radice, avvisa=avvisa or (lambda _t: None))
    except ErrorePacchetti as e:
        parti.avvisi.append(f"Non riesco a preparare i pacchetti del progetto: {e.messaggio}")
    problemi = verifica(radice)
    if problemi:
        parti.avvisi.append("L'ambiente dei pacchetti non corrisponde a leo.lock ("
                            + "; ".join(problemi[:3]) + "): scrivi `leo sincronizza` prima di compilare.")
    for v in blocco.get("leo", []):
        cartella_p = radice / PACCHETTI_LEO / v["nome"]
        for p in sorted(cartella_p.rglob("*")):
            if p.is_file() and p.name != ".impronta":
                parti.file_leo.append((p, (PACCHETTI_LEO / v["nome"] / p.relative_to(cartella_p)).as_posix()))
    impronta = hashlib.sha256((radice / NOME_BLOCCO).read_bytes()).hexdigest()[:10]
    destinazione_telefono = f"{CARTELLA_LEO}/python-{impronta}"
    installate = {d.nome: d for d in distribuzioni_installate(radice)}
    for v in blocco.get("python", []):
        d = installate.get(v["nome"])
        if d is None:
            continue
        parti.site_packages = d.cartella
        parti.moduli_python += [m for m in d.moduli if m not in parti.moduli_python]
        if d.puro:
            for rel in d.file:
                if rel.endswith((".pyc", ".pyo")) or "__pycache__" in rel or rel.split("/", 1)[0].endswith(".data"):
                    continue
                p = d.cartella / rel
                if p.is_file():
                    parti.python_puri.append((p, f"{destinazione_telefono}/{rel}"))
        else:
            parti.non_puri.append(v["nome"])
    return parti


# ===========================================================================
# Riga di comando
# ===========================================================================

def _parser(comando: str) -> argparse.ArgumentParser:
    descrizioni = {
        "aggiungi": "Aggiunge pacchetti Python o Leo al progetto (solo per questo progetto).",
        "togli": "Toglie pacchetti dal progetto.",
        "sincronizza": "Rende l'ambiente del progetto identico a leo.lock.",
        "pacchetti": "Elenca i pacchetti del progetto.",
    }
    p = argparse.ArgumentParser(prog=f"leo {comando}", description=descrizioni[comando])
    if comando in ("aggiungi", "togli"):
        p.add_argument("nomi", nargs="*", help="pacchetti: requests, \"numpy>=2\", leo:nome, ./cartella")
    if comando in ("aggiungi", "togli", "sincronizza"):
        p.add_argument("--indice", default=None, help="indice Python: cartella di wheel o indirizzo")
        p.add_argument("--indice-leo", default=None, help="registro dei pacchetti Leo: cartella o indirizzo")
    if comando in ("aggiungi", "sincronizza"):
        p.add_argument("--consenti-sorgenti", action="store_true",
                       help="permette di compilare pacchetti dal codice sorgente (esegue il loro setup)")
    if comando == "aggiungi":
        p.add_argument("--sì", "--si", "-s", dest="si", action="store_true",
                       help="non chiede conferma (nomi simili a pacchetti famosi, permessi)")
    if comando == "sincronizza":
        p.add_argument("--bloccato", action="store_true", help="errore se leo.lock non è aggiornato (per i server)")
        p.add_argument("--aggiorna", action="store_true", help="ricalcola tutte le versioni (le più nuove permesse)")
    if comando == "pacchetti":
        p.add_argument("--verifica", action="store_true", help="controlla che l'ambiente corrisponda a leo.lock")
        p.add_argument("--json", action="store_true", help="elenco in formato JSON")
    p.add_argument("--progetto", default=None, help="cartella del progetto (predefinita: quella attuale)")
    return p


def _stampa_esito(esito: Esito, cosa: str) -> None:
    diretti = [v for v in esito.python if v.get("diretto")]
    righe = [f"{cosa} in {esito.secondi:.2f} s"
             + (f" ({esito.strumento})" if esito.strumento not in ("", "nessuno") else "") + "."]
    if esito.python:
        righe.append(f"Python: {len(diretti)} diretti, {len(esito.python) - len(diretti)} indiretti.")
    if esito.leo:
        righe.append("Leo: " + ", ".join(f"{v['nome']} {v['versione']}" for v in esito.leo) + ".")
    print("\n".join(righe))


def _elenco(radice: Path, *, come_json: bool) -> int:
    blocco = leggi_blocco(radice)
    python, leo = dipendenze_dichiarate(radice)
    if come_json:
        print(json.dumps({"python": blocco.get("python", []), "leo": blocco.get("leo", []),
                          "dichiarate": {"python": python, "leo": leo}}, ensure_ascii=False, indent=1))
        return 0
    if not blocco.get("python") and not blocco.get("leo"):
        if python or leo:
            print("Ci sono dipendenze in progetto.toml ma non leo.lock: scrivi `leo sincronizza`.")
        else:
            print("Il progetto non ha pacchetti aggiunti. Leo include già tutto per l'uso normale; per una "
                  "libreria Python scrivi `leo aggiungi nome`.")
        return 0
    if blocco.get("python"):
        print("Pacchetti Python:")
        larghezza = max(len(v["nome"]) for v in blocco["python"])
        for v in blocco["python"]:
            tipo = "diretto  " if v.get("diretto") else "indiretto"
            print(f"  {v['nome']:<{larghezza}}  {v['versione']:<12} {tipo}  telefono: {v.get('telefono', '?')}")
    if blocco.get("leo"):
        print("Pacchetti Leo:")
        for v in blocco["leo"]:
            permessi = ", ".join(v.get("permessi", [])) or "nessuno"
            dove = v.get("percorso") or "registro"
            print(f"  {v['nome']}  {v['versione']}  permessi: {permessi}  ({dove})")
    return 0


def comando_pacchetti(comando: str, argomenti: list[str]) -> int:
    """Esegue ``leo aggiungi | togli | sincronizza | pacchetti``."""
    args = _parser(comando).parse_args(argomenti)
    try:
        radice = radice_progetto(args.progetto)
        if comando == "aggiungi":
            esito = aggiungi(radice, args.nomi, si_a_tutto=args.si, consenti_sorgenti=args.consenti_sorgenti,
                             indice=args.indice, indice_leo=args.indice_leo)
            _stampa_esito(esito, "Aggiunto " + ", ".join(args.nomi))
        elif comando == "togli":
            esito = togli(radice, args.nomi, indice=args.indice, indice_leo=args.indice_leo)
            _stampa_esito(esito, "Tolto " + ", ".join(args.nomi))
        elif comando == "sincronizza":
            esito = sincronizza(radice, bloccato=args.bloccato, aggiorna=args.aggiorna,
                                consenti_sorgenti=args.consenti_sorgenti, indice=args.indice,
                                indice_leo=args.indice_leo)
            _stampa_esito(esito, f"Ambiente identico a {NOME_BLOCCO}")
        else:
            if args.verifica:
                problemi = verifica(radice)
                if problemi:
                    print("L'ambiente non corrisponde a leo.lock:", file=sys.stderr)
                    for p in problemi:
                        print(f"  - {p}", file=sys.stderr)
                    return 1
                print("Tutto a posto: l'ambiente corrisponde a leo.lock.")
                return 0
            return _elenco(radice, come_json=args.json)
        return 0
    except ErrorePacchetti as e:
        print(str(e), file=sys.stderr)
        return e.codice
    except KeyboardInterrupt:
        print("Interrotto.", file=sys.stderr)
        return 130
