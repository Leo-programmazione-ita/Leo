"""Pila delle chiamate negli errori ("Chiamate (dalla più recente):").

La pila NON si tiene aggiornata durante l'esecuzione (costerebbe a ogni
chiamata): si ricostruisce solo quando c'e' un errore, mentre l'eccezione
risale le funzioni.

* ``Interprete._completa`` (chiamato per ogni nodo che l'errore attraversa,
  dal piu' interno) ricorda in ``errore._riga_qui`` la riga del PRIMO nodo
  del passo corrente: nella funzione dove e' nato l'errore e' la riga
  dell'errore, nelle funzioni chiamanti e' la riga della chiamata;
* quando l'errore esce da una funzione Leo, :func:`esci_da_funzione` aggiunge
  un :class:`~leo.errori.PassoPila` (funzione, file, riga, argomenti) e
  azzera ``_riga_qui``;
* al livello piu' esterno (programma principale, gestore ``quando``, codice
  principale di un file importato) :func:`chiudi` aggiunge l'ultimo passo.

:func:`righe_pila` produce il testo mostrato all'utente; se l'errore e' nato
al livello principale (pila vuota) non c'e' nessuna sezione, cosi' i messaggi
semplici restano semplici.
"""

from __future__ import annotations

from typing import Any

from .errori import PassoPila

__all__ = ["esci_da_funzione", "chiudi", "azzera", "righe_pila", "descrivi_passo", "PRIMI", "ULTIMI"]

#: Passi mostrati all'inizio e alla fine di una pila lunga (ricorsione profonda).
PRIMI = 3
ULTIMI = 3
#: Caratteri al massimo per il valore di un argomento e per tutti gli argomenti.
_MAX_VALORE = 20
_MAX_ARGOMENTI = 60
#: Passi ricordati al massimo (oltre si contano soltanto).
_MAX_PASSI = 5000

_ANONIMI = frozenset({"", "<sorgente>"})


def _taglia(testo: str, massimo: int) -> str:
    return testo if len(testo) <= massimo else testo[:massimo - 1] + "…"


def _breve(valore: Any) -> str:
    """Testo breve di un valore (senza calcolare la rappresentazione di liste enormi)."""
    from .valori import rappresenta

    if isinstance(valore, str):
        return rappresenta(_taglia(valore, _MAX_VALORE - 2), dentro=True) if len(valore) > _MAX_VALORE - 2 \
            else rappresenta(valore, dentro=True)
    if isinstance(valore, (list, tuple)) and len(valore) > 8:
        return f"[… {len(valore)} elementi]"
    if isinstance(valore, dict) and len(valore) > 5:
        return f"{{… {len(valore)} chiavi}}"
    return _taglia(rappresenta(valore, dentro=True), _MAX_VALORE)


def _testo_argomenti(f: Any, argomenti: Any, argomenti_nome: Any) -> str:
    try:
        parametri = list(getattr(f, "parametri", None) or ())
        parti: list[str] = []
        for i, valore in enumerate(argomenti or ()):
            p = parametri[i] if i < len(parametri) else None
            if p is not None and not getattr(p, "variadico", False):
                parti.append(f"{p.nome} = {_breve(valore)}")
            else:
                parti.append(_breve(valore))
        for nome, valore in (argomenti_nome or {}).items():
            parti.append(f"{nome} = {_breve(valore)}")
        return _taglia(", ".join(parti), _MAX_ARGOMENTI)
    except Exception:  # noqa: BLE001 - gli argomenti sono solo un aiuto
        return ""


def _aggiungi(errore: Any, passo: PassoPila | None) -> None:
    pila = errore.__dict__.get("pila_chiamate")
    if pila is None:
        pila = errore.pila_chiamate = []
        errore._passi_omessi = 0
    if passo is not None:
        if len(pila) < _MAX_PASSI:
            pila.append(passo)
        else:
            errore._passi_omessi = getattr(errore, "_passi_omessi", 0) + 1
    errore._riga_qui = 0


def esci_da_funzione(errore: Any, f: Any, argomenti: Any = (), argomenti_nome: Any = None) -> None:
    """L'errore sta uscendo dalla funzione Leo ``f``: aggiunge il suo passo."""
    try:
        nome = str(getattr(f, "nome", "") or "")
        if nome == "<anonima>":
            genere = "anonima"
        elif nome.startswith("<"):
            genere, nome = "speciale", nome.strip("<>")
        else:
            genere = "funzione"
        riga = errore._riga_qui or getattr(f, "riga", 0) or 0
        testo = _testo_argomenti(f, argomenti, argomenti_nome) if genere != "speciale" else ""
        if not errore.__dict__.get("pila_chiamate"):
            # primo passo: e' la funzione dove l'errore e' nato. Nel REPL la funzione
            # ricorda il testo dell'immissione in cui e' stata scritta.
            testo_f = getattr(f, "__dict__", {}).get("_leo_testo")
            if testo_f is not None and getattr(errore, "sorgente_file", None) is None:
                errore.sorgente_file = testo_f
        _aggiungi(errore, PassoPila(genere, nome, str(getattr(f, "nome_file", "") or ""), int(riga), testo))
    except Exception:  # noqa: BLE001 - la pila non deve mai sostituire l'errore vero
        pass


def chiudi(errore: Any, genere: str, nome: str, nome_file: str, *, sempre: bool = False) -> None:
    """Aggiunge il passo piu' esterno (``principale``, ``gestore`` o ``modulo``).

    Senza ``sempre`` il passo si aggiunge solo se l'errore ha gia' attraversato
    almeno una funzione (altrimenti la pila resta vuota e non si mostra)."""
    try:
        pila = errore.__dict__.get("pila_chiamate")
        if not pila and not sempre:
            errore._riga_qui = 0
            return
        if pila and pila[-1].genere == "principale":
            return  # gia' chiusa (esecuzioni annidate)
        riga = errore._riga_qui or 0
        if not riga and genere == "principale":
            # errore partito dai temporizzatori dopo la fine del programma
            # principale: non c'e' una riga del programma da mostrare
            errore._riga_qui = 0
            return
        _aggiungi(errore, PassoPila(genere, nome, str(nome_file or ""), int(riga)))
    except Exception:  # noqa: BLE001
        pass


def azzera(errore: Any) -> None:
    """L'errore e' stato gestito (``cattura`` finita senza rilanciarlo): se piu'
    avanti lo stesso valore viene lanciato di nuovo con ``lancia``, pila e
    posizione ripartono da li' (vedi ``Interprete.visita_Lancia``)."""
    d = errore.__dict__
    d.pop("pila_chiamate", None)
    d.pop("_passi_omessi", None)
    d.pop("_riga_qui", None)
    d["_gestito"] = True


def descrivi_passo(passo: PassoPila) -> str:
    """"dentro `calcola(dati = [1, 2])`", "nel programma principale"..."""
    g = passo.genere
    if g == "principale":
        return "nel programma principale"
    if g == "modulo":
        return f"nel file importato `{passo.nome}`"
    if g == "verifica":
        return f"nella verifica {passo.nome}"
    if g == "gestore":
        return f"dentro `quando {passo.nome}`"
    if g == "speciale":
        return f"dentro il blocco `{passo.nome}`"
    if g == "anonima":
        return "dentro la funzione anonima" + (f" ({passo.argomenti})" if passo.argomenti else "")
    return f"dentro `{passo.nome}({passo.argomenti})`"


def _dove(passo: PassoPila) -> str:
    if passo.nome_file and passo.nome_file not in _ANONIMI and passo.riga:
        return f"{passo.nome_file}:{passo.riga}"
    if passo.riga:
        return f"riga {passo.riga}"
    return passo.nome_file if passo.nome_file not in _ANONIMI else "?"


def righe_pila(errore: Any) -> list[str] | None:
    """Righe della sezione "Chiamate (dalla più recente):" o None se non serve
    (errore nato al livello principale: meno di due passi)."""
    pila = list(getattr(errore, "pila_chiamate", None) or ())
    if len(pila) < 2:
        return None
    omessi = int(getattr(errore, "_passi_omessi", 0) or 0)
    if len(pila) + omessi > PRIMI + ULTIMI + 1:
        mostrati: list[PassoPila | int] = [*pila[:PRIMI], len(pila) + omessi - PRIMI - ULTIMI, *pila[-ULTIMI:]]
    else:
        mostrati = list(pila)
    luoghi = [_dove(p) for p in mostrati if isinstance(p, PassoPila)]
    larghezza = max(len(x) for x in luoghi)
    righe = ["Chiamate (dalla più recente):"]
    for p in mostrati:
        if isinstance(p, int):
            righe.append(f"    … altre {p} chiamate …")
        else:
            righe.append(f"    {_dove(p).ljust(larghezza)}  {descrivi_passo(p)}")
    return righe
