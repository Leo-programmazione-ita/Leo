"""Modello dei valori di Leo (CONTRATTO CONDIVISO).

Corrispondenza tra tipi Leo e oggetti Python:

    Leo        Python                                   nome_tipo()
    ----------   --------------------------------------   ------------
    intero       int (MAI bool)                           "intero"
    decimale     float                                    "decimale"
    testo        str                                      "testo"
    logico       bool                                     "logico"
    nulla        None                                     "nulla"
    lista        list                                     "lista"
    dizionario   dict (chiavi: str, int, bool)            "dizionario"
    funzione     Richiamabile (FunzioneDante, FunzioneNativa, MetodoLegato)  "funzione"
    intervallo   range (prodotto da ``a..b`` e intervallo())                 "intervallo"
    errore       istanza di leo.errori.ErroreDante      "errore"
    controllo    OggettoControllo (controlli grafici)      "controllo"
    forma        leo.grafica.forme.Forma                 "forma"

Ganci per tipi aggiuntivi (es. Forma): un oggetto con attributo di classe
``NOME_TIPO_DANTE = "forma"`` e metodo ``testo_dante() -> str`` viene gestito
da ``nome_tipo`` e ``rappresenta`` senza modificare questo modulo.

Nota: i controlli di tipo dell'aritmetica stanno in ``leo.operazioni``.
"""

from __future__ import annotations

import inspect
import math
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Callable, Iterator

from .errori import ErroreDante, ErroreTipo, ErroreValore

if TYPE_CHECKING:  # solo per i suggerimenti di tipo
    from .ambiente import Ambiente
    from .nodi import Istruzione, Parametro


# ===========================================================================
# Funzioni (valori richiamabili)
# ===========================================================================

class Richiamabile(ABC):
    """Qualunque valore Leo che si puo' chiamare con ``f(...)``."""

    nome: str  # nome mostrato nei messaggi ("<anonima>" per le funzioni anonime)

    @abstractmethod
    def chiama(self, interprete: Any, argomenti: list, argomenti_nome: dict[str, Any]) -> Any:
        """Esegue la chiamata e restituisce un valore Leo."""

    def testo_dante(self) -> str:
        return f"<funzione {self.nome}>"


@dataclass(eq=False)
class FunzioneDante(Richiamabile):
    """Funzione definita dall'utente (anche anonima o gestore di evento).

    ``chiusura``: l'Ambiente in cui la funzione e' nata (chiusure lessicali).
    La chiamata vera e propria e' fatta dall'interprete:
    ``interprete.chiama_funzione_dante(self, argomenti, argomenti_nome)``.
    """

    nome: str
    parametri: "list[Parametro]"
    corpo: "list[Istruzione]"
    chiusura: "Ambiente"
    riga: int = 0
    colonna: int = 0

    # Attributi di classe (non campi): il file dove la funzione e' nata (lo scrive
    # l'interprete) e la via veloce del percorso compilato (``Compilatore.prepara``).
    nome_file = None
    _leo_p = None

    def chiama(self, interprete: Any, argomenti: list, argomenti_nome: dict[str, Any]) -> Any:
        return interprete.chiama_funzione_dante(self, argomenti, argomenti_nome)


class FunzioneNativa(Richiamabile):
    """Funzione di libreria scritta in Python.

    ``funzione`` riceve gli argomenti Leo gia' valutati (posizionali e per
    nome, con i nomi dei parametri Python = nomi Leo). Se
    ``vuole_interprete`` e' vero, riceve l'interprete come PRIMO argomento.

    ``e_metodo=True`` (metodi registrati con ``registro.metodo``): il primo
    parametro Python (dopo l'eventuale interprete) e' l'oggetto a sinistra
    del punto e NON conta negli argomenti mostrati all'utente. Quando la
    funzione e' chiamata tramite :class:`MetodoLegato` l'oggetto si salta
    comunque.

    Argomenti sbagliati (numero, nomi sconosciuti, un parametro dato due
    volte) diventano ``ErroreTipo`` in italiano, per esempio
    ``Il metodo `maiuscolo` non vuole argomenti, ma ne ha ricevuti 1.``
    oppure ```arrotonda` non ha un parametro `decimali`.``
    """

    def __init__(self, nome: str, funzione: Callable[..., Any], *,
                 vuole_interprete: bool = False, descrizione: str = "",
                 e_metodo: bool = False) -> None:
        self.nome = nome
        self.funzione = funzione
        self.vuole_interprete = vuole_interprete
        self.e_metodo = e_metodo
        # ``descrizione`` (dalla docstring) e ``firma`` (``inspect.signature``) si
        # calcolano alla prima lettura (vedi ``__getattr__``): all'avvio si registrano
        # centinaia di funzioni e quasi nessuna viene mai guardata.
        if descrizione:
            self.descrizione = descrizione

    def __getattr__(self, nome: str) -> Any:
        # chiamato solo se l'attributo non c'e' ancora nell'istanza
        if nome == "firma":
            try:
                firma: inspect.Signature | None = inspect.signature(self.funzione)
            except (TypeError, ValueError):
                firma = None
            self.firma = firma
            return firma
        if nome == "descrizione":
            self.descrizione = inspect.getdoc(self.funzione) or ""
            return self.descrizione
        raise AttributeError(f"{type(self).__name__!r} object has no attribute {nome!r}")

    def _limiti_posizionali(self) -> tuple[int, float] | None:
        """(minimo, massimo) di argomenti posizionali ammessi dalla firma, o None
        se la firma ha parametri solo-per-nome obbligatori (serve ``bind``)."""
        memo = self.__dict__.get("_memo_limiti")
        if memo is not None and memo[0] is self.firma:
            return memo[1]
        P = inspect.Parameter
        minimo = 0
        massimo: float = 0
        limiti: tuple[int, float] | None
        for p in self.firma.parameters.values():  # type: ignore[union-attr]
            if p.kind in (P.POSITIONAL_ONLY, P.POSITIONAL_OR_KEYWORD):
                massimo += 1
                if p.default is P.empty:
                    minimo = int(massimo)
            elif p.kind is P.VAR_POSITIONAL:
                massimo = float("inf")
            elif p.kind is P.KEYWORD_ONLY and p.default is P.empty:
                limiti = None
                break
        else:
            limiti = (minimo, massimo)
        self._memo_limiti = (self.firma, limiti)
        return limiti

    def _controlla_argomenti(self, argomenti: list, argomenti_nome: dict[str, Any], extra: int,
                             *, oggetto: bool | None = None, chi: str | None = None) -> None:
        """Verifica gli argomenti contro la firma Python.

        ``argomenti`` comprende l'oggetto del metodo (se ``oggetto``), non
        l'interprete (contato da ``extra``). ``oggetto=None`` vale
        ``self.e_metodo``; ``chi`` e' il nome mostrato nei messaggi.
        """
        if self.firma is None:
            return
        if not argomenti_nome:
            # via veloce: solo argomenti posizionali in numero giusto (niente `bind`)
            limiti = self._limiti_posizionali()
            if limiti is not None and limiti[0] <= extra + len(argomenti) <= limiti[1]:
                return
        try:
            self.firma.bind(*([None] * extra), *argomenti, **argomenti_nome)
            return
        except TypeError:
            pass
        if oggetto is None:
            oggetto = self.e_metodo
        P = inspect.Parameter
        salta = extra + (1 if oggetto else 0)
        parametri = list(self.firma.parameters.values())[salta:]
        posizionali = [p for p in parametri if p.kind in (P.POSITIONAL_ONLY, P.POSITIONAL_OR_KEYWORD)]
        nominabili = [p.name for p in parametri if p.kind in (P.POSITIONAL_OR_KEYWORD, P.KEYWORD_ONLY)]
        variabile = any(p.kind is P.VAR_POSITIONAL for p in parametri)
        per_nome_libero = any(p.kind is P.VAR_KEYWORD for p in parametri)
        codice = chi[1:-1] if chi and chi.startswith("`") and chi.endswith("`") else self.nome
        if chi is None:
            chi = f"Il metodo `{self.nome}`" if oggetto else f"`{self.nome}`"
        elenco = ", ".join(f"`{n}`" for n in nominabili)
        suggerimento = f"Parametri di `{self.nome}`: {elenco}." if elenco else None
        ricevuti = max(0, len(argomenti) - (1 if oggetto else 0))

        if not per_nome_libero:
            for n in argomenti_nome:
                if n not in nominabili:
                    if not nominabili:
                        raise ErroreTipo(f"{chi} non accetta argomenti per nome, ma ha ricevuto `{n} = ...`.")
                    raise ErroreTipo(f"{chi} non ha un parametro `{n}`.", suggerimento=suggerimento)
        for i, p in enumerate(posizionali):
            if p.name in argomenti_nome and i < ricevuti:
                raise ErroreTipo(f"{chi} ha ricevuto due volte `{p.name}`: una volta per posizione e una per nome.",
                                 suggerimento=suggerimento)

        totale = ricevuti + len(argomenti_nome)
        obbligatori = sum(1 for p in parametri
                          if p.kind in (P.POSITIONAL_ONLY, P.POSITIONAL_OR_KEYWORD, P.KEYWORD_ONLY)
                          and p.default is P.empty)
        massimo = len(posizionali) + sum(1 for p in parametri if p.kind is P.KEYWORD_ONLY)

        def quanti(n: int) -> str:
            return "1 argomento" if n == 1 else f"{n} argomenti"

        if variabile:
            attesi = f"almeno {quanti(obbligatori)}" if obbligatori else "qualunque numero di argomenti"
        elif massimo == 0:
            raise ErroreTipo(f"{chi} non vuole argomenti, ma ne ha ricevuti {totale}.",
                             suggerimento=f"Scrivi `{codice}()` con le parentesi vuote.")
        elif obbligatori == massimo:
            attesi = quanti(massimo)
        else:
            attesi = f"da {obbligatori} a {massimo} argomenti"
        raise ErroreTipo(f"{chi} vuole {attesi}, ma ne ha ricevuti {totale}.", suggerimento=suggerimento)

    def chiama(self, interprete: Any, argomenti: list, argomenti_nome: dict[str, Any]) -> Any:
        extra = 1 if self.vuole_interprete else 0
        self._controlla_argomenti(argomenti, argomenti_nome, extra)
        if self.vuole_interprete:
            return self.funzione(interprete, *argomenti, **argomenti_nome)
        return self.funzione(*argomenti, **argomenti_nome)

    def chiama_su(self, interprete: Any, oggetto: Any, argomenti: list, argomenti_nome: dict[str, Any],
                  *, chi: str | None = None) -> Any:
        """Chiama la funzione come metodo di ``oggetto`` (primo argomento Python,
        non contato nei messaggi d'errore)."""
        extra = 1 if self.vuole_interprete else 0
        tutti = [oggetto, *argomenti]
        self._controlla_argomenti(tutti, argomenti_nome, extra, oggetto=True, chi=chi)
        if self.vuole_interprete:
            return self.funzione(interprete, *tutti, **argomenti_nome)
        return self.funzione(*tutti, **argomenti_nome)


class MetodoLegato(Richiamabile):
    """``oggetto.metodo`` pronto da chiamare: passa ``oggetto`` come primo
    argomento (dopo l'eventuale interprete) alla FunzioneNativa del metodo.

    Nei messaggi d'errore l'oggetto non conta tra gli argomenti; per i
    controlli grafici il metodo si chiama ```Pulsante1.mostra```.
    """

    def __init__(self, oggetto: Any, metodo: FunzioneNativa) -> None:
        self.oggetto = oggetto
        self.metodo = metodo
        self.nome = metodo.nome

    def _chi(self) -> str | None:
        if isinstance(self.oggetto, OggettoControllo):
            return f"`{getattr(self.oggetto, 'nome', '?')}.{self.nome}`"
        return None

    def chiama(self, interprete: Any, argomenti: list, argomenti_nome: dict[str, Any]) -> Any:
        chiama_su = getattr(self.metodo, "chiama_su", None)
        if chiama_su is None:  # Richiamabile qualunque: comportamento storico
            return self.metodo.chiama(interprete, [self.oggetto, *argomenti], argomenti_nome)
        return chiama_su(interprete, self.oggetto, list(argomenti), argomenti_nome, chi=self._chi())


# ===========================================================================
# Controlli grafici visti dall'interprete
# ===========================================================================

class OggettoControllo(ABC):
    """Un controllo grafico visto dal codice Leo (``Pulsante1.testo``).

    Implementazione pura (senza Qt): ``leo.grafica.modello.ControlloVivo``.
    Il codice Leo lo usa cosi':
      * ``C.p``        -> ``leggi(p)``         (ErroreNome se p non esiste)
      * ``C.p = v``    -> ``scrivi(p, v)``     (ErroreTipo/ErroreValore se v non va bene)
      * ``C.m(args)``  -> ``metodo(m)`` restituisce un Richiamabile, poi chiamato
    L'interprete prova prima ``metodo(nome)``; se e' None usa ``leggi(nome)``.
    """

    NOME_TIPO_DANTE = "controllo"
    nome: str
    tipo_controllo: str

    @abstractmethod
    def leggi(self, proprieta: str) -> Any: ...

    @abstractmethod
    def scrivi(self, proprieta: str, valore: Any) -> None: ...

    def metodo(self, nome: str) -> Richiamabile | None:
        return None

    def elenco_proprieta(self) -> list[str]:
        return []

    def testo_dante(self) -> str:
        return f"<{self.tipo_controllo} {self.nome}>"


class Modulo:
    """Un modulo importato con ``importa ... come nome``: i suoi nomi si leggono
    con il punto (``geo.area(3)``, ``m.radice(9)``). Tipo Leo ``"modulo"``."""

    NOME_TIPO_DANTE = "modulo"

    def __init__(self, nome: str, voci: dict[str, Any], ambiente: Any = None,
                 visibili: "set[str] | frozenset[str] | None" = None) -> None:
        self.nome = nome
        self._voci = dict(voci)
        # Per un file importato: il suo ambiente, cosi' `m.conta` da' sempre il
        # valore attuale (anche dopo che una funzione del modulo l'ha cambiato).
        self._ambiente = ambiente
        # I nomi che il file mostra a chi lo importa (None = tutti): vedi `pubblica`.
        self._visibili = visibili

    def privato(self, nome: str) -> bool:
        """Vero se il file contiene ``nome`` ma non lo mostra (``_nome`` o senza ``pubblica``)."""
        if self._visibili is None or nome in self._visibili or self._ambiente is None:
            return False
        voce = self._ambiente.voci.get(nome)
        return voce is not None and not voce.implicito

    @property
    def voci(self) -> dict[str, Any]:
        if self._ambiente is None:
            return self._voci
        visibili = self._visibili
        return {n: v.valore for n, v in self._ambiente.voci.items()
                if not v.implicito and (visibili is None or n in visibili)}

    def leggi(self, nome: str) -> Any:
        """Valore del nome ``nome``; KeyError se il modulo non lo contiene (o non lo mostra)."""
        if self._ambiente is None:
            return self._voci[nome]
        voce = self._ambiente.voci.get(nome)
        if voce is None or voce.implicito or (self._visibili is not None and nome not in self._visibili):
            raise KeyError(nome)
        return voce.valore

    def testo_dante(self) -> str:
        return f"<modulo {self.nome}>"

    def __repr__(self) -> str:
        return f"Modulo({self.nome!r}, {sorted(self.voci)})"


# ===========================================================================
# Funzioni di utilita' sui valori
# ===========================================================================

def nome_tipo(v: Any) -> str:
    """Nome italiano del tipo di un valore Leo (quello di ``tipo(x)``)."""
    if v is None:
        return "nulla"
    if isinstance(v, bool):
        return "logico"
    if isinstance(v, int):
        return "intero"
    if isinstance(v, float):
        return "decimale"
    if isinstance(v, str):
        return "testo"
    if isinstance(v, list):
        return "lista"
    if isinstance(v, dict):
        return "dizionario"
    if isinstance(v, range):
        return "intervallo"
    if isinstance(v, Richiamabile):
        return "funzione"
    if isinstance(v, ErroreDante):
        return "errore"
    nome = getattr(type(v), "NOME_TIPO_DANTE", None)
    if nome:
        return nome
    return type(v).__name__  # non dovrebbe capitare: valore estraneo


#: Nomi di tipo femminili ("una `data`"); gli altri sono maschili ("un `intero`").
TIPI_FEMMINILI = frozenset({"lista", "funzione", "forma", "data", "frazione", "corrispondenza", "sequenza"})
#: Nomi di tipo al plurale: "dei `soldi`".
TIPI_PLURALI = frozenset({"soldi"})


def tipo_con_articolo(v: Any) -> str:
    """Tipo di ``v`` con l'articolo giusto: ``un `intero```, ``una `data```,
    ``dei `soldi```, ```nulla``` (senza articolo)."""
    t = nome_tipo(v)
    if t == "nulla":
        return "`nulla`"
    if t in TIPI_PLURALI:
        return f"dei `{t}`"
    return ("una" if t in TIPI_FEMMINILI else "un") + f" `{t}`"


def e_intero(v: Any) -> bool:
    if type(v) is int:  # via veloce (il caso di gran lunga piu' comune)
        return True
    return isinstance(v, int) and not isinstance(v, bool)


def e_numero(v: Any) -> bool:
    t = type(v)
    if t is int or t is float:  # via veloce
        return True
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _decimale_testo(x: float) -> str:
    if x != x:
        return "non_numero"
    if x in (float("inf"), float("-inf")):
        return "infinito" if x > 0 else "-infinito"
    return repr(x)


#: Fino a quante cifre (circa) un intero si scrive per intero; oltre, in forma
#: scientifica approssimata (la conversione esatta costa un tempo quadratico).
CIFRE_MASSIME_ESATTE = 20_000


def _intero_testo(n: int) -> str:
    """Cifre di un intero. Oltre il limite di Python (4300 cifre, per cui ``str``
    solleverebbe ``ValueError``) le cifre esatte si ottengono con ``decimal``
    fino a :data:`CIFRE_MASSIME_ESATTE`; oltre ancora, una forma scientifica
    approssimata come ``1.234567891e+50000``. Cosi' ``stampa(10 ^ 5000)``
    non va mai in errore e non blocca il programma."""
    try:
        return str(n)
    except ValueError:
        pass
    if n.bit_length() * 0.30103 < CIFRE_MASSIME_ESATTE:
        from decimal import Decimal

        return str(Decimal(n))
    segno = "-" if n < 0 else ""
    n = abs(n)
    # log10(n) dai 64 bit piu' alti: veloce anche per interi di milioni di cifre
    spostamento = max(0, n.bit_length() - 64)
    logaritmo = math.log10(n >> spostamento) + spostamento * math.log10(2)
    esponente = int(logaritmo)
    mantissa = 10 ** (logaritmo - esponente)
    if mantissa >= 10:  # arrotondamenti
        mantissa /= 10
        esponente += 1
    cifre = f"{mantissa:.9f}".rstrip("0")  # 10 cifre significative affidabili
    if cifre.endswith("."):
        cifre += "0"
    return f"{segno}{cifre}e+{esponente}"


def rappresenta(v: Any, *, dentro: bool = False) -> str:
    """Testo di un valore come lo mostra ``stampa`` / ``testo(x)``.

    ``dentro=True`` (elementi di liste e dizionari): i testi tra virgolette.
    Esempi: ``vero``, ``nulla``, ``3.5``, ``[1, "a", vero]``, ``{"nome": "Ada"}``,
    ``1..10``.
    """
    t = type(v)  # vie veloci per i casi piu' comuni (stessi risultati dei controlli sotto)
    if t is str and not dentro:
        return v
    if t is int:
        return _intero_testo(v)
    if v is None:
        return "nulla"
    if isinstance(v, bool):
        return "vero" if v else "falso"
    if isinstance(v, int):
        return _intero_testo(v)
    if isinstance(v, float):
        return _decimale_testo(v)
    if isinstance(v, str):
        if dentro:
            return '"' + v.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n") + '"'
        return v
    if isinstance(v, list):
        return "[" + ", ".join(rappresenta(x, dentro=True) for x in v) + "]"
    if isinstance(v, dict):
        return "{" + ", ".join(f"{rappresenta(k, dentro=True)}: {rappresenta(x, dentro=True)}"
                               for k, x in v.items()) + "}"
    if isinstance(v, range):
        # `a..b` solo se non e' vuoto: `intervallo(1, 5, -1)` non contiene nulla e
        # "1..5" direbbe il contrario (con passo 1 o -1 e almeno un elemento `a..b`
        # ha proprio gli stessi elementi)
        if (v.step == 1 or v.step == -1) and v:  # `v`, non len(v): puo' essere enorme
            ultimo = v.stop - v.step
            return f"{v.start}..{ultimo}"
        # crea_intervallo usa stop = a + 1 (o a - 1): si ricostruisce la `a` scritta
        # dall'utente, cosi' intervallo(0, 10, 3) si mostra uguale (prima: "0, 8, 3")
        fine = v.stop - (1 if v.step > 0 else -1)
        return f"intervallo({v.start}, {fine}, {v.step})"
    if isinstance(v, ErroreDante):
        return f"{v.tipo}: {v.messaggio}"
    testo = getattr(v, "testo_dante", None)
    if callable(testo):
        return testo()
    return repr(v)


def uguali(a: Any, b: Any) -> bool:
    """Uguaglianza di Leo (``==``): tipi diversi -> falso, tranne intero/decimale.

    ``vero == 1`` e' falso (in Python sarebbe vero). Liste e dizionari si
    confrontano elemento per elemento con la stessa regola.
    """
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool) and a == b
    if e_numero(a) and e_numero(b):
        return a == b
    if isinstance(a, list) and isinstance(b, list):
        return len(a) == len(b) and all(uguali(x, y) for x, y in zip(a, b))
    if isinstance(a, dict) and isinstance(b, dict):
        if len(a) != len(b):
            return False
        for k, x in a.items():
            trovato = False
            for k2, y in b.items():
                if uguali(k, k2):
                    trovato = uguali(x, y)
                    break
            if not trovato:
                return False
        return True
    if type(a) is not type(b):
        return False
    if isinstance(a, (str, range)) or a is None:
        return a == b
    if _uguaglianza_di_valore(type(a)):
        # tipi valore della libreria (data, frazione, soldi, complesso, forma...):
        # due valori con lo stesso contenuto sono uguali anche se creati a parte
        return bool(a == b)
    return a is b


def _uguaglianza_di_valore(tipo: type) -> bool:
    """Vero per i tipi Leo (con ``NOME_TIPO_DANTE``) che definiscono ``__eq__`` per valore."""
    return (getattr(tipo, "NOME_TIPO_DANTE", None) is not None
            and getattr(tipo, "__eq__", object.__eq__) is not object.__eq__)


def verifica_logico(v: Any, contesto: str) -> bool:
    """Per ``se``/``mentre``/``e``/``o``/``non``: solo ``vero``/``falso`` ammessi.

    ``contesto`` e' la parola chiave (es. "se"); ErroreTipo se ``v`` non e' logico.
    """
    if isinstance(v, bool):
        return v
    suggerimento = None
    if isinstance(v, (list, dict, str)):
        if contesto == "non":
            suggerimento = "Per controllare se è vuoto scrivi `vuota(...)`."
        elif contesto in ("e", "o"):
            suggerimento = "Per controllare se non è vuoto scrivi `non vuota(...)`."
        else:
            suggerimento = f"Per controllare se non è vuoto scrivi `{contesto} non vuota(...)`."
    raise ErroreTipo(
        f"La condizione di `{contesto}` deve essere `vero` o `falso`, non un valore di tipo `{nome_tipo(v)}`.",
        suggerimento=suggerimento,
    )


TIPI_CHIAVE = ("testo", "intero", "logico")


def verifica_chiave(k: Any) -> Any:
    """Chiavi di dizionario ammesse: testi, interi, logici. Restituisce ``k``."""
    t = type(k)
    if t is str or t is int:  # via veloce
        return k
    if isinstance(k, (str, bool)) or e_intero(k):
        return k
    raise ErroreTipo(f"Una chiave di dizionario deve essere testo, intero o logico, non `{nome_tipo(k)}`.")


def crea_intervallo(da: Any, a: Any, passo: Any = None) -> range:
    """Intervallo INCLUSIVO usato da ``da..a`` e da ``intervallo(da, a, passo)``.

    Senza passo: 1 se ``da <= a``, altrimenti -1 (``5..1`` conta all'indietro).
    """
    for nome, v in (("L'inizio", da), ("La fine", a)):
        if not e_intero(v):
            raise ErroreTipo(f"{nome} di un intervallo deve essere un intero, non `{nome_tipo(v)}`.")
    if passo is None:
        passo = 1 if da <= a else -1
    elif not e_intero(passo):
        raise ErroreTipo(f"Il passo di un intervallo deve essere un intero, non `{nome_tipo(passo)}`.")
    if passo == 0:
        raise ErroreValore("Il passo di un intervallo non può essere 0.")
    return range(da, a + (1 if passo > 0 else -1), passo)


def iterabile(v: Any) -> Iterator[Any]:
    """Cosa percorre ``per ogni``: liste (copia), testi (caratteri),
    intervalli, dizionari (chiavi, copia). Altrimenti ErroreTipo."""
    if isinstance(v, list):
        return iter(list(v))
    if isinstance(v, (str, range)):
        return iter(v)
    if isinstance(v, dict):
        return iter(list(v.keys()))
    elementi = getattr(type(v), "elementi_per_ogni", None)
    if elementi is not None:            # valori della libreria che si percorrono (canali, tabelle, oggetti del ponte Python)
        return iter(elementi(v))
    raise ErroreTipo(f"`per ogni` non può percorrere un valore di tipo `{nome_tipo(v)}`.",
                     suggerimento="Si possono percorrere liste, testi, intervalli e dizionari.")
