"""Operatori aritmetici, confronti e indici con controllo dei tipi (CONTRATTI.md §5).

Funzioni pure: gli errori NON hanno posizione (riga 0), la aggiunge l'interprete.

Regole principali (tipizzazione dinamica e forte):

* i logici (``vero``/``falso``) NON sono numeri: ``vero + 1`` e' un ``ErroreTipo``;
* ``+`` somma numeri, unisce testi e liste; ``"3" + 4`` e' un errore con il
  suggerimento di usare ``testo(4)``;
* ``/`` restituisce sempre un ``decimale``, ``//`` sempre un ``intero`` (parte
  intera per difetto), ``^`` un ``intero`` solo con base ed esponente interi
  (esponente >= 0);
* divisioni e resti per zero -> ``ErroreDivisione``; numeri troppo grandi ->
  ``ErroreValore``;
* indici interi (negativi dal fondo) su liste, testi e intervalli; chiavi di
  dizionario testo/intero/logico, con ``vero`` distinto da ``1``.
"""

from __future__ import annotations

import math
from typing import Any

from .errori import (ErroreChiave, ErroreDivisione, ErroreIndice, ErroreTipo,
                     ErroreValore)
from .valori import (e_intero, e_numero, rappresenta, tipo_con_articolo, uguali, verifica_chiave,
                     verifica_logico)

__all__ = ["binaria", "unaria", "confronta", "leggi_indice", "scrivi_indice"]

#: Limite (in bit) oltre il quale una potenza o un prodotto di interi e'
#: considerato troppo grande (circa 1,2 milioni di cifre).
LIMITE_BIT_POTENZA = 4_000_000
#: Limite di caratteri per la ripetizione ``testo * n``.
LIMITE_RIPETIZIONE = 100_000_000
#: Limite di elementi per la ripetizione ``lista * n`` (ogni elemento occupa
#: almeno 8 byte: 10 milioni sono gia' 80 MB).
LIMITE_RIPETIZIONE_LISTA = 10_000_000

_VERBI = {
    "+": "sommare",
    "-": "sottrarre",
    "*": "moltiplicare",
    "/": "dividere",
    "//": "dividere",
    "%": "calcolare il resto tra",
    "^": "elevare a potenza",
}

def _con_articolo(v: Any) -> str:
    """``un `intero```, ``una `lista```, ``dei `soldi```, ```nulla```."""
    return tipo_con_articolo(v)


def _troppo_grande() -> ErroreValore:
    return ErroreValore("Il risultato è troppo grande per essere calcolato.")


def _divisione_per_zero() -> ErroreDivisione:
    return ErroreDivisione("Divisione per zero.")


def _errore_tipi(operatore: str, a: Any, b: Any) -> ErroreTipo:
    verbo = _VERBI.get(operatore, f"usare `{operatore}` con")
    suggerimento = None
    if operatore == "+":
        if isinstance(a, str) and e_numero(b):
            suggerimento = f"Per unire un testo e un numero usa `testo({rappresenta(b)})`."
        elif isinstance(b, str) and e_numero(a):
            suggerimento = f"Per unire un testo e un numero usa `testo({rappresenta(a)})`."
        elif isinstance(a, str) or isinstance(b, str):
            suggerimento = "Per unire un testo e un altro valore usa `testo(...)`."
        elif isinstance(a, list) or isinstance(b, list):
            suggerimento = "Per aggiungere un elemento a una lista usa `.aggiungi(...)`."
    elif isinstance(a, bool) or isinstance(b, bool):
        suggerimento = "`vero` e `falso` non sono numeri."
    elif isinstance(a, str) or isinstance(b, str):
        if operatore in ("-", "/", "//", "%", "^", "*"):
            suggerimento = "Per trasformare un testo in numero usa `intero(...)` o `decimale(...)`."
    if operatore == "+" and (isinstance(a, bool) or isinstance(b, bool)) and suggerimento is None:
        suggerimento = "`vero` e `falso` non sono numeri."
    return ErroreTipo(f"Non posso {verbo} {_con_articolo(a)} e {_con_articolo(b)}.", suggerimento=suggerimento)


def _a_decimale(x: Any) -> float:
    try:
        return float(x)
    except OverflowError:
        raise _troppo_grande() from None


def _ripeti(sequenza: Any, volte: int) -> Any:
    limite = LIMITE_RIPETIZIONE_LISTA if isinstance(sequenza, list) else LIMITE_RIPETIZIONE
    if volte > 0 and len(sequenza) * volte > limite:
        raise ErroreValore("La ripetizione produrrebbe un valore troppo grande.")
    return sequenza * volte


def prodotto_troppo_grande(a: Any, b: Any) -> bool:
    """Vero se ``a * b`` tra interi supererebbe :data:`LIMITE_BIT_POTENZA`
    (``x = x * x`` ripetuto bloccherebbe il programma e la memoria)."""
    return type(a) is int and type(b) is int and a.bit_length() + b.bit_length() > LIMITE_BIT_POTENZA


def _potenza(a: Any, b: Any) -> Any:
    if e_intero(a) and e_intero(b) and b >= 0:
        if abs(a) > 1 and b > 0:
            bit = b * math.log2(abs(a))
            if bit > LIMITE_BIT_POTENZA:
                raise _troppo_grande()
        return a ** b
    fa = _a_decimale(a)
    fb = _a_decimale(b)
    if fa == 0 and fb < 0:
        raise ErroreDivisione("Divisione per zero: non posso elevare 0 a un esponente negativo.")
    try:
        return math.pow(fa, fb)
    except OverflowError:
        raise _troppo_grande() from None
    except ValueError:
        raise ErroreValore(
            "Il risultato di `^` non è un numero reale (base negativa con esponente non intero)."
        ) from None


def _altri_tipi(operatore: str, a: Any, b: Any) -> Any:
    """``a operatore b`` con tipi che Leo non conosce: chiede ai valori stessi (protocollo
    ``binaria_dante`` degli oggetti del ponte Python: numpy, Decimal, date...), altrimenti errore."""
    for v in (a, b):
        metodo = getattr(type(v), "binaria_dante", None)
        if metodo is not None:
            risultato = metodo(v, operatore, a, b)
            if risultato is not NotImplemented:
                return risultato
    raise _errore_tipi(operatore, a, b)


def binaria(operatore: str, a: Any, b: Any) -> Any:
    """Operazione aritmetica ``a operatore b`` (``+ - * / // % ^``)."""
    numeri = e_numero(a) and e_numero(b)
    try:
        if operatore == "+":
            if numeri:
                return a + b
            if isinstance(a, str) and isinstance(b, str):
                return a + b
            if isinstance(a, list) and isinstance(b, list):
                return a + b
            return _altri_tipi(operatore, a, b)
        if operatore == "-":
            if numeri:
                return a - b
            return _altri_tipi(operatore, a, b)
        if operatore == "*":
            if numeri:
                if prodotto_troppo_grande(a, b):
                    raise _troppo_grande()
                return a * b
            if isinstance(a, (str, list)) and e_intero(b):
                return _ripeti(a, b)
            if isinstance(b, (str, list)) and e_intero(a):
                return _ripeti(b, a)
            return _altri_tipi(operatore, a, b)
        if operatore == "/":
            if not numeri:
                return _altri_tipi(operatore, a, b)
            if b == 0:
                raise _divisione_per_zero()
            if isinstance(a, float) or isinstance(b, float):
                return _a_decimale(a) / _a_decimale(b)
            return a / b  # divisione vera tra interi: sempre decimale
        if operatore == "//":
            if not numeri:
                return _altri_tipi(operatore, a, b)
            if b == 0:
                raise _divisione_per_zero()
            if e_intero(a) and e_intero(b):
                return a // b
            risultato = _a_decimale(a) // _a_decimale(b)
            if math.isinf(risultato) or math.isnan(risultato):
                raise ErroreValore("Il risultato di `//` non è un numero finito.")
            return int(risultato)
        if operatore == "%":
            if not numeri:
                return _altri_tipi(operatore, a, b)
            if b == 0:
                raise _divisione_per_zero()
            if e_intero(a) and e_intero(b):
                return a % b
            return _a_decimale(a) % _a_decimale(b)
        if operatore == "^":
            if not numeri:
                return _altri_tipi(operatore, a, b)
            return _potenza(a, b)
    except OverflowError:
        raise _troppo_grande() from None
    except MemoryError:
        raise ErroreValore("Memoria esaurita: il risultato è troppo grande.") from None
    raise ErroreTipo(f"L'operatore `{operatore}` non esiste in Leo.")


def unaria(operatore: str, a: Any) -> Any:
    """``-a`` (solo numeri) oppure ``non a`` (solo logici)."""
    if operatore == "-":
        if e_numero(a):
            return -a
        metodo = getattr(type(a), "unaria_dante", None)
        if metodo is not None and (risultato := metodo(a, operatore)) is not NotImplemented:
            return risultato
        suggerimento = "`vero` e `falso` non sono numeri." if isinstance(a, bool) else None
        raise ErroreTipo(f"Il segno `-` si usa solo con i numeri, non con {_con_articolo(a)}.",
                         suggerimento=suggerimento)
    if operatore == "non":
        return not verifica_logico(a, "non")
    raise ErroreTipo(f"L'operatore `{operatore}` non esiste in Leo.")


# ---------------------------------------------------------------------------
# Confronti
# ---------------------------------------------------------------------------

def _identici(a: Any, b: Any) -> bool:
    if a is None or b is None or isinstance(a, bool) or isinstance(b, bool):
        return a is b
    if isinstance(a, (int, float, str, range)) and type(a) is type(b):
        return a == b  # valori immutabili: l'identita' coincide con il valore
    return a is b


def _cerca_chiave(d: dict, chiave: Any) -> tuple[bool, Any]:
    """(trovata, chiave_effettiva) distinguendo ``vero`` da ``1`` e ``falso`` da ``0``."""
    if isinstance(chiave, bool) or (e_intero(chiave) and chiave in (0, 1)):
        for k in d:
            if isinstance(k, bool) == isinstance(chiave, bool) and k == chiave:
                return True, k
        return False, None
    try:
        if chiave in d:
            return True, chiave
    except TypeError:  # valore non "hashable" (lista...): non puo' essere una chiave
        return False, None
    return False, None


def _in(a: Any, b: Any) -> bool:
    if isinstance(b, str):
        if not isinstance(a, str):
            raise ErroreTipo(f"Per cercare dentro un testo serve un testo, non {_con_articolo(a)}.",
                             suggerimento=f"Usa `testo({rappresenta(a, dentro=True)})`." if e_numero(a) else None)
        return a in b
    if isinstance(b, list):
        return any(uguali(a, x) for x in b)
    if isinstance(b, dict):
        # stessa regola di `d[chiave]` e `d.ha(chiave)`: solo testi, interi e logici
        verifica_chiave(a)
        return _cerca_chiave(b, a)[0]
    if isinstance(b, range):
        if e_intero(a):
            return a in b
        if isinstance(a, float) and a.is_integer():
            return int(a) in b
        return False
    contiene = getattr(type(b), "contiene_dante", None)
    if contiene is not None:
        return bool(contiene(b, a))
    raise ErroreTipo(f"`in` si usa con testi, liste, dizionari e intervalli, non con {_con_articolo(b)}.")


def confronta(operatore: str, a: Any, b: Any) -> bool:
    """Confronto ``a operatore b``; restituisce sempre un logico."""
    if operatore == "==":
        return uguali(a, b)
    if operatore == "!=":
        return not uguali(a, b)
    if operatore in ("<", "<=", ">", ">="):
        if (e_numero(a) and e_numero(b)) or (isinstance(a, str) and isinstance(b, str)):
            try:
                if operatore == "<":
                    return a < b
                if operatore == "<=":
                    return a <= b
                if operatore == ">":
                    return a > b
                return a >= b
            except OverflowError:  # pragma: no cover - int enorme contro float
                raise _troppo_grande() from None
        for v in (a, b):
            metodo = getattr(type(v), "binaria_dante", None)
            if metodo is not None and (risultato := metodo(v, operatore, a, b)) is not NotImplemented:
                return verifica_logico(risultato, operatore) if not isinstance(risultato, bool) else risultato
        suggerimento = None
        if (isinstance(a, str) and e_numero(b)) or (isinstance(b, str) and e_numero(a)):
            suggerimento = "Per confrontare un testo con un numero trasformalo prima con `intero(...)` o `decimale(...)`."
        elif isinstance(a, bool) or isinstance(b, bool):
            suggerimento = "`vero` e `falso` non sono numeri."
        raise ErroreTipo(f"Non posso confrontare {_con_articolo(a)} e {_con_articolo(b)} con `{operatore}`.",
                         suggerimento=suggerimento)
    if operatore == "in":
        return _in(a, b)
    if operatore == "è":
        return _identici(a, b)
    if operatore == "non è":
        return not _identici(a, b)
    raise ErroreTipo(f"L'operatore di confronto `{operatore}` non esiste in Leo.")


# ---------------------------------------------------------------------------
# Indici
# ---------------------------------------------------------------------------

def _nomi_sequenza(oggetto: Any) -> tuple[str, str, str]:
    """(articolo indeterminativo, complemento "dalla lista", soggetto "la lista")."""
    if isinstance(oggetto, str):
        return "un testo", "dal testo", "il testo è vuoto"
    if isinstance(oggetto, range):
        return "un intervallo", "dall'intervallo", "l'intervallo è vuoto"
    return "una lista", "dalla lista", "la lista è vuota"


def _lunghezza(oggetto: Any) -> int:
    """``len(oggetto)``, anche per intervalli enormi (``1..10^30``), dove
    ``len`` solleverebbe ``OverflowError``."""
    try:
        return len(oggetto)
    except OverflowError:
        if not isinstance(oggetto, range):
            raise
        passo = oggetto.step
        distanza = oggetto.stop - oggetto.start
        if passo > 0:
            return max(0, (distanza + passo - 1) // passo)
        return max(0, (distanza + passo + 1) // passo)


def _posizione(oggetto: Any, indice: Any) -> int:
    """Converte ``indice`` in posizione valida (0..n-1) o solleva l'errore giusto."""
    indeterminativo, fuori, vuoto = _nomi_sequenza(oggetto)
    if not e_intero(indice):
        suggerimento = None
        if isinstance(indice, float) and indice.is_integer():
            suggerimento = f"Usa un intero: per esempio `[{int(indice)}]` oppure `[intero(...)]`."
        elif isinstance(indice, str) and not isinstance(oggetto, str):
            suggerimento = "Per usare chiavi di testo serve un dizionario."
        raise ErroreTipo(f"L'indice di {indeterminativo} deve essere un intero, non {_con_articolo(indice)}.",
                         suggerimento=suggerimento)
    n = _lunghezza(oggetto)
    pos = indice + n if indice < 0 else indice
    if 0 <= pos < n:
        return pos
    if n == 0:
        raise ErroreIndice(f"L'indice {rappresenta(indice)} è fuori {fuori}: {vuoto}.")
    raise ErroreIndice(f"L'indice {rappresenta(indice)} è fuori {fuori}: gli indici vanno da 0 a {n - 1}.",
                       suggerimento="Con gli indici negativi si conta dal fondo: `[-1]` è l'ultimo elemento."
                       if indice < 0 else None)


def _errore_chiave(chiave: Any) -> ErroreChiave:
    return ErroreChiave(f"La chiave {rappresenta(chiave, dentro=True)} non è nel dizionario.",
                        suggerimento="Usa `.prendi(chiave, predefinito)` o controlla con `.ha(chiave)`.")


def _fetta(oggetto: Any, intervallo: range) -> Any:
    """``oggetto[da..a]``: sotto-sequenza (parte) inclusiva di una lista, di un
    testo o di un intervallo.

    Gli estremi ``da`` e ``a`` dell'intervallo sono ENTRAMBI inclusi, contati da
    0 come gli indici singoli; un estremo negativo conta dalla fine (``-1`` è
    l'ultimo). Gli estremi oltre i limiti si accostano agli estremi della
    sequenza (così ``parole[0..1000]`` dà tutto senza errori); se ``da`` viene
    dopo ``a`` la parte è vuota. Il tipo si conserva: una lista dà una lista, un
    testo dà un testo, un intervallo dà un intervallo."""
    if not isinstance(oggetto, (list, str, range)):
        raise ErroreTipo(f"Non posso prendere una parte (`[da..a]`) da {_con_articolo(oggetto)}.",
                         suggerimento="Le parti `[da..a]` valgono per liste, testi e intervalli; "
                                      "per un dizionario usa `.prendi(chiave, predefinito)`.")
    try:
        da = intervallo[0]
        a = intervallo[-1]
    except IndexError:
        return oggetto[:0]      # intervallo vuoto: parte vuota dello stesso tipo
    n = _lunghezza(oggetto)
    i = da + n if da < 0 else da
    j = a + n if a < 0 else a
    i = 0 if i < 0 else (n if i > n else i)
    j = -1 if j < 0 else (n - 1 if j > n - 1 else j)
    if i > j:
        return oggetto[:0]
    return oggetto[i:j + 1]


def leggi_indice(oggetto: Any, indice: Any) -> Any:
    """``oggetto[indice]`` per liste, testi, intervalli e dizionari.

    Se ``indice`` è a sua volta un intervallo (``oggetto[da..a]``) si prende la
    sotto-sequenza inclusiva (vedi ``_fetta``)."""
    if isinstance(indice, range):
        return _fetta(oggetto, indice)
    if isinstance(oggetto, (list, str, range)):
        return oggetto[_posizione(oggetto, indice)]
    if isinstance(oggetto, dict):
        verifica_chiave(indice)
        trovata, chiave = _cerca_chiave(oggetto, indice)
        if not trovata:
            raise _errore_chiave(indice)
        return oggetto[chiave]
    leggi = getattr(type(oggetto), "indice_dante", None)     # oggetti del ponte Python, byte
    if leggi is not None:
        return leggi(oggetto, indice)
    raise ErroreTipo(f"Non posso usare `[ ]` su {_con_articolo(oggetto)}.",
                     suggerimento="Le parentesi quadre si usano con liste, testi, intervalli e dizionari.")


def scrivi_indice(oggetto: Any, indice: Any, valore: Any) -> None:
    """``oggetto[indice] = valore`` per liste e dizionari."""
    if isinstance(oggetto, list):
        oggetto[_posizione(oggetto, indice)] = valore
        return
    if isinstance(oggetto, dict):
        verifica_chiave(indice)
        trovata, chiave = _cerca_chiave(oggetto, indice)
        if trovata:
            oggetto[chiave] = valore
            return
        if indice in oggetto:  # c'e' la "gemella": 1 per vero, 0 per falso (o viceversa)
            gemella = next(k for k in oggetto if k == indice)
            raise ErroreValore(
                f"Un dizionario non può avere insieme le chiavi {rappresenta(gemella, dentro=True)} "
                f"e {rappresenta(indice, dentro=True)}.",
                suggerimento="Usa chiavi dello stesso tipo, per esempio solo testi.")
        oggetto[indice] = valore
        return
    if isinstance(oggetto, str):
        raise ErroreTipo("I testi non si possono modificare: non posso cambiare un carattere con `[ ]`.",
                         suggerimento="Crea un testo nuovo, per esempio con `.sostituisci(vecchio, nuovo)` o con `+`.")
    if isinstance(oggetto, range):
        raise ErroreTipo("Gli intervalli non si possono modificare.",
                         suggerimento="Trasformalo prima in una lista.")
    scrivi = getattr(type(oggetto), "scrivi_indice_dante", None)
    if scrivi is not None:
        scrivi(oggetto, indice, valore)
        return
    raise ErroreTipo(f"Non posso usare `[ ]` su {_con_articolo(oggetto)}.",
                     suggerimento="Le parentesi quadre si usano con liste e dizionari.")
