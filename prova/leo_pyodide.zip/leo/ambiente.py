"""Ambiente (tabella dei nomi) con ambiti annidati - CONTRATTO CONDIVISO.

Ogni blocco (``se``, ``mentre``, ``per ogni``, ``ripeti``, ``prova``, corpo di
funzione, ``quando``) crea un ambiente figlio. ``variabile`` dichiara
nell'ambiente corrente; ``=`` modifica la variabile esistente piu' vicina
risalendo i genitori (niente ``global``).

Catena tipica: ambiente PREDEFINITO (libreria, costanti, tipi di errore,
controlli grafici) -> GLOBALE (programma) -> figli.

Gli errori sollevati qui NON hanno posizione (riga 0): la aggiunge l'interprete.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterator

from .errori import ErroreNome, ErroreValore


@dataclass(slots=True)
class Voce:
    """Un nome dichiarato (con ``__slots__``: leggere e scrivere ``valore`` e' il
    passo piu' frequente di ogni programma)."""

    valore: Any
    costante: bool = False
    riga: int = 0          # riga di dichiarazione (0 = predefinito)
    # Nome messo da solo da ``importa matematica`` (senza ``come``): un
    # ``variabile matematica = ...`` successivo lo sostituisce senza errore.
    implicito: bool = False


class Ambiente:
    __slots__ = ("genitore", "nome", "voci", "permetti_ridichiarazione")

    def __init__(self, genitore: "Ambiente | None" = None, *, nome: str = "",
                 permetti_ridichiarazione: bool = False) -> None:
        self.genitore = genitore
        self.nome = nome  # descrittivo: "predefinito", "globale", "funzione fattoriale", ...
        self.voci: dict[str, Voce] = {}
        # Nel REPL si puo' ridichiarare una variabile gia' esistente nello stesso ambito.
        self.permetti_ridichiarazione = permetti_ridichiarazione

    # --- creazione ------------------------------------------------------------
    def figlio(self, nome: str = "") -> "Ambiente":
        return Ambiente(self, nome=nome, permetti_ridichiarazione=self.permetti_ridichiarazione)

    # --- operazioni -------------------------------------------------------------
    def dichiara(self, nome: str, valore: Any, *, costante: bool = False, riga: int = 0,
                 implicito: bool = False) -> None:
        """Dichiara ``nome`` in QUESTO ambiente.

        ErroreNome se gia' dichiarato nello stesso ambiente (salvo REPL o nome
        implicito di un modulo importato). Si puo' invece "nascondere" un nome
        di un ambiente esterno.
        """
        esistente = self.voci.get(nome)
        if esistente is not None and not self.permetti_ridichiarazione and not esistente.implicito:
            dove = f" alla riga {esistente.riga}" if esistente.riga else ""
            raise ErroreNome(
                f"`{nome}` è già dichiarato{dove}.",
                suggerimento=f"Per cambiarne il valore scrivi solo `{nome} = ...`.",
                nome=nome,
            )
        self.voci[nome] = Voce(valore, costante, riga, implicito)

    def assegna(self, nome: str, valore: Any) -> None:
        """Cambia il valore della dichiarazione piu' vicina.

        ErroreNome se non esiste (l'interprete aggiunge i suggerimenti);
        ErroreValore se e' una costante.
        """
        amb = self.cerca_ambiente(nome)
        if amb is None:
            raise ErroreNome(f"`{nome}` non è definito.", nome=nome)
        voce = amb.voci[nome]
        if voce.costante:
            controlla = getattr(voce, "controlla_valore", None)
            if controlla is not None:  # variabile con un tipo dichiarato (leo/controllo/esecuzione.py)
                voce.valore = controlla(nome, valore)
                return
            from .valori import OggettoControllo

            from .valori import Richiamabile

            if isinstance(voce.valore, Richiamabile) and getattr(voce.valore, "nome", None) == nome:
                # `funzione f() ... fine` (o una funzione importata/predefinita)
                raise ErroreValore(
                    f"`{nome}` è una funzione: non le puoi dare un valore con `=`.",
                    suggerimento="Se ti serve una variabile, usa un altro nome.",
                )
            if isinstance(voce.valore, OggettoControllo):
                testo = valore if isinstance(valore, str) else None
                esempio = f'`{nome}.testo = "{testo}"`' if testo is not None else f"`{nome}.testo = ...`"
                raise ErroreValore(
                    f"`{nome}` è un controllo della finestra: non puoi sostituirlo con un valore.",
                    suggerimento=f"Per cambiare cosa mostra, scrivi la proprietà dopo il punto: {esempio}.",
                )
            raise ErroreValore(
                f"`{nome}` è una costante: non si può cambiare il suo valore.",
                suggerimento="Se deve cambiare, dichiarala con `variabile` invece di `costante`.",
            )
        voce.valore = valore

    def ottieni(self, nome: str) -> Any:
        """Valore di ``nome``; ErroreNome se non definito."""
        amb = self
        while amb is not None:
            voce = amb.voci.get(nome)
            if voce is not None:
                return voce.valore
            amb = amb.genitore
        raise ErroreNome(f"`{nome}` non è definito.", nome=nome)

    def esiste(self, nome: str) -> bool:
        return self.cerca_ambiente(nome) is not None

    def esiste_qui(self, nome: str) -> bool:
        return nome in self.voci

    def cerca_ambiente(self, nome: str) -> "Ambiente | None":
        amb: Ambiente | None = self
        while amb is not None:
            if nome in amb.voci:
                return amb
            amb = amb.genitore
        return None

    def voce(self, nome: str) -> Voce | None:
        amb = self.cerca_ambiente(nome)
        return amb.voci[nome] if amb else None

    def nomi_visibili(self) -> dict[str, int]:
        """Tutti i nomi visibili da qui -> riga di dichiarazione (per i suggerimenti)."""
        risultato: dict[str, int] = {}
        for amb in self.catena():
            for nome, voce in amb.voci.items():
                risultato.setdefault(nome, voce.riga)
        return risultato

    def catena(self) -> Iterator["Ambiente"]:
        amb: Ambiente | None = self
        while amb is not None:
            yield amb
            amb = amb.genitore

    def __repr__(self) -> str:
        return f"Ambiente({self.nome!r}, {list(self.voci)})"
