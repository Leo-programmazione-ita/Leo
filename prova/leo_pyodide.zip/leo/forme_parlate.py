"""Le forme "a parole" insegnano il simbolo; il correttore propone solo righe sicure.

Decisioni sul linguaggio (punti 2, 3, 5 e 6):

* le forme a parole dei calcoli e dei confronti (``3 più 4``, ``a per b``,
  ``10 diviso 2``, ``3 x 4``, ``6 × 7``, ``10 : 2``, ``x è uguale a 5``,
  ``x è maggiore di 3``, ``x è diverso da 0``, ``maggiore o uguale``...) NON
  sono codice valido: quando danno un errore Leo dice quale simbolo usare e
  propone la riga intera gia' corretta. Mai dentro il testo di un comando
  (``stampa 3 più 4 fa 7`` e' testo): li' si guarda solo cio' che sta tra parentesi;
* ``mostra`` -> ``stampa``; ``fai 5 volte`` / ``per 5 volte`` -> ``ripeti 5 volte``;
* testo + numero -> il valore tra graffe dentro il testo (``"hai {anni} anni"``);
  un numero letto con ``chiedi`` -> ``intero(...)`` / ``chiedi_numero(...)``;
  ``domanda`` (risposta sì/no) usata per un testo -> ``chiedi``;
* ``x = 5`` con ``x`` mai creata -> ``variabile x = 5``;
* nessuna riga viene MAI proposta (riga di comando, Leo Studio, telefono,
  autocorrezione) se, messa nel programma, non passa il parser
  (:func:`proposta_sicura`); niente parole chiave raddoppiate
  (``se x è uguale allora a 5 allora``), niente virgole che trasformano un
  operatore a parole in un argomento (``stampa(3, più, 4)``).

API:
    correggi_forme_a_parole(riga) -> FormeTrovate | None
    riga_ripeti(riga) -> str | None                      (``fai 5 volte`` -> ``ripeti 5 volte``)
    proposta_sicura(sorgente, numero, nuova, *, errore=None, opzioni=None) -> bool
    correzione_sospetta(riga, colonna, prima, dopo) -> str | None   (motivo per scartarla)
    migliora_errore(errore, sorgente) -> None            (messaggio, suggerimento e correzione)
    DETTAGLI_SIMBOLI                                     (il riepilogo dei simboli)
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Iterable

__all__ = ["FormeTrovate", "correggi_forme_a_parole", "riga_ripeti", "proposta_sicura",
           "correzione_sospetta", "migliora_errore", "DETTAGLI_SIMBOLI", "COMANDI_DI_TESTO",
           "pezzi", "parti_codice"]

#: Riepilogo tecnico mostrato con i messaggi normali (non con ``--semplice``).
DETTAGLI_SIMBOLI = ("Simboli di Leo: + somma, - sottrazione, * moltiplicazione, / divisione "
                    "(// divisione intera, % resto, ^ potenza); confronti == uguale, != diverso, "
                    "> maggiore, < minore, >= maggiore o uguale, <= minore o uguale.")

#: Esempi giusti per il livello semplice.
ESEMPIO_SIMBOLI = ("I calcoli e i confronti si scrivono con i simboli:",
                   'stampa(3 + 4)\nse x == 5 allora\n    stampa("cinque")\nfine')
ESEMPIO_RIPETI = ("Per ripetere un blocco:", 'ripeti 5 volte\n    stampa("Ciao")\nfine')

#: Comandi di testo (decisione 1): dopo il nome tutto e' testo, si calcola solo tra parentesi.
COMANDI_DI_TESTO = frozenset({"stampa", "scrivi", "messaggio", "chiedi", "domanda", "suona", "scrivi_qui"})

#: Parole chiave che non possono stare al posto di un valore.
_NON_VALORI = frozenset({
    "variabile", "costante", "se", "allora", "altrimenti", "fine", "mentre", "fai", "in", "ripeti",
    "volte", "interrompi", "continua", "funzione", "restituisci", "e", "o", "non", "prova", "cattura",
    "infine", "lancia", "come", "è", "é", "quando", "per", "ogni", "finché", "sennò",
    "più", "piu", "meno", "diviso", "uguale", "maggiore", "minore", "diverso", "diversa",
    "moltiplicato", "fratto", "elevato",
})

_RE_PEZZO = re.compile(r'''
     (?P<testo>"(?:\\.|[^"\\])*"?)
    |(?P<commento>\#.*$)
    |(?P<numero>\d+(?:\.\d+)?)
    |(?P<parola>[^\W\d]\w*)
    |(?P<spazio>[ \t]+)
    |(?P<op>==|!=|>=|<=|\+=|-=|\*=|/=|//|\.\.|\|>|.)
''', re.X)


@dataclass
class Pezzo:
    tipo: str          # testo, commento, numero, parola, spazio, op
    testo: str
    inizio: int
    fine: int
    codice: bool = True   # False: dentro il testo di un comando di testo (fuori dalle parentesi)


def pezzi(riga: str) -> list[Pezzo]:
    """La riga divisa in pezzi (testi tra virgolette, commento, numeri, parole, spazi, simboli)."""
    risultato = []
    for m in _RE_PEZZO.finditer(riga):
        tipo = m.lastgroup or "op"
        risultato.append(Pezzo(tipo, m.group(0), m.start(), m.end()))
        if tipo == "commento":
            break
    _segna_testo_dei_comandi(risultato)
    return risultato


def _segna_testo_dei_comandi(lista: list[Pezzo]) -> None:
    """Nei comandi di testo senza parentesi (``stampa 3 più 4``) fuori dalle parentesi e' testo."""
    sig = [p for p in lista if p.tipo not in ("spazio", "commento")]
    if len(sig) < 2 or sig[0].tipo != "parola" or sig[0].testo.lower() not in COMANDI_DI_TESTO:
        return
    dopo = sig[1]
    if dopo.tipo == "op" and dopo.testo in ("(", "=", ".", "+=", "-=", "[", ","):
        # forma classica `stampa(...)` (anche `stampa (x)`), assegnazione o attributo
        if dopo.testo != "(" or _una_sola_parentesi(sig[1:]):
            return
    livello = 0
    for p in lista[lista.index(sig[0]) + 1:]:
        if p.tipo == "op" and p.testo == "(":
            livello += 1
            continue
        if p.tipo == "op" and p.testo == ")":
            livello = max(0, livello - 1)
            continue
        if livello == 0:
            p.codice = False


def _una_sola_parentesi(sig: list[Pezzo]) -> bool:
    """``( ... )`` occupa tutto il resto della riga (forma classica del comando)."""
    livello = 0
    for i, p in enumerate(sig):
        if p.tipo == "op" and p.testo == "(":
            livello += 1
        elif p.tipo == "op" and p.testo == ")":
            livello -= 1
            if livello == 0:
                return i == len(sig) - 1
    return False


def parti_codice(riga: str) -> str:
    """La riga senza testi tra virgolette (svuotati) e senza commento."""
    return "".join('""' if p.tipo == "testo" else p.testo for p in pezzi(riga) if p.tipo != "commento")


# ---------------------------------------------------------------------------
# Forme a parole -> simboli
# ---------------------------------------------------------------------------

def _frasi(*voci: tuple[str, Iterable[str]]) -> list[tuple[tuple[str, ...], str]]:
    risultato = []
    for simbolo, frasi in voci:
        for f in frasi:
            risultato.append((tuple(f.split()), simbolo))
    risultato.sort(key=lambda x: -len(x[0]))
    return risultato


_E = ("è", "e", "é")   # "x e maggiore di 3": accento dimenticato


def _con_e(frasi: Iterable[str]) -> list[str]:
    risultato = []
    for f in frasi:
        risultato.append(f)
        risultato.extend(f"{e} {f}" for e in _E)
    return risultato


_UGUALE = ["uguale a", "uguale ad", "uguale", "uguali a", "uguali", "identico a", "identica a",
           "lo stesso di", "pari a"]
_DIVERSO = ["diverso da", "diversa da", "diversi da", "diverse da", "diverso", "diversa"]
_MAGGIORE = ["maggiore di", "maggiore", "più grande di", "piu grande di", "più di", "piu di", "più alto di"]
_MINORE = ["minore di", "minore", "più piccolo di", "piu piccolo di", "più piccola di", "meno di",
           "più basso di"]
_MAGGIORE_UGUALE = [f"{m} {o} {u}" for m in ("maggiore", "più grande", "piu grande")
                    for o in ("o", "oppure") for u in ("uguale a", "uguale ad", "uguale")] + [
    "maggiore uguale a", "maggiore uguale", "almeno"]
_MINORE_UGUALE = [f"{m} {o} {u}" for m in ("minore", "più piccolo", "piu piccolo")
                  for o in ("o", "oppure") for u in ("uguale a", "uguale ad", "uguale")] + [
    "minore uguale a", "minore uguale", "al massimo"]

#: Confronti a parole (la frase tra i due valori) -> simbolo.
CONFRONTI = _frasi(
    (">=", _con_e(_MAGGIORE_UGUALE)),
    ("<=", _con_e(_MINORE_UGUALE)),
    ("!=", _con_e(_DIVERSO) + [f"non {e} uguale a" for e in ("è", "e")] + ["non è uguale", "non uguale a",
                                                                          "non uguale", "non è uguale ad"]),
    ("==", _con_e([u for u in _UGUALE if u not in ("uguali",)]) + ["sono uguali a"]),
    (">", _con_e(_MAGGIORE)),
    ("<", _con_e(_MINORE)),
)

#: Calcoli a parole -> simbolo (``x``, ``:`` solo tra due numeri).
CALCOLI = _frasi(
    ("+", ["più", "piu", "sommato a", "aggiunto a"]),
    ("-", ["meno", "tolto"]),
    ("*", ["moltiplicato per", "per", "volte", "×"]),
    ("/", ["diviso per", "diviso", "fratto", "÷"]),
    ("^", ["elevato a", "elevato alla"]),
)
_SOLO_TRA_NUMERI = {("x",): "*", ("X",): "*", (":",): "/"}


@dataclass
class FormeTrovate:
    """La riga corretta e le sostituzioni fatte: ``[(scritto, simbolo), ...]``."""

    riga: str
    sostituzioni: list[tuple[str, str]] = field(default_factory=list)
    colonna: int = 1          # colonna (da 1) della prima forma a parole
    lunghezza: int = 1

    @property
    def confronti(self) -> bool:
        return any(s in ("==", "!=", ">", "<", ">=", "<=") for _, s in self.sostituzioni)

    @property
    def calcoli(self) -> bool:
        return any(s in ("+", "-", "*", "/", "^") for _, s in self.sostituzioni)


def _e_valore_prima(p: Pezzo | None) -> bool:
    if p is None:
        return False
    if p.tipo in ("numero", "testo"):
        return True
    if p.tipo == "parola":
        return p.testo not in _NON_VALORI
    return p.tipo == "op" and p.testo in (")", "]")


def _e_valore_dopo(p: Pezzo | None, seguente: Pezzo | None = None) -> bool:
    if p is None:
        return False
    if p.tipo in ("numero", "testo"):
        return True
    if p.tipo == "parola":
        if p.testo in ("vero", "falso", "nulla"):
            return True
        if p.testo == "non" and seguente is not None and seguente.tipo == "parola":
            return True
        return p.testo not in _NON_VALORI
    return p.tipo == "op" and p.testo in ("(", "[", "-")


def _parola(p: Pezzo) -> str:
    return p.testo.lower() if p.tipo == "parola" else p.testo


def correggi_forme_a_parole(riga: str, nomi: Iterable[str] | None = None) -> FormeTrovate | None:
    """``stampa(3 più 4)`` -> ``stampa(3 + 4)``; ``se x è uguale a 5 allora`` -> ``se x == 5 allora``.

    Solo fuori dai testi tra virgolette e dai commenti, e solo tra due valori;
    nei comandi di testo senza parentesi solo dentro le parentesi. None se
    nella riga non c'e' nessuna forma a parole. ``x`` vale "per" tra due numeri e,
    se ``nomi`` (i nomi del programma) non contiene ``x``, tra due valori qualsiasi.
    """
    x_libera = nomi is not None and "x" not in set(nomi) and "X" not in set(nomi)
    lista = pezzi(riga)
    sig = [p for p in lista if p.tipo not in ("spazio", "commento")]
    sostituzioni: list[tuple[int, int, str, str]] = []
    i = 0
    while i < len(sig):
        p = sig[i]
        if not p.codice or p.tipo not in ("parola", "op"):
            i += 1
            continue
        trovata = None
        prima = sig[i - 1] if i > 0 else None
        for tabella in (CONFRONTI, CALCOLI):
            for frase, simbolo in tabella:
                n = len(frase)
                if i + n > len(sig):
                    continue
                if tuple(_parola(q) for q in sig[i:i + n]) != frase:
                    continue
                if not all(q.codice for q in sig[i:i + n]):
                    continue
                dopo = sig[i + n] if i + n < len(sig) else None
                seguente = sig[i + n + 1] if i + n + 1 < len(sig) else None
                if not (_e_valore_prima(prima) and _e_valore_dopo(dopo, seguente)):
                    continue
                if frase == ("per",) and (dopo is not None and dopo.testo in ("ogni", "ciascun", "ciascuno")
                                          or _seguito_da_in(sig, i + n)):
                    continue          # `per ogni`, `[n per n in lista]`: non e' una moltiplicazione
                if frase == ("volte",) and not (prima.tipo == "numero" and dopo.tipo == "numero"):
                    continue          # `3 volte 4` solo tra numeri (`ripeti n volte` resta)
                if simbolo in ("-",) and frase == ("tolto",) and not (prima.tipo == "numero"):
                    continue
                trovata = (n, simbolo)
                break
            if trovata:
                break
        if trovata is None and p.tipo in ("parola", "op") and (p.testo,) in _SOLO_TRA_NUMERI:
            prima_n = prima is not None and prima.tipo == "numero"
            dopo_n = i + 1 < len(sig) and sig[i + 1].tipo == "numero"
            if x_libera and p.testo in ("x", "X"):
                prima_n = _e_valore_prima(prima)
                dopo_n = _e_valore_dopo(sig[i + 1] if i + 1 < len(sig) else None)
            if prima_n and dopo_n:
                trovata = (1, _SOLO_TRA_NUMERI[(p.testo,)])
        if trovata is None:
            i += 1
            continue
        n, simbolo = trovata
        inizio, fine = sig[i].inizio, sig[i + n - 1].fine
        sostituzioni.append((inizio, fine, riga[inizio:fine], simbolo))
        i += n
    if not sostituzioni:
        return None
    nuova = riga
    for inizio, fine, _scritto, simbolo in reversed(sostituzioni):
        sx = "" if inizio > 0 and nuova[inizio - 1] in " \t" else " "
        dx = "" if fine < len(nuova) and nuova[fine] in " \t" else " "
        nuova = nuova[:inizio] + sx + simbolo + dx + nuova[fine:]
    primo = sostituzioni[0]
    return FormeTrovate(nuova, [(s, simbolo) for _i, _f, s, simbolo in sostituzioni],
                        primo[0] + 1, max(1, primo[1] - primo[0]))


def _seguito_da_in(sig: list[Pezzo], k: int) -> bool:
    """``per n in`` / ``per a, b in`` (lista compressa senza ``ogni``)."""
    j = k
    while j < len(sig) and (sig[j].tipo == "parola" or sig[j].testo == ","):
        if sig[j].testo == "in":
            return True
        j += 1
    return False


# ---------------------------------------------------------------------------
# `fai 5 volte` -> `ripeti 5 volte`
# ---------------------------------------------------------------------------

_FAI_VOLTE = re.compile(r"^(?P<rientro>[ \t]*)(?P<parola>fai|per|ripeti per|esegui|Fai|Per)[ \t]+"
                        r"(?P<quante>[^\s\"#][^\"#]*?)[ \t]+volte\b(?P<resto>.*)$")


def riga_ripeti(riga: str) -> tuple[str, str] | None:
    """``fai 5 volte`` / ``per 5 volte`` -> (``ripeti 5 volte``, parola scritta) o None."""
    m = _FAI_VOLTE.match(riga)
    if not m:
        return None
    quante = m.group("quante").strip()
    if quante.startswith("ogni") or " in " in f" {quante} ":
        return None
    resto = m.group("resto")
    if resto.strip() in ("fai", "allora"):
        resto = ""
    return f"{m.group('rientro')}ripeti {quante} volte{resto}", m.group("parola")


# ---------------------------------------------------------------------------
# Sicurezza delle proposte
# ---------------------------------------------------------------------------

#: Parole di struttura che una riga Leo contiene al massimo una volta (fuori dai blocchi su una riga).
_PAROLE_UNICHE = ("allora", "volte", "fai", "variabile", "costante", "ripeti", "mentre", "funzione")
#: Parole che, se il correttore le infila in mezzo alla riga, devono essere seguite da un'istruzione.
_PAROLE_INFILATE = frozenset({"allora", "fai", "volte"})
#: Parole che non diventano mai un argomento separato da virgole.
_OPERATORI_A_PAROLE = frozenset({
    "più", "piu", "meno", "per", "diviso", "x", "X", "uguale", "maggiore", "minore", "diverso", "diversa",
    "fratto", "moltiplicato", "elevato", "volte", "tolto", "sommato", "aggiunto", "è", "e", "o", "non",
    "di", "da", "a",
})


def _conta_parole(codice: str) -> dict[str, int]:
    conta: dict[str, int] = {}
    for p in pezzi(codice):
        if p.tipo == "parola" and p.codice:
            conta[p.testo] = conta.get(p.testo, 0) + 1
    return conta


def parola_raddoppiata(prima: str, dopo: str) -> str | None:
    """La parola chiave che la correzione scrive una seconda volta nella riga (o None)."""
    a, b = _conta_parole(prima), _conta_parole(dopo)
    for parola in _PAROLE_UNICHE:
        if b.get(parola, 0) >= 2 and b.get(parola, 0) > a.get(parola, 0):
            return parola
    return None


def _sembra_istruzione(resto: str) -> bool:
    """Dopo ``allora``/``fai``/``volte`` infilati in mezzo alla riga ci vuole un'istruzione."""
    sig = [p for p in pezzi(resto) if p.tipo not in ("spazio", "commento")]
    if not sig:
        return True
    primo = sig[0]
    if primo.tipo != "parola":
        return False
    if primo.testo in ("se", "ripeti", "mentre", "per", "variabile", "costante", "restituisci", "interrompi",
                       "continua", "esci", "fine", "altrimenti", "lancia", "aumenta", "diminuisci", "prova"):
        return True
    if primo.testo in _NON_VALORI:
        return False
    secondo = sig[1] if len(sig) > 1 else None
    if secondo is None:
        return False          # una parola sola: `ripeti per volte sempre`
    if secondo.tipo == "op" and secondo.testo in ("(", "=", ".", "[", "+=", "-=", "*=", "/="):
        return True
    return primo.testo in COMANDI_DI_TESTO


def correzione_sospetta(riga: str, colonna: int, prima: str, dopo: str,
                        nomi_noti: Iterable[str] | None = None) -> str | None:
    """Motivo per scartare una correzione del parser su ``riga`` (o None se va bene).

    * raddoppia una parola chiave (``se x è uguale allora a 5 allora``);
    * infila ``allora``/``fai``/``volte`` in mezzo alla riga davanti a qualcosa
      che non e' un'istruzione (``ripeti per volte sempre``);
    * mette una virgola accanto a un operatore scritto a parole (``stampa(3, più, 4)``).
    """
    inizio = max(0, colonna - 1)
    if riga[inizio:inizio + len(prima)] != prima:
        return None
    nuova = riga[:inizio] + dopo + riga[inizio + len(prima):]
    doppia = parola_raddoppiata(riga, nuova)
    if doppia:
        return f"`{doppia}` scritto due volte"
    inserita = dopo.strip()
    if inserita in _PAROLE_INFILATE and not prima.strip():
        resto = riga[inizio + len(prima):]
        if resto.strip() and not resto.lstrip().startswith("#") and not _sembra_istruzione(resto):
            return f"`{inserita}` in mezzo alla riga"
    if "," in dopo and "," not in prima:
        sinistra = re.findall(r"[^\W\d]\w*", riga[:inizio])
        destra = re.findall(r"[^\W\d]\w*", riga[inizio + len(prima):])
        prec = riga[:inizio].rstrip()
        succ = riga[inizio + len(prima):].lstrip()
        if (sinistra and prec.endswith(sinistra[-1]) and sinistra[-1] in _OPERATORI_A_PAROLE) or \
                (destra and succ.startswith(destra[0]) and destra[0] in _OPERATORI_A_PAROLE):
            return "virgola accanto a un operatore scritto a parole"
        if nomi_noti is not None:
            noti = set(nomi_noti)
            sx = re.search(r"([^\W\d]\w*)\s*$", riga[:inizio])
            dx = re.match(r"\s*([^\W\d]\w*)(?!\s*[(.\[\w])", riga[inizio + len(prima):])
            for m in (sx, dx):
                if sx and dx and m.group(1) not in noti and not _noto(m.group(1)):
                    # `stampa(mio nome)` -> `stampa(mio, nome)`: due nomi che non esistono
                    return f"`{m.group(1)}` non esiste: la virgola non basta"
    return None


def _noto(nome: str) -> bool:
    """Nome della libreria o parola-valore di Leo (``vero``, ``falso``, ``nulla``)."""
    if nome in ("vero", "falso", "nulla"):
        return True
    try:
        from . import registro

        if not registro.FUNZIONI or len(registro.FUNZIONI) < 50:
            registro.carica_libreria()
        return nome in registro.FUNZIONI or nome in getattr(registro, "COSTANTI", {})
    except Exception:  # noqa: BLE001
        return True


def _primo_errore(sorgente: str, opzioni: dict | None) -> Any:
    """Il primo ``ErroreSintassi`` del sorgente (None se si analizza)."""
    from .errori import ErroreDante
    from .lexer import Lexer
    from .parser import Parser

    try:
        from .esecuzione import prepara_lessico

        sinonimi, stile = prepara_lessico(sorgente, **(opzioni or {}))
        token = Lexer(sorgente, "<proposta>", sinonimi=sinonimi, stile=stile).tokenizza()
        Parser(token, "<proposta>").analizza()
    except ErroreDante as e:
        return e
    except RecursionError:
        return RecursionError()
    return None


def _righe(sorgente: str) -> list[str]:
    return sorgente.lstrip("﻿").replace("\r\n", "\n").replace("\r", "\n").split("\n")


def proposta_sicura(sorgente: str | None, numero: int, nuova: str, *, errore: Any = None,
                    opzioni: dict | None = None) -> bool:
    """True se la riga ``numero`` sostituita da ``nuova`` si puo' proporre.

    Il programma con la riga nuova deve passare il parser; se aveva gia' un
    errore di forma in un'altra riga (che la proposta non tocca), basta che
    l'errore della riga ``numero`` sparisca e che non ne compaiano di nuovi
    prima. Niente parole chiave raddoppiate.
    """
    if not sorgente or "\n" in nuova:
        return False
    righe = _righe(sorgente)
    if not 1 <= numero <= len(righe) or righe[numero - 1] == nuova:
        return False
    if parola_raddoppiata(righe[numero - 1], nuova):
        return False
    nuove = righe[:numero - 1] + [nuova] + righe[numero:]
    dopo = _primo_errore("\n".join(nuove), opzioni)
    if dopo is None:
        return True
    if isinstance(dopo, RecursionError):
        return False
    riga_dopo = int(getattr(dopo, "riga", 0) or 0)
    if riga_dopo == numero and not _blocco_da_chiudere(dopo):
        return False
    prima = _primo_errore(sorgente, opzioni)
    if prima is None or isinstance(prima, RecursionError):
        return False         # il programma si analizzava: con la riga nuova deve analizzarsi ancora
    if _stesso_errore(prima, dopo):
        return True          # un errore che c'era gia', in un'altra riga
    return int(getattr(prima, "riga", 0) or 0) == numero and (riga_dopo > numero or _blocco_da_chiudere(dopo))


def _blocco_da_chiudere(errore: Any) -> bool:
    """"Il blocco `mentre` aperto alla riga 2 non è mai chiuso": la riga va bene, manca `fine` piu' giu'."""
    return bool(re.match(r"Il blocco `[^`]+` aperto alla riga \d+ non è mai chiuso",
                         str(getattr(errore, "messaggio", "") or "")))


def _stesso_errore(a: Any, b: Any) -> bool:
    return (getattr(a, "riga", None), getattr(a, "colonna", None), getattr(a, "messaggio", None)) == \
        (getattr(b, "riga", None), getattr(b, "colonna", None), getattr(b, "messaggio", None))


# ---------------------------------------------------------------------------
# Messaggi migliori
# ---------------------------------------------------------------------------

def _elenco(coppie: list[tuple[str, str]]) -> str:
    viste: list[tuple[str, str]] = []
    for c in coppie:
        if c not in viste:
            viste.append(c)
    pezzi_frase = [f"`{simbolo}` al posto di `{scritto}`" for scritto, simbolo in viste]
    if len(pezzi_frase) == 1:
        return pezzi_frase[0]
    return ", ".join(pezzi_frase[:-1]) + " e " + pezzi_frase[-1]


def _imposta(errore: Any, messaggio: str, suggerimento: str, *, riga: int | None = None,
             colonna: int | None = None, lunghezza: int | None = None, nuova: str | None = None,
             vecchia: str | None = None, semplice: str | None = None, dettagli: str | None = None,
             esempio: tuple[str, str] | None = None) -> None:
    """Riscrive messaggio e suggerimento (il problema, la soluzione) e la correzione della riga."""
    if not hasattr(errore, "messaggio_originale"):
        try:
            errore.messaggio_originale = getattr(errore, "messaggio", None)
            errore.suggerimento_originale = getattr(errore, "suggerimento", None)
        except Exception:  # noqa: BLE001
            pass
    errore.messaggio = messaggio
    errore.suggerimento = suggerimento + (f"\n{dettagli}" if dettagli else "")
    if semplice:
        errore.spiegazione_semplice = semplice
    if esempio:
        errore.esempio_semplice = esempio
    if riga is not None and colonna:
        try:
            errore.colonna = colonna
            if lunghezza:
                errore.lunghezza = lunghezza
        except Exception:  # noqa: BLE001
            pass
    if nuova is not None and vecchia is not None and riga:
        from .errori import Correzione

        errore.correzioni = [Correzione(riga, 1, vecchia, nuova, messaggio)]
        errore.riga_proposta = (riga, vecchia, nuova)


def _definiti(sorgente: str) -> set[str]:
    nomi = set()
    for m in re.finditer(r"(?m)^[ \t]*(?:funzione|variabile|costante|crea[ \t]+variabile|per[ \t]+ogni)"
                         r"[ \t]+([^\W\d]\w*)", sorgente):
        nomi.add(m.group(1))
    for m in re.finditer(r"(?m)^[ \t]*([^\W\d]\w*)[ \t]*=[^=]", sorgente):
        nomi.add(m.group(1))
    return nomi


def nomi_definiti(sorgente: str) -> set[str]:
    """Nomi che il programma crea (variabili, funzioni, parametri, ``per ogni``, ``come``...)."""
    nomi = _definiti(sorgente)
    for m in re.finditer(r"\bfunzione[ \t]*[^\W\d]?\w*[ \t]*\(([^)]*)\)", sorgente):
        nomi.update(re.findall(r"[^\W\d]\w*", m.group(1)))
    for m in re.finditer(r"\bper[ \t]+ogni[ \t]+([^\n]*?)[ \t]+in\b", sorgente):
        nomi.update(re.findall(r"[^\W\d]\w*", m.group(1)))
    nomi.update(re.findall(r"\bcome[ \t]+([^\W\d]\w*)", sorgente))
    nomi.update(re.findall(r"(?m)^[ \t]*importa[ \t]+([^\W\d]\w*)", sorgente))
    return nomi


#: Sinonimi di `stampa` che Leo non accetta (vocabolario): ``mostra("ciao")`` -> ``stampa("ciao")``.
_COME_STAMPA = ("mostra", "visualizza", "dì", "di'", "Mostra", "Visualizza")


def migliora_errore(errore: Any, sorgente: str | None) -> None:
    """Riconosce gli errori "da principiante" e scrive il messaggio giusto con la riga corretta.

    Lavora sul solo errore gia' avvenuto (una riga valida non viene mai toccata)
    ed e' idempotente. Ogni riga proposta passa da :func:`proposta_sicura`.
    """
    if errore is None or not sorgente or getattr(errore, "_forme_parlate_fatto", False):
        return
    try:
        errore._forme_parlate_fatto = True
    except Exception:  # noqa: BLE001
        return
    try:
        _migliora(errore, sorgente)
    except Exception:  # noqa: BLE001 - un aiuto in piu' non deve mai rompere il messaggio
        pass


def _migliora(errore: Any, sorgente: str) -> None:
    numero = int(getattr(errore, "riga", 0) or 0)
    righe = _righe(sorgente)
    if not 1 <= numero <= len(righe):
        return
    testo = righe[numero - 1]
    tipo = getattr(errore, "tipo", None) or type(errore).__name__
    altro_file = getattr(errore, "sorgente_file", None)
    if altro_file is not None and altro_file != sorgente:
        return
    if tipo == "ErroreSintassi":
        try:
            from .da_python import traduci_riga

            if traduci_riga(testo) is not None:
                return             # riga scritta alla Python: la traduce gia' `da_python`
        except ImportError:  # pragma: no cover
            pass
        _migliora_sintassi(errore, sorgente, numero, testo)
    elif tipo == "ErroreNome":
        _migliora_nome(errore, sorgente, numero, testo)
    elif tipo == "ErroreTipo":
        _migliora_tipo(errore, sorgente, numero, testo)
    elif tipo == "ErroreValore" and "domanda" in parti_codice(testo):
        _domanda_per_un_testo(errore, sorgente, numero, testo)


def _sicura(errore: Any, sorgente: str, numero: int, nuova: str) -> bool:
    return proposta_sicura(sorgente, numero, nuova, errore=errore)


def _migliora_sintassi(errore: Any, sorgente: str, numero: int, testo: str) -> None:
    # 1. `fai 5 volte`, `per 5 volte`
    ripeti = riga_ripeti(testo)
    if ripeti and _sicura(errore, sorgente, numero, ripeti[0]):
        nuova, scritta = ripeti
        quante = re.search(r"ripeti (.*) volte", nuova).group(1)
        _imposta(errore, f"`{scritta} {quante} volte` non è una forma di Leo.",
                 f"Per ripetere un blocco si scrive `ripeti {quante} volte` (e il blocco finisce con `fine`): "
                 f"`{nuova.strip()}`.", riga=numero, colonna=len(testo) - len(testo.lstrip()) + 1,
                 lunghezza=len(scritta), nuova=nuova, vecchia=testo,
                 semplice=f"Per ripetere si scrive `ripeti {quante} volte`, non `{scritta} {quante} volte`.",
                 esempio=ESEMPIO_RIPETI)
        return
    # 2. `mostra "ciao"` / `mostra ciao` all'inizio della riga
    if _stampa_al_posto(errore, sorgente, numero, testo):
        return
    # 3. parole chiave con la maiuscola in mezzo alla riga (`Se x > 3 Allora`)
    if _parole_chiave_maiuscole(errore, sorgente, numero, testo):
        return
    # 4. altre frasi in italiano parlato con una forma Leo precisa
    if _frasi_parlate(errore, sorgente, numero, testo):
        return
    # 5. calcoli e confronti a parole, simboli che Leo non conosce (`×`, `÷`)
    forme = correggi_forme_a_parole(testo, nomi_definiti(sorgente))
    if forme is None:
        return
    nuova = forme.riga
    if not _sicura(errore, sorgente, numero, nuova):
        try:
            from .suggerimenti import prossima_parola

            mancante = prossima_parola(nuova)
        except Exception:  # noqa: BLE001
            mancante = None
        if mancante and mancante[0] in ("allora", "fai", "volte"):
            nuova = nuova.rstrip() + " " + mancante[0]
        if not _sicura(errore, sorgente, numero, nuova):
            return
    _messaggio_forme(errore, forme, numero, testo, nuova)


def _messaggio_forme(errore: Any, forme: FormeTrovate, numero: int, testo: str, nuova: str) -> None:
    scritte = ", ".join(dict.fromkeys(f"`{s}`" for s, _ in forme.sostituzioni))
    if forme.confronti and forme.calcoli:
        genere = "i calcoli e i confronti"
    elif forme.confronti:
        genere = "i confronti"
    else:
        genere = "i calcoli"
    messaggio = f"In Leo {genere} si scrivono con i simboli, non a parole: qui c'è {scritte}."
    suggerimento = f"Scrivi {_elenco(forme.sostituzioni)}: `{nuova.strip()}`."
    semplice = f"Per {genere} si usano i simboli: scrivi {_elenco(forme.sostituzioni)}."
    _imposta(errore, messaggio, suggerimento, riga=numero, colonna=forme.colonna, lunghezza=forme.lunghezza,
             nuova=nuova, vecchia=testo, semplice=semplice, dettagli=DETTAGLI_SIMBOLI, esempio=ESEMPIO_SIMBOLI)


def _stampa_al_posto(errore: Any, sorgente: str, numero: int, testo: str) -> bool:
    m = re.match(r"^([ \t]*)(" + "|".join(re.escape(p) for p in _COME_STAMPA) + r")(?=[\s(\"]|$)", testo)
    if not m or m.group(2) in _definiti(sorgente):
        return False
    nuova = m.group(1) + "stampa" + testo[m.end():]
    if not _sicura(errore, sorgente, numero, nuova):
        return False
    _imposta(errore, f"`{m.group(2)}` non è un comando di Leo.",
             f"Per scrivere un testo o un valore si usa `stampa`: `{nuova.strip()}`.",
             riga=numero, colonna=len(m.group(1)) + 1, lunghezza=len(m.group(2)), nuova=nuova, vecchia=testo,
             semplice=f"Per scrivere qualcosa sullo schermo si usa `stampa`, non `{m.group(2)}`.",
             esempio=("Per scrivere sullo schermo si usa `stampa`:", 'stampa("Ciao!")\nstampa(3 + 4)'))
    return True


_N = r"[^\W\d]\w*"
_V = r"(?:-?\d+(?:\.\d+)?|[^\W\d]\w*)"

#: (regola, sostituzione, messaggio, suggerimento, frase semplice): le regole valgono sulla riga
#: intera; nella sostituzione e nelle frasi ``{g1}``, ``{g2}``... sono i gruppi trovati.
_FRASI: list[tuple[re.Pattern, str, str, str, str]] = [
    (re.compile(rf"^(?P<r>[ \t]*)(?P<d>(?:crea[ \t]+)?(?:variabile|costante)[ \t]+)?(?P<n>{_N})[ \t]+"
                r"(?P<p>è|e|é|vale|diventa|uguale a|è uguale a|prende)[ \t]+(?P<v>[^=].*)$"),
     "{r}{d}{n} = {v}",
     "Per dare un valore si usa `=`, non `{p}`.",
     "Scrivi `{nuova}`.",
     "Per dare un valore a `{n}` si usa `=`."),
    (re.compile(rf"^(?P<r>[ \t]*)(?:aggiungi|somma)[ \t]+(?P<v>{_V})[ \t]+(?:a|ad)[ \t]+(?P<n>{_N})[ \t]*$"),
     "{r}aumenta {n} di {v}",
     "`aggiungi {v} a {n}` non è una forma di Leo.",
     "Per aumentare una variabile si scrive `aumenta {n} di {v}` (oppure `{n} += {v}`).",
     "Si scrive `aumenta {n} di {v}`."),
    (re.compile(rf"^(?P<r>[ \t]*)(?:togli|sottrai)[ \t]+(?P<v>{_V})[ \t]+(?:a|da)[ \t]+(?P<n>{_N})[ \t]*$"),
     "{r}diminuisci {n} di {v}",
     "`togli {v} da {n}` non è una forma di Leo.",
     "Per diminuire una variabile si scrive `diminuisci {n} di {v}` (oppure `{n} -= {v}`).",
     "Si scrive `diminuisci {n} di {v}`."),
    (re.compile(rf"^(?P<r>[ \t]*)per[ \t]+(?!ogni\b)(?P<n>{_N})[ \t]+da[ \t]+(?P<a>{_V})[ \t]+a[ \t]+"
                rf"(?P<b>{_V})(?:[ \t]+fai)?[ \t]*$"),
     "{r}per ogni {n} in {a}..{b} fai",
     "Per contare da {a} a {b} si usa un intervallo con `..`.",
     "Scrivi `{nuova}`: `{n}` vale {a}, poi il successivo, fino a {b} compreso.",
     "Per contare da {a} a {b} si scrive `per ogni {n} in {a}..{b} fai`."),
    (re.compile(r"^(?P<r>[ \t]*)(?:aspetta|attendi|pausa|aspetta per)[ \t]+(?P<v>\d+(?:\.\d+)?)[ \t]+"
                r"(?:secondi|secondo|s)[ \t]*$"),
     "{r}attendi({v})",
     "Per fermarsi qualche secondo si usa `attendi` con i secondi tra parentesi.",
     "Scrivi `{nuova}`.",
     "Per aspettare {v} secondi si scrive `attendi({v})`."),
    (re.compile(r"^(?P<r>.*?)(?P<s>numero[ \t]+(?:a[ \t]+caso|casuale)[ \t]+(?:tra|fra|da)[ \t]+(?P<a>-?\d+)[ \t]+"
                r"(?:e|a)[ \t]+(?P<b>-?\d+))(?P<f>.*)$"),
     "{r}casuale({a}, {b}){f}",
     "Per un numero a caso si usa la funzione `casuale`.",
     "Scrivi `casuale({a}, {b})`: dà un numero intero da {a} a {b} compresi.",
     "Per un numero a caso da {a} a {b} si scrive `casuale({a}, {b})`."),
]


def _frasi_parlate(errore: Any, sorgente: str, numero: int, testo: str) -> bool:
    for regola, sostituzione, messaggio, suggerimento, semplice in _FRASI:
        m = regola.match(testo)
        if not m:
            continue
        gruppi = {k: (v or "") for k, v in m.groupdict().items()}
        nuova = sostituzione.format(**gruppi).rstrip()
        if not _sicura(errore, sorgente, numero, nuova):
            continue
        gruppi["nuova"] = nuova.strip()
        _imposta(errore, messaggio.format(**gruppi), suggerimento.format(**gruppi), riga=numero,
                 nuova=nuova, vecchia=testo, semplice=semplice.format(**gruppi))
        return True
    # i due punti in fondo alla riga (`ripeti 3 volte:`, `se x > 3 allora:`)
    m = re.match(r"^(.*?\S)[ \t]*:[ \t]*$", testo)
    if m and '"' not in testo:
        for nuova in (m.group(1), m.group(1) + " allora", m.group(1) + " fai"):
            if _sicura(errore, sorgente, numero, nuova):
                _imposta(errore, "In Leo una riga non finisce con i due punti `:`.",
                         f"Togli i due punti: `{nuova.strip()}` (il blocco finisce con `fine`).", riga=numero,
                         colonna=len(testo.rstrip()), lunghezza=1, nuova=nuova, vecchia=testo,
                         semplice="Togli i due punti in fondo alla riga: in Leo i blocchi finiscono con `fine`.")
                return True
    # virgolette tipografiche singole: ‘ciao’ -> "ciao"
    if "‘" in testo or "’" in testo:
        nuova = re.sub(r"[‘’]", '"', testo)
        if _sicura(errore, sorgente, numero, nuova):
            _imposta(errore, "Il carattere `‘` non fa parte di Leo: i testi si scrivono tra virgolette dritte `\"`.",
                     f"Scrivi `{nuova.strip()}`.", riga=numero, nuova=nuova, vecchia=testo,
                     semplice="Per i testi usa le virgolette dritte `\"`.")
            return True
    # nome con uno spazio in mezzo (`variabile mio nome = "Luca"`, poi `stampa(mio nome)`)
    coppie = re.findall(rf"(?m)^[ \t]*(?:variabile|costante)[ \t]+({_N})[ \t]+({_N})[ \t]*=", sorgente)
    coppie += [tuple(n.split("_", 1)) for n in nomi_definiti(sorgente) if n.count("_") == 1 and
               all(n.split("_", 1))]
    for a, b in coppie:
        if f"{a} {b}" in testo:
            nuova = re.sub(rf"\b{re.escape(a)}[ \t]+{re.escape(b)}\b", f"{a}_{b}", testo)
            if nuova != testo and _sicura(errore, sorgente, numero, nuova):
                _imposta(errore, f"Un nome non può contenere spazi: `{a} {b}`.",
                         f"Unisci le parole con `_`: `{a}_{b}`, anche dove usi il nome. Qui: `{nuova.strip()}`.",
                         riga=numero, nuova=nuova, vecchia=testo,
                         semplice=f"I nomi non hanno spazi: scrivi `{a}_{b}`.")
                # l'autocorrezione cambia il nome in tutte le righe (fuori dai testi)
                from .errori import Correzione

                correzioni = []
                for i, r in enumerate(_righe(sorgente), 1):
                    cambiata = _sostituisci_fuori_dai_testi(r, rf"\b{re.escape(a)}[ \t]+{re.escape(b)}\b", f"{a}_{b}")
                    if cambiata != r:
                        correzioni.append(Correzione(i, 1, r, cambiata, errore.messaggio))
                if correzioni:
                    errore.correzioni = correzioni
                return True
    return False


def _sostituisci_fuori_dai_testi(riga: str, regola: str, con: str) -> str:
    parti = []
    for p in pezzi(riga):
        parti.append(p.testo if p.tipo in ("testo", "commento") or not p.codice else None)
    # ricostruisce: i pezzi di codice consecutivi si sostituiscono insieme
    risultato, codice = [], []
    for p, fisso in zip(pezzi(riga), parti):
        if fisso is None:
            codice.append(p.testo)
            continue
        if codice:
            risultato.append(re.sub(regola, con, "".join(codice)))
            codice = []
        risultato.append(fisso)
    if codice:
        risultato.append(re.sub(regola, con, "".join(codice)))
    return "".join(risultato)


#: Numeri scritti a parole (``variabile x = cinque``).
NUMERI_A_PAROLE = {
    "zero": 0, "uno": 1, "una": 1, "due": 2, "tre": 3, "quattro": 4, "cinque": 5, "sei": 6, "sette": 7,
    "otto": 8, "nove": 9, "dieci": 10, "undici": 11, "dodici": 12, "tredici": 13, "quattordici": 14,
    "quindici": 15, "sedici": 16, "diciassette": 17, "diciotto": 18, "diciannove": 19, "venti": 20,
    "trenta": 30, "quaranta": 40, "cinquanta": 50, "sessanta": 60, "settanta": 70, "ottanta": 80,
    "novanta": 90, "cento": 100, "mille": 1000,
}


def _parole_chiave_maiuscole(errore: Any, sorgente: str, numero: int, testo: str) -> bool:
    try:
        from .tokens import PAROLE_CHIAVE
    except ImportError:  # pragma: no cover
        return False
    chiave = set(PAROLE_CHIAVE) | {"ripeti", "volte", "stampa", "ogni"}
    scritte = [p for p in pezzi(testo) if p.tipo == "parola" and p.codice and p.testo[:1].isupper()
               and p.testo.lower() in chiave and p.testo not in _definiti(sorgente)]
    if not scritte:
        return False
    nuova = testo
    for p in reversed(scritte):
        nuova = nuova[:p.inizio] + p.testo.lower() + nuova[p.fine:]
    if not _sicura(errore, sorgente, numero, nuova):
        return False
    elenco = ", ".join(dict.fromkeys(f"`{p.testo}`" for p in scritte))
    _imposta(errore, f"Le parole di Leo si scrivono in minuscolo: qui c'è {elenco}.",
             f"Scrivi `{nuova.strip()}`.", riga=numero, colonna=scritte[0].inizio + 1,
             lunghezza=len(scritte[0].testo), nuova=nuova, vecchia=testo,
             semplice=f"Le parole di Leo vanno scritte in minuscolo: {elenco}.")
    return True


def _migliora_nome(errore: Any, sorgente: str, numero: int, testo: str) -> None:
    nome = getattr(errore, "nome", None) or ""
    if not nome:
        m = re.match(r"`([^`]+)` non è definit", getattr(errore, "messaggio", "") or "")
        nome = m.group(1) if m else ""
    if not nome:
        return
    if nome in _COME_STAMPA and _stampa_al_posto(errore, sorgente, numero, testo):
        return
    if nome == "domanda":
        return
    if nome.lower() in NUMERI_A_PAROLE and nome not in _definiti(sorgente):
        cifre = str(NUMERI_A_PAROLE[nome.lower()])
        nuova = re.sub(rf"(?<![\w\"]){re.escape(nome)}(?![\w\"])", cifre, testo, count=1)
        if nuova != testo and _sicura(errore, sorgente, numero, nuova):
            _imposta(errore, f"In Leo i numeri si scrivono con le cifre: `{cifre}`, non `{nome}`.",
                     f"Scrivi `{nuova.strip()}`.", nuova=nuova, vecchia=testo, riga=numero,
                     semplice=f"I numeri si scrivono con le cifre: `{cifre}`.")
            return
    # `x = 5` con `x` mai creata -> `variabile x = 5`
    m = re.match(r"^([ \t]*)" + re.escape(nome) + r"([ \t]*=(?!=).*)$", testo)
    if m:
        suggerimento = getattr(errore, "suggerimento", None) or ""
        forte = re.search(r"forse intendevi `([^`]+)` \(definito alla riga", suggerimento)
        if forte and len(nome) >= 4:
            return                     # `contatre = 5` dopo `variabile contatore = 0`: e' un errore di battitura
        nuova = f"{m.group(1)}variabile {nome}{m.group(2)}"
        if _sicura(errore, sorgente, numero, nuova):
            _imposta(errore, f"`{nome}` non esiste ancora: una variabile nuova si crea con `variabile`.",
                     f"Scrivi `{nuova.strip()}`; dopo, per cambiarle valore, basta `{nome} = ...`.",
                     nuova=nuova, vecchia=testo, riga=numero,
                     semplice=f"La prima volta che usi `{nome}` scrivi `variabile` davanti.")


_SOMMA = re.compile(r"Non posso sommare (?:un|una|dei|delle|degli) `(\w+)` e (?:un|una|dei|delle|degli) `(\w+)`")
_CONFRONTO = re.compile(r"Non posso confrontare (?:un|una) `(\w+)` e (?:un|una) `(\w+)` con `([^`]+)`")
_NUMERI = ("intero", "decimale")


def _migliora_tipo(errore: Any, sorgente: str, numero: int, testo: str) -> None:
    messaggio = getattr(errore, "messaggio", "") or ""
    m = _SOMMA.search(messaggio)
    if m and "logico" in (m.group(1), m.group(2)) and "domanda" in _origini(sorgente, testo).values():
        _domanda_per_un_testo(errore, sorgente, numero, testo)
        return
    if m and {m.group(1), m.group(2)} & {"testo"} and {m.group(1), m.group(2)} & set(_NUMERI):
        if _testo_con_graffe(errore, sorgente, numero, testo):
            return
        _numero_da_testo(errore, sorgente, numero, testo, "+")
        return
    m = _CONFRONTO.search(messaggio)
    if m and {m.group(1), m.group(2)} & {"testo"} and {m.group(1), m.group(2)} & set(_NUMERI):
        _numero_da_testo(errore, sorgente, numero, testo, m.group(3))


# --- testo + numero -> graffe ---------------------------------------------------

def _gruppi_somma(riga: str) -> list[tuple[int, int, list[tuple[int, int]]]]:
    """Le catene ``a + b + c`` della riga (fuori dai testi): (inizio, fine, [(inizio, fine) dei pezzi])."""
    lista = [p for p in pezzi(riga) if p.tipo != "commento"]
    risultato = []
    # dividi per livelli di parentesi: una catena vive dentro la stessa coppia di parentesi
    pila: list[list] = [[]]
    for p in lista:
        if p.tipo == "op" and p.testo in "([{" and p.testo:
            pila[-1].append(p)
            pila.append([])
            continue
        if p.tipo == "op" and p.testo in ")]}" and p.testo and len(pila) > 1:
            interno = pila.pop()
            risultato.extend(_catene(interno, riga))
            pila[-1].append(p)
            continue
        pila[-1].append(p)
    for resto in pila:
        risultato.extend(_catene(resto, riga))
    return risultato


def _catene(gruppo: list, riga: str) -> list[tuple[int, int, list[tuple[int, int]]]]:
    """Dentro un livello: pezzi separati da `,`; in ognuno le parti separate da `+` di primo livello."""
    risultato = []
    # ricostruisci gli elementi "piatti" (le parentesi interne restano dentro l'elemento)
    elementi: list[list] = [[]]
    for p in gruppo:
        if isinstance(p, Pezzo) and p.tipo == "op" and p.testo in (",", "=", "==", "!=", ">", "<", ">=", "<="):
            elementi.append([])
            continue
        elementi[-1].append(p)
    for el in elementi:
        sig = [p for p in el if p.tipo != "spazio"]
        if not sig:
            continue
        parti: list[list[Pezzo]] = [[]]
        for p in sig:
            if p.tipo == "op" and p.testo == "+":
                parti.append([])
            else:
                parti[-1].append(p)
        if len(parti) < 2 or any(not parte for parte in parti):
            continue
        intervalli = [(parte[0].inizio, parte[-1].fine) for parte in parti]
        risultato.append((intervalli[0][0], intervalli[-1][1], intervalli))
    return risultato


def _testo_con_graffe(errore: Any, sorgente: str, numero: int, testo: str) -> bool:
    """``"hai " + anni + " anni"`` -> ``"hai {anni} anni"``."""
    for inizio, fine, parti in _gruppi_somma(testo):
        contenuti = [testo[a:b] for a, b in parti]
        if not any(c.startswith('"') and c.endswith('"') and len(c) >= 2 for c in contenuti):
            continue
        pezzi_testo = []
        valori = []
        for c in contenuti:
            c = c.strip()
            if c.startswith('"') and c.endswith('"') and len(c) >= 2 and c.count('"') == 2:
                pezzi_testo.append(c[1:-1])
            else:
                if "{" in c or "}" in c or '"' in c:
                    break
                pezzi_testo.append("{" + c + "}")
                valori.append(c)
        else:
            if not valori:
                continue
            unito = '"' + "".join(pezzi_testo) + '"'
            nuova = testo[:inizio] + unito + testo[fine:]
            if not _sicura(errore, sorgente, numero, nuova):
                continue
            nomi = ", ".join(f"`{v}`" for v in valori)
            graffe = ", ".join("`{" + v + "}`" for v in valori)
            _imposta(errore, f"Con `+` non si può unire un testo e un numero ({nomi}).",
                     f"Metti il valore dentro il testo tra graffe, {graffe}: `{nuova.strip()}`.",
                     nuova=nuova, vecchia=testo, riga=numero,
                     semplice=f"Per scrivere un numero dentro un testo mettilo tra graffe: {graffe}.",
                     dettagli="Dentro le virgolette `{...}` calcola il valore e lo scrive al suo posto; "
                              "in alternativa `testo(valore)` trasforma un numero in testo.")
            return True
    return False


# --- testo letto con chiedi usato come numero -----------------------------------

_ASSEGNA = re.compile(r"^[ \t]*(?:(?:crea[ \t]+)?(?:variabile|costante)[ \t]+)?([^\W\d]\w*)[ \t]*=(?!=)[ \t]*"
                      r"(chiedi|domanda|chiedi_numero|intero|decimale)?[ \t]*(\(?)")


def _origini(sorgente: str, fino_a: str | None = None) -> dict[str, str]:
    """Nome -> funzione che gli ha dato l'ultimo valore (``chiedi``, ``domanda``...) o ``"altro"``."""
    origini: dict[str, str] = {}
    for riga in _righe(sorgente):
        m = _ASSEGNA.match(riga)
        if m:
            funzione = m.group(2) if m.group(2) and m.group(3) else "altro"
            origini[m.group(1)] = funzione
    return origini


def riga_della_variabile(sorgente: str, nome: str, funzione: str) -> tuple[int, str] | None:
    """La riga che assegna a ``nome`` il valore di ``funzione(...)`` (l'ultima prima dell'errore)."""
    trovata = None
    for i, riga in enumerate(_righe(sorgente), 1):
        m = _ASSEGNA.match(riga)
        if m and m.group(1) == nome and m.group(2) == funzione and m.group(3):
            trovata = (i, riga)
    return trovata


def chiedi_numero_disponibile() -> bool:
    try:
        from . import registro

        if not registro.FUNZIONI or len(registro.FUNZIONI) < 50:
            registro.carica_libreria()
        return "chiedi_numero" in registro.FUNZIONI
    except Exception:  # noqa: BLE001
        return False


def proposta_chiedi_numero(riga: str) -> str | None:
    """``variabile t = chiedi("...")`` -> ``variabile t = chiedi_numero("...")`` (o ``intero(chiedi(...))``)."""
    m = re.search(r"\bchiedi[ \t]*\(", riga)
    if not m:
        return None
    if chiedi_numero_disponibile():
        return riga[:m.start()] + "chiedi_numero(" + riga[m.end():]
    # senza chiedi_numero: intero(chiedi(...))
    livello, k = 0, m.end() - 1
    while k < len(riga):
        c = riga[k]
        if c == '"':
            k += 1
            while k < len(riga) and riga[k] != '"':
                k += 2 if riga[k] == "\\" else 1
        elif c == "(":
            livello += 1
        elif c == ")":
            livello -= 1
            if livello == 0:
                return riga[:m.start()] + "intero(" + riga[m.start():k + 1] + ")" + riga[k + 1:]
        k += 1
    return None


def _numero_da_testo(errore: Any, sorgente: str, numero: int, testo: str, operatore: str) -> None:
    """``n + 1`` (o ``t > 3``) con ``n``/``t`` letto con ``chiedi``: ``intero(n)`` e ``chiedi_numero``."""
    origini = _origini(sorgente)
    candidati = []
    for p in pezzi(testo):
        if p.tipo == "parola" and p.codice and origini.get(p.testo) == "chiedi":
            candidati.append(p)
    if not candidati:
        return
    p = candidati[0]
    nome = p.testo
    nuova = testo[:p.inizio] + f"intero({nome})" + testo[p.fine:]
    origine = riga_della_variabile(sorgente, nome, "chiedi")
    dove = f" (riga {origine[0]})" if origine else ""
    proposta_origine = proposta_chiedi_numero(origine[1]) if origine else None
    altra = (f" Meglio ancora, leggilo già come numero{dove}: `{proposta_origine.strip()}`."
             if proposta_origine else "")
    verbo = "sommare" if operatore == "+" else "confrontare"
    if not _sicura(errore, sorgente, numero, nuova):
        nuova = None
    suggerimento = (f"`{nome}` viene da `chiedi`, che dà sempre un testo: trasformalo in numero con "
                    f"`intero({nome})`" + (f": `{nuova.strip()}`." if nuova else ".") + altra)
    _imposta(errore, f"Non posso {verbo} un testo e un numero: `{nome}` è un testo.", suggerimento,
             riga=numero, colonna=p.inizio + 1, lunghezza=len(nome), nuova=nuova, vecchia=testo if nuova else None,
             semplice=f"`{nome}` contiene le lettere scritte sulla tastiera, non un numero: "
                      f"usa `intero({nome})`.")


_INTERROGATIVE = ("come", "chi", "cosa", "che", "quale", "quali", "quanto", "quanti", "quanta", "quante",
                  "dove", "quando", "perché", "perche", "scrivi", "inserisci", "dimmi", "dammi")
_NOMI_DA_TESTO = ("nome", "cognome", "città", "citta", "testo", "parola", "frase", "colore", "animale",
                  "cibo", "squadra", "email", "indirizzo")
_ASSEGNA_DOMANDA = re.compile(r"^[ \t]*(?:(?:crea[ \t]+)?variabile[ \t]+)?([^\W\d]\w*)[ \t]*=[ \t]*domanda[ \t]*"
                              r"\([ \t]*\"([^\"]*)")


def domanda_per_un_testo(riga: str) -> bool:
    """``variabile nome = domanda("Come ti chiami? ")``: la risposta voluta e' un testo, non sì/no."""
    m = _ASSEGNA_DOMANDA.match(riga)
    if not m:
        return False
    nome, domanda = m.group(1).lower(), m.group(2).strip().lower()
    prima = re.match(r"[^\W\d]+", domanda)
    return bool(prima and prima.group(0) in _INTERROGATIVE) or any(
        nome == n or nome.startswith(n + "_") for n in _NOMI_DA_TESTO)


def _domanda_per_un_testo(errore: Any, sorgente: str, numero: int, testo: str) -> None:
    """``variabile nome = domanda("Come ti chiami?")``: `domanda` risponde solo sì/no."""
    origini = _origini(sorgente)
    nomi = [n for n, f in origini.items() if f == "domanda"]
    riga_domanda = None
    if "domanda" in parti_codice(testo):
        riga_domanda = (numero, testo)
    else:
        for n in nomi:
            if re.search(rf"\b{re.escape(n)}\b", parti_codice(testo)):
                riga_domanda = riga_della_variabile(sorgente, n, "domanda")
                break
    if riga_domanda is None:
        return
    r, vecchia = riga_domanda
    if r == numero and type(errore).__name__ == "ErroreValore" and not domanda_per_un_testo(vecchia):
        return             # `se domanda("Continuo?")` con l'ingresso finito: e' un altro problema
    nuova = re.sub(r"\bdomanda([ \t]*\()", r"chiedi\1", vecchia, count=1)
    proposta = nuova if r == numero and _sicura(errore, sorgente, numero, nuova) else None
    dove = "" if r == numero else f" alla riga {r}"
    _imposta(errore, "`domanda` aspetta una risposta sì o no e dà `vero` o `falso`, non un testo.",
             f"Per chiedere un nome o una frase usa `chiedi`{dove}: `{nuova.strip()}`.",
             nuova=proposta, vecchia=vecchia if proposta else None, riga=numero,
             semplice="`domanda` serve per le risposte sì/no; per farti scrivere un testo usa `chiedi`.",
             esempio=("`chiedi` legge un testo, `domanda` una risposta sì/no:",
                      'variabile nome = chiedi("Come ti chiami? ")\n'
                      'se domanda("Vuoi continuare?") allora\n    stampa("Ciao {nome}")\nfine'))
