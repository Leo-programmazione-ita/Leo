"""Parser a discesa ricorsiva: ``list[Token]`` -> :class:`leo.nodi.Programma`.

API (docs/CONTRATTI.md, sezione 4)::

    Parser(token, nome_file="<sorgente>", *, recupero=False, rigoroso=None)
        .analizza() -> Programma
        .espressione_isolata() -> Espressione     # parti interpolate
    analizza_token(token, nome_file="<sorgente>", **kw) -> Programma

La grammatica e' quella EBNF di docs/PROGETTO.md. Precedenze, dalla piu' bassa:
``o`` < ``e`` < confronti (concatenabili, un solo nodo :class:`Confronto`) <
``..`` (non associativo) < ``+ -`` < ``* / // %`` < ``-x``/``non`` (prefissi) <
``^`` (a destra) < chiamata, indice, attributo. Nessun ripiegamento delle
costanti: ``-3`` e' ``Unaria("-", Letterale(3))``.

Il parser si ferma sempre al PRIMO errore (``ErroreSintassi``). In modalita'
``recupero`` allega all'errore le :class:`Correzione` di forma possibili
(``fine`` mancante collocato secondo l'indentazione, virgola o parentesi
mancanti, parole chiave storpiate o di altri linguaggi...). Le correzioni per
``==``/``=`` e per ``allora``/``fai``/``volte`` mancanti sono allegate sempre.
La verifica delle correzioni ("il file diventa analizzabile") la fa
``leo.correzioni``.
"""

from __future__ import annotations

from bisect import bisect_right
import os
import re
import sys
from typing import Any, Iterable

from .errori import Correzione, ErroreSintassi, TIPI_ERRORE
from .controllo.sintassi import SintassiTipi, errore_punto_interrogativo
from .nodi import (
    Argomento, Assegnazione, Attributo, Binaria, Cattura, Chiamata, Confronto,
    Continua, DefinizioneFunzione, Dichiarazione, DizionarioLetterale, Espressione,
    Evento, FunzioneAnonima, Indice, Interrompi, Intervallo, Istruzione,
    IstruzioneEspressione, Lancia, Letterale, ListaLetterale, Logica, Mentre, Nome,
    Parametro, PerOgni, Programma, Prova, RamoSe, Restituisci, RiferimentoGenitore, Ripeti, Se,
    TestoInterpolato, Unaria,
    AssegnazioneMultipla, Caso, DichiarazioneMultipla, Importa, ListaCompresa, Scegli, Verifica,
    Aspettati, AspettatiErrore, BloccoVerifica, Parallelo, Temporizzatore, ValoreFormattato,
)
from .tokens import (
    ETICHETTE_FINE, PAROLE_DI_CONTESTO, TIPI_ASSEGNAZIONE, TIPI_CONFRONTO, TIPI_PAROLA_CHIAVE, TipoToken, Token,
    DURATA_ANIMA_PREDEFINITA, FRASI_DI_ZUCCHERO, SINONIMI_EVENTI, UNITA_DI_TEMPO, e_inizio_da_solo,
    segna_frase, UNITA_TEMPORIZZATORI, frase_potenza, e_in_parallelo,
)

T = TipoToken

__all__ = ["Parser", "analizza_token", "LIMITE_ANNIDAMENTO", "PAROLE_PER_CONTESTO", "rigoroso_da_ambiente"]

#: Quanti livelli possono annidarsi le espressioni (parentesi, liste, `-`/`non`
#: ripetuti, `^`) e, separatamente, i blocchi (`se` dentro `se` ...). Oltre il
#: limite il parser segnala un errore di sintassi invece di esaurire la pila di
#: Python (``RecursionError``).
LIMITE_ANNIDAMENTO = 100

_APRE_TIPI = frozenset({T.PARENTESI_APERTA, T.QUADRA_APERTA, T.GRAFFA_APERTA})
_CHIUDE_TIPI = frozenset({T.PARENTESI_CHIUSA, T.QUADRA_CHIUSA, T.GRAFFA_CHIUSA})

#: Suggerimento comune degli errori nei formati dell'interpolazione (``{prezzo:2}``).
SUGGERIMENTO_FORMATO = ("Dopo i due punti scrivi quanti decimali vuoi, da 0 a 20 (`{prezzo:2}`), "
                        "oppure `migliaia` (`{n:migliaia}`), o entrambi (`{totale:migliaia 2}`).")

#: Limite minimo della pila di Python mentre si analizza (ogni livello di
#: parentesi usa una dozzina di chiamate del parser).
_LIMITE_RICORSIONE_PARSER = 20_000


def rigoroso_da_ambiente() -> bool:
    """Vero se la variabile d'ambiente ``LEO_RIGOROSO`` (impostata da
    ``leo --rigoroso``; vale anche la vecchia ``DANTE_RIGOROSO``) chiede di
    disattivare le tolleranze."""
    from . import variabile_ambiente

    return (variabile_ambiente("RIGOROSO") or "").strip().lower() in ("1", "si", "sì", "vero")

# Parole che chiudono (o proseguono) un blocco: prima di esse finisce l'istruzione.
_CHIUSURE = frozenset({T.FINE, T.ALTRIMENTI, T.ALTRIMENTI_SE, T.CATTURA, T.INFINE})

# Token con cui puo' cominciare un'espressione.
_INIZIO_ESPRESSIONE = frozenset({
    T.INTERO, T.DECIMALE, T.TESTO, T.TESTO_INTERPOLATO, T.NOME, T.VERO, T.FALSO,
    T.NULLA, T.PARENTESI_APERTA, T.QUADRA_APERTA, T.GRAFFA_APERTA, T.FUNZIONE,
    T.MENO, T.NON,
})

# Dopo `scegli`/`verifica` questi token fanno capire che la parola e' un comando
# (`scegli voto`), non un nome usato in un'espressione (`scegli(3)`, `scegli + 1`).
_INIZIO_VALORE_DI_CONTESTO = frozenset({
    T.INTERO, T.DECIMALE, T.TESTO, T.TESTO_INTERPOLATO, T.NOME, T.VERO, T.FALSO,
    T.NULLA, T.NON, T.E, T.GRAFFA_APERTA, T.FUNZIONE,
})

# Tipi che possono fare da etichetta dopo ``fine`` (oltre a NOME "per").
_TIPI_ETICHETTA = frozenset({
    T.SE, T.MENTRE, T.PER_OGNI, T.RIPETI, T.FUNZIONE, T.PROVA, T.QUANDO,
})

# Token con cui puo' finire un valore (dopo di essi ci si aspetta un operatore).
_FINE_VALORE = frozenset({
    T.INTERO, T.DECIMALE, T.TESTO, T.TESTO_INTERPOLATO, T.NOME, T.VERO, T.FALSO,
    T.NULLA, T.PARENTESI_CHIUSA, T.QUADRA_CHIUSA, T.GRAFFA_CHIUSA, T.E,
})

# Operatori di Leo che una parola di altri linguaggi puo' indicare
# (`and` -> `e`, `or` -> `o`, `mod` -> `%`, `div` -> `//`, `is` -> `è`).
_OPERATORI_DA_PAROLA = frozenset({"e", "o", "%", "//", "^", "è", "non è", "==", "!=", "in"})

# Sostituzioni di piu' parole che restano un solo token di Leo (`for` ->
# `per ogni`, `elif` -> `altrimenti se`): si possono proporre senza rischi.
_PIU_PAROLE_SICURE = frozenset({"per ogni", "altrimenti se"})

#: Parole di altri linguaggi (o sinonimi italiani non ammessi) all'inizio di
#: un'istruzione che indicano una parola di contesto: `seleziona voto`,
#: `switch voto`, `match voto` -> `scegli`; `import`, `includi` -> `importa`.
#: Si propongono solo quando l'istruzione non si analizza.
PAROLE_PER_CONTESTO: dict[str, str] = {
    "seleziona": "scegli", "selezionare": "scegli", "switch": "scegli", "match": "scegli",
    "select": "scegli", "smista": "scegli",
    "import": "importa", "includi": "importa", "includere": "importa", "include": "importa",
    "importare": "importa", "require": "importa", "using": "importa",
    "asserisci": "verifica", "assert": "verifica",
}

_FRASE_CONTESTO = {
    "scegli": "In Leo si scrive `scegli`: `scegli voto`, poi i rami `caso 10 allora` e `fine`.",
    "importa": "In Leo si scrive `importa`: `importa \"geometria.leo\"` oppure `importa matematica come m`.",
    "verifica": "In Leo si scrive `verifica`: `verifica x > 0, \"x deve essere positivo\"`.",
}

# --- frasi di zucchero (aumenta / diminuisci / anima) ---------------------------
_TESTE_DI_FRASE = frozenset({T.AUMENTA, T.DIMINUISCI, T.ANIMA})
#: Token con cui un valore scritto subito dopo il bersaglio fa capire che manca
#: la parola di collegamento (`aumenta x 5` -> manca `di`).
_INIZIO_VALORE_SEMPLICE = frozenset({
    T.INTERO, T.DECIMALE, T.TESTO, T.TESTO_INTERPOLATO, T.NOME, T.VERO, T.FALSO, T.NULLA,
    T.PARENTESI_APERTA, T.QUADRA_APERTA, T.MENO,
})
#: Parole scritte al posto di `di` (`aumenta x da 5`, `aumenta x per 5`...).
_QUASI_DI = frozenset({"da", "de", "del", "dello", "della", "per", "con", "of", "by", "d"})
#: Parole scritte al posto di `a` in `anima` (`anima P.x ad 300`, `verso 300`...).
_QUASI_A = frozenset({"ad", "al", "alla", "verso", "to", "fino", "sino", "da"})
#: Parole scritte al posto di `in` prima della durata.
_QUASI_IN = frozenset({"per", "entro", "tra", "fra", "durante", "during", "for", "con", "di"})
#: Unita' di tempo scritte in altri modi -> forma accettata.
_QUASI_UNITA = {"sec": "secondi", "secs": "secondi", "seconds": "secondi", "second": "secondi",
                "secondì": "secondi", "msec": "millisecondi", "milliseconds": "millisecondi",
                "millis": "millisecondi", "millisec": "millisecondi"}
#: Curve di `anima` (libreria di animazione): senza virgolette sono un errore guidato.
_CURVE_NOTE = frozenset({"lineare", "morbida", "rimbalzo", "elastica", "veloce", "lenta"})

_OP_SOMMA = frozenset({T.PIU, T.MENO})
_OP_PRODOTTO = frozenset({T.ASTERISCO, T.BARRA, T.DOPPIA_BARRA, T.PERCENTUALE})

# Nome leggibile delle parentesi di chiusura.
_CHIUSA_DI = {
    T.PARENTESI_APERTA: ")",
    T.QUADRA_APERTA: "]",
    T.GRAFFA_APERTA: "}",
}
_TIPO_CHIUSA = {
    T.PARENTESI_APERTA: T.PARENTESI_CHIUSA,
    T.QUADRA_APERTA: T.QUADRA_CHIUSA,
    T.GRAFFA_APERTA: T.GRAFFA_CHIUSA,
}


# ---------------------------------------------------------------------------
# Utilita'
# ---------------------------------------------------------------------------

def _distanza(a: str, b: str) -> int:
    """Distanza di edit con scambio di lettere vicine (``fien`` -> ``fine`` = 1).

    Usata solo per riconoscere la parola chiave attesa scritta male.
    """
    if a == b:
        return 0
    la, lb = len(a), len(b)
    d = [[0] * (lb + 1) for _ in range(la + 1)]
    for i in range(la + 1):
        d[i][0] = i
    for j in range(lb + 1):
        d[0][j] = j
    for i in range(1, la + 1):
        for j in range(1, lb + 1):
            costo = 0 if a[i - 1] == b[j - 1] else 1
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + costo)
            if i > 1 and j > 1 and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                d[i][j] = min(d[i][j], d[i - 2][j - 2] + 1)
    return d[la][lb]


def _chiedi_suggerimento(funzione: str, parola: str) -> str | None:
    """Chiama ``leo.suggerimenti.<funzione>(parola)`` in modo protetto.

    Se il modulo manca, non e' ancora implementato o solleva, restituisce None.
    Se la risposta e' una frase con apici inversi, ne estrae la parola.
    """
    try:
        from . import suggerimenti  # import pigro: il modulo puo' non essere pronto
    except Exception:
        return None
    f = getattr(suggerimenti, funzione, None)
    if not callable(f):
        return None
    try:
        risposta = f(parola)
    except Exception:
        return None
    if not isinstance(risposta, str) or not risposta.strip():
        return None
    risposta = risposta.strip()
    if "`" in risposta:
        parti = risposta.split("`")
        if len(parti) >= 3 and parti[1].strip():
            return parti[1].strip()
        return None
    return risposta


# --- parole chiave e sinonimi con l'accento sbagliato ------------------------
#: normalizzata (senza accenti, minuscola) -> [(forma giusta, canonica)] per le
#: parole chiave, le parole di contesto e i sinonimi di UNA parola
#: (``dati/sinonimi.toml``). Le forme con l'accento vengono prima.
_CACHE_FORME: dict[str, list[tuple[str, str]]] | None = None


def _forme_parole_chiave() -> dict[str, list[tuple[str, str]]]:
    global _CACHE_FORME
    if _CACHE_FORME is not None:
        return _CACHE_FORME
    from .tokens import PAROLE_CHIAVE
    from .vocabolario import normalizza
    coppie: list[tuple[str, str]] = [(p, p) for p in PAROLE_CHIAVE]
    coppie += [(p, p) for p in PAROLE_DI_CONTESTO]
    try:
        from .sinonimi import carica_sinonimi
        for parole, tipo in carica_sinonimi().mappa.items():
            if len(parole) == 1:
                coppie.append((parole[0], tipo.value))
    except Exception:  # noqa: BLE001 - sinonimi.toml assente o malformato
        pass
    forme: dict[str, list[tuple[str, str]]] = {}
    for forma, canonica in coppie:
        elenco = forme.setdefault(normalizza(forma), [])
        if (forma, canonica) not in elenco:
            elenco.append((forma, canonica))
    for elenco in forme.values():
        elenco.sort(key=lambda fc: normalizza(fc[0]) == fc[0])  # prima quelle con l'accento
    _CACHE_FORME = forme
    return forme


def _parola_con_accento_sbagliato(parola: str) -> tuple[str, str] | None:
    """``(forma giusta, canonica)`` se ``parola`` e' una parola chiave o un
    sinonimo scritto senza accento o con l'accento sbagliato: ``senno`` ->
    ``("sennò", "altrimenti")``, ``finchè`` -> ``("finché", "mentre")``,
    ``altrimentí`` -> ``("altrimenti", "altrimenti")``, ``é`` -> ``("è", "è")``.
    Le sole differenze di maiuscole (``Fine``) non contano: se ne occupano i
    suggerimenti delle parole storpiate."""
    if not parola:
        return None
    from .vocabolario import normalizza
    n = normalizza(parola)
    candidati = _forme_parole_chiave().get(n)
    if not candidati or any(parola == forma for forma, _ in candidati):
        return None
    parola_con_accento = n != parola.lower().replace("_", " ").strip()
    for forma, canonica in candidati:
        if parola_con_accento or normalizza(forma) != forma:
            return forma, canonica
    return None


def _frasi_accento(parola: str, forma: str, canonica: str, rigoroso: bool) -> tuple[str, str]:
    """Messaggio e suggerimento per ``parola`` scritta al posto di ``forma``."""
    from .vocabolario import normalizza
    if normalizza(parola) == parola.lower():
        come = "senza accento"
    elif normalizza(forma) == forma:
        come = "con un accento di troppo"
    else:
        come = "con l'accento sbagliato"
    messaggio = f"`{parola}` sembra `{forma}` scritto {come}."
    if forma == canonica:
        suggerimento = f"Scrivi `{forma}`."
    elif rigoroso:
        suggerimento = f"Scrivi `{canonica}` (con --rigoroso il sinonimo `{forma}` non vale)."
    else:
        suggerimento = f"Scrivi `{forma}` oppure `{canonica}`."
    return messaggio, suggerimento


def _testo(tok: Token) -> str:
    """Testo del token cosi' come appare nel sorgente (il meglio che si sa)."""
    if tok.testo_originale is not None:
        return tok.testo_originale
    if tok.tipo in (T.NOME, T.INTERO, T.DECIMALE):
        return str(tok.valore)
    if tok.tipo is T.TESTO:
        return '"' + str(tok.valore) + '"'
    if tok.tipo in (T.FINE_RIGA, T.FINE_FILE, T.TESTO_INTERPOLATO, T.ERRORE, T.COMMENTO):
        return ""
    return tok.tipo.value


def _lunghezza(tok: Token) -> int:
    if tok.lunghezza:
        return tok.lunghezza
    return len(_testo(tok))


def _sintetico(tok: Token) -> bool:
    return tok.origine == "sintetico" and not tok.lunghezza


def _parola_come_nome(tok: Token) -> bool:
    """Dopo il punto una parola chiave scritta in forma canonica e' un nome
    (``Elenco.scegli()``, ``quando Scelta.caso fai``)."""
    return (tok.tipo in TIPI_PAROLA_CHIAVE and tok.origine == "canonica"
            and isinstance(tok.valore, str) and tok.valore.isidentifier()
            and tok.testo_originale in (None, tok.valore))


def _descrivi(tok: Token) -> str:
    """Descrizione di un token per i messaggi ("ho trovato ...")."""
    if tok.tipo is T.FINE_RIGA:
        return "`;`" if tok.valore == ";" else "la fine della riga"
    if tok.tipo is T.FINE_FILE:
        return "la fine del file"
    if tok.tipo in (T.TESTO, T.TESTO_INTERPOLATO):
        return "un testo"
    if tok.tipo in (T.INTERO, T.DECIMALE):
        return f"il numero `{_testo(tok)}`"
    if tok.tipo in TIPI_PAROLA_CHIAVE:
        return f"la parola chiave `{_testo(tok)}`"
    return f"`{_testo(tok)}`"


def _descrivi_bersaglio(espr: Espressione) -> str:
    if isinstance(espr, Letterale):
        return "un valore fisso"
    if isinstance(espr, TestoInterpolato):
        return "un testo"
    if isinstance(espr, Chiamata):
        return "una chiamata di funzione"
    if isinstance(espr, (Binaria, Unaria)):
        return "un'operazione"
    if isinstance(espr, Confronto):
        return "un confronto"
    if isinstance(espr, Logica):
        return "un'espressione logica"
    if isinstance(espr, Intervallo):
        return "un intervallo"
    if isinstance(espr, ListaLetterale):
        return "una lista"
    if isinstance(espr, DizionarioLetterale):
        return "un dizionario"
    if isinstance(espr, FunzioneAnonima):
        return "una funzione"
    return "questa espressione"


class _Blocco:
    """Un blocco aperto (``se``, ``mentre``, ``per ogni``, ...)."""

    __slots__ = ("nome", "token", "indice", "rientro")

    def __init__(self, nome: str, token: Token, indice: int, rientro: int) -> None:
        self.nome = nome
        self.token = token
        self.indice = indice
        self.rientro = rientro


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

class Parser(SintassiTipi):
    """Parser a discesa ricorsiva di Leo (tipi, strutture e contratti: leo/controllo/sintassi.py)."""

    def __init__(self, token: list[Token], nome_file: str = "<sorgente>", *,
                 recupero: bool = False, rigoroso: bool | None = None) -> None:
        self.nome_file = nome_file
        self.recupero = recupero
        #: Senza tolleranze (`allora`/`fai` non intercambiabili). ``None``: dalla
        #: variabile d'ambiente ``LEO_RIGOROSO`` (o la vecchia ``DANTE_RIGOROSO``).
        self.rigoroso = rigoroso_da_ambiente() if rigoroso is None else bool(rigoroso)
        self._livello_espressioni = 0
        self._livello_blocchi = 0
        if sys.getrecursionlimit() < _LIMITE_RICORSIONE_PARSER:
            sys.setrecursionlimit(_LIMITE_RICORSIONE_PARSER)
        lista = [t for t in token if t.tipo is not T.COMMENTO]
        if not lista or lista[-1].tipo is not T.FINE_FILE:
            if lista:
                ultimo = lista[-1]
                riga, colonna = ultimo.riga, ultimo.colonna + _lunghezza(ultimo)
            else:
                riga, colonna = 1, 1
            lista.append(Token(T.FINE_FILE, None, riga, colonna, None, 0, "sintetico"))
        self._t: list[Token] = lista
        self._i = 0
        self._aperti: list[_Blocco] = []
        self._chiusi: list[tuple[_Blocco, Token]] = []
        self._nomi_isolati: list[tuple[int, Token]] = []
        self._cicli = 0
        self._funzioni = 0
        #: > 0 mentre si legge la condizione di `se`/`mentre`: li' `=` vale `==` (`se x = 5`)
        self._in_condizione = 0
        self._inizi: list[Token] = []      # primo token di ogni riga logica
        self._rientri: dict[int, int] = {}  # riga -> rientro (colonna - 1)
        # indici per le ricerche per riga (O(log n) invece di scorrere `_inizi`)
        self._righe_inizi: list[int] = []   # righe di `_inizi`, nello stesso ordine
        self._inizio_per_riga: dict[int, Token] = {}
        self._inizi_ordinati = True         # righe di `_inizi` crescenti?
        self._calcola_righe()

    # ------------------------------------------------------------------ API

    def analizza(self) -> Programma:
        """Analizza tutto il programma e restituisce il :class:`Programma`."""
        try:
            return self._analizza()
        except RecursionError:
            raise self._troppo_annidato("programma") from None

    def _analizza(self) -> Programma:
        primo = self._cor
        istruzioni: list[Istruzione] = []
        teste: list[Token] = []                 # primo token di ogni istruzione esterna
        principale: list[Istruzione] | None = None
        t_inizio: Token | None = None
        self._salta_righe()
        while self._cor.tipo is not T.FINE_FILE:
            t = self._cor
            if t.tipo in _CHIUSURE:
                raise self._chiusura_orfana(t)
            if e_inizio_da_solo(self._t, self._i):
                if t_inizio is not None:
                    raise self._errore(
                        f"Ci sono due blocchi `inizio`: il primo è alla riga {t_inizio.riga}. "
                        "Un programma ha un solo blocco `inizio`.", t,
                        "Sposta queste istruzioni dentro il primo `inizio ... fine` e togli questo `inizio`.")
                t_inizio = t
                principale = self._blocco_inizio()
                self._fine_istruzione()
            else:
                teste.append(t)
                istruzioni.append(self._istruzione_completa())
            self._salta_righe()
        riga = primo.riga if primo.tipo is not T.FINE_FILE else 1
        colonna = primo.colonna if primo.tipo is not T.FINE_FILE else 1
        indice_inizio = None
        if principale is not None and t_inizio is not None:
            self._controlla_fuori_da_inizio(istruzioni, teste, t_inizio)
            # il programma principale parte DOPO tutto il resto: cosi' le funzioni
            # e i gestori `quando` scritti dopo `fine` sono gia' pronti
            indice_inizio = len(istruzioni)
            istruzioni = istruzioni + principale
        programma = Programma(istruzioni, nome_file=self.nome_file, riga=riga or 1, colonna=colonna or 1,
                              pubblici=self.__dict__.get("_pubblici"))
        if indice_inizio is not None and t_inizio is not None:
            # informazione in piu' (non e' un campo del nodo): per `leo spiega`
            programma.blocco_inizio = (t_inizio.riga, indice_inizio)  # type: ignore[attr-defined]
        return programma

    # -------------------------------------------- blocco `inizio ... fine`

    def _blocco_inizio(self) -> list[Istruzione]:
        """``inizio`` (da solo sulla riga) ... ``fine``: il programma principale.

        Dentro valgono le regole del livello principale (anche ``funzione`` e
        ``quando``). Il parser lo traduce senza nodi nuovi: le istruzioni vanno
        in fondo al :class:`Programma`, dopo quelle scritte fuori dal blocco."""
        t = self._avanza()
        blocco = self._apri("inizio", t)
        corpo = self._blocco(blocco, frozenset({T.FINE}))
        self._chiudi(blocco)
        return corpo

    @staticmethod
    def _preparazione(istruzione: Istruzione) -> bool:
        """Vero per le istruzioni che possono stare fuori da ``inizio ... fine``:
        funzioni, gestori ``quando``, variabili, costanti, ``importa`` (e le
        assegnazioni semplici ``x = 1``, che nello stile implicito dichiarano)."""
        if isinstance(istruzione, (Dichiarazione, DefinizioneFunzione, Evento, Importa, BloccoVerifica)):
            return True
        if isinstance(istruzione, Assegnazione):
            return isinstance(istruzione.bersaglio, Nome)
        if isinstance(istruzione, AssegnazioneMultipla):
            return all(isinstance(b, Nome) for b in istruzione.bersagli)
        return False

    def _controlla_fuori_da_inizio(self, istruzioni: list[Istruzione], teste: list[Token],
                                   t_inizio: Token) -> None:
        for istruzione, t in zip(istruzioni, teste):
            if self._preparazione(istruzione):
                continue
            dove = "prima del" if t.riga < t_inizio.riga else "dopo il"
            raise self._errore(
                f"Questa istruzione è {dove} blocco `inizio`: quando c'è `inizio ... fine`, il codice "
                "che parte subito va dentro il blocco.", t,
                f"Spostala dentro `inizio` (riga {t_inizio.riga}). Fuori dal blocco restano solo funzioni, "
                "gestori `quando`, variabili, costanti, `importa` e le verifiche.")

    def _inizio_fuori_posto(self, t: Token) -> ErroreSintassi:
        """``inizio`` dentro un altro blocco."""
        if not self._aperti:  # pragma: no cover - al livello esterno lo gestisce `_analizza`
            return self._errore("`inizio` qui non è al suo posto.", t,
                                "`inizio` apre il programma principale, da solo sulla sua riga.")
        interno = self._aperti[-1]
        if interno.nome == "inizio":
            return self._errore(
                f"Un blocco `inizio` non può contenerne un altro: il primo è aperto alla riga "
                f"{interno.token.riga}.", t, "Un programma ha un solo blocco `inizio`.")
        correzioni = []
        if self.recupero and t.riga in self._rientri:
            correzioni.append(self._correzione_fine(interno, entro_riga=t.riga))
        return self._errore(
            "`inizio` si usa solo al livello più esterno del programma, fuori da ogni blocco.", t,
            f"Forse manca `fine` per il blocco `{interno.nome}` aperto alla riga {interno.token.riga}.",
            correzioni)

    def espressione_isolata(self) -> Espressione:
        """Una sola espressione seguita da FINE_FILE (parti ``{...}`` dei testi)."""
        try:
            return self._espressione_isolata()
        except RecursionError:
            raise self._troppo_annidato("espressione") from None

    def _troppo_annidato(self, cosa: str) -> ErroreSintassi:
        messaggi = {
            "espressione": "Troppe parentesi o operatori uno dentro l'altro",
            "blocco": "Troppi blocchi uno dentro l'altro",
        }
        testo = messaggi.get(cosa, "Il codice è annidato troppo in profondità")
        return self._errore(
            f"{testo}: al massimo {LIMITE_ANNIDAMENTO} livelli.",
            self._cor, "Dividi il codice in pezzi più semplici, per esempio con variabili o funzioni di appoggio.")

    def _espressione_isolata(self) -> Espressione:
        self._salta_righe()
        if self._cor.tipo is T.FINE_FILE:
            raise self._errore("Tra le graffe `{}` manca l'espressione.", self._cor)
        espr = self._espressione()
        self._salta_righe()
        if self._cor.tipo is not T.FINE_FILE:
            t = self._cor
            if t.tipo is T.DUE_PUNTI:
                raise self._formato_sbagliato(t)
            raise self._errore(
                f"Tra le graffe ci va una sola espressione, ma dopo ho trovato {_descrivi(t)}.", t)
        return espr

    def _formato_sbagliato(self, t: Token) -> ErroreSintassi:
        """``{x:}``, ``{x:-1}``: dopo i due punti c'e' qualcosa che non e' un formato."""
        resto = []
        k = self._i + 1
        while k < len(self._t) and self._t[k].tipo not in (T.FINE_FILE, T.FINE_RIGA):
            resto.append(_testo(self._t[k]))
            k += 1
        formato = "".join(resto).strip()
        if not formato:
            return self._errore("Dopo i due punti manca il formato.", t, SUGGERIMENTO_FORMATO)
        return self._errore(f"Non conosco il formato `:{formato}`.", t, SUGGERIMENTO_FORMATO)

    # ------------------------------------------------------- scorrimento

    @property
    def _cor(self) -> Token:
        return self._t[self._i]

    def _guarda(self, passi: int = 1) -> Token:
        return self._t[min(self._i + passi, len(self._t) - 1)]

    def _avanza(self) -> Token:
        t = self._t[self._i]
        if t.tipo is not T.FINE_FILE:
            self._i += 1
        return t

    def _salta_righe(self) -> None:
        while self._cor.tipo is T.FINE_RIGA:
            self._i += 1

    def _precedente(self) -> Token | None:
        """Ultimo token consumato che occupa davvero del testo nel sorgente."""
        j = self._i - 1
        while j >= 0:
            t = self._t[j]
            if t.tipo not in (T.FINE_RIGA, T.FINE_FILE) and not _sintetico(t):
                return t
            j -= 1
        return None

    def _dopo(self, tok: Token | None) -> tuple[int, int]:
        """Posizione subito dopo il token (per gli inserimenti)."""
        if tok is None:
            return 1, 1
        return tok.riga, tok.colonna + _lunghezza(tok)

    # -------------------------------------------------------- righe e rientri

    def _calcola_righe(self) -> None:
        precedente: Token | None = None
        riga_precedente = 0
        for t in self._t:
            if t.tipo in (T.FINE_RIGA, T.FINE_FILE):
                precedente = t
                continue
            if precedente is None or (precedente.tipo is T.FINE_RIGA and t.riga > riga_precedente):
                if t.riga not in self._rientri:
                    if self._righe_inizi and t.riga < self._righe_inizi[-1]:
                        self._inizi_ordinati = False
                    self._inizi.append(t)
                    self._righe_inizi.append(t.riga)
                    self._inizio_per_riga[t.riga] = t
                    self._rientri[t.riga] = max(0, t.colonna - 1)
            precedente = t
            riga_precedente = t.riga

    def _rientro_di(self, riga: int) -> int:
        """Rientro della riga logica che contiene ``riga``."""
        if self._inizi_ordinati:
            # ultimo inizio con riga <= `riga` (ricerca binaria)
            k = bisect_right(self._righe_inizi, riga)
            return self._rientri[self._righe_inizi[k - 1]] if k else 0
        migliore = 0
        for t in self._inizi:
            if t.riga > riga:
                break
            migliore = self._rientri[t.riga]
        return migliore

    # ------------------------------------------------------------ errori

    def _errore(self, messaggio: str, tok: Token, suggerimento: str | None = None,
                correzioni: Iterable[Correzione] = (), lunghezza: int | None = None) -> ErroreSintassi:
        if tok.tipo is T.PUNTO_INTERROGATIVO:  # `?` fuori da un tipo
            errore = errore_punto_interrogativo(self, tok)
            messaggio, suggerimento, correzioni = errore.messaggio, errore.suggerimento, ()
        elif tok.tipo is T.ERRORE:  # token d'errore del lexer tollerante
            messaggio = str(tok.valore)
            suggerimento = None
            correzioni = ()
        else:
            operatore = self._operatore_di_altro_linguaggio(tok)
            if operatore is not None:
                # `5 mod 2`, `a and b`: la parola e' un operatore scritto come in
                # un altro linguaggio. Le altre correzioni (virgola, `allora`...)
                # sarebbero sbagliate: si propone solo la sostituzione.
                messaggio = f"Non conosco la parola `{_testo(tok)}`."
                suggerimento = f"In Leo si scrive `{operatore}`."
                correzioni = [self._sostituisci(
                    tok, operatore, f"`{_testo(tok)}` non è una parola di Leo: si scrive `{operatore}`")
                ] if self.recupero else []
            else:
                accento = self._operatore_con_accento_sbagliato(tok)
                succ = self._t[self._i + 1] if self._t[self._i] is tok and self._i + 1 < len(self._t) else None
                if accento is None and tok.tipo is T.NON and succ is not None and succ.tipo is T.NOME \
                        and succ.riga == tok.riga and self._accento_sbagliato(str(succ.valore)) == ("è", "è"):
                    # `x non é 3`: `non è` con l'accento sbagliato
                    messaggio, suggerimento = _frasi_accento(_testo(succ), "è", "è", self.rigoroso)
                    correzioni = [self._sostituisci(succ, "è", f"`{_testo(succ)}` sembra `è`: si scrive `è`")]
                    tok = succ
                    lunghezza = max(1, _lunghezza(succ))
                elif accento is not None:
                    # `a nonche b`, `x é 3`: operatore scritto con l'accento sbagliato
                    errore = self._errore_accento(tok, *accento)
                    messaggio, suggerimento = errore.messaggio, errore.suggerimento
                    correzioni = errore.correzioni
                    lunghezza = errore.lunghezza
        if lunghezza is None:
            lunghezza = _lunghezza(tok) or 1
        return ErroreSintassi(messaggio, tok.riga, tok.colonna, suggerimento,
                              correzioni=list(correzioni), nome_file=self.nome_file,
                              lunghezza=lunghezza)

    def _operatore_di_altro_linguaggio(self, tok: Token) -> str | None:
        """Se ``tok`` (il token corrente) e' un NOME scritto dopo un valore, sulla
        stessa riga, e in un altro linguaggio indica un operatore (``and``,
        ``or``, ``mod``, ``div``...), restituisce l'operatore di Leo."""
        if tok.tipo is not T.NOME or self._t[self._i] is not tok or self._i == 0:
            return None
        prec = self._t[self._i - 1]
        if prec.tipo not in _FINE_VALORE or prec.riga != tok.riga:
            return None
        operatore = _chiedi_suggerimento("parola_altro_linguaggio", str(tok.valore))
        return operatore if operatore in _OPERATORI_DA_PAROLA else None

    def _operatore_con_accento_sbagliato(self, tok: Token) -> tuple[str, str] | None:
        """Come ``_operatore_di_altro_linguaggio``, per ``nonche``/``é``: la
        coppia ``(forma giusta, canonica)`` se e' un operatore con l'accento sbagliato."""
        if tok.tipo is not T.NOME or self._t[self._i] is not tok or self._i == 0:
            return None
        prec = self._t[self._i - 1]
        if prec.tipo not in _FINE_VALORE or prec.riga != tok.riga:
            return None
        accento = self._accento_sbagliato(str(tok.valore))
        return accento if accento is not None and accento[1] in _OPERATORI_DA_PAROLA else None

    def _inatteso(self, atteso: str, tok: Token | None = None, suggerimento: str | None = None,
                  correzioni: Iterable[Correzione] = ()) -> ErroreSintassi:
        tok = tok or self._cor
        return self._errore(f"Mi aspettavo {atteso}, ma ho trovato {_descrivi(tok)}.", tok,
                            suggerimento, correzioni)

    def _riservata(self, tok: Token, cosa: str) -> ErroreSintassi:
        """Errore per un nome mancante: se c'e' una parola chiave lo spiega."""
        if tok.tipo in TIPI_PAROLA_CHIAVE:
            return self._errore(
                f"`{_testo(tok)}` è una parola riservata di Leo: non si può usare come nome.",
                tok, "Scegli un altro nome.")
        return self._inatteso(cosa, tok)

    def _inserisci_dopo(self, tok: Token | None, testo: str, motivo: str) -> Correzione:
        riga, colonna = self._dopo(tok)
        return Correzione(riga, colonna, "", testo, motivo)

    def _sostituisci(self, tok: Token, nuovo: str, motivo: str) -> Correzione:
        return Correzione(tok.riga, tok.colonna, _testo(tok), nuovo, motivo)

    @staticmethod
    def _con_alternative(correzioni: list[Correzione]) -> list[Correzione]:
        """Una correzione con le altre (ugualmente plausibili) in ``alternative``."""
        if not correzioni:
            return []
        prima = correzioni[0]
        prima.alternative = list(prima.alternative) + list(correzioni[1:])
        return [prima]

    def _parole_suggerite(self, parola: str) -> list[tuple[str, str]]:
        """Parole di Leo suggerite per ``parola``: lista di (parola, frase)."""
        risultato: list[tuple[str, str]] = []
        accento = self._accento_sbagliato(parola)
        if accento is not None:
            # `senno` -> `sennò` (= `altrimenti`), `finche` -> `finché` (= `mentre`)
            forma, canonica = accento
            risultato.append((canonica, _frasi_accento(parola, forma, canonica, self.rigoroso)[1]))
        contesto = PAROLE_PER_CONTESTO.get(parola.lower())
        if contesto is not None:
            risultato.append((contesto, _FRASE_CONTESTO[contesto]))
        altra = _chiedi_suggerimento("parola_altro_linguaggio", parola)
        if altra == contesto:
            altra = None
        if altra and altra != parola:
            risultato.append((altra, f"In Leo si scrive `{altra}`."))
        simile = _chiedi_suggerimento("parola_chiave_simile", parola)
        if simile and simile != parola and simile not in (altra, contesto) \
                and not (accento and simile == accento[1]):
            risultato.append((simile, f"Forse intendevi `{simile}`?"))
        return risultato

    def _accento_sbagliato(self, parola: str) -> tuple[str, str] | None:
        """``(forma giusta, canonica)`` per una parola chiave o un sinonimo con
        l'accento sbagliato o mancante (``senno``, ``finchè``); con --rigoroso
        anche per i sinonimi scritti giusti (``sennò``), che li' sono nomi."""
        accento = _parola_con_accento_sbagliato(parola)
        if accento is None and self.rigoroso:
            from .vocabolario import normalizza
            for forma, canonica in _forme_parole_chiave().get(normalizza(parola), ()):
                if forma == parola and canonica != forma:
                    return forma, canonica
        return accento

    def _correzioni_accento(self, tok: Token, forma: str, canonica: str) -> list[Correzione]:
        """``senno`` -> ``sennò`` (e in alternativa ``altrimenti``); con --rigoroso
        solo la parola canonica."""
        parola = _testo(tok)
        proposte = [canonica] if self.rigoroso or forma == canonica else [forma, canonica]
        return self._con_alternative([
            self._sostituisci(tok, p, f"`{parola}` sembra `{forma}`: si scrive `{p}`")
            for p in proposte])

    def _errore_accento(self, tok: Token, forma: str, canonica: str) -> ErroreSintassi:
        parola = _testo(tok)
        messaggio, suggerimento = _frasi_accento(parola, forma, canonica, self.rigoroso)
        if self.rigoroso and _parola_con_accento_sbagliato(parola) is None:
            # sinonimo scritto giusto, ma con --rigoroso non vale
            messaggio = f"Con --rigoroso `{parola}` non è una parola di Leo."
            suggerimento = f"Scrivi `{canonica}`."
        errore = ErroreSintassi(messaggio, tok.riga, tok.colonna, suggerimento,
                                correzioni=self._correzioni_accento(tok, forma, canonica),
                                nome_file=self.nome_file, lunghezza=max(1, _lunghezza(tok)))
        errore._parser_arricchito = True  # type: ignore[attr-defined] - gia' completo
        return errore

    def _arricchisci(self, errore: ErroreSintassi, tok: Token) -> None:
        """Istruzione non analizzabile che inizia con un NOME: parola di altri
        linguaggi o parola chiave storpiata?"""
        accento = self._accento_sbagliato(str(tok.valore))
        indice = next((j for j, x in enumerate(self._t) if x is tok), None)
        succ = self._t[indice + 1] if indice is not None and indice + 1 < len(self._t) else None
        if accento is not None and succ is not None and (errore.riga, errore.colonna) == (succ.riga, succ.colonna):
            # `finche x < 2 fai`, `senno se x allora`: l'errore e' subito dopo la
            # prima parola, quindi e' la prima parola (una variabile `finche`
            # con un altro errore piu' avanti nella riga resta un nome)
            nuovo = self._errore_accento(tok, *accento)
            errore.messaggio = nuovo.messaggio
            errore.args = (errore.messaggio,) + tuple(errore.args[1:])
            errore.suggerimento = nuovo.suggerimento
            errore.riga, errore.colonna = tok.riga, tok.colonna
            errore.lunghezza = nuovo.lunghezza
            errore.correzioni = list(nuovo.correzioni)
            return
        parole = self._parole_suggerite(str(tok.valore))
        if not parole:
            return
        errore.suggerimento = parole[0][1]
        if parole[0][0] == PAROLE_PER_CONTESTO.get(str(tok.valore).lower()):
            # `seleziona voto`, `import matematica`: l'errore e' la prima parola, non `voto`
            errore.messaggio = f"Non conosco la parola `{_testo(tok)}`."
            errore.args = (errore.messaggio,) + tuple(errore.args[1:])
            errore.riga, errore.colonna = tok.riga, tok.colonna
            errore.lunghezza = max(1, _lunghezza(tok))
        if self.recupero:
            # Solo le sostituzioni che danno un solo token di Leo (`for` ->
            # `per ogni`, `elif` -> `altrimenti se`): `unless` -> `se non`,
            # `until` -> `mentre non`, `loop` -> `mentre vero fai` restano
            # suggerimenti, perche' sostituite alla cieca cambierebbero il
            # significato (`se non x == 3` vuol dire `se (non x) == 3`).
            correzioni = [
                self._sostituisci(tok, p, f"`{_testo(tok)}` non è una parola di Leo: si scrive `{p}`")
                for p, _ in parole if len(p.split()) == 1 or " ".join(p.split()) in _PIU_PAROLE_SICURE
            ]
            if correzioni:
                errore.correzioni = self._con_alternative(correzioni) + list(errore.correzioni)

    # ---------------------------------------------------------- blocchi

    def _apri(self, nome: str, tok: Token) -> _Blocco:
        blocco = _Blocco(nome, tok, self._i - 1, self._rientro_di(tok.riga))
        self._aperti.append(blocco)
        return blocco

    def _blocco(self, blocco: _Blocco, terminatori: frozenset) -> list[Istruzione]:
        corpo: list[Istruzione] = []
        while True:
            self._salta_righe()
            t = self._cor
            if t.tipo in terminatori:
                return corpo
            if t.tipo is T.FINE_FILE:
                raise self._mai_chiuso(blocco)
            if t.tipo in _CHIUSURE:
                raise self._chiusura_fuori_posto(t, blocco)
            corpo.append(self._istruzione_completa())

    def _chiudi(self, blocco: _Blocco) -> None:
        """Consuma ``fine`` [etichetta] e chiude il blocco."""
        t_fine = self._cor
        if t_fine.tipo is not T.FINE:  # non dovrebbe succedere: _blocco lo garantisce
            raise self._mai_chiuso(blocco)
        self._avanza()
        e = self._cor
        etichetta: str | None = None
        if e.riga == t_fine.riga and e.tipo is not T.FINE_RIGA:
            if e.tipo is T.NOME and e.valore in ("per", "scegli", "inizio", "ogni", "dopo", "verifica",
                                                  "aspettati", "parallelo"):
                etichetta = str(e.valore)
            elif e.tipo in _TIPI_ETICHETTA:
                etichetta = e.tipo.value
        if etichetta in ("per ogni", "per") and blocco.nome != "per ogni":
            # `[funzione () restituisci i fine per ogni i in 1..3]`: il `per ogni`
            # dopo `fine` e' della lista in una riga, non un'etichetta. Resta
            # un'etichetta (sbagliata) solo se la riga finisce li'.
            dopo = self._guarda()
            if etichetta == "per" and dopo.tipo is T.NOME and dopo.valore == "ogni" and dopo.riga == e.riga:
                dopo = self._guarda(2)
            if dopo.riga == e.riga and dopo.tipo not in (T.FINE_RIGA, T.FINE_FILE):
                etichetta = None
        if etichetta is not None:
            self._avanza()
            atteso = ETICHETTE_FINE.get(etichetta, etichetta)
            if atteso != blocco.nome:
                raise self._etichetta_sbagliata(blocco, t_fine, e, etichetta, atteso)
        self._aperti.pop()
        self._chiusi.append((blocco, t_fine))

    def _mai_chiuso(self, blocco: _Blocco) -> ErroreSintassi:
        t = blocco.token
        correzioni: list[Correzione] = []
        if self.recupero:
            correzioni = self._correzioni_fine_mancante(blocco)
        if blocco.nome == "inizio":
            return self._errore(
                f"Manca il `fine` del blocco `inizio` aperto alla riga {t.riga}.", t,
                "Il programma principale si chiude con `fine`, di solito prima delle funzioni.", correzioni)
        return self._errore(
            f"Il blocco `{blocco.nome}` aperto alla riga {t.riga} non è mai chiuso: manca `fine`.",
            t, "Ogni blocco si chiude con `fine`.", correzioni)

    def _etichetta_sbagliata(self, blocco: _Blocco, t_fine: Token, t_etichetta: Token,
                             etichetta: str, atteso: str) -> ErroreSintassi:
        correzioni: list[Correzione] = []
        if self.recupero:
            esterni = [b for b in self._aperti[:-1] if b.nome == atteso]
            if esterni and self._rientri.get(t_fine.riga) is not None:
                correzioni.append(self._correzione_fine(blocco, entro_riga=t_fine.riga))
            etichetta_giusta = {"in parallelo": "parallelo"}.get(blocco.nome, blocco.nome)
            correzioni.append(self._sostituisci(
                t_etichetta, etichetta_giusta,
                f"l'etichetta di `fine` deve essere `{etichetta_giusta}`"))
            correzioni = self._con_alternative(correzioni)
        lunghezza = (t_etichetta.colonna + _lunghezza(t_etichetta) - t_fine.colonna
                     if t_etichetta.riga == t_fine.riga else _lunghezza(t_fine))
        return self._errore(
            f"`fine {etichetta}` non corrisponde al blocco `{blocco.nome}` aperto alla riga "
            f"{blocco.token.riga}.",
            t_fine, None, correzioni, lunghezza=lunghezza)

    def _chiusura_orfana(self, t: Token) -> ErroreSintassi:
        """Parola di chiusura al livello esterno, senza blocchi aperti."""
        if t.tipo is T.FINE:
            return self._errore("Questo `fine` non chiude nessun blocco.", t,
                                "Forse c'è un `fine` di troppo.")
        if t.tipo in (T.ALTRIMENTI, T.ALTRIMENTI_SE):
            return self._errore(f"`{t.tipo.value}` senza un `se` a cui appartenere.", t,
                                "`altrimenti` e `altrimenti se` vanno dentro un blocco `se ... fine`.")
        return self._errore(f"`{t.tipo.value}` senza un `prova` a cui appartenere.", t,
                            "`cattura` e `infine` vanno dentro un blocco `prova ... fine`.")

    def _chiusura_fuori_posto(self, t: Token, blocco: _Blocco) -> ErroreSintassi:
        parola = t.tipo.value
        if blocco.nome == "se" and t.tipo in (T.ALTRIMENTI, T.ALTRIMENTI_SE):
            return self._errore(
                f"Dopo `altrimenti` non può venire `{parola}`: `altrimenti` è l'ultimo ramo del `se`.",
                t, "Metti i rami `altrimenti se` prima di `altrimenti`.")
        if t.tipo is T.NOME and t.valore == "caso":
            if blocco.nome == "scegli":
                return self._errore(
                    "Dopo `altrimenti` non può venire `caso`: `altrimenti` è l'ultimo ramo di `scegli`.",
                    t, "Metti i rami `caso` prima di `altrimenti`.")
            correzioni_caso: list[Correzione] = []
            if self.recupero:
                correzioni_caso.append(self._correzione_fine(blocco, entro_riga=t.riga))
            return self._errore(
                f"`caso` non può stare dentro un blocco `{blocco.nome}`: prima chiudi il blocco "
                f"`{blocco.nome}` aperto alla riga {blocco.token.riga} con `fine`.", t, None, correzioni_caso)
        if blocco.nome == "scegli" and t.tipo is T.ALTRIMENTI_SE:
            return self._errore("Dentro `scegli` non si usa `altrimenti se`: scrivi un altro `caso`.", t,
                                "Per esempio `caso 1..5 allora`.")
        if blocco.nome == "prova" and t.tipo is T.CATTURA:
            return self._errore("`cattura` deve venire prima di `infine`.", t)
        if blocco.nome == "prova" and t.tipo is T.INFINE:
            return self._errore("Un blocco `prova` può avere un solo `infine`.", t)
        if t.tipo is T.ALTRIMENTI:
            proprietari = ("se", "scegli")
        elif t.tipo is T.ALTRIMENTI_SE:
            proprietari = ("se",)
        else:
            proprietari = ("prova",)
        correzioni: list[Correzione] = []
        if self.recupero and any(b.nome in proprietari for b in self._aperti[:-1]):
            correzioni.append(self._correzione_fine(blocco, entro_riga=t.riga))
        return self._errore(
            f"`{parola}` non può stare dentro un blocco `{blocco.nome}`: prima chiudi il blocco "
            f"`{blocco.nome}` aperto alla riga {blocco.token.riga} con `fine`.",
            t, None, correzioni)

    # ------------------------------------------------ correzioni di `fine`

    def _correzione_fine(self, blocco: _Blocco, entro_riga: int | None = None) -> Correzione:
        """Inserisce ``fine`` dove l'indentazione chiude il blocco: prima della
        prima riga successiva con rientro <= a quello della riga di apertura
        (saltando ``altrimenti``/``cattura``... dello stesso blocco), o in fondo."""
        rientro = blocco.rientro
        riga_apertura = blocco.token.riga
        riga_inserimento: int | None = None
        inizi = self._inizi
        if self._inizi_ordinati:
            # si parte dal primo inizio dopo la riga di apertura
            inizi = inizi[bisect_right(self._righe_inizi, riga_apertura):]
        for t in inizi:
            if t.riga <= riga_apertura:
                continue
            if entro_riga is not None and t.riga > entro_riga:
                break
            r = self._rientri[t.riga]
            if r > rientro:
                continue
            if (r == rientro and blocco.nome in ("se", "prova", "scegli")
                    and (t.tipo in (T.ALTRIMENTI, T.ALTRIMENTI_SE, T.CATTURA, T.INFINE)
                         or (t.tipo is T.NOME and t.valore == "caso"))):
                continue
            riga_inserimento = t.riga
            break
        if riga_inserimento is None and entro_riga is not None and entro_riga in self._rientri:
            riga_inserimento = entro_riga
        motivo = f"manca `fine` per il blocco `{blocco.nome}` aperto alla riga {riga_apertura}"
        if riga_inserimento is not None:
            riga_inserimento = self._dopo_ultimo_codice(riga_apertura, riga_inserimento)
            return Correzione(riga_inserimento, 1, "", " " * rientro + "fine\n", motivo)
        # in fondo al file: subito dopo l'ultimo token con testo
        ultimo = None
        for t in reversed(self._t):
            if t.tipo not in (T.FINE_RIGA, T.FINE_FILE) and not _sintetico(t):
                ultimo = t
                break
        riga, colonna = self._dopo(ultimo)
        return Correzione(riga, colonna, "", "\n" + " " * rientro + "fine", motivo)

    def _dopo_ultimo_codice(self, riga_apertura: int, riga_inserimento: int) -> int:
        """Anticipa l'inserimento di ``fine`` saltando le righe vuote (o di soli
        commenti) in coda al blocco: il ``fine`` va subito dopo l'ultima riga con
        codice prima di ``riga_inserimento``."""
        ultima = riga_apertura
        for t in self._t:
            if t.riga >= riga_inserimento or t.tipo in (T.FINE_RIGA, T.FINE_FILE) or _sintetico(t):
                continue
            ultima = max(ultima, t.riga)
        return min(riga_inserimento, ultima + 1)

    def _correzioni_fine_mancante(self, blocco: _Blocco) -> list[Correzione]:
        candidati: list[Correzione] = []
        # 1. una parola isolata che somiglia a `fine` (`fien`, `end`)
        for indice, tok in self._nomi_isolati:
            if indice <= blocco.indice:
                continue
            parola = str(tok.valore)
            suggerite = [p for p, _ in self._parole_suggerite(parola)]
            if "fine" in suggerite or _distanza(parola, "fine") == 1:
                candidati.append(self._sostituisci(
                    tok, "fine", f"`{parola}` sembra `fine` scritto male"))
                break
        # 2. un blocco interno chiuso da un `fine` rientrato meno di lui
        for interno, t_fine in self._chiusi:
            if interno.indice <= blocco.indice:
                continue
            if t_fine.riga not in self._rientri or self._inizio_di(t_fine.riga) is not t_fine:
                continue
            if self._rientri[t_fine.riga] < interno.rientro:
                candidati.append(self._correzione_fine(interno))
                break
        # 3. il blocco stesso
        candidati.append(self._correzione_fine(blocco))
        # niente doppioni
        unici: list[Correzione] = []
        for c in candidati:
            if all((c.riga, c.colonna, c.prima, c.dopo) != (u.riga, u.colonna, u.prima, u.dopo)
                   for u in unici):
                unici.append(c)
        return self._con_alternative(unici)

    def _inizio_di(self, riga: int) -> Token | None:
        if self._inizi_ordinati:
            return self._inizio_per_riga.get(riga)
        for t in self._inizi:
            if t.riga == riga:
                return t
            if t.riga > riga:
                break
        return None

    # --------------------------------------------------------- istruzioni

    def _fine_istruzione(self) -> None:
        t = self._cor
        if t.tipo is T.FINE_RIGA:
            self._avanza()
            return
        if t.tipo is T.FINE_FILE or t.tipo in _CHIUSURE:
            return
        prec = self._precedente()
        if prec is not None and t.riga > prec.riga:
            # a capo dentro parentesi (es. funzione anonima su piu' righe)
            return
        succ = self._guarda()
        if (t.tipo is T.VIRGOLA and prec is not None and prec.tipo is T.INTERO
                and succ.tipo is T.INTERO and prec.riga == t.riga == succ.riga
                and prec.colonna + prec.lunghezza == t.colonna and t.colonna + 1 == succ.colonna):
            # `3,14`: la virgola decimale non esiste in Leo
            scritto = f"{_testo(prec)},{_testo(succ)}"
            correzioni = [Correzione(prec.riga, prec.colonna, scritto, scritto.replace(",", "."),
                                     "i decimali si scrivono con il punto")] if self.recupero else []
            raise self._errore(f"In Leo i numeri decimali si scrivono con il punto: `{scritto.replace(',', '.')}`, "
                               f"non `{scritto}`.", prec,
                               "La virgola separa gli elementi di una lista o gli argomenti.", correzioni,
                               lunghezza=len(scritto))
        raise self._inatteso(
            "la fine dell'istruzione", t,
            "Scrivi ogni istruzione su una riga diversa, oppure separale con `;`.")

    def _istruzione_completa(self) -> Istruzione:
        """Un'istruzione e la sua fine. Se non si analizza e comincia con un NOME,
        chiede a ``suggerimenti`` se e' una parola di altri linguaggi o storpiata."""
        t = self._cor
        if t.tipo is not T.NOME or t.valore in PAROLE_DI_CONTESTO or frase_potenza(self._t, self._i):
            istruzione = self._istruzione()
            self._fine_istruzione()
            return istruzione
        try:
            istruzione = self._istruzione()
            self._fine_istruzione()
            return istruzione
        except ErroreSintassi as errore:
            if not getattr(errore, "_parser_arricchito", False):
                errore._parser_arricchito = True  # type: ignore[attr-defined]
                if errore.riga == t.riga:
                    self._arricchisci(errore, t)
            raise

    def _istruzione(self) -> Istruzione:
        self._livello_blocchi += 1
        try:
            if self._livello_blocchi > LIMITE_ANNIDAMENTO:
                raise self._troppo_annidato("blocco")
            return self._istruzione_semplice()
        finally:
            self._livello_blocchi -= 1

    def _istruzione_semplice(self) -> Istruzione:
        t = self._cor
        tipo = t.tipo
        if tipo in (T.VARIABILE, T.COSTANTE):
            return self._dichiarazione()
        if tipo is T.SE:
            return self._se()
        if tipo is T.MENTRE:
            return self._mentre()
        if tipo is T.PER_OGNI:
            return self._per_ogni()
        if tipo is T.RIPETI:
            return self._ripeti()
        if tipo is T.FUNZIONE and self._guarda().tipo is not T.PARENTESI_APERTA:
            return self._definizione_funzione()
        if tipo is T.PROVA:
            return self._prova()
        if tipo is T.RESTITUISCI:
            return self._restituisci()
        if tipo is T.INTERROMPI:
            if not self._cicli:
                raise self._errore("`interrompi` si può usare solo dentro un ciclo.", t,
                                   "`interrompi` esce da `mentre`, `per ogni` o `ripeti`.")
            self._avanza()
            return Interrompi(riga=t.riga, colonna=t.colonna)
        if tipo is T.CONTINUA:
            if not self._cicli:
                raise self._errore("`continua` si può usare solo dentro un ciclo.", t,
                                   "`continua` passa al giro successivo di `mentre`, `per ogni` o `ripeti`.")
            self._avanza()
            return Continua(riga=t.riga, colonna=t.colonna)
        if tipo is T.LANCIA:
            return self._lancia()
        if tipo is T.QUANDO:
            return self._quando()
        if tipo is T.INIZIO or (tipo is T.NOME and t.valore == "inizio" and self._aperti
                                and e_inizio_da_solo(self._t, self._i)):
            # al livello esterno ci pensa `_analizza`: qui `inizio` e' dentro un blocco
            raise self._inizio_fuori_posto(t)
        if tipo in _TESTE_DI_FRASE or (tipo is T.NOME and t.valore in FRASI_DI_ZUCCHERO):
            frase = self._frase_di_zucchero(t)
            if frase is not None:
                return frase
        if tipo is T.NOME:
            frase = frase_potenza(self._t, self._i)
            if frase is not None:
                return self._costrutto_potenza(frase[0])
        if tipo is T.NOME and t.valore in PAROLE_DI_CONTESTO:
            speciale = self._parola_di_contesto(t)
            if speciale is not None:
                return speciale
        if tipo is T.NOME:
            speciale = self._istruzione_tipi(t)  # struttura, tipo ... è uno di, pubblica
            if speciale is not None:
                return speciale
        return self._istruzione_espressione()

    # ------------------------------------------------ frasi di zucchero

    def _frase_di_zucchero(self, t: Token) -> Istruzione | None:
        """``aumenta X di N``, ``diminuisci X di N``, ``anima O.p a V in D secondi
        [con curva C]``: tradotte in nodi gia' esistenti (``X += N``, ``X -= N``,
        ``anima(O, "p", V, D, C)``). Senza un nome dopo la prima parola la frase
        non c'e' e la parola resta un nome qualsiasi (``aumenta(3)``, ``anima = 1``)."""
        if not segna_frase(self._t, self._i):
            succ = self._guarda()
            if (t.tipo is T.NOME and succ.riga == t.riga
                    and succ.tipo in (T.INTERO, T.DECIMALE, T.TESTO, T.TESTO_INTERPOLATO)):
                parola = str(t.valore)
                esempio = ("anima Pulsante1.sinistra a 300 in 0.5 secondi" if parola == "anima"
                           else f"{parola} punti di {_testo(succ) if succ.tipo in (T.INTERO, T.DECIMALE) else 1}")
                cosa = "l'oggetto e la proprietà da animare" if parola == "anima" else \
                    f"il nome della variabile da {self._infinito(parola)}"
                raise self._errore(f"Dopo `{parola}` scrivi {cosa}.", succ, f"Per esempio `{esempio}`.")
            return None
        if self._cor.tipo is T.ANIMA:
            return self._anima()
        return self._aumenta()

    @staticmethod
    def _infinito(parola: str) -> str:
        return {"aumenta": "aumentare", "diminuisci": "diminuire", "anima": "animare"}.get(parola, parola)

    def _parola_frase(self, tok: Token | None = None) -> str | None:
        """La parola di collegamento (``di``, ``a``, ``in``...) se ``tok`` lo e'."""
        tok = tok or self._cor
        return str(tok.valore) if tok.tipo is T.PAROLA_DI_FRASE else None

    def _fine_frase(self) -> bool:
        """Vero se la frase finisce qui (a capo, `;`, fine file, `fine`/`altrimenti`)."""
        t = self._cor
        if t.tipo in (T.FINE_RIGA, T.FINE_FILE) or t.tipo in _CHIUSURE:
            return True
        prec = self._precedente()
        return prec is not None and t.riga > prec.riga

    def _testo_tra(self, da: int, a: int) -> str:
        """Testo dei token ``self._t[da:a]`` (stessa riga) con gli spazi originali."""
        pezzi: list[str] = []
        fine_prec: tuple[int, int] | None = None
        for tok in self._t[da:a]:
            if tok.tipo in (T.FINE_RIGA, T.FINE_FILE) or _sintetico(tok):
                continue
            if fine_prec is not None:
                if tok.riga == fine_prec[0] and tok.colonna > fine_prec[1]:
                    pezzi.append(" " * (tok.colonna - fine_prec[1]))
                elif tok.riga != fine_prec[0]:
                    pezzi.append(" ")
            pezzi.append(_testo(tok))
            fine_prec = (tok.riga, tok.colonna + _lunghezza(tok))
        return "".join(pezzi)

    def _aumenta(self) -> Assegnazione:
        testa = self._avanza()
        parola = str(testa.valore)
        verbo = self._infinito(parola)
        inizio = self._i
        primo = self._cor
        bersaglio = self._postfisso()
        scritto = self._testo_tra(inizio, self._i)
        if not isinstance(bersaglio, (Nome, Indice, Attributo)):
            raise self._errore(
                f"Con `{parola}` si cambia una variabile, un elemento o una proprietà: "
                f"{_descrivi_bersaglio(bersaglio)} non si può {verbo}.", primo,
                f"Per esempio `{parola} punti di 1`, `{parola} voti[0] di 2`, `{parola} Pulsante1.alto di 10`.",
                lunghezza=max(1, len(scritto)))
        t = self._cor
        if self._parola_frase(t) == "di":
            self._avanza()
            if self._fine_frase():
                raise self._errore(
                    f"Dopo `di` manca di quanto {verbo} `{scritto}`.", t,
                    f"Per esempio `{parola} {scritto} di 1`.",
                    [self._inserisci_dopo(t, " 1", "manca il numero dopo `di`")])
            quanto = self._espressione()
        elif self._fine_frase():
            quanto = Letterale(1, riga=testa.riga, colonna=testa.colonna)
        else:
            raise self._manca_di(parola, scritto, t)
        operatore = "+=" if testa.tipo is T.AUMENTA else "-="
        return Assegnazione(bersaglio, operatore, quanto, riga=testa.riga, colonna=testa.colonna)

    def _manca_di(self, parola: str, scritto: str, t: Token) -> ErroreSintassi:
        esempio = f"`{parola} {scritto} di 5`"
        segno = "+=" if parola == "aumenta" else "-="
        if t.tipo in TIPI_ASSEGNAZIONE:
            return self._errore(
                f"Con `{parola}` non si usa `{_testo(t)}`: manca `di`?", t,
                f"Scrivi {esempio} (oppure `{scritto} {segno} 5`).",
                [self._sostituisci(t, "di", f"con `{parola}` si scrive `di`")])
        if t.tipo is T.NOME and (str(t.valore) in _QUASI_DI or _distanza(str(t.valore), "di") == 1):
            return self._errore(
                f"Manca `di` dopo `{parola} {scritto}`: forse intendevi `di` al posto di `{_testo(t)}`?", t,
                f"Si scrive {esempio}.",
                [self._sostituisci(t, "di", f"con `{parola}` si scrive `di`")])
        if t.tipo in _INIZIO_VALORE_SEMPLICE:
            return self._errore(
                f"Manca `di` tra `{scritto}` e `{_testo(t)}`?", t,
                f"Si scrive {esempio}: `di` dice di quanto {self._infinito(parola)}.",
                [self._inserisci_dopo(self._precedente(), " di", "manca `di`")])
        return self._inatteso(
            f"`di` e un numero (oppure la fine della riga) dopo `{parola} {scritto}`", t,
            f"Si scrive {esempio}; senza `di` si {self._infinito(parola)[:-1]} di 1.")

    def _anima(self) -> IstruzioneEspressione:
        testa = self._avanza()
        inizio = self._i
        primo = self._cor
        bersaglio = self._postfisso()
        scritto = self._testo_tra(inizio, self._i)
        esempio = "anima Pulsante1.sinistra a 300 in 0.5 secondi"
        if not isinstance(bersaglio, Attributo):
            if isinstance(bersaglio, (Nome, Indice)):
                raise self._errore(
                    f"Manca la proprietà da animare dopo `{scritto}`.", primo,
                    f"Scrivi l'oggetto, un punto e la proprietà: `anima {scritto}.sinistra a 300 in 0.5 secondi`.",
                    lunghezza=max(1, len(scritto)))
            raise self._errore(
                f"`anima` vuole un oggetto con la sua proprietà, ma ho trovato {_descrivi_bersaglio(bersaglio)}.",
                primo, f"Per esempio `{esempio}`.", lunghezza=max(1, len(scritto)))
        # --- a VALORE (tolleranza: `fino a`)
        t = self._cor
        if self._parola_frase(t) == "fino":
            succ = self._guarda()
            if self.rigoroso:
                prima = "fino " if succ.riga == t.riga and succ.colonna == t.colonna + 5 else "fino"
                raise self._errore(
                    "In modalità rigorosa si scrive solo `a`, non `fino a`.", t,
                    f"Per esempio `{esempio}`.", [Correzione(t.riga, t.colonna, prima, "", "si scrive solo `a`")])
            self._avanza()
            t = self._cor
        if self._parola_frase(t) == "a":
            t_a = self._avanza()
        else:
            raise self._manca_a(scritto, t)
        if self._fine_frase() or self._parola_frase() is not None:
            raise self._errore(
                f"Dopo `a` manca il valore da raggiungere: per esempio `anima {scritto} a 300`.",
                self._cor if not self._fine_frase() else t_a,
                "Il valore può essere un numero (`300`), un colore (`\"rosso\"`) o una variabile.")
        valore = self._espressione()
        # --- in DURATA secondi
        durata: Espressione = Letterale(DURATA_ANIMA_PREDEFINITA, riga=testa.riga, colonna=testa.colonna)
        c_e_durata = False
        t = self._cor
        if self._parola_frase(t) == "in":
            t_in = self._avanza()
            c_e_durata = True
            if self._fine_frase() or self._parola_frase() in ("con", "curva", "la") \
                    or self._parola_frase() in UNITA_DI_TEMPO:
                raise self._errore(
                    "Dopo `in` manca la durata: per esempio `in 0.5 secondi`.",
                    self._cor if not self._fine_frase() else t_in,
                    "La durata è un numero di secondi (`in 2 secondi`) o di millisecondi (`in 300 millisecondi`).")
            durata = self._espressione()
            if isinstance(durata, Nome) and durata.nome in UNITA_DI_TEMPO and self._parola_frase() is None \
                    and (self._fine_frase() or self._cor.tipo is T.NOME):
                raise self._errore(
                    f"Dopo `in` manca la durata prima di `{durata.nome}`: per esempio `in 0.5 {durata.nome}`.",
                    self._precedente() or t_in,
                    "La durata è un numero di secondi (`in 2 secondi`) o di millisecondi (`in 300 millisecondi`).")
            u = self._cor
            unita = self._parola_frase(u)
            if unita is None and u.tipo is T.NOME and u.valore in UNITA_DI_TEMPO and u.riga == t_in.riga:
                unita = str(u.valore)   # `in 2 secondi poi`: l'unita' c'e', l'errore e' dopo
            if unita in UNITA_DI_TEMPO:
                self._avanza()
                if UNITA_DI_TEMPO[unita] != 1:
                    durata = Binaria("/", durata, Letterale(UNITA_DI_TEMPO[unita], riga=u.riga, colonna=u.colonna),
                                     riga=durata.riga, colonna=durata.colonna)
            elif self._fine_frase() or unita in ("con", "curva"):
                if self.rigoroso:
                    raise self._errore(
                        "Manca l'unità di tempo dopo la durata: `secondi` o `millisecondi`?",
                        self._precedente() or u,
                        "In modalità rigorosa si scrive l'unità: `in 0.5 secondi`, `in 300 millisecondi`.",
                        [self._inserisci_dopo(self._precedente(), " secondi", "manca l'unità di tempo")])
                # tolleranza: senza unita' sono secondi
            elif u.tipo is T.NOME:
                raise self._unita_sconosciuta(u)
        # --- con curva C (tolleranze: `con la curva`, `con "..."`, `curva "..."`)
        curva: Espressione | None = None
        t = self._cor
        p = self._parola_frase(t)
        if p in ("con", "curva"):
            self._curva_nella_forma(t)
            while self._parola_frase() in ("con", "la", "curva"):
                self._avanza()
            if self._fine_frase():
                raise self._errore(
                    "Manca il nome della curva: per esempio `con curva \"rimbalzo\"`.", self._precedente() or t,
                    "Le curve sono \"lineare\", \"morbida\", \"rimbalzo\", \"elastica\", \"veloce\", \"lenta\".")
            c = self._cor
            if c.tipo is T.NOME and str(c.valore) in _CURVE_NOTE and self._guarda().tipo in (T.FINE_RIGA, T.FINE_FILE):
                raise self._errore(
                    f"Il nome della curva va tra virgolette: `\"{c.valore}\"`.", c,
                    f"Scrivi `con curva \"{c.valore}\"`.",
                    [self._sostituisci(c, f'"{c.valore}"', "il nome della curva è un testo")])
            curva = self._espressione()
        if not self._fine_frase():
            raise self._dopo_anima(scritto, self._cor, c_e_durata, curva is not None)
        argomenti = [
            Argomento(bersaglio.oggetto, riga=bersaglio.oggetto.riga, colonna=bersaglio.oggetto.colonna),
            Argomento(Letterale(bersaglio.nome, riga=bersaglio.riga, colonna=bersaglio.colonna),
                      riga=bersaglio.riga, colonna=bersaglio.colonna),
            Argomento(valore, riga=valore.riga, colonna=valore.colonna),
            Argomento(durata, riga=durata.riga, colonna=durata.colonna),
        ]
        if curva is not None:
            argomenti.append(Argomento(curva, riga=curva.riga, colonna=curva.colonna))
        chiamata = Chiamata(Nome("anima", riga=testa.riga, colonna=testa.colonna), argomenti,
                            riga=testa.riga, colonna=testa.colonna)
        return IstruzioneEspressione(chiamata, riga=testa.riga, colonna=testa.colonna)

    def _manca_a(self, scritto: str, t: Token) -> ErroreSintassi:
        esempio = f"`anima {scritto} a 300 in 0.5 secondi`"
        if t.tipo in TIPI_ASSEGNAZIONE:
            return self._errore(
                f"Con `anima` non si usa `{_testo(t)}`: manca `a`?", t, f"Si scrive {esempio}.",
                [self._sostituisci(t, "a", "con `anima` si scrive `a`")])
        if t.tipo is T.NOME and str(t.valore) in _QUASI_A:
            return self._errore(
                f"Manca `a` dopo `anima {scritto}`: forse intendevi `a` al posto di `{_testo(t)}`?", t,
                f"Si scrive {esempio}.", [self._sostituisci(t, "a", "con `anima` si scrive `a`")])
        if t.tipo in _INIZIO_VALORE_SEMPLICE:
            return self._errore(
                f"Manca `a` tra `{scritto}` e `{_testo(t)}`?", t,
                f"Si scrive {esempio}: dopo `a` va il valore da raggiungere.",
                [self._inserisci_dopo(self._precedente(), " a", "manca `a`")])
        if self._fine_frase():
            prec = self._precedente()
            return self._errore(
                f"Manca il valore da raggiungere: `anima {scritto} a ...`.", prec or t,
                f"Si scrive {esempio}.")
        return self._inatteso(f"`a` e il valore da raggiungere dopo `anima {scritto}`", t, f"Si scrive {esempio}.")

    def _unita_sconosciuta(self, u: Token) -> ErroreSintassi:
        parola = str(u.valore)
        if parola in ("minuti", "minuto", "min"):
            return self._errore(
                f"Le durate di `anima` si scrivono in secondi, non in `{parola}`.", u,
                "Per esempio `in 90 secondi` (un minuto e mezzo).")
        proposta = _QUASI_UNITA.get(parola)
        if proposta is None:
            vicine = [x for x in ("secondi", "secondo", "millisecondi") if _distanza(parola, x) <= 2]
            proposta = vicine[0] if vicine else None
        if proposta is not None:
            return self._errore(
                f"Non conosco l'unità di tempo `{parola}`: forse intendevi `{proposta}`?", u,
                "Le unità ammesse sono `secondi` (o `s`) e `millisecondi` (o `ms`).",
                [self._sostituisci(u, proposta, f"`{parola}` non è un'unità di Leo")])
        return self._errore(
            f"Non conosco l'unità di tempo `{parola}`.", u,
            "Scrivi `secondi` (o `s`) oppure `millisecondi` (o `ms`): `in 0.5 secondi`.")

    def _curva_nella_forma(self, t: Token) -> None:
        """In modalita' rigorosa la curva si scrive solo `con curva \"...\"`."""
        if not self.rigoroso:
            return
        succ = self._guarda()
        if self._parola_frase(t) == "curva":
            raise self._errore(
                "Manca `con` prima di `curva`.", t, "In modalità rigorosa si scrive `con curva \"rimbalzo\"`.",
                [Correzione(t.riga, t.colonna, "", "con ", "manca `con`")])
        if self._parola_frase(succ) == "la":
            prima = "la " if self._guarda(2).colonna == succ.colonna + 3 else "la"
            raise self._errore(
                "In modalità rigorosa si scrive `con curva`, senza `la`.", succ,
                "Per esempio `con curva \"rimbalzo\"`.",
                [Correzione(succ.riga, succ.colonna, prima, "", "si scrive `con curva`")])
        if self._parola_frase(succ) != "curva":
            raise self._errore(
                "Manca `curva` dopo `con`.", succ, "In modalità rigorosa si scrive `con curva \"rimbalzo\"`.",
                [self._inserisci_dopo(t, " curva", "manca `curva`")])

    def _dopo_anima(self, scritto: str, t: Token, c_e_durata: bool, c_e_curva: bool) -> ErroreSintassi:
        parola = str(t.valore) if t.tipo is T.NOME else None
        if not c_e_durata and not c_e_curva:
            if parola in _QUASI_IN:
                return self._errore(
                    f"La durata si scrive dopo `in`: forse intendevi `in` al posto di `{_testo(t)}`?", t,
                    f"Per esempio `anima {scritto} a 300 in 0.5 secondi`.",
                    [self._sostituisci(t, "in", "la durata si scrive dopo `in`")])
            if t.tipo in (T.INTERO, T.DECIMALE):
                return self._errore(
                    f"Manca `in` prima della durata `{_testo(t)}`?", t,
                    f"Per esempio `anima {scritto} a 300 in {_testo(t)} secondi`.",
                    [Correzione(t.riga, t.colonna, "", "in ", "manca `in`")])
        return self._inatteso(
            "`in ... secondi`, `con curva \"...\"` o la fine della riga", t,
            f"La frase completa è `anima {scritto} a 300 in 0.5 secondi con curva \"rimbalzo\"`.")

    def _parola_di_contesto(self, t: Token) -> Istruzione | None:
        """``scegli``, ``caso``, ``importa``, ``verifica`` sono parole chiave solo
        all'inizio di un'istruzione e nella forma giusta: altrimenti sono nomi."""
        succ = self._guarda()
        if succ.riga != t.riga or succ.tipo in (T.FINE_RIGA, T.FINE_FILE):
            if t.valore == "importa":
                raise self._errore(
                    "Dopo `importa` scrivi il file o il modulo da importare.", t,
                    "Per esempio `importa \"geometria.leo\"` (un file nella stessa cartella) "
                    "oppure `importa matematica come m`.")
            if t.valore == "verifica":
                raise self._errore(
                    "Dopo `verifica` scrivi la condizione da controllare.", t,
                    "Per esempio `verifica x > 0, \"x deve essere positivo\"`; per un test con nome "
                    "scrivi `verifica \"nome del test\" fai ... fine`.")
            return None
        parola = t.valore
        if parola == "scegli" and succ.tipo in _INIZIO_VALORE_DI_CONTESTO:
            return self._scegli()
        if parola == "importa" and succ.tipo in (T.TESTO, T.NOME):
            return self._importa()
        if parola == "verifica" and succ.tipo in _INIZIO_VALORE_DI_CONTESTO:
            return self._verifica()
        if parola == "caso" and self._e_caso():
            aperti = [b for b in self._aperti if b.nome == "scegli"]
            if not aperti:
                straniera = self._scegli_di_altro_linguaggio()
                if straniera is not None:
                    raise straniera
                raise self._errore("`caso` si usa solo dentro `scegli`.", t,
                                   "Scrivi prima `scegli valore`, poi i rami `caso ... allora`.")
            raise self._chiusura_fuori_posto(t, self._aperti[-1])
        return None

    def _scegli_di_altro_linguaggio(self) -> ErroreSintassi | None:
        """Un ``caso`` fuori da ``scegli`` dopo ``switch (voto)`` o ``seleziona(voto)``
        (che si analizzano come chiamate): errore sulla parola da cambiare."""
        j = self._i - 1
        limite = max(0, self._i - 2000)
        while j >= limite:
            t = self._t[j]
            if t.tipo is T.NOME and PAROLE_PER_CONTESTO.get(str(t.valore).lower()) == "scegli" \
                    and (j == 0 or self._t[j - 1].tipo is T.FINE_RIGA):
                succ = self._t[j + 1]
                correzioni = []
                if self.recupero and succ.riga == t.riga and succ.tipo in _INIZIO_VALORE_DI_CONTESTO:
                    correzioni = [self._sostituisci(
                        t, "scegli", f"`{_testo(t)}` non è una parola di Leo: si scrive `scegli`")]
                return self._errore(f"Non conosco la parola `{_testo(t)}`.", t,
                                    _FRASE_CONTESTO["scegli"], correzioni)
            if t.tipo is T.NOME and t.valore == "scegli":
                return None
            j -= 1
        return None

    def _e_caso(self, liberale: bool = False) -> bool:
        """Il token corrente (NOME ``caso``) comincia un ramo ``caso ... allora``?

        Di norma serve ``allora`` sulla stessa riga; direttamente dentro
        ``scegli`` (``liberale``) basta che dopo ci sia un valore."""
        t = self._cor
        if t.tipo is not T.NOME or t.valore != "caso":
            return False
        succ = self._guarda()
        if succ.riga != t.riga or succ.tipo in (T.FINE_RIGA, T.FINE_FILE) or succ.tipo in TIPI_ASSEGNAZIONE:
            return False
        if liberale and succ.tipo in _INIZIO_ESPRESSIONE \
                and succ.tipo not in (T.PARENTESI_APERTA, T.QUADRA_APERTA):
            return True
        j = self._i + 1
        while j < len(self._t) and self._t[j].tipo not in (T.FINE_RIGA, T.FINE_FILE):
            if self._t[j].tipo is T.ALLORA:
                return True
            j += 1
        return False

    def _istruzione_espressione(self) -> Istruzione:
        primo = self._cor
        indice = self._i
        espr = self._espressione()
        if self._cor.tipo is T.VIRGOLA and isinstance(espr, (Nome, Indice, Attributo)):
            return self._assegnazione_multipla(espr, primo)
        if self._cor.tipo in TIPI_ASSEGNAZIONE:
            op = self._avanza()
            if not isinstance(espr, (Nome, Indice, Attributo)):
                raise self._errore(
                    f"Non si può assegnare a {_descrivi_bersaglio(espr)}.", primo,
                    "Si assegna solo a una variabile (`x = 1`), a un elemento (`lista[0] = 1`) "
                    "o a una proprietà (`Etichetta1.testo = \"Ciao\"`).")
            valore = self._espressione()
            return Assegnazione(espr, op.tipo.value, valore, riga=primo.riga, colonna=primo.colonna)
        if isinstance(espr, Attributo) and isinstance(espr.oggetto, Nome) and espr.oggetto.nome[:1].isupper() \
                and self._argomento_senza_parentesi():
            # solo per gli oggetti delle finestre (`lista.aggiungi 5` resta un errore: le liste vogliono le parentesi)
            # `Palla.salta 10`, `Dado1.lancia`, `Eroe.spingi 300, -200`: metodo senza parentesi
            argomenti = [Argomento(v, riga=v.riga, colonna=v.colonna) for v in self._elenco_senza_parentesi()]
            chiamata = Chiamata(espr, argomenti, riga=primo.riga, colonna=primo.colonna)
            return IstruzioneEspressione(chiamata, riga=primo.riga, colonna=primo.colonna)
        if isinstance(espr, Nome):
            self._nomi_isolati.append((indice, primo))
            self._parola_chiave_storpiata(espr, primo)
        return IstruzioneEspressione(espr, riga=primo.riga, colonna=primo.colonna)

    def _argomento_senza_parentesi(self) -> bool:
        """Dopo ``Oggetto.metodo`` c'e' un valore sulla stessa riga (``Palla.salta 10``)?"""
        t = self._cor
        prec = self._precedente()
        if prec is None or t.riga != prec.riga:
            return False
        if t.tipo in (T.INTERO, T.DECIMALE, T.TESTO, T.VERO, T.FALSO, T.NOME):
            return True
        return t.tipo is T.MENO and self._guarda().tipo in (T.INTERO, T.DECIMALE, T.NOME)

    def _elenco_senza_parentesi(self) -> list[Espressione]:
        valori = [self._espressione()]
        while self._cor.tipo is T.VIRGOLA:
            self._avanza()
            valori.append(self._espressione())
        return valori

    def _parola_chiave_storpiata(self, espr: Nome, tok: Token) -> None:
        """Un nome da solo sulla riga che somiglia a una parola chiave che sta
        da sola (``altrimeti``, ``fien``, ``else``, ``break``) e' quasi sempre
        un refuso: un'istruzione fatta di un solo nome non fa niente, e senza
        questo controllo ``altrimeti`` farebbe finire il ramo `altrimenti`
        dentro il ramo `se` senza nessun errore."""
        if self._cor.tipo not in (T.FINE_RIGA, T.FINE_FILE) or tok.tipo is not T.NOME:
            return
        if self._inizio_di(tok.riga) is not tok or self._cor.riga != tok.riga and self._cor.tipo is not T.FINE_FILE:
            return
        parola = str(espr.nome)
        accento = self._accento_sbagliato(parola)
        if accento is not None:
            # `senno` dentro un blocco: e' `sennò` senza accento (il ramo
            # `altrimenti` finirebbe in silenzio dentro il ramo `se`). Se
            # `senno` e' anche una variabile del programma resta un nome.
            if self._aperti and not self._usato_come_nome(parola, tok):
                raise self._errore_accento(tok, *accento)
            return
        # solo le parole che avrebbero senso qui (un `fin` al livello esterno,
        # per esempio nel REPL, e' il nome di una variabile da mostrare)
        aperti = {b.nome for b in self._aperti}
        plausibili = set()
        if aperti:
            plausibili.add("fine")
        if "se" in aperti:
            plausibili.add("altrimenti")
        if "prova" in aperti:
            plausibili.update(("cattura", "infine"))
        if self._cicli:
            plausibili.update(("interrompi", "continua"))
        if not plausibili:
            return
        proposte = [(p, frase) for p, frase in self._parole_suggerite(parola) if p in plausibili]
        if not proposte and len(parola) >= 3:
            proposte = [(p, f"Forse intendevi `{p}`?") for p in sorted(plausibili)
                        if _distanza(parola.lower(), p) == 1]
        if not proposte:
            return
        correzioni = self._con_alternative([
            self._sostituisci(tok, p, f"`{parola}` non è una parola di Leo: si scrive `{p}`")
            for p, _ in proposte])
        raise self._errore(f"Non conosco la parola `{parola}`.", tok, proposte[0][1], correzioni)

    def _usato_come_nome(self, parola: str, tok: Token) -> bool:
        """Vero se ``parola`` compare altrove nel programma come nome vero e
        proprio (``variabile senno = 3``, ``stampa(senno)``, un parametro...),
        cioe' non solo da sola su una riga."""
        for j, t in enumerate(self._t):
            if t is tok or t.tipo is not T.NOME or t.valore != parola:
                continue
            prima = self._t[j - 1] if j else None
            dopo = self._t[j + 1] if j + 1 < len(self._t) else None
            da_sola = ((prima is None or prima.tipo is T.FINE_RIGA)
                       and (dopo is None or dopo.tipo in (T.FINE_RIGA, T.FINE_FILE)))
            if not da_sola:
                return True
        return False

    def _dichiarazione(self) -> Dichiarazione:
        kw = self._avanza()
        costante = kw.tipo is T.COSTANTE
        parola = "costante" if costante else "variabile"
        t = self._cor
        if t.tipo is not T.NOME:
            raise self._riservata(t, f"il nome della {parola} dopo `{_testo(kw)}`")
        nome_tok = self._avanza()
        nome = str(nome_tok.valore)
        if self._cor.tipo is T.VIRGOLA:
            return self._dichiarazione_multipla(kw, costante, parola, nome_tok)
        esempio = f"Scrivi per esempio `{parola} {nome} = 0`."
        tipo_dichiarato = None
        if self._cor.tipo is T.DUE_PUNTI and self._cor.riga == nome_tok.riga:
            # `variabile x: intero = 0`, `variabile email: testo?` (vale nulla)
            self._avanza()
            tipo_dichiarato = self._tipo_scritto(f"il tipo di `{nome}` dopo `:`")
            esempio = f"Scrivi per esempio `{parola} {nome}: {tipo_dichiarato} = ...`."
            if self._cor.tipo in (T.FINE_RIGA, T.FINE_FILE) or self._cor.tipo in _CHIUSURE:
                if tipo_dichiarato.endswith("?") and not costante:
                    return Dichiarazione(nome, Letterale(None, riga=nome_tok.riga, colonna=nome_tok.colonna),
                                         costante, tipo=tipo_dichiarato, riga=kw.riga, colonna=kw.colonna)
        t = self._cor
        if t.tipo is T.ASSEGNA:
            self._avanza()
        elif t.tipo in (T.FINE_RIGA, T.FINE_FILE) or t.tipo in _CHIUSURE:
            raise self._errore(f"Manca il valore iniziale di `{nome}`.", nome_tok, esempio)
        elif t.tipo is T.UGUALE_UGUALE:
            raise self._errore(
                f"Per dare un valore a `{nome}` usa `=`, non `==`.", t, None,
                [self._sostituisci(t, "=", "per dare un valore si usa `=`")])
        elif t.tipo in TIPI_ASSEGNAZIONE:
            raise self._errore(
                f"Una {parola} nuova si dichiara con `=`, non con `{t.tipo.value}`.", t, esempio)
        else:
            raise self._inatteso(f"`=` dopo `{parola} {nome}`", t, esempio)
        if self._cor.tipo in (T.FINE_RIGA, T.FINE_FILE) or self._cor.tipo in _CHIUSURE:
            raise self._errore(f"Manca il valore iniziale di `{nome}` dopo `=`.", self._cor, esempio)
        valore = self._espressione()
        return Dichiarazione(nome, valore, costante, tipo=tipo_dichiarato, riga=kw.riga, colonna=kw.colonna)

    def _attendi_parola(self, tipo: TipoToken, dopo_cosa: str) -> Token:
        """Consuma la parola chiave ``tipo`` (``allora``, ``fai``, ``volte``, ``in``)
        o solleva "Manca `allora` dopo ..." con la correzione."""
        t = self._cor
        if t.tipo is tipo:
            return self._avanza()
        if tipo in (T.ALLORA, T.FAI) and (t.tipo is T.FINE_FILE or (t.tipo is T.FINE_RIGA and t.valore == "\n")):
            # `allora` e `fai` sono facoltativi a fine riga: `se x > 3` e `mentre x < 10` vanno a capo da soli
            return t
        # Tolleranza per chi impara: `allora` e `fai` significano entrambi
        # "e adesso fai questo", quindi si accettano l'uno al posto dell'altro.
        parola = tipo.value
        messaggio = f"Manca `{parola}` dopo {dopo_cosa}."
        if {tipo, t.tipo} == {T.ALLORA, T.FAI}:
            if not self.rigoroso:
                return self._avanza()
            raise self._errore(
                messaggio, t, f"In modalità rigorosa dopo {dopo_cosa} si scrive `{parola}`, non `{_testo(t)}`.",
                [self._sostituisci(t, parola, f"qui ci va `{parola}`")])
        if t.tipo is T.NOME:
            scritto = str(t.valore)
            suggerite = [p for p, _ in self._parole_suggerite(scritto)]
            if parola in suggerite or _distanza(scritto, parola) == 1:
                raise self._errore(
                    messaggio, t, f"Forse intendevi `{parola}` al posto di `{_testo(t)}`?",
                    [self._sostituisci(t, parola, f"`{_testo(t)}` sembra `{parola}` scritto male")])
        if tipo is T.IN and t.tipo is T.NOME and t.valore in ("di", "da"):
            raise self._in_sbagliato(t, dopo_cosa)
        prec = self._precedente()
        correzione = self._inserisci_dopo(prec, " " + parola, f"manca `{parola}`")
        if t.tipo in (T.FINE_RIGA, T.FINE_FILE) or prec is None:
            suggerimento = f"Scrivi `{parola}` alla fine della riga."
        else:
            suggerimento = f"Scrivi `{parola}` dopo `{_testo(prec)}`."
        raise self._errore(messaggio, t, suggerimento, [correzione])

    def _in_sbagliato(self, t: Token, dopo_cosa: str) -> ErroreSintassi:
        """``per ogni i di lista`` / ``per ogni i da 1 a 3``: al posto di ``in``."""
        messaggio = f"Dopo {dopo_cosa} ci va `in`, non `{t.valore}`."
        if t.valore == "da":
            # si cerca `a` sulla stessa riga, fuori dalle parentesi: `da X a Y` -> `in X..Y`
            livello = 0
            k = self._i + 1
            indice_a = None
            fine = None
            while k < len(self._t):
                x = self._t[k]
                if x.tipo in (T.FINE_RIGA, T.FINE_FILE) or x.riga != t.riga:
                    break
                if livello == 0 and x.tipo in (T.FAI, T.ALLORA, T.SE):
                    break
                if x.tipo in (T.PARENTESI_APERTA, T.QUADRA_APERTA, T.GRAFFA_APERTA):
                    livello += 1
                elif x.tipo in (T.PARENTESI_CHIUSA, T.QUADRA_CHIUSA, T.GRAFFA_CHIUSA):
                    if livello == 0:
                        break
                    livello -= 1
                elif livello == 0 and x.tipo is T.NOME and x.valore == "a" and indice_a is None:
                    indice_a = k
                fine = k
                k += 1
            if (indice_a is not None and self._i + 1 < indice_a < (fine or 0)
                    and all(_testo(x) for x in self._t[self._i:fine + 1])):
                da_x = self._spezzone(self._i + 1, indice_a)
                a_y = self._spezzone(indice_a + 1, fine + 1)
                prima = self._spezzone(self._i, fine + 1)
                nuovo = f"in {da_x}..{a_y}"
                return self._errore(
                    messaggio, t,
                    f"Per contare da {da_x} a {a_y} si scrive un intervallo con `..`: `{nuovo}`.",
                    [Correzione(t.riga, t.colonna, prima, nuovo, "per un intervallo si scrive `in a..b`")])
            return self._errore(messaggio, t, "Per contare si scrive un intervallo con `..`, per esempio "
                                "`per ogni i in 1..10 fai`.", [self._sostituisci(t, "in", "si scrive `in`")])
        return self._errore(messaggio, t, "Per esempio `per ogni x in lista fai`.",
                            [self._sostituisci(t, "in", "si scrive `in`")])

    def _spezzone(self, inizio: int, fine: int) -> str:
        """Testo dei token ``[inizio, fine)`` di una stessa riga, con gli spazi
        originali ricostruiti dalle colonne."""
        pezzi = []
        ultimo = None
        for x in self._t[inizio:fine]:
            if ultimo is not None:
                pezzi.append(" " * max(0, x.colonna - (ultimo.colonna + _lunghezza(ultimo))))
            pezzi.append(_testo(x))
            ultimo = x
        return "".join(pezzi)

    def _condizione(self, costrutto: str, tipo_parola: TipoToken) -> Espressione:
        # nella condizione `se x = 5` vale come `se x == 5` (anche `==` va bene)
        self._in_condizione += 1
        try:
            condizione = self._espressione()
        finally:
            self._in_condizione -= 1
        t = self._cor
        if t.tipo is T.ASSEGNA:
            raise self._errore(
                "Per confrontare usa `==`.", t,
                "`=` dà un valore a una variabile; `==` controlla se due valori sono uguali.",
                [self._sostituisci(t, "==", "per confrontare si usa `==`")])
        self._attendi_parola(tipo_parola, f"la condizione di `{costrutto}`")
        return condizione

    def _se(self) -> Se:
        t_se = self._avanza()
        blocco = self._apri("se", t_se)
        terminatori = frozenset({T.ALTRIMENTI_SE, T.ALTRIMENTI, T.FINE})
        condizione = self._condizione("se", T.ALLORA)
        corpo = self._blocco(blocco, terminatori)
        rami = [RamoSe(condizione, corpo, riga=t_se.riga, colonna=t_se.colonna)]
        altrimenti = None
        while self._cor.tipo is T.ALTRIMENTI_SE:
            t = self._avanza()
            condizione = self._condizione("altrimenti se", T.ALLORA)
            corpo = self._blocco(blocco, terminatori)
            rami.append(RamoSe(condizione, corpo, riga=t.riga, colonna=t.colonna))
        if self._cor.tipo is T.ALTRIMENTI:
            self._avanza()
            altrimenti = self._blocco(blocco, frozenset({T.FINE}))
        self._chiudi(blocco)
        return Se(rami, altrimenti, riga=t_se.riga, colonna=t_se.colonna)

    def _corpo_ciclo(self, blocco: _Blocco) -> list[Istruzione]:
        self._cicli += 1
        try:
            return self._blocco(blocco, frozenset({T.FINE}))
        finally:
            self._cicli -= 1

    def _corpo_funzione(self, blocco: _Blocco) -> list[Istruzione]:
        cicli = self._cicli
        self._cicli = 0
        self._funzioni += 1
        try:
            return self._blocco(blocco, frozenset({T.FINE}))
        finally:
            self._cicli = cicli
            self._funzioni -= 1

    def _mentre(self) -> Mentre:
        t = self._avanza()
        blocco = self._apri("mentre", t)
        condizione = self._condizione("mentre", T.FAI)
        corpo = self._corpo_ciclo(blocco)
        self._chiudi(blocco)
        return Mentre(condizione, corpo, riga=t.riga, colonna=t.colonna)

    def _per_ogni(self) -> PerOgni:
        t = self._avanza()
        blocco = self._apri("per ogni", t)
        if self._cor.tipo is not T.NOME:
            errore = self._riservata(self._cor, "il nome della variabile dopo `per ogni`")
            errore.suggerimento = errore.suggerimento or "Per esempio `per ogni x in lista fai`."
            raise errore
        variabili = self._nomi_ciclo("per ogni")
        variabile = variabili[0]
        self._attendi_parola(T.IN, f"`per ogni {', '.join(variabili)}`")
        iterabile = self._espressione()
        self._attendi_parola(T.FAI, "la sequenza di `per ogni`")
        corpo = self._corpo_ciclo(blocco)
        self._chiudi(blocco)
        return PerOgni(variabile, iterabile, corpo, variabili if len(variabili) > 1 else None,
                       riga=t.riga, colonna=t.colonna)

    def _nomi_ciclo(self, costrutto: str) -> list[str]:
        """``x`` oppure ``chiave, valore`` dopo ``per ogni`` (nomi tutti diversi)."""
        nomi = [str(self._avanza().valore)]
        while self._cor.tipo is T.VIRGOLA:
            self._avanza()
            n = self._cor
            if n.tipo is not T.NOME:
                raise self._riservata(n, f"un altro nome dopo la virgola in `{costrutto}`")
            if n.valore in nomi:
                raise self._errore(f"Il nome `{n.valore}` compare due volte in `{costrutto}`.", n,
                                   "Usa nomi diversi, per esempio `per ogni chiave, valore in d`.")
            nomi.append(str(self._avanza().valore))
        return nomi

    def _ripeti(self) -> Ripeti:
        t = self._avanza()
        blocco = self._apri("ripeti", t)
        if self._cor.tipo in (T.FINE_RIGA, T.FINE_FILE):
            raise self._errore("Dopo `ripeti` serve il numero di volte, per esempio `ripeti 3 volte` "
                               "(oppure `ripeti per sempre`).", self._cor)
        c, d = self._cor, self._guarda()
        if c.tipo is T.NOME and c.valore == "per" and d.tipo is T.NOME and d.valore == "sempre" \
                and d.riga == c.riga:
            # `ripeti per sempre`: un ciclo senza fine (si esce con `interrompi`)
            self._avanza()
            self._avanza()
            if self._cor.tipo in (T.FAI, T.ALLORA):
                self._avanza()
            corpo = self._corpo_ciclo(blocco)
            self._chiudi(blocco)
            vero = Letterale(True, riga=c.riga, colonna=c.colonna)
            ciclo = Mentre(vero, corpo, riga=t.riga, colonna=t.colonna)
            ciclo.per_sempre = True  # type: ignore[attr-defined]  (per `leo spiega`)
            return ciclo
        volte = self._espressione()
        self._attendi_parola(T.VOLTE, "il numero di `ripeti`")
        if self._cor.tipo in (T.FAI, T.ALLORA):
            # `ripeti 3 volte fai`: la parola in piu' e' innocua (tolleranza)
            if not self.rigoroso:
                self._avanza()
            else:
                t_extra = self._cor
                raise self._errore(
                    f"Dopo `volte` non serve `{_testo(t_extra)}`.", t_extra,
                    "Il blocco di `ripeti` comincia sulla riga dopo: `ripeti 3 volte`.",
                    [self._sostituisci(t_extra, "", f"`{_testo(t_extra)}` in più")])
        corpo = self._corpo_ciclo(blocco)
        self._chiudi(blocco)
        return Ripeti(volte, corpo, riga=t.riga, colonna=t.colonna)

    def _parametri(self) -> list[Parametro]:
        t = self._cor
        if t.tipo is not T.PARENTESI_APERTA:
            raise self._inatteso("`(` con i parametri della funzione", t,
                                 "Anche senza parametri servono le parentesi: `funzione saluta()`.")
        apre = self._avanza()
        parametri: list[Parametro] = []
        if self._cor.tipo is T.PARENTESI_CHIUSA:
            self._avanza()
            return parametri
        visti: set[str] = set()
        con_predefinito: str | None = None
        while True:
            p = self._cor
            if p.tipo is not T.NOME:
                raise self._riservata(p, "il nome di un parametro")
            self._avanza()
            nome = str(p.valore)
            if nome in visti:
                raise self._errore(f"Il parametro `{nome}` compare due volte.", p,
                                   "Ogni parametro deve avere un nome diverso.")
            visti.add(nome)
            tipo = None
            if self._cor.tipo is T.DUE_PUNTI:
                self._avanza()
                tipo = self._tipo_scritto(f"il tipo del parametro `{nome}` dopo `:`")
            if self._cor.tipo is T.TRE_PUNTI:
                self._avanza()
                if self._cor.tipo is not T.PARENTESI_CHIUSA:
                    raise self._errore(
                        f"Il parametro `{nome}...` raccoglie tutti gli argomenti in più: deve essere l'ultimo.",
                        self._cor, "Per esempio `funzione somma(numeri...)`.")
                self._avanza()
                parametri.append(Parametro(nome, None, tipo, True, riga=p.riga, colonna=p.colonna))
                return parametri
            predefinito = None
            if self._cor.tipo is T.ASSEGNA:
                self._avanza()
                predefinito = self._espressione()
                con_predefinito = nome
            elif con_predefinito is not None:
                raise self._errore(
                    f"Il parametro `{nome}` non ha un valore predefinito ma viene dopo "
                    f"`{con_predefinito}`, che ce l'ha: i parametri con valore predefinito vanno in fondo.",
                    p)
            parametri.append(Parametro(nome, predefinito, tipo, riga=p.riga, colonna=p.colonna))
            if self._cor.tipo is T.VIRGOLA:
                self._avanza()
                continue
            if self._cor.tipo is T.PARENTESI_CHIUSA:
                self._avanza()
                return parametri
            raise self._separatore_mancante(apre, "tra i parametri")

    def _definizione_funzione(self) -> DefinizioneFunzione:
        t = self._avanza()
        nome_tok = self._cor
        if nome_tok.tipo is not T.NOME:
            errore = self._riservata(nome_tok, "il nome della funzione dopo `funzione`")
            if nome_tok.tipo not in TIPI_PAROLA_CHIAVE:
                errore.suggerimento = "Per esempio `funzione saluta(nome)`."
            raise errore
        self._avanza()
        nome = self._nome_metodo(str(nome_tok.valore))       # `funzione Alunno.media()`
        parametri = self._parametri()
        tipo_risultato = self._tipo_risultato(t)              # `dà decimale`
        blocco = self._apri("funzione", t)
        richiede, garantisce, puo_dare = self._contratti()    # in cima al corpo
        corpo = self._corpo_funzione(blocco)
        self._chiudi(blocco)
        return DefinizioneFunzione(nome, parametri, corpo, tipo_risultato=tipo_risultato, richiede=richiede,
                                   garantisce=garantisce, puo_dare=puo_dare, riga=t.riga, colonna=t.colonna)

    def _funzione_anonima(self) -> FunzioneAnonima:
        t = self._avanza()
        parametri = self._parametri()
        blocco = self._apri("funzione", t)
        corpo = self._corpo_funzione(blocco)
        self._chiudi(blocco)
        return FunzioneAnonima(parametri, corpo, riga=t.riga, colonna=t.colonna)

    def _prova(self) -> Prova:
        t = self._avanza()
        blocco = self._apri("prova", t)
        terminatori = frozenset({T.CATTURA, T.INFINE, T.FINE})
        corpo = self._blocco(blocco, terminatori)
        catture: list[Cattura] = []
        while self._cor.tipo is T.CATTURA:
            tc = self._avanza()
            tipo_errore = None
            nome_variabile = None
            c = self._cor
            if c.tipo is T.NOME and (
                    c.valore in TIPI_ERRORE
                    or self._guarda().tipo in (T.FINE_RIGA, T.FINE_FILE, T.COME)
                    or self._guarda().tipo in _CHIUSURE):
                tipo_errore = str(self._avanza().valore)
            if self._cor.tipo is T.COME:
                self._avanza()
                v = self._cor
                if v.tipo is T.E:
                    # `cattura ErroreValore come e` (esempio di PROGETTO.md): `e` qui e' un nome
                    self._avanza()
                    nome_variabile = "e"
                elif v.tipo is not T.NOME:
                    errore = self._riservata(v, "il nome da dare all'errore dopo `come`")
                    if v.tipo not in TIPI_PAROLA_CHIAVE:
                        errore.suggerimento = "Per esempio `cattura ErroreValore come e`."
                    raise errore
                else:
                    nome_variabile = str(self._avanza().valore)
            corpo_cattura = self._blocco(blocco, terminatori)
            catture.append(Cattura(tipo_errore, nome_variabile, corpo_cattura,
                                   riga=tc.riga, colonna=tc.colonna))
        infine = None
        if self._cor.tipo is T.INFINE:
            self._avanza()
            infine = self._blocco(blocco, frozenset({T.FINE}))
        self._chiudi(blocco)
        return Prova(corpo, catture, infine, riga=t.riga, colonna=t.colonna)

    def _restituisci(self) -> Restituisci:
        t = self._cor
        if not self._funzioni:
            raise self._errore("`restituisci` si può usare solo dentro una funzione.", t,
                               "`restituisci` dà il risultato di una `funzione` (o di un `quando`).")
        self._avanza()
        c = self._cor
        valore = None
        if c.tipo not in (T.FINE_RIGA, T.FINE_FILE) and c.tipo not in _CHIUSURE:
            valore = self._espressione()
        return Restituisci(valore, riga=t.riga, colonna=t.colonna)

    def _lancia(self) -> Lancia:
        t = self._avanza()
        c = self._cor
        if c.tipo in (T.FINE_RIGA, T.FINE_FILE) or c.tipo in _CHIUSURE:
            raise self._errore(
                "Dopo `lancia` serve l'errore da sollevare.", c,
                "Per esempio `lancia ErroreValore(\"Il voto deve essere tra 0 e 30\")`.")
        valore = self._espressione()
        return Lancia(valore, riga=t.riga, colonna=t.colonna)

    def _quando(self) -> Evento:
        t = self._cor
        aperti = [b for b in self._aperti if b.nome != "inizio"]   # dentro `inizio` si puo'
        if aperti:
            interno = aperti[-1]
            correzioni = []
            if self.recupero and t.riga in self._rientri:
                correzioni.append(self._correzione_fine(interno, entro_riga=t.riga))
            raise self._errore(
                "`quando` si può usare solo al livello più esterno del programma, fuori da ogni blocco.",
                t, f"Forse manca `fine` per il blocco `{interno.nome}` aperto alla riga "
                   f"{interno.token.riga}.", correzioni)
        self._avanza()
        esempio = "Per esempio `quando Pulsante1.clic fai`."
        c = self._cor
        if c.tipo is not T.NOME:
            raise self._inatteso("il nome di un controllo dopo `quando`", c, esempio)
        controllo = str(self._avanza().valore)
        if self._cor.tipo is not T.PUNTO:
            raise self._inatteso(f"`.` e il nome dell'evento dopo `quando {controllo}`", self._cor, esempio)
        self._avanza()
        ev = self._cor
        evento = str(ev.valore)
        if ev.tipo is not T.NOME and not _parola_come_nome(ev):
            # `quando Eroe.salta fai`: un sinonimo di parola chiave dopo il punto e' il nome scritto
            scritto = ev.testo_originale
            if ev.tipo in TIPI_PAROLA_CHIAVE and isinstance(scritto, str) and scritto.isidentifier():
                evento = scritto
            else:
                raise self._inatteso(f"il nome dell'evento dopo `{controllo}.`", ev, esempio)
        self._avanza()
        # `quando Giocatore.tocca Moneta fai`: il nome dopo l'evento sceglie con chi (dinamiche dei giochi)
        oggetto = ""
        if self._cor.tipo is T.NOME and self._cor.riga == ev.riga and self._guarda().tipo is not T.PARENTESI_APERTA:
            oggetto = str(self._avanza().valore)
        canonico = SINONIMI_EVENTI.get(evento.lower())
        if canonico is not None:
            # `click` all'inglese: si capisce (tolleranza), con --rigoroso e' un errore
            if self.rigoroso:
                raise self._errore(
                    f"L'evento si chiama `{canonico}`, non `{evento}`.", ev,
                    f"In Leo si scrive `quando {controllo}.{canonico} fai`.",
                    [self._sostituisci(ev, canonico, f"l'evento si scrive `{canonico}`")])
            evento = canonico
        self._attendi_parola(T.FAI, "l'evento di `quando`")
        blocco = self._apri("quando", t)
        corpo = self._corpo_funzione(blocco)
        self._chiudi(blocco)
        return Evento(controllo, evento, corpo, oggetto=oggetto, riga=t.riga, colonna=t.colonna)

    # ------------------------------------------- novita' del tema "linguaggio"

    def _valori_separati(self) -> Espressione:
        """``espr`` oppure ``espr1, espr2, ...`` (diventa una lista)."""
        primo = self._cor
        valori = [self._espressione()]
        while self._cor.tipo is T.VIRGOLA:
            self._avanza()
            valori.append(self._espressione())
        if len(valori) == 1:
            return valori[0]
        return ListaLetterale(valori, riga=primo.riga, colonna=primo.colonna)

    def _dichiarazione_multipla(self, kw: Token, costante: bool, parola: str, primo: Token) -> Dichiarazione:
        nomi = [str(primo.valore)]
        while self._cor.tipo is T.VIRGOLA:
            self._avanza()
            n = self._cor
            if n.tipo is not T.NOME:
                raise self._riservata(n, f"il nome di un'altra {parola} dopo la virgola")
            if n.valore in nomi:
                raise self._errore(f"Il nome `{n.valore}` compare due volte.", n,
                                   f"Per esempio `{parola} a, b = [1, 2]`.")
            nomi.append(str(self._avanza().valore))
        esempio = f"Scrivi per esempio `{parola} {', '.join(nomi)} = ...` con una lista di {len(nomi)} valori."
        if self._cor.tipo is not T.ASSEGNA:
            raise self._inatteso(f"`=` dopo `{parola} {', '.join(nomi)}`", self._cor, esempio)
        self._avanza()
        if self._cor.tipo in (T.FINE_RIGA, T.FINE_FILE) or self._cor.tipo in _CHIUSURE:
            raise self._errore("Manca il valore dopo `=`.", self._cor, esempio)
        valore = self._valori_separati()
        return DichiarazioneMultipla(nomi[0], valore, costante, nomi, riga=kw.riga, colonna=kw.colonna)

    def _assegnazione_multipla(self, primo_bersaglio: Espressione, primo: Token) -> AssegnazioneMultipla:
        bersagli = [primo_bersaglio]
        while self._cor.tipo is T.VIRGOLA:
            self._avanza()
            t = self._cor
            espr = self._espressione()
            if not isinstance(espr, (Nome, Indice, Attributo)):
                raise self._errore(f"Non si può assegnare a {_descrivi_bersaglio(espr)}.", t,
                                   "Per scambiare due variabili scrivi `a, b = b, a`.")
            bersagli.append(espr)
        t = self._cor
        if t.tipo is not T.ASSEGNA:
            if t.tipo in TIPI_ASSEGNAZIONE:
                raise self._errore(f"Con più variabili si usa solo `=`, non `{t.tipo.value}`.", t)
            raise self._inatteso("`=` dopo l'elenco delle variabili", t,
                                 "Per esempio `a, b = b, a` scambia due variabili.")
        self._avanza()
        valore = self._valori_separati()
        return AssegnazioneMultipla(bersagli, valore, riga=primo.riga, colonna=primo.colonna)

    def _controlla_lista_compresa(self, apre: Token) -> None:
        """Errori tipici nelle liste in una riga: ``fai``/``allora`` in piu', due
        ``per ogni``."""
        t = self._cor
        if t.tipo in (T.FAI, T.ALLORA):
            parola = _testo(t)
            correzioni = []
            prec = self._precedente()
            if prec is not None and prec.riga == t.riga:
                inizio = prec.colonna + _lunghezza(prec)
                spazi = " " * max(0, t.colonna - inizio)
                correzioni.append(Correzione(t.riga, inizio, spazi + parola, "",
                                             f"in una lista in una riga non serve `{parola}`"))
            raise self._errore(
                f"In una lista in una riga non serve `{parola}`.", t,
                "Scrivi solo `[elemento per ogni x in sequenza]`, con la condizione facoltativa "
                "`se ...` alla fine: niente `fai`, `allora` o `fine`.", correzioni)
        if t.tipo is T.PER_OGNI:
            raise self._errore(
                "In una lista in una riga si può usare un solo `per ogni`.", t,
                "Per percorrere più sequenze scrivi i cicli `per ogni ... fai` su più righe, "
                "oppure costruisci prima la lista interna in una variabile.")

    def _condizione_prima_del_per_ogni(self, apre: Token) -> ErroreSintassi | None:
        """``[n se n > 1 per ogni n in l]``: la condizione va dopo il ``per ogni``."""
        t = self._cor
        i_se = self._i
        livello = 0
        i_per = i_chiusa = None
        k = i_se + 1
        while k < len(self._t):
            x = self._t[k]
            if x.tipo in _APRE_TIPI:
                livello += 1
            elif x.tipo in _CHIUDE_TIPI:
                if livello == 0:
                    if x.tipo is T.QUADRA_CHIUSA:
                        i_chiusa = k
                    break
                livello -= 1
            elif livello == 0 and x.tipo is T.PER_OGNI and i_per is None:
                i_per = k
            elif x.tipo is T.FINE_FILE:
                break
            k += 1
        if i_per is None:
            return None
        correzioni = []
        esempio = "`[n per ogni n in lista se n > 1]`"
        if i_chiusa is not None:
            spezzoni = self._t[i_se:i_chiusa]
            if (all(x.riga == t.riga and _testo(x) for x in spezzoni)
                    and not any(x.tipo is T.FINE_RIGA for x in spezzoni)):
                prima = self._spezzone(i_se, i_chiusa)
                nuovo = self._spezzone(i_per, i_chiusa) + " " + self._spezzone(i_se, i_per)
                esempio = f"`{nuovo}`"
                correzioni.append(Correzione(t.riga, t.colonna, prima, nuovo,
                                             "la condizione `se` va dopo il `per ogni`"))
        return self._errore(
            "In una lista in una riga la condizione `se` va dopo il `per ogni`.", t,
            f"Scrivi prima il ciclo e poi la condizione: {esempio}.", correzioni)

    def _lista_compresa(self, apre: Token, elemento: Espressione) -> ListaCompresa:
        self._avanza()  # per ogni
        if self._cor.tipo is not T.NOME:
            raise self._riservata(self._cor, "il nome della variabile dopo `per ogni`")
        variabili = self._nomi_ciclo("per ogni")
        self._attendi_parola(T.IN, f"`per ogni {', '.join(variabili)}`")
        iterabile = self._espressione()
        self._controlla_lista_compresa(apre)
        condizione = None
        if self._cor.tipo is T.SE:
            self._avanza()
            condizione = self._espressione()
            self._controlla_lista_compresa(apre)
        self._chiusa(apre)
        return ListaCompresa(elemento, variabili, iterabile, condizione, riga=apre.riga, colonna=apre.colonna)

    def _scegli(self) -> Scegli:
        t = self._avanza()
        blocco = self._apri("scegli", t)
        if self._cor.tipo in (T.FINE_RIGA, T.FINE_FILE):
            raise self._errore("Dopo `scegli` serve il valore da controllare, per esempio `scegli voto`.",
                               self._cor)
        valore = self._espressione()
        if self._cor.tipo not in (T.FINE_RIGA, T.FINE_FILE):
            raise self._inatteso("la fine della riga dopo il valore di `scegli`", self._cor,
                                 "I rami vanno sulle righe dopo: `caso 1 allora`.")
        casi: list[Caso] = []
        altrimenti = None
        self._salta_righe()
        while self._e_caso(liberale=True):
            tc = self._avanza()
            if self._cor.tipo in (T.ALLORA, T.FINE_RIGA, T.FINE_FILE):
                raise self._errore("Dopo `caso` serve almeno un valore, per esempio `caso 1, 2 allora`.",
                                   self._cor)
            schemi = [self._espressione()]
            while self._cor.tipo is T.VIRGOLA:
                self._avanza()
                schemi.append(self._espressione())
            self._attendi_parola(T.ALLORA, "i valori di `caso`")
            corpo = self._blocco_caso(blocco)
            casi.append(Caso(schemi, corpo, riga=tc.riga, colonna=tc.colonna))
        if self._cor.tipo is T.ALTRIMENTI:
            self._avanza()
            altrimenti = self._blocco(blocco, frozenset({T.FINE}))
        if self._cor.tipo is T.FINE_FILE:
            raise self._mai_chiuso(blocco)
        if self._cor.tipo is not T.FINE:
            raise self._errore("Dentro `scegli` ogni ramo comincia con `caso` (o `altrimenti`).", self._cor,
                               "Per esempio:\n  scegli voto\n    caso 10 allora\n      stampa(\"Ottimo\")\n  fine")
        self._chiudi(blocco)
        return Scegli(valore, casi, altrimenti, riga=t.riga, colonna=t.colonna)

    def _blocco_caso(self, blocco: _Blocco) -> list[Istruzione]:
        """Corpo di un ``caso``: finisce al prossimo ``caso``, ``altrimenti`` o ``fine``."""
        corpo: list[Istruzione] = []
        while True:
            self._salta_righe()
            t = self._cor
            if t.tipo in (T.ALTRIMENTI, T.FINE) or self._e_caso(liberale=True):
                return corpo
            if t.tipo is T.FINE_FILE:
                raise self._mai_chiuso(blocco)
            if t.tipo in _CHIUSURE:
                raise self._chiusura_fuori_posto(t, blocco)
            corpo.append(self._istruzione_completa())

    def _importa(self) -> Importa:
        t = self._avanza()
        c = self._cor
        esempio = "Per esempio `importa \"geometria.leo\"` oppure `importa matematica come m`."
        if c.tipo is T.TESTO:
            modulo = str(c.valore)
            if not modulo.strip():
                raise self._errore("Il nome del file da importare è vuoto.", c, esempio)
        elif c.tipo is T.NOME:
            modulo = str(c.valore)
            if modulo == "python" and self._guarda(1).tipo in (T.TESTO, T.NOME):
                # `importa python "requests" come rete` / `importa python os.path` (vedi ponte_python)
                self._avanza()
                nome_py = str(self._cor.valore)
                if self._cor.tipo is T.NOME:
                    while self._guarda(1).tipo is T.PUNTO and self._guarda(2).tipo is T.NOME:
                        self._avanza()
                        self._avanza()
                        nome_py += "." + str(self._cor.valore)
                if not nome_py.strip():
                    raise self._errore("Il nome del modulo Python è vuoto.", self._cor,
                                       "Per esempio `importa python \"requests\" come rete`.")
                modulo = "python:" + nome_py.strip()
        else:
            raise self._inatteso("il nome di un modulo o di un file dopo `importa`", c, esempio)
        self._avanza()
        alias = None
        if self._cor.tipo is T.COME:
            self._avanza()
            a = self._cor
            if a.tipo is not T.NOME:
                raise self._riservata(a, "il nome da dare al modulo dopo `come`")
            alias = str(self._avanza().valore)
        return Importa(modulo, alias, riga=t.riga, colonna=t.colonna)

    def _verifica(self) -> Verifica:
        t = self._avanza()
        if self._cor.tipo in (T.FINE_RIGA, T.FINE_FILE) or self._cor.tipo in _CHIUSURE:
            raise self._errore("Dopo `verifica` serve una condizione, per esempio `verifica x > 0`.", self._cor)
        condizione = self._espressione()
        if self._cor.tipo is T.ASSEGNA:
            c = self._cor
            raise self._errore("Per confrontare usa `==`.", c,
                               "`=` dà un valore a una variabile; `==` controlla se due valori sono uguali.",
                               [self._sostituisci(c, "==", "per confrontare si usa `==`")])
        messaggio = None
        if self._cor.tipo is T.VIRGOLA:
            self._avanza()
            messaggio = self._espressione()
        return Verifica(condizione, messaggio, riga=t.riga, colonna=t.colonna)

    # ------------------------------ costrutti potenti: ogni/dopo, verifiche, parallelo

    def _costrutto_potenza(self, genere: str) -> Istruzione:
        if genere in ("ogni", "dopo"):
            return self._temporizzatore()
        if genere == "verifica":
            return self._blocco_verifica()
        if genere == "aspettati errore":
            return self._aspettati_errore()
        return self._aspettati()

    def _temporizzatore(self) -> Temporizzatore:
        """``ogni 2 secondi fai ... fine`` / ``dopo 300 millisecondi fai ... fine``.

        Tolleranze: ``ogni secondo fai`` (senza numero: 1), ``2s``/``300ms``
        attaccati, ``allora`` al posto di ``fai``, unita' mancante (secondi; con
        ``--rigoroso`` e' un errore con la correzione)."""
        t = self._avanza()
        parola = str(t.valore)
        esempio = f"Per esempio `{parola} 2 secondi fai` (oppure `{parola} 500 millisecondi fai`)."
        c = self._cor
        durata: Espressione
        if c.tipo is T.NOME and c.valore in UNITA_TEMPORIZZATORI and self._guarda().tipo in (T.FAI, T.ALLORA):
            # `ogni secondo fai`, `ogni minuto fai`: una unita'
            durata = Letterale(1, riga=c.riga, colonna=c.colonna)
            unita = str(self._avanza().valore)
        else:
            if c.tipo in (T.FAI, T.ALLORA, T.FINE_RIGA, T.FINE_FILE):
                raise self._errore(f"Dopo `{parola}` serve la durata.", c, esempio)
            durata = self._espressione()
            u = self._cor
            if u.tipo is T.NOME and u.valore in UNITA_TEMPORIZZATORI:
                unita = str(self._avanza().valore)
            elif u.tipo in (T.FAI, T.ALLORA, T.FINE_RIGA, T.FINE_FILE):
                if self.rigoroso:
                    raise self._errore(
                        "Manca l'unità di tempo dopo la durata: `secondi` o `millisecondi`?",
                        self._precedente() or u,
                        f"In modalità rigorosa si scrive l'unità: `{parola} 2 secondi fai`.",
                        [self._inserisci_dopo(self._precedente(), " secondi", "manca l'unità di tempo")])
                unita = "secondi"       # tolleranza: senza unita' sono secondi
            elif u.tipo is T.NOME:
                raise self._unita_temporizzatore(u)
            else:
                raise self._inatteso(f"l'unità di tempo e `fai` dopo la durata di `{parola}`", u, esempio)
        if self._cor.tipo in (T.FINE_RIGA, T.FINE_FILE):
            prec = self._precedente()
            raise self._errore(f"Manca `fai` dopo la durata di `{parola}`.", self._cor if prec is None else prec,
                               f"Scrivi `fai` alla fine della riga: `{parola} ... secondi fai`.",
                               [self._inserisci_dopo(prec, " fai", "manca `fai`")])
        self._attendi_parola(T.FAI, f"la durata di `{parola}`")
        blocco = self._apri("ogni", t) if parola == "ogni" else self._apri("dopo", t)
        corpo = self._corpo_funzione(blocco)
        self._chiudi(blocco)
        return Temporizzatore(durata, unita, corpo, parola == "ogni", riga=t.riga, colonna=t.colonna)

    def _unita_temporizzatore(self, u: Token) -> ErroreSintassi:
        parola = str(u.valore)
        proposta = _QUASI_UNITA.get(parola.lower())
        if proposta is None and parola.lower() in UNITA_TEMPORIZZATORI:
            proposta = parola.lower()
        if proposta is None:
            vicine = [x for x in ("secondi", "secondo", "millisecondi", "minuti", "minuto")
                      if _distanza(parola.lower(), x) <= 2]
            proposta = vicine[0] if vicine else None
        if proposta is None and parola.lower() in ("min", "minutes", "minute"):
            proposta = "minuti"
        suggerimento = "Le unità ammesse sono `secondi` (o `s`), `millisecondi` (o `ms`) e `minuti`."
        if proposta is not None:
            return self._errore(f"Non conosco l'unità di tempo `{parola}`: forse intendevi `{proposta}`?", u,
                                suggerimento, [self._sostituisci(u, proposta, f"`{parola}` non è un'unità di Leo")])
        return self._errore(f"Non conosco l'unità di tempo `{parola}`.", u, suggerimento)

    def _blocco_verifica(self) -> BloccoVerifica:
        """``verifica "nome del test" fai ... fine`` (solo al livello esterno)."""
        t = self._cor
        aperti = [b for b in self._aperti if b.nome != "inizio"]
        if aperti:
            interno = aperti[-1]
            raise self._errore(
                "Un blocco `verifica \"...\" fai` si scrive al livello più esterno del programma, "
                "fuori da ogni blocco.", t,
                f"Forse manca `fine` per il blocco `{interno.nome}` aperto alla riga {interno.token.riga}; "
                "per un controllo dentro il codice usa `verifica condizione`.")
        self._avanza()
        nome = self._primario()
        self._attendi_parola(T.FAI, "il nome della verifica")
        blocco = self._apri("verifica", t)
        corpo = self._blocco(blocco, frozenset({T.FINE}))
        self._chiudi(blocco)
        return BloccoVerifica(nome, corpo, riga=t.riga, colonna=t.colonna)

    def _fuori_da_verifica(self, t: Token, forma: str) -> None:
        if any(b.nome == "verifica" for b in self._aperti):
            return
        raise self._errore(
            f"`{forma}` si usa dentro un blocco `verifica \"nome\" fai ... fine`.", t,
            "Scrivi prima `verifica \"nome del test\" fai`; per un controllo dentro il programma usa "
            "`verifica condizione`.")

    def _aspettati(self) -> Aspettati:
        """``aspettati condizione`` (dentro una verifica)."""
        t = self._cor
        self._fuori_da_verifica(t, "aspettati")
        self._avanza()
        condizione = self._espressione()
        c = self._cor
        if c.tipo is T.ASSEGNA:
            raise self._errore("Per confrontare usa `==`.", c,
                               "`=` dà un valore a una variabile; `==` controlla se due valori sono uguali.",
                               [self._sostituisci(c, "==", "per confrontare si usa `==`")])
        return Aspettati(condizione, riga=t.riga, colonna=t.colonna)

    def _aspettati_errore(self) -> AspettatiErrore:
        """``aspettati errore [TipoErrore] fai ... fine`` (dentro una verifica)."""
        t = self._cor
        self._fuori_da_verifica(t, "aspettati errore")
        self._avanza()
        self._avanza()          # `errore`
        tipo_errore = None
        c = self._cor
        if c.tipo is T.NOME:
            tipo_errore = str(self._avanza().valore)
        if self._cor.tipo in (T.FINE_RIGA, T.FINE_FILE):
            prec = self._precedente()
            raise self._errore("Manca `fai` dopo `aspettati errore`.", prec or self._cor,
                               "Per esempio `aspettati errore ErroreValore fai`, poi il codice che deve "
                               "sbagliare e `fine`.",
                               [self._inserisci_dopo(prec, " fai", "manca `fai`")])
        self._attendi_parola(T.FAI, "`aspettati errore`")
        blocco = self._apri("aspettati", t)
        corpo = self._blocco(blocco, frozenset({T.FINE}))
        self._chiudi(blocco)
        return AspettatiErrore(tipo_errore, corpo, riga=t.riga, colonna=t.colonna)

    def _parallelo(self) -> Parallelo:
        """``in parallelo fai ... fine`` (un valore: il lavoro)."""
        t = self._avanza()      # `in`
        self._avanza()          # `parallelo`
        self._attendi_parola(T.FAI, "`in parallelo`")
        blocco = self._apri("in parallelo", t)
        corpo = self._corpo_funzione(blocco)
        self._chiudi(blocco)
        return Parallelo(corpo, riga=t.riga, colonna=t.colonna)

    def _formato(self, parte: Any, formato: str, espressione: Espressione, t: Token) -> ValoreFormattato:
        """``{prezzo:2}``, ``{n:migliaia}``: controlla il formato."""
        from .potenza import DECIMALI_MASSIMI, normalizza_formato

        canonico = normalizza_formato(formato)
        if canonico is None:
            riga = getattr(parte, "riga", 0) or t.riga
            colonna = (getattr(parte, "colonna", 0) or t.colonna) + max(0, str(parte.sorgente).rfind(":"))
            decimali = re.search(r"\d+", formato)
            messaggio = f"Non conosco il formato `:{formato}`."
            if decimali and int(decimali.group(0)) > DECIMALI_MASSIMI:
                messaggio = (f"Non conosco il formato `:{formato}`: i decimali possono essere "
                             f"al massimo {DECIMALI_MASSIMI}.")
            suggerimento = SUGGERIMENTO_FORMATO
            if decimali and int(decimali.group(0)) <= DECIMALI_MASSIMI:
                # `{x:.2f}`: si propone la forma di Leo con gli stessi decimali
                suggerimento = suggerimento.replace("`{prezzo:2}`", f"`{{...:{int(decimali.group(0))}}}`")
            raise ErroreSintassi(
                messaggio, riga, colonna, suggerimento,
                nome_file=self.nome_file, lunghezza=len(formato) + 1)
        return ValoreFormattato(espressione, canonico, riga=espressione.riga, colonna=espressione.colonna)

    # ------------------------------------------------------- espressioni

    def _espressione(self) -> Espressione:
        sinistra = self._o_logico()
        while True:
            t = self._cor
            if t.tipo is T.FINE_RIGA and t.valore == "\n" and self._guarda().tipo is T.CATENA:
                self._avanza()  # catena su piu' righe: `|>` all'inizio della riga dopo
                t = self._cor
            if t.tipo is not T.CATENA:
                return sinistra
            op = self._avanza()
            if self._cor.tipo is T.FINE_RIGA and self._cor.valore == "\n" \
                    and self._guarda().tipo not in (T.FINE_RIGA, T.FINE_FILE):
                self._avanza()  # catena su piu' righe: `|>` alla fine della riga
            if self._cor.tipo in (T.FINE_RIGA, T.FINE_FILE):
                raise self._errore("Dopo `|>` serve una funzione, per esempio `lista |> ordina`.", self._cor)
            destra = self._postfisso()
            if isinstance(destra, Chiamata):
                argomenti = [Argomento(sinistra, None, riga=op.riga, colonna=op.colonna)] + destra.argomenti
                sinistra = Chiamata(destra.funzione, argomenti, True, riga=op.riga, colonna=op.colonna)
            else:
                sinistra = Chiamata(destra, [Argomento(sinistra, None, riga=op.riga, colonna=op.colonna)], True,
                                    riga=op.riga, colonna=op.colonna)

    def _o_logico(self) -> Espressione:
        sinistra = self._e_logico()
        while self._cor.tipo is T.O or self._e_oppure():
            # `oppure` scritto cosi': se a sinistra c'e' `nulla` vale la destra (leo/controllo)
            operatore = "oppure" if self._e_oppure() else "o"
            op = self._avanza()
            destra = self._e_logico()
            sinistra = Logica(operatore, sinistra, destra, riga=op.riga, colonna=op.colonna)
        return sinistra

    def _e_logico(self) -> Espressione:
        sinistra = self._confronto()
        while self._cor.tipo is T.E:
            op = self._avanza()
            destra = self._confronto()
            sinistra = Logica("e", sinistra, destra, riga=op.riga, colonna=op.colonna)
        return sinistra

    def _e_confronto(self, t: Token) -> bool:
        return t.tipo in TIPI_CONFRONTO or (t.tipo is T.ASSEGNA and self._in_condizione > 0)

    def _confronto(self) -> Espressione:
        primo = self._intervallo()
        if not self._e_confronto(self._cor):
            ha_valore = self._ha_valore(primo)  # `x ha valore`, `x non ha valore`
            return primo if ha_valore is None else ha_valore
        op0 = self._cor
        operandi = [primo]
        operatori: list[str] = []
        while self._e_confronto(self._cor):
            op = self._avanza()
            operatori.append("==" if op.tipo is T.ASSEGNA else op.tipo.value)
            operandi.append(self._intervallo())
        return Confronto(operandi, operatori, riga=op0.riga, colonna=op0.colonna)

    def _intervallo(self) -> Espressione:
        inizio = self._somma()
        if self._cor.tipo is not T.PUNTO_PUNTO:
            return inizio
        op = self._avanza()
        fine = self._somma()
        if self._cor.tipo is T.PUNTO_PUNTO:
            raise self._errore(
                "Gli intervalli non si possono concatenare: scrivi `a..b`, non `a..b..c`.",
                self._cor)
        return Intervallo(inizio, fine, riga=op.riga, colonna=op.colonna)

    def _somma(self) -> Espressione:
        sinistra = self._prodotto()
        while self._cor.tipo in _OP_SOMMA:
            op = self._avanza()
            destra = self._prodotto()
            sinistra = Binaria(op.tipo.value, sinistra, destra, riga=op.riga, colonna=op.colonna)
        return sinistra

    def _prodotto(self) -> Espressione:
        sinistra = self._unario()
        while self._cor.tipo in _OP_PRODOTTO:
            op = self._avanza()
            destra = self._unario()
            sinistra = Binaria(op.tipo.value, sinistra, destra, riga=op.riga, colonna=op.colonna)
        return sinistra

    def _unario(self) -> Espressione:
        self._livello_espressioni += 1
        try:
            if self._livello_espressioni > LIMITE_ANNIDAMENTO:
                raise self._troppo_annidato("espressione")
            t = self._cor
            if t.tipo in (T.MENO, T.NON):
                self._avanza()
                operando = self._unario()
                return Unaria(t.tipo.value, operando, riga=t.riga, colonna=t.colonna)
            # `nuovo Persona(...)`: forma discorsiva della creazione di una `classe`
            # (o `struttura`). `nuovo` e' una parola di contesto: vale solo davanti a
            # un nome sulla stessa riga, altrove resta un nome qualunque (`nuovo = 3`,
            # `nuovo(x)`, `scrivi nuovo`).
            if t.tipo is T.NOME and t.valore == "nuovo":
                succ = self._guarda()
                if succ.tipo is T.NOME and succ.riga == t.riga:
                    self._avanza()
                    return self._potenza()
            return self._potenza()
        finally:
            self._livello_espressioni -= 1

    def _potenza(self) -> Espressione:
        base = self._postfisso()
        if self._cor.tipo is T.CIRCONFLESSO:
            op = self._avanza()
            esponente = self._unario()
            return Binaria("^", base, esponente, riga=op.riga, colonna=op.colonna)
        return base

    def _postfisso(self) -> Espressione:
        inizio = self._cor
        espr = self._primario()
        while True:
            t = self._cor
            if t.tipo is T.PARENTESI_APERTA:
                self._avanza()
                argomenti = self._argomenti(t)
                espr = Chiamata(espr, argomenti, riga=inizio.riga, colonna=inizio.colonna)
            elif t.tipo is T.QUADRA_APERTA:
                self._avanza()
                indice = self._espressione()
                self._chiusa(t)
                espr = Indice(espr, indice, riga=t.riga, colonna=t.colonna)
            elif t.tipo is T.PUNTO:
                self._avanza()
                n = self._cor
                nome_membro = str(n.valore)
                if n.tipo is not T.NOME and not _parola_come_nome(n):
                    # dopo il punto un sinonimo di parola chiave e' il nome scritto (`Eroe.salta`)
                    scritto = n.testo_originale
                    if n.tipo in TIPI_PAROLA_CHIAVE and isinstance(scritto, str) and scritto.isidentifier():
                        nome_membro = scritto
                    else:
                        raise self._inatteso("il nome di una proprietà o di un metodo dopo `.`", n)
                self._avanza()
                espr = Attributo(espr, nome_membro, riga=n.riga, colonna=n.colonna)
            else:
                return espr

    def _chiusa(self, apre: Token) -> Token:
        """Consuma la parentesi che chiude ``apre`` (espressione singola dentro)."""
        chiusa = _TIPO_CHIUSA[apre.tipo]
        t = self._cor
        if t.tipo is chiusa:
            return self._avanza()
        if t.tipo is T.ASSEGNA:
            raise self._errore(
                "Per confrontare usa `==`.", t,
                "`=` dà un valore a una variabile; `==` controlla se due valori sono uguali.",
                [self._sostituisci(t, "==", "per confrontare si usa `==`")])
        simbolo = _CHIUSA_DI[apre.tipo]
        correzioni = []
        if self.recupero:
            correzioni.append(self._inserisci_dopo(self._precedente(), simbolo, f"manca `{simbolo}`"))
        raise self._errore(
            f"Manca `{simbolo}` per chiudere la parentesi `{apre.tipo.value}` aperta alla riga {apre.riga}.",
            t, None, correzioni)

    def _separatore_mancante(self, apre: Token, dove: str) -> ErroreSintassi:
        """Dopo un elemento non c'e' ne' la virgola ne' la parentesi di chiusura."""
        t = self._cor
        simbolo = _CHIUSA_DI[apre.tipo]
        prec = self._precedente()
        if t.tipo in _INIZIO_ESPRESSIONE:
            correzioni: list[Correzione] = []
            if self.recupero:
                virgola = self._inserisci_dopo(prec, ",", "manca una virgola")
                parentesi = self._inserisci_dopo(prec, simbolo, f"manca `{simbolo}`")
                if prec is not None and t.riga > prec.riga:
                    correzioni = self._con_alternative([parentesi, virgola])
                else:
                    correzioni = [virgola]
            return self._errore(f"Manca una virgola {dove}.", t,
                                "Separa gli elementi con `,`.", correzioni)
        correzioni = []
        if self.recupero:
            correzioni.append(self._inserisci_dopo(prec, simbolo, f"manca `{simbolo}`"))
        return self._errore(
            f"Manca `{simbolo}` per chiudere la parentesi `{apre.tipo.value}` aperta alla riga {apre.riga}.",
            t, None, correzioni)

    def _argomenti(self, apre: Token) -> list[Argomento]:
        argomenti: list[Argomento] = []
        if self._cor.tipo is T.PARENTESI_CHIUSA:
            self._avanza()
            return argomenti
        nomi: set[str] = set()
        ultimo_per_nome: str | None = None
        while True:
            t = self._cor
            if t.tipo is T.NOME and self._guarda().tipo is T.ASSEGNA:
                nome = str(t.valore)
                self._avanza()
                self._avanza()
                valore = self._espressione()
                if nome in nomi:
                    raise self._errore(f"L'argomento `{nome}` è passato due volte.", t)
                nomi.add(nome)
                ultimo_per_nome = nome
                argomenti.append(Argomento(valore, nome, riga=t.riga, colonna=t.colonna))
            else:
                valore = self._espressione()
                if ultimo_per_nome is not None:
                    raise self._errore(
                        f"Dopo un argomento per nome (`{ultimo_per_nome} = ...`) non puoi passare "
                        "argomenti senza nome.", t,
                        "Metti prima gli argomenti senza nome, poi quelli per nome.")
                espandi = False
                if self._cor.tipo is T.TRE_PUNTI:
                    self._avanza()
                    espandi = True
                argomenti.append(Argomento(valore, None, espandi, riga=t.riga, colonna=t.colonna))
            if self._cor.tipo is T.VIRGOLA:
                self._avanza()
                if self._cor.tipo is T.PARENTESI_CHIUSA:
                    self._avanza()
                    return argomenti
                continue
            if self._cor.tipo is T.PARENTESI_CHIUSA:
                self._avanza()
                return argomenti
            raise self._separatore_mancante(apre, "tra gli argomenti")

    def _lista(self) -> ListaLetterale:
        apre = self._avanza()
        elementi: list[Espressione] = []
        while self._cor.tipo is not T.QUADRA_CHIUSA:
            elementi.append(self._espressione())
            if len(elementi) == 1 and self._cor.tipo is T.PER_OGNI:
                return self._lista_compresa(apre, elementi[0])
            if len(elementi) == 1 and self._cor.tipo is T.SE:
                errore = self._condizione_prima_del_per_ogni(apre)
                if errore is not None:
                    raise errore
            if self._cor.tipo is T.VIRGOLA:
                self._avanza()
                continue
            if self._cor.tipo is not T.QUADRA_CHIUSA:
                raise self._separatore_mancante(apre, "tra gli elementi della lista")
        self._avanza()
        return ListaLetterale(elementi, riga=apre.riga, colonna=apre.colonna)

    def _dizionario(self) -> DizionarioLetterale:
        apre = self._avanza()
        coppie: list[tuple[Espressione, Espressione]] = []
        while self._cor.tipo is not T.GRAFFA_CHIUSA:
            chiave = self._espressione()
            if self._cor.tipo is not T.DUE_PUNTI:
                t = self._cor
                correzioni = []
                if self.recupero and t.tipo in _INIZIO_ESPRESSIONE:
                    correzioni.append(self._inserisci_dopo(self._precedente(), ":", "manca `:`"))
                raise self._errore("Manca `:` tra la chiave e il valore nel dizionario.", t,
                                   "Per esempio `{\"nome\": \"Ada\"}`.", correzioni)
            self._avanza()
            valore = self._espressione()
            coppie.append((chiave, valore))
            if self._cor.tipo is T.VIRGOLA:
                self._avanza()
                continue
            if self._cor.tipo is not T.GRAFFA_CHIUSA:
                raise self._separatore_mancante(apre, "tra le coppie del dizionario")
        self._avanza()
        return DizionarioLetterale(coppie, riga=apre.riga, colonna=apre.colonna)

    def _interpolato(self) -> TestoInterpolato:
        t = self._avanza()
        parti: list = []
        for parte in t.valore or []:
            if isinstance(parte, str):
                parti.append(parte)
                continue
            token = list(getattr(parte, "token", None) or [])
            if not [x for x in token if x.tipo not in (T.FINE_RIGA, T.FINE_FILE, T.COMMENTO)]:
                riga = getattr(parte, "riga", 0) or t.riga
                colonna = getattr(parte, "colonna", 0) or t.colonna
                raise ErroreSintassi("Tra le graffe `{}` manca l'espressione.", riga, colonna,
                                     "Scrivi `\\{` se vuoi una graffa nel testo.",
                                     nome_file=self.nome_file)
            interno = Parser(token, self.nome_file, recupero=self.recupero, rigoroso=self.rigoroso)
            interno._livello_espressioni = self._livello_espressioni
            interno._livello_blocchi = self._livello_blocchi
            espressione = interno.espressione_isolata()
            formato = getattr(parte, "formato", None)
            if formato is not None:
                espressione = self._formato(parte, formato, espressione, t)
            parti.append(espressione)
        nodo = TestoInterpolato(parti, riga=t.riga, colonna=t.colonna)
        if t.origine == "comando":
            # testo di un comando senza parentesi (`stampa Ciao (nome)`): per `leo spiega`
            nodo.da_comando = True  # type: ignore[attr-defined]
        return nodo

    def _primario(self) -> Espressione:
        t = self._cor
        tipo = t.tipo
        if tipo in (T.INTERO, T.DECIMALE, T.TESTO):
            self._avanza()
            return Letterale(t.valore, riga=t.riga, colonna=t.colonna)
        if tipo is T.TESTO_INTERPOLATO:
            return self._interpolato()
        if tipo is T.VERO:
            self._avanza()
            return Letterale(True, riga=t.riga, colonna=t.colonna)
        if tipo is T.FALSO:
            self._avanza()
            return Letterale(False, riga=t.riga, colonna=t.colonna)
        if tipo is T.NULLA:
            self._avanza()
            return Letterale(None, riga=t.riga, colonna=t.colonna)
        if tipo is T.NOME and t.valore == "genitore" and getattr(self, "_classe_genitore", None) \
                and self._guarda().tipo is T.PUNTO:
            # `genitore.saluta()` dentro un'azione di `classe ... estende ...`:
            # l'oggetto corrente visto come la classe genitore.
            self._avanza()
            return RiferimentoGenitore(self._classe_genitore, riga=t.riga, colonna=t.colonna)
        if tipo is T.NOME:
            self._avanza()
            return Nome(str(t.valore), riga=t.riga, colonna=t.colonna)
        if tipo is T.E:
            # Dove serve un valore `e` non puo' essere l'operatore logico: e' il nome
            # dell'errore catturato con `cattura ... come e` (`e.messaggio`).
            self._avanza()
            return Nome("e", riga=t.riga, colonna=t.colonna)
        if tipo is T.QUADRA_APERTA:
            return self._lista()
        if tipo is T.GRAFFA_APERTA:
            return self._dizionario()
        if tipo is T.PARENTESI_APERTA:
            self._avanza()
            espr = self._espressione()
            self._chiusa(t)
            return espr
        if tipo is T.FUNZIONE:
            if self._guarda().tipo is T.PARENTESI_APERTA:
                return self._funzione_anonima()
            if self._guarda().tipo is T.NOME:
                raise self._errore(
                    "Una funzione con nome non può stare dentro un'espressione.", self._guarda(),
                    "Togli il nome per una funzione anonima: `funzione (x) restituisci x * 2 fine`.")
            raise self._inatteso("`(` dopo `funzione`", self._guarda())
        if tipo is T.IN and self._guarda().tipo is T.NOME and self._guarda().valore == "parallelo" \
                and self._guarda().riga == t.riga:
            return self._parallelo()
        if tipo is T.ASTERISCO and self._i > 0:
            prec = self._t[self._i - 1]
            if prec.tipo is T.ASTERISCO and prec.riga == t.riga and prec.colonna + 1 == t.colonna:
                correzioni = [Correzione(prec.riga, prec.colonna, "**", "^",
                                         "la potenza in Leo si scrive `^`")] if self.recupero else []
                raise self._errore("In Leo la potenza si scrive `^`, non `**`.", prec,
                                   "Per esempio `2 ^ 3` vale 8.", correzioni, lunghezza=2)
        suggerimento = None
        if tipo in TIPI_PAROLA_CHIAVE:
            suggerimento = f"`{_testo(t)}` è una parola riservata di Leo: non si può usare come nome."
        raise self._inatteso("un valore", t, suggerimento)


def analizza_token(token: list[Token], nome_file: str = "<sorgente>", **kw) -> Programma:
    """Comodita': ``Parser(token, nome_file, **kw).analizza()``."""
    return Parser(token, nome_file, **kw).analizza()
