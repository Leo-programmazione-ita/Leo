"""La tartaruga di Leo: logica pura del disegno (nessuna dipendenza da Qt).

Una :class:`Tartaruga` parte dal centro del foglio (0, 0), guarda in alto e
lascia una scia quando cammina con la penna giù. Ogni movimento viene
registrato come un *elemento* del disegno:

* :class:`Tratto`   - un segmento (``penna`` falsa = spostamento senza segno);
* :class:`Macchia`  - un riempimento (poligono colorato);
* :class:`Scritta`  - un testo scritto sul foglio.

Coordinate "da matematica": x cresce verso destra, y verso l'alto; gli angoli
sono in gradi, 0 = verso destra, 90 = verso l'alto; ``destra`` gira in senso
orario, ``sinistra`` in senso antiorario (come la tartaruga del Logo).

Il disegno si può salvare in SVG (:meth:`Tartaruga.svg`) oppure mostrare in
una finestra animata (``leo.grafica.qt.tartaruga_qt``). La funzione
:func:`parti_visibili` calcola cosa si vede dopo che la tartaruga ha percorso
una certa distanza: la usa l'animazione ed è testata qui, senza Qt.

API di servizio per la riga di comando:
    tartaruga_di(interprete, crea=True) -> Tartaruga | None
    concludi_programma(nome_programma, uscita=print) -> str | None
    scarta(tartaruga) / scarta_tutte()
    modalita_finestra() -> bool      # PySide6 presente, LEO_TARTARUGA != "testo", non su Android
"""

from __future__ import annotations

import math
import os
import random
from dataclasses import dataclass, field
from typing import Any, Callable

from . import variabile_ambiente


def _escape_xml(testo: str) -> str:
    """Come ``xml.sax.saxutils.escape`` (``&``, ``<``, ``>``), senza importare
    ``xml.sax`` che si porta dietro ``urllib``, ``http`` ed ``email`` (~20 ms all'avvio)."""
    return testo.replace("&", "&amp;").replace(">", "&gt;").replace("<", "&lt;")


#: Oltre questa distanza dal centro (in passi) la tartaruga si rifiuta di andare.
LIMITE_COORDINATE = 100_000.0
#: Numero massimo di elementi di un disegno (protegge da cicli infiniti).
LIMITE_ELEMENTI = 200_000

#: I colori dell'arcobaleno, usati da ``colore(numero)``.
ARCOBALENO = ("#E53935", "#FB8C00", "#FDD835", "#43A047", "#1E88E5", "#3949AB", "#8E24AA")

COLORE_INIZIALE = "#000000"
SPESSORE_INIZIALE = 2.0
#: Sfondo iniziale: "" = il programma non ha scelto uno sfondo. Sullo schermo
#: la finestra usa allora il suo sfondo scuro; nel file SVG vale
#: :data:`SFONDO_FOGLIO_PREDEFINITO`. Cosi' ``sfondo("bianco")`` scelto dal
#: programma si distingue dallo sfondo di partenza e viene rispettato.
SFONDO_INIZIALE = ""
#: Colore del foglio nel file SVG quando il programma non sceglie uno sfondo.
SFONDO_FOGLIO_PREDEFINITO = "#FFFFFF"
VELOCITA_INIZIALE = 5


class ErroreTartaruga(ValueError):
    """Errore della logica pura: la libreria lo trasforma in ``ErroreValore``."""

    def __init__(self, messaggio: str, suggerimento: str | None = None) -> None:
        super().__init__(messaggio)
        self.messaggio = messaggio
        self.suggerimento = suggerimento


@dataclass
class Tratto:
    x1: float
    y1: float
    x2: float
    y2: float
    colore: str = COLORE_INIZIALE
    spessore: float = SPESSORE_INIZIALE
    penna: bool = True
    velocita: int = VELOCITA_INIZIALE

    @property
    def lunghezza(self) -> float:
        return math.hypot(self.x2 - self.x1, self.y2 - self.y1)


@dataclass
class Macchia:
    punti: list[tuple[float, float]]
    colore: str
    velocita: int = VELOCITA_INIZIALE


@dataclass
class Scritta:
    x: float
    y: float
    testo: str
    colore: str = COLORE_INIZIALE
    dimensione: float = 16.0
    velocita: int = VELOCITA_INIZIALE


def _arrotonda(v: float) -> float:
    """Toglie gli errori di arrotondamento dei calcoli con seni e coseni."""
    r = round(v, 9)
    return 0.0 if r == 0 else r


def numero_valido(valore: Any, nome: str) -> float:
    """Numero finito e non esagerato, altrimenti :class:`ErroreTartaruga`."""
    if isinstance(valore, bool) or not isinstance(valore, (int, float)):
        raise ErroreTartaruga(f"`{nome}` deve essere un numero.")
    try:
        v = float(valore)
    except OverflowError:
        v = math.inf
    if not math.isfinite(v):
        raise ErroreTartaruga(f"`{nome}` deve essere un numero normale, non infinito.",
                              "Prova con un numero come 100.")
    if abs(v) > LIMITE_COORDINATE:
        raise ErroreTartaruga(f"Il numero {valore} è troppo grande per la tartaruga.",
                              f"Usa numeri tra -{int(LIMITE_COORDINATE)} e {int(LIMITE_COORDINATE)}.")
    return v


def normalizza_colore_tartaruga(valore: Any) -> str:
    """Colore come ``#RRGGBB``: nomi italiani, esadecimali, numeri (arcobaleno) o [r, g, b]."""
    if isinstance(valore, bool):
        raise ErroreTartaruga("Un colore si scrive come testo, per esempio \"rosso\".")
    if isinstance(valore, int):
        return ARCOBALENO[valore % len(ARCOBALENO)]
    if isinstance(valore, list):
        if len(valore) == 3 and all(isinstance(c, (int, float)) and not isinstance(c, bool) for c in valore):
            try:
                r, g, b = (max(0, min(255, int(c))) for c in valore)
            except (OverflowError, ValueError):
                raise ErroreTartaruga("I numeri di un colore [rosso, verde, blu] vanno da 0 a 255.") from None
            return f"#{r:02X}{g:02X}{b:02X}"
        raise ErroreTartaruga("Un colore come lista deve avere tre numeri da 0 a 255: [rosso, verde, blu].")
    if isinstance(valore, str):
        testo = valore.strip()
        if testo.lower() in ("casuale", "a caso"):
            return random.choice(ARCOBALENO)
        if testo.lower() == "arcobaleno":
            return ARCOBALENO[0]
        if not testo:
            raise ErroreTartaruga("Il nome del colore è vuoto.", "Scrivi per esempio `colore(\"rosso\")`.")
        from .grafica.colori import normalizza_colore

        try:
            esa = normalizza_colore(testo)
        except Exception as e:  # noqa: BLE001 - ErroreValore/ErroreTipo di colori.py
            raise ErroreTartaruga(getattr(e, "messaggio", str(e)), getattr(e, "suggerimento", None)) from None
        return esa[:7] if len(esa) == 9 and esa[7:] == "FF" else esa
    raise ErroreTartaruga("Un colore si scrive come testo, per esempio \"rosso\", \"blu\" o \"#FF8800\".")


@dataclass
class Tartaruga:
    """Stato della tartaruga e disegno fatto finora."""

    x: float = 0.0
    y: float = 0.0
    direzione: float = 90.0
    penna_giu: bool = True
    colore: str = COLORE_INIZIALE
    spessore: float = SPESSORE_INIZIALE
    velocita: int = VELOCITA_INIZIALE
    visibile: bool = True
    sfondo: str = SFONDO_INIZIALE
    elementi: list = field(default_factory=list)
    #: colore e punti del riempimento in corso (None = nessuno)
    colore_riempimento: str | None = None
    punti_riempimento: list = field(default_factory=list)
    #: numero di elementi già mostrati/salvati (per non rifarlo a fine programma)
    elementi_mostrati: int = -1
    elementi_salvati: int = -1
    mostra_richiesto: bool = False

    # ------------------------------------------------------------------ utilità
    @property
    def tratti(self) -> list[Tratto]:
        """I tratti visibili (penna giù), nell'ordine in cui sono stati disegnati."""
        return [e for e in self.elementi if isinstance(e, Tratto) and e.penna]

    @property
    def posizione(self) -> tuple[float, float]:
        return (self.x, self.y)

    def _aggiungi(self, elemento: Any) -> None:
        if len(self.elementi) >= LIMITE_ELEMENTI:
            raise ErroreTartaruga("Il disegno ha troppi elementi: il limite è 200.000.",
                                  "Forse un ciclo non finisce mai: controlla i tuoi `ripeti` e `mentre`.")
        self.elementi.append(elemento)

    def _vai(self, nx: float, ny: float) -> None:
        nx, ny = _arrotonda(nx), _arrotonda(ny)
        if abs(nx) > LIMITE_COORDINATE or abs(ny) > LIMITE_COORDINATE:
            raise ErroreTartaruga("La tartaruga uscirebbe troppo lontano dal foglio.",
                                  "Usa numeri più piccoli, oppure `casa()` per tornare al centro.")
        if (nx, ny) != (self.x, self.y):
            self._aggiungi(Tratto(self.x, self.y, nx, ny, self.colore, self.spessore,
                                  self.penna_giu, self.velocita))
            if self.colore_riempimento is not None:
                self.punti_riempimento.append((nx, ny))
        self.x, self.y = nx, ny

    # ------------------------------------------------------------- movimento
    def avanti(self, passi: Any) -> None:
        p = numero_valido(passi, "passi")
        rad = math.radians(self.direzione)
        self._vai(self.x + p * math.cos(rad), self.y + p * math.sin(rad))

    def indietro(self, passi: Any) -> None:
        self.avanti(-numero_valido(passi, "passi"))

    def destra(self, gradi: Any = 90) -> None:
        self.direzione = _arrotonda((self.direzione - numero_valido(gradi, "gradi")) % 360)

    def sinistra(self, gradi: Any = 90) -> None:
        self.direzione = _arrotonda((self.direzione + numero_valido(gradi, "gradi")) % 360)

    def punta_verso(self, gradi: Any) -> None:
        self.direzione = _arrotonda(numero_valido(gradi, "gradi") % 360)

    def vai_a(self, x: Any, y: Any) -> None:
        self._vai(numero_valido(x, "x"), numero_valido(y, "y"))

    def casa(self) -> None:
        """Torna al centro guardando in alto, senza disegnare."""
        penna = self.penna_giu
        self.penna_giu = False
        try:
            self._vai(0.0, 0.0)
        finally:
            self.penna_giu = penna
        self.direzione = 90.0

    def cerchio(self, raggio: Any, gradi: Any = 360) -> None:
        """Cerchio (o arco) con il centro a sinistra della tartaruga (a destra se raggio < 0)."""
        r = numero_valido(raggio, "raggio")
        g = numero_valido(gradi, "gradi")
        if r == 0 or g == 0:
            return
        g = max(-3600.0, min(3600.0, g))
        lati_giro = max(24, min(180, int(abs(r) / 2)))         # lati per un giro completo
        lati = max(4, int(round(lati_giro * abs(g) / 360)))
        passo_angolo = g / lati
        lato = 2 * abs(r) * math.sin(math.radians(abs(passo_angolo)) / 2)
        verso = 1 if r > 0 else -1
        if g < 0:
            lato = -lato
        # come il Logo: mezzo giro, lato, mezzo giro... così la figura si chiude
        self.direzione += verso * passo_angolo / 2
        for _ in range(lati):
            rad = math.radians(self.direzione)
            self._vai(self.x + lato * math.cos(rad), self.y + lato * math.sin(rad))
            self.direzione += verso * passo_angolo
        self.direzione = _arrotonda((self.direzione - verso * passo_angolo / 2) % 360)

    # ------------------------------------------------------------------ penna
    def penna_su(self) -> None:
        self.penna_giu = False

    def penna_giu_(self) -> None:
        self.penna_giu = True

    def imposta_colore(self, valore: Any) -> str:
        self.colore = normalizza_colore_tartaruga(valore)
        return self.colore

    def imposta_spessore(self, valore: Any) -> None:
        v = numero_valido(valore, "spessore")
        if v <= 0 or v > 500:
            raise ErroreTartaruga("Lo spessore deve essere tra 1 e 500.", "Prova con `spessore(5)`.")
        self.spessore = v

    def imposta_velocita(self, valore: Any) -> None:
        v = numero_valido(valore, "velocità")
        if v < 0 or v > 10:
            raise ErroreTartaruga("La velocità va da 1 (lentissima) a 10 (velocissima); 0 = subito.",
                                  "Prova con `velocità(7)`.")
        self.velocita = int(round(v))

    def imposta_sfondo(self, valore: Any) -> None:
        self.sfondo = normalizza_colore_tartaruga(valore)

    @property
    def sfondo_scelto(self) -> bool:
        """Vero se il programma ha scelto uno sfondo con ``sfondo(...)``."""
        return bool(self.sfondo)

    @property
    def sfondo_foglio(self) -> str:
        """Colore del foglio da usare nei file (bianco se il programma non ne ha scelto uno)."""
        return self.sfondo or SFONDO_FOGLIO_PREDEFINITO

    # ------------------------------------------------------------ riempimento
    def inizia_riempimento(self, colore: Any = None) -> None:
        if self.colore_riempimento is not None:
            self.finisci_riempimento()
        self.colore_riempimento = self.colore if colore is None else normalizza_colore_tartaruga(colore)
        self.punti_riempimento = [(self.x, self.y)]

    def finisci_riempimento(self) -> bool:
        """Chiude il riempimento in corso; vero se ha colorato qualcosa."""
        colore, punti = self.colore_riempimento, self.punti_riempimento
        self.colore_riempimento, self.punti_riempimento = None, []
        if colore is None or len(punti) < 3:
            return False
        # la macchia va SOTTO i tratti che l'hanno disegnata: la inserisco prima di loro
        n_tratti = len(punti) - 1
        indice = len(self.elementi)
        contati = 0
        while indice > 0 and contati < n_tratti:
            indice -= 1
            if isinstance(self.elementi[indice], Tratto):
                contati += 1
        if len(self.elementi) >= LIMITE_ELEMENTI:
            raise ErroreTartaruga("Il disegno ha troppi elementi: il limite è 200.000.")
        self.elementi.insert(indice, Macchia(list(punti), colore, self.velocita))
        return True

    # ------------------------------------------------------------------- altro
    def scrivi_qui(self, testo: str, dimensione: Any = 16) -> None:
        d = numero_valido(dimensione, "dimensione")
        if d <= 0 or d > 1000:
            raise ErroreTartaruga("La dimensione del testo deve essere tra 1 e 1000.")
        self._aggiungi(Scritta(self.x, self.y, testo, self.colore, d, self.velocita))

    def pulisci(self) -> None:
        """Cancella il disegno (la tartaruga resta dov'è)."""
        self.elementi.clear()
        self.colore_riempimento, self.punti_riempimento = None, []

    # --------------------------------------------------------------------- SVG
    def limiti(self) -> tuple[float, float, float, float]:
        """(x minima, y minima, x massima, y massima) del disegno e della tartaruga."""
        xs, ys = [self.x], [self.y]
        for e in self.elementi:
            if isinstance(e, Tratto):
                if e.penna:
                    xs += [e.x1, e.x2]
                    ys += [e.y1, e.y2]
            elif isinstance(e, Macchia):
                xs += [p[0] for p in e.punti]
                ys += [p[1] for p in e.punti]
            else:
                xs += [e.x, e.x + len(e.testo) * e.dimensione * 0.6]
                ys += [e.y, e.y + e.dimensione]
        return min(xs), min(ys), max(xs), max(ys)

    def svg(self, margine: float = 20.0) -> str:
        """Il disegno come immagine SVG (y verso l'alto, come nella finestra)."""
        x0, y0, x1, y1 = self.limiti()
        spess = max([e.spessore for e in self.elementi if isinstance(e, Tratto)] + [self.spessore])
        m = margine + spess
        larghezza = max(1.0, x1 - x0) + 2 * m
        altezza = max(1.0, y1 - y0) + 2 * m

        def px(x: float) -> str:
            return _num(x - x0 + m)

        def py(y: float) -> str:
            return _num(y1 - y + m)

        righe = [
            '<?xml version="1.0" encoding="UTF-8"?>',
            f'<svg xmlns="http://www.w3.org/2000/svg" width="{_num(larghezza)}" height="{_num(altezza)}" '
            f'viewBox="0 0 {_num(larghezza)} {_num(altezza)}">',
            "  <title>Disegno della tartaruga di Leo</title>",
            f'  <rect width="100%" height="100%" fill="{self.sfondo_foglio}"/>',
        ]
        for e in self.elementi:
            if isinstance(e, Tratto):
                if e.penna:
                    righe.append(f'  <line x1="{px(e.x1)}" y1="{py(e.y1)}" x2="{px(e.x2)}" y2="{py(e.y2)}" '
                                 f'stroke="{e.colore}" stroke-width="{_num(e.spessore)}" '
                                 'stroke-linecap="round"/>')
            elif isinstance(e, Macchia):
                punti = " ".join(f"{px(x)},{py(y)}" for x, y in e.punti)
                righe.append(f'  <polygon points="{punti}" fill="{e.colore}" stroke="none"/>')
            else:
                righe.append(f'  <text x="{px(e.x)}" y="{py(e.y)}" fill="{e.colore}" '
                             f'font-size="{_num(e.dimensione)}" font-family="sans-serif">'
                             f'{_escape_xml(e.testo)}</text>')
        if self.visibile:
            punti = " ".join(f"{px(x)},{py(y)}" for x, y in forma_tartaruga(self.x, self.y, self.direzione))
            righe.append(f'  <polygon points="{punti}" fill="#2E7D32" stroke="#1B5E20" stroke-width="1"/>')
        righe.append("</svg>")
        return "\n".join(righe) + "\n"

    def salva_svg(self, percorso: str | os.PathLike) -> str:
        with open(percorso, "w", encoding="utf-8") as f:
            f.write(self.svg())
        self.elementi_salvati = len(self.elementi)
        return os.fspath(percorso)


def _num(v: float) -> str:
    testo = f"{v:.2f}".rstrip("0").rstrip(".")
    return "0" if testo in ("-0", "") else testo


def forma_tartaruga(x: float, y: float, direzione: float, grandezza: float = 10.0) -> list[tuple[float, float]]:
    """Triangolo (la "tartaruga") con la punta nella direzione in cui guarda."""
    punti = []
    for angolo, dist in ((0, grandezza * 1.4), (140, grandezza), (220, grandezza)):
        rad = math.radians(direzione + angolo)
        punti.append((x + dist * math.cos(rad), y + dist * math.sin(rad)))
    return punti


# ---------------------------------------------------------------------------
# Animazione (logica pura)
# ---------------------------------------------------------------------------

def passi_per_fotogramma(velocita: int) -> float:
    """Quanti passi percorre la tartaruga in un fotogramma (circa 60 al secondo)."""
    if velocita <= 0:
        return math.inf
    return float(velocita * velocita * 2)


def parti_visibili(elementi: list, distanza: float) -> tuple[list, Any, tuple[float, float] | None, bool]:
    """Cosa si vede dopo che la tartaruga ha percorso ``distanza`` passi.

    Restituisce ``(elementi_completi, tratto_parziale, punta, finito)``:
    ``tratto_parziale`` è un :class:`Tratto` accorciato (o None), ``punta`` è
    dove si trova la tartaruga (None se non si è ancora mossa), ``finito`` è
    vero quando tutto il disegno è visibile. Macchie e scritte non costano
    distanza; i tratti con velocità 0 nemmeno.
    """
    completi: list = []
    punta: tuple[float, float] | None = None
    resto = distanza
    for i, e in enumerate(elementi):
        if isinstance(e, Tratto):
            costo = 0.0 if e.velocita <= 0 else e.lunghezza
            if costo > resto:
                t = resto / costo if costo else 1.0
                parziale = Tratto(e.x1, e.y1, e.x1 + (e.x2 - e.x1) * t, e.y1 + (e.y2 - e.y1) * t,
                                  e.colore, e.spessore, e.penna, e.velocita)
                return completi, parziale, (parziale.x2, parziale.y2), False
            resto -= costo
            punta = (e.x2, e.y2)
        completi.append(e)
    return completi, None, punta, True


# ---------------------------------------------------------------------------
# Collegamento con l'interprete e la riga di comando
# ---------------------------------------------------------------------------

_ATTRIBUTO = "_tartaruga_dante"
#: tartarughe create dall'ultimo ``concludi_programma`` (in ordine)
_IN_ATTESA: list[Tartaruga] = []


def tartaruga_di(interprete: Any, crea: bool = True) -> Tartaruga | None:
    """La tartaruga dell'interprete (creata al primo uso)."""
    t = getattr(interprete, _ATTRIBUTO, None)
    if t is None and crea:
        t = Tartaruga()
        try:
            setattr(interprete, _ATTRIBUTO, t)
        except (AttributeError, TypeError):
            pass
        _IN_ATTESA.append(t)
    return t


def scarta(tartaruga: Tartaruga | None) -> None:
    """Dimentica una tartaruga: a fine programma non verrà mostrata."""
    while tartaruga in _IN_ATTESA:
        _IN_ATTESA.remove(tartaruga)


def scarta_tutte() -> None:
    _IN_ATTESA.clear()


def pyside6_presente() -> bool:
    import importlib.util

    try:
        return importlib.util.find_spec("PySide6") is not None
    except (ImportError, ValueError):
        return False


def modalita_finestra() -> bool:
    """Vero se il disegno va mostrato in una finestra (PySide6 e niente LEO_TARTARUGA=testo).

    Su Android mai: il disegno si salva in SVG nella cartella di lavoro (i programmi dell'app).
    """
    if (variabile_ambiente("TARTARUGA") or "").strip().lower() in ("testo", "svg", "no"):
        return False
    from .piattaforma import e_android

    if e_android():
        return False
    return pyside6_presente()


def nome_svg(nome_programma: str | os.PathLike | None) -> str:
    """``casa.leo`` -> ``casa.svg`` (``disegno.svg`` se il nome manca)."""
    if not nome_programma:
        return "disegno.svg"
    base = os.path.splitext(os.fspath(nome_programma))[0]
    if not os.path.basename(base) or base.startswith("<"):
        return "disegno.svg"
    return base + ".svg"


def mostra_finestra(tartaruga: Tartaruga, titolo: str = "La tartaruga di Leo") -> bool:
    """Apre la finestra animata (blocca finché non si chiude). Falso se non è possibile."""
    try:
        from .grafica.qt.tartaruga_qt import mostra_disegno
    except ImportError:
        return False
    try:
        mostra_disegno(tartaruga, titolo)
    except ImportError:
        return False
    tartaruga.elementi_mostrati = len(tartaruga.elementi)
    return True


def concludi_programma(nome_programma: str | os.PathLike | None = None,
                       uscita: Callable[[str], None] | None = None,
                       *, finestra: bool | None = None) -> str | None:
    """A fine programma mostra (o salva in SVG) i disegni non ancora mostrati.

    Restituisce il percorso dell'SVG salvato, se ce n'è uno. ``uscita`` riceve
    i messaggi per l'utente (predefinito: ``print``).
    """
    scrivi = uscita or (lambda testo: print(testo, flush=True))
    salvato = None
    # un programma = una tartaruga: le precedenti (tentativi falliti) si dimenticano
    attese = _IN_ATTESA[-1:]
    _IN_ATTESA.clear()
    usa_finestra = modalita_finestra() if finestra is None else finestra
    for t in attese:
        if t.colore_riempimento is not None:
            t.finisci_riempimento()
        if not t.elementi:
            continue
        n = len(t.elementi)
        if usa_finestra and (t.mostra_richiesto or t.elementi_mostrati != n):
            if mostra_finestra(t, f"La tartaruga di Leo - {os.path.basename(nome_svg(nome_programma))}"):
                continue
        if t.elementi_salvati == n or t.elementi_mostrati == n:
            continue
        percorso = nome_svg(nome_programma)
        try:
            t.salva_svg(percorso)
        except OSError as e:
            scrivi(f"Non sono riuscito a salvare il disegno in {percorso}: {e.strerror or e}.")
            continue
        salvato = percorso
        scrivi(f"Disegno salvato in \"{percorso}\" (si apre con il browser).")
    return salvato
