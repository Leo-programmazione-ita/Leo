"""Formattazione dei messaggi di errore in quattro parti (docs/CONTRATTI.md §8.1).

Formato (righe vuote tra le parti)::

    ErroreNome alla riga 7, colonna 11 di voti.leo

        7 |     stampa(tottale)
          |            ^^^^^^^

    `tottale` non è definito.
    Suggerimento: forse intendevi `totale` (definito alla riga 3)?

Varianti:

- senza posizione (``riga == 0``): ``ErroreNome in voti.leo`` e niente riga
  di codice;
- senza sorgente (o riga oltre la fine del sorgente): niente riga di codice;
- senza suggerimento: niente ultima riga;
- nome del file sconosciuto (``""`` o ``"<sorgente>"``): l'intestazione non
  nomina il file (``ErroreNome alla riga 7, colonna 11``);
- errore nato dentro una o piu' funzioni: in fondo la sezione
  ``Chiamate (dalla più recente):`` con ``file:riga`` e funzione di ogni
  passo, fino al programma principale (vedi :mod:`leo.pila`).

Con ``colori=True`` si usano sequenze ANSI prese dal tema (``leo.temi``) e
la riga di codice viene colorata con ``leo.colorazione.ansi``. Entrambi i
moduli sono importati in modo protetto: se mancano, non sono ancora pronti o
sollevano un'eccezione, si ripiega sul testo puro (o su colori di riserva).

API:
    formatta_errore(errore, sorgente=None, *, tema=None, colori=False) -> str
    riga_con_indicatore(sorgente, riga, colonna, lunghezza=1) -> str
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:  # pragma: no cover - solo per i tipi
    from .errori import ErroreDante

__all__ = ["formatta_errore", "riga_con_indicatore", "intestazione", "NOMI_FILE_ANONIMI"]

#: Nomi di file che non vengono mostrati nell'intestazione.
NOMI_FILE_ANONIMI: frozenset[str] = frozenset({"", "<sorgente>"})

#: Rientro prima del numero di riga nella riga di codice.
_RIENTRO = "    "

_ANSI_RESET_RISERVA = "\x1b[0m"


# ---------------------------------------------------------------------------
# Testo puro
# ---------------------------------------------------------------------------

def _righe(sorgente: str) -> list[str]:
    """Righe del sorgente senza terminatori (gestisce ``\\r\\n`` e ``\\r``)."""
    if sorgente.startswith("﻿"):
        sorgente = sorgente[1:]
    return sorgente.replace("\r\n", "\n").replace("\r", "\n").split("\n")


def _testo_riga(sorgente: str | None, riga: int) -> str | None:
    """Testo della riga ``riga`` (1-based) o None se non disponibile."""
    if sorgente is None or riga < 1:
        return None
    righe = _righe(sorgente)
    if riga > len(righe):
        return None
    return righe[riga - 1]


def _parti_indicatore(testo: str, colonna: int, lunghezza: int) -> tuple[str, str]:
    """Spaziatura prima dei ``^`` e i ``^`` stessi.

    Le tabulazioni del codice prima della colonna vengono copiate tali e quali
    nella spaziatura, cosi' i ``^`` restano allineati anche con i tab.
    La lunghezza e' limitata alla fine della riga (minimo un ``^``).
    """
    colonna = max(1, colonna)
    prima = testo[: colonna - 1]
    spazi = "".join("\t" if c == "\t" else " " for c in prima)
    if len(prima) < colonna - 1:  # colonna oltre la fine della riga
        spazi += " " * (colonna - 1 - len(prima))
    disponibili = len(testo) - (colonna - 1)
    n = max(1, lunghezza)
    if disponibili >= 1:
        n = min(n, disponibili)
    else:
        n = 1
    return spazi, "^" * n


def riga_con_indicatore(sorgente: str, riga: int, colonna: int, lunghezza: int = 1) -> str:
    """Le due righe centrali del messaggio: codice numerato e indicatore ``^``.

    Esempio (``riga=7, colonna=11, lunghezza=7``)::

            7 |     stampa(tottale)
              |            ^^^^^^^

    Se la riga non esiste nel sorgente restituisce ``""``. Con ``colonna``
    0 (sconosciuta) mostra solo la riga di codice, senza indicatore.
    """
    testo = _testo_riga(sorgente, riga)
    if testo is None:
        return ""
    numero = str(riga)
    vuoto = " " * len(numero)
    prima = f"{_RIENTRO}{numero} | {testo}".rstrip()
    if colonna < 1:
        return prima
    spazi, cappelli = _parti_indicatore(testo, colonna, lunghezza)
    return f"{prima}\n{_RIENTRO}{vuoto} | {spazi}{cappelli}"


def intestazione(errore: Any) -> str:
    """Prima riga: tipo, posizione e file."""
    tipo = _tipo(errore)
    nome_file = getattr(errore, "nome_file", "") or ""
    riga = _intero(getattr(errore, "riga", 0))
    colonna = _intero(getattr(errore, "colonna", 0))
    con_file = nome_file not in NOMI_FILE_ANONIMI
    if riga > 0:
        pos = f"alla riga {riga}"
        if colonna > 0:
            pos += f", colonna {colonna}"
        return f"{tipo} {pos} di {nome_file}" if con_file else f"{tipo} {pos}"
    return f"{tipo} in {nome_file}" if con_file else tipo


def _tipo(errore: Any) -> str:
    tipo = getattr(errore, "tipo", None)
    return tipo if isinstance(tipo, str) and tipo else type(errore).__name__


def _intero(v: Any) -> int:
    try:
        return int(v or 0)
    except (TypeError, ValueError):
        return 0


def _messaggio(errore: Any) -> str:
    m = getattr(errore, "messaggio", None)
    if m is None:
        m = str(errore)
    return str(m)


_SCRIVI_AL_POSTO = None


def _suggerimento(errore: Any, sorgente: str | None) -> str | None:
    """Il suggerimento dell'errore, reso piu' preciso guardando la riga: per il
    tipo di controllo scritto al posto del nome (``etichetta.testo``) la frase
    "Scrivi `Etichetta1` al posto di `etichetta`." diventa "Scrivi `Etichetta1.testo`."."""
    suggerimento = getattr(errore, "suggerimento", None)
    if not suggerimento or not sorgente:
        return suggerimento
    try:
        import re

        global _SCRIVI_AL_POSTO
        if _SCRIVI_AL_POSTO is None:
            _SCRIVI_AL_POSTO = re.compile(r"Scrivi `(\w+)` al posto di `(\w+)`\.$")
        m = _SCRIVI_AL_POSTO.search(suggerimento)
        riga = _intero(getattr(errore, "riga", 0))
        colonna = _intero(getattr(errore, "colonna", 0))
        testo = _testo_riga(sorgente, riga) if m and riga > 0 and colonna > 0 else None
        if not m or testo is None:
            return suggerimento
        giusto, scritto = m.group(1), m.group(2)
        dopo = re.match(re.escape(scritto) + r"\s*\.\s*(\w+)", testo[colonna - 1:])
        if not dopo:
            return suggerimento
        return suggerimento[:m.start()] + f"Scrivi `{giusto}.{dopo.group(1)}`."
    except Exception:  # noqa: BLE001 - mai perdere il suggerimento originale
        return suggerimento


def _formatta_puro(errore: Any, sorgente: str | None) -> str:
    parti = [intestazione(errore)]
    riga = _intero(getattr(errore, "riga", 0))
    if riga > 0 and sorgente is not None:
        codice = riga_con_indicatore(
            sorgente, riga, _intero(getattr(errore, "colonna", 0)),
            max(1, _intero(getattr(errore, "lunghezza", 1))))
        if codice:
            parti.append(codice)
    finale = _messaggio(errore)
    suggerimento = _suggerimento(errore, sorgente)
    if suggerimento:
        finale += f"\nSuggerimento: {suggerimento}"
    parti.append(finale)
    pila = _sezione_pila(errore)
    if pila:
        parti.append(pila)
    return "\n\n".join(parti)


def _sezione_pila(errore: Any, pennello: Any = None, colore: str | None = None) -> str | None:
    """La sezione "Chiamate (dalla più recente):" (None se l'errore e' nato al
    livello principale o la pila non c'e')."""
    try:
        from .pila import righe_pila

        righe = righe_pila(errore)
    except Exception:  # noqa: BLE001 - la pila e' solo un aiuto in piu'
        return None
    if not righe:
        return None
    if pennello is not None:
        righe[0] = pennello.colora(righe[0], colore, True)
    return "\n".join(righe)


# ---------------------------------------------------------------------------
# Colori ANSI (import protetti)
# ---------------------------------------------------------------------------

def _hex_in_rgb(colore: str) -> tuple[int, int, int] | None:
    c = str(colore).strip().lstrip("#")
    if len(c) == 3:
        c = "".join(x * 2 for x in c)
    if len(c) not in (6, 8):
        return None
    try:
        return int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)
    except ValueError:
        return None


class _Pennello:
    """Produce le sequenze ANSI, dal modulo temi se c'e', altrimenti da se'."""

    def __init__(self, temi_mod: Any) -> None:
        self.temi = temi_mod
        reset = getattr(temi_mod, "ANSI_RESET", None) if temi_mod else None
        self.reset = reset if isinstance(reset, str) and reset else _ANSI_RESET_RISERVA

    def codice(self, colore: str | None, grassetto: bool = False) -> str:
        if not colore:
            return "\x1b[1m" if grassetto else ""
        if self.temi is not None:
            try:
                stile = self.temi.StileCategoria(colore=colore, grassetto=grassetto)
                codice = self.temi.codice_ansi(stile)
                if isinstance(codice, str):
                    return codice
            except Exception:  # noqa: BLE001 - temi incompleto: ripiego
                pass
        rgb = _hex_in_rgb(colore)
        if rgb is None:
            return "\x1b[1m" if grassetto else ""
        pre = "1;" if grassetto else ""
        return f"\x1b[{pre}38;2;{rgb[0]};{rgb[1]};{rgb[2]}m"

    def colora(self, testo: str, colore: str | None, grassetto: bool = False) -> str:
        codice = self.codice(colore, grassetto)
        return f"{codice}{testo}{self.reset}" if codice else testo


def _importa_temi() -> Any:
    try:
        from . import temi  # type: ignore[attr-defined]
    except Exception:  # noqa: BLE001
        return None
    return temi


def _carica_tema_predefinito(temi_mod: Any) -> Any:
    if temi_mod is None:
        return None
    try:
        return temi_mod.carica_tema("nero")
    except Exception:  # noqa: BLE001
        return None


def _codice_colorato(testo: str, tema: Any) -> str | None:
    """Riga di codice colorata con ``colorazione.ansi`` o None se non si puo'."""
    if tema is None:
        return None
    try:
        from . import colorazione  # type: ignore[attr-defined]
        risultato = colorazione.ansi(testo, tema)
    except Exception:  # noqa: BLE001 - colorazione non pronta o in errore
        return None
    if not isinstance(risultato, str):
        return None
    return risultato.rstrip("\n")


def _formatta_colori(errore: Any, sorgente: str | None, tema: Any) -> str:
    temi_mod = _importa_temi()
    if tema is None:
        tema = _carica_tema_predefinito(temi_mod)
    p = _Pennello(temi_mod)
    col_errore = getattr(tema, "errore", None) or "#ff5f5f"
    col_numeri = getattr(tema, "numeri_riga", None) or "#808080"
    col_avviso = getattr(tema, "avviso", None) or "#ffd75f"

    parti = [p.colora(_tipo(errore), col_errore, grassetto=True)
             + intestazione(errore)[len(_tipo(errore)):]]

    riga = _intero(getattr(errore, "riga", 0))
    testo = _testo_riga(sorgente, riga) if riga > 0 else None
    if testo is not None:
        colonna = _intero(getattr(errore, "colonna", 0))
        numero = str(riga)
        vuoto = " " * len(numero)
        codice = _codice_colorato(testo, tema)
        if codice is None:
            codice = testo
        barra = p.colora("|", col_numeri)
        prima = f"{_RIENTRO}{p.colora(numero, col_numeri)} {barra} {codice}".rstrip()
        if colonna >= 1:
            spazi, cappelli = _parti_indicatore(
                testo, colonna, max(1, _intero(getattr(errore, "lunghezza", 1))))
            prima += f"\n{_RIENTRO}{vuoto} {barra} {spazi}{p.colora(cappelli, col_errore, True)}"
        parti.append(prima)

    finale = _messaggio(errore)
    suggerimento = _suggerimento(errore, sorgente)
    if suggerimento:
        finale += f"\n{p.colora('Suggerimento:', col_avviso, True)} {suggerimento}"
    parti.append(finale)
    pila = _sezione_pila(errore, p, col_numeri)
    if pila:
        parti.append(pila)
    return "\n\n".join(parti)


# ---------------------------------------------------------------------------
# API pubblica
# ---------------------------------------------------------------------------

def formatta_errore(errore: "ErroreDante", sorgente: str | None = None, *,
                    tema: Any = None, colori: bool = False) -> str:
    """Messaggio completo in quattro parti (vedi il docstring del modulo).

    ``errore`` e' un :class:`leo.errori.ErroreDante` (basta un oggetto con
    ``tipo``, ``messaggio``, ``riga``, ``colonna``, ``suggerimento``,
    ``nome_file``, ``lunghezza``). ``sorgente`` e' il testo completo del file.
    Con ``colori=True`` il risultato contiene sequenze ANSI; se i moduli dei
    colori non sono disponibili si ottiene comunque un messaggio leggibile.
    """
    try:
        from .forme_parlate import migliora_errore

        migliora_errore(errore, sorgente)   # forme a parole, testo + numero, `x = 5`...
    except ImportError:  # pragma: no cover
        pass
    if colori:
        try:
            return _formatta_colori(errore, sorgente, tema)
        except Exception:  # noqa: BLE001 - mai perdere il messaggio per i colori
            pass
    return _formatta_puro(errore, sorgente)
