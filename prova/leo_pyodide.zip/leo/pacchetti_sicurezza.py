"""Controlli di sicurezza del gestore di pacchetti (``leo aggiungi``).

* :func:`nome_sospetto` - avviso sui nomi molto simili a pacchetti famosi
  (``reqeusts``, ``python-requests``, ``nurnpy``...): è il trucco più comune per
  far installare un pacchetto malevolo al posto di quello giusto.
* :func:`impronta_file` / :func:`impronta_cartella` - impronte sha256.
* :func:`controlla_impronta` - confronto obbligatorio con quella del blocco.
"""

from __future__ import annotations

import hashlib
import os
import re
from pathlib import Path

#: Pacchetti Python molto usati (nomi normalizzati come PEP 503). Chi ne scrive uno
#: quasi uguale riceve un avviso e deve confermare.
FAMOSI_PYTHON = frozenset("""
requests numpy pandas urllib3 setuptools certifi idna charset-normalizer python-dateutil pyyaml boto3 botocore
typing-extensions packaging wheel pip cryptography jinja2 markupsafe attrs click pydantic flask django fastapi
uvicorn sqlalchemy pillow matplotlib scipy scikit-learn tensorflow torch keras opencv-python beautifulsoup4 lxml
selenium pytest colorama tqdm rich psutil pyjwt paramiko pycryptodome aiohttp httpx websockets protobuf grpcio
redis pymongo psycopg2 psycopg2-binary mysql-connector-python openpyxl xlrd docutils pygments sympy networkx nltk
transformers openai anthropic discord-py python-telegram-bot tweepy pyserial pyusb pygame arcade kivy pyqt5
pyside6 streamlit plotly seaborn bokeh dash numba cython joblib pyarrow polars h5py statsmodels xgboost lightgbm
catboost gunicorn celery scrapy playwright pyautogui pynput keyboard pywin32 wxpython reportlab pypdf pypdf2
pymupdf python-docx python-pptx markdown toml tomli orjson ujson simplejson msgpack python-dotenv loguru typer
arrow pendulum pytz tzdata babel faker hypothesis coverage black flake8 mypy pylint isort ruff virtualenv poetry
pipenv twine requests-oauthlib oauthlib google-auth google-api-python-client azure-core awscli s3transfer
jmespath pyasn1 rsa cffi pycparser wrapt decorator chardet pyparsing filelock platformdirs distlib zipp
importlib-metadata multidict yarl frozenlist greenlet gevent werkzeug itsdangerous jsonschema regex
scikit-image imageio shapely geopandas folium pyproj pyopenssl pynacl bcrypt passlib qrcode pyzmq tornado
dask trio anyio sniffio h11 httpcore textual fabric invoke pika kafka-python mock nose pyglet panda3d pymunk
ursina bleak tabulate xlsxwriter pyinstaller nuitka pywebview flet nicegui gradio jupyter notebook ipython
ipykernel peewee alembic marshmallow emoji unidecode pexpect sh tox nox pyperclip pyttsx3 speechrecognition
""".split())

#: Prefissi e suffissi aggiunti ai nomi famosi per confondere.
_AGGIUNTE = ("python-", "py-", "py", "-python", "-py", "python3-", "-dev", "-lib", "lib-")


def normalizza(nome: str) -> str:
    """Nome normalizzato (PEP 503): minuscolo, ``-`` al posto di ``_`` e ``.``."""
    return re.sub(r"[-_.]+", "-", nome.strip()).lower()


def distanza(a: str, b: str) -> int:
    """Distanza di Damerau-Levenshtein (scambio di due lettere vicine = 1)."""
    if a == b:
        return 0
    la, lb = len(a), len(b)
    if abs(la - lb) > 2:
        return 3
    d = [[0] * (lb + 1) for _ in range(la + 1)]
    for i in range(la + 1):
        d[i][0] = i
    for j in range(lb + 1):
        d[0][j] = j
    for i in range(1, la + 1):
        for j in range(1, lb + 1):
            costo = 0 if a[i - 1] == b[j - 1] else 1
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + costo)
            if i > 1 and j > 1 and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                d[i][j] = min(d[i][j], d[i - 2][j - 2] + 1)
    return d[la][lb]


def _sembianze(nome: str) -> str:
    """Lettere che si somigliano a colpo d'occhio, ricondotte a una sola forma."""
    return nome.replace("rn", "m").replace("vv", "w").replace("0", "o").replace("1", "l").replace("5", "s")


def nome_sospetto(nome: str, famosi: frozenset[str] | set[str] = FAMOSI_PYTHON) -> str | None:
    """Il nome famoso a cui ``nome`` assomiglia troppo (None se il nome va bene)."""
    n = normalizza(nome)
    if n in famosi or len(n) < 4:
        return None
    for aggiunta in _AGGIUNTE:
        if aggiunta.endswith("-") or (aggiunta == "py"):
            ridotto = n[len(aggiunta):] if n.startswith(aggiunta) else None
        else:
            ridotto = n[:-len(aggiunta)] if n.endswith(aggiunta) else None
        if ridotto and ridotto in famosi:
            return ridotto
    simile = _sembianze(n)
    for f in sorted(famosi):
        if len(f) < 4:
            continue
        if simile == _sembianze(f):
            return f
        soglia = 1 if len(f) <= 6 else 2
        if distanza(n, f) <= soglia:
            return f
    return None


def impronta_file(percorso: str | os.PathLike) -> str:
    """sha256 esadecimale del contenuto di un file."""
    h = hashlib.sha256()
    with open(percorso, "rb") as f:
        for pezzo in iter(lambda: f.read(1 << 20), b""):
            h.update(pezzo)
    return h.hexdigest()


def impronta_cartella(cartella: str | os.PathLike) -> str:
    """sha256 di una cartella: nomi relativi e contenuti di tutti i file, in ordine."""
    base = Path(cartella)
    h = hashlib.sha256()
    for p in sorted(base.rglob("*")):
        if p.is_dir() or "__pycache__" in p.parts:
            continue
        rel = p.relative_to(base).as_posix()
        h.update(rel.encode("utf-8") + b"\0" + impronta_file(p).encode("ascii") + b"\n")
    return h.hexdigest()


def controlla_impronta(attesa: str, trovata: str, cosa: str) -> None:
    """ErrorePacchetti se le due impronte sono diverse (o se manca quella attesa)."""
    from .pacchetti import ErrorePacchetti

    if not attesa or not re.fullmatch(r"[0-9a-f]{64}", attesa):
        raise ErrorePacchetti(f"{cosa}: manca l'impronta sha256 nel blocco: non installo nulla senza impronta.",
                              suggerimento="Ricrea il blocco con `leo aggiungi` o `leo sincronizza --aggiorna`.")
    if attesa != trovata:
        raise ErrorePacchetti(
            f"{cosa}: l'impronta sha256 non corrisponde a quella di `leo.lock`.\n"
            f"  attesa:  {attesa}\n  trovata: {trovata}\n"
            "Il file è stato cambiato dopo che il blocco è stato creato: potrebbe essere stato manomesso.",
            suggerimento="Se il cambiamento è voluto (per esempio un tuo pacchetto locale modificato), "
                         "aggiungilo di nuovo con `leo aggiungi` per accettare la nuova impronta.")
