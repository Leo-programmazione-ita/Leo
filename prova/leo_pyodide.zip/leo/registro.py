"""Registro delle funzioni, dei metodi e delle costanti predefinite - CONTRATTO CONDIVISO.

I moduli di ``leo/libreria/`` si registrano con i decoratori; l'interprete
costruisce l'ambiente predefinito con :func:`crea_ambiente_predefinito`.

Esempio (in ``leo/libreria/matematica.py``)::

    from ..registro import funzione, metodo, costante

    @funzione("assoluto")
    def assoluto(x):
        ...

    @funzione("stampa", interprete=True)
    def stampa(interprete, *valori, separatore=" "):
        interprete.scrivi(...)

    @metodo("lista", "aggiungi")
    def lista_aggiungi(lista, elemento):   # primo parametro = oggetto
        lista.append(elemento)

    costante("PI_GRECO", math.pi)

Regole:
  * i nomi dei parametri Python sono quelli visibili da Leo per gli
    argomenti per nome, quindi in italiano;
  * gli errori si segnalano sollevando le classi di ``leo.errori`` SENZA
    posizione; mai eccezioni Python generiche verso l'utente;
  * le funzioni restituiscono sempre valori Leo (vedi ``leo.valori``);
    ``None`` = ``nulla``;
  * per chiamare una funzione Leo ricevuta come argomento (es. chiave di
    ordinamento): ``interprete.chiama(f, [argomenti])`` (serve ``interprete=True``).
"""

from __future__ import annotations

import sys
from typing import Any, Callable, Iterable

from . import permessi as _permessi
from .valori import FunzioneNativa

#: nome -> FunzioneNativa (funzioni globali: stampa, lunghezza, messaggio, ...)
FUNZIONI: dict[str, FunzioneNativa] = {}
#: nome_tipo Leo ("testo", "lista", "dizionario", ...) -> nome metodo -> FunzioneNativa
METODI: dict[str, dict[str, FunzioneNativa]] = {}
#: nome -> valore (PI_GRECO, ...)
COSTANTI: dict[str, Any] = {}


def funzione(nome: str | None = None, *, interprete: bool = False) -> Callable:
    """Decoratore: registra una funzione globale di libreria."""

    def decora(f: Callable) -> Callable:
        n = nome or f.__name__
        inserisci(FUNZIONI, None, n, FunzioneNativa(n, f, vuole_interprete=interprete))
        return f

    return decora


def metodo(tipo: str, nome: str | None = None, *, interprete: bool = False) -> Callable:
    """Decoratore: registra un metodo per un tipo Leo (``"testo"``, ``"lista"``...).

    La funzione Python riceve (eventuale interprete, poi) l'oggetto come primo argomento.
    """

    def decora(f: Callable) -> Callable:
        n = nome or f.__name__
        inserisci(METODI.setdefault(tipo, {}), tipo, n,
                  FunzioneNativa(n, f, vuole_interprete=interprete, e_metodo=True))
        return f

    return decora


# ---------------------------------------------------------------------------
# Moduli della libreria caricati alla prima chiamata
# ---------------------------------------------------------------------------
#
# I moduli "pesanti" della libreria (internet, sistema, suoni...) non si
# importano all'avvio: ``leo.libreria`` mette nei registri, al loro posto, un
# :class:`_Segnaposto` per ogni funzione (nomi e opzioni presi dall'indice
# generato ``leo/libreria/_indice.py``). Chi elenca i nomi (suggerimenti,
# colorazione, documentazione) li vede tutti, nello stesso ordine di prima.
# Alla prima lettura di ``funzione``, ``firma``, ``descrizione``... il
# segnaposto importa il suo modulo; le registrazioni del modulo *riempiono*
# il segnaposto (stessa identita': gli ambienti gia' creati lo contengono)
# invece di sostituirlo.

#: (tipo o None, nome) -> (segnaposto, modulo che lo riempie) per le funzioni
#: (tipo None) e i metodi (tipo) dei moduli caricati alla prima chiamata
_SEGNAPOSTI: dict[tuple[str | None, str], tuple[FunzioneNativa, str]] = {}


class _Segnaposto(FunzioneNativa):
    """Funzione di un modulo della libreria non ancora importato.

    Ha gia' ``nome``, ``vuole_interprete`` ed ``e_metodo``; qualunque altro
    attributo importa il modulo, che trasforma l'oggetto nella funzione vera
    (stessa classe e stessi attributi di quella che avrebbe registrato)."""

    def __init__(self, chiave: tuple[str | None, str], modulo: str, modulo_python: str,
                 vuole_interprete: bool, e_metodo: bool) -> None:  # noqa: D107 - niente super(): manca la funzione
        self.nome = chiave[1]
        self.vuole_interprete = vuole_interprete
        self.e_metodo = e_metodo
        self._chiave_pigra = chiave
        self._modulo_pigro = modulo
        self._modulo_python = modulo_python

    def __getattr__(self, nome: str) -> Any:
        if nome.startswith("__"):
            raise AttributeError(nome)
        voci = self.__dict__
        modulo = voci.get("_modulo_pigro")
        if modulo is None:
            raise AttributeError(nome)
        import importlib

        importlib.import_module(modulo)
        if type(self) is _Segnaposto:
            # una copia del segnaposto (``copy``): prende lo stato di quello registrato
            registrato = _SEGNAPOSTI.get(voci.get("_chiave_pigra"))  # type: ignore[arg-type]
            if registrato is not None and type(registrato[0]) is not _Segnaposto:
                _riempi(self, registrato[0])
        if type(self) is _Segnaposto:
            raise AttributeError(f"`{self.nome}`: il modulo {modulo} non l'ha registrata ({nome})")
        return getattr(self, nome)


def _riempi(segnaposto: FunzioneNativa, vera: FunzioneNativa) -> None:
    """Il segnaposto diventa ``vera`` (classe e attributi), restando lo stesso oggetto."""
    # prima gli attributi nuovi, poi la classe, poi via quelli del segnaposto:
    # un altro thread che la legge nel frattempo trova sempre cio' che cerca
    stato = segnaposto.__dict__
    nuovi = vera.__dict__
    stato.update(nuovi)
    segnaposto.__class__ = type(vera)
    for chiave in [k for k in stato if k not in nuovi]:
        del stato[chiave]


def _modulo_in_caricamento(modulo: str) -> bool:
    m = sys.modules.get(modulo)
    if m is None:
        return False
    spec = getattr(m, "__spec__", None)
    return bool(getattr(spec, "_initializing", True))


def inserisci(voci: dict, tipo: str | None, nome: str, valore: Any) -> None:
    """``voci[nome] = valore`` per :data:`FUNZIONI` (``tipo`` None) o ``METODI[tipo]``.

    Se c'e' il segnaposto di ``nome`` e il suo modulo si sta importando, lo si
    riempie con ``valore`` invece di sostituirlo.

    Qui passano tutte le funzioni della libreria: :func:`leo.permessi.proteggi` mette
    il custode dei permessi a quelle che toccano rete, file, sistema, processi..."""
    if isinstance(valore, FunzioneNativa):
        _permessi.proteggi(valore, None, nome)
    voce = _SEGNAPOSTI.get((tipo, nome))
    if (voce is not None and voce[0] is not valore and isinstance(valore, FunzioneNativa)
            and _modulo_in_caricamento(voce[1])):
        segnaposto = voce[0]
        _riempi(segnaposto, valore)
        if nome not in voci:
            voci[nome] = segnaposto
        # se nel frattempo qualcuno ha messo un'altra funzione al suo posto, resta quella
        return
    voci[nome] = valore


def registra_pigre(modulo: str, voci: Iterable[tuple]) -> None:
    """Segnaposti per le funzioni e i metodi di ``modulo`` (non ancora importato).

    ``voci``: tuple ``(tipo o None, nome, vuole_interprete, e_metodo, modulo_python o None)``
    come in ``leo/libreria/_indice.py``."""
    for tipo, nome, vuole_interprete, e_metodo, modulo_python in voci:
        destinazione = FUNZIONI if tipo is None else METODI.setdefault(tipo, {})
        if nome in destinazione:        # gia' registrata (non dovrebbe succedere: lo verifica un test)
            continue
        chiave = (tipo, nome)
        segnaposto = _Segnaposto(chiave, modulo, modulo_python or modulo, vuole_interprete, e_metodo)
        _SEGNAPOSTI[chiave] = (segnaposto, modulo)
        destinazione[nome] = segnaposto


def modulo_python(nativa: Any) -> str:
    """``nativa.funzione.__module__`` senza importare il modulo di un segnaposto."""
    stato = getattr(nativa, "__dict__", {})
    if "_modulo_python" in stato:
        return stato["_modulo_python"]
    return getattr(getattr(nativa, "funzione", None), "__module__", "") or ""


def costante(nome: str, valore: Any) -> None:
    COSTANTI[nome] = valore


def trova_metodo(nome_tipo: str, nome: str) -> FunzioneNativa | None:
    return METODI.get(nome_tipo, {}).get(nome)


def carica_libreria() -> None:
    """Importa tutti i moduli di ``leo.libreria`` (che si registrano)."""
    from . import libreria  # noqa: F401  (l'import esegue le registrazioni)


def crea_ambiente_predefinito(*, permetti_ridichiarazione: bool = False):
    """Ambiente radice con libreria, costanti e costruttori degli errori.

    I controlli grafici NON sono qui: li aggiunge il runtime grafico.
    """
    from .ambiente import Ambiente
    from .errori import TIPI_ERRORE

    carica_libreria()
    amb = Ambiente(nome="predefinito", permetti_ridichiarazione=permetti_ridichiarazione)
    for n, f in FUNZIONI.items():
        amb.dichiara(n, f, costante=True)
    for n, v in COSTANTI.items():
        amb.dichiara(n, v, costante=True)
    for n, classe in TIPI_ERRORE.items():
        amb.dichiara(n, _costruttore_errore(n, classe), costante=True)
    # l'ambiente predefinito puo' essere "nascosto" ma mai modificato:
    amb.permetti_ridichiarazione = False
    return amb


def _costruttore_errore(nome: str, classe: type) -> FunzioneNativa:
    def crea(messaggio="", suggerimento=None):
        from .valori import rappresenta

        return classe(rappresenta(messaggio), suggerimento=suggerimento)

    crea.__doc__ = f"Crea un errore `{nome}` da usare con `lancia`."
    return FunzioneNativa(nome, crea)
