"""Temi dei colori dell'editor, del REPL e dei messaggi (``dati/temi/*.toml``).

API (docs/CONTRATTI.md, sezione 11.2)::

    StileCategoria(colore, grassetto=False, corsivo=False)
    Tema(nome, scuro, sfondo, testo, cursore, selezione, riga_corrente,
         numeri_riga, numeri_riga_corrente, errore, avviso, coppia_blocco,
         categorie)
    Tema.stile(categoria) -> StileCategoria
    tema_da_dizionario(dati) -> Tema          # categorie mancanti = testo_normale
    carica_tema(nome_o_percorso="nero") -> Tema
    temi_disponibili() -> list[str]           # dati/temi + cartella_utente()/temi
    codice_ansi(stile) -> str                 # sequenza ANSI a 24 bit
    ANSI_RESET

Formato di un file di tema::

    [tema]
    nome = "Nero"
    scuro = true
    sfondo = "#0B0B0D"
    testo = "#ECECEF"
    ...                                  # cursore, selezione, riga_corrente, ...

    [categorie.flusso]
    colore = "#FF3B4E"
    grassetto = true

Funzioni pubbliche in piu' (non nel contratto): ``rapporto_contrasto(c1, c2)``
(usa ``leo.grafica.colori`` se pronto, altrimenti un calcolo locale WCAG 2.x)
e ``TEMI_PREDEFINITI`` (i nomi dei tre temi forniti).

Categorie mancanti in un tema: si usa la catena di :data:`RICADUTE`
(``parametri`` -> ``variabili`` -> ``testo_normale``, ``eventi`` e ``campi`` ->
``proprieta``...), cosi' un tema scritto prima delle categorie nuove si vede
esattamente come prima.

Colori personalizzati (Impostazioni di Studio, "Colori del codice")::

    imposta_personalizzazioni({"nero": {"variabili": {"colore": "#FFD166", "grassetto": True}}})
    carica_tema("nero")          # -> con le personalizzazioni applicate
    carica_tema("nero", personalizzato=False)   # -> il tema com'e' nel file
    normalizza_personalizzazioni(dati) -> dict  # solo voci valide, mai eccezioni
    applica_personalizzazioni(tema, stili) -> Tema

Le personalizzazioni valgono per il processo e, tramite la variabile
d'ambiente ``LEO_COLORI_CODICE`` (JSON), anche per i programmi avviati da
Studio (colori ANSI del terminale).
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field, replace
from pathlib import Path

from .categorie import Categoria
from .errori import ErroreValore

#: Sequenza ANSI che riporta il terminale ai colori normali.
ANSI_RESET = "\x1b[0m"

#: Temi forniti con Leo, nell'ordine in cui compaiono nei menu.
TEMI_PREDEFINITI: tuple[str, ...] = ("nero", "bianco", "alto_contrasto")

_CAMPI_COLORE = ("sfondo", "testo", "cursore", "selezione", "riga_corrente", "numeri_riga",
                 "numeri_riga_corrente", "errore", "avviso", "coppia_blocco")


# ===========================================================================
# Modello
# ===========================================================================

@dataclass
class StileCategoria:
    """Aspetto di una categoria di parole: colore ``#RRGGBB`` e stile del carattere."""

    colore: str
    grassetto: bool = False
    corsivo: bool = False


@dataclass
class Tema:
    """Un tema completo dell'editor (colori dell'interfaccia e delle categorie)."""

    nome: str
    scuro: bool
    sfondo: str
    testo: str
    cursore: str
    selezione: str
    riga_corrente: str
    numeri_riga: str
    numeri_riga_corrente: str
    errore: str
    avviso: str
    coppia_blocco: str
    categorie: dict[Categoria, StileCategoria] = field(default_factory=dict)

    def stile(self, categoria: Categoria) -> StileCategoria:
        """Stile della categoria; se manca, quello della sua ricaduta (alla fine il testo normale)."""
        visti = 0
        while categoria is not None and visti < 8:
            trovato = self.categorie.get(categoria)
            if trovato is not None:
                return trovato
            categoria = RICADUTE.get(categoria)
            visti += 1
        normale = self.categorie.get(Categoria.TESTO_NORMALE)
        if normale is not None:
            return normale
        return StileCategoria(self.testo)


#: Categoria da usare quando un tema non definisce quella chiesta (catena, fino a testo_normale).
RICADUTE: dict[Categoria, Categoria] = {
    Categoria.VARIABILI: Categoria.TESTO_NORMALE,
    Categoria.COSTANTI: Categoria.TESTO_NORMALE,
    Categoria.PARAMETRI: Categoria.VARIABILI,
    Categoria.CAMPI: Categoria.PROPRIETA,
    Categoria.EVENTI: Categoria.PROPRIETA,
    Categoria.OPERATORI: Categoria.TESTO_NORMALE,
    Categoria.PUNTEGGIATURA: Categoria.OPERATORI,
}


# ===========================================================================
# Colori (con ripiego locale se leo.grafica.colori non e' ancora pronto)
# ===========================================================================

_ESADECIMALE = re.compile(r"^#(?:[0-9A-Fa-f]{3}|[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$")


def _normalizza_locale(valore: str) -> str:
    testo = valore.strip()
    if not _ESADECIMALE.match(testo):
        raise ErroreValore(f"`{valore}` non è un colore valido.",
                           suggerimento="Scrivi il colore come `#RRGGBB`, per esempio `#D4D4D4`.")
    if len(testo) == 4:
        testo = "#" + "".join(c * 2 for c in testo[1:])
    return testo.upper()


def _normalizza_colore(valore: object, campo: str) -> str:
    """Colore in forma ``#RRGGBB`` (o ``#RRGGBBAA``); accetta anche i nomi italiani
    se ``leo.grafica.colori`` e' disponibile."""
    if not isinstance(valore, str) or not valore.strip():
        raise ErroreValore(f"Nel tema, `{campo}` deve essere un colore come `#D4D4D4`.")
    testo = valore.strip()
    if _ESADECIMALE.match(testo):
        return _normalizza_locale(testo)
    try:
        from .grafica.colori import normalizza_colore  # type: ignore[attr-defined]
    except Exception:
        return _normalizza_locale(testo)
    try:
        risultato = normalizza_colore(testo)
    except ErroreValore:
        raise
    except Exception:
        return _normalizza_locale(testo)
    if not isinstance(risultato, str) or not _ESADECIMALE.match(risultato):
        return _normalizza_locale(testo)
    return risultato.upper()


def _rgb(colore: str) -> tuple[int, int, int]:
    testo = _normalizza_locale(colore)
    return int(testo[1:3], 16), int(testo[3:5], 16), int(testo[5:7], 16)


def _luminanza_locale(colore: str) -> float:
    def lineare(c: int) -> float:
        v = c / 255
        return v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4

    r, g, b = _rgb(colore)
    return 0.2126 * lineare(r) + 0.7152 * lineare(g) + 0.0722 * lineare(b)


def rapporto_contrasto(c1: str, c2: str) -> float:
    """Rapporto di contrasto WCAG 2.x tra due colori (da 1 a 21)."""
    try:
        from .grafica.colori import rapporto_contrasto as esterno  # type: ignore[attr-defined]

        valore = esterno(c1, c2)
        if isinstance(valore, (int, float)) and 1.0 <= valore <= 21.0 + 1e-9:
            return float(valore)
    except Exception:
        pass
    l1, l2 = _luminanza_locale(c1), _luminanza_locale(c2)
    chiaro, scuro = max(l1, l2), min(l1, l2)
    return (chiaro + 0.05) / (scuro + 0.05)


# ===========================================================================
# Costruzione e caricamento
# ===========================================================================

def _booleano(valore: object, campo: str) -> bool:
    if isinstance(valore, bool):
        return valore
    if isinstance(valore, str) and valore.strip().lower() in ("vero", "si", "sì", "true"):
        return True
    if isinstance(valore, str) and valore.strip().lower() in ("falso", "no", "false"):
        return False
    raise ErroreValore(f"Nel tema, `{campo}` deve essere `true` oppure `false`.")


def _categoria_da_nome(nome: str) -> Categoria | None:
    chiave = str(nome).strip().lower().replace(" ", "_").replace("à", "a")
    for categoria in Categoria:
        if categoria.value == chiave or categoria.name.lower() == chiave:
            return categoria
    return None


def tema_da_dizionario(dati: dict) -> Tema:
    """Costruisce un :class:`Tema` dal contenuto di un file di tema.

    Accetta sia ``{"tema": {...}, "categorie": {...}}`` sia la sezione ``tema``
    "piatta" con dentro ``categorie``. Campi dell'interfaccia mancanti:
    ricavati da ``sfondo``/``testo``; categorie mancanti: come ``testo_normale``.
    """
    if not isinstance(dati, dict):
        raise ErroreValore("Il tema deve essere una tabella TOML con le sezioni `[tema]` e `[categorie]`.")
    sezione = dati.get("tema", dati)
    if not isinstance(sezione, dict):
        raise ErroreValore("La sezione `[tema]` deve essere una tabella.")
    categorie_grezze = dati.get("categorie", sezione.get("categorie", {}))
    if not isinstance(categorie_grezze, dict):
        raise ErroreValore("La sezione `[categorie]` del tema deve essere una tabella.")

    scuro_dato = sezione.get("scuro")
    sfondo = _normalizza_colore(sezione.get("sfondo", "#0B0B0D" if scuro_dato is not False else "#FFFFFF"),
                                "sfondo")
    scuro = _booleano(scuro_dato, "scuro") if scuro_dato is not None else _luminanza_locale(sfondo[:7]) < 0.4
    testo = _normalizza_colore(sezione.get("testo", "#ECECEF" if scuro else "#111114"), "testo")
    predefiniti = {
        "cursore": testo,
        "selezione": "#5A1520" if scuro else "#F6C9CF",
        "riga_corrente": "#151518" if scuro else "#F7F7F9",
        "numeri_riga": "#7A7A84" if scuro else "#6A6A75",
        "numeri_riga_corrente": testo,
        "errore": "#FFB020" if scuro else "#A05200",
        "avviso": "#FFCB6B" if scuro else "#9A6700",
        "coppia_blocco": "#3A1219" if scuro else "#FBE3E6",
    }
    colori = {"sfondo": sfondo, "testo": testo}
    for campo, predefinito in predefiniti.items():
        colori[campo] = _normalizza_colore(sezione.get(campo, predefinito), campo)

    categorie: dict[Categoria, StileCategoria] = {}
    for nome, valori in categorie_grezze.items():
        categoria = _categoria_da_nome(nome)
        if categoria is None:
            validi = ", ".join(f"`{c.value}`" for c in Categoria)
            raise ErroreValore(f"`{nome}` non è una categoria di colori.",
                               suggerimento=f"Le categorie sono: {validi}.")
        if isinstance(valori, str):
            valori = {"colore": valori}
        if not isinstance(valori, dict):
            raise ErroreValore(f"La categoria `{nome}` del tema deve essere una tabella con `colore`.")
        colore = _normalizza_colore(valori.get("colore", testo), f"categorie.{nome}.colore")
        categorie[categoria] = StileCategoria(
            colore,
            _booleano(valori.get("grassetto", False), f"categorie.{nome}.grassetto"),
            _booleano(valori.get("corsivo", False), f"categorie.{nome}.corsivo"),
        )
    normale = categorie.get(Categoria.TESTO_NORMALE, StileCategoria(testo))
    categorie[Categoria.TESTO_NORMALE] = normale
    definite = dict(categorie)
    for categoria in Categoria:
        if categoria not in categorie:
            origine, passi = RICADUTE.get(categoria), 0
            while origine is not None and origine not in definite and passi < 8:
                origine, passi = RICADUTE.get(origine), passi + 1
            base = definite.get(origine, normale) if origine is not None else normale
            categorie[categoria] = StileCategoria(base.colore, base.grassetto, base.corsivo)

    nome_tema = sezione.get("nome", "Senza nome")
    return Tema(nome=str(nome_tema), scuro=scuro, categorie=categorie, **colori)


# Copia incorporata dei temi forniti: si usa solo se i file di dati mancano.
def _incorporato(nome: str, scuro: bool, ui: tuple[str, ...], cat: dict[str, tuple[str, str]]) -> dict:
    tema = dict(zip(("sfondo", "testo", "cursore", "selezione", "riga_corrente", "numeri_riga",
                     "numeri_riga_corrente", "errore", "avviso", "coppia_blocco"), ui))
    tema.update(nome=nome, scuro=scuro)
    categorie = {c: {"colore": colore, "grassetto": "g" in s, "corsivo": "c" in s}
                 for c, (colore, s) in cat.items()}
    return {"tema": tema, "categorie": categorie}


_TEMI_INCORPORATI: dict[str, dict] = {
    "nero": _incorporato("Nero", True, (
        "#0B0B0D", "#ECECEF", "#E0182D", "#5A1520", "#151518", "#7A7A84", "#FF3B4E",
        "#FFB020", "#FFCB6B", "#3A1219"), {
        "testo_normale": ("#E6E6EA", ""), "flusso": ("#FF3B4E", "g"), "dichiarazioni": ("#FF8A9A", "g"),
        "errori": ("#FF5C8A", "g"), "logici": ("#D9A3AA", ""), "valori_speciali": ("#FF8C42", "c"),
        "numeri": ("#FFBE8C", ""), "testi": ("#FFB020", ""), "interpolazione": ("#FFE08A", ""),
        "libreria": ("#FFC7CE", ""), "funzioni_utente": ("#FFC7CE", "c"), "controlli": ("#D2D2D8", ""),
        "proprieta": ("#A8A8B3", ""), "commenti": ("#8A8A94", "c"),
        "variabili": ("#F2C94C", ""), "costanti": ("#6FCF97", ""), "parametri": ("#FF9E7A", ""),
        "campi": ("#A6C8FF", ""), "eventi": ("#FF7B72", ""), "operatori": ("#C4C4CC", ""),
        "punteggiatura": ("#9A9AA6", "")}),
    "bianco": _incorporato("Bianco", False, (
        "#FFFFFF", "#111114", "#C8102E", "#F6C9CF", "#F7F7F9", "#6A6A75", "#C8102E",
        "#A05200", "#9A6700", "#FBE3E6"), {
        "testo_normale": ("#111114", ""), "flusso": ("#C8102E", "g"), "dichiarazioni": ("#B0304F", "g"),
        "errori": ("#A3124F", "g"), "logici": ("#8A4A55", ""), "valori_speciali": ("#B34700", "c"),
        "numeri": ("#A84E00", ""), "testi": ("#8A5A00", ""), "interpolazione": ("#6F5200", ""),
        "libreria": ("#7A1F2B", ""), "funzioni_utente": ("#7A1F2B", "c"), "controlli": ("#3C3C46", ""),
        "proprieta": ("#5A5A66", ""), "commenti": ("#6A6A75", "c"),
        "variabili": ("#6E5E00", ""), "costanti": ("#1A7F37", ""), "parametri": ("#B2451F", ""),
        "campi": ("#1F5FA8", ""), "eventi": ("#C0392B", ""), "operatori": ("#4A4A55", ""),
        "punteggiatura": ("#5F5F6B", "")}),
    "alto_contrasto": _incorporato("Alto contrasto", True, (
        "#000000", "#FFFFFF", "#FFFF00", "#1F3F8F", "#1A1A1A", "#FFFFFF", "#FFFF00",
        "#FF5555", "#FFFF00", "#444444"), {
        "testo_normale": ("#FFFFFF", ""), "flusso": ("#FF9CFF", "g"), "dichiarazioni": ("#8CC8FF", "g"),
        "errori": ("#FF7070", "g"), "logici": ("#FFE070", "g"), "valori_speciali": ("#70E0FF", "c"),
        "numeri": ("#A0FFA0", ""), "testi": ("#FFC080", ""), "interpolazione": ("#FFFF00", ""),
        "libreria": ("#FFFFA0", ""), "funzioni_utente": ("#FFFFA0", "c"), "controlli": ("#70FFE0", ""),
        "proprieta": ("#C0E8FF", ""), "commenti": ("#90D090", "c"),
        "variabili": ("#FFD84D", ""), "costanti": ("#7CFC9A", ""), "parametri": ("#FFB870", ""),
        "campi": ("#9FD4FF", ""), "eventi": ("#FF9A9A", ""), "operatori": ("#E0E0E0", ""),
        "punteggiatura": ("#CFCFCF", "")}),
}


def _chiave_nome(nome: str) -> str:
    """"Alto contrasto" -> "alto_contrasto"."""
    return re.sub(r"[\s\-]+", "_", nome.strip().lower())


def _cartelle_temi() -> list[Path]:
    cartelle: list[Path] = []
    try:
        from .percorsi import cartella_dati

        cartelle.append(cartella_dati() / "temi")
    except Exception:
        pass
    try:
        from .percorsi import cartella_utente

        cartelle.append(cartella_utente() / "temi")
    except Exception:
        pass
    return cartelle


def _leggi_file_tema(percorso: Path) -> Tema:
    from .tomlutil import ErroreToml, carica_toml

    try:
        dati = carica_toml(percorso)
    except ErroreToml as e:
        raise ErroreValore(f"Il tema `{percorso}` non è un TOML valido: {e.messaggio}.",
                           riga=e.riga, nome_file=str(percorso)) from e
    return tema_da_dizionario(dati)


def carica_tema(nome_o_percorso: str = "nero", *, personalizzato: bool = True) -> Tema:
    """Come :func:`_carica_tema_base`, con le personalizzazioni dell'utente se ``personalizzato``."""
    tema = _carica_tema_base(nome_o_percorso)
    if not personalizzato:
        return tema
    try:
        richiesta = os.fspath(nome_o_percorso) if nome_o_percorso else "nero"
        stili = personalizzazioni_attive().get(chiave_tema(richiesta))
        return applica_personalizzazioni(tema, stili) if stili else tema
    except Exception:
        return tema


def chiave_tema(nome_o_percorso: str) -> str:
    """Chiave delle personalizzazioni: ``"Alto contrasto"`` -> ``"alto_contrasto"``, un percorso -> il suo nome."""
    testo = str(nome_o_percorso or "nero")
    if testo.lower().endswith(".toml") or "/" in testo or "\\" in testo:
        testo = Path(testo.replace("\\", "/")).stem
    return _chiave_nome(testo) or "nero"


def _carica_tema_base(nome_o_percorso: str = "nero") -> Tema:
    """Carica un tema per nome (``"nero"``, ``"bianco"``, ``"alto_contrasto"`` o
    un tema dell'utente in ``cartella_utente()/temi``) oppure da un percorso ``.toml``.

    I temi dell'utente con lo stesso nome di un tema fornito lo sostituiscono.
    Se i file forniti mancano, usa la copia incorporata. Tema sconosciuto:
    ``ErroreValore`` con l'elenco dei temi disponibili.
    """
    richiesta = os.fspath(nome_o_percorso) if nome_o_percorso else "nero"
    percorso = Path(richiesta)
    sembra_percorso = richiesta.lower().endswith(".toml") or os.sep in richiesta or "/" in richiesta
    if sembra_percorso:
        if percorso.is_file():
            return _leggi_file_tema(percorso)
        raise ErroreValore(f"Non trovo il file del tema `{richiesta}`.",
                           suggerimento="Controlla il percorso: il tema deve essere un file `.toml`.")
    chiave = _chiave_nome(richiesta)
    for cartella in reversed(_cartelle_temi()):   # prima l'utente, poi i dati di Leo
        candidato = cartella / f"{chiave}.toml"
        if candidato.is_file():
            return _leggi_file_tema(candidato)
    if chiave in _TEMI_INCORPORATI:
        return tema_da_dizionario(_TEMI_INCORPORATI[chiave])
    elenco = ", ".join(f"`{n}`" for n in temi_disponibili())
    raise ErroreValore(f"Non conosco il tema `{richiesta}`.",
                       suggerimento=f"I temi disponibili sono: {elenco}.")


def temi_disponibili() -> list[str]:
    """Nomi dei temi (forniti per primi, poi quelli dell'utente in ordine alfabetico)."""
    trovati: set[str] = set(TEMI_PREDEFINITI)
    for cartella in _cartelle_temi():
        try:
            for file in cartella.glob("*.toml"):
                if file.is_file():
                    trovati.add(file.stem)
        except OSError:
            continue
    altri = sorted(n for n in trovati if n not in TEMI_PREDEFINITI)
    return list(TEMI_PREDEFINITI) + altri


# ===========================================================================
# Personalizzazioni dell'utente (Impostazioni di Studio -> Colori del codice)
# ===========================================================================

#: Categorie come le vede la persona, nell'ordine del dialogo: (categoria, nome, esempio).
ETICHETTE_CATEGORIE: tuple[tuple[Categoria, str, str], ...] = (
    (Categoria.VARIABILI, "Variabili", "totale"),
    (Categoria.COSTANTI, "Costanti", "PI_GRECO"),
    (Categoria.PARAMETRI, "Parametri", "importo"),
    (Categoria.FUNZIONI_UTENTE, "Funzioni del programma", "saluta"),
    (Categoria.LIBRERIA, "Funzioni di libreria", "stampa"),
    (Categoria.CONTROLLI, "Controlli", "Pulsante1"),
    (Categoria.PROPRIETA, "Proprietà e metodi", ".testo"),
    (Categoria.EVENTI, "Eventi", ".clic"),
    (Categoria.CAMPI, "Campi degli oggetti", ".tipo"),
    (Categoria.FLUSSO, "Flusso", "se … allora"),
    (Categoria.DICHIARAZIONI, "Dichiarazioni", "variabile"),
    (Categoria.ERRORI, "Errori", "prova"),
    (Categoria.LOGICI, "Parole logiche", "e  non  è"),
    (Categoria.VALORI_SPECIALI, "Valori speciali", "vero"),
    (Categoria.NUMERI, "Numeri", "42"),
    (Categoria.TESTI, "Testi", '"ciao"'),
    (Categoria.INTERPOLAZIONE, "Interpolazione", "{nome}"),
    (Categoria.OPERATORI, "Operatori", "+  =  =="),
    (Categoria.PUNTEGGIATURA, "Punteggiatura", "( ) [ ] ,"),
    (Categoria.COMMENTI, "Commenti", "# nota"),
    (Categoria.TESTO_NORMALE, "Altro testo", "nome"),
)

#: Variabile d'ambiente con le personalizzazioni in JSON (per i programmi avviati da Studio).
VARIABILE_AMBIENTE = "LEO_COLORI_CODICE"

_PERSONALIZZAZIONI: dict[str, dict[str, dict]] = {}
_STATO_PERSONALIZZAZIONI = {"impostate": False, "ambiente": None, "da_ambiente": {}}


def _stile_valido(valori: object) -> dict | None:
    """``{"colore": "#RRGGBB", "grassetto": bool, "corsivo": bool}`` oppure None se non valido."""
    if isinstance(valori, str):
        valori = {"colore": valori}
    if not isinstance(valori, dict):
        return None
    try:
        colore = _normalizza_locale(str(valori.get("colore", "")))[:7]
    except ErroreValore:
        return None
    risultato = {"colore": colore}
    for chiave in ("grassetto", "corsivo"):
        valore = valori.get(chiave, False)
        risultato[chiave] = valore if isinstance(valore, bool) else False
    return risultato


def normalizza_personalizzazioni(dati: object) -> dict[str, dict[str, dict]]:
    """Solo le voci valide di ``{tema: {categoria: stile}}`` (mai eccezioni)."""
    risultato: dict[str, dict[str, dict]] = {}
    if not isinstance(dati, dict):
        return risultato
    for nome_tema, categorie in dati.items():
        if not isinstance(nome_tema, str) or not nome_tema.strip() or not isinstance(categorie, dict):
            continue
        buone: dict[str, dict] = {}
        for nome, valori in categorie.items():
            categoria = _categoria_da_nome(str(nome))
            stile = _stile_valido(valori)
            if categoria is not None and stile is not None:
                buone[categoria.value] = stile
        if buone:
            risultato[chiave_tema(nome_tema)] = buone
    return risultato


def imposta_personalizzazioni(dati: object, *, ambiente: bool = True) -> None:
    """Imposta i colori personalizzati per i temi (``{}`` = nessuno).

    Con ``ambiente`` li scrive anche in ``LEO_COLORI_CODICE`` per i processi figli.
    """
    pulite = normalizza_personalizzazioni(dati)
    _PERSONALIZZAZIONI.clear()
    _PERSONALIZZAZIONI.update(pulite)
    _STATO_PERSONALIZZAZIONI["impostate"] = True
    if ambiente:
        try:
            if pulite:
                os.environ[VARIABILE_AMBIENTE] = json.dumps(pulite, sort_keys=True)
            else:
                os.environ.pop(VARIABILE_AMBIENTE, None)
        except Exception:
            pass


def personalizzazioni_attive() -> dict[str, dict[str, dict]]:
    """Le personalizzazioni in uso: quelle impostate, altrimenti quelle di ``LEO_COLORI_CODICE``."""
    if _STATO_PERSONALIZZAZIONI["impostate"]:
        return {k: dict(v) for k, v in _PERSONALIZZAZIONI.items()}
    testo = os.environ.get(VARIABILE_AMBIENTE, "")
    if testo != _STATO_PERSONALIZZAZIONI["ambiente"]:
        try:
            dati = json.loads(testo) if testo else {}
        except (ValueError, TypeError):
            dati = {}
        _STATO_PERSONALIZZAZIONI["ambiente"] = testo
        _STATO_PERSONALIZZAZIONI["da_ambiente"] = normalizza_personalizzazioni(dati)
    return {k: dict(v) for k, v in _STATO_PERSONALIZZAZIONI["da_ambiente"].items()}


def applica_personalizzazioni(tema: Tema, stili: object) -> Tema:
    """Copia del tema con gli stili ``{categoria: stile}`` al posto di quelli del tema.

    Le categorie che ricadono su una categoria cambiata (e che il tema non
    definisce di suo) non cambiano: ogni categoria ha il suo pulsante.
    """
    if not isinstance(stili, dict) or not stili:
        return tema
    categorie = dict(tema.categorie)
    for nome, valori in stili.items():
        categoria = nome if isinstance(nome, Categoria) else _categoria_da_nome(str(nome))
        stile = _stile_valido(valori.__dict__ if isinstance(valori, StileCategoria) else valori)
        if categoria is not None and stile is not None:
            categorie[categoria] = StileCategoria(stile["colore"], stile["grassetto"], stile["corsivo"])
    return replace(tema, categorie=categorie)


# ===========================================================================
# ANSI
# ===========================================================================

def codice_ansi(stile: StileCategoria) -> str:
    """Sequenza ANSI SGR a 24 bit per lo stile (colore, grassetto, corsivo)."""
    parti: list[str] = []
    if stile.grassetto:
        parti.append("1")
    if stile.corsivo:
        parti.append("3")
    try:
        r, g, b = _rgb(stile.colore[:7] if len(stile.colore) >= 7 else stile.colore)
        parti.append(f"38;2;{r};{g};{b}")
    except ErroreValore:
        pass
    if not parti:
        return ""
    return "\x1b[" + ";".join(parti) + "m"
