"""Leo: linguaggio di programmazione interpretato con parole chiave italiane.

Uso da Python::

    from leo.esecuzione import esegui_sorgente
    esegui_sorgente('stampa("Ciao, mondo!")')

Questo modulo resta leggero: non importa lexer, parser o interprete.

I sorgenti hanno estensione ``.leo``; i file ``.dante`` (progetti creati
quando il linguaggio si chiamava Dante) si leggono ancora.
"""

from __future__ import annotations

import os

from . import avvio_rapido as _avvio_rapido

# le funzioni generate da @dataclass (nodi, errori, valori...) si ricordano su disco
_avvio_rapido.installa()

__version__ = "0.1.0"
__author__ = "Rosario Zappalà"
#: Nota di copyright mostrata da CLI, Leo Studio e negli eseguibili.
COPYRIGHT = "Copyright © 2026 Rosario Zappalà. Tutti i diritti riservati."
NOME = "Leo"
NOME_STUDIO = "Leo Studio"
ESTENSIONE_SORGENTE = ".leo"
#: Estensione dei sorgenti delle versioni precedenti (ancora accettata).
ESTENSIONE_VECCHIA = ".dante"
#: Tutte le estensioni accettate per i sorgenti, la nuova per prima.
ESTENSIONI_SORGENTE = (ESTENSIONE_SORGENTE, ESTENSIONE_VECCHIA)
ESTENSIONE_MASCHERA = ".maschera"


def e_sorgente(nome) -> bool:
    """Vero se ``nome`` (testo o percorso) finisce in ``.leo`` o ``.dante``."""
    return str(nome).lower().endswith(ESTENSIONI_SORGENTE)


def nomi_file_modulo(modulo: str) -> tuple:
    """Nomi di file da provare per ``importa "modulo"``, nell'ordine.

    ``"geo"`` -> ``geo.leo``, ``geo.dante``; ``"geo.leo"`` -> ``geo.leo``, poi
    ``geo.dante``; ``"geo.dante"`` -> ``geo.dante``, poi ``geo.leo`` (un programma
    vecchio trova anche il modulo gia' rinominato).
    """
    minuscolo = modulo.lower()
    for estensione in ESTENSIONI_SORGENTE:
        if minuscolo.endswith(estensione):
            base = modulo[: len(modulo) - len(estensione)]
            altre = [base + e for e in ESTENSIONI_SORGENTE if e != estensione]
            return (modulo, *altre)
    return tuple(modulo + e for e in ESTENSIONI_SORGENTE)


def nome_modulo_implicito(nome: str):
    """Il nome che ``importa <nome>`` (senza ``come``) mette nel programma.

    ``matematica`` -> ``matematica``; ``"geo.leo"`` o ``"cartella/geo.leo"`` ->
    ``geo``. None se il nome del file non e' un nome valido di Leo (per esempio
    ``"mio-file.leo"`` o una parola chiave): in quel caso serve ``come``.
    """
    import os

    base = os.path.basename(nome.replace("\\", "/"))
    minuscolo = base.lower()
    for estensione in ESTENSIONI_SORGENTE:
        if minuscolo.endswith(estensione):
            base = base[: len(base) - len(estensione)]
            break
    if not base.isidentifier():
        return None
    from .tokens import PAROLE_CHIAVE

    return None if base in PAROLE_CHIAVE else base


def file_sorgente(cartella, base: str):
    """Il sorgente ``<base>.leo`` nella cartella; se manca ma c'e' ``<base>.dante``, quello.

    Senza nessuno dei due restituisce il percorso ``.leo`` (per creare un file nuovo).
    """
    from pathlib import Path

    cartella = Path(cartella)
    nuovo = cartella / (base + ESTENSIONE_SORGENTE)
    if nuovo.exists():
        return nuovo
    vecchio = cartella / (base + ESTENSIONE_VECCHIA)
    if vecchio.exists():
        return vecchio
    return nuovo


def variabile_ambiente(nome: str, predefinito=None):
    """Legge ``LEO_<nome>``; se non c'e', la vecchia ``DANTE_<nome>``."""
    valore = os.environ.get("LEO_" + nome)
    if valore is None:
        valore = os.environ.get("DANTE_" + nome)
    return predefinito if valore is None else valore
