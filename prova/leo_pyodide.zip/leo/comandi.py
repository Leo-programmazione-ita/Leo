"""Comandi senza parentesi: tabelle e analisi dei nomi del programma.

Regola di Leo: **le parentesi vogliono dire CALCOLA**. Un comando a inizio
riga si scrive anche senza parentesi:

* comandi di TESTO (``stampa``, ``scrivi``, ``messaggio``, ``chiedi``,
  ``domanda``, ``suona``, ``scrivi_qui``): tutto quello che segue e' testo cosi'
  com'e' scritto; quello che sta tra parentesi tonde si calcola;
* comandi di VALORE (``avanti``, ``destra``, ``attendi``, ``colore``...):
  valori separati da virgole, ognuno un numero (con unita' facoltativa:
  ``attendi 2 secondi``), un calcolo con nomi che esistono (``avanti lato * 2``)
  oppure parole che diventano testo (``colore verde chiaro``);
* comandi SENZA valori (``casa``, ``penna_su``...);
* metodi degli oggetti delle finestre (``Palla.rimbalza 3``) e funzioni
  scritte nel programma senza ``restituisci`` (``saluta Giulia``).

Il lexer (``leo/lexer.py``) usa questo modulo; lo usano anche la colorazione,
``leo spiega`` e :mod:`leo.lettura` (che dice all'editor quali parti di una
riga sono testo e quali calcoli).

API::

    genere_comando(nome) -> "testo" | "valore" | "senza" | None
    SINONIMI_COMANDI                     # {"scrivi": "stampa"}
    UNITA, UNITA_DEI_COMANDI             # unita' facoltative dei comandi di valore
    PROPRIETA_DI_TESTO                   # Etichetta1.testo = Ciao (nome)
    trova_definizioni(sorgente, parole=None) -> Definizioni
    definizioni_progetto(nome_file) -> Definizioni | None   # gli altri file del progetto
    nomi_predefiniti() -> frozenset[str] # libreria, costanti, errori, tipi dei controlli
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import Any, Iterable

__all__ = [
    "COMANDI_TESTO", "COMANDI_VALORE", "COMANDI_SENZA", "COMANDI_DOPO_UGUALE", "SINONIMI_COMANDI",
    "UNITA", "UNITA_DEI_COMANDI", "PROPRIETA_DI_TESTO", "genere_unita", "Definizioni", "Pezzo", "ComandoLetto",
    "genere_comando", "trova_definizioni", "definizioni_progetto", "nomi_predefiniti", "e_comando",
]

#: Comandi di testo: dopo il nome tutto e' testo; le parentesi calcolano.
COMANDI_TESTO = frozenset({"stampa", "messaggio", "chiedi", "domanda", "scrivi_qui", "suona"})
#: Comandi di valore: valori separati da virgola.
COMANDI_VALORE = frozenset({
    "avanti", "indietro", "destra", "sinistra", "punta_verso", "vai_a", "cerchio", "colore", "sfondo",
    "spessore", "riempi", "velocità", "velocita", "attendi", "apri_finestra", "chiudi_finestra",
    "suona_file", "salva_disegno",
})
#: Comandi senza valori.
COMANDI_SENZA = frozenset({
    "casa", "penna_su", "penna_giu", "penna_giù", "pulisci_disegno", "fine_riempi", "nascondi_tartaruga",
    "mostra_tartaruga", "mostra_disegno", "colore_casuale", "ferma_suoni", "aspetta_animazioni",
})
#: Comandi ammessi anche come lato destro di ``=``: ``variabile nome = chiedi Come ti chiami?``.
COMANDI_DOPO_UGUALE = frozenset({"chiedi", "domanda"})
#: Sinonimi veri dei comandi (valgono anche nella forma classica: ``scrivi("ciao")``).
SINONIMI_COMANDI = {"scrivi": "stampa"}

#: Unita' facoltative: parola -> (fattore, genere). ``attendi 500 millisecondi`` = ``attendi(0.5)``.
UNITA: dict[str, tuple[float, str]] = {
    "secondi": (1, "tempo"), "secondo": (1, "tempo"), "s": (1, "tempo"), "sec": (1, "tempo"),
    "millisecondi": (0.001, "tempo"), "millisecondo": (0.001, "tempo"), "ms": (0.001, "tempo"),
    "minuti": (60, "tempo"), "minuto": (60, "tempo"),
    "passi": (1, "lunghezza"), "passo": (1, "lunghezza"), "pixel": (1, "lunghezza"), "px": (1, "lunghezza"),
    "gradi": (1, "angolo"), "grado": (1, "angolo"), "°": (1, "angolo"),
}
#: Genere di unita' che ogni comando accetta (una tupla: un genere per ogni valore).
UNITA_DEI_COMANDI: dict[str, str | tuple[str, ...]] = {
    "attendi": "tempo",
    "avanti": "lunghezza", "indietro": "lunghezza", "cerchio": ("lunghezza", "angolo"), "vai_a": "lunghezza",
    "spessore": "lunghezza",
    "destra": "angolo", "sinistra": "angolo", "punta_verso": "angolo",
}


def genere_unita(comando: str, indice: int = 0) -> str | None:
    """Genere di unita' del valore numero ``indice`` del comando (``None``: qualunque)."""
    genere = UNITA_DEI_COMANDI.get(comando)
    if isinstance(genere, tuple):
        return genere[indice] if indice < len(genere) else None
    return genere
_NOME_GENERE = {"tempo": "secondi", "lunghezza": "passi", "angolo": "gradi"}

#: Proprieta' di testo degli oggetti: ``Etichetta1.testo = Ciao (nome)`` segue la regola dei
#: comandi di testo (se cio' che segue ``=`` non e' gia' un calcolo valido).
PROPRIETA_DI_TESTO = frozenset({
    "testo", "titolo", "scritta", "suggerimento", "segnaposto", "testo_pulsante", "didascalia",
})


def genere_comando(nome: str) -> str | None:
    """``"testo"``, ``"valore"``, ``"senza"`` oppure ``None`` (non e' un comando)."""
    nome = SINONIMI_COMANDI.get(nome, nome)
    if nome in COMANDI_TESTO:
        return "testo"
    if nome in COMANDI_VALORE:
        return "valore"
    if nome in COMANDI_SENZA:
        return "senza"
    return None


def e_comando(nome: str) -> bool:
    """Vero se ``nome`` e' un comando della libreria che si scrive anche senza parentesi."""
    return genere_comando(nome) is not None


def nome_unita(genere: str) -> str:
    return _NOME_GENERE.get(genere, genere)


# ---------------------------------------------------------------------------
# Risultato della lettura di una riga (per l'editor: leo.lettura)
# ---------------------------------------------------------------------------

@dataclass
class Pezzo:
    """Un pezzo di un comando senza parentesi.

    ``tipo``: ``"testo"`` (scritto cosi' com'e'), ``"calcolo"`` (tra parentesi o
    un'espressione: si calcola), ``"numero"`` (numero di un comando di valore,
    ``valore`` = il numero gia' convertito con l'unita').
    ``colonna`` parte da 1; ``lunghezza`` in caratteri.
    """

    tipo: str
    testo: str
    colonna: int
    lunghezza: int
    valore: Any = None


@dataclass
class ComandoLetto:
    """Un comando senza parentesi riconosciuto dal lexer."""

    riga: int
    colonna: int
    nome: str              # forma canonica (``stampa`` anche per ``Scrivi``)
    scritto: str           # come e' scritto (``Scrivi``)
    genere: str            # testo | valore | senza | metodo | proprieta | utente
    pezzi: list[Pezzo] = field(default_factory=list)
    #: colonna dopo l'ultimo carattere del comando (prima di un commento o di ``fine``)
    fine_colonna: int = 0


# ---------------------------------------------------------------------------
# Definizioni del programma (nomi dell'utente)
# ---------------------------------------------------------------------------

@dataclass
class Definizioni:
    """Nomi definiti da un programma (o da un progetto)."""

    #: nome -> (riga, file) della prima definizione
    nomi: dict[str, tuple[int, str]] = field(default_factory=dict)
    #: funzioni senza ``restituisci``: si usano come comandi (``saluta Giulia``)
    comandi: set[str] = field(default_factory=set)
    #: funzioni con ``restituisci``: danno un valore, vogliono le parentesi
    funzioni_valore: set[str] = field(default_factory=set)
    #: nomi dei controlli delle maschere del progetto (``Etichetta1``)
    controlli: set[str] = field(default_factory=set)
    #: ``importa *`` o simili: possono esistere nomi che non si vedono
    nomi_nascosti: bool = False

    def unisci(self, altra: "Definizioni | None") -> "Definizioni":
        if altra is None:
            return self
        nuova = Definizioni(dict(altra.nomi), set(altra.comandi), set(altra.funzioni_valore),
                            set(altra.controlli), altra.nomi_nascosti or self.nomi_nascosti)
        nuova.nomi.update(self.nomi)
        nuova.controlli |= self.controlli
        # le definizioni di questo file vincono su quelle degli altri
        nuova.comandi = (nuova.comandi - self.funzioni_valore) | self.comandi
        nuova.funzioni_valore = (nuova.funzioni_valore - self.comandi) | self.funzioni_valore
        return nuova


_PAROLE_PREDEFINITE: dict[str, list[str]] | None = None


def _parole_predefinite() -> dict[str, list[str]]:
    """Forme (anche sinonimi) delle parole che definiscono nomi."""
    global _PAROLE_PREDEFINITE
    if _PAROLE_PREDEFINITE is None:
        from .tokens import TipoToken as T
        voci: dict[str, list[str]] = {}
        try:
            from .sinonimi import carica_sinonimi
            mappa = carica_sinonimi().mappa
        except Exception:
            mappa = {}
        tabella = {(T.VARIABILE.value,): T.VARIABILE, (T.COSTANTE.value,): T.COSTANTE,
                   (T.FUNZIONE.value,): T.FUNZIONE, ("per", "ogni"): T.PER_OGNI,
                   (T.RESTITUISCI.value,): T.RESTITUISCI, (T.FINE.value,): T.FINE,
                   (T.CATTURA.value,): T.CATTURA, ("crea", "variabile"): T.VARIABILE,
                   ("crea", "costante"): T.COSTANTE}
        tabella.update(mappa)
        for chiave, tipo in tabella.items():
            voci.setdefault(tipo.name, []).append(" ".join(chiave))
        _PAROLE_PREDEFINITE = voci
    return _PAROLE_PREDEFINITE


def parole_da_tabella(tabella: dict) -> dict[str, list[str]]:
    """Dalla tabella del lexer (parole -> (tipo, origine)) alle forme per tipo."""
    voci: dict[str, list[str]] = {}
    for chiave, (tipo, _origine) in tabella.items():
        voci.setdefault(tipo.name, []).append(" ".join(chiave))
    return voci


def _alternativa(forme: Iterable[str]) -> str:
    forme = sorted(set(forme), key=len, reverse=True)
    return "|".join(r"[ \t]+".join(re.escape(p) for p in f.split()) for f in forme)


_RE_NOME = re.compile(r"[^\W\d]\w*")
_RE_IMPLICITA = re.compile(r"^[ \t]*([^\W\d]\w*(?:[ \t]*,[ \t]*[^\W\d]\w*)*)[ \t]*(?::[^=]*)?=(?!=)")


def _pulisci_riga(riga: str, stato: list[bool]) -> str:
    """La riga senza testi tra virgolette e senza commento (``stato[0]``: dentro ``\"\"\"``)."""
    if not stato[0] and '"' not in riga and "#" not in riga:
        return riga
    fuori: list[str] = []
    i = 0
    n = len(riga)
    while i < n:
        if stato[0]:
            j = riga.find('"""', i)
            if j < 0:
                return "".join(fuori)
            stato[0] = False
            fuori.append('""')
            i = j + 3
            continue
        c = riga[i]
        if riga.startswith('"""', i):
            stato[0] = True
            i += 3
            continue
        if c == '"':
            j = i + 1
            while j < n and riga[j] != '"':
                j += 2 if riga[j] == "\\" else 1
            fuori.append('""')
            i = j + 1
            continue
        if c == "#":
            break
        fuori.append(c)
        i += 1
    return "".join(fuori)


def _rientro(riga: str) -> int:
    return len(riga) - len(riga.lstrip(" \t"))


def _prima_parola(riga: str) -> tuple[str, str]:
    s = riga.lstrip(" \t")
    m = _RE_NOME.match(s)
    if not m:
        return "", s
    return m.group(0), s[m.end():]


def _riga_di_testo(riga: str) -> bool:
    """Vero se la riga e' un comando di testo senza parentesi (il resto e' testo)."""
    parola, resto = _prima_parola(riga)
    if not parola:
        return False
    nome = parola[0].lower() + parola[1:]
    if genere_comando(nome) != "testo":
        return False
    if not resto[:1] in (" ", "\t"):
        return False
    resto = resto.lstrip(" \t")
    return bool(resto) and resto[0] not in "(=.[,+-*/" and not resto.startswith('"')


def _parametri(testo: str) -> list[str]:
    nomi = []
    for pezzo in testo.split(","):
        pezzo = pezzo.strip().lstrip(".").strip()
        m = _RE_NOME.match(pezzo)
        if m:
            nomi.append(m.group(0))
    return nomi


def trova_definizioni(sorgente: str, parole: dict[str, list[str]] | None = None,
                      nome_file: str = "") -> Definizioni:
    """Nomi definiti in ``sorgente`` (variabili, costanti, funzioni, parametri, variabili
    dei cicli, ``cattura come e``, ``importa``, assegnazioni ``x = ...``) e quali funzioni
    non restituiscono niente (comandi). Analisi per righe, veloce e prudente: i testi tra
    virgolette, i commenti e le righe dei comandi di testo non definiscono niente."""
    if parole is None:
        parole = _parole_predefinite()
    regole = _regole(parole)
    return _trova(sorgente, regole, nome_file)


_CACHE_REGOLE: dict[tuple, tuple] = {}


def _regole(parole: dict[str, list[str]]) -> tuple:
    chiave = tuple(sorted((k, tuple(sorted(v))) for k, v in parole.items()))
    gia = _CACHE_REGOLE.get(chiave)
    if gia is not None:
        return gia
    alt = {k: _alternativa(v) for k, v in parole.items() if v}
    inizio = r"(?:^|(?<=[\s;]))"
    re_dich = re.compile(inizio + r"(?:%s)[ \t]+([^\W\d]\w*(?:[ \t]*,[ \t]*[^\W\d]\w*)*)"
                         % "|".join(x for x in (alt.get("VARIABILE"), alt.get("COSTANTE")) if x)) \
        if alt.get("VARIABILE") or alt.get("COSTANTE") else None
    re_funz = re.compile(inizio + r"(?:%s)(?:[ \t]+([^\W\d]\w*))?[ \t]*(?:\(([^)]*)\)|[ \t]+con[ \t]+([^\n]*))?"
                         % alt["FUNZIONE"]) if alt.get("FUNZIONE") else None
    re_per = re.compile(inizio + r"(?:%s)[ \t]+([^\W\d]\w*(?:[ \t]*,[ \t]*[^\W\d]\w*)*)" % alt["PER_OGNI"]) \
        if alt.get("PER_OGNI") else None
    re_rest = re.compile(r"(?<!\w)(?:%s)(?!\w)" % alt["RESTITUISCI"]) if alt.get("RESTITUISCI") else None
    re_fine = re.compile(r"^(?:%s)(?!\w)" % alt["FINE"]) if alt.get("FINE") else None
    re_catt = re.compile(inizio + r"(?:%s)(?!\w)(.*)" % alt["CATTURA"]) if alt.get("CATTURA") else None
    re_import = re.compile(inizio + r"(?:da[ \t]+\S+[ \t]+)?importa(?!\w)(.*)")
    re_fine_ovunque = re.compile(r"(?<!\w)(?:%s)(?!\w)" % alt["FINE"]) if alt.get("FINE") else None
    prime = {f.split()[0] for k in ("VARIABILE", "COSTANTE", "FUNZIONE", "PER_OGNI", "CATTURA")
             for f in parole.get(k, ())} | {"importa", "quando"}
    re_scatto = re.compile(r"(?<!\w)(?:%s)(?!\w)|=" % "|".join(re.escape(x) for x in sorted(prime)))
    regole = (re_dich, re_funz, re_per, re_rest, re_fine, re_catt, re_import, re_fine_ovunque, re_scatto)
    if len(_CACHE_REGOLE) > 32:
        _CACHE_REGOLE.clear()
    _CACHE_REGOLE[chiave] = regole
    return regole


_RE_STRUTTURA = re.compile(r"(?:pubblica[ \t]+)?(struttura|tipo)[ \t]+([^\W\d]\w*)")
_RE_UNO_DI = re.compile(r"(?:è|e')[ \t]+uno[ \t]+di\b")
_RE_VARIANTE = re.compile(r"([^\W\d]\w*)[ \t]*(?:\(|$)")


def _trova(sorgente: str, regole: tuple, nome_file: str) -> Definizioni:
    re_dich, re_funz, re_per, re_rest, re_fine, re_catt, re_import, re_fine_ovunque, re_scatto = regole
    righe = sorgente.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    stato = [False]
    pulite = [_pulisci_riga(r, stato) for r in righe]
    d = Definizioni()

    def aggiungi(nome: str, riga: int) -> None:
        if nome and nome not in d.nomi:
            d.nomi[nome] = (riga, nome_file)

    funzioni: list[tuple[str, int]] = []
    for n, p in enumerate(pulite):
        if not re_scatto.search(p) or _riga_di_testo(p):
            continue                    # niente che possa definire un nome
        riga = n + 1
        if re_dich is not None:
            for m in re_dich.finditer(p):
                for nome in _parametri(m.group(1)):
                    aggiungi(nome, riga)
        if re_funz is not None:
            for m in re_funz.finditer(p):
                if m.group(1):
                    aggiungi(m.group(1), riga)
                    funzioni.append((m.group(1), n))
                for gruppo in (m.group(2), m.group(3)):
                    if gruppo:
                        for nome in _parametri(gruppo):
                            aggiungi(nome, riga)
        if re_per is not None:
            for m in re_per.finditer(p):
                for nome in _parametri(m.group(1)):
                    aggiungi(nome, riga)
        if re_catt is not None:
            m = re_catt.search(p)
            if m:
                for nome in _RE_NOME.findall(m.group(1)):
                    if nome not in ("come", "allora", "fai"):
                        aggiungi(nome, riga)
        m = re_import.search(p)
        if m:
            resto = m.group(1)
            if "*" in resto:
                d.nomi_nascosti = True
            for nome in _RE_NOME.findall(resto):
                if nome != "come":
                    aggiungi(nome, riga)
        m = _RE_IMPLICITA.match(p)
        if m:
            for nome in _parametri(m.group(1)):
                aggiungi(nome, riga)
        if p.lstrip().startswith("quando") and ("(" in p or " con " in p):
            # parametri dell'evento: quando Tela1.clic(x, y) / ... con x, y
            for g in re.findall(r"\(([^)]*)\)", p) + re.findall(r"[ \t]con[ \t]+(.*?)(?:[ \t]+fai\b|$)", p):
                for nome in _parametri(g):
                    aggiungi(nome, riga)
    # `struttura Punto`, `tipo Forma è uno di` e le sue varianti (`Cerchio(r: decimale)`,
    # `Vuota`): nomi dell'utente, mai comandi (Cerchio non è il comando cerchio)
    nel_tipo = False
    for n, p in enumerate(pulite):
        s = p.strip()
        if nel_tipo:
            if re_fine is not None and re_fine.match(s):
                nel_tipo = False
                continue
            m = _RE_VARIANTE.match(s)
            if m:
                aggiungi(m.group(1), n + 1)
            continue
        m = _RE_STRUTTURA.match(s)
        if m:
            aggiungi(m.group(2), n + 1)
            nel_tipo = m.group(1) == "tipo" and bool(_RE_UNO_DI.search(s[m.end():]))
    # funzioni con o senza `restituisci`: il corpo va fino al `fine` con lo stesso rientro
    for nome, n in funzioni:
        intestazione = pulite[n]
        restituisce = False
        dopo = intestazione[intestazione.find(nome) + len(nome):]
        if re_rest is not None and re_rest.search(dopo):
            restituisce = True
        elif re_fine_ovunque is not None and re_fine_ovunque.search(dopo):
            restituisce = False          # funzione su una riga senza restituisci
        else:
            rientro = _rientro(righe[n])
            for m in range(n + 1, len(pulite)):
                p = pulite[m]
                s = p.strip()
                if not s:
                    continue
                if re_fine is not None and re_fine.match(s) and _rientro(righe[m]) <= rientro:
                    break
                if re_rest is not None and re_rest.search(p):
                    restituisce = True
                    break
        (d.funzioni_valore if restituisce else d.comandi).add(nome)
    return d


# ---------------------------------------------------------------------------
# Progetto: gli altri file .leo e i controlli delle maschere
# ---------------------------------------------------------------------------

_CACHE_PROGETTO: dict[str, tuple[tuple, Definizioni]] = {}
_RE_CONTROLLO = re.compile(r'^\s*nome\s*=\s*"([^"]+)"', re.M)
_RE_IMPORTA_FILE = re.compile(r'importa[ \t]+"([^"]+\.leo)"')


def _file_progetto(cartella: str, nome_file: str) -> list[str]:
    """I file .leo e .maschera del progetto di ``nome_file`` (escluso lui stesso)."""
    file: list[str] = []
    progetto = os.path.isfile(os.path.join(cartella, "progetto.toml"))
    if progetto:
        try:
            for voce in sorted(os.listdir(cartella)):
                if voce.endswith((".leo", ".maschera")):
                    file.append(os.path.join(cartella, voce))
        except OSError:
            return []
    else:
        # file singolo: solo i file che importa con `importa "altro.leo"`
        try:
            with open(nome_file, encoding="utf-8-sig") as fh:
                testo = fh.read()
        except (OSError, UnicodeDecodeError):
            return []
        for m in _RE_IMPORTA_FILE.finditer(testo):
            percorso = os.path.join(cartella, m.group(1))
            if os.path.isfile(percorso):
                file.append(percorso)
    stesso = os.path.abspath(nome_file)
    return [f for f in file if os.path.abspath(f) != stesso]


def definizioni_progetto(nome_file: str | None) -> Definizioni | None:
    """Definizioni degli ALTRI file del progetto di ``nome_file`` (con ``progetto.toml``
    nella stessa cartella) o dei file che importa; ``None`` se non c'e' niente."""
    if not nome_file or nome_file.startswith("<"):
        return None
    try:
        if not os.path.isfile(nome_file):
            return None
        cartella = os.path.dirname(os.path.abspath(nome_file))
        file = _file_progetto(cartella, nome_file)
        if not file:
            return None
        chiave_tempi = tuple((f, os.path.getmtime(f)) for f in file)
    except OSError:
        return None
    chiave = os.path.abspath(nome_file)
    gia = _CACHE_PROGETTO.get(chiave)
    if gia is not None and gia[0] == chiave_tempi:
        return gia[1]
    totale = Definizioni()
    for f in file:
        try:
            with open(f, encoding="utf-8-sig") as fh:
                testo = fh.read()
        except (OSError, UnicodeDecodeError):
            continue
        if f.endswith(".maschera"):
            totale.controlli.update(_RE_CONTROLLO.findall(testo))
        else:
            totale = trova_definizioni(testo, nome_file=os.path.basename(f)).unisci(totale)
    if len(_CACHE_PROGETTO) > 64:
        _CACHE_PROGETTO.clear()
    _CACHE_PROGETTO[chiave] = (chiave_tempi, totale)
    return totale


# ---------------------------------------------------------------------------
# Nomi che esistono sempre (libreria, costanti, errori, tipi dei controlli)
# ---------------------------------------------------------------------------

_PREDEFINITI: frozenset[str] | None = None


def nomi_predefiniti() -> frozenset[str]:
    """Nomi della libreria standard, costanti, tipi d'errore e tipi dei controlli."""
    global _PREDEFINITI
    if _PREDEFINITI is None:
        nomi: set[str] = {"evento"}
        try:
            from . import registro
            registro.carica_libreria()
            nomi |= set(registro.FUNZIONI) | set(registro.COSTANTI)
        except Exception:
            pass
        try:
            from .errori import TIPI_ERRORE
            nomi |= set(TIPI_ERRORE)
        except Exception:
            pass
        try:
            from .grafica import metadati
            metadati.carica_catalogo()
            nomi |= set(metadati.CATALOGO)
        except Exception:
            pass
        _PREDEFINITI = frozenset(nomi)
    return _PREDEFINITI


def funzioni_libreria() -> frozenset[str]:
    try:
        from . import registro
        registro.carica_libreria()
        return frozenset(registro.FUNZIONI)
    except Exception:
        return frozenset()
