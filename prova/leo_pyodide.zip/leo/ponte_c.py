"""Ponte verso C/native: usare da Leo una libreria .so/.dll/.dylib (ctypes).

    importa c "m" come mate
    mate.dichiara("sqrt", "decimale", ["decimale"])
    stampa(mate.sqrt(2.0))

Tipi (come testo): "intero", "decimale", "logico", "testo", "puntatore", "byte", "nulla".
In più:
    x.struttura("Punto", {"x": "decimale", "y": "decimale"})   -> un tipo struttura C
    x.callback("intero", ["intero", "intero"])                 -> un tipo di funzione C (callback)
    memoria_c(n)                                                -> un buffer di n byte modificabile
Gli errori del C diventano errori Leo in italiano. Nel browser e su Android `importa c`
non è disponibile (messaggio chiaro).
"""
from __future__ import annotations

import ctypes
import ctypes.util
import os
from typing import Any

from .errori import ErroreDante, ErroreFile, ErroreIndice, ErroreNome, ErroreTipo, ErroreValore
from .valori import Richiamabile, rappresenta

_TIPI = {
    "intero": ctypes.c_longlong,
    "intero32": ctypes.c_int,
    "decimale": ctypes.c_double,
    "decimale32": ctypes.c_float,
    "logico": ctypes.c_bool,
    "testo": ctypes.c_char_p,
    "puntatore": ctypes.c_void_p,
    "byte": ctypes.c_ubyte,
    "nulla": None,
}
_ELENCO_TIPI = "intero, decimale, logico, testo, puntatore, byte, nulla (o una struttura/callback)"

#: Mantiene vive le callback: senza riferimento, ctypes libera la closure e il C va in crash.
_CALLBACK_VIVE: list = []
#: Ultimo interprete attivo, per le callback chiamate dal C.
_INTERPRETE: list = []


def _tipo_c(nome_tipo: Any, dove: str):
    if nome_tipo in (None, "nulla"):
        return None
    if isinstance(nome_tipo, TipoStruttura):
        return nome_tipo.ctype
    if isinstance(nome_tipo, TipoCallback):
        return nome_tipo.cfunctype
    t = _TIPI.get(nome_tipo)
    if t is None:
        raise ErroreTipo(
            f"`{dove}`: non conosco il tipo C `{rappresenta(nome_tipo)}`.",
            suggerimento=f"Scrivi il tipo come testo. Tipi possibili: {_ELENCO_TIPI}.",
        )
    return t


def _degrado(dove: str) -> None:
    from .piattaforma import non_su_web, e_android, errore_android

    non_su_web(dove)
    if e_android():
        raise errore_android(dove)


def trova_libreria(nome: str) -> str:
    basso = nome.lower()
    esplicito = os.sep in nome or basso.endswith((".so", ".dll", ".dylib")) or ".so." in basso
    if esplicito:
        if os.sep in nome and not os.path.exists(nome):
            raise ErroreFile(
                f"Non trovo la libreria C `{nome}`.",
                suggerimento="Scrivi il percorso completo del file .so/.dll/.dylib.",
            )
        return nome
    trovato = ctypes.util.find_library(nome)
    if trovato is None:
        raise ErroreNome(
            f"Non trovo la libreria C `{nome}` sul sistema.",
            suggerimento=f'Installa la libreria, oppure indica il percorso: '
            f'`importa c "/percorso/lib{nome}.so" come {nome}`.',
            nome=nome,
        )
    return trovato


def carica_libreria(nome: str, interprete: Any = None) -> "LibreriaC":
    _degrado(f'importa c "{nome}"')
    if interprete is not None:
        if interprete in _INTERPRETE:
            _INTERPRETE.remove(interprete)
        _INTERPRETE.append(interprete)
        del _INTERPRETE[:-4]
    percorso = trova_libreria(nome)
    try:
        dll = ctypes.CDLL(percorso)
    except OSError as e:
        raise ErroreFile(
            f"Non riesco a caricare la libreria C `{nome}`: {e}.",
            suggerimento="Controlla che sia della stessa architettura (32 o 64 bit) di Leo.",
        ) from None
    return LibreriaC(nome, dll)


def usa_libreria_c(nome: str, interprete: Any = None) -> "LibreriaC":
    """Come `importa c "nome"`, ma come funzione: restituisce la libreria C."""
    return carica_libreria(nome, interprete)


class LibreriaC:
    NOME_TIPO_DANTE = "libreria c"
    ATTRIBUTI_DANTE = True
    _SPECIALI = ("dichiara", "struttura", "callback")

    def __init__(self, nome: str, dll: Any) -> None:
        self._nome = nome
        self._dll = dll
        self._firme: dict[str, FunzioneC] = {}
        self._tipi: dict[str, TipoStruttura] = {}

    def dichiara_funzione(self, nome, restituisce="nulla", parametri=None):
        if not isinstance(nome, str):
            raise ErroreTipo("`dichiara` vuole il nome della funzione C come testo.")
        try:
            simbolo = getattr(self._dll, nome)
        except AttributeError:
            raise ErroreNome(
                f"La libreria `{self._nome}` non ha la funzione C `{nome}`.",
                suggerimento="Controlla il nome esatto: il C distingue maiuscole e minuscole.",
                nome=nome,
            ) from None
        if parametri is None:
            parametri = []
        if not isinstance(parametri, (list, tuple)):
            raise ErroreTipo('`parametri` di `dichiara` vuole una lista di tipi, per esempio ["decimale"].')
        parametri = [self._tipi.get(p, p) if isinstance(p, str) else p for p in parametri]
        if isinstance(restituisce, str):
            restituisce = self._tipi.get(restituisce, restituisce)
        simbolo.restype = _tipo_c(restituisce, nome)
        simbolo.argtypes = [_tipo_c(p, nome) for p in parametri]
        f = FunzioneC(self._nome, nome, simbolo, restituisce, list(parametri))
        self._firme[nome] = f
        return f

    def crea_struttura(self, nome, campi):
        if not isinstance(nome, str) or not nome.isidentifier():
            raise ErroreValore('Il primo argomento di `struttura` è il nome del tipo, per esempio "Punto".')
        if not isinstance(campi, dict) or not campi:
            raise ErroreTipo('Il secondo argomento di `struttura` è un dizionario {"campo": "tipo"}.')
        risolti = {k: (self._tipi[v] if isinstance(v, str) and v in self._tipi else v) for k, v in campi.items()}
        tipo = TipoStruttura(nome, risolti)
        self._tipi[nome] = tipo
        return tipo

    def crea_callback(self, ritorno="nulla", parametri=None):
        return TipoCallback(ritorno, list(parametri or []))

    def attributo_dante(self, nome):
        if nome in self._SPECIALI:
            return _MetodoLibreria(self, nome)
        if nome in self._tipi:
            return self._tipi[nome]
        f = self._firme.get(nome)
        if f is not None:
            return f
        raise ErroreNome(
            f"`{self._nome}` non ha `{nome}`.",
            suggerimento=f'Prima dichiara la funzione: '
            f'`{self._nome}.dichiara("{nome}", "decimale", ["decimale"])`.',
            nome=nome,
        )

    def leggi(self, nome):
        return self.attributo_dante(nome)

    def testo_dante(self):
        return f"<libreria c {self._nome}>"


class _MetodoLibreria(Richiamabile):
    def __init__(self, libreria, nome):
        self._libreria = libreria
        self.nome = nome

    def chiama(self, interprete, argomenti, argomenti_nome):
        lib, nome = self._libreria, self.nome
        if nome == "dichiara":
            if not argomenti:
                raise ErroreTipo('`dichiara` vuole il nome della funzione C.',
                                 suggerimento='Per esempio `m.dichiara("sqrt", "decimale", ["decimale"])`.')
            restituisce = argomenti_nome.get("restituisce", argomenti[1] if len(argomenti) > 1 else "nulla")
            parametri = argomenti_nome.get("parametri", argomenti[2] if len(argomenti) > 2 else None)
            return lib.dichiara_funzione(argomenti[0], restituisce, parametri)
        if nome == "struttura":
            if len(argomenti) < 2:
                raise ErroreTipo('`struttura` vuole il nome e i campi, per esempio `s.struttura("Punto", {"x": "decimale"})`.')
            return lib.crea_struttura(argomenti[0], argomenti[1])
        if nome == "callback":
            ritorno = argomenti_nome.get("restituisce", argomenti[0] if argomenti else "nulla")
            parametri = argomenti_nome.get("parametri", argomenti[1] if len(argomenti) > 1 else None)
            return lib.crea_callback(ritorno, parametri)
        raise ErroreNome(f"Metodo `{nome}` sconosciuto.")

    def testo_dante(self):
        return f"<metodo {self.nome}>"


class FunzioneC(Richiamabile):
    def __init__(self, libreria, nome, simbolo, restituisce, parametri):
        self.nome = nome
        self._libreria = libreria
        self._sym = simbolo
        self._restituisce = restituisce
        self._parametri = parametri

    def chiama(self, interprete, argomenti, argomenti_nome):
        if argomenti_nome:
            raise ErroreTipo(f"La funzione C `{self.nome}` vuole gli argomenti in ordine, non per nome.")
        if len(argomenti) != len(self._parametri):
            raise ErroreTipo(
                f"`{self.nome}` vuole {len(self._parametri)} argomenti, ma ne ha ricevuti {len(argomenti)}."
            )
        try:
            grezzi = [_verso_c(a, t, self.nome, interprete) for a, t in zip(argomenti, self._parametri)]
            risultato = self._sym(*grezzi)
        except (ctypes.ArgumentError, TypeError) as e:
            raise ErroreTipo(f"Argomenti non adatti per la funzione C `{self.nome}`: {e}.") from None
        except OSError as e:
            raise ErroreValore(f"La funzione C `{self.nome}` è andata in errore: {e}.") from None
        return _da_c(risultato, self._restituisce)

    def testo_dante(self):
        return f"<funzione c {self._libreria}.{self.nome}>"


# ----------------------------------------------------------------- memoria
def memoria_c(dimensione_o_dati):
    """memoria_c(n): alloca n byte azzerati e modificabili da passare a funzioni C."""
    return ByteC(dimensione_o_dati)


class ByteC:
    NOME_TIPO_DANTE = "byte C"
    ATTRIBUTI_DANTE = True
    _METODI = ("testo", "byte", "lunghezza", "puntatore", "scrivi_testo", "libera")

    def __init__(self, dimensione_o_dati):
        if isinstance(dimensione_o_dati, bool) or not isinstance(dimensione_o_dati, (int, bytes, bytearray)):
            raise ErroreTipo("`memoria_c` vuole un numero di byte, oppure dei byte da copiare.")
        if isinstance(dimensione_o_dati, int):
            if dimensione_o_dati < 0:
                raise ErroreValore("La dimensione della memoria non può essere negativa.")
            if dimensione_o_dati > (1 << 30):
                raise ErroreValore("Memoria richiesta troppo grande (oltre 1 GB).")
            self._buf = ctypes.create_string_buffer(dimensione_o_dati)
        else:
            dati = bytes(dimensione_o_dati)
            self._buf = ctypes.create_string_buffer(dati, len(dati))
        self._liberato = False

    def _vivo(self):
        if self._liberato:
            raise ErroreValore("Questa memoria è già stata liberata: non si può più usare.")
        return self._buf

    def indice_dante(self, indice):
        buf = self._vivo()
        if isinstance(indice, bool) or not isinstance(indice, int):
            raise ErroreTipo("La posizione in un `byte C` deve essere un intero.")
        try:
            return buf.raw[indice]
        except IndexError:
            raise ErroreIndice(f"Posizione {indice} fuori dai limiti ({len(buf.raw)} byte).") from None

    def scrivi_indice_dante(self, indice, valore):
        buf = self._vivo()
        if isinstance(valore, bool) or not isinstance(valore, int) or not 0 <= valore <= 255:
            raise ErroreTipo("In un `byte C` si scrivono numeri da 0 a 255.")
        try:
            buf[indice] = bytes([valore])
        except IndexError:
            raise ErroreIndice(f"Posizione {indice} fuori dai limiti ({len(buf.raw)} byte).") from None

    def lunghezza_dante(self):
        return len(self._vivo().raw)

    def attributo_dante(self, nome):
        if nome not in self._METODI:
            raise ErroreNome(f"Un `byte C` non ha `{nome}`.",
                             suggerimento="Metodi: " + ", ".join(f"`{m}`" for m in self._METODI) + ".", nome=nome)
        return _MetodoByteC(self, nome)

    leggi = attributo_dante

    def valore_python(self):
        return self._vivo()

    def testo_dante(self):
        if self._liberato:
            return "<byte C: liberato>"
        return f"<byte C: {len(self._buf.raw)} byte>"


class _MetodoByteC(Richiamabile):
    def __init__(self, bc, nome):
        self.bc, self.nome = bc, nome

    def chiama(self, interprete, argomenti, argomenti_nome):
        bc, nome = self.bc, self.nome
        if nome == "lunghezza":
            return bc.lunghezza_dante()
        if nome == "byte":
            from .ponte_python import Byte
            return Byte(bc._vivo().raw)
        if nome == "testo":
            cod = argomenti[0] if argomenti else argomenti_nome.get("codifica", "utf-8")
            return bc._vivo().value.decode(str(cod), errors="replace")
        if nome == "scrivi_testo":
            testo = argomenti[0] if argomenti else argomenti_nome.get("testo", "")
            dati = str(testo).encode("utf-8") + b"\0"
            buf = bc._vivo()
            if len(dati) > len(buf.raw):
                raise ErroreValore(f"Il testo ({len(dati)} byte) non entra in {len(buf.raw)} byte.")
            buf[:len(dati)] = dati
            return None
        if nome == "puntatore":
            return ctypes.cast(bc._vivo(), ctypes.c_void_p).value or 0
        if nome == "libera":
            bc._liberato = True
            bc._buf = ctypes.create_string_buffer(0)
            return None
        raise ErroreNome(f"Un `byte C` non ha `{nome}`.")

    def testo_dante(self):
        return f"<metodo byte C {self.nome}>"


# ----------------------------------------------------------------- struct
class TipoStruttura(Richiamabile):
    NOME_TIPO_DANTE = "tipo struttura C"

    def __init__(self, nome, campi):
        self.nome = nome
        self._campi = campi
        self._sottotipi = {}
        campi_ctypes = []
        for nome_campo, tipo in campi.items():
            if isinstance(tipo, TipoStruttura):
                campi_ctypes.append((nome_campo, tipo.ctype))
                self._sottotipi[nome_campo] = tipo
            else:
                ct = _TIPI.get(tipo)
                if ct is None or tipo == "nulla":
                    raise ErroreValore(
                        f"Nella struttura `{nome}` il campo `{nome_campo}` ha un tipo non valido `{rappresenta(tipo)}`.",
                        suggerimento="Tipi dei campi: intero, decimale, logico, testo, puntatore, byte.")
                campi_ctypes.append((nome_campo, ct))
        self.ctype = type(f"Struct_{nome}", (ctypes.Structure,), {"_fields_": campi_ctypes})

    def chiama(self, interprete, argomenti, argomenti_nome):
        grezzo = self.ctype()
        nomi = list(self._campi)
        if argomenti:
            if len(argomenti) > len(nomi):
                raise ErroreTipo(f"La struttura `{self.nome}` ha {len(nomi)} campi, ricevuti {len(argomenti)} valori.")
            for nome_campo, valore in zip(nomi, argomenti):
                _scrivi_campo(grezzo, nome_campo, self._campi[nome_campo], valore, self._sottotipi)
        for nome_campo, valore in argomenti_nome.items():
            if nome_campo not in self._campi:
                raise ErroreNome(f"La struttura `{self.nome}` non ha il campo `{nome_campo}`.",
                                 suggerimento="Campi: " + ", ".join(f"`{c}`" for c in self._campi) + ".")
            _scrivi_campo(grezzo, nome_campo, self._campi[nome_campo], valore, self._sottotipi)
        return ValoreStruttura(self, grezzo)

    def da_c(self, grezzo):
        return ValoreStruttura(self, grezzo)

    def testo_dante(self):
        return f"<struttura C {self.nome}>"


class ValoreStruttura:
    NOME_TIPO_DANTE = "struttura C"
    ATTRIBUTI_DANTE = True

    def __init__(self, tipo, grezzo):
        self._tipo = tipo
        self.grezzo = grezzo

    def attributo_dante(self, nome):
        if nome not in self._tipo._campi:
            raise ErroreNome(f"La struttura `{self._tipo.nome}` non ha il campo `{nome}`.",
                             suggerimento="Campi: " + ", ".join(f"`{c}`" for c in self._tipo._campi) + ".", nome=nome)
        return _leggi_campo(self.grezzo, nome, self._tipo._campi[nome], self._tipo._sottotipi)

    def scrivi_attributo_dante(self, nome, valore):
        if nome not in self._tipo._campi:
            raise ErroreNome(f"La struttura `{self._tipo.nome}` non ha il campo `{nome}`.", nome=nome)
        _scrivi_campo(self.grezzo, nome, self._tipo._campi[nome], valore, self._tipo._sottotipi)

    leggi = attributo_dante
    scrivi = scrivi_attributo_dante

    def valore_python(self):
        return self.grezzo

    def testo_dante(self):
        parti = ", ".join(f"{c}: {rappresenta(self.attributo_dante(c))}" for c in self._tipo._campi)
        return f"{self._tipo.nome}({parti})"


def _leggi_campo(grezzo, nome, tipo, sottotipi):
    if nome in sottotipi:
        return sottotipi[nome].da_c(getattr(grezzo, nome))
    bruto = getattr(grezzo, nome)
    if tipo == "testo":
        return "" if bruto is None else bruto.decode("utf-8", errors="replace")
    if tipo == "logico":
        return bool(bruto)
    return bruto


def _scrivi_campo(grezzo, nome, tipo, valore, sottotipi):
    if nome in sottotipi:
        if not isinstance(valore, ValoreStruttura):
            raise ErroreTipo(f"Il campo `{nome}` vuole una struttura `{sottotipi[nome].nome}`.")
        setattr(grezzo, nome, valore.grezzo)
        return
    if tipo == "testo":
        if not isinstance(valore, str):
            raise ErroreTipo(f"Il campo `{nome}` è un testo.")
        setattr(grezzo, nome, valore.encode("utf-8"))
        return
    try:
        setattr(grezzo, nome, valore)
    except (TypeError, ctypes.ArgumentError) as e:
        raise ErroreTipo(f"Valore non adatto per il campo `{nome}`: {e}.") from None


# ----------------------------------------------------------------- callback
class TipoCallback(Richiamabile):
    NOME_TIPO_DANTE = "tipo callback C"

    def __init__(self, ritorno, parametri):
        self.nome = "callback"
        self._ritorno = ritorno
        self._parametri = list(parametri)
        self.cfunctype = ctypes.CFUNCTYPE(_tipo_c(ritorno, "callback"),
                                          *[_tipo_c(p, "callback") for p in self._parametri])

    def chiama(self, interprete, argomenti, argomenti_nome):
        if len(argomenti) != 1 or not isinstance(argomenti[0], Richiamabile):
            raise ErroreTipo("Una `callback` si crea con una funzione Leo, per esempio `confronto(mia_funzione)`.")
        return ValoreCallback(self, argomenti[0], interprete)

    def testo_dante(self):
        return f"<tipo callback C ({', '.join(map(str, self._parametri))}) -> {self._ritorno}>"


class ValoreCallback:
    NOME_TIPO_DANTE = "callback C"

    def __init__(self, tipo, funzione, interprete):
        self._tipo = tipo
        self._funzione = funzione
        self._interprete = interprete
        rit = tipo._ritorno
        par = tipo._parametri

        def ponte(*args):
            interp = self._interprete or (_INTERPRETE[-1] if _INTERPRETE else None)
            if interp is None:
                return _zero(rit)
            try:
                leo_args = [_da_c(a, t) for a, t in zip(args, par)]
                risultato = interp.chiama(funzione, leo_args, {})
                return _ritorno_callback(risultato, rit)
            except ErroreDante:
                return _zero(rit)

        self._puntatore = tipo.cfunctype(ponte)
        _CALLBACK_VIVE.append(self)

    def valore_python(self):
        return self._puntatore

    def testo_dante(self):
        return f"<callback C su {getattr(self._funzione, 'nome', '?')}>"


def _zero(tipo):
    if tipo in (None, "nulla"):
        return None
    if tipo == "testo":
        return b""
    if tipo == "logico":
        return False
    if tipo in ("decimale", "decimale32"):
        return 0.0
    return 0


def _ritorno_callback(valore, tipo):
    if tipo in (None, "nulla"):
        return None
    if tipo == "testo":
        return valore.encode("utf-8") if isinstance(valore, str) else (valore or b"")
    if tipo == "logico":
        return bool(valore)
    if tipo in ("decimale", "decimale32"):
        return float(valore)
    if tipo in ("intero", "intero32", "byte"):
        return int(valore)
    return valore


# ----------------------------------------------------------------- conversioni
def _verso_c(valore, tipo, dove, interprete=None):
    if isinstance(tipo, TipoStruttura):
        if isinstance(valore, ValoreStruttura) and valore._tipo is tipo:
            return valore.grezzo
        raise ErroreTipo(f"`{dove}`: qui serve una struttura `{tipo.nome}`.")
    if isinstance(tipo, TipoCallback):
        if isinstance(valore, ValoreCallback):
            return valore._puntatore
        if isinstance(valore, Richiamabile):
            return ValoreCallback(tipo, valore, interprete)._puntatore
        raise ErroreTipo(f"`{dove}`: qui serve una funzione Leo (callback).")
    if tipo == "testo":
        if isinstance(valore, str):
            return valore.encode("utf-8")
        raise ErroreTipo(f"`{dove}`: qui serve un testo.")
    if tipo == "logico":
        return bool(valore)
    if tipo in ("intero", "intero32", "byte"):
        if isinstance(valore, bool) or not isinstance(valore, int):
            raise ErroreTipo(f"`{dove}`: qui serve un numero intero.")
        return valore
    if tipo in ("decimale", "decimale32"):
        if isinstance(valore, bool) or not isinstance(valore, (int, float)):
            raise ErroreTipo(f"`{dove}`: qui serve un numero.")
        return float(valore)
    if tipo == "puntatore":
        if isinstance(valore, ByteC):
            return valore.valore_python()
        if isinstance(valore, ValoreStruttura):
            return ctypes.byref(valore.grezzo)
        return valore
    return valore


def _da_c(valore, tipo):
    if isinstance(tipo, TipoStruttura):
        return tipo.da_c(valore)
    if tipo == "testo":
        if valore is None:
            return None
        try:
            return valore.decode("utf-8")
        except (UnicodeDecodeError, AttributeError):
            return valore
    if tipo == "logico":
        return bool(valore)
    if tipo in (None, "nulla"):
        return None
    return valore
