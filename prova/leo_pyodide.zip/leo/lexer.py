"""Lexer di Leo: sorgente -> ``list[Token]`` (API in docs/CONTRATTI.md, sezione 3).

Uso tipico::

    from leo.lexer import Lexer, tokenizza
    token = Lexer(sorgente, "voti.leo", sinonimi=sinonimi, stile=stile).tokenizza()
    token = tokenizza("variabile x = 1")          # comodita', senza sinonimi

Riassunto delle regole (dettagli nel contratto):

* ``\\r\\n`` e ``\\r`` valgono come ``\\n``; ``FINE_RIGA`` a ogni a capo o ``;``
  fuori dalle parentesi, mai doppio ne' iniziale; la lista finisce con
  ``FINE_RIGA, FINE_FILE`` (solo ``FINE_FILE`` se il programma e' vuoto).
* Colonne in caratteri Unicode (una tabulazione = 1 colonna); ``lunghezza`` =
  caratteri coperti nel sorgente (dopo la normalizzazione degli a capo).
* Commenti ``#`` e ``#[ ... ]#`` (annidabili); con ``conserva_commenti`` escono
  token ``COMMENTO`` che non cambiano i ``FINE_RIGA``.
* Parole chiave, coppie di parole, sinonimi e forme di stile: si cerca la
  sequenza di parole piu' lunga; poi si applicano le ``FUSIONI_DI_TOKEN``.
* Stile ``con`` (parentesi sintetiche) e stile ``al`` (``al clic di P fai``).
* Numeri, testi con escape, interpolazione ``{espressione}`` con token reali.
* Operatori (il piu' lungo), pila delle parentesi, errori in italiano.
* Modalita' ``tollerante`` (editor): nessuna eccezione, token ``ERRORE``.
* ``inizio`` da solo sulla sua riga diventa ``INIZIO`` (apre il blocco del
  programma principale, ``inizio ... fine``); altrove resta un ``NOME``.
* Frasi di zucchero (``aumenta x di 1``, ``anima P.alto a 10 in 1 secondi``):
  all'inizio di un'istruzione le loro parole diventano ``AUMENTA``/
  ``DIMINUISCI``/``ANIMA`` e ``PAROLA_DI_FRASE`` (vedi ``tokens.segna_frase``);
  dopo ``in`` di ``anima`` si accetta anche ``2s``/``300ms`` (numero e unita').

* Comandi senza parentesi ("le parentesi vogliono dire calcola", GUIDA §2 bis):
  ``stampa Ciao (nome)``, ``avanti 100 passi``, ``saluta Giulia``,
  ``Palla.rimbalza 3``, ``Etichetta1.testo = Ciao (nome)`` diventano i token
  della forma classica (parentesi sintetiche; il testo libero e' ``TESTO`` o
  ``TESTO_INTERPOLATO`` con origine ``"comando"``). Tabelle e analisi dei nomi
  in :mod:`leo.comandi`; ``Lexer(..., nomi_noti=, comandi_noti=)`` aggiunge i
  nomi definiti altrove, ``comandi=False`` spegne la regola; dopo
  ``tokenizza()`` l'elenco ``Lexer.comandi_letti`` dice che cosa e' stato
  capito (lo usa :mod:`leo.lettura`). Anche: maiuscola iniziale sulla prima
  parola della riga (``Se``, ``Stampa``), ``scrivi`` = ``stampa``, simboli
  ``≥ ≤ ≠ × ÷``.

Attributo in piu' (non nel contratto, utile alla colorazione riga per riga):
``Lexer.profondita_commento`` = quanti ``#[`` restano aperti a fine sorgente
(sempre 0 se non si e' in modalita' tollerante, perche' altrimenti e' errore).
"""

from __future__ import annotations

import bisect
import os
import re
import unicodedata
from typing import TYPE_CHECKING, Any, Iterable

from .comandi import (
    COMANDI_DOPO_UGUALE,
    PROPRIETA_DI_TESTO,
    SINONIMI_COMANDI,
    UNITA,
    ComandoLetto,
    Definizioni,
    Pezzo,
    definizioni_progetto,
    funzioni_libreria,
    genere_comando,
    genere_unita,
    nome_unita,
    nomi_predefiniti,
    parole_da_tabella,
    trova_definizioni,
)
from .errori import Correzione, ErroreSintassi
from .stile import Stile
from .tokens import (
    COPPIE_DI_PAROLE,
    FRASI_DI_ZUCCHERO,
    FUSIONI_DI_TOKEN,
    OPERATORI,
    PAROLE_CHIAVE,
    PAROLE_DI_CONTESTO,
    UNITA_DI_TEMPO,
    ParteInterpolata,
    TipoToken,
    Token,
    e_inizio_da_solo,
    segna_frase,
)

if TYPE_CHECKING:  # pragma: no cover - solo per le annotazioni
    from .sinonimi import Sinonimi

__all__ = ["Lexer", "tokenizza"]

T = TipoToken

#: Caratteri trattati come spazio (oltre all'a capo, che e' speciale).
_SPAZI = " \t\f\v ﻿"
#: Caratteri che possono separare le parole di una sequenza (``per ogni``).
_SEPARATORI_PAROLE = " \t "
#: Escape ammessi nei testi.
_ESCAPE = {"n": "\n", "t": "\t", '"': '"', "\\": "\\", "{": "{", "}": "}"}
#: Parentesi aperte -> chiusura corrispondente.
_APERTE = {"(": ")", "[": "]", "{": "}"}
_CHIUSE = {")": "(", "]": "[", "}": "{"}
#: Parole chiave che, attaccate a un numero (``ripeti 3volte``), si staccano con uno spazio.
_PAROLE_DA_STACCARE = frozenset({TipoToken.VOLTE, TipoToken.ALLORA, TipoToken.FAI})
#: Righe il cui ``allora``/``fai`` finale resta fuori da un testo non chiuso.
_INTESTAZIONI = frozenset({TipoToken.SE, TipoToken.ALTRIMENTI_SE, TipoToken.MENTRE,
                           TipoToken.PER_OGNI, TipoToken.QUANDO})
# --- comandi senza parentesi ("le parentesi vogliono dire calcola") -----------------
#: Dopo queste parole, sulla stessa riga, comincia un'istruzione (blocchi su una riga).
_APRONO_SU_UNA_RIGA = frozenset({T.ALLORA, T.FAI, T.ALTRIMENTI, T.VOLTE})
#: Parole chiave che possono cominciare un'istruzione (per la maiuscola iniziale: ``Se``, ``Fine``).
_TIPI_INIZIO_ISTRUZIONE = frozenset({
    T.VARIABILE, T.COSTANTE, T.SE, T.ALTRIMENTI_SE, T.ALTRIMENTI, T.FINE, T.MENTRE, T.PER_OGNI,
    T.RIPETI, T.INTERROMPI, T.CONTINUA, T.FUNZIONE, T.RESTITUISCI, T.PROVA, T.CATTURA, T.INFINE,
    T.LANCIA, T.QUANDO,
})
#: Parole che a inizio istruzione hanno gia' un significato (frasi di zucchero, parole di
#: contesto, costrutti di potenza): non diventano mai comandi senza parentesi.
_MAI_COMANDI = frozenset(FRASI_DI_ZUCCHERO) | PAROLE_DI_CONTESTO | frozenset({
    "inizio", "ogni", "dopo", "aspettati", "parallelo", "caso"})
#: Faccine prima di ``(``: ``:(`` ``:-(`` ``;(`` restano testo.
_FACCINE = (":", ";", "=", ":-", ";-", "=-", "8-")
#: Numero con unita' facoltativa (``2 secondi``, ``90°``, ``500ms``).
_RE_NUMERO_UNITA = re.compile(r"(-?\d+(?:\.\d+)?)(?:[ \t]*(°|[^\W\d]\w*))?")
_RE_IDENTIFICATORE = re.compile(r"[^\W\d]\w*")
#: Unita' in fondo a un calcolo (``attendi pausa secondi``).
_RE_UNITA_FINALE = re.compile(r"[ \t]+([^\W\d]\w*)$")
#: Simboli matematici accettati: ``≥`` vale ``>=``, ``×`` vale ``*``...
_OPERATORI_UNICODE = {"≥": ">=", "≤": "<=", "≠": "!=", "×": "*", "÷": "/", "−": "-"}
_TIPO_OPERATORE = dict((testo, tipo) for testo, tipo in OPERATORI)


def _non_e_argomento(resto: str) -> bool:
    """Vero se dopo il nome c'e' qualcosa che non puo' cominciare gli argomenti di un
    comando (``stampa = 3``, ``colore += 1``, ``x.y``, ``casa[0]``, ``f, g = ...``)."""
    if resto[0] in ",)]}" or resto.startswith(("+=", "-=", "*=", "/=", "|>")):
        return True
    return resto[0] == "=" and not resto.startswith("==")


_TONDE = str.maketrans("[]{}", "()()")


def _e_espressione(testo: str) -> bool:
    """Vero se ``testo`` e' un'espressione valida di Leo (senza errori del lexer)."""
    try:
        from .parser import Parser
        token = Lexer(testo, tollerante=True, comandi=False).tokenizza()
        if any(t.tipo is T.ERRORE for t in token):
            return False
        Parser([t for t in token if t.tipo is not T.FINE_RIGA], rigoroso=False).espressione_isolata()
        return True
    except Exception:
        return False


def _nomi_liberi(nodo: Any) -> set[str]:
    """Nomi usati da un'espressione (``Nome``), senza i membri dopo il punto e senza la
    base maiuscola di un attributo (``CasellaNome.testo``: un controllo)."""
    nomi: set[str] = set()

    def visita(x: Any) -> None:
        if isinstance(x, list):
            for v in x:
                visita(v)
            return
        if not hasattr(x, "__dataclass_fields__"):
            return
        tipo = type(x).__name__
        if tipo == "Nome":
            nomi.add(x.nome)
            return
        if tipo == "FunzioneAnonima":
            return
        if tipo == "Attributo" and type(x.oggetto).__name__ == "Nome" and x.oggetto.nome[:1].isupper():
            return
        for campo in x.__dataclass_fields__:
            if campo not in ("riga", "colonna"):
                visita(getattr(x, campo))

    visita(nodo)
    return nomi


#: Massimo annidamento di testi interpolati uno dentro l'altro.
_MAX_ANNIDAMENTO = 20

#: Simboli di altri linguaggi con il suggerimento corrispondente.
_SIMBOLI_NOTI: tuple[tuple[str, str], ...] = (
    ("&&", "Per il «e» logico in Leo si scrive `e`: `se a e b allora`."),
    ("||", "Per il «o» logico in Leo si scrive `o`: `se a o b allora`."),
    ("&", "Per il «e» logico in Leo si scrive `e`: `se a e b allora`."),
    ("|", "Per il «o» logico in Leo si scrive `o`: `se a o b allora`."),
    ("!", "Per negare in Leo si scrive `non`: `se non trovato allora`; per «diverso» usa `!=`."),
    ("'", "I testi si scrivono tra virgolette doppie: `\"ciao\"`."),
    ("“", "Per i testi usa le virgolette dritte `\"`, non quelle tipografiche."),
    ("”", "Per i testi usa le virgolette dritte `\"`, non quelle tipografiche."),
    ("«", "Per i testi usa le virgolette dritte `\"`."),
    ("»", "Per i testi usa le virgolette dritte `\"`."),
    ("\\", "La barra rovesciata `\\` si usa solo dentro i testi (per esempio `\"a\\nb\"`)."),
    ("?", "In Leo non c'è l'operatore `?`: usa `se ... allora ... altrimenti ... fine`."),
)

_SUGG_ESCAPE = ("Dentro un testo puoi usare `\\n` (a capo), `\\t` (tabulazione), `\\\"`, "
                "`\\\\`, `\\{` e `\\}`; per una barra rovesciata vera scrivi `\\\\`.")


#: Parole chiave che chiudono l'elenco dei parametri nello stile ``con`` anche
#: sulla stessa riga: ``funzione con x restituisci x * 2 fine``.
_CHIUDONO_CON = frozenset({
    T.RESTITUISCI, T.FINE, T.SE, T.MENTRE, T.PER_OGNI, T.RIPETI, T.VARIABILE, T.COSTANTE,
    T.PROVA, T.LANCIA, T.INTERROMPI, T.CONTINUA, T.FAI, T.ALLORA,
})


def _inizio_nome(c: str) -> bool:
    """Primo carattere di un identificatore: lettera Unicode o ``_``."""
    return c == "_" or c.isalpha()


def _parte_nome(c: str) -> bool:
    """Carattere successivo di un identificatore: lettere, cifre, ``_`` e
    segni diacritici combinanti (accenti scritti come carattere separato)."""
    if c == "_" or c.isalpha() or c.isdigit():
        return True
    return ord(c) > 127 and unicodedata.category(c).startswith("M")


def _cifra(c: str) -> bool:
    return "0" <= c <= "9"


def _mostra_carattere(c: str) -> str:
    """Rappresentazione leggibile di un carattere per i messaggi."""
    if c.isprintable() and not c.isspace():
        return c
    return f"U+{ord(c):04X}"


def _normalizza_parola(parola: str) -> str:
    return "è" if parola == "e'" else parola


# ---------------------------------------------------------------------------
# Lexer
# ---------------------------------------------------------------------------

class Lexer:
    """Divide un sorgente Leo in token (vedi il docstring del modulo)."""

    def __init__(
        self,
        sorgente: str,
        nome_file: str = "<sorgente>",
        *,
        sinonimi: "Sinonimi | None" = None,
        stile: Stile | None = None,
        conserva_commenti: bool = False,
        tollerante: bool = False,
        nomi_noti: Iterable[str] = (),
        comandi_noti: Iterable[str] = (),
        comandi: bool = True,
    ) -> None:
        if sorgente is None:
            sorgente = ""
        self.sorgente_originale = sorgente
        #: Sorgente con gli a capo normalizzati: le posizioni si riferiscono a questo.
        self.sorgente = sorgente.replace("\r\n", "\n").replace("\r", "\n")
        self.nome_file = nome_file
        self.sinonimi = sinonimi
        self.stile = stile if stile is not None else Stile()
        self.conserva_commenti = conserva_commenti
        self.tollerante = tollerante
        self.profondita_commento = 0
        #: Vero se il sorgente finisce dentro un testo su piu' righe (``\"\"\"``) mai
        #: chiuso (solo in modalita' tollerante: serve alla colorazione riga per riga).
        self.testo_lungo_aperto = False

        self._inizi_riga = [0]
        for indice, carattere in enumerate(self.sorgente):
            if carattere == "\n":
                self._inizi_riga.append(indice + 1)

        # Tabella unica: sequenza di parole -> (tipo canonico, origine).
        # Ordine di inserimento = priorita' crescente (le canoniche vincono).
        parole: dict[tuple[str, ...], tuple[TipoToken, str]] = {}
        if sinonimi is not None:
            for chiave, tipo in sinonimi.mappa.items():
                parole[tuple(_normalizza_parola(p) for p in chiave)] = (tipo, "sinonimo")
        for chiave, tipo in self.stile.forme_lessicali().items():
            parole[tuple(_normalizza_parola(p) for p in chiave)] = (tipo, "stile")
        for parola, tipo in PAROLE_CHIAVE.items():
            parole[(parola,)] = (tipo, "canonica")
        for chiave, tipo in COPPIE_DI_PAROLE.items():
            parole[chiave] = (tipo, "canonica")
        parole.pop((), None)
        self._parole = parole
        self._max_parole = max(len(k) for k in parole)
        #: Comandi senza parentesi: ``comandi=False`` li spegne (forma classica soltanto).
        self.comandi = comandi
        #: Nomi definiti altrove (altri file, righe precedenti nel REPL, resto del documento
        #: nell'editor) e funzioni senza ``restituisci`` definite altrove (comandi dell'utente).
        self.nomi_noti = frozenset(nomi_noti or ())
        self.comandi_noti = frozenset(comandi_noti or ())
        #: Comandi senza parentesi letti (per :mod:`leo.lettura`), in ordine.
        self.comandi_letti: list[ComandoLetto] = []
        self._definizioni: Definizioni | None = None
        self._cache_alberi: dict[str, Any] = {}
        self._prime_parole: frozenset[str] | None = None
        self._chiusure: frozenset[str] | None = None

    # --- API pubblica ---------------------------------------------------------
    def definizioni(self) -> Definizioni:
        """Nomi del programma (e degli altri file del progetto): servono ai comandi senza
        parentesi per sapere quali nomi sono dell'utente (vedi :mod:`leo.comandi`)."""
        if self._definizioni is None:
            d = trova_definizioni(self.sorgente, parole_da_tabella(self._parole), self.nome_file)
            d = d.unisci(definizioni_progetto(self.nome_file))
            for nome in self.nomi_noti | self.comandi_noti:
                d.nomi.setdefault(nome, (0, ""))
            d.comandi |= {n for n in self.comandi_noti if n not in d.funzioni_valore}
            self._definizioni = d
        return self._definizioni

    def prime_parole_istruzione(self) -> frozenset[str]:
        """Prime parole delle parole chiave che cominciano un'istruzione (``se``, ``per``...)."""
        if self._prime_parole is None:
            self._prime_parole = frozenset(k[0] for k, (tipo, _o) in self._parole.items()
                                           if tipo in _TIPI_INIZIO_ISTRUZIONE)
        return self._prime_parole

    def parole_che_chiudono(self) -> frozenset[str]:
        """Parole che chiudono il testo di un comando in un blocco su una riga."""
        if self._chiusure is None:
            self._chiusure = frozenset(k[0] for k, (tipo, _o) in self._parole.items()
                                       if len(k) == 1 and tipo in (T.FINE, T.ALTRIMENTI, T.ALTRIMENTI_SE))
        return self._chiusure

    def tokenizza(self) -> list[Token]:
        """Restituisce la lista dei token (sempre terminata da ``FINE_FILE``)."""
        if not self.tollerante:
            return self._tokenizza()
        try:
            return self._tokenizza()
        except Exception as e:  # rete di sicurezza: in modalita' editor mai eccezioni
            fine = self._posizione(len(self.sorgente))
            return [
                Token(T.ERRORE, f"Errore interno del lexer: {e}", 1, 1, None, 0, "sintetico"),
                Token(T.FINE_FILE, None, fine[0], fine[1], None, 0, "sintetico"),
            ]

    # --- interni ----------------------------------------------------------------
    def _tokenizza(self) -> list[Token]:
        self.profondita_commento = 0
        self.testo_lungo_aperto = False
        self.comandi_letti = []
        scansione = _Scansione(self, 0, len(self.sorgente), parte=False, profondita=0)
        token = scansione.esegui()
        self.profondita_commento = scansione.profondita_commento
        if self.stile.eventi_al:
            token = self._applica_stile_al(token)
        if self.stile.parametri_con:
            token = self._applica_stile_con(token)
        return self._segna_frasi(token)

    # --- frasi di zucchero: aumenta / diminuisci / anima -----------------------
    @staticmethod
    def _segna_frasi(token: list[Token]) -> list[Token]:
        """Ritipizza le frasi di zucchero che cominciano un'istruzione (a inizio
        riga, dopo ``;`` o dopo ``allora``/``fai``/``altrimenti`` sulla stessa riga)."""
        inizio = True
        for i, t in enumerate(token):
            if t.tipo is T.COMMENTO:
                continue
            if inizio and t.tipo is T.NOME:
                if t.valore == "inizio" and e_inizio_da_solo(token, i):
                    # `inizio` da solo sulla riga: apre il programma principale
                    token[i] = Token(T.INIZIO, "inizio", t.riga, t.colonna, t.testo_originale,
                                     t.lunghezza, t.origine)
                else:
                    segna_frase(token, i)
            inizio = t.tipo in (T.FINE_RIGA, T.ALLORA, T.FAI, T.ALTRIMENTI)
        return token

    def _posizione(self, offset: int) -> tuple[int, int]:
        """Da posizione assoluta nel sorgente normalizzato a (riga, colonna), 1-based."""
        riga = bisect.bisect_right(self._inizi_riga, offset)
        return riga, offset - self._inizi_riga[riga - 1] + 1

    # --- stile "al": al EVENTO di CONTROLLO fai -> quando CONTROLLO . EVENTO fai ----
    @staticmethod
    def _e_forma_al(token: list[Token], i: int) -> bool:
        if i + 4 >= len(token):
            return False
        al, evento, di, controllo, fai = token[i:i + 5]
        if not (al.tipo is T.NOME and al.valore == "al" and di.tipo is T.NOME and di.valore == "di"):
            return False
        if evento.tipo is not T.NOME or controllo.tipo is not T.NOME or fai.tipo is not T.FAI:
            return False
        return len({t.riga for t in (al, evento, di, controllo, fai)}) == 1

    def _applica_stile_al(self, token: list[Token]) -> list[Token]:
        risultato: list[Token] = []
        inizio_istruzione = True
        i = 0
        while i < len(token):
            t = token[i]
            if t.tipo is T.COMMENTO:
                risultato.append(t)
                i += 1
                continue
            if inizio_istruzione and self._e_forma_al(token, i):
                al, evento, di, controllo, fai = token[i:i + 5]
                risultato.append(Token(T.QUANDO, T.QUANDO.value, al.riga, al.colonna,
                                       al.testo_originale, al.lunghezza, "stile"))
                risultato.append(controllo)
                risultato.append(Token(T.PUNTO, ".", di.riga, di.colonna, di.testo_originale, 0, "sintetico"))
                risultato.append(evento)
                risultato.append(fai)
                i += 5
                inizio_istruzione = False
                continue
            risultato.append(t)
            inizio_istruzione = t.tipo is T.FINE_RIGA
            i += 1
        return risultato

    # --- stile "con": funzione somma con a, b -> funzione somma ( a, b ) ----------
    def _applica_stile_con(self, token: list[Token]) -> list[Token]:
        risultato: list[Token] = []
        chiusura_in_attesa = False
        n = len(token)
        i = 0
        while i < n:
            t = token[i]
            if chiusura_in_attesa and (t.tipo in (T.FINE_RIGA, T.FINE_FILE) or t.tipo in _CHIUDONO_CON):
                k = len(risultato)
                while k > 0 and risultato[k - 1].tipo is T.COMMENTO:
                    k -= 1
                ultimo = risultato[k - 1]
                estensione = ultimo.lunghezza
                if ultimo.origine == "sintetico" and ultimo.testo_originale:
                    estensione = len(ultimo.testo_originale)
                risultato.insert(k, Token(T.PARENTESI_CHIUSA, ")", ultimo.riga,
                                          ultimo.colonna + estensione, None, 0, "sintetico"))
                chiusura_in_attesa = False
            if t.tipo is T.FUNZIONE and not chiusura_in_attesa:
                indice_con = self._indice_con(token, i)
                if indice_con is not None:
                    risultato.extend(token[i:indice_con])
                    con = token[indice_con]
                    risultato.append(Token(T.PARENTESI_APERTA, "(", con.riga, con.colonna,
                                           con.testo_originale, 0, "sintetico"))
                    chiusura_in_attesa = True
                    i = indice_con + 1
                    continue
            risultato.append(t)
            i += 1
        return risultato

    @staticmethod
    def _indice_con(token: list[Token], i: int) -> int | None:
        """Indice della parola ``con`` dopo ``funzione NOME`` o ``funzione`` (anonima)."""
        funzione = token[i]

        def e_con(j: int) -> bool:
            return (j < len(token) and token[j].tipo is T.NOME and token[j].valore == "con"
                    and token[j].riga == funzione.riga)

        j = i + 1
        if j < len(token) and token[j].tipo is T.NOME and token[j].riga == funzione.riga and e_con(j + 1):
            return j + 1
        if e_con(j) and not (j + 1 < len(token) and token[j + 1].tipo is T.PARENTESI_APERTA):
            return j
        return None


def tokenizza(sorgente: str, nome_file: str = "<sorgente>", **opzioni: Any) -> list[Token]:
    """Comodita': ``Lexer(sorgente, nome_file, **opzioni).tokenizza()``."""
    return Lexer(sorgente, nome_file, **opzioni).tokenizza()


# ---------------------------------------------------------------------------
# Scansione di un tratto di sorgente (tutto il file, o una parte interpolata)
# ---------------------------------------------------------------------------

class _Scansione:
    """Stato della scansione di ``sorgente[inizio:fine]``.

    Con ``parte=True`` il tratto e' il contenuto di ``{...}`` in un testo: niente
    ``FINE_RIGA`` e la lista finisce con il solo ``FINE_FILE``.
    """

    def __init__(self, lexer: Lexer, inizio: int, fine: int, *, parte: bool, profondita: int) -> None:
        self.lx = lexer
        self.src = lexer.sorgente
        self.i = inizio
        self.fine = fine
        self.parte = parte
        self.profondita = profondita
        self.token: list[Token] = []
        self.span: list[tuple[int, int]] = []          # (inizio, fine) assoluti di ogni token
        self.pila: list[tuple[str, int]] = []           # parentesi aperte: (carattere, offset)
        self.ultimo_significativo: TipoToken | None = None
        self.fine_codice: dict[int, int] = {}           # riga -> colonna dopo l'ultimo token di codice
        self.profondita_commento = 0

    # --- ciclo principale ---------------------------------------------------------
    def esegui(self) -> list[Token]:
        src, fine = self.src, self.fine
        while self.i < fine:
            c = src[self.i]
            if c == "\n":
                if not self.pila:
                    self._fine_riga(self.i, "\n")
                self.i += 1
            elif c in _SPAZI:
                self.i += 1
            elif c == "#":
                self._commento()
            elif c == ";":
                self._punto_e_virgola()
            elif c == '"':
                self._testo()
            elif _cifra(c):
                self._numero()
            elif _inizio_nome(c):
                self._parola()
            else:
                self._operatore()
        self._chiudi()
        return self.token

    # --- emissione -------------------------------------------------------------------
    def _emetti(self, tipo: TipoToken, valore: Any, inizio: int, fine: int, *,
                origine: str = "canonica", testo: str | None = None) -> Token:
        riga, colonna = self.lx._posizione(inizio)
        if testo is None:
            testo = self.src[inizio:fine]
        tok = Token(tipo, valore, riga, colonna, testo, fine - inizio, origine)
        if self.token and tipo is not T.COMMENTO:
            prec = self.token[-1]
            fusione = FUSIONI_DI_TOKEN.get((prec.tipo, tipo))
            if fusione is not None and prec.riga == riga:
                p_inizio, p_fine = self.span[-1]
                if all(ch in _SEPARATORI_PAROLE for ch in self.src[p_fine:inizio]):
                    origini = {prec.origine, origine}
                    if "sinonimo" in origini:
                        nuova = "sinonimo"
                    elif "stile" in origini:
                        nuova = "stile"
                    else:
                        nuova = "canonica"
                    tok = Token(fusione, fusione.value, prec.riga, prec.colonna,
                                self.src[p_inizio:fine], fine - p_inizio, nuova)
                    self.token.pop()
                    self.span.pop()
                    inizio = p_inizio
        self._aggiungi(tok, inizio, fine)
        return tok

    def _aggiungi(self, tok: Token, inizio: int, fine: int) -> None:
        self.token.append(tok)
        self.span.append((inizio, fine))
        if tok.tipo is not T.COMMENTO:
            self.ultimo_significativo = tok.tipo
            if tok.tipo is not T.FINE_RIGA:
                self.fine_codice[tok.riga] = tok.colonna + tok.lunghezza

    def _errore(self, messaggio: str, inizio: int, lunghezza: int, *,
                suggerimento: str | None = None, correzioni: list[Correzione] | None = None) -> None:
        """In modalita' normale solleva ``ErroreSintassi``; in quella tollerante
        aggiunge un token ``ERRORE`` e ritorna."""
        riga, colonna = self.lx._posizione(inizio)
        if self.lx.tollerante:
            tok = Token(T.ERRORE, messaggio, riga, colonna,
                        self.src[inizio:inizio + lunghezza], lunghezza, "canonica")
            self._aggiungi(tok, inizio, inizio + lunghezza)
            return
        raise ErroreSintassi(messaggio, riga, colonna, suggerimento, correzioni=correzioni,
                             nome_file=self.lx.nome_file, lunghezza=max(1, lunghezza))

    # --- fine riga -----------------------------------------------------------------------
    def _fine_riga(self, offset: int, valore: str) -> None:
        if self.ultimo_significativo is None or self.ultimo_significativo is T.FINE_RIGA:
            return
        self._emetti(T.FINE_RIGA, valore, offset, offset + 1)

    def _punto_e_virgola(self) -> None:
        i = self.i
        self.i += 1
        if self.parte:
            self._errore("Dentro le graffe di un testo va una sola espressione: il `;` non è ammesso.",
                         i, 1, suggerimento="Togli il `;` oppure scrivi l'istruzione fuori dal testo.")
        elif self.pila:
            aperta, _ = self.pila[-1]
            self._errore(f"Il `;` separa le istruzioni: non può stare dentro `{aperta}{_APERTE[aperta]}`.",
                         i, 1, suggerimento="Per separare gli elementi usa la virgola `,`.")
        else:
            self._fine_riga(i, ";")

    # --- commenti -----------------------------------------------------------------------
    def _commento(self) -> None:
        src, fine, i = self.src, self.fine, self.i
        if src.startswith("#[", i, fine):
            profondita = 0
            j = i
            while j < fine:
                if src.startswith("#[", j, fine):
                    profondita += 1
                    j += 2
                elif src.startswith("]#", j, fine):
                    profondita -= 1
                    j += 2
                    if profondita == 0:
                        break
                else:
                    j += 1
            if profondita > 0:
                self.profondita_commento = profondita
                if self.lx.conserva_commenti:
                    self._emetti(T.COMMENTO, src[i:fine], i, fine)
                self.i = fine
                self._errore("Il commento `#[` aperto qui non è mai chiuso: manca `]#`.", i, 2,
                             suggerimento="Chiudi il commento su più righe con `]#`.")
                return
        else:
            j = src.find("\n", i, fine)
            if j == -1:
                j = fine
        if self.lx.conserva_commenti:
            self._emetti(T.COMMENTO, src[i:j], i, j)
        self.i = j

    # --- parole -----------------------------------------------------------------------
    def _leggi_parola(self, i: int) -> tuple[str, int]:
        src, fine = self.src, self.fine
        j = i + 1
        while j < fine and _parte_nome(src[j]):
            j += 1
        parola = src[i:j]
        if parola == "e" and j < fine and src[j] == "'":
            return "è", j + 1
        return parola, j

    def _parola(self) -> None:
        src, fine, i = self.src, self.fine, self.i
        prima, j = self._leggi_parola(i)
        if prima == "permessi" and self._intestazione_permessi(j):
            return
        scritta = prima
        valore_nome = prima
        if self.lx.comandi and not self.parte and not self.pila:
            inizio, in_blocco = self._contesto_istruzione()
            if (inizio or self.ultimo_significativo is T.ASSEGNA) and \
                    self._parola_in_testa(prima, i, j, inizio, in_blocco):
                return
            if inizio:
                minuscola = self._maiuscola_iniziale(prima, j)
                if minuscola is not None:
                    prima = valore_nome = minuscola
            if valore_nome in SINONIMI_COMANDI and self.ultimo_significativo is not T.PUNTO \
                    and valore_nome not in self._definizioni().nomi:
                valore_nome = SINONIMI_COMANDI[valore_nome]          # `scrivi("ciao")`
        parole = [(prima, i, j)]
        k = j
        while len(parole) < self.lx._max_parole:
            m = k
            while m < fine and src[m] in _SEPARATORI_PAROLE:
                m += 1
            if m == k or m >= fine or not _inizio_nome(src[m]):
                break
            parola, e = self._leggi_parola(m)
            parole.append((parola, m, e))
            k = e
        for n in range(len(parole), 0, -1):
            trovato = self.lx._parole.get(tuple(p for p, _, _ in parole[:n]))
            if trovato is not None:
                tipo, origine = trovato
                fine_token = parole[n - 1][2]
                self._emetti(tipo, tipo.value, i, fine_token, origine=origine)
                self.i = fine_token
                return
        self._emetti(T.NOME, valore_nome, i, j, testo=scritta)
        self.i = j

    def _intestazione_permessi(self, j: int) -> bool:
        """``permessi: rete "sito.it", ...`` in cima al programma (prima del codice) è
        un'intestazione come ``#stile:``: la legge :mod:`leo.permessi`, qui vale come commento."""
        src, fine = self.src, self.fine
        k = j
        while k < fine and src[k] in " \t":
            k += 1
        if self.parte or k >= fine or src[k] != ":":
            return False
        if any(t.tipo is not T.COMMENTO and t.tipo is not T.FINE_RIGA for t in self.token):
            return False
        fine_riga = src.find("\n", k, fine)
        if fine_riga == -1:
            fine_riga = fine
        if self.lx.conserva_commenti:
            self._emetti(T.COMMENTO, src[self.i:fine_riga], self.i, fine_riga)
        self.i = fine_riga
        return True

    # --- comandi senza parentesi ("le parentesi vogliono dire calcola") -------------------
    # Regole in leo/comandi.py e in docs/GUIDA.md ("Comandi senza parentesi"). Il comando
    # diventa i token della forma classica: NOME ( argomenti ) con parentesi sintetiche;
    # il testo libero diventa TESTO / TESTO_INTERPOLATO con origine "comando".

    def _fine_riga_da(self, j: int) -> int:
        f = self.src.find("\n", j, self.fine)
        return self.fine if f == -1 else f

    def _contesto_istruzione(self) -> tuple[bool, bool]:
        """(``inizio``, ``in_blocco``): la parola corrente comincia un'istruzione? E' in un
        blocco su una riga (dopo ``allora``/``fai``/``altrimenti``/``volte`` o ``;``)?"""
        ult = self.ultimo_significativo
        if ult in _APRONO_SU_UNA_RIGA:
            return True, True
        if ult is None:
            return True, False
        if ult is T.FINE_RIGA:
            k = len(self.token) - 1
            while k >= 0 and self.token[k].tipo is T.COMMENTO:
                k -= 1
            ultimo = self.token[k] if k >= 0 else None
            stessa_riga = ultimo is not None and ultimo.valore == ";" and \
                "\n" not in self.src[self.span[k][1]:self.i]
            return True, stessa_riga
        return False, False

    def _definizioni(self) -> Definizioni:
        return self.lx.definizioni()

    def _funzione_nota(self, nome: str) -> bool:
        """Vero se ``nome(...)`` dentro un testo libero e' una chiamata da calcolare."""
        defs = self._definizioni()
        return nome in defs.nomi or nome in funzioni_libreria() or nome in nomi_predefiniti()

    def _maiuscola_iniziale(self, parola: str, fine_parola: int) -> str | None:
        """``Stampa`` -> ``stampa``, ``Se`` -> ``se``, ``Fine`` -> ``fine``: la prima parola
        della riga con la maiuscola vale come in minuscolo se in minuscolo e' una parola
        chiave d'inizio istruzione, un comando o una funzione (e non un nome dell'utente)."""
        if len(parola) < 2 or not parola[0].isupper() or parola[1:] != parola[1:].lower():
            return None
        src = self.src
        k = fine_parola
        while k < self.fine and src[k] in " \t":
            k += 1
        dopo = src[k:min(self.fine, k + 2)]
        if dopo and (dopo[0] in ".[" or _non_e_argomento(dopo)):
            return None                               # `Lanci.testo = ...`, `Contatore += 1`
        minuscola = parola[0].lower() + parola[1:]
        if not (minuscola in self.lx.prime_parole_istruzione() or minuscola in FRASI_DI_ZUCCHERO
                or minuscola == "inizio" or minuscola in SINONIMI_COMANDI
                or minuscola in self._definizioni().nomi or minuscola in funzioni_libreria()):
            return None
        defs = self._definizioni()
        if parola in defs.nomi or parola in defs.controlli:
            return None
        return minuscola

    def _sintetico(self, tipo: TipoToken, valore: Any, pos: int) -> None:
        riga, col = self.lx._posizione(pos)
        self._aggiungi(Token(tipo, valore, riga, col, None, 0, "sintetico"), pos, pos)

    def _chiusa_di(self, q: int, limite: int) -> int | None:
        """Indice della ``)`` che chiude la ``(`` in ``q`` (testi tra virgolette saltati)."""
        src = self.src
        livello = 0
        k = q
        while k < limite:
            c = src[k]
            if c == '"':
                k += 1
                while k < limite and src[k] != '"':
                    k += 2 if src[k] == "\\" else 1
            elif c == "(":
                livello += 1
            elif c == ")":
                livello -= 1
                if livello == 0:
                    return k
            k += 1
        return None

    def _classica(self, k: int, fine_arg: int) -> bool:
        """Vero se la ``(`` in ``k`` racchiude tutti gli argomenti (``stampa (x)``), anche
        quando si chiude su un'altra riga (``stampa (`` a capo ``"a", "b")``)."""
        chiusa = self._chiusa_di(k, fine_arg)
        if chiusa == fine_arg - 1:
            return True
        if chiusa is None:
            chiusa = self._chiusa_di(k, self.fine)
            return chiusa is not None and chiusa >= fine_arg
        return False

    def _faccina(self, q: int, inizio: int, limite: int) -> bool:
        """Vero se la ``(`` in ``q`` fa parte di una faccina (``:(``, ``:-(``, ``;(``)."""
        prima = self.src[max(inizio, q - 2):q]
        return prima.endswith(_FACCINE) and (q + 1 >= limite or self.src[q + 1] in " \t")

    def _fine_comando(self, k: int, fine_riga: int, in_blocco: bool, modo: str) -> int:
        """Fine del tratto del comando: prima di un commento `` # ``; nei blocchi su una riga
        prima di ``fine``/``altrimenti``; nei comandi di valore anche prima di ``;``."""
        src = self.src
        virgolette = modo != "testo" or src[k:k + 1] == '"'
        chiusure = self.lx.parole_che_chiudono() if in_blocco else ()
        q = k
        livello = 0
        while q < fine_riga:
            c = src[q]
            if c == '"' and virgolette:
                q += 1
                while q < fine_riga and src[q] != '"':
                    q += 2 if src[q] == "\\" else 1
            elif c == "(":
                if not (modo == "testo" and self._faccina(q, k, fine_riga)):
                    livello += 1
            elif c == ")":
                livello = max(0, livello - 1)
            elif livello == 0:
                staccato = q == k or src[q - 1] in " \t"
                if c == "#" and staccato and (q + 1 >= fine_riga or src[q + 1] in " \t#["):
                    break
                if c == ";" and modo != "testo":
                    break
                if chiusure and staccato and _inizio_nome(c):
                    parola, e = self._leggi_parola(q)
                    if parola in chiusure and (e >= fine_riga or not _parte_nome(src[e])):
                        break
            q += 1
        e = min(q, fine_riga)
        while e > k and src[e - 1] in " \t\r":
            e -= 1
        return e

    def _parola_in_testa(self, parola: str, i: int, j: int, inizio: bool, in_blocco: bool) -> bool:
        """Prova a leggere un comando senza parentesi che comincia con ``parola``."""
        if (parola,) in self.lx._parole or (parola.lower(),) in self.lx._parole:
            return False                              # parola chiave: mai un comando
        if parola in _MAI_COMANDI:
            return False                              # frasi (`anima P.alto a 10`) e parole di contesto
        src = self.src
        if src[j:j + 1] == "." and inizio:
            return self._comando_oggetto(parola, i, j, in_blocco)
        # controlli veloci prima di cercare i nomi del programma
        if j < self.fine and src[j] not in " \t\n#;":
            return False                              # attaccato: stampa( stampa" x=...
        k = j
        while k < self.fine and src[k] in " \t":
            k += 1
        if k < self.fine and src[k] not in "\n#;" and _non_e_argomento(src[k:k + 2]):
            return False                              # `x = 5`, `totale += 1`, `a, b = ...`
        nome = parola
        defs = self._definizioni()
        minuscola = self._maiuscola_iniziale(parola, j) if inizio else None
        if minuscola is not None:
            nome = minuscola
        if nome in defs.nomi:
            canonico = nome
            libreria = genere_comando(nome) if nome not in SINONIMI_COMANDI else None
            if libreria is not None:
                genere = "ridefinito"
            elif nome in defs.comandi:
                genere = "utente"
            elif nome in defs.funzioni_valore:
                genere = "funzione_valore"
            else:
                return False
        else:
            canonico = SINONIMI_COMANDI.get(nome, nome)
            genere = genere_comando(canonico)
            if genere is None:
                return False
        if not inizio:
            # `variabile nome = chiedi Come ti chiami?`
            if genere != "testo" or canonico not in COMANDI_DOPO_UGUALE:
                return False
        src = self.src
        fine_riga = self._fine_riga_da(j)
        k = j
        while k < fine_riga and src[k] in " \t":
            k += 1
        modo = "testo" if genere == "testo" else "valore"
        fine_arg = self._fine_comando(k, fine_riga, in_blocco, modo)
        resto = src[k:fine_arg]
        if not resto:
            if genere in ("ridefinito", "funzione_valore") or not inizio:
                return False
            if k == j and k < fine_riga and src[k] not in "#;":
                return False                          # `casa.x`, `stampa(`...
        else:
            if k == j:
                return False                          # attaccato: stampa( stampa. stampa= stampa"...
            if _non_e_argomento(resto):
                return False
            if resto[0] == "(" and self._classica(k, fine_arg):
                return False                          # forma classica: stampa (x), vai_a (1, 2)
            if genere == "ridefinito":
                riga_def, file_def = defs.nomi.get(nome, (0, ""))
                dove = f" alla riga {riga_def}" if riga_def else ""
                if file_def and file_def != os.path.basename(self.lx.nome_file):
                    dove += f" del file `{file_def}`"
                self._errore(f"`{nome}` qui è un nome del tuo programma (definito{dove}): per questo "
                             f"non funziona come comando senza parentesi.", i, j - i,
                             suggerimento=f"Scrivi la forma classica `{nome}(...)`, oppure dai un altro nome "
                                          f"alla tua variabile o funzione e usa il comando `{nome}`.")
                return False
            if genere == "funzione_valore":
                self._errore(f"La funzione `{nome}` restituisce un valore: si usa con le parentesi, "
                             f"come le funzioni che calcolano.", i, j - i,
                             suggerimento=f"Scrivi per esempio `stampa({nome}({resto}))` oppure "
                                          f"`variabile risultato = {nome}({resto})`.")
                return False
            if genere == "senza":
                self._errore(f"`{canonico}` non vuole valori: scrivi solo `{canonico}`.", k, fine_arg - k,
                             suggerimento=f"Togli `{resto}` oppure mettilo su un'altra riga.")
                return False
        # emissione: NOME ( argomenti )
        self._emetti(T.NOME, canonico, i, j, testo=parola)
        comando = self._nuovo_comando(canonico, parola, i, genere)
        self._sintetico(T.PARENTESI_APERTA, "(", j)
        if resto:
            if modo == "testo":
                if resto[0] == '"':
                    self._espressione_in(k, fine_arg)
                    self._pezzo(comando, "calcolo", k, fine_arg)
                else:
                    # `chiedi Come ti chiami?`: uno spazio tra la domanda e la risposta
                    self._testo_calcolato(k, fine_arg, comando,
                                          spazio_finale=canonico in COMANDI_DOPO_UGUALE)
            else:
                self._argomenti_valore(k, fine_arg, canonico, comando)
        self._sintetico(T.PARENTESI_CHIUSA, ")", fine_arg)
        self._chiudi_comando(comando, fine_arg)
        self.i = fine_arg
        return True

    def _comando_oggetto(self, parola: str, i: int, j: int, in_blocco: bool) -> bool:
        """``Palla.rimbalza 3`` (metodo senza parentesi) e ``Etichetta1.testo = Ciao (nome)``."""
        src = self.src
        fine_riga = self._fine_riga_da(j)
        if j + 1 >= fine_riga or not _inizio_nome(src[j + 1]):
            return False
        if not (parola[0].isupper() or parola in self._definizioni().controlli):
            return False                              # `lista.aggiungi(x)` resta con le parentesi
        membro, e = self._leggi_parola(j + 1)
        if e >= fine_riga or src[e] not in " \t":
            return False                              # `Finestra1.mostra` da solo, `P.x=1`, `P.f(...)`
        k = e
        while k < fine_riga and src[k] in " \t":
            k += 1
        if k >= fine_riga:
            return False
        if src[k] == "=" and src[k + 1:k + 2] != "=":
            if membro not in PROPRIETA_DI_TESTO:
                return False
            return self._proprieta_di_testo(parola, i, j, membro, e, k, fine_riga, in_blocco)
        fine_arg = self._fine_comando(k, fine_riga, in_blocco, "valore")
        resto = src[k:fine_arg]
        if not resto or _non_e_argomento(resto) or resto[0] in "<>*/%^+-!|:":
            return False
        if resto[0] == "(" and self._classica(k, fine_arg):
            return False
        self._emetti(T.NOME, parola, i, j)
        self._emetti(T.PUNTO, ".", j, j + 1)
        self._emetti(T.NOME, membro, j + 1, e)
        comando = self._nuovo_comando(f"{parola}.{membro}", f"{parola}.{membro}", i, "metodo")
        self._sintetico(T.PARENTESI_APERTA, "(", e)
        self._argomenti_valore(k, fine_arg, membro, comando)
        self._sintetico(T.PARENTESI_CHIUSA, ")", fine_arg)
        self._chiudi_comando(comando, fine_arg)
        self.i = fine_arg
        return True

    def _proprieta_di_testo(self, oggetto: str, i: int, j: int, membro: str, e: int, k: int,
                            fine_riga: int, in_blocco: bool) -> bool:
        src = self.src
        a = k + 1
        while a < fine_riga and src[a] in " \t":
            a += 1
        fine_arg = self._fine_comando(a, fine_riga, in_blocco, "testo")
        resto = src[a:fine_arg]
        if not resto or resto[0] in "\"([{" or _non_e_argomento(resto):
            return False
        if _inizio_nome(resto[0]):
            prima, fp = self._leggi_parola(a)
            prima = prima[0].lower() + prima[1:]
            if prima in COMANDI_DOPO_UGUALE and fp < fine_arg and src[fp] in " \t":
                return False                          # `Etichetta1.testo = chiedi Come ti chiami?`
        if self._e_codice(a, fine_arg):
            return False                              # `Etichetta1.testo = nome` (un calcolo valido)
        if _RE_IDENTIFICATORE.fullmatch(resto) and ("_" in resto or any(c.isdigit() for c in resto)):
            return False                              # `= nome_sconosciuto`: un nome sbagliato, non testo
        self._emetti(T.NOME, oggetto, i, j)
        self._emetti(T.PUNTO, ".", j, j + 1)
        self._emetti(T.NOME, membro, j + 1, e)
        self._emetti(T.ASSEGNA, "=", k, k + 1)
        comando = self._nuovo_comando(f"{oggetto}.{membro}", f"{oggetto}.{membro}", i, "proprieta")
        self._testo_calcolato(a, fine_arg, comando)
        self._chiudi_comando(comando, fine_arg)
        self.i = fine_arg
        return True

    # --- registro dei comandi letti (per leo.lettura e l'editor) ---------------------
    def _nuovo_comando(self, nome: str, scritto: str, i: int, genere: str) -> ComandoLetto:
        riga, colonna = self.lx._posizione(i)
        return ComandoLetto(riga, colonna, nome, scritto, genere)

    def _pezzo(self, comando: ComandoLetto | None, tipo: str, a: int, b: int, valore: Any = None) -> None:
        if comando is None or b <= a:
            return
        comando.pezzi.append(Pezzo(tipo, self.src[a:b], self.lx._posizione(a)[1], b - a, valore))

    def _chiudi_comando(self, comando: ComandoLetto, fine: int) -> None:
        comando.fine_colonna = self.lx._posizione(fine)[1]
        self.lx.comandi_letti.append(comando)

    # --- argomenti ------------------------------------------------------------------------
    def _espressione_in(self, a: int, b: int) -> None:
        sotto = _Scansione(self.lx, a, b, parte=True, profondita=self.profondita)
        for t, sp in zip(sotto.esegui(), sotto.span):
            if t.tipo is not T.FINE_FILE:
                self._aggiungi(t, *sp)

    def _token_di_prova(self, a: int, b: int) -> list[Token] | None:
        """Token di ``src[a:b]`` senza errori (``None`` se il lexer trova un problema)."""
        if b <= a:
            return None
        lx = self.lx
        vecchio = (lx.tollerante, lx.conserva_commenti, lx.testo_lungo_aperto)
        lx.tollerante, lx.conserva_commenti = True, False
        try:
            sotto = _Scansione(lx, a, b, parte=True, profondita=self.profondita + 1)
            token = sotto.esegui()
        except Exception:
            return None
        finally:
            lx.tollerante, lx.conserva_commenti, lx.testo_lungo_aperto = vecchio
        if any(t.tipo is T.ERRORE for t in token) or sotto.pila or sotto.profondita_commento:
            return None
        return token

    def _albero_di(self, a: int, b: int):
        """L'espressione di ``src[a:b]`` (``None`` se non e' un calcolo valido)."""
        cache = self.lx._cache_alberi
        testo = self.src[a:b]
        if "\n" not in testo and testo in cache:
            return cache[testo]
        albero = self._calcola_albero(a, b)
        if "\n" not in testo:
            cache[testo] = albero
        return albero

    def _calcola_albero(self, a: int, b: int):
        token = self._token_di_prova(a, b)
        if token is None or len(token) < 2:
            return None
        from .parser import Parser
        try:
            return Parser(token, self.lx.nome_file, rigoroso=False).espressione_isolata()
        except Exception:
            return None

    def _e_codice(self, a: int, b: int) -> bool:
        """Vero se ``src[a:b]`` e' un calcolo valido i cui nomi esistono tutti (variabili e
        funzioni del programma, controlli, libreria): allora non e' testo."""
        albero = self._albero_di(a, b)
        if albero is None:
            return False
        defs = self._definizioni()
        if type(albero).__name__ == "Nome" and albero.nome in funzioni_libreria() \
                and albero.nome not in defs.nomi:
            return False                              # `colore casuale`: una parola, non la funzione
        if defs.nomi_nascosti:
            return True
        predefiniti = nomi_predefiniti()
        for nome in _nomi_liberi(albero):
            if nome not in defs.nomi and nome not in defs.controlli and nome not in predefiniti:
                return False
        return True

    def _dividi_virgole(self, a: int, b: int) -> list[tuple[int, int]]:
        src = self.src
        pezzi = []
        livello = 0
        inizio = a
        q = a
        while q < b:
            c = src[q]
            if c == '"':
                q += 1
                while q < b and src[q] != '"':
                    q += 2 if src[q] == "\\" else 1
            elif c in "([{":
                livello += 1
            elif c in ")]}":
                livello = max(0, livello - 1)
            elif c == "," and livello == 0:
                pezzi.append((inizio, q))
                inizio = q + 1
            q += 1
        pezzi.append((inizio, b))
        pulite = []
        for x, y in pezzi:
            while x < y and src[x] in " \t":
                x += 1
            while y > x and src[y - 1] in " \t":
                y -= 1
            pulite.append((x, y))
        return pulite

    def _argomenti_valore(self, a: int, b: int, comando_nome: str, comando: ComandoLetto) -> None:
        for n, (x, y) in enumerate(self._dividi_virgole(a, b)):
            if n:
                self._sintetico(T.VIRGOLA, ",", x)
            self._argomento_valore(x, y, comando_nome, comando, n)

    def _numero_con_unita(self, a: int, b: int, comando_nome: str, comando: ComandoLetto,
                          indice: int = 0) -> bool:
        """``100``, ``2 secondi``, ``500 millisecondi``, ``90 gradi``, ``90°``: un numero (con
        l'unita' facoltativa, convertita). Falso se ``src[a:b]`` non e' cosi'."""
        m = _RE_NUMERO_UNITA.fullmatch(self.src, a, b)
        if not m:
            return False
        cifre, unita = m.group(1), m.group(2)
        fattore: float = 1
        if unita is not None:
            voce = UNITA.get(unita)
            if voce is None:
                return False                          # `3 volte`, `100 metri`: testo
            fattore, genere = voce
            atteso = genere_unita(comando_nome, indice)
            if atteso is not None and atteso != genere:
                self._errore(f"`{comando_nome}` si misura in {nome_unita(atteso)}, non in `{unita}`.",
                             a, b - a, suggerimento=f"Scrivi per esempio `{comando_nome} {cifre} "
                                                    f"{nome_unita(atteso)}`, oppure solo il numero.")
                return True
        valore: Any = float(cifre) if "." in cifre else int(cifre)
        if fattore != 1:
            valore = valore * fattore
            if isinstance(valore, float) and valore.is_integer() and "." not in cifre and fattore > 1:
                valore = int(valore)
        self._emetti(T.DECIMALE if isinstance(valore, float) else T.INTERO, valore, a, b)
        self._pezzo(comando, "numero", a, b, valore)
        return True

    def _argomento_valore(self, a: int, b: int, comando_nome: str, comando: ComandoLetto,
                          indice: int = 0) -> None:
        src = self.src
        testo = src[a:b]
        if not testo:
            self._errore("Qui manca un valore tra le virgole.", a, 1,
                         suggerimento="Scrivi un valore tra le due virgole oppure togline una.")
            return
        if self._numero_con_unita(a, b, comando_nome, comando, indice):
            return
        if testo[0] == '"' or testo in ("vero", "falso", "nulla") or (
                testo[0] == "(" and self._chiusa_di(a, b) == b - 1):
            self._espressione_in(a, b)
            self._pezzo(comando, "calcolo", a, b)
            return
        # unita' dopo un calcolo: `attendi pausa secondi`, `destra angolo gradi`
        m = _RE_UNITA_FINALE.search(src, a, b)
        if m and m.end() == b and m.start() > a:
            unita = m.group(1)
            voce = UNITA.get(unita)
            atteso = genere_unita(comando_nome, indice)
            if voce is not None and (atteso is None or atteso == voce[1]) and self._e_codice(a, m.start()):
                fine_espr = m.start()
                while fine_espr > a and src[fine_espr - 1] in " \t":
                    fine_espr -= 1
                if voce[0] != 1:
                    self._sintetico(T.PARENTESI_APERTA, "(", a)
                self._espressione_in(a, fine_espr)
                if voce[0] != 1:
                    self._sintetico(T.PARENTESI_CHIUSA, ")", fine_espr)
                    self._sintetico(T.ASTERISCO, "*", fine_espr)
                    self._sintetico(T.DECIMALE if isinstance(voce[0], float) else T.INTERO, voce[0], fine_espr)
                self._pezzo(comando, "calcolo", a, fine_espr)
                return
        if self._e_codice(a, b):
            self._espressione_in(a, b)
            self._pezzo(comando, "calcolo", a, b)
            return
        self._testo_calcolato(a, b, comando)

    # --- testo libero: le parentesi calcolano ------------------------------------------
    @staticmethod
    def _catena_prima(buf: list[str]) -> int:
        """Quanti caratteri alla fine di ``buf`` formano ``nome`` o ``oggetto.metodo``."""
        s = len(buf)
        while True:
            t = s
            while t > 0 and _parte_nome(buf[t - 1]):
                t -= 1
            if t == s or not _inizio_nome(buf[t]):
                break
            s = t
            if s > 1 and buf[s - 1] == "." and _parte_nome(buf[s - 2]):
                s -= 1
                continue
            break
        if s < len(buf) and buf[s] == ".":
            s += 1
        return len(buf) - s

    def _parentesi_non_calcolabile(self, a: int, b: int, q: int, e: int, motivo: str) -> None:
        testo = self.src[a:b]
        riga, colonna = self.lx._posizione(a)
        correzioni = []
        if not any(c in testo for c in '"{}\\'):
            correzioni = [Correzione(riga, colonna, testo, f'"{testo}"',
                                     "metti la frase tra virgolette: le parentesi restano parentesi")]
        self._errore(f"Le parentesi calcolano: {motivo}", q, e + 1 - q,
                     suggerimento=f"Per scrivere le parentesi così come sono metti la frase tra virgolette: "
                                  f"`\"{testo}\"`.", correzioni=correzioni)

    def _parentesi_scolastiche(self, a: int, b: int, q: int) -> int:
        """Quadre o graffe nel testo libero: in Leo si calcola solo con le tonde."""
        src = self.src
        aperta = src[q]
        chiusa = "]" if aperta == "[" else "}"
        e = src.find(chiusa, q + 1, b)
        fine = b if e < 0 else e + 1
        riga, colonna = self.lx._posizione(q)
        correzioni = []
        tutto = src[a:b].translate(_TONDE)
        if aperta == "[" and _e_espressione(tutto):
            # `stampa [3 + 4] * 2` -> `stampa ((3 + 4) * 2)`: tutto il calcolo tra tonde
            riga_a, colonna_a = self.lx._posizione(a)
            correzioni = [Correzione(riga_a, colonna_a, src[a:b], "(" + tutto + ")",
                                     "per calcolare si usano le parentesi tonde")]
        elif e >= 0 and self._albero_di(q + 1, e) is not None:
            correzioni = [Correzione(riga, colonna, src[q:fine], "(" + src[q + 1:e] + ")",
                                     "per calcolare si usano le parentesi tonde")]
        if aperta == "{":
            messaggio = ("Le graffe `{ }` valgono solo dentro le virgolette (`\"Ciao {nome}\"`): "
                         "fuori dalle virgolette i valori si scrivono tra parentesi tonde.")
            suggerimento = f"Scrivi `({src[q + 1:e]})`." if e >= 0 else "Usa le parentesi tonde `( )`."
        else:
            messaggio = ("In Leo per i calcoli si usano solo le parentesi tonde `( )`: le quadre `[ ]` "
                         "servono per le liste.")
            suggerimento = ("Usa le tonde, una dentro l'altra se serve: `((3 + 4) * 2)`. Per scrivere le "
                            "quadre così come sono metti la frase tra virgolette.")
        self._errore(messaggio, q, fine - q, suggerimento=suggerimento, correzioni=correzioni)
        return fine

    def _testo_calcolato(self, a: int, b: int, comando: ComandoLetto | None, *,
                         spazio_finale: bool = False) -> None:
        """Testo libero: le parentesi calcolano, il resto e' testo cosi' com'e'."""
        src = self.src
        parti: list[Any] = []
        buf: list[str] = []
        inizio_buf = a
        q = a
        while q < b:
            c = src[q]
            if c in "[{":
                if buf:
                    parti.append("".join(buf))
                    self._pezzo(comando, "testo", inizio_buf, q)
                    buf = []
                q = self._parentesi_scolastiche(a, b, q)
                inizio_buf = q
                continue
            if c == "(":
                if self._faccina(q, a, b):
                    buf.append(c)
                    q += 1
                    continue
                e = self._chiusa_di(q, b)
                if e is None:
                    self._errore("La parentesi `(` non è mai chiusa: dopo un comando le parentesi "
                                 "servono a calcolare.", q, 1,
                                 suggerimento="Chiudi con `)`; per scrivere una parentesi così com'è metti "
                                              "la frase tra virgolette: `\"...\"`.")
                    buf.append(src[q:b])
                    q = b
                    break
                lung = self._catena_prima(buf)
                nome_f = "".join(buf[len(buf) - lung:]) if lung else ""
                if nome_f and "." not in nome_f and not self._funzione_nota(nome_f):
                    self._errore(f"`{nome_f}(...)`: `{nome_f}` non è una funzione che conosco. Dopo un comando "
                                 "le parentesi calcolano.", q - lung, e + 1 - (q - lung),
                                 suggerimento=f"Stacca la parola dalla parentesi (`{nome_f} (...)`), oppure "
                                              "metti la frase tra virgolette.")
                    nome_f = ""
                    lung = 0
                if nome_f:
                    inizio_calcolo = q - lung
                    if self._albero_di(inizio_calcolo, e + 1) is None:
                        self._parentesi_non_calcolabile(a, b, inizio_calcolo, e,
                                                        f"`{src[inizio_calcolo:e + 1]}` non è un calcolo valido.")
                    del buf[len(buf) - lung:]
                    parte = self._parte(inizio_calcolo, e + 1)
                else:
                    inizio_calcolo = q
                    interno = src[q + 1:e]
                    due_punti = self._due_punti_del_formato(q + 1, e)
                    fine_espr = due_punti if due_punti is not None else e
                    if not interno.strip():
                        self._parentesi_non_calcolabile(a, b, q, e, "tra `(` e `)` non c'è niente da calcolare.")
                    elif self._albero_di(q + 1, fine_espr) is None:
                        self._parentesi_non_calcolabile(a, b, q, e,
                                                        f"`({interno})` non è un calcolo che Leo sa fare.")
                    parte = self._parte(q + 1, e)
                if buf:
                    parti.append("".join(buf))
                    self._pezzo(comando, "testo", inizio_buf, inizio_calcolo)
                    buf = []
                parti.append(parte)
                self._pezzo(comando, "calcolo", inizio_calcolo, e + 1)
                q = e + 1
                inizio_buf = q
                continue
            buf.append(c)
            q += 1
        if buf:
            parti.append("".join(buf))
            self._pezzo(comando, "testo", inizio_buf, q)
        if not parti:
            return
        if spazio_finale:
            if isinstance(parti[-1], str):
                if not parti[-1][-1:].isspace():
                    parti[-1] += " "
            else:
                parti.append(" ")
        if len(parti) == 1 and isinstance(parti[0], str):
            self._emetti(T.TESTO, parti[0], a, b, origine="comando")
        else:
            self._emetti(T.TESTO_INTERPOLATO, parti, a, b, origine="comando")

    # --- numeri -----------------------------------------------------------------------
    def _cifre(self, j: int) -> int:
        """Consuma cifre (con ``_`` solo tra due cifre) da ``j``; restituisce la fine."""
        src, fine = self.src, self.fine
        inizio = j
        while j < fine:
            c = src[j]
            if _cifra(c):
                j += 1
            elif (c == "_" and j > inizio and _cifra(src[j - 1])
                  and j + 1 < fine and _cifra(src[j + 1])):
                j += 1
            else:
                break
        return j

    def _numero(self) -> None:
        src, fine, i = self.src, self.fine, self.i
        j = self._cifre(i)
        decimale = False
        if j + 1 < fine and src[j] == "." and _cifra(src[j + 1]):
            decimale = True
            j = self._cifre(j + 1)
        if j < fine and src[j] in "eE":
            k = j + 1
            if k < fine and src[k] in "+-":
                k += 1
            if k < fine and _cifra(src[k]):
                decimale = True
                j = self._cifre(k)
        testo = src[i:j]
        if j < fine and _parte_nome(src[j]):
            k = j
            while k < fine and _parte_nome(src[k]):
                k += 1
            if self._durata_di_anima(src[j:k]):
                # `anima P.alto a 10 in 2s`: numero e unita' attaccati
                self.i = j
                pulito = testo.replace("_", "")
                self._emetti(T.DECIMALE if decimale else T.INTERO,
                             float(pulito) if decimale else int(pulito), i, j)
                self._emetti(T.NOME, src[j:k], j, k)
                self.i = k
                return
            self.i = k
            if src[j] == "_":
                self._errore(f"Nel numero `{src[i:k]}` il `_` può stare solo tra due cifre.", i, k - i,
                             suggerimento="Usa `_` per separare le migliaia, come in `1_000_000`.")
            else:
                self._numero_attaccato(testo, i, j, k)
            return
        self.i = j
        pulito = testo.replace("_", "")
        try:
            valore: Any = float(pulito) if decimale else int(pulito)
        except (ValueError, OverflowError):
            self._errore(f"Il numero `{testo}` è troppo lungo.", i, j - i)
            return
        self._emetti(T.DECIMALE if decimale else T.INTERO, valore, i, j)

    def _numero_attaccato(self, testo: str, i: int, j: int, k: int) -> None:
        """Numero ``src[i:j]`` attaccato alla parola ``src[j:k]`` (``2a``, ``3volte``).

        Se la parola e' ``volte``/``allora``/``fai`` basta uno spazio (correzione di
        forma). Con un nome invece non si corregge mai da soli: ``2a`` puo' voler dire
        ``2 * a`` oppure ``2, a`` e scegliere cambierebbe la logica del programma.
        """
        attaccato = self.src[j:k]
        trovato = self.lx._parole.get((_normalizza_parola(attaccato),))
        if trovato is not None and trovato[0] in _PAROLE_DA_STACCARE:
            riga, colonna = self.lx._posizione(j)
            self._errore(f"Il numero `{testo}` è attaccato a `{attaccato}`: manca uno spazio.", i, k - i,
                         suggerimento=f"Scrivi `{testo} {attaccato}`, con uno spazio in mezzo.",
                         correzioni=[Correzione(riga, colonna, "", " ",
                                                f"separa il numero `{testo}` da `{attaccato}`")])
            return
        suggerimento = (f"Un nome non può iniziare con una cifra. Scrivi `{testo} * {attaccato}` "
                        f"(per moltiplicare) oppure `{testo}, {attaccato}` (due valori).")
        if attaccato in UNITA_DI_TEMPO:
            suggerimento += f" Per una durata scrivi `{testo} secondi`, con lo spazio."
        self._errore(f"Il numero `{testo}` è attaccato a `{attaccato}`.", i, k - i, suggerimento=suggerimento)

    def _durata_di_anima(self, unita: str) -> bool:
        """Vero se ``unita`` (``s``, ``ms``, ``secondi``...) e' attaccata a un numero
        scritto subito dopo ``in`` in una riga che comincia con ``anima``."""
        if unita not in UNITA_DI_TEMPO or self.parte:
            return False
        k = len(self.token) - 1
        while k >= 0 and self.token[k].tipo is T.COMMENTO:
            k -= 1
        if k >= 0 and self.token[k].tipo is T.NOME and self.token[k].valore in ("ogni", "dopo"):
            # `ogni 2s fai`, `dopo 300ms fai`: il numero subito dopo la parola, a inizio istruzione
            j = k - 1
            while j >= 0 and self.token[j].tipo is T.COMMENTO:
                j -= 1
            return j < 0 or self.token[j].tipo in (T.FINE_RIGA, T.ALLORA, T.FAI, T.ALTRIMENTI)
        if k < 0 or self.token[k].tipo is not T.IN:
            return False
        primo = None
        while k >= 0 and self.token[k].tipo is not T.FINE_RIGA:
            if self.token[k].tipo is not T.COMMENTO:
                primo = self.token[k]
            k -= 1
        return primo is not None and primo.tipo is T.NOME and primo.valore == "anima"

    # --- testi ------------------------------------------------------------------------
    def _testo(self) -> None:
        src, i = self.src, self.i
        if src.startswith('"""', i, self.fine):
            self._testo_lungo()
            return
        fine_riga = src.find("\n", i, self.fine)
        if fine_riga == -1:
            fine_riga = self.fine
        parti: list[Any] = []
        buffer: list[str] = []
        interpolato = False
        errore: tuple[str, str | None] | None = None   # primo errore (solo modalita' tollerante)
        j = i + 1
        while True:
            if j >= fine_riga:
                self._testo_non_chiuso(i, fine_riga)
                return
            c = src[j]
            if c == '"':
                j += 1
                break
            if c == "\\":
                if j + 1 < fine_riga and src[j + 1] in _ESCAPE:
                    buffer.append(_ESCAPE[src[j + 1]])
                    j += 2
                    continue
                sequenza = src[j:j + 2] if j + 1 < fine_riga else "\\"
                messaggio = f"La sequenza `{sequenza}` non è valida in un testo."
                if not self.lx.tollerante:
                    self._errore(messaggio, j, len(sequenza), suggerimento=_SUGG_ESCAPE)
                errore = errore or (messaggio, _SUGG_ESCAPE)
                buffer.append(sequenza)
                j += len(sequenza)
                continue
            if c == "{":
                k = self._fine_graffa(j, fine_riga)
                if k is None:
                    self._graffa_non_chiusa(i, j, fine_riga)
                    return
                interno = src[j + 1:k]
                if not interno.strip():
                    messaggio = "Le graffe `{}` nel testo sono vuote: scrivi un'espressione tra `{` e `}`."
                    suggerimento = "Per scrivere una graffa vera usa `\\{` e `\\}`."
                    if not self.lx.tollerante:
                        self._errore(messaggio, j, k - j + 1, suggerimento=suggerimento)
                    errore = errore or (messaggio, suggerimento)
                    j = k + 1
                    continue
                if buffer:
                    parti.append("".join(buffer))
                    buffer = []
                parti.append(self._parte(j + 1, k))
                interpolato = True
                j = k + 1
                continue
            buffer.append(c)
            j += 1
        if errore is not None:
            self._errore(errore[0], i, j - i, suggerimento=errore[1])
            self.i = j
            return
        if interpolato:
            if buffer:
                parti.append("".join(buffer))
            self._emetti(T.TESTO_INTERPOLATO, parti, i, j)
        else:
            self._emetti(T.TESTO, "".join(buffer), i, j)
        self.i = j

    def _testo_lungo(self) -> None:
        """Testo su piu' righe ``\"\"\" ... \"\"\"``: escape e ``{espressioni}`` come nei
        testi normali. L'a capo subito dopo le virgolette di apertura non conta; se
        le virgolette di chiusura stanno da sole sulla loro riga, il loro rientro si
        toglie da ogni riga (e l'a capo prima di esse non conta): cosi' il testo si
        puo' rientrare insieme al codice."""
        src, i, limite = self.src, self.i, self.fine
        j = i + 3
        chiusura = -1
        while j < limite:
            c = src[j]
            if c == "\\":
                j += 2
                continue
            if src.startswith('"""', j, limite):
                while j + 3 < limite and src[j + 3] == '"':
                    j += 1          # `""""`: l'ultima virgoletta del testo prima della chiusura
                chiusura = j
                break
            j += 1
        if chiusura < 0:
            self.lx.testo_lungo_aperto = True
            self.i = limite
            if self.lx.tollerante:
                self._emetti(T.TESTO, src[i + 3:limite], i, limite)
                return
            self._errore("Il testo su più righe aperto qui non è mai chiuso: mancano le tre virgolette `\"\"\"`.",
                         i, 3, suggerimento="Chiudi il testo con `\"\"\"` (tre virgolette) dove finisce.")
            return
        inizio = i + 3
        fine = chiusura
        if src.startswith("\n", inizio, fine):
            inizio += 1
        rientro = ""
        ultimo_a_capo = src.rfind("\n", inizio - 1, fine)
        if ultimo_a_capo >= inizio - 1 and ultimo_a_capo >= 0 and not src[ultimo_a_capo + 1:fine].strip(" \t"):
            rientro = src[ultimo_a_capo + 1:fine]
            fine = max(inizio, ultimo_a_capo)
        parti: list[Any] = []
        buffer: list[str] = []
        interpolato = False
        errore: tuple[str, str | None] | None = None
        j = inizio
        a_inizio_riga = inizio != i + 3     # dopo l'a capo iniziale si toglie anche il primo rientro
        while j < fine:
            if a_inizio_riga:
                a_inizio_riga = False
                k = 0
                while k < len(rientro) and j < fine and src[j] == rientro[k]:
                    j += 1
                    k += 1
                if j >= fine:
                    break
            c = src[j]
            if c == "\n":
                buffer.append(c)
                j += 1
                a_inizio_riga = True
                continue
            if c == "\\":
                if j + 1 < fine and src[j + 1] in _ESCAPE:
                    buffer.append(_ESCAPE[src[j + 1]])
                    j += 2
                    continue
                sequenza = src[j:j + 2] if j + 1 < fine else "\\"
                messaggio = f"La sequenza `{sequenza}` non è valida in un testo."
                if not self.lx.tollerante:
                    self._errore(messaggio, j, len(sequenza), suggerimento=_SUGG_ESCAPE)
                errore = errore or (messaggio, _SUGG_ESCAPE)
                buffer.append(sequenza)
                j += len(sequenza)
                continue
            if c == "{":
                k = self._fine_graffa(j, fine)
                if k is None:
                    messaggio = "La graffa `{` aperta in questo testo non è mai chiusa."
                    suggerimento = "Chiudi l'espressione con `}`; per scrivere una graffa vera usa `\\{`."
                    if not self.lx.tollerante:
                        self._errore(messaggio, j, 1, suggerimento=suggerimento)
                    errore = errore or (messaggio, suggerimento)
                    buffer.append(c)
                    j += 1
                    continue
                if not src[j + 1:k].strip():
                    messaggio = "Le graffe `{}` nel testo sono vuote: scrivi un'espressione tra `{` e `}`."
                    suggerimento = "Per scrivere una graffa vera usa `\\{` e `\\}`."
                    if not self.lx.tollerante:
                        self._errore(messaggio, j, k - j + 1, suggerimento=suggerimento)
                    errore = errore or (messaggio, suggerimento)
                    j = k + 1
                    continue
                if buffer:
                    parti.append("".join(buffer))
                    buffer = []
                parti.append(self._parte(j + 1, k))
                interpolato = True
                j = k + 1
                continue
            buffer.append(c)
            j += 1
        fine_token = chiusura + 3
        self.i = fine_token
        if errore is not None:
            self._errore(errore[0], i, fine_token - i, suggerimento=errore[1])
            return
        if interpolato:
            if buffer:
                parti.append("".join(buffer))
            self._emetti(T.TESTO_INTERPOLATO, parti, i, fine_token)
        else:
            self._emetti(T.TESTO, "".join(buffer), i, fine_token)

    def _testo_non_chiuso(self, i: int, fine_riga: int) -> None:
        self.i = fine_riga
        if self.lx.tollerante:
            self._emetti(T.TESTO, self.src[i + 1:fine_riga], i, fine_riga)
            return
        punto, dubbio = self._punto_di_chiusura(i + 1, fine_riga)
        if punto is None:
            colonna_testo = self.lx._posizione(i)[1]
            self._errore(f"Manca la virgoletta `\"` che chiude il testo iniziato alla colonna {colonna_testo}.",
                         i, fine_riga - i,
                         suggerimento=f"Non si capisce dove finisce il testo: {dubbio} "
                                      "Metti tu la `\"` nel punto giusto.")
            return
        riga, colonna = self.lx._posizione(punto)
        self._errore("Il testo aperto qui non è mai chiuso: manca la virgoletta `\"` che lo chiude.", i, fine_riga - i,
                     suggerimento="Un testo sta su una sola riga: chiudilo con `\"`; per andare a capo usa `\\n`.",
                     correzioni=[Correzione(riga, colonna, "", '"', "chiudi il testo con `\"`")])

    def _punto_di_chiusura(self, inizio: int, fine_riga: int) -> tuple[int | None, str]:
        """Dove mettere la ``"`` che manca a un testo iniziato in ``inizio`` e mai chiuso.

        La virgoletta va prima delle parentesi finali che chiudono quelle aperte fuori
        dal testo (``stampa("ciao)`` -> ``stampa("ciao")``) e, nelle righe
        ``se``/``mentre``/``per ogni``/``altrimenti se``/``quando``, prima di
        ``allora``/``fai`` finale (``se n == "Ada allora`` -> ``se n == "Ada" allora``).
        Restituisce ``(posizione, "")`` oppure ``(None, spiegazione)`` quando il punto
        giusto e' ambiguo (``stampa("(nota)``: la ``)`` e' del testo o della chiamata?).
        """
        src = self.src
        fine = fine_riga
        while fine > inizio and src[fine - 1] in _SPAZI + "\r":
            fine -= 1
        punto = fine
        if self._riga_di_intestazione():
            m = fine
            while m > inizio and _parte_nome(src[m - 1]):
                m -= 1
            trovato = self.lx._parole.get((_normalizza_parola(src[m:fine]),)) if m < fine else None
            if (trovato is not None and trovato[0] in (T.ALLORA, T.FAI)
                    and m > inizio and src[m - 1] in _SEPARATORI_PAROLE):
                punto = m
                while punto > inizio and src[punto - 1] in _SPAZI:
                    punto -= 1
        # parentesi finali che chiudono quelle aperte fuori dal testo (la piu' interna per prima)
        attese = [_APERTE[aperta] for aperta, _ in reversed(self.pila)]
        finali: list[int] = []          # posizioni delle parentesi finali, da destra
        k = punto
        while k > inizio:
            c = src[k - 1]
            if c in _SPAZI:
                k -= 1
            elif c in _CHIUSE:
                finali.append(k - 1)
                k -= 1
            else:
                break
        spostate = 0
        for n in range(min(len(finali), len(attese)), 0, -1):
            if [src[q] for q in reversed(finali[:n])] == attese[:n]:
                spostate = n
                break
        if spostate:
            punto = finali[spostate - 1]
        elif punto == fine:
            punto = fine_riga if src[fine_riga - 1:fine_riga] != "\r" else fine
        # parentesi dentro il testo che restano senza compagna
        aperte_dentro: list[str] = []
        chiuse_sole: list[str] = []
        k = inizio
        while k < punto:
            c = src[k]
            if c == "\\":
                k += 2
                continue
            if c in _APERTE:
                aperte_dentro.append(c)
            elif c in _CHIUSE:
                if aperte_dentro and aperte_dentro[-1] == _CHIUSE[c]:
                    aperte_dentro.pop()
                else:
                    chiuse_sole.append(c)
            k += 1
        if spostate and aperte_dentro:
            c = src[finali[spostate - 1]]
            return None, f"la `{c}` finale può far parte del testo oppure chiudere la `{_CHIUSE[c]}` fuori dal testo."
        fuori = attese[spostate:]
        for c in chiuse_sole:
            if c in fuori:
                return None, f"la `{c}` può far parte del testo oppure chiudere la `{_CHIUSE[c]}` fuori dal testo."
        return punto, ""

    def _riga_di_intestazione(self) -> bool:
        """Vero se l'istruzione della riga corrente comincia con ``se``, ``altrimenti se``,
        ``mentre``, ``per ogni`` o ``quando`` e non ha ancora il suo ``allora``/``fai``."""
        k = len(self.token) - 1
        primo = None
        while k >= 0 and self.token[k].tipo is not T.FINE_RIGA:
            tipo = self.token[k].tipo
            if tipo in (T.ALLORA, T.FAI):
                return False
            if tipo is not T.COMMENTO:
                primo = self.token[k]
            k -= 1
        return primo is not None and primo.tipo in _INTESTAZIONI

    def _graffa_non_chiusa(self, i: int, j: int, fine_riga: int) -> None:
        """Graffa ``{`` di interpolazione senza ``}`` sulla stessa riga."""
        self.i = fine_riga
        testo_aperto = '"' not in self.src[j + 1:fine_riga]
        if self.lx.tollerante:
            if testo_aperto:
                self._emetti(T.TESTO, self.src[i + 1:fine_riga], i, fine_riga)
            else:
                self._errore("La graffa `{` aperta in questo testo non è mai chiusa.", i, fine_riga - i)
            return
        correzioni = []
        if testo_aperto:
            punto, _dubbio = self._punto_di_chiusura(j + 1, fine_riga)
            if punto is not None:
                riga, colonna = self.lx._posizione(punto)
                correzioni.append(Correzione(riga, colonna, "", '}"', "chiudi la graffa e il testo"))
        self._errore("La graffa `{` aperta in questo testo non è mai chiusa.", j, 1,
                     suggerimento="Chiudi l'espressione con `}`; per scrivere una graffa vera usa `\\{`.",
                     correzioni=correzioni)

    def _fine_graffa(self, j: int, limite: int) -> int | None:
        """Indice della ``}`` che chiude la ``{`` in ``j`` (graffe annidate e testi
        tra virgolette saltati), oppure None se non si chiude prima di ``limite``."""
        src = self.src
        modi = ["g"]          # "g" = dentro graffe, "t" = dentro un testo annidato
        k = j + 1
        while k < limite:
            c = src[k]
            if modi[-1] == "t":
                if c == "\\":
                    k += 2
                    continue
                if c == '"':
                    modi.pop()
                elif c == "{":
                    modi.append("g")
            else:
                if c == "{":
                    modi.append("g")
                elif c == "}":
                    modi.pop()
                    if not modi:
                        return k
                elif c == '"':
                    modi.append("t")
            k += 1
        return None

    def _parte(self, inizio: int, fine: int) -> ParteInterpolata:
        """Tokenizza il contenuto di ``{...}`` con posizioni reali."""
        riga, colonna = self.lx._posizione(inizio)
        sorgente = self.src[inizio:fine]
        if self.profondita + 1 > _MAX_ANNIDAMENTO:
            messaggio = "Troppi testi interpolati uno dentro l'altro."
            if not self.lx.tollerante:
                self._errore(messaggio, inizio, fine - inizio)
            fine_riga, fine_colonna = self.lx._posizione(fine)
            token = [Token(T.ERRORE, messaggio, riga, colonna, sorgente, fine - inizio, "canonica"),
                     Token(T.FINE_FILE, None, fine_riga, fine_colonna, None, 0, "sintetico")]
            return ParteInterpolata(sorgente, riga, colonna, token)
        due_punti = self._due_punti_del_formato(inizio, fine)
        formato = None
        fine_espressione = fine
        if due_punti is not None:
            formato = self.src[due_punti + 1:fine].strip()
            fine_espressione = due_punti
        scansione = _Scansione(self.lx, inizio, fine_espressione, parte=True, profondita=self.profondita + 1)
        return ParteInterpolata(sorgente, riga, colonna, scansione.esegui(), formato)

    def _due_punti_del_formato(self, inizio: int, fine: int) -> int | None:
        """Posizione dei ``:`` di un formato (``{prezzo:2}``, ``{n:migliaia}``): i due
        punti fuori da parentesi e testi, seguiti solo da lettere, cifre e spazi.
        Nelle espressioni di Leo i ``:`` fuori dalle parentesi non esistono, quindi
        nessun testo che prima funzionava cambia significato."""
        src = self.src
        livello = 0
        k = inizio
        trovato = None
        while k < fine:
            c = src[k]
            if c == '"':
                k += 1
                while k < fine and src[k] != '"':
                    k += 2 if src[k] == "\\" else 1
            elif c in "([{":
                livello += 1
            elif c in ")]}":
                livello -= 1
            elif c == ":" and livello == 0:
                trovato = k
                break
            k += 1
        if trovato is None:
            return None
        resto = src[trovato + 1:fine]
        if not resto.strip() or any(not (ch.isalnum() or ch in " \t_.,") for ch in resto):
            return None
        return trovato

    # --- operatori e parentesi ------------------------------------------------------------
    def _operatore(self) -> None:
        src, fine, i = self.src, self.fine, self.i
        simbolo = _OPERATORI_UNICODE.get(src[i])
        if simbolo is not None:
            # `≥ ≤ ≠ × ÷` valgono come `>= <= != * /`
            self.i = i + 1
            self._emetti(_TIPO_OPERATORE[simbolo], simbolo, i, i + 1)
            return
        if src.startswith(("=>", "=<"), i, fine):
            self._confronto_rovesciato()
            return
        for testo, tipo in OPERATORI:
            if src.startswith(testo, i, fine):
                break
        else:
            self._sconosciuto()
            return
        self.i = i + len(testo)
        if testo in _APERTE:
            self.pila.append((testo, i))
        elif testo in _CHIUSE:
            if not self._chiusura_valida(testo, i):
                return
        self._emetti(tipo, testo, i, i + len(testo))

    def _confronto_rovesciato(self) -> None:
        """``=>`` e ``=<`` scritti al posto di ``>=`` e ``<=``: errore con la
        riga corretta proposta (in modalita' tollerante un token ``ERRORE``,
        come per gli altri simboli sconosciuti)."""
        i = self.i
        scritto = self.src[i:i + 2]
        giusto = scritto[1] + "="
        self.i = i + 2
        riga, colonna = self.lx._posizione(i)
        nome = "maggiore o uguale" if giusto == ">=" else "minore o uguale"
        self._errore(f"`{scritto}` non è un operatore di Leo: per «{nome}» si scrive `{giusto}`.", i, 2,
                     suggerimento=f"Il segno `=` va dopo: `{giusto}`, come si legge «{nome}».",
                     correzioni=[Correzione(riga, colonna, scritto, giusto, f"scrivi `{giusto}`")])

    def _chiusura_valida(self, testo: str, i: int) -> bool:
        riga, colonna = self.lx._posizione(i)
        if not self.pila:
            self._errore(f"Ho trovato `{testo}` ma non c'è nessuna parentesi aperta da chiudere.", i, 1,
                         suggerimento=f"Togli la `{testo}` in più oppure aggiungi la `{_CHIUSE[testo]}` che manca.",
                         correzioni=[Correzione(riga, colonna, testo, "", f"togli la `{testo}` in più")])
            return False
        aperta, offset = self.pila[-1]
        if _APERTE[aperta] != testo:
            riga_aperta = self.lx._posizione(offset)[0]
            giusta = _APERTE[aperta]
            self._errore(f"Ho trovato `{testo}` ma era aperta `{aperta}` alla riga {riga_aperta}.", i, 1,
                         suggerimento=f"Chiudi prima la `{aperta}` con `{giusta}`.",
                         correzioni=[Correzione(riga, colonna, testo, giusta,
                                                f"chiudi la `{aperta}` aperta alla riga {riga_aperta}")])
            # (solo in modalita' tollerante si arriva qui) recupero: se piu' in basso
            # nella pila c'e' la parentesi giusta, si considerano chiuse quelle sopra.
            for indice in range(len(self.pila) - 1, -1, -1):
                if _APERTE[self.pila[indice][0]] == testo:
                    del self.pila[indice:]
                    break
            return False
        self.pila.pop()
        return True

    def _sconosciuto(self) -> None:
        src, fine, i = self.src, self.fine, self.i
        if src[i] == "?" and i > 0 and (src[i - 1].isalnum() or src[i - 1] in "_)"):
            # `testo?`: tipo che puo' valere nulla (il parser lo accetta solo nei tipi)
            self.i = i + 1
            self._emetti(T.PUNTO_INTERROGATIVO, "?", i, i + 1)
            return
        for simbolo, suggerimento in _SIMBOLI_NOTI:
            if src.startswith(simbolo, i, fine):
                self.i = i + len(simbolo)
                nome = "Il carattere" if len(simbolo) == 1 else "Il simbolo"
                self._errore(f"{nome} `{simbolo}` non fa parte di Leo.", i, len(simbolo),
                             suggerimento=suggerimento, correzioni=self._correzioni_simbolo(simbolo, i))
                return
        c = src[i]
        self.i = i + 1
        self._errore(f"Il carattere `{_mostra_carattere(c)}` non fa parte di Leo.", i, 1)

    def _correzioni_simbolo(self, simbolo: str, i: int) -> list[Correzione]:
        """Correzioni di forma per i simboli di altri linguaggi: ``&&`` -> ``e``,
        ``||`` -> ``o``, ``!x`` -> ``non x``, ``'ciao'`` o ``“ciao”`` -> ``"ciao"``."""
        if self.lx.tollerante:
            return []
        src = self.src
        riga, colonna = self.lx._posizione(i)
        dopo = i + len(simbolo)
        parola = {"&&": "e", "||": "o", "!": "non"}.get(simbolo)
        if parola is not None:
            prima_spazio = i == 0 or src[i - 1] in _SPAZI + "\n("
            dopo_spazio = dopo >= len(src) or src[dopo] in _SPAZI + "\n)"
            nuovo = ("" if prima_spazio else " ") + parola + ("" if dopo_spazio else " ")
            return [Correzione(riga, colonna, simbolo, nuovo, f"in Leo si scrive `{parola}`")]
        chiusura = {"'": "'", "“": "”", "”": "”", "«": "»"}.get(simbolo)
        if chiusura is None:
            return []
        fine_riga = src.find("\n", dopo)
        if fine_riga < 0:
            fine_riga = len(src)
        j = src.find(chiusura, dopo, fine_riga)
        if j < 0 or '"' in src[dopo:j] or "\\" in src[dopo:j]:
            return []
        riga_j, colonna_j = self.lx._posizione(j)
        motivo = "i testi si scrivono tra virgolette doppie `\"`"
        # un'unica correzione che sostituisce il testo intero (le due virgolette insieme)
        return [Correzione(riga, colonna, src[i:j + 1], '"' + src[dopo:j] + '"', motivo)]

    # --- fine della scansione ---------------------------------------------------------------
    def _chiudi(self) -> None:
        fine = self.fine
        if self.pila:
            if self.lx.tollerante:
                for aperta, offset in self.pila:
                    riga = self.lx._posizione(offset)[0]
                    self._errore(f"La parentesi `{aperta}` aperta alla riga {riga} non è mai chiusa.", offset, 1)
                self.pila.clear()
            else:
                aperta, offset = self.pila[-1]
                riga, _ = self.lx._posizione(offset)
                chiusure = []
                for a, o in reversed(self.pila):
                    if self.lx._posizione(o)[0] != riga:
                        break
                    chiusure.append(_APERTE[a])
                if self.parte:
                    colonna_inserimento = self.lx._posizione(fine)[1]
                else:
                    colonna_inserimento = self.fine_codice.get(riga, self.lx._posizione(offset)[1] + 1)
                testo_chiusure = "".join(chiusure)
                self._errore(f"La parentesi `{aperta}` aperta alla riga {riga} non è mai chiusa.", offset, 1,
                             suggerimento=f"Aggiungi `{testo_chiusure}` dove finisce l'espressione.",
                             correzioni=[Correzione(riga, colonna_inserimento, "", testo_chiusure,
                                                    f"chiudi la `{aperta}` aperta alla riga {riga}")])
        riga, colonna = self.lx._posizione(fine)
        if not self.parte and self.ultimo_significativo not in (None, T.FINE_RIGA):
            self._aggiungi(Token(T.FINE_RIGA, "\n", riga, colonna, None, 0, "sintetico"), fine, fine)
        self._aggiungi(Token(T.FINE_FILE, None, riga, colonna, None, 0, "sintetico"), fine, fine)
