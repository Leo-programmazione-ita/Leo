"""Controllo prima di eseguire: un lavoro ``in parallelo`` non cambia le variabili del programma.

Un lavoro riceve una copia delle variabili che usa (vedi :mod:`leo.parallelo`):
se le cambiasse, la modifica resterebbe nella copia e il programma non la
vedrebbe mai. Leo lo dice subito, prima di eseguire, quando si vede dal testo:

* ``x = ...``, ``x += ...``, ``x[i] = ...`` dentro il lavoro, con ``x``
  dichiarata fuori dal lavoro (prima del blocco ``in parallelo``);
* ``x.aggiungi(...)`` e gli altri metodi che cambiano una lista o un dizionario
  (``inserisci``, ``rimuovi``, ``estrai``, ``ordina``, ``inverti``) su una
  variabile di fuori;
* la chiamata, dal lavoro, di una funzione del programma che fa una di queste
  cose su una variabile globale (anche passando per altre funzioni).

Quello che il testo non mostra (una funzione passata come valore, due nomi per
la stessa lista) lo ferma l'interprete appena succede, con lo stesso messaggio;
le modifiche a una lista ricevuta come parametro restano nella copia del lavoro.

:func:`controlla_lavori` e' chiamata da :func:`leo.esecuzione.analizza`.
"""

from __future__ import annotations

from typing import Any

from . import nodi as N
from .errori import ErroreSintassi

__all__ = ["controlla_lavori", "METODI_CHE_CAMBIANO"]

#: Metodi che cambiano la lista o il dizionario su cui si chiamano.
METODI_CHE_CAMBIANO = frozenset({"aggiungi", "inserisci", "rimuovi", "estrai", "ordina", "inverti"})

_CONSIGLIO = ("Il lavoro lavora su una copia delle variabili del programma: usa una variabile sua "
              "(`variabile {nome}_lavoro = {nome}`), poi restituisci il risultato con `restituisci` e "
              "prendilo con `aspetta(lavoro)`, oppure mandalo con un canale (`canale()`).")


class _Violazione(Exception):
    def __init__(self, errore: ErroreSintassi) -> None:
        super().__init__(errore.messaggio)
        self.errore = errore


class _Ambito:
    __slots__ = ("nomi",)

    def __init__(self) -> None:
        self.nomi: dict[str, Any] = {}


def _e_blocco(valore: Any) -> bool:
    return isinstance(valore, list) and any(isinstance(x, N.Istruzione) for x in valore)


class _Controllore:
    def __init__(self, programma: N.Programma) -> None:
        self.nome_file = getattr(programma, "nome_file", "<sorgente>")
        self.globali: set[str] = set()
        self.funzioni: dict[str, N.DefinizioneFunzione] = {}
        for istruzione in programma.istruzioni:
            if isinstance(istruzione, N.DefinizioneFunzione):
                self.funzioni[istruzione.nome] = istruzione
                self.globali.add(istruzione.nome)
            elif isinstance(istruzione, N.DichiarazioneMultipla):
                self.globali.update(istruzione.nomi or [istruzione.nome])
            elif isinstance(istruzione, N.Dichiarazione):
                self.globali.add(istruzione.nome)
        self.pila: list[_Ambito] = []
        self.lavori: list[int] = []          # profondita' della pila dove comincia ogni lavoro aperto
        self._effetti: dict[int, list[tuple[str, N.Nodo, str]]] = {}
        self._in_calcolo: set[int] = set()

    # --- nomi ---
    def dichiara(self, nome: str | None, definizione: Any = True) -> None:
        if nome:
            self.pila[-1].nomi[nome] = definizione

    def livello(self, nome: str) -> int:
        for i in range(len(self.pila) - 1, -1, -1):
            if nome in self.pila[i].nomi:
                return i
        return -1

    def di_fuori(self, nome: str) -> bool:
        """Vero se ``nome`` e' una variabile dichiarata fuori dal lavoro piu' interno aperto."""
        if not self.lavori:
            return False
        i = self.livello(nome)
        return 0 <= i < self.lavori[-1]

    # --- errori ---
    def errore(self, messaggio: str, nodo: Any, suggerimento: str) -> None:
        e = ErroreSintassi(messaggio, getattr(nodo, "riga", 0), getattr(nodo, "colonna", 0), suggerimento,
                           nome_file=self.nome_file)
        raise _Violazione(e)

    def cambia(self, nome: str, nodo: Any, come: str) -> None:
        if self.di_fuori(nome):
            self.errore(f"Un lavoro `in parallelo` non può {come} `{nome}`: è una variabile del programma.",
                        nodo, _CONSIGLIO.format(nome=nome))

    # --- visita ---
    def blocco(self, istruzioni: list) -> None:
        self.pila.append(_Ambito())
        try:
            for istruzione in istruzioni:
                self.visita(istruzione)
        finally:
            self.pila.pop()

    def visita(self, x: Any) -> None:
        if isinstance(x, list):
            if _e_blocco(x):
                self.blocco(x)
            else:
                for elemento in x:
                    self.visita(elemento)
            return
        if not isinstance(x, N.Nodo):
            return
        metodo = getattr(self, "v_" + type(x).__name__, None)
        if metodo is not None:
            metodo(x)
            return
        self.generico(x)

    def generico(self, nodo: N.Nodo) -> None:
        for valore in vars(nodo).values():
            if isinstance(valore, (N.Nodo, list)):
                self.visita(valore)

    # dichiarazioni
    def v_Dichiarazione(self, nodo: N.Dichiarazione) -> None:
        self.visita(nodo.valore)
        self.dichiara(nodo.nome)

    def v_DichiarazioneMultipla(self, nodo: N.DichiarazioneMultipla) -> None:
        self.visita(nodo.valore)
        for nome in nodo.nomi or [nodo.nome]:
            self.dichiara(nome)

    def v_Importa(self, nodo: N.Importa) -> None:
        if nodo.alias:
            self.dichiara(nodo.alias)

    def _funzione(self, parametri: list, corpo: list) -> None:
        for p in parametri or ():
            if getattr(p, "predefinito", None) is not None:
                self.visita(p.predefinito)
        self.pila.append(_Ambito())
        try:
            for p in parametri or ():
                self.dichiara(p.nome)
            for istruzione in corpo:
                self.visita(istruzione)
        finally:
            self.pila.pop()

    def v_DefinizioneFunzione(self, nodo: N.DefinizioneFunzione) -> None:
        self.dichiara(nodo.nome, nodo)
        self._funzione(nodo.parametri, nodo.corpo)

    def v_FunzioneAnonima(self, nodo: N.FunzioneAnonima) -> None:
        self._funzione(nodo.parametri, nodo.corpo)

    def v_PerOgni(self, nodo: N.PerOgni) -> None:
        self.visita(nodo.iterabile)
        self.pila.append(_Ambito())
        try:
            for nome in nodo.variabili or [nodo.variabile]:
                self.dichiara(nome)
            for istruzione in nodo.corpo:
                self.visita(istruzione)
        finally:
            self.pila.pop()

    def v_ListaCompresa(self, nodo: N.ListaCompresa) -> None:
        self.visita(nodo.iterabile)
        self.pila.append(_Ambito())
        try:
            for nome in nodo.variabili:
                self.dichiara(nome)
            self.visita(nodo.elemento)
            if nodo.condizione is not None:
                self.visita(nodo.condizione)
        finally:
            self.pila.pop()

    def v_Prova(self, nodo: N.Prova) -> None:
        self.blocco(nodo.corpo)
        for cattura in nodo.catture:
            self.pila.append(_Ambito())
            try:
                self.dichiara(cattura.nome_variabile)
                for istruzione in cattura.corpo:
                    self.visita(istruzione)
            finally:
                self.pila.pop()
        if nodo.infine:
            self.blocco(nodo.infine)

    # cambiamenti
    def _bersaglio(self, bersaglio: Any, nodo: Any, operatore: str = "=") -> None:
        if isinstance(bersaglio, N.Nome):
            self.cambia(bersaglio.nome, bersaglio, "cambiare")
        elif isinstance(bersaglio, N.Indice):
            base = bersaglio.oggetto
            while isinstance(base, N.Indice):
                self.visita(base.indice)
                base = base.oggetto
            if isinstance(base, N.Nome):
                self.cambia(base.nome, base, "cambiare gli elementi di")
            else:
                self.visita(base)
            self.visita(bersaglio.indice)
        else:
            self.visita(bersaglio)

    def v_Assegnazione(self, nodo: N.Assegnazione) -> None:
        self.visita(nodo.valore)
        self._bersaglio(nodo.bersaglio, nodo, nodo.operatore)

    def v_AssegnazioneMultipla(self, nodo: N.AssegnazioneMultipla) -> None:
        self.visita(nodo.valore)
        for bersaglio in nodo.bersagli:
            self._bersaglio(bersaglio, nodo)

    def v_Chiamata(self, nodo: N.Chiamata) -> None:
        funzione = nodo.funzione
        if isinstance(funzione, N.Attributo) and funzione.nome in METODI_CHE_CAMBIANO \
                and isinstance(funzione.oggetto, N.Nome):
            self.cambia(funzione.oggetto.nome, funzione.oggetto, f"usare `{funzione.nome}` su")
        if self.lavori and isinstance(funzione, N.Nome):
            self._chiamata_dal_lavoro(funzione.nome, funzione)
        self.generico(nodo)

    def _chiamata_dal_lavoro(self, nome: str, nodo: Any) -> None:
        i = self.livello(nome)
        if i != 0 or nome not in self.funzioni or i >= self.lavori[-1]:
            return                                 # non e' una funzione globale del programma
        definizione = self.funzioni[nome]
        effetti = self.effetti(definizione)
        if effetti:
            cambiata, dove, come = effetti[0]
            self.errore(
                f"Un lavoro `in parallelo` non può chiamare `{nome}`: {come} `{cambiata}` (riga "
                f"{getattr(dove, 'riga', 0)}), una variabile del programma.",
                nodo, "Il lavoro lavora su una copia delle variabili del programma, quindi quel cambiamento "
                      "andrebbe perso. Fai calcolare alla funzione un risultato e restituiscilo (`restituisci`), "
                      "poi aggiorna la variabile nel programma principale dopo `aspetta(lavoro)`, oppure manda "
                      "i dati con un canale (`canale()`).")

    def v_Parallelo(self, nodo: N.Parallelo) -> None:
        self.lavori.append(len(self.pila))
        try:
            self.blocco(nodo.corpo)
        finally:
            self.lavori.pop()

    # --- effetti delle funzioni globali (per le chiamate da un lavoro) ---
    def effetti(self, definizione: N.DefinizioneFunzione) -> list[tuple[str, Any, str]]:
        """Le variabili globali che la funzione cambia: (nome, nodo, "cambia"/"usa `aggiungi` su")."""
        chiave = id(definizione)
        if chiave in self._effetti:
            return self._effetti[chiave]
        if chiave in self._in_calcolo:
            return []
        self._in_calcolo.add(chiave)
        try:
            raccolta = _Effetti(self)
            raccolta.funzione(definizione)
            self._effetti[chiave] = raccolta.trovati
        finally:
            self._in_calcolo.discard(chiave)
        return self._effetti[chiave]


class _Effetti(_Controllore):
    """Raccoglie le variabili globali cambiate da una funzione (anche tramite le funzioni che chiama)."""

    def __init__(self, padre: _Controllore) -> None:  # noqa: D107 - condivide tabelle e cache del padre
        self.padre = padre
        self.nome_file = padre.nome_file
        self.globali = padre.globali
        self.funzioni = padre.funzioni
        self._effetti = padre._effetti
        self._in_calcolo = padre._in_calcolo
        self.pila = []
        self.lavori = []
        self.trovati: list[tuple[str, Any, str]] = []

    def funzione(self, definizione: N.DefinizioneFunzione) -> None:
        globale = _Ambito()
        globale.nomi = {n: True for n in self.globali}
        self.pila = [globale]
        self.lavori = [1]                     # tutto cio' che e' globale e' "di fuori"
        self._funzione(definizione.parametri, definizione.corpo)

    def cambia(self, nome: str, nodo: Any, come: str) -> None:
        if self.livello(nome) == 0:
            parole = {"cambiare": "cambia", "cambiare gli elementi di": "cambia gli elementi di"}
            self.trovati.append((nome, nodo, parole.get(come, come.replace("usare", "usa"))))

    def errore(self, messaggio: str, nodo: Any, suggerimento: str) -> None:  # pragma: no cover
        return None

    def _chiamata_dal_lavoro(self, nome: str, nodo: Any) -> None:
        if self.livello(nome) != 0 or nome not in self.funzioni:
            return
        for nome_cambiato, dove, come in self.padre.effetti(self.funzioni[nome]):
            self.trovati.append((nome_cambiato, dove, come))

    # le funzioni annidate e i lavori dentro la funzione non contano (si controllano a parte)
    def v_DefinizioneFunzione(self, nodo: N.DefinizioneFunzione) -> None:
        self.dichiara(nodo.nome, nodo)

    def v_FunzioneAnonima(self, nodo: N.FunzioneAnonima) -> None:
        return None

    def v_Parallelo(self, nodo: N.Parallelo) -> None:
        return None


def controlla_lavori(programma: Any) -> None:
    """Solleva :class:`ErroreSintassi` se un lavoro ``in parallelo`` cambia una variabile del programma."""
    if not _ha_lavori(programma):
        return
    c = _Controllore(programma)
    c.pila.append(_Ambito())
    for nome, definizione in c.funzioni.items():
        c.dichiara(nome, definizione)
    try:
        for istruzione in programma.istruzioni:
            c.visita(istruzione)
    except _Violazione as v:
        raise v.errore from None


def _ha_lavori(nodo: Any) -> bool:
    pila = [nodo]
    while pila:
        x = pila.pop()
        if isinstance(x, N.Parallelo):
            return True
        if isinstance(x, N.Nodo):
            for valore in vars(x).values():
                if isinstance(valore, (N.Nodo, list)):
                    pila.append(valore)
        elif isinstance(x, list):
            pila.extend(v for v in x if isinstance(v, (N.Nodo, list)))
    return False
