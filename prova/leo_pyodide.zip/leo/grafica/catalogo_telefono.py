"""Catalogo dei controlli della scheda "Telefono": l'hardware del telefono con parole semplici.

Sette controlli pensati per le app Leo sul telefono (vedi ``android/CONTRATTO.md``, sezione
"Hardware del telefono"):

* visibili: ``Bussola`` (una bussola disegnata che gira con il telefono) e ``Livella`` (una bolla
  che si muove quando inclini il telefono);
* invisibili: ``Vibrazione``, ``Torcia``, ``Posizione`` (GPS), ``Batteria``, ``Condivisione``.

Come per gli altri controlli, i metodi chiedono il lavoro all'interfaccia con
``azioni.richiedi_interfaccia``: sul telefono risponde il motore delle finestre
(``leo.grafica.web.hardware``), sul computer i widget di ``leo.grafica.qt.widget_telefono``
(segnaposto o simulazioni). Senza interfaccia il metodo spiega che qui non e' disponibile.

API: ``tipi()`` (oggetti NUOVI a ogni chiamata), ``DATI_EVENTI``, ``SCHEDA``.
"""

from __future__ import annotations

import math
from typing import Any

from ..errori import ErroreValore
from .catalogo_dante import (_interfaccia, _intero, _lista, _non_disponibile, _numero, _p, _sl, _t, _testo,
                             _valore)
from .metadati import TipoControllo, registra

__all__ = ["tipi", "DATI_EVENTI", "SCHEDA", "TIPI_TELEFONO", "distanza_metri", "punto_cardinale"]

#: Nome della scheda nella casella dei controlli.
SCHEDA = "Telefono"

#: Raggio medio della Terra, in metri (per ``Posizione.distanza_da``).
_RAGGIO_TERRA = 6_371_000.0


# ===========================================================================
# Calcoli puri (usati anche dal motore web e dai widget Qt)
# ===========================================================================

def distanza_metri(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Distanza "in linea d'aria" tra due punti della Terra, in metri (formula dell'emisenoverso)."""
    f1, f2 = math.radians(lat1), math.radians(lat2)
    df, dl = math.radians(lat2 - lat1), math.radians(lon2 - lon1)
    a = math.sin(df / 2) ** 2 + math.cos(f1) * math.cos(f2) * math.sin(dl / 2) ** 2
    return 2 * _RAGGIO_TERRA * math.asin(min(1.0, math.sqrt(a)))


_PUNTI = ("N", "NE", "E", "SE", "S", "SO", "O", "NO")


def punto_cardinale(gradi: float) -> str:
    """0 -> "N", 90 -> "E", 180 -> "S", 270 -> "O" (e le vie di mezzo: "NE", "SE", "SO", "NO")."""
    return _PUNTI[int(((float(gradi) % 360) + 22.5) // 45) % 8]


# ===========================================================================
# Metodi
# ===========================================================================

def _chiedi(c: Any, azione: str, cosa: str, *argomenti: Any) -> Any:
    """Esegue ``azione`` con l'interfaccia (telefono o computer); senza interfaccia: non disponibile."""
    gestita, risultato = _interfaccia(c, azione, *argomenti)
    if gestita:
        return risultato
    raise _non_disponibile(cosa)


def _vibra(c, millisecondi=300):
    """Fa vibrare il telefono per i millisecondi indicati (300 se non dici niente)."""
    ms = _intero(millisecondi, "La durata della vibrazione")
    if not 1 <= ms <= 10_000:
        raise ErroreValore("La vibrazione dura da 1 a 10000 millisecondi.",
                           suggerimento="Per esempio `Vibrazione1.vibra(500)` vibra per mezzo secondo.")
    return _chiedi(c, "vibra", "La vibrazione", ms)


def _vibra_schema(c, schema):
    """Vibra a ritmo: una lista di millisecondi [pausa, vibra, pausa, vibra, ...]."""
    lista = _lista(schema, "Lo schema della vibrazione")
    if not lista or len(lista) > 40:
        raise ErroreValore("Lo schema della vibrazione è una lista da 1 a 40 numeri.",
                           suggerimento="Per esempio `Vibrazione1.schema([0, 200, 100, 200])`: "
                                        "vibra, si ferma, vibra di nuovo.")
    numeri = []
    for x in lista:
        n = _intero(x, "Ogni numero dello schema")
        if not 0 <= n <= 10_000:
            raise ErroreValore("I numeri dello schema vanno da 0 a 10000 millisecondi.")
        numeri.append(n)
    return _chiedi(c, "schema", "La vibrazione", numeri)


def _torcia_accendi(c):
    """Accende la luce del flash; restituisce vero se si è accesa."""
    return _chiedi(c, "accendi", "La torcia")


def _torcia_spegni(c):
    """Spegne la luce del flash."""
    return _chiedi(c, "spegni", "La torcia")


def _torcia_commuta(c):
    """Accende la torcia se è spenta, la spegne se è accesa."""
    return _torcia_spegni(c) if _valore(c, "accesa", False) else _torcia_accendi(c)


def _posizione_avvia(c):
    """Comincia a chiedere la posizione al GPS (evento `cambio` a ogni aggiornamento)."""
    return _chiedi(c, "avvia", "La posizione (GPS)")


def _posizione_ferma(c):
    """Smette di seguire la posizione (il GPS consuma batteria)."""
    return _chiedi(c, "ferma", "La posizione (GPS)")


def _posizione_distanza_da(c, latitudine, longitudine):
    """Metri tra l'ultima posizione letta e il punto (latitudine, longitudine)."""
    lat = float(_numero(latitudine, "La latitudine"))
    lon = float(_numero(longitudine, "La longitudine"))
    if not (-90 <= lat <= 90 and -180 <= lon <= 180):
        raise ErroreValore("La latitudine va da -90 a 90 e la longitudine da -180 a 180.")
    if _valore(c, "precisione", -1.0) < 0:
        raise ErroreValore(f"`{c.nome}` non conosce ancora la posizione.",
                           suggerimento=f"Chiama `{c.nome}.avvia()` e aspetta l'evento `cambio`.")
    return round(distanza_metri(float(_valore(c, "latitudine", 0.0)), float(_valore(c, "longitudine", 0.0)),
                                lat, lon), 1)


def _batteria_aggiorna(c):
    """Legge subito la batteria e restituisce il livello (da 0 a 100)."""
    return _chiedi(c, "aggiorna", "La batteria")


def _condividi(c, testo=None):
    """Apre la finestra del telefono per mandare il testo (WhatsApp, posta, messaggi...)."""
    if testo is None:
        testo = str(_valore(c, "testo", ""))
    else:
        testo = _testo(testo, "Il testo da condividere")
    if not testo.strip():
        raise ErroreValore("Non c'è niente da condividere: il testo è vuoto.",
                           suggerimento=f"Scrivi per esempio `{c.nome}.condividi(\"Ciao!\")`.")
    return _chiedi(c, "condividi", "La condivisione", testo)


# ===========================================================================
# Tipi
# ===========================================================================

#: Dati degli eventi (chiavi del dizionario `evento` nel gestore) per ogni tipo.
DATI_EVENTI: dict[str, dict[str, tuple[str, ...]]] = {
    "Bussola": {"cambio": ("direzione", "punto_cardinale")},
    "Livella": {"cambio": ("inclinazione_x", "inclinazione_y", "in_piano")},
    "Vibrazione": {},
    "Torcia": {},
    "Posizione": {"cambio": ("latitudine", "longitudine", "precisione", "altitudine", "velocita"),
                  "errore": ("messaggio",)},
    "Batteria": {"cambio": ("livello", "in_carica")},
    "Condivisione": {},
}


def tipi() -> list[TipoControllo]:
    """I controlli della scheda "Telefono", come oggetti NUOVI a ogni chiamata."""
    s = SCHEDA
    return [
        _t("Bussola", s, "Bussola che gira con il telefono: indica dove è il nord", 1, [
            _sl("direzione", "decimale", 0.0, "Dove punta la cima del telefono, in gradi (0 = nord, 90 = est)"),
            _sl("punto_cardinale", "testo", "N", "Direzione a parole: N, NE, E, SE, S, SO, O, NO"),
            _p("colore", "colore", "#E0182D", "Colore della punta nord dell'ago", "Aspetto"),
            _p("intervallo", "intero", 100, "Millisecondi tra una lettura e l'altra", "Comportamento",
               minimo=20, massimo=5000),
        ], ("cambio",), "cambio", icona="bussola", dimensione=(160, 160)),
        _t("Livella", s, "Livella a bolla: la bolla si sposta quando inclini il telefono", 1, [
            _sl("inclinazione_x", "decimale", 0.0, "Gradi di inclinazione: positivi se il lato destro è più alto"),
            _sl("inclinazione_y", "decimale", 0.0, "Gradi di inclinazione: positivi se la cima del telefono è più alta"),
            _sl("in_piano", "logico", True, "Vero quando il telefono è in piano"),
            _p("tolleranza", "decimale", 2.0, "Entro quanti gradi il telefono è \"in piano\"", "Comportamento",
               minimo=0.1, massimo=45),
            _p("intervallo", "intero", 100, "Millisecondi tra una lettura e l'altra", "Comportamento",
               minimo=20, massimo=5000),
        ], ("cambio",), "cambio", icona="livella", dimensione=(200, 200)),
        _t("Vibrazione", s, "Invisibile: fa vibrare il telefono", 1, [
        ], (), None, icona="vibrazione", invisibile=True,
           metodi={"vibra": _vibra, "schema": _vibra_schema}),
        _t("Torcia", s, "Invisibile: accende e spegne la luce del flash", 1, [
            _sl("accesa", "logico", False, "Vero quando la torcia è accesa"),
        ], (), None, icona="torcia", invisibile=True,
           metodi={"accendi": _torcia_accendi, "spegni": _torcia_spegni, "commuta": _torcia_commuta}),
        _t("Posizione", s, "Invisibile: dove ti trovi, con il GPS del telefono", 1, [
            _p("precisa", "logico", True, "Usa il GPS (più preciso, consuma più batteria)", "Comportamento"),
            _p("continua", "logico", True, "Continua ad aggiornare mentre ti muovi", "Comportamento"),
            _sl("attiva", "logico", False, "Vero mentre segue la posizione"),
            _sl("latitudine", "decimale", 0.0, "Latitudine in gradi (nord positivo)"),
            _sl("longitudine", "decimale", 0.0, "Longitudine in gradi (est positivo)"),
            _sl("precisione", "decimale", -1.0, "Errore possibile in metri (-1 = posizione non ancora letta)"),
            _sl("altitudine", "decimale", 0.0, "Altezza sul livello del mare, in metri"),
            _sl("velocita", "decimale", 0.0, "Velocità in km/h"),
        ], ("cambio", "errore"), "cambio", icona="posizione", invisibile=True,
           metodi={"avvia": _posizione_avvia, "ferma": _posizione_ferma, "distanza_da": _posizione_distanza_da}),
        _t("Batteria", s, "Invisibile: quanta carica ha il telefono e se è in carica", 1, [
            _sl("livello", "intero", -1, "Carica da 0 a 100 (-1 = non ancora letta)"),
            _sl("in_carica", "logico", False, "Vero se il telefono è attaccato al caricatore"),
        ], ("cambio",), "cambio", icona="batteria", invisibile=True,
           metodi={"aggiorna": _batteria_aggiorna}),
        _t("Condivisione", s, "Invisibile: manda un testo con WhatsApp, posta, messaggi...", 1, [
            _p("testo", "testo", "", "Testo da mandare se `condividi()` non ne riceve uno"),
        ], (), None, icona="condividi", invisibile=True,
           metodi={"condividi": _condividi}),
    ]


#: Nomi dei tipi della scheda "Telefono".
TIPI_TELEFONO: tuple[str, ...] = tuple(t.nome for t in tipi())

for _tipo in tipi():
    registra(_tipo)
del _tipo
