"""Lettura e scrittura dei file ``.maschera`` (TOML) - CONTRATTO CONDIVISO.

Formato (versione 1)::

    [maschera]
    versione = 1

    [finestra]
    nome = "Finestra1"
    tipo = "Finestra"
    testo = "La mia prima finestra"
    larghezza = 640
    altezza = 480
    forma = "rettangolo"            # oppure { tipo_forma = "poligono", lati = 6 }

    [[controlli]]
    nome = "Pulsante1"
    tipo = "Pulsante"
    contenitore = ""                # "" = direttamente nella finestra
    sinistra = 120
    alto = 80
    larghezza = 90
    altezza = 28
    testo = "Salva"
    ancoraggio = ["alto", "sinistra"]

Regole: ``nome``, ``tipo``, ``contenitore`` e ``scheda`` sono campi strutturali;
tutte le altre chiavi sono proprieta'. L'ordine di ``[[controlli]]`` e' l'ordine
di disegno. Vengono scritte solo le proprieta' presenti nel modello (Leo
Studio puo' omettere quelle uguali al predefinito). Le forme non nominate
sono tabelle in linea con la chiave ``tipo_forma`` (vedi ``leo.grafica.forme``).

API:
    leggi_maschera(testo: str) -> ModelloMaschera        # ErroreValore se malformata
    scrivi_maschera(m: ModelloMaschera) -> str
    carica_maschera(percorso) -> ModelloMaschera           # ErroreFile / ErroreValore
    salva_maschera(percorso, m: ModelloMaschera) -> None
"""

from __future__ import annotations

import os
from typing import Any

from ..errori import ErroreValore
from ..tomlutil import ErroreToml, carica_toml, leggi_toml, scrivi_toml
from .modello import ModelloControllo, ModelloMaschera

VERSIONE_MASCHERA = 1
_STRUTTURALI = ("nome", "tipo", "contenitore", "scheda")


def _da_toml(v: Any) -> Any:
    if isinstance(v, dict) and "tipo_forma" in v:
        try:
            from .forme import Forma
            return Forma.da_dizionario(v)
        except (ImportError, AttributeError):
            return v
    return v


def _a_toml(v: Any) -> Any:
    """Valore Python -> valore scrivibile in TOML.

    TOML non ha ``nulla``: nelle liste diventa ``""`` (cosi' le posizioni non
    si spostano, es. le celle di una Tabella); nei dizionari la chiave si
    omette (rileggendola manca, cioe' vale ``nulla`` con ``get``).
    """
    a_diz = getattr(v, "a_dizionario", None)
    if callable(a_diz):
        return a_diz()
    if isinstance(v, (list, tuple)):
        return ["" if x is None else _a_toml(x) for x in v]
    if isinstance(v, dict):
        return {str(k): _a_toml(x) for k, x in v.items() if x is not None}
    return v


def _controllo(d: dict, dove: str) -> ModelloControllo:
    if not isinstance(d, dict):
        raise ErroreValore(f"{dove}: mi aspettavo una tabella.")
    nome = d.get("nome")
    tipo = d.get("tipo")
    if not isinstance(nome, str) or not nome:
        raise ErroreValore(f"{dove}: manca `nome`.")
    if not isinstance(tipo, str) or not tipo:
        raise ErroreValore(f"{dove}: al controllo `{nome}` manca `tipo`.")
    prop = {k: _da_toml(v) for k, v in d.items() if k not in _STRUTTURALI}
    scheda = d.get("scheda")
    contenitore = d.get("contenitore", "")
    if not isinstance(contenitore, str):
        raise ErroreValore(f"{dove}: `contenitore` di `{nome}` deve essere un testo (il nome di un controllo).")
    return ModelloControllo(tipo, nome, prop, contenitore,
                            scheda if isinstance(scheda, int) and not isinstance(scheda, bool) else None)


def leggi_maschera(testo: str) -> ModelloMaschera:
    # file salvati o modificati su Windows: a capo CRLF (e un eventuale BOM)
    testo = testo.replace("\r\n", "\n")
    try:
        dati = leggi_toml(testo)
    except ErroreToml as e:
        raise ErroreValore(f"La maschera non è un TOML valido: {e.messaggio}.", e.riga) from None
    return leggi_maschera_da_dizionario(dati)


def leggi_maschera_da_dizionario(dati: dict) -> ModelloMaschera:
    """Come leggi_maschera, ma da un dizionario gia' letto."""
    if not isinstance(dati, dict):
        raise ErroreValore("La maschera deve essere una tabella TOML.")
    intest = dati.get("maschera", {})
    versione = intest.get("versione", VERSIONE_MASCHERA) if isinstance(intest, dict) else VERSIONE_MASCHERA
    if isinstance(versione, float) and versione.is_integer():
        versione = int(versione)
    if not isinstance(versione, int) or isinstance(versione, bool) or versione < 1:
        raise ErroreValore("In `[maschera]` la `versione` deve essere un intero positivo (per esempio 1).")
    if versione > VERSIONE_MASCHERA:
        raise ErroreValore(f"La maschera usa la versione {versione}, ma questo Leo conosce fino alla {VERSIONE_MASCHERA}.")
    if "finestra" not in dati:
        raise ErroreValore("Nella maschera manca la sezione `[finestra]`.")
    finestra = _controllo(dati["finestra"], "[finestra]")
    elenco = dati.get("controlli", [])
    if not isinstance(elenco, list):
        raise ErroreValore("`controlli` deve essere un elenco di tabelle `[[controlli]]`.")
    controlli = [_controllo(c, f"[[controlli]] n. {i + 1}") for i, c in enumerate(elenco)]
    m = ModelloMaschera(finestra, [], versione)
    for c in controlli:
        m.aggiungi(c)  # controlla i nomi doppi
    return m


def _a_dizionario(c: ModelloControllo) -> dict:
    d: dict[str, Any] = {"nome": c.nome, "tipo": c.tipo}
    if c.tipo != "Finestra":
        d["contenitore"] = c.contenitore
        if c.scheda is not None:
            d["scheda"] = c.scheda
    for k, v in c.proprieta.items():
        if k not in _STRUTTURALI:
            d[k] = _a_toml(v)
    return d


def scrivi_maschera(m: ModelloMaschera) -> str:
    dati: dict[str, Any] = {
        "maschera": {"versione": VERSIONE_MASCHERA},
        "finestra": _a_dizionario(m.finestra),
    }
    if m.controlli:
        dati["controlli"] = [_a_dizionario(c) for c in m.controlli]
    # intestazione dei file .maschera: resta com'e' da sempre (i file salvati non cambiano)
    intestazione = "# File generato da Leo Studio: posizione e proprieta' dei controlli.\n"
    return intestazione + scrivi_toml(dati)


def carica_maschera(percorso: str | os.PathLike) -> ModelloMaschera:
    try:
        return leggi_maschera_da_dizionario(carica_toml(percorso))
    except ErroreToml as e:
        raise ErroreValore(f"`{os.fspath(percorso)}` non è un TOML valido: {e.messaggio}.", e.riga) from None


def salva_maschera(percorso: str | os.PathLike, m: ModelloMaschera) -> None:
    # salva_toml non permette l'intestazione di commento: scriviamo in modo atomico a mano
    import tempfile

    from ..errori import ErroreFile

    testo = scrivi_maschera(m)
    cartella = os.path.dirname(os.path.abspath(percorso)) or "."
    try:
        fd, tmp = tempfile.mkstemp(prefix=".tmp_", suffix=".maschera", dir=cartella)
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(testo)
        os.replace(tmp, percorso)
    except OSError as e:
        raise ErroreFile(f"Non riesco a salvare `{os.fspath(percorso)}`: {e.strerror or e}.") from e


__all__ = ["leggi_maschera", "leggi_maschera_da_dizionario", "scrivi_maschera",
           "carica_maschera", "salva_maschera", "VERSIONE_MASCHERA"]
