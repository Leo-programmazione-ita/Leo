"""Catalogo dei controlli della scheda "Tutti i giorni": i pezzi delle app di ogni giorno.

Venti controlli che si vedono in tutte le app moderne, con parole semplici: calendario del mese,
chat a bolle, lista di schede con immagine, selettore dell'ora, firma a mano, gradimento a cinque
livelli, casella del PIN, campo di ricerca con suggerimenti, tag, fisarmonica, barra delle schede in
basso, pulsante fluttuante, avviso a scomparsa, lista delle cose da fare, contatore +/-, carosello di
immagini, orologio con le lancette, meteo, scheda del profilo e indicatore dei passi.

Funzionano allo stesso modo sul computer (``leo.grafica.qt.widget_quotidiani``) e sul telefono
(``assets/web/finestre_quotidiani.js``): i metodi qui sotto cambiano solo le proprieta' (le vedono tutte e
due le interfacce), e quello che fa l'utente (tocchi, scrittura) torna al programma come proprieta'
aggiornate ed eventi. La logica pura e le icone sono in ``leo.grafica.logica_quotidiani``.

API: ``tipi()`` (oggetti NUOVI a ogni chiamata), ``DATI_EVENTI``, ``SCHEDA``, ``TIPI_QUOTIDIANI``.
"""

from __future__ import annotations

import copy
from pathlib import Path
from typing import Any

from ..errori import ErroreValore
from . import logica_quotidiani as L
from .catalogo_dante import _intero, _lista, _p, _percorso, _sl, _t, _testo, _valore
from .metadati import Proprieta, TipoControllo, registra

__all__ = ["tipi", "DATI_EVENTI", "SCHEDA", "TIPI_QUOTIDIANI", "CARTELLA_ESEMPIO"]

#: Nome della scheda nella casella dei controlli.
SCHEDA = "Tutti i giorni"

#: Cartella dell'esempio (sotto ``esempi/controlli``).
CARTELLA_ESEMPIO = "tutti_i_giorni"


# ===========================================================================
# Utilita'
# ===========================================================================

def _imposta(c: Any, proprieta: str, valore: Any) -> None:
    """Cambia una proprieta' e avvisa l'interfaccia (anche quelle di sola lettura)."""
    c.modello.proprieta[proprieta] = valore
    c.avvisa(proprieta, valore)


def _data(valore: Any, cosa: str = "La data") -> str:
    testo = _testo(valore, cosa)
    d = L.leggi_data(testo)
    if d is None:
        raise ErroreValore(f"`{testo}` non è una data valida.",
                           suggerimento="Scrivi la data come \"GG/MM/AAAA\", per esempio \"25/12/2026\".")
    return L.scrivi_data(*d)


def _indice(c: Any, valore: Any, lunghezza: int, cosa: str) -> int:
    i = _intero(valore, cosa)
    if not 0 <= i < lunghezza:
        if lunghezza == 0:
            raise ErroreValore(f"`{c.nome}` è vuoto: non c'è niente in posizione {i}.")
        raise ErroreValore(f"In `{c.nome}` non c'è niente in posizione {i}.",
                           suggerimento=f"Le posizioni vanno da 0 a {lunghezza - 1}.")
    return i


# ===========================================================================
# Metodi
# ===========================================================================

# --- CalendarioMese ------------------------------------------------------------------------------

def _cal_aggiungi_impegno(c, data, testo, colore=""):
    """Segna un impegno nel giorno `data` ("GG/MM/AAAA"), con un colore se vuoi."""
    data = _data(data)
    testo = _testo(testo, "Il testo dell'impegno")
    colore = _testo(colore, "Il colore")
    impegni = copy.deepcopy(_lista(_valore(c, "impegni", []), "Gli impegni"))
    voce = {"data": data, "testo": testo}
    if colore:
        from .colori import normalizza_colore

        voce["colore"] = normalizza_colore(colore)
    impegni.append(voce)
    _imposta(c, "impegni", impegni)


def _cal_togli_impegni(c, data):
    """Toglie tutti gli impegni del giorno `data`; restituisce quanti ne ha tolti."""
    data = _data(data)
    impegni = [x for x in _lista(_valore(c, "impegni", []), "Gli impegni")]
    restano = [x for x in impegni if not (isinstance(x, dict) and L.leggi_data(x.get("data")) == L.leggi_data(data))]
    _imposta(c, "impegni", restano)
    return len(impegni) - len(restano)


def _cal_impegni_del_giorno(c, data):
    """I testi degli impegni del giorno `data` (una lista, vuota se non ce ne sono)."""
    data = _data(data)
    return [x["testo"] for x in L.impegni_calendario(_valore(c, "impegni", [])) if x["data"] == data]


def _cal_sposta(c, passi: int) -> None:
    anno, mese = L.mese_mostrato(_valore(c, "data", ""), _valore(c, "mese", 0), _valore(c, "anno", 0))
    anno, mese = L.sposta_mese(anno, mese, passi)
    _imposta(c, "mese", mese)
    _imposta(c, "anno", anno)


def _cal_mese_successivo(c):
    """Mostra il mese dopo."""
    _cal_sposta(c, 1)


def _cal_mese_precedente(c):
    """Mostra il mese prima."""
    _cal_sposta(c, -1)


def _cal_vai_a_oggi(c):
    """Sceglie il giorno di oggi e mostra il suo mese."""
    oggi = L.oggi_testo()
    a, m, _g = L.leggi_data(oggi)
    _imposta(c, "data", oggi)
    _imposta(c, "mese", m)
    _imposta(c, "anno", a)


# --- Chat ----------------------------------------------------------------------------------------

def _ora_adesso() -> str:
    import datetime

    return datetime.datetime.now().strftime("%H:%M")


def _chat_aggiungi(c, testo, mio: bool, autore: str) -> None:
    messaggi = copy.deepcopy(_lista(_valore(c, "messaggi", []), "I messaggi"))
    voce = {"testo": testo, "mio": mio, "ora": _ora_adesso()}
    if autore:
        voce["autore"] = autore
    messaggi.append(voce)
    _imposta(c, "messaggi", messaggi)


def _chat_ricevi(c, testo, autore=""):
    """Aggiunge un messaggio di qualcun altro (bolla a sinistra)."""
    _chat_aggiungi(c, _testo(testo, "Il messaggio"), False, _testo(autore, "L'autore"))


def _chat_invia(c, testo):
    """Aggiunge un tuo messaggio (bolla a destra), come se l'avessi scritto tu."""
    _chat_aggiungi(c, _testo(testo, "Il messaggio"), True, "")


def _chat_svuota(c):
    """Cancella tutti i messaggi."""
    _imposta(c, "messaggi", [])


# --- ListaSchede ---------------------------------------------------------------------------------

def _schede_aggiungi(c, titolo, sottotitolo="", immagine=""):
    """Aggiunge una scheda in fondo, con titolo, sottotitolo e immagine."""
    elementi = copy.deepcopy(_lista(_valore(c, "elementi", []), "Gli elementi"))
    voce = {"titolo": _testo(titolo, "Il titolo"), "sottotitolo": _testo(sottotitolo, "Il sottotitolo")}
    immagine = _testo(immagine, "L'immagine")
    if immagine:
        voce["immagine"] = immagine
    elementi.append(voce)
    _imposta(c, "elementi", elementi)


def _schede_rimuovi(c, indice):
    """Toglie la scheda in posizione `indice` (la prima e' 0)."""
    elementi = copy.deepcopy(_lista(_valore(c, "elementi", []), "Gli elementi"))
    i = _indice(c, indice, len(elementi), "La posizione")
    elementi.pop(i)
    _imposta(c, "elementi", elementi)
    scelto = _valore(c, "indice_selezionato", -1)
    if isinstance(scelto, int) and scelto >= len(elementi):
        _imposta(c, "indice_selezionato", -1)


def _svuota_elementi(c):
    """Toglie tutto."""
    _imposta(c, "elementi", [])
    if "indice_selezionato" in c.tipo.proprieta:
        _imposta(c, "indice_selezionato", -1)


# --- FirmaAMano ----------------------------------------------------------------------------------

def _firma_pulisci(c):
    """Cancella la firma."""
    _imposta(c, "tratti", [])
    _imposta(c, "firmato", False)


def _firma_salva(c, percorso):
    """Salva la firma come immagine PNG (fondo trasparente); restituisce il percorso."""
    percorso = _percorso(percorso, c)
    if not percorso.lower().endswith(".png"):
        raise ErroreValore("La firma si salva come immagine PNG.",
                           suggerimento=f"Scrivi per esempio `{c.nome}.salva(\"firma.png\")`.")
    tratti = _valore(c, "tratti", [])
    if not any(L.punti_tratto(t) for t in (tratti if isinstance(tratti, list) else [])):
        raise ErroreValore(f"`{c.nome}` è ancora vuota: non c'è nessuna firma da salvare.")
    larghezza = int(_valore(c, "larghezza", 320) or 320)
    altezza = int(_valore(c, "altezza", 160) or 160)
    colore = str(_valore(c, "colore_penna", "") or "#111111")
    spessore = float(_valore(c, "spessore_penna", 3) or 3)
    dati = L.png_da_tratti(tratti, larghezza, altezza, colore, spessore)
    p = Path(percorso)
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(dati)
    except OSError as e:
        raise ErroreValore(f"Non riesco a salvare la firma in `{percorso}`: {e.strerror or e}.") from None
    return str(p)


# --- CasellaPIN, CampoRicerca --------------------------------------------------------------------

def _pin_pulisci(c):
    """Cancella le cifre scritte."""
    _imposta(c, "valore", "")
    _imposta(c, "completo", False)


def _ricerca_pulisci(c):
    """Svuota la casella di ricerca."""
    _imposta(c, "testo", "")


# --- Tag -----------------------------------------------------------------------------------------

def _tag_aggiungi(c, testo):
    """Aggiunge un tag (se non c'e' gia')."""
    testo = _testo(testo, "Il tag").strip()
    if not testo:
        raise ErroreValore("Un tag vuoto non si può aggiungere.")
    elementi = L.testi(_valore(c, "elementi", []))
    if testo not in elementi:
        _imposta(c, "elementi", elementi + [testo])


def _tag_rimuovi(c, testo):
    """Toglie un tag (e lo toglie anche dai selezionati)."""
    testo = _testo(testo, "Il tag")
    elementi = L.testi(_valore(c, "elementi", []))
    if testo not in elementi:
        raise ErroreValore(f"In `{c.nome}` non c'è il tag `{testo}`.")
    _imposta(c, "elementi", [x for x in elementi if x != testo])
    selezionati = L.testi(_valore(c, "selezionati", []))
    if testo in selezionati:
        _imposta(c, "selezionati", [x for x in selezionati if x != testo])


def _tag_svuota(c):
    """Toglie tutti i tag."""
    _imposta(c, "elementi", [])
    _imposta(c, "selezionati", [])


# --- Fisarmonica ---------------------------------------------------------------------------------

def _fis_apri(c, indice):
    """Apre la sezione in posizione `indice` (la prima e' 0) e chiude le altre."""
    sezioni = L.sezioni_fisarmonica(_valore(c, "sezioni", []))
    _imposta(c, "aperta", _indice(c, indice, len(sezioni), "La sezione"))


def _fis_chiudi(c):
    """Chiude tutte le sezioni."""
    _imposta(c, "aperta", -1)


# --- Avviso --------------------------------------------------------------------------------------

def _avviso_mostra(c, testo=None, livello=None):
    """Fa comparire l'avviso (con un testo nuovo, se lo scrivi) per `durata` millisecondi."""
    if testo is not None:
        _imposta(c, "testo", _testo(testo, "Il testo dell'avviso"))
    if livello is not None:
        meta = c.tipo.proprieta["livello"]
        _imposta(c, "livello", meta.converti(_testo(livello, "Il livello")))
    _imposta(c, "volte", int(_valore(c, "volte", 0) or 0) + 1)
    _imposta(c, "mostrato", True)


def _avviso_nascondi(c):
    """Fa sparire l'avviso subito."""
    _imposta(c, "mostrato", False)


# --- ListaCoseDaFare -----------------------------------------------------------------------------

def _conta_fatti(c, elementi: list) -> None:
    voci = L.cose_da_fare(elementi)
    fatti = sum(1 for x in voci if x["fatto"])
    _imposta(c, "fatti", fatti)
    _imposta(c, "da_fare", len(voci) - fatti)


def _todo_imposta(c, elementi: list) -> None:
    _imposta(c, "elementi", elementi)
    _conta_fatti(c, elementi)


def _todo_aggiungi(c, testo):
    """Aggiunge una cosa da fare in fondo alla lista."""
    testo = _testo(testo, "La cosa da fare").strip()
    if not testo:
        raise ErroreValore("Una cosa da fare vuota non si può aggiungere.")
    _todo_imposta(c, L.cose_da_fare(_valore(c, "elementi", [])) + [{"testo": testo, "fatto": False}])


def _todo_rimuovi(c, quale):
    """Toglie una cosa da fare: scrivi il suo testo o la sua posizione (la prima e' 0)."""
    voci = L.cose_da_fare(_valore(c, "elementi", []))
    if isinstance(quale, str):
        trovati = [i for i, x in enumerate(voci) if x["testo"] == quale]
        if not trovati:
            raise ErroreValore(f"In `{c.nome}` non c'è `{quale}`.")
        i = trovati[0]
    else:
        i = _indice(c, quale, len(voci), "La posizione")
    voci.pop(i)
    _todo_imposta(c, voci)


def _todo_spunta(c, quale, fatto=True):
    """Mette (o toglie, con `falso`) la spunta a una cosa da fare: testo o posizione."""
    voci = L.cose_da_fare(_valore(c, "elementi", []))
    if isinstance(quale, str):
        trovati = [i for i, x in enumerate(voci) if x["testo"] == quale]
        if not trovati:
            raise ErroreValore(f"In `{c.nome}` non c'è `{quale}`.")
        i = trovati[0]
    else:
        i = _indice(c, quale, len(voci), "La posizione")
    if not isinstance(fatto, bool):
        raise ErroreValore("Il secondo valore di `spunta` è `vero` (fatto) o `falso` (da fare).")
    voci[i]["fatto"] = fatto
    _todo_imposta(c, voci)


def _todo_togli_fatti(c):
    """Toglie dalla lista tutte le cose gia' fatte; restituisce quante ne ha tolte."""
    voci = L.cose_da_fare(_valore(c, "elementi", []))
    restano = [x for x in voci if not x["fatto"]]
    _todo_imposta(c, restano)
    return len(voci) - len(restano)


def _todo_svuota(c):
    """Toglie tutto dalla lista."""
    _todo_imposta(c, [])


# --- Contatore -----------------------------------------------------------------------------------

def _contatore_metti(c, valore: int) -> int:
    minimo = int(_valore(c, "minimo", 0))
    massimo = int(_valore(c, "massimo", 99))
    valore = max(min(minimo, massimo), min(max(minimo, massimo), valore))
    _imposta(c, "valore", valore)
    return valore


def _contatore_aumenta(c):
    """Aggiunge `passo` (senza superare `massimo`); restituisce il valore nuovo."""
    return _contatore_metti(c, int(_valore(c, "valore", 0)) + int(_valore(c, "passo", 1)))


def _contatore_diminuisci(c):
    """Toglie `passo` (senza scendere sotto `minimo`); restituisce il valore nuovo."""
    return _contatore_metti(c, int(_valore(c, "valore", 0)) - int(_valore(c, "passo", 1)))


def _contatore_azzera(c):
    """Rimette il contatore al minimo (o a 0 se 0 e' tra minimo e massimo)."""
    minimo, massimo = int(_valore(c, "minimo", 0)), int(_valore(c, "massimo", 99))
    return _contatore_metti(c, 0 if min(minimo, massimo) <= 0 <= max(minimo, massimo) else minimo)


# --- Carosello ----------------------------------------------------------------------------------

def _car_metti(c, indice: int) -> int:
    n = len(L.diapositive(_valore(c, "diapositive", [])))
    if n == 0:
        _imposta(c, "indice", 0)
        return 0
    if _valore(c, "ciclico", True):
        indice %= n
    else:
        indice = max(0, min(n - 1, indice))
    _imposta(c, "indice", indice)
    return indice


def _car_avanti(c):
    """Mostra la diapositiva dopo; restituisce la sua posizione."""
    return _car_metti(c, int(_valore(c, "indice", 0) or 0) + 1)


def _car_indietro(c):
    """Mostra la diapositiva prima; restituisce la sua posizione."""
    return _car_metti(c, int(_valore(c, "indice", 0) or 0) - 1)


def _car_vai_a(c, indice):
    """Mostra la diapositiva in posizione `indice` (la prima è 0)."""
    n = len(L.diapositive(_valore(c, "diapositive", [])))
    return _car_metti(c, _indice(c, indice, n, "La posizione"))


def _car_aggiungi(c, immagine, titolo="", testo=""):
    """Aggiunge una diapositiva in fondo: immagine (anche "") con titolo e testo."""
    voci = copy.deepcopy(_lista(_valore(c, "diapositive", []), "Le diapositive"))
    voce = {"immagine": _testo(immagine, "L'immagine"), "titolo": _testo(titolo, "Il titolo"),
            "testo": _testo(testo, "Il testo")}
    voci.append({k: v for k, v in voce.items() if v})
    _imposta(c, "diapositive", voci)


def _car_svuota(c):
    """Toglie tutte le diapositive."""
    _imposta(c, "diapositive", [])
    _imposta(c, "indice", 0)


# --- IndicatorePassi -----------------------------------------------------------------------------

def _passi_vai(c, delta: int) -> int:
    n = len(_lista(_valore(c, "passi", []), "I passi"))
    passo = int(_valore(c, "passo", 1)) + delta
    passo = max(1, min(max(1, n), passo))
    _imposta(c, "passo", passo)
    return passo


def _passi_avanti(c):
    """Va al passo dopo (fermandosi all'ultimo); restituisce il passo nuovo."""
    return _passi_vai(c, 1)


def _passi_indietro(c):
    """Torna al passo prima (fermandosi al primo); restituisce il passo nuovo."""
    return _passi_vai(c, -1)


# ===========================================================================
# Tipi
# ===========================================================================

#: Dati degli eventi (chiavi del dizionario `evento` nel gestore) per ogni tipo.
DATI_EVENTI: dict[str, dict[str, tuple[str, ...]]] = {
    "CalendarioMese": {"selezione": ("data", "impegni"), "cambio_mese": ("mese", "anno")},
    "Chat": {"invio": ("testo",)},
    "ListaSchede": {"selezione": ("indice", "titolo", "elemento")},
    "SelettoreOrario": {"cambio": ("ora", "ore", "minuti")},
    "FirmaAMano": {"firma": ("tratti",)},
    "Gradimento": {"cambio": ("valore", "testo")},
    "CasellaPIN": {"cambio": ("valore",), "completato": ("valore",)},
    "CampoRicerca": {"cambio": ("testo",), "ricerca": ("testo",)},
    "Tag": {"selezione": ("elemento", "selezionati"), "rimozione": ("elemento",)},
    "Fisarmonica": {"apertura": ("indice", "titolo")},
    "BarraSchede": {"cambio": ("indice", "testo")},
    "PulsanteFluttuante": {},
    "Avviso": {"clic_azione": (), "chiusura": ()},
    "ListaCoseDaFare": {"spunta": ("indice", "testo", "fatto"), "aggiunta": ("testo",), "rimozione": ("testo",)},
    "Contatore": {"cambio": ("valore",)},
    "Carosello": {"cambio": ("indice", "titolo")},
    "Orologio": {"sveglia": ("ora",)},
    "Meteo": {},
    "SchedaProfilo": {"clic_pulsante": ("seguito",)},
    "IndicatorePassi": {"cambio": ("passo", "testo")},
}


def _ancorata(*lati: str) -> Proprieta:
    return Proprieta("ancoraggio", "ancoraggio", list(lati), "Posizione",
                     "Bordi della finestra a cui il controllo resta agganciato")


def _tipi_senza_registrare() -> list[TipoControllo]:
    s = SCHEDA
    scelte_icone = L.NOMI_ICONE
    return [
        _t("CalendarioMese", s, "Calendario del mese con gli impegni colorati: tocchi un giorno per sceglierlo", 1, [
            _p("data", "testo", "", "Giorno scelto, \"GG/MM/AAAA\" (vuoto = oggi)"),
            _p("mese", "intero", 0, "Mese mostrato, da 1 a 12 (0 = il mese del giorno scelto)", minimo=0, massimo=12),
            _p("anno", "intero", 0, "Anno mostrato (0 = l'anno del giorno scelto)", minimo=0, massimo=9999),
            _p("impegni", "lista", [], "Impegni da segnare: dizionari con \"data\", \"testo\" e \"colore\""),
        ], ("selezione", "cambio_mese"), "selezione", icona="calendario_mese", dimensione=(320, 300),
           metodi={"aggiungi_impegno": _cal_aggiungi_impegno, "togli_impegni": _cal_togli_impegni,
                   "impegni_del_giorno": _cal_impegni_del_giorno, "mese_successivo": _cal_mese_successivo,
                   "mese_precedente": _cal_mese_precedente, "vai_a_oggi": _cal_vai_a_oggi}),
        _t("Chat", s, "Chat a bolle: i tuoi messaggi a destra, quelli degli altri a sinistra", 1, [
            _p("messaggi", "lista", [], "Messaggi: dizionari con \"testo\", \"mio\" (vero se è tuo), \"autore\" e \"ora\""),
            _p("mostra_casella", "logico", True, "Mostra in basso la casella per scrivere", "Comportamento"),
            _p("segnaposto", "testo", "Scrivi un messaggio", "Testo grigio nella casella vuota", "Aspetto"),
            _p("colore_mio", "colore", "", "Colore delle tue bolle; se non lo scegli, colore principale", "Aspetto"),
        ], ("invio",), "invio", icona="chat", dimensione=(320, 400),
           metodi={"ricevi": _chat_ricevi, "invia": _chat_invia, "svuota": _chat_svuota}),
        _t("ListaSchede", s, "Lista di schede con immagine, titolo e sottotitolo, come nelle app", 1, [
            _p("elementi", "lista", [], "Schede: dizionari con \"titolo\", \"sottotitolo\" e \"immagine\" (o solo testi)"),
            _p("indice_selezionato", "intero", -1, "Posizione della scheda scelta (-1 = nessuna)", minimo=-1),
            _p("disposizione", "scelta", "righe", "Una sotto l'altra (righe) o due per riga (griglia)", "Aspetto",
               scelte=("righe", "griglia")),
        ], ("selezione",), "selezione", icona="lista_schede", dimensione=(320, 300),
           metodi={"aggiungi": _schede_aggiungi, "rimuovi": _schede_rimuovi, "svuota": _svuota_elementi}),
        _t("SelettoreOrario", s, "Ore e minuti grandi, con le frecce per cambiarli", 1, [
            _p("ora", "testo", "08:00", "Ora scelta, \"HH:MM\""),
            _p("passo_minuti", "intero", 5, "Di quanti minuti cambiano le frecce", "Comportamento",
               minimo=1, massimo=30),
            _sl("ore", "intero", 8, "Le ore dell'ora scelta (da 0 a 23)"),
            _sl("minuti", "intero", 0, "I minuti dell'ora scelta (da 0 a 59)"),
        ], ("cambio",), "cambio", icona="selettore_orario", dimensione=(200, 120)),
        _t("FirmaAMano", s, "Riquadro dove firmare con il dito o con il mouse; si salva come immagine", 1, [
            _p("colore_penna", "colore", "", "Colore dell'inchiostro; se non lo scegli, come il testo", "Aspetto"),
            _p("spessore_penna", "intero", 3, "Spessore del tratto in pixel", "Aspetto", minimo=1, massimo=20),
            _p("linea_guida", "testo", "Firma qui", "Scritta sulla riga; se non lo scegli, niente riga", "Aspetto"),
            _p("tratti", "lista", [], "I tratti della firma: liste di punti [x, y]"),
            _sl("firmato", "logico", False, "Vero quando c'è almeno un tratto"),
        ], ("firma",), "firma", icona="firma", dimensione=(320, 160),
           metodi={"pulisci": _firma_pulisci, "salva": _firma_salva}),
        _t("Gradimento", s, "Cinque livelli di gradimento con le faccine a linee, come nei sondaggi di soddisfazione",
           1, [
            _p("valore", "intero", 0, "Livello scelto, da 1 a 5 (0 = nessuno)", minimo=0, massimo=5),
            _p("testi", "lista", list(L.TESTI_GRADIMENTO),
               "Le parole dei cinque livelli, dal più basso al più alto", "Aspetto"),
            _p("domanda", "testo", "Come valuti il servizio?", "Scritta finché non si sceglie; se non lo scegli, niente",
               "Aspetto"),
            _p("mostra_testo", "logico", True, "Scrive la parola del livello scelto", "Aspetto"),
            _p("colori", "logico", True, "Ogni livello ha il suo colore (falso = solo il colore principale)",
               "Aspetto"),
            _p("sola_lettura", "logico", False, "Se vero non si può cambiare toccando", "Comportamento"),
        ], ("cambio",), "cambio", icona="gradimento", dimensione=(300, 96)),
        _t("CasellaPIN", s, "Caselle per un codice segreto di poche cifre", 1, [
            _p("cifre", "intero", 4, "Quante cifre (da 3 a 8)", "Comportamento", minimo=3, massimo=8),
            _p("valore", "testo", "", "Le cifre scritte"),
            _p("nascosto", "logico", True, "Mostra pallini al posto delle cifre", "Aspetto"),
            _sl("completo", "logico", False, "Vero quando tutte le cifre sono scritte"),
        ], ("completato", "cambio"), "completato", icona="casella_pin", dimensione=(260, 56),
           metodi={"pulisci": _pin_pulisci}),
        _t("CampoRicerca", s, "Casella di ricerca con la lente e i suggerimenti mentre scrivi", 1, [
            _p("testo", "testo", "", "Il testo cercato"),
            _p("segnaposto", "testo", "Cerca", "Testo grigio nella casella vuota", "Aspetto"),
            _p("suggerimenti", "lista", [], "Parole da suggerire mentre si scrive"),
            _p("massimo_suggerimenti", "intero", 6, "Quanti suggerimenti al massimo", "Comportamento",
               minimo=0, massimo=20),
        ], ("ricerca", "cambio"), "ricerca", icona="campo_ricerca", dimensione=(300, 44),
           metodi={"pulisci": _ricerca_pulisci}),
        _t("Tag", s, "Etichette tonde da toccare per sceglierle o filtrare (lavoro, urgente, ...)", 1, [
            _p("elementi", "lista", ["Lavoro", "Personale", "Urgente", "Da leggere"], "I tag"),
            _p("selezionati", "lista", [], "I tag scelti"),
            _p("modo_scelta", "scelta", "molti", "Quanti tag si possono scegliere", "Comportamento",
               scelte=("molti", "uno", "nessuno")),
            _p("rimovibili", "logico", False, "Ogni tag ha la crocetta per toglierlo", "Comportamento"),
        ], ("selezione", "rimozione"), "selezione", icona="tag", dimensione=(320, 80),
           metodi={"aggiungi": _tag_aggiungi, "rimuovi": _tag_rimuovi, "svuota": _tag_svuota}),
        _t("Fisarmonica", s, "Titoli che si aprono con un tocco e mostrano il loro testo", 1, [
            _p("sezioni", "lista", [
                {"titolo": "Spedizione", "testo": "Consegna in 24-48 ore in tutta Italia; gratuita sopra i 50 euro."},
                {"titolo": "Resi e rimborsi", "testo": "Hai 30 giorni per restituire un articolo: il rimborso arriva "
                                                      "sullo stesso metodo di pagamento."},
                {"titolo": "Assistenza", "testo": "Scrivici dalla chat: rispondiamo dal lunedì al venerdì, "
                                                  "dalle 9 alle 18."},
            ], "Sezioni: dizionari con \"titolo\" e \"testo\""),
            _p("aperta", "intero", 0, "Posizione della sezione aperta (-1 = tutte chiuse)", minimo=-1),
        ], ("apertura",), "apertura", icona="fisarmonica", dimensione=(320, 260),
           metodi={"apri": _fis_apri, "chiudi": _fis_chiudi}),
        _t("BarraSchede", s, "Barra in basso con icone e nomi, come nelle app del telefono", 1, [
            _p("voci", "lista", [{"testo": "Casa", "icona": "casa"}, {"testo": "Cerca", "icona": "cerca"},
                                 {"testo": "Preferiti", "icona": "cuore"}, {"testo": "Profilo", "icona": "profilo"}],
               "Voci: dizionari con \"testo\" e \"icona\" (o solo testi)"),
            _p("indice", "intero", 0, "Posizione della voce scelta (la prima è 0)", minimo=0),
            _p("mostra_testi", "logico", True, "Scrive il nome sotto le icone", "Aspetto"),
            _p("bollini", "dizionario", {}, "Numeri rossi sulle voci, per esempio {\"Chat\": 3}"),
            _ancorata("sinistra", "destra", "basso"),
        ], ("cambio",), "cambio", icona="barra_schede", dimensione=(360, 64)),
        _t("PulsanteFluttuante", s, "Pulsante tondo con un'icona, che resta sopra agli altri", 1, [
            _p("icona", "scelta", "più", "Il disegno sul pulsante", "Aspetto", scelte=scelte_icone),
            _p("testo", "testo", "", "Scritta accanto all'icona; se non lo scegli, solo l'icona, tondo", "Aspetto"),
            _ancorata("destra", "basso"),
        ], (), "clic", icona="fluttuante", dimensione=(56, 56)),
        _t("Avviso", s, "Messaggio che compare in basso per qualche secondo e poi sparisce", 1, [
            _p("testo", "testo", "Modifiche salvate", "Il messaggio"),
            _p("livello", "scelta", "informazione", "Che tipo di avviso (cambia colore e icona)", "Aspetto",
               scelte=tuple(L.LIVELLI_AVVISO)),
            _p("durata", "intero", 2500, "Millisecondi prima di sparire (0 = resta finché non lo chiudi)",
               "Comportamento", minimo=0, massimo=60000),
            _p("testo_azione", "testo", "", "Scritta del pulsante nell'avviso, per esempio \"Annulla\"", "Aspetto"),
            _sl("mostrato", "logico", False, "Vero mentre l'avviso si vede"),
            _sl("volte", "intero", 0, "Quante volte è stato mostrato"),
            _ancorata("sinistra", "destra", "basso"),
        ], ("clic_azione", "chiusura"), "clic_azione", icona="avviso_scomparsa", dimensione=(320, 52),
           metodi={"mostra": _avviso_mostra, "nascondi": _avviso_nascondi}),
        _t("ListaCoseDaFare", s, "Lista delle cose da fare con la spunta e la casella per aggiungerne", 1, [
            _p("elementi", "lista", [{"testo": "Rivedere il contratto", "fatto": True},
                                     {"testo": "Preparare la demo", "fatto": False},
                                     {"testo": "Rispondere ai clienti", "fatto": False}],
               "Cose da fare: dizionari con \"testo\" e \"fatto\" (o solo testi)"),
            _p("mostra_casella", "logico", True, "Mostra la casella per aggiungere", "Comportamento"),
            _p("segnaposto", "testo", "Aggiungi una cosa da fare", "Testo grigio nella casella vuota", "Aspetto"),
            _sl("fatti", "intero", 1, "Quante cose sono già fatte"),
            _sl("da_fare", "intero", 2, "Quante cose restano da fare"),
        ], ("spunta", "aggiunta", "rimozione"), "spunta", icona="cose_da_fare", dimensione=(320, 300),
           metodi={"aggiungi": _todo_aggiungi, "rimuovi": _todo_rimuovi, "spunta": _todo_spunta,
                   "togli_fatti": _todo_togli_fatti, "svuota": _todo_svuota}),
        _t("Contatore", s, "Numero con i tasti - e + ai lati, per contare le quantità", 1, [
            _p("valore", "intero", 1, "Il numero"),
            _p("minimo", "intero", 0, "Il numero più piccolo", "Comportamento"),
            _p("massimo", "intero", 99, "Il numero più grande", "Comportamento"),
            _p("passo", "intero", 1, "Di quanto cambia a ogni tocco", "Comportamento", minimo=1),
        ], ("cambio",), "cambio", icona="contatore", dimensione=(150, 44),
           metodi={"aumenta": _contatore_aumenta, "diminuisci": _contatore_diminuisci, "azzera": _contatore_azzera}),
        _t("Carosello", s, "Immagini (o schede di testo) che scorrono col dito, con titolo, didascalia e puntini",
           1, [
            _p("diapositive", "lista", [dict(x) for x in L.DIAPOSITIVE_ESEMPIO],
               "Diapositive: percorsi di immagini o dizionari con \"immagine\", \"titolo\" e \"testo\""),
            _p("indice", "intero", 0, "Posizione della diapositiva mostrata (la prima è 0)", minimo=0),
            _p("automatico", "logico", False, "Passa da sola alla diapositiva dopo", "Comportamento"),
            _p("intervallo", "intero", 4000, "Millisecondi tra una diapositiva e l'altra (se automatico)",
               "Comportamento", minimo=1000, massimo=60000),
            _p("ciclico", "logico", True, "Dopo l'ultima torna alla prima", "Comportamento"),
            _p("mostra_punti", "logico", True, "Mostra i puntini in basso", "Aspetto"),
            _p("adatta", "scelta", "riempi", "Come sta l'immagine nel riquadro", "Aspetto",
               scelte=("riempi", "adatta")),
        ], ("cambio",), "cambio", icona="carosello", dimensione=(320, 200),
           metodi={"avanti": _car_avanti, "indietro": _car_indietro, "vai_a": _car_vai_a,
                   "aggiungi": _car_aggiungi, "svuota": _car_svuota}),
        _t("Orologio", s, "Orologio con le lancette: mostra l'ora vera o quella che scegli", 1, [
            _p("ora", "testo", "", "Ora mostrata, \"HH:MM\" o \"HH:MM:SS\" (vuoto = l'ora vera, che avanza)"),
            _p("mostra_secondi", "logico", True, "Mostra la lancetta dei secondi", "Aspetto"),
            _p("mostra_numeri", "logico", True, "Scrive i numeri da 1 a 12", "Aspetto"),
            _p("digitale", "logico", False, "Scrive anche l'ora in cifre sotto le lancette", "Aspetto"),
            _p("sveglia", "testo", "", "\"HH:MM\": a quell'ora arriva l'evento sveglia; se non lo scegli, nessuna",
               "Comportamento"),
        ], ("sveglia",), "sveglia", icona="orologio_analogico", dimensione=(160, 160)),
        _t("Meteo", s, "Scheda del meteo: città, temperatura, icona e previsioni (i dati li dà il programma)", 1, [
            _p("citta", "testo", "Roma", "Nome della città"),
            _p("condizione", "scelta", "sole", "Com'è il cielo", scelte=tuple(L.ICONE_METEO)),
            _p("temperatura", "decimale", 22.0, "Temperatura adesso"),
            _p("minima", "decimale", 16.0, "Temperatura minima di oggi"),
            _p("massima", "decimale", 25.0, "Temperatura massima di oggi"),
            _p("umidita", "intero", -1, "Umidità in percentuale (-1 = non mostrarla)", minimo=-1, massimo=100),
            _p("previsioni", "lista", [], "Prossimi giorni: dizionari con \"giorno\", \"condizione\", \"minima\" e "
               "\"massima\""),
            _p("unita", "scelta", "°C", "Gradi Celsius o Fahrenheit", "Aspetto", scelte=("°C", "°F")),
        ], (), "clic", icona="meteo", dimensione=(320, 200)),
        _t("SchedaProfilo", s, "Scheda di una persona: foto, nome, descrizione, numeri e un pulsante", 1, [
            _p("persona", "testo", "Ada Lovelace", "Il nome della persona"),
            _p("descrizione", "testo", "Matematica · primo programma della storia", "Una riga sotto il nome"),
            _p("immagine", "immagine", "", "La foto; se non lo scegli, le iniziali in un cerchio colorato"),
            _p("numeri", "dizionario", {"Progetti": 12, "Contatti": 128, "Valutazioni": 530},
               "Numeri da mostrare, per esempio {\"Amici\": 12}"),
            _p("testo_pulsante", "testo", "Segui", "Scritta del pulsante; se non lo scegli, niente pulsante", "Aspetto"),
            _p("testo_pulsante_premuto", "testo", "Seguito", "Scritta del pulsante quando `seguito` è vero",
               "Aspetto"),
            _p("seguito", "logico", False, "Si accende e si spegne toccando il pulsante"),
            _p("colore_copertina", "colore", "", "Colore della fascia in alto; se non lo scegli, colore principale", "Aspetto"),
        ], ("clic_pulsante",), "clic_pulsante", icona="scheda_profilo", dimensione=(300, 270)),
        _t("IndicatorePassi", s, "Pallini numerati collegati: a che passo sei di un modulo in più pagine", 1, [
            _p("passi", "lista", ["Carrello", "Dati", "Pagamento", "Fatto"], "I nomi dei passi"),
            _p("passo", "intero", 1, "Il passo a cui sei (il primo è 1)", minimo=1),
        ], ("cambio",), "cambio", icona="indicatore_passi", dimensione=(320, 64),
           metodi={"avanti": _passi_avanti, "indietro": _passi_indietro}),
    ]


def tipi() -> list[TipoControllo]:
    """I controlli della scheda "Tutti i giorni", come oggetti NUOVI a ogni chiamata."""
    return _tipi_senza_registrare()


#: Nomi dei tipi della scheda "Tutti i giorni" (nell'ordine della casella).
TIPI_QUOTIDIANI: tuple[str, ...] = L.TIPI_QUOTIDIANI

for _tipo in tipi():
    registra(_tipo)
del _tipo
