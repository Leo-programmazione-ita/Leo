"""Il controllo ``Foglio``: un foglio di calcolo completo (Leo Fogli) da mettere in una finestra.

Il calcolo è nel motore ``leo.fogli`` (formule in italiano come Excel, ~250 funzioni, più fogli,
matrici dinamiche, file .xlsx). Il controllo tiene la sua ``Cartella`` di lavoro e la mostra con
``leo.grafica.qt.widget_fogli``; i metodi funzionano anche senza finestra (per esempio nei test o
in un programma che prepara un file Excel e lo salva).

Esempio::

    quando Finestra1.apertura fai
        Foglio1.imposta("A1", "Prodotto")
        Foglio1.imposta("B1", "Prezzo")
        Foglio1.imposta("B5", "=SOMMA(B2:B4)")
        Foglio1.stile("A1:B1", {"grassetto": vero, "colore_sfondo": "#FACC15"})
    fine

    quando Foglio1.cambio fai
        Etichetta1.testo = "Totale: {Foglio1.testo("B5")}"
    fine
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from ..errori import ErroreTipo, ErroreValore
from .metadati import Proprieta, TipoControllo, registra

__all__ = ["SCHEDA", "TIPI_FOGLI", "cartella_di", "riferimento", "area", "tipi", "DATI_EVENTI"]

SCHEDA = "Dati"
TIPI_FOGLI = ("Foglio",)

DATI_EVENTI: dict[str, dict[str, tuple[str, ...]]] = {
    "Foglio": {
        "cambio": ("cella", "valore", "foglio"),
        "selezione": ("cella", "area", "foglio"),
        "doppio_clic": ("cella", "foglio"),
        "cambio_foglio": ("foglio",),
        "errore_convalida": ("cella", "messaggio"),
        "salvataggio": ("percorso",),
        "apertura_file": ("percorso",),
    }
}


# ===========================================================================
# Collegamento con il motore
# ===========================================================================

def cartella_di(controllo: Any):
    """La cartella di lavoro (motore ``leo.fogli``) del controllo, creata alla prima richiesta."""
    cartella = getattr(controllo, "_cartella_fogli", None)
    if cartella is None:
        from ..fogli import Cartella
        cartella = Cartella()
        try:
            controllo._cartella_fogli = cartella
        except AttributeError:  # pragma: no cover
            pass
    return cartella


def _imposta(c: Any, proprieta: str, valore: Any) -> None:
    c.modello.proprieta[proprieta] = valore
    c.avvisa(proprieta, valore)


def foglio_attivo(c: Any):
    cartella = cartella_di(c)
    nome = c.modello.proprieta.get("foglio_attivo") or ""
    f = cartella.foglio(nome) if nome else None
    if f is None:
        f = cartella.fogli[0]
        c.modello.proprieta["foglio_attivo"] = f.nome
    return f


def riferimento(c: Any, testo: Any) -> tuple[Any, int, int]:
    """"B3", "Foglio2!B3" o [riga, colonna] (da 1) -> (foglio, riga, colonna) da 0."""
    from ..fogli.riferimenti import leggi_cella
    cartella = cartella_di(c)
    if isinstance(testo, list) and len(testo) == 2 and all(isinstance(x, int) and not isinstance(x, bool) for x in testo):
        return foglio_attivo(c), testo[0] - 1, testo[1] - 1
    if not isinstance(testo, str):
        raise ErroreTipo("La cella si scrive come testo (\"B3\" o \"Foglio2!B3\") o come lista [riga, colonna].")
    f = foglio_attivo(c)
    t = testo.strip()
    if "!" in t:
        nome, t = t.rsplit("!", 1)
        nome = nome.strip("'")
        f = cartella.foglio(nome)
        if f is None:
            raise ErroreValore(f"Il foglio «{nome}» non esiste.", suggerimento=f"I fogli sono: {', '.join(x.nome for x in cartella.fogli)}.")
    p = leggi_cella(t)
    if p is None:
        raise ErroreValore(f"«{testo}» non è una cella.", suggerimento="Scrivi la cella come \"B3\".")
    return f, p[0], p[1]


def area(c: Any, testo: Any) -> tuple[Any, tuple[int, int, int, int]]:
    """"A1:C5" (anche con il foglio, anche "A:A" o una sola cella) -> (foglio, (r1, c1, r2, c2))."""
    from ..fogli.riferimenti import leggi_area
    if not isinstance(testo, str):
        raise ErroreTipo("L'intervallo si scrive come testo, per esempio \"A1:C10\".")
    cartella = cartella_di(c)
    f = foglio_attivo(c)
    t = testo.strip()
    if "!" in t:
        nome, t = t.rsplit("!", 1)
        nome = nome.strip("'")
        f = cartella.foglio(nome)
        if f is None:
            raise ErroreValore(f"Il foglio «{nome}» non esiste.")
    a = leggi_area(t)
    if a is None:
        raise ErroreValore(f"«{testo}» non è un intervallo.", suggerimento="Scrivi l'intervallo come \"A1:C10\".")
    return f, a


def _valore_leo(v: Any) -> Any:
    from ..fogli.valori import Errore
    if isinstance(v, Errore):
        return v.codice
    if isinstance(v, float) and v.is_integer() and abs(v) < 1e15:
        return int(v)
    return v


def _percorso(c: Any, p: Any) -> str:
    if not isinstance(p, str) or not p.strip():
        raise ErroreValore("Serve il percorso del file.")
    percorso = Path(p)
    base = getattr(c, "cartella_progetto", None)
    if not percorso.is_absolute() and base is not None:
        percorso = Path(base) / percorso
    return str(percorso)


def _aggiorna_interfaccia(c: Any) -> None:
    """Dice alla griglia (se c'è) di ridisegnare tutto: nuovo file, fogli, righe e colonne cambiate."""
    try:
        from .azioni import richiedi_interfaccia
        richiedi_interfaccia(c, "aggiorna")
    except Exception:  # noqa: BLE001 - senza finestra non c'è niente da ridisegnare
        pass


def _dopo_modifica(c: Any) -> None:
    c.modello.proprieta["modificato"] = True
    c.avvisa("modificato", True)


# ===========================================================================
# Metodi
# ===========================================================================

def _m_imposta(c, cella, valore):
    """Scrive in una cella come farebbe l'utente: un testo che inizia con "=" è una formula."""
    f, r, k = riferimento(c, cella)
    cartella = cartella_di(c)
    with cartella.operazione("Imposta"):
        cartella.imposta(f, r, k, valore)
    _dopo_modifica(c)


def _m_imposta_valore(c, cella, valore):
    """Scrive un valore così com'è: un testo resta testo anche se comincia con "=" o sembra un numero."""
    f, r, k = riferimento(c, cella)
    cartella = cartella_di(c)
    with cartella.operazione("Imposta"):
        cartella.imposta_valore(f, r, k, valore)
    _dopo_modifica(c)


def _m_valore(c, cella):
    """Il valore calcolato della cella (numero, testo, vero/falso, nulla; gli errori come "#DIV/0!")."""
    f, r, k = riferimento(c, cella)
    return _valore_leo(f.valore(r, k))


def _m_formula(c, cella):
    """Quello che è scritto nella cella (la formula, se c'è)."""
    f, r, k = riferimento(c, cella)
    return f.ingresso(r, k)


def _m_testo(c, cella):
    """Il testo come si vede nella cella (con il formato: "€ 1.234,50", "25/12/2026")."""
    from ..fogli.operazioni import testo_mostrato
    f, r, k = riferimento(c, cella)
    return testo_mostrato(cartella_di(c), f, r, k)[0]


def _m_intervallo(c, intervallo):
    """I valori di un intervallo come lista di righe."""
    f, (r1, c1, r2, c2) = area(c, intervallo)
    mr, mc = f.estensione()
    r2, c2 = min(r2, max(mr, r1)), min(c2, max(mc, c1))
    return [[_valore_leo(f.valore(r, k)) for k in range(c1, c2 + 1)] for r in range(r1, r2 + 1)]


def _m_scrivi_tabella(c, cella, righe):
    """Scrive una tabella a partire dalla cella: lista di righe (liste) o lista di dizionari (con l'intestazione)."""
    if not isinstance(righe, list):
        raise ErroreTipo("`scrivi_tabella` vuole una lista di righe o di dizionari.")
    f, r, k = riferimento(c, cella)
    cartella = cartella_di(c)
    if righe and all(isinstance(x, dict) for x in righe):
        chiavi: list = []
        for x in righe:
            for ch in x:
                if ch not in chiavi:
                    chiavi.append(ch)
        tabella = [list(chiavi)] + [[x.get(ch) for ch in chiavi] for x in righe]
    else:
        tabella = [x if isinstance(x, list) else [x] for x in righe]
    with cartella.operazione("Scrivi tabella"):
        for i, riga in enumerate(tabella):
            for j, v in enumerate(riga):
                if isinstance(v, str) and v.startswith("="):
                    cartella.imposta(f, r + i, k + j, v)
                else:
                    cartella.imposta_valore(f, r + i, k + j, v)
    _dopo_modifica(c)


def _m_leggi_tabella(c, intervallo, intestazione=True):
    """Le righe di un intervallo come dizionari (la prima riga dà i nomi), o come liste."""
    righe = _m_intervallo(c, intervallo)
    while righe and all(v is None for v in righe[-1]):
        righe.pop()
    if not intestazione or not righe:
        return righe
    nomi = [str(v) if v is not None else f"colonna_{i + 1}" for i, v in enumerate(righe[0])]
    return [dict(zip(nomi, r)) for r in righe[1:]]


def _m_cancella(c, intervallo):
    """Svuota le celle dell'intervallo (i formati restano)."""
    from ..fogli.operazioni import svuota
    f, a = area(c, intervallo)
    svuota(cartella_di(c), f, a)
    _dopo_modifica(c)


def _m_nuovo(c):
    """Un foglio di lavoro nuovo e vuoto."""
    from ..fogli import Cartella
    vecchia = cartella_di(c)
    nuova = Cartella()
    nuova.osservatori = vecchia.osservatori
    c._cartella_fogli = nuova
    _imposta(c, "file", "")
    _imposta(c, "foglio_attivo", nuova.fogli[0].nome)
    _imposta(c, "modificato", False)
    _aggiorna_interfaccia(c)


def apri_file(percorso: str):
    estensione = os.path.splitext(percorso)[1].lower()
    if estensione in (".xlsx", ".xlsm"):
        from ..fogli.file_xlsx import apri_xlsx
        return apri_xlsx(percorso)
    if estensione in (".csv", ".txt", ".tsv"):
        from ..fogli import Cartella
        from ..fogli.file_csv import importa_csv
        nuova = Cartella()
        importa_csv(nuova, nuova.fogli[0], percorso)
        nuova._annulla.clear()
        return nuova
    if estensione in (".ods", ".xls"):
        # LibreOffice/vecchi Excel: si leggono i valori con la libreria "ufficio" di Leo
        from ..fogli import Cartella
        from ..libreria import ufficio
        fogli = ufficio.leggi_fogli_excel(percorso, intestazione=False)
        nuova = Cartella(nuovo_foglio=False)
        for nome, righe in fogli.items():
            g = nuova.aggiungi_foglio(str(nome)[:31] or None)
            for i, riga in enumerate(righe):
                for j, v in enumerate(riga):
                    if v is not None:
                        nuova.imposta_valore(g, i, j, v)
        if not nuova.fogli:
            nuova.aggiungi_foglio("Foglio1")
        nuova._annulla.clear()
        return nuova
    from ..fogli.file_lfogli import apri
    return apri(percorso)


def salva_file(cartella, percorso: str) -> None:
    estensione = os.path.splitext(percorso)[1].lower()
    if estensione in (".xlsx", ".xlsm"):
        from ..fogli.file_xlsx import salva_xlsx
        salva_xlsx(cartella, percorso)
    elif estensione in (".csv", ".txt"):
        from ..fogli.file_csv import esporta_csv
        esporta_csv(cartella, cartella.fogli[0], percorso)
    elif estensione == ".pdf":
        from ..fogli.stampa import esporta_pdf
        esporta_pdf(cartella, cartella.fogli[0], percorso)
    else:
        from ..fogli.file_lfogli import salva
        salva(cartella, percorso)


def _m_apri(c, percorso):
    """Apre un file: .lfogli (Leo Fogli), .xlsx (Excel, con le formule), .csv, .ods."""
    p = _percorso(c, percorso)
    if not os.path.exists(p):
        raise ErroreValore(f"Il file «{p}» non esiste.")
    nuova = apri_file(p)
    vecchia = cartella_di(c)
    nuova.osservatori = vecchia.osservatori
    nuova.registra_storico = bool(c.modello.proprieta.get("registra_modifiche", False))
    nuova.utente = str(c.modello.proprieta.get("utente", "") or "")
    c._cartella_fogli = nuova
    _imposta(c, "file", p)
    _imposta(c, "foglio_attivo", nuova.fogli[0].nome)
    _imposta(c, "modificato", False)
    _aggiorna_interfaccia(c)


def _m_apri_modello(c, percorso):
    """Apre un modello come documento nuovo: "Salva" chiederà dove salvarlo (il modello resta com'è)."""
    _m_apri(c, percorso)
    _imposta(c, "file", "")
    _imposta(c, "modificato", False)


def _m_salva(c, percorso=None):
    """Salva nel file indicato (o in quello aperto): .lfogli, .xlsx, .csv, .pdf secondo l'estensione."""
    if percorso is None:
        percorso = c.modello.proprieta.get("file") or ""
        if not percorso:
            raise ErroreValore("Non c'è un file aperto: scrivi dove salvare, per esempio `Foglio1.salva(\"conti.lfogli\")`.")
    p = _percorso(c, percorso)
    salva_file(cartella_di(c), p)
    if os.path.splitext(p)[1].lower() in (".lfogli", ".xlsx", ".xlsm", ""):
        _imposta(c, "file", p)
        _imposta(c, "modificato", False)


def _m_esporta(c, percorso):
    """Salva una copia (.xlsx, .csv, .pdf, .lfogli) senza cambiare il file aperto."""
    salva_file(cartella_di(c), _percorso(c, percorso))


def _m_fogli(c):
    """I nomi dei fogli, in ordine."""
    return [f.nome for f in cartella_di(c).fogli]


def _m_aggiungi_foglio(c, nome=None):
    """Aggiunge un foglio (con il nome indicato o "FoglioN") e restituisce il suo nome."""
    cartella = cartella_di(c)
    try:
        with cartella.operazione("Nuovo foglio"):
            f = cartella.aggiungi_foglio(nome if isinstance(nome, str) and nome else None)
    except ValueError as e:
        raise ErroreValore(str(e))
    _aggiorna_interfaccia(c)
    _dopo_modifica(c)
    return f.nome


def _m_elimina_foglio(c, nome):
    cartella = cartella_di(c)
    try:
        with cartella.operazione("Elimina foglio"):
            cartella.elimina_foglio(nome)
    except ValueError as e:
        raise ErroreValore(str(e))
    if (c.modello.proprieta.get("foglio_attivo") or "").lower() == str(nome).lower():
        _imposta(c, "foglio_attivo", cartella.fogli[0].nome)
    _aggiorna_interfaccia(c)
    _dopo_modifica(c)


def _m_rinomina_foglio(c, vecchio, nuovo):
    cartella = cartella_di(c)
    try:
        with cartella.operazione("Rinomina foglio"):
            cartella.rinomina_foglio(vecchio, nuovo)
    except ValueError as e:
        raise ErroreValore(str(e))
    if (c.modello.proprieta.get("foglio_attivo") or "").lower() == str(vecchio).lower():
        _imposta(c, "foglio_attivo", nuovo)
    _aggiorna_interfaccia(c)
    _dopo_modifica(c)


def _m_attiva_foglio(c, nome):
    f = cartella_di(c).foglio(nome)
    if f is None:
        raise ErroreValore(f"Il foglio «{nome}» non esiste.")
    _imposta(c, "foglio_attivo", f.nome)


_FORMATI_NOMI = None


def _codice_formato(formato: str) -> str:
    from ..fogli.formato import FORMATI_PREDEFINITI
    for nome, codice in FORMATI_PREDEFINITI.items():
        if nome.lower() == formato.strip().lower():
            return codice
    return formato


def _m_formato(c, intervallo, formato):
    """Formato dei numeri: un nome ("Valuta", "Percentuale", "Data", "Numero"...) o un codice ("#,##0.00")."""
    if not isinstance(formato, str):
        raise ErroreTipo("Il formato è un testo, per esempio \"Valuta\" o \"0.00%\".")
    _m_stile(c, intervallo, {"formato": _codice_formato(formato)})


_STILI_AMMESSI = ("grassetto", "corsivo", "sottolineato", "barrato", "colore_testo", "colore_sfondo", "carattere",
                  "dimensione", "allineamento", "verticale", "a_capo", "formato", "rientro", "bordo_sopra",
                  "bordo_sotto", "bordo_sinistra", "bordo_destra", "colore_bordo")


def _m_stile(c, intervallo, stile):
    """Cambia l'aspetto delle celle: {"grassetto": vero, "colore_sfondo": "#FACC15", "allineamento": "centro",
    "bordi": "tutti"...}."""
    if not isinstance(stile, dict):
        raise ErroreTipo("Lo stile è un dizionario, per esempio {\"grassetto\": vero}.")
    f, (r1, c1, r2, c2) = area(c, intervallo)
    cartella = cartella_di(c)
    s = dict(stile)
    bordi = s.pop("bordi", None)
    for k in s:
        if k not in _STILI_AMMESSI:
            raise ErroreValore(f"«{k}» non è uno stile delle celle.", suggerimento="Stili: " + ", ".join(_STILI_AMMESSI) + ", bordi.")
    mr, mc = f.estensione()
    if r2 - r1 > 100000:
        r2 = max(mr, r1)
    if c2 - c1 > 1000:
        c2 = max(mc, c1)
    with cartella.operazione("Formato"):
        for r in range(r1, r2 + 1):
            for k in range(c1, c2 + 1):
                cambi = dict(s)
                if bordi in ("tutti", "griglia"):
                    cambi.update(bordo_sopra="sottile", bordo_sotto="sottile", bordo_sinistra="sottile", bordo_destra="sottile")
                elif bordi == "esterno":
                    if r == r1:
                        cambi["bordo_sopra"] = "sottile"
                    if r == r2:
                        cambi["bordo_sotto"] = "sottile"
                    if k == c1:
                        cambi["bordo_sinistra"] = "sottile"
                    if k == c2:
                        cambi["bordo_destra"] = "sottile"
                elif bordi in ("nessuno", ""):
                    cambi.update(bordo_sopra=None, bordo_sotto=None, bordo_sinistra=None, bordo_destra=None)
                cartella.imposta_stile(f, r, k, **cambi)
    _dopo_modifica(c)


def _m_larghezza_colonna(c, colonna, pixel):
    from ..fogli.riferimenti import colonna as col_da
    f = foglio_attivo(c)
    k = col_da(colonna) if isinstance(colonna, str) else int(colonna) - 1
    f.larghezze[k] = max(4, int(pixel))
    _aggiorna_interfaccia(c)


def _m_altezza_riga(c, riga, pixel):
    f = foglio_attivo(c)
    f.altezze[int(riga) - 1] = max(4, int(pixel))
    _aggiorna_interfaccia(c)


def _m_unisci(c, intervallo):
    from ..fogli.operazioni import unisci_celle
    f, a = area(c, intervallo)
    unisci_celle(cartella_di(c), f, a)
    _aggiorna_interfaccia(c)


def _m_separa(c, intervallo):
    from ..fogli.operazioni import separa_celle
    f, a = area(c, intervallo)
    separa_celle(cartella_di(c), f, a)
    _aggiorna_interfaccia(c)


def _m_ordina(c, intervallo, colonna, crescente=True, intestazione=False):
    """Ordina le righe dell'intervallo secondo una colonna ("B" o numero da 1)."""
    from ..fogli.operazioni import ordina
    from ..fogli.riferimenti import colonna as col_da
    f, a = area(c, intervallo)
    k = col_da(colonna) if isinstance(colonna, str) else a[1] + int(colonna) - 1
    ordina(cartella_di(c), f, a, [(k, bool(crescente))], intestazione=bool(intestazione))
    _dopo_modifica(c)


def _m_filtra(c, intervallo):
    """Mette il filtro (le frecce nell'intestazione) sulla tabella."""
    from ..fogli.operazioni import imposta_filtro
    f, a = area(c, intervallo)
    imposta_filtro(cartella_di(c), f, a)
    _aggiorna_interfaccia(c)


def _m_filtra_colonna(c, colonna, condizione):
    """Filtra una colonna: una condizione (">100", "Roma", "<>") o una lista di valori da tenere."""
    from ..fogli.operazioni import filtra_colonna
    from ..fogli.riferimenti import colonna as col_da
    f = foglio_attivo(c)
    k = col_da(colonna) if isinstance(colonna, str) else int(colonna) - 1
    crit = None if condizione is None else ({"valori": [str(x) for x in condizione]} if isinstance(condizione, list)
                                             else {"condizione": condizione})
    try:
        filtra_colonna(cartella_di(c), f, k, crit)
    except ValueError as e:
        raise ErroreValore(str(e))
    _aggiorna_interfaccia(c)


def _m_togli_filtro(c):
    from ..fogli.operazioni import togli_filtro
    togli_filtro(cartella_di(c), foglio_attivo(c))
    _aggiorna_interfaccia(c)


def _m_cerca(c, testo):
    """Le celle (di tutti i fogli) che contengono il testo: ["Foglio1!B3", ...]."""
    from ..fogli.operazioni import trova
    from ..fogli.riferimenti import nome_cella
    return [f"{f.nome}!{nome_cella(r, k)}" for f, r, k in trova(cartella_di(c), str(testo), nelle_formule=False)]


def _m_sostituisci(c, cosa, con):
    from ..fogli.operazioni import sostituisci
    n = sostituisci(cartella_di(c), str(cosa), str(con))
    _dopo_modifica(c)
    return n


def _struttura(nome_funzione: str):
    def metodo(c, posizione, quante=1):
        from ..fogli import operazioni as O
        from ..fogli.riferimenti import colonna as col_da
        f = foglio_attivo(c)
        if "colonne" in nome_funzione:
            k = col_da(posizione) if isinstance(posizione, str) else int(posizione) - 1
        else:
            k = int(posizione) - 1
        getattr(O, nome_funzione)(cartella_di(c), f, k, int(quante))
        _aggiorna_interfaccia(c)
        _dopo_modifica(c)
    metodo.__doc__ = {"inserisci_righe": "Inserisce righe vuote prima della riga indicata (da 1).",
                      "elimina_righe": "Elimina righe a partire da quella indicata (da 1).",
                      "inserisci_colonne": "Inserisce colonne vuote prima della colonna (\"C\" o numero).",
                      "elimina_colonne": "Elimina colonne a partire da quella indicata."}[nome_funzione]
    return metodo


def _m_definisci_nome(c, nome, rif):
    """Dà un nome a una cella o a un intervallo: definisci_nome("IVA", "Foglio1!$B$1")."""
    try:
        cartella_di(c).definisci_nome(str(nome), str(rif))
    except ValueError as e:
        raise ErroreValore(str(e))
    _dopo_modifica(c)


def _m_condizionale(c, intervallo, regola):
    """Formattazione condizionale: {"tipo": "valore", "operatore": ">", "valore1": "100",
    "stile": {"colore_sfondo": "#FDE68A"}}; tipi anche "testo", "formula", "duplicati", "primi",
    "scala", "barre" (vedi la guida)."""
    if not isinstance(regola, dict):
        raise ErroreTipo("La regola è un dizionario.")
    f, a = area(c, intervallo)
    g = dict(regola)
    g["area"] = list(a)
    cartella = cartella_di(c)
    with cartella.operazione("Formattazione condizionale"):
        cartella._registra_struttura()
        f.condizionali.append(g)
    _aggiorna_interfaccia(c)
    _dopo_modifica(c)


def _m_togli_condizionali(c, intervallo):
    f, (r1, c1, r2, c2) = area(c, intervallo)
    f.condizionali[:] = [g for g in f.condizionali
                         if g["area"][2] < r1 or g["area"][0] > r2 or g["area"][3] < c1 or g["area"][1] > c2]
    _aggiorna_interfaccia(c)


def _m_convalida(c, intervallo, regola):
    """Convalida dei dati: {"tipo": "lista", "elenco": "Sì;No"} oppure {"tipo": "intero", "operatore": "tra",
    "valore1": "1", "valore2": "10", "messaggio": "..."}."""
    if not isinstance(regola, dict):
        raise ErroreTipo("La regola è un dizionario.")
    f, a = area(c, intervallo)
    g = dict(regola)
    g["area"] = list(a)
    cartella = cartella_di(c)
    with cartella.operazione("Convalida"):
        cartella._registra_struttura()
        f.convalide.append(g)
    _aggiorna_interfaccia(c)


def _m_blocca(c, cella):
    """Blocca le righe sopra e le colonne a sinistra della cella (restano ferme scorrendo)."""
    f, r, k = riferimento(c, cella)
    f.blocca = (r, k)
    _aggiorna_interfaccia(c)


def _m_sblocca(c):
    foglio_attivo(c).blocca = (0, 0)
    _aggiorna_interfaccia(c)


def _m_nota(c, cella, testo):
    """Aggiunge (o toglie, con "") una nota alla cella."""
    f, r, k = riferimento(c, cella)
    cartella_di(c).imposta_nota(f, r, k, str(testo) if testo else None)


def _m_annulla(c):
    ok = cartella_di(c).annulla()
    _aggiorna_interfaccia(c)
    return ok


def _m_ripeti(c):
    ok = cartella_di(c).ripeti()
    _aggiorna_interfaccia(c)
    return ok


def _m_seleziona(c, intervallo):
    """Seleziona un intervallo (e porta lì la cella attiva)."""
    f, (r1, c1, r2, c2) = area(c, intervallo)
    from ..fogli.riferimenti import nome_area, nome_cella
    if f.nome != c.modello.proprieta.get("foglio_attivo"):
        _imposta(c, "foglio_attivo", f.nome)
    _imposta(c, "cella_attiva", nome_cella(r1, c1))
    c.modello.proprieta["selezione"] = nome_area(r1, c1, r2, c2)
    c.avvisa("selezione", c.modello.proprieta["selezione"])


def _m_ricalcola(c):
    cartella_di(c).ricalcola_tutto()


def _m_storico(c):
    """Il registro delle modifiche (se `registra_modifiche` è vero): dizionari con quando, chi, cella, prima, dopo."""
    return [dict(x) for x in cartella_di(c).storico]


def _m_grafico(c, intervallo, tipo="colonne", titolo="", cella=None):
    """Aggiunge un grafico collegato ai dati: tipo "colonne", "barre", "linee", "area", "torta", "anello", "dispersione"."""
    from ..fogli.grafici import aggiungi_grafico
    f, a = area(c, intervallo)
    posizione = None
    if cella is not None:
        _f, r, k = riferimento(c, cella)
        posizione = (r, k)
    g = aggiungi_grafico(cartella_di(c), f, a, str(tipo), str(titolo or ""), posizione)
    _aggiorna_interfaccia(c)
    _dopo_modifica(c)
    return g["id"]


def _m_ricerca_obiettivo(c, cella_formula, obiettivo, cella_variabile):
    """Cambia la cella variabile finché la formula non dà il valore obiettivo; restituisce il valore trovato."""
    from ..fogli.analisi_dati import ricerca_obiettivo
    f1, r1, k1 = riferimento(c, cella_formula)
    f2, r2, k2 = riferimento(c, cella_variabile)
    if not isinstance(obiettivo, (int, float)) or isinstance(obiettivo, bool):
        raise ErroreTipo("L'obiettivo deve essere un numero.")
    try:
        x = ricerca_obiettivo(cartella_di(c), f1, r1, k1, float(obiettivo), f2, r2, k2)
    except ValueError as e:
        raise ErroreValore(str(e))
    _dopo_modifica(c)
    return _valore_leo(x)


def _m_funzioni(c):
    """L'elenco delle funzioni che si possono usare nelle formule."""
    from ..fogli.funzioni import elenco
    return [i.nome for i in elenco()]


METODI = {
    "imposta": _m_imposta, "imposta_valore": _m_imposta_valore, "valore": _m_valore, "formula": _m_formula,
    "testo": _m_testo, "intervallo": _m_intervallo, "scrivi_tabella": _m_scrivi_tabella,
    "leggi_tabella": _m_leggi_tabella, "cancella": _m_cancella, "nuovo": _m_nuovo, "apri": _m_apri,
    "salva": _m_salva, "esporta": _m_esporta, "apri_modello": _m_apri_modello, "fogli": _m_fogli, "aggiungi_foglio": _m_aggiungi_foglio,
    "elimina_foglio": _m_elimina_foglio, "rinomina_foglio": _m_rinomina_foglio, "attiva_foglio": _m_attiva_foglio,
    "formato": _m_formato, "stile": _m_stile, "larghezza_colonna": _m_larghezza_colonna,
    "altezza_riga": _m_altezza_riga, "unisci": _m_unisci, "separa": _m_separa, "ordina": _m_ordina,
    "filtra": _m_filtra, "filtra_colonna": _m_filtra_colonna, "togli_filtro": _m_togli_filtro, "cerca": _m_cerca,
    "sostituisci": _m_sostituisci, "inserisci_righe": _struttura("inserisci_righe"),
    "elimina_righe": _struttura("elimina_righe"), "inserisci_colonne": _struttura("inserisci_colonne"),
    "elimina_colonne": _struttura("elimina_colonne"), "definisci_nome": _m_definisci_nome,
    "condizionale": _m_condizionale, "togli_condizionali": _m_togli_condizionali, "convalida": _m_convalida,
    "blocca": _m_blocca, "sblocca": _m_sblocca, "nota": _m_nota, "annulla": _m_annulla, "ripeti": _m_ripeti,
    "seleziona": _m_seleziona, "ricalcola": _m_ricalcola, "storico": _m_storico, "grafico": _m_grafico,
    "ricerca_obiettivo": _m_ricerca_obiettivo, "funzioni": _m_funzioni,
}


def _p(nome: str, tipo: str, predefinito: Any, descrizione: str, gruppo: str = "Dati", **kw: Any) -> Proprieta:
    return Proprieta(nome, tipo, predefinito, gruppo, descrizione, **kw)


def tipi() -> list[TipoControllo]:
    proprieta = [
        _p("file", "testo", "", "Il file aperto (vuoto se il foglio non è ancora stato salvato)", sola_lettura=True),
        _p("foglio_attivo", "testo", "Foglio1", "Il foglio che si vede (scrivi il nome per cambiarlo)"),
        _p("cella_attiva", "testo", "A1", "La cella dove si trova il cursore, es. \"B3\""),
        _p("selezione", "testo", "A1", "L'intervallo selezionato, es. \"A1:C5\"", sola_lettura=True),
        _p("modificato", "logico", False, "Vero se ci sono modifiche non salvate", sola_lettura=True),
        _p("sola_lettura", "logico", False, "Se vero le celle non si possono cambiare", "Comportamento"),
        _p("registra_modifiche", "logico", False, "Tiene il registro di chi cambia cosa e quando (storico)",
           "Comportamento"),
        _p("utente", "testo", "", "Nome di chi lavora, per il registro delle modifiche", "Comportamento"),
        _p("barra_strumenti", "logico", True, "Mostra la barra con grassetto, colori, formati...", "Aspetto"),
        _p("barra_formula", "logico", True, "Mostra la barra della formula (fx)", "Aspetto"),
        _p("schede_fogli", "logico", True, "Mostra le schede dei fogli in basso", "Aspetto"),
        _p("barra_stato", "logico", True, "Mostra somma, media e conteggio della selezione", "Aspetto"),
        _p("tema", "scelta", "chiaro", "Colori della griglia", "Aspetto", scelte=("chiaro", "scuro")),
        _p("colore_accento", "colore", "", "Colore della selezione e dei pulsanti; se non lo scegli, quello di Leo",
           "Aspetto"),
        _p("zoom", "intero", 100, "Ingrandimento della griglia in percentuale", "Aspetto", minimo=50, massimo=300),
    ]
    return [TipoControllo(
        nome="Foglio", scheda=SCHEDA,
        descrizione="Foglio di calcolo completo (Leo Fogli): formule in italiano come Excel, più fogli, grafici, file .xlsx",
        versione=3, proprieta={p.nome: p for p in proprieta},
        eventi=("cambio", "selezione", "doppio_clic", "cambio_foglio", "errore_convalida", "salvataggio",
                "apertura_file"),
        evento_predefinito="cambio", dimensione_predefinita=(640, 400), icona="tabella", metodi=dict(METODI),
    )]


for _tipo in tipi():
    registra(_tipo)
del _tipo
