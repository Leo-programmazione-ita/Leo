"""Runtime grafico di Leo: parte pura (modelli, maschere, forme) e strato Qt in `qt/`."""
