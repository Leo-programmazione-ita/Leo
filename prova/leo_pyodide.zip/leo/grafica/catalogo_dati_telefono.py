"""Catalogo degli oggetti "dati, cruscotti e telefono" (seconda cassetta del telefono).

Tredici oggetti che funzionano sul telefono (``leo.grafica.web.dati_telefono`` + ``finestre_dati.js``)
e sul computer (``leo.grafica.qt.widget_dati_telefono``):

* cruscotti e dati: ``Cruscotto`` (lancetta con zone colorate), ``AnelloAvanzamento`` (barra
  circolare), ``GraficoDalVivo`` (linee che scorrono), ``TabellaOrdinabile`` (si ordina toccando le
  intestazioni e si filtra scrivendo);
* sensori del telefono: ``Contapassi``, ``SensoreLuce``, ``SensoreProssimità``, ``Barometro``,
  ``Movimento`` (scuotere il telefono);
* microfono, rete e schermo: ``Fonometro``, ``RegistratoreAudio``, ``StatoRete``, ``OrientamentoSchermo``.

Sul computer gli oggetti del telefono usano l'equivalente del PC quando c'e' (rete del computer, forma
della finestra, finestra scossa col mouse) oppure una simulazione che lo dice una volta sulla console.
I metodi che servono all'hardware chiedono il lavoro all'interfaccia (``_interfaccia``); i conti
(ordine, filtro, zone, altitudine...) sono in ``logica_dati_telefono``.

API: ``tipi()`` (oggetti NUOVI a ogni chiamata), ``DATI_EVENTI``, ``TIPI_DATI_TELEFONO``.
"""

from __future__ import annotations

import copy
from typing import Any

from ..errori import ErroreValore
from . import logica_dati_telefono as L
from .catalogo_dante import _interfaccia, _intero, _non_disponibile, _numero, _p, _sl, _t, _testo, _valore
from .metadati import registra

__all__ = ["tipi", "DATI_EVENTI", "TIPI_DATI_TELEFONO"]


def _imposta(c: Any, proprieta: str, valore: Any) -> None:
    c.modello.proprieta[proprieta] = valore
    c.avvisa(proprieta, valore)


def _chiedi(c: Any, azione: str, cosa: str, *argomenti: Any) -> Any:
    gestita, risultato = _interfaccia(c, azione, *argomenti)
    if gestita:
        return risultato
    raise _non_disponibile(cosa)


# ===========================================================================
# GraficoDalVivo
# ===========================================================================

def _grafico_aggiungi(c, valore, serie="valore"):
    """Aggiunge un valore in fondo al grafico (i piu' vecchi escono a sinistra): `Grafico1.aggiungi(21.5)`."""
    v = _numero(valore, "Il valore")
    nome = _testo(serie, "Il nome della serie").strip() or "valore"
    dati = L.aggiungi_a_serie(_valore(c, "dati", {}), nome, float(v), int(_valore(c, "punti", 60)))
    if len(dati) > 8:
        raise ErroreValore("Il GraficoDalVivo disegna al massimo 8 linee (serie).",
                           suggerimento="Usa meno nomi di serie diversi.")
    _imposta(c, "dati", dati)


def _grafico_aggiungi_valori(c, valori):
    """Aggiunge un valore per ogni serie: `Grafico1.aggiungi_valori({"interna": 21, "esterna": 14})`."""
    if not isinstance(valori, dict):
        raise ErroreValore("`aggiungi_valori` vuole un dizionario {nome della serie: numero}.",
                           suggerimento='Per esempio `aggiungi_valori({"interna": 21, "esterna": 14})`.')
    dati = _valore(c, "dati", {})
    punti = int(_valore(c, "punti", 60))
    for nome, v in valori.items():
        dati = L.aggiungi_a_serie(dati, str(nome), float(_numero(v, f"Il valore di \"{nome}\"")), punti)
    if len(dati) > 8:
        raise ErroreValore("Il GraficoDalVivo disegna al massimo 8 linee (serie).")
    _imposta(c, "dati", dati)


def _grafico_svuota(c):
    """Cancella tutte le linee."""
    _imposta(c, "dati", {})


def _grafico_pausa(c):
    """Ferma il disegno (i valori nuovi si tengono lo stesso); tocca il grafico o chiama `riprendi()`."""
    _imposta(c, "in_pausa", True)


def _grafico_riprendi(c):
    """Fa ripartire il disegno dopo `pausa()`."""
    _imposta(c, "in_pausa", False)


# ===========================================================================
# TabellaOrdinabile
# ===========================================================================

def _tab_righe(c) -> list[list[Any]]:
    return L.righe_normali(_valore(c, "righe", []))


def _tab_aggiungi_riga(c, valori):
    """Aggiunge una riga in fondo: `Tabella1.aggiungi_riga(["Anna", 9])`."""
    riga = list(valori) if isinstance(valori, list) else [valori]
    righe = copy.deepcopy(_tab_righe(c))
    righe.append(riga)
    _imposta(c, "righe", righe)


def _tab_rimuovi_riga(c, indice):
    """Toglie la riga numero `indice` (da 0, come in `righe`)."""
    i = _intero(indice, "Il numero della riga")
    righe = copy.deepcopy(_tab_righe(c))
    if not 0 <= i < len(righe):
        raise ErroreValore(f"La riga {i} non c'è: le righe vanno da 0 a {len(righe) - 1}.")
    del righe[i]
    _imposta(c, "righe", righe)
    scelta = int(_valore(c, "riga_selezionata", -1))
    if scelta == i:
        _imposta(c, "riga_selezionata", -1)
    elif scelta > i:
        _imposta(c, "riga_selezionata", scelta - 1)


def _tab_ordina(c, colonna, crescente=True):
    """Ordina per una colonna (numero da 0 o nome): `Tabella1.ordina("Voto", falso)`."""
    k = L.indice_colonna(colonna, _valore(c, "colonne", []))
    if k < 0:
        raise ErroreValore(f"La colonna `{colonna}` non c'è.",
                           suggerimento="Scrivi il nome di una colonna o il suo numero (la prima è 0).")
    if not isinstance(crescente, bool):
        raise ErroreValore("`crescente` è vero (dal più piccolo) o falso (dal più grande).")
    _imposta(c, "crescente", crescente)
    _imposta(c, "colonna_ordinata", k)


def _tab_filtra(c, testo=""):
    """Mostra solo le righe che contengono il testo (vuoto = tutte)."""
    _imposta(c, "filtro", _testo(testo, "Il filtro"))


def _tab_svuota(c):
    """Toglie tutte le righe."""
    _imposta(c, "righe", [])
    _imposta(c, "riga_selezionata", -1)


def _tab_righe_visibili(c):
    """Le righe che si vedono, nell'ordine in cui si vedono (con ordine e filtro)."""
    righe = _tab_righe(c)
    indici = L.indici_visibili(righe, _valore(c, "filtro", ""), int(_valore(c, "colonna_ordinata", -1)),
                               bool(_valore(c, "crescente", True)))
    return [copy.deepcopy(righe[i]) for i in indici]


def _tab_riga(c, indice):
    """La riga numero `indice` (da 0, come in `righe`)."""
    i = _intero(indice, "Il numero della riga")
    righe = _tab_righe(c)
    if not 0 <= i < len(righe):
        raise ErroreValore(f"La riga {i} non c'è.")
    return copy.deepcopy(righe[i])


# ===========================================================================
# Hardware
# ===========================================================================

def _contapassi_azzera(c):
    """Ricomincia a contare da zero."""
    gestita, _ = _interfaccia(c, "azzera")
    if not gestita:
        _imposta(c, "passi", 0)
        _imposta(c, "distanza", 0.0)
    return None


def _movimento_azzera(c):
    """Riporta a zero il numero delle scosse."""
    gestita, _ = _interfaccia(c, "azzera")
    if not gestita:
        _imposta(c, "scosse", 0)
    return None


def _fonometro_avvia(c):
    """Comincia ad ascoltare il rumore (sul telefono la prima volta chiede il permesso del microfono)."""
    return _chiedi(c, "avvia", "Il fonometro")


def _fonometro_ferma(c):
    """Smette di ascoltare."""
    return _chiedi(c, "ferma", "Il fonometro")


def _fonometro_azzera(c):
    """Dimentica il rumore piu' forte misurato."""
    _imposta(c, "massimo", 0.0)


def _registratore_registra(c):
    """Comincia a registrare dal microfono (la prima volta il telefono chiede il permesso)."""
    return _chiedi(c, "registra", "Il registratore")


def _registratore_ferma(c):
    """Ferma la registrazione (arriva l'evento `fine_registrazione`) o l'ascolto."""
    return _chiedi(c, "ferma", "Il registratore")


def _registratore_riproduci(c, file=None):
    """Fa sentire l'ultima registrazione (o il file indicato)."""
    if file is not None:
        file = _testo(file, "Il file")
    percorso = file if file is not None else str(_valore(c, "ultimo_file", ""))
    if not percorso:
        raise ErroreValore(f"`{c.nome}` non ha ancora registrato niente.",
                           suggerimento=f"Prima chiama `{c.nome}.registra()` e poi `{c.nome}.ferma()`.")
    return _chiedi(c, "riproduci", "Il registratore", percorso)


def _rete_aggiorna(c):
    """Controlla subito la rete e restituisce vero se il telefono (o il computer) è collegato."""
    _chiedi(c, "aggiorna", "Lo stato della rete")
    return bool(_valore(c, "connesso", False))


def _orientamento_blocca(c, orientamento="attuale"):
    """Blocca lo schermo in "verticale" o "orizzontale" ("attuale" = com'è adesso)."""
    o = _testo(orientamento, "L'orientamento").strip().lower()
    if o == "attuale":
        o = str(_valore(c, "orientamento", "verticale"))
    if o not in ("verticale", "orizzontale"):
        raise ErroreValore(f"`{orientamento}` non è un orientamento.",
                           suggerimento='Scrivi "verticale", "orizzontale" oppure "attuale".')
    _imposta(c, "blocco", o)


def _orientamento_sblocca(c):
    """Lo schermo torna a girare da solo quando giri il telefono."""
    _imposta(c, "blocco", "libero")


# ===========================================================================
# Tipi
# ===========================================================================

#: Dati degli eventi (chiavi del dizionario `evento` nel gestore) per ogni tipo.
DATI_EVENTI: dict[str, dict[str, tuple[str, ...]]] = {
    "Cruscotto": {"cambio_zona": ("zona", "valore")},
    "AnelloAvanzamento": {"completato": ("valore",)},
    "GraficoDalVivo": {"pausa": ("in_pausa",)},
    "TabellaOrdinabile": {"selezione": ("riga", "colonna", "valori"), "ordinamento": ("colonna", "crescente"),
                          "filtro": ("testo", "visibili")},
    "Contapassi": {"cambio": ("passi", "distanza"), "obiettivo_raggiunto": ("passi",)},
    "SensoreLuce": {"cambio": ("luce", "livello"), "buio": ("luce",), "luce": ("luce",)},
    "SensoreProssimità": {"avvicinamento": ("distanza",), "allontanamento": ("distanza",)},
    "Barometro": {"cambio": ("pressione", "altitudine", "tendenza")},
    "Movimento": {"scossa": ("forza", "scosse")},
    "Fonometro": {"cambio": ("livello",), "troppo_rumore": ("livello",)},
    "RegistratoreAudio": {"fine_registrazione": ("file", "durata"), "errore": ("messaggio",)},
    "StatoRete": {"cambio": ("connesso", "tipo_rete")},
    "OrientamentoSchermo": {"cambio": ("orientamento", "larghezza", "altezza")},
}

_INDICATORI = "Indicatori"
_DATI = "Dati"
_TELEFONO = "Telefono"


def tipi() -> list:
    """Gli oggetti di questo catalogo, come oggetti NUOVI a ogni chiamata."""
    return [
        # --- cruscotti -------------------------------------------------------------------------
        _t("Cruscotto", _INDICATORI, "Cruscotto a lancetta con le zone verde, gialla e rossa", 1, [
            _p("valore", "decimale", 0.0, "Il numero che la lancetta indica"),
            _p("minimo", "decimale", 0.0, "Valore all'inizio della scala"),
            _p("massimo", "decimale", 100.0, "Valore alla fine della scala"),
            _p("soglia_attenzione", "decimale", 60.0, "Da qui comincia la zona gialla"),
            _p("soglia_pericolo", "decimale", 80.0,
               "Da qui comincia la zona rossa (se è più bassa dell'attenzione il pericolo è in basso)"),
            _p("unita", "testo", "", "Unità di misura scritta sotto il numero (°C, km/h, %...)", "Aspetto"),
            _p("titolo", "testo", "", "Scritta sopra il cruscotto", "Aspetto"),
            _p("decimali", "intero", 0, "Cifre dopo la virgola del numero", "Aspetto", minimo=0, massimo=3),
            _p("colore", "colore", "", "Colore della lancetta; se non lo scegli, come il testo", "Aspetto"),
            _sl("zona", "testo", "normale", "Zona della lancetta: \"normale\", \"attenzione\" o \"pericolo\""),
        ], ("cambio_zona",), "cambio_zona", icona="cruscotto", dimensione=(200, 160)),
        _t("AnelloAvanzamento", _INDICATORI, "Barra di avanzamento rotonda, con la percentuale al centro", 1, [
            _p("valore", "decimale", 0.0, "Quanto è pieno l'anello"),
            _p("minimo", "decimale", 0.0, "Valore dell'anello vuoto"),
            _p("massimo", "decimale", 100.0, "Valore dell'anello pieno"),
            _p("testo", "testo", "", "Scritta al centro; se non lo scegli, la percentuale", "Aspetto"),
            _p("spessore", "intero", 10, "Spessore dell'anello in pixel", "Aspetto", minimo=2, massimo=60),
            _p("colore", "colore", "", "Colore della parte piena; se non lo scegli, colore del tema", "Aspetto"),
            _sl("completato", "logico", False, "Vero quando l'anello è pieno"),
        ], ("completato",), "completato", icona="anello", dimensione=(120, 120)),
        _t("GraficoDalVivo", _DATI, "Grafico a linee che scorre mentre arrivano i valori (sensori, misure...)", 1, [
            _p("dati", "dizionario", {}, "Le linee: {nome della serie: [valori]}"),
            _p("punti", "intero", 60, "Quanti valori si vedono (i più vecchi escono a sinistra)",
               "Comportamento", minimo=2, massimo=2000),
            _p("scala_automatica", "logico", True, "L'asse verticale si adatta da solo ai valori", "Comportamento"),
            _p("minimo", "decimale", 0.0, "Fondo dell'asse verticale (senza scala automatica)"),
            _p("massimo", "decimale", 100.0, "Cima dell'asse verticale (senza scala automatica)"),
            _p("titolo", "testo", "", "Scritta sopra il grafico", "Aspetto"),
            _p("unita", "testo", "", "Unità di misura accanto all'ultimo valore", "Aspetto"),
            _p("mostra_legenda", "logico", True, "Mostra i nomi delle linee", "Aspetto"),
            _p("in_pausa", "logico", False, "Se vero il disegno è fermo (toccalo per fermarlo o farlo ripartire)",
               "Comportamento"),
        ], ("pausa",), "pausa", icona="grafico_vivo", dimensione=(320, 200),
           metodi={"aggiungi": _grafico_aggiungi, "aggiungi_valori": _grafico_aggiungi_valori,
                   "svuota": _grafico_svuota, "pausa": _grafico_pausa, "riprendi": _grafico_riprendi}),
        _t("TabellaOrdinabile", _DATI, "Tabella che si ordina toccando le intestazioni e si filtra scrivendo", 1, [
            _p("colonne", "lista", ["Nome", "Valore"], "Titoli delle colonne"),
            _p("righe", "lista", [], "Le righe: una lista per riga"),
            _p("filtro", "testo", "", "Si vedono solo le righe che contengono queste parole"),
            _p("mostra_filtro", "logico", True, "Mostra la casella per cercare sopra la tabella", "Aspetto"),
            _p("colonna_ordinata", "intero", -1, "Colonna usata per ordinare (-1 = ordine delle righe)",
               minimo=-1),
            _p("crescente", "logico", True, "Vero: dal più piccolo al più grande (A-Z); falso: al contrario"),
            _p("riga_selezionata", "intero", -1, "Numero della riga scelta, come in `righe` (-1 = nessuna)",
               minimo=-1),
        ], ("selezione", "ordinamento", "filtro"), "selezione", icona="tabella_ordinabile", dimensione=(320, 240),
           metodi={"aggiungi_riga": _tab_aggiungi_riga, "rimuovi_riga": _tab_rimuovi_riga, "ordina": _tab_ordina,
                   "filtra": _tab_filtra, "svuota": _tab_svuota, "righe_visibili": _tab_righe_visibili,
                   "riga": _tab_riga}),
        # --- sensori del telefono ----------------------------------------------------------------
        _t("Contapassi", _TELEFONO, "Conta i passi mentre cammini, con l'anello dell'obiettivo", 1, [
            _sl("passi", "intero", 0, "Passi fatti da quando la finestra è aperta (o da `azzera()`)"),
            _sl("distanza", "decimale", 0.0, "Chilometri percorsi (passi × lunghezza del passo)"),
            _p("obiettivo", "intero", 6000, "Passi da fare: l'anello si riempie", minimo=1, massimo=1_000_000),
            _p("lunghezza_passo", "decimale", 0.7, "Lunghezza di un passo in metri", minimo=0.2, massimo=2.0),
            _p("colore", "colore", "", "Colore dell'anello; se non lo scegli, colore del tema", "Aspetto"),
        ], ("cambio", "obiettivo_raggiunto"), "cambio", icona="contapassi", dimensione=(180, 180),
           metodi={"azzera": _contapassi_azzera}),
        _t("SensoreLuce", _TELEFONO, "Misura quanta luce c'è intorno al telefono (in lux)", 1, [
            _sl("luce", "decimale", 0.0, "Luce misurata in lux (buio 0, stanza 300, sole 30000)"),
            _sl("livello", "testo", "luce", "A parole: \"buio\", \"poca luce\", \"luce\" o \"sole\""),
            _p("soglia_buio", "decimale", 10.0, "Sotto questi lux arriva l'evento `buio`", minimo=0),
            _p("intervallo", "intero", 500, "Millisecondi tra una lettura e l'altra", "Comportamento",
               minimo=50, massimo=60000),
        ], ("cambio", "buio", "luce"), "cambio", icona="sensore_luce", dimensione=(160, 90)),
        _t("SensoreProssimità", _TELEFONO,
           "Si accorge quando qualcosa si avvicina allo schermo (la mano, l'orecchio)", 1, [
            _sl("vicino", "logico", False, "Vero quando qualcosa è vicino allo schermo"),
            _sl("distanza", "decimale", -1.0, "Distanza in centimetri (-1 = non ancora letta; molti telefoni "
                                              "dicono solo 0 = vicino o 5 = lontano)"),
            _p("intervallo", "intero", 200, "Millisecondi tra una lettura e l'altra", "Comportamento",
               minimo=50, massimo=60000),
        ], ("avvicinamento", "allontanamento"), "avvicinamento", icona="prossimita", dimensione=(100, 100)),
        _t("Barometro", _TELEFONO, "Misura la pressione dell'aria e stima l'altezza sul mare", 1, [
            _sl("pressione", "decimale", 0.0, "Pressione dell'aria in hPa (al mare circa 1013)"),
            _sl("altitudine", "decimale", 0.0, "Altezza sul mare stimata dalla pressione, in metri"),
            _sl("tendenza", "testo", "stabile",
                "\"sale\" (bel tempo), \"scende\" (brutto tempo in arrivo) o \"stabile\""),
            _p("pressione_mare", "decimale", 1013.25, "Pressione al livello del mare oggi (per l'altitudine)",
               minimo=800, massimo=1100),
            _p("intervallo", "intero", 1000, "Millisecondi tra una lettura e l'altra", "Comportamento",
               minimo=100, massimo=60000),
        ], ("cambio",), "cambio", icona="barometro", dimensione=(180, 180)),
        _t("Movimento", _TELEFONO, "Invisibile: si accorge quando scuoti il telefono", 1, [
            _p("sensibilita", "scelta", "media", "Quanto forte scuotere: \"alta\" basta poco, \"bassa\" serve forza",
               "Comportamento", scelte=("bassa", "media", "alta")),
            _sl("scosse", "intero", 0, "Quante volte hai scosso il telefono"),
            _sl("forza", "decimale", 0.0, "Forza dell'ultima scossa (1 = peso normale)"),
        ], ("scossa",), "scossa", icona="movimento", invisibile=True, metodi={"azzera": _movimento_azzera}),
        # --- microfono, rete, schermo -----------------------------------------------------------------
        _t("Fonometro", _TELEFONO, "Misura quanto rumore c'è con il microfono (in decibel)", 1, [
            _sl("livello", "decimale", 0.0, "Rumore adesso in decibel (sussurro 30, voce 60, urlo 90)"),
            _sl("massimo", "decimale", 0.0, "Il rumore più forte misurato"),
            _p("attivo", "logico", False, "Vero mentre ascolta (toccalo per accenderlo o spegnerlo)",
               "Comportamento"),
            _p("soglia", "decimale", 85.0, "Sopra questi decibel arriva l'evento `troppo_rumore`",
               minimo=0, massimo=140),
        ], ("cambio", "troppo_rumore"), "troppo_rumore", icona="fonometro", dimensione=(200, 130),
           metodi={"avvia": _fonometro_avvia, "ferma": _fonometro_ferma, "azzera": _fonometro_azzera}),
        _t("RegistratoreAudio", _TELEFONO, "Registra la voce con il microfono e la fa riascoltare", 1, [
            _sl("registrando", "logico", False, "Vero mentre registra"),
            _sl("durata", "decimale", 0.0, "Secondi registrati (dell'ultima registrazione)"),
            _sl("ultimo_file", "testo", "", "Il file dell'ultima registrazione"),
            _p("cartella", "testo", "registrazioni", "Cartella del progetto dove vanno le registrazioni",
               "Comportamento"),
            _p("durata_massima", "intero", 300, "Dopo tanti secondi la registrazione si ferma da sola",
               "Comportamento", minimo=1, massimo=3600),
        ], ("fine_registrazione", "errore"), "fine_registrazione", icona="registratore", dimensione=(240, 76),
           metodi={"registra": _registratore_registra, "ferma": _registratore_ferma,
                   "riproduci": _registratore_riproduci}),
        _t("StatoRete", _TELEFONO, "Invisibile: dice se il telefono è collegato (Wi-Fi, dati mobili o niente)", 1, [
            _sl("connesso", "logico", False, "Vero se c'è una rete"),
            _sl("tipo_rete", "testo", "sconosciuto", "\"wifi\", \"dati\", \"cavo\", \"nessuna\" o \"altro\""),
            _sl("a_consumo", "logico", False, "Vero se la rete si paga a consumo (di solito i dati mobili)"),
        ], ("cambio",), "cambio", icona="stato_rete", invisibile=True, metodi={"aggiorna": _rete_aggiorna}),
        _t("OrientamentoSchermo", _TELEFONO, "Invisibile: dice se il telefono è in verticale o in orizzontale", 1, [
            _sl("orientamento", "testo", "verticale", "\"verticale\" o \"orizzontale\""),
            _p("blocco", "scelta", "libero", "\"libero\" gira con il telefono; \"verticale\" o \"orizzontale\" "
                                             "tiene fermo lo schermo", "Comportamento",
               scelte=("libero", "verticale", "orizzontale")),
        ], ("cambio",), "cambio", icona="orientamento", invisibile=True,
           metodi={"blocca": _orientamento_blocca, "sblocca": _orientamento_sblocca}),
    ]


#: Nomi dei tipi di questo catalogo.
TIPI_DATI_TELEFONO: tuple[str, ...] = tuple(t.nome for t in tipi())

for _tipo in tipi():
    registra(_tipo)
del _tipo
