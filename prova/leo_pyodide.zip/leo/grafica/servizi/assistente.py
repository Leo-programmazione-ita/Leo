"""Chat con un modello di intelligenza artificiale (API Messages di Anthropic), senza Qt.

La chiave API si cerca, in ordine:
    1. l'argomento ``chiave`` (proprieta' ``chiave_api`` del controllo);
    2. la variabile d'ambiente ``ANTHROPIC_API_KEY``;
    3. il file ``cartella_utente()/assistente.toml`` con ``chiave = "..."``
       (e facoltativi ``modello = "..."``, ``istruzioni = "..."``).

API::

    class Assistente(chiave="", modello="", istruzioni=""):
        chiedi(domanda) -> str     # blocca (rete): usala in un thread
        storia                     # [{"ruolo": "utente"|"assistente", "testo": ...}, ...]
        azzera()
        disponibile() -> bool      # c'e' una chiave?

Gli errori sono ``ErroreValore`` in italiano; la chiave non compare MAI nei
messaggi (ne' in ``repr``).
"""

from __future__ import annotations

import json
import os
import socket
import urllib.error
import urllib.request
from pathlib import Path

from ...errori import ErroreTipo, ErroreValore

INDIRIZZO_API = "https://api.anthropic.com/v1/messages"
VERSIONE_API = "2023-06-01"
MODELLO_PREDEFINITO = "claude-sonnet-4-5"
TOKEN_MASSIMI = 1024
TEMPO_MASSIMO = 60.0
#: Quanti scambi (domanda + risposta) si mandano al modello al massimo.
SCAMBI_MASSIMI = 20

ISTRUZIONI_PREDEFINITE = (
    "Sei un assistente dentro un programma scritto con Leo, un linguaggio di "
    "programmazione in italiano. Rispondi sempre in italiano, in modo chiaro, "
    "gentile e breve, adatto anche a chi sta imparando."
)

NOME_FILE_CONFIGURAZIONE = "assistente.toml"


def _file_configurazione() -> Path | None:
    try:
        from ...percorsi import cartella_utente

        return cartella_utente() / NOME_FILE_CONFIGURAZIONE
    except Exception:
        return None


def _leggi_configurazione() -> dict:
    """Contenuto di ``assistente.toml`` (dizionario vuoto se manca o e' rotto)."""
    percorso = _file_configurazione()
    if percorso is None or not percorso.is_file():
        return {}
    try:
        from ...tomlutil import carica_toml

        dati = carica_toml(percorso)
    except Exception:
        return {}
    if isinstance(dati.get("assistente"), dict):  # accetta anche una sezione [assistente]
        dati = {**dati, **dati["assistente"]}
    return dati if isinstance(dati, dict) else {}


class Assistente:
    """Una conversazione con il modello; ricorda le domande e le risposte."""

    def __init__(self, chiave: str = "", modello: str = "", istruzioni: str = "", *,
                 indirizzo: str = INDIRIZZO_API, tempo_massimo: float = TEMPO_MASSIMO) -> None:
        for nome, v in (("chiave", chiave), ("modello", modello), ("istruzioni", istruzioni)):
            if not isinstance(v, str):
                raise ErroreTipo(f"`{nome}` dell'assistente deve essere un testo.")
        configurazione: dict | None = None

        def config() -> dict:
            nonlocal configurazione
            if configurazione is None:
                configurazione = _leggi_configurazione()
            return configurazione

        self._chiave = chiave.strip() or os.environ.get("ANTHROPIC_API_KEY", "").strip() \
            or str(config().get("chiave", "") or "").strip()
        self.modello = modello.strip() or str(config().get("modello", "") or "").strip() or MODELLO_PREDEFINITO
        self.istruzioni = istruzioni.strip() or str(config().get("istruzioni", "") or "").strip() \
            or ISTRUZIONI_PREDEFINITE
        self.indirizzo = indirizzo
        self.tempo_massimo = tempo_massimo
        self.storia: list[dict] = []

    def __repr__(self) -> str:
        return f"<Assistente modello={self.modello!r} chiave={'presente' if self._chiave else 'assente'}>"

    # --- stato ----------------------------------------------------------------
    def disponibile(self) -> bool:
        return bool(self._chiave)

    def azzera(self) -> None:
        """Dimentica la conversazione."""
        self.storia = []

    def _nascondi(self, testo: str) -> str:
        """Toglie la chiave da un testo (per sicurezza, prima di mostrarlo)."""
        if self._chiave and self._chiave in testo:
            testo = testo.replace(self._chiave, "***")
        return testo

    # --- richiesta ----------------------------------------------------------------
    def _messaggi(self, domanda: str) -> list[dict]:
        precedenti = self.storia[-2 * SCAMBI_MASSIMI:]
        messaggi = [{"role": "user" if m["ruolo"] == "utente" else "assistant", "content": m["testo"]}
                    for m in precedenti]
        messaggi.append({"role": "user", "content": domanda})
        return messaggi

    def chiedi(self, domanda) -> str:
        """Manda la domanda (con la conversazione precedente) e restituisce la risposta."""
        if not isinstance(domanda, str):
            raise ErroreTipo("La domanda per l'assistente deve essere un testo.")
        if not domanda.strip():
            raise ErroreValore("La domanda per l'assistente è vuota.")
        if not self._chiave:
            percorso = _file_configurazione()
            dove = f" o nel file `{percorso}`" if percorso else ""
            raise ErroreValore(
                "Manca la chiave API dell'assistente.",
                suggerimento="Scrivila nella proprietà `chiave_api`, nella variabile d'ambiente "
                f"`ANTHROPIC_API_KEY`{dove} (riga `chiave = \"...\"`).")
        corpo = {
            "model": self.modello,
            "max_tokens": TOKEN_MASSIMI,
            "system": self.istruzioni,
            "messages": self._messaggi(domanda),
        }
        richiesta = urllib.request.Request(
            self.indirizzo,
            data=json.dumps(corpo).encode("utf-8"),
            headers={
                "x-api-key": self._chiave,
                "anthropic-version": VERSIONE_API,
                "content-type": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(richiesta, timeout=self.tempo_massimo) as risposta:
                grezzo = risposta.read()
        except urllib.error.HTTPError as e:
            raise self._errore_http(e) from None
        except urllib.error.URLError as e:
            if isinstance(getattr(e, "reason", None), (socket.timeout, TimeoutError)):
                raise ErroreValore("L'assistente non ha risposto in tempo.",
                                   suggerimento="Riprova tra poco.") from None
            raise ErroreValore("Non riesco a collegarmi al servizio dell'assistente.",
                               suggerimento="Controlla la connessione a Internet.") from None
        except (socket.timeout, TimeoutError):
            raise ErroreValore("L'assistente non ha risposto in tempo.", suggerimento="Riprova tra poco.") from None
        except OSError:
            raise ErroreValore("Non riesco a collegarmi al servizio dell'assistente.",
                               suggerimento="Controlla la connessione a Internet.") from None
        testo = self._testo_risposta(grezzo)
        self.storia.append({"ruolo": "utente", "testo": domanda})
        self.storia.append({"ruolo": "assistente", "testo": testo})
        return testo

    def _testo_risposta(self, grezzo: bytes) -> str:
        try:
            dati = json.loads(grezzo.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise ErroreValore("L'assistente ha mandato una risposta che non capisco.") from None
        if not isinstance(dati, dict) or not isinstance(dati.get("content"), list):
            raise ErroreValore("L'assistente ha mandato una risposta che non capisco.")
        parti = [b.get("text", "") for b in dati["content"]
                 if isinstance(b, dict) and b.get("type") == "text" and isinstance(b.get("text"), str)]
        return self._nascondi("".join(parti).strip())

    def _errore_http(self, e: urllib.error.HTTPError) -> ErroreValore:
        dettaglio = ""
        try:
            dati = json.loads(e.read().decode("utf-8"))
            dettaglio = str(dati.get("error", {}).get("message", "")) if isinstance(dati, dict) else ""
        except Exception:
            dettaglio = ""
        dettaglio = self._nascondi(dettaglio)
        codice = e.code
        if codice == 401:
            return ErroreValore("La chiave API dell'assistente non è valida.",
                                suggerimento="Controlla di averla copiata per intero, senza spazi.")
        if codice == 403:
            return ErroreValore("La chiave API non ha il permesso di usare questo modello.",
                                suggerimento=f"Controlla il nome del modello (`{self.modello}`) e il tuo account.")
        if codice == 404:
            return ErroreValore(f"Il modello `{self.modello}` non esiste.",
                                suggerimento="Lascia vuota la proprietà `modello` per usare quello predefinito.")
        if codice == 429:
            return ErroreValore("Troppe richieste all'assistente in poco tempo.",
                                suggerimento="Aspetta qualche secondo e riprova.")
        if codice == 400:
            testo = "La richiesta all'assistente non è valida"
            return ErroreValore(testo + (f": {dettaglio}" if dettaglio else "."))
        if codice in (500, 502, 503, 504, 529):
            return ErroreValore("Il servizio dell'assistente è sovraccarico o non disponibile.",
                                suggerimento="Riprova più tardi.")
        return ErroreValore(f"L'assistente ha risposto con un errore ({codice})"
                            + (f": {dettaglio}" if dettaglio else "."))


def disponibile(chiave: str = "") -> bool:
    """Vero se c'e' una chiave API (argomento, variabile d'ambiente o file)."""
    return Assistente(chiave).disponibile()


__all__ = ["Assistente", "disponibile", "MODELLO_PREDEFINITO", "ISTRUZIONI_PREDEFINITE"]
