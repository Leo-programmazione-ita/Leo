"""Archivio SQLite con comandi in italiano (controllo ``BancaDati``).

API:

    class BancaDati(percorso=":memory:"):
        crea_tabella(nome, colonne: dict)
        inserisci(tabella, riga: dict) -> int
        cerca(tabella, condizioni=None, ordina="", limite=0) -> list[dict]
        aggiorna(tabella, condizioni, valori) -> int
        elimina(tabella, condizioni) -> int
        esegui(sql, parametri=None) -> list[dict]
        conta(tabella, condizioni=None) -> int
        elimina_tabella(nome) -> bool
        inizia_transazione(), conferma(), annulla(), in_transazione
        tabelle() -> list[str]
        colonne(tabella) -> dict[str, str]
        chiudi()

Tipi delle colonne (valori di ``colonne``): ``intero``, ``decimale``,
``testo``, ``logico`` (anche ``sì/no``), ``data``, eventualmente seguiti da
``chiave`` (chiave primaria), ``obbligatorio`` (non nullo), ``unico`` e
``collegato TABELLA`` (la colonna contiene l'``id`` di una riga di un'altra
tabella); esempio
``{"nome": "testo obbligatorio", "età": "intero"}``. Se non c'è una colonna
``id``, ne viene aggiunta una automatica (intero crescente) che ``inserisci``
restituisce.

Condizioni: dizionario ``colonna -> valore`` (uguaglianza; ``nulla`` = vuoto)
oppure ``colonna -> [operatore, valore]`` con operatori ``=``, ``!=``, ``<``,
``>``, ``<=``, ``>=``, ``come`` (LIKE con ``%``), ``contiene``,
``inizia``, ``finisce``, ``tra`` (``["tra", a, b]``), ``in``
(``["in", [a, b, c]]``). Tutte le condizioni devono valere insieme.

Ordinamento: ``"nome"``, ``"età discendente"`` (anche ``"-età"`` o
``"età desc"``), più colonne separate da virgole.

I risultati sono valori Leo: liste di dizionari con testi, interi,
decimali, logici e ``nulla``.

Date: nelle colonne ``data`` si salva il testo ISO ``AAAA-MM-GG`` (con
`` HH:MM:SS`` se c'è un orario), così l'ordine alfabetico è quello del
calendario. Si possono passare oggetti ``datetime``/``date``, valori con un
attributo ``valore`` di tipo ``datetime`` (la ``data`` di Leo) oppure testi
``"25/09/2026"``. In lettura le date restano testi ISO, a meno che
``converti_data`` (una funzione testo ISO -> valore) sia impostato: la
libreria di Leo lo usa per restituire valori ``data``.
"""

from __future__ import annotations

import datetime
import re
import sqlite3
import threading
from os import PathLike, fspath
from typing import Any, Union

from ...errori import ErroreFile, ErroreTipo, ErroreValore

__all__ = ["BancaDati", "TIPI_COLONNA"]

#: Tipo Leo -> tipo dichiarato in SQLite.
TIPI_COLONNA: dict[str, str] = {
    "intero": "INTEGER",
    "decimale": "REAL",
    "testo": "TEXT",
    "logico": "LOGICO",  # affinità NUMERIC: si salva 0/1, si rilegge come logico
    "data": "DATA",      # affinità NUMERIC: si salva il testo ISO AAAA-MM-GG[ HH:MM:SS]
}

_SINONIMI_TIPO = {"numero": "decimale", "reale": "decimale", "stringa": "testo",
                  "booleano": "logico", "integer": "intero", "int": "intero",
                  "real": "decimale", "float": "decimale", "text": "testo",
                  "bool": "logico", "boolean": "logico", "sì/no": "logico", "si/no": "logico",
                  "sì_no": "logico", "si_no": "logico", "vero/falso": "logico",
                  "data_ora": "data", "date": "data", "datetime": "data", "giorno": "data"}

_MODIFICATORI = {"chiave": "PRIMARY KEY", "obbligatorio": "NOT NULL", "obbligatoria": "NOT NULL",
                 "unico": "UNIQUE", "unica": "UNIQUE"}
_COLLEGAMENTO = {"collegato", "collegata", "collegato_a", "collegata_a"}

_IDENTIFICATORE = re.compile(r"^[^\W\d]\w*$")

_OPERATORI = {"=": "=", "==": "=", "!=": "!=", "<>": "!=", "<": "<", ">": ">",
              "<=": "<=", ">=": ">="}

_DISCENDENTE = {"discendente", "decrescente", "desc", "giù", "giu"}
_ASCENDENTE = {"ascendente", "crescente", "asc", "su"}


def _identificatore(nome: Any, cosa: str = "tabella") -> str:
    if not isinstance(nome, str):
        raise ErroreTipo(f"Il nome della {cosa} deve essere un testo.")
    nome = nome.strip()
    if not _IDENTIFICATORE.match(nome) or nome.lower().startswith("sqlite_"):
        raise ErroreValore(
            f"`{nome}` non è un nome valido per una {cosa}.",
            suggerimento="Usa lettere, cifre e trattini bassi, cominciando con una lettera "
                         "(per esempio `studenti` o `voto_finale`).")
    return nome


def _q(nome: str) -> str:
    return '"' + nome.replace('"', '""') + '"'


def _testo_data(v: "datetime.date") -> str:
    """Data (o data e ora) -> testo ISO che si ordina come il calendario."""
    testo = f"{v.year:04d}-{v.month:02d}-{v.day:02d}"
    if isinstance(v, datetime.datetime) and (v.hour or v.minute or v.second):
        testo += f" {v.hour:02d}:{v.minute:02d}:{v.second:02d}"
    return testo


_RE_DATA_ITALIANA = re.compile(
    r"^\s*(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})(?:[ T,]+(\d{1,2})[:.](\d{2})(?:[:.](\d{2}))?)?\s*$")
_RE_DATA_ISO = re.compile(r"^\s*(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?\s*$")


def data_da_testo(testo: str) -> "datetime.datetime | None":
    """``"25/09/2026"``, ``"2026-09-25"`` (con ora facoltativa) -> datetime; None se non è una data."""
    m = _RE_DATA_ITALIANA.match(testo)
    if m:
        g, me, a = int(m.group(1)), int(m.group(2)), int(m.group(3))
    else:
        m = _RE_DATA_ISO.match(testo)
        if not m:
            return None
        a, me, g = int(m.group(1)), int(m.group(2)), int(m.group(3))
    try:
        return datetime.datetime(a, me, g, int(m.group(4) or 0), int(m.group(5) or 0), int(m.group(6) or 0))
    except ValueError:
        return None


def _valore_in(valore: Any, colonna: str = "") -> Any:
    """Valore Leo -> valore SQLite."""
    if valore is None or isinstance(valore, (int, float, str)):
        return int(valore) if isinstance(valore, bool) else valore
    if isinstance(valore, datetime.date):
        return _testo_data(valore)
    interno = getattr(valore, "valore", None)
    if isinstance(interno, datetime.date) and getattr(valore, "NOME_TIPO_DANTE", "") == "data":
        return _testo_data(interno)
    dove = f" nella colonna `{colonna}`" if colonna else ""
    tipo = "una lista" if isinstance(valore, list) else (
        "un dizionario" if isinstance(valore, dict) else f"un valore di tipo {type(valore).__name__}")
    raise ErroreTipo(
        f"Non posso salvare {tipo}{dove}: la banca dati contiene solo interi, decimali, "
        "testi, logici o nulla.",
        suggerimento="Trasforma il valore in testo con `testo(...)` prima di salvarlo.")


def _valore_out(valore: Any) -> Any:
    if isinstance(valore, bytes):
        return valore.decode("utf-8", errors="replace")
    return valore


def _traduci(e: Exception, contesto: str = "") -> Exception:
    """Errore sqlite3 -> errore Leo in italiano."""
    testo = str(e)
    minuscolo = testo.lower()
    prefisso = f"{contesto}: " if contesto else ""
    m = re.search(r"no such table: (\S+)", testo)
    if m:
        return ErroreValore(f"{prefisso}la tabella `{m.group(1)}` non esiste.",
                            suggerimento="Creala prima con `crea_tabella`.")
    m = re.search(r"no such column: (\S+)", testo)
    if not m:
        m = re.search(r"has no column named (\S+)", testo)
    if m:
        return ErroreValore(f"{prefisso}la colonna `{m.group(1)}` non esiste.",
                            suggerimento="Controlla il nome della colonna (maiuscole e accenti contano).")
    if isinstance(e, sqlite3.IntegrityError):
        if "unique" in minuscolo or "primary key" in minuscolo:
            return ErroreValore(f"{prefisso}esiste già una riga con lo stesso valore "
                                f"({testo.split(':', 1)[-1].strip()}).",
                                suggerimento="Quella colonna è `unico` o `chiave`: usa un valore diverso.")
        if "not null" in minuscolo:
            return ErroreValore(f"{prefisso}manca un valore obbligatorio "
                                f"({testo.split(':', 1)[-1].strip()}).")
        if "foreign key" in minuscolo:
            return ErroreValore(f"{prefisso}il collegamento punta a una riga che non esiste "
                                "(o altre righe dipendono da questa).",
                                suggerimento="Controlla l'`id` della riga collegata.")
        return ErroreValore(f"{prefisso}dati non accettati: {testo}.")
    if "already exists" in minuscolo:
        return ErroreValore(f"{prefisso}esiste già: {testo}.")
    if "syntax error" in minuscolo or "incomplete input" in minuscolo:
        return ErroreValore(f"{prefisso}il comando SQL contiene un errore ({testo}).",
                            suggerimento="Controlla virgole, apici e parole chiave del comando SQL.")
    if "one statement at a time" in minuscolo:
        return ErroreValore(f"{prefisso}si può eseguire un solo comando SQL alla volta.",
                            suggerimento="Togli il `;` in mezzo e dividi il testo in più chiamate.")
    if "bindings" in minuscolo or "parameter" in minuscolo:
        return ErroreValore(f"{prefisso}il numero di parametri non corrisponde ai `?` del comando "
                            f"({testo}).")
    if isinstance(e, sqlite3.OperationalError) and (
            "unable to open" in minuscolo or "readonly" in minuscolo or "disk" in minuscolo
            or "locked" in minuscolo):
        return ErroreFile(f"{prefisso}problema con il file della banca dati ({testo}).",
                          suggerimento="Controlla che il file esista, sia scrivibile e non sia "
                                       "aperto da un altro programma.")
    if isinstance(e, sqlite3.DatabaseError) and ("not a database" in minuscolo
                                                 or "malformed" in minuscolo):
        return ErroreFile(f"{prefisso}il file non è una banca dati valida ({testo}).")
    if isinstance(e, sqlite3.ProgrammingError) and "closed" in minuscolo:
        return ErroreValore("La banca dati è chiusa.")
    return ErroreValore(f"{prefisso}errore della banca dati: {testo}.")


class BancaDati:
    """Archivio SQLite (``:memory:`` = solo in memoria, altrimenti un file)."""

    def __init__(self, percorso: Union[str, "PathLike[str]"] = ":memory:") -> None:
        try:
            self.percorso = fspath(percorso)
        except TypeError:
            raise ErroreTipo("Il percorso della banca dati deve essere un testo.") from None
        self._blocco = threading.RLock()
        try:
            self._connessione: sqlite3.Connection | None = sqlite3.connect(
                self.percorso, check_same_thread=False)
            # verifica subito che il file sia davvero una banca dati
            self._connessione.execute("SELECT name FROM sqlite_master LIMIT 1").fetchall()
        except sqlite3.Error as e:
            raise ErroreFile(
                f"Non riesco ad aprire la banca dati `{self.percorso}` ({e}).",
                suggerimento="Controlla che la cartella esista e che il file sia una banca dati "
                             "SQLite.") from None
        self._cache_colonne: dict[str, dict[str, str]] = {}
        #: vero tra ``inizia_transazione`` e ``conferma``/``annulla``
        self._transazione = False
        #: se impostata, trasforma i testi ISO delle colonne ``data`` letti da ``cerca``
        self.converti_data: Any = None

    # -- utilità interne -----------------------------------------------------
    def _conn(self) -> sqlite3.Connection:
        if self._connessione is None:
            raise ErroreValore("La banca dati è chiusa.",
                               suggerimento="Crea una nuova banca dati per continuare.")
        return self._connessione

    def _esegui(self, sql: str, parametri: Any = (), contesto: str = "") -> sqlite3.Cursor:
        conn = self._conn()
        try:
            cursore = conn.execute(sql, parametri)
            if conn.in_transaction and not self._transazione:
                conn.commit()
            return cursore
        except sqlite3.Error as e:
            # dentro una transazione esplicita decide chi l'ha aperta (conferma/annulla):
            # SQLite ha già annullato il solo comando fallito
            if conn.in_transaction and not self._transazione:
                conn.rollback()
            raise _traduci(e, contesto) from None

    def _info(self, tabella: str) -> dict[str, str]:
        """Colonne della tabella -> tipo dichiarato (in maiuscolo), con cache."""
        if tabella not in self._cache_colonne:
            righe = self._esegui(f"PRAGMA table_info({_q(tabella)})").fetchall()
            self._cache_colonne[tabella] = {r[1]: str(r[2]).upper() for r in righe}
        return self._cache_colonne[tabella]

    def _colonne_logiche(self, tabella: str) -> set[str]:
        return {c for c, t in self._info(tabella).items() if t == "LOGICO"}

    def _colonne_data(self, tabella: str) -> set[str]:
        return {c for c, t in self._info(tabella).items() if t == "DATA"}

    def _valore_per(self, tabella: str, colonna: str, valore: Any) -> Any:
        """Come ``_valore_in``, ma nelle colonne ``data`` un testo come "25/09/2026" diventa ISO."""
        if isinstance(valore, str) and self._info(tabella).get(colonna) == "DATA":
            d = data_da_testo(valore)
            if d is not None:
                return _testo_data(d)
        return _valore_in(valore, colonna)

    def _colonna(self, tabella: str, colonna: Any) -> str:
        """Valida il nome e verifica che la colonna esista davvero.

        (SQLite tratterebbe un nome sconosciuto tra virgolette come un testo.)
        """
        nome = _identificatore(colonna, "colonna")
        info = self._info(tabella)
        if nome not in info:
            raise ErroreValore(
                f"La colonna `{nome}` non esiste nella tabella `{tabella}`.",
                suggerimento="Colonne presenti: " + ", ".join(f"`{c}`" for c in info) + ".")
        return nome

    def _richiedi_tabella(self, tabella: Any) -> str:
        nome = _identificatore(tabella)
        riga = self._esegui("SELECT 1 FROM sqlite_master WHERE type IN ('table','view') AND name = ?",
                            (nome,)).fetchone()
        if riga is None:
            esistenti = self.tabelle()
            raise ErroreValore(
                f"La tabella `{nome}` non esiste.",
                suggerimento=("Tabelle presenti: " + ", ".join(f"`{t}`" for t in esistenti) + "."
                              if esistenti else "Creala prima con `crea_tabella`."))
        return nome

    def _righe(self, cursore: sqlite3.Cursor, logiche: set[str] | None = None,
               date: set[str] | None = None) -> list[dict]:
        if cursore.description is None:
            return []
        nomi = [d[0] for d in cursore.description]
        risultato = []
        for riga in cursore.fetchall():
            voce = {}
            for nome, valore in zip(nomi, riga):
                valore = _valore_out(valore)
                if logiche and nome in logiche and valore is not None:
                    valore = bool(valore)
                elif date and nome in date and isinstance(valore, str) and self.converti_data:
                    d = data_da_testo(valore)
                    if d is not None:
                        valore = self.converti_data(d)
                voce[nome] = valore
            risultato.append(voce)
        return risultato

    def _dove(self, tabella: str, condizioni: Any, valida: Any = None) -> tuple[str, list]:
        """Condizioni -> (" WHERE ...", parametri). ``valida(colonna)`` (facoltativo) controlla i
        nomi al posto delle colonne di ``tabella`` (per esempio nei risultati di un'unione)."""
        if condizioni is None:
            return "", []
        if not isinstance(condizioni, dict):
            raise ErroreTipo(
                "Le condizioni devono essere un dizionario, per esempio {\"età\": [\">\", 18]}.")
        pezzi: list[str] = []
        parametri: list = []
        for colonna, condizione in condizioni.items():
            vero_nome = valida(colonna) if valida else self._colonna(tabella, colonna)
            nome = _q(vero_nome)

            def dentro(v: Any) -> Any:
                return _valore_in(v, vero_nome) if valida else self._valore_per(tabella, vero_nome, v)

            if isinstance(condizione, tuple):
                condizione = list(condizione)
            if not isinstance(condizione, list):
                if condizione is None:
                    pezzi.append(f"{nome} IS NULL")
                else:
                    pezzi.append(f"{nome} = ?")
                    parametri.append(dentro(condizione))
                continue
            if not condizione or not isinstance(condizione[0], str):
                raise ErroreValore(
                    f"Condizione non valida per `{colonna}`: serve [operatore, valore].",
                    suggerimento="Esempi: [\">\", 18], [\"contiene\", \"ros\"], [\"tra\", 1, 10].")
            operatore = condizione[0].strip().lower()
            argomenti = condizione[1:]

            def uno() -> Any:
                if len(argomenti) != 1:
                    raise ErroreValore(
                        f"L'operatore `{operatore}` su `{colonna}` vuole esattamente un valore.")
                return argomenti[0]

            if operatore in _OPERATORI:
                valore = uno()
                if valore is None and _OPERATORI[operatore] in ("=", "!="):
                    pezzi.append(f"{nome} IS {'NOT ' if _OPERATORI[operatore] == '!=' else ''}NULL")
                else:
                    pezzi.append(f"{nome} {_OPERATORI[operatore]} ?")
                    parametri.append(dentro(valore))
            elif operatore in ("come", "like"):
                pezzi.append(f"{nome} LIKE ?")
                parametri.append(_valore_in(uno(), colonna))
            elif operatore in ("contiene", "inizia", "finisce"):
                valore = uno()
                if not isinstance(valore, str):
                    raise ErroreTipo(f"L'operatore `{operatore}` vuole un testo.")
                scappato = valore.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
                modello = {"contiene": f"%{scappato}%", "inizia": f"{scappato}%",
                           "finisce": f"%{scappato}"}[operatore]
                pezzi.append(f"{nome} LIKE ? ESCAPE '\\'")
                parametri.append(modello)
            elif operatore == "tra":
                if len(argomenti) != 2:
                    raise ErroreValore(f"`tra` su `{colonna}` vuole due valori: [\"tra\", minimo, massimo].")
                pezzi.append(f"{nome} BETWEEN ? AND ?")
                parametri.extend(dentro(v) for v in argomenti)
            elif operatore in ("in", "fra"):
                valori = uno()
                if not isinstance(valori, (list, tuple)) or not valori:
                    raise ErroreValore(f"`in` su `{colonna}` vuole una lista non vuota di valori.")
                pezzi.append(f"{nome} IN ({', '.join('?' * len(valori))})")
                parametri.extend(dentro(v) for v in valori)
            else:
                raise ErroreValore(
                    f"Operatore `{condizione[0]}` sconosciuto nella condizione su `{colonna}`.",
                    suggerimento="Operatori: =, !=, <, >, <=, >=, come, contiene, inizia, "
                                 "finisce, tra, in.")
        if not pezzi:
            return "", []
        return " WHERE " + " AND ".join(pezzi), parametri

    def _ordine(self, tabella: str, ordina: Any, valida: Any = None) -> str:
        if not ordina:
            return ""
        if isinstance(ordina, list):
            parti = [str(p) for p in ordina]
        elif isinstance(ordina, str):
            parti = ordina.split(",")
        else:
            raise ErroreTipo("`ordina` deve essere un testo, per esempio \"età discendente\".")
        pezzi = []
        for parte in parti:
            parole = parte.split()
            if not parole:
                continue
            nome = parole[0]
            direzione = "ASC"
            if nome.startswith("-"):
                nome, direzione = nome[1:], "DESC"
            elif nome.startswith("+"):
                nome = nome[1:]
            if len(parole) > 2:
                raise ErroreValore(f"Ordinamento `{parte.strip()}` non valido.",
                                   suggerimento="Esempio: \"cognome, età discendente\".")
            if len(parole) == 2:
                verso = parole[1].lower()
                if verso in _DISCENDENTE:
                    direzione = "DESC"
                elif verso not in _ASCENDENTE:
                    raise ErroreValore(f"Verso di ordinamento `{parole[1]}` sconosciuto.",
                                       suggerimento="Usa `crescente` oppure `discendente`.")
            colonna = valida(nome) if valida else self._colonna(tabella, nome)
            pezzi.append(f"{_q(colonna)} {direzione}")
        return " ORDER BY " + ", ".join(pezzi) if pezzi else ""

    # -- API pubblica ------------------------------------------------------------
    def crea_tabella(self, nome: str, colonne: dict) -> None:
        """Crea la tabella se non esiste già (con colonna ``id`` automatica)."""
        tabella = _identificatore(nome)
        if not isinstance(colonne, dict) or not colonne:
            raise ErroreTipo(
                "Le colonne devono essere un dizionario non vuoto, per esempio "
                "{\"nome\": \"testo\", \"età\": \"intero\"}.")
        definizioni: list[str] = []
        ha_id = any(isinstance(c, str) and c.strip().lower() == "id" for c in colonne)
        ha_chiave = False
        if not ha_id:
            definizioni.append('"id" INTEGER PRIMARY KEY AUTOINCREMENT')
        for colonna, tipo in colonne.items():
            nome_colonna = _identificatore(colonna, "colonna")
            if not isinstance(tipo, str) or not tipo.split():
                raise ErroreTipo(f"Il tipo della colonna `{nome_colonna}` deve essere un testo "
                                 "(intero, decimale, testo o logico).")
            parole = tipo.lower().split()
            base = _SINONIMI_TIPO.get(parole[0], parole[0])
            if base not in TIPI_COLONNA:
                raise ErroreValore(
                    f"Tipo `{parole[0]}` sconosciuto per la colonna `{nome_colonna}`.",
                    suggerimento="I tipi possibili sono: intero, decimale, testo, logico (sì/no), data.")
            pezzo = f"{_q(nome_colonna)} {TIPI_COLONNA[base]}"
            altre = iter(parole[1:])
            for parola in altre:
                if parola in _COLLEGAMENTO:
                    collegata = next(altre, None)
                    if collegata in ("a", "alla", "con"):
                        collegata = next(altre, None)
                    if collegata is None:
                        raise ErroreValore(
                            f"Dopo `collegato` nella colonna `{nome_colonna}` scrivi il nome della tabella.",
                            suggerimento="Esempio: {\"classe_id\": \"intero collegato classi\"}.")
                    pezzo += f" REFERENCES {_q(_identificatore(collegata))}"
                    continue
                if parola not in _MODIFICATORI:
                    raise ErroreValore(
                        f"Parola `{parola}` sconosciuta nel tipo della colonna `{nome_colonna}`.",
                        suggerimento="Dopo il tipo puoi scrivere: chiave, obbligatorio, unico, "
                                     "collegato TABELLA.")
                if parola == "chiave":
                    if ha_chiave:
                        raise ErroreValore("Una tabella può avere una sola colonna `chiave`.")
                    ha_chiave = True
                pezzo += " " + _MODIFICATORI[parola]
            definizioni.append(pezzo)
        if ha_chiave and not ha_id:
            # la chiave scelta dall'utente sostituisce l'id automatico
            definizioni.pop(0)
        with self._blocco:
            self._esegui(f"CREATE TABLE IF NOT EXISTS {_q(tabella)} ({', '.join(definizioni)})",
                         contesto=f"Creazione della tabella `{tabella}`")
            self._cache_colonne.pop(tabella, None)

    def inserisci(self, tabella: str, riga: dict) -> int:
        """Aggiunge una riga; restituisce il suo identificatore (``id``)."""
        if not isinstance(riga, dict):
            raise ErroreTipo("La riga da inserire deve essere un dizionario colonna -> valore.")
        with self._blocco:
            nome = self._richiedi_tabella(tabella)
            colonne = [self._colonna(nome, c) for c in riga]
            valori = [self._valore_per(nome, c, v) for c, v in zip(colonne, riga.values())]
            if colonne:
                sql = (f"INSERT INTO {_q(nome)} ({', '.join(_q(c) for c in colonne)}) "
                       f"VALUES ({', '.join('?' * len(colonne))})")
            else:
                sql = f"INSERT INTO {_q(nome)} DEFAULT VALUES"
            cursore = self._esegui(sql, valori, contesto=f"Inserimento in `{nome}`")
            return int(cursore.lastrowid or 0)

    def cerca(self, tabella: str, condizioni: dict | None = None, ordina: str = "",
              limite: int = 0) -> list[dict]:
        """Righe che rispettano le condizioni (tutte, se ``condizioni`` è vuoto)."""
        if isinstance(limite, bool) or not isinstance(limite, int):
            raise ErroreTipo("`limite` deve essere un numero intero.")
        if limite < 0:
            raise ErroreValore("`limite` non può essere negativo (0 = nessun limite).")
        with self._blocco:
            nome = self._richiedi_tabella(tabella)
            dove, parametri = self._dove(nome, condizioni)
            sql = f"SELECT * FROM {_q(nome)}{dove}{self._ordine(nome, ordina)}"
            if limite:
                sql += f" LIMIT {int(limite)}"
            cursore = self._esegui(sql, parametri, contesto=f"Ricerca in `{nome}`")
            return self._righe(cursore, self._colonne_logiche(nome), self._colonne_data(nome))

    def aggiorna(self, tabella: str, condizioni: dict | None, valori: dict) -> int:
        """Cambia i ``valori`` nelle righe che rispettano le condizioni; restituisce
        quante righe sono cambiate."""
        if not isinstance(valori, dict) or not valori:
            raise ErroreTipo("I nuovi valori devono essere un dizionario non vuoto colonna -> valore.")
        with self._blocco:
            nome = self._richiedi_tabella(tabella)
            assegnazioni = []
            parametri: list = []
            for colonna, valore in valori.items():
                c = self._colonna(nome, colonna)
                assegnazioni.append(f"{_q(c)} = ?")
                parametri.append(self._valore_per(nome, c, valore))
            dove, parametri_dove = self._dove(nome, condizioni)
            cursore = self._esegui(f"UPDATE {_q(nome)} SET {', '.join(assegnazioni)}{dove}",
                                   parametri + parametri_dove, contesto=f"Aggiornamento di `{nome}`")
            return max(0, cursore.rowcount)

    def elimina(self, tabella: str, condizioni: dict | None) -> int:
        """Elimina le righe che rispettano le condizioni; restituisce quante.

        Con condizioni vuote (``{}`` o ``nulla``) svuota la tabella.
        """
        with self._blocco:
            nome = self._richiedi_tabella(tabella)
            dove, parametri = self._dove(nome, condizioni)
            cursore = self._esegui(f"DELETE FROM {_q(nome)}{dove}", parametri,
                                   contesto=f"Eliminazione da `{nome}`")
            return max(0, cursore.rowcount)

    def esegui(self, sql: str, parametri: list | dict | None = None) -> list[dict]:
        """Esegue un comando SQL con parametri ``?`` (lista) o ``:nome``
        (dizionario). Restituisce le righe (lista vuota se il comando non ne
        produce)."""
        if not isinstance(sql, str) or not sql.strip():
            raise ErroreTipo("Il comando SQL deve essere un testo non vuoto.")
        if parametri is None:
            valori: Any = ()
        elif isinstance(parametri, dict):
            valori = {str(k): _valore_in(v, str(k)) for k, v in parametri.items()}
        elif isinstance(parametri, (list, tuple)):
            valori = [_valore_in(v) for v in parametri]
        else:
            valori = [_valore_in(parametri)]
        with self._blocco:
            cursore = self._esegui(sql, valori, contesto="Comando SQL")
            self._cache_colonne.clear()  # il comando può aver cambiato le tabelle
            return self._righe(cursore)

    def conta(self, tabella: str, condizioni: dict | None = None) -> int:
        """Quante righe rispettano le condizioni (tutte, se ``condizioni`` è vuoto)."""
        with self._blocco:
            nome = self._richiedi_tabella(tabella)
            dove, parametri = self._dove(nome, condizioni)
            riga = self._esegui(f"SELECT COUNT(*) FROM {_q(nome)}{dove}", parametri,
                                contesto=f"Conteggio in `{nome}`").fetchone()
            return int(riga[0]) if riga else 0

    def elimina_tabella(self, tabella: str) -> bool:
        """Elimina la tabella con tutte le sue righe; ``False`` se non esisteva."""
        nome = _identificatore(tabella)
        with self._blocco:
            esisteva = nome in self.tabelle()
            self._esegui(f"DROP TABLE IF EXISTS {_q(nome)}", contesto=f"Eliminazione della tabella `{nome}`")
            self._cache_colonne.pop(nome, None)
            return esisteva

    # -- transazioni -------------------------------------------------------------
    @property
    def in_transazione(self) -> bool:
        return self._transazione

    def inizia_transazione(self) -> None:
        """Da qui in poi le modifiche restano in sospeso fino a ``conferma`` o ``annulla``."""
        with self._blocco:
            conn = self._conn()
            if self._transazione:
                raise ErroreValore("C'è già una transazione aperta.",
                                   suggerimento="Chiudila con `conferma()` o `annulla()` prima di aprirne un'altra.")
            if conn.in_transaction:
                conn.commit()
            try:
                conn.execute("BEGIN")
            except sqlite3.Error as e:
                raise _traduci(e, "Inizio della transazione") from None
            self._transazione = True

    def conferma(self) -> None:
        """Salva definitivamente le modifiche della transazione."""
        with self._blocco:
            if not self._transazione:
                raise ErroreValore("Non c'è nessuna transazione da confermare.",
                                   suggerimento="Aprila prima con `inizia_transazione()`.")
            self._transazione = False
            conn = self._conn()
            try:
                if conn.in_transaction:
                    conn.commit()
            except sqlite3.Error as e:
                conn.rollback()
                self._cache_colonne.clear()
                raise _traduci(e, "Conferma della transazione") from None

    def annulla(self) -> None:
        """Annulla tutte le modifiche fatte dall'inizio della transazione."""
        with self._blocco:
            if not self._transazione:
                raise ErroreValore("Non c'è nessuna transazione da annullare.",
                                   suggerimento="Aprila prima con `inizia_transazione()`.")
            self._transazione = False
            conn = self._conn()
            if conn.in_transaction:
                conn.rollback()
            self._cache_colonne.clear()  # una tabella creata nella transazione non c'è più

    def tabelle(self) -> list[str]:
        """Nomi delle tabelle, in ordine alfabetico."""
        with self._blocco:
            righe = self._esegui(
                "SELECT name FROM sqlite_master WHERE type = 'table' "
                "AND name NOT LIKE 'sqlite\\_%' ESCAPE '\\' ORDER BY name").fetchall()
            return [r[0] for r in righe]

    def colonne(self, tabella: str) -> dict[str, str]:
        """Colonne della tabella con il loro tipo Leo."""
        inverso = {v: k for k, v in TIPI_COLONNA.items()}
        with self._blocco:
            nome = self._richiedi_tabella(tabella)
            return {c: inverso.get(t, t.lower() or "testo") for c, t in self._info(nome).items()}

    def chiudi(self) -> None:
        """Chiude la banca dati (chiamarla più volte non è un errore)."""
        with self._blocco:
            if self._connessione is not None:
                self._transazione = False  # chiudere senza conferma annulla le modifiche in sospeso
                try:
                    self._connessione.close()
                finally:
                    self._connessione = None

    @property
    def aperta(self) -> bool:
        return self._connessione is not None

    def __enter__(self) -> "BancaDati":
        return self

    def __exit__(self, *_: Any) -> None:
        self.chiudi()

    def __del__(self) -> None:  # pragma: no cover - dipende dal garbage collector
        try:
            self.chiudi()
        except Exception:
            pass
