"""Generatore di codici QR in puro Python (ISO/IEC 18004).

Caratteristiche:

* modalità byte con il testo codificato in UTF-8 (i lettori moderni
  riconoscono l'UTF-8 anche senza designatore ECI);
* versioni da 1 a 40, scelta automaticamente la più piccola che contiene
  il testo;
* livelli di correzione degli errori ``L`` (7%), ``M`` (15%), ``Q`` (25%),
  ``H`` (30%);
* codici Reed–Solomon su GF(256) (polinomio 0x11D), suddivisione in blocchi e
  interleaving come da norma;
* le 8 maschere con il calcolo delle penalità, per scegliere la migliore;
* informazioni di formato (BCH 15,5) e di versione (BCH 18,6).

API:

    matrice_qr(testo, correzione="M") -> list[list[bool]]
        matrice quadrata [riga][colonna], ``True`` = modulo scuro, senza
        margine bianco.
    svg_qr(testo, modulo=4, margine=4, colore="#000000") -> str
        immagine SVG completa (fondo bianco).
    png_qr(testo, percorso, modulo=8, margine=4) -> None
        scrive un file PNG (zlib + struct, nessuna libreria esterna).
"""

from __future__ import annotations

import re
import struct
import zlib
from os import PathLike
from typing import Union

from ...errori import ErroreFile, ErroreTipo, ErroreValore

__all__ = ["matrice_qr", "svg_qr", "png_qr", "LIVELLI_CORREZIONE", "versione_per"]

#: Livelli di correzione accettati.
LIVELLI_CORREZIONE: tuple[str, ...] = ("L", "M", "Q", "H")

# Bit del livello nelle informazioni di formato (norma, tabella 12).
_BIT_FORMATO = {"L": 1, "M": 0, "Q": 3, "H": 2}

# Codeword di correzione per blocco, indice [livello][versione] (0 non usato).
_CORREZIONE_PER_BLOCCO = {
    "L": (-1, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22, 24, 28, 30, 28, 28,
          28, 28, 30, 30, 26, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30),
    "M": (-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24, 28, 28, 26, 26, 26,
          26, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28, 28),
    "Q": (-1, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30, 24, 28, 28, 26, 30,
          28, 30, 30, 30, 30, 28, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30),
    "H": (-1, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24, 30, 28, 28, 26, 28,
          30, 24, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30, 30),
}

# Numero di blocchi di correzione, indice [livello][versione].
_NUMERO_BLOCCHI = {
    "L": (-1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6, 6, 6, 6, 7, 8,
          8, 9, 9, 10, 12, 12, 12, 13, 14, 15, 16, 17, 18, 19, 19, 20, 21, 22, 24, 25),
    "M": (-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10, 10, 11, 13, 14, 16,
          17, 17, 18, 20, 21, 23, 25, 26, 28, 29, 31, 33, 35, 37, 38, 40, 43, 45, 47, 49),
    "Q": (-1, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12, 17, 16, 18, 21, 20,
          23, 23, 25, 27, 29, 34, 34, 35, 38, 40, 43, 45, 48, 51, 53, 56, 59, 62, 65, 68),
    "H": (-1, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18, 16, 19, 21, 25, 25,
          25, 34, 30, 32, 35, 37, 40, 42, 45, 48, 51, 54, 57, 60, 63, 66, 70, 74, 77, 81),
}

# Pesi delle penalità (norma, 7.8.3).
_P1, _P2, _P3, _P4 = 3, 3, 40, 10


# ---------------------------------------------------------------------------
# Aritmetica su GF(256)
# ---------------------------------------------------------------------------

_ESP = [0] * 512
_LOG = [0] * 256


def _prepara_tabelle() -> None:
    x = 1
    for i in range(255):
        _ESP[i] = x
        _LOG[x] = i
        x <<= 1
        if x & 0x100:
            x ^= 0x11D
    for i in range(255, 512):
        _ESP[i] = _ESP[i - 255]


_prepara_tabelle()


def _moltiplica(a: int, b: int) -> int:
    if a == 0 or b == 0:
        return 0
    return _ESP[_LOG[a] + _LOG[b]]


def _generatore_rs(grado: int) -> list[int]:
    """Polinomio generatore (x - α^0)(x - α^1)...(x - α^(grado-1)), senza il
    coefficiente principale (che vale 1), dal grado più alto al più basso."""
    risultato = [0] * (grado - 1) + [1]
    radice = 1
    for _ in range(grado):
        for j in range(grado):
            risultato[j] = _moltiplica(risultato[j], radice)
            if j + 1 < grado:
                risultato[j] ^= risultato[j + 1]
        radice = _moltiplica(radice, 2)
    return risultato


def _resto_rs(dati: list[int], generatore: list[int]) -> list[int]:
    """Codeword di correzione: resto della divisione di dati·x^n per il generatore."""
    resto = [0] * len(generatore)
    for byte in dati:
        fattore = byte ^ resto.pop(0)
        resto.append(0)
        for i, coefficiente in enumerate(generatore):
            resto[i] ^= _moltiplica(coefficiente, fattore)
    return resto


# ---------------------------------------------------------------------------
# Tabelle derivate
# ---------------------------------------------------------------------------

def _moduli_dati_grezzi(versione: int) -> int:
    """Numero di moduli disponibili per dati e correzione (bit), resti inclusi."""
    risultato = (16 * versione + 128) * versione + 64
    if versione >= 2:
        allineamenti = versione // 7 + 2
        risultato -= (25 * allineamenti - 10) * allineamenti - 55
        if versione >= 7:
            risultato -= 36
    return risultato


def _codeword_totali(versione: int) -> int:
    return _moduli_dati_grezzi(versione) // 8


def _codeword_dati(versione: int, livello: str) -> int:
    return (_codeword_totali(versione)
            - _CORREZIONE_PER_BLOCCO[livello][versione] * _NUMERO_BLOCCHI[livello][versione])


def _posizioni_allineamento(versione: int) -> list[int]:
    if versione == 1:
        return []
    numero = versione // 7 + 2
    lato = versione * 4 + 17
    if versione == 32:
        passo = 26
    else:
        passo = (versione * 4 + numero * 2 + 1) // (numero * 2 - 2) * 2
    posizioni = [lato - 7 - i * passo for i in range(numero - 1)]
    return [6] + sorted(posizioni)


def _bit_conteggio(versione: int) -> int:
    """Bit dell'indicatore di lunghezza in modalità byte."""
    return 8 if versione <= 9 else 16


def _normalizza_livello(correzione: str) -> str:
    if not isinstance(correzione, str):
        raise ErroreTipo(
            "Il livello di correzione deve essere un testo (\"L\", \"M\", \"Q\" o \"H\").")
    livello = correzione.strip().upper()
    if livello not in _BIT_FORMATO:
        raise ErroreValore(
            f"Livello di correzione `{correzione}` non valido.",
            suggerimento="Usa \"L\" (7%), \"M\" (15%), \"Q\" (25%) oppure \"H\" (30%).")
    return livello


def versione_per(testo: str, correzione: str = "M") -> int:
    """Versione (1–40) più piccola che contiene ``testo`` al livello dato."""
    livello = _normalizza_livello(correzione)
    dati = _come_byte(testo)
    for versione in range(1, 41):
        bit_necessari = 4 + _bit_conteggio(versione) + 8 * len(dati)
        if bit_necessari <= _codeword_dati(versione, livello) * 8:
            return versione
    massimo = _codeword_dati(40, livello) - 3
    raise ErroreValore(
        f"Il testo è troppo lungo per un codice QR: {len(dati)} byte, "
        f"al massimo {massimo} con la correzione \"{livello}\".",
        suggerimento="Accorcia il testo oppure scegli un livello di correzione più basso (\"L\").")


def _come_byte(testo: str) -> bytes:
    if not isinstance(testo, str):
        raise ErroreTipo("Il contenuto di un codice QR deve essere un testo.")
    return testo.encode("utf-8")


# ---------------------------------------------------------------------------
# Costruzione della matrice
# ---------------------------------------------------------------------------

class _Simbolo:
    def __init__(self, versione: int) -> None:
        self.versione = versione
        self.lato = versione * 4 + 17
        self.moduli = [[False] * self.lato for _ in range(self.lato)]
        self.funzione = [[False] * self.lato for _ in range(self.lato)]

    def imposta(self, x: int, y: int, scuro: bool) -> None:
        """Modulo di funzione in colonna ``x``, riga ``y``."""
        self.moduli[y][x] = scuro
        self.funzione[y][x] = True

    # -- schemi fissi ----------------------------------------------------
    def disegna_schemi(self) -> None:
        lato = self.lato
        for i in range(lato):  # temporizzazione
            self.imposta(6, i, i % 2 == 0)
            self.imposta(i, 6, i % 2 == 0)
        for cx, cy in ((3, 3), (lato - 4, 3), (3, lato - 4)):  # posizione + separatori
            for dy in range(-4, 5):
                for dx in range(-4, 5):
                    x, y = cx + dx, cy + dy
                    if 0 <= x < lato and 0 <= y < lato:
                        distanza = max(abs(dx), abs(dy))
                        self.imposta(x, y, distanza not in (2, 4))
        posizioni = _posizioni_allineamento(self.versione)
        ultimo = len(posizioni) - 1
        for i, cx in enumerate(posizioni):
            for j, cy in enumerate(posizioni):
                if (i == 0 and j == 0) or (i == 0 and j == ultimo) or (i == ultimo and j == 0):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        self.imposta(cx + dx, cy + dy, max(abs(dx), abs(dy)) != 1)
        self.disegna_formato("M", 0)  # riserva l'area; riscritto dopo
        self.disegna_versione()

    def disegna_formato(self, livello: str, maschera: int) -> None:
        bits = bit_formato(livello, maschera)
        lato = self.lato

        def bit(i: int) -> bool:
            return (bits >> i) & 1 == 1

        for i in range(6):
            self.imposta(8, i, bit(i))
        self.imposta(8, 7, bit(6))
        self.imposta(8, 8, bit(7))
        self.imposta(7, 8, bit(8))
        for i in range(9, 15):
            self.imposta(14 - i, 8, bit(i))
        for i in range(8):
            self.imposta(lato - 1 - i, 8, bit(i))
        for i in range(8, 15):
            self.imposta(8, lato - 15 + i, bit(i))
        self.imposta(8, lato - 8, True)  # modulo scuro fisso

    def disegna_versione(self) -> None:
        if self.versione < 7:
            return
        bits = bit_versione(self.versione)
        for i in range(18):
            scuro = (bits >> i) & 1 == 1
            a = self.lato - 11 + i % 3
            b = i // 3
            self.imposta(a, b, scuro)
            self.imposta(b, a, scuro)

    # -- dati --------------------------------------------------------------
    def disegna_dati(self, codeword: list[int]) -> None:
        lato = self.lato
        i = 0
        totale = len(codeword) * 8
        destra = lato - 1
        while destra >= 1:
            if destra == 6:
                destra = 5
            verso_alto = ((destra + 1) & 2) == 0
            for verticale in range(lato):
                y = lato - 1 - verticale if verso_alto else verticale
                for j in range(2):
                    x = destra - j
                    if not self.funzione[y][x] and i < totale:
                        self.moduli[y][x] = (codeword[i >> 3] >> (7 - (i & 7))) & 1 == 1
                        i += 1
            destra -= 2

    def applica_maschera(self, maschera: int) -> None:
        condizione = _MASCHERE[maschera]
        for y in range(self.lato):
            riga = self.moduli[y]
            funzione = self.funzione[y]
            for x in range(self.lato):
                if not funzione[x] and condizione(x, y):
                    riga[x] = not riga[x]

    def penalita(self) -> int:
        return penalita_matrice(self.moduli)


_MASCHERE = (
    lambda x, y: (x + y) % 2 == 0,
    lambda x, y: y % 2 == 0,
    lambda x, y: x % 3 == 0,
    lambda x, y: (x + y) % 3 == 0,
    lambda x, y: (x // 3 + y // 2) % 2 == 0,
    lambda x, y: x * y % 2 + x * y % 3 == 0,
    lambda x, y: (x * y % 2 + x * y % 3) % 2 == 0,
    lambda x, y: ((x + y) % 2 + x * y % 3) % 2 == 0,
)


def bit_formato(livello: str, maschera: int) -> int:
    """I 15 bit delle informazioni di formato (BCH(15,5) già mascherato con 0x5412)."""
    dati = (_BIT_FORMATO[livello] << 3) | maschera
    resto = dati
    for _ in range(10):
        resto = (resto << 1) ^ ((resto >> 9) * 0x537)
    return ((dati << 10) | resto) ^ 0x5412


def bit_versione(versione: int) -> int:
    """I 18 bit delle informazioni di versione (BCH(18,6), polinomio 0x1F25)."""
    resto = versione
    for _ in range(12):
        resto = (resto << 1) ^ ((resto >> 11) * 0x1F25)
    return (versione << 12) | resto


_SCHEMA_A = (True, False, True, True, True, False, True, False, False, False, False)
_SCHEMA_B = tuple(reversed(_SCHEMA_A))


def penalita_matrice(moduli: list[list[bool]]) -> int:
    """Punteggio di penalità (regole N1–N4 della norma)."""
    lato = len(moduli)
    totale = 0
    colonne = [[moduli[y][x] for y in range(lato)] for x in range(lato)]
    for linea in list(moduli) + colonne:
        # N1: sequenze di 5 o più moduli dello stesso colore
        corsa = 1
        for k in range(1, lato):
            if linea[k] == linea[k - 1]:
                corsa += 1
            else:
                if corsa >= 5:
                    totale += _P1 + corsa - 5
                corsa = 1
        if corsa >= 5:
            totale += _P1 + corsa - 5
        # N3: schema 1:1:3:1:1 con 4 moduli chiari da un lato
        tupla = tuple(linea)
        for k in range(lato - 10):
            pezzo = tupla[k:k + 11]
            if pezzo == _SCHEMA_A or pezzo == _SCHEMA_B:
                totale += _P3
    # N2: blocchi 2x2 dello stesso colore
    for y in range(lato - 1):
        sopra, sotto = moduli[y], moduli[y + 1]
        for x in range(lato - 1):
            c = sopra[x]
            if c == sopra[x + 1] == sotto[x] == sotto[x + 1]:
                totale += _P2
    # N4: proporzione di moduli scuri
    scuri = sum(sum(1 for m in riga if m) for riga in moduli)
    celle = lato * lato
    k = (abs(scuri * 20 - celle * 10) + celle - 1) // celle - 1
    totale += max(0, k) * _P4
    return totale


def _codifica_dati(dati: bytes, versione: int, livello: str) -> list[int]:
    capacita = _codeword_dati(versione, livello) * 8
    bit: list[int] = []

    def aggiungi(valore: int, lunghezza: int) -> None:
        for i in range(lunghezza - 1, -1, -1):
            bit.append((valore >> i) & 1)

    aggiungi(0b0100, 4)  # modalità byte
    aggiungi(len(dati), _bit_conteggio(versione))
    for byte in dati:
        aggiungi(byte, 8)
    aggiungi(0, min(4, capacita - len(bit)))  # terminatore
    aggiungi(0, (-len(bit)) % 8)
    codeword = [int("".join(map(str, bit[i:i + 8])), 2) for i in range(0, len(bit), 8)]
    riempimento = (0xEC, 0x11)
    k = 0
    while len(codeword) < capacita // 8:
        codeword.append(riempimento[k % 2])
        k += 1
    return codeword


def _aggiungi_correzione(dati: list[int], versione: int, livello: str) -> list[int]:
    numero_blocchi = _NUMERO_BLOCCHI[livello][versione]
    lunghezza_ec = _CORREZIONE_PER_BLOCCO[livello][versione]
    totali = _codeword_totali(versione)
    blocchi_corti = numero_blocchi - totali % numero_blocchi
    lunghezza_corta = totali // numero_blocchi
    generatore = _generatore_rs(lunghezza_ec)
    blocchi_dati: list[list[int]] = []
    blocchi_ec: list[list[int]] = []
    k = 0
    for i in range(numero_blocchi):
        quanti = lunghezza_corta - lunghezza_ec + (0 if i < blocchi_corti else 1)
        blocco = dati[k:k + quanti]
        k += quanti
        blocchi_dati.append(blocco)
        blocchi_ec.append(_resto_rs(blocco, generatore))
    risultato: list[int] = []
    for i in range(max(len(b) for b in blocchi_dati)):
        for blocco in blocchi_dati:
            if i < len(blocco):
                risultato.append(blocco[i])
    for i in range(lunghezza_ec):
        for blocco in blocchi_ec:
            risultato.append(blocco[i])
    assert len(risultato) == totali
    return risultato


def matrice_qr(testo: str, correzione: str = "M") -> list[list[bool]]:
    """Matrice del codice QR di ``testo``: ``[riga][colonna]``, ``True`` = scuro.

    La matrice non include il margine bianco (zona di rispetto).
    Errori: ``ErroreTipo`` se ``testo`` non è un testo, ``ErroreValore`` se il
    livello non è L/M/Q/H o se il testo non entra nemmeno nella versione 40.
    """
    livello = _normalizza_livello(correzione)
    dati = _come_byte(testo)
    versione = versione_per(testo, livello)
    codeword = _aggiungi_correzione(_codifica_dati(dati, versione, livello), versione, livello)
    simbolo = _Simbolo(versione)
    simbolo.disegna_schemi()
    simbolo.disegna_dati(codeword)
    migliore: tuple[int, int] | None = None
    for maschera in range(8):
        simbolo.applica_maschera(maschera)
        simbolo.disegna_formato(livello, maschera)
        punteggio = simbolo.penalita()
        if migliore is None or punteggio < migliore[0]:
            migliore = (punteggio, maschera)
        simbolo.applica_maschera(maschera)  # la maschera è un XOR: la toglie
    assert migliore is not None
    simbolo.applica_maschera(migliore[1])
    simbolo.disegna_formato(livello, migliore[1])
    return simbolo.moduli


# ---------------------------------------------------------------------------
# Esportazione
# ---------------------------------------------------------------------------

_COLORE_ESADECIMALE = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")


def _controlla_dimensioni(modulo: int, margine: int) -> None:
    for nome, valore, minimo in (("modulo", modulo, 1), ("margine", margine, 0)):
        if isinstance(valore, bool) or not isinstance(valore, int):
            raise ErroreTipo(f"`{nome}` deve essere un numero intero.")
        if valore < minimo or valore > 1000:
            raise ErroreValore(
                f"`{nome}` vale {valore}, ma deve essere tra {minimo} e 1000.")


def _rgb(colore: str) -> tuple[int, int, int]:
    if not isinstance(colore, str) or not _COLORE_ESADECIMALE.match(colore.strip()):
        raise ErroreValore(
            f"Colore `{colore}` non valido per il codice QR.",
            suggerimento="Scrivi il colore nella forma \"#RRGGBB\", per esempio \"#000000\".")
    cifre = colore.strip()[1:]
    if len(cifre) == 3:
        cifre = "".join(c * 2 for c in cifre)
    return int(cifre[0:2], 16), int(cifre[2:4], 16), int(cifre[4:6], 16)


def svg_qr(testo: str, modulo: int = 4, margine: int = 4, colore: str = "#000000",
           *, correzione: str = "M") -> str:
    """Immagine SVG del codice QR (fondo bianco, moduli del colore scelto)."""
    _controlla_dimensioni(modulo, margine)
    r, g, b = _rgb(colore)
    matrice = matrice_qr(testo, correzione)
    lato = len(matrice) + 2 * margine
    pixel = lato * modulo
    pezzi: list[str] = []
    for y, riga in enumerate(matrice):
        x = 0
        while x < len(riga):
            if riga[x]:
                inizio = x
                while x < len(riga) and riga[x]:
                    x += 1
                pezzi.append(f"M{inizio + margine},{y + margine}h{x - inizio}v1h-{x - inizio}z")
            else:
                x += 1
    return (
        '<?xml version="1.0" encoding="UTF-8"?>\n'
        f'<svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="{pixel}" height="{pixel}" '
        f'viewBox="0 0 {lato} {lato}" shape-rendering="crispEdges">\n'
        f'<rect width="{lato}" height="{lato}" fill="#FFFFFF"/>\n'
        f'<path d="{"".join(pezzi)}" fill="#{r:02X}{g:02X}{b:02X}"/>\n'
        '</svg>\n'
    )


def _blocco_png(tipo: bytes, dati: bytes) -> bytes:
    return (struct.pack(">I", len(dati)) + tipo + dati
            + struct.pack(">I", zlib.crc32(tipo + dati) & 0xFFFFFFFF))


def dati_png_qr(testo: str, modulo: int = 8, margine: int = 4, *, colore: str = "#000000",
                correzione: str = "M") -> bytes:
    """Byte di un file PNG (RGB, 8 bit per canale) con il codice QR."""
    _controlla_dimensioni(modulo, margine)
    scuro = bytes(_rgb(colore))
    chiaro = b"\xff\xff\xff"
    matrice = matrice_qr(testo, correzione)
    lato = len(matrice) + 2 * margine
    pixel = lato * modulo
    bordo = chiaro * (margine * modulo)
    riga_vuota = b"\x00" + chiaro * pixel
    righe: list[bytes] = [riga_vuota] * (margine * modulo)
    for riga in matrice:
        linea = b"\x00" + bordo + b"".join((scuro if m else chiaro) * modulo for m in riga) + bordo
        righe.extend([linea] * modulo)
    righe.extend([riga_vuota] * (margine * modulo))
    intestazione = struct.pack(">IIBBBBB", pixel, pixel, 8, 2, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n"
            + _blocco_png(b"IHDR", intestazione)
            + _blocco_png(b"IDAT", zlib.compress(b"".join(righe), 9))
            + _blocco_png(b"IEND", b""))


def png_qr(testo: str, percorso: Union[str, "PathLike[str]"], modulo: int = 8, margine: int = 4,
           *, colore: str = "#000000", correzione: str = "M") -> None:
    """Scrive in ``percorso`` un'immagine PNG del codice QR.

    ``ErroreFile`` se il file non si può scrivere.
    """
    contenuto = dati_png_qr(testo, modulo, margine, colore=colore, correzione=correzione)
    try:
        with open(percorso, "wb") as file:
            file.write(contenuto)
    except OSError as e:
        raise ErroreFile(
            f"Non riesco a scrivere l'immagine del codice QR in `{percorso}`: "
            f"{e.strerror or e}.",
            suggerimento="Controlla che la cartella esista e che tu possa scriverci.") from None
