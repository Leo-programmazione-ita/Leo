"""Sintesi e riconoscimento vocale con gli strumenti del sistema operativo, senza Qt.

Sintesi (lettura ad alta voce):
    * Windows: PowerShell + ``System.Speech`` (voce italiana se installata);
    * macOS: il comando ``say`` (voce italiana se presente);
    * Linux: ``espeak-ng`` (o ``espeak``), altrimenti ``spd-say``.
Riconoscimento (dettatura): Windows, PowerShell + ``System.Speech.Recognition``
con il riconoscitore italiano (``it-IT``) installato.

API::

    sintesi_disponibile() -> bool
    leggi_ad_alta_voce(testo, velocita=0, volume=100, al_termine=None)   # non blocca
    ferma_lettura()
    riconoscimento_disponibile() -> bool
    riconosci_frase(lingua="it-IT", tempo_massimo=5) -> str             # blocca: usala in un thread
    ferma_riconoscimento()

Senza strumenti adatti le funzioni sollevano ``ErroreValore("...: non
disponibile su questo computer.")`` con un suggerimento. ``al_termine`` viene
chiamata (senza argomenti) in un thread secondario quando la lettura finisce
o viene fermata.
"""

from __future__ import annotations

import base64
import os
import shutil
import subprocess
import sys
import tempfile
import threading
from typing import Callable

from ...errori import ErroreTipo, ErroreValore

NON_DISPONIBILE = "non disponibile su questo computer"

#: Su Windows niente finestra nera della console per i processi figli.
_SENZA_FINESTRA = getattr(subprocess, "CREATE_NO_WINDOW", 0)

_lucchetto = threading.Lock()
_lettura: subprocess.Popen | None = None
_riconoscimento: subprocess.Popen | None = None
_cache: dict[str, object] = {}


def _non_disponibile(cosa: str, suggerimento: str) -> ErroreValore:
    return ErroreValore(f"{cosa}: {NON_DISPONIBILE}.", suggerimento=suggerimento)


def _windows() -> bool:
    return os.name == "nt"


def _macos() -> bool:
    return sys.platform == "darwin"


def _powershell() -> str | None:
    return shutil.which("powershell") or shutil.which("powershell.exe") or shutil.which("pwsh")


def _comando_powershell(script: str) -> list[str]:
    """Riga di comando che esegue ``script`` senza problemi di virgolette (-EncodedCommand)."""
    codificato = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
    return [_powershell() or "powershell", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
            "-EncodedCommand", codificato]


def _testo_ps(testo: str) -> str:
    """Letterale PowerShell tra apici singoli."""
    return "'" + testo.replace("'", "''") + "'"


# ===========================================================================
# Sintesi
# ===========================================================================

def _motore_sintesi() -> str | None:
    """"windows", "say", "espeak-ng", "espeak", "spd-say" oppure None."""
    if _windows():
        return "windows" if _powershell() else None
    if _macos() and shutil.which("say"):
        return "say"
    for nome in ("espeak-ng", "espeak", "spd-say"):
        if shutil.which(nome):
            return nome
    return None


def sintesi_disponibile() -> bool:
    return _motore_sintesi() is not None


def _controlla_parametri(testo, velocita, volume) -> tuple[str, int, int]:
    if not isinstance(testo, str):
        raise ErroreTipo("Si può leggere ad alta voce solo un testo.",
                         suggerimento="Per un numero usa `testo(...)`.")
    for nome, v in (("velocita", velocita), ("volume", volume)):
        if isinstance(v, bool) or not isinstance(v, (int, float)):
            raise ErroreTipo(f"`{nome}` deve essere un numero.")
    if not -10 <= velocita <= 10:
        raise ErroreValore("`velocita` va da -10 (piano) a 10 (veloce).")
    if not 0 <= volume <= 100:
        raise ErroreValore("`volume` va da 0 a 100.")
    return testo, int(round(velocita)), int(round(volume))


def _voce_italiana_say() -> str | None:
    """Nome di una voce italiana di macOS (es. "Alice"), cercata una volta sola."""
    if "voce_say" in _cache:
        return _cache["voce_say"]  # type: ignore[return-value]
    voce = None
    try:
        uscita = subprocess.run(["say", "-v", "?"], capture_output=True, text=True, timeout=5).stdout
        for riga in uscita.splitlines():
            if "it_IT" in riga or "it-IT" in riga:
                voce = riga.split("  ")[0].strip() or None
                if voce:
                    break
    except (OSError, subprocess.SubprocessError):
        voce = None
    _cache["voce_say"] = voce
    return voce


def _comando_sintesi(motore: str, testo: str, velocita: int, volume: int) -> tuple[list[str], bytes | None, str | None]:
    """(comando, dati da mandare su stdin, file temporaneo da cancellare)."""
    if motore == "windows":
        # il testo passa da un file UTF-8: nessun limite di lunghezza, nessun problema di accenti
        fd, percorso = tempfile.mkstemp(prefix="leo_voce_", suffix=".txt")
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(testo)
        script = (
            "Add-Type -AssemblyName System.Speech\n"
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer\n"
            "try { $v = $s.GetInstalledVoices() | Where-Object { $_.Enabled -and "
            "$_.VoiceInfo.Culture.Name -eq 'it-IT' } | Select-Object -First 1\n"
            "  if ($v) { $s.SelectVoice($v.VoiceInfo.Name) } } catch {}\n"
            f"$s.Rate = {velocita}\n"
            f"$s.Volume = {volume}\n"
            f"$t = [System.IO.File]::ReadAllText({_testo_ps(percorso)}, [System.Text.Encoding]::UTF8)\n"
            "$s.Speak($t)\n"
            "$s.Dispose()\n"
        )
        return _comando_powershell(script), None, percorso
    if motore == "say":
        parole_minuto = int(175 * 2 ** (velocita / 10))
        comando = ["say", "-r", str(parole_minuto)]
        voce = _voce_italiana_say()
        if voce:
            comando += ["-v", voce]
        # [[volm x]] e' un comando incorporato di `say` per il volume (0-1)
        return comando, f"[[volm {volume / 100:.2f}]] {testo}".encode("utf-8"), None
    if motore in ("espeak-ng", "espeak"):
        parole_minuto = int(175 * 2 ** (velocita / 10))
        return ([shutil.which(motore) or motore, "-v", "it", "-s", str(parole_minuto), "-a", str(volume * 2),
                 "--stdin"], testo.encode("utf-8"), None)
    # spd-say: velocita' e volume da -100 a 100
    return (["spd-say", "-l", "it", "-w", "-r", str(velocita * 10), "-i", str(volume * 2 - 100), "--", testo],
            None, None)


def leggi_ad_alta_voce(testo: str, velocita=0, volume=100, al_termine: Callable[[], None] | None = None) -> None:
    """Legge ``testo`` ad alta voce senza bloccare; ferma una lettura gia' in corso."""
    testo, velocita, volume = _controlla_parametri(testo, velocita, volume)
    motore = _motore_sintesi()
    if motore is None:
        raise _non_disponibile(
            "Lettura ad alta voce",
            "Su Linux installa `espeak-ng` (per esempio `sudo apt install espeak-ng`); "
            "su Windows serve PowerShell, su macOS il comando `say`.")
    ferma_lettura()
    if not testo.strip():
        if al_termine is not None:
            threading.Thread(target=al_termine, daemon=True).start()
        return
    comando, dati, temporaneo = _comando_sintesi(motore, testo, velocita, volume)
    global _lettura
    try:
        processo = subprocess.Popen(comando, stdin=subprocess.PIPE if dati is not None else subprocess.DEVNULL,
                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                    creationflags=_SENZA_FINESTRA)
    except OSError as e:
        if temporaneo:
            _cancella(temporaneo)
        raise _non_disponibile("Lettura ad alta voce", f"Non riesco ad avviare `{comando[0]}`: {e}.") from e
    with _lucchetto:
        _lettura = processo

    def attendi() -> None:
        global _lettura
        try:
            if dati is not None and processo.stdin is not None:
                try:
                    processo.stdin.write(dati)
                    processo.stdin.close()
                except OSError:
                    pass
            processo.wait()
        finally:
            with _lucchetto:
                if _lettura is processo:
                    _lettura = None
            if temporaneo:
                _cancella(temporaneo)
            if al_termine is not None:
                try:
                    al_termine()
                except Exception:
                    pass

    threading.Thread(target=attendi, daemon=True, name="leo-voce").start()


def _cancella(percorso: str) -> None:
    try:
        os.remove(percorso)
    except OSError:
        pass


def _termina(processo: subprocess.Popen | None) -> None:
    if processo is None or processo.poll() is not None:
        return
    try:
        processo.terminate()
        try:
            processo.wait(timeout=2)
        except subprocess.TimeoutExpired:
            processo.kill()
    except OSError:
        pass


def ferma_lettura() -> None:
    """Interrompe la lettura in corso (se c'e')."""
    global _lettura
    with _lucchetto:
        processo, _lettura = _lettura, None
    _termina(processo)


def lettura_in_corso() -> bool:
    with _lucchetto:
        return _lettura is not None and _lettura.poll() is None


# ===========================================================================
# Riconoscimento
# ===========================================================================

def riconoscimento_disponibile() -> bool:
    """Vero su Windows con PowerShell (il riconoscitore italiano si verifica al primo uso)."""
    return _windows() and _powershell() is not None


def _script_riconoscimento(lingua: str, secondi: float) -> str:
    return (
        "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8\n"
        "Add-Type -AssemblyName System.Speech\n"
        f"$cultura = New-Object System.Globalization.CultureInfo({_testo_ps(lingua)})\n"
        "try { $r = New-Object System.Speech.Recognition.SpeechRecognitionEngine($cultura) }\n"
        "catch { [Console]::Error.WriteLine('NESSUN_RICONOSCITORE'); exit 3 }\n"
        "try { $r.SetInputToDefaultAudioDevice() }\n"
        "catch { [Console]::Error.WriteLine('NESSUN_MICROFONO'); exit 4 }\n"
        "$r.LoadGrammar((New-Object System.Speech.Recognition.DictationGrammar))\n"
        f"$risultato = $r.Recognize([TimeSpan]::FromSeconds({float(secondi):.1f}))\n"
        "if ($risultato) { [Console]::Out.Write($risultato.Text) }\n"
        "$r.Dispose()\n"
    )


def riconosci_frase(lingua: str = "it-IT", tempo_massimo=5) -> str:
    """Ascolta il microfono e restituisce la frase riconosciuta ("" se non ha sentito nulla).

    Blocca per al massimo ``tempo_massimo`` secondi (piu' l'avvio): chiamala da un thread.
    """
    if not isinstance(lingua, str) or not lingua:
        raise ErroreTipo("La lingua deve essere un testo come \"it-IT\".")
    if isinstance(tempo_massimo, bool) or not isinstance(tempo_massimo, (int, float)) or tempo_massimo <= 0:
        raise ErroreValore("`tempo_massimo` deve essere un numero di secondi maggiore di zero.")
    if not riconoscimento_disponibile():
        raise _non_disponibile(
            "Riconoscimento vocale",
            "Per ora la dettatura funziona solo su Windows (con il riconoscimento vocale italiano installato).")
    global _riconoscimento
    try:
        processo = subprocess.Popen(_comando_powershell(_script_riconoscimento(lingua, tempo_massimo)),
                                    stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                    creationflags=_SENZA_FINESTRA)
    except OSError as e:
        raise _non_disponibile("Riconoscimento vocale", f"Non riesco ad avviare PowerShell: {e}.") from e
    with _lucchetto:
        _riconoscimento = processo
    try:
        try:
            uscita, errori = processo.communicate(timeout=float(tempo_massimo) + 30)
        except subprocess.TimeoutExpired:
            _termina(processo)
            raise ErroreValore("Il riconoscimento vocale non ha risposto in tempo.")
    finally:
        with _lucchetto:
            fermato = _riconoscimento is not processo
            if not fermato:
                _riconoscimento = None
    if fermato:
        return ""
    testo_errori = errori.decode("utf-8", errors="replace") if errori else ""
    if processo.returncode == 3 or "NESSUN_RICONOSCITORE" in testo_errori:
        raise _non_disponibile(
            f"Riconoscimento vocale in `{lingua}`",
            "Installa la lingua italiana con il riconoscimento vocale da Impostazioni > Ora e lingua > Lingua.")
    if processo.returncode == 4 or "NESSUN_MICROFONO" in testo_errori:
        raise _non_disponibile("Microfono", "Collega un microfono e controlla che Windows lo veda.")
    if processo.returncode not in (0, None):
        raise ErroreValore("Il riconoscimento vocale si è interrotto con un errore.",
                           suggerimento="Controlla il microfono e riprova.")
    return (uscita or b"").decode("utf-8", errors="replace").strip()


def ferma_riconoscimento() -> None:
    """Interrompe l'ascolto in corso: ``riconosci_frase`` restituisce ""."""
    global _riconoscimento
    with _lucchetto:
        processo, _riconoscimento = _riconoscimento, None
    _termina(processo)


__all__ = ["sintesi_disponibile", "leggi_ad_alta_voce", "ferma_lettura", "lettura_in_corso",
           "riconoscimento_disponibile", "riconosci_frase", "ferma_riconoscimento"]
