"""Servizi puri (senza Qt) usati dai controlli inventati per Leo.

Ogni modulo del pacchetto e' scritto solo con la libreria standard di Python
e si puo' usare (e provare) senza interfaccia grafica:

* ``italia``          codice fiscale, IBAN, targhe, importi in euro, Pasqua e
                      festivita' nazionali, ricerca dei comuni;
* ``qr``              generatore di codici QR;
* ``sicurezza``       robustezza delle password, impronte, cifratura didattica;
* ``bancadati``       piccola banca dati SQLite con comandi in italiano;
* ``rete``            richieste web e server locale;
* ``registro_eventi`` elenco di eventi con livelli;
* ``giochi``          fisica elementare, collisioni e punteggi;
* ``pico``            Raspberry Pi Pico (anche simulata);
* ``segnali``         memoria dei valori per l'oscilloscopio e le lancette;
* ``voce``            sintesi e riconoscimento vocale del sistema;
* ``assistente``      chat con un modello di intelligenza artificiale.

I moduli vengono importati solo quando servono (import pigri): questo file
non importa nulla.
"""

from __future__ import annotations
