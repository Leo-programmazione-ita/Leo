"""Servizi italiani per i controlli della scheda *Italia* (puro Python, senza Qt).

Contenuto:

* **codice fiscale**: formato, carattere di controllo, omocodia, data di
  nascita, sesso e codice catastale del comune
  (:func:`verifica_codice_fiscale`, :func:`calcola_carattere_controllo`,
  :func:`calcola_codice_fiscale`);
* **IBAN**: cifre di controllo (modulo 97), CIN italiano, ABI/CAB/conto,
  nome della banca per i principali ABI, formattazione a gruppi di 4
  (:func:`verifica_iban`, :func:`formatta_iban`);
* **targhe**: auto (dal 1994), moto (dal 1999), ciclomotori e formati
  storici (:func:`verifica_targa`);
* **importi** all'italiana, ``1.234,50 €`` e lettura inversa
  (:func:`formatta_importo`, :func:`leggi_importo`);
* **calendario**: Pasqua (algoritmo di Meeus/Jones/Butcher), festivita'
  nazionali (:func:`pasqua`, :func:`festivita`, :func:`e_festivo`);
* **comuni**: ricerca senza accenti ne' maiuscole, per prefisso e per parola,
  nei dati di ``dati/italia/comuni.csv`` (:func:`cerca_comuni`,
  :func:`comune_da_codice_catastale`).

I risultati sono valori Leo (dizionari con chiavi testuali, testi, logici,
numeri); le date di nascita sono testi ``GG/MM/AAAA`` come nel controllo
``SelettoreData``. Gli argomenti sbagliati producono ``ErroreTipo`` o
``ErroreValore`` in italiano.
"""

from __future__ import annotations

import csv
import re
import unicodedata
from datetime import date, datetime, timedelta
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from typing import Any

from ...errori import ErroreFile, ErroreTipo, ErroreValore

__all__ = [
    "verifica_codice_fiscale", "calcola_carattere_controllo", "calcola_codice_fiscale",
    "verifica_iban", "formatta_iban", "BANCHE",
    "verifica_targa",
    "formatta_importo", "leggi_importo",
    "pasqua", "festivita", "e_festivo",
    "cerca_comuni", "comune_da_codice_catastale", "carica_comuni",
]


# ===========================================================================
# Utilita'
# ===========================================================================

def _senza_accenti(testo: str) -> str:
    """``"Città"`` -> ``"Citta"`` (toglie i segni diacritici)."""
    scomposto = unicodedata.normalize("NFD", testo)
    return "".join(c for c in scomposto if unicodedata.category(c) != "Mn")


def _vuole_testo(valore: Any, cosa: str) -> str:
    if not isinstance(valore, str):
        from ...valori import nome_tipo

        raise ErroreTipo(f"{cosa} deve essere un testo, non `{nome_tipo(valore)}`.")
    return valore


def _compatta(testo: str) -> str:
    """Maiuscolo, senza spazi, trattini e punti."""
    return re.sub(r"[\s\-.]+", "", testo).upper()


# ===========================================================================
# Codice fiscale
# ===========================================================================

#: Valori dei caratteri in posizione DISPARI (1a, 3a, ... 15a).
_CF_DISPARI = {
    "0": 1, "1": 0, "2": 5, "3": 7, "4": 9, "5": 13, "6": 15, "7": 17, "8": 19, "9": 21,
    "A": 1, "B": 0, "C": 5, "D": 7, "E": 9, "F": 13, "G": 15, "H": 17, "I": 19, "J": 21,
    "K": 2, "L": 4, "M": 18, "N": 20, "O": 11, "P": 3, "Q": 6, "R": 8, "S": 12, "T": 14,
    "U": 16, "V": 10, "W": 22, "X": 25, "Y": 24, "Z": 23,
}


def _valore_pari(c: str) -> int:
    return int(c) if c.isdigit() else ord(c) - ord("A")


#: Lettere dei mesi (gennaio = A ... dicembre = T).
_CF_MESI = "ABCDEHLMPRST"

#: Lettere che sostituiscono le cifre nei codici omocodici (L = 0 ... V = 9).
_CF_OMOCODIA = "LMNPQRSTUV"

#: Posizioni (da 0) dove l'omocodia puo' sostituire una cifra con una lettera.
_CF_POSIZIONI_NUMERICHE = (6, 7, 9, 10, 12, 13, 14)

_CF_FORMATO = re.compile(r"^[A-Z]{6}[0-9LMNPQRSTUV]{2}[A-Z][0-9LMNPQRSTUV]{2}[A-Z][0-9LMNPQRSTUV]{3}[A-Z]$")


def _carattere_controllo(primi15: str) -> str:
    somma = 0
    for i, c in enumerate(primi15):
        somma += _CF_DISPARI[c] if i % 2 == 0 else _valore_pari(c)
    return chr(ord("A") + somma % 26)


def calcola_carattere_controllo(cf15: str) -> str:
    """Carattere di controllo (16a lettera) dei primi 15 caratteri di un codice fiscale."""
    testo = _compatta(_vuole_testo(cf15, "Il codice fiscale"))
    if len(testo) == 16:
        testo = testo[:15]
    if len(testo) != 15 or any(c not in _CF_DISPARI for c in testo):
        raise ErroreValore("Per calcolare il carattere di controllo servono i primi 15 caratteri del codice fiscale.",
                           suggerimento="Solo lettere e cifre, per esempio \"RSSMRA80A01H501\".")
    return _carattere_controllo(testo)


def _togli_omocodia(cf: str) -> str:
    caratteri = list(cf)
    for i in _CF_POSIZIONI_NUMERICHE:
        c = caratteri[i]
        if c in _CF_OMOCODIA:
            caratteri[i] = str(_CF_OMOCODIA.index(c))
    return "".join(caratteri)


def _anno_completo(aa: int, oggi: date | None = None) -> int:
    """Anno a due cifre -> quattro cifre (nel futuro no: 30 -> 1930 se oggi e' prima del 2030)."""
    oggi = oggi or date.today()
    anno = 2000 + aa
    return anno if anno <= oggi.year else 1900 + aa


def _risultato_cf(errore: str) -> dict:
    return {"valido": False, "errore": errore, "data_nascita": "", "sesso": "",
            "codice_comune": "", "comune": ""}


def verifica_codice_fiscale(cf: str) -> dict:
    """Controlla un codice fiscale delle persone fisiche.

    Restituisce ``{"valido", "errore", "data_nascita", "sesso", "codice_comune", "comune"}``:
    ``errore`` e' ``""`` se il codice e' valido; ``data_nascita`` e' ``"GG/MM/AAAA"``,
    ``sesso`` ``"M"`` o ``"F"``, ``comune`` il nome del comune se e' tra quelli
    conosciuti (``"Stato estero"`` per i codici che iniziano con Z).
    Accetta anche i codici omocodici (cifre sostituite da lettere).
    """
    testo = _compatta(_vuole_testo(cf, "Il codice fiscale"))
    if not testo:
        return _risultato_cf("Il codice fiscale è vuoto.")
    if len(testo) != 16:
        return _risultato_cf(f"Il codice fiscale ha 16 caratteri, non {len(testo)}.")
    if not testo.isalnum() or not testo.isascii():
        return _risultato_cf("Il codice fiscale contiene solo lettere e cifre.")
    if not _CF_FORMATO.match(testo):
        if not testo[:6].isalpha():
            return _risultato_cf("I primi 6 caratteri (cognome e nome) devono essere lettere.")
        return _risultato_cf("Il formato non è quello di un codice fiscale (es. RSSMRA80A01H501U).")
    atteso = _carattere_controllo(testo[:15])
    if testo[15] != atteso:
        return _risultato_cf(f"Il carattere di controllo non torna: dovrebbe essere `{atteso}`, non `{testo[15]}`.")
    base = _togli_omocodia(testo)
    mese_lettera = base[8]
    if mese_lettera not in _CF_MESI:
        return _risultato_cf(f"`{mese_lettera}` non indica nessun mese (lettere ammesse: {', '.join(_CF_MESI)}).")
    mese = _CF_MESI.index(mese_lettera) + 1
    giorno = int(base[9:11])
    sesso = "M"
    if giorno > 40:
        giorno -= 40
        sesso = "F"
    if not 1 <= giorno <= 31:
        return _risultato_cf("Il giorno di nascita non è valido (1-31 per i maschi, 41-71 per le femmine).")
    anno = _anno_completo(int(base[6:8]))
    try:
        nascita = date(anno, mese, giorno)
    except ValueError:
        return _risultato_cf(f"La data di nascita {giorno:02d}/{mese:02d}/{anno} non esiste.")
    codice_comune = base[11:15]
    if codice_comune[0] == "Z":
        comune = "Stato estero"
    else:
        trovato = comune_da_codice_catastale(codice_comune)
        comune = trovato["nome"] if trovato else ""
    return {
        "valido": True, "errore": "",
        "data_nascita": nascita.strftime("%d/%m/%Y"),
        "sesso": sesso,
        "codice_comune": codice_comune,
        "comune": comune,
    }


def _consonanti_vocali(parola: str) -> tuple[str, str]:
    lettere = [c for c in _senza_accenti(parola).upper() if "A" <= c <= "Z"]
    consonanti = "".join(c for c in lettere if c not in "AEIOU")
    vocali = "".join(c for c in lettere if c in "AEIOU")
    return consonanti, vocali


def _parte_cognome(cognome: str) -> str:
    c, v = _consonanti_vocali(cognome)
    return (c + v + "XXX")[:3]


def _parte_nome(nome: str) -> str:
    c, v = _consonanti_vocali(nome)
    if len(c) >= 4:
        return c[0] + c[2] + c[3]
    return (c + v + "XXX")[:3]


def _data_da_valore(valore: Any) -> date:
    """``date``/``datetime`` o testo ``GG/MM/AAAA`` (anche con ``-`` o ``.``)."""
    if isinstance(valore, datetime):
        return valore.date()
    if isinstance(valore, date):
        return valore
    if isinstance(valore, str):
        m = re.fullmatch(r"\s*(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})\s*", valore)
        if m:
            try:
                return date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
            except ValueError:
                raise ErroreValore(f"La data `{valore.strip()}` non esiste.") from None
        raise ErroreValore(f"`{valore}` non è una data.", suggerimento="Scrivi la data come \"GG/MM/AAAA\", es. \"25/04/2025\".")
    from ...valori import nome_tipo

    raise ErroreTipo(f"Mi serve una data come testo \"GG/MM/AAAA\", non `{nome_tipo(valore)}`.")


def calcola_codice_fiscale(cognome: str, nome: str, data_nascita: Any, sesso: str, codice_comune: str) -> str:
    """Calcola il codice fiscale (senza omocodia) dai dati anagrafici.

    ``data_nascita``: testo ``"GG/MM/AAAA"`` o ``date``; ``sesso``: ``"M"`` o ``"F"``;
    ``codice_comune``: codice catastale (es. ``"H501"`` per Roma) oppure nome di
    un comune conosciuto.
    """
    _vuole_testo(cognome, "Il cognome")
    _vuole_testo(nome, "Il nome")
    _vuole_testo(sesso, "Il sesso")
    _vuole_testo(codice_comune, "Il comune")
    if not _consonanti_vocali(cognome)[0] + _consonanti_vocali(cognome)[1]:
        raise ErroreValore("Il cognome deve contenere almeno una lettera.")
    if not _consonanti_vocali(nome)[0] + _consonanti_vocali(nome)[1]:
        raise ErroreValore("Il nome deve contenere almeno una lettera.")
    nascita = _data_da_valore(data_nascita)
    s = sesso.strip().upper()[:1]
    if s not in ("M", "F"):
        raise ErroreValore(f"Il sesso `{sesso}` non va bene.", suggerimento="Usa \"M\" oppure \"F\".")
    codice = codice_comune.strip().upper()
    if not re.fullmatch(r"[A-Z]\d{3}", codice):
        trovati = [c for c in cerca_comuni(codice_comune, limite=5)
                   if _chiave_ricerca(c["nome"]) == _chiave_ricerca(codice_comune)]
        if not trovati:
            raise ErroreValore(f"Non conosco il comune `{codice_comune}`.",
                               suggerimento="Indica il codice catastale, es. \"H501\" per Roma.")
        codice = trovati[0]["codice_catastale"]
    giorno = nascita.day + (40 if s == "F" else 0)
    primi15 = (_parte_cognome(cognome) + _parte_nome(nome) + f"{nascita.year % 100:02d}"
               + _CF_MESI[nascita.month - 1] + f"{giorno:02d}" + codice)
    return primi15 + _carattere_controllo(primi15)


# ===========================================================================
# IBAN
# ===========================================================================

#: Lunghezza dell'IBAN per paese (area SEPA e vicini).
LUNGHEZZE_IBAN = {
    "AD": 24, "AT": 20, "BE": 16, "BG": 22, "CH": 21, "CY": 28, "CZ": 24, "DE": 22, "DK": 18,
    "EE": 20, "ES": 24, "FI": 18, "FR": 27, "GB": 22, "GR": 27, "HR": 21, "HU": 28, "IE": 22,
    "IS": 26, "IT": 27, "LI": 21, "LT": 20, "LU": 20, "LV": 21, "MC": 27, "MT": 31, "NL": 18,
    "NO": 15, "PL": 28, "PT": 25, "RO": 24, "SE": 24, "SI": 19, "SK": 24, "SM": 27, "VA": 22,
}

#: Principali banche italiane per codice ABI (piccola tabella, non esaustiva).
BANCHE = {
    "01005": "Banca Nazionale del Lavoro",
    "01030": "Banca Monte dei Paschi di Siena",
    "02008": "UniCredit",
    "03002": "UniCredit",
    "03015": "FinecoBank",
    "03032": "Credito Emiliano (Credem)",
    "03062": "Banca Mediolanum",
    "03069": "Intesa Sanpaolo",
    "03104": "Deutsche Bank",
    "03111": "UBI Banca",
    "03268": "Banca Sella",
    "05034": "Banco BPM",
    "05387": "BPER Banca",
    "05428": "Banca Popolare di Bergamo",
    "05696": "Banca Popolare di Sondrio",
    "06230": "Crédit Agricole Italia",
    "07601": "Poste Italiane (BancoPosta)",
}


def _mod97(testo: str) -> int:
    """Resto modulo 97 dell'IBAN riordinato (lettere -> 10..35), a pezzi."""
    resto = 0
    for c in testo:
        cifre = str(int(c, 36))
        for d in cifre:
            resto = (resto * 10 + int(d)) % 97
    return resto


def _risultato_iban(errore: str, paese: str = "") -> dict:
    return {"valido": False, "errore": errore, "paese": paese, "abi": "", "cab": "", "conto": "", "banca": ""}


def verifica_iban(iban: str) -> dict:
    """Controlla un IBAN.

    Restituisce ``{"valido", "errore", "paese", "abi", "cab", "conto", "banca"}``.
    Per gli IBAN italiani (e di San Marino) controlla anche il CIN e ricava
    ABI, CAB, numero di conto e, se conosciuta, la banca.
    """
    testo = _compatta(_vuole_testo(iban, "L'IBAN"))
    if testo.startswith("IBAN"):
        testo = testo[4:]
    if not testo:
        return _risultato_iban("L'IBAN è vuoto.")
    if not testo.isascii() or not testo.isalnum():
        return _risultato_iban("L'IBAN contiene solo lettere e cifre.")
    if len(testo) < 4 or not testo[:2].isalpha() or not testo[2:4].isdigit():
        return _risultato_iban("L'IBAN inizia con la sigla del paese e due cifre di controllo (es. IT60...).")
    paese = testo[:2]
    attesa = LUNGHEZZE_IBAN.get(paese)
    if attesa is not None and len(testo) != attesa:
        return _risultato_iban(f"Un IBAN {paese} ha {attesa} caratteri, questo ne ha {len(testo)}.", paese)
    if attesa is None and not 15 <= len(testo) <= 34:
        return _risultato_iban(f"Un IBAN ha da 15 a 34 caratteri, questo ne ha {len(testo)}.", paese)
    if _mod97(testo[4:] + testo[:4]) != 1:
        return _risultato_iban("Le cifre di controllo non tornano: probabilmente c'è un errore di battitura.", paese)
    risultato = {"valido": True, "errore": "", "paese": paese, "abi": "", "cab": "", "conto": "", "banca": ""}
    if paese in ("IT", "SM"):
        cin, abi, cab, conto = testo[4], testo[5:10], testo[10:15], testo[15:27]
        if not cin.isalpha() or not abi.isdigit() or not cab.isdigit():
            return _risultato_iban("Dopo le cifre di controllo vengono il CIN (una lettera), l'ABI e il CAB (5 cifre ciascuno).",
                                   paese)
        cin_atteso = _carattere_controllo_bban(abi + cab + conto)
        if cin != cin_atteso:
            return _risultato_iban(f"Il CIN non torna: dovrebbe essere `{cin_atteso}`, non `{cin}`.", paese)
        risultato.update(abi=abi, cab=cab, conto=conto, banca=BANCHE.get(abi, ""))
    return risultato


def _carattere_controllo_bban(bban22: str) -> str:
    """CIN italiano: stesse tabelle del codice fiscale su ABI+CAB+conto (22 caratteri)."""
    somma = 0
    for i, c in enumerate(bban22):
        somma += _CF_DISPARI[c] if i % 2 == 0 else _valore_pari(c)
    return chr(ord("A") + somma % 26)


def formatta_iban(iban: str) -> str:
    """``"it60x0542811101000000123456"`` -> ``"IT60 X054 2811 1010 0000 0123 456"`` (gruppi di 4)."""
    testo = _compatta(_vuole_testo(iban, "L'IBAN"))
    return " ".join(testo[i:i + 4] for i in range(0, len(testo), 4))


# ===========================================================================
# Targhe
# ===========================================================================

#: Lettere mai usate nelle targhe italiane moderne.
_LETTERE_ESCLUSE = "IOQU"
_L = "[A-HJ-NPR-TV-Z]"          # lettere ammesse (senza I, O, Q, U)

_TARGA_AUTO = re.compile(rf"^{_L}{{2}}\d{{3}}{_L}{{2}}$")
_TARGA_MOTO = re.compile(rf"^{_L}{{2}}\d{{5}}$")
_TARGA_CICLOMOTORE = re.compile(rf"^{_L}[0-9A-HJ-NPR-TV-Z]{{5}}$")
_TARGA_CICLOMOTORE_VECCHIA = re.compile(rf"^{_L}[0-9A-HJ-NPR-TV-Z]{{4}}$")

#: Sigle delle province usate nelle targhe storiche (prima del 1994); Roma usava "ROMA".
_SIGLE_STORICHE = {
    "AG", "AL", "AN", "AO", "AP", "AQ", "AR", "AT", "AV", "BA", "BG", "BL", "BN", "BO", "BR", "BS", "BZ",
    "CA", "CB", "CE", "CH", "CL", "CN", "CO", "CR", "CS", "CT", "CZ", "EN", "FE", "FG", "FI", "FO", "FR",
    "GE", "GO", "GR", "IM", "IS", "LE", "LI", "LT", "LU", "MC", "ME", "MI", "MN", "MO", "MS", "MT", "NA",
    "NO", "NU", "OR", "PA", "PC", "PD", "PE", "PG", "PI", "PN", "PO", "PR", "PS", "PT", "PV", "PZ", "RA",
    "RC", "RE", "RG", "RI", "RO", "SA", "SI", "SO", "SP", "SR", "SS", "SV", "TA", "TE", "TN", "TO", "TP",
    "TR", "TS", "TV", "UD", "VA", "VC", "VE", "VI", "VR", "VT", "BI", "LC", "LO", "KR", "VB", "VV", "RN",
    "ROMA",
}
_TARGA_STORICA = re.compile(r"^(ROMA|[A-Z]{2})([0-9A-Z]{5,6})$")


def verifica_targa(targa: str) -> dict:
    """Controlla una targa italiana.

    Restituisce ``{"valido", "errore", "tipo", "nota"}``; ``tipo`` e' uno tra
    ``"auto"`` (formato AA 000 AA, dal 1994), ``"moto"`` (AA 00000, dal 1999),
    ``"ciclomotore"`` (6 caratteri, dal 2006), ``"ciclomotore (contrassegno)"``
    (5 caratteri, 1993-2006) e ``"storica"`` (sigla della provincia, fino al 1994).
    ``nota`` spiega i formati storici.
    """
    testo = _compatta(_vuole_testo(targa, "La targa"))
    risultato = {"valido": False, "errore": "", "tipo": "", "nota": ""}
    if not testo:
        risultato["errore"] = "La targa è vuota."
        return risultato
    if not testo.isascii() or not testo.isalnum():
        risultato["errore"] = "Una targa contiene solo lettere e cifre."
        return risultato
    if _TARGA_AUTO.match(testo):
        return {"valido": True, "errore": "", "tipo": "auto", "nota": ""}
    if _TARGA_MOTO.match(testo):
        return {"valido": True, "errore": "", "tipo": "moto", "nota": ""}
    storica = _TARGA_STORICA.match(testo)
    if storica and storica.group(1) in _SIGLE_STORICHE and any(c.isdigit() for c in storica.group(2)):
        sigla = storica.group(1)
        return {"valido": True, "errore": "", "tipo": "storica",
                "nota": f"Targa provinciale ({'Roma' if sigla == 'ROMA' else sigla}) del vecchio formato, "
                        "rilasciato fino al 1994: oggi non si assegna più."}
    if (_TARGA_CICLOMOTORE.match(testo) and sum(c.isdigit() for c in testo) >= 1
            and sum(c.isalpha() for c in testo) >= 2):
        return {"valido": True, "errore": "", "tipo": "ciclomotore", "nota": ""}
    if (_TARGA_CICLOMOTORE_VECCHIA.match(testo) and sum(c.isdigit() for c in testo) >= 1
            and sum(c.isalpha() for c in testo) >= 2):
        return {"valido": True, "errore": "", "tipo": "ciclomotore (contrassegno)",
                "nota": "Contrassegno per ciclomotori a 5 caratteri (1993-2006), sostituito dalla targa a 6 caratteri."}
    # Messaggi mirati
    esclusi = sorted({c for c in testo if c in _LETTERE_ESCLUSE})
    if esclusi and len(testo) in (5, 6, 7):
        risultato["errore"] = ("Le targhe italiane non usano le lettere I, O, Q e U "
                               f"(qui c'è {', '.join(esclusi)}).")
        return risultato
    if len(testo) == 7 and testo[:2].isalpha() and testo[5:].isalpha():
        risultato["errore"] = "Una targa auto è fatta così: due lettere, tre cifre, due lettere (es. AB 123 CD)."
    elif len(testo) == 7:
        risultato["errore"] = "Il formato non è quello di una targa: auto AB 123 CD, moto AB 12345."
    else:
        risultato["errore"] = (f"Una targa auto ha 7 caratteri (es. AB 123 CD), questa ne ha {len(testo)}.")
    return risultato


# ===========================================================================
# Importi in euro
# ===========================================================================

def formatta_importo(valore: Any, simbolo: bool = True, decimali: int = 2) -> str:
    """``1234.5`` -> ``"1.234,50 €"``: punto per le migliaia, virgola per i decimali.

    Arrotonda a meta' lontano da zero; ``simbolo=falso`` toglie `` €``.
    """
    from ...valori import e_numero, nome_tipo

    if not e_numero(valore):
        raise ErroreTipo(f"Per scrivere un importo serve un numero, non `{nome_tipo(valore)}`.")
    if isinstance(decimali, bool) or not isinstance(decimali, int):
        raise ErroreTipo("`decimali` deve essere un numero intero.")
    if not 0 <= decimali <= 10:
        raise ErroreValore("`decimali` deve essere tra 0 e 10.")
    if isinstance(valore, float) and (valore != valore or valore in (float("inf"), float("-inf"))):
        raise ErroreValore("Questo numero non si può scrivere come importo.")
    quanto = Decimal(str(valore)).quantize(Decimal(1).scaleb(-decimali), rounding=ROUND_HALF_UP)
    negativo = quanto < 0
    assoluto = abs(quanto)
    testo = f"{assoluto:.{decimali}f}"
    intera, _, frazione = testo.partition(".")
    gruppi = []
    while len(intera) > 3:
        gruppi.insert(0, intera[-3:])
        intera = intera[:-3]
    gruppi.insert(0, intera)
    risultato = ".".join(gruppi) + ("," + frazione if decimali else "")
    if negativo:
        risultato = "-" + risultato
    return risultato + (" €" if simbolo else "")


def leggi_importo(testo: str) -> float:
    """``"1.234,50 €"`` -> ``1234.5``. Accetta anche ``€ 12``, ``12,5 euro``, ``-3,20``.

    Con la virgola, i punti sono separatori delle migliaia; senza virgola, un
    punto seguito da gruppi di esattamente 3 cifre indica le migliaia
    (``1.500`` = 1500), altrimenti e' il separatore decimale (``2.5``).
    """
    originale = _vuole_testo(testo, "L'importo")
    t = originale.strip()
    t = re.sub(r"(?i)\b(eur|euro)\b", "", t).replace("€", "")
    t = t.replace(" ", "").replace(" ", "").replace("'", "")
    negativo = False
    if t.startswith("(") and t.endswith(")"):
        negativo, t = True, t[1:-1]
    if t.startswith("-") or t.startswith("+"):
        negativo, t = (t[0] == "-") != negativo, t[1:]
    if t.endswith("-"):
        negativo, t = not negativo, t[:-1]
    errore = ErroreValore(f"`{originale}` non è un importo.",
                          suggerimento="Scrivi l'importo all'italiana, es. \"1.234,50 €\" oppure \"12,5\".")
    if not t or not re.fullmatch(r"[0-9.,]+", t):
        raise errore
    if "," in t:
        if t.count(",") > 1:
            raise errore
        intera, frazione = t.split(",")
        if intera and "." in intera and not re.fullmatch(r"\d{1,3}(\.\d{3})+", intera):
            raise ErroreValore(f"In `{originale}` i punti delle migliaia sono al posto sbagliato.",
                               suggerimento="Il punto separa le migliaia a gruppi di tre cifre: 1.234.567,89.")
        intera = intera.replace(".", "")
        if not frazione.isdigit() and frazione != "":
            raise errore
        numero = (intera or "0") + "." + (frazione or "0")
    elif "." in t:
        if re.fullmatch(r"\d{1,3}(\.\d{3})+", t):
            numero = t.replace(".", "")
        elif t.count(".") == 1:
            numero = t
        else:
            raise errore
    else:
        numero = t
    try:
        valore = float(Decimal(numero))
    except (InvalidOperation, ValueError):
        raise errore from None
    return -valore if negativo and valore else valore


# ===========================================================================
# Calendario: Pasqua e festivita'
# ===========================================================================

def _vuole_anno(anno: Any) -> int:
    if isinstance(anno, bool) or not isinstance(anno, int):
        from ...valori import nome_tipo

        raise ErroreTipo(f"L'anno deve essere un numero intero, non `{nome_tipo(anno)}`.")
    if not 1583 <= anno <= 9999:
        raise ErroreValore(f"L'anno {anno} è fuori dal calendario gregoriano che so calcolare (1583-9999).")
    return anno


def pasqua(anno: int) -> date:
    """Data della Pasqua nel calendario gregoriano (algoritmo di Meeus/Jones/Butcher)."""
    anno = _vuole_anno(anno)
    a = anno % 19
    b, c = divmod(anno, 100)
    d, e = divmod(b, 4)
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = divmod(c, 4)
    l = (32 + 2 * e + 2 * i - h - k) % 7  # noqa: E741 (nome dell'algoritmo)
    m = (a + 11 * h + 22 * l) // 451
    mese, giorno = divmod(h + l - 7 * m + 114, 31)
    return date(anno, mese, giorno + 1)


def festivita(anno: int) -> dict[date, str]:
    """Festivita' nazionali italiane dell'anno, ordinate per data.

    Comprende Pasqua e Lunedi' dell'Angelo; tiene conto delle principali
    variazioni storiche (Epifania sospesa dal 1977 al 1985, Festa della
    Repubblica spostata dal 1977 al 2000, San Francesco d'Assisi dal 2026).
    Se due festivita' cadono lo stesso giorno i nomi sono uniti da " e ".
    """
    anno = _vuole_anno(anno)
    elenco: list[tuple[date, str]] = [(date(anno, 1, 1), "Capodanno")]
    if not 1977 <= anno <= 1985:
        elenco.append((date(anno, 1, 6), "Epifania"))
    p = pasqua(anno)
    elenco.append((p, "Pasqua"))
    elenco.append((p + timedelta(days=1), "Lunedì dell'Angelo"))
    if anno >= 1946:
        elenco.append((date(anno, 4, 25), "Festa della Liberazione"))
    elenco.append((date(anno, 5, 1), "Festa del Lavoro"))
    if anno >= 1947 and not 1977 <= anno <= 2000:
        elenco.append((date(anno, 6, 2), "Festa della Repubblica"))
    elenco.append((date(anno, 8, 15), "Ferragosto"))
    if anno >= 2026:
        elenco.append((date(anno, 10, 4), "San Francesco d'Assisi"))
    elenco.append((date(anno, 11, 1), "Ognissanti"))
    elenco.append((date(anno, 12, 8), "Immacolata Concezione"))
    elenco.append((date(anno, 12, 25), "Natale"))
    elenco.append((date(anno, 12, 26), "Santo Stefano"))
    risultato: dict[date, str] = {}
    for giorno, nome in sorted(elenco, key=lambda x: x[0]):
        risultato[giorno] = f"{risultato[giorno]} e {nome}" if giorno in risultato else nome
    return risultato


def e_festivo(d: Any, domeniche: bool = False) -> str | None:
    """Nome della festivita' nazionale del giorno ``d`` (``date`` o ``"GG/MM/AAAA"``), o None.

    Con ``domeniche=True`` le domeniche senza festivita' restituiscono ``"Domenica"``.
    """
    giorno = _data_da_valore(d)
    nome = festivita(giorno.year).get(giorno)
    if nome is None and domeniche and giorno.weekday() == 6:
        return "Domenica"
    return nome


# ===========================================================================
# Comuni
# ===========================================================================

_CAMPI_COMUNE = ("nome", "provincia", "sigla", "regione", "cap", "codice_catastale")
_COMUNI: list[dict] | None = None
_CHIAVI: list[tuple[str, list[str]]] = []


def _chiave_ricerca(testo: str) -> str:
    """Minuscolo, senza accenti, apostrofi e trattini come spazi."""
    t = _senza_accenti(testo).lower()
    t = re.sub(r"[^a-z0-9]+", " ", t)
    return t.strip()


def carica_comuni(percorso: Any = None, *, ricarica: bool = False) -> list[dict]:
    """Legge ``dati/italia/comuni.csv`` (UTF-8, separatore ``;``) una volta sola.

    Restituisce una lista di dizionari con le chiavi
    ``nome, provincia, sigla, regione, cap, codice_catastale``. Con ``percorso``
    legge un altro file senza cambiare l'elenco usato da :func:`cerca_comuni`.
    """
    global _COMUNI, _CHIAVI
    predefinito = percorso is None
    if _COMUNI is not None and not ricarica and predefinito:
        return _COMUNI
    if predefinito:
        from ...percorsi import file_dati

        percorso = file_dati("italia", "comuni.csv")
    try:
        with open(percorso, encoding="utf-8-sig", newline="") as f:
            righe = list(csv.DictReader(f, delimiter=";"))
    except OSError as e:
        raise ErroreFile(f"Non riesco a leggere l'elenco dei comuni `{percorso}`: {e.strerror or e}.") from e
    comuni = []
    for r in righe:
        voce = {k: (r.get(k) or "").strip() for k in _CAMPI_COMUNE}
        if voce["nome"]:
            voce["codice_catastale"] = voce["codice_catastale"].upper()
            voce["sigla"] = voce["sigla"].upper()
            comuni.append(voce)
    if not predefinito:  # un file indicato a mano non cambia l'elenco usato dalle ricerche
        return comuni
    _COMUNI = comuni
    _CHIAVI = [(_chiave_ricerca(c["nome"]), _chiave_ricerca(c["nome"]).split()) for c in comuni]
    return comuni


def cerca_comuni(testo: str, limite: int = 20) -> list[dict]:
    """Cerca i comuni il cui nome contiene ``testo`` (senza accenti ne' maiuscole).

    Ordine: nome uguale, poi nome che inizia con il testo, poi una parola del
    nome che inizia con il testo (``"stabia"`` trova Castellammare di Stabia),
    poi sigla della provincia uguale; a parita', in ordine alfabetico.
    Restituisce copie dei dizionari (al massimo ``limite``; 0 = tutti).
    """
    _vuole_testo(testo, "Il testo da cercare")
    if isinstance(limite, bool) or not isinstance(limite, int):
        raise ErroreTipo("`limite` deve essere un numero intero.")
    comuni = carica_comuni()
    chiave = _chiave_ricerca(testo)
    if not chiave:
        return []
    parole_cercate = chiave.split()
    trovati: list[tuple[int, str, dict]] = []
    for comune, (nome, parole) in zip(comuni, _CHIAVI):
        if nome == chiave:
            rango = 0
        elif nome.startswith(chiave):
            rango = 1
        elif all(any(p.startswith(pc) for p in parole) for pc in parole_cercate):
            rango = 2
        elif len(chiave) == 2 and comune["sigla"].lower() == chiave:
            rango = 3
        else:
            continue
        trovati.append((rango, nome, comune))
    trovati.sort(key=lambda x: (x[0], x[1]))
    if limite > 0:
        trovati = trovati[:limite]
    return [dict(c) for _, _, c in trovati]


def comune_da_codice_catastale(codice: str) -> dict | None:
    """Comune con quel codice catastale (es. ``"H501"`` -> Roma), o None se non e' tra quelli conosciuti."""
    c = _vuole_testo(codice, "Il codice catastale").strip().upper()
    for comune in carica_comuni():
        if comune["codice_catastale"] == c:
            return dict(comune)
    return None
