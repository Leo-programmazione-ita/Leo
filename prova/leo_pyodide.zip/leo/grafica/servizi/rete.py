"""Servizi di rete per i controlli ``RichiestaWeb`` e ``ServerWeb``.

API:

    scarica(indirizzo, metodo="GET", dati=None, intestazioni=None, tempo_massimo=15)
        -> {"stato", "testo", "json", "intestazioni", "messaggio"}
    class RichiestaAsincrona(indirizzo, metodo="GET", dati=None, al_termine=None)
        .avvia()      # esegue ``scarica`` in un thread e poi chiama
                      # al_termine(risposta, None) oppure al_termine(None, errore)
    class ServerLocale(porta, gestore, host="127.0.0.1")
        .avvia(), .ferma(), .indirizzo, .attivo

Note:

* Una risposta HTTP con stato di errore (404, 500, ...) NON è un'eccezione:
  ``scarica`` restituisce il dizionario con ``stato`` e un ``messaggio`` in
  italiano; il programma decide cosa fare. Sono eccezioni solo i problemi
  veri: indirizzo non valido (``ErroreValore``), rete assente, server
  irraggiungibile o tempo scaduto (``ErroreFile``, come una risorsa che non
  si riesce a leggere).
* Il corpo JSON (se la risposta lo è) viene convertito in valori Leo
  (dizionari, liste, testi, numeri, logici, ``nulla``) nella chiave ``json``.
* Gli indirizzi locali (localhost, 127.0.0.1) non passano mai per un proxy.
* ``al_termine`` di :class:`RichiestaAsincrona` e il ``gestore`` di
  :class:`ServerLocale` vengono chiamati in un thread secondario: chi li usa
  in un'interfaccia grafica deve riportare il lavoro nel thread principale.
"""

from __future__ import annotations

import json
import socket
import threading
import urllib.error
import urllib.parse
import urllib.request
from email.message import Message
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any, Callable, Optional

from ...errori import ErroreDante, ErroreFile, ErroreTipo, ErroreValore

__all__ = ["scarica", "RichiestaAsincrona", "ServerLocale", "METODI", "descrizione_stato"]

METODI: tuple[str, ...] = ("GET", "POST", "PUT", "DELETE", "PATCH", "HEAD")

_DESCRIZIONI = {
    200: "Tutto bene", 201: "Creato", 202: "Accettato", 204: "Nessun contenuto",
    301: "Spostato definitivamente", 302: "Spostato temporaneamente", 304: "Non modificato",
    400: "Richiesta non valida", 401: "Serve l'autenticazione", 403: "Accesso vietato",
    404: "Pagina non trovata", 405: "Metodo non permesso", 408: "Tempo scaduto sul server",
    409: "Conflitto", 410: "Non più disponibile", 413: "Dati troppo grandi",
    415: "Tipo di dati non supportato", 418: "Sono una teiera", 429: "Troppe richieste",
    500: "Errore interno del server", 501: "Non implementato", 502: "Gateway non valido",
    503: "Servizio non disponibile", 504: "Tempo scaduto sul gateway",
}

_HOST_LOCALI = {"localhost", "127.0.0.1", "::1", "[::1]"}


def descrizione_stato(stato: int) -> str:
    """Descrizione in italiano di un codice di stato HTTP."""
    if stato in _DESCRIZIONI:
        return f"{_DESCRIZIONI[stato]} ({stato})"
    if 200 <= stato < 300:
        return f"Riuscito ({stato})"
    if 300 <= stato < 400:
        return f"Reindirizzamento ({stato})"
    if 400 <= stato < 500:
        return f"Errore nella richiesta ({stato})"
    if stato >= 500:
        return f"Errore del server ({stato})"
    return f"Stato {stato}"


def _controlla_indirizzo(indirizzo: Any) -> urllib.parse.SplitResult:
    if not isinstance(indirizzo, str):
        raise ErroreTipo("L'indirizzo deve essere un testo, per esempio \"https://esempio.it\".")
    indirizzo = indirizzo.strip()
    parti = urllib.parse.urlsplit(indirizzo)
    if parti.scheme.lower() not in ("http", "https") or not parti.netloc:
        suggerimento = ("Forse intendevi \"https://" + indirizzo + "\"?"
                        if indirizzo and "://" not in indirizzo
                        else "Un indirizzo comincia con \"http://\" o \"https://\".")
        raise ErroreValore(f"`{indirizzo}` non è un indirizzo web valido.",
                           suggerimento=suggerimento)
    return parti


def _in_json(valore: Any) -> bytes:
    try:
        return json.dumps(valore, ensure_ascii=False).encode("utf-8")
    except (TypeError, ValueError) as e:
        raise ErroreTipo(f"Questi dati non si possono inviare come JSON ({e}).") from None


def _decodifica(corpo: bytes, intestazioni: Message) -> str:
    charset = intestazioni.get_content_charset() or "utf-8"
    try:
        return corpo.decode(charset, errors="replace")
    except LookupError:
        return corpo.decode("utf-8", errors="replace")


def _prova_json(testo: str, tipo: str) -> Any:
    pulito = testo.strip()
    if not pulito:
        return None
    if "json" in tipo.lower() or pulito[0] in "[{":
        try:
            return json.loads(pulito)
        except ValueError:
            return None
    return None


def _intestazioni_dict(intestazioni: Any) -> dict:
    risultato: dict[str, str] = {}
    if intestazioni is None:
        return risultato
    for chiave, valore in intestazioni.items():
        if chiave in risultato:
            risultato[chiave] += ", " + valore
        else:
            risultato[chiave] = valore
    return risultato


def scarica(indirizzo: str, metodo: str = "GET", dati: Any = None,
            intestazioni: Optional[dict] = None, tempo_massimo: float = 15) -> dict:
    """Esegue una richiesta HTTP e restituisce la risposta come dizionario.

    ``dati``: dizionario o lista → corpo JSON (per GET/DELETE/HEAD un
    dizionario diventa invece parametri nell'indirizzo, ``?a=1&b=2``);
    testo → corpo in testo semplice; ``nulla`` → nessun corpo.
    """
    parti = _controlla_indirizzo(indirizzo)
    if not isinstance(metodo, str) or metodo.strip().upper() not in METODI:
        raise ErroreValore(f"Metodo `{metodo}` non valido.",
                           suggerimento="Usa " + ", ".join(METODI[:4]) + ".")
    metodo = metodo.strip().upper()
    if isinstance(tempo_massimo, bool) or not isinstance(tempo_massimo, (int, float)) \
            or tempo_massimo <= 0:
        raise ErroreValore("`tempo_massimo` deve essere un numero di secondi maggiore di zero.")
    if intestazioni is not None and not isinstance(intestazioni, dict):
        raise ErroreTipo("Le intestazioni devono essere un dizionario nome -> valore.")
    url = indirizzo.strip()
    corpo: bytes | None = None
    testate = {"User-Agent": "Leo/1.0 (linguaggio didattico)", "Accept": "*/*"}
    if dati is not None:
        if metodo in ("GET", "DELETE", "HEAD") and isinstance(dati, dict):
            query = urllib.parse.urlencode(
                {str(k): ("vero" if v is True else "falso" if v is False else
                          "" if v is None else str(v)) for k, v in dati.items()})
            url += ("&" if parti.query else "?") + query
        elif isinstance(dati, (dict, list)):
            corpo = _in_json(dati)
            testate["Content-Type"] = "application/json; charset=utf-8"
        elif isinstance(dati, bytes):
            corpo = dati
            testate["Content-Type"] = "application/octet-stream"
        else:
            testo = dati if isinstance(dati, str) else json.dumps(dati)
            corpo = testo.encode("utf-8")
            testate["Content-Type"] = "text/plain; charset=utf-8"
    for chiave, valore in (intestazioni or {}).items():
        testate[str(chiave)] = str(valore)
    richiesta = urllib.request.Request(url, data=corpo, headers=testate, method=metodo)
    host = (parti.hostname or "").lower()
    if host in _HOST_LOCALI:
        apri = urllib.request.build_opener(urllib.request.ProxyHandler({})).open
    else:
        apri = urllib.request.urlopen
    try:
        try:
            risposta = apri(richiesta, timeout=tempo_massimo)
        except urllib.error.HTTPError as e:
            risposta = e  # anche gli stati di errore hanno un corpo da leggere
        with risposta:
            stato = int(risposta.status if getattr(risposta, "status", None) is not None
                        else risposta.getcode())
            contenuto = risposta.read()
            testate_risposta = risposta.headers
    except (socket.timeout, TimeoutError):
        raise ErroreFile(f"Il server non ha risposto entro {tempo_massimo} secondi ({url}).",
                         suggerimento="Riprova più tardi o aumenta `tempo_massimo`.") from None
    except urllib.error.URLError as e:
        motivo = e.reason
        if isinstance(motivo, (socket.timeout, TimeoutError)):
            raise ErroreFile(f"Il server non ha risposto entro {tempo_massimo} secondi ({url}).",
                             suggerimento="Riprova più tardi o aumenta `tempo_massimo`.") from None
        if isinstance(motivo, socket.gaierror):
            raise ErroreFile(f"Non trovo il sito `{host}`.",
                             suggerimento="Controlla l'indirizzo e la connessione a Internet.") from None
        if isinstance(motivo, ConnectionRefusedError):
            raise ErroreFile(f"Il server `{parti.netloc}` ha rifiutato la connessione.",
                             suggerimento="Forse il server non è acceso o la porta è sbagliata.") from None
        raise ErroreFile(f"Non riesco a collegarmi a `{url}` ({motivo}).",
                         suggerimento="Controlla la connessione a Internet.") from None
    except (ConnectionError, OSError) as e:
        raise ErroreFile(f"La connessione con `{parti.netloc}` si è interrotta ({e}).",
                         suggerimento="Controlla la connessione e riprova.") from None
    testo = _decodifica(contenuto, testate_risposta)
    tipo = testate_risposta.get("Content-Type", "") if testate_risposta else ""
    return {
        "stato": stato,
        "testo": testo,
        "json": _prova_json(testo, tipo),
        "intestazioni": _intestazioni_dict(testate_risposta),
        "messaggio": descrizione_stato(stato),
    }


class RichiestaAsincrona:
    """Esegue :func:`scarica` in un thread e poi chiama ``al_termine``.

    ``al_termine(risposta, None)`` se tutto va bene, ``al_termine(None,
    errore)`` in caso di errore (sempre un ``ErroreDante``).
    """

    def __init__(self, indirizzo: str, metodo: str = "GET", dati: Any = None,
                 al_termine: Optional[Callable[[Optional[dict], Optional[ErroreDante]], None]] = None,
                 *, intestazioni: Optional[dict] = None, tempo_massimo: float = 15) -> None:
        self.indirizzo = indirizzo
        self.metodo = metodo
        self.dati = dati
        self.al_termine = al_termine
        self.intestazioni = intestazioni
        self.tempo_massimo = tempo_massimo
        self.risposta: Optional[dict] = None
        self.errore: Optional[ErroreDante] = None
        self._thread: Optional[threading.Thread] = None
        self._finito = threading.Event()

    @property
    def in_corso(self) -> bool:
        return self._thread is not None and not self._finito.is_set()

    def avvia(self) -> None:
        """Parte la richiesta (non blocca). Errore se è già in corso."""
        if self.in_corso:
            raise ErroreValore("La richiesta è già in corso.",
                               suggerimento="Aspetta l'evento `risposta` prima di inviarne un'altra.")
        self.risposta = None
        self.errore = None
        self._finito.clear()
        self._thread = threading.Thread(target=self._esegui, name="Leo-RichiestaWeb", daemon=True)
        self._thread.start()

    def _esegui(self) -> None:
        risposta: Optional[dict] = None
        errore: Optional[ErroreDante] = None
        try:
            risposta = scarica(self.indirizzo, self.metodo, self.dati, self.intestazioni,
                               self.tempo_massimo)
        except ErroreDante as e:
            errore = e
        except Exception as e:  # imprevisto: diventa comunque un errore Leo
            errore = ErroreValore(f"Errore imprevisto durante la richiesta: {e}.")
        self.risposta, self.errore = risposta, errore
        self._finito.set()
        if self.al_termine is not None:
            self.al_termine(risposta, errore)

    def aspetta(self, tempo: Optional[float] = None) -> bool:
        """Aspetta la fine (al massimo ``tempo`` secondi); vero se è finita."""
        if self._thread is None:
            return True
        self._thread.join(tempo)
        return not self._thread.is_alive()


# ---------------------------------------------------------------------------
# Server locale
# ---------------------------------------------------------------------------

_CHIAVI_RISPOSTA = {"stato", "testo", "corpo", "json", "tipo", "intestazioni"}


def _parametri(query: str) -> dict:
    risultato: dict[str, Any] = {}
    for chiave, valori in urllib.parse.parse_qs(query, keep_blank_values=True).items():
        risultato[chiave] = valori[0] if len(valori) == 1 else list(valori)
    return risultato


def _latino(valore: Any) -> str:
    """Le intestazioni HTTP accettano solo caratteri latin-1: gli altri vengono
    codificati con la notazione ``%XX`` (UTF-8)."""
    testo = str(valore).replace("\r", " ").replace("\n", " ")
    try:
        testo.encode("latin-1")
        return testo
    except UnicodeEncodeError:
        return urllib.parse.quote(testo, safe=" !#$&'()*+,-./:;=?@[]_~")


def _prepara_risposta(risultato: Any) -> tuple[int, str, bytes, dict]:
    """Valore restituito dal gestore -> (stato, tipo, corpo, intestazioni)."""
    if risultato is None:
        return 200, "text/plain; charset=utf-8", b"", {}
    if isinstance(risultato, str):
        inizio = risultato.lstrip()[:15].lower()
        tipo = ("text/html; charset=utf-8" if inizio.startswith(("<!doctype", "<html"))
                else "text/plain; charset=utf-8")
        return 200, tipo, risultato.encode("utf-8"), {}
    if isinstance(risultato, dict) and risultato and set(risultato) <= _CHIAVI_RISPOSTA:
        stato = risultato.get("stato", 200)
        if isinstance(stato, bool) or not isinstance(stato, int) or not 100 <= stato <= 599:
            raise ErroreValore(f"Stato HTTP `{stato}` non valido nella risposta del gestore.")
        intestazioni = {_latino(k): _latino(v)
                        for k, v in (risultato.get("intestazioni") or {}).items()}
        if "json" in risultato:
            corpo = _in_json(risultato["json"])
            tipo = "application/json; charset=utf-8"
        else:
            testo = risultato.get("testo", risultato.get("corpo", ""))
            testo = "" if testo is None else str(testo)
            corpo = testo.encode("utf-8")
            inizio = testo.lstrip()[:15].lower()
            tipo = ("text/html; charset=utf-8" if inizio.startswith(("<!doctype", "<html"))
                    else "text/plain; charset=utf-8")
        if risultato.get("tipo"):
            tipo = str(risultato["tipo"])
        return stato, tipo, corpo, intestazioni
    if isinstance(risultato, (dict, list, int, float, bool)):
        return 200, "application/json; charset=utf-8", _in_json(risultato), {}
    return 200, "text/plain; charset=utf-8", str(risultato).encode("utf-8"), {}


class _Gestore(BaseHTTPRequestHandler):
    server_version = "LeoServerLocale/1.0"
    protocol_version = "HTTP/1.1"
    proprietario: "ServerLocale"  # impostato nella sottoclasse creata da ServerLocale

    def log_message(self, formato: str, *argomenti: Any) -> None:  # silenzioso
        pass

    def _gestisci(self) -> None:
        parti = urllib.parse.urlsplit(self.path)
        lunghezza = int(self.headers.get("Content-Length") or 0)
        grezzo = self.rfile.read(lunghezza) if lunghezza > 0 else b""
        corpo = _decodifica(grezzo, self.headers)
        richiesta = {
            "percorso": urllib.parse.unquote(parti.path) or "/",
            "metodo": self.command,
            "parametri": _parametri(parti.query),
            "corpo": corpo,
            "json": _prova_json(corpo, self.headers.get("Content-Type", "")),
            "intestazioni": _intestazioni_dict(self.headers),
            "cliente": self.client_address[0],
        }
        try:
            stato, tipo, contenuto, extra = _prepara_risposta(self.proprietario.gestore(richiesta))
        except ErroreDante as e:
            stato, tipo, contenuto, extra = 500, "text/plain; charset=utf-8", \
                f"Errore nel programma: {e.messaggio}".encode("utf-8"), {}
            self.proprietario.ultimo_errore = e
        except Exception as e:  # il server non deve fermarsi per un errore del gestore
            stato, tipo, contenuto, extra = 500, "text/plain; charset=utf-8", \
                f"Errore nel programma: {e}".encode("utf-8"), {}
            self.proprietario.ultimo_errore = ErroreValore(str(e))
        self.send_response(stato)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(contenuto)))
        for chiave, valore in extra.items():
            self.send_header(chiave, valore)
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(contenuto)

    do_GET = do_POST = do_PUT = do_DELETE = do_PATCH = do_HEAD = do_OPTIONS = _gestisci


class ServerLocale:
    """Piccolo server web in un thread.

    ``gestore(richiesta)`` riceve ``{"percorso", "metodo", "parametri",
    "corpo", "json", "intestazioni", "cliente"}`` e restituisce:

    * un testo → risposta 200 (HTML se comincia con ``<html`` o ``<!doctype``);
    * un dizionario con alcune delle chiavi ``stato``, ``testo``, ``json``,
      ``tipo``, ``intestazioni`` → risposta costruita da quelle;
    * qualunque altro dizionario o lista → risposta JSON.

    Per sicurezza ascolta solo su 127.0.0.1 (questo computer), a meno di
    indicare un altro ``host``. ``porta=0`` sceglie una porta libera.
    """

    def __init__(self, porta: int, gestore: Callable[[dict], Any], host: str = "127.0.0.1") -> None:
        if isinstance(porta, bool) or not isinstance(porta, int) or not 0 <= porta <= 65535:
            raise ErroreValore(f"Porta `{porta}` non valida: deve essere un intero tra 0 e 65535.")
        if not callable(gestore):
            raise ErroreTipo("Il gestore del server deve essere una funzione.")
        self.porta = porta
        self.gestore = gestore
        self.host = host
        self.ultimo_errore: Optional[ErroreDante] = None
        self._server: Optional[ThreadingHTTPServer] = None
        self._thread: Optional[threading.Thread] = None
        self._blocco = threading.Lock()

    @property
    def attivo(self) -> bool:
        return self._server is not None

    @property
    def indirizzo(self) -> str:
        """Indirizzo da aprire nel browser (``""`` se il server è spento)."""
        if self._server is None:
            return ""
        host = self.host
        if host in ("", "0.0.0.0"):
            host = "127.0.0.1"
        elif ":" in host:
            host = f"[{host}]"
        return f"http://{host}:{self._server.server_address[1]}/"

    def avvia(self) -> None:
        """Accende il server (non fa niente se è già acceso)."""
        with self._blocco:
            if self._server is not None:
                return
            gestore = type("GestoreDante", (_Gestore,), {"proprietario": self})
            classe = ThreadingHTTPServer
            if ":" in self.host:
                classe = type("ServerIPv6", (ThreadingHTTPServer,), {"address_family": socket.AF_INET6})
            try:
                server = classe((self.host, self.porta), gestore)
            except OSError as e:
                if getattr(e, "errno", None) in (98, 48, 10048) or "in use" in str(e).lower():
                    raise ErroreFile(f"La porta {self.porta} è già in uso da un altro programma.",
                                     suggerimento="Scegli un'altra porta, per esempio 8081.") from None
                raise ErroreFile(f"Non riesco ad accendere il server su {self.host}:{self.porta} ({e}).",
                                 suggerimento="Prova un'altra porta (sopra 1024).") from None
            server.daemon_threads = True
            self._server = server
            self._thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.2},
                                            name="Leo-ServerLocale", daemon=True)
            self._thread.start()

    def ferma(self) -> None:
        """Spegne il server (non fa niente se è già spento)."""
        with self._blocco:
            server, thread = self._server, self._thread
            self._server = self._thread = None
        if server is None:
            return
        server.shutdown()
        server.server_close()
        if thread is not None:
            thread.join(5)

    def __enter__(self) -> "ServerLocale":
        self.avvia()
        return self

    def __exit__(self, *_: Any) -> None:
        self.ferma()
