"""Segnali per gli strumenti di misura (Oscilloscopio, Quadrante), senza Qt.

API::

    class BufferSegnale(capacita=200, soglia=None):
        aggiungi(v) -> bool      # vero se la soglia e' stata superata PROPRIO ORA
        valori, minimo, massimo, media, ultimo
        svuota(), punti(larghezza, altezza, minimo, massimo)
    angolo_lancetta(valore, minimo, massimo, inizio=-135.0, fine=135.0) -> float
"""

from __future__ import annotations

from collections import deque
from typing import Iterable

from ...errori import ErroreTipo, ErroreValore


def _numero(v, cosa: str = "Il valore") -> float:
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        raise ErroreTipo(f"{cosa} deve essere un numero.")
    if v != v:  # NaN
        raise ErroreValore(f"{cosa} non è un numero valido.")
    return float(v)


class BufferSegnale:
    """Ultimi ``capacita`` campioni di un segnale, con soglia di allarme.

    La soglia e' "superata" quando un campione e' maggiore della soglia e il
    precedente non lo era (o non c'era): cosi' l'evento ``soglia_superata``
    scatta una volta sola per ogni superamento, non a ogni campione.
    """

    def __init__(self, capacita: int = 200, soglia: float | None = None) -> None:
        self._campioni: deque[float] = deque(maxlen=self._capacita_valida(capacita))
        self.soglia = None if soglia is None else _numero(soglia, "La soglia")
        self._sopra = False

    @staticmethod
    def _capacita_valida(capacita) -> int:
        if isinstance(capacita, bool) or not isinstance(capacita, int):
            raise ErroreTipo("Il numero di campioni deve essere un intero.")
        if capacita < 2:
            raise ErroreValore("Servono almeno 2 campioni.")
        return capacita

    # --- capacita' ------------------------------------------------------------
    @property
    def capacita(self) -> int:
        return self._campioni.maxlen or 0

    @capacita.setter
    def capacita(self, nuova: int) -> None:
        nuova = self._capacita_valida(nuova)
        if nuova != self.capacita:
            self._campioni = deque(self._campioni, maxlen=nuova)

    # --- dati --------------------------------------------------------------------
    def aggiungi(self, v) -> bool:
        valore = _numero(v)
        self._campioni.append(valore)
        if self.soglia is None:
            self._sopra = False
            return False
        sopra = valore > self.soglia
        superata = sopra and not self._sopra
        self._sopra = sopra
        return superata

    def estendi(self, valori: Iterable) -> list[float]:
        """Aggiunge piu' campioni; restituisce quelli che hanno superato la soglia."""
        return [float(v) for v in valori if self.aggiungi(v)]

    def svuota(self) -> None:
        self._campioni.clear()
        self._sopra = False

    def __len__(self) -> int:
        return len(self._campioni)

    @property
    def valori(self) -> list[float]:
        return list(self._campioni)

    @property
    def ultimo(self) -> float | None:
        return self._campioni[-1] if self._campioni else None

    @property
    def minimo(self) -> float | None:
        return min(self._campioni) if self._campioni else None

    @property
    def massimo(self) -> float | None:
        return max(self._campioni) if self._campioni else None

    @property
    def media(self) -> float | None:
        return sum(self._campioni) / len(self._campioni) if self._campioni else None

    # --- disegno --------------------------------------------------------------------
    def punti(self, larghezza: float, altezza: float, minimo: float, massimo: float) -> list[tuple[float, float]]:
        """Coordinate (x, y) in pixel per disegnare la traccia in un'area
        ``larghezza`` x ``altezza``: il campione piu' vecchio a sinistra, ``minimo``
        in basso e ``massimo`` in alto (valori fuori scala tagliati ai bordi).
        La traccia occupa sempre tutta la capacita': con pochi campioni parte da destra."""
        n = len(self._campioni)
        if n == 0 or larghezza <= 0 or altezza <= 0:
            return []
        passo = larghezza / (self.capacita - 1)
        x0 = larghezza - passo * (n - 1)
        return [(x0 + i * passo, y_per_valore(v, altezza, minimo, massimo))
                for i, v in enumerate(self._campioni)]


def y_per_valore(valore: float, altezza: float, minimo: float, massimo: float) -> float:
    """Posizione verticale in pixel (0 = in alto) di ``valore`` sulla scala ``minimo``-``massimo``."""
    if massimo == minimo:
        return altezza / 2
    t = (valore - minimo) / (massimo - minimo)
    t = max(0.0, min(1.0, t))
    return altezza * (1.0 - t)


def angolo_lancetta(valore, minimo, massimo, inizio: float = -135.0, fine: float = 135.0) -> float:
    """Angolo in gradi della lancetta di un quadrante (0 = verso l'alto, positivo in senso orario).

    ``valore`` fuori dall'intervallo viene portato al bordo; se ``minimo ==
    massimo`` la lancetta resta su ``inizio``. Funziona anche con ``minimo >
    massimo`` (scala al contrario).
    """
    v = _numero(valore)
    lo = _numero(minimo, "Il minimo")
    hi = _numero(massimo, "Il massimo")
    if hi == lo:
        return float(inizio)
    t = (v - lo) / (hi - lo)
    t = max(0.0, min(1.0, t))
    return float(inizio) + (float(fine) - float(inizio)) * t


__all__ = ["BufferSegnale", "angolo_lancetta", "y_per_valore"]
