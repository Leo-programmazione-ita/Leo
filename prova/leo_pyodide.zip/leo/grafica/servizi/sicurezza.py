"""Servizi di sicurezza per i controlli ``Cifratura`` e ``MisuratorePassword``.

API:

    valuta_password(pw) -> {"punteggio": int, "livello": str, "consigli": list[str]}
    impronta(testo, algoritmo="sha256") -> str
    genera_password(lunghezza=16, simboli=True) -> str
    cifra(testo, chiave) -> str
    decifra(cifrato, chiave) -> str

``cifra``/``decifra`` usano la cifratura VERA di Leo (:mod:`leo.cifratura`):
AES-256-GCM con la chiave ricavata dalla frase segreta con scrypt e un sale
casuale; lo stesso formato di ``cifra_testo``/``decifra_testo`` della libreria.
Il cifrario lo fa una libreria riconosciuta (``cryptography`` sul PC,
``javax.crypto`` sul telefono); se manca, un errore spiega come installarla.

``decifra`` legge ancora i testi del vecchio schema didattico ("DNT1",
HMAC-SHA256 in modalità contatore), che nessuno aveva verificato: solo per
recuperare i dati vecchi, non si usa più per cifrare.

Impronte: ``sha256`` (consigliato) e ``sha512``; ``sha1`` e ``md5`` NON sono
sicuri (si possono costruire due testi con la stessa impronta) e restano solo
per confrontare impronte già esistenti.
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import re
import secrets
import string

from ...errori import ErroreTipo, ErroreValore

__all__ = ["valuta_password", "impronta", "genera_password", "cifra", "decifra",
           "LIVELLI_PASSWORD", "ALGORITMI", "ALGORITMI_NON_SICURI"]

#: Livelli restituiti da :func:`valuta_password`, dal più basso al più alto.
LIVELLI_PASSWORD: tuple[str, ...] = ("debolissima", "debole", "media", "forte", "fortissima")

#: Algoritmi di impronta proposti nel controllo ``Cifratura``.
ALGORITMI: tuple[str, ...] = ("sha256", "sha512", "sha1", "md5")
#: Algoritmi NON sicuri: solo per confrontare impronte vecchie (non per password o firme).
ALGORITMI_NON_SICURI: tuple[str, ...] = ("sha1", "md5")

# ---------------------------------------------------------------------------
# Valutazione delle password
# ---------------------------------------------------------------------------

# Piccola lista di parole e password comuni (italiane e internazionali).
_PAROLE_COMUNI = frozenset("""
password passwort parola parolachiave segreto segreta accesso entra entrare admin amministratore
utente ospite qwerty qwertz azerty asdfgh zxcvbn ciao ciaociao amore amoremio tiamo tesoro
cuore bacio baci stella sole luna mare cielo fiore rosa gatto gatta cane cagnolino micio
juventus juve milan inter roma lazio napoli torino fiorentina forzajuve forzamilan forzainter
forzaroma forzanapoli forzaitalia italia italiano calcio pallone campione mamma papa papà
nonna nonno famiglia bambino bambina principessa principe dragone drago angelo diavolo
dio gesù gesu maria francesco giuseppe giovanni andrea marco luca matteo alessandro lorenzo
giulia sofia chiara martina sara anna laura francesca federica valentina elisa alessia
estate inverno primavera autunno lunedi domenica natale pasqua ferrari vespa pizza pasta
mozzarella caffe caffè cioccolato benvenuto benvenuti buongiorno buonasera grazie prego
dante alighieri computer internet scuola casa lavoro ufficio segreteria welcome letmein
iloveyou monkey dragon football baseball master shadow sunshine princess superman batman
trustno1 starwars pokemon minecraft fortnite
""".split())

_TASTIERA = ("qwertyuiop", "asdfghjkl", "zxcvbnm", "qwertzuiop", "azertyuiop",
             "1234567890", "0987654321")

_LEET = str.maketrans({"0": "o", "1": "i", "3": "e", "4": "a", "5": "s", "7": "t",
                       "@": "a", "$": "s", "!": "i", "8": "b", "9": "g"})

_ANNO = re.compile(r"(19|20)\d\d")
_DATA = re.compile(r"(?<!\d)(0?[1-9]|[12]\d|3[01])[\-/.]?(0?[1-9]|1[0-2])[\-/.]?((19|20)?\d\d)(?!\d)")


def _classi(pw: str) -> dict[str, bool]:
    return {
        "minuscole": any(c.islower() for c in pw),
        "maiuscole": any(c.isupper() for c in pw),
        "cifre": any(c.isdigit() for c in pw),
        "simboli": any(not c.isalnum() for c in pw),
    }


def _ha_sequenza(pw: str, lunghezza: int = 3) -> bool:
    """Vero se contiene lettere/cifre consecutive (abc, 321) o righe di tastiera."""
    minuscola = pw.lower()
    for i in range(len(minuscola) - lunghezza + 1):
        pezzo = minuscola[i:i + lunghezza]
        if pezzo.isalnum():
            differenze = {ord(pezzo[k + 1]) - ord(pezzo[k]) for k in range(lunghezza - 1)}
            if differenze in ({1}, {-1}):
                return True
        for riga in _TASTIERA:
            if pezzo in riga or pezzo in riga[::-1]:
                if len(pezzo) >= 4 or pezzo.isalpha():
                    return True
    return False


def _ha_ripetizioni(pw: str) -> bool:
    """Tre caratteri uguali di fila, oppure un pezzo ripetuto (abcabc)."""
    if re.search(r"(.)\1\1", pw):
        return True
    return bool(re.fullmatch(r"(.{1,4})\1+.?", pw)) and len(pw) >= 4


def _parola_comune(pw: str) -> str | None:
    """Parola comune contenuta nella password (anche scritta 'l33t')."""
    minuscola = pw.lower()
    candidati = {minuscola, minuscola.translate(_LEET), re.sub(r"[^a-zàèéìòù]", "", minuscola)}
    migliore: str | None = None
    for testo in candidati:
        for parola in _PAROLE_COMUNI:
            if len(parola) >= 4 and parola in testo:
                if migliore is None or len(parola) > len(migliore):
                    migliore = parola
    return migliore


def _ha_data(pw: str) -> bool:
    return bool(_ANNO.search(pw) or _DATA.search(pw))


def valuta_password(pw: str) -> dict:
    """Valuta la robustezza di una password.

    Restituisce ``{"punteggio": 0..100, "livello": ..., "consigli": [...]}``
    dove ``livello`` è uno di ``debolissima``, ``debole``, ``media``,
    ``forte``, ``fortissima``. I consigli sono frasi in italiano.
    """
    if pw is None:
        pw = ""
    if not isinstance(pw, str):
        raise ErroreTipo("La password da valutare deve essere un testo.")
    consigli: list[str] = []
    if not pw:
        return {"punteggio": 0, "livello": "debolissima",
                "consigli": ["Scrivi una password: almeno 12 caratteri, con lettere, "
                             "numeri e simboli."]}

    lunghezza = len(pw)
    classi = _classi(pw)
    varieta = sum(classi.values())

    # Punti per la lunghezza (fino a 50) e per la varietà (fino a 40).
    punteggio = min(50, lunghezza * 4)
    punteggio += (varieta - 1) * 10 + (10 if varieta >= 1 else 0)
    if lunghezza >= 16:
        punteggio += 10
    if lunghezza >= 20:
        punteggio += 10
    diversi = len(set(pw))
    if diversi < lunghezza / 2:
        punteggio -= 10

    if lunghezza < 8:
        consigli.append("È troppo corta: usa almeno 12 caratteri.")
        punteggio = min(punteggio, 25)
    elif lunghezza < 12:
        consigli.append("Allungala: con almeno 12 caratteri è molto più difficile da indovinare.")
        punteggio = min(punteggio, 70)

    if not classi["minuscole"] and not classi["maiuscole"]:
        consigli.append("Aggiungi delle lettere, minuscole e maiuscole.")
    elif not classi["minuscole"] or not classi["maiuscole"]:
        consigli.append("Mescola lettere minuscole e maiuscole.")
    if not classi["cifre"]:
        consigli.append("Aggiungi qualche numero.")
    if not classi["simboli"]:
        consigli.append("Aggiungi un simbolo, per esempio ! ? # @ % &.")
    if varieta == 1:
        punteggio -= 10
        if pw.isdigit():
            consigli.append("Una password fatta solo di numeri si indovina in fretta.")

    parola = _parola_comune(pw)
    if parola:
        punteggio -= 30
        punteggio = min(punteggio, 35)
        consigli.append(f"Contiene la parola comune «{parola}»: evita parole, nomi e squadre "
                        "facili da indovinare.")
    if _ha_sequenza(pw):
        punteggio -= 15
        consigli.append("Evita le sequenze come «abc», «123» o «qwerty».")
    if _ha_ripetizioni(pw):
        punteggio -= 15
        consigli.append("Evita di ripetere gli stessi caratteri (come «aaa» o «abcabc»).")
    if _ha_data(pw):
        punteggio -= 15
        consigli.append("Evita le date (compleanni, anni): sono tra le prime cose che si provano.")

    punteggio = max(0, min(100, int(punteggio)))
    livello = LIVELLI_PASSWORD[min(4, punteggio // 20)]
    if not consigli:
        if livello == "fortissima":
            consigli.append("Password molto robusta. Non usarla su più siti e conservala in un posto sicuro.")
        else:
            consigli.append("Per renderla ancora più forte, allungala con altre parole o simboli.")
    return {"punteggio": punteggio, "livello": livello, "consigli": consigli}


# ---------------------------------------------------------------------------
# Impronte e generazione di password
# ---------------------------------------------------------------------------

def impronta(testo: str, algoritmo: str = "sha256") -> str:
    """Impronta (hash) esadecimale del testo codificato in UTF-8."""
    if not isinstance(testo, str):
        raise ErroreTipo("Si può calcolare l'impronta solo di un testo.")
    if not isinstance(algoritmo, str):
        raise ErroreTipo("Il nome dell'algoritmo deve essere un testo.")
    nome = algoritmo.strip().lower().replace("-", "")
    try:
        h = hashlib.new(nome)
    except (ValueError, TypeError):
        raise ErroreValore(
            f"Algoritmo di impronta `{algoritmo}` sconosciuto.",
            suggerimento="Usa " + ", ".join(f"\"{a}\"" for a in ALGORITMI) + ".") from None
    h.update(testo.encode("utf-8"))
    if nome.startswith("shake"):
        return h.hexdigest(32)  # type: ignore[call-arg]
    return h.hexdigest()


_SIMBOLI = "!#$%&*+-=?@_.:;"


def genera_password(lunghezza: int = 16, simboli: bool = True) -> str:
    """Password casuale (modulo ``secrets``) con minuscole, maiuscole, cifre
    e, se ``simboli`` è vero, simboli: almeno un carattere di ogni gruppo."""
    if isinstance(lunghezza, bool) or not isinstance(lunghezza, int):
        raise ErroreTipo("La lunghezza della password deve essere un numero intero.")
    gruppi = [string.ascii_lowercase, string.ascii_uppercase, string.digits]
    if simboli:
        gruppi.append(_SIMBOLI)
    if lunghezza < len(gruppi) or lunghezza > 1024:
        raise ErroreValore(
            f"Lunghezza {lunghezza} non valida: deve essere tra {len(gruppi)} e 1024.",
            suggerimento="Una buona password ha almeno 12 caratteri.")
    tutti = "".join(gruppi)
    caratteri = [secrets.choice(g) for g in gruppi]
    caratteri += [secrets.choice(tutti) for _ in range(lunghezza - len(gruppi))]
    secrets.SystemRandom().shuffle(caratteri)
    return "".join(caratteri)


# ---------------------------------------------------------------------------
# Cifratura (AES-256-GCM, leo.cifratura) e lettura del vecchio schema didattico
# ---------------------------------------------------------------------------

_INTESTAZIONE = b"DNT1"
_SALE = 16
_NONCE = 16
_ETICHETTA = 32
_ITERAZIONI = 120_000


def _chiavi(chiave: str, sale: bytes) -> tuple[bytes, bytes]:
    if not isinstance(chiave, str):
        raise ErroreTipo("La chiave di cifratura deve essere un testo.")
    if not chiave:
        raise ErroreValore("La chiave di cifratura è vuota.",
                           suggerimento="Scegli una frase segreta lunga, che ricorderai.")
    materiale = hashlib.pbkdf2_hmac("sha256", chiave.encode("utf-8"), sale, _ITERAZIONI, dklen=64)
    return materiale[:32], materiale[32:]


def _flusso(chiave: bytes, nonce: bytes, lunghezza: int) -> bytes:
    blocchi = []
    for contatore in range((lunghezza + 31) // 32):
        blocchi.append(hmac.new(chiave, nonce + contatore.to_bytes(8, "big"), hashlib.sha256).digest())
    return b"".join(blocchi)[:lunghezza]


def _xor(a: bytes, b: bytes) -> bytes:
    return (int.from_bytes(a, "big") ^ int.from_bytes(b, "big")).to_bytes(len(a), "big")


def cifra(testo: str, chiave: str) -> str:
    """Cifra ``testo`` con la frase ``chiave`` (AES-256-GCM); il risultato è testo base64.

    Ogni chiamata usa sale e nonce casuali: cifrando due volte lo stesso testo
    si ottengono risultati diversi, entrambi decifrabili.
    """
    if not isinstance(testo, str):
        raise ErroreTipo("Si può cifrare solo un testo.")
    if not isinstance(chiave, str):
        raise ErroreTipo("La chiave di cifratura deve essere un testo.")
    if not chiave:
        raise ErroreValore("La chiave di cifratura è vuota.",
                           suggerimento="Scegli una frase segreta lunga, che ricorderai.")
    from ... import cifratura

    return cifratura.cifra_testo(testo, chiave)


def decifra(cifrato: str, chiave: str) -> str:
    """Decifra un testo prodotto da :func:`cifra` (o dal vecchio schema didattico "DNT1").

    ``ErroreValore`` se la chiave è sbagliata, se il testo è stato alterato o
    se non è un testo cifrato da Leo.
    """
    if not isinstance(cifrato, str):
        raise ErroreTipo("Si può decifrare solo un testo.")
    if not isinstance(chiave, str):
        raise ErroreTipo("La chiave di cifratura deve essere un testo.")
    try:
        dati = base64.b64decode("".join(cifrato.split()).encode("ascii"), validate=True)
    except (binascii.Error, ValueError, UnicodeEncodeError):
        raise ErroreValore("Questo non è un testo cifrato valido (base64 non corretto).",
                           suggerimento="Usa esattamente il testo prodotto da `cifra`.") from None
    from ... import cifratura

    if cifratura.e_cifrato_leo(dati):
        try:
            chiaro = cifratura.decifra(dati, chiave)
        except ErroreValore as e:
            if "password è sbagliata" in e.messaggio:
                raise ErroreValore("Chiave sbagliata, oppure il testo cifrato è stato modificato.",
                                   suggerimento="Controlla la chiave: maiuscole e spazi contano.") from None
            raise
        try:
            return chiaro.decode("utf-8")
        except UnicodeDecodeError:
            raise ErroreValore("Il testo decifrato non è valido.") from None
    # vecchio schema didattico "DNT1" (solo lettura, per i dati già salvati)
    minimo = len(_INTESTAZIONE) + _SALE + _NONCE + _ETICHETTA
    if len(dati) < minimo or not dati.startswith(_INTESTAZIONE):
        raise ErroreValore("Questo non è un testo cifrato da Leo.",
                           suggerimento="Usa esattamente il testo prodotto da `cifra`.")
    corpo, etichetta = dati[:-_ETICHETTA], dati[-_ETICHETTA:]
    inizio = len(_INTESTAZIONE)
    sale = corpo[inizio:inizio + _SALE]
    nonce = corpo[inizio + _SALE:inizio + _SALE + _NONCE]
    contenuto = corpo[inizio + _SALE + _NONCE:]
    chiave_cifra, chiave_etichetta = _chiavi(chiave, sale)
    attesa = hmac.new(chiave_etichetta, corpo, hashlib.sha256).digest()
    if not hmac.compare_digest(attesa, etichetta):
        raise ErroreValore("Chiave sbagliata, oppure il testo cifrato è stato modificato.",
                           suggerimento="Controlla la chiave: maiuscole e spazi contano.")
    chiaro = _xor(contenuto, _flusso(chiave_cifra, nonce, len(contenuto))) if contenuto else b""
    try:
        return chiaro.decode("utf-8")
    except UnicodeDecodeError:  # pragma: no cover - impossibile con etichetta valida
        raise ErroreValore("Il testo decifrato non è valido.") from None
