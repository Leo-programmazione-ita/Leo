"""Servizi puri per i giochi: fisica semplice, collisioni, punteggio, joystick.

Usati dai controlli ``Scena``, ``Sprite``, ``Fisica``, ``Joystick`` e
``Punteggio`` (widget in ``leo/grafica/qt/widget_dante.py``), ma senza Qt:
si provano con unittest.

Convenzioni: coordinate in pixel come sullo schermo (x verso destra, y verso
il basso), velocita' in pixel al secondo, accelerazioni in pixel/s², tempi in
secondi. I rettangoli sono ``(x, y, larghezza, altezza)``.

API (note_generali del piano, mini-contratto 4):

    class CorpoFisico(nome, x, y, larghezza, altezza, vx=0, vy=0)
    class MondoFisico(gravita=980.0, rimbalzo=0.6):
        aggiungi(corpo), rimuovi(nome), passo(dt, area: (w, h)) -> list[{"sprite", "bordo"}]
    collide(r1, r2) -> bool
    uscita_bordo(rett, area) -> str | None          # "sinistra" "destra" "alto" "basso"
    class Punteggio(nome, percorso=None): valore, record, aggiungi(n) -> bool, azzera()
    joystick_da_punto(dx, dy, raggio) -> (x, y, angolo, forza)

Il record di :class:`Punteggio` si conserva in ``cartella_utente()/punteggi.toml``
(sezione ``[record]``, una chiave per nome); per i test si passa ``percorso``.
"""

from __future__ import annotations

import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from ...errori import ErroreDante, ErroreTipo, ErroreValore

#: Bordi dell'area di gioco, nell'ordine in cui si controllano.
BORDI = ("sinistra", "destra", "alto", "basso")

#: Sotto questa velocita' d'urto (px/s) il corpo si ferma sul bordo senza evento
#: (evita un "urto" a ogni fotogramma quando uno sprite e' appoggiato a terra).
SOGLIA_RIPOSO = 30.0

#: Passo massimo della simulazione: passi piu' lunghi si dividono (niente corpi
#: che attraversano i bordi se il computer rallenta).
PASSO_MASSIMO = 1 / 120


def _numero(v: Any, nome: str) -> float:
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
        try:
            from ...valori import nome_tipo
            tipo = nome_tipo(v)
        except ImportError:  # pragma: no cover
            tipo = type(v).__name__
        raise ErroreTipo(f"`{nome}` deve essere un numero, non `{tipo}`.")
    return float(v)


def _rett(r: Any) -> tuple[float, float, float, float]:
    """Rettangolo da tupla/lista ``(x, y, w, h)`` o da un oggetto con ``rettangolo``."""
    if hasattr(r, "rettangolo"):
        r = r.rettangolo
    if not isinstance(r, (tuple, list)) or len(r) != 4:
        raise ErroreTipo("Un rettangolo si scrive `[x, y, larghezza, altezza]`.")
    x, y, w, h = (_numero(v, "rettangolo") for v in r)
    return x, y, w, h


def _area(area: Any) -> tuple[float, float]:
    if not isinstance(area, (tuple, list)) or len(area) != 2:
        raise ErroreTipo("L'area di gioco si scrive `[larghezza, altezza]`.")
    return _numero(area[0], "larghezza dell'area"), _numero(area[1], "altezza dell'area")


# ===========================================================================
# Corpi e mondo
# ===========================================================================

@dataclass
class CorpoFisico:
    """Uno sprite visto dalla fisica. ``fisso`` = non si muove (piattaforme)."""

    nome: str
    x: float
    y: float
    larghezza: float
    altezza: float
    vx: float = 0.0
    vy: float = 0.0
    fisso: bool = False

    @property
    def rettangolo(self) -> tuple[float, float, float, float]:
        return (self.x, self.y, self.larghezza, self.altezza)

    @property
    def fermo(self) -> bool:
        return self.vx == 0 and self.vy == 0


class MondoFisico:
    """Gravita' verso il basso, rimbalzi e urti contro i bordi dell'area."""

    def __init__(self, gravita: float = 980.0, rimbalzo: float = 0.6) -> None:
        self.gravita = _numero(gravita, "gravita")
        self.rimbalzo = _numero(rimbalzo, "rimbalzo")
        if not 0 <= self.rimbalzo <= 1:
            raise ErroreValore(f"`rimbalzo` va da 0 (nessun rimbalzo) a 1 (rimbalzo perfetto), non {rimbalzo}.")
        self.corpi: dict[str, CorpoFisico] = {}

    def aggiungi(self, corpo: CorpoFisico) -> None:
        """Aggiunge un corpo (ne sostituisce uno con lo stesso nome)."""
        if not isinstance(corpo, CorpoFisico):
            raise ErroreTipo("Al mondo fisico si aggiungono solo corpi fisici.")
        self.corpi[corpo.nome] = corpo

    def rimuovi(self, nome: str) -> bool:
        """Toglie il corpo; falso se non c'era."""
        return self.corpi.pop(nome, None) is not None

    def corpo(self, nome: str) -> CorpoFisico | None:
        return self.corpi.get(nome)

    def passo(self, dt: float, area: tuple[float, float]) -> list[dict]:
        """Fa avanzare la simulazione di ``dt`` secondi dentro ``area`` = (larghezza, altezza).

        Restituisce gli urti avvenuti: ``[{"sprite": nome, "bordo": "basso"}, ...]``
        (al massimo uno per sprite e bordo in ogni chiamata).
        """
        dt = _numero(dt, "dt")
        if dt < 0:
            raise ErroreValore("Il tempo di un passo non può essere negativo.")
        w, h = _area(area)
        urti: list[dict] = []
        visti: set[tuple[str, str]] = set()
        n = max(1, int(math.ceil(dt / PASSO_MASSIMO))) if dt > 0 else 0
        piccolo = dt / n if n else 0.0
        for _ in range(n):
            for corpo in list(self.corpi.values()):
                if corpo.fisso:
                    continue
                for bordo in self._muovi(corpo, piccolo, w, h):
                    if (corpo.nome, bordo) not in visti:
                        visti.add((corpo.nome, bordo))
                        urti.append({"sprite": corpo.nome, "bordo": bordo})
        return urti

    def _muovi(self, c: CorpoFisico, dt: float, w: float, h: float) -> list[str]:
        urti = []
        c.vy += self.gravita * dt
        c.x += c.vx * dt
        c.y += c.vy * dt
        e = self.rimbalzo
        # orizzontale
        if c.x < 0 and c.vx <= 0:
            c.x = 0.0
            if self._rimbalza(c, "vx", e):
                urti.append("sinistra")
        elif c.x + c.larghezza > w and c.vx >= 0:
            c.x = max(0.0, w - c.larghezza)
            if self._rimbalza(c, "vx", e):
                urti.append("destra")
        # verticale
        if c.y < 0 and c.vy <= 0:
            c.y = 0.0
            if self._rimbalza(c, "vy", e):
                urti.append("alto")
        elif c.y + c.altezza > h and c.vy >= 0:
            c.y = max(0.0, h - c.altezza)
            if self._rimbalza(c, "vy", e):
                urti.append("basso")
        return urti

    def _rimbalza(self, c: CorpoFisico, asse: str, e: float) -> bool:
        """Inverte la velocita' sull'asse; vero se l'urto e' abbastanza forte da contare."""
        v = getattr(c, asse)
        if abs(v) < SOGLIA_RIPOSO:
            setattr(c, asse, 0.0)
            return False
        nuova = -v * e
        setattr(c, asse, nuova if abs(nuova) >= SOGLIA_RIPOSO else 0.0)
        return True

    def collisioni(self) -> list[tuple[str, str]]:
        """Coppie di corpi che si sovrappongono (nomi in ordine di inserimento)."""
        corpi = list(self.corpi.values())
        return [(a.nome, b.nome) for i, a in enumerate(corpi) for b in corpi[i + 1:] if collide(a, b)]


# ===========================================================================
# Collisioni e bordi
# ===========================================================================

def collide(r1: Any, r2: Any) -> bool:
    """Vero se i due rettangoli si sovrappongono (toccarsi sul bordo non conta)."""
    x1, y1, w1, h1 = _rett(r1)
    x2, y2, w2, h2 = _rett(r2)
    if w1 <= 0 or h1 <= 0 or w2 <= 0 or h2 <= 0:
        return False
    return x1 < x2 + w2 and x2 < x1 + w1 and y1 < y2 + h2 and y2 < y1 + h1


def uscita_bordo(rett: Any, area: Any) -> str | None:
    """Il bordo dell'area che il rettangolo sta superando, o ``None`` se e' tutto dentro.

    Basta che una parte esca. Se esce da due lati conta il primo tra
    ``sinistra``, ``destra``, ``alto``, ``basso``.
    """
    x, y, w, h = _rett(rett)
    aw, ah = _area(area)
    if x < 0:
        return "sinistra"
    if x + w > aw:
        return "destra"
    if y < 0:
        return "alto"
    if y + h > ah:
        return "basso"
    return None


# ===========================================================================
# Punteggio con record
# ===========================================================================

def _percorso_punteggi() -> Path:
    from ...percorsi import cartella_utente

    return cartella_utente() / "punteggi.toml"


class Punteggio:
    """Contatore di punti che ricorda il record tra un'esecuzione e l'altra.

    ``nome`` identifica il record nel file (per esempio il nome del gioco); con
    nome vuoto il record vale solo finche' il programma e' aperto.
    """

    def __init__(self, nome: str, percorso: str | os.PathLike | None = None) -> None:
        if not isinstance(nome, str):
            raise ErroreTipo("Il nome del punteggio deve essere un testo.")
        self.nome = nome
        self.percorso = Path(percorso) if percorso is not None else None
        self.valore: int | float = 0
        self.record: int | float = self._leggi_record()

    # --- file --------------------------------------------------------------
    def _file(self) -> Path | None:
        if not self.nome:
            return None
        if self.percorso is not None:
            return self.percorso
        try:
            return _percorso_punteggi()
        except (ImportError, OSError):  # pragma: no cover
            return None

    def _leggi_tutti(self, file: Path) -> dict:
        from ...tomlutil import ErroreToml, carica_toml

        if not file.is_file():
            return {}
        try:
            dati = carica_toml(file)
        except (ErroreToml, ErroreDante, OSError):
            return {}   # file rovinato: si riparte da zero, senza fermare il gioco
        return dati if isinstance(dati, dict) else {}

    def _leggi_record(self) -> int | float:
        file = self._file()
        if file is None:
            return 0
        record = self._leggi_tutti(file).get("record", {})
        v = record.get(self.nome, 0) if isinstance(record, dict) else 0
        return v if isinstance(v, (int, float)) and not isinstance(v, bool) else 0

    def _salva_record(self) -> None:
        file = self._file()
        if file is None:
            return
        from ...tomlutil import salva_toml

        dati = self._leggi_tutti(file)
        record = dati.get("record")
        if not isinstance(record, dict):
            record = {}
        record[self.nome] = self.record
        dati["record"] = record
        try:
            file.parent.mkdir(parents=True, exist_ok=True)
            salva_toml(file, dati)
        except (ErroreDante, OSError):
            pass  # non poter salvare il record non deve interrompere il gioco

    # --- API ---------------------------------------------------------------
    def aggiungi(self, n: int | float = 1) -> bool:
        """Aggiunge ``n`` punti (anche negativi); vero se e' un nuovo record."""
        if isinstance(n, bool) or not isinstance(n, (int, float)):
            raise ErroreTipo("Al punteggio si aggiungono numeri.")
        self.valore += n
        if self.valore > self.record:
            self.record = self.valore
            self._salva_record()
            return True
        return False

    def azzera(self) -> None:
        """Riporta a zero i punti (il record resta)."""
        self.valore = 0

    def azzera_record(self) -> None:
        """Cancella il record (anche dal file)."""
        self.record = 0
        self._salva_record()


# ===========================================================================
# Joystick
# ===========================================================================

def joystick_da_punto(dx: float, dy: float, raggio: float) -> tuple[float, float, float, float]:
    """Posizione della levetta a partire dallo spostamento dal centro, in pixel.

    Restituisce ``(x, y, angolo, forza)``:
      * ``x``, ``y`` tra -1 e 1, con la stessa direzione dello schermo
        (``y`` positivo = in basso), limitati al cerchio di raggio 1;
      * ``angolo`` in gradi da 0 a 360: 0 = destra, 90 = alto, 180 = sinistra,
        270 = basso (0 se la levetta e' al centro);
      * ``forza`` tra 0 (al centro) e 1 (sul bordo o oltre).
    """
    dx = _numero(dx, "dx")
    dy = _numero(dy, "dy")
    raggio = _numero(raggio, "raggio")
    if raggio <= 0:
        raise ErroreValore("Il raggio del joystick deve essere maggiore di zero.")
    distanza = math.hypot(dx, dy)
    if distanza == 0:
        return (0.0, 0.0, 0.0, 0.0)
    forza = min(1.0, distanza / raggio)
    x = dx / distanza * forza
    y = dy / distanza * forza
    angolo = math.degrees(math.atan2(-dy, dx)) % 360.0
    return (x, y, angolo, forza)


__all__ = ["CorpoFisico", "MondoFisico", "collide", "uscita_bordo", "Punteggio", "joystick_da_punto",
           "BORDI", "SOGLIA_RIPOSO"]
