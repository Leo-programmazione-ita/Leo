"""Rilevamento e preparazione (flash) delle schede, senza Qt.

Due cose che servono a **Leo Robotica** prima ancora di comandare una scheda:

* **rilevare** cosa è collegato: schede pronte (con la seriale USB) e schede in *modalità flash*
  (una Pico col BOOTSEL premuto compare come un disco ``RPI-RP2``), riconoscendo il modello;
* **flashare**: copiare il firmware MicroPython ``.uf2`` sulla scheda in modalità flash e poi caricare
  il programma di Leo (``leo_pico.py`` come ``main.py``), così l'utente non usa Thonny.

L'enumerazione del sistema (porte seriali, dischi) è isolata in funzioni sostituibili, così la logica
di riconoscimento è provabile senza hardware.
"""

from __future__ import annotations

import glob
import os
import sys
from dataclasses import dataclass
from typing import Any, Callable

# --- tabella di riconoscimento per identificativo USB (VID, PID) --------------
VID_RASPBERRY = 0x2E8A
#: (vid, pid) -> (tipo, nome leggibile). pid None = qualsiasi pid di quel produttore.
IDENTITA: dict[tuple[int, int | None], tuple[str, str]] = {
    (0x2E8A, 0x0005): ("pico", "Raspberry Pi Pico"),
    (0x2E8A, 0x000A): ("pico", "Raspberry Pi Pico (MicroPython)"),
    (0x2E8A, 0x0003): ("pico", "Raspberry Pi Pico (modalità flash)"),
    (0x2E8A, None):   ("pico", "Scheda Raspberry (RP2040/RP2350)"),
    (0x10C4, None):   ("esp32", "ESP32 (adattatore CP210x)"),
    (0x1A86, None):   ("esp32", "ESP32 o Arduino (adattatore CH340)"),
    (0x0403, None):   ("esp32", "ESP32 (adattatore FTDI)"),
    (0x2341, None):   ("arduino", "Arduino"),
    (0x2A03, None):   ("arduino", "Arduino"),
    (0x239A, None):   ("adafruit", "Scheda Adafruit"),
}
#: nomi dei modelli dal Board-ID del file INFO_UF2.TXT della modalità flash
MODELLI_UF2 = {
    "RPI-RP2": "Raspberry Pi Pico / Pico W",
    "RP2350": "Raspberry Pi Pico 2 / Pico 2 W",
}


@dataclass(frozen=True)
class Dispositivo:
    """Una scheda vista dal computer. ``modo`` è "pronta" (seriale) o "flash" (BOOTSEL)."""

    tipo: str            # pico / esp32 / arduino / adafruit / sconosciuto
    nome: str
    modo: str            # "pronta" | "flash"
    porta: str = ""      # porta seriale, se pronta (es. COM5, /dev/ttyACM0)
    unita: str = ""      # percorso del disco, se in modalità flash (es. E:\, /media/.../RPI-RP2)

    def a_dizionario(self) -> dict:
        return {"tipo": self.tipo, "nome": self.nome, "modo": self.modo,
                "porta": self.porta, "unita": self.unita, "pronta": self.modo == "pronta"}


def identifica(vid: int | None, pid: int | None, descrizione: str = "") -> tuple[str, str]:
    """(tipo, nome) da un identificativo USB; sconosciuto se non in tabella."""
    if vid is not None:
        if (vid, pid) in IDENTITA:
            return IDENTITA[(vid, pid)]
        if (vid, None) in IDENTITA:
            return IDENTITA[(vid, None)]
    testo = (descrizione or "").lower()
    for ago, tipo, nome in (("pico", "pico", "Raspberry Pi Pico"), ("rp2040", "pico", "Scheda RP2040"),
                            ("esp32", "esp32", "ESP32"), ("arduino", "arduino", "Arduino")):
        if ago in testo:
            return tipo, nome
    return "sconosciuto", (descrizione.strip() or "Scheda seriale")


# --- enumerazione del sistema (sostituibile nei test) -------------------------
def _porte_seriali_grezze() -> list[tuple[str, int | None, int | None, str]]:
    """[(porta, vid, pid, descrizione)] via pyserial, o [] se non c'è."""
    try:
        from serial.tools import list_ports  # type: ignore
    except Exception:
        return []
    fuori = []
    for p in list_ports.comports():
        fuori.append((p.device, getattr(p, "vid", None), getattr(p, "pid", None),
                      getattr(p, "description", "") or ""))
    return fuori


def _dischi_candidati() -> list[str]:
    """Percorsi di dischi dove cercare una scheda in modalità flash (INFO_UF2.TXT)."""
    percorsi: list[str] = []
    if os.name == "nt":  # pragma: no cover - solo Windows
        import string
        for lettera in string.ascii_uppercase:
            percorsi.append(f"{lettera}:\\")
    else:
        for base in ("/media", "/run/media", "/Volumes", "/mnt"):
            percorsi.extend(glob.glob(base + "/*"))
            percorsi.extend(glob.glob(base + "/*/*"))
    return percorsi


def _info_uf2(percorso: str) -> dict[str, str] | None:
    """Legge INFO_UF2.TXT da un disco, se c'è (Model:/Board-ID:)."""
    file = os.path.join(percorso, "INFO_UF2.TXT")
    try:
        if not os.path.isfile(file):
            return None
        dati: dict[str, str] = {}
        with open(file, "r", encoding="utf-8", errors="replace") as f:
            for riga in f:
                if ":" in riga:
                    k, v = riga.split(":", 1)
                    dati[k.strip()] = v.strip()
        return dati
    except OSError:
        return None


def unita_in_flash(dischi: Callable[[], list[str]] | None = None,
                   info: Callable[[str], dict | None] | None = None) -> list[Dispositivo]:
    """Le schede in modalità flash (BOOTSEL): dischi con INFO_UF2.TXT."""
    elenca = dischi or _dischi_candidati
    leggi = info or _info_uf2
    fuori: list[Dispositivo] = []
    for d in elenca():
        dati = leggi(d)
        if not dati:
            continue
        board = (dati.get("Board-ID", "") or dati.get("Model", "")).upper()
        nome = next((n for chiave, n in MODELLI_UF2.items() if chiave in board), None)
        nome = nome or dati.get("Model", "") or "Scheda in modalità flash"
        fuori.append(Dispositivo(tipo="pico", nome=nome, modo="flash", unita=d))
    return fuori


def rileva_dispositivi(porte: Callable[[], list] | None = None,
                       flash: Callable[[], list[Dispositivo]] | None = None) -> list[Dispositivo]:
    """Tutte le schede collegate: quelle pronte (seriale) e quelle in modalità flash."""
    leggi_porte = porte or _porte_seriali_grezze
    leggi_flash = flash or unita_in_flash
    fuori: list[Dispositivo] = []
    for porta, vid, pid, descr in leggi_porte():
        tipo, nome = identifica(vid, pid, descr)
        fuori.append(Dispositivo(tipo=tipo, nome=nome, modo="pronta", porta=porta))
    fuori.extend(leggi_flash())
    # le schede pronte per prime, poi quelle da flashare
    fuori.sort(key=lambda d: (0 if d.modo == "pronta" else 1, d.nome))
    return fuori


# ============================================================================
# Flashing: firmware .uf2 sulla scheda in modalità flash + caricamento del programma
# ============================================================================

def cartella_firmware() -> str:
    """La cartella ``dati/pico/firmware`` dove Leo tiene i .uf2 di MicroPython (se presenti)."""
    qui = os.path.dirname(os.path.abspath(__file__))
    radice = os.path.abspath(os.path.join(qui, "..", "..", ".."))
    return os.path.join(radice, "dati", "pico", "firmware")


def firmware_per(tipo_scheda: str) -> str:
    """Il percorso del .uf2 di MicroPython per una scheda (``pico``/``pico2``...), o "" se non c'è."""
    base = cartella_firmware()
    for nome in (f"{tipo_scheda}.uf2", f"micropython_{tipo_scheda}.uf2", "micropython.uf2"):
        p = os.path.join(base, nome)
        if os.path.isfile(p):
            return p
    return ""


def _e_unita_flash(unita: str) -> bool:
    return bool(_info_uf2(unita))


def flasha_firmware(unita: str, firmware_uf2: str) -> None:
    """Copia il firmware ``.uf2`` sulla scheda in modalità flash (il disco BOOTSEL).

    Dopo la copia la scheda si riavvia da sola con il nuovo firmware. Solleva ``ErroreValore``
    con messaggio chiaro se l'unità non è una scheda in modalità flash o il firmware non va bene.
    """
    import shutil

    from ...errori import ErroreFile, ErroreValore

    unita = str(unita or "").strip()
    if not unita:
        raise ErroreValore("Non mi hai detto su quale scheda scrivere.",
                           suggerimento="Usa `rileva_dispositivi()` e prendi l'unità di una scheda `in flash`.")
    if not os.path.isdir(unita) or not _e_unita_flash(unita):
        raise ErroreValore(f"`{unita}` non è una scheda in modalità flash.",
                           suggerimento="Tieni premuto BOOTSEL mentre colleghi la Pico: compare un disco `RPI-RP2`.")
    if not firmware_uf2 or not os.path.isfile(firmware_uf2):
        raise ErroreFile("Non trovo il file del firmware (.uf2) da scrivere.",
                         suggerimento="Scarica MicroPython per la tua scheda da micropython.org, oppure mettilo "
                         "in `dati/pico/firmware`.")
    if not firmware_uf2.lower().endswith(".uf2"):
        raise ErroreValore("Il firmware deve essere un file `.uf2`.")
    try:
        shutil.copy(firmware_uf2, os.path.join(unita, os.path.basename(firmware_uf2)))
    except OSError as e:
        raise ErroreValore(f"Non riesco a scrivere sulla scheda: {e.strerror or e}.",
                           suggerimento="Controlla che la scheda sia ancora collegata in modalità flash.") from e


def carica_programma(porta: str, sorgente_py: str, nome_remoto: str = "main.py",
                     trasporto: Any = None) -> None:
    """Carica un file Python sulla scheda come ``nome_remoto`` (di norma ``main.py``), via REPL MicroPython.

    Usato per mettere ``dati/pico/leo_pico.py`` sulla Pico senza Thonny. La scheda deve già avere
    MicroPython (vedi :func:`flasha_firmware`). Richiede ``pyserial`` o la porta aperta via trasporto.
    """
    from ...errori import ErroreFile, ErroreValore
    from .pico import TrasportoSeriale

    if not os.path.isfile(sorgente_py):
        raise ErroreFile(f"Non trovo il file da caricare: `{sorgente_py}`.")
    with open(sorgente_py, "rb") as f:
        contenuto = f.read()

    t = trasporto if trasporto is not None else TrasportoSeriale(porta)
    proprio = trasporto is None
    if proprio:
        t.apri()
    try:
        t.scrivi(b"\r\x03\x03")        # due Ctrl-C: ferma un programma in corso
        t.scrivi(b"\r\x01")            # Ctrl-A: entra nel REPL "grezzo"
        _attendi(t, b"raw REPL")
        comando = (
            "f=open('%s','wb')\n" % nome_remoto
            + "f.write(%r)\n" % contenuto
            + "f.close()\n"
        ).encode("utf-8")
        t.scrivi(comando)
        t.scrivi(b"\x04")               # Ctrl-D: esegui
        esito = _attendi(t, b"OK", limite=6.0)
        if b"Error" in esito or b"Traceback" in esito:
            raise ErroreValore("La scheda ha rifiutato il programma.",
                               suggerimento="Controlla che sulla scheda ci sia MicroPython.")
        t.scrivi(b"\r\x02")            # Ctrl-B: esci dal REPL grezzo
    finally:
        if proprio:
            try:
                t.chiudi()
            except Exception:
                pass


def _attendi(trasporto: Any, atteso: bytes, limite: float = 4.0) -> bytes:
    """Legge dalla seriale finché arriva ``atteso`` o scade il tempo; restituisce quanto letto."""
    import time

    from ...errori import ErroreValore

    fine = time.monotonic() + limite
    buffer = b""
    while time.monotonic() < fine:
        pezzo = trasporto.leggi(0.2)
        if pezzo:
            buffer += pezzo
            if atteso in buffer:
                return buffer
    raise ErroreValore("La scheda non ha risposto come previsto durante il caricamento.",
                       suggerimento="Scollega e ricollega la scheda e riprova.")


__all__ = ["Dispositivo", "IDENTITA", "MODELLI_UF2", "identifica",
           "unita_in_flash", "rileva_dispositivi", "cartella_firmware", "firmware_per",
           "flasha_firmware", "carica_programma"]
