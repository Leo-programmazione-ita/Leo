"""Collegamento con una Raspberry Pi Pico (USB seriale o Wi-Fi), senza Qt.

Sulla scheda gira ``dati/pico/leo_pico.py`` (MicroPython), da copiare una
volta sola sulla Pico come ``main.py``. Il computer e la scheda si scambiano
**righe JSON** (una per riga, terminate da ``\\n``):

richiesta (computer -> scheda)::

    {"id": 7, "cmd": "scrivi_pin", "pin": 25, "valore": 1}

risposta (scheda -> computer, stesso ``id``)::

    {"id": 7, "ok": true}
    {"id": 8, "ok": true, "valore": 21.4}
    {"id": 9, "ok": false, "errore": "Il pin 40 non esiste sulla Pico."}

notifica spontanea (scheda -> computer, senza ``id``)::

    {"evento": "pressione", "pin": 14}
    {"evento": "rilascio", "pin": 14}
    {"evento": "testo", "testo": "..."}

Comandi: ``ping``, ``scrivi_pin`` (pin, valore 0/1), ``leggi_pin`` (pin,
[pull "su"/"giu"]), ``pwm`` (pin, percentuale 0-100, [frequenza]),
``leggi_sensore`` (tipo, pin, [eco]), ``pulsante`` (pin: lo sorveglia e
notifica pressione/rilascio), ``testo`` (testo).

API (vedi note_generali del piano)::

    porte_disponibili() -> list[str]
    class SchedaPico(porta="auto", indirizzo="", simulata=False):
        connetti(), disconnetti(), connessa, scrivi_pin(pin, valore),
        leggi_pin(pin) -> int, leggi_sensore(tipo, pin) -> float,
        invia_testo(t), ricevi() -> list[dict], ultimo_errore

I trasporti (:class:`TrasportoSeriale`, :class:`TrasportoTCP`,
:class:`TrasportoSimulato`) hanno tutti la stessa interfaccia
(:class:`Trasporto`); :class:`TrasportoSeriale` serve anche al controllo
``PortaSeriale`` per parlare con qualunque dispositivo seriale.

Tutte le operazioni sono **bloccanti** (con tempo massimo): chi le usa da
un'interfaccia grafica le esegue in un thread.
"""

from __future__ import annotations

import glob
import json
import math
import os
import queue
import random
import threading
import time
from typing import Any, Callable

from ...errori import ErroreDante, ErroreTipo, ErroreValore

#: Messaggio standard quando manca qualcosa sul computer.
NON_DISPONIBILE = "non disponibile su questo computer"

#: Porta TCP del server Wi-Fi di ``leo_pico.py``.
PORTA_TCP_PREDEFINITA = 4242

#: Velocità seriale predefinita (per l'USB della Pico non conta, ma serve ad altri dispositivi).
VELOCITA_PREDEFINITA = 115200

#: Identificativo USB del produttore della Raspberry Pi Pico.
VID_RASPBERRY = 0x2E8A

#: Tipi di sensore e loro unità di misura.
UNITA_SENSORI: dict[str, str] = {
    "temperatura": "°C",
    "luce": "%",
    "distanza": "cm",
    "analogico": "V",
}

#: Pin GPIO utilizzabili sulla Pico (0-28) più 25 = LED di bordo.
PIN_VALIDI = range(0, 29)

#: Pin con convertitore analogico (ADC); 4 = sensore di temperatura interno.
PIN_ANALOGICI = (26, 27, 28)


def _non_disponibile(cosa: str, suggerimento: str | None = None) -> ErroreValore:
    return ErroreValore(f"{cosa}: {NON_DISPONIBILE}.", suggerimento=suggerimento)


# ===========================================================================
# Porte
# ===========================================================================

def _pyserial():
    """Il modulo ``serial`` (pyserial) se installato, altrimenti None."""
    try:
        import serial  # type: ignore[import-not-found]
        import serial.tools.list_ports  # type: ignore[import-not-found]  # noqa: F401
    except Exception:  # pyserial manca o e' rotto
        return None
    return serial


def _porte_registro_windows() -> list[str]:
    try:
        import winreg  # type: ignore[import-not-found]
    except ImportError:
        return []
    porte: list[str] = []
    try:
        chiave = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DEVICEMAP\SERIALCOMM")
    except OSError:
        return []
    try:
        i = 0
        while True:
            try:
                _nome, valore, _tipo = winreg.EnumValue(chiave, i)
            except OSError:
                break
            porte.append(str(valore))
            i += 1
    finally:
        winreg.CloseKey(chiave)
    return porte


def _chiave_porta(p: str):
    """Ordina COM2 prima di COM10 e /dev/ttyACM0 prima di /dev/ttyACM1."""
    cifre = "".join(c for c in p if c.isdigit())
    testa = p.rstrip("0123456789")
    return (testa, int(cifre) if cifre else -1, p)


def porte_disponibili() -> list[str]:
    """Porte seriali presenti, con le Pico (se riconoscibili) per prime.

    Usa pyserial se installato; altrimenti il registro di Windows oppure i
    file ``/dev/ttyACM*``, ``/dev/ttyUSB*``, ``/dev/cu.usbmodem*``.
    Non solleva mai errori: nessuna porta = lista vuota.
    """
    serial = _pyserial()
    if serial is not None:
        try:
            from serial.tools import list_ports  # type: ignore[import-not-found]

            info = list(list_ports.comports())
        except Exception:
            info = []
        if info:
            pico = [p.device for p in info if getattr(p, "vid", None) == VID_RASPBERRY]
            altre = [p.device for p in info if getattr(p, "vid", None) != VID_RASPBERRY]
            return sorted(pico, key=_chiave_porta) + sorted(altre, key=_chiave_porta)
    if os.name == "nt":
        return sorted(_porte_registro_windows(), key=_chiave_porta)
    trovate: list[str] = []
    for schema in ("/dev/ttyACM*", "/dev/cu.usbmodem*", "/dev/ttyUSB*", "/dev/cu.usbserial*"):
        trovate += sorted(glob.glob(schema), key=_chiave_porta)
    return trovate


# ===========================================================================
# Trasporti
# ===========================================================================

class Trasporto:
    """Canale di byte verso un dispositivo. Le sottoclassi implementano i metodi."""

    descrizione = "trasporto"

    def __init__(self) -> None:
        self.aperto = False

    def apri(self) -> None:  # pragma: no cover - astratto
        raise NotImplementedError

    def chiudi(self) -> None:  # pragma: no cover - astratto
        raise NotImplementedError

    def scrivi(self, dati: bytes) -> None:  # pragma: no cover - astratto
        raise NotImplementedError

    def leggi(self, tempo_massimo: float = 0.1) -> bytes:  # pragma: no cover - astratto
        """Byte disponibili (attende al massimo ``tempo_massimo`` secondi); b"" se nessuno."""
        raise NotImplementedError


class LettoreRighe:
    """Spezza in righe il flusso di byte di un :class:`Trasporto`."""

    def __init__(self, trasporto: Trasporto) -> None:
        self.trasporto = trasporto
        self._buffer = b""

    def svuota(self) -> None:
        self._buffer = b""

    def leggi_riga(self, tempo_massimo: float = 0.1) -> str | None:
        """Una riga completa (senza ``\\r\\n``) oppure None se non arriva in tempo."""
        limite = time.monotonic() + max(0.0, tempo_massimo)
        while True:
            if b"\n" in self._buffer:
                riga, self._buffer = self._buffer.split(b"\n", 1)
                return riga.rstrip(b"\r").decode("utf-8", errors="replace")
            resto = limite - time.monotonic()
            dati = self.trasporto.leggi(max(0.0, resto))
            if dati:
                self._buffer += dati
                if len(self._buffer) > 1_000_000:  # dispositivo impazzito: non riempire la memoria
                    self._buffer = self._buffer[-65536:]
                continue
            if resto <= 0:
                return None


class TrasportoSeriale(Trasporto):
    """Porta seriale (USB). Usa pyserial se c'e'; altrimenti apre il file del
    dispositivo in modalita' binaria (``/dev/ttyACM0`` o ``\\\\.\\COM3``)."""

    def __init__(self, porta: str, velocita: int = VELOCITA_PREDEFINITA) -> None:
        super().__init__()
        self.porta = porta
        self.velocita = int(velocita)
        self.descrizione = f"porta seriale {porta}"
        self._seriale = None       # oggetto pyserial
        self._fd: int | None = None  # descrittore POSIX
        self._file = None          # file Windows senza pyserial
        self._coda: "queue.Queue[bytes]" = queue.Queue()
        self._thread: threading.Thread | None = None

    # --- apertura -----------------------------------------------------------
    def apri(self) -> None:
        if self.aperto:
            return
        if not self.porta:
            raise ErroreValore("Non hai indicato la porta seriale.",
                               suggerimento="Scrivi il nome della porta, per esempio \"COM3\" o \"/dev/ttyACM0\".")
        serial = _pyserial()
        try:
            if serial is not None:
                self._seriale = serial.Serial(self.porta, self.velocita, timeout=0, write_timeout=2)
            elif os.name == "nt":
                nome = self.porta if self.porta.startswith("\\\\.\\") else "\\\\.\\" + self.porta
                self._file = open(nome, "r+b", buffering=0)
                self._thread = threading.Thread(target=self._leggi_in_sottofondo, daemon=True,
                                                name=f"seriale-{self.porta}")
                self._thread.start()
            else:
                self._apri_posix()
        except ErroreDante:
            raise
        except FileNotFoundError as e:
            raise ErroreValore(f"La porta `{self.porta}` non esiste.",
                               suggerimento="Controlla che il cavo USB sia collegato; porte trovate: "
                               + (", ".join(porte_disponibili()) or "nessuna") + ".") from e
        except PermissionError as e:
            raise ErroreValore(f"Non ho il permesso di aprire la porta `{self.porta}`.",
                               suggerimento="Forse la usa già un altro programma (per esempio Thonny): chiudilo."
                               + ("" if os.name == "nt" else " Su Linux aggiungi il tuo utente al gruppo `dialout`.")
                               ) from e
        except Exception as e:  # SerialException, OSError...
            raise ErroreValore(f"Non riesco ad aprire la porta `{self.porta}`: {e}.",
                               suggerimento="Controlla il cavo e che nessun altro programma usi la porta.") from e
        self.aperto = True

    def _apri_posix(self) -> None:
        fd = os.open(self.porta, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
        try:
            import termios

            attr = termios.tcgetattr(fd)
            # modalita' "raw": niente eco, niente elaborazione delle righe
            attr[0] = 0                                   # iflag
            attr[1] = 0                                   # oflag
            attr[2] = termios.CS8 | termios.CREAD | termios.CLOCAL  # cflag
            attr[3] = 0                                   # lflag
            velocita = getattr(termios, f"B{self.velocita}", None)
            if velocita is not None:
                attr[4] = attr[5] = velocita
            termios.tcsetattr(fd, termios.TCSANOW, attr)
        except Exception:
            pass  # non e' un terminale vero (o termios manca): si usa com'e'
        self._fd = fd

    def _leggi_in_sottofondo(self) -> None:
        """Solo Windows senza pyserial: la lettura blocca, quindi si fa in un thread."""
        f = self._file
        while f is not None and not f.closed:
            try:
                dati = f.read(1)
            except (OSError, ValueError):
                break
            if not dati:
                time.sleep(0.01)
                continue
            self._coda.put(dati)
        self._coda.put(b"")

    # --- uso ------------------------------------------------------------------
    def chiudi(self) -> None:
        self.aperto = False
        try:
            if self._seriale is not None:
                self._seriale.close()
            if self._fd is not None:
                os.close(self._fd)
            if self._file is not None:
                self._file.close()
        except Exception:
            pass
        self._seriale = None
        self._fd = None
        self._file = None

    def _controlla_aperta(self) -> None:
        if not self.aperto:
            raise ErroreValore(f"La porta `{self.porta}` non è aperta.",
                               suggerimento="Chiama prima `apri()`.")

    def scrivi(self, dati: bytes) -> None:
        self._controlla_aperta()
        try:
            if self._seriale is not None:
                self._seriale.write(dati)
                self._seriale.flush()
            elif self._fd is not None:
                inviati = 0
                limite = time.monotonic() + 2
                while inviati < len(dati):
                    try:
                        inviati += os.write(self._fd, dati[inviati:])
                    except BlockingIOError:
                        if time.monotonic() > limite:
                            raise TimeoutError
                        time.sleep(0.005)
            elif self._file is not None:
                self._file.write(dati)
                self._file.flush()
        except Exception as e:
            self.chiudi()
            raise ErroreValore(f"Non riesco a scrivere sulla porta `{self.porta}`: forse il cavo è stato scollegato.") from e

    def leggi(self, tempo_massimo: float = 0.1) -> bytes:
        self._controlla_aperta()
        try:
            if self._seriale is not None:
                limite = time.monotonic() + tempo_massimo
                while True:
                    n = self._seriale.in_waiting
                    if n:
                        return self._seriale.read(n)
                    if time.monotonic() >= limite:
                        return b""
                    time.sleep(min(0.01, max(0.0, limite - time.monotonic())))
            if self._fd is not None:
                import select

                pronti, _, _ = select.select([self._fd], [], [], max(0.0, tempo_massimo))
                if not pronti:
                    return b""
                try:
                    dati = os.read(self._fd, 4096)
                except BlockingIOError:
                    return b""
                if not dati:
                    raise OSError("fine del flusso")
                return dati
            if self._file is not None:
                try:
                    primo = self._coda.get(timeout=max(0.0, tempo_massimo)) if tempo_massimo > 0 \
                        else self._coda.get_nowait()
                except queue.Empty:
                    return b""
                if primo == b"":
                    raise OSError("fine del flusso")
                parti = [primo]
                while True:
                    try:
                        altro = self._coda.get_nowait()
                    except queue.Empty:
                        break
                    if altro == b"":
                        self._coda.put(b"")
                        break
                    parti.append(altro)
                return b"".join(parti)
        except ErroreDante:
            raise
        except Exception as e:
            self.chiudi()
            raise ErroreValore(f"La porta `{self.porta}` non risponde più: forse il cavo è stato scollegato.") from e
        return b""


class TrasportoTCP(Trasporto):
    """Connessione Wi-Fi (TCP) verso una Pico W con ``leo_pico.py``."""

    def __init__(self, host: str, porta: int = PORTA_TCP_PREDEFINITA, tempo_connessione: float = 4.0) -> None:
        super().__init__()
        self.host = host
        self.porta = int(porta)
        self.tempo_connessione = tempo_connessione
        self.descrizione = f"{host}:{self.porta}"
        self._socket = None

    @classmethod
    def da_indirizzo(cls, indirizzo: str) -> "TrasportoTCP":
        """``"192.168.1.50"`` oppure ``"192.168.1.50:4242"``."""
        testo = indirizzo.strip()
        if testo.startswith("tcp://"):
            testo = testo[6:]
        host, porta = testo, PORTA_TCP_PREDEFINITA
        if testo.count(":") == 1:
            host, _, p = testo.partition(":")
            try:
                porta = int(p)
            except ValueError:
                raise ErroreValore(f"`{indirizzo}` non è un indirizzo valido.",
                                   suggerimento="Scrivi per esempio \"192.168.1.50\" o \"192.168.1.50:4242\".") from None
        if not host:
            raise ErroreValore("L'indirizzo della scheda è vuoto.")
        return cls(host, porta)

    def apri(self) -> None:
        if self.aperto:
            return
        import socket

        try:
            s = socket.create_connection((self.host, self.porta), timeout=self.tempo_connessione)
        except socket.timeout as e:
            raise ErroreValore(f"La scheda a `{self.descrizione}` non risponde.",
                               suggerimento="Controlla che la Pico W sia accesa e collegata alla stessa rete Wi-Fi.") from e
        except OSError as e:
            raise ErroreValore(f"Non riesco a collegarmi a `{self.descrizione}`: {e.strerror or e}.",
                               suggerimento="Controlla l'indirizzo (lo stampa la Pico all'avvio) e la rete Wi-Fi.") from e
        try:
            s.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError:
            pass
        self._socket = s
        self.aperto = True

    def chiudi(self) -> None:
        self.aperto = False
        if self._socket is not None:
            try:
                self._socket.close()
            except OSError:
                pass
        self._socket = None

    def scrivi(self, dati: bytes) -> None:
        if not self.aperto or self._socket is None:
            raise ErroreValore("La connessione Wi-Fi con la scheda non è aperta.")
        try:
            self._socket.settimeout(3)
            self._socket.sendall(dati)
        except OSError as e:
            self.chiudi()
            raise ErroreValore("La connessione Wi-Fi con la scheda si è interrotta.") from e

    def leggi(self, tempo_massimo: float = 0.1) -> bytes:
        if not self.aperto or self._socket is None:
            raise ErroreValore("La connessione Wi-Fi con la scheda non è aperta.")
        import socket

        try:
            self._socket.settimeout(max(0.0, tempo_massimo) or 0.0)
            if tempo_massimo <= 0:
                self._socket.setblocking(False)
            dati = self._socket.recv(4096)
        except (socket.timeout, BlockingIOError):
            return b""
        except OSError as e:
            self.chiudi()
            raise ErroreValore("La connessione Wi-Fi con la scheda si è interrotta.") from e
        if not dati:
            self.chiudi()
            raise ErroreValore("La scheda ha chiuso la connessione Wi-Fi.")
        return dati


# ===========================================================================
# Scheda simulata (per la classe, senza hardware)
# ===========================================================================

class PicoSimulata:
    """Finta Pico che risponde al protocollo con valori plausibili.

    ``orologio``: funzione che restituisce i secondi (sostituibile nei test).
    I pin registrati come pulsanti vengono "premuti" per ``durata_pressione``
    secondi ogni ``periodo_pulsanti`` secondi.
    """

    def __init__(self, orologio: Callable[[], float] = time.monotonic, seme: int | None = None,
                 periodo_pulsanti: float = 4.0, durata_pressione: float = 0.3) -> None:
        self.orologio = orologio
        self.inizio = orologio()
        self.casuale = random.Random(seme)
        self.pin: dict[int, int] = {}
        self.pwm: dict[int, float] = {}
        self.pulsanti: dict[int, bool] = {}   # pin -> premuto
        self.periodo_pulsanti = periodo_pulsanti
        self.durata_pressione = durata_pressione
        self.testi: list[str] = []

    def _t(self) -> float:
        return self.orologio() - self.inizio

    def notifiche(self) -> list[dict]:
        """Eventi dei pulsanti simulati dall'ultima chiamata."""
        eventi: list[dict] = []
        if not self.pulsanti or self.periodo_pulsanti <= 0:
            return eventi
        fase = self._t() % self.periodo_pulsanti
        for i, (pin, premuto) in enumerate(sorted(self.pulsanti.items())):
            # ogni pulsante e' sfasato di mezzo secondo dal precedente
            f = (fase - 0.5 * i) % self.periodo_pulsanti
            ora_premuto = f < self.durata_pressione
            if ora_premuto != premuto:
                self.pulsanti[pin] = ora_premuto
                eventi.append({"evento": "pressione" if ora_premuto else "rilascio", "pin": pin})
        return eventi

    def sensore(self, tipo: str, pin: int) -> float:
        t = self._t()
        r = self.casuale.uniform(-1, 1)
        if tipo == "temperatura":
            return round(21.0 + 1.5 * math.sin(t / 30.0) + 0.2 * r, 1)
        if tipo == "luce":
            return round(max(0.0, min(100.0, 55.0 + 15.0 * math.sin(t / 10.0) + 2 * r)), 1)
        if tipo == "distanza":
            return round(max(2.0, 50.0 + 35.0 * math.sin(t / 5.0) + 1.5 * r), 1)
        # analogico: tensione 0-3,3 V
        return round(max(0.0, min(3.3, 1.65 + 1.2 * math.sin(t / 3.0 + pin) + 0.05 * r)), 3)

    def esegui(self, richiesta: dict) -> dict:
        """Risposta (senza ``id``) a una richiesta del protocollo."""
        cmd = richiesta.get("cmd")
        try:
            if cmd == "ping":
                return {"ok": True, "versione": "1.0", "scheda": "Pico simulata", "wifi": False}
            if cmd == "scrivi_pin":
                pin = _pin_valido(richiesta.get("pin"))
                self.pin[pin] = 1 if richiesta.get("valore") else 0
                self.pwm.pop(pin, None)
                return {"ok": True}
            if cmd == "leggi_pin":
                pin = _pin_valido(richiesta.get("pin"))
                if pin in self.pulsanti:
                    # pulsante con pull-up: premuto = 0
                    return {"ok": True, "valore": 0 if self.pulsanti[pin] else 1}
                return {"ok": True, "valore": self.pin.get(pin, 0)}
            if cmd == "pwm":
                pin = _pin_valido(richiesta.get("pin"))
                self.pwm[pin] = float(richiesta.get("valore", 0))
                return {"ok": True}
            if cmd == "leggi_sensore":
                tipo = str(richiesta.get("tipo", ""))
                if tipo not in UNITA_SENSORI:
                    return {"ok": False, "errore": f"Il sensore `{tipo}` non esiste."}
                return {"ok": True, "valore": self.sensore(tipo, int(richiesta.get("pin", 26) or 0)),
                        "unita": UNITA_SENSORI[tipo]}
            if cmd == "pulsante":
                pin = _pin_valido(richiesta.get("pin"))
                self.pulsanti.setdefault(pin, False)
                return {"ok": True}
            if cmd == "testo":
                self.testi.append(str(richiesta.get("testo", "")))
                return {"ok": True}
        except ErroreDante as e:
            return {"ok": False, "errore": e.messaggio}
        return {"ok": False, "errore": f"Comando sconosciuto: `{cmd}`."}


class TrasportoSimulato(Trasporto):
    """Trasporto verso una :class:`PicoSimulata`: stesso protocollo di una scheda vera."""

    descrizione = "scheda simulata"

    def __init__(self, scheda: PicoSimulata | None = None) -> None:
        super().__init__()
        self.scheda = scheda or PicoSimulata()
        self._uscita = b""
        self._entrata = b""

    def apri(self) -> None:
        self.aperto = True

    def chiudi(self) -> None:
        self.aperto = False

    def scrivi(self, dati: bytes) -> None:
        if not self.aperto:
            raise ErroreValore("La scheda simulata non è collegata.")
        self._entrata += dati
        while b"\n" in self._entrata:
            riga, self._entrata = self._entrata.split(b"\n", 1)
            try:
                richiesta = json.loads(riga.decode("utf-8"))
            except ValueError:
                continue
            if not isinstance(richiesta, dict):
                continue
            risposta = self.scheda.esegui(richiesta)
            if "id" in richiesta:
                risposta["id"] = richiesta["id"]
            self._uscita += (json.dumps(risposta) + "\r\n").encode("utf-8")

    def leggi(self, tempo_massimo: float = 0.1) -> bytes:
        if not self.aperto:
            raise ErroreValore("La scheda simulata non è collegata.")
        for n in self.scheda.notifiche():
            self._uscita += (json.dumps(n) + "\r\n").encode("utf-8")
        dati, self._uscita = self._uscita, b""
        if not dati and tempo_massimo > 0:
            time.sleep(min(tempo_massimo, 0.01))
        return dati


# ===========================================================================
# Scheda
# ===========================================================================

def _pin_valido(pin: Any) -> int:
    if isinstance(pin, bool) or not isinstance(pin, (int, float)) or (isinstance(pin, float) and not pin.is_integer()):
        raise ErroreTipo("Il numero del pin deve essere un intero (per esempio 25).")
    pin = int(pin)
    if pin not in PIN_VALIDI:
        raise ErroreValore(f"Il pin {pin} non esiste sulla Pico.",
                           suggerimento="I pin GPIO della Pico vanno da 0 a 28; il LED sulla scheda è il 25.")
    return pin


class SchedaPico:
    """Una Raspberry Pi Pico collegata via USB (``porta``) o Wi-Fi (``indirizzo``).

    ``porta="auto"``: la prima porta trovata (le Pico per prime). Se
    ``indirizzo`` non e' vuoto si usa il Wi-Fi. ``simulata=True``: nessun
    hardware, valori plausibili (utile in classe).

    I metodi sollevano :class:`ErroreValore` con un messaggio in italiano e
    salvano lo stesso messaggio in ``ultimo_errore``. Thread-safe: una sola
    richiesta alla volta.
    """

    TEMPO_RISPOSTA = 2.0

    def __init__(self, porta: str = "auto", indirizzo: str = "", simulata: bool = False, *,
                 trasporto: Trasporto | None = None) -> None:
        self.porta = porta or "auto"
        self.indirizzo = indirizzo or ""
        self.simulata = bool(simulata)
        self.ultimo_errore = ""
        self.info: dict = {}
        self._trasporto_dato = trasporto
        self._trasporto: Trasporto | None = None
        self._righe: LettoreRighe | None = None
        self._notifiche: list[dict] = []
        self._prossimo_id = 1
        self._lucchetto = threading.RLock()

    def __repr__(self) -> str:
        stato = "collegata" if self.connessa else "scollegata"
        return f"<SchedaPico {self.descrizione} {stato}>"

    # --- stato ------------------------------------------------------------------
    @property
    def connessa(self) -> bool:
        return self._trasporto is not None and self._trasporto.aperto

    @property
    def descrizione(self) -> str:
        if self._trasporto is not None:
            return self._trasporto.descrizione
        if self.simulata:
            return "scheda simulata"
        if self.indirizzo:
            return self.indirizzo
        return self.porta

    def _errore(self, errore: ErroreDante) -> ErroreDante:
        self.ultimo_errore = errore.messaggio
        return errore

    def _crea_trasporto(self) -> Trasporto:
        if self._trasporto_dato is not None:
            return self._trasporto_dato
        if self.simulata:
            return TrasportoSimulato()
        if self.indirizzo.strip():
            return TrasportoTCP.da_indirizzo(self.indirizzo)
        porta = self.porta
        if porta == "auto":
            porte = porte_disponibili()
            if not porte:
                raise ErroreValore("Nessuna scheda Pico trovata.",
                                   suggerimento="Collega la Pico con un cavo USB dati (non solo di ricarica), "
                                   "oppure usa `simulata = vero` per provare senza scheda.")
            porta = porte[0]
        return TrasportoSeriale(porta)

    # --- connessione -------------------------------------------------------------
    def connetti(self) -> None:
        """Apre il collegamento e verifica che sulla scheda giri ``leo_pico.py``."""
        with self._lucchetto:
            if self.connessa:
                return
            try:
                trasporto = self._crea_trasporto()
                trasporto.apri()
            except ErroreDante as e:
                raise self._errore(e)
            self._trasporto = trasporto
            self._righe = LettoreRighe(trasporto)
            try:
                # una riga vuota "pulisce" eventuali caratteri a meta' sulla scheda
                trasporto.scrivi(b"\n")
                self.info = self._richiesta("ping", _tempo=3.0, _ping=True)
            except ErroreDante as e:
                self._chiudi_trasporto()
                raise self._errore(e)
            self.ultimo_errore = ""

    def disconnetti(self) -> None:
        with self._lucchetto:
            self._chiudi_trasporto()

    def _chiudi_trasporto(self) -> None:
        if self._trasporto is not None:
            try:
                self._trasporto.chiudi()
            except Exception:
                pass
        self._trasporto = None
        self._righe = None

    def _controlla_connessa(self) -> None:
        if not self.connessa:
            raise self._errore(ErroreValore("La scheda Pico non è collegata.",
                                            suggerimento="Chiama prima `connetti()` e controlla il cavo USB."))

    # --- protocollo ----------------------------------------------------------------
    def _analizza_riga(self, riga: str) -> dict | None:
        """Riga ricevuta -> dizionario; le righe non JSON diventano notifiche ``testo``."""
        riga = riga.strip()
        if not riga:
            return None
        if riga.startswith("{"):
            try:
                dati = json.loads(riga)
            except ValueError:
                dati = None
            if isinstance(dati, dict):
                return dati
        return {"evento": "testo", "testo": riga, "_non_json": True}

    def _richiesta(self, cmd: str, _tempo: float | None = None, _ping: bool = False, **parametri) -> dict:
        """Invia un comando e attende la risposta con lo stesso ``id``."""
        with self._lucchetto:
            self._controlla_connessa()
            assert self._trasporto is not None and self._righe is not None
            ident = self._prossimo_id
            self._prossimo_id += 1
            messaggio = {"id": ident, "cmd": cmd, **parametri}
            try:
                self._trasporto.scrivi((json.dumps(messaggio) + "\n").encode("utf-8"))
            except ErroreDante as e:
                self._chiudi_trasporto()
                raise self._errore(e)
            limite = time.monotonic() + (self.TEMPO_RISPOSTA if _tempo is None else _tempo)
            testo_estraneo = False
            while True:
                resto = limite - time.monotonic()
                if resto <= 0:
                    break
                try:
                    riga = self._righe.leggi_riga(resto)
                except ErroreDante as e:
                    self._chiudi_trasporto()
                    raise self._errore(e)
                if riga is None:
                    break
                dati = self._analizza_riga(riga)
                if dati is None:
                    continue
                if dati.get("id") == ident:
                    if dati.get("ok"):
                        return dati
                    raise self._errore(ErroreValore(
                        "La scheda risponde: " + str(dati.get("errore") or "errore sconosciuto.")))
                if "id" in dati:
                    continue  # risposta vecchia, arrivata in ritardo
                if dati.pop("_non_json", False):
                    testo_estraneo = True
                    if _ping:
                        continue  # durante la connessione: eco del REPL, messaggi d'avvio...
                self._notifiche.append(dati)
            if _ping and testo_estraneo:
                errore = ErroreValore(
                    "La scheda risponde ma non esegue il programma di Leo.",
                    suggerimento="Copia `dati/pico/leo_pico.py` sulla Pico con il nome `main.py` "
                    "(per esempio con Thonny) e riavviala.")
            elif _ping:
                errore = ErroreValore(
                    f"La scheda su `{self.descrizione}` non risponde.",
                    suggerimento="Controlla che sulla Pico ci sia `main.py` (copiato da `dati/pico/leo_pico.py`) "
                    "e prova a scollegarla e ricollegarla.")
            else:
                errore = ErroreValore(f"La scheda non ha risposto al comando `{cmd}` in tempo.",
                                      suggerimento="Controlla il collegamento con la scheda.")
            raise self._errore(errore)

    # --- comandi -----------------------------------------------------------------------
    def scrivi_pin(self, pin, valore) -> None:
        """Accende (1/vero) o spegne (0/falso) un pin digitale."""
        pin = _pin_valido(pin)
        if isinstance(valore, bool):
            v = 1 if valore else 0
        elif isinstance(valore, (int, float)) and valore in (0, 1):
            v = int(valore)
        else:
            raise ErroreValore("Il valore di un pin può essere solo 0, 1, `vero` o `falso`.",
                               suggerimento="Per una luminosità intermedia usa `pwm(pin, percentuale)`.")
        self._richiesta("scrivi_pin", pin=pin, valore=v)

    def pwm(self, pin, percentuale, frequenza: int = 1000) -> None:
        """Uscita PWM (0-100 %), per regolare LED e motorini."""
        pin = _pin_valido(pin)
        if isinstance(percentuale, bool) or not isinstance(percentuale, (int, float)):
            raise ErroreTipo("La percentuale del PWM deve essere un numero da 0 a 100.")
        if not 0 <= percentuale <= 100:
            raise ErroreValore("La percentuale del PWM deve essere tra 0 e 100.")
        self._richiesta("pwm", pin=pin, valore=float(percentuale), frequenza=int(frequenza))

    def leggi_pin(self, pin, pull: str = "") -> int:
        """Legge un pin digitale: 0 o 1. ``pull``: "su", "giu" o "" (nessuno)."""
        pin = _pin_valido(pin)
        if pull not in ("", "su", "giu"):
            raise ErroreValore("`pull` può essere \"su\", \"giu\" o \"\".")
        risposta = self._richiesta("leggi_pin", pin=pin, pull=pull)
        return 1 if risposta.get("valore") else 0

    def leggi_sensore(self, tipo: str, pin=26, eco=None) -> float:
        """Legge un sensore: "temperatura" (°C), "luce" (%), "distanza" (cm, HC-SR04:
        trigger su ``pin``, eco su ``eco`` o ``pin + 1``), "analogico" (V)."""
        if tipo not in UNITA_SENSORI:
            raise ErroreValore(f"Il sensore `{tipo}` non esiste.",
                               suggerimento="Tipi di sensore: " + ", ".join(f'"{t}"' for t in UNITA_SENSORI) + ".")
        if tipo == "temperatura" and pin in (-1, 4):
            pin = 4  # sensore interno della Pico
        else:
            pin = _pin_valido(pin)
            if tipo in ("luce", "analogico", "temperatura") and pin not in PIN_ANALOGICI:
                raise ErroreValore(f"Il pin {pin} non sa leggere valori analogici.",
                                   suggerimento="Usa uno dei pin analogici 26, 27 o 28"
                                   + (" (o -1 per il sensore interno)." if tipo == "temperatura" else "."))
        parametri: dict[str, Any] = {"tipo": tipo, "pin": pin}
        if tipo == "distanza":
            parametri["eco"] = _pin_valido(eco if eco is not None else pin + 1)
        risposta = self._richiesta("leggi_sensore", **parametri)
        valore = risposta.get("valore")
        if isinstance(valore, bool) or not isinstance(valore, (int, float)):
            raise self._errore(ErroreValore("La scheda ha mandato una lettura non valida."))
        return float(valore)

    def sorveglia_pulsante(self, pin) -> None:
        """Chiede alla scheda di notificare pressione e rilascio del pulsante su ``pin``."""
        self._richiesta("pulsante", pin=_pin_valido(pin))

    def invia_testo(self, testo) -> None:
        """Manda un testo alla scheda (che lo stampa sulla sua console)."""
        if not isinstance(testo, str):
            raise ErroreTipo("Alla scheda si può mandare solo un testo.")
        self._richiesta("testo", testo=testo)

    def ricevi(self) -> list[dict]:
        """Notifiche arrivate dalla scheda (pressioni dei pulsanti, testi), senza attendere."""
        with self._lucchetto:
            if self.connessa and self._righe is not None:
                try:
                    while True:
                        riga = self._righe.leggi_riga(0)
                        if riga is None:
                            break
                        dati = self._analizza_riga(riga)
                        if dati is not None and "id" not in dati:
                            dati.pop("_non_json", None)
                            self._notifiche.append(dati)
                except ErroreDante as e:
                    self._chiudi_trasporto()
                    self._errore(e)
            arrivate, self._notifiche = self._notifiche, []
            return arrivate


__all__ = [
    "NON_DISPONIBILE", "UNITA_SENSORI", "PORTA_TCP_PREDEFINITA", "porte_disponibili",
    "Trasporto", "LettoreRighe", "TrasportoSeriale", "TrasportoTCP", "TrasportoSimulato",
    "PicoSimulata", "SchedaPico",
]
