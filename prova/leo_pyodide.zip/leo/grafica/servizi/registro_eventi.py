"""Registro degli eventi del programma (controllo ``Registro``).

API:

    LIVELLI = ("debug", "info", "avviso", "errore")
    class RegistroEventi:
        aggiungi(testo, livello="info") -> {"ora", "livello", "testo"}
        voci                               # copia della lista delle voci
        filtra(livello_minimo="debug", testo="") -> list[dict]
        esporta(percorso, formato="txt")  # "txt" oppure "csv"
        svuota()

L'ora di ogni voce è un testo ``"GG/MM/AAAA HH:MM:SS"``. Il file CSV usa il
punto e virgola come separatore e la codifica UTF-8 con BOM, così Excel in
italiano lo apre correttamente.
"""

from __future__ import annotations

import csv
import threading
from datetime import datetime
from os import PathLike
from typing import Any, Callable, Optional, Union

from ...errori import ErroreFile, ErroreTipo, ErroreValore

__all__ = ["LIVELLI", "RegistroEventi", "normalizza_livello"]

LIVELLI: tuple[str, ...] = ("debug", "info", "avviso", "errore")

_SINONIMI = {
    "debug": "debug", "dettaglio": "debug", "prova": "debug",
    "info": "info", "informazione": "info", "informazioni": "info", "nota": "info",
    "avviso": "avviso", "attenzione": "avviso", "avvertimento": "avviso", "warning": "avviso",
    "errore": "errore", "error": "errore", "grave": "errore",
}

_FORMATO_ORA = "%d/%m/%Y %H:%M:%S"


def normalizza_livello(livello: Any) -> str:
    """Nome ufficiale del livello (accetta maiuscole e qualche sinonimo)."""
    if not isinstance(livello, str):
        raise ErroreTipo("Il livello deve essere un testo: " + ", ".join(LIVELLI) + ".")
    chiave = livello.strip().lower()
    if chiave not in _SINONIMI:
        raise ErroreValore(f"Livello `{livello}` sconosciuto.",
                           suggerimento="I livelli sono: " + ", ".join(f"\"{l}\"" for l in LIVELLI) + ".")
    return _SINONIMI[chiave]


class RegistroEventi:
    """Elenco di voci con ora, livello e testo.

    ``capacita``: numero massimo di voci conservate (le più vecchie vengono
    tolte); 0 = nessun limite.
    """

    def __init__(self, capacita: int = 10000) -> None:
        if isinstance(capacita, bool) or not isinstance(capacita, int) or capacita < 0:
            raise ErroreValore("La capacità del registro deve essere un intero >= 0.")
        self.capacita = capacita
        self._voci: list[dict] = []
        self._blocco = threading.Lock()
        self._osservatori: list[Callable[[dict], None]] = []

    # -- osservatori (usati dal widget per l'evento nuova_voce) -------------------
    def aggiungi_osservatore(self, funzione: Callable[[dict], None]) -> None:
        """``funzione(voce)`` viene chiamata dopo ogni :meth:`aggiungi`."""
        self._osservatori.append(funzione)

    def rimuovi_osservatore(self, funzione: Callable[[dict], None]) -> None:
        try:
            self._osservatori.remove(funzione)
        except ValueError:
            pass

    # -- API ------------------------------------------------------------------
    def aggiungi(self, testo: Any, livello: str = "info") -> dict:
        """Aggiunge una voce e la restituisce (``{"ora", "livello", "testo"}``)."""
        livello = normalizza_livello(livello)
        if not isinstance(testo, str):
            try:
                from ...valori import rappresenta
                testo = rappresenta(testo)
            except (ImportError, AttributeError, TypeError):  # pragma: no cover
                testo = str(testo)
        voce = {"ora": datetime.now().strftime(_FORMATO_ORA), "livello": livello, "testo": testo}
        with self._blocco:
            self._voci.append(voce)
            if self.capacita and len(self._voci) > self.capacita:
                del self._voci[:len(self._voci) - self.capacita]
        for osservatore in list(self._osservatori):
            osservatore(dict(voce))
        return dict(voce)

    @property
    def voci(self) -> list[dict]:
        """Copia delle voci, dalla più vecchia alla più recente."""
        with self._blocco:
            return [dict(v) for v in self._voci]

    def __len__(self) -> int:
        return len(self._voci)

    def filtra(self, livello_minimo: str = "debug", testo: str = "") -> list[dict]:
        """Voci di livello almeno ``livello_minimo`` che contengono ``testo``
        (senza distinguere maiuscole e minuscole)."""
        minimo = LIVELLI.index(normalizza_livello(livello_minimo))
        if not isinstance(testo, str):
            raise ErroreTipo("Il testo da cercare deve essere un testo.")
        cercato = testo.casefold()
        return [v for v in self.voci
                if LIVELLI.index(v["livello"]) >= minimo and cercato in v["testo"].casefold()]

    def esporta(self, percorso: Union[str, "PathLike[str]"], formato: str = "txt",
                livello_minimo: str = "debug") -> None:
        """Salva le voci in un file di testo (``txt``) o in un foglio ``csv``."""
        if not isinstance(formato, str) or formato.strip().lower().lstrip(".") not in ("txt", "csv"):
            raise ErroreValore(f"Formato `{formato}` non supportato.",
                               suggerimento="Usa \"txt\" oppure \"csv\".")
        formato = formato.strip().lower().lstrip(".")
        voci = self.filtra(livello_minimo)
        try:
            if formato == "txt":
                with open(percorso, "w", encoding="utf-8", newline="") as file:
                    for v in voci:
                        file.write(f"[{v['ora']}] {v['livello'].upper()}: {v['testo']}\n")
            else:
                with open(percorso, "w", encoding="utf-8-sig", newline="") as file:
                    scrittore = csv.writer(file, delimiter=";")
                    scrittore.writerow(["ora", "livello", "testo"])
                    for v in voci:
                        scrittore.writerow([v["ora"], v["livello"], v["testo"]])
        except OSError as e:
            raise ErroreFile(f"Non riesco a salvare il registro in `{percorso}`: {e.strerror or e}.",
                             suggerimento="Controlla che la cartella esista e che tu possa scriverci.") from None

    def svuota(self) -> None:
        """Toglie tutte le voci."""
        with self._blocco:
            self._voci.clear()
