"""Logica pura dei controlli classici (senza Qt), usata da ``grafica/qt/widget.py``.

Qui sta tutto cio' che si puo' calcolare e verificare senza un'interfaccia
grafica, cosi' si prova con ``unittest`` anche dove PySide6 manca:

* gruppi esclusivi dei controlli ``Scelta``;
* indice e selezione di ``Elenco`` / ``MenuATendina``;
* date ``GG/MM/AAAA`` <-> ``(anno, mese, giorno)`` per ``SelettoreData``;
* geometria del ``Grafico`` (barre, linee, punti, spicchi della torta, scale
  degli assi con valori "belli");
* percorsi ``"a/b"`` dell'``Albero``;
* dati della ``Tabella``;
* voci del ``MenuContestuale`` e pulsanti della ``BarraStrumenti``;
* piccoli calcoli di disegno (``Immagine`` con ``adatta``, ``Linea``,
  ``Forma``, ``Divisore``, ``PannelloScorrevole``) e il filtro di ``DialogoFile``.

Gli errori verso l'utente sono sempre classi di :mod:`leo.errori` con
messaggi in italiano.
"""

from __future__ import annotations

import datetime as _dt
import math
import re
from typing import Any, Iterable, Sequence

from ..errori import ErroreIndice, ErroreTipo, ErroreValore
from ..valori import e_intero, e_numero, nome_tipo, rappresenta

Rettangolo = tuple  # (x, y, larghezza, altezza) in pixel (float o int)


# ===========================================================================
# Utilita' generali
# ===========================================================================

def limita(valore: float, minimo: float, massimo: float) -> float:
    """Riporta ``valore`` tra ``minimo`` e ``massimo`` (se invertiti, li scambia)."""
    if minimo > massimo:
        minimo, massimo = massimo, minimo
    return max(minimo, min(massimo, valore))


def valore_numero(valore: Any, decimali: int = 0) -> int | float:
    """Valore di una ``CasellaNumero``: intero se ``decimali == 0``, altrimenti
    decimale arrotondato a ``decimali`` cifre."""
    if not e_numero(valore):
        raise ErroreTipo(f"Serve un numero, non `{nome_tipo(valore)}`.")
    if decimali <= 0:
        # arrotondamento a meta' lontano da zero, come `arrotonda`
        return int(math.floor(abs(valore) + 0.5)) * (1 if valore >= 0 else -1)
    return round(float(valore), int(decimali))


def testo_valore(valore: Any) -> str:
    """Testo mostrato per un valore Leo dentro un controllo ("" per ``nulla``)."""
    if valore is None:
        return ""
    return rappresenta(valore)


def controlla_numeri(nome_metodo: str, **argomenti: Any) -> dict[str, float]:
    """Controlla che gli argomenti di un metodo di disegno siano numeri.

    ``controlla_numeri("linea", x1=0, y1=0)`` -> ``{"x1": 0.0, "y1": 0.0}``;
    un argomento non numerico -> ``ErroreTipo`` in italiano.
    """
    risultato: dict[str, float] = {}
    for nome, v in argomenti.items():
        if not e_numero(v):
            raise ErroreTipo(f"`{nome_metodo}`: l'argomento `{nome}` deve essere un numero, "
                             f"non `{nome_tipo(v)}`.")
        risultato[nome] = float(v)
    return risultato


# ===========================================================================
# Scelta: gruppi esclusivi
# ===========================================================================

def chiave_gruppo(contenitore: str, scheda: int | None, gruppo: str) -> tuple[str, int, str]:
    """Chiave del gruppo esclusivo di una ``Scelta``.

    Sono esclusive tra loro le scelte con lo stesso contenitore, la stessa
    scheda (per ``Schede``/``Divisore``) e lo stesso ``gruppo``.
    """
    return (contenitore or "", int(scheda or 0), gruppo or "")


def gruppi_esclusivi(controlli: Iterable[Any]) -> dict[tuple[str, int, str], list[str]]:
    """Raggruppa i controlli ``Scelta`` (ModelloControllo o simili) per chiave di gruppo.

    Gli altri tipi vengono ignorati. L'ordine dei nomi segue quello d'ingresso.
    """
    gruppi: dict[tuple[str, int, str], list[str]] = {}
    for c in controlli:
        if getattr(c, "tipo", None) != "Scelta":
            continue
        gruppo = ""
        proprieta = getattr(c, "proprieta", {}) or {}
        if isinstance(proprieta, dict):
            gruppo = proprieta.get("gruppo", "") or ""
        chiave = chiave_gruppo(getattr(c, "contenitore", ""), getattr(c, "scheda", None), gruppo)
        gruppi.setdefault(chiave, []).append(c.nome)
    return gruppi


def scelte_da_spegnere(scelte: Iterable[tuple[str, str, bool]], nome_acceso: str) -> list[str]:
    """Scelte da deselezionare quando ``nome_acceso`` diventa selezionata.

    ``scelte``: ``(nome, gruppo, selezionata)`` delle scelte dello **stesso
    contenitore** (e scheda). Restituisce i nomi delle altre scelte selezionate
    con lo stesso gruppo di ``nome_acceso``.
    """
    elenco = list(scelte)
    gruppo = None
    for nome, g, _sel in elenco:
        if nome == nome_acceso:
            gruppo = g or ""
            break
    if gruppo is None:
        return []
    return [nome for nome, g, sel in elenco if nome != nome_acceso and (g or "") == gruppo and sel]


def correggi_gruppi_iniziali(scelte: Sequence[tuple[str, str, bool]]) -> list[str]:
    """Con piu' scelte selezionate nello stesso gruppo resta solo l'ultima:
    restituisce i nomi da deselezionare."""
    ultima: dict[str, str] = {}
    for nome, g, sel in scelte:
        if sel:
            ultima[g or ""] = nome
    return [nome for nome, g, sel in scelte if sel and ultima.get(g or "") != nome]


# ===========================================================================
# Elenco e MenuATendina
# ===========================================================================

def testi_elementi(elementi: Any) -> list[str]:
    """Testi mostrati per gli elementi di un elenco (``rappresenta`` di ognuno)."""
    if not isinstance(elementi, list):
        raise ErroreTipo(f"`elementi` deve essere una lista, non `{nome_tipo(elementi)}`.")
    return [testo_valore(e) for e in elementi]


def normalizza_indice(indice: Any, quanti: int) -> int:
    """Indice selezionato valido: un intero tra 0 e ``quanti - 1``, altrimenti -1."""
    if not e_intero(indice):
        return -1
    if 0 <= indice < quanti:
        return int(indice)
    return -1


def normalizza_indici(indici: Iterable[Any], quanti: int) -> list[int]:
    """Indici validi, ordinati e senza doppioni (selezione multipla)."""
    return sorted({int(i) for i in indici if e_intero(i) and 0 <= i < quanti})


def selezione_elenco(elementi: Sequence[Any], indici: Iterable[int], multipla: bool = False) -> Any:
    """Valore della proprieta' ``selezione``.

    Selezione singola: l'elemento scelto o ``None`` (nulla). Multipla: la lista
    degli elementi scelti, nell'ordine dell'elenco.
    """
    validi = normalizza_indici(indici, len(elementi))
    if multipla:
        return [elementi[i] for i in validi]
    return elementi[validi[0]] if validi else None


def dati_evento_selezione(elementi: Sequence[Any], indici: Iterable[int], multipla: bool = False) -> dict:
    """Dati dell'evento ``selezione``: ``{"indice", "elemento"}``.

    ``indice`` e' il primo indice scelto (-1 se nessuno); ``elemento`` e'
    l'elemento (o, con ``multipla``, la lista degli elementi scelti).
    """
    validi = normalizza_indici(indici, len(elementi))
    indice = validi[0] if validi else -1
    return {"indice": indice, "elemento": selezione_elenco(elementi, validi, multipla)}


def indice_dopo_rimozione(selezionato: int, rimosso: int) -> int:
    """Nuovo indice selezionato dopo aver tolto l'elemento ``rimosso``."""
    if selezionato < 0:
        return -1
    if rimosso == selezionato:
        return -1
    if rimosso < selezionato:
        return selezionato - 1
    return selezionato


# ===========================================================================
# Date (SelettoreData)
# ===========================================================================

_RE_DATA = re.compile(r"^\s*(\d{1,2})\s*[/.\-]\s*(\d{1,2})\s*[/.\-]\s*(\d{4})\s*$")


def analizza_data(testo: Any) -> tuple[int, int, int]:
    """``"25/09/2026"`` -> ``(2026, 9, 25)``. Accetta anche ``-`` e ``.`` come separatori.

    Testo non valido o data inesistente (``31/02/2026``) -> ``ErroreValore``.
    """
    if not isinstance(testo, str):
        raise ErroreTipo(f"Una data si scrive come testo \"GG/MM/AAAA\", non come `{nome_tipo(testo)}`.")
    m = _RE_DATA.match(testo)
    if not m:
        raise ErroreValore(f"`{testo}` non è una data valida.",
                           suggerimento="Scrivi la data come \"GG/MM/AAAA\", per esempio \"25/12/2026\".")
    giorno, mese, anno = int(m.group(1)), int(m.group(2)), int(m.group(3))
    try:
        _dt.date(anno, mese, giorno)
    except ValueError:
        raise ErroreValore(f"La data `{testo}` non esiste nel calendario.",
                           suggerimento="Controlla giorno e mese (il mese va da 1 a 12).") from None
    return anno, mese, giorno


def formatta_data(anno: int, mese: int, giorno: int) -> str:
    """``(2026, 9, 5)`` -> ``"05/09/2026"``."""
    return f"{int(giorno):02d}/{int(mese):02d}/{int(anno):04d}"


def data_valida(testo: Any) -> bool:
    """Vero se ``testo`` e' una data ``GG/MM/AAAA`` esistente."""
    try:
        analizza_data(testo)
    except (ErroreValore, ErroreTipo):
        return False
    return True


def data_o_oggi(testo: str, oggi: _dt.date | None = None) -> tuple[int, int, int]:
    """Data del testo, oppure quella di oggi se il testo e' vuoto."""
    if not testo or not str(testo).strip():
        d = oggi or _dt.date.today()
        return d.year, d.month, d.day
    return analizza_data(testo)


def limita_data(data: tuple[int, int, int], minimo: str = "", massimo: str = "") -> tuple[int, int, int]:
    """Riporta ``data`` dentro ``[minimo, massimo]`` (testi ``GG/MM/AAAA``, "" = nessun limite)."""
    risultato = tuple(data)
    if minimo:
        m = analizza_data(minimo)
        if risultato < m:
            risultato = m
    if massimo:
        m = analizza_data(massimo)
        if risultato > m:
            risultato = m
    return risultato  # type: ignore[return-value]


# ===========================================================================
# Grafico
# ===========================================================================

TIPI_GRAFICO = ("barre", "linee", "torta", "punti")

#: Colori delle serie e degli spicchi (leggibili su sfondo chiaro e scuro).
#: La prima serie usa il rosso del tema; niente ciano/viola della vecchia tavolozza.
COLORI_GRAFICO = ("#E0182D", "#FFB020", "#5AC8FA", "#34C759", "#FF7A1A",
                  "#9C9CA6", "#FF2D95", "#FFCC00", "#20B2AA", "#A2845E")

#: Margini interni dell'area del grafico (pixel).
MARGINE = 8
MARGINE_ASSE_Y = 44
MARGINE_ASSE_X = 22
ALTEZZA_TITOLO = 22


def normalizza_dati_grafico(dati: Any) -> list[tuple[str, float]]:
    """``[3, 5, ["Mele", 2]]`` -> ``[("1", 3.0), ("2", 5.0), ("Mele", 2.0)]``.

    Ogni elemento e' un numero oppure una coppia ``[etichetta, valore]``;
    altro -> ``ErroreTipo``.
    """
    if not isinstance(dati, list):
        raise ErroreTipo(f"`dati` del grafico deve essere una lista, non `{nome_tipo(dati)}`.")
    risultato: list[tuple[str, float]] = []
    for i, d in enumerate(dati):
        if e_numero(d):
            risultato.append((str(i + 1), float(d)))
        elif isinstance(d, list) and len(d) == 2 and e_numero(d[1]):
            risultato.append((testo_valore(d[0]), float(d[1])))
        else:
            raise ErroreTipo(f"L'elemento {i} dei dati del grafico non va bene: `{rappresenta(d, dentro=True)}`.",
                             suggerimento="Ogni dato è un numero oppure una coppia [etichetta, valore], "
                                          "per esempio [\"Mele\", 12].")
    return risultato


def numero_bello(x: float, arrotonda: bool) -> float:
    """Numero "bello" (1, 2, 5 per potenze di 10) vicino a ``x`` (Heckbert)."""
    if x <= 0:
        return 1.0
    esponente = math.floor(math.log10(x))
    frazione = x / 10 ** esponente
    if arrotonda:
        if frazione < 1.5:
            f = 1
        elif frazione < 3:
            f = 2
        elif frazione < 7:
            f = 5
        else:
            f = 10
    else:
        if frazione <= 1:
            f = 1
        elif frazione <= 2:
            f = 2
        elif frazione <= 5:
            f = 5
        else:
            f = 10
    return f * 10 ** esponente


def scala_asse(minimo: float, massimo: float, tacche: int = 5) -> tuple[float, float, float]:
    """Scala con valori "belli": ``(inizio, fine, passo)`` con inizio <= minimo e fine >= massimo.

    ``scala_asse(0, 87)`` -> ``(0, 100, 20)``. Con ``minimo == massimo`` allarga
    l'intervallo attorno al valore.
    """
    if minimo > massimo:
        minimo, massimo = massimo, minimo
    if minimo == massimo:
        if minimo == 0:
            massimo = 1.0
        else:
            delta = abs(minimo) * 0.5
            minimo, massimo = minimo - delta, massimo + delta
    tacche = max(2, int(tacche))
    ampiezza = numero_bello(massimo - minimo, False)
    passo = numero_bello(ampiezza / (tacche - 1), True)
    inizio = math.floor(minimo / passo) * passo
    fine = math.ceil(massimo / passo) * passo
    return _pulisci(inizio), _pulisci(fine), _pulisci(passo)


def _pulisci(x: float) -> float:
    """Toglie gli errori di arrotondamento (0.30000000000000004 -> 0.3)."""
    y = float(round(x, 10))
    return 0.0 if y == 0 else y


def valori_tacche(inizio: float, fine: float, passo: float) -> list[float]:
    """Valori delle tacche da ``inizio`` a ``fine`` compresi."""
    if passo <= 0:
        return [inizio]
    n = int(round((fine - inizio) / passo))
    return [_pulisci(inizio + i * passo) for i in range(n + 1)]


def formatta_tacca(v: float) -> str:
    """Etichetta di una tacca: ``20.0`` -> ``"20"``, ``0.25`` -> ``"0.25"``, ``1500000`` -> ``"1.5M"``."""
    a = abs(v)
    if a >= 1_000_000:
        return f"{v / 1_000_000:g}M"
    if a >= 10_000:
        return f"{v / 1000:g}k"
    if float(v).is_integer():
        return str(int(v))
    return f"{v:g}"


def area_grafico(larghezza: float, altezza: float, *, titolo: bool = False, assi: bool = True) -> Rettangolo:
    """Rettangolo interno in cui disegnare barre, linee o punti (o la torta)."""
    alto = MARGINE + (ALTEZZA_TITOLO if titolo else 0)
    sinistra = MARGINE_ASSE_Y if assi else MARGINE
    basso = MARGINE_ASSE_X if assi else MARGINE
    w = max(0.0, larghezza - sinistra - MARGINE)
    h = max(0.0, altezza - alto - basso)
    return (float(sinistra), float(alto), w, h)


def scala_dati(valori: Sequence[float], tipo: str = "barre") -> tuple[float, float, float]:
    """Scala dell'asse verticale per i valori; le barre partono sempre da 0."""
    if not valori:
        return (0.0, 1.0, 0.2)
    minimo, massimo = min(valori), max(valori)
    if tipo == "barre":
        minimo, massimo = min(0.0, minimo), max(0.0, massimo)
    return scala_asse(minimo, massimo)


def y_di(valore: float, area: Rettangolo, scala: tuple[float, float, float]) -> float:
    """Coordinata verticale (pixel) di un valore nell'area con la scala data."""
    x, y, w, h = area
    inizio, fine, _ = scala
    if fine == inizio:
        return y + h
    return y + h - (valore - inizio) / (fine - inizio) * h


def geometria_barre(valori: Sequence[float], area: Rettangolo,
                    scala: tuple[float, float, float] | None = None,
                    spazio: float = 0.2) -> list[tuple[float, float, float, float]]:
    """Rettangoli ``(x, y, w, h)`` delle barre; le barre negative scendono sotto lo zero."""
    if not valori:
        return []
    scala = scala or scala_dati(valori, "barre")
    x0, _y0, w, _h = area
    fetta = w / len(valori)
    larghezza_barra = fetta * (1 - spazio)
    zero = y_di(0.0, area, scala)
    rettangoli = []
    for i, v in enumerate(valori):
        yv = y_di(v, area, scala)
        alto = min(yv, zero)
        rettangoli.append((x0 + i * fetta + (fetta - larghezza_barra) / 2, alto, larghezza_barra, abs(zero - yv)))
    return rettangoli


def punti_linee(valori: Sequence[float], area: Rettangolo,
                scala: tuple[float, float, float] | None = None) -> list[tuple[float, float]]:
    """Punti ``(x, y)`` per i grafici a linee e a punti (centrati nella propria fetta)."""
    if not valori:
        return []
    scala = scala or scala_dati(valori, "linee")
    x0, _y0, w, _h = area
    fetta = w / len(valori)
    return [(x0 + (i + 0.5) * fetta, y_di(v, area, scala)) for i, v in enumerate(valori)]


def spicchi_torta(valori: Sequence[float]) -> list[tuple[float, float]]:
    """Spicchi ``(inizio, ampiezza)`` in gradi, in senso orario dalle ore 12.

    I valori negativi o nulli hanno ampiezza 0. Somma delle ampiezze = 360
    (se almeno un valore e' positivo).
    """
    positivi = [max(0.0, float(v)) for v in valori]
    totale = sum(positivi)
    spicchi = []
    angolo = 0.0
    for v in positivi:
        ampiezza = 360.0 * v / totale if totale > 0 else 0.0
        spicchi.append((angolo, ampiezza))
        angolo += ampiezza
    return spicchi


def cerchio_torta(area: Rettangolo) -> tuple[float, float, float]:
    """Centro e raggio ``(cx, cy, r)`` della torta dentro l'area."""
    x, y, w, h = area
    r = max(0.0, min(w, h) / 2)
    return (x + w / 2, y + h / 2, r)


def angolo_qt(inizio: float, ampiezza: float) -> tuple[int, int]:
    """Converte uno spicchio (gradi, orario dalle 12) negli angoli di ``QPainter.drawPie``
    (sedicesimi di grado, antiorario dalle ore 3)."""
    return (int(round((90.0 - inizio) * 16)), int(round(-ampiezza * 16)))


def indice_colpito(tipo: str, valori: Sequence[float], area: Rettangolo, x: float, y: float,
                   tolleranza: float = 8.0) -> int:
    """Indice del dato sotto il punto ``(x, y)``, oppure -1."""
    if not valori:
        return -1
    if tipo == "torta":
        cx, cy, r = cerchio_torta(area)
        dx, dy = x - cx, y - cy
        if dx * dx + dy * dy > r * r:
            return -1
        # angolo in senso orario dalle ore 12
        angolo = math.degrees(math.atan2(dx, -dy)) % 360.0
        for i, (inizio, ampiezza) in enumerate(spicchi_torta(valori)):
            if ampiezza > 0 and inizio <= angolo < inizio + ampiezza:
                return i
        return -1
    if tipo == "barre":
        for i, (bx, by, bw, bh) in enumerate(geometria_barre(valori, area)):
            if bx <= x <= bx + bw and by - 2 <= y <= by + max(bh, 2) + 2:
                return i
        return -1
    # linee e punti: il punto piu' vicino entro la tolleranza
    migliore, distanza = -1, tolleranza
    for i, (px, py) in enumerate(punti_linee(valori, area)):
        d = math.hypot(px - x, py - y)
        if d <= distanza:
            migliore, distanza = i, d
    return migliore


def dati_evento_grafico(dati: Any, indice: int) -> dict:
    """Dati dell'evento ``clic`` del grafico: ``{"indice", "valore"}`` (valore nulla se -1)."""
    if indice < 0 or not isinstance(dati, list) or indice >= len(dati):
        return {"indice": -1, "valore": None}
    d = dati[indice]
    valore = d[1] if isinstance(d, list) and len(d) == 2 else d
    return {"indice": indice, "valore": valore}


# ===========================================================================
# Albero
# ===========================================================================

SEPARATORE_PERCORSO = "/"


def dividi_percorso(percorso: Any) -> list[str]:
    """``"a/b/c"`` -> ``["a", "b", "c"]`` (le parti vuote si ignorano; "" = radice)."""
    if percorso is None:
        return []
    if not isinstance(percorso, str):
        raise ErroreTipo(f"Un percorso dell'albero è un testo come \"a/b\", non `{nome_tipo(percorso)}`.")
    return [p.strip() for p in percorso.split(SEPARATORE_PERCORSO) if p.strip()]


def unisci_percorso(parti: Iterable[str]) -> str:
    return SEPARATORE_PERCORSO.join(parti)


def normalizza_elementi(elementi: Any) -> dict:
    """Copia normalizzata degli elementi dell'albero.

    Forma: ``{etichetta: {figli...} | None}``. Si accettano anche liste di
    etichette (foglie) al posto dei dizionari; le etichette diventano testi.
    """
    if elementi is None:
        return {}
    if isinstance(elementi, list):
        risultato: dict = {}
        for e in elementi:
            if isinstance(e, (list, dict)):
                raise ErroreTipo("In una lista di elementi dell'albero ci vanno solo etichette.",
                                 suggerimento="Per i sottoelementi usa un dizionario: {\"Frutta\": [\"Mela\", \"Pera\"]}.")
            risultato[testo_valore(e)] = None
        return risultato
    if not isinstance(elementi, dict):
        raise ErroreTipo(f"`elementi` dell'albero deve essere un dizionario, non `{nome_tipo(elementi)}`.")
    risultato = {}
    for k, v in elementi.items():
        etichetta = testo_valore(k)
        if v is None or (isinstance(v, (dict, list)) and not v):
            risultato[etichetta] = None if v is None else {}
        elif isinstance(v, (dict, list)):
            risultato[etichetta] = normalizza_elementi(v)
        else:
            # un valore semplice diventa un figlio foglia
            risultato[etichetta] = {testo_valore(v): None}
    return risultato


def trova_nodo(elementi: dict, percorso: Any) -> dict | None:
    """Figli del nodo al ``percorso`` (la radice per ""); ``None`` se il nodo e' una foglia.

    Percorso inesistente -> ``ErroreValore``.
    """
    nodo: Any = elementi
    fatto: list[str] = []
    for parte in dividi_percorso(percorso):
        if not isinstance(nodo, dict) or parte not in nodo:
            raise ErroreValore(f"Nell'albero non c'è l'elemento `{unisci_percorso(fatto + [parte])}`.")
        fatto.append(parte)
        nodo = nodo[parte]
    return nodo


def esiste_percorso(elementi: dict, percorso: Any) -> bool:
    try:
        trova_nodo(elementi, percorso)
    except (ErroreValore, ErroreTipo):
        return False
    return True


def aggiungi_elemento(elementi: dict, percorso_genitore: Any, etichetta: Any) -> dict:
    """Nuovi elementi con ``etichetta`` aggiunta sotto ``percorso_genitore`` ("" = radice)."""
    import copy

    testo = testo_valore(etichetta).strip()
    if not testo:
        raise ErroreValore("L'etichetta di un elemento dell'albero non può essere vuota.")
    if SEPARATORE_PERCORSO in testo:
        raise ErroreValore(f"L'etichetta `{testo}` non può contenere `/`: serve a separare i livelli.")
    nuovi = copy.deepcopy(normalizza_elementi(elementi))
    parti = dividi_percorso(percorso_genitore)
    nodo: Any = nuovi
    genitore: Any = None
    for parte in parti:
        if not isinstance(nodo, dict) or parte not in nodo:
            raise ErroreValore(f"Nell'albero non c'è l'elemento `{unisci_percorso(parti)}`.")
        genitore = nodo
        nodo = nodo[parte]
    if nodo is None:  # una foglia diventa un ramo
        nodo = {}
        genitore[parti[-1]] = nodo
    if testo in nodo:
        raise ErroreValore(f"Sotto `{unisci_percorso(parti) or 'la radice'}` c'è già `{testo}`.")
    nodo[testo] = None
    return nuovi


def rimuovi_elemento(elementi: dict, percorso: Any) -> dict:
    """Nuovi elementi senza il nodo al ``percorso`` (e i suoi figli)."""
    import copy

    parti = dividi_percorso(percorso)
    if not parti:
        raise ErroreValore("Indica quale elemento togliere, per esempio \"Frutta/Mela\".")
    nuovi = copy.deepcopy(normalizza_elementi(elementi))
    genitore = trova_nodo(nuovi, unisci_percorso(parti[:-1]))
    if not isinstance(genitore, dict) or parti[-1] not in genitore:
        raise ErroreValore(f"Nell'albero non c'è l'elemento `{unisci_percorso(parti)}`.")
    del genitore[parti[-1]]
    return nuovi


def percorsi_albero(elementi: dict, prefisso: str = "") -> list[str]:
    """Tutti i percorsi, in ordine (prima il genitore, poi i figli)."""
    risultato = []
    for etichetta, figli in (elementi or {}).items():
        percorso = f"{prefisso}{SEPARATORE_PERCORSO}{etichetta}" if prefisso else etichetta
        risultato.append(percorso)
        if isinstance(figli, dict):
            risultato.extend(percorsi_albero(figli, percorso))
    return risultato


# ===========================================================================
# Tabella
# ===========================================================================

def lettera_colonna(indice: int) -> str:
    """0 -> "A", 25 -> "Z", 26 -> "AA" (intestazioni delle colonne in piu')."""
    testo = ""
    n = indice + 1
    while n > 0:
        n, resto = divmod(n - 1, 26)
        testo = chr(ord("A") + resto) + testo
    return testo


def normalizza_tabella(colonne: Any, righe: Any) -> tuple[list[str], list[list]]:
    """Intestazioni e righe rettangolari.

    Una riga che non e' una lista diventa una riga di una sola cella; le righe
    corte si completano con ``""``; se una riga e' piu' lunga delle colonne si
    aggiungono intestazioni con lettere ("D", "E"...).
    """
    if not isinstance(colonne, list):
        raise ErroreTipo(f"`colonne` deve essere una lista, non `{nome_tipo(colonne)}`.")
    if not isinstance(righe, list):
        raise ErroreTipo(f"`righe` deve essere una lista, non `{nome_tipo(righe)}`.")
    intestazioni = [testo_valore(c) for c in colonne]
    righe_norm = [list(r) if isinstance(r, list) else [r] for r in righe]
    larghezza = max([len(intestazioni)] + [len(r) for r in righe_norm])
    for i in range(len(intestazioni), larghezza):
        intestazioni.append(lettera_colonna(i))
    for r in righe_norm:
        r.extend([""] * (larghezza - len(r)))
    return intestazioni, righe_norm


def controlla_cella(righe: Sequence[Sequence[Any]], riga: Any, colonna: Any) -> tuple[int, int]:
    """Controlla gli indici di una cella; ``ErroreTipo``/``ErroreIndice`` in italiano."""
    for nome, v in (("riga", riga), ("colonna", colonna)):
        if not e_intero(v):
            raise ErroreTipo(f"L'indice di {nome} deve essere un intero, non `{nome_tipo(v)}`.")
    if not righe:
        raise ErroreIndice("La tabella è vuota: non ci sono celle.")
    if not 0 <= riga < len(righe):
        raise ErroreIndice(f"La riga {riga} non esiste: le righe vanno da 0 a {len(righe) - 1}.")
    if not 0 <= colonna < len(righe[riga]):
        raise ErroreIndice(f"La colonna {colonna} non esiste: le colonne vanno da 0 a {len(righe[riga]) - 1}.")
    return int(riga), int(colonna)


def converti_cella(testo: str, vecchio: Any = "") -> Any:
    """Valore Leo di una cella modificata dall'utente.

    Se la cella conteneva un numero e il testo e' un numero, resta un numero
    (intero o decimale); altrimenti diventa testo. Si accetta anche la virgola
    decimale all'italiana (``"3,5"``).
    """
    t = testo.strip()
    if e_numero(vecchio) or (vecchio in ("", None) and t and re.fullmatch(r"[-+]?\d+([.,]\d+)?", t)):
        try:
            if re.fullmatch(r"[-+]?\d+", t):
                return int(t)
            return float(t.replace(",", "."))
        except ValueError:
            return testo
    return testo


# ===========================================================================
# Menu contestuale e barra degli strumenti
# ===========================================================================

SEPARATORE_VOCI = "-"


def voci_menu(voci: Any) -> list[tuple[int, str] | None]:
    """Voci del ``MenuContestuale``: ``(indice, testo)`` oppure ``None`` per un separatore.

    ``indice`` e' la posizione nella lista originale (quella dell'evento ``clic``).
    Separatori all'inizio, alla fine o ripetuti si tolgono.
    """
    if not isinstance(voci, list):
        raise ErroreTipo(f"`voci` deve essere una lista, non `{nome_tipo(voci)}`.")
    risultato: list[tuple[int, str] | None] = []
    for i, v in enumerate(voci):
        testo = testo_valore(v)
        if testo.strip() == SEPARATORE_VOCI or set(testo.strip()) == {"-"}:
            if risultato and risultato[-1] is not None:
                risultato.append(None)
        else:
            risultato.append((i, testo))
    while risultato and risultato[-1] is None:
        risultato.pop()
    return risultato


def dati_evento_menu(voci: list, indice: int) -> dict:
    """Dati del ``clic`` di una voce: ``{"indice", "voce"}``."""
    voce = testo_valore(voci[indice]) if 0 <= indice < len(voci) else ""
    return {"indice": indice, "voce": voce}


def pulsanti_barra(pulsanti: Any) -> list[tuple[int, str, str] | None]:
    """Pulsanti della ``BarraStrumenti``: ``(indice, testo, icona)`` o ``None`` (separatore).

    Ogni elemento e' un testo oppure ``[testo, icona]``.
    """
    if not isinstance(pulsanti, list):
        raise ErroreTipo(f"`pulsanti` deve essere una lista, non `{nome_tipo(pulsanti)}`.")
    risultato: list[tuple[int, str, str] | None] = []
    for i, p in enumerate(pulsanti):
        if isinstance(p, list):
            if not p or len(p) > 2:
                raise ErroreValore(f"Il pulsante {i} della barra non va bene.",
                                   suggerimento="Usa un testo oppure [testo, icona], per esempio [\"Apri\", \"apri.png\"].")
            testo = testo_valore(p[0])
            icona = testo_valore(p[1]) if len(p) == 2 else ""
        else:
            testo, icona = testo_valore(p), ""
        if testo.strip() == SEPARATORE_VOCI and not icona:
            risultato.append(None)
        else:
            risultato.append((i, testo, icona))
    return risultato


def dati_evento_barra(pulsanti: list, indice: int) -> dict:
    """Dati del ``clic`` della barra: ``{"indice", "pulsante"}`` (testo del pulsante)."""
    testo = ""
    if 0 <= indice < len(pulsanti):
        p = pulsanti[indice]
        testo = testo_valore(p[0] if isinstance(p, list) and p else p)
    return {"indice": indice, "pulsante": testo}


# ===========================================================================
# Disegno: Immagine, Linea, Forma
# ===========================================================================

MODI_ADATTA = ("adatta", "riempi", "estendi", "nessuno")


def rettangolo_immagine(larghezza_img: float, altezza_img: float, larghezza: float, altezza: float,
                        adatta: str = "adatta") -> tuple[float, float, float, float]:
    """Dove disegnare un'immagine nel controllo ``Immagine``.

    * ``adatta``: tutta visibile, proporzioni mantenute, centrata;
    * ``riempi``: copre tutto il controllo, proporzioni mantenute (i bordi escono);
    * ``estendi``: deformata per coprire esattamente il controllo;
    * ``nessuno``: dimensione originale, in alto a sinistra.
    """
    if larghezza_img <= 0 or altezza_img <= 0:
        return (0.0, 0.0, 0.0, 0.0)
    if adatta == "estendi":
        return (0.0, 0.0, float(larghezza), float(altezza))
    if adatta == "nessuno":
        return (0.0, 0.0, float(larghezza_img), float(altezza_img))
    sx, sy = larghezza / larghezza_img, altezza / altezza_img
    s = max(sx, sy) if adatta == "riempi" else min(sx, sy)
    w, h = larghezza_img * s, altezza_img * s
    return ((larghezza - w) / 2, (altezza - h) / 2, w, h)


def estremi_linea(direzione: str, larghezza: float, altezza: float,
                  spessore: float = 1) -> tuple[float, float, float, float]:
    """Estremi ``(x1, y1, x2, y2)`` della ``Linea`` nel suo rettangolo."""
    m = spessore / 2
    if direzione == "verticale":
        return (larghezza / 2, m, larghezza / 2, altezza - m)
    if direzione == "diagonale":
        return (m, m, larghezza - m, altezza - m)
    if direzione == "diagonale_inversa":
        return (m, altezza - m, larghezza - m, m)
    return (m, altezza / 2, larghezza - m, altezza / 2)  # orizzontale


def rettangolo_forma(figura: str, larghezza: float, altezza: float,
                     spessore: float = 1) -> tuple[float, float, float, float, float]:
    """Rettangolo ``(x, y, w, h, raggio_angoli)`` della ``Forma`` (dentro il bordo).

    ``cerchio`` usa un quadrato centrato; ``rettangolo_arrotondato`` ha un raggio
    pari a un quinto del lato minore (al massimo 16).
    """
    m = spessore / 2
    w, h = max(0.0, larghezza - spessore), max(0.0, altezza - spessore)
    x, y = m, m
    raggio = 0.0
    if figura == "cerchio":
        lato = min(w, h)
        x, y, w, h = x + (w - lato) / 2, y + (h - lato) / 2, lato, lato
    elif figura == "rettangolo_arrotondato":
        raggio = min(16.0, min(w, h) / 5)
    return (x, y, w, h, raggio)


FIGURE_TELA = ("linea", "rettangolo", "cerchio", "testo")


def normalizza_comando_disegno(comando: Any) -> dict | None:
    """Comando di disegno della ``Tela`` (voce di ``disegni``) pronto per il disegno.

    ``{"figura": "linea", "x1": .., "y1": .., "x2": .., "y2": ..}``,
    ``{"figura": "rettangolo", "x", "y", "larghezza", "altezza", "riempito"}``,
    ``{"figura": "cerchio", "x", "y", "raggio", "riempito"}``,
    ``{"figura": "testo", "x", "y", "testo"}``; tutti con ``colore`` e ``spessore``
    facoltativi. Restituisce ``None`` per un comando non valido (che si salta).
    """
    if not isinstance(comando, dict):
        return None
    figura = comando.get("figura")
    campi = {"linea": ("x1", "y1", "x2", "y2"), "rettangolo": ("x", "y", "larghezza", "altezza"),
             "cerchio": ("x", "y", "raggio"), "testo": ("x", "y")}.get(figura)
    if campi is None:
        return None
    risultato: dict[str, Any] = {"figura": figura}
    for campo in campi:
        v = comando.get(campo)
        if not e_numero(v):
            return None
        risultato[campo] = float(v)
    if figura in ("rettangolo", "cerchio"):
        if min(risultato.get("larghezza", 0), risultato.get("altezza", 0), risultato.get("raggio", 0)) < 0:
            return None
        risultato["riempito"] = comando.get("riempito") is True
    if figura == "testo":
        risultato["testo"] = testo_valore(comando.get("testo", ""))
    colore = comando.get("colore")
    risultato["colore"] = colore if isinstance(colore, str) and colore else "#000000"
    spessore = comando.get("spessore", 2)
    risultato["spessore"] = float(spessore) if e_numero(spessore) and spessore > 0 else 1.0
    return risultato


# ===========================================================================
# Contenitori: Divisore, PannelloScorrevole
# ===========================================================================

def dimensioni_divisore(totale: int, posizione: int, maniglia: int = 5,
                        minimo: int = 0) -> list[int]:
    """Dimensioni ``[prima, seconda]`` dei due riquadri del ``Divisore``."""
    utile = max(0, int(totale) - int(maniglia))
    prima = int(limita(int(posizione), minimo, max(minimo, utile - minimo)))
    return [prima, max(0, utile - prima)]


def scostamento_divisore(scheda: Any, orientamento: Any, posizione: Any, maniglia: int = 5) -> tuple[int, int]:
    """Dove comincia il riquadro ``scheda`` (0 o 1) di un ``Divisore``, rispetto al suo angolo.

    Convenzione comune a Leo Studio e al runtime: le coordinate dei figli di
    ``Schede``/``Divisore`` nella ``.maschera`` sono relative all'angolo del
    contenitore; il runtime le sposta nel riquadro sottraendo questo scostamento
    (calcolato con la ``posizione`` scritta nella maschera, cosi' poi i figli si
    muovono insieme al loro riquadro quando si trascina la barra).
    """
    try:
        indice = int(scheda or 0)
    except (TypeError, ValueError):
        indice = 0
    if indice < 1:
        return (0, 0)
    try:
        inizio = max(0, int(posizione)) + max(0, int(maniglia))
    except (TypeError, ValueError):
        inizio = 150 + max(0, int(maniglia))
    if str(orientamento or "orizzontale") == "verticale":
        return (0, inizio)
    return (inizio, 0)


def rettangolo_nella_pagina(rettangolo: Sequence[int], scostamento: Sequence[int]) -> tuple[int, int, int, int]:
    """Rettangolo del modello (relativo al contenitore) portato nella pagina che parte da ``scostamento``."""
    x, y, w, h = (int(v) for v in rettangolo[:4])
    dx, dy = (int(v) for v in scostamento[:2])
    return (x - dx, y - dy, max(0, w), max(0, h))


def dimensione_contenuto(rettangoli_figli: Iterable[Sequence[int]], larghezza_contenuto: int = 0,
                         altezza_contenuto: int = 0, visibile: tuple[int, int] = (0, 0),
                         margine: int = 8) -> tuple[int, int]:
    """Dimensione dell'area interna del ``PannelloScorrevole``.

    0 = automatica: arriva fino al bordo del controllo figlio piu' lontano
    (piu' un margine), e mai meno dell'area visibile.
    """
    larghezza, altezza = int(larghezza_contenuto), int(altezza_contenuto)
    if larghezza <= 0 or altezza <= 0:
        destra = basso = 0
        for r in rettangoli_figli:
            x, y, w, h = (int(v) for v in r[:4])
            destra = max(destra, x + w)
            basso = max(basso, y + h)
        if larghezza <= 0:
            larghezza = max(visibile[0], destra + margine if destra else 0)
        if altezza <= 0:
            altezza = max(visibile[1], basso + margine if basso else 0)
    return max(0, larghezza), max(0, altezza)


# ===========================================================================
# DialogoFile e Suggerimento
# ===========================================================================

def filtro_qt(filtro: Any) -> str:
    """Filtro di ``DialogoFile`` nel formato di ``QFileDialog``.

    ``"Tutti i file (*.*)"`` -> ``"Tutti i file (*)"``; piu' filtri si separano
    con ``;;`` o con ``|`` (``"Immagini (*.png *.jpg)|Testi (*.txt)"``). Un
    filtro senza parentesi (``"*.txt"``) resta com'e'.
    """
    if not isinstance(filtro, str) or not filtro.strip():
        return "Tutti i file (*)"
    parti = [p.strip() for p in re.split(r";;|\|", filtro) if p.strip()]
    risultato = []
    for p in parti:
        p = re.sub(r"(?<![\w*])\*\.\*(?![\w*])", "*", p)
        risultato.append(p)
    return ";;".join(risultato)


MODALITA_DIALOGO = ("apri", "salva", "cartella")


def testo_suggerimento(testi: Any, nome: str) -> str:
    """Testo del ``Suggerimento`` per il controllo ``nome`` ("" se non c'e')."""
    if not isinstance(testi, dict):
        return ""
    v = testi.get(nome)
    return "" if v is None else testo_valore(v)


# ===========================================================================
# Ordine di applicazione delle proprieta' iniziali
# ===========================================================================

#: Proprieta' da applicare per prime (limiti, contenuti) ...
PROPRIETA_PRIMA = ("minimo", "massimo", "passo", "decimali", "orientamento", "multipla", "modificabile",
                   "elementi", "colonne", "righe", "schede", "voci", "pulsanti", "tipo_grafico",
                   "minimo_data", "massimo_data", "larghezza_contenuto", "altezza_contenuto",
                   "file", "immagine")
#: ... e per ultime (valori che dipendono dalle precedenti).
PROPRIETA_DOPO = ("valore", "data", "indice_selezionato", "selezione", "scheda_corrente", "riga_selezionata",
                  "selezionata", "acceso", "posizione", "scorrimento_x", "scorrimento_y", "attivo",
                  "automatico", "visibile")
GEOMETRIA = ("sinistra", "alto", "larghezza", "altezza")


def ordine_proprieta(nomi: Iterable[str]) -> list[str]:
    """Ordine in cui applicare le proprieta' iniziali di un controllo:
    geometria, poi limiti e contenuti, poi il resto, infine i valori."""
    nomi = list(dict.fromkeys(nomi))

    def peso(n: str) -> tuple[int, int]:
        if n in GEOMETRIA:
            return (0, GEOMETRIA.index(n))
        if n in PROPRIETA_PRIMA:
            return (1, PROPRIETA_PRIMA.index(n))
        if n in PROPRIETA_DOPO:
            return (3, PROPRIETA_DOPO.index(n))
        return (2, 0)

    return sorted(nomi, key=peso)

