"""Ancoraggi dei controlli: come si spostano e si allargano quando la finestra cambia misura.

Nessuna dipendenza da Qt. Regole (come Windows Forms, docs/CONTRATTI.md §13.3):

* in orizzontale: ``sinistra`` + ``destra`` -> il controllo si allarga di Δw;
  solo ``destra`` -> si sposta di Δw; nessuno dei due -> si sposta di Δw/2
  (resta centrato rispetto a dove era); solo ``sinistra`` -> resta fermo;
* in verticale lo stesso con ``alto`` / ``basso`` e Δh;
* le dimensioni non diventano mai negative;
* si calcola sempre dal rettangolo **originale**, cosi' allargando e
  stringendo molte volte la finestra non si accumulano errori di arrotondamento.

API::

    calcola_rettangolo(rettangolo, ancoraggio, dimensione_originale, dimensione_nuova) -> (x, y, w, h)
    class GestoreAncoraggi(dimensione_originale):
        registra(nome, rettangolo, ancoraggio, dimensione=None)
        aggiorna(dimensione_nuova) -> dict[nome, (x, y, w, h)]
"""

from __future__ import annotations

from typing import Iterable

Rettangolo = tuple[int, int, int, int]
Dimensione = tuple[int, int]


def _lati(ancoraggio: Iterable[str] | str | None) -> set[str]:
    if ancoraggio is None:
        return set()
    if isinstance(ancoraggio, str):
        return set(ancoraggio.replace(",", " ").replace("+", " ").split())
    return {str(lato) for lato in ancoraggio}


def _meta(delta: int) -> int:
    """Meta' di uno spostamento, troncata verso lo zero (simmetrica tra allargare e stringere)."""
    return int(delta / 2)


def _asse(inizio: int, misura: int, delta: int, primo: bool, secondo: bool) -> tuple[int, int]:
    if primo and secondo:
        return inizio, max(0, misura + delta)
    if secondo:
        return inizio + delta, max(0, misura)
    if primo:
        return inizio, max(0, misura)
    return inizio + _meta(delta), max(0, misura)


def calcola_rettangolo(rettangolo: tuple[int, int, int, int], ancoraggio: list[str],
                       dimensione_originale: tuple[int, int], dimensione_nuova: tuple[int, int]
                       ) -> tuple[int, int, int, int]:
    """Nuovo rettangolo ``(sinistra, alto, larghezza, altezza)`` del controllo.

    ``rettangolo`` e' quello che il controllo aveva quando la finestra era grande
    ``dimensione_originale``; ``ancoraggio`` e' la lista dei lati (anche un
    testo come ``"alto destra"``).
    """
    x, y, w, h = (int(v) for v in rettangolo)
    ow, oh = (int(v) for v in dimensione_originale)
    nw, nh = (int(v) for v in dimensione_nuova)
    lati = _lati(ancoraggio)
    nx, nw_ctrl = _asse(x, w, nw - ow, "sinistra" in lati, "destra" in lati)
    ny, nh_ctrl = _asse(y, h, nh - oh, "alto" in lati, "basso" in lati)
    return nx, ny, nw_ctrl, nh_ctrl


class GestoreAncoraggi:
    """Ricorda il rettangolo originale di ogni controllo e lo ricalcola a ogni ridimensionamento."""

    def __init__(self, dimensione_originale: tuple[int, int]) -> None:
        self.dimensione_originale: Dimensione = (int(dimensione_originale[0]), int(dimensione_originale[1]))
        self.dimensione_attuale: Dimensione = self.dimensione_originale
        # nome -> (rettangolo di riferimento, ancoraggio, dimensione della finestra di riferimento)
        self._controlli: dict[str, tuple[Rettangolo, list[str], Dimensione]] = {}

    def registra(self, nome: str, rettangolo, ancoraggio: list[str],
                 dimensione: tuple[int, int] | None = None) -> None:
        """Registra (o aggiorna) un controllo.

        ``dimensione``: misura della finestra a cui si riferisce ``rettangolo``
        (predefinita: la dimensione originale). Quando il codice sposta un
        controllo mentre la finestra e' gia' stata ridimensionata, lo si
        registra di nuovo passando la dimensione attuale della finestra.
        """
        rett = tuple(int(v) for v in rettangolo)
        if len(rett) != 4:
            raise ValueError("il rettangolo deve avere 4 valori: sinistra, alto, larghezza, altezza")
        riferimento = self.dimensione_originale if dimensione is None else (int(dimensione[0]), int(dimensione[1]))
        self._controlli[nome] = (rett, sorted(_lati(ancoraggio)), riferimento)  # type: ignore[assignment]

    def rimuovi(self, nome: str) -> None:
        """Dimentica un controllo (nessun errore se non c'e')."""
        self._controlli.pop(nome, None)

    def nomi(self) -> list[str]:
        return list(self._controlli)

    def __contains__(self, nome: object) -> bool:
        return nome in self._controlli

    def __len__(self) -> int:
        return len(self._controlli)

    def rettangolo(self, nome: str, dimensione_nuova: tuple[int, int] | None = None) -> Rettangolo:
        """Rettangolo di un solo controllo per la dimensione data (predefinita: quella attuale)."""
        rett, lati, riferimento = self._controlli[nome]
        dimensione = self.dimensione_attuale if dimensione_nuova is None else dimensione_nuova
        return calcola_rettangolo(rett, lati, riferimento, dimensione)

    def aggiorna(self, dimensione_nuova: tuple[int, int]) -> dict[str, tuple[int, int, int, int]]:
        """Rettangoli di tutti i controlli registrati per la nuova misura della finestra."""
        self.dimensione_attuale = (int(dimensione_nuova[0]), int(dimensione_nuova[1]))
        return {nome: calcola_rettangolo(rett, lati, riferimento, self.dimensione_attuale)
                for nome, (rett, lati, riferimento) in self._controlli.items()}


__all__ = ["calcola_rettangolo", "GestoreAncoraggi"]
