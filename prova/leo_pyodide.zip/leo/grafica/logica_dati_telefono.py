"""Logica pura (senza Qt e senza pagina) degli oggetti "dati, cruscotti e telefono".

La usano il catalogo (``catalogo_dati_telefono``), i widget del computer
(``qt/widget_dati_telefono``) e il motore del telefono (``web/dati_telefono``), cosi' PC e telefono
fanno gli stessi conti: zone del Cruscotto, ordine e filtro della TabellaOrdinabile, livelli della
luce, altitudine dal barometro, scosse del Movimento, passi del Contapassi.
"""

from __future__ import annotations

import math
import re
import unicodedata
from typing import Any, Iterable

__all__ = [
    "ZONE", "zona_cruscotto", "frazione", "chiave_ordine", "righe_normali", "indice_colonna", "filtra_righe",
    "ordina_indici", "indici_visibili", "LIVELLI_LUCE", "livello_luce", "altitudine_da_pressione",
    "tendenza_pressione", "SENSIBILITA", "RilevatoreScosse", "distanza_passi", "orientamento_da_misure",
    "tipo_rete_leggibile", "serie_da_valore", "aggiungi_a_serie", "limiti_serie",
]


# ===========================================================================
# Cruscotto e AnelloAvanzamento
# ===========================================================================

#: Zone del Cruscotto, dalla piu' tranquilla alla piu' pericolosa, con i loro colori.
ZONE = ("normale", "attenzione", "pericolo")
COLORI_ZONE = {"normale": "#30B158", "attenzione": "#FF9F0A", "pericolo": "#FF3B30"}


def _num(v: Any, predefinito: float = 0.0) -> float:
    try:
        n = float(v)
    except (TypeError, ValueError):
        return predefinito
    return n if math.isfinite(n) else predefinito


def zona_cruscotto(valore: Any, attenzione: Any, pericolo: Any) -> str:
    """"normale", "attenzione" o "pericolo".

    Di solito il pericolo e' in alto (temperatura: attenzione 60, pericolo 80). Se ``pericolo`` e'
    minore di ``attenzione`` il pericolo e' in basso (batteria: attenzione 30, pericolo 10).
    """
    v, a, p = _num(valore), _num(attenzione), _num(pericolo)
    if p >= a:
        return "pericolo" if v >= p else "attenzione" if v >= a else "normale"
    return "pericolo" if v <= p else "attenzione" if v <= a else "normale"


def frazione(valore: Any, minimo: Any, massimo: Any) -> float:
    """Dove sta ``valore`` tra ``minimo`` e ``massimo``: da 0.0 a 1.0."""
    a, b, v = _num(minimo), _num(massimo, 100.0), _num(valore)
    if b == a:
        return 0.0
    return max(0.0, min(1.0, (v - a) / (b - a)))


# ===========================================================================
# TabellaOrdinabile: ordine e filtro (gli stessi in Python, nel widget Qt e in finestre_dati.js)
# ===========================================================================

def _semplice(testo: Any) -> str:
    """Minuscole e senza accenti: "Città" -> "citta"."""
    t = unicodedata.normalize("NFD", str(testo).casefold())
    return "".join(c for c in t if not unicodedata.combining(c))


_NUMERO = re.compile(r"^[-+]?\d{1,3}(\.\d{3})*(,\d+)?$|^[-+]?\d+([.,]\d+)?$")
_DATA = re.compile(r"^(\d{1,2})/(\d{1,2})/(\d{4})$")


def chiave_ordine(valore: Any) -> tuple:
    """Chiave per ordinare le celle: prima i numeri (anche "1.234,5" e le date GG/MM/AAAA), poi i testi
    (senza badare a maiuscole e accenti), in fondo le celle vuote."""
    if isinstance(valore, bool):
        return (1, 0.0, "vero" if valore else "falso")
    if isinstance(valore, (int, float)) and math.isfinite(float(valore)):
        return (0, float(valore), "")
    testo = "" if valore is None else str(valore).strip()
    if not testo:
        return (2, 0.0, "")
    data = _DATA.match(testo)
    if data:
        g, m, a = (int(x) for x in data.groups())
        return (0, float(a * 10000 + m * 100 + g), "")
    if _NUMERO.match(testo):
        if "," in testo:
            numero = testo.replace(".", "").replace(",", ".")
        elif re.match(r"^[-+]?\d{1,3}(\.\d{3})+$", testo):
            numero = testo.replace(".", "")          # "1.234" all'italiana
        else:
            numero = testo
        try:
            return (0, float(numero), "")
        except ValueError:
            pass
    return (1, 0.0, _semplice(testo))


def righe_normali(righe: Any) -> list[list[Any]]:
    """Le righe come liste (una cella sola se la riga non e' una lista)."""
    if not isinstance(righe, list):
        return []
    return [list(r) if isinstance(r, (list, tuple)) else [r] for r in righe]


def indice_colonna(colonna: Any, colonne: Any) -> int:
    """Numero della colonna (da 0) dal numero o dal nome (maiuscole e accenti non contano); -1 se non c'e'."""
    if isinstance(colonna, bool):
        return -1
    if isinstance(colonna, int):
        return colonna
    if isinstance(colonna, float) and colonna.is_integer():
        return int(colonna)
    nomi = [_semplice(c) for c in (colonne if isinstance(colonne, list) else [])]
    chiave = _semplice(colonna).strip()
    return nomi.index(chiave) if chiave in nomi else -1


def filtra_righe(righe: list[list[Any]], filtro: Any) -> list[int]:
    """Indici delle righe che contengono TUTTE le parole del filtro (in qualunque cella)."""
    parole = _semplice(filtro or "").split()
    if not parole:
        return list(range(len(righe)))
    risultato = []
    for i, riga in enumerate(righe):
        testo = " ".join(_semplice("" if x is None else x) for x in riga)
        if all(p in testo for p in parole):
            risultato.append(i)
    return risultato


def ordina_indici(righe: list[list[Any]], indici: Iterable[int], colonna: int, crescente: bool = True) -> list[int]:
    """Gli ``indici`` delle righe ordinati secondo la colonna (ordine stabile; vuote sempre in fondo)."""
    indici = list(indici)
    if colonna < 0:
        return indici

    def chiave(i: int) -> tuple:
        riga = righe[i]
        return chiave_ordine(riga[colonna] if colonna < len(riga) else None)

    pieni = [i for i in indici if chiave(i)[0] != 2]
    vuoti = [i for i in indici if chiave(i)[0] == 2]
    pieni.sort(key=chiave, reverse=not crescente)
    return pieni + vuoti


def indici_visibili(righe: Any, filtro: Any = "", colonna: Any = -1, crescente: bool = True) -> list[int]:
    """Indici (nelle righe vere) delle righe da mostrare, nell'ordine in cui si vedono."""
    rr = righe_normali(righe)
    k = colonna if isinstance(colonna, int) and not isinstance(colonna, bool) else -1
    return ordina_indici(rr, filtra_righe(rr, filtro), k, bool(crescente))


# ===========================================================================
# GraficoDalVivo
# ===========================================================================

def serie_da_valore(dati: Any) -> dict[str, list[float]]:
    """``dati`` del GraficoDalVivo come {nome della serie: [numeri]} (una lista sola = serie "valore")."""
    if isinstance(dati, list):
        dati = {"valore": dati}
    if not isinstance(dati, dict):
        return {}
    risultato: dict[str, list[float]] = {}
    for nome, valori in dati.items():
        if isinstance(valori, list):
            risultato[str(nome)] = [float(x) for x in valori
                                    if isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)]
    return risultato


def aggiungi_a_serie(dati: Any, serie: str, valore: float, punti: int) -> dict[str, list[float]]:
    """Nuovo dizionario con ``valore`` in fondo alla serie; ogni serie tiene al massimo ``punti`` valori."""
    risultato = serie_da_valore(dati)
    lista = risultato.setdefault(str(serie), [])
    lista.append(float(valore))
    punti = max(1, int(punti))
    if len(lista) > punti:
        del lista[:len(lista) - punti]
    return risultato


def limiti_serie(serie: dict[str, list[float]], minimo: float, massimo: float, automatica: bool) -> tuple[float, float]:
    """(basso, alto) dell'asse verticale: fissi, oppure presi dai dati con un po' di margine."""
    if not automatica:
        return (minimo, massimo) if massimo > minimo else (minimo, minimo + 1)
    tutti = [x for valori in serie.values() for x in valori]
    if not tutti:
        return (minimo, massimo) if massimo > minimo else (0.0, 1.0)
    basso, alto = min(tutti), max(tutti)
    if alto == basso:
        return basso - 1, alto + 1
    margine = (alto - basso) * 0.1
    return basso - margine, alto + margine


# ===========================================================================
# Sensori del telefono
# ===========================================================================

#: (soglia in lux, livello): sotto la soglia vale il livello.
LIVELLI_LUCE = ((10.0, "buio"), (200.0, "poca luce"), (5000.0, "luce"), (float("inf"), "sole"))


def livello_luce(lux: Any) -> str:
    """"buio" (< 10 lux), "poca luce" (< 200), "luce" (< 5000, come in una stanza illuminata) o "sole"."""
    v = _num(lux)
    for soglia, nome in LIVELLI_LUCE:
        if v < soglia:
            return nome
    return "sole"


def altitudine_da_pressione(pressione: Any, pressione_mare: Any = 1013.25) -> float:
    """Altezza sul mare stimata dalla pressione (formula barometrica internazionale), in metri."""
    p, p0 = _num(pressione), _num(pressione_mare, 1013.25) or 1013.25
    if p <= 0:
        return 0.0
    return round(44330.0 * (1.0 - (p / p0) ** (1 / 5.255)), 1)


def tendenza_pressione(storia: list[tuple[float, float]], soglia: float = 0.5) -> str:
    """"sale", "scende" o "stabile": confronto tra la lettura piu' vecchia e la piu' nuova della ``storia``
    [(secondi, hPa)]. Una pressione che scende di solito annuncia brutto tempo."""
    if len(storia) < 2:
        return "stabile"
    differenza = storia[-1][1] - storia[0][1]
    if differenza >= soglia:
        return "sale"
    if differenza <= -soglia:
        return "scende"
    return "stabile"


#: Forza minima (in "g", 1 = peso normale) di una scossa per sensibilita'.
SENSIBILITA = {"alta": 1.5, "media": 2.0, "bassa": 2.7}
_G = 9.80665


class RilevatoreScosse:
    """Riconosce le scosse dalle letture dell'accelerometro [x, y, z] (m/s²).

    Una scossa e' un picco sopra la soglia della sensibilita'; picchi a meno di ``pausa`` secondi dal
    precedente sono la stessa scossa (una mano che agita il telefono fa molti picchi di fila).
    """

    def __init__(self, pausa: float = 0.5) -> None:
        self.pausa = pausa
        self.ultima = -1e9
        self.scosse = 0

    def lettura(self, x: float, y: float, z: float, adesso: float, sensibilita: str = "media") -> float | None:
        """La forza della scossa (in g, un decimale) se questa lettura e' una scossa nuova, altrimenti None."""
        forza = math.sqrt(x * x + y * y + z * z) / _G
        if forza < SENSIBILITA.get(sensibilita, SENSIBILITA["media"]):
            return None
        if adesso - self.ultima < self.pausa:
            self.ultima = adesso                 # la stessa scossa continua
            return None
        self.ultima = adesso
        self.scosse += 1
        return round(forza, 1)


def distanza_passi(passi: Any, lunghezza_passo: Any) -> float:
    """Chilometri percorsi (due decimali) con ``passi`` passi lunghi ``lunghezza_passo`` metri."""
    return round(max(0.0, _num(passi)) * max(0.0, _num(lunghezza_passo, 0.7)) / 1000.0, 2)


def orientamento_da_misure(larghezza: Any, altezza: Any) -> str:
    """"orizzontale" se lo schermo (o la finestra) e' piu' largo che alto, altrimenti "verticale"."""
    return "orizzontale" if _num(larghezza) > _num(altezza) else "verticale"


_TIPI_RETE = {"wifi": "Wi-Fi", "dati": "dati mobili", "cavo": "cavo", "nessuna": "nessuna rete",
              "altro": "altra rete", "sconosciuto": "sconosciuta"}


def tipo_rete_leggibile(tipo: Any) -> str:
    """"wifi" -> "Wi-Fi", "dati" -> "dati mobili"... (per le scritte)."""
    return _TIPI_RETE.get(str(tipo or ""), str(tipo or ""))
