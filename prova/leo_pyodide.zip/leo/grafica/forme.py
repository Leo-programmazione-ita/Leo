"""Forme delle finestre: geometria pura, senza Qt (CONTRATTI.md §13.2).

Una :class:`Forma` descrive il contorno di una finestra di Leo. Le forme
"con nome" (``"rettangolo"``, ``"arrotondata"``, ``"cerchio"``, ``"ellisse"``)
si possono indicare anche con un semplice testo; tutte le altre si creano con
le funzioni di questo modulo, che la libreria rende disponibili al codice Leo
(``forma_poligono(6)``, ``forma_stella(5)``, ``forma_punti([...])``, ...).

Tipi di forma e parametri (``Forma.tipo`` / ``Forma.parametri``)::

    rettangolo    {}
    arrotondata   {"raggio": 24}                     # raggio degli angoli in pixel
    cerchio       {}                                 # cerchio centrato, diametro = min(w, h)
    ellisse       {}                                 # ellisse inscritta nel rettangolo w x h
    poligono      {"lati": 6}                        # regolare, inscritto nell'ellisse, primo vertice in alto
    stella        {"punte": 5, "profondita": 0.5}    # raggio interno = esterno * (1 - profondita)
    punti         {"punti": [[x, y], ...]}           # in pixel, >= 3 punti
                  {"punti": [...], "curve": [[cx, cy] | None, ...]}
                                                     # lato i (da punti[i] a punti[i+1]) curvo:
                                                     # Bezier quadratica con quel punto di controllo
    immagine      {"percorso": "gatto.png"}          # le parti trasparenti del PNG sono "fuori"
    unione        {} con figli (a, b)                # dentro se in a oppure in b
    sottrazione   {} con figli (a, b)                # dentro se in a e non in b

Formato nei file ``.maschera``: tabella in linea con la chiave ``tipo_forma``
(vedi :meth:`Forma.a_dizionario`)::

    forma = { tipo_forma = "stella", punte = 5, profondita = 0.5 }
    forma = { tipo_forma = "sottrazione", figli = [{ tipo_forma = "cerchio" },
              { tipo_forma = "punti", punti = [[150, 150], [250, 150], [200, 250]] }] }

Nel TOML non esiste ``nulla``: nelle ``curve`` un lato dritto si scrive ``[]``.

Come usano le forme gli altri moduli:

* **Runtime** (``leo/grafica/qt/applicazione.py``): la proprieta' ``forma``
  della ``Finestra`` contiene un testo o una :class:`Forma`; a ogni cambio e a
  ogni ridimensionamento il runtime chiama
  ``forme_qt.applica_forma(finestra, forma, raggio_angoli, cartella)``, che usa
  :func:`forma_da_valore` e ritaglia la finestra con una maschera Qt. Il bordo
  (``bordo``/``colore_bordo``/``spessore_bordo``) si disegna con
  ``forme_qt.disegna_bordo``, che segue lo stesso contorno.
* **Leo Studio**: l'area di progettazione disegna :meth:`Forma.contorni`
  (poligoni in pixel, curve approssimate con segmenti) e segna in rosso i
  controlli per cui :meth:`Forma.contiene_rettangolo` e' falso
  (``progettazione.controlli_fuori_forma``). Lo strumento *Penna* crea le forme
  libere con :func:`forma_punti_curvi`: i clic danno i vertici, le maniglie
  trascinate danno i punti di controllo dei lati curvi.
* **Libreria** (``leo/libreria/grafica.py``): espone ``forma_poligono``,
  ``forma_stella``, ``forma_punti``, ``forma_immagine``, ``forma_unisci``,
  ``forma_sottrai`` come funzioni native che chiamano quelle di questo modulo.

Le forme sono valori immutabili: si confrontano per valore (``==``) e si
possono usare come chiavi. Per Leo il loro tipo e' ``"forma"``
(``NOME_TIPO_DANTE``) e si stampano come ``<forma poligono>``.
"""

from __future__ import annotations

import difflib
import math
from typing import Any, Iterable

from ..errori import ErroreTipo, ErroreValore

#: Tutti i tipi di forma conosciuti.
TIPI_FORMA = ("rettangolo", "arrotondata", "cerchio", "ellisse", "poligono", "stella",
              "punti", "immagine", "unione", "sottrazione")

#: Forme indicabili con un testo (uguale a ``metadati.FORME_NOMINATE``).
FORME_NOMINATE = ("rettangolo", "arrotondata", "cerchio", "ellisse")

#: Segmenti usati per approssimare una curva chiusa (cerchio, ellisse).
SEGMENTI_CURVA = 64
#: Segmenti per un quarto di cerchio (angoli arrotondati) e per un lato curvo.
SEGMENTI_ARCO = SEGMENTI_CURVA // 4

#: Parametri ammessi per ogni tipo (chiave -> obbligatorio).
_PARAMETRI: dict[str, dict[str, bool]] = {
    "rettangolo": {},
    "arrotondata": {"raggio": False},
    "cerchio": {},
    "ellisse": {},
    "poligono": {"lati": True},
    "stella": {"punte": True, "profondita": False},
    "punti": {"punti": True, "curve": False},
    "immagine": {"percorso": True},
    "unione": {},
    "sottrazione": {},
}

_COMPOSTE = ("unione", "sottrazione")

Punto = "tuple[float, float]"


# ===========================================================================
# Controlli sui valori
# ===========================================================================

def _nome_tipo(v: Any) -> str:
    try:
        from ..valori import nome_tipo
        return nome_tipo(v)
    except ImportError:  # pragma: no cover
        return type(v).__name__


def _e_numero(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v)


def _intero(valore: Any, nome: str, funzione: str) -> int:
    if isinstance(valore, float) and math.isfinite(valore) and valore.is_integer():
        valore = int(valore)
    if not isinstance(valore, int) or isinstance(valore, bool):
        raise ErroreTipo(f"`{funzione}` vuole un intero per `{nome}`, non `{_nome_tipo(valore)}`.",
                         suggerimento="Per convertire usa `intero(...)`.")
    return valore


def _numero(valore: Any, nome: str, funzione: str) -> float | int:
    if not _e_numero(valore):
        raise ErroreTipo(f"`{funzione}` vuole un numero per `{nome}`, non `{_nome_tipo(valore)}`.")
    return valore


def _punto(valore: Any, dove: str, funzione: str) -> list:
    if isinstance(valore, tuple):
        valore = list(valore)
    if not isinstance(valore, list):
        raise ErroreTipo(f"`{funzione}`: {dove} dovrebbe essere una lista `[x, y]`, non `{_nome_tipo(valore)}`.",
                         suggerimento="Scrivi ogni punto come `[x, y]`, per esempio `[100, 50]`.")
    if len(valore) != 2:
        raise ErroreValore(f"`{funzione}`: {dove} ha {len(valore)} numeri, ma un punto ne vuole 2 (`[x, y]`).",
                           suggerimento="Scrivi ogni punto come `[x, y]`, per esempio `[100, 50]`.")
    for c in valore:
        if not _e_numero(c):
            raise ErroreTipo(f"`{funzione}`: le coordinate di {dove} devono essere numeri, "
                             f"non `{_nome_tipo(c)}`.")
    return [valore[0], valore[1]]


def _suggerisci_forma(nome: str) -> str:
    vicine = difflib.get_close_matches(nome.lower(), list(FORME_NOMINATE) + ["poligono", "stella"], n=1, cutoff=0.6)
    if vicine and vicine[0] in FORME_NOMINATE:
        return f"Forse intendevi \"{vicine[0]}\"?"
    if vicine:
        return f"Per un{'a' if vicine[0] == 'stella' else ''} {vicine[0]} usa `forma_{vicine[0]}(...)`."
    return ("Forme con nome: " + ", ".join(f'"{f}"' for f in FORME_NOMINATE)
            + "; le altre si creano con `forma_poligono`, `forma_stella`, `forma_punti`...")


# ===========================================================================
# Forma
# ===========================================================================

def _congela(v: Any) -> Any:
    """Versione confrontabile e hashable di un parametro."""
    if isinstance(v, (list, tuple)):
        return tuple(_congela(x) for x in v)
    if isinstance(v, float) and v.is_integer():
        return int(v)
    return v


class Forma:
    """Contorno di una finestra (immutabile, uguaglianza per valore)."""

    NOME_TIPO_DANTE = "forma"

    __slots__ = ("_tipo", "_parametri", "_figli")

    def __init__(self, tipo: str, parametri: dict | None = None, figli: Iterable["Forma"] = ()) -> None:
        if tipo not in TIPI_FORMA:
            raise ErroreValore(f"La forma `{tipo}` non esiste.", suggerimento=_suggerisci_forma(str(tipo)))
        figli = tuple(figli)
        if tipo in _COMPOSTE:
            if len(figli) != 2 or not all(isinstance(f, Forma) for f in figli):
                raise ErroreValore(f"Una forma `{tipo}` vuole esattamente due forme.")
        elif figli:
            raise ErroreValore(f"La forma `{tipo}` non può avere forme figlie.")
        self._tipo = tipo
        self._parametri = dict(parametri or {})
        self._figli = figli

    # --- attributi in sola lettura ------------------------------------------
    @property
    def tipo(self) -> str:
        return self._tipo

    @property
    def parametri(self) -> dict:
        """Copia dei parametri (la forma non si modifica dopo la creazione)."""
        import copy

        return copy.deepcopy(self._parametri)

    @property
    def figli(self) -> tuple["Forma", ...]:
        return self._figli

    # --- confronto ----------------------------------------------------------
    def _chiave(self) -> tuple:
        return (self._tipo, tuple(sorted((k, _congela(v)) for k, v in self._parametri.items())),
                tuple(f._chiave() for f in self._figli))

    def __eq__(self, altro: object) -> bool:
        if not isinstance(altro, Forma):
            return NotImplemented
        return self._chiave() == altro._chiave()

    def __ne__(self, altro: object) -> bool:
        r = self.__eq__(altro)
        return r if r is NotImplemented else not r

    def __hash__(self) -> int:
        return hash(self._chiave())

    def __repr__(self) -> str:
        figli = f", figli={list(self._figli)!r}" if self._figli else ""
        return f"Forma({self._tipo!r}, {self._parametri!r}{figli})"

    def testo_dante(self) -> str:
        return f"<forma {self._tipo}>"

    def __str__(self) -> str:
        return self.testo_dante()

    # --- dizionario (file .maschera) ------------------------------------------
    def a_dizionario(self) -> dict:
        """``{"tipo_forma": tipo, **parametri, "figli": [...]}`` (figli solo se presenti).

        I lati dritti delle ``curve`` diventano ``[]`` (in TOML non c'e' nulla).
        """
        d: dict[str, Any] = {"tipo_forma": self._tipo}
        for k, v in self._parametri.items():
            if k == "curve":
                d[k] = [[] if c is None else list(c) for c in v]
            elif k == "punti":
                d[k] = [list(p) for p in v]
            else:
                d[k] = v
        if self._figli:
            d["figli"] = [f.a_dizionario() for f in self._figli]
        return d

    @classmethod
    def da_dizionario(cls, d: dict) -> "Forma":
        """Ricostruisce una forma da :meth:`a_dizionario` (controlla i parametri)."""
        if not isinstance(d, dict):
            raise ErroreTipo(f"Una forma si descrive con un dizionario, non con `{_nome_tipo(d)}`.")
        tipo = d.get("tipo_forma")
        if not isinstance(tipo, str):
            raise ErroreValore("Nella descrizione della forma manca `tipo_forma`.",
                               suggerimento="Esempio: `{ tipo_forma = \"poligono\", lati = 6 }`.")
        if tipo not in TIPI_FORMA:
            raise ErroreValore(f"La forma `{tipo}` non esiste.", suggerimento=_suggerisci_forma(tipo))
        ammessi = _PARAMETRI[tipo]
        altre = [k for k in d if k not in ammessi and k not in ("tipo_forma", "figli")]
        if altre:
            elenco = ", ".join(f"`{k}`" for k in ammessi) or "nessuno"
            raise ErroreValore(f"La forma `{tipo}` non ha il parametro `{altre[0]}`.",
                               suggerimento=f"Parametri di `{tipo}`: {elenco}.")
        for k, obbligatorio in ammessi.items():
            if obbligatorio and k not in d:
                raise ErroreValore(f"Alla forma `{tipo}` manca il parametro `{k}`.")
        if tipo in _COMPOSTE:
            figli = d.get("figli")
            if not isinstance(figli, list) or len(figli) != 2:
                raise ErroreValore(f"La forma `{tipo}` vuole `figli` con esattamente due forme.")
            a, b = (cls.da_dizionario(f) for f in figli)
            return Forma(tipo, {}, (a, b))
        if "figli" in d:
            raise ErroreValore(f"La forma `{tipo}` non può avere `figli`.")
        if tipo == "arrotondata":
            return forma_arrotondata(d.get("raggio", 0))
        if tipo == "poligono":
            return forma_poligono(d["lati"])
        if tipo == "stella":
            return forma_stella(d["punte"], d.get("profondita", 0.5))
        if tipo == "punti":
            if "curve" in d:
                return forma_punti_curvi(d["punti"], d["curve"])
            return forma_punti(d["punti"])
        if tipo == "immagine":
            return forma_immagine(d["percorso"])
        return Forma(tipo)

    # --- geometria ---------------------------------------------------------
    def contorni(self, larghezza: float, altezza: float) -> list[list[tuple[float, float]]]:
        """Poligoni chiusi (senza ripetere il primo punto) in pixel della finestra.

        Per ``unione`` e ``sottrazione`` sono i contorni di entrambe le forme:
        vanno bene per disegnare le linee, mentre l'appartenenza si chiede a
        :meth:`contiene`.
        """
        w = max(0.0, float(larghezza))
        h = max(0.0, float(altezza))
        t = self._tipo
        p = self._parametri
        if t in _COMPOSTE:
            return self._figli[0].contorni(w, h) + self._figli[1].contorni(w, h)
        if t in ("rettangolo", "immagine"):
            return [_rettangolo(w, h)]
        if t == "arrotondata":
            return [_arrotondato(w, h, float(p.get("raggio", 0)))]
        if t == "cerchio":
            r = min(w, h) / 2
            return [_ellisse(w / 2, h / 2, r, r, SEGMENTI_CURVA)]
        if t == "ellisse":
            return [_ellisse(w / 2, h / 2, w / 2, h / 2, SEGMENTI_CURVA)]
        if t == "poligono":
            return [_ellisse(w / 2, h / 2, w / 2, h / 2, int(p["lati"]))]
        if t == "stella":
            return [_stella(w, h, int(p["punte"]), float(p.get("profondita", 0.5)))]
        if t == "punti":
            return [_punti_curvi(p["punti"], p.get("curve"))]
        raise AssertionError(t)  # pragma: no cover

    def contiene(self, x: float, y: float, larghezza: float, altezza: float) -> bool:
        """Vero se il punto (x, y) e' dentro la forma (regola pari-dispari)."""
        t = self._tipo
        if t == "unione":
            a, b = self._figli
            return a.contiene(x, y, larghezza, altezza) or b.contiene(x, y, larghezza, altezza)
        if t == "sottrazione":
            a, b = self._figli
            return a.contiene(x, y, larghezza, altezza) and not b.contiene(x, y, larghezza, altezza)
        if t in ("rettangolo", "immagine"):
            return 0 <= x <= larghezza and 0 <= y <= altezza
        return _pari_dispari(x, y, self.contorni(larghezza, altezza))

    def contiene_rettangolo(self, rett: tuple[int, int, int, int], larghezza: float, altezza: float) -> bool:
        """Vero se tutto il rettangolo ``(x, y, w, h)`` sta dentro la forma.

        Si controllano gli angoli e punti lungo i lati (ogni 4 pixel), poi che
        nessun punto del contorno vero della forma cada dentro il rettangolo
        (rientranze, buchi delle forme combinate).
        """
        x, y, rw, rh = (float(v) for v in rett)
        if rw < 0 or rh < 0:
            return False
        eps = min(0.01, rw / 4 if rw else 0.01, rh / 4 if rh else 0.01)
        x0, y0, x1, y1 = x + eps, y + eps, x + rw - eps, y + rh - eps
        for px, py in _campioni_bordo(x0, y0, x1, y1, passo=4.0):
            if not self.contiene(px, py, larghezza, altezza):
                return False
        for vx, vy in self._vertici_di_bordo(larghezza, altezza):
            if x0 < vx < x1 and y0 < vy < y1:
                return False
        return True

    def _vertici_di_bordo(self, w: float, h: float) -> list[tuple[float, float]]:
        """Vertici dei contorni che stanno davvero sul bordo della forma."""
        t = self._tipo
        if t in _COMPOSTE:
            a, b = self._figli
            va = a._vertici_di_bordo(w, h)
            vb = b._vertici_di_bordo(w, h)
            if t == "unione":
                return ([v for v in va if not _dentro_stretto(b, v, w, h)]
                        + [v for v in vb if not _dentro_stretto(a, v, w, h)])
            return ([v for v in va if not _dentro_stretto(b, v, w, h)]
                    + [v for v in vb if a.contiene(v[0], v[1], w, h)])
        return [pt for c in self.contorni(w, h) for pt in c]


def _dentro_stretto(forma: Forma, v: tuple[float, float], w: float, h: float) -> bool:
    """Vero se un intorno del punto e' tutto dentro la forma (non e' sul bordo)."""
    d = 0.5
    return all(forma.contiene(v[0] + dx, v[1] + dy, w, h)
               for dx, dy in ((-d, -d), (d, -d), (d, d), (-d, d)))


# ===========================================================================
# Geometria di supporto
# ===========================================================================

def _rettangolo(w: float, h: float) -> list[tuple[float, float]]:
    return [(0.0, 0.0), (w, 0.0), (w, h), (0.0, h)]


def _ellisse(cx: float, cy: float, rx: float, ry: float, n: int, inizio: float = -math.pi / 2
             ) -> list[tuple[float, float]]:
    """``n`` punti sull'ellisse, il primo in alto, in senso orario sullo schermo."""
    return [(cx + rx * math.cos(inizio + 2 * math.pi * k / n),
             cy + ry * math.sin(inizio + 2 * math.pi * k / n)) for k in range(n)]


def _arrotondato(w: float, h: float, raggio: float) -> list[tuple[float, float]]:
    r = max(0.0, min(raggio, w / 2, h / 2))
    if r <= 0:
        return _rettangolo(w, h)
    punti: list[tuple[float, float]] = []
    # centri degli angoli, in senso orario partendo da in alto a destra
    angoli = (((w - r, r), -math.pi / 2), ((w - r, h - r), 0.0),
              ((r, h - r), math.pi / 2), ((r, r), math.pi))
    for (cx, cy), inizio in angoli:
        for k in range(SEGMENTI_ARCO + 1):
            a = inizio + (math.pi / 2) * k / SEGMENTI_ARCO
            punti.append((cx + r * math.cos(a), cy + r * math.sin(a)))
    return punti


def _stella(w: float, h: float, punte: int, profondita: float) -> list[tuple[float, float]]:
    cx, cy, rx, ry = w / 2, h / 2, w / 2, h / 2
    interno = 1.0 - profondita
    punti = []
    for k in range(2 * punte):
        a = -math.pi / 2 + math.pi * k / punte
        f = 1.0 if k % 2 == 0 else interno
        punti.append((cx + rx * f * math.cos(a), cy + ry * f * math.sin(a)))
    return punti


def _bezier(p0, c, p1, n: int) -> list[tuple[float, float]]:
    """Punti della Bezier quadratica (senza p0, con p1)."""
    out = []
    for k in range(1, n + 1):
        t = k / n
        u = 1 - t
        out.append((u * u * p0[0] + 2 * u * t * c[0] + t * t * p1[0],
                    u * u * p0[1] + 2 * u * t * c[1] + t * t * p1[1]))
    return out


def _punti_curvi(punti: list, curve: list | None) -> list[tuple[float, float]]:
    pts = [(float(p[0]), float(p[1])) for p in punti]
    if not curve:
        return pts
    out: list[tuple[float, float]] = []
    n = len(pts)
    for i in range(n):
        p0, p1 = pts[i], pts[(i + 1) % n]
        out.append(p0)
        c = curve[i]
        if c is not None:
            out.extend(_bezier(p0, (float(c[0]), float(c[1])), p1, SEGMENTI_ARCO)[:-1])
    return out


def _dentro_poligono(x: float, y: float, poligono: list[tuple[float, float]]) -> bool:
    """Regola pari-dispari (raggio orizzontale verso destra)."""
    dentro = False
    n = len(poligono)
    if n < 3:
        return False
    j = n - 1
    for i in range(n):
        xi, yi = poligono[i]
        xj, yj = poligono[j]
        if (yi > y) != (yj > y):
            xint = xi + (y - yi) * (xj - xi) / (yj - yi)
            if x < xint:
                dentro = not dentro
        j = i
    return dentro


def _pari_dispari(x: float, y: float, contorni: list[list[tuple[float, float]]]) -> bool:
    dentro = False
    for c in contorni:
        if _dentro_poligono(x, y, c):
            dentro = not dentro
    return dentro


def _campioni_bordo(x0: float, y0: float, x1: float, y1: float, passo: float) -> list[tuple[float, float]]:
    punti = [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
    nx = max(1, int(math.ceil((x1 - x0) / passo)))
    ny = max(1, int(math.ceil((y1 - y0) / passo)))
    for k in range(1, nx):
        xx = x0 + (x1 - x0) * k / nx
        punti += [(xx, y0), (xx, y1)]
    for k in range(1, ny):
        yy = y0 + (y1 - y0) * k / ny
        punti += [(x0, yy), (x1, yy)]
    return punti


# ===========================================================================
# Costruttori (usati anche dalla libreria di Leo)
# ===========================================================================

def forma_arrotondata(raggio: int = 0) -> Forma:
    """Rettangolo con gli angoli arrotondati di ``raggio`` pixel (>= 0)."""
    raggio = _intero(raggio, "raggio", "forma arrotondata")
    if raggio < 0:
        raise ErroreValore("Il raggio degli angoli non può essere negativo.",
                           suggerimento="Usa 0 per gli angoli vivi, per esempio 24 per angoli morbidi.")
    return Forma("arrotondata", {"raggio": raggio})


def forma_da_valore(valore: Any, raggio_angoli: int = 0) -> Forma:
    """Forma da un testo (``"cerchio"``...), da una :class:`Forma` o da un dizionario con ``tipo_forma``.

    Con ``"arrotondata"`` usa ``raggio_angoli`` (la proprieta' della finestra).
    """
    if isinstance(valore, Forma):
        return valore
    if isinstance(valore, str):
        nome = valore.strip().lower()
        if nome == "arrotondata":
            return forma_arrotondata(raggio_angoli)
        if nome in FORME_NOMINATE:
            return Forma(nome)
        raise ErroreValore(f"La forma `{valore}` non esiste.", suggerimento=_suggerisci_forma(nome))
    if isinstance(valore, dict) and "tipo_forma" in valore:
        return Forma.da_dizionario(valore)
    raise ErroreTipo(f"Mi aspettavo una forma o il suo nome, non `{_nome_tipo(valore)}`.",
                     suggerimento="Esempi: `\"cerchio\"`, `forma_poligono(6)`, `forma_stella(5)`.")


def forma_poligono(lati: int) -> Forma:
    """Poligono regolare con ``lati`` >= 3, inscritto nell'ellisse w x h, primo vertice in alto."""
    lati = _intero(lati, "lati", "forma_poligono")
    if lati < 3:
        raise ErroreValore(f"Un poligono ha almeno 3 lati, non {lati}.",
                           suggerimento="3 = triangolo, 4 = rombo, 6 = esagono.")
    if lati > 1000:
        raise ErroreValore(f"{lati} lati sono troppi per un poligono (al massimo 1000).",
                           suggerimento="Per una forma rotonda usa \"cerchio\" o \"ellisse\".")
    return Forma("poligono", {"lati": lati})


def forma_stella(punte: int, profondita: float = 0.5) -> Forma:
    """Stella con ``punte`` >= 3; ``profondita`` tra 0 e 1 (esclusi) dice quanto sono lunghe le punte."""
    punte = _intero(punte, "punte", "forma_stella")
    if punte < 3:
        raise ErroreValore(f"Una stella ha almeno 3 punte, non {punte}.",
                           suggerimento="Prova `forma_stella(5)`.")
    if punte > 500:
        raise ErroreValore(f"{punte} punte sono troppe per una stella (al massimo 500).")
    profondita = _numero(profondita, "profondita", "forma_stella")
    if not 0 < profondita < 1:
        raise ErroreValore(f"La profondità della stella deve stare tra 0 e 1 (esclusi), non {profondita}.",
                           suggerimento="0.5 è una stella classica; 0.2 punte corte, 0.8 punte sottili.")
    return Forma("stella", {"punte": punte, "profondita": profondita})


def _controlla_punti(punti: Any, funzione: str) -> list[list]:
    if isinstance(punti, tuple):
        punti = list(punti)
    if not isinstance(punti, list):
        raise ErroreTipo(f"`{funzione}` vuole una lista di punti `[x, y]`, non `{_nome_tipo(punti)}`.",
                         suggerimento="Esempio: `forma_punti([[0, 0], [300, 40], [150, 260]])`.")
    if len(punti) < 3:
        raise ErroreValore(f"`{funzione}` vuole almeno 3 punti, ne hai dati {len(punti)}.",
                           suggerimento="Esempio: `forma_punti([[0, 0], [300, 40], [150, 260]])`.")
    return [_punto(p, f"il punto {i}", funzione) for i, p in enumerate(punti)]


def forma_punti(punti: list) -> Forma:
    """Forma libera: almeno 3 punti ``[x, y]`` in pixel della finestra, uniti da lati dritti."""
    return Forma("punti", {"punti": _controlla_punti(punti, "forma_punti")})


def forma_punti_curvi(punti: list, controlli: list) -> Forma:
    """Forma libera con lati curvi (strumento *Penna* di Leo Studio).

    ``controlli[i]`` e' il punto di controllo ``[x, y]`` della Bezier quadratica
    del lato che va da ``punti[i]`` a ``punti[i + 1]`` (l'ultimo torna al
    primo), oppure ``nulla`` (o ``[]``) per un lato dritto. Se tutti i lati sono
    dritti la forma e' uguale a ``forma_punti(punti)``.
    """
    pts = _controlla_punti(punti, "forma_punti_curvi")
    if isinstance(controlli, tuple):
        controlli = list(controlli)
    if not isinstance(controlli, list):
        raise ErroreTipo(f"`forma_punti_curvi` vuole una lista di punti di controllo, "
                         f"non `{_nome_tipo(controlli)}`.")
    if len(controlli) != len(pts):
        raise ErroreValore(f"`forma_punti_curvi`: ci sono {len(pts)} punti ma {len(controlli)} punti di "
                           "controllo; ne serve uno per lato (anche `nulla` per un lato dritto).")
    curve: list = []
    for i, c in enumerate(controlli):
        if c is None or (isinstance(c, (list, tuple)) and len(c) == 0):
            curve.append(None)
        else:
            curve.append(_punto(c, f"il punto di controllo {i}", "forma_punti_curvi"))
    if all(c is None for c in curve):
        return Forma("punti", {"punti": pts})
    return Forma("punti", {"punti": pts, "curve": curve})


def forma_immagine(percorso: str) -> Forma:
    """Forma ricavata da un PNG: le parti trasparenti restano fuori dalla finestra.

    Il percorso e' relativo alla cartella del progetto. In puro Python l'immagine
    non si legge: i contorni sono il rettangolo intero (il ritaglio vero lo fa Qt).
    """
    if not isinstance(percorso, str):
        raise ErroreTipo(f"`forma_immagine` vuole il percorso di un'immagine (testo), non `{_nome_tipo(percorso)}`.")
    if not percorso.strip():
        raise ErroreValore("`forma_immagine` vuole il percorso di un'immagine, non un testo vuoto.",
                           suggerimento="Esempio: `forma_immagine(\"gatto.png\")`; le parti trasparenti restano fuori.")
    return Forma("immagine", {"percorso": percorso})


def _operando(v: Any, funzione: str) -> Forma:
    if isinstance(v, (Forma, str)) or (isinstance(v, dict) and "tipo_forma" in v):
        return forma_da_valore(v)
    raise ErroreTipo(f"`{funzione}` vuole due forme (o nomi di forme), non `{_nome_tipo(v)}`.",
                     suggerimento="Esempio: `forma_sottrai(\"cerchio\", forma_poligono(6))`.")


def forma_unisci(a: Any, b: Any) -> Forma:
    """Unione: dentro se il punto e' in ``a`` oppure in ``b``."""
    return Forma("unione", {}, (_operando(a, "forma_unisci"), _operando(b, "forma_unisci")))


def forma_sottrai(a: Any, b: Any) -> Forma:
    """Sottrazione: dentro se il punto e' in ``a`` ma non in ``b`` (per esempio una ciambella)."""
    return Forma("sottrazione", {}, (_operando(a, "forma_sottrai"), _operando(b, "forma_sottrai")))


__all__ = ["Forma", "TIPI_FORMA", "FORME_NOMINATE", "SEGMENTI_CURVA", "forma_da_valore", "forma_arrotondata",
           "forma_poligono", "forma_stella", "forma_punti", "forma_punti_curvi", "forma_immagine",
           "forma_unisci", "forma_sottrai"]
