"""Colori: nomi italiani, esadecimali ``#RRGGBB[AA]``, contrasto WCAG e sfumature.

Nessuna dipendenza da Qt. API (docs/CONTRATTI.md §13.4)::

    COLORI_NOMINATI: dict[str, str]                 # "rosso" -> "#FF0000", "trasparente" -> "#00000000"
    normalizza_colore(valore) -> str                # "" -> ""; "#abc" -> "#AABBCC"; nome -> esadecimale
    da_esadecimale(colore) -> (r, g, b, a)
    a_esadecimale(r, g, b, a=255) -> str            # "#RRGGBB" se a == 255, altrimenti "#RRGGBBAA"
    luminanza(colore) -> float                      # luminanza relativa WCAG 2.x (0..1)
    rapporto_contrasto(c1, c2) -> float             # WCAG 2.x (1..21)
    mescola(c1, c2, t) -> str                       # t = 0 -> c1, t = 1 -> c2

In piu' (piano.json, note_generali)::

    analizza_sfumatura(testo) -> dict | None        # "sfumatura: #0B0B0D, #E0182D[, angolo]"
    normalizza_sfumatura(testo) -> str              # forma canonica di una sfumatura
    normalizza_sfondo(valore) -> str                # colore, sfumatura, "immagine: x.png", "motivo: x.png"

I nomi si riconoscono senza badare a maiuscole, accenti e spazi: ``"Verde
chiaro"``, ``"verde_chiaro"`` e ``"verde-chiaro"`` sono lo stesso colore.
"""

from __future__ import annotations

import difflib
import math
import re
import unicodedata
from typing import Any

from ..errori import ErroreTipo, ErroreValore

# ---------------------------------------------------------------------------
# Nomi italiani
# ---------------------------------------------------------------------------

COLORI_NOMINATI: dict[str, str] = {
    # fondamentali
    "nero": "#000000",
    "bianco": "#FFFFFF",
    "rosso": "#FF0000",
    "verde": "#008000",
    "blu": "#0000FF",
    "giallo": "#FFFF00",
    "arancione": "#FFA500",
    "viola": "#800080",
    "rosa": "#FFC0CB",
    "marrone": "#8B4513",
    "grigio": "#808080",
    "azzurro": "#1E90FF",
    "celeste": "#87CEEB",
    "ciano": "#00FFFF",
    "magenta": "#FF00FF",
    # sfumature
    "grigio_chiaro": "#D3D3D3",
    "grigio_scuro": "#404040",
    "rosso_scuro": "#8B0000",
    "verde_chiaro": "#90EE90",
    "verde_scuro": "#006400",
    "verde_oliva": "#808000",
    "verde_acqua": "#20B2AA",
    "verde_prato": "#7CFC00",
    "blu_scuro": "#00008B",
    "blu_notte": "#191970",
    "blu_marino": "#000080",
    "giallo_chiaro": "#FFFFE0",
    # altri nomi comuni
    "oro": "#FFD700",
    "argento": "#C0C0C0",
    "beige": "#F5F5DC",
    "bordeaux": "#800020",
    "turchese": "#40E0D0",
    "indaco": "#4B0082",
    "lilla": "#C8A2C8",
    "lavanda": "#E6E6FA",
    "corallo": "#FF7F50",
    "salmone": "#FA8072",
    "pesca": "#FFDAB9",
    "crema": "#FFFDD0",
    "avorio": "#FFFFF0",
    "sabbia": "#C2B280",
    "cioccolato": "#D2691E",
    "fucsia": "#FF00FF",
    "porpora": "#9F1D35",
    "senape": "#FFDB58",
    "smeraldo": "#50C878",
    "menta": "#98FF98",
    "ocra": "#CC7722",
    "terracotta": "#E2725B",
    "tortora": "#B9A99A",
    "antracite": "#293133",
    "cremisi": "#DC143C",
    "vinaccia": "#6D0F2F",
    "grafite": "#131316",
    "ciano_elettrico": "#3DD6F5",     # nome storico: resta valido nei programmi vecchi
    # i colori del tema di Leo (stessi codici di leo.studio.tavolozza.COLORI_TEMA:
    # la casella "Codice" della tavolozza suggerisce "tema_rosso" & co.)
    "tema_nero": "#0B0B0D",
    "tema_grafite": "#131316",
    "tema_rosso": "#E0182D",
    "tema_rosso_chiaro": "#FF3B4E",
    "tema_ambra": "#FFB020",
    "tema_arancio": "#FF7A1A",
    "tema_grigio": "#9C9CA6",
    "tema_bianco": "#ECECEF",
    # speciale
    "trasparente": "#00000000",
}

_ESADECIMALE = re.compile(r"^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{4}|[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})$")


def _chiave_nome(testo: str) -> str:
    """Forma di confronto di un nome: minuscolo, senza accenti, parole unite da ``_``."""
    senza_accenti = "".join(c for c in unicodedata.normalize("NFD", testo)
                            if unicodedata.category(c) != "Mn")
    return re.sub(r"[\s_\-']+", "_", senza_accenti.strip().lower()).strip("_")


_INDICE_NOMI: dict[str, str] = {_chiave_nome(n): v for n, v in COLORI_NOMINATI.items()}


def _esempi() -> str:
    return "\"rosso\", \"#FF0000\" o \"#F00\""


def normalizza_colore(valore: str) -> str:
    """Colore in forma canonica maiuscola ``#RRGGBB`` o ``#RRGGBBAA``.

    ``""`` resta ``""`` (= colore predefinito). Accetta ``#RGB``, ``#RGBA``,
    ``#RRGGBB``, ``#RRGGBBAA`` e i nomi di :data:`COLORI_NOMINATI`.
    Un valore non valido produce ``ErroreValore`` con un suggerimento.
    """
    if not isinstance(valore, str):
        from ..valori import nome_tipo

        raise ErroreTipo(f"Un colore si scrive come testo (es. {_esempi()}), non come `{nome_tipo(valore)}`.")
    testo = valore.strip()
    if testo == "":
        return ""
    if testo.startswith("#"):
        if not _ESADECIMALE.match(testo):
            raise ErroreValore(
                f"Il colore `{valore}` non è scritto bene.",
                suggerimento="Dopo `#` servono 3 o 6 cifre esadecimali (0-9, A-F), "
                             "più eventualmente 1 o 2 per la trasparenza: per esempio \"#FF8800\".")
        cifre = testo[1:].upper()
        if len(cifre) in (3, 4):
            cifre = "".join(c * 2 for c in cifre)
        return "#" + cifre
    chiave = _chiave_nome(testo)
    if chiave in _INDICE_NOMI:
        return _INDICE_NOMI[chiave]
    if re.fullmatch(r"[0-9A-Fa-f]{6}([0-9A-Fa-f]{2})?", testo):
        raise ErroreValore(f"Il colore `{valore}` non è scritto bene.",
                           suggerimento=f"Forse intendevi \"#{testo.upper()}\"? I colori esadecimali iniziano con `#`.")
    vicini = difflib.get_close_matches(chiave, list(COLORI_NOMINATI), n=1, cutoff=0.6)
    if vicini:
        suggerimento = f"Forse intendevi \"{vicini[0]}\"?"
    else:
        suggerimento = (f"Scrivi un colore come {_esempi()}. Alcuni nomi: "
                        + ", ".join(f"\"{n}\"" for n in ("rosso", "verde", "blu", "giallo", "arancione",
                                                         "viola", "grigio", "azzurro")) + ".")
    raise ErroreValore(f"Non conosco il colore `{valore}`.", suggerimento=suggerimento)


def da_esadecimale(colore: str) -> tuple[int, int, int, int]:
    """``"#FF8800"`` (o un nome) -> ``(255, 136, 0, 255)``. ``""`` non e' un colore: ErroreValore."""
    c = normalizza_colore(colore)
    if c == "":
        raise ErroreValore("Il colore vuoto (\"\") indica il colore predefinito e non ha un valore RGB.")
    cifre = c[1:]
    r, g, b = (int(cifre[i:i + 2], 16) for i in (0, 2, 4))
    a = int(cifre[6:8], 16) if len(cifre) == 8 else 255
    return r, g, b, a


def _componente(v: Any, nome: str) -> int:
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        raise ErroreTipo(f"La componente `{nome}` di un colore deve essere un numero da 0 a 255.")
    if isinstance(v, float) and math.isnan(v):
        raise ErroreValore(f"La componente `{nome}` di un colore non è un numero.")
    return max(0, min(255, int(round(v))))


def a_esadecimale(r: int, g: int, b: int, a: int = 255) -> str:
    """Componenti 0-255 (arrotondate e limitate) -> ``"#RRGGBB"`` o ``"#RRGGBBAA"``."""
    r, g, b, a = (_componente(v, n) for v, n in ((r, "rosso"), (g, "verde"), (b, "blu"), (a, "trasparenza")))
    testo = f"#{r:02X}{g:02X}{b:02X}"
    if a != 255:
        testo += f"{a:02X}"
    return testo


def _lineare(c: int) -> float:
    s = c / 255.0
    return s / 12.92 if s <= 0.04045 else ((s + 0.055) / 1.055) ** 2.4


def luminanza(colore: str) -> float:
    """Luminanza relativa WCAG 2.x (0 = nero, 1 = bianco); la trasparenza e' ignorata."""
    r, g, b, _ = da_esadecimale(colore)
    return 0.2126 * _lineare(r) + 0.7152 * _lineare(g) + 0.0722 * _lineare(b)


def rapporto_contrasto(c1: str, c2: str) -> float:
    """Rapporto di contrasto WCAG 2.x tra due colori (da 1 a 21; AA richiede 4,5)."""
    l1, l2 = luminanza(c1), luminanza(c2)
    chiaro, scuro = max(l1, l2), min(l1, l2)
    return (chiaro + 0.05) / (scuro + 0.05)


def mescola(c1: str, c2: str, t: float) -> str:
    """Colore intermedio: ``t = 0`` -> ``c1``, ``t = 1`` -> ``c2`` (t limitato a 0..1)."""
    if isinstance(t, bool) or not isinstance(t, (int, float)):
        raise ErroreTipo("La proporzione di `mescola` deve essere un numero da 0 a 1.")
    t = max(0.0, min(1.0, float(t)))
    a = da_esadecimale(c1)
    b = da_esadecimale(c2)
    return a_esadecimale(*(x + (y - x) * t for x, y in zip(a, b)))


# ---------------------------------------------------------------------------
# Sfumature e sfondi
# ---------------------------------------------------------------------------

_PREFISSO_SFUMATURA = re.compile(r"^\s*sfumatura\b\s*:?\s*", re.IGNORECASE)
# "sfumatura radiale: ...", "sfumatura orizzontale: ...", "sfumatura lineare verticale: ..."
_PREFISSO_SFUMATURA_PAROLE = re.compile(r"^\s*sfumatura\b(?P<parole>[\s\w]*?)\s*:\s*", re.IGNORECASE)
_ANGOLO = re.compile(r"^(?:angolo\s*:?\s*)?(-?\d+(?:[.,]\d+)?)\s*(?:°|gradi)?$", re.IGNORECASE)
_DIREZIONI = {"verticale": 90.0, "orizzontale": 0.0, "diagonale": 45.0, "diagonale_inversa": 135.0}
_FORME_SFUMATURA = ("lineare", "radiale")


def _numero_angolo(testo: str) -> float | None:
    m = _ANGOLO.match(testo.strip())
    if not m:
        return None
    return float(m.group(1).replace(",", "."))


def analizza_sfumatura(testo: str) -> dict | None:
    """Analizza uno sfondo a sfumatura lineare.

    Formato: ``"sfumatura: COLORE, COLORE[, ...][, ANGOLO]"``. Senza angolo la
    sfumatura e' verticale (dall'alto in basso). L'angolo e' in gradi, in senso
    orario a partire da destra: 0 = da sinistra a destra, 90 = dall'alto in
    basso, 45 = in diagonale verso il basso a destra; al posto del numero si puo'
    scrivere ``verticale``, ``orizzontale``, ``diagonale`` o ``diagonale_inversa``.

    Prima dei due punti si possono scrivere anche la forma e la direzione:
    ``"sfumatura radiale: bianco, azzurro"`` (dal centro verso i bordi: il
    risultato ha ``"tipo": "radiale"``, ``"centro": (0.5, 0.5)`` e
    ``"raggio": 0.5``), ``"sfumatura orizzontale: rosso, giallo"``.

    Restituisce ``None`` se il testo non e' una sfumatura, altrimenti::

        {"tipo": "lineare", "colori": ["#0B0B0D", "#E0182D"], "angolo": 90.0,
         "fermate": [(0.0, "#0B0B0D"), (1.0, "#E0182D")],
         "inizio": (0.5, 0.0), "fine": (0.5, 1.0)}

    ``inizio``/``fine`` sono in frazioni del rettangolo (0..1), pronti per un
    gradiente lineare. Una sfumatura scritta male produce ``ErroreValore``.
    """
    if not isinstance(testo, str):
        return None
    forma = "lineare"
    angolo = 90.0
    m = _PREFISSO_SFUMATURA_PAROLE.match(testo)
    if m and m.group("parole").strip():
        for parola in m.group("parole").split():
            chiave = _chiave_nome(parola)
            if chiave in _FORME_SFUMATURA:
                forma = chiave
            elif chiave in _DIREZIONI:
                angolo = _DIREZIONI[chiave]
            else:
                raise ErroreValore(f"Nella sfumatura non capisco `{parola}`.",
                                   suggerimento="Esempi: \"sfumatura: #0B0B0D, #E0182D\", "
                                                "\"sfumatura orizzontale: rosso, giallo\", "
                                                "\"sfumatura radiale: bianco, azzurro\".")
    else:
        m = _PREFISSO_SFUMATURA.match(testo)
        if not m:
            return None
    parti = [p.strip() for p in testo[m.end():].split(",")]
    parti = [p for p in parti if p]
    if parti:
        ultimo = parti[-1]
        valore_angolo = _numero_angolo(ultimo)
        if valore_angolo is None and _chiave_nome(ultimo) in _DIREZIONI:
            valore_angolo = _DIREZIONI[_chiave_nome(ultimo)]
        if valore_angolo is not None:
            angolo = valore_angolo % 360.0
            parti = parti[:-1]
    if len(parti) < 2:
        raise ErroreValore(f"La sfumatura `{testo.strip()}` ha bisogno di almeno due colori.",
                           suggerimento="Esempio: \"sfumatura: #0B0B0D, #E0182D\" oppure "
                                        "\"sfumatura: blu, azzurro, 0\" (0 = orizzontale).")
    colori = []
    for p in parti:
        c = normalizza_colore(p)
        if c == "":  # pragma: no cover - le parti vuote sono gia' state tolte
            continue
        colori.append(c)
    n = len(colori)
    fermate = [(round(i / (n - 1), 6), c) for i, c in enumerate(colori)]
    rad = math.radians(angolo)
    dx, dy = math.cos(rad) / 2.0, math.sin(rad) / 2.0

    def _pulito(v: float) -> float:
        v = round(v, 6)
        return 0.0 if v == 0 else v

    if forma == "radiale":
        return {
            "tipo": "radiale",
            "colori": colori,
            "angolo": angolo,
            "fermate": fermate,
            "centro": (0.5, 0.5),
            "raggio": 0.5,
        }
    return {
        "tipo": "lineare",
        "colori": colori,
        "angolo": angolo,
        "fermate": fermate,
        "inizio": (_pulito(0.5 - dx), _pulito(0.5 - dy)),
        "fine": (_pulito(0.5 + dx), _pulito(0.5 + dy)),
    }


def normalizza_sfumatura(testo: str) -> str:
    """Forma canonica di una sfumatura: ``"sfumatura: #AABBCC, #DDEEFF"`` (+ ``", ANGOLO"`` se non 90);
    ``"sfumatura radiale: #AABBCC, #DDEEFF"`` per quella radiale."""
    s = analizza_sfumatura(testo)
    if s is None:
        raise ErroreValore(f"`{testo}` non è una sfumatura.",
                           suggerimento="Esempio: \"sfumatura: #0B0B0D, #E0182D\".")
    if s["tipo"] == "radiale":
        return "sfumatura radiale: " + ", ".join(s["colori"])
    risultato = "sfumatura: " + ", ".join(s["colori"])
    if s["angolo"] != 90.0:
        angolo = s["angolo"]
        risultato += f", {int(angolo) if float(angolo).is_integer() else angolo:g}"
    return risultato


def _sfondo_dal_runtime(valore: str) -> str | None:
    """Forma canonica ricavata da ``temi_controlli.analizza_sfondo`` (None se il modulo manca).

    Cosi' la proprieta' ``sfondo`` accetta esattamente cio' che la finestra sa
    disegnare, e un motivo sbagliato si segnala gia' quando lo si scrive.
    """
    try:
        from .temi_controlli import analizza_sfondo
    except (ImportError, AttributeError):  # pragma: no cover - modulo sempre presente
        return None
    d = analizza_sfondo(valore)  # ErroreValore/ErroreTipo in italiano
    tipo = d.get("tipo")
    if tipo == "nessuno":
        return ""
    if tipo == "colore":
        return str(d["colore"])
    if tipo == "immagine":
        modo = d.get("modo", "riempi")
        return f"immagine: {d['percorso']}" + (f", {modo}" if modo and modo != "riempi" else "")
    if tipo == "motivo":
        if "percorso" in d:
            return f"motivo: {d['percorso']}"
        testo = f"motivo: {d['motivo']}"
        colore, fondo = d.get("colore", ""), d.get("sfondo", "")
        if fondo:
            return f"{testo}, {colore}, {fondo}"
        if colore and colore != "#00000040":
            return f"{testo}, {colore}"
        return testo
    return None


_PREFISSO_IMMAGINE = re.compile(r"^\s*(immagine|motivo)\s*:\s*(.*)$", re.IGNORECASE | re.DOTALL)


def normalizza_sfondo(valore: str) -> str:
    """Valore dello ``sfondo`` di una finestra in forma canonica.

    Accetta ``""``, un colore, una sfumatura (:func:`analizza_sfumatura`, anche
    ``"sfumatura radiale: ..."`` e ``"sfumatura orizzontale: ..."``),
    ``"immagine: percorso[, riempi|adatta|estendi|centra]"``, un percorso di
    immagine da solo (``"sfondo.png"``), ``"motivo: percorso"`` (immagine
    ripetuta) e i motivi disegnati (``"motivo: puntini[, colore[, fondo]]"``):
    gli stessi formati che il runtime capisce (``temi_controlli.analizza_sfondo``).
    """
    if not isinstance(valore, str):
        from ..valori import nome_tipo

        raise ErroreTipo(f"Lo sfondo si scrive come testo (un colore, una sfumatura o un'immagine), "
                         f"non come `{nome_tipo(valore)}`.")
    if analizza_sfumatura(valore) is not None:
        return normalizza_sfumatura(valore)
    canonico = _sfondo_dal_runtime(valore)
    if canonico is not None:
        return canonico
    m = _PREFISSO_IMMAGINE.match(valore)
    if m:
        percorso = m.group(2).strip()
        if not percorso:
            raise ErroreValore(f"Nello sfondo `{valore.strip()}` manca il percorso dell'immagine.",
                               suggerimento="Esempio: \"immagine: sfondo.png\" o \"motivo: mattonella.png\".")
        return f"{m.group(1).lower()}: {percorso}"
    return normalizza_colore(valore)


__all__ = ["COLORI_NOMINATI", "normalizza_colore", "da_esadecimale", "a_esadecimale", "luminanza",
           "rapporto_contrasto", "mescola", "analizza_sfumatura", "normalizza_sfumatura", "normalizza_sfondo"]
