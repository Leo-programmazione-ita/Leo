"""Catalogo dei 40 controlli classici di Leo (la casella "alla Visual Basic").

Tabella di riferimento: docs/PROGETTO.md, "Controlli disponibili"; proprieta'
della versione 1 in docs/CONTRATTI.md §13.1; versioni 2 e 3 nella tabella di
piano.json (note_generali).

* :func:`tipi` costruisce ogni volta oggetti :class:`TipoControllo` nuovi
  (i test li contano senza toccare ``metadati.CATALOGO``);
* importando il modulo, ogni tipo viene registrato con ``metadati.registra``
  (che aggiunge nome, posizione, colori, carattere e l'evento ``clic``).

I metodi sono funzioni ``f(controllo_vivo, *argomenti)``: controllano gli
argomenti, aggiornano ``controllo.modello.proprieta`` e avvisano gli osservatori
con ``controllo.avvisa(proprieta, valore)``. Quelli che hanno bisogno del widget
vero (finestre di dialogo, suoni, appunti...) passano da
:func:`leo.grafica.azioni.richiedi_interfaccia`, con il nome del metodo come
nome dell'azione.

Proprieta' in piu' rispetto alle tabelle (per lo strato Qt):
    ``Tela.disegni`` (lista, sola lettura): i comandi di disegno eseguiti, come
    dizionari ``{"figura": "linea"|"rettangolo"|"cerchio"|"testo", ...}``;
    ``VoceMenu.abilitato`` / ``VoceMenu.visibile`` (logici, vero).
``Finestra.sfondo`` accetta, oltre ai colori, ``"sfumatura: #0B0B0D, #E0182D[, angolo]"``,
``"immagine: file.png"`` e ``"motivo: file.png"`` (vedi ``colori.normalizza_sfondo``).
"""

from __future__ import annotations

import copy
import datetime
import inspect
import re
from typing import Any, Callable

from ..errori import ErroreIndice, ErroreTipo, ErroreValore
from ..valori import e_intero, e_numero, nome_tipo, rappresenta
from . import azioni
from .metadati import Proprieta, TipoControllo, registra

#: Schede della casella dei controlli, nell'ordine di PROGETTO.md.
SCHEDE = ("Base", "Inserimento", "Scelta", "Contenitori", "Visualizzazione", "Dati", "Disegno",
          "Media", "Menu", "Invisibili")

_NESSUNA_INTERFACCIA = object()


# ===========================================================================
# Proprieta' con controlli speciali
# ===========================================================================

class ProprietaSfondo(Proprieta):
    """Proprieta' di tipo ``colore`` che accetta anche sfumature e immagini (``Finestra.sfondo``)."""

    def converti(self, valore: Any) -> Any:
        from .colori import normalizza_sfondo

        return normalizza_sfondo(valore)


_FORMATO_DATA = re.compile(r"^\s*(\d{1,2})/(\d{1,2})/(\d{4})\s*$")


def normalizza_data(valore: Any, nome: str = "data") -> str:
    """``""`` oppure una data vera ``GG/MM/AAAA`` (restituita con due cifre per giorno e mese)."""
    if not isinstance(valore, str):
        raise ErroreTipo(f"La proprietà `{nome}` vuole una data come testo \"GG/MM/AAAA\", "
                         f"non `{nome_tipo(valore)}`.")
    if valore.strip() == "":
        return ""
    m = _FORMATO_DATA.match(valore)
    if not m:
        raise ErroreValore(f"`{valore}` non è una data scritta come GG/MM/AAAA.",
                           suggerimento="Esempio: \"25/12/2026\".")
    giorno, mese, anno = (int(g) for g in m.groups())
    try:
        datetime.date(anno, mese, giorno)
    except ValueError:
        raise ErroreValore(f"La data `{valore}` non esiste nel calendario.") from None
    return f"{giorno:02d}/{mese:02d}/{anno:04d}"


class ProprietaData(Proprieta):
    """Proprieta' di tipo ``testo`` che contiene una data ``GG/MM/AAAA`` (o ``""``)."""

    def converti(self, valore: Any) -> Any:
        return normalizza_data(valore, self.nome)


# ===========================================================================
# Aiuti per costruire il catalogo
# ===========================================================================

def _p(nome: str, tipo: str, predefinito: Any, gruppo: str = "Aspetto", descrizione: str = "",
       *, scelte: tuple[str, ...] | list[str] = (), minimo: float | None = None,
       massimo: float | None = None, sola_lettura: bool = False, classe: type = Proprieta) -> Proprieta:
    return classe(nome, tipo, predefinito, gruppo, descrizione, tuple(scelte), minimo, massimo, sola_lettura)


def _scelta(nome: str, scelte: tuple[str, ...], gruppo: str = "Aspetto", descrizione: str = "",
            predefinito: str | None = None) -> Proprieta:
    return _p(nome, "scelta", scelte[0] if predefinito is None else predefinito, gruppo, descrizione,
              scelte=scelte)


def _tipo(nome: str, scheda: str, descrizione: str, versione: int, proprieta: list[Proprieta],
          eventi: tuple[str, ...], evento_predefinito: str | None, *, dimensione: tuple[int, int] = (100, 30),
          icona: str = "", invisibile: bool = False, contenitore: bool = False,
          metodi: dict[str, Callable[..., Any]] | None = None, prefisso: str | None = None) -> TipoControllo:
    return TipoControllo(
        nome=nome, scheda=scheda, descrizione=descrizione, versione=versione,
        proprieta={p.nome: p for p in proprieta}, eventi=tuple(eventi), evento_predefinito=evento_predefinito,
        invisibile=invisibile, contenitore=contenitore, dimensione_predefinita=dimensione, icona=icona,
        metodi=dict(metodi or {}), prefisso_nome=nome if prefisso is None else prefisso,
    )


# ===========================================================================
# Aiuti per i metodi
# ===========================================================================

def _metodo(nome: str, funzione: Callable[..., Any]) -> Callable[..., Any]:
    """Avvolge ``funzione(controllo, ...)`` controllando il numero di argomenti.

    ``FunzioneNativa`` conterebbe anche il controllo tra gli argomenti; qui il
    messaggio parla solo di quelli scritti dall'utente.
    """
    firma = inspect.signature(funzione)
    parametri = list(firma.parameters.values())[1:]
    obbligatori = [p.name for p in parametri if p.default is p.empty]

    def metodo(controllo: Any, *argomenti: Any, **per_nome: Any) -> Any:
        try:
            firma.bind(controllo, *argomenti, **per_nome)
        except TypeError:
            chi = f"{getattr(controllo, 'nome', '?')}.{nome}"
            if len(obbligatori) == len(parametri):
                attesi = {0: "nessun argomento", 1: "1 argomento"}.get(len(parametri), f"{len(parametri)} argomenti")
            else:
                attesi = f"da {len(obbligatori)} a {len(parametri)} argomenti"
            ricevuti = len(argomenti) + len(per_nome)
            elenco = ", ".join(f"`{p.name}`" for p in parametri)
            raise ErroreTipo(f"`{chi}` vuole {attesi}, ma ne ha ricevuti {ricevuti}.",
                             suggerimento=f"Si scrive `{chi}({', '.join(p.name for p in parametri)})`."
                             if elenco else f"Si scrive `{chi}()`, senza argomenti.") from None
        return funzione(controllo, *argomenti, **per_nome)

    metodo.__name__ = nome
    metodo.__qualname__ = nome
    metodo.__doc__ = funzione.__doc__
    return metodo


def _metodi(**funzioni: Callable[..., Any]) -> dict[str, Callable[..., Any]]:
    return {nome: _metodo(nome, f) for nome, f in funzioni.items()}


def _chi(c: Any, metodo: str) -> str:
    return f"`{getattr(c, 'nome', '?')}.{metodo}`"


def _intero(c: Any, metodo: str, parametro: str, v: Any, minimo: int | None = None) -> int:
    if isinstance(v, float) and v.is_integer():
        v = int(v)
    if not e_intero(v):
        raise ErroreTipo(f"{_chi(c, metodo)}: `{parametro}` deve essere un intero, non `{nome_tipo(v)}`.")
    if minimo is not None and v < minimo:
        raise ErroreValore(f"{_chi(c, metodo)}: `{parametro}` non può essere minore di {minimo}.")
    return v


def _numero(c: Any, metodo: str, parametro: str, v: Any) -> int | float:
    if not e_numero(v):
        raise ErroreTipo(f"{_chi(c, metodo)}: `{parametro}` deve essere un numero, non `{nome_tipo(v)}`.")
    return v


def _testo(c: Any, metodo: str, parametro: str, v: Any) -> str:
    if not isinstance(v, str):
        raise ErroreTipo(f"{_chi(c, metodo)}: `{parametro}` deve essere un testo, non `{nome_tipo(v)}`.",
                         suggerimento="Per convertire usa `testo(...)`.")
    return v


def _logico(c: Any, metodo: str, parametro: str, v: Any) -> bool:
    if not isinstance(v, bool):
        raise ErroreTipo(f"{_chi(c, metodo)}: `{parametro}` deve essere `vero` o `falso`, non `{nome_tipo(v)}`.")
    return v


def _indice(c: Any, metodo: str, parametro: str, v: Any, lunghezza: int, cosa: str) -> int:
    i = _intero(c, metodo, parametro, v)
    if not 0 <= i < lunghezza:
        if lunghezza == 0:
            raise ErroreIndice(f"{_chi(c, metodo)}: {cosa} è vuoto, non c'è la posizione {i}.")
        raise ErroreIndice(f"{_chi(c, metodo)}: la posizione {i} non esiste.",
                           suggerimento=f"Le posizioni vanno da 0 a {lunghezza - 1}.")
    return i


def _prop(c: Any, nome: str, predefinito: Any = None) -> Any:
    return c.modello.proprieta.get(nome, predefinito)


def _imposta(c: Any, nome: str, valore: Any) -> None:
    """Aggiorna il modello e avvisa lo strato grafico."""
    c.modello.proprieta[nome] = valore
    c.avvisa(nome, valore)


def _lista(c: Any, nome: str) -> list:
    v = _prop(c, nome)
    return list(v) if isinstance(v, list) else []


# ===========================================================================
# Metodi: CasellaTesto, AreaTesto
# ===========================================================================

def _seleziona_tutto(c):
    """Seleziona tutto il testo della casella."""
    azioni.richiedi_interfaccia(c, "seleziona_tutto")


def _aggiungi_riga(c, riga):
    """Aggiunge una riga in fondo al testo (numeri e altri valori vengono scritti come testo)."""
    t = riga if isinstance(riga, str) else rappresenta(riga)
    attuale = _prop(c, "testo", "") or ""
    _imposta(c, "testo", f"{attuale}\n{t}" if attuale else t)


# ===========================================================================
# Metodi: Elenco, MenuATendina
# ===========================================================================

def _aggiorna_selezione(c, elementi: list, indice: int) -> None:
    c.modello.proprieta["selezione"] = elementi[indice] if 0 <= indice < len(elementi) else None
    if _prop(c, "indice_selezionato", -1) != indice:
        _imposta(c, "indice_selezionato", indice)


def _elenco_aggiungi(c, elemento):
    """Aggiunge un elemento in fondo all'elenco."""
    elementi = _lista(c, "elementi")
    elementi.append(elemento)
    _imposta(c, "elementi", elementi)


def _elenco_rimuovi(c, indice):
    """Toglie l'elemento alla posizione `indice` (da 0) e lo restituisce."""
    elementi = _lista(c, "elementi")
    i = _indice(c, "rimuovi", "indice", indice, len(elementi), "l'elenco")
    tolto = elementi.pop(i)
    _imposta(c, "elementi", elementi)
    sel = _prop(c, "indice_selezionato", -1)
    if not e_intero(sel):
        sel = -1
    if sel == i:
        sel = -1
    elif sel > i:
        sel -= 1
    _aggiorna_selezione(c, elementi, sel)
    return tolto


def _elenco_svuota(c):
    """Toglie tutti gli elementi."""
    _imposta(c, "elementi", [])
    _aggiorna_selezione(c, [], -1)


_METODI_ELENCO = dict(aggiungi=_elenco_aggiungi, rimuovi=_elenco_rimuovi, svuota=_elenco_svuota)


# ===========================================================================
# Metodi: Timer, Interruttore, Collegamento, PannelloScorrevole
# ===========================================================================

def _timer_avvia(c):
    """Fa ripartire il timer."""
    _imposta(c, "attivo", True)


def _timer_ferma(c):
    """Ferma il timer."""
    _imposta(c, "attivo", False)


def _commuta(c):
    """Accende l'interruttore se e' spento, e viceversa."""
    _imposta(c, "acceso", not bool(_prop(c, "acceso", False)))


def _collegamento_apri(c):
    """Apre l'indirizzo nel browser."""
    indirizzo = _prop(c, "indirizzo", "") or ""
    if not indirizzo.strip():
        raise ErroreValore(f"{_chi(c, 'apri')}: prima imposta `indirizzo`.",
                           suggerimento=f"Esempio: `{getattr(c, 'nome', 'Collegamento1')}.indirizzo = \"https://www.example.org\"`.")
    risultato = azioni.richiedi_interfaccia(c, "apri", indirizzo, predefinito=_NESSUNA_INTERFACCIA)
    if risultato is _NESSUNA_INTERFACCIA:
        import webbrowser

        try:
            aperto = webbrowser.open(indirizzo)
        except Exception:  # noqa: BLE001
            aperto = False
        if not aperto:
            raise azioni.errore_non_disponibile(f"Aprire `{indirizzo}` nel browser")
    _imposta(c, "visitato", True)


def _scorri_a(c, x, y):
    """Scorre il contenuto fino al punto (x, y), in pixel."""
    x = _intero(c, "scorri_a", "x", x, 0)
    y = _intero(c, "scorri_a", "y", y, 0)
    _imposta(c, "scorrimento_x", x)
    _imposta(c, "scorrimento_y", y)


# ===========================================================================
# Metodi: SelettoreColore, BarraStato, Suggerimento
# ===========================================================================

def _scegli_colore(c):
    """Apre la finestra dei colori; restituisce il colore scelto o `nulla` se si annulla."""
    risultato = azioni.richiedi_interfaccia(c, "scegli", predefinito=None)
    if not isinstance(risultato, str) or not risultato:
        return None
    from .colori import normalizza_colore

    colore = normalizza_colore(risultato)
    _imposta(c, "colore", colore)
    return colore


def _mostra_messaggio(c, testo, millisecondi=0):
    """Mostra un messaggio temporaneo nella barra (0 millisecondi = finche' non ne arriva un altro)."""
    t = testo if isinstance(testo, str) else rappresenta(testo)
    ms = _intero(c, "mostra_messaggio", "millisecondi", millisecondi, 0)
    azioni.richiedi_interfaccia(c, "mostra_messaggio", t, ms)


def _suggerimento_mostra(c, controllo, testo):
    """Mostra subito il suggerimento `testo` vicino a `controllo` (un controllo o il suo nome)."""
    if isinstance(controllo, str):
        nome = controllo
    elif hasattr(controllo, "tipo_controllo") and hasattr(controllo, "nome"):
        nome = controllo.nome
    else:
        raise ErroreTipo(f"{_chi(c, 'mostra')}: `controllo` deve essere un controllo o il suo nome, "
                         f"non `{nome_tipo(controllo)}`.")
    t = testo if isinstance(testo, str) else rappresenta(testo)
    azioni.richiedi_interfaccia(c, "mostra", nome, t)


# ===========================================================================
# Metodi: Tabella
# ===========================================================================

def _colonna(c, metodo: str, colonna: Any) -> int:
    colonne = _lista(c, "colonne")
    if isinstance(colonna, str):
        if colonna in colonne:
            return colonne.index(colonna)
        raise ErroreValore(f"{_chi(c, metodo)}: la colonna `{colonna}` non esiste.",
                           suggerimento="Colonne: " + ", ".join(f"\"{rappresenta(k)}\"" for k in colonne) + "."
                           if colonne else "La tabella non ha colonne.")
    return _indice(c, metodo, "colonna", colonna, len(colonne), "la tabella (senza colonne)")


def _righe(c) -> list[list]:
    return [list(r) if isinstance(r, list) else [r] for r in _lista(c, "righe")]


def _aggiungi_riga_tabella(c, valori):
    """Aggiunge una riga (una lista di valori, uno per colonna)."""
    if not isinstance(valori, list):
        raise ErroreTipo(f"{_chi(c, 'aggiungi_riga')}: la riga deve essere una lista, non `{nome_tipo(valori)}`.",
                         suggerimento="Esempio: `Tabella1.aggiungi_riga([\"Anna\", 8])`.")
    n = len(_lista(c, "colonne"))
    if n and len(valori) > n:
        raise ErroreValore(f"{_chi(c, 'aggiungi_riga')}: la riga ha {len(valori)} valori, "
                           f"ma la tabella ha {n} colonne.")
    riga = list(valori) + [""] * max(0, n - len(valori))
    righe = _righe(c)
    righe.append(riga)
    _imposta(c, "righe", righe)


def _rimuovi_riga(c, indice):
    """Toglie la riga alla posizione `indice` (da 0) e la restituisce."""
    righe = _righe(c)
    i = _indice(c, "rimuovi_riga", "indice", indice, len(righe), "la tabella")
    tolta = righe.pop(i)
    _imposta(c, "righe", righe)
    sel = _prop(c, "riga_selezionata", -1)
    if e_intero(sel) and sel >= 0:
        nuova = -1 if sel == i else (sel - 1 if sel > i else sel)
        if nuova != sel:
            _imposta(c, "riga_selezionata", nuova)
    return tolta


def _cella(c, riga, colonna):
    """Valore della cella alla riga `riga` e alla colonna `colonna` (numero o nome della colonna)."""
    righe = _righe(c)
    r = _indice(c, "cella", "riga", riga, len(righe), "la tabella")
    k = _colonna(c, "cella", colonna)
    return righe[r][k] if k < len(righe[r]) else ""


def _imposta_cella(c, riga, colonna, valore):
    """Cambia il valore di una cella."""
    righe = _righe(c)
    r = _indice(c, "imposta_cella", "riga", riga, len(righe), "la tabella")
    k = _colonna(c, "imposta_cella", colonna)
    while len(righe[r]) <= k:
        righe[r].append("")
    righe[r][k] = valore
    _imposta(c, "righe", righe)


def _tabella_svuota(c):
    """Toglie tutte le righe (le colonne restano)."""
    _imposta(c, "righe", [])
    if _prop(c, "riga_selezionata", -1) != -1:
        _imposta(c, "riga_selezionata", -1)


# ===========================================================================
# Metodi: Albero
# ===========================================================================

def _parti_percorso(c, metodo: str, percorso: Any) -> list[str]:
    p = _testo(c, metodo, "percorso", percorso)
    return [parte.strip() for parte in p.split("/") if parte.strip()]


def _nodo(c, metodo: str, elementi: dict, parti: list[str]) -> dict:
    """Dizionario dei figli del nodo indicato (lo crea se il nodo era una foglia)."""
    nodo = elementi
    fatto: list[str] = []
    for parte in parti:
        fatto.append(parte)
        if parte not in nodo:
            raise ErroreValore(f"{_chi(c, metodo)}: nell'albero non c'è `{'/'.join(fatto)}`.")
        figli = nodo[parte]
        if not isinstance(figli, dict):
            figli = {}
            nodo[parte] = figli
        nodo = figli
    return nodo


def _albero_aggiungi(c, percorso_genitore, etichetta):
    """Aggiunge `etichetta` sotto il nodo `percorso_genitore` ("" = in cima), es. `aggiungi("Animali", "Gatto")`."""
    parti = _parti_percorso(c, "aggiungi", percorso_genitore)
    e = _testo(c, "aggiungi", "etichetta", etichetta).strip()
    if not e or "/" in e:
        raise ErroreValore(f"{_chi(c, 'aggiungi')}: l'etichetta non può essere vuota né contenere `/`.")
    elementi = copy.deepcopy(_prop(c, "elementi") or {})
    if not isinstance(elementi, dict):
        elementi = {}
    nodo = _nodo(c, "aggiungi", elementi, parti)
    if e in nodo:
        raise ErroreValore(f"{_chi(c, 'aggiungi')}: `{'/'.join(parti + [e])}` c'è già.")
    nodo[e] = None
    _imposta(c, "elementi", elementi)


def _albero_rimuovi(c, percorso):
    """Toglie il nodo `percorso` (es. "Animali/Gatto") con tutto quello che contiene."""
    parti = _parti_percorso(c, "rimuovi", percorso)
    if not parti:
        raise ErroreValore(f"{_chi(c, 'rimuovi')}: indica quale nodo togliere, es. \"Animali/Gatto\".")
    elementi = copy.deepcopy(_prop(c, "elementi") or {})
    if not isinstance(elementi, dict):
        elementi = {}
    genitore = _nodo(c, "rimuovi", elementi, parti[:-1])
    if parti[-1] not in genitore:
        raise ErroreValore(f"{_chi(c, 'rimuovi')}: nell'albero non c'è `{'/'.join(parti)}`.")
    del genitore[parti[-1]]
    _imposta(c, "elementi", elementi)
    selezione = _prop(c, "selezione", "") or ""
    tolto = "/".join(parti)
    if selezione == tolto or selezione.startswith(tolto + "/"):
        c.modello.proprieta["selezione"] = ""


def _espandi_tutto(c):
    """Apre tutti i rami dell'albero."""
    azioni.richiedi_interfaccia(c, "espandi_tutto")


# ===========================================================================
# Metodi: Grafico, Tela
# ===========================================================================

def _aggiungi_valore(c, valore, etichetta=None):
    """Aggiunge un valore al grafico, con un'etichetta facoltativa."""
    v = _numero(c, "aggiungi_valore", "valore", valore)
    dati = _lista(c, "dati")
    if etichetta is None:
        dati.append(v)
    else:
        e = etichetta if isinstance(etichetta, str) else rappresenta(etichetta)
        dati.append([e, v])
    _imposta(c, "dati", dati)


def _grafico_svuota(c):
    """Toglie tutti i valori."""
    _imposta(c, "dati", [])


def _disegna(c, comando: dict) -> None:
    comando.setdefault("colore", _prop(c, "colore_penna", "#000000") or "#000000")
    comando.setdefault("spessore", _prop(c, "spessore_penna", 2))
    disegni = _prop(c, "disegni")
    if not isinstance(disegni, list):
        disegni = []
        c.modello.proprieta["disegni"] = disegni
    disegni.append(comando)
    c.avvisa("disegni", disegni)


def _tela_linea(c, x1, y1, x2, y2):
    """Disegna una linea da (x1, y1) a (x2, y2) con la penna attuale."""
    valori = [_numero(c, "linea", n, v) for n, v in (("x1", x1), ("y1", y1), ("x2", x2), ("y2", y2))]
    _disegna(c, dict(zip(("figura", "x1", "y1", "x2", "y2"), ["linea", *valori])))


def _tela_rettangolo(c, x, y, larghezza, altezza, riempito=False):
    """Disegna un rettangolo; con `riempito` = vero lo colora dentro."""
    x, y = _numero(c, "rettangolo", "x", x), _numero(c, "rettangolo", "y", y)
    w, h = _numero(c, "rettangolo", "larghezza", larghezza), _numero(c, "rettangolo", "altezza", altezza)
    if w < 0 or h < 0:
        raise ErroreValore(f"{_chi(c, 'rettangolo')}: larghezza e altezza non possono essere negative.")
    _disegna(c, {"figura": "rettangolo", "x": x, "y": y, "larghezza": w, "altezza": h,
                 "riempito": _logico(c, "rettangolo", "riempito", riempito)})


def _tela_cerchio(c, x, y, raggio, riempito=False):
    """Disegna un cerchio di centro (x, y); con `riempito` = vero lo colora dentro."""
    x, y = _numero(c, "cerchio", "x", x), _numero(c, "cerchio", "y", y)
    r = _numero(c, "cerchio", "raggio", raggio)
    if r < 0:
        raise ErroreValore(f"{_chi(c, 'cerchio')}: il raggio non può essere negativo.")
    _disegna(c, {"figura": "cerchio", "x": x, "y": y, "raggio": r,
                 "riempito": _logico(c, "cerchio", "riempito", riempito)})


def _tela_scrivi(c, x, y, testo):
    """Scrive `testo` a partire dal punto (x, y)."""
    x, y = _numero(c, "scrivi", "x", x), _numero(c, "scrivi", "y", y)
    t = testo if isinstance(testo, str) else rappresenta(testo)
    _disegna(c, {"figura": "testo", "x": x, "y": y, "testo": t})


def _tela_pulisci(c):
    """Cancella tutto il disegno."""
    _imposta(c, "disegni", [])


def _tela_salva(c, percorso):
    """Salva il disegno in un file immagine (PNG, JPG...)."""
    p = _testo(c, "salva", "percorso", percorso)
    if not p.strip():
        raise ErroreValore(f"{_chi(c, 'salva')}: indica il nome del file, es. \"disegno.png\".")
    risultato = azioni.richiedi_interfaccia(c, "salva", p, predefinito=_NESSUNA_INTERFACCIA)
    if risultato is _NESSUNA_INTERFACCIA:
        raise azioni.errore_non_disponibile("Salvare il disegno della tela")
    return risultato


# ===========================================================================
# Metodi: Suono, Video, MenuContestuale, Appunti, DialogoFile
# ===========================================================================

def _riproduci(c):
    """Avvia (o riprende) la riproduzione del file."""
    if not (_prop(c, "file", "") or "").strip():
        raise ErroreValore(f"{_chi(c, 'riproduci')}: prima imposta `file`.",
                           suggerimento=f"Esempio: `{getattr(c, 'nome', 'Suono1')}.file = \"musica.mp3\"`.")
    risultato = azioni.richiedi_interfaccia(c, "riproduci", predefinito=_NESSUNA_INTERFACCIA)
    if risultato is _NESSUNA_INTERFACCIA:
        raise azioni.errore_non_disponibile("La riproduzione di suoni e video")


def _pausa(c):
    """Mette in pausa la riproduzione."""
    azioni.richiedi_interfaccia(c, "pausa")


def _ferma(c):
    """Ferma la riproduzione e torna all'inizio."""
    azioni.richiedi_interfaccia(c, "ferma")


def _menu_mostra(c):
    """Apre il menu nel punto in cui si trova il mouse."""
    azioni.richiedi_interfaccia(c, "mostra")


def _appunti_copia(c, testo):
    """Copia `testo` negli appunti del sistema."""
    t = testo if isinstance(testo, str) else rappresenta(testo)
    _imposta(c, "testo", t)


def _appunti_incolla(c):
    """Restituisce il testo che si trova negli appunti."""
    risultato = azioni.richiedi_interfaccia(c, "incolla", predefinito=_NESSUNA_INTERFACCIA)
    if risultato is _NESSUNA_INTERFACCIA or risultato is None:
        return _prop(c, "testo", "") or ""
    t = risultato if isinstance(risultato, str) else rappresenta(risultato)
    c.aggiorna_da_interfaccia("testo", t)
    return t


def _dialogo_mostra(c):
    """Apre la finestra per scegliere un file; restituisce il percorso o `nulla` se si annulla."""
    risultato = azioni.richiedi_interfaccia(c, "mostra", predefinito=None)
    if not isinstance(risultato, str) or not risultato:
        return None
    _imposta(c, "percorso", risultato)
    return risultato


# ===========================================================================
# Il catalogo
# ===========================================================================

_ALLINEAMENTI = ("sinistra", "centro", "destra")
_ORIENTAMENTI = ("orizzontale", "verticale")
_ANIMAZIONI = ("nessuna", "dissolvenza", "zoom", "scorrimento", "rimbalzo")


def _finestra() -> TipoControllo:
    return _tipo(
        "Finestra", "Base", "La finestra del programma: contiene tutti gli altri controlli.", 1,
        [
            _p("testo", "testo", "Finestra", "Aspetto", "Titolo della finestra"),
            _p("forma", "forma", "rettangolo", "Aspetto",
               "Forma della finestra: \"rettangolo\", \"arrotondata\", \"cerchio\", \"ellisse\" o una forma"),
            _p("raggio_angoli", "intero", 0, "Aspetto", "Raggio degli angoli per la forma \"arrotondata\"", minimo=0),
            _p("sfondo", "colore", "", "Aspetto",
               "Colore, sfumatura (\"sfumatura: #0B0B0D, #E0182D\") o immagine (\"immagine: x.png\", "
               "\"motivo: x.png\") dello sfondo", classe=ProprietaSfondo),
            _p("immagine_sfondo", "immagine", "", "Aspetto", "Immagine di sfondo"),
            _p("opacità", "intero", 100, "Aspetto", "Opacità da 0 (invisibile) a 100 (piena)", minimo=0, massimo=100),
            _scelta("bordo", ("nessuno", "linea", "doppio", "luminoso"), "Aspetto", "Contorno che segue la forma"),
            _p("colore_bordo", "colore", "", "Aspetto", "Colore del contorno; se non lo scegli, quello del tema"),
            _p("spessore_bordo", "intero", 1, "Aspetto", "Spessore del contorno in pixel", minimo=0),
            _p("ombra", "logico", False, "Aspetto", "Ombra sotto la finestra"),
            _scelta("barra_titolo", ("sistema", "personalizzata", "nascosta"), "Aspetto", "Barra del titolo"),
            _scelta("pulsanti_finestra", ("sistema", "personalizzati", "nascosti"), "Aspetto",
                    "Pulsanti chiudi, riduci e ingrandisci"),
            _p("trascinabile_da", "testo", "", "Comportamento",
               "Da dove si trascina la finestra: \"finestra\" o il nome di un controllo; se non lo scegli, dalla barra del titolo"),
            _p("sempre_in_primo_piano", "logico", False, "Comportamento", "Resta sopra le altre finestre"),
            _scelta("animazione_apertura", _ANIMAZIONI, "Aspetto", "Effetto quando la finestra si apre"),
            _scelta("animazione_chiusura", _ANIMAZIONI, "Aspetto", "Effetto quando la finestra si chiude"),
            _scelta("cursore", ("freccia", "mano", "mirino", "attesa", "testo"), "Aspetto",
                    "Puntatore del mouse sulla finestra"),
            _scelta("tema_controlli", ("moderno", "classico", "piatto", "futuristico"), "Aspetto",
                    "Aspetto di pulsanti e caselle nella finestra (\"futuristico\" = nero e rosso)"),
            _p("ridimensionabile", "logico", True, "Comportamento", "Se vero la finestra si può allargare e stringere"),
            _p("icona", "immagine", "", "Aspetto", "Icona della finestra"),
        ],
        ("apertura", "chiusura", "ridimensionamento", "tasto", "clic"), "apertura",
        dimensione=(640, 480), icona="app-window", contenitore=True,
    )


def tipi() -> list[TipoControllo]:
    """I 40 controlli classici, costruiti da capo a ogni chiamata (nell'ordine di PROGETTO.md)."""
    testo_ro = "Se vero il testo si può leggere e copiare ma non cambiare"
    elenco_prop = [
        _p("elementi", "lista", [], "Dati", "Elementi mostrati"),
        _p("indice_selezionato", "intero", -1, "Dati", "Posizione dell'elemento scelto (-1 quando non è scelto nessuno)", minimo=-1),
        _p("selezione", "qualsiasi", None, "Dati", "Elemento scelto (nulla se nessuno)", sola_lettura=True),
    ]
    return [
        # ------------------------------------------------------------- Base
        _finestra(),
        _tipo("Etichetta", "Base", "Testo fisso da leggere, come un titolo o una spiegazione.", 1,
              [_p("testo", "testo", "Etichetta", "Aspetto", "Testo mostrato"),
               _scelta("allineamento", _ALLINEAMENTI, "Aspetto", "Allineamento del testo")],
              ("clic",), "clic", dimensione=(100, 24), icona="type"),
        _tipo("Pulsante", "Base", "Pulsante da premere per far succedere qualcosa.", 1,
              [_p("testo", "testo", "Pulsante", "Aspetto", "Scritta sul pulsante"),
               _p("immagine", "immagine", "", "Aspetto", "Icona accanto alla scritta")],
              ("clic",), "clic", dimensione=(90, 28), icona="mouse-pointer-click"),
        _tipo("PulsanteImmagine", "Base", "Pulsante che mostra un'immagine o un'icona.", 1,
              [_p("immagine", "immagine", "", "Aspetto", "Immagine del pulsante"),
               _p("testo", "testo", "", "Aspetto", "Scritta facoltativa")],
              ("clic",), "clic", dimensione=(48, 48), icona="image-play"),
        _tipo("Collegamento", "Base", "Testo cliccabile che apre un indirizzo web.", 2,
              [_p("testo", "testo", "Collegamento", "Aspetto", "Testo mostrato"),
               _p("indirizzo", "testo", "", "Dati", "Indirizzo da aprire (es. https://...)"),
               _p("visitato", "logico", False, "Comportamento", "Diventa vero dopo che il collegamento è stato aperto")],
              ("clic",), "clic", dimensione=(110, 24), icona="link", metodi=_metodi(apri=_collegamento_apri)),
        # ------------------------------------------------------ Inserimento
        _tipo("CasellaTesto", "Inserimento", "Casella in cui scrivere una riga di testo.", 1,
              [_p("testo", "testo", "", "Dati", "Testo scritto nella casella"),
               _p("segnaposto", "testo", "", "Aspetto", "Suggerimento grigio mostrato quando è vuota"),
               _p("sola_lettura", "logico", False, "Comportamento", testo_ro),
               _p("lunghezza_massima", "intero", 0, "Comportamento", "Numero massimo di caratteri (0 per nessun limite)",
                  minimo=0)],
              ("cambio", "invio"), "cambio", dimensione=(160, 28), icona="text-cursor-input",
              metodi=_metodi(seleziona_tutto=_seleziona_tutto)),
        _tipo("CasellaPassword", "Inserimento", "Casella per le password: mostra pallini al posto delle lettere.", 1,
              [_p("testo", "testo", "", "Dati", "Password scritta"),
               _p("segnaposto", "testo", "", "Aspetto", "Suggerimento grigio mostrato quando è vuota")],
              ("invio", "cambio"), "invio", dimensione=(160, 28), icona="key-round"),
        _tipo("AreaTesto", "Inserimento", "Casella di testo su più righe.", 1,
              [_p("testo", "testo", "", "Dati", "Testo scritto"),
               _p("sola_lettura", "logico", False, "Comportamento", testo_ro),
               _p("a_capo_automatico", "logico", True, "Aspetto", "Va a capo da solo alla fine della riga")],
              ("cambio",), "cambio", dimensione=(240, 120), icona="text",
              metodi=_metodi(aggiungi_riga=_aggiungi_riga)),
        _tipo("CasellaNumero", "Inserimento", "Casella per i numeri, con le frecce su e giù.", 1,
              [_p("valore", "numero", 0, "Dati", "Numero scritto"),
               _p("minimo", "numero", 0, "Dati", "Valore minimo"),
               _p("massimo", "numero", 100, "Dati", "Valore massimo"),
               _p("passo", "numero", 1, "Dati", "Di quanto cambia con le frecce"),
               _p("decimali", "intero", 0, "Aspetto", "Cifre dopo la virgola", minimo=0, massimo=10)],
              ("cambio",), "cambio", dimensione=(100, 28), icona="hash"),
        _tipo("SelettoreData", "Inserimento", "Casella con calendario per scegliere una data.", 2,
              [_p("data", "testo", "", "Dati", "Data scelta, GG/MM/AAAA; se non la scegli, oggi", classe=ProprietaData),
               _p("minimo_data", "testo", "", "Dati", "Prima data ammessa; se non la scegli, nessun limite", classe=ProprietaData),
               _p("massimo_data", "testo", "", "Dati", "Ultima data ammessa; se non la scegli, nessun limite",
                  classe=ProprietaData)],
              ("cambio",), "cambio", dimensione=(130, 28), icona="calendar"),
        _tipo("SelettoreColore", "Inserimento", "Riquadro colorato: cliccandolo si sceglie un colore.", 2,
              [_p("colore", "colore", "#E0182D", "Dati", "Colore scelto")],
              ("cambio",), "cambio", dimensione=(100, 28), icona="palette", metodi=_metodi(scegli=_scegli_colore)),
        _tipo("Cursore", "Inserimento", "Levetta da trascinare per scegliere un numero.", 1,
              [_p("valore", "intero", 0, "Dati", "Numero scelto"),
               _p("minimo", "intero", 0, "Dati", "Valore minimo"),
               _p("massimo", "intero", 100, "Dati", "Valore massimo"),
               _p("passo", "intero", 1, "Dati", "Di quanto cambia a ogni scatto", minimo=1),
               _scelta("orientamento", _ORIENTAMENTI, "Aspetto", "Direzione della levetta")],
              ("cambio",), "cambio", dimensione=(160, 28), icona="sliders-horizontal"),
        # ----------------------------------------------------------- Scelta
        _tipo("CasellaSpunta", "Scelta", "Casella da spuntare per dire sì o no.", 1,
              [_p("testo", "testo", "Casella di spunta", "Aspetto", "Testo accanto alla casella"),
               _p("selezionata", "logico", False, "Dati", "Vero se è spuntata")],
              ("cambio",), "cambio", dimensione=(150, 24), icona="square-check"),
        _tipo("Scelta", "Scelta", "Pallino da scegliere tra alternative (una sola per gruppo).", 1,
              [_p("testo", "testo", "Scelta", "Aspetto", "Testo accanto al pallino"),
               _p("selezionata", "logico", False, "Dati", "Vero se è scelta"),
               _p("gruppo", "testo", "", "Comportamento",
                  "Le scelte dello stesso contenitore e dello stesso gruppo si escludono a vicenda")],
              ("cambio",), "cambio", dimensione=(150, 24), icona="circle-dot"),
        _tipo("Interruttore", "Scelta", "Interruttore acceso/spento, come quelli dei telefoni.", 2,
              [_p("acceso", "logico", False, "Dati", "Vero se è acceso"),
               _p("testo", "testo", "", "Aspetto", "Testo accanto all'interruttore")],
              ("cambio",), "cambio", dimensione=(120, 28), icona="toggle-right", metodi=_metodi(commuta=_commuta)),
        _tipo("Elenco", "Scelta", "Elenco di elementi tra cui sceglierne uno (o più).", 1,
              [*copy.deepcopy(elenco_prop),
               _p("multipla", "logico", False, "Comportamento",
                  "Se vero si possono scegliere più elementi (allora `selezione` è una lista)")],
              ("selezione",), "selezione", dimensione=(160, 120), icona="list", metodi=_metodi(**_METODI_ELENCO)),
        _tipo("MenuATendina", "Scelta", "Casella che si apre mostrando un elenco di scelte.", 1,
              [*copy.deepcopy(elenco_prop),
               _p("modificabile", "logico", False, "Comportamento", "Se vero si può anche scrivere un valore nuovo")],
              ("selezione",), "selezione", dimensione=(160, 28), icona="chevrons-up-down",
              metodi=_metodi(**_METODI_ELENCO)),
        # ------------------------------------------------------ Contenitori
        _tipo("Riquadro", "Contenitori", "Cornice con titolo che raggruppa altri controlli.", 1,
              [_p("testo", "testo", "", "Aspetto", "Titolo del riquadro")],
              (), None, dimensione=(200, 150), icona="frame", contenitore=True),
        _tipo("Schede", "Contenitori", "Pagine con linguette: ogni scheda contiene i suoi controlli.", 1,
              [_p("schede", "lista", ["Scheda 1", "Scheda 2"], "Dati", "Titoli delle linguette"),
               _p("scheda_corrente", "intero", 0, "Dati", "Scheda mostrata (da 0)", minimo=0)],
              ("cambio_scheda",), "cambio_scheda", dimensione=(300, 200), icona="panels-top-left", contenitore=True),
        _tipo("PannelloScorrevole", "Contenitori", "Area con barre di scorrimento per contenuti grandi.", 2,
              [_p("larghezza_contenuto", "intero", 0, "Posizione", "Larghezza dell'area interna; se non la scegli, automatica",
                  minimo=0),
               _p("altezza_contenuto", "intero", 0, "Posizione", "Altezza dell'area interna; se non la scegli, automatica", minimo=0),
               _p("scorrimento_x", "intero", 0, "Posizione", "Scorrimento orizzontale in pixel", minimo=0),
               _p("scorrimento_y", "intero", 0, "Posizione", "Scorrimento verticale in pixel", minimo=0)],
              ("scorrimento",), "scorrimento", dimensione=(240, 180), icona="scroll", contenitore=True,
              metodi=_metodi(scorri_a=_scorri_a)),
        _tipo("Divisore", "Contenitori", "Due pannelli separati da una barra trascinabile (figli con scheda 0 e 1).", 3,
              [_scelta("orientamento", _ORIENTAMENTI, "Aspetto", "Pannelli affiancati (orizzontale) o uno sopra l'altro"),
               _p("posizione", "intero", 150, "Posizione", "Posizione della barra in pixel", minimo=0)],
              ("spostamento",), "spostamento", dimensione=(320, 200), icona="columns-2", contenitore=True),
        # -------------------------------------------------- Visualizzazione
        _tipo("Immagine", "Visualizzazione", "Mostra un'immagine (PNG, JPG, GIF...).", 1,
              [_p("immagine", "immagine", "", "Aspetto", "File dell'immagine"),
               _scelta("adatta", ("adatta", "riempi", "estendi", "nessuno"), "Aspetto",
                       "Come l'immagine si adatta al riquadro")],
              ("clic",), "clic", dimensione=(120, 120), icona="image"),
        _tipo("BarraAvanzamento", "Visualizzazione", "Barra che si riempie per mostrare a che punto si è.", 1,
              [_p("valore", "intero", 0, "Dati", "Valore attuale"),
               _p("minimo", "intero", 0, "Dati", "Valore minimo"),
               _p("massimo", "intero", 100, "Dati", "Valore massimo"),
               _p("mostra_percentuale", "logico", True, "Aspetto", "Scrive la percentuale sulla barra")],
              (), None, dimensione=(200, 22), icona="loader"),
        _tipo("BarraStato", "Visualizzazione", "Striscia in fondo alla finestra con messaggi e informazioni.", 2,
              [_p("testo", "testo", "", "Aspetto", "Testo mostrato"),
               _p("sezioni", "lista", [], "Dati", "Testi delle sezioni a destra")],
              (), None, dimensione=(300, 24), icona="panel-bottom",
              metodi=_metodi(mostra_messaggio=_mostra_messaggio)),
        _tipo("Suggerimento", "Visualizzazione", "Fumetti di aiuto che compaiono passando col mouse sui controlli.", 2,
              [_p("ritardo", "intero", 500, "Comportamento", "Attesa prima di mostrare il fumetto (ms)", minimo=0),
               _p("testi", "dizionario", {}, "Dati", "Nome del controllo -> testo del fumetto")],
              (), None, dimensione=(32, 32), icona="message-square", invisibile=True,
              metodi=_metodi(mostra=_suggerimento_mostra)),
        # ------------------------------------------------------------- Dati
        _tipo("Tabella", "Dati", "Griglia di righe e colonne, come un foglio di calcolo.", 2,
              [_p("colonne", "lista", ["A", "B", "C"], "Dati", "Titoli delle colonne"),
               _p("righe", "lista", [], "Dati", "Righe: una lista di valori per ogni riga"),
               _p("modificabile", "logico", True, "Comportamento", "Se vero le celle si possono cambiare"),
               _p("riga_selezionata", "intero", -1, "Dati", "Riga scelta (-1 quando non è scelta nessuna)", minimo=-1)],
              ("selezione", "modifica_cella"), "selezione", dimensione=(320, 200), icona="table",
              metodi=_metodi(aggiungi_riga=_aggiungi_riga_tabella, rimuovi_riga=_rimuovi_riga, cella=_cella,
                             imposta_cella=_imposta_cella, svuota=_tabella_svuota)),
        _tipo("Albero", "Dati", "Elementi organizzati a rami, come le cartelle.", 2,
              [_p("elementi", "dizionario", {}, "Dati", "Etichetta -> dizionario dei figli (o nulla per una foglia)"),
               _p("selezione", "testo", "", "Dati", "Percorso dell'elemento scelto, es. \"Animali/Gatto\"",
                  sola_lettura=True)],
              ("selezione", "espansione"), "selezione", dimensione=(200, 240), icona="list-tree",
              metodi=_metodi(aggiungi=_albero_aggiungi, rimuovi=_albero_rimuovi, espandi_tutto=_espandi_tutto)),
        _tipo("Grafico", "Dati", "Grafico a barre, a linee, a torta o a punti.", 3,
              [_scelta("tipo_grafico", ("barre", "linee", "torta", "punti"), "Aspetto", "Tipo di grafico"),
               _p("dati", "lista", [], "Dati", "Numeri, oppure coppie [etichetta, valore]"),
               _p("titolo", "testo", "", "Aspetto", "Titolo del grafico")],
              ("clic",), "clic", dimensione=(320, 220), icona="chart-column",
              metodi=_metodi(aggiungi_valore=_aggiungi_valore, svuota=_grafico_svuota)),
        # ---------------------------------------------------------- Disegno
        _tipo("Tela", "Disegno", "Area su cui disegnare linee, figure e testi dal codice.", 2,
              [_p("colore_penna", "colore", "#000000", "Aspetto", "Colore dei prossimi disegni"),
               _p("spessore_penna", "intero", 2, "Aspetto", "Spessore dei prossimi disegni", minimo=1),
               _p("disegni", "lista", [], "Dati", "Comandi di disegno eseguiti finora", sola_lettura=True)],
              ("clic", "trascina"), "clic", dimensione=(320, 240), icona="brush",
              metodi=_metodi(linea=_tela_linea, rettangolo=_tela_rettangolo, cerchio=_tela_cerchio,
                             scrivi=_tela_scrivi, pulisci=_tela_pulisci, salva=_tela_salva)),
        _tipo("Linea", "Disegno", "Linea decorativa.", 1,
              [_scelta("direzione", ("orizzontale", "verticale", "diagonale", "diagonale_inversa"), "Aspetto",
                       "Direzione della linea nel suo riquadro"),
               _p("colore", "colore", "#000000", "Aspetto", "Colore della linea"),
               _p("spessore", "intero", 1, "Aspetto", "Spessore in pixel", minimo=0),
               _scelta("stile_linea", ("continua", "tratteggiata", "punteggiata"), "Aspetto", "Tipo di tratto")],
              ("clic",), "clic", dimensione=(120, 10), icona="minus"),
        _tipo("Forma", "Disegno", "Figura decorativa: rettangolo, cerchio, ellisse.", 1,
              [_scelta("figura", ("rettangolo", "rettangolo_arrotondato", "cerchio", "ellisse"), "Aspetto",
                       "Figura disegnata"),
               _p("colore_riempimento", "colore", "", "Aspetto", "Colore dell'interno; se non lo scegli, la forma resta vuota"),
               _p("colore_bordo", "colore", "#000000", "Aspetto", "Colore del contorno"),
               _p("spessore_bordo", "intero", 1, "Aspetto", "Spessore del contorno in pixel", minimo=0)],
              ("clic",), "clic", dimensione=(100, 100), icona="shapes"),
        # ------------------------------------------------------------ Media
        _tipo("Suono", "Media", "Riproduce musica ed effetti sonori (MP3, WAV...).", 3,
              [_p("file", "testo", "", "Dati", "File audio da riprodurre"),
               _p("volume", "intero", 100, "Comportamento", "Volume da 0 a 100", minimo=0, massimo=100),
               _p("ripeti", "logico", False, "Comportamento", "Ricomincia da capo quando finisce")],
              ("fine_riproduzione",), "fine_riproduzione", dimensione=(32, 32), icona="volume-2", invisibile=True,
              metodi=_metodi(riproduci=_riproduci, pausa=_pausa, ferma=_ferma)),
        _tipo("Video", "Media", "Lettore video.", 3,
              [_p("file", "testo", "", "Dati", "File video da riprodurre"),
               _p("volume", "intero", 100, "Comportamento", "Volume da 0 a 100", minimo=0, massimo=100),
               _p("automatico", "logico", False, "Comportamento", "Parte da solo quando si apre la finestra")],
              ("fine_riproduzione",), "fine_riproduzione", dimensione=(320, 240), icona="video",
              metodi=_metodi(riproduci=_riproduci, pausa=_pausa, ferma=_ferma)),
        # ------------------------------------------------------------- Menu
        _tipo("BarraMenu", "Menu", "Barra dei menu in cima alla finestra (le voci sono VoceMenu).", 1,
              [], (), None, dimensione=(32, 32), icona="menu", invisibile=True),
        _tipo("VoceMenu", "Menu", "Voce di un menu; il suo contenitore è la BarraMenu o un'altra VoceMenu.", 1,
              [_p("testo", "testo", "Voce", "Aspetto", "Testo della voce (\"-\" = separatore)"),
               _p("scorciatoia", "testo", "", "Comportamento", "Tasti rapidi, es. \"Ctrl+S\""),
               _p("spuntabile", "logico", False, "Comportamento", "Se vero la voce si può spuntare"),
               _p("spuntata", "logico", False, "Dati", "Vero se la voce è spuntata"),
               _p("abilitato", "logico", True, "Comportamento", "Se falso la voce è grigia e non risponde"),
               _p("visibile", "logico", True, "Comportamento", "Se falso la voce non compare")],
              ("clic",), "clic", dimensione=(32, 32), icona="square-menu", invisibile=True),
        _tipo("MenuContestuale", "Menu", "Menu che si apre con il tasto destro.", 2,
              [_p("voci", "lista", [], "Dati", "Testi delle voci (\"-\" = separatore)"),
               _p("controllo", "testo", "", "Comportamento", "Controllo su cui si apre; se non lo scegli, tutta la finestra")],
              ("clic",), "clic", dimensione=(32, 32), icona="text-select", invisibile=True,
              metodi=_metodi(mostra=_menu_mostra)),
        _tipo("BarraStrumenti", "Menu", "Fila di pulsanti con icone sotto il menu.", 2,
              [_p("pulsanti", "lista", [], "Dati", "Testi dei pulsanti, oppure coppie [testo, icona]")],
              ("clic",), "clic", dimensione=(300, 32), icona="wrench"),
        # ------------------------------------------------------- Invisibili
        _tipo("Timer", "Invisibili", "Fa scattare un evento a intervalli regolari.", 1,
              [_p("intervallo", "intero", 1000, "Comportamento", "Tempo tra uno scatto e l'altro, in millisecondi",
                  minimo=1),
               _p("attivo", "logico", True, "Comportamento", "Se falso il timer è fermo")],
              ("scatto",), "scatto", dimensione=(32, 32), icona="timer", invisibile=True,
              metodi=_metodi(avvia=_timer_avvia, ferma=_timer_ferma)),
        _tipo("DialogoFile", "Invisibili", "Finestra standard per scegliere un file da aprire o salvare.", 1,
              [_p("titolo", "testo", "Apri", "Aspetto", "Titolo della finestra di dialogo"),
               _scelta("modalita", ("apri", "salva", "cartella"), "Comportamento", "Cosa si sceglie"),
               _p("filtro", "testo", "Tutti i file (*.*)", "Comportamento",
                  "Tipi di file mostrati, es. \"Immagini (*.png *.jpg)\""),
               _p("percorso", "testo", "", "Dati", "Ultimo percorso scelto", sola_lettura=True)],
              ("scelta",), "scelta", dimensione=(32, 32), icona="folder-open", invisibile=True,
              metodi=_metodi(mostra=_dialogo_mostra)),
        _tipo("Appunti", "Invisibili", "Legge e scrive gli appunti del sistema (copia e incolla).", 3,
              [_p("testo", "testo", "", "Dati", "Testo negli appunti")],
              ("cambio",), "cambio", dimensione=(32, 32), icona="clipboard", invisibile=True,
              metodi=_metodi(copia=_appunti_copia, incolla=_appunti_incolla)),
    ]


for _t in tipi():
    registra(_t)
del _t

__all__ = ["tipi", "SCHEDE", "ProprietaSfondo", "ProprietaData", "normalizza_data"]
