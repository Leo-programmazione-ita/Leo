"""Metadati dei controlli grafici (proprieta', eventi) - CONTRATTO CONDIVISO, senza Qt.

Il catalogo vero (146 controlli) e' in ``catalogo_classici.py`` (i 40 classici),
``catalogo_dante.py`` (gli inventati), ``catalogo_telefono.py`` (scheda "Telefono"),
``catalogo_quotidiani.py`` ("Tutti i giorni"), ``catalogo_giochi.py`` ("Giochi") e
``catalogo_dati_telefono.py`` (dati, cruscotti e sensori): ognuno chiama :func:`registra` per
ogni :class:`TipoControllo`. :func:`tipo_controllo` carica il catalogo alla
prima richiesta.

Tipi di proprieta' (campo ``Proprieta.tipo``):
    "intero" "decimale" "numero" (intero o decimale, conservato com'e')
    "testo" "logico" "colore" "scelta" "ancoraggio"
    "forma" "immagine" "lista" "dizionario" "qualsiasi"
"""

from __future__ import annotations

import math
import unicodedata
from dataclasses import dataclass, field
from typing import Any, Callable

from ..errori import ErroreNome, ErroreTipo, ErroreValore
from ..valori import e_intero, e_numero, nome_tipo

TIPI_PROPRIETA = ("intero", "decimale", "numero", "testo", "logico", "colore", "scelta", "ancoraggio",
                  "forma", "immagine", "lista", "dizionario", "qualsiasi")

GRUPPI = ("Aspetto", "Posizione", "Comportamento", "Dati", "Effetti", "Dinamiche")

LATI_ANCORAGGIO = ("sinistra", "destra", "alto", "basso")
#: Nello stesso ordine che produce :func:`normalizza_ancoraggio` (cosi' il
#: predefinito resta uguale a se stesso dopo la conversione).
ANCORAGGIO_PREDEFINITO = ["sinistra", "alto"]

#: Limiti delle proprieta' ``intero`` (interi a 32 bit, come i widget Qt).
INTERO_MINIMO = -(2 ** 31)
INTERO_MASSIMO = 2 ** 31 - 1

#: Forme di finestra indicabili con un testo (le altre sono oggetti Forma).
FORME_NOMINATE = ("rettangolo", "arrotondata", "cerchio", "ellisse")


@dataclass
class Proprieta:
    nome: str
    tipo: str
    predefinito: Any = None
    gruppo: str = "Aspetto"
    descrizione: str = ""
    scelte: tuple[str, ...] = ()          # per tipo "scelta"
    minimo: float | None = None           # per intero/decimale
    massimo: float | None = None
    sola_lettura: bool = False            # non scrivibile da codice (es. valori calcolati)
    solo_progettazione: bool = False      # modificabile solo in Leo Studio (es. nome)
    sinonimi: dict[str, str] = field(default_factory=dict)  # per "scelta": altri nomi -> scelta vera

    def converti(self, valore: Any) -> Any:
        """Controlla e normalizza un valore assegnato da Leo.

        ErroreTipo per tipo sbagliato, ErroreValore per valore fuori dai limiti.
        """
        t = self.tipo
        n = self.nome
        if t == "qualsiasi":
            return valore
        if t == "intero":
            if isinstance(valore, float) and valore.is_integer():
                valore = int(valore)
            if not e_intero(valore):
                raise ErroreTipo(f"La proprietà `{n}` vuole un intero, non `{nome_tipo(valore)}`.")
            if not INTERO_MINIMO <= valore <= INTERO_MASSIMO:
                raise ErroreValore(f"Il numero {valore} è fuori misura per `{n}`.",
                                   suggerimento=f"Usa un intero tra {INTERO_MINIMO} e {INTERO_MASSIMO}.")
            return self._limiti(valore)
        if t in ("decimale", "numero"):
            if not e_numero(valore):
                raise ErroreTipo(f"La proprietà `{n}` vuole un numero, non `{nome_tipo(valore)}`.")
            try:
                finito = math.isfinite(valore)
            except OverflowError:  # intero enorme: non entra in un decimale
                finito = False
            if not finito:
                raise ErroreValore(f"`{n}` vuole un numero vero e finito, non `{valore}`.",
                                   suggerimento="Controlla il calcolo: forse c'è una divisione strana.")
            return self._limiti(float(valore) if t == "decimale" else valore)
        if t in ("testo", "immagine"):
            if not isinstance(valore, str):
                raise ErroreTipo(f"La proprietà `{n}` vuole un testo, non `{nome_tipo(valore)}`.",
                                 suggerimento="Per convertire usa `testo(...)`.")
            return valore
        if t == "logico":
            if not isinstance(valore, bool):
                raise ErroreTipo(f"La proprietà `{n}` vuole `vero` o `falso`, non `{nome_tipo(valore)}`.")
            return valore
        if t == "scelta":
            if isinstance(valore, str) and valore not in self.scelte:
                chiave = semplifica_nome(valore)
                for s in self.scelte:
                    if semplifica_nome(s) == chiave:  # "Nessuno", " nessuno " -> "nessuno"
                        return s
                sinonimo = self.sinonimi.get(chiave.replace(" ", "_")) if self.sinonimi else None
                if sinonimo in self.scelte:  # `stile = "primario"` -> "principale"
                    return sinonimo
            if not isinstance(valore, str) or valore not in self.scelte:
                raise ErroreValore(f"`{valore}` non va bene per `{n}`.",
                                   suggerimento="Valori ammessi: " + ", ".join(f'"{s}"' for s in self.scelte) + ".")
            return valore
        if t == "colore":
            try:
                from .colori import normalizza_colore
            except ImportError:  # pragma: no cover
                normalizza_colore = None
            if not isinstance(valore, str):
                raise ErroreTipo(f"La proprietà `{n}` vuole un colore come testo (es. \"#FF0000\" o \"rosso\").")
            return normalizza_colore(valore) if normalizza_colore else valore
        if t == "ancoraggio":
            return normalizza_ancoraggio(valore)
        if t == "forma":
            if isinstance(valore, str):
                if valore not in FORME_NOMINATE:
                    raise ErroreValore(f"La forma `{valore}` non esiste.",
                                       suggerimento="Forme con nome: " + ", ".join(f'"{f}"' for f in FORME_NOMINATE)
                                       + "; le altre si creano con `forma_poligono`, `forma_stella`, `forma_punti`...")
                return valore
            if nome_tipo(valore) != "forma":
                raise ErroreTipo(f"La proprietà `{n}` vuole una forma, non `{nome_tipo(valore)}`.")
            return valore
        if t == "lista":
            if not isinstance(valore, list):
                raise ErroreTipo(f"La proprietà `{n}` vuole una lista, non `{nome_tipo(valore)}`.")
            return valore
        if t == "dizionario":
            if not isinstance(valore, dict):
                raise ErroreTipo(f"La proprietà `{n}` vuole un dizionario, non `{nome_tipo(valore)}`.")
            return valore
        return valore

    def _limiti(self, v):
        if self.minimo is not None and v < self.minimo:
            raise ErroreValore(f"`{self.nome}` non può essere minore di {self.minimo:g}.")
        if self.massimo is not None and v > self.massimo:
            raise ErroreValore(f"`{self.nome}` non può essere maggiore di {self.massimo:g}.")
        return v


def semplifica_nome(nome: str) -> str:
    """Chiave per confronti "amichevoli": minuscole, senza accenti e spazi ai lati.

    ``"Opacità"`` -> ``"opacita"``; ``" Visibilità "`` -> ``"visibilita"``.
    """
    scomposto = unicodedata.normalize("NFD", nome.strip().casefold())
    return "".join(c for c in scomposto if not unicodedata.combining(c))


def normalizza_ancoraggio(valore: Any) -> list[str]:
    """``"alto sinistra"`` / ``["Alto", "sinistra"]`` -> lista ordinata e senza doppioni.

    L'ordine e' sempre quello di :data:`LATI_ANCORAGGIO`; maiuscole e spazi
    ai lati sono ignorati.
    """
    if isinstance(valore, str):
        parti = valore.replace(",", " ").replace("+", " ").split()
    elif isinstance(valore, (list, tuple)):
        parti = list(valore)
    else:
        raise ErroreTipo(f"`ancoraggio` vuole una lista di lati, non `{nome_tipo(valore)}`.")
    lati = set()
    for p in parti:
        lato = semplifica_nome(p) if isinstance(p, str) else p
        if lato not in LATI_ANCORAGGIO:
            mostrato = p if isinstance(p, str) else nome_tipo(p)
            raise ErroreValore(f"`{mostrato}` non è un lato valido per `ancoraggio`.",
                               suggerimento="Lati: \"sinistra\", \"destra\", \"alto\", \"basso\".")
        lati.add(lato)
    return [lato for lato in LATI_ANCORAGGIO if lato in lati]


#: Firma dei metodi dei controlli: (controllo_vivo, *argomenti Leo) -> valore Leo
MetodoControllo = Callable[..., Any]


#: Nomi "naturali" che un principiante potrebbe usare, verso i nomi veri.
#: Le chiavi sono gia' "semplificate" (vedi :func:`semplifica_nome`). Il primo
#: nome vero che il controllo possiede vince. ``colore`` e' trattato a parte in
#: :meth:`TipoControllo.risolvi_nome` (dipende dal tipo di controllo).
ALIAS_PROPRIETA: dict[str, tuple[str, ...]] = {
    "sfondo": ("colore_sfondo",),
    "colore_sfondo": ("sfondo",),
    "colore_di_sfondo": ("sfondo", "colore_sfondo"),
    "colore_del_testo": ("colore_testo",),
    "colore_scritta": ("colore_testo",),
    "font": ("carattere",),
    "dimensione_font": ("dimensione_carattere",),
    "scritta": ("testo",),
    "titolo": ("testo",),
    "x": ("sinistra",),
    "y": ("alto",),
    "larghezza_finestra": ("larghezza",),
    "visibilita": ("visibile",),
}


@dataclass
class TipoControllo:
    nome: str                          # "Pulsante"
    scheda: str                        # "Base", "Inserimento", ... (casella dei controlli)
    descrizione: str
    versione: int = 1                  # 1, 2, 3 (roadmap)
    proprieta: dict[str, Proprieta] = field(default_factory=dict)
    eventi: tuple[str, ...] = ()
    evento_predefinito: str | None = None
    invisibile: bool = False           # Timer, DialogoFile...: nella striscia sotto la finestra
    contenitore: bool = False          # puo' contenere altri controlli (Riquadro, Schede...)
    dimensione_predefinita: tuple[int, int] = (100, 30)
    icona: str = ""                    # nome icona (Lucide) per la casella
    metodi: dict[str, MetodoControllo] = field(default_factory=dict)
    prefisso_nome: str = ""            # per i nomi automatici; vuoto = nome del tipo

    def risolvi_nome(self, nome: str) -> str:
        """Nome vero di una proprieta' scritta in modo "da bambino".

        Ordine di ricerca:

        1. il nome esatto;
        2. lo stesso nome con maiuscole/accenti diversi (``Titolo`` -> ``titolo``
           sul Grafico, ``opacita`` -> ``opacità`` sulla Finestra, ``X`` -> ``x``
           sul Joystick): una proprieta' vera vince sempre sugli alias;
        3. gli alias: ``colore`` -> ``sfondo`` sulla Finestra, ``colore_sfondo``
           sui contenitori, ``colore_testo`` sugli altri; poi
           :data:`ALIAS_PROPRIETA` (``Finestra1.colore_sfondo`` -> ``sfondo``,
           ``Etichetta1.sfondo`` -> ``colore_sfondo``, ``titolo`` -> ``testo``).

        Se non c'e' niente di adatto restituisce ``nome`` com'e' (e poi arriva
        l'errore normale di :meth:`proprieta_o_errore`).
        """
        if nome in self.proprieta or not isinstance(nome, str):
            return nome
        chiave = semplifica_nome(nome)
        for k in self.proprieta:
            if semplifica_nome(k) == chiave:
                return k
        if chiave == "colore":
            if "sfondo" in self.proprieta:
                alternative: tuple[str, ...] = ("sfondo", "colore_sfondo")
            elif self.contenitore:
                alternative = ("colore_sfondo", "colore_testo")
            else:
                alternative = ("colore_testo", "colore_sfondo")
        else:
            alternative = ALIAS_PROPRIETA.get(chiave, ())
        for alt in alternative:
            if alt in self.proprieta:
                return alt
        return nome

    def risolvi_metodo(self, nome: str) -> str | None:
        """Nome vero di un metodo (maiuscole e accenti ignorati) o ``None``.

        Si chiama a ogni lettura di una proprieta' dal codice Leo (``Casella1.testo``):
        le risposte si ricordano (si ricalcolano se cambiano i metodi del tipo)."""
        metodi = self.metodi
        if nome in metodi:
            return nome
        if not isinstance(nome, str):
            return None
        memoria = self.__dict__.get("_memoria_metodi")
        firma = (id(metodi), len(metodi))
        if memoria is None or memoria[0] != firma:
            memoria = self._memoria_metodi = (firma, {})
        risposte = memoria[1]
        if nome in risposte:
            return risposte[nome]
        chiave = semplifica_nome(nome)
        trovato = None
        for k in metodi:
            if semplifica_nome(k) == chiave:
                trovato = k
                break
        if len(risposte) < 1000:
            risposte[nome] = trovato
        return trovato

    def proprieta_o_errore(self, nome: str) -> Proprieta:
        p = self.proprieta.get(nome)
        if p is None:
            raise ErroreNome(
                f"Il controllo `{self.nome}` non ha la proprietà `{nome}`.",
                suggerimento="Proprietà disponibili: " + ", ".join(f"`{k}`" for k in sorted(self.proprieta)) + ".",
                nome=nome,
            )
        return p

    def valori_predefiniti(self) -> dict[str, Any]:
        """Copia dei valori predefiniti (liste copiate), senza ``nome``."""
        import copy

        return {k: copy.deepcopy(p.predefinito) for k, p in self.proprieta.items() if k != "nome"}


def proprieta_comuni(*, invisibile: bool = False, larghezza: int = 100, altezza: int = 30) -> dict[str, Proprieta]:
    """Proprieta' che hanno tutti i controlli (per quelli invisibili solo ``nome``).

    I controlli visibili hanno anche colori e carattere; :func:`registra` aggiunge
    inoltre l'evento ``clic`` ai controlli visibili che non lo dichiarano.
    """
    comuni = [Proprieta("nome", "testo", "", "Comportamento", "Nome usato nel codice", solo_progettazione=True)]
    if not invisibile:
        comuni += [
            Proprieta("sinistra", "intero", 0, "Posizione", "Distanza dal bordo sinistro, in pixel"),
            Proprieta("alto", "intero", 0, "Posizione", "Distanza dal bordo in alto, in pixel"),
            Proprieta("larghezza", "intero", larghezza, "Posizione", "Larghezza in pixel", minimo=0),
            Proprieta("altezza", "intero", altezza, "Posizione", "Altezza in pixel", minimo=0),
            Proprieta("ancoraggio", "ancoraggio", list(ANCORAGGIO_PREDEFINITO), "Posizione",
                      "Bordi della finestra a cui il controllo resta agganciato"),
            Proprieta("visibile", "logico", True, "Comportamento", "Se falso il controllo non si vede"),
            Proprieta("abilitato", "logico", True, "Comportamento", "Se falso il controllo non risponde"),
            Proprieta("suggerimento", "testo", "", "Comportamento", "Testo che compare passandoci sopra"),
            Proprieta("colore_testo", "colore", "", "Aspetto", "Colore del testo; se non lo scegli, quello del tema"),
            Proprieta("colore_sfondo", "colore", "", "Aspetto", "Colore dello sfondo; se non lo scegli, quello del tema"),
            Proprieta("carattere", "testo", "", "Aspetto", "Nome del carattere; se non lo scegli, quello del sistema"),
            Proprieta("dimensione_carattere", "intero", 0, "Aspetto", "Dimensione del carattere in pixel; se non la scegli, quella del tema",
                      minimo=0),
            Proprieta("opacità", "intero", 100, "Aspetto", "Opacità da 0 (invisibile) a 100 (piena)",
                      minimo=0, massimo=100),
            *proprieta_personalizzazione(),
            *proprieta_effetti(),
        ]
    return {p.nome: p for p in comuni}


#: Nomi delle proprieta' di personalizzazione comuni (bordo, angoli, ombra, sfumatura, stile del testo).
PROPRIETA_PERSONALIZZAZIONE = ("raggio_angoli", "colore_bordo", "spessore_bordo", "ombra", "colore_sfumatura",
                               "grassetto", "corsivo", "sottolineato")


def proprieta_personalizzazione() -> list[Proprieta]:
    """Personalizzazioni che hanno tutti i controlli visibili (non la Finestra, che ha le sue)."""
    return [
        Proprieta("raggio_angoli", "intero", -1, "Aspetto",
                  "Arrotondamento degli angoli in pixel (0 per angoli vivi); se non lo scegli, come il tema", minimo=-1, massimo=500),
        Proprieta("colore_bordo", "colore", "", "Aspetto", "Colore del bordo; se non lo scegli, nessun bordo in più"),
        Proprieta("spessore_bordo", "intero", 0, "Aspetto",
                  "Spessore del bordo in pixel; se non lo scegli e c'è un colore del bordo, 1 pixel", minimo=0, massimo=20),
        Proprieta("ombra", "logico", False, "Aspetto", "Ombra sotto il controllo"),
        Proprieta("colore_sfumatura", "colore", "", "Aspetto",
                  "Secondo colore dello sfondo: in alto il colore dello sfondo, in basso questo, con una sfumatura"),
        Proprieta("grassetto", "logico", False, "Aspetto", "Testo in grassetto"),
        Proprieta("corsivo", "logico", False, "Aspetto", "Testo in corsivo"),
        Proprieta("sottolineato", "logico", False, "Aspetto", "Testo sottolineato"),
    ]


# ---------------------------------------------------------------------------
# Effetti senza codice (gruppo "Effetti" del pannello): vedi ``leo.grafica.effetti``
# ---------------------------------------------------------------------------

#: Nomi delle proprieta' degli effetti (tutti i controlli visibili, non la Finestra).
PROPRIETA_EFFETTI = ("animazione_entrata", "ritardo_entrata", "durata_entrata", "effetto_continuo",
                     "velocità_effetto", "effetto_tocco")


def proprieta_effetti() -> list[Proprieta]:
    """Effetti e animazioni che si scelgono dal pannello, senza scrivere codice."""
    from . import effetti as ef

    return [
        Proprieta("animazione_entrata", "scelta", "nessuna", "Effetti",
                  "Come compare quando si apre la finestra o quando torna visibile "
                  "(dissolvenza, scorri su, zoom, rimbalzo, caduta...)",
                  scelte=ef.ENTRATE, sinonimi=dict(ef.SINONIMI_ENTRATE)),
        Proprieta("ritardo_entrata", "intero", 0, "Effetti",
                  "Millisecondi da aspettare prima dell'entrata (per farli entrare uno dopo l'altro)",
                  minimo=0, massimo=60000),
        Proprieta("durata_entrata", "intero", ef.DURATA_ENTRATA, "Effetti",
                  "Quanto dura l'entrata, in millisecondi (500 = mezzo secondo)", minimo=50, massimo=10000),
        Proprieta("effetto_continuo", "scelta", "nessuno", "Effetti",
                  "Effetto che si ripete sempre, finché il controllo si vede (pulsa, galleggia, ruota, battito...)",
                  scelte=ef.CONTINUI, sinonimi=dict(ef.SINONIMI_CONTINUI)),
        Proprieta("velocità_effetto", "scelta", "normale", "Effetti", "Velocità dell'effetto continuo",
                  scelte=ef.VELOCITA, sinonimi=dict(ef.SINONIMI_VELOCITA)),
        Proprieta("effetto_tocco", "scelta", "nessuno", "Effetti",
                  "Cosa fa quando lo tocchi o lo premi (rimbalzo, affonda, onda, brilla...)",
                  scelte=ef.TOCCHI, sinonimi=dict(ef.SINONIMI_TOCCHI)),
    ]


# ---------------------------------------------------------------------------
# Registro
# ---------------------------------------------------------------------------

CATALOGO: dict[str, TipoControllo] = {}
_catalogo_caricato = False


def registra(tipo: TipoControllo) -> TipoControllo:
    """Aggiunge un tipo al catalogo, completando le proprieta' comuni mancanti."""
    comuni = proprieta_comuni(invisibile=tipo.invisibile,
                              larghezza=tipo.dimensione_predefinita[0],
                              altezza=tipo.dimensione_predefinita[1])
    if "sfondo" in tipo.proprieta:  # la Finestra usa `sfondo` al posto di `colore_sfondo`
        comuni.pop("colore_sfondo", None)
        for k in PROPRIETA_PERSONALIZZAZIONE + PROPRIETA_EFFETTI:  # e ha le sue personalizzazioni (bordo,
            comuni.pop(k, None)                                    # forma, ombra) e le sue animazioni
    for k, p in comuni.items():
        tipo.proprieta.setdefault(k, p)
    if not tipo.invisibile and "clic" not in tipo.eventi:
        tipo.eventi = tuple(tipo.eventi) + ("clic",)
    if not tipo.invisibile:  # ogni controllo visibile (anche i nuovi) e la Finestra: leo.grafica.stili_oggetti
        tipo.proprieta.setdefault("stile", proprieta_stile(tipo.nome))
    if not tipo.invisibile and tipo.nome != "Finestra":
        for nome, metodo in METODI_ANIMAZIONE.items():
            tipo.metodi.setdefault(nome, metodo)
        _aggiungi_giochi(tipo)
    CATALOGO[tipo.nome] = tipo
    return tipo


# ---------------------------------------------------------------------------
# Stili pronti e animazioni (aggiunti da `registra`)
# ---------------------------------------------------------------------------

#: Controlli che, oltre agli stili degli oggetti, hanno gli stili "di significato"
#: (``principale``, ``pericolo``...: vedi ``temi_controlli.STILI_CONTROLLI``).
TIPI_CON_STILE = ("Pulsante", "PulsanteImmagine", "Etichetta")


def proprieta_stile(tipo: str = "") -> Proprieta:
    """La proprieta' ``stile`` di ogni controllo visibile e della Finestra.

    Scelte: ``"normale"`` (come la finestra) e gli stili di :mod:`leo.grafica.stili_oggetti`
    (``NOMI_STILI``: moderno, pillola, 3d, neon...); per
    :data:`TIPI_CON_STILE` anche gli stili di significato di ``temi_controlli``.
    """
    from . import stili_oggetti as so

    if tipo == "Finestra":
        return Proprieta("stile", "scelta", so.NORMALE, "Aspetto",
                         "Stile di tutti gli oggetti della finestra (" + ", ".join(so.NOMI_STILI)
                         + "); ogni oggetto può averne uno suo",
                         scelte=so.SCELTE, sinonimi=dict(so.SINONIMI))
    scelte: tuple[str, ...] = so.SCELTE
    sinonimi = dict(so.SINONIMI)
    if tipo in TIPI_CON_STILE:
        from .temi_controlli import SINONIMI_STILI, STILI_CONTROLLI

        scelte = scelte + tuple(s for s in STILI_CONTROLLI if s not in scelte)
        sinonimi.update(SINONIMI_STILI)
    return Proprieta("stile", "scelta", so.NORMALE, "Aspetto",
                     "Stile dell'oggetto: la forma (angoli, bordi, ombre, carattere, reazione al tocco); "
                     "il colore resta quello scelto. \"normale\" = come la finestra",
                     scelte=scelte, sinonimi=sinonimi)


# Metodi di animazione di ogni controllo visibile: `Pulsante1.scuoti()`,
# `Pulsante1.anima("alto", 50, 0.3)`. Il modulo della libreria si importa solo
# quando servono (Leo Studio carica il catalogo senza la libreria).

def _m_anima(controllo, proprieta, valore, durata=0.3, curva="morbida", poi=None):
    """Porta pian piano una proprieta' a un nuovo valore: `Pulsante1.anima("alto", 50, 0.3)`."""
    from ..libreria.animazioni import anima_controllo

    anima_controllo(controllo, proprieta, valore, durata, curva, poi)


def _m_lampeggia(controllo, volte=3, durata=0.3, poi=None):
    """Fa lampeggiare il controllo (`volte` lampi)."""
    from ..libreria.animazioni import effetto_controllo

    effetto_controllo("lampeggia", controllo, volte=volte, durata=durata, poi=poi)


def _m_scuoti(controllo, intensita=10, durata=0.45, poi=None):
    """Scuote il controllo a destra e a sinistra."""
    from ..libreria.animazioni import effetto_controllo

    effetto_controllo("scuoti", controllo, intensita=intensita, durata=durata, poi=poi)


def _m_dissolvi(controllo, durata=0.4, poi=None):
    """Fa sparire il controllo sfumandolo (alla fine `visibile` e' falso)."""
    from ..libreria.animazioni import effetto_controllo

    effetto_controllo("dissolvi", controllo, durata=durata, poi=poi)


def _m_compari(controllo, durata=0.4, poi=None):
    """Fa comparire il controllo sfumandolo."""
    from ..libreria.animazioni import effetto_controllo

    effetto_controllo("compari", controllo, durata=durata, poi=poi)


def _m_pulsa(controllo, volte=1, durata=0.45, poi=None):
    """Fa "battere" il controllo: si ingrandisce un poco e torna com'era."""
    from ..libreria.animazioni import effetto_controllo

    effetto_controllo("pulsa", controllo, volte=volte, durata=durata, poi=poi)


# --- effetti per chi comincia (vedi anche il gruppo "Effetti" del pannello) ---------------------

def _m_rimbalza(controllo, volte=1, durata=None, poi=None):
    """Fa saltellare il controllo come una palla (`volte` salti), poi torna al suo posto."""
    from ..libreria.animazioni import colpo_controllo

    colpo_controllo("rimbalza", controllo, volte=volte, durata=durata, poi=poi)


def _m_ruota(controllo, giri=1, durata=None, poi=None):
    """Fa girare il controllo su se stesso (`giri` giri interi; negativo = al contrario)."""
    from ..libreria.animazioni import colpo_controllo

    colpo_controllo("ruota", controllo, giri=giri, durata=durata, poi=poi)


def _m_capovolgi(controllo, durata=None, poi=None):
    """Gira il controllo come una carta da gioco e lo rimette dritto."""
    from ..libreria.animazioni import colpo_controllo

    colpo_controllo("capovolgi", controllo, durata=durata, poi=poi)


def _m_brilla(controllo, volte=1, durata=None, poi=None):
    """Fa brillare il controllo con un lampo di luce (`volte` lampi)."""
    from ..libreria.animazioni import colpo_controllo

    colpo_controllo("brilla", controllo, volte=volte, durata=durata, poi=poi)


def _m_dondola(controllo, volte=2, durata=None, poi=None):
    """Fa dondolare il controllo a destra e a sinistra, come chi dice di no con la testa."""
    from ..libreria.animazioni import colpo_controllo

    colpo_controllo("dondola", controllo, volte=volte, durata=durata, poi=poi)


def _m_trema(controllo, durata=None, poi=None):
    """Fa tremare il controllo per un attimo, come se avesse freddo (più fine di `scuoti`)."""
    from ..libreria.animazioni import colpo_controllo

    colpo_controllo("trema", controllo, durata=durata, poi=poi)


def _m_vola_a(controllo, x, y, durata=0.6, curva="morbida", poi=None):
    """Porta il controllo volando fino al punto (x, y) della finestra: `Palla.vola_a(20, 300)`."""
    from ..libreria.animazioni import vola_controllo

    vola_controllo(controllo, x, y, durata, curva, poi)


def _m_ingrandisci(controllo, fattore=1.2, durata=0.3, curva="morbida", poi=None):
    """Ingrandisce il controllo dal centro (1.5 = una volta e mezza; 0.5 = la metà); resta così."""
    from ..libreria.animazioni import ingrandisci_controllo

    ingrandisci_controllo(controllo, fattore, durata, curva, poi)


def _m_cambia_colore(controllo, colore, durata=0.5, poi=None):
    """Cambia pian piano il colore del testo: `Titolo.cambia_colore("rosso")`."""
    from ..libreria.animazioni import anima_controllo

    anima_controllo(controllo, "colore_testo", colore, durata, "morbida", poi)


def _m_cambia_sfondo(controllo, colore, durata=0.5, poi=None):
    """Cambia pian piano il colore dello sfondo: `Pulsante1.cambia_sfondo("#34C759")`."""
    from ..libreria.animazioni import anima_controllo

    anima_controllo(controllo, "colore_sfondo", colore, durata, "morbida", poi)


def _m_mostra_con(controllo, effetto="dissolvenza", durata=0.5, poi=None):
    """Fa comparire il controllo con un'animazione d'entrata (`"zoom"`, `"scorri_su"`, `"rimbalzo"`...)."""
    from ..libreria.animazioni import entrata_controllo

    entrata_controllo(controllo, effetto, durata, poi, mostra=True)


def _m_nascondi_con(controllo, effetto="dissolvenza", durata=0.5, poi=None):
    """Fa sparire il controllo con un'animazione (le stesse di `mostra_con`, al contrario)."""
    from ..libreria.animazioni import entrata_controllo

    entrata_controllo(controllo, effetto, durata, poi, mostra=False)


METODI_ANIMAZIONE: dict[str, MetodoControllo] = {
    "anima": _m_anima, "lampeggia": _m_lampeggia, "scuoti": _m_scuoti,
    "dissolvi": _m_dissolvi, "compari": _m_compari, "pulsa": _m_pulsa,
    "rimbalza": _m_rimbalza, "ruota": _m_ruota, "capovolgi": _m_capovolgi, "brilla": _m_brilla,
    "dondola": _m_dondola, "trema": _m_trema, "vola_a": _m_vola_a, "ingrandisci": _m_ingrandisci,
    "cambia_colore": _m_cambia_colore, "cambia_sfondo": _m_cambia_sfondo,
    "mostra_con": _m_mostra_con, "nascondi_con": _m_nascondi_con,
}


def _aggiungi_giochi(tipo: TipoControllo) -> None:
    """Dinamiche da gioco (proprieta' ``dinamiche``) e metodi ``salta``, ``spingi``... per ogni controllo visibile."""
    from .giochi.dinamiche import METODI_GIOCO, proprieta_dinamiche

    # gli eventi delle dinamiche (tocca, raccoglie...) valgono per tutti: vedi giochi.dinamiche.EVENTI_GIOCO
    tipo.proprieta.setdefault("dinamiche", proprieta_dinamiche())
    for nome, metodo in METODI_GIOCO.items():
        tipo.metodi.setdefault(nome, metodo)


def carica_catalogo() -> dict[str, TipoControllo]:
    global _catalogo_caricato
    if not _catalogo_caricato:
        _catalogo_caricato = True
        from . import catalogo_classici, catalogo_dante, catalogo_telefono  # noqa: F401 (si registrano)
        from . import catalogo_quotidiani  # noqa: F401 (scheda "Tutti i giorni")
        from . import catalogo_giochi  # noqa: F401 (oggetti da gioco, scheda "Giochi")
        from . import catalogo_dati_telefono  # noqa: F401 (dati, cruscotti e telefono)
    return CATALOGO


def tipo_controllo(nome: str) -> TipoControllo:
    """Metadati di un tipo di controllo; ErroreNome se sconosciuto."""
    carica_catalogo()
    t = CATALOGO.get(nome)
    if t is None:
        raise ErroreNome(f"Il tipo di controllo `{nome}` non esiste.", nome=nome)
    return t
