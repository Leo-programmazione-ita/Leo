"""Stili degli oggetti: la stessa scelta di "forma" per ogni controllo, sul telefono e sul PC.

Ogni controllo visibile ha la proprietà ``stile`` (la aggiunge da sola
:func:`leo.grafica.metadati.registra`, quindi anche i controlli nuovi la
ereditano); la Finestra ha ``stile`` per tutti i suoi oggetti. Uno stile decide
la FORMA (angoli, bordi, ombre, carattere, stati premuto/sopra/disattivato e la
micro-animazione al tocco); il COLORE resta quello scelto dall'utente
(``colore_sfondo`` dei pulsanti, altrimenti il colore principale dell'app), da
cui lo stile ricava le sfumature. Le personalizzazioni dell'utente
(``raggio_angoli``, ``colore_bordo``, ``ombra``...) vincono sempre sullo stile.

Questo modulo è il catalogo condiviso (nomi, titoli, descrizioni, sinonimi,
angoli, carattere, micro-animazione): il telefono lo riceve da
``strumenti/genera_stili_oggetti.py``, che lo scrive in
``android/app/src/main/assets/web/stili_oggetti.js`` (un test controlla che sia
aggiornato), così PC e telefono hanno gli stessi stili:

* telefono: ``stili_oggetti.css`` (regole ``.lf-c[data-lf-look="neon"]``) e
  ``stili_oggetti.js`` (tabella, colori leggibili, anteprima e pannello del disegnatore);
* PC (Qt): :func:`foglio_qss` e :func:`effetto_qt` di questo modulo, applicati da
  :mod:`leo.grafica.qt.stili_oggetti`;
* Leo Studio: l'anteprima nell'area di progettazione e le miniature del pannello
  (:mod:`leo.studio.qt.stili_oggetti_studio`, con :func:`colori`).

Nomi (``STILI_OGGETTI``): ``moderno``, ``pillola``, ``3d``, ``neon``, ``vetro``,
``cartone``, ``pixel``, ``carta``, ``minimale``, ``gioco``, ``elegante`` (Scuro
elegante), ``tecnico``;
``"normale"`` vuol dire "come la finestra" (per la Finestra: l'aspetto di
sempre). Da codice maiuscole, accenti e spazi non contano
(``Pulsante1.stile = "Neon"``, ``"tridimensionale"``, ``"8 bit"``...).

API::

    STILI_OGGETTI: tuple[StileOggetto, ...]      NOMI_STILI: tuple[str, ...]
    stile_oggetto(nome) -> StileOggetto          # ErroreValore se non c'è
    normalizza(nome) -> str | None               # nome canonico o None
    stile_effettivo(stile_controllo, stile_finestra) -> str | None
    genere_di(tipo) -> "pulsante" | "campo" | "spunta" | "interruttore" | "barra" | "cursore" | "testo"
                       | "contenitore" | "superficie"
    colori(nome, base, *, scuro=False, ...) -> dict      # colori derivati dal colore scelto
    foglio_qss(nome, genere, selettore, base, *, scuro=False, ...) -> str
    effetto_qt(nome, genere, base, *, scuro=False) -> dict | None   # ombra / bagliore
    tocco_di(nome) -> str                        # micro-animazione al tocco (un effetto_tocco)
    stili_per_js() -> list[dict]                 # la tabella di finestre.js / disegna.js
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from typing import Any

from ..errori import ErroreValore
from .metadati import semplifica_nome

# ===========================================================================
# Catalogo
# ===========================================================================


@dataclass(frozen=True)
class StileOggetto:
    nome: str                 # nome canonico ("neon")
    titolo: str               # nome da mostrare ("Neon")
    descrizione: str          # una riga, per il pannello e la galleria
    raggio: int               # angoli dei pulsanti (px)
    raggio_campi: int         # angoli di caselle ed elenchi (px)
    bordo: int                # spessore del contorno (px, 0 = niente)
    carattere: str            # famiglie del carattere, dalla preferita (CSS e Qt)
    peso: int                 # peso del testo dei pulsanti (400 normale, 700 grassetto, 900 nerissimo)
    maiuscole: bool           # testo dei pulsanti in maiuscolo
    tocco: str                # micro-animazione al tocco (un valore di ``effetto_tocco``)
    icona: str                # simbolo per le gallerie
    schiarisci: float = 0.0   # quanto bianco c'è nella parte più chiara del pulsante (per scegliere il testo)
    sempre_scuro: bool = False  # oggetti scuri anche con il tema chiaro (Scuro elegante)


#: Famiglie dei caratteri (dalla preferita; le ultime ci sono su tutti i sistemi).
CARATTERE_SISTEMA = '-apple-system, "Segoe UI Variable Text", "Segoe UI", Roboto, system-ui, sans-serif'
CARATTERE_ROTONDO = '"Nunito", "Varela Round", "Arial Rounded MT Bold", "Segoe UI Black", Roboto, system-ui, sans-serif'
CARATTERE_A_MANO = '"Segoe Print", "Bradley Hand", "Chalkboard SE", "Comic Neue", casual, "Comic Sans MS", cursive'
CARATTERE_PIXEL = '"Leo Pixel", "Press Start 2P", "Courier New", monospace'
CARATTERE_TECNICO = ('"JetBrains Mono", "Cascadia Code", "Cascadia Mono", "SF Mono", Menlo, Consolas, '
                     '"Roboto Mono", "DejaVu Sans Mono", monospace')
CARATTERE_GIOCO = '"Lilita One", "Luckiest Guy", "Arial Black", "Segoe UI Black", Roboto, system-ui, sans-serif'

STILI_OGGETTI: tuple[StileOggetto, ...] = (
    StileOggetto("moderno", "Moderno", "Pulito e morbido, con una luce leggera e un'ombra nel colore scelto",
                 12, 12, 0, CARATTERE_SISTEMA, 600, False, "affonda", "◐", 0.07),
    StileOggetto("pillola", "Pillola", "Angoli del tutto arrotondati e colori pieni",
                 999, 999, 0, CARATTERE_ROTONDO, 700, False, "rimbalzo", "⬭", 0.0),
    StileOggetto("3d", "3D", "In rilievo come un tasto fisico: premuto si abbassa",
                 12, 10, 0, CARATTERE_SISTEMA, 700, False, "affonda", "▰", 0.12),
    StileOggetto("neon", "Neon", "Contorni luminosi su fondo scuro, come un'insegna al neon",
                 12, 10, 2, CARATTERE_SISTEMA, 600, True, "brilla", "◈", 0.0),
    StileOggetto("vetro", "Vetro", "Trasparente e sfocato, come vetro smerigliato",
                 16, 14, 1, CARATTERE_SISTEMA, 600, False, "onda", "◇", 0.15),
    StileOggetto("cartone", "Cartone", "Contorni spessi, colori pieni e ombra netta, da illustrazione",
                 16, 14, 3, CARATTERE_ROTONDO, 800, False, "rimbalzo", "◉", 0.0),
    StileOggetto("pixel", "Pixel", "Griglia di pixel e carattere a 8 bit, in stile retrò",
                 0, 0, 4, CARATTERE_PIXEL, 400, True, "affonda", "▦", 0.0),
    StileOggetto("carta", "Carta", "Tratto disegnato a mano su carta, con un'ombra morbida",
                 6, 6, 2, CARATTERE_A_MANO, 700, False, "affonda", "▤", 0.0),
    StileOggetto("minimale", "Minimale", "Solo l'essenziale: linee sottili e niente ombre",
                 8, 0, 1, CARATTERE_SISTEMA, 500, False, "onda", "—", 0.0),
    StileOggetto("gioco", "Gioco", "Pulsanti grandi e lucidi da interfaccia di gioco, con rimbalzo al tocco",
                 18, 12, 3, CARATTERE_GIOCO, 900, True, "rimbalzo", "▶", 0.2),
    StileOggetto("elegante", "Scuro elegante", "Superfici nere opache, linee sottili e il colore scelto come filo di luce",
                 10, 10, 1, CARATTERE_SISTEMA, 500, True, "onda", "◆", 0.0, True),
    StileOggetto("tecnico", "Tecnico", "Carattere a spaziatura fissa, angoli vivi e linee nette, come una console",
                 4, 2, 1, CARATTERE_TECNICO, 600, True, "affonda", "▭", 0.0),
)

NOMI_STILI: tuple[str, ...] = tuple(s.nome for s in STILI_OGGETTI)
#: "come la finestra" (per la Finestra: l'aspetto normale del tema).
NORMALE = "normale"
#: Scelte della proprietà ``stile`` della Finestra (e parte di quelle dei controlli).
SCELTE: tuple[str, ...] = (NORMALE,) + NOMI_STILI

_PER_NOME = {s.nome: s for s in STILI_OGGETTI}

#: Altri nomi accettati dal codice (chiavi "semplificate", con ``_`` al posto degli spazi).
SINONIMI: dict[str, str] = {
    "moderna": "moderno", "attuale": "moderno", "morbido": "moderno",
    "pillole": "pillola", "tondo": "pillola", "rotondo": "pillola", "capsula": "pillola", "arrotondato": "pillola",
    "scuro_elegante": "elegante", "scuro": "elegante", "nero": "elegante", "lusso": "elegante", "raffinato": "elegante",
    "elegante_scuro": "elegante",
    "tridimensionale": "3d", "tre_d": "3d", "3_d": "3d", "rilievo": "3d", "in_rilievo": "3d", "tasto": "3d",
    "tasti": "3d",
    "luminoso": "neon", "luce": "neon", "fluo": "neon", "fosforescente": "neon", "insegna": "neon", "notte": "neon",
    "glass": "vetro", "vetroso": "vetro", "smerigliato": "vetro", "vetro_smerigliato": "vetro", "cristallo": "vetro",
    "cartoon": "cartone", "cartoni": "cartone", "cartone_animato": "cartone", "cartoni_animati": "cartone",
    "fumetto": "cartone", "fumetti": "cartone",
    "8_bit": "pixel", "8bit": "pixel", "otto_bit": "pixel", "retro": "pixel", "pixelato": "pixel", "pixels": "pixel",
    "fatto_a_mano": "carta", "a_mano": "carta", "foglio": "carta", "disegnato": "carta", "carta_e_matita": "carta",
    "minimal": "minimale", "minimalista": "minimale", "essenziale": "minimale", "semplice": "minimale",
    "pulito": "minimale", "sottile": "minimale",
    "videogioco": "gioco", "videogiochi": "gioco", "videogame": "gioco", "giochi": "gioco", "arcade": "gioco",
    "lucido": "gioco",
    "console": "tecnico", "terminale": "tecnico", "monospazio": "tecnico", "codice": "tecnico",
    "tecnica": "tecnico", "programmatore": "tecnico",
    "nessuno": NORMALE, "predefinito": NORMALE, "standard": NORMALE, "come_la_finestra": NORMALE,
    "automatico": NORMALE,
}


def normalizza(nome: Any) -> str | None:
    """Nome canonico (``"Neon"`` -> ``"neon"``, ``"8 bit"`` -> ``"pixel"``, ``""`` -> ``"normale"``) o None."""
    if not isinstance(nome, str):
        return None
    chiave = semplifica_nome(nome).replace("-", " ").replace("'", " ")
    chiave = "_".join(chiave.split())
    if chiave == "":
        return NORMALE
    if chiave in SCELTE:
        return chiave
    return SINONIMI.get(chiave)


def stile_oggetto(nome: Any) -> StileOggetto:
    """Lo stile col nome dato (anche un sinonimo); ErroreValore se non esiste (o se è "normale")."""
    canonico = normalizza(nome)
    if canonico in _PER_NOME:
        return _PER_NOME[canonico]
    raise ErroreValore(f"Lo stile `{nome}` non esiste.",
                       suggerimento="Stili: " + ", ".join(f'"{s}"' for s in NOMI_STILI) + ".")


def stile_effettivo(stile_controllo: Any, stile_finestra: Any = None) -> str | None:
    """Lo stile con cui si disegna un controllo (None = aspetto normale del tema).

    Uno stile proprio del controllo vince; con ``"normale"`` (o uno stile "di significato" come
    ``"principale"`` o ``"pericolo"``, che sceglie solo il colore) vale lo stile della finestra.
    """
    proprio = normalizza(stile_controllo) if isinstance(stile_controllo, str) else None
    if proprio in _PER_NOME:
        return proprio
    finestra = normalizza(stile_finestra) if isinstance(stile_finestra, str) else None
    return finestra if finestra in _PER_NOME else None


def tocco_di(nome: Any) -> str:
    """Micro-animazione al tocco dello stile (``"nessuno"`` se lo stile non c'è)."""
    s = _PER_NOME.get(normalizza(nome) or "")
    return s.tocco if s is not None else "nessuno"


# ===========================================================================
# Generi di controllo (che parte disegna lo stile)
# ===========================================================================

_GENERI: dict[str, tuple[str, ...]] = {
    "pulsante": ("Pulsante", "PulsanteImmagine", "PulsanteFisico", "SelettoreColore", "BarraStrumenti"),
    "campo": ("CasellaTesto", "CasellaPassword", "CasellaNumero", "AreaTesto", "MenuATendina", "Elenco", "Tabella",
              "Albero", "SelettoreData", "CasellaCodiceFiscale", "CasellaIBAN", "CasellaTarga", "CasellaImporto",
              "SelettoreComune", "Registro", "EditorCodice", "Terminale"),
    "spunta": ("CasellaSpunta", "Scelta"),
    "interruttore": ("Interruttore",),
    "barra": ("BarraAvanzamento", "MisuratorePassword"),
    "cursore": ("Cursore",),
    "testo": ("Etichetta", "Collegamento", "BarraStato", "ContoAllaRovescia", "Punteggio"),
    "contenitore": ("Riquadro", "Schede", "PannelloScorrevole", "Divisore", "Scena"),
}
GENERI: tuple[str, ...] = tuple(_GENERI) + ("superficie",)
_GENERE_DI = {tipo: genere for genere, tipi in _GENERI.items() for tipo in tipi}


def genere_di(tipo: str) -> str:
    """Che cosa dello stile vale per un tipo di controllo; ``"superficie"`` per tutti gli altri
    (anche i controlli nuovi): carattere, angoli, contorno e ombra del riquadro."""
    return _GENERE_DI.get(str(tipo or ""), "superficie")


# ===========================================================================
# Colori derivati dal colore scelto
# ===========================================================================

_ESA = re.compile(r"#?([0-9A-Fa-f]{6})([0-9A-Fa-f]{2})?")


def _rgb(colore: str) -> tuple[int, int, int]:
    m = _ESA.fullmatch(str(colore or "").strip())
    if not m:
        return (224, 24, 45)
    h = m.group(1)
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def _esa(r: float, g: float, b: float) -> str:
    # arrotondamento "mezzo in su" come Math.round di stili_oggetti.js (round() di Python va al pari)
    return "#" + "".join(f"{max(0, min(255, int(math.floor(v + 0.5)))):02X}" for v in (r, g, b))


def mescola(a: str, b: str, quanto: float) -> str:
    """Colore tra ``a`` (0) e ``b`` (1)."""
    ra, ga, ba = _rgb(a)
    rb, gb, bb = _rgb(b)
    q = max(0.0, min(1.0, float(quanto)))
    return _esa(ra + (rb - ra) * q, ga + (gb - ga) * q, ba + (bb - ba) * q)


def con_alfa(colore: str, alfa: float) -> str:
    """``#RRGGBBAA`` con opacità ``alfa`` (0..1)."""
    r, g, b = _rgb(colore)
    return _esa(r, g, b) + f"{max(0, min(255, int(round(alfa * 255)))):02X}"


def luminanza(colore: str) -> float:
    def lin(v: int) -> float:
        s = v / 255.0
        return s / 12.92 if s <= 0.04045 else ((s + 0.055) / 1.055) ** 2.4

    r, g, b = _rgb(colore)
    return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)


def contrasto(a: str, b: str) -> float:
    la, lb = luminanza(a), luminanza(b)
    return (max(la, lb) + 0.05) / (min(la, lb) + 0.05)


def testo_su(fondo: str, *altri: str) -> str:
    """Bianco o quasi nero: quello che si legge meglio sul fondo (come ``--lf-k-testo`` sul telefono).

    Con più fondi (le due estremità di una sfumatura) sceglie quello col contrasto minimo più alto.
    """
    fondi = (fondo,) + altri
    bianco = min(contrasto("#FFFFFF", f) for f in fondi)
    nero = min(contrasto("#16161A", f) for f in fondi)
    return "#FFFFFF" if bianco >= nero else "#16161A"


#: Contrasto minimo tra testo e fondo (WCAG AA per il testo normale).
CONTRASTO_MINIMO = 4.5


def base_leggibile(colore: str, schiarisci: float = 0.0, minimo: float = CONTRASTO_MINIMO) -> tuple[str, str]:
    """Il colore scelto (appena scurito o schiarito se serve) e il testo da metterci sopra.

    Il testo (bianco o quasi nero) deve leggersi sia sul colore sia sulla sua versione schiarita
    di ``schiarisci`` (la luce degli stili lucidi); se non basta, il colore si scurisce (o si
    schiarisce, per il testo nero) a piccoli passi finché il contrasto arriva a ``minimo``.
    Stessa regola in stili_oggetti.js (``baseLeggibile``).
    """
    k = _esa(*_rgb(colore))
    migliore = (0.0, k, testo_su(k))
    for verso in ("#000000", "#FFFFFF"):    # prima si prova a scurire (il testo bianco resta)
        for passo in range(0, 21):
            prova = mescola(k, verso, passo * 0.02)
            chiaro = mescola(prova, "#FFFFFF", schiarisci)
            testo = testo_su(prova, chiaro)
            valore = min(contrasto(testo, prova), contrasto(testo, chiaro))
            if valore >= minimo:
                return prova, testo
            if valore > migliore[0]:
                migliore = (valore, prova, testo)
    return migliore[1], migliore[2]


def leggibile(colore: str, fondo: str, minimo: float = 4.5) -> str:
    """``colore`` schiarito o scurito quanto basta per leggersi su ``fondo`` (contrasto >= ``minimo``)."""
    verso = "#FFFFFF" if luminanza(fondo) < 0.18 else "#000000"
    for passo in range(0, 21):
        prova = mescola(colore, verso, passo / 20)
        if contrasto(prova, fondo) >= minimo:
            return prova
    return verso


#: Colori fissi degli stili (inchiostro, carta, console).
CONSOLE = {"campo": "#0D0F12", "testo": "#E6E8EB", "bordo": "#2F343B", "testa": "#15181C"}
INCHIOSTRO = "#1B1B1F"
CARTA = {"chiaro": "#FFFCF3", "scuro": "#2A2622", "inchiostro": "#3B3024"}


def colori(nome: Any, base: str = "#E0182D", *, scuro: bool = False, colore_testo: str = "",
           colore_sfondo: str = "") -> dict[str, str]:
    """Colori di uno stile ricavati dal colore scelto (``base``).

    Chiavi: ``fondo``/``fondo_2`` (pulsante, dall'alto al basso), ``sopra``, ``premuto``,
    ``testo`` (sul pulsante), ``bordo``, ``bordo_2`` (bordo inferiore / rilievo), ``campo``,
    ``testo_campo``, ``bordo_campo``, ``fuoco``, ``traccia`` (binari e barre vuote), ``pieno``
    (la parte piena di barre, cursori e spunte), ``etichetta`` (colore dei testi),
    ``ombra`` e ``bagliore`` (per gli effetti), ``disattivato``. ``colore_testo`` e
    ``colore_sfondo`` dell'utente vincono: il fondo dei campi resta il suo, il testo pure.
    """
    s = _PER_NOME.get(normalizza(nome) or "")
    k, testo_k = base_leggibile(base, s.schiarisci if s is not None else 0.0)
    nome = s.nome if s is not None else "moderno"
    bianco, nero = "#FFFFFF", "#000000"
    fondo_finestra = "#0B0B0D" if scuro else "#F2F2F7"
    testo_base = "#F5F5F7" if scuro else "#1D1D1F"
    c: dict[str, str] = {
        "fondo": k, "fondo_2": k, "sopra": mescola(k, bianco if scuro else nero, 0.08),
        "premuto": mescola(k, nero, 0.18), "testo": testo_k, "bordo": k, "bordo_2": mescola(k, nero, 0.3),
        "campo": "#1C1C1F" if scuro else "#FFFFFF", "testo_campo": testo_base,
        "bordo_campo": mescola(fondo_finestra, testo_base, 0.22), "fuoco": k,
        "traccia": "#3A3A40" if scuro else "#E3E3E8", "pieno": k, "etichetta": testo_base,
        "ombra": con_alfa(k, 0.45), "bagliore": "", "disattivato": mescola(k, fondo_finestra, 0.55),
    }
    if nome == "moderno":
        c["fondo"] = mescola(k, bianco, 0.14)
        c["ombra"] = con_alfa(k, 0.40)
    elif nome == "pillola":
        c.update(fondo=k, fondo_2=k, sopra=mescola(k, bianco, 0.1), premuto=mescola(k, nero, 0.14),
                 ombra=con_alfa(k, 0.38), bordo_campo=mescola(fondo_finestra, testo_base, 0.16),
                 campo="#1C1C1F" if scuro else "#FFFFFF", traccia="#3A3A40" if scuro else "#E6E6EC")
    elif nome == "elegante":
        superficie, superficie_2 = "#1B1B20", "#101013"
        luce = leggibile(mescola(k, bianco, 0.35), superficie, 4.5)
        c.update(fondo=superficie, fondo_2=superficie_2, sopra="#24242A", premuto="#0B0B0D", testo=luce,
                 bordo=con_alfa(bianco, 0.14), bordo_2=k, campo="#141417", testo_campo="#EDEDF0",
                 bordo_campo="#34343C", fuoco=k, traccia="#2A2A30", pieno=k,
                 etichetta=testo_base, ombra=con_alfa(nero, 0.45), disattivato="#2A2A2E")
    elif nome == "3d":
        c["fondo"] = mescola(k, bianco, 0.16)
        c["bordo"] = mescola(k, nero, 0.12)
        c["bordo_2"] = mescola(k, nero, 0.38)
        c["premuto"] = mescola(k, nero, 0.08)
        c["campo"] = "#17171A" if scuro else "#FBFBFD"
        c["ombra"] = con_alfa(nero, 0.30)
    elif nome == "neon":
        luce = mescola(k, bianco, 0.55)
        c.update(fondo=mescola(k, "#05050A", 0.86), fondo_2=mescola(k, "#05050A", 0.93), testo=luce,
                 sopra=mescola(k, "#05050A", 0.76), premuto=mescola(k, "#05050A", 0.62), bordo=mescola(k, bianco, 0.15),
                 campo="#07070D", testo_campo=mescola(k, bianco, 0.78), bordo_campo=k, pieno=mescola(k, bianco, 0.1),
                 traccia=mescola(k, "#05050A", 0.75), etichetta=mescola(k, bianco, 0.45) if scuro else mescola(k, nero, 0.25),
                 bagliore=k, ombra=con_alfa(k, 0.85))
    elif nome == "vetro":
        c.update(fondo=con_alfa(mescola(k, bianco, 0.18), 0.62), fondo_2=con_alfa(k, 0.55),
                 sopra=con_alfa(mescola(k, bianco, 0.25), 0.70), premuto=con_alfa(k, 0.78),
                 bordo=con_alfa(bianco, 0.55), bordo_2=con_alfa(bianco, 0.15),
                 campo=con_alfa(bianco, 0.10) if scuro else con_alfa(bianco, 0.55),
                 bordo_campo=con_alfa(bianco, 0.28) if scuro else con_alfa(bianco, 0.85),
                 traccia=con_alfa(bianco, 0.18) if scuro else con_alfa(nero, 0.10), ombra=con_alfa(nero, 0.22))
        c["testo"] = testo_su(mescola(k, fondo_finestra, 0.3))
    elif nome == "cartone":
        inchiostro = nero if scuro else INCHIOSTRO
        c.update(bordo=inchiostro, bordo_2=inchiostro, campo="#2A2A31" if scuro else bianco,
                 bordo_campo=inchiostro, traccia="#3A3A42" if scuro else "#EDEDF2", ombra=con_alfa(inchiostro, 1.0),
                 sopra=mescola(k, bianco, 0.1))
    elif nome == "pixel":
        c.update(bordo="#000000" if scuro else "#111111", fondo_2=mescola(k, nero, 0.1),
                 sopra=mescola(k, bianco, 0.12), premuto=mescola(k, nero, 0.2),
                 bordo_2=mescola(k, nero, 0.35), campo="#101018" if scuro else bianco,
                 bordo_campo="#000000" if scuro else "#111111", traccia="#2A2A36" if scuro else "#D7D7DE",
                 ombra=con_alfa(nero, 0.9))
    elif nome == "carta":
        fondo = mescola(k, CARTA["chiaro"], 0.22)
        c.update(fondo=fondo, fondo_2=mescola(k, CARTA["chiaro"], 0.1), testo=testo_su(fondo),
                 bordo=mescola(k, CARTA["inchiostro"], 0.55), bordo_2=mescola(k, CARTA["inchiostro"], 0.55),
                 campo=CARTA["scuro"] if scuro else CARTA["chiaro"],
                 testo_campo="#EDE6D8" if scuro else CARTA["inchiostro"],
                 bordo_campo="#8C7F6C" if scuro else "#5A4C3A", traccia="#4A433B" if scuro else "#E7DFCD",
                 etichetta="#EDE6D8" if scuro else CARTA["inchiostro"], ombra=con_alfa("#3C2814", 0.35))
    elif nome == "minimale":
        c.update(fondo=k, fondo_2=k, bordo=k, campo="transparent" if not colore_sfondo else colore_sfondo,
                 bordo_campo=mescola(fondo_finestra, testo_base, 0.35), traccia=mescola(fondo_finestra, testo_base, 0.15),
                 ombra="")
    elif nome == "gioco":
        c.update(fondo=mescola(k, bianco, 0.32), fondo_2=mescola(k, nero, 0.12), sopra=mescola(k, bianco, 0.4),
                 premuto=mescola(k, nero, 0.2), bordo=mescola(k, nero, 0.45), bordo_2=mescola(k, nero, 0.55),
                 campo="#15151C" if scuro else "#FFFFFF", bordo_campo=mescola(k, nero, 0.45),
                 traccia="#2B2B35" if scuro else "#DADAE3", ombra=con_alfa(nero, 0.35))
        c["testo"] = testo_su(c["fondo"], c["fondo_2"])
    elif nome == "tecnico":
        c.update(fondo=mescola(k, bianco, 0.08), fondo_2=k, bordo=mescola(k, nero, 0.3), bordo_2=mescola(k, nero, 0.3),
                 campo=CONSOLE["campo"] if scuro else bianco, testo_campo=CONSOLE["testo"] if scuro else testo_base,
                 bordo_campo=CONSOLE["bordo"] if scuro else mescola(fondo_finestra, testo_base, 0.32),
                 traccia=CONSOLE["testa"] if scuro else "#DEDFE3", ombra="")
    # contrasto: i testi scelti dallo stile si devono leggere (quelli dell'utente restano i suoi)
    if len(c["fondo"]) == 7 and len(c["fondo_2"]) == 7:
        sotto = mescola(c["fondo"], c["fondo_2"], 0.5)          # il colore sotto il testo
        if contrasto(c["testo"], sotto) < CONTRASTO_MINIMO:
            c["testo"] = testo_su(sotto)
        verso = "#000000" if c["testo"] == "#FFFFFF" else "#FFFFFF"
        for _ in range(12):
            if contrasto(c["testo"], sotto) >= CONTRASTO_MINIMO:
                break
            c["fondo"], c["fondo_2"] = mescola(c["fondo"], verso, 0.05), mescola(c["fondo_2"], verso, 0.05)
            sotto = mescola(c["fondo"], c["fondo_2"], 0.5)
        c["sotto_testo"] = sotto
    c["etichetta"] = leggibile(c["etichetta"], fondo_finestra)
    if len(c["campo"]) == 7:
        c["testo_campo"] = leggibile(c["testo_campo"], c["campo"])
    c["k"] = k
    if colore_sfondo and nome != "minimale":
        c["campo"] = colore_sfondo
        c["testo_campo"] = testo_su(colore_sfondo) if len(colore_sfondo) in (7, 9) else c["testo_campo"]
    if colore_testo:
        c["testo"] = c["testo_campo"] = c["etichetta"] = colore_testo
    return c


# ===========================================================================
# Qt: fogli di stile ed effetti
# ===========================================================================

def _q(colore: str) -> str:
    """``#RRGGBB[AA]`` -> colore per i fogli di stile Qt (``rgba(...)`` se c'è l'alfa)."""
    if colore == "transparent":
        return "transparent"
    m = _ESA.fullmatch(str(colore or ""))
    if not m:
        return colore
    r, g, b = _rgb(colore)
    if m.group(2):
        return f"rgba({r}, {g}, {b}, {int(m.group(2), 16)})"
    return f"#{m.group(1).upper()}"


def famiglie_qt(carattere: str) -> str:
    """Le famiglie CSS nella forma dei fogli di stile Qt (senza le parole generiche che Qt non conosce)."""
    parti = [p.strip() for p in carattere.split(",") if p.strip()]
    tenute = [p if p.startswith('"') else f'"{p}"' for p in parti
              if p.strip('"') not in ("-apple-system", "system-ui", "casual", "cursive", "sans-serif", "monospace")]
    return ", ".join(tenute) or '"Segoe UI"'


def _gradiente(alto: str, basso: str) -> str:
    if alto == basso:
        return _q(alto)
    return f"qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 {_q(alto)}, stop:1 {_q(basso)})"


def foglio_qss(nome: Any, genere: str, selettore: str, base: str = "#E0182D", *, scuro: bool = False,
               colore_testo: str = "", colore_sfondo: str = "", altezza: int = 0) -> str:
    """Foglio di stile Qt di un controllo con lo stile ``nome`` ("" se lo stile non c'è).

    ``selettore`` è il selettore del widget (di solito ``#Pulsante1``); ``genere`` viene da
    :func:`genere_di` (o dalla classe del widget). Stati ``:hover``, ``:pressed``,
    ``:disabled`` e ``:focus`` come sul telefono; la sfocatura del vetro Qt non la sa fare:
    diventa un fondo semitrasparente con un riflesso chiaro.
    """
    s = _PER_NOME.get(normalizza(nome) or "")
    if s is None:
        return ""
    fondo_pulsante = colore_sfondo if genere == "pulsante" and colore_sfondo else base
    c = colori(s.nome, fondo_pulsante if len(str(fondo_pulsante)) == 7 else base, scuro=scuro,
               colore_testo=colore_testo, colore_sfondo=colore_sfondo if genere != "pulsante" else "")
    n = selettore
    font = f"font-family: {famiglie_qt(s.carattere)};"
    maiuscole = ""   # QSS non ha text-transform: il maiuscolo lo fa widget.py sul testo mostrato
    bordo = max(0, s.bordo)
    r, rc = s.raggio, s.raggio_campi
    if r >= 999 or rc >= 999:           # Pillola: metà dell'altezza (Qt non accetta angoli più grandi)
        mezzo = max(4, int(altezza) // 2) if altezza else 18
        r, rc = (mezzo if r >= 999 else r), (mezzo if rc >= 999 else rc)
    regole: list[str] = []
    if genere == "pulsante":
        alto, basso = c["fondo"], c["fondo_2"]
        if s.nome == "3d":
            giu = f"border-bottom: 5px solid {_q(c['bordo_2'])};"
            regole += [f"{n} {{ {font} font-weight: {s.peso}; color: {_q(c['testo'])}; background: {_gradiente(alto, basso)}; "
                       f"border: 1px solid {_q(c['bordo'])}; {giu} border-radius: {r}px; padding: 4px 14px 2px 14px; }}",
                       f"{n}:hover {{ background: {_gradiente(mescola(alto, '#FFFFFF', 0.08), basso)}; }}",
                       f"{n}:pressed {{ background: {_q(c['premuto'])}; border-bottom-width: 1px; "
                       f"margin-top: 4px; padding-top: 4px; }}"]
        elif s.nome == "pillola":
            regole += [f"{n} {{ {font} font-weight: {s.peso}; color: {_q(c['testo'])}; background: {_q(alto)}; "
                       f"border: none; border-radius: {r}px; padding: 4px 18px; }}",
                       f"{n}:hover {{ background: {_q(c['sopra'])}; }}",
                       f"{n}:pressed {{ background: {_q(c['premuto'])}; padding-top: 6px; }}"]
        elif s.nome == "elegante":
            regole += [f"{n} {{ {font} font-weight: {s.peso}; color: {_q(c['testo'])}; background: {_gradiente(alto, basso)}; "
                       f"border: 1px solid {_q(c['bordo'])}; border-bottom: 2px solid {_q(c['bordo_2'])}; "
                       f"border-radius: {r}px; padding: 4px 16px; }}",
                       f"{n}:hover {{ background: {_q(c['sopra'])}; border-color: {_q(c['bordo_2'])}; }}",
                       f"{n}:pressed {{ background: {_q(c['premuto'])}; }}"]
        elif s.nome == "neon":
            regole += [f"{n} {{ {font} font-weight: {s.peso}; color: {_q(c['testo'])}; background: {_gradiente(alto, basso)}; "
                       f"border: {bordo}px solid {_q(c['bordo'])}; border-radius: {r}px; padding: 4px 14px; }}",
                       f"{n}:hover {{ background: {_q(c['sopra'])}; color: #FFFFFF; }}",
                       f"{n}:pressed {{ background: {_q(c['premuto'])}; color: #FFFFFF; border-color: #FFFFFF; }}"]
        elif s.nome == "vetro":
            riflesso = (f"qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 {_q(con_alfa('#FFFFFF', 0.55))}, "
                        f"stop:0.5 {_q(alto)}, stop:1 {_q(basso)})")
            regole += [f"{n} {{ {font} font-weight: {s.peso}; color: {_q(c['testo'])}; background: {riflesso}; "
                       f"border: 1px solid {_q(c['bordo'])}; border-bottom-color: {_q(c['bordo_2'])}; "
                       f"border-radius: {r}px; padding: 4px 14px; }}",
                       f"{n}:hover {{ background: {_q(c['sopra'])}; }}",
                       f"{n}:pressed {{ background: {_q(c['premuto'])}; }}"]
        elif s.nome == "cartone":
            regole += [f"{n} {{ {font} font-weight: {s.peso}; color: {_q(c['testo'])}; background: {_q(alto)}; "
                       f"border: {bordo}px solid {_q(c['bordo'])}; border-radius: {r}px; padding: 3px 14px; }}",
                       f"{n}:hover {{ background: {_q(c['sopra'])}; }}",
                       f"{n}:pressed {{ background: {_q(c['premuto'])}; margin: 2px 0 0 2px; }}"]
        elif s.nome == "pixel":
            regole += [f"{n} {{ {font} color: {_q(c['testo'])}; background: {_q(alto)}; border: {bordo}px solid {_q(c['bordo'])}; "
                       f"border-right-color: {_q(c['bordo'])}; border-radius: 0px; padding: 3px 12px; }}",
                       f"{n}:hover {{ background: {_q(c['sopra'])}; }}",
                       f"{n}:pressed {{ background: {_q(c['premuto'])}; padding-top: 5px; padding-bottom: 1px; }}"]
        elif s.nome == "carta":
            regole += [f"{n} {{ {font} font-weight: {s.peso}; color: {_q(c['testo'])}; background: {_gradiente(alto, basso)}; "
                       f"border: {bordo}px solid {_q(c['bordo'])}; border-top-left-radius: {r + 8}px; "
                       f"border-top-right-radius: {max(2, r - 3)}px; border-bottom-right-radius: {r + 6}px; "
                       f"border-bottom-left-radius: {max(2, r - 2)}px; padding: 4px 14px; }}",
                       f"{n}:hover {{ background: {_q(c['sopra'])}; }}",
                       f"{n}:pressed {{ background: {_q(c['premuto'])}; padding-top: 6px; }}"]
        elif s.nome == "minimale":
            regole += [f"{n} {{ {font} font-weight: {s.peso}; color: {_q(c['testo'])}; background: {_q(alto)}; "
                       f"border: none; border-radius: {r}px; padding: 4px 14px; }}",
                       f"{n}:hover {{ background: {_q(c['sopra'])}; }}",
                       f"{n}:pressed {{ background: {_q(c['premuto'])}; }}"]
        elif s.nome == "gioco":
            lucido = (f"qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 {_q(mescola(alto, '#FFFFFF', 0.35))}, "
                      f"stop:0.48 {_q(alto)}, stop:0.52 {_q(base)}, stop:1 {_q(basso)})")
            regole += [f"{n} {{ {font} font-weight: {s.peso}; color: {_q(c['testo'])}; background: {lucido}; "
                       f"border: {bordo}px solid {_q(c['bordo'])}; border-bottom-width: 6px; "
                       f"border-radius: {r}px; padding: 4px 16px 2px 16px; }}",
                       f"{n}:hover {{ background: {_gradiente(c['sopra'], basso)}; }}",
                       f"{n}:pressed {{ background: {_gradiente(base, c['premuto'])}; border-bottom-width: {bordo}px; "
                       f"margin-top: 3px; }}"]
        elif s.nome == "tecnico":
            regole += [f"{n} {{ {font} font-weight: {s.peso}; color: {_q(c['testo'])}; background: {_gradiente(alto, basso)}; "
                       f"border: {bordo}px solid {_q(c['bordo'])}; border-radius: {r}px; padding: 4px 14px; "
                       f"letter-spacing: 1px; }}",
                       f"{n}:hover {{ background: {_q(c['sopra'])}; }}",
                       f"{n}:pressed {{ background: {_q(c['premuto'])}; }}"]
        else:  # moderno
            regole += [f"{n} {{ {font} font-weight: {s.peso}; color: {_q(c['testo'])}; background: {_gradiente(alto, basso)}; "
                       f"border: none; border-radius: {r}px; padding: 4px 14px; }}",
                       f"{n}:hover {{ background: {_gradiente(c['sopra'], basso)}; }}",
                       f"{n}:pressed {{ background: {_q(c['premuto'])}; }}"]
        regole.append(f"{n}:disabled {{ background: {_q(c['disattivato'])}; color: {_q(con_alfa(c['testo'], 0.6))}; }}")
        regole.append(f"{n}:focus {{ outline: none; }}")
    elif genere in ("campo", "spunta", "interruttore", "barra", "cursore"):
        stile_bordo = "solid"
        spessore = 1 if s.nome in ("moderno", "3d", "vetro", "neon", "pillola", "elegante") else max(1, bordo)
        if s.nome == "pixel":
            spessore = 3
        campo = (f"{n} {{ {font} color: {_q(c['testo_campo'])}; background: {_q(c['campo'])}; "
                 f"selection-background-color: {_q(con_alfa(base, 0.35))}; ")
        if s.nome == "minimale":
            campo += (f"border: none; border-bottom: 1px solid {_q(c['bordo_campo'])}; border-radius: 0px; "
                      f"padding: 2px 2px; }}")
            fuoco = f"{n}:focus {{ border-bottom: 2px solid {_q(c['fuoco'])}; }}"
        else:
            campo += (f"border: {spessore}px {stile_bordo} {_q(c['bordo_campo'])}; border-radius: {rc}px; "
                      f"padding: 2px 8px; }}")
            fuoco = f"{n}:focus {{ border-color: {_q(c['fuoco'])}; }}"
        if genere == "campo":
            regole += [campo, fuoco,
                       f"{n}:disabled {{ color: {_q(con_alfa(c['testo_campo'], 0.5))}; }}",
                       f"{n}::drop-down {{ border: none; width: 22px; }}",
                       f"{n} QHeaderView::section {{ {font} background: {_q(c['traccia'])}; color: {_q(c['testo_campo'])}; "
                       f"border: none; padding: 4px; }}",
                       f"{n}::item:selected {{ background: {_q(con_alfa(base, 0.30))}; color: {_q(c['testo_campo'])}; }}"]
        indicatore_raggio = {"spunta": max(0, min(rc, 7)), "interruttore": 3 if s.nome == "tecnico" else 9}.get(genere, 4)
        if genere in ("spunta", "interruttore"):
            tondo = "radio" in n.lower()
            regole += [f"{n} {{ {font} color: {_q(c['etichetta'])}; spacing: 8px; }}",
                       f"{n}::indicator {{ width: 18px; height: 18px; background: {_q(c['campo'])}; "
                       f"border: {max(1, min(spessore, 3))}px solid {_q(c['bordo_campo'])}; "
                       f"border-radius: {9 if tondo else indicatore_raggio}px; }}",
                       f"{n}::indicator:checked {{ background: {_q(c['pieno'])}; border-color: {_q(c['bordo'] if s.nome in ('cartone', 'pixel', 'gioco') else c['pieno'])}; }}",
                       f"{n}::indicator:hover {{ border-color: {_q(c['fuoco'])}; }}"]
        if genere == "barra":
            regole += [f"{n} {{ {font} color: {_q(c['etichetta'])}; background: {_q(c['traccia'])}; "
                       f"border: {max(0, spessore if s.nome in ('cartone', 'pixel', 'gioco') else 0)}px solid {_q(c['bordo_campo'])}; "
                       f"border-radius: {min(rc, 8)}px; text-align: center; }}",
                       f"{n}::chunk {{ background: {_gradiente(mescola(c['pieno'], '#FFFFFF', 0.25), c['pieno']) if s.nome in ('gioco', '3d', 'moderno') else _q(c['pieno'])}; "
                       f"border-radius: {min(rc, 8)}px; }}"]
        if genere == "cursore":
            maniglia = c["pieno"] if s.nome in ("cartone", "pixel", "gioco", "neon") else "#FFFFFF"
            regole += [f"{n}::groove:horizontal {{ height: {8 if s.nome in ('cartone', 'gioco', 'pixel') else 4}px; "
                       f"background: {_q(c['traccia'])}; border-radius: { {'pixel': 0, 'tecnico': 1}.get(s.nome, 3) }px; }}",
                       f"{n}::sub-page:horizontal {{ background: {_q(c['pieno'])}; border-radius: { {'pixel': 0, 'tecnico': 1}.get(s.nome, 3) }px; }}",
                       f"{n}::handle:horizontal {{ width: 20px; margin: -8px 0; background: {_q(maniglia)}; "
                       f"border: {max(1, min(spessore, 3))}px solid {_q(c['bordo'] if s.nome in ('cartone', 'pixel', 'gioco') else c['pieno'])}; "
                       f"border-radius: { {'pixel': 0, 'tecnico': 3}.get(s.nome, 10) }px; }}",
                       f"{n}::groove:vertical {{ width: 4px; background: {_q(c['traccia'])}; }}",
                       f"{n}::add-page:vertical {{ background: {_q(c['pieno'])}; }}",
                       f"{n}::handle:vertical {{ height: 20px; margin: 0 -8px; background: {_q(maniglia)}; "
                       f"border-radius: { {'pixel': 0, 'tecnico': 3}.get(s.nome, 10) }px; }}"]
    elif genere == "testo":
        peso = s.peso if s.nome in ("cartone", "gioco", "carta") else 400
        regole.append(f"{n} {{ {font} color: {_q(c['etichetta'])}; font-weight: {peso}; }}")
    elif genere == "contenitore":
        regole += [f"{n} {{ {font} color: {_q(c['etichetta'])}; border: {max(1, min(bordo, 3))}px solid "
                   f"{_q(c['bordo_campo'])}; border-radius: {rc}px; }}",
                   f"{n} QTabBar::tab {{ {font} padding: 6px 12px; color: {_q(c['etichetta'])}; }}",
                   f"{n} QTabBar::tab:selected {{ color: {_q(c['pieno'])}; border-bottom: 2px solid {_q(c['pieno'])}; }}"]
    else:  # superficie: controlli disegnati da se' (Led, Grafico, controlli nuovi...)
        regole.append(f"{n} {{ {font} }}")
    if maiuscole:
        regole.append(maiuscole)
    return "\n".join(regole) + "\n"


def effetto_qt(nome: Any, genere: str, base: str = "#E0182D", *, scuro: bool = False) -> dict | None:
    """Ombra o bagliore dello stile per un ``QGraphicsDropShadowEffect``.

    ``{"colore": "#RRGGBBAA", "sfocatura": px, "dx": px, "dy": px}`` o None (niente effetto).
    """
    s = _PER_NOME.get(normalizza(nome) or "")
    if s is None or genere in ("contenitore",):
        return None
    c = colori(s.nome, base, scuro=scuro)
    if s.nome == "neon":
        return {"colore": con_alfa(c["bagliore"] or base, 0.95), "sfocatura": 22, "dx": 0, "dy": 0}
    if genere == "testo":
        return None
    if s.nome == "cartone":
        return {"colore": c["ombra"], "sfocatura": 0, "dx": 4, "dy": 4}
    if s.nome == "pixel" and genere == "pulsante":
        return {"colore": c["ombra"], "sfocatura": 0, "dx": 4, "dy": 4}
    if s.nome in ("moderno", "gioco", "pillola") and genere == "pulsante":
        return {"colore": c["ombra"], "sfocatura": 18, "dx": 0, "dy": 5}
    if s.nome == "3d" and genere == "pulsante":
        return {"colore": c["ombra"], "sfocatura": 10, "dx": 0, "dy": 4}
    if s.nome == "elegante" and genere in ("pulsante", "campo"):
        return {"colore": c["ombra"], "sfocatura": 16, "dx": 0, "dy": 4}
    if s.nome in ("vetro", "carta"):
        return {"colore": c["ombra"], "sfocatura": 24, "dx": 0, "dy": 6}
    return None


def testo_mostrato(nome: Any, genere: str, testo: str) -> str:
    """Il testo come lo mostra lo stile (maiuscolo per Pixel, Neon e Gioco sui pulsanti)."""
    s = _PER_NOME.get(normalizza(nome) or "")
    if s is not None and s.maiuscole and genere == "pulsante":
        return str(testo).upper()
    return str(testo)


# ===========================================================================
# Tabella per il telefono (finestre.js / disegna.js)
# ===========================================================================

def stili_per_js() -> list[dict]:
    """La tabella di ``stili_oggetti.js``: ``[{nome, titolo, sotto, icona, tocco, schiarisci, scuro}]``."""
    return [{"nome": s.nome, "titolo": s.titolo, "sotto": s.descrizione, "icona": s.icona, "tocco": s.tocco,
             "schiarisci": s.schiarisci, "scuro": s.sempre_scuro} for s in STILI_OGGETTI]


def dati_per_js() -> dict:
    """Tutto quello che serve a ``stili_oggetti.js``: stili, sinonimi, generi e contrasto minimo."""
    return {"stili": stili_per_js(), "sinonimi": dict(sorted(SINONIMI.items())),
            "generi": {g: list(t) for g, t in _GENERI.items()}, "contrasto": CONTRASTO_MINIMO}


def elenco_stili() -> list[str]:
    """I nomi degli stili da mostrare ("Moderno", "Pillola", "3D"...), per ``stili_oggetti()`` in Leo."""
    return [s.titolo for s in STILI_OGGETTI]


__all__ = ["StileOggetto", "STILI_OGGETTI", "NOMI_STILI", "NORMALE", "SCELTE", "SINONIMI", "GENERI", "normalizza",
           "stile_oggetto", "stile_effettivo", "tocco_di", "genere_di", "colori", "foglio_qss", "effetto_qt",
           "testo_mostrato", "famiglie_qt", "mescola", "con_alfa", "luminanza", "contrasto", "testo_su",
           "stili_per_js", "dati_per_js", "elenco_stili", "base_leggibile", "leggibile", "CONTRASTO_MINIMO"]
