"""Primitive di disegno per l'arte dei giochi: SVG vettoriale e pixel art dallo stesso disegno (senza Qt).

Una :class:`Tela` raccoglie forme semplici (cerchi, ellissi, capsule affusolate, poligoni, percorsi,
linee) con il loro colore. Poi:

* :meth:`Tela.svg` le scrive come SVG (con sfumature automatiche e contorno, secondo lo :class:`Stile`);
* :meth:`Tela.pixel` le "rasterizza" su una griglia (per esempio 32 x 32) e scrive la pixel art come
  rettangoli SVG con il contorno scuro, come nei giochi a 8/16 bit.

Così ogni personaggio si disegna una volta sola e funziona in tutti gli stili.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any


# ===========================================================================
# Colori
# ===========================================================================

def rgb(colore: str) -> tuple[int, int, int]:
    c = colore.lstrip("#")
    if len(c) == 3:
        c = "".join(x * 2 for x in c)
    return int(c[0:2], 16), int(c[2:4], 16), int(c[4:6], 16)


def esadecimale(r: float, g: float, b: float) -> str:
    return "#%02X%02X%02X" % tuple(max(0, min(255, int(round(v)))) for v in (r, g, b))


def mescola(a: str, b: str, t: float) -> str:
    ra, ga, ba = rgb(a)
    rb, gb, bb = rgb(b)
    return esadecimale(ra + (rb - ra) * t, ga + (gb - ga) * t, ba + (bb - ba) * t)


def chiaro(c: str, t: float = 0.35) -> str:
    return mescola(c, "#FFFFFF", t)


def scuro(c: str, t: float = 0.35) -> str:
    return mescola(c, "#000000", t)


def _f(v: float) -> str:
    """Numero corto per l'SVG."""
    t = f"{v:.1f}"
    return t[:-2] if t.endswith(".0") else t


# ===========================================================================
# Forme
# ===========================================================================

@dataclass
class Forma:
    tipo: str                  # cerchio, ellisse, capsula, poligono, percorso, linea
    dati: tuple
    colore: str = "#000000"
    bordo: bool = True         # contorno nello stile "cartone"
    opacita: float = 1.0
    sfuma: bool = True         # sfumatura automatica (se lo stile le usa)
    poligono: list = field(default_factory=list)   # approssimazione per la pixel art (percorsi)
    spessore: float = 0.0      # per le linee
    luce: bool = False         # luce che "brilla" (fantascienza): alone sotto
    gruppo: int = 0            # forme dello stesso gruppo hanno un contorno unico (prima i bordi, poi i colori)


def _capsula_d(x1, y1, x2, y2, r1, r2) -> str:
    """Percorso di una capsula affusolata: cerchio di raggio r1 in (x1,y1) e r2 in (x2,y2) uniti."""
    dx, dy = x2 - x1, y2 - y1
    d = math.hypot(dx, dy)
    if d < 1e-6:
        r = max(r1, r2)
        return (f"M{_f(x1 - r)},{_f(y1)}a{_f(r)},{_f(r)} 0 1,0 {_f(2 * r)},0"
                f"a{_f(r)},{_f(r)} 0 1,0 {_f(-2 * r)},0Z")
    ux, uy = dx / d, dy / d
    # angolo della tangente comune (raggi diversi)
    s = max(-1.0, min(1.0, (r1 - r2) / d))
    c = math.sqrt(1 - s * s)
    # normale ruotata
    nx, ny = -uy * c + ux * s, ux * c + uy * s
    mx, my = uy * c + ux * s, -ux * c + uy * s
    a1 = (x1 + nx * r1, y1 + ny * r1)
    a2 = (x2 + nx * r2, y2 + ny * r2)
    b2 = (x2 + mx * r2, y2 + my * r2)
    b1 = (x1 + mx * r1, y1 + my * r1)
    return (f"M{_f(a1[0])},{_f(a1[1])}L{_f(a2[0])},{_f(a2[1])}"
            f"A{_f(r2)},{_f(r2)} 0 0,0 {_f(b2[0])},{_f(b2[1])}"
            f"L{_f(b1[0])},{_f(b1[1])}A{_f(r1)},{_f(r1)} 0 0,0 {_f(a1[0])},{_f(a1[1])}Z")


def _dist_segmento(px, py, x1, y1, x2, y2) -> tuple[float, float]:
    dx, dy = x2 - x1, y2 - y1
    l2 = dx * dx + dy * dy
    t = 0.0 if l2 == 0 else max(0.0, min(1.0, ((px - x1) * dx + (py - y1) * dy) / l2))
    return math.hypot(px - (x1 + t * dx), py - (y1 + t * dy)), t


def _dentro_poligono(px, py, punti) -> bool:
    dentro = False
    n = len(punti)
    j = n - 1
    for i in range(n):
        xi, yi = punti[i]
        xj, yj = punti[j]
        if (yi > py) != (yj > py) and px < (xj - xi) * (py - yi) / ((yj - yi) or 1e-9) + xi:
            dentro = not dentro
        j = i
    return dentro


def contiene(f: Forma, x: float, y: float) -> bool:
    """Vero se il punto è dentro la forma (per la pixel art)."""
    t, d = f.tipo, f.dati
    if t == "cerchio":
        return (x - d[0]) ** 2 + (y - d[1]) ** 2 <= d[2] ** 2
    if t == "ellisse":
        cx, cy, rx, ry, ang = d
        a = math.radians(-ang)
        lx = (x - cx) * math.cos(a) - (y - cy) * math.sin(a)
        ly = (x - cx) * math.sin(a) + (y - cy) * math.cos(a)
        return (lx / max(rx, 1e-6)) ** 2 + (ly / max(ry, 1e-6)) ** 2 <= 1
    if t == "capsula":
        x1, y1, x2, y2, r1, r2 = d
        dist, tt = _dist_segmento(x, y, x1, y1, x2, y2)
        return dist <= r1 + (r2 - r1) * tt
    if t == "linea":
        x1, y1, x2, y2 = d
        dist, _tt = _dist_segmento(x, y, x1, y1, x2, y2)
        return dist <= f.spessore / 2
    if t == "poligono":
        return _dentro_poligono(x, y, d[0])
    if t == "percorso":
        return bool(f.poligono) and _dentro_poligono(x, y, f.poligono)
    return False


# ===========================================================================
# Stile
# ===========================================================================

@dataclass(frozen=True)
class Stile:
    nome: str
    contorno: str = ""            # colore del contorno ("" = niente)
    spessore: float = 0.0
    sfumature: str = ""           # "", "tonde" (radiali), "metallo" (lineari verticali)
    pixel: int = 0                # lato della griglia della pixel art (0 = vettoriale)


STILI = {
    "cartone": Stile("cartone", contorno="#1B1A22", spessore=2.4, sfumature="tonde"),
    "piatto": Stile("piatto"),
    "pixel": Stile("pixel", contorno="#15131B", pixel=32),
    "realistico": Stile("realistico", contorno="#000000", spessore=0.6, sfumature="tonde"),
    "fantascienza": Stile("fantascienza", contorno="#06080C", spessore=0.8, sfumature="metallo"),
}


# ===========================================================================
# Tela
# ===========================================================================

class Tela:
    """Raccoglie le forme di un disegno (coordinate di una cella, di solito 128 x 128)."""

    def __init__(self) -> None:
        self.forme: list[Forma] = []
        self._gruppo = 0
        self._contatore = 0

    def unisci(self) -> "Tela":
        """``with tela.unisci(): ...``: le forme disegnate dentro hanno un solo contorno esterno
        (un braccio fatto di due pezzi non mostra la giuntura)."""
        return self

    def __enter__(self) -> "Tela":
        self._contatore += 1
        self._gruppo = self._contatore
        return self

    def __exit__(self, *_a) -> None:
        self._gruppo = 0

    # --- forme -------------------------------------------------------------
    def cerchio(self, cx, cy, r, colore, **k) -> Forma:
        return self._metti(Forma("cerchio", (cx, cy, r), colore, **k))

    def ellisse(self, cx, cy, rx, ry, colore, angolo=0.0, **k) -> Forma:
        return self._metti(Forma("ellisse", (cx, cy, rx, ry, angolo), colore, **k))

    def capsula(self, x1, y1, x2, y2, r1, r2, colore, **k) -> Forma:
        return self._metti(Forma("capsula", (x1, y1, x2, y2, r1, r2), colore, **k))

    def poligono(self, punti, colore, **k) -> Forma:
        return self._metti(Forma("poligono", (list(punti),), colore, **k))

    def percorso(self, d, colore, poligono=None, **k) -> Forma:
        return self._metti(Forma("percorso", (d,), colore, poligono=list(poligono or []), **k))

    def linea(self, x1, y1, x2, y2, colore, spessore=2.0, **k) -> Forma:
        k.setdefault("sfuma", False)
        return self._metti(Forma("linea", (x1, y1, x2, y2), colore, spessore=spessore, **k))

    def _metti(self, f: Forma) -> Forma:
        f.gruppo = self._gruppo
        self.forme.append(f)
        return f

    # --- SVG vettoriale ------------------------------------------------------
    def svg(self, stile: Stile, sfumature: dict[str, str]) -> str:
        """Gli elementi SVG (senza <svg>); ``sfumature`` raccoglie le <defs> necessarie (id -> testo)."""
        parti: list[str] = []
        k = 0
        forme = self.forme
        while k < len(forme):
            g = forme[k].gruppo
            if g and stile.contorno and stile.spessore:
                fine = k
                while fine + 1 < len(forme) and forme[fine + 1].gruppo == g:
                    fine += 1
                gruppo = forme[k:fine + 1]
                for f in gruppo:          # prima tutti i bordi (forme ingrossate e scure)...
                    if f.bordo and f.tipo != "linea":
                        parti.append(self._uno(f, stile, sfumature, solo_bordo=True))
                for f in gruppo:          # ...poi tutti i colori, senza bordo
                    parti.append(self._uno(f, stile, sfumature, senza_bordo=True))
                k = fine + 1
                continue
            parti.append(self._uno(forme[k], stile, sfumature))
            k += 1
        return "".join(parti)

    def _uno(self, f: Forma, stile: Stile, sfumature: dict[str, str], solo_bordo: bool = False,
             senza_bordo: bool = False) -> str:
        parti: list[str] = []
        if True:
            riempi = self._riempimento(f, stile, sfumature)
            bordo = ""
            if solo_bordo:
                riempi = stile.contorno
                bordo = (f' stroke="{stile.contorno}" stroke-width="{_f(stile.spessore * 2)}" '
                         'stroke-linejoin="round"')
            elif stile.contorno and f.bordo and f.tipo != "linea" and not senza_bordo:
                bordo = (f' stroke="{stile.contorno}" stroke-width="{_f(stile.spessore)}" '
                         'stroke-linejoin="round"')
            op = f' opacity="{_f(f.opacita) if f.opacita >= 0.1 else round(f.opacita, 2)}"' if f.opacita < 1 else ""
            d = f.dati
            if f.luce and stile.nome == "fantascienza" and not solo_bordo:
                parti.append(self._alone(f))
            if f.tipo == "cerchio":
                parti.append(f'<circle cx="{_f(d[0])}" cy="{_f(d[1])}" r="{_f(d[2])}" fill="{riempi}"{bordo}{op}/>')
            elif f.tipo == "ellisse":
                rot = f' transform="rotate({_f(d[4])} {_f(d[0])} {_f(d[1])})"' if d[4] else ""
                parti.append(f'<ellipse cx="{_f(d[0])}" cy="{_f(d[1])}" rx="{_f(d[2])}" ry="{_f(d[3])}" '
                             f'fill="{riempi}"{rot}{bordo}{op}/>')
            elif f.tipo == "capsula":
                parti.append(f'<path d="{_capsula_d(*d)}" fill="{riempi}"{bordo}{op}/>')
            elif f.tipo == "poligono":
                punti = " ".join(f"{_f(x)},{_f(y)}" for x, y in d[0])
                parti.append(f'<polygon points="{punti}" fill="{riempi}"{bordo}{op}/>')
            elif f.tipo == "percorso":
                parti.append(f'<path d="{d[0]}" fill="{riempi}"{bordo}{op}/>')
            elif f.tipo == "linea":
                parti.append(f'<line x1="{_f(d[0])}" y1="{_f(d[1])}" x2="{_f(d[2])}" y2="{_f(d[3])}" '
                             f'stroke="{f.colore}" stroke-width="{_f(f.spessore)}" stroke-linecap="round"{op}/>')
        return "".join(parti)

    @staticmethod
    def _alone(f: Forma) -> str:
        d = f.dati
        if f.tipo == "linea":
            return (f'<line x1="{_f(d[0])}" y1="{_f(d[1])}" x2="{_f(d[2])}" y2="{_f(d[3])}" stroke="{f.colore}" '
                    f'stroke-width="{_f(f.spessore * 3.2)}" stroke-linecap="round" opacity=".28"/>')
        if f.tipo == "cerchio":
            return f'<circle cx="{_f(d[0])}" cy="{_f(d[1])}" r="{_f(d[2] * 2.1)}" fill="{f.colore}" opacity=".22"/>'
        return ""

    @staticmethod
    def _riempimento(f: Forma, stile: Stile, sfumature: dict[str, str]) -> str:
        colore = f.colore
        if not colore.startswith("#") or not f.sfuma or not stile.sfumature:
            return colore
        chiave = colore.lstrip("#").upper()
        if stile.sfumature == "tonde":
            ident = "t" + chiave
            if ident not in sfumature:
                forte = 0.42 if stile.nome == "cartone" else 0.28
                sfumature[ident] = (f'<radialGradient id="{ident}" cx="38%" cy="30%" r="78%">'
                                    f'<stop offset="0" stop-color="{chiaro(colore, forte)}"/>'
                                    f'<stop offset=".55" stop-color="{colore}"/>'
                                    f'<stop offset="1" stop-color="{scuro(colore, 0.28)}"/></radialGradient>')
            return f"url(#{ident})"
        ident = "m" + chiave
        if ident not in sfumature:
            sfumature[ident] = (f'<linearGradient id="{ident}" x1="0" y1="0" x2=".35" y2="1">'
                                f'<stop offset="0" stop-color="{chiaro(colore, 0.45)}"/>'
                                f'<stop offset=".45" stop-color="{colore}"/>'
                                f'<stop offset=".5" stop-color="{scuro(colore, 0.12)}"/>'
                                f'<stop offset="1" stop-color="{scuro(colore, 0.4)}"/></linearGradient>')
        return f"url(#{ident})"

    # --- pixel art -------------------------------------------------------------
    def griglia(self, lato: int, cella: float = 128.0) -> list[list[str | None]]:
        """I colori della pixel art: ``lato`` x ``lato`` celle (None = vuota)."""
        passo = cella / lato
        g: list[list[str | None]] = [[None] * lato for _ in range(lato)]
        for f in self.forme:
            if f.opacita < 0.5 or not f.colore.startswith("#"):
                continue
            trovata = False
            for r in range(lato):
                y = (r + 0.5) * passo
                for c in range(lato):
                    if contiene(f, (c + 0.5) * passo, y):
                        g[r][c] = f.colore
                        trovata = True
            if not trovata:
                # dettagli piu' piccoli di un pixel (occhi, naso): almeno il pixel in cui cadono
                x, y = _centro(f)
                r, c = int(y // passo), int(x // passo)
                if 0 <= r < lato and 0 <= c < lato:
                    g[r][c] = f.colore
        return g

    def pixel(self, lato: int, contorno: str, cella: float = 128.0) -> str:
        """La pixel art come rettangoli SVG (righe unite), con il contorno scuro attorno alla figura."""
        g = self.griglia(lato, cella)
        passo = cella / lato
        # contorno: celle vuote accanto a celle piene
        bordo = [[False] * lato for _ in range(lato)]
        for r in range(lato):
            for c in range(lato):
                if g[r][c] is None and any(
                        0 <= r + dr < lato and 0 <= c + dc < lato and g[r + dr][c + dc] is not None
                        for dr, dc in ((-1, 0), (1, 0), (0, -1), (0, 1))):
                    bordo[r][c] = True
        # luce in alto e ombra in basso di ogni zona di colore (come la pixel art a 16 bit)
        finale: list[list[str | None]] = [[None] * lato for _ in range(lato)]
        for r in range(lato):
            for c in range(lato):
                if bordo[r][c]:
                    finale[r][c] = contorno
                elif g[r][c] is not None:
                    col = g[r][c]
                    sopra = g[r - 1][c] if r > 0 else None
                    sotto = g[r + 1][c] if r + 1 < lato else None
                    if sotto is None and sopra == col:
                        finale[r][c] = scuro(col, 0.22)
                    elif sopra is None and sotto == col:
                        finale[r][c] = chiaro(col, 0.25)
                    else:
                        finale[r][c] = col
        # un solo percorso per colore (righe di pixel uguali unite): file piccoli
        per_colore: dict[str, list[str]] = {}
        for r in range(lato):
            c = 0
            while c < lato:
                col = finale[r][c]
                if col is None:
                    c += 1
                    continue
                k = c
                while k + 1 < lato and finale[r][k + 1] == col:
                    k += 1
                per_colore.setdefault(col, []).append(
                    f"M{_f(c * passo)} {_f(r * passo)}h{_f((k - c + 1) * passo)}v{_f(passo)}h{_f(-(k - c + 1) * passo)}z")
                c = k + 1
        return "".join(f'<path fill="{col}" d="{"".join(d)}"/>' for col, d in per_colore.items())


def _centro(f: Forma) -> tuple[float, float]:
    d = f.dati
    if f.tipo in ("cerchio", "ellisse"):
        return d[0], d[1]
    if f.tipo in ("capsula", "linea"):
        return (d[0] + d[2]) / 2, (d[1] + d[3]) / 2
    punti = d[0] if f.tipo == "poligono" else f.poligono
    if punti:
        return sum(p[0] for p in punti) / len(punti), sum(p[1] for p in punti) / len(punti)
    return -1.0, -1.0


def ruota(px: float, py: float, cx: float, cy: float, gradi: float) -> tuple[float, float]:
    a = math.radians(gradi)
    dx, dy = px - cx, py - cy
    return cx + dx * math.cos(a) - dy * math.sin(a), cy + dx * math.sin(a) + dy * math.cos(a)


def punto_da(x: float, y: float, angolo: float, lunghezza: float) -> tuple[float, float]:
    """Il punto a ``lunghezza`` da (x, y) verso il basso ruotato di ``angolo`` gradi (positivo = in avanti)."""
    a = math.radians(angolo)
    return x + math.sin(a) * lunghezza, y + math.cos(a) * lunghezza


def avvolgi(svg_interno: str, larghezza: int, altezza: int, defs: dict[str, str] | None = None,
            pixel: bool = False) -> str:
    """Un documento SVG completo."""
    extra = ' shape-rendering="crispEdges"' if pixel else ""
    d = "<defs>" + "".join(defs.values()) + "</defs>" if defs else ""
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{larghezza}" height="{altezza}" '
            f'viewBox="0 0 {larghezza} {altezza}"{extra}>{d}{svg_interno}</svg>')


__all__ = ["Tela", "Forma", "Stile", "STILI", "rgb", "esadecimale", "mescola", "chiaro", "scuro", "ruota",
           "punto_da", "avvolgi", "contiene"]
