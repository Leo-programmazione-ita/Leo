"""I giochi nei programmi con finestre del telefono (lato Python di ``giochi.js``).

La pagina fa tutto il lavoro per fotogramma (movimento, urti, animazioni, suoni) e manda a Python solo:

* gli eventi normali dei controlli (``{"tipo": "evento"}``: tocca, raccoglie, colpito, cambio...), con i
  valori cambiati (posizioni, punti, vite) in ``agg``, come tutti gli altri controlli;
* i messaggi ``{"tipo": "gioco", "f": finestra, "azione": ...}`` per ciò che solo Python può fare:

  ``apri``     ``{"finestra": nome}``: una Porta o "Quando arriva a zero" aprono un'altra finestra;
  ``casella``  ``{"c": scacchiera, "riga": r, "colonna": k}``: un tocco sulla Scacchiera (le regole dei
               giochi da tavolo stanno in :mod:`leo.grafica.giochi.tabellone`, uguali sul PC).

:func:`prepara_finestra` mette i valori iniziali calcolati (classifica salvata, pezzi della scacchiera,
mazzo mescolato, labirinto) prima che la finestra parta verso la pagina.
"""

from __future__ import annotations

from typing import Any

#: Controlli disegnati da ``giochi.js`` (lo controlla tests/test_ogg_giochi.py).
TIPI_WEB = frozenset({
    "Personaggio", "MondoAPiastrelle", "Piattaforma", "Moneta", "Nemico", "Proiettile", "Ostacolo", "Porta",
    "SfondoCheScorre", "Telecamera", "Vite", "Classifica", "TimerDiGioco", "PulsanteGioco", "FrecceDirezionali",
    "Dado", "MazzoDiCarte", "Scacchiera", "Particelle", "Pianoforte", "RuotaDellaFortuna", "Bersaglio", "Labirinto",
})


def prepara_finestra(finestra: Any) -> None:
    """Valori iniziali degli oggetti da gioco di una finestra (prima di mandarla alla pagina)."""
    from ..catalogo_giochi import TIPI_GIOCHI, prepara

    for vivo in finestra.vivi.values():
        if vivo.tipo_controllo in TIPI_GIOCHI:
            try:
                prepara(vivo)
            except Exception:  # noqa: BLE001 - un valore strano non deve fermare la finestra
                pass


def gestisci(programma: Any, finestra: Any, ev: dict) -> None:
    """Un messaggio ``{"tipo": "gioco"}`` della pagina."""
    azione = str(ev.get("azione", ""))
    if azione == "apri":
        nome = str(ev.get("finestra", "") or "")
        if nome:
            try:
                programma.apri_finestra(nome)
            except Exception as e:  # noqa: BLE001 - finestra sbagliata: si mostra l'errore e si continua
                mostra = getattr(programma, "mostra_errore", None)
                if callable(mostra):
                    from ...errori import ErroreDante, ErroreValore

                    mostra(e if isinstance(e, ErroreDante) else ErroreValore(
                        f"La porta vuole aprire la finestra `{nome}`, ma non ci riesco: {e}"))
        return
    if azione == "casella":
        vivo = finestra.vivi.get(str(ev.get("c", "")))
        if vivo is None or vivo.tipo_controllo != "Scacchiera":
            return
        try:
            riga, colonna = int(ev.get("riga")), int(ev.get("colonna"))
        except (TypeError, ValueError):
            return
        from ..catalogo_giochi import gioca_casella

        _esito, eventi = gioca_casella(vivo, riga, colonna)
        for evento, dati in eventi:
            programma.emetti_evento(vivo.nome, evento, dati, finestra=finestra.nome)


__all__ = ["TIPI_WEB", "prepara_finestra", "gestisci"]
