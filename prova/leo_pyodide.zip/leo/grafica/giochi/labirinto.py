"""Labirinti per il controllo ``Labirinto`` (senza Qt, identici sul telefono).

Un labirinto di ``righe`` x ``colonne`` celle diventa una mappa di testo di (2*righe+1) x (2*colonne+1)
caratteri, la stessa forma del ``MondoAPiastrelle``:

* ``#`` muro, ``.`` corridoio, ``S`` partenza (in alto a sinistra), ``F`` uscita (in basso a destra),
  ``o`` moneta (se richieste).

La generazione è "a scavo" (ricerca in profondità con ritorno) guidata da un generatore di numeri
pseudo-casuali semplicissimo (LCG a 31 bit), scritto uguale in ``giochi.js``: lo stesso ``seme`` dà lo
stesso labirinto sul PC e sul telefono, anche nel disegnatore (dove Python non c'è).
"""

from __future__ import annotations

from typing import Any

#: Massimo di righe e colonne di celle.
MASSIMO = 60


class Casuale:
    """LCG di Park e Miller (minimo standard): ``prossimo()`` in [1, 2^31 - 2]. Uguale in giochi.js."""

    def __init__(self, seme: int) -> None:
        seme = int(seme) % 2147483647
        self.stato = seme if seme > 0 else 1

    def prossimo(self) -> int:
        self.stato = (self.stato * 48271) % 2147483647
        return self.stato

    def intero(self, n: int) -> int:
        """Un intero in [0, n)."""
        return self.prossimo() % max(1, n)


def genera(righe: int, colonne: int, seme: int, monete: int = 0) -> list[str]:
    """La mappa di un labirinto perfetto (un solo percorso tra due celle qualunque)."""
    righe = max(2, min(MASSIMO, int(righe)))
    colonne = max(2, min(MASSIMO, int(colonne)))
    caso = Casuale(seme)
    alto, largo = 2 * righe + 1, 2 * colonne + 1
    griglia = [["#"] * largo for _ in range(alto)]
    visitate = [[False] * colonne for _ in range(righe)]
    pila = [(0, 0)]
    visitate[0][0] = True
    griglia[1][1] = "."
    direzioni = ((-1, 0), (0, 1), (1, 0), (0, -1))
    while pila:
        r, c = pila[-1]
        vicine = [(dr, dc) for dr, dc in direzioni
                  if 0 <= r + dr < righe and 0 <= c + dc < colonne and not visitate[r + dr][c + dc]]
        if not vicine:
            pila.pop()
            continue
        dr, dc = vicine[caso.intero(len(vicine))]
        nr, nc = r + dr, c + dc
        visitate[nr][nc] = True
        griglia[2 * r + 1 + dr][2 * c + 1 + dc] = "."
        griglia[2 * nr + 1][2 * nc + 1] = "."
        pila.append((nr, nc))
    griglia[1][1] = "S"
    griglia[alto - 2][largo - 2] = "F"
    # monete nei vicoli ciechi (poi a caso nei corridoi), sempre nello stesso ordine
    if monete > 0:
        cieche, libere = [], []
        for r in range(righe):
            for c in range(colonne):
                y, x = 2 * r + 1, 2 * c + 1
                if griglia[y][x] != ".":
                    continue
                aperti = sum(1 for dy, dx in direzioni if griglia[y + dy][x + dx] != "#")
                (cieche if aperti == 1 else libere).append((y, x))
        for gruppo in (cieche, libere):
            while gruppo and monete > 0:
                y, x = gruppo.pop(caso.intero(len(gruppo)))
                griglia[y][x] = "o"
                monete -= 1
    return ["".join(riga) for riga in griglia]


def percorso(mappa: list[str]) -> list[tuple[int, int]]:
    """Il percorso più breve da ``S`` a ``F`` (lista di (riga, colonna) della mappa; vuota se non c'è)."""
    righe = [str(r) for r in mappa if isinstance(r, str)]
    inizio = fine = None
    for y, riga in enumerate(righe):
        for x, ch in enumerate(riga):
            if ch == "S":
                inizio = (y, x)
            elif ch == "F":
                fine = (y, x)
    if inizio is None or fine is None:
        return []
    prima: dict[tuple[int, int], Any] = {inizio: None}
    coda = [inizio]
    while coda:
        punto = coda.pop(0)
        if punto == fine:
            break
        y, x = punto
        for dy, dx in ((-1, 0), (0, 1), (1, 0), (0, -1)):
            ny, nx = y + dy, x + dx
            if 0 <= ny < len(righe) and 0 <= nx < len(righe[ny]) and righe[ny][nx] != "#" \
                    and (ny, nx) not in prima:
                prima[(ny, nx)] = punto
                coda.append((ny, nx))
    if fine not in prima:
        return []
    strada = []
    punto: Any = fine
    while punto is not None:
        strada.append(punto)
        punto = prima[punto]
    return strada[::-1]


__all__ = ["Casuale", "genera", "percorso", "MASSIMO"]
