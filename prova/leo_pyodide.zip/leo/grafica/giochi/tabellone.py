"""Le regole dei giochi da tavolo della ``Scacchiera``: tris, forza quattro, dama (senza Qt).

Le caselle sono una lista di righe, ogni riga una lista di testi (``""`` = vuota). I pezzi:

* tris: ``"X"`` e ``"O"`` (comincia X);
* forza quattro: ``"rosso"`` e ``"giallo"`` (comincia rosso; il gettone cade in fondo alla colonna);
* dama (all'italiana, semplificata): ``"b"``/``"n"`` pedine bianche e nere, ``"B"``/``"N"`` dame;
  comincia il bianco (in basso); le pedine vanno avanti in diagonale e mangiano saltando; arrivate
  in fondo diventano dame, che vanno anche indietro; dopo una presa si continua se si può mangiare ancora;
* libero: nessuna regola (il programma decide tutto con l'evento ``clic_casella``).

Tutto passa da :func:`mossa`, usata sia dal telefono sia dal PC: la stessa regola ovunque.
"""

from __future__ import annotations

import copy
from typing import Any

GIOCHI = ("tris", "forza_quattro", "dama", "libero")
MISURE = {"tris": (3, 3), "forza_quattro": (6, 7), "dama": (8, 8)}
GIOCATORI = {"tris": ("X", "O"), "forza_quattro": ("rosso", "giallo"), "dama": ("bianco", "nero"), "libero": ("", "")}


def misura(gioco: str, righe: int = 0, colonne: int = 0) -> tuple[int, int]:
    if gioco in MISURE:
        return MISURE[gioco]
    return max(1, min(30, int(righe or 8))), max(1, min(30, int(colonne or 8)))


def iniziale(gioco: str, righe: int = 0, colonne: int = 0) -> list[list[str]]:
    """Le caselle all'inizio della partita."""
    r, c = misura(gioco, righe, colonne)
    caselle = [["" for _ in range(c)] for _ in range(r)]
    if gioco == "dama":
        for i in range(r):
            for j in range(c):
                if (i + j) % 2 == 1:
                    if i < 3:
                        caselle[i][j] = "n"
                    elif i >= r - 3:
                        caselle[i][j] = "b"
    return caselle


def primo_turno(gioco: str) -> str:
    return GIOCATORI.get(gioco, ("", ""))[0]


def _altro(gioco: str, turno: str) -> str:
    a, b = GIOCATORI.get(gioco, ("", ""))
    return b if turno == a else a


def normalizza(caselle: Any, gioco: str, righe: int = 0, colonne: int = 0) -> list[list[str]]:
    """Caselle della misura giusta (quelle mancanti vuote, quelle in più tolte)."""
    r, c = misura(gioco, righe, colonne)
    sorgente = caselle if isinstance(caselle, list) else []
    risultato = []
    for i in range(r):
        riga = sorgente[i] if i < len(sorgente) and isinstance(sorgente[i], list) else []
        risultato.append([str(riga[j]) if j < len(riga) and riga[j] is not None else "" for j in range(c)])
    return risultato


def _in_fila(caselle: list[list[str]], quanti: int) -> tuple[str, list[list[int]]] | None:
    righe, colonne = len(caselle), len(caselle[0]) if caselle else 0
    for i in range(righe):
        for j in range(colonne):
            v = caselle[i][j]
            if not v:
                continue
            for di, dj in ((0, 1), (1, 0), (1, 1), (1, -1)):
                fila = [[i, j]]
                a, b = i + di, j + dj
                while 0 <= a < righe and 0 <= b < colonne and caselle[a][b] == v and len(fila) < quanti:
                    fila.append([a, b])
                    a, b = a + di, b + dj
                if len(fila) >= quanti:
                    return v, fila
    return None


def _pieno(caselle: list[list[str]]) -> bool:
    return all(v for riga in caselle for v in riga)


# --- dama -----------------------------------------------------------------------------------------

def _di(pezzo: str) -> str:
    return "bianco" if pezzo in ("b", "B") else "nero" if pezzo in ("n", "N") else ""


def _direzioni(pezzo: str) -> list[tuple[int, int]]:
    if pezzo in ("B", "N"):
        return [(-1, -1), (-1, 1), (1, -1), (1, 1)]
    return [(-1, -1), (-1, 1)] if pezzo == "b" else [(1, -1), (1, 1)]


def _prese(caselle: list[list[str]], i: int, j: int) -> list[tuple[int, int, int, int]]:
    """(riga, colonna di arrivo, riga, colonna mangiata) delle prese possibili del pezzo in (i, j)."""
    pezzo = caselle[i][j]
    risultato = []
    for di, dj in _direzioni(pezzo):
        mi, mj, ai, aj = i + di, j + dj, i + 2 * di, j + 2 * dj
        if 0 <= ai < len(caselle) and 0 <= aj < len(caselle[0]) and not caselle[ai][aj]:
            preda = caselle[mi][mj]
            if preda and _di(preda) != _di(pezzo):
                # una pedina non mangia una dama (regola italiana)
                if pezzo in ("b", "n") and preda in ("B", "N"):
                    continue
                risultato.append((ai, aj, mi, mj))
    return risultato


def _passi(caselle: list[list[str]], i: int, j: int) -> list[tuple[int, int]]:
    risultato = []
    for di, dj in _direzioni(caselle[i][j]):
        a, b = i + di, j + dj
        if 0 <= a < len(caselle) and 0 <= b < len(caselle[0]) and not caselle[a][b]:
            risultato.append((a, b))
    return risultato


def _puo_muovere(caselle: list[list[str]], giocatore: str) -> bool:
    for i, riga in enumerate(caselle):
        for j, v in enumerate(riga):
            if v and _di(v) == giocatore and (_passi(caselle, i, j) or _prese(caselle, i, j)):
                return True
    return False


def mosse_possibili(caselle: list[list[str]], i: int, j: int) -> list[list[int]]:
    """Le caselle dove può andare il pezzo in (i, j) (per evidenziarle)."""
    if not (0 <= i < len(caselle) and 0 <= j < len(caselle[0])) or not caselle[i][j]:
        return []
    return [[a, b] for a, b, _x, _y in _prese(caselle, i, j)] + [[a, b] for a, b in _passi(caselle, i, j)]


def mossa(gioco: str, caselle: Any, turno: str, riga: int, colonna: int, selezione: Any = None,
          righe: int = 0, colonne: int = 0) -> dict:
    """Applica il tocco sulla casella (riga, colonna).

    Restituisce ``{"valida", "caselle", "turno", "selezione", "vincitore", "pareggio", "fila", "mangiato"}``:
    ``vincitore`` è il nome di chi ha vinto ("" se nessuno), ``fila`` le caselle vincenti.
    """
    tab = normalizza(caselle, gioco, righe, colonne)
    turno = turno or primo_turno(gioco)
    esito: dict[str, Any] = {"valida": False, "caselle": tab, "turno": turno, "selezione": selezione,
                             "vincitore": "", "pareggio": False, "fila": [], "mangiato": None}
    if not tab or not (0 <= riga < len(tab) and 0 <= colonna < len(tab[0])):
        return esito
    if gioco == "tris":
        if tab[riga][colonna]:
            return esito
        tab[riga][colonna] = turno
    elif gioco == "forza_quattro":
        libera = next((i for i in range(len(tab) - 1, -1, -1) if not tab[i][colonna]), None)
        if libera is None:
            return esito
        tab[libera][colonna] = turno
        esito["riga_caduta"] = libera
    elif gioco == "dama":
        return _mossa_dama(esito, tab, turno, riga, colonna, selezione)
    else:
        esito["valida"] = True
        return esito
    esito["valida"] = True
    fila = _in_fila(tab, 3 if gioco == "tris" else 4)
    if fila:
        esito["vincitore"], esito["fila"] = fila
    elif _pieno(tab):
        esito["pareggio"] = True
    else:
        esito["turno"] = _altro(gioco, turno)
    return esito


def _mossa_dama(esito: dict, tab: list[list[str]], turno: str, i: int, j: int, selezione: Any) -> dict:
    sel = selezione if isinstance(selezione, list) and len(selezione) == 2 else None
    v = tab[i][j]
    if v and _di(v) == turno:
        if esito.get("obbligata"):
            return esito
        esito["selezione"] = [i, j]
        esito["valida"] = True
        esito["evidenzia"] = mosse_possibili(tab, i, j)
        return esito
    if sel is None:
        return esito
    si, sj = int(sel[0]), int(sel[1])
    if not (0 <= si < len(tab) and 0 <= sj < len(tab[0])) or _di(tab[si][sj]) != turno:
        esito["selezione"] = None
        return esito
    pezzo = tab[si][sj]
    presa = next(((a, b, mi, mj) for a, b, mi, mj in _prese(tab, si, sj) if (a, b) == (i, j)), None)
    passo = (i, j) in _passi(tab, si, sj)
    if presa is None and not passo:
        return esito
    tab[si][sj] = ""
    if presa is not None:
        esito["mangiato"] = [presa[2], presa[3]]
        tab[presa[2]][presa[3]] = ""
    promossa = (pezzo == "b" and i == 0) or (pezzo == "n" and i == len(tab) - 1)
    tab[i][j] = pezzo.upper() if promossa else pezzo
    esito["valida"] = True
    esito["selezione"] = None
    if presa is not None and not promossa and _prese(tab, i, j):
        esito["selezione"] = [i, j]          # presa multipla: tocca ancora a lui
        esito["evidenzia"] = mosse_possibili(tab, i, j)
        return esito
    altro = _altro("dama", turno)
    if not any(_di(x) == altro for r in tab for x in r) or not _puo_muovere(tab, altro):
        esito["vincitore"] = turno
    else:
        esito["turno"] = altro
    return esito


def copia(caselle: Any) -> list:
    return copy.deepcopy(caselle) if isinstance(caselle, list) else []


__all__ = ["GIOCHI", "MISURE", "GIOCATORI", "misura", "iniziale", "primo_turno", "normalizza", "mossa",
           "mosse_possibili", "copia"]
