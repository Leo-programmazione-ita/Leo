"""Il motore dei giochi di Leo: dinamiche senza codice, oggetti da gioco, personaggi disegnati.

* :mod:`.dinamiche`: il catalogo delle dinamiche (Giocatore, Gravità e salto, Piattaforma,
  Raccoglibile, Nemico...) che si assegnano a qualunque controllo dal pannello delle proprietà;
* :mod:`.motore`: il motore di gioco in Python puro (fisica, urti, raccolte) che Leo Studio fa
  girare con un timer a 60 fotogrammi al secondo; sul telefono lo stesso lavoro lo fa la pagina
  (``android/app/src/main/assets/web/giochi.js``) con ``requestAnimationFrame``;
* :mod:`.risorse`: le immagini pronte (``personaggio:volpe``, ``oggetto:moneta``) e quelle della
  galleria (``galleria:categoria/nome``).

Il catalogo dei controlli della scheda "Giochi" è in ``leo.grafica.catalogo_giochi``.
"""
