"""Il MOTORE DI GIOCO di Leo: movimento, gravità, urti, raccolte, nemici, colpi, telecamera (senza Qt).

Questo è il riferimento: ``android/app/src/main/assets/web/giochi.js`` fa esattamente le stesse cose sul
telefono (a 60 fotogrammi al secondo con ``requestAnimationFrame``) e Leo Studio fa girare questo modulo
con un timer. Python (il programma Leo) riceve solo gli EVENTI (tocca, raccoglie, colpito...) e i valori
cambiati (posizioni, punti, vite): mai un lavoro per fotogramma.

Uso::

    mondo = Mondo(360, 640)
    mondo.aggiungi("Eroe", "Personaggio", 40, 300, 48, 48, [{"tipo": "giocatore"}, {"tipo": "gravità"}])
    mondo.aggiungi("Terra", "Piattaforma", 0, 600, 360, 40, [{"tipo": "piattaforma"}])
    mondo.ingressi.destra = True
    for _ in range(60):
        mondo.passo(1 / 60)
    eventi = mondo.prendi_eventi()        # [(controllo, evento, dati), ...]
    cambi = mondo.prendi_cambi()          # {controllo: {proprieta: valore}}

Le coordinate sono quelle del contenitore (la finestra o una Scena), in pixel logici; y cresce verso il
basso. Il passo fisso è 1/120 di secondo (più passi per fotogramma se serve): stesso risultato a 30, 60
o 120 fotogrammi al secondo.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Any, Callable

from .dinamiche import complete

PASSO = 1 / 120
#: Controlli che scorrono con la telecamera anche senza dinamiche (il "mondo"); gli altri (indicatori,
#: pulsanti, riquadri) restano fermi sullo schermo. Uguale in giochi.js.
TIPI_CHE_SCORRONO = frozenset({"Immagine", "Forma", "Linea", "Tela", "Sprite", "Personaggio", "MondoAPiastrelle",
                               "Labirinto", "Piattaforma", "Moneta", "Nemico", "Proiettile", "Ostacolo", "Porta",
                               "Bersaglio", "Particelle"})
#: Contatori gestiti dal motore (valori che cambiano giocando).
TIPI_CONTATORI = frozenset({"Vite", "Punteggio", "TimerDiGioco"})
#: Simboli delle mappe a piastrelle.
SOLIDI = "#B"
PONTI = "="
RACCOGLIBILI = {"o": 10, "*": 50, "c": 0}
PERICOLI = "^~"
_CIFRE = re.compile(r"\d+$")


def nome_base(nome: str) -> str:
    """``Moneta3`` -> ``Moneta``; ``Meteorite_12`` -> ``Meteorite`` (per `serve` della Porta e i filtri)."""
    return _CIFRE.sub("", str(nome)).rstrip("_") or str(nome)


@dataclass
class Ingressi:
    """Lo stato dei comandi: tastiera, frecce sullo schermo, joystick, inclinazione, pulsanti da gioco."""
    sinistra: bool = False
    destra: bool = False
    su: bool = False
    giu: bool = False
    joystick: tuple = (0.0, 0.0)        # da -1 a 1 (y positivo = giù)
    inclinazione: tuple = (0.0, 0.0)    # da -1 a 1
    salta: bool = False
    spara: bool = False
    azione: bool = False
    # un tocco veloce (premuto e lasciato prima del passo dopo) vale lo stesso: il salto non si perde
    colpo_salta: bool = False
    colpo_spara: bool = False

    def premi(self, nome: str, giu: bool) -> None:
        """Preme o lascia un comando ("salta", "spara", "sinistra"...): così un tocco veloce non si perde."""
        giu = bool(giu)
        if giu and nome in ("salta", "spara") and not getattr(self, nome):
            setattr(self, "colpo_" + nome, True)
        setattr(self, nome, giu)

    def direzione(self, comandi: str = "automatici") -> tuple[float, float]:
        dx = (1.0 if self.destra else 0.0) - (1.0 if self.sinistra else 0.0)
        dy = (1.0 if self.giu else 0.0) - (1.0 if self.su else 0.0)
        if comandi in ("automatici", "joystick"):
            jx, jy = self.joystick
            if abs(jx) > 0.15 or abs(jy) > 0.15:
                dx, dy = jx, jy
        if comandi == "inclinazione":
            ix, iy = self.inclinazione
            if (abs(ix) > 0.08 or abs(iy) > 0.08) and not (dx or dy):
                dx, dy = ix, iy
        return max(-1.0, min(1.0, dx)), max(-1.0, min(1.0, dy))


@dataclass
class Corpo:
    nome: str
    tipo: str
    x: float
    y: float
    w: float
    h: float
    dinamiche: dict = field(default_factory=dict)     # nome -> regolazioni complete
    vx: float = 0.0
    vy: float = 0.0
    visibile: bool = True
    proprieta: dict = field(default_factory=dict)     # altre proprietà utili (amico, punti_centro...)
    # stato
    x0: float = 0.0
    y0: float = 0.0
    a_terra: bool = False
    su: "Corpo | None" = None          # piattaforma sotto i piedi
    salti: int = 0
    guarda: int = 1
    salto_tenuto: bool = False
    tempo_terra: float = 0.0           # da quanto non tocca terra (salto "in ritardo")
    prenota_salto: float = 0.0         # salto premuto poco prima di toccare terra
    invulnerabile: float = 0.0
    animazione: str = "fermo"
    tempo_animazione: float = 0.0
    speciale: str = ""                 # colpito, attacco, vittoria (animazione a tempo)
    tempo_speciale: float = 0.0
    angolo: float = 0.0
    opacita: float = 1.0
    tempo: float = 0.0
    ricarica: float = 0.0
    generatore: float = 0.0
    copie: int = 0
    copia_di: str = ""
    trascinato: bool = False
    torna: bool = False
    tocchi: set = field(default_factory=set)
    spostamento: tuple = (0.0, 0.0)    # quanto si è mosso nell'ultimo passo (piattaforme mobili)
    sconfitto: float = 0.0             # > 0 mentre "sparisce" dopo essere stato sconfitto
    arrivi: set = field(default_factory=set)   # mappe di cui tocca l'arrivo (F)
    via: bool = False                  # da togliere (copie, colpi)

    def ha(self, nome: str) -> bool:
        return nome in self.dinamiche

    def d(self, nome: str) -> dict:
        return self.dinamiche.get(nome, {})

    @property
    def destra(self) -> float:
        return self.x + self.w

    @property
    def basso(self) -> float:
        return self.y + self.h

    def centro(self) -> tuple[float, float]:
        return self.x + self.w / 2, self.y + self.h / 2


def _sovrapposti(a: Corpo, b: Corpo, margine: float = 0.0) -> bool:
    return (a.x + margine < b.x + b.w and b.x + margine < a.x + a.w and a.y + margine < b.y + b.h
            and b.y + margine < a.y + a.h)


@dataclass
class Piastrelle:
    """Una mappa a piastrelle (MondoAPiastrelle o Labirinto) nel mondo."""
    nome: str
    tipo: str
    x: float
    y: float
    lato: float
    mappa: list
    lato_y: float = 0.0

    def __post_init__(self) -> None:
        if not self.lato_y:
            self.lato_y = self.lato
        self.mappa = [str(r) for r in self.mappa]

    def simbolo(self, r: int, c: int) -> str:
        if r < 0 or c < 0 or r >= len(self.mappa) or c >= len(self.mappa[r]):
            return "."
        return self.mappa[r][c]

    def metti(self, r: int, c: int, s: str) -> None:
        riga = self.mappa[r]
        self.mappa[r] = riga[:c] + s + riga[c + 1:]

    def celle(self, x: float, y: float, w: float, h: float):
        c0 = int(math.floor((x - self.x) / self.lato))
        c1 = int(math.floor((x + w - 0.001 - self.x) / self.lato))
        r0 = int(math.floor((y - self.y) / self.lato_y))
        r1 = int(math.floor((y + h - 0.001 - self.y) / self.lato_y))
        for r in range(max(0, r0), min(len(self.mappa) - 1, r1) + 1):
            for c in range(max(0, c0), c1 + 1):
                yield r, c, self.simbolo(r, c)

    def rettangolo(self, r: int, c: int) -> tuple[float, float, float, float]:
        return self.x + c * self.lato, self.y + r * self.lato_y, self.lato, self.lato_y


class Mondo:
    """Il mondo di gioco di un contenitore: corpi, piastrelle, contatori, telecamera."""

    def __init__(self, larghezza: float, altezza: float) -> None:
        self.larghezza = float(larghezza)       # misura dello schermo (la "finestra" sul mondo)
        self.altezza = float(altezza)
        self.mondo_l = 0.0                      # misura del mondo (0 = calcolata dai corpi)
        self.mondo_a = 0.0
        self.corpi: dict[str, Corpo] = {}
        self.piastrelle: list[Piastrelle] = []
        self.contatori: dict[str, dict] = {}    # nome -> {"tipo", "valore", "massimo", "dinamiche", ...}
        self.ingressi = Ingressi()
        self._prima = Ingressi()
        self.eventi: list[tuple[str, str, dict]] = []
        self.cambi: dict[str, dict] = {}
        self.azioni: list[dict] = []            # per chi ospita: fine_partita, vittoria, apri, suono, effetto...
        self.telecamera = [0.0, 0.0]
        self.segui = ""                         # nome del corpo seguito ("" = dinamica telecamera o giocatore)
        self.morbidezza = 0.15
        self.asse = "entrambi"
        self.scossa = (0.0, 0.0)                # forza, tempo rimasto
        self.fermo = False                      # pausa o fine partita
        self.finita = ""                        # "", "persa", "vinta"
        self.tempo = 0.0
        self._accumulo = 0.0
        self._contatore_copie = 0
        self.raccolti: list[str] = []           # nomi (base) delle cose raccolte (per `serve` delle porte)
        self._iniziale: dict[str, Any] = {}
        self._con_gestore: Callable[[str, str], bool] = lambda _c, _e: True
        self.casuale = _Casuale(12345)

    # --- costruzione -------------------------------------------------------------------
    def aggiungi(self, nome: str, tipo: str, x: float, y: float, w: float, h: float, dinamiche: Any = None,
                 visibile: bool = True, **proprieta: Any) -> Corpo:
        corpo = Corpo(nome, tipo, float(x), float(y), max(1.0, float(w)), max(1.0, float(h)), visibile=visibile,
                      proprieta=dict(proprieta))
        corpo.x0, corpo.y0 = corpo.x, corpo.y
        self.corpi[nome] = corpo
        self.imposta_dinamiche(nome, dinamiche or [])
        return corpo

    def imposta_dinamiche(self, nome: str, dinamiche: Any) -> None:
        corpo = self.corpi.get(nome)
        if corpo is None:
            return
        prima = corpo.ha("rimbalza") or corpo.ha("si_muove")
        corpo.dinamiche = {d["tipo"]: d for d in complete(dinamiche)}
        if prima and not any(corpo.ha(n) for n in ("rimbalza", "si_muove", "gravità", "giocatore", "nemico")):
            corpo.vx = corpo.vy = 0.0           # tolta la dinamica che lo muoveva: si ferma
        if corpo.ha("rimbalza") and not corpo.vx and not corpo.vy:
            r = corpo.d("rimbalza")
            corpo.vx, corpo.vy = float(r["velocità_x"]), float(r["velocità_y"])
        if corpo.ha("generatore") and corpo.d("generatore").get("nascondi_originale", True):
            corpo.visibile = False
            self._cambia(nome, "visibile", False)
            corpo.generatore = 0.0
        if corpo.ha("telecamera"):
            t = corpo.d("telecamera")
            self.morbidezza, self.asse = float(t["morbidezza"]), str(t["asse"])

    def aggiungi_piastrelle(self, nome: str, tipo: str, x: float, y: float, lato: float, mappa: list,
                            lato_y: float = 0.0) -> Piastrelle:
        p = Piastrelle(nome, tipo, float(x), float(y), float(lato), list(mappa or []), float(lato_y or 0))
        self.piastrelle = [q for q in self.piastrelle if q.nome != nome] + [p]
        return p

    def aggiungi_contatore(self, nome: str, tipo: str, valore: Any, dinamiche: Any = None, **altro: Any) -> None:
        c = {"tipo": tipo, "valore": valore, "dinamiche": {d["tipo"]: d for d in complete(dinamiche or [])},
             "fatto_zero": False, "fatto_traguardo": False, "resto": 0.0}
        c.update(altro)
        self.contatori[nome] = c

    def ricorda_inizio(self) -> None:
        """Si ricorda lo stato iniziale (per "Ricomincia")."""
        self._iniziale = {
            "corpi": {n: (c.x, c.y, c.vx, c.vy, c.visibile, dict(c.dinamiche)) for n, c in self.corpi.items()
                      if not c.copia_di},
            "contatori": {n: dict(c) for n, c in self.contatori.items()},
            "piastrelle": {p.nome: list(p.mappa) for p in self.piastrelle},
        }

    def con_gestore(self, funzione: Callable[[str, str], bool]) -> None:
        """``funzione(controllo, evento)`` dice se il programma ha un gestore (gli altri eventi non si fanno)."""
        self._con_gestore = funzione

    # --- comandi dal programma --------------------------------------------------------------
    def comando(self, nome: str, azione: str, dati: dict | None = None) -> None:
        dati = dati or {}
        c = self.corpi.get(nome)
        if azione == "scuoti":
            self.scossa = (float(dati.get("forza", 10)), float(dati.get("secondi", 0.4)))
            return
        if c is None:
            return
        if azione == "salta":
            forza = dati.get("forza")
            salto = c.d("gravità").get("salto", 700) if c.ha("gravità") else 700
            if forza:
                salto = salto * float(forza) / 10
            c.vy = -float(salto)
            c.a_terra = False
            self._evento(nome, "salta", {})
        elif azione == "spingi":
            c.vx += float(dati.get("vx", 0))
            c.vy += float(dati.get("vy", 0))
            if c.vy < 0:
                c.a_terra = False
        elif azione == "ferma":
            c.vx = c.vy = 0.0
        elif azione == "spara":
            self._spara(c, forzato=True)
        elif azione == "esulta":
            self._speciale(c, "vittoria", float(dati.get("secondi", 1.5)))
        elif azione == "attacca":
            self._speciale(c, "attacco", 0.45)
            if c.ha("spara"):
                self._spara(c, forzato=True)
        elif azione == "anima":
            self._speciale(c, str(dati.get("animazione", "fermo")), float(dati.get("secondi", 1)))

    def sposta(self, nome: str, x: float | None = None, y: float | None = None) -> None:
        """Il programma ha cambiato ``sinistra``/``alto``."""
        c = self.corpi.get(nome)
        if c is None:
            return
        if x is not None:
            c.x = float(x)
        if y is not None:
            c.y = float(y)
        c.a_terra = False

    def mostra(self, nome: str, visibile: bool) -> None:
        c = self.corpi.get(nome)
        if c is not None:
            c.visibile = bool(visibile)
            c.sconfitto = 0.0
            c.opacita = 1.0

    def imposta_contatore(self, nome: str, valore: Any) -> None:
        c = self.contatori.get(nome)
        if c is not None:
            c["valore"] = valore
            if isinstance(valore, (int, float)) and valore > 0:
                c["fatto_zero"] = False

    # --- trascinamento (dito o mouse) -------------------------------------------------------------
    def prendi(self, nome: str) -> bool:
        c = self.corpi.get(nome)
        if c is None or not c.ha("trascinabile") or not c.visibile:
            return False
        c.trascinato = True
        c.torna = False
        c.vx = c.vy = 0.0
        self._evento(nome, "preso", {})
        return True

    def trascina(self, nome: str, x: float, y: float) -> None:
        c = self.corpi.get(nome)
        if c is None or not c.trascinato:
            return
        c.x, c.y = float(x), float(y)
        if c.d("trascinabile").get("resta_dentro", True):
            self._dentro(c)

    def lascia(self, nome: str, vx: float = 0.0, vy: float = 0.0) -> None:
        c = self.corpi.get(nome)
        if c is None or not c.trascinato:
            return
        c.trascinato = False
        t = c.d("trascinabile")
        if t.get("torna_indietro"):
            c.torna = True
        elif t.get("lancia"):
            c.vx, c.vy = float(vx), float(vy)
        self._cambia_posizione(c)
        self._evento(nome, "lasciato", {"x": round(c.x), "y": round(c.y)})

    # --- il passo ------------------------------------------------------------------------------
    def passo(self, dt: float) -> None:
        """Avanza di ``dt`` secondi (con passi fissi da 1/120)."""
        if self.fermo:
            self._prima = _copia_ingressi(self.ingressi)
            self.ingressi.colpo_salta = self.ingressi.colpo_spara = False
            return
        dt = max(0.0, min(0.1, float(dt)))
        self._accumulo += dt
        while self._accumulo >= PASSO - 1e-9:
            self._accumulo -= PASSO
            self._uno(PASSO)
            if self.fermo:
                break
        self._telecamera(dt)
        self._prima = _copia_ingressi(self.ingressi)

    def _uno(self, dt: float) -> None:
        self.tempo += dt
        # una volta per passo: chi può fare da piattaforma e la misura del mondo (si usano tante volte)
        self._piattaforme = [s for s in self.corpi.values() if s.ha("piattaforma")]
        self._misura = None
        premuto_salta = (self.ingressi.salta and not self._prima.salta) or self.ingressi.colpo_salta
        premuto_spara = (self.ingressi.spara and not self._prima.spara) or self.ingressi.colpo_spara
        self.ingressi.colpo_salta = self.ingressi.colpo_spara = False
        self._prima.salta = self.ingressi.salta
        self._prima.spara = self.ingressi.spara
        corpi = [c for c in self.corpi.values() if c.visibile or c.ha("generatore")]
        # 1. piattaforme che si muovono (prima di tutti: portano chi ci sta sopra)
        for c in corpi:
            c.spostamento = (0.0, 0.0)
            if c.ha("piattaforma") and c.d("piattaforma")["movimento"] != "ferma" and c.visibile:
                p = c.d("piattaforma")
                distanza, vel = float(p["distanza"]), max(1.0, float(p["velocità"]))
                periodo = 2 * distanza / vel if distanza > 0 else 1
                fase = (self.tempo % periodo) / periodo if distanza > 0 else 0
                off = distanza * (1 - abs(1 - 2 * fase))          # avanti e indietro
                nx, ny = c.x, c.y
                if p["movimento"] == "orizzontale":
                    nx = c.x0 + off
                else:
                    ny = c.y0 - off
                c.spostamento = (nx - c.x, ny - c.y)
                c.x, c.y = nx, ny
        for c in corpi:
            if c.su is not None and c.a_terra:
                c.x += c.su.spostamento[0]
                c.y += c.su.spostamento[1]
        # 2. comportamenti
        giocatori = [c for c in corpi if c.ha("giocatore") and c.visibile]
        for c in corpi:
            c.tempo += dt
            if c.invulnerabile > 0:
                c.invulnerabile = max(0.0, c.invulnerabile - dt)
            if c.tempo_speciale > 0:
                c.tempo_speciale -= dt
                if c.tempo_speciale <= 0:
                    c.speciale = ""
            if c.sconfitto > 0:
                c.sconfitto -= dt
                c.opacita = max(0.0, c.sconfitto / 0.35)
                if c.sconfitto <= 0:
                    c.visibile = False
                    c.via = bool(c.copia_di)
                    self._cambia(c.nome, "visibile", False)
                continue
            if c.ha("generatore"):
                self._genera(c, dt)
                if not c.visibile:
                    continue
            if not c.visibile or c.trascinato:
                continue
            if c.torna:
                k = min(1.0, dt * 10)
                c.x += (c.x0 - c.x) * k
                c.y += (c.y0 - c.y) * k
                if abs(c.x - c.x0) < 0.5 and abs(c.y - c.y0) < 0.5:
                    c.x, c.y, c.torna = c.x0, c.y0, False
                continue
            if c.ha("giocatore"):
                self._giocatore(c, dt, premuto_salta)
            if c.ha("nemico"):
                self._nemico(c, dt, giocatori)
            if c.ha("si_muove"):
                s = c.d("si_muove")
                v = float(s["velocità"])
                c.vx, c.vy = {"sinistra": (-v, c.vy if c.ha("gravità") else 0.0),
                              "destra": (v, c.vy if c.ha("gravità") else 0.0),
                              "su": (0.0, -v), "giù": (0.0, v)}[s["direzione"]]
            if c.ha("gravità"):
                g = c.d("gravità")
                c.vy = min(float(g["caduta_massima"]), c.vy + float(g["forza"]) * dt)
            elif c.ha("trascinabile") and c.d("trascinabile").get("lancia") and not c.ha("rimbalza"):
                attrito = 0.985 ** (dt * 60)
                c.vx *= attrito
                c.vy *= attrito
                if abs(c.vx) < 3 and abs(c.vy) < 3:
                    c.vx = c.vy = 0.0
            if c.ha("ruota"):
                c.angolo = (c.angolo + float(c.d("ruota")["velocità"]) * dt) % 360
            if c.ha("lampeggia"):
                lm = c.d("lampeggia")
                per = float(lm["per_secondi"])
                if per <= 0 or c.tempo <= per:
                    onda = 0.5 + 0.5 * math.cos(2 * math.pi * float(lm["volte_al_secondo"]) * c.tempo)
                    c.opacita = float(lm["minimo"]) + (1 - float(lm["minimo"])) * onda
                else:
                    c.opacita = 1.0
            elif c.invulnerabile > 0:
                c.opacita = 0.35 if int(c.invulnerabile * 12) % 2 else 1.0
            elif c.sconfitto <= 0:
                c.opacita = 1.0
            if c.ha("spara"):
                c.ricarica = max(0.0, c.ricarica - dt)
                quando = c.d("spara")["quando"]
                if quando == "sempre" or (not c.ha("giocatore") and quando == "pulsante"):
                    if c.ricarica <= 0:
                        self._spara(c)
                elif c.ha("giocatore") and (premuto_spara or (self.ingressi.spara and c.ricarica <= 0)):
                    if c.ricarica <= 0:
                        self._spara(c)
            self._muovi(c, dt)
        # 3. contatti
        self._contatti([c for c in self.corpi.values() if c.visibile and c.sconfitto <= 0])
        # 4. contatori a tempo
        for nome, k in self.contatori.items():
            if k["tipo"] == "TimerDiGioco" and k.get("attivo", True) and not self.finita:
                k["resto"] += dt
                while k["resto"] >= 1.0:
                    k["resto"] -= 1.0
                    verso = k.get("verso", "indietro")
                    valore = int(k["valore"])
                    if verso == "indietro":
                        if valore <= 0:
                            k["attivo"] = False
                            break
                        valore -= 1
                    else:
                        valore += 1
                    self._contatore(nome, valore)
                    if verso == "indietro" and valore <= 0:
                        k["attivo"] = False
                        self._cambia(nome, "attivo", False)
                        self._evento(nome, "scaduto", {}, forzato=False)
        for nome in [n for n, c in self.corpi.items() if c.via]:
            del self.corpi[nome]
            self.azioni.append({"azione": "togli", "nome": nome})

    # --- giocatore ---------------------------------------------------------------------------
    def _giocatore(self, c: Corpo, dt: float, premuto_salta: bool) -> None:
        g = c.d("giocatore")
        vel = float(g["velocità"])
        dx, dy = self.ingressi.direzione(str(g["comandi"]))
        direzioni = g["direzioni"]
        gravita = c.ha("gravità")
        if gravita or direzioni == "orizzontale":
            dy = 0.0
        if direzioni == "verticale":
            dx = 0.0
        if not gravita and dx and dy:
            n = math.hypot(dx, dy)
            if n > 1:
                dx, dy = dx / n, dy / n
        k = min(1.0, dt * 14)          # accelerazione: risponde subito ma senza scatti
        if c.speciale == "colpito" and c.tempo_speciale > 0.2:
            k = 0.0
        c.vx += (dx * vel - c.vx) * k
        if not gravita:
            c.vy += (dy * vel - c.vy) * k
        if g.get("gira_immagine", True) and abs(dx) > 0.05:
            c.guarda = 1 if dx > 0 else -1
        if gravita:
            gr = c.d("gravità")
            c.tempo_terra = 0.0 if c.a_terra else c.tempo_terra + dt
            if premuto_salta:
                c.prenota_salto = 0.12
            elif c.prenota_salto > 0:
                c.prenota_salto -= dt
            if c.prenota_salto > 0:
                puo = c.a_terra or c.tempo_terra < 0.1
                doppio = gr.get("salto_doppio") and c.salti < 2 and not puo and premuto_salta
                if puo or doppio:
                    c.vy = -float(gr["salto"]) * (0.9 if doppio else 1.0)
                    c.salti = 2 if doppio else 1
                    c.a_terra = False
                    c.su = None
                    c.tempo_terra = 1.0
                    c.prenota_salto = 0.0
                    c.salto_tenuto = True
                    self._evento(c.nome, "salta", {})
                    self.azioni.append({"azione": "suono", "suono": "salto"})
            # salto più basso se si lascia subito il pulsante
            if c.salto_tenuto and not self.ingressi.salta and c.vy < 0:
                c.vy *= 0.55
                c.salto_tenuto = False
            if c.vy >= 0:
                c.salto_tenuto = False

    # --- nemici ------------------------------------------------------------------------------
    def _nemico(self, c: Corpo, dt: float, giocatori: list[Corpo]) -> None:
        n = c.d("nemico")
        mov, vel = n["movimento"], float(n["velocità"])
        if mov == "fermo":
            if not c.ha("gravità"):
                c.vx = c.vy = 0.0
            return
        if mov in ("pattuglia", "vola"):
            if c.vx == 0:
                c.vx = -vel if c.guarda < 0 else vel
            c.vx = math.copysign(vel, c.vx)
            distanza = float(n["distanza"])
            if distanza > 0:
                if c.x > c.x0 + distanza / 2 and c.vx > 0:
                    c.vx = -vel
                elif c.x < c.x0 - distanza / 2 and c.vx < 0:
                    c.vx = vel
            # sul bordo della piattaforma torna indietro (non cade)
            if c.ha("gravità") and c.a_terra:
                avanti = c.destra + 2 if c.vx > 0 else c.x - 2
                if not self._solido_in(avanti, c.basso + 4, escluso=c):
                    c.vx = -c.vx
            if mov == "vola":
                c.vy = math.cos(c.tempo * 2.4) * 40
        elif mov == "insegue" and giocatori:
            bersaglio = min(giocatori, key=lambda g: abs(g.x - c.x) + abs(g.y - c.y))
            bx, by = bersaglio.centro()
            cx, cy = c.centro()
            if c.ha("gravità"):
                c.vx = math.copysign(vel, bx - cx) if abs(bx - cx) > 4 else 0.0
            else:
                d = math.hypot(bx - cx, by - cy) or 1.0
                c.vx, c.vy = (bx - cx) / d * vel, (by - cy) / d * vel
        if abs(c.vx) > 1:
            c.guarda = 1 if c.vx > 0 else -1

    # --- movimento e urti ----------------------------------------------------------------------
    def _solidi(self, c: Corpo) -> list[Corpo]:
        piattaforme = getattr(self, "_piattaforme", None)
        if piattaforme is None:
            piattaforme = [s for s in self.corpi.values() if s.ha("piattaforma")]
        return [s for s in piattaforme if s is not c and s.visibile and s.sconfitto <= 0]

    def _solido_in(self, x: float, y: float, escluso: Corpo | None = None) -> bool:
        for s in self.corpi.values():
            if s is not escluso and s.visibile and s.ha("piattaforma") and s.x <= x < s.destra and s.y <= y < s.basso:
                return True
        for p in self.piastrelle:
            c = int(math.floor((x - p.x) / p.lato))
            r = int(math.floor((y - p.y) / p.lato_y))
            if p.simbolo(r, c) in SOLIDI + PONTI:
                return True
        return False

    def _urta(self, c: Corpo) -> bool:
        """Vero se il corpo partecipa agli urti con muri e piattaforme."""
        return (c.ha("giocatore") or c.ha("gravità") or c.ha("nemico") or c.ha("rimbalza")
                or (c.ha("trascinabile") and c.d("trascinabile").get("lancia")) or c.tipo == "Proiettile"
                or c.proprieta.get("colpo"))

    def _muovi(self, c: Corpo, dt: float) -> None:
        if c.ha("piattaforma"):
            return
        if not (c.vx or c.vy or c.ha("gravità")):
            return
        prima_x, prima_y = c.x, c.y
        urta = self._urta(c)
        velocita = max(abs(c.vx), abs(c.vy)) * dt
        passi = max(1, min(8, int(math.ceil(velocita / 6))))
        sub = dt / passi
        era_a_terra = c.a_terra
        c.a_terra = False
        for _ in range(passi):
            # x
            c.x += c.vx * sub
            if urta:
                self._urti_x(c)
            # y
            fondo_prima = c.basso
            c.y += c.vy * sub
            if urta:
                self._urti_y(c, fondo_prima)
        if c.a_terra and not era_a_terra and c.ha("gravità"):
            c.salti = 0
            if c.ha("giocatore"):
                self._evento(c.nome, "atterra", {})
        if not c.a_terra:
            c.su = None
        self._bordi(c)
        if (c.x, c.y) != (prima_x, prima_y):
            c.spostamento = (c.spostamento[0] + c.x - prima_x, c.spostamento[1] + c.y - prima_y)

    def _rimbalza_su(self, c: Corpo, asse: str, bordo: str) -> bool:
        if not c.ha("rimbalza"):
            return False
        e = float(c.d("rimbalza")["elasticità"])
        if asse == "x":
            c.vx = -c.vx * e
        else:
            c.vy = -c.vy * e
            if c.ha("gravità") and abs(c.vy) < 60:
                c.vy = 0.0
        self._evento(c.nome, "rimbalzo", {"bordo": bordo})
        return True

    def _colpo_fermo(self, c: Corpo) -> bool:
        if c.proprieta.get("colpo") or c.tipo == "Proiettile":
            c.visibile = False
            c.via = bool(c.copia_di or c.proprieta.get("colpo"))
            self._cambia(c.nome, "visibile", False)
            return True
        return False

    def _urti_x(self, c: Corpo) -> None:
        for s in self._solidi(c):
            if s.d("piattaforma")["attraversabile"] or not _sovrapposti(c, s):
                continue
            if self._colpo_fermo(c):
                return
            if c.vx > 0 or (c.vx == 0 and c.x < s.x):
                c.x = s.x - c.w
                bordo = "destra"
            else:
                c.x = s.destra
                bordo = "sinistra"
            if not self._rimbalza_su(c, "x", bordo):
                if c.ha("nemico"):
                    c.vx = -c.vx
                else:
                    c.vx = 0.0
        for p in self.piastrelle:
            for r, k, s in p.celle(c.x, c.y, c.w, c.h):
                if s not in SOLIDI:
                    continue
                if self._colpo_fermo(c):
                    return
                tx, _ty, tw, _th = p.rettangolo(r, k)
                if c.vx > 0:
                    c.x = tx - c.w
                elif c.vx < 0:
                    c.x = tx + tw
                if not self._rimbalza_su(c, "x", "muro"):
                    c.vx = -c.vx if c.ha("nemico") else 0.0
                break

    def _urti_y(self, c: Corpo, fondo_prima: float) -> None:
        for s in self._solidi(c):
            if not _sovrapposti(c, s):
                continue
            muro = not s.d("piattaforma")["attraversabile"]
            if not muro and (c.vy < 0 or fondo_prima > s.y + 0.5):
                continue
            if self._colpo_fermo(c):
                return
            if c.vy >= 0 and fondo_prima <= s.y + max(6.0, abs(c.vy) / 60 + 2):
                c.y = s.y - c.h
                if not self._rimbalza_su(c, "y", "basso"):
                    c.vy = 0.0
                c.a_terra = True
                c.su = s
            elif muro:
                if c.vy < 0:
                    c.y = s.basso
                    if not self._rimbalza_su(c, "y", "alto"):
                        c.vy = 0.0
                else:
                    c.y = s.y - c.h
                    c.vy = 0.0
                    c.a_terra = True
                    c.su = s
        for p in self.piastrelle:
            for r, k, s in p.celle(c.x, c.y, c.w, c.h):
                if s not in SOLIDI and s not in PONTI:
                    continue
                _tx, ty, _tw, th = p.rettangolo(r, k)
                if s in PONTI and (c.vy < 0 or fondo_prima > ty + 0.5):
                    continue
                if self._colpo_fermo(c):
                    return
                if c.vy > 0 or (s in PONTI):
                    c.y = ty - c.h
                    if not self._rimbalza_su(c, "y", "basso"):
                        c.vy = 0.0
                    c.a_terra = True
                    c.su = None
                elif c.vy < 0:
                    c.y = ty + th
                    if not self._rimbalza_su(c, "y", "alto"):
                        c.vy = 0.0
                break

    def dimensione_mondo(self) -> tuple[float, float]:
        misura = getattr(self, "_misura", None)
        if misura is not None:
            return misura
        l, a = self.mondo_l, self.mondo_a
        if not l or not a:
            originali = [c for c in self.corpi.values() if not c.copia_di and not c.proprieta.get("colpo")]
            dx = max([self.larghezza] + [c.x0 + c.w for c in originali]
                     + [p.x + max((len(r) for r in p.mappa), default=0) * p.lato for p in self.piastrelle])
            dy = max([self.altezza] + [c.y0 + c.h for c in originali]
                     + [p.y + len(p.mappa) * p.lato_y for p in self.piastrelle])
            l, a = l or dx, a or dy
        self._misura = (max(l, self.larghezza), max(a, self.altezza))
        return self._misura

    def _dentro(self, c: Corpo) -> None:
        l, a = self.dimensione_mondo()
        c.x = max(0.0, min(l - c.w, c.x))
        c.y = max(0.0, min(a - c.h, c.y))

    def _bordi(self, c: Corpo) -> None:
        l, a = self.dimensione_mondo()
        fuori = ""
        if c.x < 0:
            fuori = "sinistra"
        elif c.destra > l:
            fuori = "destra"
        elif c.y < 0 and not c.ha("gravità"):
            fuori = "alto"
        elif c.basso > a:
            fuori = "basso"
        if not fuori:
            return
        if c.ha("rimbalza"):
            if fuori == "sinistra":
                c.x = 0.0
                c.vx = abs(c.vx)
            elif fuori == "destra":
                c.x = l - c.w
                c.vx = -abs(c.vx)
            elif fuori == "alto":
                c.y = 0.0
                c.vy = abs(c.vy)
            else:
                c.y = a - c.h
                c.vy = -abs(c.vy) * float(c.d("rimbalza")["elasticità"])
                if c.ha("gravità") and abs(c.vy) < 60:
                    c.vy = 0.0
                    c.a_terra = True
            self._evento(c.nome, "rimbalzo", {"bordo": fuori})
            return
        if c.ha("si_muove") or c.proprieta.get("colpo"):
            regola = c.d("si_muove").get("al_bordo", "sparisce") if c.ha("si_muove") else "sparisce"
            if fuori in ("sinistra", "destra", "alto", "basso") and (
                    (fuori == "sinistra" and c.destra < 0) or (fuori == "destra" and c.x > l)
                    or (fuori == "alto" and c.basso < 0) or (fuori == "basso" and c.y > a)):
                if regola == "ricomincia":
                    if fuori == "sinistra":
                        c.x = l
                    elif fuori == "destra":
                        c.x = -c.w
                    elif fuori == "alto":
                        c.y = a
                    else:
                        c.y = -c.h
                elif regola == "sparisce":
                    c.visibile = False
                    c.via = bool(c.copia_di or c.proprieta.get("colpo"))
                    self._cambia(c.nome, "visibile", False)
                    self._evento(c.nome, "esce", {"bordo": fuori})
            if regola == "rimbalza":
                if fuori in ("sinistra", "destra"):
                    c.x = max(0.0, min(l - c.w, c.x))
                    c.vx = -c.vx
                else:
                    c.y = max(0.0, min(a - c.h, c.y))
                    c.vy = -c.vy
                if c.ha("si_muove"):
                    s = c.d("si_muove")
                    opposti = {"sinistra": "destra", "destra": "sinistra", "su": "giù", "giù": "su"}
                    s["direzione"] = opposti[s["direzione"]]
            elif regola == "si_ferma":
                c.x = max(0.0, min(l - c.w, c.x))
                c.y = max(0.0, min(a - c.h, c.y))
                c.vx = c.vy = 0.0
                s = c.d("si_muove")
                s["velocità"] = 0
            return
        if c.ha("giocatore") and fuori == "basso" and c.y > a:
            # caduto nel vuoto: perde una vita e torna all'inizio
            self._evento(c.nome, "esce", {"bordo": "basso"})
            self._colpisci(c, None, 1)
            c.x, c.y, c.vx, c.vy = c.x0, c.y0, 0.0, 0.0
            return
        resta = (c.ha("giocatore") and c.d("giocatore").get("resta_dentro", True)) or c.ha("nemico") \
            or (c.ha("trascinabile") and c.d("trascinabile").get("resta_dentro", True))
        if resta:
            if fuori in ("sinistra", "destra"):
                c.x = max(0.0, min(l - c.w, c.x))
                if c.ha("nemico"):
                    c.vx = -c.vx
                elif c.ha("trascinabile"):
                    c.vx = -c.vx * 0.6
                else:
                    c.vx = 0.0
            elif fuori == "alto":
                c.y = 0.0
                c.vy = max(0.0, c.vy)
            elif fuori == "basso" and not c.ha("gravità"):
                c.y = a - c.h
                c.vy = 0.0 if not c.ha("trascinabile") else -c.vy * 0.6

    # --- contatti -------------------------------------------------------------------------------
    def _contatti(self, corpi: list[Corpo]) -> None:
        for i, a in enumerate(corpi):
            for b in corpi[i + 1:]:
                insieme = _sovrapposti(a, b)
                prima = b.nome in a.tocchi
                if insieme and not prima:
                    a.tocchi.add(b.nome)
                    b.tocchi.add(a.nome)
                    self._inizia_contatto(a, b)
                    if a.visibile and b.visibile:
                        self._inizia_contatto(b, a)
                elif not insieme and prima:
                    a.tocchi.discard(b.nome)
                    b.tocchi.discard(a.nome)
                elif insieme:
                    self._continua_contatto(a, b)
                    self._continua_contatto(b, a)
        for c in corpi:
            if c.ha("giocatore") and c.visibile:
                self._piastrelle_giocatore(c)

    def _tocca(self, a: Corpo, b: Corpo) -> None:
        self._evento(a.nome, "tocca", {"con": b.nome, "tipo_con": b.tipo, "originale_con": b.copia_di or b.nome})

    def _inizia_contatto(self, a: Corpo, b: Corpo) -> None:
        """``a`` ha appena toccato ``b`` (si chiama nei due versi)."""
        if not a.visibile or not b.visibile:
            return
        self._tocca(a, b)
        if a.ha("giocatore"):
            if b.ha("raccoglibile"):
                self._raccogli(a, b)
            elif b.ha("porta"):
                self._porta(a, b)
        if a.proprieta.get("colpo") or a.tipo == "Proiettile":
            self._colpo_su(a, b)

    def _continua_contatto(self, a: Corpo, b: Corpo) -> None:
        if not a.visibile or not b.visibile:
            return
        if a.ha("giocatore") and b.ha("nemico") and b.sconfitto <= 0:
            self._contro_nemico(a, b)

    def _contro_nemico(self, g: Corpo, n: Corpo) -> None:
        nd = n.d("nemico")
        if nd["si_schiaccia"] and g.vy > 0 and g.basso - g.vy * PASSO * 2 <= n.y + n.h * 0.45:
            # salto in testa: nemico sconfitto
            g.vy = -float(g.d("gravità").get("salto", 700)) * 0.55 if g.ha("gravità") else -300.0
            self._sconfiggi(n, g)
            return
        if g.invulnerabile > 0 or int(nd["toglie_vite"]) <= 0:
            return
        self._colpisci(g, n, int(nd["toglie_vite"]))
        # spinta all'indietro
        verso = -1 if n.centro()[0] > g.centro()[0] else 1
        g.vx = verso * 260.0
        if g.ha("gravità"):
            g.vy = -320.0
            g.a_terra = False

    def _sconfiggi(self, n: Corpo, da: Corpo) -> None:
        if n.sconfitto > 0:
            return
        n.sconfitto = 0.35
        n.speciale, n.tempo_speciale = "colpito", 0.35
        punti = int(n.d("nemico").get("punti", 0)) if n.ha("nemico") else 0
        self._evento(n.nome, "sconfitto", {"da": da.nome, "originale_da": da.copia_di or da.nome})
        chi = self._tiratore(da)
        self._evento(chi.nome, "sconfigge", {"nemico": n.nome, "punti": punti, "originale_nemico": n.copia_di or n.nome})
        if punti:
            self._aggiungi_punti(punti, "")
        self.azioni.append({"azione": "effetto", "effetto": "sconfitto", "nome": n.nome, "punti": punti,
                           "x": n.centro()[0], "y": n.y})
        self.azioni.append({"azione": "suono", "suono": "sconfitto"})

    def _tiratore(self, colpo: Corpo) -> Corpo:
        nome = colpo.proprieta.get("da")
        return self.corpi.get(nome, colpo) if nome else colpo

    def _colpisci(self, g: Corpo, da: Corpo | None, vite: int) -> None:
        if g.invulnerabile > 0:
            return
        g.invulnerabile = 1.5
        self._speciale(g, "colpito", 0.45)
        rimaste = None
        nome_vite = self._contatore_di("Vite", "")
        if nome_vite:
            k = self.contatori[nome_vite]
            rimaste = max(0, int(k["valore"]) - vite)
            self._contatore(nome_vite, rimaste)
        dati = {"da": da.nome if da else "", "vite": rimaste if rimaste is not None else 0}
        if da is not None:
            dati["originale_da"] = da.copia_di or da.nome
        self._evento(g.nome, "colpito", dati)
        self.azioni.append({"azione": "suono", "suono": "colpito"})
        self.azioni.append({"azione": "effetto", "effetto": "colpito", "nome": g.nome})

    def _raccogli(self, g: Corpo, o: Corpo) -> None:
        r = o.d("raccoglibile")
        o.visibile = False
        o.via = bool(o.copia_di)
        self._cambia(o.nome, "visibile", False)
        self.raccolti.append(nome_base(o.copia_di or o.nome))
        punti, vite = int(r["punti"]), int(r["vite"])
        self._evento(g.nome, "raccoglie", {"oggetto": o.nome, "punti": punti, "vite": vite,
                                           "originale_oggetto": o.copia_di or o.nome, "tipo_oggetto": o.tipo})
        self._evento(o.nome, "raccolto", {"da": g.nome})
        if punti:
            self._aggiungi_punti(punti, str(r.get("punteggio", "")))
        if vite:
            nome_vite = self._contatore_di("Vite", "")
            if nome_vite:
                k = self.contatori[nome_vite]
                self._contatore(nome_vite, max(0, min(int(k.get("massimo", 99)), int(k["valore"]) + vite)))
        if r.get("suono", "moneta") != "nessuno":
            self.azioni.append({"azione": "suono", "suono": r.get("suono", "moneta")})
        self.azioni.append({"azione": "effetto", "effetto": r.get("effetto", "stelle"), "nome": o.nome,
                            "punti": punti, "x": o.centro()[0], "y": o.centro()[1]})

    def _porta(self, g: Corpo, p: Corpo) -> None:
        d = p.d("porta")
        serve = str(d.get("serve") or "").strip()
        if serve and nome_base(serve).lower() not in [x.lower() for x in self.raccolti]:
            self.azioni.append({"azione": "messaggio", "testo": f"Serve: {serve}"})
            return
        va_a = str(d.get("va_a") or "")
        self._evento(p.nome, "entra", {"chi": g.nome, "va_a": va_a}, forzato=False)
        if d.get("messaggio"):
            self.azioni.append({"azione": "messaggio", "testo": str(d["messaggio"])})
        if va_a:
            self.azioni.append({"azione": "apri", "finestra": va_a})
        self.azioni.append({"azione": "suono", "suono": "porta"})

    def _colpo_su(self, colpo: Corpo, b: Corpo) -> None:
        if b is colpo or b.nome == colpo.proprieta.get("da") or b.ha("raccoglibile"):
            return
        if b.proprieta.get("colpo") or b.tipo == "Proiettile":
            return
        amico = bool(colpo.proprieta.get("amico", True))
        if b.tipo == "Bersaglio":
            cx, cy = b.centro()
            px, py = colpo.centro()
            self.colpisci_bersaglio(b.nome, px - b.x, py - b.y, self._tiratore(colpo).nome)
        elif amico and b.ha("nemico"):
            self._sconfiggi(b, colpo)
        elif not amico and b.ha("giocatore"):
            self._colpisci(b, colpo, 1)
        elif b.ha("piattaforma") and not b.d("piattaforma")["attraversabile"]:
            pass
        else:
            return
        colpo.visibile = False
        colpo.via = bool(colpo.copia_di or colpo.proprieta.get("colpo"))
        self._cambia(colpo.nome, "visibile", False)

    def colpisci_bersaglio(self, nome: str, x: float, y: float, da: str = "") -> int:
        """Un colpo (o un tocco) nel punto (x, y) del Bersaglio: punti secondo l'anello."""
        b = self.corpi.get(nome)
        if b is None:
            return 0
        anelli = max(1, int(b.proprieta.get("anelli", 5)))
        centro = int(b.proprieta.get("punti_centro", 100))
        raggio = min(b.w, b.h) / 2
        d = math.hypot(x - b.w / 2, y - b.h / 2)
        if d > raggio:
            return 0
        anello = min(anelli - 1, int(d / (raggio / anelli)))
        punti = int(round(centro * (anelli - anello) / anelli))
        self._evento(nome, "colpito", {"punti": punti, "x": round(x), "y": round(y), "da": da}, forzato=False)
        self._aggiungi_punti(punti, "")
        self.azioni.append({"azione": "effetto", "effetto": "punti", "nome": nome, "punti": punti,
                            "x": b.x + x, "y": b.y + y})
        return punti

    def _piastrelle_giocatore(self, g: Corpo) -> None:
        arrivi: set = set()                # mappe di cui il giocatore tocca l'arrivo (F) adesso
        for p in self.piastrelle:
            for r, k, s in list(p.celle(g.x + 2, g.y + 2, g.w - 4, g.h - 4)):
                if s in RACCOGLIBILI:
                    p.metti(r, k, ".")
                    self._cambia(p.nome, "mappa", list(p.mappa))
                    self._evento(p.nome, "raccolta", {"simbolo": s, "riga": r, "colonna": k, "da": g.nome},
                                 forzato=False)
                    if s == "c":
                        nome_vite = self._contatore_di("Vite", "")
                        if nome_vite:
                            kk = self.contatori[nome_vite]
                            self._contatore(nome_vite, min(int(kk.get("massimo", 99)), int(kk["valore"]) + 1))
                    else:
                        self._aggiungi_punti(RACCOGLIBILI[s], "")
                    tx, ty, tw, th = p.rettangolo(r, k)
                    self.azioni.append({"azione": "suono", "suono": "moneta" if s == "o" else "stella"})
                    self.azioni.append({"azione": "effetto", "effetto": "stelle", "nome": p.nome,
                                        "punti": RACCOGLIBILI[s], "x": tx + tw / 2, "y": ty + th / 2})
                elif s in PERICOLI:
                    if g.invulnerabile <= 0:
                        self._colpisci(g, None, 1)
                        if g.ha("gravità"):
                            g.vy = -420.0
                            g.a_terra = False
                elif s == "F" and not self.finita:
                    arrivi.add(p.nome)
                    if p.nome not in g.arrivi:
                        evento = "uscita" if p.tipo == "Labirinto" else "arrivo"
                        self._evento(p.nome, evento, {"chi": g.nome}, forzato=False)
                        self.azioni.append({"azione": "suono", "suono": "porta"})
                        if not self._con_gestore(p.nome, evento):
                            self._speciale(g, "vittoria", 1.5)
                            self._fine("vinta", "Livello completato!")
        g.arrivi = arrivi

    # --- colpi ----------------------------------------------------------------------------------
    def _spara(self, c: Corpo, forzato: bool = False) -> None:
        s = c.d("spara") if c.ha("spara") else {"ogni": 0.3, "direzione": "avanti", "velocità": 480,
                                                  "proiettile": "", "colore": "#FFCC00"}
        if c.ricarica > 0 and not forzato:
            return
        c.ricarica = float(s["ogni"])
        v = float(s["velocità"])
        direzione = s["direzione"]
        vx, vy = {"destra": (v, 0.0), "sinistra": (-v, 0.0), "su": (0.0, -v), "giù": (0.0, v)}.get(
            direzione, (v * c.guarda, 0.0))
        if direzione == "avanti" and c.ha("giocatore") and not c.ha("gravità") and c.d("giocatore")[
                "direzioni"] == "orizzontale":
            vx, vy = 0.0, -v        # astronave che va a destra e sinistra: spara in su
        if direzione == "verso_il_giocatore":
            gioc = [g for g in self.corpi.values() if g.ha("giocatore") and g.visibile]
            if gioc:
                gx, gy = gioc[0].centro()
                cx, cy = c.centro()
                d = math.hypot(gx - cx, gy - cy) or 1.0
                vx, vy = (gx - cx) / d * v, (gy - cy) / d * v
        modello = self.corpi.get(str(s.get("proiettile") or ""))
        self._contatore_copie += 1
        nome = f"{c.nome}_colpo{self._contatore_copie}"
        w, h = (modello.w, modello.h) if modello else (12.0, 12.0)
        cx, cy = c.centro()
        x = cx - w / 2 + (vx / v if v else 0) * (c.w / 2 + w / 2)
        y = cy - h / 2 + (vy / v if v else 0) * (c.h / 2 + h / 2)
        colpo = self.aggiungi(nome, modello.tipo if modello else "Proiettile", x, y, w, h, [],
                              colpo=True, da=c.nome, amico=c.ha("giocatore"), colore=str(s.get("colore", "#FFCC00")),
                              modello=modello.nome if modello else "")
        colpo.copia_di = modello.nome if modello else ""
        colpo.vx, colpo.vy = vx, vy
        colpo.guarda = 1 if vx >= 0 else -1
        colpo.angolo = math.degrees(math.atan2(vy, vx)) if (vx or vy) else 0.0
        self._evento(c.nome, "spara", {"colpo": nome})
        self.azioni.append({"azione": "nuovo", "nome": nome, "modello": modello.nome if modello else "",
                            "colore": str(s.get("colore", "#FFCC00"))})
        self.azioni.append({"azione": "suono", "suono": "sparo"})
        if c.tipo == "Personaggio":
            self._speciale(c, "attacco", 0.3)

    def _genera(self, c: Corpo, dt: float) -> None:
        g = c.d("generatore")
        c.generatore += dt
        if c.generatore < float(g["ogni"]):
            return
        c.generatore = 0.0
        vive = sum(1 for x in self.corpi.values() if x.copia_di == c.nome and x.visibile)
        if vive >= int(g["massimo"]):
            return
        self._contatore_copie += 1
        nome = f"{c.nome}_{self._contatore_copie}"
        l, a = self.dimensione_mondo()
        tx, ty = self.telecamera
        dove = g["dove"]
        fascia = float(g.get("fascia", 0) or 0)
        x, y = c.x0, c.y0
        if dove == "a_caso_in_alto":
            x = (c.x0 + self.casuale.tra(0, max(0.0, fascia - c.w)) if fascia
                 else tx + self.casuale.tra(0, max(0.0, self.larghezza - c.w)))
            y = ty - c.h
        elif dove == "a_caso_a_destra":
            x = tx + self.larghezza
            y = (c.y0 + self.casuale.tra(0, max(0.0, fascia - c.h)) if fascia
                 else ty + self.casuale.tra(0, max(0.0, self.altezza - c.h)))
        elif dove == "a_caso":
            x = tx + self.casuale.tra(0, max(0.0, self.larghezza - c.w))
            y = ty + self.casuale.tra(0, max(0.0, self.altezza - c.h))
        dinamiche = [dict(v) for k, v in c.dinamiche.items() if k != "generatore"]
        copia = self.aggiungi(nome, c.tipo, x, y, c.w, c.h, dinamiche, **c.proprieta)
        copia.copia_di = c.nome
        copia.x0, copia.y0 = x, y
        copia.guarda = c.guarda
        self._evento(c.nome, "nuova_copia", {"copia": nome})
        self.azioni.append({"azione": "nuovo", "nome": nome, "modello": c.nome})

    # --- telecamera ----------------------------------------------------------------------------
    def _telecamera(self, dt: float) -> None:
        self._misura = None
        bersaglio = self.corpi.get(self.segui) if self.segui else None
        if bersaglio is None:
            for c in self.corpi.values():
                if c.ha("telecamera") and c.visibile:
                    bersaglio = c
                    break
        if bersaglio is None and self.segui == "*":
            for c in self.corpi.values():
                if c.ha("giocatore") and c.visibile:
                    bersaglio = c
                    break
        l, a = self.dimensione_mondo()
        if bersaglio is not None:
            if bersaglio.ha("telecamera"):
                t = bersaglio.d("telecamera")
                self.morbidezza, self.asse = float(t["morbidezza"]), str(t["asse"])
            cx, cy = bersaglio.centro()
            ox, oy = cx - self.larghezza / 2, cy - self.altezza / 2
            k = 1 - (1 - max(0.01, min(1.0, self.morbidezza))) ** (dt * 60)
            if self.asse in ("entrambi", "orizzontale"):
                self.telecamera[0] += (ox - self.telecamera[0]) * k
            if self.asse in ("entrambi", "verticale"):
                self.telecamera[1] += (oy - self.telecamera[1]) * k
        self.telecamera[0] = max(0.0, min(l - self.larghezza, self.telecamera[0]))
        self.telecamera[1] = max(0.0, min(a - self.altezza, self.telecamera[1]))
        forza, resto = self.scossa
        if resto > 0:
            self.scossa = (forza, max(0.0, resto - dt))

    def spostamento_scossa(self) -> tuple[float, float]:
        forza, resto = self.scossa
        if resto <= 0:
            return 0.0, 0.0
        return (math.sin(self.tempo * 61) * forza * min(1.0, resto * 3),
                math.cos(self.tempo * 47) * forza * min(1.0, resto * 3))

    # --- contatori -----------------------------------------------------------------------------
    def _contatore_di(self, tipo: str, nome: str) -> str:
        if nome and nome in self.contatori:
            return nome
        for n, c in self.contatori.items():
            if c["tipo"] == tipo:
                return n
        return ""

    def _aggiungi_punti(self, punti: int, nome: str) -> None:
        n = self._contatore_di("Punteggio", nome)
        if n:
            self._contatore(n, int(self.contatori[n]["valore"]) + int(punti))

    def _contatore(self, nome: str, valore: Any) -> None:
        k = self.contatori[nome]
        if k["valore"] == valore:
            return
        k["valore"] = valore
        proprieta = "rimanenti" if k["tipo"] == "TimerDiGioco" else "valore"
        self._cambia(nome, proprieta, valore)
        self._evento(nome, "cambio", {proprieta: valore} if k["tipo"] == "TimerDiGioco" else {"valore": valore},
                     forzato=False)
        dinamiche = k["dinamiche"]
        if isinstance(valore, (int, float)) and valore <= 0 and not k["fatto_zero"]:
            k["fatto_zero"] = True
            if k["tipo"] == "Vite":
                self._evento(nome, "finite", {}, forzato=False)
            if "a_zero" in dinamiche:
                self._evento(nome, "zero", {}, forzato=False)
                z = dinamiche["a_zero"]
                if z["fai"] == "fine_partita":
                    self._fine("persa", str(z.get("messaggio") or "Fine partita!"))
                elif z["fai"] == "ricomincia":
                    self.azioni.append({"azione": "ricomincia"})
                elif z["fai"] == "vai_a" and z.get("va_a"):
                    self.azioni.append({"azione": "apri", "finestra": str(z["va_a"])})
        if "traguardo" in dinamiche and isinstance(valore, (int, float)) and not k["fatto_traguardo"]:
            t = dinamiche["traguardo"]
            if valore >= int(t["valore"]):
                k["fatto_traguardo"] = True
                self._evento(nome, "traguardo", {"valore": valore}, forzato=False)
                if t["fai"] == "vittoria":
                    for c in self.corpi.values():
                        if c.ha("giocatore"):
                            self._speciale(c, "vittoria", 2.0)
                    self._fine("vinta", str(t.get("messaggio") or "Livello completato!"))
                elif t["fai"] == "vai_a" and t.get("va_a"):
                    self.azioni.append({"azione": "apri", "finestra": str(t["va_a"])})

    def _fine(self, come: str, messaggio: str) -> None:
        if self.finita:
            return
        self.finita = come
        self.fermo = True
        punti = 0
        n = self._contatore_di("Punteggio", "")
        if n:
            punti = int(self.contatori[n]["valore"])
        self.azioni.append({"azione": "fine", "come": come, "messaggio": messaggio, "punti": punti})
        self.azioni.append({"azione": "suono", "suono": "vittoria" if come == "vinta" else "fine"})

    def ricomincia(self) -> None:
        """Rimette tutto come all'inizio (dopo "Fine partita" o "Ricomincia")."""
        ini = self._iniziale
        for nome in [n for n, c in self.corpi.items() if c.copia_di or c.proprieta.get("colpo")]:
            del self.corpi[nome]
            self.azioni.append({"azione": "togli", "nome": nome})
        for nome, (x, y, vx, vy, vis, din) in ini.get("corpi", {}).items():
            c = self.corpi.get(nome)
            if c is None:
                continue
            c.x, c.y, c.vx, c.vy, c.visibile = x, y, vx, vy, vis
            c.dinamiche = {k: dict(v) for k, v in din.items()}
            c.a_terra, c.su, c.invulnerabile, c.speciale, c.tempo_speciale = False, None, 0.0, "", 0.0
            c.sconfitto, c.opacita, c.tocchi, c.salti, c.generatore = 0.0, 1.0, set(), 0, 0.0
            self._cambia(nome, "visibile", vis)
            self._cambia_posizione(c)
        for nome, k in ini.get("contatori", {}).items():
            self.contatori[nome] = dict(k)
            proprieta = "rimanenti" if k["tipo"] == "TimerDiGioco" else "valore"
            self._cambia(nome, proprieta, k["valore"])
            if k["tipo"] == "TimerDiGioco":
                self._cambia(nome, "attivo", k.get("attivo", True))
        for p in self.piastrelle:
            if p.nome in ini.get("piastrelle", {}):
                p.mappa = list(ini["piastrelle"][p.nome])
                self._cambia(p.nome, "mappa", list(p.mappa))
        self.raccolti = []
        for c in self.corpi.values():
            c.arrivi = set()
        self.finita = ""
        self.fermo = False
        self.telecamera = [0.0, 0.0]
        self.tempo = 0.0

    # --- utilità -------------------------------------------------------------------------------
    def _speciale(self, c: Corpo, animazione: str, secondi: float) -> None:
        c.speciale, c.tempo_speciale = animazione, secondi

    def _evento(self, controllo: str, evento: str, dati: dict, forzato: bool = False) -> None:
        corpo = self.corpi.get(controllo)
        nome = controllo
        if corpo is not None and corpo.copia_di:
            # le copie mandano gli eventi a nome dell'originale (con il nome della copia)
            dati = dict(dati, copia=controllo)
            nome = corpo.copia_di
        elif corpo is not None and corpo.proprieta.get("colpo"):
            return
        if forzato or self._con_gestore(nome, evento):
            self.eventi.append((nome, evento, dati))

    def _cambia(self, nome: str, proprieta: str, valore: Any) -> None:
        corpo = self.corpi.get(nome)
        if corpo is not None and (corpo.copia_di or corpo.proprieta.get("colpo")):
            return
        self.cambi.setdefault(nome, {})[proprieta] = valore

    def _cambia_posizione(self, c: Corpo) -> None:
        self._cambia(c.nome, "sinistra", int(round(c.x)))
        self._cambia(c.nome, "alto", int(round(c.y)))

    def prendi_eventi(self) -> list[tuple[str, str, dict]]:
        """Gli eventi da mandare al programma (e li dimentica). Con gli eventi partono anche le posizioni."""
        e, self.eventi = self.eventi, []
        if e:
            for c in self.corpi.values():
                if not c.copia_di and not c.proprieta.get("colpo") and (c.vx or c.vy or c.ha("giocatore")):
                    self._cambia_posizione(c)
        return e

    def prendi_cambi(self) -> dict[str, dict]:
        c, self.cambi = self.cambi, {}
        return c

    def prendi_azioni(self) -> list[dict]:
        a, self.azioni = self.azioni, []
        return a

    def animazione(self, c: Corpo) -> tuple[str, int]:
        """L'animazione da mostrare per un Personaggio e il fotogramma (0..7)."""
        if c.speciale and c.tempo_speciale > 0:
            nome = c.speciale
            durata = {"colpito": 0.45, "attacco": 0.45}.get(nome, 0.0)
            if durata:
                fatto = 1 - max(0.0, c.tempo_speciale) / durata
                return nome, min(7, int(fatto * 8))
            return nome, int(c.tempo * 10) % 8
        gravita = c.ha("gravità")
        if gravita and not c.a_terra and c.tempo_terra > 0.06:
            if c.vy < -250:
                return "salta", 2
            if c.vy < -60:
                return "salta", 3
            if c.vy < 120:
                return "salta", 4
            if c.vy < 400:
                return "salta", 5
            return "salta", 6
        v = abs(c.vx) if gravita else math.hypot(c.vx, c.vy)
        if v > 175:
            return "corre", int(c.tempo * 14) % 8
        if v > 12:
            return "cammina", int(c.tempo * 10) % 8
        return "fermo", int(c.tempo * 6) % 8


def _copia_ingressi(i: Ingressi) -> Ingressi:
    return Ingressi(i.sinistra, i.destra, i.su, i.giu, i.joystick, i.inclinazione, i.salta, i.spara, i.azione)


class _Casuale:
    """Numeri pseudo-casuali ripetibili (come labirinto.Casuale), per le copie del Generatore."""

    def __init__(self, seme: int) -> None:
        self.stato = int(seme) % 2147483647 or 1

    def tra(self, a: float, b: float) -> float:
        self.stato = (self.stato * 48271) % 2147483647
        return a + (b - a) * (self.stato / 2147483647)


__all__ = ["Mondo", "Corpo", "Ingressi", "Piastrelle", "PASSO", "TIPI_CHE_SCORRONO", "TIPI_CONTATORI", "nome_base"]
