"""Le DINAMICHE dei giochi: comportamenti che si assegnano a qualunque oggetto, senza codice.

Una dinamica è un comportamento pronto ("si muove con le frecce", "cade e salta", "si raccoglie e
dà punti", "è un nemico che pattuglia"...) con qualche regolazione (velocità, forza del salto,
punti...). Ogni controllo visibile ha la proprietà ``dinamiche``: una lista di dizionari, uno per
dinamica, con il nome della dinamica in ``"tipo"`` e le regolazioni cambiate::

    [{"tipo": "giocatore", "velocità": 260}, {"tipo": "gravità", "salto_doppio": vero}]

Nel pannello delle proprietà (Leo Studio e disegnatore del telefono) le dinamiche si aggiungono con
un pulsante e si regolano con i campi giusti; dal codice si usano ``Palla.aggiungi_dinamica("rimbalza")``,
``Palla.togli_dinamica("rimbalza")``, ``Giocatore.salta()`` e gli eventi ``quando Giocatore.tocca
Moneta fai ... fine``.

Il movimento e gli urti li calcola il motore di gioco a 60 fotogrammi al secondo: sul telefono la
pagina (``giochi.js``, con ``requestAnimationFrame``), sul PC :mod:`leo.grafica.giochi.motore` con un
timer. Python riceve solo gli eventi (tocchi, raccolte, colpi): mai un lavoro per fotogramma.

Questo modulo è puro (niente Qt) ed è il riferimento per tutti: nomi, regolazioni e predefiniti
sono gli stessi in ``giochi.js`` (lo controlla un test).
"""

from __future__ import annotations

import copy
import math
import re
from dataclasses import dataclass, field
from typing import Any

from ...errori import ErroreTipo, ErroreValore
from ...valori import nome_tipo
from ..metadati import Proprieta, semplifica_nome

# ===========================================================================
# Catalogo
# ===========================================================================


@dataclass(frozen=True)
class Regolazione:
    """Una regolazione di una dinamica (un campo nel pannello).

    ``tipo``: ``"numero"``, ``"intero"``, ``"logico"``, ``"scelta"``, ``"testo"``, ``"colore"`` o
    ``"controllo"`` (il nome di un altro controllo della finestra, "" = scelto da solo).
    """

    nome: str
    tipo: str
    predefinito: Any
    descrizione: str
    scelte: tuple[str, ...] = ()
    minimo: float | None = None
    massimo: float | None = None
    titolo: str = ""

    @property
    def etichetta(self) -> str:
        return self.titolo or self.nome.replace("_", " ").capitalize()


@dataclass(frozen=True)
class Dinamica:
    nome: str
    titolo: str
    descrizione: str
    icona: str
    regolazioni: tuple[Regolazione, ...] = ()
    eventi: tuple[str, ...] = ()
    sinonimi: tuple[str, ...] = field(default=())

    def regolazione(self, nome: str) -> Regolazione | None:
        chiave = semplifica_nome(str(nome)).replace(" ", "_")
        for r in self.regolazioni:
            if r.nome == nome or semplifica_nome(r.nome) == chiave:
                return r
        return None

    def predefiniti(self) -> dict[str, Any]:
        return {r.nome: copy.deepcopy(r.predefinito) for r in self.regolazioni}


def _r(nome, tipo, predefinito, descrizione, scelte=(), minimo=None, massimo=None, titolo=""):
    return Regolazione(nome, tipo, predefinito, descrizione, tuple(scelte), minimo, massimo, titolo)


#: Le dinamiche, nell'ordine in cui compaiono nel pannello.
_ELENCO: tuple[Dinamica, ...] = (
    Dinamica("giocatore", "Giocatore", "Si muove con le frecce, il joystick o inclinando il telefono",
             "gamepad", (
                 _r("comandi", "scelta", "automatici",
                    "Con che cosa si guida: \"automatici\" = frecce della tastiera, joystick e pulsanti da "
                    "gioco della finestra", ("automatici", "frecce", "joystick", "inclinazione")),
                 _r("direzioni", "scelta", "tutte", "In quali direzioni può andare (con la gravità solo a destra "
                    "e a sinistra)", ("tutte", "orizzontale", "verticale")),
                 _r("velocità", "numero", 220, "Pixel al secondo", minimo=0, massimo=3000),
                 _r("joystick", "controllo", "", "Nome del joystick da usare; se non lo scegli, il primo della finestra"),
                 _r("resta_dentro", "logico", True, "Non può uscire dal mondo (o dalla finestra)"),
                 _r("gira_immagine", "logico", True, "L'immagine guarda dalla parte in cui va"),
             ), ("tocca", "raccoglie", "colpito", "sconfigge", "esce"), ("player", "guida", "comandato")),
    Dinamica("gravità", "Gravità e salto", "Cade verso il basso, si ferma sulle piattaforme e salta",
             "freccia_giu", (
                 _r("forza", "numero", 1800, "Quanto tira verso il basso (pixel al secondo per secondo)",
                    minimo=0, massimo=20000, titolo="Forza di gravità"),
                 _r("salto", "numero", 700, "Forza del salto (pixel al secondo)", minimo=0, massimo=6000,
                    titolo="Forza del salto"),
                 _r("salto_doppio", "logico", False, "Può saltare di nuovo mentre è in aria"),
                 _r("caduta_massima", "numero", 1400, "Velocità massima di caduta (pixel al secondo)",
                    minimo=50, massimo=10000),
             ), ("salta", "atterra"), ("gravita", "salto", "cade", "salta", "peso")),
    Dinamica("piattaforma", "Piattaforma o muro", "Gli altri ci camminano sopra e non la attraversano",
             "piattaforma", (
                 _r("attraversabile", "logico", False, "Si attraversa saltando da sotto e ci si appoggia sopra "
                    "(falso = muro che blocca da tutte le parti)", titolo="Attraversabile dal basso"),
                 _r("movimento", "scelta", "ferma", "Se si sposta avanti e indietro da sola",
                    ("ferma", "orizzontale", "verticale")),
                 _r("distanza", "numero", 120, "Di quanti pixel si sposta", minimo=0, massimo=10000),
                 _r("velocità", "numero", 60, "Pixel al secondo", minimo=0, massimo=3000),
             ), (), ("muro", "pavimento", "terreno", "solido", "blocco")),
    Dinamica("raccoglibile", "Raccoglibile", "Si raccoglie toccandolo: dà punti (o vite) e sparisce",
             "stella", (
                 _r("punti", "intero", 10, "Punti che dà", minimo=-100000, massimo=100000),
                 _r("vite", "intero", 0, "Vite che dà (1 = un cuore in più)", minimo=-100, massimo=100),
                 _r("suono", "scelta", "moneta", "Suono quando si raccoglie",
                    ("moneta", "stella", "bonus", "nessuno")),
                 _r("effetto", "scelta", "stelle", "Come sparisce", ("stelle", "brilla", "sale", "sparisci")),
                 _r("punteggio", "controllo", "", "Punteggio a cui aggiungere i punti; se non lo scegli, il primo"),
             ), ("raccolto",), ("moneta", "premio", "bonus", "da_raccogliere", "raccogli")),
    Dinamica("nemico", "Nemico", "Se lo tocchi perdi una vita; può pattugliare o inseguirti",
             "teschio", (
                 _r("toglie_vite", "intero", 1, "Quante vite toglie", minimo=0, massimo=100),
                 _r("movimento", "scelta", "pattuglia", "Come si muove", ("fermo", "pattuglia", "insegue", "vola")),
                 _r("velocità", "numero", 80, "Pixel al secondo", minimo=0, massimo=3000),
                 _r("distanza", "numero", 160, "Quanto va avanti e indietro quando pattuglia", minimo=0,
                    massimo=10000),
                 _r("si_schiaccia", "logico", True, "Saltandogli sopra lo sconfiggi"),
                 _r("punti", "intero", 50, "Punti se lo sconfiggi", minimo=-100000, massimo=100000),
             ), ("sconfitto",), ("cattivo", "mostro", "avversario", "pericolo", "ostacolo")),
    Dinamica("spara", "Spara", "Lancia proiettili a ritmo o quando premi Spara", "mirino", (
        _r("quando", "scelta", "pulsante", "\"pulsante\" = con il pulsante Spara o la barra spaziatrice; "
           "\"sempre\" = da solo, a ritmo", ("pulsante", "sempre"), titolo="Quando spara"),
        _r("ogni", "numero", 0.6, "Secondi tra un colpo e l'altro", minimo=0.05, massimo=60,
           titolo="Un colpo ogni (secondi)"),
        _r("direzione", "scelta", "avanti", "Dove vanno i colpi (\"avanti\" = dove guarda)",
           ("avanti", "destra", "sinistra", "su", "giù", "verso_il_giocatore")),
        _r("velocità", "numero", 480, "Velocità dei colpi (pixel al secondo)", minimo=10, massimo=6000),
        _r("proiettile", "controllo", "", "Proiettile da copiare; se non lo scegli, una pallina"),
        _r("colore", "colore", "#FFCC00", "Colore della pallina"),
    ), ("spara",), ("sparare", "tiro", "lancia", "colpi")),
    Dinamica("rimbalza", "Rimbalza", "Si muove da solo e rimbalza sui bordi e sui muri", "palla", (
        _r("velocità_x", "numero", 180, "Pixel al secondo in orizzontale", minimo=-6000, massimo=6000),
        _r("velocità_y", "numero", -160, "Pixel al secondo in verticale (negativo = in su)", minimo=-6000,
           massimo=6000),
        _r("elasticità", "numero", 1.0, "1 = rimbalza sempre uguale, 0.5 = perde metà della forza", minimo=0,
           massimo=1.5),
    ), ("rimbalzo",), ("palla", "rimbalzo", "pallina")),
    Dinamica("trascinabile", "Trascinabile", "Si sposta con il dito o con il mouse", "mano", (
        _r("lancia", "logico", False, "Quando lo lasci continua ad andare (come una biglia lanciata)"),
        _r("torna_indietro", "logico", False, "Quando lo lasci torna al suo posto"),
        _r("resta_dentro", "logico", True, "Non esce dal mondo (o dalla finestra)"),
    ), ("preso", "lasciato"), ("trascina", "sposta", "dito")),
    Dinamica("ruota", "Ruota", "Gira su se stesso senza fermarsi", "ruota", (
        _r("velocità", "numero", 90, "Gradi al secondo (negativo = al contrario)", minimo=-7200, massimo=7200),
    ), (), ("gira", "rotazione")),
    Dinamica("lampeggia", "Lampeggia", "Si accende e si spegne a ritmo (avvisi, bonus a tempo, luci)", "lampo", (
        _r("volte_al_secondo", "numero", 2.0, "Quante volte al secondo lampeggia", minimo=0.1, massimo=30),
        _r("per_secondi", "numero", 0.0, "Per quanti secondi (0 = sempre)", minimo=0, massimo=3600),
        _r("minimo", "numero", 0.15, "Quanto resta visibile nel momento più spento (0 = sparisce, 1 = sempre "
           "pieno)", minimo=0, massimo=1, titolo="Opacità più bassa"),
    ), (), ("lampeggiare", "luce", "intermittente")),
    Dinamica("porta", "Porta", "Chi la tocca va a un'altra schermata (o a un altro livello)", "porta", (
        _r("va_a", "testo", "", "Nome della finestra da aprire; se non lo scegli, solo l'evento `entra`",
           titolo="Va a"),
        _r("serve", "testo", "", "Cosa bisogna aver raccolto per entrare; se non lo scegli, niente, per esempio "
           "\"Chiave\""),
        _r("messaggio", "testo", "", "Frase da mostrare entrando; se non lo scegli, nessuna"),
    ), ("entra",), ("uscita", "passaggio", "livello")),
    Dinamica("telecamera", "La telecamera segue", "Lo schermo scorre per tenere l'oggetto sempre in vista",
             "telecamera", (
                 _r("asse", "scelta", "entrambi", "In che direzione scorre lo schermo",
                    ("entrambi", "orizzontale", "verticale")),
                 _r("morbidezza", "numero", 0.15, "0 = fermo, 1 = segue di colpo", minimo=0.01, massimo=1),
             ), (), ("segui", "camera", "scorrimento")),
    Dinamica("generatore", "Generatore", "Crea copie dell'oggetto ogni tanto (nemici, monete, meteoriti...)",
             "copia", (
                 _r("ogni", "numero", 2.0, "Secondi tra una copia e l'altra", minimo=0.05, massimo=3600,
                    titolo="Una copia ogni (secondi)"),
                 _r("massimo", "intero", 10, "Quante copie al massimo nello stesso momento", minimo=1,
                    massimo=500),
                 _r("dove", "scelta", "qui", "Dove compaiono le copie",
                    ("qui", "a_caso_in_alto", "a_caso_a_destra", "a_caso")),
                 _r("fascia", "numero", 0, "Larghezza (o altezza) della striscia in cui compaiono, a partire "
                    "dall'originale (0 = tutto lo schermo): per esempio solo sulla strada", minimo=0, massimo=100000),
                 _r("nascondi_originale", "logico", True, "L'originale resta nascosto: si vedono solo le copie"),
             ), ("nuova_copia",), ("copie", "crea", "fabbrica", "spawn")),
    Dinamica("a_zero", "Quando arriva a zero", "Che cosa succede quando vite, tempo o punti arrivano a zero",
             "clessidra", (
                 _r("fai", "scelta", "fine_partita", "Cosa succede", ("fine_partita", "ricomincia", "vai_a", "niente"),
                    titolo="Poi"),
                 _r("messaggio", "testo", "Fine partita!", "Frase della fine della partita"),
                 _r("va_a", "testo", "", "Finestra da aprire con \"vai a\"", titolo="Va a"),
             ), ("zero",), ("zero", "fine", "fine_partita", "vite", "timer", "tempo")),
    Dinamica("traguardo", "Traguardo", "Quando il valore (punti, monete raccolte...) arriva a una soglia: vittoria",
             "trofeo", (
                 _r("valore", "intero", 100, "Valore da raggiungere", minimo=-1_000_000_000, massimo=1_000_000_000),
                 _r("fai", "scelta", "vittoria", "Cosa succede", ("vittoria", "vai_a", "niente"), titolo="Poi"),
                 _r("messaggio", "testo", "Livello completato!", "Frase della vittoria"),
                 _r("va_a", "testo", "", "Finestra da aprire con \"vai a\"", titolo="Va a"),
             ), ("traguardo",), ("obiettivo", "vittoria", "meta", "vinci")),
    Dinamica("si_muove", "Si muove da solo", "Va sempre nella stessa direzione (nuvole, auto, meteoriti)",
             "freccia_destra", (
                 _r("direzione", "scelta", "sinistra", "Dove va", ("sinistra", "destra", "su", "giù")),
                 _r("velocità", "numero", 120, "Pixel al secondo", minimo=0, massimo=6000),
                 _r("al_bordo", "scelta", "ricomincia", "Cosa fa quando esce dal mondo",
                    ("ricomincia", "rimbalza", "sparisce", "si_ferma")),
             ), (), ("muovi", "movimento", "va", "scorre")),
)

#: nome -> Dinamica
DINAMICHE: dict[str, Dinamica] = {d.nome: d for d in _ELENCO}
#: Nomi delle dinamiche, in ordine.
NOMI_DINAMICHE: tuple[str, ...] = tuple(DINAMICHE)

#: Eventi che le dinamiche mandano (a qualunque controllo visibile): nome -> chiavi del dizionario `evento`.
DATI_EVENTI_GIOCO: dict[str, tuple[str, ...]] = {
    "tocca": ("con", "tipo_con"),
    "raccoglie": ("oggetto", "punti", "vite"),
    "raccolto": ("da",),
    "colpito": ("da", "vite"),
    "sconfigge": ("nemico", "punti"),
    "sconfitto": ("da",),
    "esce": ("bordo",),
    "salta": (),
    "atterra": (),
    "rimbalzo": ("bordo",),
    "preso": (),
    "lasciato": ("x", "y"),
    "entra": ("chi", "va_a"),
    "nuova_copia": ("copia",),
    "spara": ("colpo",),
    "zero": (),
    "traguardo": ("valore",),
}
#: Nomi degli eventi di gioco (validi per qualunque controllo visibile, anche senza dinamiche).
EVENTI_GIOCO: tuple[str, ...] = tuple(DATI_EVENTI_GIOCO)


def _chiave(testo: str) -> str:
    return semplifica_nome(str(testo)).replace(" ", "_").replace("-", "_")


_SINONIMI_NOMI: dict[str, str] = {}
for _d in _ELENCO:
    _SINONIMI_NOMI[_chiave(_d.nome)] = _d.nome
    _SINONIMI_NOMI[_chiave(_d.titolo)] = _d.nome
    for _s in _d.sinonimi:
        _SINONIMI_NOMI.setdefault(_chiave(_s), _d.nome)
del _d


def nome_dinamica(nome: Any) -> str | None:
    """Nome canonico di una dinamica (``"Gravita"`` -> ``"gravità"``, ``"muro"`` -> ``"piattaforma"``) o None."""
    if not isinstance(nome, str):
        return None
    return _SINONIMI_NOMI.get(_chiave(nome))


def _suggerimento_nomi() -> str:
    return "Dinamiche: " + ", ".join(f'"{n}"' for n in NOMI_DINAMICHE) + "."


def _converti_regolazione(r: Regolazione, valore: Any, dinamica: str) -> Any:
    dove = f"`{r.nome}` della dinamica \"{dinamica}\""
    if r.tipo in ("numero", "intero"):
        if isinstance(valore, bool) or not isinstance(valore, (int, float)) or not math.isfinite(valore):
            raise ErroreTipo(f"La regolazione {dove} vuole un numero, non `{nome_tipo(valore)}`.")
        if r.tipo == "intero":
            if isinstance(valore, float) and not valore.is_integer():
                raise ErroreTipo(f"La regolazione {dove} vuole un numero intero.")
            valore = int(valore)
        if r.minimo is not None and valore < r.minimo:
            raise ErroreValore(f"La regolazione {dove} non può essere minore di {r.minimo:g}.")
        if r.massimo is not None and valore > r.massimo:
            raise ErroreValore(f"La regolazione {dove} non può essere maggiore di {r.massimo:g}.")
        return valore
    if r.tipo == "logico":
        if not isinstance(valore, bool):
            raise ErroreTipo(f"La regolazione {dove} vuole `vero` o `falso`, non `{nome_tipo(valore)}`.")
        return valore
    if r.tipo == "scelta":
        if isinstance(valore, str):
            k = _chiave(valore)
            for s in r.scelte:
                if _chiave(s) == k:
                    return s
        raise ErroreValore(f"`{valore}` non va bene per la regolazione {dove}.",
                           suggerimento="Valori ammessi: " + ", ".join(f'"{s}"' for s in r.scelte) + ".")
    if r.tipo in ("testo", "controllo", "colore"):
        if not isinstance(valore, str):
            raise ErroreTipo(f"La regolazione {dove} vuole un testo, non `{nome_tipo(valore)}`.")
        if r.tipo == "colore" and valore:
            try:
                from ..colori import normalizza_colore
                return normalizza_colore(valore)
            except Exception:  # noqa: BLE001 - un colore strano resta com'e'
                return valore
        return valore
    return valore


def converti_dinamica(voce: Any) -> dict:
    """Una voce della lista ``dinamiche`` in forma canonica (errori chiari in italiano).

    Si accettano ``"gravità"`` (solo il nome) o ``{"tipo": "gravità", "salto": 900}``; le regolazioni
    si scrivono anche senza accenti o con le maiuscole. Il risultato ha solo le regolazioni scritte.
    """
    if isinstance(voce, str):
        voce = {"tipo": voce}
    if not isinstance(voce, dict):
        raise ErroreTipo(f"Ogni dinamica è un nome (\"gravità\") o un dizionario, non `{nome_tipo(voce)}`.",
                         suggerimento='Per esempio `{"tipo": "giocatore", "velocità": 300}`.')
    grezzo = voce.get("tipo", voce.get("nome"))
    nome = nome_dinamica(grezzo)
    if nome is None:
        raise ErroreValore(f"La dinamica `{grezzo}` non esiste.", suggerimento=_suggerimento_nomi())
    d = DINAMICHE[nome]
    risultato: dict[str, Any] = {"tipo": nome}
    for k, v in voce.items():
        if k in ("tipo", "nome"):
            continue
        r = d.regolazione(k)
        if r is None:
            raise ErroreValore(f"La dinamica \"{nome}\" non ha la regolazione `{k}`.",
                               suggerimento="Regolazioni: " + ", ".join(f"`{x.nome}`" for x in d.regolazioni) + ".")
        risultato[r.nome] = _converti_regolazione(r, v, nome)
    return risultato


def converti_dinamiche(valore: Any) -> list[dict]:
    """La proprietà ``dinamiche`` in forma canonica (lista di dizionari con ``"tipo"``)."""
    if isinstance(valore, (str, dict)):
        valore = [valore]
    if not isinstance(valore, list):
        raise ErroreTipo(f"La proprietà `dinamiche` vuole una lista, non `{nome_tipo(valore)}`.",
                         suggerimento='Per esempio `["giocatore", "gravità"]`.')
    return [converti_dinamica(v) for v in valore]


def complete(valore: Any) -> list[dict]:
    """Le dinamiche con TUTTE le regolazioni (i predefiniti al posto di quelle mancanti).

    Tollerante: le voci sbagliate si saltano (serve al motore e al disegno, mai errori)."""
    risultato = []
    for v in valore if isinstance(valore, list) else []:
        try:
            voce = converti_dinamica(v)
        except (ErroreTipo, ErroreValore):
            continue
        piena = DINAMICHE[voce["tipo"]].predefiniti()
        piena.update(voce)
        risultato.append(piena)
    return risultato


def ha_dinamica(valore: Any, nome: str) -> bool:
    nome = nome_dinamica(nome) or nome
    return any(isinstance(v, dict) and nome_dinamica(v.get("tipo")) == nome
               or isinstance(v, str) and nome_dinamica(v) == nome for v in (valore if isinstance(valore, list) else []))


class ProprietaDinamiche(Proprieta):
    """La proprietà ``dinamiche``: una lista controllata con il catalogo delle dinamiche."""

    def converti(self, valore: Any) -> Any:
        return converti_dinamiche(valore)


def proprieta_dinamiche(predefinito: list | None = None) -> ProprietaDinamiche:
    return ProprietaDinamiche(
        "dinamiche", "lista", list(predefinito or []), "Dinamiche",
        "Comportamenti da gioco senza codice: giocatore, gravità e salto, piattaforma, raccoglibile, nemico, "
        "spara, rimbalza, trascinabile... (se ne possono mettere più di una)")


# ===========================================================================
# `quando Giocatore.tocca Moneta fai`: a chi corrisponde il nome scritto dopo l'evento
# ===========================================================================

_CIFRE_FINALI = re.compile(r"\d+$")


def corrisponde(filtro: str, dati: Any) -> bool:
    """Vero se l'oggetto dell'evento (``con``, ``oggetto``, ``da``, ``nemico``...) è ``filtro``.

    Vale il nome esatto (``Moneta3``), il tipo del controllo (``Moneta``, ``Nemico``) o il nome senza
    il numero finale (``Moneta`` per ``Moneta1``, ``Moneta2``...); maiuscole e accenti non contano."""
    if not isinstance(dati, dict):
        return False
    f = semplifica_nome(str(filtro))
    for chiave, tipo in (("con", "tipo_con"), ("oggetto", "tipo_oggetto"), ("da", "tipo_da"),
                         ("nemico", "tipo_nemico"), ("chi", "tipo_chi")):
        nome = dati.get(chiave)
        if not isinstance(nome, str) or not nome:
            continue
        candidati = {semplifica_nome(nome), semplifica_nome(_CIFRE_FINALI.sub("", nome))}
        t = dati.get(tipo)
        if isinstance(t, str) and t:
            candidati.add(semplifica_nome(t))
        base = dati.get("originale_" + chiave)
        if isinstance(base, str) and base:
            candidati.add(semplifica_nome(base))
            candidati.add(semplifica_nome(_CIFRE_FINALI.sub("", base)))
        if f in candidati:
            return True
    return False


# ===========================================================================
# Metodi di gioco di ogni controllo visibile (aggiunti da `metadati.registra`)
# ===========================================================================

#: Notifica ai motori (web e Qt) di un comando di gioco: stessa via degli effetti grafici.
TIPO_NOTIFICA = "gioco"


def comanda(controllo: Any, azione: str, **dati: Any) -> bool:
    """Manda un comando al motore di gioco che disegna il controllo (vero se qualcuno l'ha ricevuto)."""
    from .. import effetti as ef

    messaggio = {"tipo": TIPO_NOTIFICA, "effetto": azione, "durata": 0}
    messaggio.update({k: v for k, v in dati.items() if v is not None})
    return ef.notifica(controllo, messaggio)


def _numero(v: Any, cosa: str) -> float:
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
        raise ErroreTipo(f"{cosa} dev'essere un numero, non `{nome_tipo(v)}`.")
    return float(v)


def _m_salta(controllo, forza=None):
    """Fa saltare l'oggetto: `Palla.salta()` o `Palla.salta 15` (forza da 1 a 30: 10 è il salto normale)."""
    if forza is not None:
        forza = _numero(forza, "La forza del salto")
        if not 0 < forza <= 100:
            raise ErroreValore("La forza del salto va da 1 (saltino) a 30 (salto altissimo); 10 è normale.",
                               suggerimento="Per esempio `Giocatore.salta 12`.")
    comanda(controllo, "salta", forza=forza)


def _m_spingi(controllo, velocita_x=0, velocita_y=0):
    """Dà una spinta: `Palla.spingi(300, -200)` (pixel al secondo; y negativo = in su)."""
    comanda(controllo, "spingi", vx=_numero(velocita_x, "La spinta in orizzontale"),
            vy=_numero(velocita_y, "La spinta in verticale"))


def _m_ferma_movimento(controllo):
    """Ferma il movimento dell'oggetto (le dinamiche restano)."""
    comanda(controllo, "ferma")


def _m_spara(controllo):
    """Spara un colpo adesso (serve la dinamica "spara", altrimenti una pallina in avanti)."""
    comanda(controllo, "spara")


def _m_esulta(controllo, secondi=1.5):
    """Il personaggio esulta per un po' (salti di gioia)."""
    comanda(controllo, "esulta", secondi=_numero(secondi, "La durata"))


def _dinamiche_di(controllo) -> list:
    v = controllo.modello.proprieta.get("dinamiche")
    return list(v) if isinstance(v, list) else []


def _m_aggiungi_dinamica(controllo, nome, regolazioni=None):
    """Aggiunge una dinamica: `Palla.aggiungi_dinamica("rimbalza", {"velocità_x": 300})`."""
    voce = {"tipo": nome}
    if regolazioni is not None:
        if not isinstance(regolazioni, dict):
            raise ErroreTipo("Le regolazioni si scrivono come dizionario, per esempio `{\"velocità\": 300}`.")
        voce.update(regolazioni)
    voce = converti_dinamica(voce)
    lista = [v for v in _dinamiche_di(controllo) if nome_dinamica(v.get("tipo") if isinstance(v, dict) else v)
             != voce["tipo"]]
    lista.append(voce)
    controllo.scrivi("dinamiche", lista)


def _m_togli_dinamica(controllo, nome):
    """Toglie una dinamica: `Nemico1.togli_dinamica("nemico")`."""
    vero = nome_dinamica(nome)
    if vero is None:
        raise ErroreValore(f"La dinamica `{nome}` non esiste.", suggerimento=_suggerimento_nomi())
    lista = [v for v in _dinamiche_di(controllo) if nome_dinamica(v.get("tipo") if isinstance(v, dict) else v)
             != vero]
    controllo.scrivi("dinamiche", lista)


def _m_ha_dinamica(controllo, nome):
    """Vero se l'oggetto ha la dinamica: `se Palla.ha_dinamica("gravità") allora`."""
    return ha_dinamica(_dinamiche_di(controllo), str(nome))


def _m_regola(controllo, nome, regolazione, valore):
    """Cambia una regolazione: `Giocatore.regola("giocatore", "velocità", 400)`."""
    vero = nome_dinamica(nome)
    if vero is None:
        raise ErroreValore(f"La dinamica `{nome}` non esiste.", suggerimento=_suggerimento_nomi())
    lista = _dinamiche_di(controllo)
    for i, v in enumerate(lista):
        voce = {"tipo": v} if isinstance(v, str) else dict(v)
        if nome_dinamica(voce.get("tipo")) == vero:
            voce[regolazione] = valore
            lista[i] = converti_dinamica(voce)
            controllo.scrivi("dinamiche", lista)
            return
    raise ErroreValore(f"`{controllo.nome}` non ha la dinamica \"{vero}\".",
                       suggerimento=f"Aggiungila con `{controllo.nome}.aggiungi_dinamica(\"{vero}\")`.")


def _rettangolo(c: Any) -> tuple[float, float, float, float] | None:
    p = getattr(getattr(c, "modello", None), "proprieta", None)
    if not isinstance(p, dict):
        return None
    try:
        return (float(p.get("sinistra", 0)), float(p.get("alto", 0)), float(p.get("larghezza", 0)),
                float(p.get("altezza", 0)))
    except (TypeError, ValueError):
        return None


def _m_tocca(controllo, altro):
    """Vero se i due oggetti si toccano adesso: `se Giocatore.tocca(Lava) allora`."""
    a, b = _rettangolo(controllo), _rettangolo(altro)
    if a is None or b is None:
        raise ErroreTipo("`tocca` vuole un altro controllo della finestra, per esempio `Giocatore.tocca(Moneta1)`.")
    if getattr(getattr(altro, "modello", None), "proprieta", {}).get("visibile") is False:
        return False
    return a[0] < b[0] + b[2] and b[0] < a[0] + a[2] and a[1] < b[1] + b[3] and b[1] < a[1] + a[3]


METODI_GIOCO = {
    "salta": _m_salta, "spingi": _m_spingi, "ferma_movimento": _m_ferma_movimento, "spara": _m_spara, "esulta": _m_esulta,
    "aggiungi_dinamica": _m_aggiungi_dinamica, "togli_dinamica": _m_togli_dinamica,
    "ha_dinamica": _m_ha_dinamica, "regola": _m_regola, "tocca": _m_tocca,
}


# ===========================================================================
# Per i pannelli (Leo Studio e disegnatore del telefono)
# ===========================================================================

def catalogo_json() -> list[dict]:
    """Le dinamiche come dati JSON: ``[{nome, titolo, descrizione, icona, regolazioni: [...]}, ...]``."""
    risultato = []
    for d in _ELENCO:
        regolazioni = []
        for r in d.regolazioni:
            voce: dict[str, Any] = {"nome": r.nome, "tipo": r.tipo, "predefinito": r.predefinito,
                                    "descrizione": r.descrizione, "titolo": r.etichetta}
            if r.scelte:
                voce["scelte"] = list(r.scelte)
            if r.minimo is not None:
                voce["minimo"] = r.minimo
            if r.massimo is not None:
                voce["massimo"] = r.massimo
            regolazioni.append(voce)
        risultato.append({"nome": d.nome, "titolo": d.titolo, "descrizione": d.descrizione, "icona": d.icona,
                          "regolazioni": regolazioni, "eventi": list(d.eventi)})
    return risultato


def riassunto(valore: Any) -> str:
    """``"Giocatore, Gravità e salto"`` (per il campo nel pannello); ``"nessuna"`` se vuota."""
    nomi = []
    for v in valore if isinstance(valore, list) else []:
        n = nome_dinamica(v.get("tipo") if isinstance(v, dict) else v)
        if n:
            nomi.append(DINAMICHE[n].titolo)
    return ", ".join(nomi) if nomi else "nessuna"


def _letterale(v: Any) -> str:
    """Un valore come si scrive nel codice Leo (vero/falso, numeri con il punto, testi tra virgolette)."""
    if isinstance(v, bool):
        return "vero" if v else "falso"
    if isinstance(v, float):
        return str(int(v)) if v.is_integer() else repr(v)
    if isinstance(v, int):
        return str(v)
    if isinstance(v, str):
        return '"' + v.replace("\\", "\\\\").replace('"', '\\"') + '"'
    if isinstance(v, list):
        return "[" + ", ".join(_letterale(x) for x in v) + "]"
    if isinstance(v, dict):
        return "{" + ", ".join(f"{_letterale(str(k))}: {_letterale(x)}" for k, x in v.items()) + "}"
    return '""'


def codice_leo(nome: str, valore: Any, *, commenti: bool = True) -> str:
    """Il codice Leo che fa le stesse dinamiche del pannello (per leggerlo e per copiarlo nel programma).

    Solo le regolazioni diverse dal predefinito::

        # Giocatore: si muove con le frecce, il joystick o inclinando il telefono
        Eroe.aggiungi_dinamica("giocatore", {"velocità": 260})
    """
    righe = []
    for v in valore if isinstance(valore, list) else []:
        try:
            voce = converti_dinamica(v)
        except (ErroreTipo, ErroreValore):
            continue
        d = DINAMICHE[voce["tipo"]]
        cambiate = {k: x for k, x in voce.items() if k != "tipo" and x != d.regolazione(k).predefinito}
        if commenti:
            righe.append(f"# {d.titolo}: {d.descrizione[0].lower()}{d.descrizione[1:]}")
        if cambiate:
            righe.append(f'{nome}.aggiungi_dinamica("{d.nome}", {_letterale(cambiate)})')
        else:
            righe.append(f'{nome}.aggiungi_dinamica("{d.nome}")')
    return "\n".join(righe)


__all__ = ["codice_leo", "Regolazione", "Dinamica", "DINAMICHE", "NOMI_DINAMICHE", "DATI_EVENTI_GIOCO", "EVENTI_GIOCO",
           "nome_dinamica", "converti_dinamica", "converti_dinamiche", "complete", "ha_dinamica",
           "ProprietaDinamiche", "proprieta_dinamiche", "corrisponde", "comanda", "METODI_GIOCO", "TIPO_NOTIFICA",
           "catalogo_json", "riassunto"]
