"""L'ARTE dei giochi: oggetti, nemici, ostacoli, colpi, piattaforme, porte, paesaggi e piastrelle (SVG).

Tutto è generato qui, in Python puro, e diventa file SVG in ``android/app/src/main/assets/web/giochi/``
(``strumenti/genera_arte_giochi.py``) per il telefono; Leo Studio usa le stesse immagini direttamente
da questo modulo. Un nome pronto si scrive come ``gruppo:nome`` (``oggetto:moneta``, ``nemico:slime``,
``personaggio:volpe``): vedi :func:`svg`.

Misure:

* oggetti, ostacoli, colpi, porte: 64 x 64 (le porte 64 x 96);
* nemici: foglio 4 fotogrammi x 2 righe (si muove, colpito) di celle 64 x 64;
* piattaforme: piastrella 64 x 32 che si ripete in orizzontale;
* paesaggi: tre strati 960 x 540 (lontano, medio, vicino) che si ripetono in orizzontale + il cielo;
* piastrelle dei mondi: 32 x 32 (terreno sopra, terreno dentro, ponte, blocco, acqua).
"""

from __future__ import annotations

import math
import random
from functools import lru_cache

from .disegno import chiaro, mescola, scuro

N = "#1B1A22"     # contorno


def _svg(l: int, a: int, corpo: str, defs: str = "") -> str:
    d = f"<defs>{defs}</defs>" if defs else ""
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{l}" height="{a}" viewBox="0 0 {l} {a}">'
            f"{d}{corpo}</svg>")


def _rad(ident: str, colore: str, forza: float = 0.45) -> str:
    return (f'<radialGradient id="{ident}" cx="35%" cy="30%" r="80%"><stop offset="0" stop-color="{chiaro(colore, forza)}"/>'
            f'<stop offset=".55" stop-color="{colore}"/><stop offset="1" stop-color="{scuro(colore, .3)}"/>'
            f"</radialGradient>")


def _lin(ident: str, *colori: str, x2: float = 0, y2: float = 1) -> str:
    n = len(colori) - 1
    stop = "".join(f'<stop offset="{k / n:.2f}" stop-color="{c}"/>' for k, c in enumerate(colori))
    return f'<linearGradient id="{ident}" x1="0" y1="0" x2="{x2}" y2="{y2}">{stop}</linearGradient>'


def _stella(cx: float, cy: float, r1: float, r2: float, punte: int = 5, giro: float = -90) -> str:
    pts = []
    for k in range(punte * 2):
        r = r1 if k % 2 == 0 else r2
        a = math.radians(giro + k * 180 / punte)
        pts.append(f"{cx + math.cos(a) * r:.1f},{cy + math.sin(a) * r:.1f}")
    return " ".join(pts)


def _cuore_d(cx: float, cy: float, s: float) -> str:
    return (f"M{cx},{cy + s * 0.9}C{cx - s * 1.4},{cy + s * 0.1} {cx - s * 1.0},{cy - s * 0.95} {cx},{cy - s * 0.35}"
            f"C{cx + s * 1.0},{cy - s * 0.95} {cx + s * 1.4},{cy + s * 0.1} {cx},{cy + s * 0.9}Z")


# ===========================================================================
# Oggetti da raccogliere (64 x 64)
# ===========================================================================

def _oggetto(nome: str) -> str:
    if nome == "moneta":
        return _svg(64, 64, f'<circle cx="32" cy="32" r="25" fill="url(#g)" stroke="{N}" stroke-width="3"/>'
                    '<circle cx="32" cy="32" r="18" fill="none" stroke="#B8860B" stroke-width="2.5"/>'
                    '<path d="M28 20h8v24h-8z" fill="#E8A317" stroke="#9A6B00" stroke-width="1.5"/>'
                    '<ellipse cx="23" cy="20" rx="6" ry="3.5" fill="#FFF7C2" opacity=".8" transform="rotate(-35 23 20)"/>',
                    _rad("g", "#FFC928"))
    if nome == "gemma":
        return _svg(64, 64, f'<polygon points="32,6 54,24 32,58 10,24" fill="url(#g)" stroke="{N}" stroke-width="3" '
                    'stroke-linejoin="round"/><polygon points="32,6 42,24 32,58 22,24" fill="#7DF0C8" opacity=".55"/>'
                    '<polyline points="10,24 54,24" stroke="#0E7A5A" stroke-width="1.5"/>'
                    '<polygon points="24,12 30,10 26,20" fill="#FFFFFF" opacity=".85"/>', _rad("g", "#1FC48A"))
    if nome == "diamante":
        return _svg(64, 64, f'<polygon points="18,10 46,10 58,24 32,58 6,24" fill="url(#g)" stroke="{N}" '
                    'stroke-width="3" stroke-linejoin="round"/><polyline points="6,24 58,24" stroke="#2C7FB8" '
                    'stroke-width="1.6" fill="none"/><polyline points="18,10 26,24 32,58 38,24 46,10" '
                    'stroke="#2C7FB8" stroke-width="1.2" fill="none"/><polygon points="22,13 28,13 24,20" '
                    'fill="#FFFFFF" opacity=".9"/>', _rad("g", "#8FD6FF", .6))
    if nome == "stella":
        return _svg(64, 64, f'<polygon points="{_stella(32, 34, 27, 12)}" fill="url(#g)" stroke="{N}" '
                    'stroke-width="3" stroke-linejoin="round"/><circle cx="27" cy="31" r="2.6" fill="#3B2A00"/>'
                    '<circle cx="37" cy="31" r="2.6" fill="#3B2A00"/><path d="M28 38q4 3 8 0" stroke="#3B2A00" '
                    'stroke-width="2" fill="none" stroke-linecap="round"/>', _rad("g", "#FFD43B"))
    if nome == "cuore":
        return _svg(64, 64, f'<path d="{_cuore_d(32, 33, 22)}" fill="url(#g)" stroke="{N}" stroke-width="3"/>'
                    '<ellipse cx="22" cy="24" rx="5" ry="3" fill="#FFFFFF" opacity=".75" transform="rotate(-35 22 24)"/>',
                    _rad("g", "#F0283C"))
    if nome == "chiave":
        return _svg(64, 64, f'<g stroke="{N}" stroke-width="3" stroke-linejoin="round" fill="url(#g)">'
                    '<circle cx="20" cy="22" r="13"/><path d="M29 30l23 23-5 5-4-4-4 4-4-4-4 4-6-6z"/></g>'
                    '<circle cx="20" cy="22" r="5.5" fill="#7A5A00" stroke="#4A3600" stroke-width="1.5"/>',
                    _rad("g", "#F5C542"))
    if nome == "mela":
        return _svg(64, 64, f'<path d="M32 18c-10-6-24-2-24 14 0 14 10 26 18 26 3 0 4-2 6-2s3 2 6 2c8 0 18-12 18-26'
                    f' 0-16-14-20-24-14z" fill="url(#g)" stroke="{N}" stroke-width="3"/>'
                    f'<path d="M32 18c0-6 2-10 6-12" stroke="{N}" stroke-width="3" fill="none" stroke-linecap="round"/>'
                    f'<path d="M34 12c6-6 14-4 16-2-4 6-12 6-16 2z" fill="#4CB944" stroke="{N}" stroke-width="2"/>'
                    '<ellipse cx="20" cy="28" rx="4" ry="6" fill="#FFFFFF" opacity=".6"/>', _rad("g", "#E53935"))
    if nome == "fungo":
        return _svg(64, 64, f'<path d="M24 36h16v16a4 4 0 0 1-4 4h-8a4 4 0 0 1-4-4z" fill="#FFF3E0" stroke="{N}" '
                    f'stroke-width="3"/><path d="M6 36C6 18 18 8 32 8s26 10 26 28z" fill="url(#g)" stroke="{N}" '
                    'stroke-width="3"/><circle cx="20" cy="22" r="5" fill="#FFFFFF"/><circle cx="40" cy="18" r="4" '
                    'fill="#FFFFFF"/><circle cx="46" cy="30" r="3.5" fill="#FFFFFF"/><circle cx="28" cy="44" r="2" '
                    'fill="#1B1A22"/><circle cx="36" cy="44" r="2" fill="#1B1A22"/>', _rad("g", "#E53935"))
    if nome == "trofeo":
        return _svg(64, 64, f'<g stroke="{N}" stroke-width="3" stroke-linejoin="round"><path d="M14 12c-10 0-10 16 4 18"'
                    ' fill="none"/><path d="M50 12c10 0 10 16-4 18" fill="none"/><path d="M16 8h32v10c0 12-8 20-16 20'
                    'S16 30 16 18z" fill="url(#g)"/><path d="M28 38h8v8h-8z" fill="url(#g)"/>'
                    '<path d="M18 46h28v10H18z" fill="#6B4423"/></g><path d="M22 12h6v14c-4-2-6-6-6-10z" '
                    'fill="#FFF7C2" opacity=".7"/>', _rad("g", "#FFC928"))
    if nome == "pozione":
        return _svg(64, 64, f'<path d="M26 6h12v14l14 22c4 8-2 16-10 16H20c-8 0-14-8-10-16l16-22z" fill="#DDEBF7" '
                    f'stroke="{N}" stroke-width="3" stroke-linejoin="round"/><path d="M14 40h36l2 4c2 6-2 10-8 10H20'
                    'c-6 0-10-4-8-10z" fill="url(#g)"/><rect x="24" y="2" width="16" height="7" rx="2" fill="#8A5A3C" '
                    f'stroke="{N}" stroke-width="2.5"/><circle cx="26" cy="46" r="2.5" fill="#FFFFFF" opacity=".8"/>'
                    '<circle cx="36" cy="49" r="1.6" fill="#FFFFFF" opacity=".8"/>', _rad("g", "#B23CF0"))
    raise KeyError(nome)


# ===========================================================================
# Nemici: foglio 4 x 2 (si muove / colpito) di celle 64 x 64
# ===========================================================================

def _nemico_cella(nome: str, i: int, colpito: bool) -> str:
    t = i / 4
    s = math.sin(2 * math.pi * t)
    occhi_x = "M-4,-3l5,5M1,-3l-5,5" if colpito else ""

    def occhi(cx, cy, d=7, r=4.2):
        if colpito:
            return (f'<path d="M{cx - d - 3},{cy - 3}l6,6m0,-6l-6,6M{cx + d - 3},{cy - 3}l6,6m0,-6l-6,6" '
                    f'stroke="{N}" stroke-width="2.4" stroke-linecap="round"/>')
        return (f'<circle cx="{cx - d}" cy="{cy}" r="{r}" fill="#FFF"/><circle cx="{cx + d}" cy="{cy}" r="{r}" '
                f'fill="#FFF"/><circle cx="{cx - d + 1.4}" cy="{cy + .6}" r="{r * .5:.1f}" fill="{N}"/>'
                f'<circle cx="{cx + d + 1.4}" cy="{cy + .6}" r="{r * .5:.1f}" fill="{N}"/>'
                f'<path d="M{cx - d - 4},{cy - r - 2}l7,3M{cx + d + 4},{cy - r - 2}l-7,3" stroke="{N}" '
                'stroke-width="2.2" stroke-linecap="round"/>')
    del occhi_x
    if nome == "slime":
        sq = 1 + 0.12 * s
        alto = 36 * sq
        return (f'<path d="M8,58C8,{58 - alto:.1f} 20,{58 - alto - 6:.1f} 32,{58 - alto - 6:.1f}S56,{58 - alto:.1f} '
                f'56,58z" fill="url(#gs)" stroke="{N}" stroke-width="3"/>'
                f'<ellipse cx="22" cy="{58 - alto + 4:.1f}" rx="6" ry="3" fill="#FFF" opacity=".7"/>'
                + occhi(32, 58 - alto * 0.45) + '<path d="M26,52q6,4 12,0" stroke="#1B1A22" stroke-width="2" '
                'fill="none"/>')
    if nome == "fungo_cattivo":
        passo = 4 * s
        return (f'<ellipse cx="{24 + passo}" cy="58" rx="7" ry="4" fill="#3B2A1A" stroke="{N}" stroke-width="2"/>'
                f'<ellipse cx="{40 - passo}" cy="58" rx="7" ry="4" fill="#3B2A1A" stroke="{N}" stroke-width="2"/>'
                f'<path d="M20,34h24v18c0,4-4,6-12,6s-12-2-12-6z" fill="#F3E3C3" stroke="{N}" stroke-width="3"/>'
                f'<path d="M4,36C4,16 18,8 32,8S60,16 60,36z" fill="url(#gs)" stroke="{N}" stroke-width="3"/>'
                '<circle cx="18" cy="22" r="4" fill="#F3E3C3"/><circle cx="44" cy="18" r="5" fill="#F3E3C3"/>'
                + occhi(32, 44, 6, 3.6))
    if nome == "pipistrello":
        ala = 14 * s
        return (f'<path d="M30,30C20,{18 - ala:.1f} 8,{16 - ala:.1f} 2,{24 - ala * 0.6:.1f}C8,28 8,34 12,38'
                f'C16,34 20,36 24,40z" fill="url(#ga)" stroke="{N}" stroke-width="2.6" stroke-linejoin="round"/>'
                f'<path d="M34,30C44,{18 - ala:.1f} 56,{16 - ala:.1f} 62,{24 - ala * 0.6:.1f}C56,28 56,34 52,38'
                f'C48,34 44,36 40,40z" fill="url(#ga)" stroke="{N}" stroke-width="2.6" stroke-linejoin="round"/>'
                f'<ellipse cx="32" cy="36" rx="12" ry="13" fill="url(#gs)" stroke="{N}" stroke-width="3"/>'
                f'<path d="M23,26l2,-10 5,8M41,26l-2,-10 -5,8" fill="url(#gs)" stroke="{N}" stroke-width="2.4"/>'
                + occhi(32, 34, 5, 3.4) + '<path d="M28,43l2,3 2,-3 2,3 2,-3" stroke="#FFF" stroke-width="1.6" '
                'fill="none"/>')
    if nome == "fantasma":
        onda = 3 * s
        base = " ".join(f"{x},{56 + (onda if k % 2 else -onda):.1f}" for k, x in enumerate(range(10, 56, 6)))
        return (f'<path d="M10,58V30C10,16 20,8 32,8S54,16 54,30V58L{base.replace(" ", "L")}z" '
                f'fill="url(#gs)" stroke="{N}" stroke-width="3" stroke-linejoin="round" opacity=".95"/>'
                + occhi(32, 28, 8, 4.6) + '<ellipse cx="32" cy="42" rx="5" ry="6" fill="#1B1A22"/>')
    if nome == "ragno":
        zampe = ""
        for k in range(4):
            mov = 5 * math.sin(2 * math.pi * t + k)
            for lato in (-1, 1):
                x1 = 32 + lato * 10
                y1 = 34 + k * 4
                x2 = 32 + lato * (22 + k * 2)
                y2 = 24 + k * 6 + mov * lato
                x3 = 32 + lato * (28 + k * 2)
                zampe += (f'<polyline points="{x1},{y1} {x2},{y2:.1f} {x3},{58 - k}" fill="none" stroke="{N}" '
                          'stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>')
        return (zampe + f'<ellipse cx="32" cy="38" rx="15" ry="13" fill="url(#gs)" stroke="{N}" stroke-width="3"/>'
                + occhi(32, 36, 5, 3.6) + '<path d="M28,46v4M36,46v4" stroke="#F3E3C3" stroke-width="2"/>')
    if nome == "chiocciola":
        allunga = 4 * (s + 1) / 2
        return (f'<path d="M4,58C4,48 12,44 20,46L{48 + allunga:.1f},46C{54 + allunga:.1f},46 {58 + allunga:.1f},40 '
                f'{56 + allunga:.1f},34L{52 + allunga:.1f},30L{50 + allunga:.1f},40L{46 + allunga:.1f},38L{44 + allunga:.1f},'
                f'48L4,58z" fill="#C9B27C" stroke="{N}" stroke-width="2.6" stroke-linejoin="round"/>'
                f'<circle cx="26" cy="34" r="17" fill="url(#gs)" stroke="{N}" stroke-width="3"/>'
                '<path d="M26,34m-3,0a3,3 0 1,1 6,0a7,7 0 1,1 -14,0a11,11 0 1,1 22,0" fill="none" stroke="#7A3A12" '
                f'stroke-width="2.4"/><circle cx="{52 + allunga:.1f}" cy="30" r="3" fill="#FFF" stroke="{N}" '
                f'stroke-width="1.5"/><circle cx="{53 + allunga:.1f}" cy="30.5" r="1.4" fill="{N}"/>')
    raise KeyError(nome)


_COLORI_NEMICI = {"slime": ("#7ED957", "#7ED957"), "fungo_cattivo": ("#8E3BD6", "#8E3BD6"),
                  "pipistrello": ("#5B4B8A", "#3B2F5E"), "fantasma": ("#E8EEF7", "#E8EEF7"),
                  "ragno": ("#3A3448", "#3A3448"), "chiocciola": ("#E07A3A", "#E07A3A")}


def _nemico(nome: str) -> str:
    c1, c2 = _COLORI_NEMICI[nome]
    parti = []
    for riga in (0, 1):
        for i in range(4):
            cella = _nemico_cella(nome, i, riga == 1)
            filtro = ' opacity=".92"' if riga == 1 else ""
            sposta = (-3 if i % 2 else 3) if riga == 1 else 0
            parti.append(f'<g transform="translate({i * 64 + sposta} {riga * 64})"{filtro}>{cella}</g>')
    defs = _rad("gs", c1) + _rad("ga", c2, .3)
    return _svg(256, 128, "".join(parti), defs)


# ===========================================================================
# Ostacoli e colpi (64 x 64)
# ===========================================================================

def _ostacolo(nome: str) -> str:
    if nome == "spuntoni":
        punte = "".join(f'<polygon points="{x},60 {x + 8},16 {x + 16},60" fill="url(#g)" stroke="{N}" '
                        f'stroke-width="2.6" stroke-linejoin="round"/>' for x in range(0, 64, 16))
        return _svg(64, 64, punte + '<rect x="0" y="56" width="64" height="8" fill="#5A616C"/>',
                    _lin("g", "#F2F4F8", "#9AA3AE", "#5A616C", x2=1, y2=0))
    if nome == "lava":
        return _svg(64, 64, '<rect x="0" y="14" width="64" height="50" fill="url(#g)"/>'
                    '<path d="M0,16q8,-8 16,0t16,0t16,0t16,0V24H0z" fill="#FFD43B"/>'
                    '<circle cx="18" cy="36" r="4" fill="#FFB13B"/><circle cx="44" cy="46" r="3" fill="#FFB13B"/>'
                    '<circle cx="34" cy="28" r="2" fill="#FFE8A3"/>', _lin("g", "#FF8A1F", "#E0301E", "#8A1010"))
    if nome == "cactus":
        return _svg(64, 64, f'<g fill="url(#g)" stroke="{N}" stroke-width="3" stroke-linejoin="round">'
                    '<path d="M24,62V12a8,8 0 0 1 16,0V62z"/><path d="M24,40H14a6,6 0 0 1-6-6V22a5,5 0 0 1 10,0v8h6"/>'
                    '<path d="M40,34h8v-8a5,5 0 0 1 10,0v10a6,6 0 0 1-6,6H40"/></g>'
                    '<path d="M30,16v40M34,20v36" stroke="#2E7D32" stroke-width="1.5"/>'
                    '<path d="M28,24l-3,-1M36,30l3,-1M28,44l-3,-1" stroke="#F3E3C3" stroke-width="1.6"/>',
                    _rad("g", "#43A047", .3))
    if nome == "sega":
        denti = _stella(32, 32, 30, 22, 12, 0)
        return _svg(64, 64, f'<polygon points="{denti}" fill="url(#g)" stroke="{N}" stroke-width="2.6" '
                    f'stroke-linejoin="round"/><circle cx="32" cy="32" r="8" fill="#5A616C" stroke="{N}" '
                    'stroke-width="2.6"/><circle cx="32" cy="32" r="3" fill="#1B1A22"/>',
                    _rad("g", "#C7CED8", .5))
    if nome == "fuoco":
        return _svg(64, 64, f'<path d="M32,4C40,18 54,24 52,42C50,56 40,62 32,62S12,56 12,42C12,30 22,26 22,16'
                    f'C26,22 28,26 30,28C32,20 30,12 32,4z" fill="url(#g)" stroke="#8A1010" stroke-width="2.4"/>'
                    '<path d="M32,30C36,38 44,42 42,50C40,58 24,58 22,50C20,44 28,40 32,30z" fill="#FFE45C"/>',
                    _lin("g", "#FFD43B", "#FF8A1F", "#E0301E"))
    if nome == "cassa":
        return _svg(64, 64, f'<rect x="4" y="4" width="56" height="56" rx="4" fill="url(#g)" stroke="{N}" '
                    'stroke-width="3"/><rect x="10" y="10" width="44" height="44" fill="none" stroke="#6B4423" '
                    'stroke-width="3"/><path d="M10,10L54,54M54,10L10,54" stroke="#6B4423" stroke-width="4"/>',
                    _lin("g", "#D9A066", "#B07A44"))
    raise KeyError(nome)


def _proiettile(nome: str) -> str:
    if nome == "palla":
        return _svg(64, 64, f'<circle cx="32" cy="32" r="22" fill="url(#g)" stroke="{N}" stroke-width="3"/>'
                    '<ellipse cx="24" cy="23" rx="6" ry="4" fill="#FFF" opacity=".7"/>', _rad("g", "#FFCC00"))
    if nome == "freccia":
        return _svg(64, 64, f'<path d="M6,32H50" stroke="#7A4E2A" stroke-width="5" stroke-linecap="round"/>'
                    f'<polygon points="62,32 46,22 50,32 46,42" fill="#C7CED8" stroke="{N}" stroke-width="2.4" '
                    'stroke-linejoin="round"/><path d="M4,24l10,8-10,8M12,24l10,8-10,8" fill="none" '
                    'stroke="#D7132A" stroke-width="3"/>')
    if nome == "stella":
        return _svg(64, 64, f'<polygon points="{_stella(32, 32, 28, 12, 4, 0)}" fill="url(#g)" stroke="{N}" '
                    'stroke-width="2.6" stroke-linejoin="round"/><circle cx="32" cy="32" r="4" fill="#5A616C"/>',
                    _rad("g", "#C7CED8", .6))
    if nome == "laser":
        return _svg(64, 64, '<rect x="2" y="24" width="60" height="16" rx="8" fill="#FF2D46" opacity=".35"/>'
                    '<rect x="4" y="27" width="56" height="10" rx="5" fill="#FF2D46"/>'
                    '<rect x="8" y="30" width="48" height="4" rx="2" fill="#FFE1E5"/>')
    if nome == "palla_di_fuoco":
        return _svg(64, 64, '<path d="M4,32C14,18 30,12 46,14C58,16 62,26 62,32S58,48 46,50C30,52 14,46 4,32z" '
                    'fill="url(#g)"/><circle cx="44" cy="32" r="13" fill="#FFE45C"/><circle cx="46" cy="30" r="6" '
                    'fill="#FFFFFF"/>', _lin("g", "#E0301E", "#FF8A1F", "#FFD43B", x2=1, y2=0))
    if nome == "bolla":
        return _svg(64, 64, '<circle cx="32" cy="32" r="26" fill="#9FE3FF" opacity=".35" stroke="#5BC8F5" '
                    'stroke-width="3"/><path d="M18,22a18,18 0 0 1 14,-8" stroke="#FFF" stroke-width="4" fill="none" '
                    'stroke-linecap="round"/><circle cx="44" cy="40" r="3" fill="#FFF" opacity=".8"/>')
    raise KeyError(nome)


# ===========================================================================
# Piattaforme (piastrella 64 x 32 che si ripete)
# ===========================================================================

def _piattaforma(nome: str) -> str:
    if nome == "erba":
        return _svg(64, 32, '<rect width="64" height="32" fill="url(#t)"/>'
                    '<path d="M0,0H64V10Q60,14 56,10T48,10T40,10T32,10T24,10T16,10T8,10T0,10z" fill="#5CC34A"/>'
                    '<path d="M0,0H64V5H0z" fill="#86E070"/><circle cx="14" cy="20" r="2" fill="#6B4423"/>'
                    '<circle cx="44" cy="25" r="2.5" fill="#6B4423"/><circle cx="30" cy="16" r="1.5" fill="#B88A5A"/>',
                    _lin("t", "#A4703F", "#7A4E2A"))
    if nome == "pietra":
        return _svg(64, 32, '<rect width="64" height="32" fill="#7D8794"/>'
                    '<path d="M0,0H30V14H0zM32,0H64V14H32zM0,16H14V32H0zM16,16H48V32H16zM50,16H64V32H50z" '
                    'fill="url(#t)" stroke="#4E5662" stroke-width="1.5"/>', _lin("t", "#B7C0CC", "#8E98A6"))
    if nome == "legno":
        return _svg(64, 32, '<rect width="64" height="32" fill="url(#t)"/>'
                    '<path d="M0,10.5H64M0,21.5H64" stroke="#6B4423" stroke-width="2"/>'
                    '<path d="M20,0v10M50,11v10M8,22v10M40,22v10" stroke="#6B4423" stroke-width="2"/>'
                    '<circle cx="4" cy="5" r="1.4" fill="#4A2E16"/><circle cx="60" cy="5" r="1.4" fill="#4A2E16"/>',
                    _lin("t", "#D9A066", "#A8713A"))
    if nome == "ghiaccio":
        return _svg(64, 32, '<rect width="64" height="32" fill="url(#t)"/><path d="M0,0H64V6H0z" fill="#F2FBFF"/>'
                    '<path d="M10,12l10,8M40,10l6,12M52,8l-6,6" stroke="#FFFFFF" stroke-width="2" opacity=".8"/>',
                    _lin("t", "#BFEAFF", "#7CC7EC"))
    if nome == "nuvola":
        return _svg(64, 32, '<path d="M0,20C0,10 8,6 16,8C18,2 30,0 34,6C40,0 52,2 54,10C62,10 64,16 64,20'
                    'C64,28 56,30 48,28H12C4,30 0,26 0,20z" fill="#FFFFFF" stroke="#C9DDF0" stroke-width="2"/>'
                    '<path d="M6,24H58" stroke="#DCEAF7" stroke-width="3"/>')
    if nome == "metallo":
        return _svg(64, 32, '<rect width="64" height="32" fill="url(#t)"/><path d="M0,1H64" stroke="#E6EBF2" '
                    'stroke-width="2"/><path d="M0,31H64" stroke="#3E4652" stroke-width="2"/>'
                    '<circle cx="6" cy="8" r="2" fill="#3E4652"/><circle cx="58" cy="8" r="2" fill="#3E4652"/>'
                    '<circle cx="6" cy="24" r="2" fill="#3E4652"/><circle cx="58" cy="24" r="2" fill="#3E4652"/>'
                    '<path d="M16,16H48" stroke="#FFB13B" stroke-width="3" stroke-dasharray="6 4"/>',
                    _lin("t", "#A9B4C2", "#6E7A8A"))
    if nome == "mattoni":
        return _svg(64, 32, '<rect width="64" height="32" fill="#7A2E1E"/>'
                    '<path d="M1,1H31V15H1zM33,1H63V15H33zM-15,17H15V31H-15zM17,17H47V31H17zM49,17H79V31H49z" '
                    'fill="url(#t)"/>', _lin("t", "#D8603E", "#B4442A"))
    raise KeyError(nome)


# ===========================================================================
# Porte (64 x 96)
# ===========================================================================

def _porta(nome: str) -> str:
    if nome == "porta":
        return _svg(64, 96, f'<path d="M6,94V30C6,14 18,4 32,4S58,14 58,30V94z" fill="#6B4423" stroke="{N}" '
                    f'stroke-width="3"/><path d="M12,94V32C12,20 20,11 32,11S52,20 52,32V94z" fill="url(#g)"/>'
                    '<path d="M32,11V94M12,48H52M12,72H52" stroke="#6B4423" stroke-width="2"/>'
                    f'<circle cx="44" cy="60" r="3.5" fill="#F5C542" stroke="{N}" stroke-width="1.5"/>',
                    _lin("g", "#C8874A", "#9A5E2E"))
    if nome == "bandiera":
        return _svg(64, 96, f'<rect x="8" y="6" width="5" height="88" rx="2" fill="#C7CED8" stroke="{N}" '
                    f'stroke-width="2"/><circle cx="10.5" cy="6" r="5" fill="#F5C542" stroke="{N}" stroke-width="2"/>'
                    f'<path d="M13,12C26,6 38,18 58,12V44C38,50 26,38 13,44z" fill="url(#g)" stroke="{N}" '
                    'stroke-width="2.6"/><path d="M24,18h8v8h-8zM40,26h8v8h-8zM24,34h8v4h-8z" fill="#FFFFFF" '
                    'opacity=".9"/><ellipse cx="10" cy="93" rx="10" ry="3" fill="#000" opacity=".2"/>',
                    _lin("g", "#E0182D", "#A00F20", x2=1, y2=0))
    if nome == "portale":
        return _svg(64, 96, '<ellipse cx="32" cy="50" rx="28" ry="44" fill="url(#g)"/>'
                    '<ellipse cx="32" cy="50" rx="20" ry="34" fill="#1B0B3A" opacity=".55"/>'
                    '<ellipse cx="32" cy="50" rx="28" ry="44" fill="none" stroke="#B48CFF" stroke-width="4"/>'
                    '<path d="M32,20a14,30 0 0 1 0,60" stroke="#E6D9FF" stroke-width="2" fill="none" opacity=".6"/>',
                    '<radialGradient id="g"><stop offset="0" stop-color="#FFFFFF"/><stop offset=".3" '
                    'stop-color="#C79BFF"/><stop offset=".7" stop-color="#6A2BD9"/><stop offset="1" '
                    'stop-color="#2A0F66"/></radialGradient>')
    if nome == "castello":
        merli = "".join(f'<rect x="{x}" y="10" width="7" height="8" fill="url(#g)" stroke="{N}" stroke-width="2"/>'
                        for x in (4, 18, 32, 46))
        return _svg(64, 96, merli + f'<rect x="4" y="18" width="56" height="76" fill="url(#g)" stroke="{N}" '
                    f'stroke-width="3"/><path d="M20,94V62a12,12 0 0 1 24,0V94z" fill="#3B2A1A" stroke="{N}" '
                    'stroke-width="2.6"/><rect x="28" y="30" width="8" height="12" rx="4" fill="#3B2A1A"/>'
                    '<path d="M32,10V0" stroke="#5A616C" stroke-width="2"/><path d="M32,1l10,4-10,4z" fill="#D7132A"/>',
                    _lin("g", "#C9C2B6", "#9C9386"))
    raise KeyError(nome)


# ===========================================================================
# Veicoli (visti dall'alto: 64 x 96; astronavi 96 x 96)
# ===========================================================================

def _auto(colore: str) -> str:
    return _svg(64, 96, f'<rect x="6" y="14" width="8" height="18" rx="3" fill="#1B1A22"/><rect x="50" y="14" width="8" '
                f'height="18" rx="3" fill="#1B1A22"/><rect x="6" y="64" width="8" height="18" rx="3" fill="#1B1A22"/>'
                f'<rect x="50" y="64" width="8" height="18" rx="3" fill="#1B1A22"/>'
                f'<path d="M14,10C14,4 22,2 32,2S50,4 50,10V86C50,92 42,94 32,94S14,92 14,86z" fill="url(#g)" '
                f'stroke="{N}" stroke-width="2.5"/><path d="M18,26C22,22 42,22 46,26L44,38H20z" fill="#9FD3F5" '
                f'stroke="{N}" stroke-width="2"/><path d="M20,70H44L46,80C42,84 22,84 18,80z" fill="#7FB6D9" '
                f'stroke="{N}" stroke-width="2"/><rect x="20" y="42" width="24" height="24" rx="4" fill="{chiaro(colore, .15)}"/>'
                '<rect x="17" y="4" width="8" height="4" rx="2" fill="#FFF3B0"/><rect x="39" y="4" width="8" height="4" '
                'rx="2" fill="#FFF3B0"/><rect x="17" y="89" width="8" height="3" rx="1.5" fill="#FF4D4D"/>'
                '<rect x="39" y="89" width="8" height="3" rx="1.5" fill="#FF4D4D"/>', _lin("g", chiaro(colore, .25), colore,
                                                                                        scuro(colore, .2), x2=1, y2=0))


def _veicolo(nome: str) -> str:
    if nome == "auto_rossa":
        return _auto("#D7132A")
    if nome == "auto_blu":
        return _auto("#1971C2")
    if nome == "auto_gialla":
        return _auto("#F2B705")
    if nome == "auto_verde":
        return _auto("#2F9E44")
    if nome == "astronave":
        return _svg(96, 96, f'<path d="M48,4C58,18 62,34 62,52L84,70V82L62,74L58,86H38L34,74L12,82V70L34,52C34,34 38,18 48,4z" '
                    f'fill="url(#g)" stroke="{N}" stroke-width="3" stroke-linejoin="round"/>'
                    f'<path d="M48,18C53,26 55,34 55,44H41C41,34 43,26 48,18z" fill="#38D6FF" stroke="{N}" stroke-width="2"/>'
                    '<path d="M44,24l3,-4v12h-3z" fill="#FFFFFF" opacity=".8"/>'
                    '<path d="M38,86L44,96L48,90L52,96L58,86z" fill="#FFB13B"/><path d="M42,86L48,94L54,86z" fill="#FFE45C"/>'
                    '<path d="M12,70L34,56V64L12,76z" fill="#C8102E"/><path d="M84,70L62,56V64L84,76z" fill="#C8102E"/>',
                    _lin("g", "#F2F4F8", "#AEB6C2", "#6E7A8A", x2=1, y2=0))
    if nome == "astronave_nemica":
        return _svg(96, 96, f'<ellipse cx="48" cy="52" rx="44" ry="16" fill="url(#g)" stroke="{N}" stroke-width="3"/>'
                    f'<path d="M26,46C26,26 70,26 70,46z" fill="#7DF0C8" opacity=".85" stroke="{N}" stroke-width="2.5"/>'
                    '<circle cx="40" cy="40" r="4" fill="#1B1A22"/><circle cx="56" cy="40" r="4" fill="#1B1A22"/>'
                    + "".join(f'<circle cx="{x}" cy="56" r="3.2" fill="#FFE45C"/>' for x in (18, 33, 48, 63, 78)),
                    _lin("g", "#B48CFF", "#6A2BD9", "#2A0F66"))
    if nome == "asteroide":
        return _svg(96, 96, f'<path d="M30,8L62,6L86,26L90,58L70,86L36,90L10,70L6,36z" fill="url(#g)" stroke="{N}" '
                    'stroke-width="3" stroke-linejoin="round"/><circle cx="34" cy="34" r="9" fill="#6E6258"/>'
                    '<circle cx="62" cy="58" r="12" fill="#6E6258"/><circle cx="38" cy="66" r="6" fill="#6E6258"/>'
                    '<circle cx="66" cy="28" r="5" fill="#6E6258"/>', _rad("g", "#A89684", .3))
    if nome == "camion":
        return _svg(64, 128, f'<rect x="6" y="18" width="8" height="18" rx="3" fill="#1B1A22"/><rect x="50" y="18" width="8" '
                    'height="18" rx="3" fill="#1B1A22"/><rect x="6" y="96" width="8" height="20" rx="3" fill="#1B1A22"/>'
                    '<rect x="50" y="96" width="8" height="20" rx="3" fill="#1B1A22"/>'
                    f'<rect x="12" y="4" width="40" height="34" rx="8" fill="#1971C2" stroke="{N}" stroke-width="2.5"/>'
                    f'<rect x="17" y="10" width="30" height="12" rx="3" fill="#9FD3F5" stroke="{N}" stroke-width="2"/>'
                    f'<rect x="10" y="40" width="44" height="84" rx="4" fill="url(#g)" stroke="{N}" stroke-width="2.5"/>'
                    '<path d="M14,60H50M14,80H50M14,100H50" stroke="#B9BFC8" stroke-width="2"/>',
                    _lin("g", "#F2F4F8", "#C9CED6", x2=1, y2=0))
    raise KeyError(nome)


VEICOLI = ("auto_rossa", "auto_blu", "auto_gialla", "auto_verde", "astronave", "astronave_nemica", "asteroide", "camion")


def _strada(strato: str) -> str:
    """La strada vista dall'alto (si ripete in verticale): 540 x 960."""
    if strato == "cielo":
        return _svg(540, 960, '<rect width="540" height="960" fill="#4CA64C"/><rect x="90" width="360" height="960" '
                    'fill="#3D4148"/><rect x="80" width="10" height="960" fill="#F2F2EE"/><rect x="450" width="10" '
                    'height="960" fill="#F2F2EE"/>' + "".join(
                        f'<rect x="{x}" y="{y}" width="10" height="40" fill="#D7132A"/>' for x in (80, 450)
                        for y in range(0, 960, 80)) + "".join(
                        f'<circle cx="{x}" cy="{y}" r="2" fill="#3E8E3A"/>' for x, y in
                        ((20, 50), (50, 300), (30, 620), (510, 140), (490, 480), (520, 800))))
    if strato == "vicino":
        return _svg(540, 960, "".join(f'<rect x="{x}" y="{y}" width="8" height="60" rx="2" fill="#F2F2EE" opacity=".9"/>'
                                      for x in (176, 266, 356) for y in range(20, 960, 120)))
    if strato == "medio":
        alberi = []
        for k, (x, y) in enumerate(((36, 80), (40, 380), (30, 700), (504, 220), (500, 560), (508, 880))):
            alberi.append(f'<circle cx="{x}" cy="{y + 6}" r="30" fill="#000" opacity=".18"/><circle cx="{x}" cy="{y}" '
                          f'r="28" fill="#2E7D32"/><circle cx="{x - 8}" cy="{y - 8}" r="14" fill="#43A047"/>')
        return _svg(540, 960, "".join(alberi))
    return _svg(540, 960, "")


# ===========================================================================
# Paesaggi (tre strati 960 x 540 che si ripetono in orizzontale + cielo)
# ===========================================================================

SCENE = {
    # cielo (alto, basso), colori degli strati (lontano, medio, vicino)
    "colline": (("#7EC8F5", "#D9F0FF"), ("#A9D9A0", "#6FBF5C", "#3E8E3A")),
    "città": (("#F6A96B", "#FFE0B8"), ("#9C8BB5", "#6A5C8A", "#2E2742")),
    "spazio": (("#05060F", "#1A1440"), ("#2A2060", "#3D2A80", "#14102A")),
    "mare": (("#5EB8F0", "#CFEFFF"), ("#7FB6D9", "#2F8FD0", "#1B6FB0")),
    "bosco": (("#9ED8C8", "#E8F7EF"), ("#6FA88A", "#3E7A5A", "#1F4A34")),
    "montagne": (("#8CB8E8", "#EAF3FF"), ("#B7C3D6", "#7A8BA8", "#4A5A78")),
    "deserto": (("#F7C978", "#FFF0CF"), ("#E8B77A", "#D49A5A", "#B07438")),
}


def _onde(rnd: random.Random, base: float, ampiezze: tuple, periodi: tuple, larghezza: int = 960) -> list[float]:
    """Una linea periodica (si ripete esattamente ogni ``larghezza``) fatta di seni con periodi interi."""
    fasi = [rnd.random() * math.tau for _ in ampiezze]
    return [base + sum(a * math.sin(math.tau * p * x / larghezza + f) for a, p, f in zip(ampiezze, periodi, fasi))
            for x in range(0, larghezza + 1, 8)]


def _profilo(punti: list[float], colore: str, altezza: int = 540, passo: int = 8) -> str:
    d = "M0,{:.1f}".format(punti[0]) + "".join(f"L{k * passo},{y:.1f}" for k, y in enumerate(punti)) + \
        f"L960,{altezza}L0,{altezza}Z"
    return f'<path d="{d}" fill="{colore}"/>'


def _strato(scena: str, livello: int) -> str:
    rnd = random.Random(hash((scena, livello)) & 0xFFFF if False else (len(scena) * 131 + livello * 17))
    _cielo, colori = SCENE[scena]
    c = colori[livello]
    parti: list[str] = []
    if scena in ("colline", "bosco", "deserto"):
        base = (300, 380, 450)[livello]
        amp = ((40, 18), (30, 12), (16, 6))[livello]
        parti.append(_profilo(_onde(rnd, base, amp, (2, 5)), c))
        if scena == "bosco" and livello >= 1:
            for k in range(18 if livello == 1 else 10):
                x = (k * 960 / (18 if livello == 1 else 10) + rnd.random() * 20) % 960
                h = (90 if livello == 1 else 150) * (0.8 + rnd.random() * 0.4)
                yb = base + 10
                for dx in (0, -960, 960):
                    parti.append(f'<polygon points="{x + dx - h * .28:.0f},{yb:.0f} {x + dx:.0f},{yb - h:.0f} '
                                 f'{x + dx + h * .28:.0f},{yb:.0f}" fill="{scuro(c, 0.15)}"/>')
        if scena == "colline" and livello == 2:
            for k in range(12):
                x = k * 80 + 20
                parti.append(f'<circle cx="{x}" cy="{base + 10 + rnd.random() * 20:.0f}" r="{3 + rnd.random() * 3:.0f}" '
                             f'fill="{"#FFE45C" if k % 2 else "#FFFFFF"}"/>')
        if scena == "deserto" and livello == 2:
            for k in range(3):
                x = 160 + k * 320
                parti.append(f'<path d="M{x},{base + 6}v-50a10,10 0 0 1 20,0v50zM{x},{base - 20}h-14v-16a6,6 0 0 1 12,0v8"'
                             f' fill="#3E8E3A" stroke="#2E6B2A" stroke-width="3"/>')
    elif scena == "montagne":
        base = (280, 360, 450)[livello]
        punti = []
        n = (6, 9, 14)[livello]
        for k in range(n + 1):
            x = k * 960 / n
            punti.append((x, base - (120, 90, 40)[livello] * (0.6 + 0.4 * ((k * 7 + livello) % 3) / 2)))
            if k < n:
                punti.append((x + 960 / n / 2, base + 30))
        punti[-1] = (960, punti[0][1])
        d = "M" + "L".join(f"{x:.0f},{y:.0f}" for x, y in punti) + "L960,540L0,540Z"
        parti.append(f'<path d="{d}" fill="{c}"/>')
        if livello == 0:
            for x, y in punti[::2]:
                parti.append(f'<polygon points="{x - 22:.0f},{y + 26:.0f} {x:.0f},{y:.0f} {x + 22:.0f},{y + 26:.0f}" '
                             'fill="#FFFFFF" opacity=".9"/>')
    elif scena == "città":
        base = (360, 420, 480)[livello]
        x = 0
        while x < 960:
            w = (60, 80, 110)[livello] * (0.6 + rnd.random() * 0.6)
            w = min(w, 960 - x)
            h = (180, 160, 120)[livello] * (0.5 + rnd.random() * 0.7)
            parti.append(f'<rect x="{x:.0f}" y="{base - h:.0f}" width="{w + 1:.0f}" height="{540 - base + h:.0f}" '
                         f'fill="{c}"/>')
            if livello >= 1:
                for fy in range(int(base - h + 12), int(base), 22):
                    for fx in range(int(x + 8), int(x + w - 8), 16):
                        if rnd.random() < 0.55:
                            parti.append(f'<rect x="{fx}" y="{fy}" width="7" height="10" fill="#FFE8A3" '
                                         f'opacity="{0.5 if livello == 1 else 0.85}"/>')
            x += w + (0 if livello == 2 else rnd.random() * 10)
        parti.append(f'<rect x="0" y="{base}" width="960" height="{540 - base}" fill="{c}"/>')
    elif scena == "mare":
        if livello == 0:
            parti.append(_profilo(_onde(rnd, 330, (25, 8), (2, 5)), c))
        else:
            base = (0, 400, 470)[livello]
            parti.append(_profilo(_onde(rnd, base, (6, 3), (12, 30)), c))
            parti.append(_profilo([y + 14 for y in _onde(rnd, base, (5, 2), (16, 24))], scuro(c, 0.12)))
            if livello == 2:
                for k in range(16):
                    x = k * 60 + 10
                    parti.append(f'<path d="M{x},{base + 30}q10,-8 20,0" stroke="#FFFFFF" stroke-width="3" '
                                 'fill="none" opacity=".6"/>')
    elif scena == "spazio":
        if livello == 0:
            for k in range(120):
                x, y = rnd.random() * 960, rnd.random() * 540
                parti.append(f'<circle cx="{x:.0f}" cy="{y:.0f}" r="{rnd.random() * 1.4 + .4:.1f}" fill="#FFFFFF" '
                             f'opacity="{.4 + rnd.random() * .6:.2f}"/>')
        elif livello == 1:
            parti.append('<circle cx="700" cy="160" r="70" fill="url(#p1)"/><ellipse cx="700" cy="160" rx="110" '
                         'ry="18" fill="none" stroke="#C9B6FF" stroke-width="5" opacity=".7"/>'
                         '<circle cx="200" cy="300" r="26" fill="url(#p2)"/>')
        else:
            parti.append(_profilo(_onde(rnd, 480, (12, 6), (3, 8)), c))
            for k in range(8):
                x = k * 120 + 40
                parti.append(f'<ellipse cx="{x}" cy="{500 + rnd.random() * 20:.0f}" rx="{10 + rnd.random() * 10:.0f}" '
                             f'ry="4" fill="{scuro(c, .4)}"/>')
    defs = ""
    if scena == "spazio" and livello == 1:
        defs = _rad("p1", "#E07A3A") + _rad("p2", "#5BC8F5")
    return _svg(960, 540, "".join(parti), defs)


def _cielo(scena: str) -> str:
    (alto, basso), _c = SCENE[scena]
    extra = ""
    if scena in ("colline", "mare", "montagne", "bosco"):
        extra = ('<g fill="#FFFFFF" opacity=".85"><ellipse cx="180" cy="110" rx="70" ry="22"/>'
                 '<ellipse cx="220" cy="96" rx="44" ry="26"/><ellipse cx="640" cy="70" rx="90" ry="20"/>'
                 '<ellipse cx="610" cy="58" rx="40" ry="22"/></g>')
    if scena in ("deserto", "città"):
        extra = '<circle cx="760" cy="150" r="60" fill="#FFF3C4" opacity=".9"/>'
    return _svg(960, 540, f'<rect width="960" height="540" fill="url(#c)"/>{extra}', _lin("c", alto, basso))


# ===========================================================================
# Piastrelle dei mondi (32 x 32)
# ===========================================================================

MONDI = {
    # terreno sopra, terreno dentro, dettaglio, ponte, blocco
    "prato": ("#5CC34A", "#9A6338", "#7A4E2A", "#C8874A", "#E8A317"),
    "deserto": ("#F2C46D", "#D49A5A", "#B07438", "#C8874A", "#E07A3A"),
    "neve": ("#F2FBFF", "#8FB8D8", "#6A94B8", "#BFEAFF", "#5BC8F5"),
    "caverna": ("#6E6A80", "#4A4658", "#35323F", "#8A6A4A", "#9C7AD9"),
    "castello": ("#B8B0A2", "#8C8476", "#6E675C", "#7A4E2A", "#D7132A"),
    "spazio": ("#8FA3B8", "#4A5A6C", "#2E3946", "#5BC8F5", "#FF2D46"),
}


def _piastrella(mondo: str, tipo: str) -> str:
    sopra, dentro, dett, ponte, blocco = MONDI[mondo]
    if tipo == "terreno_sopra":
        return _svg(32, 32, f'<rect width="32" height="32" fill="{dentro}"/><path d="M0,0H32V9Q28,12 24,9T16,9T8,9T0,9z" '
                    f'fill="{sopra}"/><path d="M0,0H32V3H0z" fill="{chiaro(sopra, .3)}"/>'
                    f'<circle cx="9" cy="20" r="1.6" fill="{dett}"/><circle cx="24" cy="25" r="2" fill="{dett}"/>')
    if tipo == "terreno":
        return _svg(32, 32, f'<rect width="32" height="32" fill="{dentro}"/><circle cx="8" cy="8" r="1.6" '
                    f'fill="{dett}"/><circle cx="22" cy="16" r="2" fill="{dett}"/><circle cx="12" cy="26" r="1.4" '
                    f'fill="{dett}"/>')
    if tipo == "ponte":
        return _svg(32, 32, f'<rect y="0" width="32" height="12" fill="{ponte}" stroke="{scuro(ponte, .4)}" '
                    f'stroke-width="2"/><path d="M8,1v10M24,1v10" stroke="{scuro(ponte, .4)}" stroke-width="1.5"/>')
    if tipo == "blocco":
        return _svg(32, 32, f'<rect x="1" y="1" width="30" height="30" rx="3" fill="{blocco}" stroke="{N}" '
                    f'stroke-width="2"/><rect x="4" y="4" width="24" height="5" rx="2" fill="{chiaro(blocco, .4)}"/>'
                    f'<text x="16" y="24" font-family="Arial,sans-serif" font-weight="bold" font-size="14" '
                    f'text-anchor="middle" fill="{scuro(blocco, .5)}">?</text>')
    if tipo == "acqua":
        colore = "#FF8A1F" if mondo in ("caverna", "castello") else "#2F8FD0"
        return _svg(32, 32, f'<rect y="6" width="32" height="26" fill="{colore}" opacity=".85"/>'
                    f'<path d="M0,8q4,-4 8,0t8,0t8,0t8,0" stroke="{chiaro(colore, .5)}" stroke-width="2.5" fill="none"/>')
    raise KeyError(tipo)


TIPI_PIASTRELLE = ("terreno_sopra", "terreno", "ponte", "blocco", "acqua")


# ===========================================================================
# Indice
# ===========================================================================

OGGETTI = ("moneta", "gemma", "stella", "cuore", "chiave", "diamante", "mela", "fungo", "trofeo", "pozione")
NEMICI = tuple(_COLORI_NEMICI)
OSTACOLI = ("spuntoni", "lava", "cactus", "sega", "fuoco", "cassa")
PROIETTILI = ("palla", "freccia", "stella", "laser", "palla_di_fuoco", "bolla")
PIATTAFORME = ("erba", "pietra", "legno", "ghiaccio", "nuvola", "metallo", "mattoni")
PORTE = ("porta", "bandiera", "portale", "castello")


def elenco() -> dict[str, str]:
    """Tutte le immagini pronte: percorso relativo (``oggetto/moneta.svg``) -> testo SVG."""
    from . import personaggi

    tutto: dict[str, str] = {}
    for n in OGGETTI:
        tutto[f"oggetto/{n}.svg"] = _oggetto(n)
    for n in NEMICI:
        tutto[f"nemico/{n}.svg"] = _nemico(n)
    for n in OSTACOLI:
        tutto[f"ostacolo/{n}.svg"] = _ostacolo(n)
    for n in PROIETTILI:
        tutto[f"proiettile/{n}.svg"] = _proiettile(n)
    for n in PIATTAFORME:
        tutto[f"piattaforma/{n}.svg"] = _piattaforma(n)
    for n in PORTE:
        tutto[f"porta/{n}.svg"] = _porta(n)
    for n in SCENE:
        tutto[f"scena/{n}_cielo.svg"] = _cielo(n)
        for k, strato in enumerate(("lontano", "medio", "vicino")):
            tutto[f"scena/{n}_{strato}.svg"] = _strato(n, k)
    for strato in ("cielo", "lontano", "medio", "vicino"):
        tutto[f"scena/strada_{strato}.svg"] = _strada(strato)
    for n in VEICOLI:
        tutto[f"veicolo/{n}.svg"] = _veicolo(n)
    for m in MONDI:
        for t in TIPI_PIASTRELLE:
            tutto[f"mondo/{m}_{t}.svg"] = _piastrella(m, t)
    for n in personaggi.PERSONAGGI:
        tutto[f"personaggio/{n}.svg"] = personaggi.foglio(n)
    return tutto


@lru_cache(maxsize=1)
def _indice() -> dict[str, str]:
    return elenco()


def svg(percorso: str) -> str | None:
    """L'SVG di un'immagine pronta (``"oggetto/moneta.svg"``) o None."""
    return _indice().get(percorso)


__all__ = ["elenco", "svg", "VEICOLI", "OGGETTI", "NEMICI", "OSTACOLI", "PROIETTILI", "PIATTAFORME", "PORTE", "SCENE", "MONDI",
           "TIPI_PIASTRELLE", "mescola"]
