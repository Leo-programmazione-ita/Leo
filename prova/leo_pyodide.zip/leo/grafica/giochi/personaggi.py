"""I PERSONAGGI disegnati per Leo: fogli di animazione SVG generati da uno scheletro (senza Qt).

Ogni personaggio ha 7 animazioni da 8 fotogrammi (una riga del foglio ciascuna, celle 128 x 128,
guarda a destra; a sinistra lo gira chi lo disegna):

    fermo, cammina, corre, salta, colpito, attacco, vittoria

Gli stili: ``cartone`` (testa grande, contorno, sfumature morbide), ``piatto`` (colori pieni),
``pixel`` (pixel art 32 x 32), ``realistico`` (proporzioni vere, chiaroscuro) e ``fantascienza``
(armature metalliche e luci).

Il disegno è uno scheletro (anche, ginocchia, spalle, gomiti, testa) che si piega secondo la
posa di ogni fotogramma; ogni personaggio "veste" lo scheletro con le sue forme. Così le animazioni sono
fluide e uguali per tutti, e un personaggio nuovo è solo un insieme di colori e di parti.

API: :func:`foglio` (SVG completo del foglio), :func:`fotogramma` (SVG di una cella),
:data:`PERSONAGGI` (nome -> :class:`Personaggio`), :data:`ANIMAZIONI`, :data:`CELLA`.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Any, Callable

from .disegno import STILI, Tela, avvolgi, chiaro, mescola, punto_da, ruota, scuro

ANIMAZIONI = ("fermo", "cammina", "corre", "salta", "colpito", "attacco", "vittoria")
FOTOGRAMMI = 8
CELLA = 128
TERRA = 122.0   # dove poggiano i piedi nella cella


# ===========================================================================
# Pose
# ===========================================================================

@dataclass
class Posa:
    inclina: float = 0.0                 # busto (gradi, positivo = in avanti)
    testa: float = 0.0                   # testa rispetto al busto
    gambe: tuple = ((0.0, 0.0), (0.0, 0.0))      # (anca, ginocchio) dietro, davanti
    braccia: tuple = ((0.0, 10.0), (0.0, 10.0))  # (spalla, gomito) dietro, davanti
    alza: float = 0.0                    # quanto sta sopra la terra (salti di gioia)
    sposta: float = 0.0                  # spostamento orizzontale (colpito)
    schiaccia: float = 1.0               # < 1 = accovacciato
    occhi: str = "aperti"                # aperti, chiusi, felici, dolore, decisi
    bocca: str = "sorriso"               # sorriso, aperta, dolore, decisa, o
    arco: float = 0.0                    # scia dell'attacco (0 = niente; 1 = piena)
    lampo: bool = False                  # bocca del fuoco (armi da fuoco)
    coda: float = 0.0                    # oscillazione della coda (gradi)


def _onda(t: float, fase: float = 0.0) -> float:
    return math.sin(2 * math.pi * (t + fase))


def posa(animazione: str, i: int) -> Posa:
    """La posa del fotogramma ``i`` (0..7) di un'animazione."""
    t = i / FOTOGRAMMI
    s = _onda(t)
    c = _onda(t, 0.25)
    if animazione == "fermo":
        respiro = (s + 1) / 2
        return Posa(inclina=1.0 * s, testa=1.5 * s,
                    gambe=((-3, 4 + 3 * respiro), (4, 4 + 3 * respiro)),
                    braccia=((-6 - 2 * s, 14 + 3 * s), (8 + 2 * s, 16 + 3 * s)),
                    occhi="chiusi" if i == 6 else "aperti", coda=8 * s)
    if animazione == "cammina":
        return Posa(inclina=3, testa=-1 + 1.5 * abs(c),
                    gambe=((-26 * s, 6 + 32 * max(0.0, s)), (26 * s, 6 + 32 * max(0.0, -s))),
                    braccia=((22 * s, 18), (-22 * s, 22)),
                    alza=1.6 * abs(c), coda=14 * s)
    if animazione == "corre":
        return Posa(inclina=13, testa=-8,
                    gambe=((-46 * s + 6, 14 + 70 * max(0.0, s)), (46 * s + 6, 14 + 70 * max(0.0, -s))),
                    braccia=((52 * s, 85), (-52 * s, 88)),
                    alza=4.5 * abs(c), bocca="aperta" if i % 4 == 1 else "sorriso", coda=24 * s)
    if animazione == "salta":
        fasi = [
            Posa(inclina=10, testa=-6, gambe=((-30, 62), (-18, 58)), braccia=((-30, 20), (-36, 26)), schiaccia=0.9,
                 occhi="decisi", bocca="decisa"),
            Posa(inclina=4, testa=-4, gambe=((-8, 8), (4, 6)), braccia=((-150, 10), (-150, 14)), bocca="aperta"),
            Posa(inclina=2, testa=-2, gambe=((-14, 40), (38, 86)), braccia=((-155, 8), (-160, 12)), bocca="aperta"),
            Posa(inclina=0, testa=0, gambe=((-10, 50), (44, 92)), braccia=((-120, 20), (-128, 24)), bocca="aperta"),
            Posa(inclina=0, testa=2, gambe=((-6, 40), (36, 76)), braccia=((-90, 30), (-96, 30)), bocca="o"),
            Posa(inclina=-2, testa=3, gambe=((-4, 26), (24, 48)), braccia=((-70, 30), (-76, 30)), bocca="o"),
            Posa(inclina=-3, testa=4, gambe=((-2, 12), (14, 22)), braccia=((-55, 24), (-60, 26)), bocca="o"),
            Posa(inclina=6, testa=-2, gambe=((-14, 34), (-4, 30)), braccia=((-25, 20), (-30, 24)), schiaccia=0.95),
        ]
        return fasi[i]
    if animazione == "colpito":
        scossa = (-3.5, 3.5, -2.5, 2.5, -1.5, 1.5, -0.8, 0)[i]
        return Posa(inclina=-16 + 4 * (i / 7), testa=-12, gambe=((-14, 18), (20, 12)),
                    braccia=((-125, 30), (-110, 40)), sposta=scossa - 2 * (1 - i / 7),
                    occhi="dolore", bocca="dolore", coda=-20)
    if animazione == "attacco":
        # carica (0-2), colpo (3-4), ritorno (5-7)
        spalla = (-95, -125, -140, 40, 80, 70, 40, 15)[i]
        gomito = (-30, -40, -45, 10, 0, 6, 14, 18)[i]
        inclina = (-4, -8, -10, 10, 16, 14, 8, 3)[i]
        arco = (0, 0, 0, 1, 0.7, 0.25, 0, 0)[i]
        return Posa(inclina=inclina, testa=-inclina * 0.4,
                    gambe=((-18, 14), (24 + inclina * 0.6, 18)),
                    braccia=((-20 + inclina, 30), (spalla, gomito)),
                    occhi="decisi", bocca="decisa" if i < 3 else "aperta", arco=arco, lampo=i in (3, 4))
    if animazione == "vittoria":
        salto = (0, 5, 10, 13, 13, 10, 5, 0)[i]
        pugno = (165, 170, 175, 178, 178, 175, 170, 165)[i]
        return Posa(inclina=-3, testa=-8, gambe=((-10, 30 if salto else 6), (10, 40 if salto else 6)),
                    braccia=((-pugno + 25, -15), (pugno - 50, 40)), alza=salto, occhi="felici", bocca="aperta",
                    coda=25 * s)
    return Posa()


# ===========================================================================
# Scheletro
# ===========================================================================

@dataclass(frozen=True)
class Corpo:
    """Misure dello scheletro (pixel della cella)."""
    testa: float            # raggio della testa
    busto: float            # dall'anca al collo
    larghezza: float        # larghezza del busto (spalle)
    omero: float
    avambraccio: float
    coscia: float
    gamba: float
    piede: float
    r_braccio: tuple = (5.0, 4.0)
    r_gamba: tuple = (6.0, 5.0)
    collo: float = 0.0


@dataclass
class Scheletro:
    anca: tuple
    collo: tuple
    testa: tuple
    spalle: tuple           # (dietro, davanti)
    gomiti: tuple
    mani: tuple
    anche: tuple            # (dietro, davanti)
    ginocchia: tuple
    piedi: tuple
    inclina: float
    angolo_testa: float
    braccia: tuple          # angoli assoluti (omero, avambraccio) per lato
    gambe: tuple


def scheletro(corpo: Corpo, p: Posa, centro: float = 64.0) -> Scheletro:
    s = p.schiaccia
    # prima con l'anca a 0, poi si sposta tutto perché i piedi tocchino terra
    anca = (0.0, 0.0)
    inclina = p.inclina
    a = math.radians(inclina)
    lb = corpo.busto * s
    collo = (anca[0] + math.sin(a) * lb, anca[1] - math.cos(a) * lb)
    at = math.radians(inclina + p.testa)
    alto_testa = corpo.testa * 0.92 + corpo.collo
    testa = (collo[0] + math.sin(at) * alto_testa, collo[1] - math.cos(at) * alto_testa)
    spalla = (collo[0] - math.sin(a) * lb * 0.12, collo[1] + math.cos(a) * lb * 0.12)
    largo = corpo.larghezza * 0.16
    spalle = ((spalla[0] - largo, spalla[1]), (spalla[0] + largo, spalla[1]))
    anche = ((anca[0] - largo * 0.6, anca[1]), (anca[0] + largo * 0.6, anca[1]))
    gomiti, mani, angoli_b = [], [], []
    for k, (spa, gom) in enumerate(p.braccia):
        e = punto_da(*spalle[k], spa, corpo.omero)
        m = punto_da(*e, spa + gom, corpo.avambraccio)
        gomiti.append(e)
        mani.append(m)
        angoli_b.append((spa, spa + gom))
    ginocchia, piedi, angoli_g = [], [], []
    for k, (anc, gin) in enumerate(p.gambe):
        g = punto_da(*anche[k], anc, corpo.coscia * s)
        f = punto_da(*g, anc - gin, corpo.gamba * s)
        ginocchia.append(g)
        piedi.append(f)
        angoli_g.append((anc, anc - gin))
    basso = max(piedi[0][1], piedi[1][1])
    dy = TERRA - corpo.piede * 0.35 - basso - p.alza
    # niente deve uscire dalla cella in alto (salti di gioia con le braccia alzate)
    alto = min(testa[1] - corpo.testa * 1.25, mani[0][1] - 4, mani[1][1] - 4) + dy
    if alto < 2:
        dy += min(p.alza, 2 - alto)
    dx = centro + p.sposta

    def m(pt):
        return (pt[0] + dx, pt[1] + dy)

    return Scheletro(anca=m(anca), collo=m(collo), testa=m(testa), spalle=tuple(m(x) for x in spalle),
                     gomiti=tuple(m(x) for x in gomiti), mani=tuple(m(x) for x in mani),
                     anche=tuple(m(x) for x in anche), ginocchia=tuple(m(x) for x in ginocchia),
                     piedi=tuple(m(x) for x in piedi), inclina=inclina, angolo_testa=inclina + p.testa,
                     braccia=tuple(angoli_b), gambe=tuple(angoli_g))


# ===========================================================================
# Personaggi
# ===========================================================================

@dataclass
class Personaggio:
    nome: str
    stile: str
    titolo: str
    descrizione: str
    corpo: Corpo
    colori: dict
    testa: Callable[["Personaggio", Tela, Scheletro, Posa], None]
    busto: Callable[["Personaggio", Tela, Scheletro, Posa], None] | None = None
    dietro: Callable[["Personaggio", Tela, Scheletro, Posa], None] | None = None    # coda, mantello, zaino
    arma: str = ""            # spada, bastone, sciabola, arco, blaster, fucile ("" = pugno)
    extra: dict = field(default_factory=dict)


# --- parti comuni -------------------------------------------------------------

def _gamba(pg: Personaggio, t: Tela, sk: Scheletro, k: int, dietro: bool) -> None:
    c = pg.colori
    corpo = pg.corpo
    r1, r2 = corpo.r_gamba
    colore_pant = c.get("gambe", c["primario"])
    colore_pant = scuro(colore_pant, 0.18) if dietro else colore_pant
    an, gi, pi = sk.anche[k], sk.ginocchia[k], sk.piedi[k]
    stivale = c.get("stivali")
    with t.unisci():
        t.capsula(*an, *gi, r1, (r1 + r2) / 2, colore_pant)
        t.capsula(*gi, *pi, (r1 + r2) / 2, r2, colore_pant)
    if stivale:
        mezzo = ((gi[0] + pi[0] * 2) / 3, (gi[1] + pi[1] * 2) / 3)
        t.capsula(*mezzo, *pi, r2 * 1.12, r2 * 1.05, scuro(stivale, 0.15) if dietro else stivale)
    scarpa = c.get("scarpe", scuro(c["primario"], 0.45))
    scarpa = scuro(scarpa, 0.15) if dietro else scarpa
    ang = sk.gambe[k][1]
    lung = corpo.piede
    cx, cy = pi[0] + lung * 0.32, pi[1] + r2 * 0.25
    cx, cy = ruota(cx, cy, pi[0], pi[1], -ang * 0.5)
    t.ellisse(cx, cy, lung * 0.62, max(3.0, r2 * 0.78), scarpa, angolo=-ang * 0.5)
    if c.get("suola"):
        t.ellisse(cx, cy + r2 * 0.45, lung * 0.6, max(1.2, r2 * 0.25), c["suola"], angolo=-ang * 0.5, bordo=False)


def _braccio(pg: Personaggio, t: Tela, sk: Scheletro, k: int, dietro: bool, p: Posa) -> None:
    c = pg.colori
    r1, r2 = pg.corpo.r_braccio
    manica = c.get("braccia", c["primario"])
    pelle = c.get("mani", c.get("pelle", manica))
    if dietro:
        manica, pelle = scuro(manica, 0.18), scuro(pelle, 0.15)
    sp, go, ma = sk.spalle[k], sk.gomiti[k], sk.mani[k]
    avambraccio = c.get("avambracci", manica if c.get("maniche_lunghe", True) else pelle)
    if dietro:
        avambraccio = scuro(avambraccio, 0.15) if avambraccio not in (manica, pelle) else avambraccio
    with t.unisci():
        t.capsula(*sp, *go, r1, (r1 + r2) / 2, manica)
        t.capsula(*go, *ma, (r1 + r2) / 2, r2, avambraccio)
        if c.get("guanti"):
            t.cerchio(*ma, r2 * 1.35, scuro(c["guanti"], 0.15) if dietro else c["guanti"])
        else:
            t.cerchio(*ma, r2 * 1.25, pelle)
    if not dietro:
        _arma(pg, t, sk, p)


def _arma(pg: Personaggio, t: Tela, sk: Scheletro, p: Posa) -> None:
    arma = pg.arma
    mano = sk.mani[1]
    ang = sk.braccia[1][1]          # angolo dell'avambraccio (0 = giù)
    c = pg.colori
    if p.arco > 0 and arma in ("spada", "sciabola", "bastone", ""):
        # scia del colpo
        cx, cy = sk.spalle[1]
        r = pg.corpo.omero + pg.corpo.avambraccio + (28 if arma else 6)
        largo = 10 if arma else 6
        a1, a2 = math.radians(165), math.radians(35)      # da sopra la testa a davanti in basso
        x1, y1 = cx + math.sin(a1) * r, cy + math.cos(a1) * r
        x2, y2 = cx + math.sin(a2) * r, cy + math.cos(a2) * r
        x3, y3 = cx + math.sin(a2) * (r - 2), cy + math.cos(a2) * (r - 2)
        x4, y4 = cx + math.sin(a1) * (r - largo), cy + math.cos(a1) * (r - largo)
        d = (f"M{x1:.1f},{y1:.1f}A{r:.1f},{r:.1f} 0 0,1 {x2:.1f},{y2:.1f}L{x3:.1f},{y3:.1f}"
             f"A{r - largo:.1f},{r - largo:.1f} 0 0,0 {x4:.1f},{y4:.1f}Z")
        poli = [(cx + math.sin(a) * rr, cy + math.cos(a) * rr)
                for rr, giro in ((r, 1), (r - largo, -1)) for a in
                [a1 + (a2 - a1) * k / 10 for k in (range(11) if giro == 1 else range(10, -1, -1))]]
        t.percorso(d, c.get("scia", "#FFE08A"), poligono=poli, opacita=0.85 * p.arco, bordo=False, sfuma=False)
    if not arma:
        return
    a = math.radians(ang)
    dx, dy = math.sin(a), math.cos(a)       # direzione dell'avambraccio
    if arma in ("spada", "sciabola"):
        # l'arma prosegue l'avambraccio
        lung = 34 if arma == "spada" else 30
        punta = (mano[0] + dx * lung, mano[1] + dy * lung)
        base = (mano[0] + dx * 4, mano[1] + dy * 4)
        t.capsula(mano[0] - dx * 5, mano[1] - dy * 5, *base, 1.8, 1.8, "#5A3A22")
        gx, gy = -dy * 7, dx * 7
        t.capsula(base[0] - gx, base[1] - gy, base[0] + gx, base[1] + gy, 1.8, 1.8, c.get("elsa", "#C9A227"))
        lama = c.get("lama", "#D9DEE6")
        if arma == "sciabola":
            ctrl = (base[0] + dx * lung * 0.6 - dy * 7, base[1] + dy * lung * 0.6 + dx * 7)
            d = (f"M{base[0] - dy * 2.6:.1f},{base[1] + dx * 2.6:.1f}Q{ctrl[0]:.1f},{ctrl[1]:.1f} {punta[0]:.1f},"
                 f"{punta[1]:.1f}Q{ctrl[0] + dy * 4:.1f},{ctrl[1] - dx * 4:.1f} {base[0] + dy * 2.6:.1f},"
                 f"{base[1] - dx * 2.6:.1f}Z")
            t.percorso(d, lama, poligono=[(base[0] - dy * 2.6, base[1] + dx * 2.6), ctrl, punta,
                                         (base[0] + dy * 2.6, base[1] - dx * 2.6)])
        else:
            t.poligono([(base[0] - dy * 2.8, base[1] + dx * 2.8), (punta[0] - dy * 1.2, punta[1] + dx * 1.2),
                        (punta[0] + dx * 4, punta[1] + dy * 4), (punta[0] + dy * 1.2, punta[1] - dx * 1.2),
                        (base[0] + dy * 2.8, base[1] - dx * 2.8)], lama)
            t.linea(base[0], base[1], punta[0], punta[1], chiaro(lama, 0.6), 0.9, bordo=False, opacita=0.8)
    elif arma == "bastone":
        alto = (mano[0] - dx * 30, mano[1] - dy * 30)
        basso = (mano[0] + dx * 20, mano[1] + dy * 20)
        t.capsula(*alto, *basso, 2.2, 2.0, "#6B4423")
        t.cerchio(alto[0] - dx * 4, alto[1] - dy * 4, 5.2, c.get("gemma", "#38D6FF"), luce=True)
        t.cerchio(alto[0] - dx * 5 - 1.5, alto[1] - dy * 5 - 1.5, 1.6, "#FFFFFF", bordo=False, sfuma=False)
    elif arma == "arco":
        # arco tenuto davanti, in verticale rispetto all'avambraccio
        # arco verticale davanti alla mano: curva (8 pezzi) e corda
        a1 = (mano[0] - 2, mano[1] - 24)
        a2 = (mano[0] - 2, mano[1] + 24)
        ctrl = (mano[0] + 16, mano[1])
        t.linea(*a1, *a2, "#E8E2D0", 0.8, bordo=False)
        punti = []
        for k in range(9):
            u = k / 8
            punti.append(((1 - u) ** 2 * a1[0] + 2 * u * (1 - u) * ctrl[0] + u * u * a2[0],
                          (1 - u) ** 2 * a1[1] + 2 * u * (1 - u) * ctrl[1] + u * u * a2[1]))
        with t.unisci():
            for k in range(8):
                r1 = 1.4 + 1.2 * math.sin(math.pi * k / 8)
                r2 = 1.4 + 1.2 * math.sin(math.pi * (k + 1) / 8)
                t.capsula(*punti[k], *punti[k + 1], r1, r2, "#7A4E2A")
    elif arma in ("blaster", "fucile"):
        # l'arma è perpendicolare all'avambraccio, verso l'avanti
        avanti_x, avanti_y = math.sin(a + math.pi / 2), math.cos(a + math.pi / 2)
        if avanti_x < 0:
            avanti_x, avanti_y = -avanti_x, -avanti_y
        lung = 16 if arma == "blaster" else 28
        base = (mano[0] - avanti_x * 4, mano[1] - avanti_y * 4)
        punta = (mano[0] + avanti_x * lung, mano[1] + avanti_y * lung)
        corpo_arma = c.get("arma", "#3A3F4B")
        t.capsula(*base, *punta, 3.6, 2.6, corpo_arma)
        t.capsula(mano[0], mano[1], mano[0] + dx * 7, mano[1] + dy * 7, 2.2, 2.0, scuro(corpo_arma, 0.3))
        luce = c.get("luce", "#38D6FF")
        t.linea(base[0] + avanti_x * 3, base[1] + avanti_y * 3 - 1.2, punta[0] - avanti_x * 4,
                punta[1] - avanti_y * 4 - 1.2, luce, 1.2, bordo=False, luce=True)
        if p.lampo:
            fx, fy = punta[0] + avanti_x * 6, punta[1] + avanti_y * 6
            raggi = []
            for k in range(10):
                r = 9 if k % 2 == 0 else 4
                aa = math.radians(k * 36)
                raggi.append((fx + math.cos(aa) * r, fy + math.sin(aa) * r))
            t.poligono(raggi, "#FFE45C", bordo=False, sfuma=False)
            t.cerchio(fx, fy, 3, "#FFFFFF", bordo=False, sfuma=False)


def _busto_base(pg: Personaggio, t: Tela, sk: Scheletro, p: Posa) -> None:
    c = pg.colori
    corpo = pg.corpo
    an, co = sk.anca, sk.collo
    larghezza = corpo.larghezza
    # busto: capsula larga dalla vita alle spalle
    t.capsula(an[0], an[1] - 2, co[0], co[1] + larghezza * 0.22, larghezza * 0.42, larghezza * 0.5,
              c.get("busto", c["primario"]))
    if c.get("pancia"):
        mx, my = (an[0] * 0.55 + co[0] * 0.45), (an[1] * 0.55 + co[1] * 0.45)
        t.ellisse(mx + 2, my, larghezza * 0.3, larghezza * 0.42, c["pancia"], angolo=sk.inclina, bordo=False)
    if c.get("cintura"):
        t.capsula(an[0] - larghezza * 0.42, an[1] - 3, an[0] + larghezza * 0.42, an[1] - 3, 2.6, 2.6,
                  c["cintura"], bordo=False)
        t.ellisse(an[0] + larghezza * 0.12, an[1] - 3, 3.2, 2.6, c.get("fibbia", "#E5C14A"), bordo=False)


# --- facce -------------------------------------------------------------------------

def _occhio(t: Tela, x: float, y: float, r: float, p: Posa, iride: str = "#2B2B35", bianco: str = "#FFFFFF",
            sclera: bool = True) -> None:
    if p.occhi == "chiusi":
        t.linea(x - r * 0.9, y + r * 0.1, x + r * 0.9, y + r * 0.1, "#1B1A22", max(1.2, r * 0.35))
        return
    if p.occhi == "felici":
        t.linea(x - r * 0.9, y + r * 0.25, x, y - r * 0.55, "#1B1A22", max(1.2, r * 0.35))
        t.linea(x, y - r * 0.55, x + r * 0.9, y + r * 0.25, "#1B1A22", max(1.2, r * 0.35))
        return
    if p.occhi == "dolore":
        t.linea(x - r * 0.8, y - r * 0.6, x + r * 0.8, y + r * 0.2, "#1B1A22", max(1.2, r * 0.35))
        t.linea(x - r * 0.8, y + r * 0.6, x + r * 0.8, y - r * 0.2, "#1B1A22", max(1.2, r * 0.35))
        return
    if sclera:
        t.ellisse(x, y, r * 0.82, r, bianco, bordo=False, sfuma=False)
    ry = r * (0.62 if p.occhi == "decisi" else 0.72)
    t.ellisse(x + r * 0.22, y + r * 0.08, r * 0.52, ry, iride, bordo=False, sfuma=False)
    t.cerchio(x + r * 0.38, y - r * 0.22, max(0.8, r * 0.2), "#FFFFFF", bordo=False, sfuma=False)
    if p.occhi == "decisi":
        t.linea(x - r * 0.9, y - r * 1.05, x + r * 0.9, y - r * 0.6, "#1B1A22", max(1.2, r * 0.32))


def _bocca(t: Tela, x: float, y: float, w: float, p: Posa, colore: str = "#3B1D1D") -> None:
    if p.bocca in ("aperta", "dolore", "o"):
        if p.bocca == "o":
            t.ellisse(x, y + w * 0.1, w * 0.28, w * 0.34, colore, bordo=False, sfuma=False)
            return
        d = f"M{x - w * 0.5:.1f},{y:.1f}Q{x:.1f},{y + w * (0.9 if p.bocca == 'aperta' else 0.4):.1f} " \
            f"{x + w * 0.5:.1f},{y:.1f}Z"
        t.percorso(d, colore, poligono=[(x - w * 0.5, y), (x, y + w * 0.6), (x + w * 0.5, y)], bordo=False,
                   sfuma=False)
        if p.bocca == "aperta":
            t.ellisse(x, y + w * 0.42, w * 0.22, w * 0.12, "#E86A7A", bordo=False, sfuma=False)
        return
    if p.bocca == "decisa":
        t.linea(x - w * 0.4, y + w * 0.1, x + w * 0.4, y, colore, max(1.0, w * 0.14))
        return
    t.linea(x - w * 0.45, y, x - w * 0.1, y + w * 0.22, colore, max(1.0, w * 0.14))
    t.linea(x - w * 0.1, y + w * 0.22, x + w * 0.45, y - w * 0.02, colore, max(1.0, w * 0.14))


def _rt(sk: Scheletro, dx: float, dy: float) -> tuple[float, float]:
    """Punto relativo al centro della testa, ruotato con la testa."""
    hx, hy = sk.testa
    return ruota(hx + dx, hy + dy, hx, hy, sk.angolo_testa)


# --- teste dei personaggi --------------------------------------------------------------

def _testa_animale(pg: Personaggio, t: Tela, sk: Scheletro, p: Posa) -> None:
    c = pg.colori
    r = pg.corpo.testa
    hx, hy = sk.testa
    tipo = pg.extra.get("orecchie", "punta")
    pelo = c["pelo"]
    # orecchie dietro la testa
    if tipo == "punta":            # volpe
        for dx, scala in ((-r * 0.55, 0.9), (r * 0.25, 1.0)):
            b1, b2, cima = _rt(sk, dx - r * 0.32, -r * 0.6), _rt(sk, dx + r * 0.38, -r * 0.72), \
                _rt(sk, dx + r * 0.05, -r * 1.55 * scala)
            t.poligono([b1, cima, b2], pelo)
            i1, i2, ci = _rt(sk, dx - r * 0.14, -r * 0.7), _rt(sk, dx + r * 0.24, -r * 0.76), \
                _rt(sk, dx + r * 0.05, -r * 1.3 * scala)
            t.poligono([i1, ci, i2], c.get("interno", "#3A2A2A"), bordo=False)
    elif tipo == "gatto":
        for dx in (-r * 0.6, r * 0.2):
            b1, b2, cima = _rt(sk, dx - r * 0.3, -r * 0.55), _rt(sk, dx + r * 0.4, -r * 0.7), \
                _rt(sk, dx + r * 0.0, -r * 1.35)
            t.poligono([b1, cima, b2], pelo)
            t.poligono([_rt(sk, dx - r * 0.1, -r * 0.68), _rt(sk, dx + r * 0.0, -r * 1.1),
                        _rt(sk, dx + r * 0.24, -r * 0.74)], c.get("interno", "#F4A6B8"), bordo=False)
    elif tipo == "tonde":           # orsetto
        for dx in (-r * 0.62, r * 0.42):
            t.cerchio(*_rt(sk, dx, -r * 0.78), r * 0.34, pelo)
            t.cerchio(*_rt(sk, dx, -r * 0.78), r * 0.18, c.get("interno", "#E9C29B"), bordo=False)
    elif tipo == "corna":           # draghetto
        for dx in (-r * 0.5, r * 0.2):
            t.poligono([_rt(sk, dx - r * 0.16, -r * 0.7), _rt(sk, dx - r * 0.42, -r * 1.45),
                        _rt(sk, dx + r * 0.2, -r * 0.78)], c.get("corna", "#F3E2B3"))
    # testa
    if tipo == "rana":
        t.ellisse(hx, hy + r * 0.12, r * 1.12, r * 0.86, pelo)
        for dx in (-r * 0.45, r * 0.42):
            ex, ey = _rt(sk, dx, -r * 0.62)
            t.cerchio(ex, ey, r * 0.42, pelo)
            _occhio(t, ex + r * 0.05, ey, r * 0.3, p, sclera=True)
        mx, my = _rt(sk, r * 0.38, r * 0.3)
        t.ellisse(*_rt(sk, r * 0.15, r * 0.45), r * 0.75, r * 0.34, c.get("muso", "#C9F28B"), bordo=False,
                  angolo=sk.angolo_testa)
        _bocca(t, mx, my, r * 0.8, p)
        t.ellisse(*_rt(sk, -r * 0.55, r * 0.25), r * 0.17, r * 0.1, "#FF8FA3", bordo=False, opacita=0.7)
        return
    t.cerchio(hx, hy, r, pelo)
    # muso
    muso = c.get("muso")
    if tipo == "punta":
        # guance bianche e muso a punta arrotondato
        t.ellisse(*_rt(sk, -r * 0.15, r * 0.52), r * 0.55, r * 0.36, muso or "#FFFFFF", angolo=sk.angolo_testa - 10,
                  bordo=False)
        a, b, cpu, pu = _rt(sk, r * 0.25, -r * 0.02), _rt(sk, r * 0.2, r * 0.78), _rt(sk, r * 1.05, r * 0.42), \
            _rt(sk, r * 1.22, r * 0.3)
        d = (f"M{a[0]:.1f},{a[1]:.1f}Q{cpu[0]:.1f},{cpu[1] - r * 0.5:.1f} {pu[0]:.1f},{pu[1]:.1f}"
             f"Q{cpu[0]:.1f},{cpu[1] + r * 0.45:.1f} {b[0]:.1f},{b[1]:.1f}Z")
        t.percorso(d, muso or "#FFFFFF", poligono=[a, (cpu[0], cpu[1] - r * 0.25), pu, (cpu[0], cpu[1] + r * 0.2), b],
                   bordo=False)
        t.ellisse(*_rt(sk, r * 1.16, r * 0.27), r * 0.13, r * 0.1, "#1B1A22", bordo=False)
    elif tipo == "corna":
        t.ellisse(*_rt(sk, r * 0.75, r * 0.32), r * 0.55, r * 0.42, muso or chiaro(pelo, 0.3), angolo=sk.angolo_testa)
        t.cerchio(*_rt(sk, r * 1.05, r * 0.18), r * 0.07, "#1B1A22", bordo=False)
    else:
        t.ellisse(*_rt(sk, r * 0.55, r * 0.38), r * 0.5, r * 0.36, muso or chiaro(pelo, 0.5), angolo=sk.angolo_testa)
        t.ellisse(*_rt(sk, r * 0.86, r * 0.24), r * 0.14, r * 0.1, c.get("naso", "#2A1E22"), bordo=False)
    if tipo == "gatto":
        for k, dy in enumerate((-0.08, 0.08)):
            a = _rt(sk, r * 0.62, r * (0.42 + dy))
            b = _rt(sk, r * 1.5, r * (0.32 + dy * 3))
            t.linea(*a, *b, "#1B1A22", 0.8, bordo=False, opacita=0.8)
    # occhi (quello dietro più piccolo)
    _occhio(t, *_rt(sk, r * 0.05, -r * 0.18), r * 0.25, p)
    _occhio(t, *_rt(sk, r * 0.56, -r * 0.2), r * 0.29, p)
    _bocca(t, *_rt(sk, r * 0.55, r * 0.66), r * 0.42, p)
    t.ellisse(*_rt(sk, -r * 0.08, r * 0.38), r * 0.18, r * 0.1, "#FF8FA3", bordo=False, opacita=0.55)


def _testa_umana(pg: Personaggio, t: Tela, sk: Scheletro, p: Posa) -> None:
    """Teste umane (piatto, pixel, realistico): pelle, capelli, cappello o casco."""
    c = pg.colori
    r = pg.corpo.testa
    hx, hy = sk.testa
    e = pg.extra
    pelle = c.get("pelle", "#F1C27D")
    capelli = c.get("capelli")
    realistico = pg.stile == "realistico"
    # capelli dietro (coda, treccia)
    if capelli and e.get("coda_capelli"):
        a = _rt(sk, -r * 0.85, -r * 0.2)
        b = _rt(sk, -r * (1.35 + 0.08 * math.sin(p.coda / 10)), r * 0.85)
        t.capsula(*a, *b, r * 0.3, r * 0.16, capelli)
    if capelli and e.get("treccia"):
        a = _rt(sk, -r * 0.7, r * 0.1)
        for k in range(4):
            b = _rt(sk, -r * (0.9 + k * 0.12), r * (0.55 + k * 0.48))
            t.ellisse(*b, r * 0.26, r * 0.32, capelli)
    # collo
    co = sk.collo
    if not e.get("casco"):
        t.capsula(co[0], co[1] + 2, hx - r * 0.1, hy + r * 0.5, r * 0.36, r * 0.32, scuro(pelle, 0.1), bordo=False)
    # testa: per il realistico un ovale con la mascella
    if realistico:
        t.ellisse(hx, hy, r * 0.88, r * 1.06, pelle, angolo=sk.angolo_testa)
        t.ellisse(*_rt(sk, r * 0.42, r * 0.5), r * 0.5, r * 0.5, pelle, angolo=sk.angolo_testa, bordo=False)
        # naso
        t.poligono([_rt(sk, r * 0.78, -r * 0.1), _rt(sk, r * 1.0, r * 0.32), _rt(sk, r * 0.74, r * 0.36)],
                   scuro(pelle, 0.08), bordo=False)
        # orecchio
        t.ellisse(*_rt(sk, -r * 0.1, r * 0.05), r * 0.16, r * 0.24, scuro(pelle, 0.1), bordo=False)
    else:
        t.cerchio(hx, hy, r, pelle)
        t.ellisse(*_rt(sk, -r * 0.18, r * 0.1), r * 0.16, r * 0.22, scuro(pelle, 0.12), bordo=False)
    if e.get("barba"):
        t.ellisse(*_rt(sk, r * 0.38, r * 0.62), r * 0.55, r * 0.42, capelli or "#3B2A20", angolo=sk.angolo_testa,
                  bordo=False, opacita=0.92)
    # occhi
    if not e.get("casco_chiuso"):
        if realistico:
            ex, ey = _rt(sk, r * 0.52, -r * 0.1)
            t.ellisse(ex, ey, r * 0.15, r * 0.1, "#FFFFFF", bordo=False, sfuma=False)
            if p.occhi in ("chiusi", "felici", "dolore"):
                t.linea(ex - r * 0.16, ey, ex + r * 0.16, ey, "#2A1B14", 1.0)
            else:
                t.cerchio(ex + r * 0.05, ey, r * 0.08, c.get("iridi", "#4A3426"), bordo=False, sfuma=False)
            t.linea(*_rt(sk, r * 0.34, -r * 0.3), *_rt(sk, r * 0.72, -r * (0.36 if p.occhi != "decisi" else 0.22)),
                    capelli or "#2A1B14", 1.4)
            mx, my = _rt(sk, r * 0.58, r * 0.58)
            if p.bocca in ("aperta", "dolore", "o"):
                t.ellisse(mx, my, r * 0.16, r * (0.1 if p.bocca != "o" else 0.13), "#5A2424", bordo=False)
            else:
                t.linea(mx - r * 0.16, my, mx + r * 0.14, my - (r * 0.05 if p.bocca == "sorriso" else 0),
                        scuro(pelle, 0.45), 1.1)
        else:
            _occhio(t, *_rt(sk, r * 0.18, -r * 0.08), r * 0.22, p)
            _occhio(t, *_rt(sk, r * 0.62, -r * 0.1), r * 0.25, p)
            _bocca(t, *_rt(sk, r * 0.5, r * 0.5), r * 0.4, p)
            if pg.stile != "pixel":
                t.ellisse(*_rt(sk, r * 0.05, r * 0.3), r * 0.16, r * 0.09, "#FF8FA3", bordo=False, opacita=0.5)
    if e.get("benda"):
        t.cerchio(*_rt(sk, r * 0.62, -r * 0.1), r * 0.24, "#1B1A22", bordo=False)
        t.linea(*_rt(sk, -r * 0.9, -r * 0.55), *_rt(sk, r * 0.95, r * 0.05), "#1B1A22", 1.4, bordo=False)
    # capelli davanti / sopra
    if capelli and not e.get("casco"):
        d_alto = r * (1.05 if not realistico else 1.1)
        punti = [_rt(sk, -r * 1.0, r * 0.25), _rt(sk, -r * 0.95, -r * 0.55), _rt(sk, -r * 0.4, -d_alto),
                 _rt(sk, r * 0.35, -d_alto * 1.02), _rt(sk, r * 0.92, -r * 0.45), _rt(sk, r * 0.55, -r * 0.42),
                 _rt(sk, r * 0.2, -r * 0.62), _rt(sk, -r * 0.35, -r * 0.4), _rt(sk, -r * 0.55, r * 0.1)]
        t.poligono(punti, capelli)
    # copricapo
    cappello = e.get("cappello")
    if cappello == "esploratore":
        col = c.get("cappello", "#8A6A3E")
        t.ellisse(*_rt(sk, r * 0.1, -r * 0.62), r * 1.45, r * 0.28, scuro(col, 0.1), angolo=sk.angolo_testa)
        t.poligono([_rt(sk, -r * 0.82, -r * 0.6), _rt(sk, -r * 0.62, -r * 1.42), _rt(sk, r * 0.72, -r * 1.42),
                    _rt(sk, r * 0.9, -r * 0.6)], col)
        t.poligono([_rt(sk, -r * 0.78, -r * 0.72), _rt(sk, r * 0.86, -r * 0.72), _rt(sk, r * 0.84, -r * 0.92),
                    _rt(sk, -r * 0.75, -r * 0.92)], c.get("nastro", "#5A3A22"), bordo=False)
    elif cappello == "mago":
        col = c.get("cappello", "#5B2C83")
        t.ellisse(*_rt(sk, r * 0.05, -r * 0.6), r * 1.5, r * 0.3, col, angolo=sk.angolo_testa)
        t.poligono([_rt(sk, -r * 0.9, -r * 0.6), _rt(sk, -r * 0.6, -r * 2.6), _rt(sk, r * 0.95, -r * 0.6)], col)
        t.cerchio(*_rt(sk, -r * 0.1, -r * 1.3), r * 0.17, "#FFD84A", bordo=False)
    elif cappello == "bandana":
        col = c.get("cappello", "#C8102E")
        t.poligono([_rt(sk, -r * 1.02, -r * 0.05), _rt(sk, -r * 0.7, -r * 0.92), _rt(sk, r * 0.5, -r * 1.02),
                    _rt(sk, r * 1.0, -r * 0.35), _rt(sk, -r * 0.2, -r * 0.48)], col)
        t.poligono([_rt(sk, -r * 0.95, -r * 0.2), _rt(sk, -r * 1.7, r * 0.15), _rt(sk, -r * 1.55, r * 0.55),
                    _rt(sk, -r * 0.85, r * 0.1)], col)
    elif cappello == "elmo":
        col = c.get("elmo", "#AEB6C2")
        t.cerchio(hx, hy - r * 0.08, r * 1.08, col)
        t.poligono([_rt(sk, r * 0.2, -r * 0.25), _rt(sk, r * 1.12, -r * 0.25), _rt(sk, r * 1.12, r * 0.05),
                    _rt(sk, r * 0.2, r * 0.05)], "#1B1A22", bordo=False)
        t.poligono([_rt(sk, -r * 0.3, -r * 1.05), _rt(sk, -r * 1.2, -r * 1.5), _rt(sk, -r * 1.55, -r * 0.6),
                    _rt(sk, -r * 0.6, -r * 0.6)], c.get("pennacchio", "#D7132A"))
    elif cappello == "cappuccio":
        col = c.get("cappuccio", "#2F4A2E")
        t.poligono([_rt(sk, -r * 1.2, r * 0.9), _rt(sk, -r * 1.25, -r * 0.4), _rt(sk, -r * 0.6, -r * 1.2),
                    _rt(sk, r * 0.5, -r * 1.25), _rt(sk, r * 1.05, -r * 0.5), _rt(sk, r * 0.92, -r * 0.2),
                    _rt(sk, r * 0.25, -r * 0.7), _rt(sk, -r * 0.4, -r * 0.5), _rt(sk, -r * 0.7, r * 0.8)], col)
    elif cappello == "fascia":   # ninja
        col = c.get("fascia", "#D7132A")
        t.capsula(*_rt(sk, -r * 0.95, -r * 0.4), *_rt(sk, r * 0.95, -r * 0.45), r * 0.18, r * 0.18, col)
        fl = math.sin(p.coda / 9)
        t.capsula(*_rt(sk, -r * 0.9, -r * 0.4), *_rt(sk, -r * 2.0, -r * (0.1 + 0.3 * fl)), r * 0.13, r * 0.08, col)
        t.capsula(*_rt(sk, -r * 0.9, -r * 0.35), *_rt(sk, -r * 1.8, r * (0.35 + 0.2 * fl)), r * 0.12, r * 0.07, col)
    if e.get("maschera"):            # ninja: maschera sotto gli occhi
        t.poligono([_rt(sk, -r * 0.98, r * 0.12), _rt(sk, r * 1.0, r * 0.12), _rt(sk, r * 0.85, r * 0.75),
                    _rt(sk, 0, r * 1.0), _rt(sk, -r * 0.8, r * 0.7)], c.get("maschera", "#24242C"))
    if e.get("casco"):               # astronauta, pilota
        col = c.get("casco", "#F3F4F7")
        visiera = c.get("visiera", "#203A5C")
        if not STILI[pg.stile].contorno:
            t.cerchio(hx, hy, r * 1.26, scuro(col, 0.22))
        t.cerchio(hx, hy, r * 1.18, col)
        t.ellisse(*_rt(sk, r * 0.4, -r * 0.02), r * 0.8, r * 0.72, visiera, angolo=sk.angolo_testa)
        t.ellisse(*_rt(sk, r * 0.6, -r * 0.25), r * 0.22, r * 0.12, "#FFFFFF", bordo=False, opacita=0.75,
                  angolo=sk.angolo_testa - 25)
        if not e.get("casco_chiuso"):
            _occhio(t, *_rt(sk, r * 0.35, -r * 0.05), r * 0.17, p)
            _occhio(t, *_rt(sk, r * 0.7, -r * 0.06), r * 0.19, p)
        if c.get("dettaglio_casco"):
            t.capsula(*_rt(sk, -r * 0.82, -r * 0.4), *_rt(sk, -r * 0.3, -r * 0.92), r * 0.1, r * 0.1,
                      c["dettaglio_casco"], bordo=False)


def _testa_robot(pg: Personaggio, t: Tela, sk: Scheletro, p: Posa) -> None:
    c = pg.colori
    r = pg.corpo.testa
    hx, hy = sk.testa
    metallo = c.get("metallo", "#8FA3B8")
    # antenna
    a = _rt(sk, -r * 0.1, -r * 0.95)
    b = _rt(sk, -r * 0.25, -r * 1.65)
    t.linea(*a, *b, scuro(metallo, 0.3), 2.0)
    t.cerchio(*b, r * 0.18, c.get("luce", "#D7132A"), luce=True)
    t.poligono([_rt(sk, -r, -r * 0.92), _rt(sk, r * 1.0, -r * 0.92), _rt(sk, r * 1.08, r * 0.92),
                _rt(sk, -r * 0.95, r * 0.92)], metallo)
    t.poligono([_rt(sk, -r * 0.35, -r * 0.62), _rt(sk, r * 0.85, -r * 0.62), _rt(sk, r * 0.85, r * 0.55),
                _rt(sk, -r * 0.35, r * 0.55)], c.get("schermo", "#14202C"))
    occhio = c.get("occhi", "#3BE3FF")
    if p.occhi in ("chiusi", "felici"):
        t.linea(*_rt(sk, -r * 0.05, -r * 0.05), *_rt(sk, r * 0.15, -r * 0.05), occhio, 2.0, luce=True)
        t.linea(*_rt(sk, r * 0.45, -r * 0.05), *_rt(sk, r * 0.65, -r * 0.05), occhio, 2.0, luce=True)
    elif p.occhi == "dolore":
        t.linea(*_rt(sk, -r * 0.05, -r * 0.2), *_rt(sk, r * 0.18, r * 0.05), "#FF5A5A", 2.0, luce=True)
        t.linea(*_rt(sk, r * 0.45, r * 0.05), *_rt(sk, r * 0.68, -r * 0.2), "#FF5A5A", 2.0, luce=True)
    else:
        t.cerchio(*_rt(sk, r * 0.05, -r * 0.08), r * 0.15, occhio, luce=True, bordo=False)
        t.cerchio(*_rt(sk, r * 0.58, -r * 0.08), r * 0.15, occhio, luce=True, bordo=False)
    bocca = _rt(sk, r * 0.3, r * 0.32)
    w = r * (0.45 if p.bocca in ("aperta", "o") else 0.3)
    t.linea(bocca[0] - w, bocca[1], bocca[0] + w, bocca[1], occhio, 1.6, luce=True, opacita=0.9)
    t.cerchio(*_rt(sk, -r * 0.7, 0), r * 0.16, scuro(metallo, 0.25))


def _testa_scifi(pg: Personaggio, t: Tela, sk: Scheletro, p: Posa) -> None:
    """Casco da fantascienza con visiera luminosa."""
    c = pg.colori
    r = pg.corpo.testa
    hx, hy = sk.testa
    co = sk.collo
    armatura = c.get("armatura", "#E8ECF1")
    luce = c.get("luce", "#38D6FF")
    t.capsula(co[0], co[1] + 2, hx - r * 0.15, hy + r * 0.6, r * 0.42, r * 0.38, c.get("tuta", "#2A2F38"))
    t.ellisse(hx, hy, r * 0.95, r * 1.08, armatura, angolo=sk.angolo_testa)
    forma = pg.extra.get("visiera", "fascia")
    if forma == "t":
        t.poligono([_rt(sk, r * 0.1, -r * 0.3), _rt(sk, r * 1.0, -r * 0.3), _rt(sk, r * 1.0, -r * 0.08),
                    _rt(sk, r * 0.62, -r * 0.08), _rt(sk, r * 0.62, r * 0.55), _rt(sk, r * 0.4, r * 0.55),
                    _rt(sk, r * 0.4, -r * 0.08), _rt(sk, r * 0.1, -r * 0.08)], "#07090D")
        t.linea(*_rt(sk, r * 0.18, -r * 0.19), *_rt(sk, r * 0.92, -r * 0.19), luce, 1.1, luce=True)
    else:
        t.poligono([_rt(sk, -r * 0.05, -r * 0.42), _rt(sk, r * 0.98, -r * 0.34), _rt(sk, r * 0.9, r * 0.12),
                    _rt(sk, -r * 0.02, r * 0.02)], "#07090D")
        lampo = 1.0 if p.occhi != "chiusi" else 0.4
        t.linea(*_rt(sk, r * 0.1, -r * 0.18), *_rt(sk, r * 0.86, -r * 0.13), luce, 1.4, luce=True, opacita=lampo)
    t.linea(*_rt(sk, -r * 0.75, -r * 0.55), *_rt(sk, -r * 0.2, -r * 0.95), luce, 0.9, luce=True, opacita=0.8)
    t.ellisse(*_rt(sk, -r * 0.35, r * 0.15), r * 0.3, r * 0.42, scuro(armatura, 0.25), angolo=sk.angolo_testa)
    if pg.extra.get("cresta"):
        t.poligono([_rt(sk, -r * 0.5, -r * 0.85), _rt(sk, r * 0.3, -r * 1.25), _rt(sk, r * 0.15, -r * 0.9)],
                   c.get("cresta", "#D7132A"))


# --- busti e parti dietro ------------------------------------------------------------

def _busto_scifi(pg: Personaggio, t: Tela, sk: Scheletro, p: Posa) -> None:
    c = pg.colori
    corpo = pg.corpo
    an, co = sk.anca, sk.collo
    lw = corpo.larghezza
    tuta = c.get("tuta", "#2A2F38")
    armatura = c.get("armatura", "#E8ECF1")
    luce = c.get("luce", "#38D6FF")
    t.capsula(an[0], an[1] - 1, co[0], co[1] + lw * 0.2, lw * 0.36, lw * 0.44, tuta)
    # piastra del petto
    pa = ruota(co[0] + lw * 0.05, co[1] + lw * 0.42, co[0], co[1], sk.inclina)
    t.ellisse(*pa, lw * 0.4, lw * 0.36, armatura, angolo=sk.inclina)
    nucleo = ruota(co[0] + lw * 0.14, co[1] + lw * 0.45, co[0], co[1], sk.inclina)
    t.cerchio(*nucleo, lw * 0.09, luce, luce=True)
    # cintura con luci
    t.capsula(an[0] - lw * 0.36, an[1] - 3, an[0] + lw * 0.36, an[1] - 3, 2.4, 2.4, scuro(armatura, 0.35))
    t.linea(an[0] - lw * 0.2, an[1] - 3, an[0] + lw * 0.25, an[1] - 3, luce, 1.0, luce=True)
    # spallacci
    for k in (0, 1):
        t.ellisse(*sk.spalle[k], lw * 0.2, lw * 0.15, scuro(armatura, 0.12) if k == 0 else armatura,
                  angolo=sk.inclina - 10)


def _coda(pg: Personaggio, t: Tela, sk: Scheletro, p: Posa) -> None:
    c = pg.colori
    tipo = pg.extra.get("coda")
    an = sk.anca
    base = (an[0] - pg.corpo.larghezza * 0.3, an[1] - 3)
    ang = math.radians(-60 + p.coda)
    if tipo == "volpe":
        punta = (base[0] - math.cos(ang) * 30, base[1] + math.sin(ang) * 30 - 6)
        mezzo = (base[0] - math.cos(ang) * 16, base[1] + math.sin(ang) * 14 - 2)
        t.capsula(*base, *mezzo, 4.5, 9.0, c["pelo"])
        t.capsula(*mezzo, *punta, 9.0, 4.0, c["pelo"])
        t.capsula(punta[0] + math.cos(ang) * 6, punta[1] - math.sin(ang) * 6, *punta, 6.0, 3.5, "#FFFFFF")
    elif tipo == "gatto":
        a1 = (base[0] - 12, base[1] - 4 + p.coda * 0.1)
        a2 = (base[0] - 18, base[1] - 22 - p.coda * 0.2)
        t.capsula(*base, *a1, 3.0, 3.0, c["pelo"])
        t.capsula(*a1, *a2, 3.0, 3.4, c["pelo"])
    elif tipo == "orsetto":
        t.cerchio(base[0] - 2, base[1] - 2, 5, c["pelo"])
    elif tipo == "drago":
        punti = [base]
        for k in range(1, 5):
            punti.append((base[0] - k * 8, base[1] + 4 + k * 2 - math.sin(k + p.coda / 12) * 4))
        for k in range(4):
            t.capsula(*punti[k], *punti[k + 1], 6 - k * 1.2, 5 - k * 1.2, c["pelo"])
        fx, fy = punti[-1]
        t.poligono([(fx + 2, fy - 2), (fx - 9, fy - 7), (fx - 6, fy + 4)], c.get("ali", "#F5C04A"))
    elif tipo == "pinguino":
        t.poligono([(base[0] + 2, base[1] - 4), (base[0] - 8, base[1] + 4), (base[0] + 4, base[1] + 3)], c["pelo"])


def _ali(pg: Personaggio, t: Tela, sk: Scheletro, p: Posa) -> None:
    c = pg.colori
    co = sk.collo
    sp = (co[0] - pg.corpo.larghezza * 0.25, co[1] + 6)
    battito = math.sin(p.coda / 8) * 8
    t.poligono([sp, (sp[0] - 22, sp[1] - 18 - battito), (sp[0] - 16, sp[1] - 4 - battito / 2),
                (sp[0] - 24, sp[1] + 2), (sp[0] - 12, sp[1] + 6), (sp[0] - 14, sp[1] + 14), (sp[0] + 2, sp[1] + 10)],
               c.get("ali", "#F5C04A"))
    _coda(pg, t, sk, p)


def _zaino(pg: Personaggio, t: Tela, sk: Scheletro, p: Posa) -> None:
    c = pg.colori
    co, an = sk.collo, sk.anca
    lw = pg.corpo.larghezza
    cx = (co[0] + an[0]) / 2 - lw * 0.45
    cy = (co[1] + an[1]) / 2 - 2
    t.ellisse(cx, cy, lw * 0.3, lw * 0.52, c.get("zaino", "#9AA3AE"), angolo=sk.inclina)
    if pg.extra.get("razzo"):
        t.ellisse(cx - lw * 0.05, cy + lw * 0.55, lw * 0.12, lw * 0.18, "#FFB13B", bordo=False, opacita=0.9)


def _mantello(pg: Personaggio, t: Tela, sk: Scheletro, p: Posa) -> None:
    c = pg.colori
    co, an = sk.collo, sk.anca
    vento = math.sin(p.coda / 9) * 5 - p.inclina * 0.4
    t.poligono([(co[0] - 4, co[1] + 4), (co[0] + 4, co[1] + 4), (an[0] - 2, an[1] + 22),
                (an[0] - 16 + vento, an[1] + 18), (an[0] - 20 + vento, an[1] + 4)], c.get("mantello", "#7A1020"))


def _pinna(pg: Personaggio, t: Tela, sk: Scheletro, p: Posa) -> None:
    _coda(pg, t, sk, p)


# ===========================================================================
# Il catalogo dei personaggi
# ===========================================================================

_CARTONE = Corpo(testa=23, busto=26, larghezza=32, omero=12, avambraccio=11, coscia=12, gamba=11, piede=11,
                 r_braccio=(5.6, 4.6), r_gamba=(7.0, 5.8))
_CARTONE_TONDO = Corpo(testa=22, busto=27, larghezza=38, omero=12, avambraccio=11, coscia=11, gamba=10, piede=12,
                       r_braccio=(6.4, 5.4), r_gamba=(8.0, 6.8))
_PIATTO = Corpo(testa=17, busto=31, larghezza=28, omero=15, avambraccio=14, coscia=17, gamba=16, piede=11,
                r_braccio=(5.0, 4.0), r_gamba=(6.2, 5.0), collo=1)
_PIXEL = Corpo(testa=19, busto=26, larghezza=30, omero=12, avambraccio=11, coscia=13, gamba=12, piede=11,
               r_braccio=(6.0, 5.5), r_gamba=(7.0, 6.5))
_REALE = Corpo(testa=9.2, busto=34, larghezza=27, omero=18, avambraccio=17, coscia=24, gamba=23, piede=10,
               r_braccio=(4.0, 2.8), r_gamba=(5.8, 3.6), collo=3)
_SCIFI = Corpo(testa=9.6, busto=33, larghezza=30, omero=18, avambraccio=17, coscia=23, gamba=23, piede=11,
               r_braccio=(4.8, 3.8), r_gamba=(6.4, 4.8), collo=2.5)


def _busto_pinguino(pg, t, sk, p):
    c = pg.colori
    an, co = sk.anca, sk.collo
    t.ellisse((an[0] + co[0]) / 2, (an[1] + co[1]) / 2 + 2, pg.corpo.larghezza * 0.55, pg.corpo.busto * 0.72,
              c["pelo"], angolo=sk.inclina)
    t.ellisse((an[0] + co[0]) / 2 + 4, (an[1] + co[1]) / 2 + 4, pg.corpo.larghezza * 0.36, pg.corpo.busto * 0.58,
              "#F7F7F2", angolo=sk.inclina, bordo=False)


def _testa_pinguino(pg, t, sk, p):
    c = pg.colori
    r = pg.corpo.testa
    hx, hy = sk.testa
    t.cerchio(hx, hy, r, c["pelo"])
    t.ellisse(*_rt(sk, r * 0.35, r * 0.15), r * 0.62, r * 0.66, "#F7F7F2", bordo=False, angolo=sk.angolo_testa)
    _occhio(t, *_rt(sk, r * 0.25, -r * 0.1), r * 0.24, p)
    _occhio(t, *_rt(sk, r * 0.68, -r * 0.12), r * 0.26, p)
    aperto = p.bocca in ("aperta", "o", "dolore")
    t.poligono([_rt(sk, r * 0.7, r * 0.22), _rt(sk, r * 1.45, r * 0.35), _rt(sk, r * 0.7, r * 0.5)], "#F59A23")
    if aperto:
        t.poligono([_rt(sk, r * 0.7, r * 0.52), _rt(sk, r * 1.3, r * 0.62), _rt(sk, r * 0.7, r * 0.66)], "#D97A10")


def _ninja_busto(pg, t, sk, p):
    _busto_base(pg, t, sk, p)
    an, co = sk.anca, sk.collo
    t.linea(co[0] - 6, co[1] + 4, an[0] + 8, an[1] - 4, pg.colori.get("fascia", "#D7132A"), 3.0)


def _esploratrice_busto(pg, t, sk, p):
    _busto_base(pg, t, sk, p)
    an, co = sk.anca, sk.collo
    t.linea(co[0] + 6, co[1] + 4, an[0] - 9, an[1] - 4, "#5A3A22", 2.4)


def _pirata_busto(pg, t, sk, p):
    _busto_base(pg, t, sk, p)
    an, co = sk.anca, sk.collo
    for k in range(1, 4):
        y = co[1] + 8 + k * 6
        t.linea(an[0] - 10, y, an[0] + 10, y, "#1E3A6E", 3.0, bordo=False)


def _astronauta_busto(pg, t, sk, p):
    _busto_base(pg, t, sk, p)
    an, co = sk.anca, sk.collo
    pannello = ruota(co[0] + 5, co[1] + 13, co[0], co[1], sk.inclina)
    t.poligono([(pannello[0] - 5, pannello[1] - 4), (pannello[0] + 5, pannello[1] - 4),
                (pannello[0] + 5, pannello[1] + 4), (pannello[0] - 5, pannello[1] + 4)], "#5C6B80")
    t.cerchio(pannello[0] - 2, pannello[1], 1.4, "#D7132A", bordo=False)
    t.cerchio(pannello[0] + 2, pannello[1], 1.4, "#38D6FF", bordo=False)


def _robot_busto(pg, t, sk, p):
    c = pg.colori
    an, co = sk.anca, sk.collo
    lw = pg.corpo.larghezza
    m = c.get("metallo", "#8FA3B8")
    a = sk.inclina
    pts = [ruota(x, y, an[0], an[1], a) for x, y in
           ((an[0] - lw * 0.42, an[1]), (an[0] + lw * 0.42, an[1]), (an[0] + lw * 0.5, an[1] - pg.corpo.busto),
            (an[0] - lw * 0.5, an[1] - pg.corpo.busto))]
    t.poligono(pts, m)
    centro = ruota(an[0] + 2, an[1] - pg.corpo.busto * 0.55, an[0], an[1], a)
    t.cerchio(*centro, lw * 0.14, c.get("luce", "#D7132A"), luce=True)
    t.cerchio(*centro, lw * 0.07, "#FFFFFF", bordo=False, sfuma=False, opacita=0.8)


def _realistico_busto(pg, t, sk, p):
    c = pg.colori
    corpo = pg.corpo
    an, co = sk.anca, sk.collo
    lw = corpo.larghezza
    # torace a trapezio (spalle larghe, vita stretta)
    a = sk.inclina
    pts = [ruota(x, y, an[0], an[1], a) for x, y in (
        (an[0] - lw * 0.3, an[1] + 2), (an[0] + lw * 0.3, an[1] + 2), (an[0] + lw * 0.34, an[1] - corpo.busto * 0.55),
        (an[0] + lw * 0.42, an[1] - corpo.busto * 0.92), (an[0] + lw * 0.15, an[1] - corpo.busto * 1.02),
        (an[0] - lw * 0.15, an[1] - corpo.busto * 1.02), (an[0] - lw * 0.42, an[1] - corpo.busto * 0.92),
        (an[0] - lw * 0.34, an[1] - corpo.busto * 0.55))]
    t.poligono(pts, c.get("busto", c["primario"]))
    if c.get("armatura"):
        pp = [ruota(x, y, an[0], an[1], a) for x, y in (
            (an[0] - lw * 0.28, an[1] - corpo.busto * 0.4), (an[0] + lw * 0.3, an[1] - corpo.busto * 0.4),
            (an[0] + lw * 0.36, an[1] - corpo.busto * 0.9), (an[0] - lw * 0.36, an[1] - corpo.busto * 0.9))]
        t.poligono(pp, c["armatura"])
    if c.get("cintura"):
        t.capsula(*ruota(an[0] - lw * 0.32, an[1] - 2, an[0], an[1], a), *ruota(an[0] + lw * 0.32, an[1] - 2, an[0],
                  an[1], a), 2.2, 2.2, c["cintura"])
    if c.get("numero"):
        n = ruota(an[0] + lw * 0.1, an[1] - corpo.busto * 0.62, an[0], an[1], a)
        t.ellisse(*n, lw * 0.13, lw * 0.11, "#FFFFFF", bordo=False, opacita=0.9)
    if pg.extra.get("faretra"):
        q1 = ruota(an[0] - lw * 0.42, an[1] - corpo.busto * 0.3, an[0], an[1], a - 25)
        q2 = ruota(an[0] - lw * 0.42, an[1] - corpo.busto * 1.25, an[0], an[1], a - 25)
        t.capsula(*q1, *q2, 3.2, 3.6, "#5A3A22")
        for k in (-2, 1, 3):
            t.linea(q2[0] + k, q2[1], q2[0] + k - 2, q2[1] - 7, "#D9C9A0", 1.2, bordo=False)


def _cuore_dietro_umano(pg, t, sk, p):
    if pg.extra.get("mantello"):
        _mantello(pg, t, sk, p)
    if pg.extra.get("zaino"):
        _zaino(pg, t, sk, p)


PERSONAGGI: dict[str, Personaggio] = {}


def _aggiungi(pg: Personaggio) -> None:
    PERSONAGGI[pg.nome] = pg


# --- cartone ---
_aggiungi(Personaggio("volpe", "cartone", "Volpe", "Volpe agile in stile cartone animato", _CARTONE,
                      {"pelo": "#F07A2A", "muso": "#FFF4E6", "primario": "#2E6FD8", "busto": "#2E6FD8",
                       "gambe": "#F07A2A", "braccia": "#F07A2A", "mani": "#2B2B33", "scarpe": "#2B2B33",
                       "maniche_lunghe": True, "pancia": "#FFF4E6"},
                      _testa_animale, dietro=_coda, extra={"orecchie": "punta", "coda": "volpe"}))
_aggiungi(Personaggio("gatto", "cartone", "Gatto", "Gatto curioso con la sciarpa rossa", _CARTONE,
                      {"pelo": "#6F6A8C", "muso": "#EDEAF7", "primario": "#6F6A8C", "busto": "#6F6A8C",
                       "pancia": "#EDEAF7", "interno": "#F4A6B8", "naso": "#F27D97", "scarpe": "#EDEAF7",
                       "cintura": "#D7132A", "fibbia": "#D7132A"},
                      _testa_animale, dietro=_coda, extra={"orecchie": "gatto", "coda": "gatto"}))
_aggiungi(Personaggio("rana", "cartone", "Rana", "Rana saltatrice dagli occhi grandi", _CARTONE,
                      {"pelo": "#4CB944", "muso": "#C9F28B", "primario": "#4CB944", "busto": "#4CB944",
                       "pancia": "#C9F28B", "scarpe": "#3A9A34", "mani": "#3A9A34"},
                      _testa_animale, extra={"orecchie": "rana"}))
_aggiungi(Personaggio("orsetto", "cartone", "Orsetto", "Orsetto robusto con la salopette", _CARTONE_TONDO,
                      {"pelo": "#9A6338", "muso": "#E9C29B", "interno": "#E9C29B", "primario": "#3B6EA8",
                       "busto": "#3B6EA8", "gambe": "#3B6EA8", "braccia": "#9A6338", "mani": "#9A6338",
                       "scarpe": "#5A3A22", "cintura": "#2B4F7A", "fibbia": "#F2C94C"},
                      _testa_animale, dietro=_coda, extra={"orecchie": "tonde", "coda": "orsetto"}))
_aggiungi(Personaggio("draghetto", "cartone", "Draghetto", "Piccolo drago con le ali e il fiato di fuoco",
                      _CARTONE, {"pelo": "#2BA59A", "muso": "#BFF0E3", "primario": "#2BA59A", "busto": "#2BA59A",
                                 "pancia": "#F7E3A1", "scarpe": "#1F7D74", "mani": "#1F7D74", "ali": "#F5A524",
                                 "corna": "#F7E3A1"},
                      _testa_animale, dietro=_ali, extra={"orecchie": "corna", "coda": "drago"}))
# --- piatto ---
_aggiungi(Personaggio("astronauta", "piatto", "Astronauta", "Astronauta con la tuta spaziale e lo zaino a razzo",
                      _PIATTO, {"pelle": "#E8B48A", "primario": "#E3E7EE", "busto": "#E9EDF3", "gambe": "#D5DAE3",
                                "braccia": "#E3E7EE", "guanti": "#F07A2A", "scarpe": "#5C6B80", "casco": "#F3F4F7",
                                "visiera": "#1E3554", "zaino": "#C7CDD8", "cintura": "#F07A2A", "fibbia": "#5C6B80",
                                "dettaglio_casco": "#F07A2A"},
                      _testa_umana, busto=_astronauta_busto, dietro=_cuore_dietro_umano,
                      extra={"casco": True, "zaino": True, "razzo": True}))
_aggiungi(Personaggio("robot", "piatto", "Robot", "Robot di metallo con l'antenna e gli occhi luminosi", _PIATTO,
                      {"metallo": "#8FA3B8", "primario": "#6F8399", "gambe": "#6F8399", "braccia": "#6F8399",
                       "guanti": "#4A5A6C", "scarpe": "#3E4B5A", "schermo": "#14202C", "occhi": "#3BE3FF",
                       "luce": "#D7132A"},
                      _testa_robot, busto=_robot_busto))
_aggiungi(Personaggio("ninja", "piatto", "Ninja", "Ninja silenzioso con la fascia rossa", _PIATTO,
                      {"pelle": "#E8B48A", "primario": "#24242C", "busto": "#24242C", "gambe": "#24242C",
                       "braccia": "#24242C", "guanti": "#1A1A20", "scarpe": "#1A1A20", "maschera": "#24242C",
                       "capelli": "#24242C", "fascia": "#D7132A", "cintura": "#D7132A", "fibbia": "#D7132A",
                       "scia": "#E6E9F0"},
                      _testa_umana, busto=_ninja_busto, arma="spada",
                      extra={"maschera": True, "cappello": "fascia"}))
_aggiungi(Personaggio("esploratrice", "piatto", "Esploratrice", "Esploratrice con il cappello e lo zaino",
                      _PIATTO, {"pelle": "#C98B5E", "capelli": "#3B2416", "primario": "#C9B27C", "busto": "#E9DCB5",
                                "gambe": "#7A6A4A", "braccia": "#E9DCB5", "scarpe": "#5A3A22", "cappello": "#9A7646",
                                "nastro": "#5A3A22", "zaino": "#7A5A34", "cintura": "#5A3A22",
                                "maniche_lunghe": False, "mani": "#C98B5E", "avambracci": "#C98B5E"},
                      _testa_umana, busto=_esploratrice_busto, dietro=_cuore_dietro_umano,
                      extra={"cappello": "esploratore", "coda_capelli": True, "zaino": True}))
# --- pixel ---
_aggiungi(Personaggio("cavaliere", "pixel", "Cavaliere", "Cavaliere in armatura con spada e pennacchio", _PIXEL,
                      {"pelle": "#F1C27D", "primario": "#8F9BB0", "busto": "#7D889C", "gambe": "#5E6778",
                       "braccia": "#8F9BB0", "guanti": "#6C7480", "scarpe": "#5A616C", "elmo": "#C7CED8",
                       "pennacchio": "#D7132A", "mantello": "#9E1B2C", "cintura": "#6B4423", "fibbia": "#E5C14A"},
                      _testa_umana, dietro=_cuore_dietro_umano, arma="spada",
                      extra={"cappello": "elmo", "casco": False, "mantello": True}))
_aggiungi(Personaggio("maga", "pixel", "Maga", "Maga con il cappello a punta e il bastone luminoso", _PIXEL,
                      {"pelle": "#F1C27D", "capelli": "#E8D06A", "primario": "#5B2C83", "busto": "#5B2C83",
                       "gambe": "#4A2370", "braccia": "#5B2C83", "scarpe": "#2E1A40", "cappello": "#5B2C83",
                       "gemma": "#38D6FF", "cintura": "#E5C14A", "fibbia": "#E5C14A"},
                      _testa_umana, arma="bastone", extra={"cappello": "mago"}))
_aggiungi(Personaggio("pirata", "pixel", "Pirata", "Pirata con la bandana, la benda e la sciabola", _PIXEL,
                      {"pelle": "#E0A877", "capelli": "#3B2416", "primario": "#F2F2EE", "busto": "#F2F2EE",
                       "gambe": "#2B3A55", "braccia": "#F2F2EE", "scarpe": "#3B2416", "cappello": "#C8102E",
                       "cintura": "#5A3A22", "fibbia": "#E5C14A"},
                      _testa_umana, busto=_pirata_busto, arma="sciabola",
                      extra={"cappello": "bandana", "benda": True, "barba": True}))
_aggiungi(Personaggio("pinguino", "pixel", "Pinguino", "Pinguino buffo che scivola sul ghiaccio", _PIXEL,
                      {"pelo": "#2A2D3A", "primario": "#2A2D3A", "gambe": "#2A2D3A", "braccia": "#2A2D3A",
                       "mani": "#2A2D3A", "scarpe": "#F59A23"},
                      _testa_pinguino, busto=_busto_pinguino, dietro=_pinna, extra={"coda": "pinguino"}))
# --- realistico ---
_aggiungi(Personaggio("atleta", "realistico", "Atleta", "Atleta da corsa con la canotta e le scarpe da gara",
                      _REALE, {"pelle": "#8D5A3B", "capelli": "#1B1410", "primario": "#D7132A", "busto": "#D7132A",
                               "gambe": "#1F1F26", "braccia": "#8D5A3B", "maniche_lunghe": False, "mani": "#8D5A3B",
                               "avambracci": "#8D5A3B", "scarpe": "#F2F2F2", "suola": "#D7132A", "numero": True,
                               "iridi": "#2B1A10"},
                      _testa_umana, busto=_realistico_busto, extra={}))
_aggiungi(Personaggio("ranger", "realistico", "Ranger", "Ranger dei boschi con il cappuccio e l'arco", _REALE,
                      {"pelle": "#E2B08C", "capelli": "#6B4A2A", "primario": "#3E5A3A", "busto": "#4D6B45",
                       "gambe": "#4A3B2A", "braccia": "#4D6B45", "guanti": "#5A3A22", "scarpe": "#3B2A1A",
                       "stivali": "#5A3A22", "cappuccio": "#2F4A2E", "cintura": "#5A3A22", "mantello": "#2F4A2E"},
                      _testa_umana, busto=_realistico_busto, dietro=_cuore_dietro_umano, arma="arco",
                      extra={"cappello": "cappuccio", "barba": True, "faretra": True, "mantello": True}))
_aggiungi(Personaggio("guerriera", "realistico", "Guerriera", "Guerriera con la treccia rossa, armatura e spada",
                      _REALE, {"pelle": "#F0C8A8", "capelli": "#B8381E", "primario": "#5A4030", "busto": "#6A4B36",
                               "armatura": "#A7B0BC", "gambe": "#3A2E28", "braccia": "#F0C8A8", "maniche_lunghe": False,
                               "mani": "#F0C8A8", "avambracci": "#8A939F", "guanti": "#5A3A22", "scarpe": "#3B2A1A",
                               "stivali": "#5A3A22", "cintura": "#3B2A1A", "iridi": "#2E6B4A", "scia": "#F2F4F8"},
                      _testa_umana, busto=_realistico_busto, arma="spada", extra={"treccia": True}))
# --- fantascienza ---
_aggiungi(Personaggio("androide", "fantascienza", "Androide", "Androide bianco con le linee di luce azzurre",
                      _SCIFI, {"armatura": "#E8ECF1", "tuta": "#2A2F38", "primario": "#2A2F38", "gambe": "#2A2F38",
                               "braccia": "#3A404C", "guanti": "#E8ECF1", "scarpe": "#E8ECF1", "luce": "#38D6FF",
                               "stivali": "#C9D0D9", "scia": "#38D6FF"},
                      _testa_scifi, busto=_busto_scifi, extra={"visiera": "fascia"}))
_aggiungi(Personaggio("pilota", "fantascienza", "Pilota", "Pilota spaziale con la tuta arancione e il blaster",
                      _SCIFI, {"armatura": "#D9DEE5", "tuta": "#E0782A", "primario": "#E0782A", "gambe": "#C8661F",
                               "braccia": "#E0782A", "guanti": "#3A3F4B", "scarpe": "#3A3F4B", "luce": "#FFB13B",
                               "stivali": "#3A3F4B", "arma": "#4A505C"},
                      _testa_scifi, busto=_busto_scifi, arma="blaster", extra={"visiera": "fascia", "cresta": False}))
_aggiungi(Personaggio("cacciatrice", "fantascienza", "Cacciatrice", "Cacciatrice in armatura nera con il fucile",
                      _SCIFI, {"armatura": "#3A3F4A", "tuta": "#15171C", "primario": "#15171C", "gambe": "#1B1E24",
                               "braccia": "#1B1E24", "guanti": "#3A3F4A", "scarpe": "#3A3F4A", "luce": "#FF2D46",
                               "stivali": "#2A2E36", "arma": "#2A2E36", "cresta": "#D7132A"},
                      _testa_scifi, busto=_busto_scifi, arma="fucile", extra={"visiera": "t", "cresta": True}))


# ===========================================================================
# Disegno
# ===========================================================================

def disegna(pg: Personaggio, animazione: str, i: int) -> Tela:
    """Il fotogramma ``i`` di un'animazione come :class:`Tela` (coordinate della cella 128 x 128)."""
    p = posa(animazione, i)
    sk = scheletro(pg.corpo, p)
    t = Tela()
    # ombra a terra (si stringe nei salti)
    alto = TERRA - max(sk.piedi[0][1], sk.piedi[1][1])
    if animazione != "salta":
        larghezza = pg.corpo.larghezza * 0.75 * max(0.45, 1 - alto / 60)
        t.ellisse(64 + p.sposta, TERRA + 1.5, larghezza, 3.2, "#000000", bordo=False, sfuma=False, opacita=0.22)
    if pg.dietro:
        pg.dietro(pg, t, sk, p)
    _braccio(pg, t, sk, 0, True, p)
    _gamba(pg, t, sk, 0, True)
    (pg.busto or _busto_base)(pg, t, sk, p)
    _gamba(pg, t, sk, 1, False)
    pg.testa(pg, t, sk, p)
    _braccio(pg, t, sk, 1, False, p)
    return t


def fotogramma(nome: str, animazione: str = "fermo", i: int = 0) -> str:
    """SVG completo (128 x 128) di un fotogramma."""
    pg = PERSONAGGI[nome]
    stile = STILI[pg.stile]
    t = disegna(pg, animazione, i)
    if stile.pixel:
        return avvolgi(t.pixel(stile.pixel, stile.contorno), CELLA, CELLA, pixel=True)
    defs: dict[str, str] = {}
    corpo = t.svg(stile, defs)
    return avvolgi(corpo, CELLA, CELLA, defs)


@lru_cache(maxsize=64)
def foglio(nome: str) -> str:
    """Il foglio di animazione completo: 8 colonne (fotogrammi) x 7 righe (animazioni), celle 128 x 128."""
    pg = PERSONAGGI[nome]
    stile = STILI[pg.stile]
    defs: dict[str, str] = {}
    parti = []
    for r, animazione in enumerate(ANIMAZIONI):
        for i in range(FOTOGRAMMI):
            t = disegna(pg, animazione, i)
            corpo = t.pixel(stile.pixel, stile.contorno) if stile.pixel else t.svg(stile, defs)
            parti.append(f'<g transform="translate({i * CELLA} {r * CELLA})">{corpo}</g>')
    return avvolgi("".join(parti), CELLA * FOTOGRAMMI, CELLA * len(ANIMAZIONI), defs, pixel=bool(stile.pixel))


def per_stile() -> dict[str, list[str]]:
    risultato: dict[str, list[str]] = {}
    for pg in PERSONAGGI.values():
        risultato.setdefault(pg.stile, []).append(pg.nome)
    return risultato


__all__ = ["ANIMAZIONI", "FOTOGRAMMI", "CELLA", "PERSONAGGI", "Personaggio", "Posa", "posa", "foglio",
           "fotogramma", "disegna", "per_stile"]
