"""Effetti e animazioni "senza codice" dei controlli: catalogo condiviso, senza Qt.

Quattro famiglie di effetti, con gli stessi nomi sul PC (Leo Studio, Qt) e sul
telefono (``android/.../web/finestre.js``, animazioni CSS):

* **entrate** (:data:`ENTRATE`): come compare il controllo quando si apre la
  finestra o quando torna visibile (proprietà ``animazione_entrata``, con
  ``ritardo_entrata`` e ``durata_entrata``); le stesse, al contrario, servono
  a ``nascondi_con`` (uscita) e ``mostra_con``;
* **effetti continui** (:data:`CONTINUI`): girano sempre, finché il
  controllo si vede (proprietà ``effetto_continuo`` e ``velocità_effetto``);
* **effetti al tocco** (:data:`TOCCHI`): partono quando lo si tocca o ci si
  clicca sopra (proprietà ``effetto_tocco``);
* **colpi** (:data:`COLPI`): effetti brevi dei metodi (``Pulsante1.rimbalza()``,
  ``ruota()``, ``capovolgi()``, ``brilla()``, ``dondola()``, ``trema()``) e dei tocchi.

Sul telefono gli effetti ruotano, capovolgono e ingrandiscono davvero (CSS
``transform``). Qt non sa ruotare un widget: :func:`fotogramma` dà per ogni
istante un'approssimazione fatta di spostamento, ridimensionamento dal
centro, trasparenza, bagliore e tinta, che ``leo.grafica.qt.effetti_qt``
applica al widget (una rotazione diventa un "giro di moneta": il controllo si
stringe e si riallarga).

Gli effetti sono solo grafici: non cambiano le proprietà del controllo
(``sinistra``, ``opacità``...), tranne ``visibile`` per entrate e uscite.
"""

from __future__ import annotations

import math
from typing import Any

from .metadati import semplifica_nome

#: Nome della "notifica" che i motori delle animazioni mandano agli osservatori
#: di un ``ControlloVivo`` per far partire un effetto grafico (non è una proprietà:
#: non si salva nel modello). Valore: dizionario di :func:`dati_effetto`.
NOTIFICA_EFFETTO = "#effetto"
#: Notifica del motore web: un'animazione di proprietà da far girare nella pagina.
NOTIFICA_ANIMAZIONE = "#animazione"

ENTRATE = ("nessuna", "dissolvenza", "scorri_su", "scorri_giu", "scorri_sinistra", "scorri_destra", "zoom",
           "rimbalzo", "elastico", "caduta", "ruota", "capovolgi")
CONTINUI = ("nessuno", "pulsa", "respira", "galleggia", "saltella", "oscilla", "ruota", "lampeggia", "brilla",
            "arcobaleno", "battito", "vibra")
TOCCHI = ("nessuno", "rimbalzo", "affonda", "onda", "ingrandisci", "scuoti", "brilla", "ruota", "salta")
VELOCITA = ("lenta", "normale", "veloce")
#: Effetti brevi (metodi e tocchi): nomi usati nei messaggi verso il telefono e in Qt.
COLPI = ("rimbalza", "ruota", "capovolgi", "brilla", "dondola", "trema", "affonda", "onda", "ingrandisci",
         "scuoti", "salta", "pulsa", "lampeggia")

#: Tocco -> colpo (i tocchi hanno nomi "da pannello", i colpi "da verbo").
COLPO_DEL_TOCCO = {"rimbalzo": "rimbalza", "affonda": "affonda", "onda": "onda", "ingrandisci": "ingrandisci",
                   "scuoti": "scuoti", "brilla": "brilla", "ruota": "ruota", "salta": "salta"}

#: Durate predefinite (millisecondi).
DURATA_ENTRATA = 500
DURATA_TOCCO = 350
#: Periodo degli effetti continui a velocità "normale" (millisecondi).
PERIODI_CONTINUI = {"pulsa": 1200, "respira": 3000, "galleggia": 2400, "saltella": 900, "oscilla": 1600,
                    "ruota": 3000, "lampeggia": 1000, "brilla": 1800, "arcobaleno": 4000, "battito": 1300,
                    "vibra": 250}
FATTORE_VELOCITA = {"lenta": 1.6, "normale": 1.0, "veloce": 0.6}

DESCRIZIONI_ENTRATE = {
    "nessuna": "compare subito, senza animazione",
    "dissolvenza": "compare sfumando piano piano",
    "scorri_su": "entra salendo dal basso",
    "scorri_giu": "entra scendendo dall'alto",
    "scorri_sinistra": "entra da destra andando verso sinistra",
    "scorri_destra": "entra da sinistra andando verso destra",
    "zoom": "cresce dal centro",
    "rimbalzo": "cresce e fa un piccolo rimbalzo",
    "elastico": "cresce come una molla",
    "caduta": "cade dall'alto e rimbalza a terra",
    "ruota": "entra girando su se stesso",
    "capovolgi": "si gira come una carta",
}
DESCRIZIONI_CONTINUI = {
    "nessuno": "resta fermo",
    "pulsa": "si ingrandisce e rimpicciolisce piano",
    "respira": "sfuma e torna pieno, lentamente",
    "galleggia": "sale e scende come sull'acqua",
    "saltella": "fa dei saltelli",
    "oscilla": "dondola a destra e a sinistra",
    "ruota": "gira su se stesso senza fermarsi",
    "lampeggia": "si accende e si spegne",
    "brilla": "ha un bagliore che va e viene",
    "arcobaleno": "cambia tinta passando per l'arcobaleno",
    "battito": "batte come un cuore",
    "vibra": "vibra come un telefono che squilla",
}
DESCRIZIONI_TOCCHI = {
    "nessuno": "non fa niente di speciale",
    "rimbalzo": "fa un saltello",
    "affonda": "si schiaccia un poco, come un tasto vero",
    "onda": "parte un'onda dal punto toccato",
    "ingrandisci": "si ingrandisce un attimo",
    "scuoti": "si scuote",
    "brilla": "manda un lampo di luce",
    "ruota": "fa un giro",
    "salta": "fa un salto in alto",
}


def _sinonimi(scelte: tuple[str, ...], altri: dict[str, str]) -> dict[str, str]:
    """Sinonimi per ``Proprieta.sinonimi``: ogni scelta anche scritta con gli spazi (``"scorri giù"``)."""
    s = {semplifica_nome(x).replace(" ", "_"): x for x in scelte}
    s.update(altri)
    return s


SINONIMI_ENTRATE = _sinonimi(ENTRATE, {
    "nessuno": "nessuna", "niente": "nessuna", "dissolvi": "dissolvenza", "sfuma": "dissolvenza",
    "sfumatura": "dissolvenza", "dal_basso": "scorri_su", "dall_alto": "scorri_giu", "da_destra": "scorri_sinistra",
    "da_sinistra": "scorri_destra", "cresci": "zoom", "ingrandisci": "zoom", "rimbalza": "rimbalzo",
    "molla": "elastico", "elastica": "elastico", "cadi": "caduta", "gira": "ruota", "carta": "capovolgi",
    "gira_carta": "capovolgi",
})
SINONIMI_CONTINUI = _sinonimi(CONTINUI, {
    "nessuna": "nessuno", "niente": "nessuno", "respiro": "respira", "galleggiare": "galleggia",
    "salta": "saltella", "saltelli": "saltella", "dondola": "oscilla", "gira": "ruota", "lampeggio": "lampeggia",
    "luce": "brilla", "bagliore": "brilla", "colori": "arcobaleno", "cuore": "battito", "vibrazione": "vibra",
    "trema": "vibra",
})
SINONIMI_TOCCHI = _sinonimi(TOCCHI, {
    "nessuna": "nessuno", "niente": "nessuno", "rimbalza": "rimbalzo", "schiaccia": "affonda",
    "premi": "affonda", "increspatura": "onda", "cresci": "ingrandisci", "scossa": "scuoti", "luce": "brilla",
    "lampo": "brilla", "gira": "ruota", "salto": "salta",
})
SINONIMI_VELOCITA = _sinonimi(VELOCITA, {"lento": "lenta", "piano": "lenta", "normali": "normale",
                                         "media": "normale", "veloci": "veloce", "rapida": "veloce",
                                         "svelta": "veloce"})


def normalizza(nome: Any, scelte: tuple[str, ...], sinonimi: dict[str, str]) -> str | None:
    """Nome canonico di un effetto (``"Scorri giù"`` -> ``"scorri_giu"``) o None se sconosciuto."""
    if not isinstance(nome, str):
        return None
    if nome in scelte:
        return nome
    chiave = semplifica_nome(nome).replace(" ", "_").replace("-", "_")
    if chiave in scelte:
        return chiave
    return sinonimi.get(chiave)


def periodo_continuo(nome: str, velocita: str = "normale") -> int:
    """Durata di un giro dell'effetto continuo (millisecondi)."""
    return int(round(PERIODI_CONTINUI.get(nome, 1500) * FATTORE_VELOCITA.get(velocita, 1.0)))


#: Durata predefinita di ogni ripetizione dei colpi dei metodi (secondi).
DURATE_COLPI = {"rimbalza": 0.6, "ruota": 0.8, "capovolgi": 0.7, "brilla": 0.7, "dondola": 0.5, "trema": 0.6,
                "affonda": 0.3, "onda": 0.5, "ingrandisci": 0.35, "scuoti": 0.45, "salta": 0.5, "pulsa": 0.45, "lampeggia": 0.3}


def impostazioni(p: dict) -> dict[str, Any]:
    """Effetti "senza codice" di un controllo, letti dalle sue proprietà (valori sbagliati = nessuno).

    ``{"entrata", "ritardo", "durata", "continuo", "periodo", "tocco"}`` (tempi in millisecondi).
    """
    entrata = normalizza(p.get("animazione_entrata", "nessuna"), ENTRATE, SINONIMI_ENTRATE) or "nessuna"
    continuo = normalizza(p.get("effetto_continuo", "nessuno"), CONTINUI, SINONIMI_CONTINUI) or "nessuno"
    tocco = normalizza(p.get("effetto_tocco", "nessuno"), TOCCHI, SINONIMI_TOCCHI) or "nessuno"
    velocita = normalizza(p.get("velocità_effetto", "normale"), VELOCITA, SINONIMI_VELOCITA) or "normale"

    def ms(nome: str, predefinito: int) -> int:
        v = p.get(nome, predefinito)
        try:
            return max(0, min(60000, int(v)))
        except (TypeError, ValueError):
            return predefinito

    return {"entrata": entrata, "ritardo": ms("ritardo_entrata", 0), "durata": ms("durata_entrata", DURATA_ENTRATA) or 1,
            "continuo": continuo, "periodo": periodo_continuo(continuo, velocita), "tocco": tocco}


# ===========================================================================
# Viste: chi disegna gli effetti di un controllo (widget Qt, pagina del telefono)
# ===========================================================================

def aggiungi_vista(controllo: Any, funzione: Any) -> None:
    """``funzione(dati)`` riceverà gli effetti grafici del controllo (vedi :func:`notifica`)."""
    viste = controllo.__dict__.setdefault("_viste_effetti", [])
    if funzione not in viste:
        viste.append(funzione)


def togli_vista(controllo: Any, funzione: Any) -> None:
    viste = getattr(controllo, "_viste_effetti", None)
    if viste and funzione in viste:
        viste.remove(funzione)


def notifica(controllo: Any, dati: dict) -> bool:
    """Manda un effetto grafico (dizionario di :func:`dati_effetto`) a chi disegna il controllo.

    Restituisce vero se almeno una vista l'ha ricevuto. Una vista che si rompe
    (widget già distrutto) viene tolta, senza fermare il programma.
    """
    viste = list(getattr(controllo, "_viste_effetti", None) or ())
    for f in viste:
        try:
            f(dict(dati))
        except RuntimeError:
            togli_vista(controllo, f)
    return bool(viste)


def dati_effetto(tipo: str, effetto: str, durata_ms: int, **altro: Any) -> dict:
    """Dizionario di un effetto grafico (valore di :data:`NOTIFICA_EFFETTO` e messaggio per il telefono).

    ``tipo``: ``"colpo"``, ``"entrata"``, ``"uscita"`` o ``"ferma"``; ``altro``:
    ``volte``, ``giri``, ``colore``.
    """
    d: dict[str, Any] = {"tipo": tipo, "effetto": effetto, "durata": int(max(0, durata_ms))}
    for k, v in altro.items():
        if v is not None and v != "":
            d[k] = v
    return d


# ===========================================================================
# Fotogrammi approssimati (per Qt, che non ruota i widget)
# ===========================================================================

def _uscita_cubica(t: float) -> float:
    return 1 - (1 - t) ** 3


def _dietro(t: float, s: float = 1.70158) -> float:
    """Arriva oltre 1 e torna indietro (OutBack)."""
    t -= 1
    return t * t * ((s + 1) * t + s) + 1


def _elastica(t: float) -> float:
    if t <= 0 or t >= 1:
        return max(0.0, min(1.0, t))
    return 2 ** (-10 * t) * math.sin((t * 10 - 0.75) * (2 * math.pi / 3)) + 1


def _rimbalzo(t: float) -> float:
    n, d = 7.5625, 2.75
    if t < 1 / d:
        return n * t * t
    if t < 2 / d:
        t -= 1.5 / d
        return n * t * t + 0.75
    if t < 2.5 / d:
        t -= 2.25 / d
        return n * t * t + 0.9375
    t -= 2.625 / d
    return n * t * t + 0.984375


def _giro(gradi: float) -> float:
    """Larghezza apparente di una carta che gira di ``gradi`` attorno all'asse verticale."""
    return max(0.04, abs(math.cos(math.radians(gradi))))


def fotogramma_neutro() -> dict[str, Any]:
    """Nessuna trasformazione: ``dx``/``dy`` in pixel, ``sx``/``sy`` scala, ``alfa`` 0..1,
    ``luce`` 0..1 (bagliore), ``tinta`` 0..1 (tonalità dell'arcobaleno) o None."""
    return {"dx": 0.0, "dy": 0.0, "sx": 1.0, "sy": 1.0, "alfa": 1.0, "luce": 0.0, "tinta": None}


def fotogramma_entrata(nome: str, t: float) -> dict[str, Any]:
    """Fotogramma di un'entrata: ``t`` = 0 nascosto, 1 al suo posto. Per l'uscita si usa ``1 - t``."""
    t = max(0.0, min(1.0, float(t)))
    f = fotogramma_neutro()
    e = _uscita_cubica(t)
    if nome == "dissolvenza":
        f["alfa"] = e
    elif nome in ("scorri_su", "scorri_giu", "scorri_sinistra", "scorri_destra"):
        resto = 48 * (1 - e)
        f["alfa"] = min(1.0, t * 2)
        f["dy" if nome in ("scorri_su", "scorri_giu") else "dx"] = resto if nome in ("scorri_su", "scorri_sinistra") \
            else -resto
    elif nome == "zoom":
        f["sx"] = f["sy"] = 0.3 + 0.7 * e
        f["alfa"] = min(1.0, t * 2)
    elif nome == "rimbalzo":
        f["sx"] = f["sy"] = max(0.05, 0.3 + 0.7 * _dietro(t, 2.6))
        f["alfa"] = min(1.0, t * 3)
    elif nome == "elastico":
        f["sx"] = f["sy"] = max(0.05, 0.3 + 0.7 * _elastica(t))
        f["alfa"] = min(1.0, t * 3)
    elif nome == "caduta":
        f["dy"] = -90 * (1 - _rimbalzo(t))
        f["alfa"] = min(1.0, t * 4)
    elif nome == "ruota":
        s = 0.3 + 0.7 * e
        f["sx"] = s * _giro(-180 * (1 - e))
        f["sy"] = s
        f["alfa"] = min(1.0, t * 2)
    elif nome == "capovolgi":
        f["sx"] = _giro(90 * (1 - e))
        f["alfa"] = min(1.0, t * 3)
    return f


def fotogramma_continuo(nome: str, fase: float) -> dict[str, Any]:
    """Fotogramma di un effetto continuo; ``fase`` = 0..1 dentro un giro."""
    fase = float(fase) % 1.0
    f = fotogramma_neutro()
    onda = math.sin(2 * math.pi * fase)          # -1..1
    su = (1 - math.cos(2 * math.pi * fase)) / 2  # 0..1..0
    if nome == "pulsa":
        f["sx"] = f["sy"] = 1 + 0.06 * su
    elif nome == "respira":
        f["alfa"] = 1 - 0.45 * su
        f["sx"] = f["sy"] = 1 + 0.02 * su
    elif nome == "galleggia":
        f["dy"] = -6 * su
    elif nome == "saltella":
        f["dy"] = -12 * abs(math.sin(math.pi * fase))
    elif nome == "oscilla":
        f["dx"] = 4 * onda
    elif nome == "ruota":
        f["sx"] = _giro(360 * fase)
    elif nome == "lampeggia":
        f["alfa"] = 0.15 if fase >= 0.5 else 1.0
    elif nome == "brilla":
        f["luce"] = su
    elif nome == "arcobaleno":
        f["tinta"] = fase
    elif nome == "battito":
        colpo = 0.0
        for centro in (0.14, 0.42):
            distanza = abs(fase - centro)
            if distanza < 0.12:
                colpo = max(colpo, math.cos(distanza / 0.12 * math.pi / 2))
        f["sx"] = f["sy"] = 1 + 0.12 * colpo
    elif nome == "vibra":
        f["dx"] = 2 * math.sin(2 * math.pi * fase * 2)
        f["dy"] = 1.5 * math.cos(2 * math.pi * fase * 3)
    return f


def fotogramma_colpo(nome: str, t: float, *, volte: int = 1, giri: float = 1) -> dict[str, Any]:
    """Fotogramma di un effetto breve; ``t`` = 0..1 nella durata totale."""
    t = max(0.0, min(1.0, float(t)))
    volte = max(1, int(volte or 1))
    f = fotogramma_neutro()
    campana = math.sin(math.pi * t)                     # 0..1..0
    if nome == "rimbalza":
        u = (t * volte) % 1.0 if t < 1 else 0.0
        smorza = 1 - 0.35 * math.floor(t * volte) / max(1, volte)
        f["dy"] = -22 * smorza * math.sin(math.pi * u)
    elif nome == "ruota":
        f["sx"] = _giro(360 * float(giri or 1) * (4 * t ** 3 if t < 0.5 else 1 - (-2 * t + 2) ** 3 / 2))
    elif nome == "capovolgi":
        f["sx"] = _giro(360 * t)
    elif nome == "brilla":
        f["luce"] = abs(math.sin(math.pi * t * volte))
    elif nome == "dondola":
        f["dx"] = 5 * math.sin(2 * math.pi * t * volte) * (1 - t)
    elif nome == "trema":
        f["dx"] = 2.5 * math.sin(2 * math.pi * t * 9) * (1 - 0.5 * t)
        f["dy"] = 1.5 * math.sin(2 * math.pi * t * 13) * (1 - 0.5 * t)
    elif nome == "affonda":
        f["sx"] = f["sy"] = 1 - 0.07 * campana
        f["dy"] = 1.5 * campana
    elif nome == "onda":
        f["luce"] = campana * 0.8
    elif nome == "ingrandisci":
        f["sx"] = f["sy"] = 1 + 0.12 * campana
    elif nome == "scuoti":
        f["dx"] = 8 * math.sin(2 * math.pi * t * 4) * (1 - t)
    elif nome == "salta":
        f["dy"] = -30 * campana
    elif nome == "pulsa":
        f["sx"] = f["sy"] = 1 + 0.08 * abs(math.sin(math.pi * t * volte))
    elif nome == "lampeggia":
        f["alfa"] = 0.2 + 0.8 * abs(math.cos(math.pi * t * volte))
    return f


def componi(fotogrammi: list[dict[str, Any]]) -> dict[str, Any]:
    """Più effetti insieme (entrata + continuo + tocco): spostamenti sommati, scale e alfa moltiplicati."""
    r = fotogramma_neutro()
    for f in fotogrammi:
        r["dx"] += f.get("dx", 0.0)
        r["dy"] += f.get("dy", 0.0)
        r["sx"] *= f.get("sx", 1.0)
        r["sy"] *= f.get("sy", 1.0)
        r["alfa"] *= f.get("alfa", 1.0)
        r["luce"] = max(r["luce"], f.get("luce", 0.0))
        if f.get("tinta") is not None:
            r["tinta"] = f["tinta"]
    return r


def rettangolo_effetto(rettangolo: tuple[int, int, int, int], f: dict[str, Any]) -> tuple[int, int, int, int]:
    """Rettangolo ``(x, y, w, h)`` spostato e scalato dal centro secondo il fotogramma."""
    x, y, w, h = rettangolo
    nw = max(1, int(round(w * f.get("sx", 1.0))))
    nh = max(1, int(round(h * f.get("sy", 1.0))))
    return (int(round(x + (w - nw) / 2 + f.get("dx", 0.0))), int(round(y + (h - nh) / 2 + f.get("dy", 0.0))),
            nw, nh)


def colore_tinta(tinta: float) -> str:
    """Colore dell'arcobaleno per ``tinta`` 0..1 (``"#RRGGBB"``)."""
    import colorsys

    r, g, b = colorsys.hsv_to_rgb(float(tinta) % 1.0, 0.85, 1.0)
    return "#{:02X}{:02X}{:02X}".format(int(r * 255), int(g * 255), int(b * 255))


__all__ = ["DURATE_COLPI", "impostazioni", "aggiungi_vista", "togli_vista", "notifica", "ENTRATE", "CONTINUI", "TOCCHI", "VELOCITA", "COLPI", "COLPO_DEL_TOCCO", "NOTIFICA_EFFETTO",
           "NOTIFICA_ANIMAZIONE", "DURATA_ENTRATA", "DURATA_TOCCO", "PERIODI_CONTINUI", "normalizza",
           "periodo_continuo", "dati_effetto", "fotogramma_entrata", "fotogramma_continuo", "fotogramma_colpo",
           "componi", "rettangolo_effetto", "colore_tinta"]
