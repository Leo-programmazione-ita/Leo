"""Ponte tra interprete e interfaccia grafica - CONTRATTO CONDIVISO (senza Qt).

L'interprete ha l'attributo ``ponte_grafico`` (None = nessuna grafica). Le
funzioni di libreria ``messaggio``, ``domanda``, ``apri_finestra``,
``chiudi_finestra`` (in ``leo/libreria/grafica.py``) lo usano; se e' None
usano :class:`PonteConsole` sull'interprete.

Implementazione Qt: ``leo.grafica.qt.applicazione.PonteQt``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class PonteGrafico(ABC):
    @abstractmethod
    def messaggio(self, testo: str, titolo: str = "Leo") -> None:
        """Finestrella con il testo e il pulsante OK (bloccante)."""

    @abstractmethod
    def domanda(self, testo: str, titolo: str = "Leo") -> bool:
        """Finestrella Si'/No; restituisce vero per Si'."""

    @abstractmethod
    def apri_finestra(self, nome: str) -> None:
        """Mostra la finestra ``nome`` (caricata dalla sua .maschera). ErroreNome se non esiste."""

    @abstractmethod
    def chiudi_finestra(self, nome: str) -> None:
        """Chiude la finestra ``nome``; chiudere la finestra iniziale termina il programma."""

    def attendi(self, secondi: float) -> None:
        """``attendi()`` in un programma grafico: deve lasciare vivere l'interfaccia
        (l'implementazione Qt elabora gli eventi mentre aspetta)."""
        import time

        time.sleep(secondi)


class PonteConsole(PonteGrafico):
    """Ripiego testuale: usa ``interprete.scrivi`` / ``interprete.leggi``."""

    def __init__(self, interprete: Any) -> None:
        self.interprete = interprete

    def messaggio(self, testo: str, titolo: str = "Leo") -> None:
        self.interprete.scrivi(f"[{titolo}] {testo}\n")

    def domanda(self, testo: str, titolo: str = "Leo") -> bool:
        while True:
            risposta = self.interprete.leggi(f"[{titolo}] {testo} [s/n] ").strip().lower()
            if risposta in ("s", "si", "sì", "si'"):
                return True
            if risposta in ("n", "no"):
                return False

    def apri_finestra(self, nome: str) -> None:
        from ..errori import ErroreValore

        raise ErroreValore(f"Non posso aprire la finestra `{nome}`: il programma non è in modalità grafica.")

    def chiudi_finestra(self, nome: str) -> None:
        pass
