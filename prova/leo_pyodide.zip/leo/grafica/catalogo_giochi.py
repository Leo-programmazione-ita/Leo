"""Catalogo degli OGGETTI DA GIOCO (scheda "Giochi" della casella, accanto a Scena, Sprite e Joystick).

Oggetti pronti per fare un gioco senza scrivere codice: personaggi animati, mondi a piastrelle,
piattaforme, monete, nemici, proiettili, ostacoli, sfondi che scorrono, telecamera, vite,
classifica, timer, pulsanti da gioco, dado, mazzo di carte, scacchiera, particelle, pianoforte,
ruota della fortuna, bersaglio e porta.

Il comportamento viene dalle **dinamiche** (:mod:`leo.grafica.giochi.dinamiche`): ogni oggetto ha
già quelle giuste (la Moneta è "raccoglibile", il Nemico è "nemico", la Piattaforma è
"piattaforma"...) e se ne possono aggiungere altre dal pannello delle proprietà, anche ai controlli
normali (un'Immagine che rimbalza, un'Etichetta trascinabile...).

Il disegno e il movimento li fanno ``giochi.js`` sul telefono e ``leo.grafica.qt.widget_giochi`` sul PC;
qui ci sono i dati e i metodi puri (dado, mazzo, scacchiera, classifica, vite, timer...).

Le immagini accettano i nomi pronti (``personaggio:volpe``, ``oggetto:moneta``), i file del progetto
e quelli della galleria (``galleria:categoria/nome``): vedi :mod:`leo.grafica.giochi.risorse`.

API: ``tipi()`` (oggetti NUOVI a ogni chiamata), ``DATI_EVENTI``, ``SCHEDA``, ``TIPI_GIOCHI``.
"""

from __future__ import annotations

import json
import random
from pathlib import Path
from typing import Any

from ..errori import ErroreTipo, ErroreValore
from .catalogo_dante import _intero, _lista, _numero, _p, _sl, _t, _testo, _valore
from .giochi import tabellone
from .giochi.dinamiche import proprieta_dinamiche
from .metadati import TipoControllo, registra

__all__ = ["tipi", "DATI_EVENTI", "SCHEDA", "TIPI_GIOCHI", "PERSONAGGI", "STILI_PERSONAGGI", "FIGURE",
           "prepara", "mazzo", "nome_carta", "CARTE_ITALIANE"]

#: Scheda della casella dei controlli (la stessa di Scena, Sprite, Joystick e Punteggio).
SCHEDA = "Giochi"

#: I personaggi disegnati per Leo (fogli di animazione: 8 fotogrammi x 7 animazioni, vedi
#: :mod:`leo.grafica.giochi.personaggi`), per stile.
STILI_PERSONAGGI: dict[str, tuple[str, ...]] = {
    "cartone": ("volpe", "gatto", "rana", "orsetto", "draghetto"),
    "piatto": ("astronauta", "robot", "ninja", "esploratrice"),
    "pixel": ("cavaliere", "maga", "pirata", "pinguino"),
    "realistico": ("atleta", "ranger", "guerriera"),
    "fantascienza": ("androide", "pilota", "cacciatrice"),
}
PERSONAGGI: tuple[str, ...] = tuple(n for gruppo in STILI_PERSONAGGI.values() for n in gruppo)

#: Le animazioni di un personaggio (una riga del foglio ciascuna, 8 fotogrammi).
ANIMAZIONI = ("fermo", "cammina", "corre", "salta", "colpito", "attacco", "vittoria")

#: Figure pronte degli altri oggetti (``dati/giochi/<gruppo>/<nome>.svg``).
FIGURE: dict[str, tuple[str, ...]] = {
    "oggetto": ("moneta", "gemma", "stella", "cuore", "chiave", "diamante", "mela", "fungo", "trofeo", "pozione"),
    "nemico": ("slime", "fungo_cattivo", "pipistrello", "fantasma", "ragno", "chiocciola"),
    "ostacolo": ("spuntoni", "lava", "cactus", "sega", "fuoco", "cassa"),
    "proiettile": ("palla", "freccia", "stella", "laser", "palla_di_fuoco", "bolla"),
    "piattaforma": ("erba", "pietra", "legno", "ghiaccio", "nuvola", "metallo", "mattoni"),
    "porta": ("porta", "bandiera", "portale", "castello"),
    "scena": ("colline", "città", "spazio", "mare", "bosco", "montagne", "deserto", "strada"),
    "veicolo": ("auto_rossa", "auto_blu", "auto_gialla", "auto_verde", "astronave", "astronave_nemica", "asteroide",
                "camion"),
    "mondo": ("prato", "deserto", "neve", "caverna", "castello", "spazio"),
}

CARTE_FRANCESI_SEMI = ("cuori", "quadri", "fiori", "picche")
CARTE_ITALIANE = ("coppe", "denari", "spade", "bastoni")
_NOMI_FRANCESI = {1: "Asso", 11: "Jack", 12: "Donna", 13: "Re"}
_NOMI_ITALIANI = {1: "Asso", 8: "Fante", 9: "Cavallo", 10: "Re"}
# I simboli dei semi delle carte (scritti come codici: non sono emoji dell'interfaccia)
_SIMBOLI = {seme: chr(codice) for seme, codice in
            (("cuori", 0x2665), ("quadri", 0x2666), ("fiori", 0x2663), ("picche", 0x2660))}

#: Mappa del MondoAPiastrelle appena messo nella finestra (un piccolo livello da provare subito).
MAPPA_ESEMPIO = [
    "..............",
    "..............",
    "..........o.o.",
    "........=====.",
    "...o.o........",
    "..=====....^..",
    "##############",
    "##############",
]
#: Simboli della mappa e cosa sono (vedi anche il disegno in giochi.js e widget_giochi.py).
SIMBOLI_MAPPA = {
    "#": "terreno (muro)", "=": "ponte (si salta da sotto)", "B": "blocco", "o": "moneta (10 punti)",
    "*": "stella (50 punti)", "c": "cuore (una vita)", "^": "spuntoni (tolgono una vita)",
    "~": "acqua o lava (tolgono una vita)", "F": "bandiera d'arrivo", ".": "vuoto",
}

#: Azioni dei pulsanti da gioco (le prime muovono il giocatore; le altre sono per i menu delle app).
AZIONI_PULSANTE = ("salta", "spara", "azione", "pausa", "sinistra", "destra", "su", "giù", "a", "b", "x", "y",
                   "gioca", "ricomincia", "menu", "casa", "suono", "impostazioni", "avanti", "indietro",
                   "conferma", "annulla", "aggiungi", "cerca", "condividi", "preferito")
#: Forme dei pulsanti da gioco.
FORME_PULSANTE = ("rotondo", "quadrato", "pillola")

_SUONI_STRUMENTO = ("pianoforte", "xilofono", "organo", "chitarra", "flauto")
_NOTE = ("do", "re", "mi", "fa", "sol", "la", "si")


# ===========================================================================
# Utilita'
# ===========================================================================

def _imposta(c: Any, proprieta: str, valore: Any) -> None:
    c.modello.proprieta[proprieta] = valore
    c.avvisa(proprieta, valore)


def _comanda(c: Any, azione: str, **dati: Any) -> bool:
    from .giochi.dinamiche import comanda
    return comanda(c, azione, **dati)


def _cartella_utente() -> Path:
    from ..percorsi import cartella_utente
    return cartella_utente()


# ===========================================================================
# Personaggio
# ===========================================================================

def _personaggio_esulta(c, secondi=1.5):
    """Il personaggio festeggia la vittoria per un po' (animazione "vittoria")."""
    _comanda(c, "esulta", secondi=float(_numero(secondi, "La durata")))


def _personaggio_attacca(c):
    """Il personaggio attacca (animazione "attacco"); con la dinamica Spara parte anche un colpo."""
    _comanda(c, "attacca")


def _personaggio_anima(c, animazione, secondi=0):
    """Mostra un'animazione: `Eroe.anima_come("colpito", 0.5)` (0 secondi = finché non la cambi)."""
    nome = _testo(animazione, "L'animazione")
    if nome not in ANIMAZIONI and nome != "automatica":
        raise ErroreValore(f"Il personaggio non ha l'animazione \"{nome}\".",
                           suggerimento="Animazioni: " + ", ".join(f'"{a}"' for a in ANIMAZIONI) + ".")
    secondi = float(_numero(secondi, "La durata"))
    if secondi > 0:
        _comanda(c, "anima", animazione=nome, secondi=secondi)
    else:
        _imposta(c, "animazione", nome)


def _personaggio_guarda(c, verso):
    """Gira il personaggio: `Eroe.guarda("sinistra")`."""
    verso = _testo(verso, "Il verso")
    if verso not in ("destra", "sinistra"):
        raise ErroreValore("Il personaggio guarda a \"destra\" o a \"sinistra\".")
    _imposta(c, "guarda", verso)


# ===========================================================================
# Vite
# ===========================================================================

def _vite_togli(c, quante=1):
    """Toglie vite (una se non dici niente); a zero arriva l'evento `finite`."""
    n = _intero(quante, "Il numero di vite")
    _imposta(c, "valore", max(0, int(_valore(c, "valore", 0)) - n))


def _vite_aggiungi(c, quante=1):
    """Aggiunge vite, senza superare il `massimo`."""
    n = _intero(quante, "Il numero di vite")
    massimo = int(_valore(c, "massimo", 5))
    _imposta(c, "valore", max(0, min(massimo, int(_valore(c, "valore", 0)) + n)))


def _vite_riempi(c):
    """Rimette tutte le vite (quante ne dice `massimo`)."""
    _imposta(c, "valore", int(_valore(c, "massimo", 5)))


# ===========================================================================
# Timer di gioco
# ===========================================================================

def _timer_avvia(c):
    """Fa partire (o ripartire) il tempo."""
    _imposta(c, "attivo", True)


def _timer_ferma(c):
    """Ferma il tempo (lo fa ripartire `avvia`)."""
    _imposta(c, "attivo", False)


def _timer_azzera(c):
    """Rimette il tempo all'inizio (fermo)."""
    _imposta(c, "attivo", False)
    _imposta(c, "rimanenti", int(_valore(c, "secondi", 60)) if _valore(c, "verso", "indietro") == "indietro" else 0)


def _timer_aggiungi(c, secondi):
    """Aggiunge secondi (negativi = toglie)."""
    s = _intero(secondi, "I secondi")
    _imposta(c, "rimanenti", max(0, int(_valore(c, "rimanenti", 0)) + s))


# ===========================================================================
# Classifica (salvata sul dispositivo)
# ===========================================================================

def _file_classifiche() -> Path:
    return _cartella_utente() / "classifiche.json"


def _leggi_classifiche() -> dict:
    try:
        dati = json.loads(_file_classifiche().read_text(encoding="utf-8"))
        return dati if isinstance(dati, dict) else {}
    except (OSError, ValueError):
        return {}


def _salva_classifiche(dati: dict) -> None:
    try:
        f = _file_classifiche()
        f.parent.mkdir(parents=True, exist_ok=True)
        f.write_text(json.dumps(dati, ensure_ascii=False, indent=1), encoding="utf-8")
    except OSError:
        pass


def _voci_pulite(voci: Any, quante: int) -> list[dict]:
    pulite = []
    for v in voci if isinstance(voci, list) else []:
        if isinstance(v, dict):
            nome, punti = v.get("nome", ""), v.get("punti", 0)
        elif isinstance(v, (list, tuple)) and len(v) >= 2:
            nome, punti = v[0], v[1]
        else:
            continue
        try:
            punti = int(punti)
        except (TypeError, ValueError):
            continue
        pulite.append({"nome": str(nome)[:24], "punti": punti})
    pulite.sort(key=lambda x: -x["punti"])
    return pulite[:max(1, quante)]


def carica_classifica(c) -> None:
    """Legge la classifica salvata (se `salva` è vero) e la mette in `voci`."""
    if not _valore(c, "salva", True):
        return
    chiave = str(_valore(c, "nome_classifica", "") or c.nome)
    salvate = _leggi_classifiche().get(chiave)
    if isinstance(salvate, list):
        c.modello.proprieta["voci"] = _voci_pulite(salvate, int(_valore(c, "quante", 10)))


def _classifica_aggiungi(c, nome, punti):
    """Aggiunge un risultato; restituisce la posizione (1 = primo) o 0 se non entra in classifica."""
    nome = _testo(nome, "Il nome").strip() or "Senza nome"
    punti = _intero(punti, "I punti")
    quante = int(_valore(c, "quante", 10))
    voci = _voci_pulite(_valore(c, "voci", []), 1000)
    nuova = {"nome": nome[:24], "punti": punti, "nuova": True}
    voci.append(nuova)
    voci.sort(key=lambda x: -x["punti"])
    posizione = voci.index(nuova) + 1
    voci = voci[:quante]
    if posizione > quante:
        posizione = 0
    per_salvare = [{"nome": v["nome"], "punti": v["punti"]} for v in voci]
    _imposta(c, "voci", [dict(v, nuova=True) if v is nuova else {"nome": v["nome"], "punti": v["punti"]}
                         for v in voci])
    if _valore(c, "salva", True):
        dati = _leggi_classifiche()
        dati[str(_valore(c, "nome_classifica", "") or c.nome)] = per_salvare
        _salva_classifiche(dati)
    return posizione


def _classifica_svuota(c):
    """Cancella tutti i risultati (anche quelli salvati)."""
    _imposta(c, "voci", [])
    if _valore(c, "salva", True):
        dati = _leggi_classifiche()
        dati.pop(str(_valore(c, "nome_classifica", "") or c.nome), None)
        _salva_classifiche(dati)


def _classifica_migliore(c):
    """Il punteggio più alto (0 se la classifica è vuota)."""
    voci = _voci_pulite(_valore(c, "voci", []), 1)
    return voci[0]["punti"] if voci else 0


def _classifica_entra(c, punti):
    """Vero se con questi punti si entra in classifica."""
    punti = _intero(punti, "I punti")
    voci = _voci_pulite(_valore(c, "voci", []), 1000)
    quante = int(_valore(c, "quante", 10))
    return len(voci) < quante or punti > voci[min(len(voci), quante) - 1]["punti"]


# ===========================================================================
# Dado
# ===========================================================================

def _dado_lancia(c):
    """Lancia il dado (con l'animazione) e restituisce il numero uscito."""
    facce = int(_valore(c, "facce", 6))
    quanti = int(_valore(c, "quanti", 1))
    valori = [random.randint(1, facce) for _ in range(quanti)]
    c.modello.proprieta["valori"] = valori
    _imposta(c, "valore", sum(valori))
    _comanda(c, "lancia", valori=valori)
    return sum(valori)


# ===========================================================================
# Mazzo di carte
# ===========================================================================

def nome_carta(valore: int, seme: str, tipo: str) -> str:
    if tipo == "numeri":
        return str(valore)
    nomi = _NOMI_ITALIANI if tipo == "napoletane" else _NOMI_FRANCESI
    return f"{nomi.get(valore, str(valore))} di {seme}"


def mazzo(tipo: str) -> list[dict]:
    """Tutte le carte di un mazzo nuovo, in ordine."""
    if tipo == "napoletane":
        return [{"valore": v, "seme": s, "nome": nome_carta(v, s, tipo)} for s in CARTE_ITALIANE for v in range(1, 11)]
    if tipo == "numeri":
        return [{"valore": v, "seme": "", "nome": str(v)} for v in range(1, 21)]
    carte = []
    for s in CARTE_FRANCESI_SEMI:
        for v in range(1, 14):
            simbolo = {1: "A", 11: "J", 12: "Q", 13: "K"}.get(v, str(v))
            carte.append({"valore": v, "seme": s, "nome": nome_carta(v, s, tipo), "simbolo": simbolo + _SIMBOLI[s]})
    return carte


def _mazzo_mescola(c):
    """Rimette tutte le carte nel mazzo e le mescola."""
    carte = mazzo(str(_valore(c, "tipo_mazzo", "francesi")))
    random.shuffle(carte)
    _imposta(c, "carte", carte)
    _imposta(c, "rimaste", len(carte))
    _imposta(c, "carta", {})
    _comanda(c, "mescola")


def _mazzo_pesca(c):
    """Pesca la carta in cima: un dizionario con `valore`, `seme` e `nome` (vuoto se il mazzo è finito)."""
    carte = list(_valore(c, "carte", []) or [])
    if not carte:
        return {}
    carta = carte.pop(0)
    c.modello.proprieta["carte"] = carte
    _imposta(c, "rimaste", len(carte))
    _imposta(c, "carta", carta)
    return dict(carta)


# ===========================================================================
# Scacchiera
# ===========================================================================

def _scacchiera_ricomincia(c):
    """Rimette i pezzi all'inizio della partita."""
    gioco = str(_valore(c, "gioco", "tris"))
    _imposta(c, "caselle", tabellone.iniziale(gioco, int(_valore(c, "righe", 8)), int(_valore(c, "colonne", 8))))
    _imposta(c, "turno", tabellone.primo_turno(gioco))
    _imposta(c, "vincitore", "")
    _imposta(c, "selezione", [])
    c.modello.proprieta.pop("fila", None)
    c.modello.proprieta.pop("evidenzia", None)


def _scacchiera_metti(c, riga, colonna, pezzo):
    """Mette un pezzo in una casella (`""` = la svuota): per i giochi inventati da te."""
    r, k = _intero(riga, "La riga"), _intero(colonna, "La colonna")
    caselle = tabellone.normalizza(_valore(c, "caselle", []), str(_valore(c, "gioco", "tris")),
                                   int(_valore(c, "righe", 8)), int(_valore(c, "colonne", 8)))
    if not (0 <= r < len(caselle) and 0 <= k < len(caselle[0])):
        raise ErroreValore(f"La casella ({r}, {k}) non c'è: righe e colonne partono da 0.")
    caselle[r][k] = str(pezzo or "")
    _imposta(c, "caselle", caselle)


def _scacchiera_pezzo(c, riga, colonna):
    """Il pezzo nella casella (`""` se è vuota)."""
    r, k = _intero(riga, "La riga"), _intero(colonna, "La colonna")
    caselle = _valore(c, "caselle", []) or []
    try:
        return str(caselle[r][k] or "")
    except (IndexError, TypeError):
        return ""


def gioca_casella(c, riga: int, colonna: int) -> tuple[dict, list[tuple[str, dict]]]:
    """Tocco sulla casella (riga, colonna): applica le regole e dice quali eventi mandare.

    Restituisce ``(esito, eventi)``; il modello è già aggiornato (e l'interfaccia avvisata)."""
    gioco = str(_valore(c, "gioco", "tris"))
    eventi: list[tuple[str, dict]] = [("clic_casella", {"riga": riga, "colonna": colonna,
                                                        "pezzo": _scacchiera_pezzo(c, riga, colonna)})]
    if _valore(c, "vincitore", "") or not _valore(c, "regole", True) or gioco == "libero":
        return {"valida": False}, eventi
    esito = tabellone.mossa(gioco, _valore(c, "caselle", []), str(_valore(c, "turno", "")), riga, colonna,
                            _valore(c, "selezione", []) or None, int(_valore(c, "righe", 8)),
                            int(_valore(c, "colonne", 8)))
    if not esito["valida"]:
        return esito, eventi
    _imposta(c, "caselle", esito["caselle"])
    _imposta(c, "selezione", esito.get("selezione") or [])
    c.modello.proprieta["evidenzia"] = esito.get("evidenzia") or []
    if esito["turno"] != _valore(c, "turno", ""):
        _imposta(c, "turno", esito["turno"])
        eventi.append(("turno", {"turno": esito["turno"]}))
    if esito["vincitore"]:
        _imposta(c, "vincitore", esito["vincitore"])
        c.modello.proprieta["fila"] = esito.get("fila") or []
        _comanda(c, "vittoria", fila=esito.get("fila") or [])
        eventi.append(("vittoria", {"vincitore": esito["vincitore"]}))
    elif esito["pareggio"]:
        _imposta(c, "vincitore", "pareggio")
        eventi.append(("pareggio", {}))
    return esito, eventi


# ===========================================================================
# Particelle, pianoforte, ruota, bersaglio, telecamera, sfondo
# ===========================================================================

def _particelle_scoppia(c, x=None, y=None):
    """Fa partire le particelle (esplosione, stelle, coriandoli...) nel punto (x, y) del controllo."""
    _comanda(c, "scoppia", x=None if x is None else float(_numero(x, "La x")),
             y=None if y is None else float(_numero(y, "La y")))


def _particelle_ferma(c):
    """Ferma le particelle continue (neve, pioggia, bolle...)."""
    _imposta(c, "continue", False)


def _pianoforte_suona(c, nota, durata=0.4):
    """Suona una nota: `Piano1.suona("do")`, `Piano1.suona("sol5", 1)`."""
    nota = _testo(nota, "La nota")
    _comanda(c, "suona", nota=nota, durata=float(_numero(durata, "La durata")))


def _ruota_gira(c):
    """Fa girare la ruota; quando si ferma arriva l'evento `fermata`. Restituisce l'indice che uscirà."""
    spicchi = _lista(_valore(c, "spicchi", []), "Gli spicchi")
    if not spicchi:
        raise ErroreValore("La ruota non ha spicchi: scrivili nella proprietà `spicchi`.")
    indice = random.randrange(len(spicchi))
    _comanda(c, "gira", indice=indice)
    return indice


def _telecamera_scuoti(c, forza=10, secondi=0.4):
    """Scuote lo schermo (un'esplosione, un colpo...)."""
    _comanda(c, "scuoti", forza=float(_numero(forza, "La forza")), secondi=float(_numero(secondi, "La durata")))


def _telecamera_segui(c, oggetto):
    """Fa seguire un altro oggetto: `Telecamera1.segui("Eroe")`."""
    nome = getattr(oggetto, "nome", oggetto)
    _imposta(c, "segui", _testo(nome, "Il nome dell'oggetto"))


def _labirinto_genera(c, seme=None):
    """Crea un labirinto nuovo (`seme` = numero che dà sempre lo stesso labirinto; niente = a caso)."""
    from .giochi import labirinto

    if seme is None:
        seme = random.randint(1, 2_000_000_000)
    seme = _intero(seme, "Il seme")
    c.modello.proprieta["seme"] = seme
    _imposta(c, "mappa", labirinto.genera(int(_valore(c, "righe", 8)), int(_valore(c, "colonne", 8)), seme,
                                          int(_valore(c, "monete", 0))))
    _imposta(c, "seme", seme)


def _labirinto_muro(c, riga, colonna):
    """Vero se nella casella (riga, colonna) della mappa c'è un muro (anche fuori dal labirinto)."""
    r, k = _intero(riga, "La riga"), _intero(colonna, "La colonna")
    return _fuori(c, r, k) or _mondo_piastrella(c, r, k) == "#"


def _fuori(c, riga, colonna) -> bool:
    mappa = _valore(c, "mappa", []) or []
    r, k = int(riga), int(colonna)
    return r < 0 or k < 0 or r >= len(mappa) or k >= len(str(mappa[r]))


def _labirinto_percorso(c):
    """Il percorso più breve dalla partenza all'uscita: una lista di [riga, colonna]."""
    from .giochi import labirinto

    return [[r, k] for r, k in labirinto.percorso(list(_valore(c, "mappa", []) or []))]


def _mondo_piastrella(c, riga, colonna):
    """Il simbolo nella piastrella (riga, colonna) della mappa (`"."` se è vuota o fuori)."""
    r, k = _intero(riga, "La riga"), _intero(colonna, "La colonna")
    mappa = _valore(c, "mappa", []) or []
    try:
        return str(mappa[r][k]) if r >= 0 and k >= 0 else "."
    except (IndexError, TypeError):
        return "."


def _mondo_metti(c, riga, colonna, simbolo):
    """Cambia una piastrella: `Mondo1.metti(3, 5, "o")` mette una moneta."""
    r, k = _intero(riga, "La riga"), _intero(colonna, "La colonna")
    simbolo = _testo(simbolo, "Il simbolo")[:1] or "."
    mappa = [str(x) for x in (_valore(c, "mappa", []) or [])]
    if r < 0 or k < 0:
        raise ErroreValore("Righe e colonne partono da 0.")
    while len(mappa) <= r:
        mappa.append("")
    riga_testo = mappa[r].ljust(k + 1, ".")
    mappa[r] = riga_testo[:k] + simbolo + riga_testo[k + 1:]
    _imposta(c, "mappa", mappa)


# ===========================================================================
# Preparazione all'apertura della finestra (telefono e PC)
# ===========================================================================

def prepara(c) -> None:
    """Valori iniziali calcolati degli oggetti da gioco (classifica salvata, pezzi, mazzo, vite, tempo)."""
    tipo = c.tipo_controllo
    p = c.modello.proprieta
    if tipo == "Classifica":
        carica_classifica(c)
    elif tipo == "Scacchiera":
        gioco = str(p.get("gioco", "tris"))
        caselle = p.get("caselle")
        if not caselle:
            p["caselle"] = tabellone.iniziale(gioco, int(p.get("righe", 8)), int(p.get("colonne", 8)))
        else:
            p["caselle"] = tabellone.normalizza(caselle, gioco, int(p.get("righe", 8)), int(p.get("colonne", 8)))
        if not p.get("turno"):
            p["turno"] = tabellone.primo_turno(gioco)
    elif tipo == "MazzoDiCarte":
        if not p.get("carte"):
            carte = mazzo(str(p.get("tipo_mazzo", "francesi")))
            if p.get("mescolato", True):
                random.shuffle(carte)
            p["carte"] = carte
            p["rimaste"] = len(carte)
    elif tipo == "Labirinto":
        from .giochi import labirinto

        if not p.get("mappa"):
            seme = p.get("seme") or 0
            try:
                seme = int(seme)
            except (TypeError, ValueError):
                seme = 0
            if seme <= 0:
                seme = random.randint(1, 2_000_000_000)
            p["mappa"] = labirinto.genera(int(p.get("righe", 8)), int(p.get("colonne", 8)), seme,
                                          int(p.get("monete", 0)))
    elif tipo == "TimerDiGioco":
        p["rimanenti"] = int(p.get("secondi", 60)) if p.get("verso", "indietro") == "indietro" else 0
    elif tipo == "Vite":
        try:
            p["valore"] = max(0, min(int(p.get("massimo", 5)), int(p.get("valore", 3))))
        except (TypeError, ValueError):
            p["valore"] = 3


# ===========================================================================
# Tipi
# ===========================================================================

#: Eventi di ogni tipo (chiavi del dizionario `evento`), oltre a quelli di gioco validi per tutti.
DATI_EVENTI: dict[str, dict[str, tuple[str, ...]]] = {
    "Personaggio": {"tocca": ("con", "tipo_con"), "raccoglie": ("oggetto", "punti", "vite"),
                    "colpito": ("da", "vite"), "sconfigge": ("nemico", "punti"), "salta": (), "atterra": ()},
    "MondoAPiastrelle": {"raccolta": ("simbolo", "riga", "colonna", "da"), "arrivo": ("chi",)},
    "Piattaforma": {"tocca": ("con", "tipo_con")},
    "Moneta": {"raccolto": ("da",)},
    "Nemico": {"sconfitto": ("da",), "tocca": ("con", "tipo_con")},
    "Proiettile": {"tocca": ("con", "tipo_con")},
    "Ostacolo": {"tocca": ("con", "tipo_con")},
    "Porta": {"entra": ("chi", "va_a")},
    "SfondoCheScorre": {},
    "Telecamera": {},
    "Vite": {"cambio": ("valore",), "finite": ()},
    "Classifica": {},
    "TimerDiGioco": {"cambio": ("rimanenti",), "scaduto": ()},
    "PulsanteGioco": {"pressione": ("azione",), "rilascio": ("azione",)},
    "FrecceDirezionali": {"pressione": ("direzione",), "rilascio": ("direzione",)},
    "Dado": {"lanciato": ("valore", "valori")},
    "MazzoDiCarte": {"pescata": ("carta",)},
    "Scacchiera": {"clic_casella": ("riga", "colonna", "pezzo"), "turno": ("turno",),
                   "vittoria": ("vincitore",), "pareggio": ()},
    "Particelle": {"finite": ()},
    "Pianoforte": {"nota": ("nota", "frequenza")},
    "RuotaDellaFortuna": {"fermata": ("indice", "testo")},
    "Bersaglio": {"colpito": ("punti", "x", "y", "da")},
    "Labirinto": {"uscita": ("chi",), "raccolta": ("simbolo", "riga", "colonna", "da")},
}


def _dinamiche(predefinite: list | None = None):
    return proprieta_dinamiche(predefinite)


def _figura(gruppo: str, predefinita: str, descrizione: str):
    return _p("figura", "scelta", predefinita, descrizione, "Aspetto", scelte=FIGURE[gruppo])


def _immagine(descrizione: str = "Un'immagine tua o della galleria al posto della figura pronta "
                                 "(anche un foglio di animazione: vedi `colonne` e `righe`)"):
    return _p("immagine", "immagine", "", descrizione, "Aspetto")


def _foglio() -> list:
    return [
        _p("colonne", "intero", 0, "Fotogrammi in orizzontale nel foglio dell'immagine (0 = da solo)", "Aspetto",
           minimo=0, massimo=64),
        _p("righe", "intero", 0, "Righe del foglio dell'immagine: una animazione per riga (0 = da solo)", "Aspetto",
           minimo=0, massimo=64),
    ]


def tipi() -> list[TipoControllo]:
    """Gli oggetti da gioco, come oggetti NUOVI a ogni chiamata."""
    s = SCHEDA
    return [
        _t("Personaggio", s, "Personaggio animato (fermo, cammina, corre, salta, colpito, attacco, vittoria) già pronto a "
           "muoversi e saltare", 3, [
               _p("personaggio", "scelta", "volpe", "Personaggio disegnato per Leo in cinque stili: cartone, "
                  "piatto, pixel, realistico, fantascienza", "Aspetto", scelte=PERSONAGGI),
               _immagine("Un foglio di animazione tuo o della galleria al posto del personaggio pronto "
                         "(righe: fermo, cammina, corre, salta, colpito, attacco, vittoria)"),
               *_foglio(),
               _p("fotogrammi", "lista", [], "In alternativa al foglio: le immagini dell'animazione, una per "
                  "fotogramma (si ripetono in ordine)", "Aspetto"),
               _p("animazione", "scelta", "automatica", "Animazione da mostrare (\"automatica\" = la sceglie il "
                  "gioco: fermo, cammina, corre, salta, colpito, attacco, vittoria)", "Aspetto",
                  scelte=("automatica",) + ANIMAZIONI),
               _p("velocità_animazione", "intero", 10, "Fotogrammi al secondo delle animazioni", "Aspetto",
                  minimo=1, massimo=60),
               _p("guarda", "scelta", "destra", "Da che parte guarda", "Aspetto", scelte=("destra", "sinistra")),
               _dinamiche([{"tipo": "giocatore"}, {"tipo": "gravità"}]),
           ], ("tocca", "raccoglie", "colpito", "sconfigge", "salta", "atterra"), "tocca", icona="personaggio",
           dimensione=(64, 64), metodi={"esulta": _personaggio_esulta, "attacca": _personaggio_attacca,
                                        "anima_come": _personaggio_anima, "guarda_verso": _personaggio_guarda}),
        _t("MondoAPiastrelle", s, "Livello a griglia scritto con i simboli: # terreno, = ponte, o moneta, "
           "* stella, ^ spuntoni, F arrivo", 3, [
               _p("mappa", "lista", list(MAPPA_ESEMPIO), "Le righe del livello, un simbolo per piastrella: "
                  "# terreno, = ponte, B blocco, o moneta, * stella, c cuore, ^ spuntoni, ~ acqua, F arrivo, "
                  ". vuoto", "Dati"),
               _p("piastrella", "intero", 32, "Lato di una piastrella in pixel", "Aspetto", minimo=8, massimo=256),
               _p("ambiente", "scelta", "prato", "Ambiente delle piastrelle (prato, deserto, neve, caverna...)",
                  "Aspetto", scelte=FIGURE["mondo"]),
               _p("cielo", "colore", "", "Colore dietro le piastrelle; se non lo scegli, trasparente", "Aspetto"),
           ], ("raccolta", "arrivo"), "raccolta", icona="mondo", dimensione=(448, 256), contenitore=True,
           metodi={"piastrella": _mondo_piastrella, "metti": _mondo_metti}, prefisso="Mondo"),
        _t("Piattaforma", s, "Piattaforma su cui camminare (ferma o che si muove)", 3, [
            _figura("piattaforma", "erba", "Materiale della piattaforma"),
            _immagine("Un'immagine tua al posto del materiale (si ripete in orizzontale)"),
            _dinamiche([{"tipo": "piattaforma"}]),
        ], ("tocca",), "tocca", icona="piattaforma", dimensione=(160, 28)),
        _t("Moneta", s, "Oggetto da raccogliere: dà punti (monete, gemme, stelle, cuori, chiavi...)", 3, [
            _figura("oggetto", "moneta", "Cosa si raccoglie"),
            _immagine(), *_foglio(),
            _dinamiche([{"tipo": "raccoglibile"}]),
        ], ("raccolto",), "raccolto", icona="moneta", dimensione=(32, 32)),
        _t("Nemico", s, "Nemico che pattuglia o insegue: se ti tocca perdi una vita, se gli salti sopra vinci tu", 3, [
            _figura("nemico", "slime", "Che nemico è"),
            _immagine(), *_foglio(),
            _dinamiche([{"tipo": "nemico"}, {"tipo": "gravità"}]),
        ], ("sconfitto", "tocca"), "sconfitto", icona="nemico", dimensione=(48, 48)),
        _t("Proiettile", s, "Colpo che vola dritto (o il modello dei colpi della dinamica Spara)", 3, [
            _figura("proiettile", "palla", "Che colpo è"),
            _immagine(), *_foglio(),
            _p("amico", "logico", True, "Vero = colpisce i nemici; falso = colpisce il giocatore", "Comportamento"),
            _dinamiche([{"tipo": "si_muove", "direzione": "destra", "velocità": 360, "al_bordo": "sparisce"}]),
        ], ("tocca",), "tocca", icona="proiettile", dimensione=(24, 24)),
        _t("Ostacolo", s, "Ostacolo che fa male: spuntoni, lava, cactus, sega, fuoco", 3, [
            _figura("ostacolo", "spuntoni", "Che ostacolo è"),
            _immagine(), *_foglio(),
            _dinamiche([{"tipo": "nemico", "movimento": "fermo", "si_schiaccia": False}]),
        ], ("tocca",), "tocca", icona="ostacolo", dimensione=(64, 28)),
        _t("Porta", s, "Porta, bandiera o portale: chi la tocca passa a un'altra schermata o livello", 3, [
            _figura("porta", "bandiera", "Che porta è"),
            _immagine(), *_foglio(),
            _dinamiche([{"tipo": "porta"}]),
        ], ("entra",), "entra", icona="porta", dimensione=(48, 64)),
        _t("SfondoCheScorre", s, "Paesaggio a più strati che scorre (effetto profondità)", 3, [
            _p("scena", "scelta", "colline", "Paesaggio pronto", "Aspetto", scelte=FIGURE["scena"]),
            _immagine("Un'immagine tua al posto del paesaggio (si ripete in orizzontale)"),
            _p("velocità", "decimale", 40.0, "Pixel al secondo con cui scorre da solo (0 = fermo, negativo = "
               "verso destra o verso l'alto)", "Comportamento", minimo=-5000, massimo=5000),
            _p("direzione", "scelta", "orizzontale", "\"orizzontale\" = il paesaggio scorre verso sinistra (corse, "
               "piattaforme); \"verticale\" = scorre verso il basso (astronavi, auto viste dall'alto)", "Comportamento",
               scelte=("orizzontale", "verticale")),
            _p("profondità", "decimale", 0.5, "Quanto segue la telecamera: 0 = lontanissimo, 1 = come il mondo",
               "Comportamento", minimo=0, massimo=1),
        ], (), None, icona="montagne", dimensione=(360, 240), prefisso="Sfondo"),
        _t("Telecamera", s, "Invisibile: fa scorrere il mondo per seguire un oggetto, e sa scuotere lo schermo", 3, [
            _p("segui", "testo", "", "Nome dell'oggetto da seguire; se non lo scegli, chi ha la dinamica Giocatore",
               "Comportamento"),
            _p("larghezza_mondo", "intero", 0, "Larghezza del mondo in pixel (0 = fin dove ci sono oggetti)",
               "Comportamento", minimo=0, massimo=1_000_000),
            _p("altezza_mondo", "intero", 0, "Altezza del mondo in pixel (0 = fin dove ci sono oggetti)",
               "Comportamento", minimo=0, massimo=1_000_000),
            _p("morbidezza", "decimale", 0.15, "0,01 = segue piano, 1 = segue di colpo", "Comportamento",
               minimo=0.01, massimo=1),
        ], (), None, icona="telecamera", invisibile=True,
           metodi={"scuoti_schermo": _telecamera_scuoti, "segui_oggetto": _telecamera_segui}),
        _t("Vite", s, "Le vite del giocatore, come cuori", 3, [
            _p("valore", "intero", 3, "Vite rimaste", minimo=0, massimo=99),
            _p("massimo", "intero", 5, "Vite al massimo", "Aspetto", minimo=1, massimo=99),
            _p("figura", "scelta", "cuore", "Come si disegna una vita", "Aspetto", scelte=("cuore", "stella", "scudo")),
            _dinamiche([{"tipo": "a_zero"}]),
        ], ("cambio", "finite"), "finite", icona="cuore", dimensione=(150, 36),
           metodi={"togli": _vite_togli, "aggiungi": _vite_aggiungi, "riempi": _vite_riempi}),
        _t("Classifica", s, "I punteggi migliori con i nomi, salvati sul dispositivo", 3, [
            _p("titolo", "testo", "Classifica", "Titolo in alto", "Aspetto"),
            _p("voci", "lista", [], "Risultati: {nome, punti}, dal migliore"),
            _p("quante", "intero", 10, "Quanti risultati tenere", minimo=1, massimo=100),
            _p("salva", "logico", True, "Ricorda i risultati anche quando riapri il gioco", "Comportamento"),
            _p("nome_classifica", "testo", "", "Nome con cui salvarla; se non lo scegli, il nome del controllo",
               "Comportamento"),
        ], (), None, icona="podio", dimensione=(240, 260),
           metodi={"aggiungi": _classifica_aggiungi, "svuota": _classifica_svuota,
                   "migliore": _classifica_migliore, "entra": _classifica_entra}),
        _t("TimerDiGioco", s, "Tempo di gioco che scende (o sale); a zero finisce la partita", 3, [
            _p("secondi", "intero", 60, "Durata della partita in secondi", minimo=0, massimo=86400),
            _sl("rimanenti", "intero", 60, "Secondi che mancano (o passati, se conta in avanti)"),
            _p("attivo", "logico", True, "Vero = il tempo scorre (parte da solo quando si apre la finestra)",
               "Comportamento"),
            _p("verso", "scelta", "indietro", "\"indietro\" = conto alla rovescia; \"avanti\" = cronometro",
               "Comportamento", scelte=("indietro", "avanti")),
            _p("avviso", "intero", 10, "Negli ultimi secondi il tempo diventa rosso e pulsa", "Aspetto",
               minimo=0, massimo=3600),
            _dinamiche([{"tipo": "a_zero"}]),
        ], ("cambio", "scaduto"), "scaduto", icona="clessidra", dimensione=(120, 44), prefisso="Tempo",
           metodi={"avvia": _timer_avvia, "ferma": _timer_ferma, "azzera": _timer_azzera,
                   "aggiungi": _timer_aggiungi}),
        _t("PulsanteGioco", s, "Grande pulsante rotondo da gioco: Salta, Spara, Pausa, frecce, azione", 3, [
            _p("azione", "scelta", "salta", "Che cosa fa nel gioco", "Comportamento", scelte=AZIONI_PULSANTE),
            _p("testo", "testo", "", "Scritta; se non lo scegli, un simbolo adatto all'azione", "Aspetto"),
            _p("colore", "colore", "", "Colore del pulsante; se non lo scegli, adatto all'azione", "Aspetto"),
            _p("forma_pulsante", "scelta", "rotondo", "Rotondo (da gioco), quadrato con gli angoli arrotondati o "
               "a pillola (con la scritta accanto al simbolo)", "Aspetto", scelte=FORME_PULSANTE),
            _p("ripeti", "logico", False, "Tenendolo premuto manda `pressione` di continuo (per sparare a raffica)",
               "Comportamento"),
            _sl("premuto", "logico", False, "Vero mentre è premuto"),
        ], ("pressione", "rilascio"), "pressione", icona="pulsante_gioco", dimensione=(76, 76), prefisso="Tasto"),
        _t("FrecceDirezionali", s, "Croce con le quattro frecce, comoda per il pollice", 3, [
            _p("colore", "colore", "", "Colore delle frecce; se non lo scegli, predefinito", "Aspetto"),
            _sl("direzione", "testo", "", "Freccia premuta: su, giù, sinistra, destra; se non lo scegli, nessuna"),
        ], ("pressione", "rilascio"), "pressione", icona="croce", dimensione=(150, 150), prefisso="Frecce"),
        _t("Dado", s, "Dado da lanciare toccandolo (anche più dadi insieme)", 3, [
            _p("valore", "intero", 1, "Il numero uscito (la somma, con più dadi)", minimo=0),
            _p("facce", "intero", 6, "Facce del dado", "Comportamento", minimo=2, massimo=100),
            _p("quanti", "intero", 1, "Quanti dadi", "Comportamento", minimo=1, massimo=6),
            _p("colore", "colore", "#FFFFFF", "Colore del dado", "Aspetto"),
            _p("lancia_col_tocco", "logico", True, "Si lancia toccandolo", "Comportamento"),
        ], ("lanciato",), "lanciato", icona="dado", dimensione=(72, 72), metodi={"lancia": _dado_lancia}),
        _t("MazzoDiCarte", s, "Mazzo di carte francesi o napoletane: mescola e pesca", 3, [
            _p("tipo_mazzo", "scelta", "francesi", "Che carte", "Comportamento",
               scelte=("francesi", "napoletane", "numeri")),
            _p("mescolato", "logico", True, "Parte già mescolato", "Comportamento"),
            _sl("carte", "lista", [], "Le carte rimaste nel mazzo, dalla prima"),
            _sl("carta", "dizionario", {}, "L'ultima carta pescata: valore, seme, nome"),
            _sl("rimaste", "intero", 0, "Quante carte restano"),
            _p("pesca_col_tocco", "logico", True, "Si pesca toccando il mazzo", "Comportamento"),
            _p("colore_dorso", "colore", "#C8102E", "Colore del dorso delle carte", "Aspetto"),
        ], ("pescata",), "pescata", icona="carte", dimensione=(110, 150), prefisso="Mazzo",
           metodi={"mescola": _mazzo_mescola, "pesca": _mazzo_pesca}),
        _t("Scacchiera", s, "Griglia di gioco con le regole pronte: tris, forza quattro, dama (o libera)", 3, [
            _p("gioco", "scelta", "tris", "Che gioco (\"libero\" = nessuna regola, decidi tu con il codice)",
               "Comportamento", scelte=tabellone.GIOCHI),
            _p("righe", "intero", 8, "Righe (solo per il gioco libero)", "Comportamento", minimo=1, massimo=30),
            _p("colonne", "intero", 8, "Colonne (solo per il gioco libero)", "Comportamento", minimo=1, massimo=30),
            _p("caselle", "lista", [], "I pezzi: una lista di righe (un testo vuoto è una casella vuota)"),
            _p("turno", "testo", "", "A chi tocca (X/O, rosso/giallo, bianco/nero)"),
            _p("regole", "logico", True, "Applica da sola le regole del gioco", "Comportamento"),
            _sl("vincitore", "testo", "", "Chi ha vinto (\"pareggio\" se nessuno)"),
            _sl("selezione", "lista", [], "Il pezzo scelto nella dama: [riga, colonna]"),
            _p("colore_chiaro", "colore", "#F3E3C3", "Colore delle caselle chiare", "Aspetto"),
            _p("colore_scuro", "colore", "#8A5A3C", "Colore delle caselle scure", "Aspetto"),
        ], ("clic_casella", "turno", "vittoria", "pareggio"), "vittoria", icona="scacchiera", dimensione=(300, 300),
           metodi={"ricomincia": _scacchiera_ricomincia, "metti": _scacchiera_metti, "pezzo": _scacchiera_pezzo}),
        _t("Particelle", s, "Esplosioni, stelle, coriandoli, fuochi d'artificio, neve, pioggia, bolle", 3, [
            _p("effetto", "scelta", "coriandoli", "Che particelle", "Aspetto",
               scelte=("esplosione", "stelle", "coriandoli", "fuochi", "neve", "pioggia", "bolle", "cuori", "fumo")),
            _p("continue", "logico", False, "Vero = non si fermano mai (neve, pioggia...); falso = partono con "
               "`scoppia()`", "Comportamento"),
            _p("quantità", "intero", 60, "Quante particelle", "Comportamento", minimo=1, massimo=600),
            _p("colore", "colore", "", "Colore; se non lo scegli, tanti colori", "Aspetto"),
        ], ("finite",), None, icona="scintille", dimensione=(240, 240),
           metodi={"scoppia": _particelle_scoppia, "ferma_particelle": _particelle_ferma}),
        _t("Pianoforte", s, "Tastiera da suonare con le dita (do re mi)", 3, [
            _p("ottave", "intero", 1, "Quante ottave", "Aspetto", minimo=1, massimo=4),
            _p("prima_ottava", "intero", 4, "Da che ottava parte (4 = il do centrale)", "Comportamento",
               minimo=1, massimo=7),
            _p("suono", "scelta", "pianoforte", "Che strumento", "Comportamento", scelte=_SUONI_STRUMENTO),
            _p("mostra_note", "logico", True, "Scrive do re mi sui tasti", "Aspetto"),
        ], ("nota",), "nota", icona="pianoforte", dimensione=(320, 140), prefisso="Piano",
           metodi={"suona": _pianoforte_suona}),
        _t("RuotaDellaFortuna", s, "Ruota a spicchi da far girare: dove si ferma?", 3, [
            _p("spicchi", "lista", ["100", "200", "Perdi", "500", "Raddoppia", "50", "Jolly", "300"],
               "I testi degli spicchi"),
            _p("colori", "lista", [], "Colori degli spicchi (vuoto = arcobaleno)", "Aspetto"),
            _p("gira_col_tocco", "logico", True, "Gira toccandola", "Comportamento"),
            _sl("indice", "intero", -1, "Lo spicchio dove si è fermata (-1 = non ancora)"),
        ], ("fermata",), "fermata", icona="ruota_fortuna", dimensione=(260, 260), prefisso="Ruota",
           metodi={"gira": _ruota_gira}),
        _t("Labirinto", s, "Labirinto generato da solo (sempre diverso o sempre uguale con lo stesso seme): i muri "
           "fermano il giocatore, l'uscita è la F", 3, [
            _p("righe", "intero", 8, "Righe di stanze", "Comportamento", minimo=2, massimo=60),
            _p("colonne", "intero", 10, "Colonne di stanze", "Comportamento", minimo=2, massimo=60),
            _p("seme", "intero", 0, "Numero del labirinto: lo stesso numero dà sempre lo stesso (0 = ogni volta "
               "diverso)", "Comportamento", minimo=0, massimo=2_000_000_000),
            _p("monete", "intero", 0, "Monete da raccogliere sparse nei vicoli ciechi", "Comportamento",
               minimo=0, massimo=500),
            _p("mappa", "lista", [], "La mappa: # muro, . corridoio, S partenza, F uscita, o moneta (vuota = la "
               "crea dal seme)"),
            _p("colore_muri", "colore", "#2A2D34", "Colore dei muri", "Aspetto"),
            _p("colore_pavimento", "colore", "#F1ECE2", "Colore dei corridoi", "Aspetto"),
            _p("mostra_percorso", "logico", False, "Disegna la strada giusta (per aiutare)", "Aspetto"),
        ], ("uscita", "raccolta"), "uscita", icona="labirinto", dimensione=(336, 272), contenitore=True,
           metodi={"genera": _labirinto_genera, "muro": _labirinto_muro, "percorso": _labirinto_percorso}),
        _t("Bersaglio", s, "Bersaglio a cerchi: più vicino al centro, più punti", 3, [
            _p("anelli", "intero", 5, "Quanti cerchi", "Aspetto", minimo=1, massimo=12),
            _p("punti_centro", "intero", 100, "Punti del centro (gli altri anelli meno)", minimo=0, massimo=100000),
            _p("colore", "colore", "#E0182D", "Colore dei cerchi", "Aspetto"),
            _dinamiche([]),
        ], ("colpito",), "colpito", icona="bersaglio", dimensione=(120, 120)),
    ]


#: Nomi degli oggetti da gioco.
TIPI_GIOCHI: tuple[str, ...] = tuple(t.nome for t in tipi())

for _tipo in tipi():
    registra(_tipo)
del _tipo
