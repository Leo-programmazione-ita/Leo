"""Azioni che i metodi dei controlli chiedono all'interfaccia grafica (senza Qt).

Alcuni metodi dei controlli non si possono eseguire sul solo modello puro:
aprire una finestra di dialogo, riprodurre un suono, salvare il disegno di una
tela... Il metodo chiama allora :func:`richiedi_interfaccia`; lo strato Qt,
quando crea il widget, registra con :func:`imposta_gestore` una funzione che
esegue queste azioni sul widget vero.

Convenzione: il nome dell'azione e' il nome del metodo Leo (``"mostra"``,
``"salva"``, ``"riproduci"``...). Il gestore riceve ``(azione, argomenti)``
con ``argomenti`` gia' validati (lista Python di valori Leo) e restituisce un
valore Leo. Un gestore che non conosce un'azione puo' restituire
:data:`NON_GESTITA`: in quel caso vale il ``predefinito``, come se non ci
fosse interfaccia.

API (fissata in piano.json, note_generali):
    NON_DISPONIBILE = "non disponibile su questo computer"
    imposta_gestore(controllo, gestore) -> None
    richiedi_interfaccia(controllo, azione, *argomenti, predefinito=None) -> Any
    errore_non_disponibile(cosa) -> ErroreValore
"""

from __future__ import annotations

from typing import Any, Callable

from ..errori import ErroreDante, ErroreValore, SegnaleControllo

NON_DISPONIBILE = "non disponibile su questo computer"

#: Firma dei gestori: (azione, argomenti) -> valore Leo
GestoreAzioni = Callable[[str, list], Any]


class _NonGestita:
    """Segnaposto restituito da un gestore che non sa eseguire un'azione."""

    _istanza: "_NonGestita | None" = None

    def __new__(cls) -> "_NonGestita":
        if cls._istanza is None:
            cls._istanza = super().__new__(cls)
        return cls._istanza

    def __repr__(self) -> str:
        return "NON_GESTITA"

    def __bool__(self) -> bool:
        return False


#: Valore che un gestore restituisce per dire "questa azione non la conosco".
NON_GESTITA: Any = _NonGestita()


def imposta_gestore(controllo: Any, gestore: GestoreAzioni | None) -> None:
    """Collega (o scollega, con ``None``) il gestore delle azioni di un controllo."""
    setattr(controllo, "gestore_azioni", gestore)


def ha_interfaccia(controllo: Any) -> bool:
    """Vero se il controllo ha un gestore delle azioni (cioe' un widget vero)."""
    return getattr(controllo, "gestore_azioni", None) is not None


def richiedi_interfaccia(controllo: Any, azione: str, *argomenti: Any, predefinito: Any = None) -> Any:
    """Chiede all'interfaccia di eseguire ``azione`` sul widget del controllo.

    Senza gestore (programma senza grafica, test) restituisce ``predefinito``.
    Gli errori Python del gestore diventano ``ErroreValore`` in italiano; gli
    errori Leo e i segnali (es. fine del programma) passano cosi' come sono.
    """
    gestore = getattr(controllo, "gestore_azioni", None)
    if gestore is None:
        return predefinito
    try:
        risultato = gestore(azione, list(argomenti))
    except (ErroreDante, SegnaleControllo):
        raise
    except Exception as e:  # noqa: BLE001 - nessun errore Python deve arrivare all'utente
        nome = getattr(controllo, "nome", "controllo")
        dettaglio = str(e) or type(e).__name__
        raise ErroreValore(f"`{nome}.{azione}` non è riuscito: {dettaglio}.") from e
    if risultato is NON_GESTITA:
        return predefinito
    return risultato


def errore_non_disponibile(cosa: str) -> ErroreValore:
    """Errore da lanciare quando una funzione richiede qualcosa che qui manca."""
    return ErroreValore(
        f"{cosa}: {NON_DISPONIBILE}.",
        suggerimento="Serve l'interfaccia grafica: esegui il progetto con Leo Studio "
                     "(o con `leo` sulla cartella del progetto), e controlla che il "
                     "componente necessario sia installato.",
    )


__all__ = ["NON_DISPONIBILE", "NON_GESTITA", "GestoreAzioni", "imposta_gestore", "ha_interfaccia",
           "richiedi_interfaccia", "errore_non_disponibile"]
