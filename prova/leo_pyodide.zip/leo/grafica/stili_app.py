"""Stili dell'app "con un tocco": gli stessi per il disegnatore del telefono e per Leo Studio.

Uno stile cambia in un colpo lo sfondo della finestra e l'aspetto di tutti gli oggetti, divisi in tre
gruppi: pulsanti, campi (caselle, elenchi, menu a tendina...) e testi (etichette, spunte, scelte...).
Applicarlo toglie prima i colori personali di ogni oggetto del gruppo (``PERSONALI``) e poi mette
quelli dello stile; "Classico" toglie soltanto, e gli oggetti tornano ai colori normali.
Ogni stile dell'app sceglie anche lo stile degli oggetti della finestra (``stile``: "moderno",
"vetro", "neon"... di :mod:`leo.grafica.stili_oggetti`) e un gruppo puo' averne uno suo (il suo
dizionario ha ``"stile"``: in "Prato" i pulsanti sono "gioco" e il resto "cartone").

La stessa tabella sta anche in ``android/app/src/main/assets/web/disegna.js`` (``STILI_APP``):
:func:`stili_per_js` la da' nella forma di quel file e un test controlla che siano uguali.

API::

    STILI_APP: tuple[StileApp, ...]
    stile_app(nome) -> StileApp                 # ErroreNome se non c'e'
    gruppo_di(tipo) -> "p" | "c" | "t" | None
    modifiche_stile(stile, controlli, nome_finestra, ha_proprieta=None) -> {nome: {proprieta: valore | TOGLI}}
    colori_anteprima(stile) -> (sfondo, sfondo_2, pulsante, testo_pulsante, campo, bordo_campo, testo)
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable

from ..errori import ErroreNome

#: Le proprieta' dell'aspetto che uno stile toglie prima di mettere le sue.
PERSONALI: tuple[str, ...] = ("colore_sfondo", "colore_testo", "colore_sfumatura", "colore_bordo", "spessore_bordo",
                              "raggio_angoli", "ombra")

PULSANTI = frozenset({"Pulsante", "PulsanteImmagine"})
CAMPI = frozenset({"CasellaTesto", "CasellaPassword", "CasellaNumero", "AreaTesto", "CasellaCodiceFiscale",
                   "CasellaIBAN", "CasellaTarga", "CasellaImporto", "SelettoreComune", "SelettoreData",
                   "MenuATendina", "Elenco"})
TESTI = frozenset({"Etichetta", "CasellaSpunta", "Scelta", "Interruttore", "Collegamento"})


class _Togli:
    """Segnaposto: "togli questa proprieta'" (torna al valore normale)."""

    _istanza = None

    def __new__(cls):
        if cls._istanza is None:
            cls._istanza = super().__new__(cls)
        return cls._istanza

    def __repr__(self) -> str:
        return "TOGLI"


TOGLI: Any = _Togli()


@dataclass(frozen=True)
class StileApp:
    nome: str
    sotto: str                                   # riga di spiegazione sotto il nome
    sfondo: str                                  # sfondo della finestra ("" = quello normale)
    pulsanti: dict = field(default_factory=dict)
    campi: dict = field(default_factory=dict)
    testi: dict = field(default_factory=dict)
    sotto_pc: str = ""                           # spiegazione in Leo Studio, se diversa da ``sotto``
    stile: str = ""                              # stile degli oggetti della finestra (leo.grafica.stili_oggetti)

    @property
    def spiegazione_pc(self) -> str:
        return self.sotto_pc or self.sotto

    def per_gruppo(self, gruppo: str | None) -> dict | None:
        return {"p": self.pulsanti, "c": self.campi, "t": self.testi}.get(gruppo or "")


STILI_APP: tuple[StileApp, ...] = (
    StileApp("Leo", "Rosso e nero, elegante", "sfumatura: #1A0507, #0B0B0D",
             {"colore_sfondo": "#E0182D", "colore_sfumatura": "#9E0B1C", "colore_testo": "#FFFFFF",
              "raggio_angoli": 12, "ombra": True},
             {"colore_sfondo": "#1C1C1E", "colore_testo": "#F2F2F7", "colore_bordo": "#3A3A3C", "raggio_angoli": 10},
             {"colore_testo": "#F2F2F7"}, stile="moderno"),
    StileApp("Notte", "Blu notte e viola", "sfumatura: #0F172A, #020617",
             {"colore_sfondo": "#6366F1", "raggio_angoli": 14},
             {"colore_sfondo": "#1E293B", "colore_testo": "#F1F5F9", "colore_bordo": "#334155", "raggio_angoli": 12},
             {"colore_testo": "#E2E8F0"}, stile="elegante"),
    StileApp("Oceano", "Azzurro fresco", "sfumatura: #E0F2FE, #BAE6FD",
             {"colore_sfondo": "#0EA5E9", "raggio_angoli": 16},
             {"colore_sfondo": "#FFFFFF", "colore_testo": "#0C4A6E", "colore_bordo": "#7DD3FC", "raggio_angoli": 12},
             {"colore_testo": "#0C4A6E"}, stile="vetro"),
    StileApp("Pastello", "Pesca e crema, morbido", "#FFF7ED",
             {"colore_sfondo": "#FDBA74", "colore_testo": "#431407"},
             {"colore_sfondo": "#FFFFFF", "colore_testo": "#431407", "colore_bordo": "#FED7AA"},
             {"colore_testo": "#7C2D12"}, stile="pillola"),
    StileApp("Neon", "Contorni luminosi su nero", "#05010D",
             {"colore_sfondo": "#00F0FF", "raggio_angoli": 10},
             {"colore_sfondo": "#0B0620", "colore_testo": "#FDE7FF", "colore_bordo": "#FF2BD6", "raggio_angoli": 8},
             {"colore_testo": "#00F0FF"}, stile="neon"),
    StileApp("Prato", "Verde natura, pulsanti da gioco", "sfumatura: #F0FDF4, #DCFCE7",
             {"colore_sfondo": "#22C55E", "colore_sfumatura": "#15803D", "colore_testo": "#FFFFFF",
              "raggio_angoli": 18, "ombra": True, "stile": "gioco"},
             {"colore_sfondo": "#FFFFFF", "colore_testo": "#14532D", "colore_bordo": "#86EFAC", "raggio_angoli": 12},
             {"colore_testo": "#14532D"}, stile="cartone"),
    StileApp("Classico", "Toglie gli stili: colori del telefono", "", {}, {}, {},
             sotto_pc="Toglie gli stili: tornano i colori normali"),
)


def stile_app(nome: str) -> StileApp:
    chiave = str(nome or "").strip().casefold()
    for s in STILI_APP:
        if s.nome.casefold() == chiave:
            return s
    raise ErroreNome(f"Non conosco lo stile `{nome}`.",
                     suggerimento="Stili: " + ", ".join(s.nome for s in STILI_APP) + ".")


def gruppo_di(tipo: str) -> str | None:
    """``"p"`` pulsanti, ``"c"`` campi, ``"t"`` testi, None per gli altri oggetti (restano come sono)."""
    if tipo in PULSANTI:
        return "p"
    if tipo in CAMPI:
        return "c"
    if tipo in TESTI:
        return "t"
    return None


def modifiche_stile(stile: StileApp, controlli: Iterable[tuple[str, str, dict]], nome_finestra: str,
                    ha_proprieta: Callable[[str, str], bool] | None = None) -> dict[str, dict[str, Any]]:
    """Cosa cambia applicando ``stile``: ``{nome: {proprieta: valore o TOGLI}}``.

    ``controlli``: terne ``(nome, tipo, proprieta attuali)``. Come ``applicaStile`` di disegna.js:
    lo sfondo della finestra diventa quello dello stile; per pulsanti, campi e testi si tolgono le
    proprieta' :data:`PERSONALI` (e lo ``stile`` dei pulsanti) e si mettono quelle dello stile.
    ``ha_proprieta(tipo, proprieta)`` (facoltativo) salta le proprieta' che un tipo non ha.
    Nel risultato ci sono solo i cambiamenti veri.
    """
    risultato: dict[str, dict[str, Any]] = {}
    for nome, tipo, attuali in controlli:
        if nome == nome_finestra or tipo == "Finestra":
            voluto: dict[str, Any] = {"sfondo": stile.sfondo if stile.sfondo else TOGLI,
                                      "stile": stile.stile if stile.stile else TOGLI}
        else:
            gruppo = stile.per_gruppo(gruppo_di(tipo))
            if gruppo is None:
                continue
            voluto = {k: TOGLI for k in PERSONALI}
            voluto["stile"] = TOGLI              # lo stile degli oggetti viene dalla finestra (o dal gruppo)
            voluto.update(gruppo)
        cambi = {}
        for k, v in voluto.items():
            if ha_proprieta is not None and not ha_proprieta(tipo, k):
                continue
            if v is TOGLI:
                if k in attuali:
                    cambi[k] = TOGLI
            elif k not in attuali or attuali[k] != v or type(attuali[k]) is not type(v):
                cambi[k] = v
        if cambi:
            risultato[nome] = cambi
    return risultato


_ESADECIMALE = re.compile(r"#[0-9A-Fa-f]{6}")


def colori_anteprima(stile: StileApp) -> dict[str, str]:
    """I colori per disegnare il campione di uno stile (nella scelta dello stile e nelle anteprime)."""
    colori = _ESADECIMALE.findall(stile.sfondo)
    fondo = colori[0] if colori else "#F2F2F7"
    return {
        "sfondo": fondo,
        "sfondo_2": colori[1] if len(colori) > 1 else fondo,
        "pulsante": stile.pulsanti.get("colore_sfondo", "#8E8E93"),
        "pulsante_2": stile.pulsanti.get("colore_sfumatura", stile.pulsanti.get("colore_sfondo", "#8E8E93")),
        "bordo_pulsante": stile.pulsanti.get("colore_bordo", ""),
        "testo_pulsante": stile.pulsanti.get("colore_testo", "#FFFFFF"),
        "campo": stile.campi.get("colore_sfondo", "#FFFFFF"),
        "bordo_campo": stile.campi.get("colore_bordo", "#C7C7CC"),
        "testo": stile.testi.get("colore_testo", "#1C1C1E"),
    }


def stili_per_js() -> list[dict]:
    """La tabella nella forma di ``STILI_APP`` di disegna.js (``nome, sotto, sfondo, stile, p, c, t``)."""
    return [{"nome": s.nome, "sotto": s.sotto, "sfondo": s.sfondo, "stile": s.stile, "p": dict(s.pulsanti),
             "c": dict(s.campi), "t": dict(s.testi)} for s in STILI_APP]


__all__ = ["STILI_APP", "StileApp", "stile_app", "gruppo_di", "modifiche_stile", "colori_anteprima", "stili_per_js",
           "PERSONALI", "PULSANTI", "CAMPI", "TESTI", "TOGLI"]
