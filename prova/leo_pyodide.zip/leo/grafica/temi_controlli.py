"""Logica pura (senza Qt) del runtime grafico: temi dei controlli, sfondi,
animazioni, menu, ordine di creazione, ancoraggi annidati e piccole regole
delle finestre personalizzabili.

Il modulo e' usato da ``leo.grafica.qt.applicazione`` (lo strato PySide6),
ma non importa Qt: tutto si verifica con ``unittest``.

Contenuto:

* **Temi dei controlli** (proprieta' ``tema_controlli`` della Finestra):
  :func:`foglio_di_stile` restituisce il foglio di stile QSS per
  ``"moderno"`` (chiaro, accento rosso; predefinito), ``"classico"``,
  ``"piatto"`` o ``"futuristico"`` (nero e rosso); :func:`colori_tema` i
  colori di base (sfondo della finestra, testo, accento...);
  :func:`tavolozza_tema` i colori dei ruoli di ``QPalette``.
* **Stemma**: :func:`percorso_stemma` e :func:`icona_finestra` (lo stemma di
  Leo e' l'icona delle finestre che non ne indicano una).
* **Tartaruga**: :func:`sfondo_tartaruga`, :func:`colore_su_sfondo`,
  :func:`passo_griglia`, :func:`righe_griglia`, :func:`testo_hud`.
* **Cursori**: :data:`CURSORI` e :func:`nome_cursore_qt` (``"mano"`` ->
  ``"PointingHandCursor"``, il nome del membro di ``Qt.CursorShape``).
* **Animazioni** di apertura e chiusura: :func:`parametri_animazione`
  (durata tra 120 e 300 ms, curva, opacita', scala, spostamento).
* **Sfondi**: :func:`analizza_sfondo` riconosce colori, sfumature,
  immagini e motivi ripetuti; :func:`punti_sfumatura` calcola gli estremi
  di una sfumatura lineare.
* **Menu**: :func:`menu_da_modelli` costruisce l'albero di ``BarraMenu`` /
  ``VoceMenu``; :func:`scorciatoia_qt` traduce ``"Ctrl+Maiusc+S"``.
* **Ordine di creazione**: :func:`ordine_creazione` (contenitori prima dei figli).
* **Finestre**: :func:`stile_finestra` (cornice, barra, ombra...),
  :func:`pulsanti_barra`, :func:`pulsante_in`, :func:`bordo_ridimensionamento`.
* **Tasti**: :func:`nome_tasto` e :func:`dati_tasto` per l'evento ``tasto``.
* **Avvisi**: :func:`avvisi_gestori` per i ``quando`` che non verranno mai chiamati.
* **Ancoraggi**: :class:`AncoraggiFinestra`, ancoraggi anche dentro i contenitori.

Formati accettati da ``sfondo`` (vedi :func:`analizza_sfondo`)::

    ""                                        -> sfondo predefinito del tema
    "#1E1E2E", "azzurro", "trasparente"       -> colore pieno
    "sfumatura: #0B0B0D, #E0182D"             -> sfumatura verticale (dall'alto in basso)
    "sfumatura orizzontale: rosso, giallo"    -> da sinistra a destra
    "sfumatura: #000000, #FFFFFF, 45"         -> angolo in gradi (anche "45°", "angolo 45")
    "sfumatura radiale: bianco, azzurro"      -> dal centro verso i bordi
    "immagine: sfondo.png"                    -> immagine che riempie la finestra
    "immagine: sfondo.png, adatta"            -> modi: riempi (predefinito), adatta, estendi, centra
    "sfondo.jpg"                              -> come "immagine: sfondo.jpg"
    "motivo: piastrella.png"                  -> immagine ripetuta
    "motivo: puntini, #00000030, bianco"      -> motivo disegnato (colore del disegno, colore di fondo)

Angoli delle sfumature: 0 = da sinistra a destra, 90 = dall'alto in basso
(predefinito), 180 = da destra a sinistra, 270 = dal basso in alto.
"""

from __future__ import annotations

import difflib
import math
import re
from typing import Any, Iterable

from ..errori import ErroreTipo, ErroreValore

# ===========================================================================
# Temi dei controlli
# ===========================================================================

TEMI_CONTROLLI = ("moderno", "classico", "piatto", "futuristico")
TEMA_PREDEFINITO = "moderno"

#: Temi con la finestra scura (testo chiaro).
TEMI_SCURI = ("futuristico",)

_COLORI_TEMI: dict[str, dict[str, str]] = {
    # Chiaro, con l'accento rosso di Leo (tavolozza "chiaro" dello Studio).
    "moderno": {
        "sfondo": "#F5F5F7", "testo": "#111114", "testo_disabilitato": "#9A9AA4",
        "accento": "#C8102E", "testo_accento": "#FFFFFF", "bordo": "#D6D6DC",
        "campo": "#FFFFFF", "pulsante": "#FFFFFF", "pulsante_sopra": "#FBEEF0",
        "pulsante_premuto": "#F5D6DB", "barra_titolo": "#EFEFF2", "selezione": "#F7D0D7",
    },
    "classico": {
        "sfondo": "#D4D0C8", "testo": "#000000", "testo_disabilitato": "#808080",
        "accento": "#000080", "testo_accento": "#FFFFFF", "bordo": "#808080",
        "campo": "#FFFFFF", "pulsante": "#D4D0C8", "pulsante_sopra": "#DEDAD2",
        "pulsante_premuto": "#C4C0B8", "barra_titolo": "#0A246A", "selezione": "#0A246A",
    },
    "piatto": {
        "sfondo": "#FFFFFF", "testo": "#202124", "testo_disabilitato": "#A0A4A8",
        "accento": "#1A73E8", "testo_accento": "#FFFFFF", "bordo": "#DADCE0",
        "campo": "#F1F3F4", "pulsante": "#1A73E8", "pulsante_sopra": "#1765CC",
        "pulsante_premuto": "#185ABC", "barra_titolo": "#F1F3F4", "selezione": "#D2E3FC",
    },
    # Nero e rosso (tavolozza "scuro" dello Studio): professionale, spigoli vivi.
    "futuristico": {
        "sfondo": "#0B0B0D", "testo": "#ECECEF", "testo_disabilitato": "#6E6E78",
        "testo_secondario": "#9C9CA6",
        "accento": "#E0182D", "accento_chiaro": "#FF3B4E", "testo_accento": "#FFFFFF",
        "bordo": "#2B2B31", "campo": "#131316", "pulsante": "#1A1A1F", "pulsante_sopra": "#22222A",
        "pulsante_premuto": "#E0182D", "barra_titolo": "#131316", "selezione": "#8E0F1D",
    },
}

#: Colore del bordo "luminoso" quando ``colore_bordo`` e' vuoto (rosso acceso di Leo).
COLORE_LUMINOSO = "#FF3B4E"


def _tema_valido(tema: str) -> str:
    if tema in _COLORI_TEMI:
        return tema
    if tema in ("", None):
        return TEMA_PREDEFINITO
    raise ErroreValore(f"Il tema dei controlli `{tema}` non esiste.",
                       suggerimento="Temi disponibili: " + ", ".join(f'"{t}"' for t in TEMI_CONTROLLI) + ".")


def colori_tema(tema: str = TEMA_PREDEFINITO) -> dict[str, str]:
    """Colori di base di un tema (copia): ``sfondo``, ``testo``, ``accento``, ``bordo``..."""
    return dict(_COLORI_TEMI[_tema_valido(tema)])


def colore_sfondo_predefinito(tema: str = TEMA_PREDEFINITO) -> str:
    """Colore della finestra quando ``sfondo`` e' vuoto."""
    return _COLORI_TEMI[_tema_valido(tema)]["sfondo"]


def colore_bordo_predefinito(stile_bordo: str, tema: str = TEMA_PREDEFINITO) -> str:
    """Colore del bordo quando ``colore_bordo`` e' vuoto."""
    if stile_bordo == "luminoso":
        return COLORE_LUMINOSO
    tema = _tema_valido(tema)
    colori = _COLORI_TEMI[tema]
    return colori["accento"] if tema in ("piatto", "futuristico") else colori["bordo"]


def foglio_di_stile(tema: str = TEMA_PREDEFINITO, *, colore_testo: str = "") -> str:
    """Foglio di stile QSS per i controlli di una finestra dell'utente.

    ``colore_testo`` (facoltativo) e' il colore del testo della finestra: si
    applica a etichette, caselle di spunta, scelte e riquadri. I colori propri
    di ogni controllo (impostati sul widget) hanno la precedenza.
    """
    tema = _tema_valido(tema)
    c = _COLORI_TEMI[tema]
    if tema == "moderno":
        qss = _QSS_MODERNO
    elif tema == "classico":
        qss = _QSS_CLASSICO
    elif tema == "futuristico":
        qss = _QSS_FUTURISTICO
    else:
        qss = _QSS_PIATTO
    for chiave, valore in c.items():
        qss = qss.replace("{" + chiave + "}", valore)
    # Colore del testo sempre esplicito: con Windows in modalita' scura la
    # tavolozza di sistema darebbe testo bianco su una finestra chiara.
    testo_base = colore_testo or c.get("testo", "#1F2328")
    qss += (f"\nQLabel, QCheckBox, QRadioButton, QGroupBox {{ color: {_qss_colore(testo_base)}; }}\n")
    return qss


def _qss_colore(colore: str) -> str:
    """``#RRGGBBAA`` -> ``rgba(r, g, b, a)`` (il QSS non capisce l'alfa in coda)."""
    if len(colore) == 9 and colore.startswith("#"):
        r, g, b, a = (int(colore[i:i + 2], 16) for i in (1, 3, 5, 7))
        return f"rgba({r}, {g}, {b}, {a})"
    return colore


_QSS_MODERNO = """
QPushButton {
    background: {pulsante}; color: {testo}; border: 1px solid {bordo};
    border-radius: 6px; padding: 4px 12px;
}
QPushButton:hover { background: {pulsante_sopra}; border-color: {accento}; }
QPushButton:pressed { background: {pulsante_premuto}; }
QPushButton:disabled { color: {testo_disabilitato}; border-color: {bordo}; }
QPushButton:focus { border: 1px solid {accento}; }
QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QDoubleSpinBox, QComboBox, QListWidget,
QListView, QTreeView, QTreeWidget, QTableView, QTableWidget, QDateEdit {
    background: {campo}; color: {testo}; border: 1px solid {bordo}; border-radius: 6px;
    padding: 3px 6px; selection-background-color: {selezione}; selection-color: {testo};
}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus,
QComboBox:focus, QListWidget:focus, QDateEdit:focus { border: 1px solid {accento}; }
QLineEdit:disabled, QTextEdit:disabled, QPlainTextEdit:disabled { color: {testo_disabilitato}; }
QComboBox::drop-down { border: none; width: 20px; }
QGroupBox { border: 1px solid {bordo}; border-radius: 8px; margin-top: 10px; padding-top: 6px; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; }
QTabWidget::pane { border: 1px solid {bordo}; border-radius: 6px; top: -1px; background: {campo}; }
QTabBar::tab { background: transparent; color: {testo}; padding: 5px 12px; border: none;
    border-bottom: 2px solid transparent; }
QTabBar::tab:selected { border-bottom: 2px solid {accento}; color: {accento}; }
QProgressBar { border: 1px solid {bordo}; border-radius: 6px; background: {campo}; text-align: center;
    color: {testo}; }
QProgressBar::chunk { background: {accento}; border-radius: 5px; }
QSlider::groove:horizontal { height: 4px; background: {bordo}; border-radius: 2px; }
QSlider::groove:vertical { width: 4px; background: {bordo}; border-radius: 2px; }
QSlider::handle:horizontal, QSlider::handle:vertical { background: {accento}; width: 14px; height: 14px;
    margin: -5px; border-radius: 7px; }
QCheckBox, QRadioButton { color: {testo}; spacing: 6px; }
QMenuBar { background: {sfondo}; color: {testo}; }
QMenuBar::item:selected { background: {pulsante_sopra}; border-radius: 4px; }
QMenu { background: {campo}; color: {testo}; border: 1px solid {bordo}; padding: 4px; }
QMenu::item { padding: 4px 18px; border-radius: 4px; }
QMenu::item:selected { background: {selezione}; }
QToolTip { background: {campo}; color: {testo}; border: 1px solid {bordo}; padding: 3px; }
"""

_QSS_CLASSICO = """
QPushButton {
    background: {pulsante}; color: {testo}; padding: 3px 10px; border-radius: 0px;
    border-style: outset; border-width: 2px;
    border-top-color: #FFFFFF; border-left-color: #FFFFFF;
    border-right-color: #404040; border-bottom-color: #404040;
}
QPushButton:pressed {
    background: {pulsante_premuto}; border-style: inset;
    border-top-color: #404040; border-left-color: #404040;
    border-right-color: #FFFFFF; border-bottom-color: #FFFFFF;
}
QPushButton:disabled { color: {testo_disabilitato}; }
QPushButton:focus { outline: 1px dotted #000000; }
QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QDoubleSpinBox, QComboBox, QListWidget,
QListView, QTreeView, QTreeWidget, QTableView, QTableWidget, QDateEdit {
    background: {campo}; color: {testo}; border-radius: 0px; border-style: inset; border-width: 2px;
    border-top-color: #808080; border-left-color: #808080;
    border-right-color: #FFFFFF; border-bottom-color: #FFFFFF;
    selection-background-color: {selezione}; selection-color: #FFFFFF;
}
QLineEdit:disabled, QTextEdit:disabled, QPlainTextEdit:disabled { background: {sfondo};
    color: {testo_disabilitato}; }
QGroupBox { border: 2px groove #FFFFFF; margin-top: 10px; padding-top: 4px; }
QGroupBox::title { subcontrol-origin: margin; left: 8px; padding: 0 3px; }
QTabWidget::pane { border: 2px outset #FFFFFF; background: {sfondo}; }
QTabBar::tab { background: {sfondo}; color: {testo}; padding: 3px 10px; border: 2px outset #FFFFFF;
    border-bottom: none; }
QTabBar::tab:selected { margin-bottom: -2px; }
QProgressBar { border: 2px inset #808080; background: {campo}; text-align: center; color: {testo}; }
QProgressBar::chunk { background: {accento}; width: 10px; margin: 1px; }
QCheckBox, QRadioButton { color: {testo}; }
QMenuBar { background: {sfondo}; color: {testo}; }
QMenuBar::item:selected { background: {selezione}; color: #FFFFFF; }
QMenu { background: {sfondo}; color: {testo}; border: 2px outset #FFFFFF; }
QMenu::item:selected { background: {selezione}; color: #FFFFFF; }
QToolTip { background: #FFFFE1; color: #000000; border: 1px solid #000000; }
"""

_QSS_PIATTO = """
QPushButton {
    background: {pulsante}; color: {testo_accento}; border: none; border-radius: 0px;
    padding: 5px 14px; font-weight: bold;
}
QPushButton:hover { background: {pulsante_sopra}; }
QPushButton:pressed { background: {pulsante_premuto}; }
QPushButton:disabled { background: {bordo}; color: {testo_disabilitato}; }
QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QDoubleSpinBox, QComboBox, QListWidget,
QListView, QTreeView, QTreeWidget, QTableView, QTableWidget, QDateEdit {
    background: {campo}; color: {testo}; border: none; border-bottom: 2px solid {bordo};
    border-radius: 0px; padding: 4px 6px; selection-background-color: {selezione};
    selection-color: {testo};
}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus,
QComboBox:focus, QListWidget:focus, QDateEdit:focus { border-bottom: 2px solid {accento}; }
QComboBox::drop-down { border: none; width: 20px; }
QGroupBox { border: none; border-top: 2px solid {bordo}; margin-top: 12px; padding-top: 6px;
    font-weight: bold; }
QGroupBox::title { subcontrol-origin: margin; left: 0px; padding: 0 4px 0 0; }
QTabWidget::pane { border: none; border-top: 1px solid {bordo}; background: {sfondo}; }
QTabBar::tab { background: transparent; color: {testo}; padding: 6px 14px; border: none; }
QTabBar::tab:selected { color: {accento}; border-bottom: 3px solid {accento}; }
QProgressBar { border: none; background: {campo}; text-align: center; color: {testo}; height: 8px; }
QProgressBar::chunk { background: {accento}; }
QSlider::groove:horizontal { height: 2px; background: {bordo}; }
QSlider::groove:vertical { width: 2px; background: {bordo}; }
QSlider::handle:horizontal, QSlider::handle:vertical { background: {accento}; width: 12px; height: 12px;
    margin: -5px; border-radius: 6px; }
QCheckBox, QRadioButton { color: {testo}; spacing: 8px; }
QMenuBar { background: {sfondo}; color: {testo}; border-bottom: 1px solid {bordo}; }
QMenuBar::item:selected { background: {campo}; }
QMenu { background: {sfondo}; color: {testo}; border: 1px solid {bordo}; }
QMenu::item { padding: 5px 20px; }
QMenu::item:selected { background: {selezione}; }
QToolTip { background: #3C4043; color: #FFFFFF; border: none; padding: 4px; }
"""

_QSS_FUTURISTICO = """
QPushButton {
    background: {pulsante}; color: {testo}; border: 1px solid {bordo};
    border-radius: 3px; padding: 4px 14px;
}
QPushButton:hover { background: {pulsante_sopra}; border-color: {accento_chiaro}; }
QPushButton:pressed { background: {pulsante_premuto}; color: {testo_accento}; border-color: {accento}; }
QPushButton:default { border-color: {accento}; }
QPushButton:disabled { color: {testo_disabilitato}; background: {campo}; border-color: {bordo}; }
QPushButton:focus { border: 1px solid {accento}; }
QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QDoubleSpinBox, QComboBox, QListWidget,
QListView, QTreeView, QTreeWidget, QTableView, QTableWidget, QDateEdit {
    background: {campo}; color: {testo}; border: 1px solid {bordo}; border-radius: 3px;
    padding: 3px 6px; selection-background-color: {selezione}; selection-color: {testo};
}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus, QSpinBox:focus, QDoubleSpinBox:focus,
QComboBox:focus, QListWidget:focus, QDateEdit:focus { border: 1px solid {accento}; }
QLineEdit:disabled, QTextEdit:disabled, QPlainTextEdit:disabled { color: {testo_disabilitato}; }
QComboBox::drop-down { border: none; width: 20px; }
QComboBox QAbstractItemView { background: {campo}; color: {testo}; border: 1px solid {bordo};
    selection-background-color: {selezione}; selection-color: {testo}; }
QHeaderView::section { background: {pulsante}; color: {testo_secondario}; border: none;
    border-bottom: 1px solid {bordo}; padding: 4px 6px; }
QTableView, QTableWidget { gridline-color: {bordo}; }
QGroupBox { border: 1px solid {bordo}; border-radius: 3px; margin-top: 12px; padding-top: 6px; }
QGroupBox::title { subcontrol-origin: margin; left: 8px; padding: 0 4px; color: {accento_chiaro};
    font-weight: bold; }
QTabWidget::pane { border: 1px solid {bordo}; border-radius: 3px; top: -1px; background: {campo}; }
QTabBar::tab { background: transparent; color: {testo_secondario}; padding: 5px 14px; border: none;
    border-bottom: 2px solid transparent; }
QTabBar::tab:hover { color: {testo}; }
QTabBar::tab:selected { border-bottom: 2px solid {accento}; color: {testo}; }
QProgressBar { border: 1px solid {bordo}; border-radius: 3px; background: {campo}; text-align: center;
    color: {testo}; }
QProgressBar::chunk { background: {accento}; border-radius: 2px; }
QSlider::groove:horizontal { height: 2px; background: {bordo}; }
QSlider::groove:vertical { width: 2px; background: {bordo}; }
QSlider::sub-page:horizontal { background: {accento}; }
QSlider::add-page:vertical { background: {accento}; }
QSlider::handle:horizontal, QSlider::handle:vertical { background: {accento}; width: 12px; height: 12px;
    margin: -5px; border-radius: 2px; }
QSlider::handle:horizontal:hover, QSlider::handle:vertical:hover { background: {accento_chiaro}; }
QCheckBox, QRadioButton { color: {testo}; spacing: 6px; }
QCheckBox::indicator, QRadioButton::indicator { width: 13px; height: 13px; border: 1px solid {bordo};
    background: {campo}; }
QCheckBox::indicator { border-radius: 2px; }
QRadioButton::indicator { border-radius: 7px; }
QCheckBox::indicator:hover, QRadioButton::indicator:hover { border-color: {accento_chiaro}; }
QCheckBox::indicator:checked, QRadioButton::indicator:checked { background: {accento}; border-color: {accento}; }
QScrollBar:vertical { background: {sfondo}; width: 10px; margin: 0; }
QScrollBar:horizontal { background: {sfondo}; height: 10px; margin: 0; }
QScrollBar::handle:vertical, QScrollBar::handle:horizontal { background: {bordo}; border-radius: 2px;
    min-height: 24px; min-width: 24px; }
QScrollBar::handle:vertical:hover, QScrollBar::handle:horizontal:hover { background: {accento}; }
QScrollBar::add-line, QScrollBar::sub-line { width: 0px; height: 0px; }
QScrollBar::add-page, QScrollBar::sub-page { background: transparent; }
QMenuBar { background: {sfondo}; color: {testo}; border-bottom: 1px solid {bordo}; }
QMenuBar::item:selected { background: {pulsante_sopra}; color: {testo}; }
QMenu { background: {campo}; color: {testo}; border: 1px solid {bordo}; padding: 4px; }
QMenu::item { padding: 4px 18px; border-radius: 2px; }
QMenu::item:selected { background: {selezione}; color: {testo}; }
QMenu::separator { height: 1px; background: {bordo}; margin: 4px 6px; }
QToolTip { background: {pulsante}; color: {testo}; border: 1px solid {accento}; padding: 3px; }
"""


def tema_scuro(tema: str = TEMA_PREDEFINITO) -> bool:
    """Vero se il tema ha la finestra scura (testo chiaro)."""
    return _tema_valido(tema) in TEMI_SCURI


#: Ruoli di ``QPalette.ColorRole`` -> chiave del colore del tema.
_RUOLI_TAVOLOZZA = {
    "Window": "sfondo", "WindowText": "testo", "Base": "campo", "AlternateBase": "pulsante_sopra",
    "Text": "testo", "Button": "pulsante", "ButtonText": "testo", "Highlight": "selezione",
    "HighlightedText": "testo", "ToolTipBase": "campo", "ToolTipText": "testo",
    "PlaceholderText": "testo_disabilitato", "Link": "accento", "BrightText": "testo_accento",
}


def tavolozza_tema(tema: str = TEMA_PREDEFINITO, *, colore_testo: str = "") -> dict[str, str]:
    """Colori dei ruoli di ``QPalette`` per un tema (nome del ruolo -> ``#RRGGBB``).

    Serve ai controlli che si disegnano da soli con la tavolozza (non col
    foglio di stile): cosi' il testo resta leggibile anche con Windows in
    modalita' scura, perche' non si eredita la tavolozza di sistema.
    ``colore_testo`` (facoltativo) sostituisce il testo della finestra.
    """
    tema = _tema_valido(tema)
    c = _COLORI_TEMI[tema]
    ruoli = {ruolo: c[chiave] for ruolo, chiave in _RUOLI_TAVOLOZZA.items()}
    if tema == "piatto":  # nel tema piatto il "pulsante" e' l'accento: testo bianco
        ruoli["ButtonText"] = c["testo_accento"]
    if tema == "classico":
        ruoli["HighlightedText"] = "#FFFFFF"
    if colore_testo:
        ruoli["WindowText"] = colore_testo
    return ruoli


# ===========================================================================
# Contrasto (WCAG)
# ===========================================================================

def _rgb(colore: str) -> tuple[int, int, int]:
    c = _normalizza_colore(colore)
    if not re.fullmatch(r"#[0-9A-Fa-f]{6}(?:[0-9A-Fa-f]{2})?", c or ""):
        raise ErroreValore(f"`{colore}` non è un colore.")
    return int(c[1:3], 16), int(c[3:5], 16), int(c[5:7], 16)


def luminanza(colore: str) -> float:
    """Luminanza relativa (WCAG 2) di un colore, da 0 (nero) a 1 (bianco)."""
    def lin(v: int) -> float:
        s = v / 255.0
        return s / 12.92 if s <= 0.04045 else ((s + 0.055) / 1.055) ** 2.4

    r, g, b = _rgb(colore)
    return 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b)


def contrasto(colore1: str, colore2: str) -> float:
    """Rapporto di contrasto WCAG tra due colori (da 1 a 21)."""
    l1, l2 = luminanza(colore1), luminanza(colore2)
    chiaro, scuro = max(l1, l2), min(l1, l2)
    return (chiaro + 0.05) / (scuro + 0.05)


# ===========================================================================
# Stemma (icona predefinita delle finestre dei programmi)
# ===========================================================================

#: File dello stemma cercati in ``dati/icone``, in ordine di preferenza.
FILE_STEMMA = ("stemma.png", "stemma.svg", "leo.ico", "dante.ico")


def percorso_stemma(cartella_icone: Any = None) -> str | None:
    """Percorso del file dello stemma di Leo, o None se non c'e'.

    ``cartella_icone`` predefinita: ``dati/icone`` (vedi ``leo.percorsi``).
    Chi mostra lo stemma deve funzionare anche senza (nessuna icona).
    """
    from pathlib import Path

    if cartella_icone is None:
        try:
            from ..percorsi import file_dati
            cartella_icone = file_dati("icone")
        except Exception:  # noqa: BLE001 - installazione incompleta
            return None
    cartella = Path(cartella_icone)
    for nome in FILE_STEMMA:
        p = cartella / nome
        try:
            if p.is_file() and p.stat().st_size > 0:
                return str(p)
        except OSError:
            continue
    return None


def icona_finestra(icona: Any, cartella_icone: Any = None) -> str | None:
    """Icona da usare per una finestra: quella indicata (``icona`` non vuota)
    oppure lo stemma di Leo; None se non c'e' nessuna delle due."""
    if isinstance(icona, str) and icona.strip():
        return icona.strip()
    return percorso_stemma(cartella_icone)


# ===========================================================================
# Finestra della tartaruga: sfondo scuro, griglia, HUD
# ===========================================================================

#: Colori della finestra della tartaruga (sullo schermo; il file SVG resta com'e').
COLORI_TARTARUGA = {
    "sfondo": "#0B0B0D", "griglia": "#16161A", "griglia_forte": "#23232A", "assi": "#3A1016",
    "hud": "#FF3B4E", "hud_secondario": "#9C9CA6", "hud_fondo": "#131316E6",
    "tartaruga": "#E0182D", "tartaruga_bordo": "#FF3B4E", "testo_chiaro": "#ECECEF",
}

#: Sfondo iniziale della tartaruga (``Tartaruga.sfondo`` non cambiato dal programma).
SFONDO_TARTARUGA_INIZIALE = "#FFFFFF"

_PASSI_GRIGLIA = (1, 2, 5, 10, 20, 25, 50, 100, 200, 250, 500, 1000, 2000, 5000, 10000, 20000, 50000)


def sfondo_tartaruga(sfondo: str) -> str:
    """Sfondo della finestra: scuro se il programma non ha scelto uno sfondo."""
    s = (sfondo or "").strip().upper()
    if not s:  # nessuna scelta del programma (lo sfondo della tartaruga parte vuoto)
        return COLORI_TARTARUGA["sfondo"]
    return sfondo


def colore_su_sfondo(colore: str, sfondo: str, *, minimo: float = 1.5) -> str:
    """Colore di un tratto sullo schermo: se si confonde con lo sfondo
    (contrasto sotto ``minimo``) diventa il testo chiaro o scuro del tema.

    Serve soprattutto per il nero iniziale della penna sullo sfondo scuro.
    """
    try:
        if contrasto(colore, sfondo) >= minimo:
            return colore
        scuro = luminanza(sfondo) < 0.18
    except (ErroreValore, ErroreTipo, ValueError):
        return colore
    return COLORI_TARTARUGA["testo_chiaro"] if scuro else "#111114"


def passo_griglia(scala: float, minimo_pixel: float = 32.0) -> float:
    """Distanza (in passi della tartaruga) tra le righe della griglia, perche'
    sullo schermo siano lontane almeno ``minimo_pixel`` pixel."""
    if not scala or scala <= 0 or math.isinf(scala) or math.isnan(scala):
        return float(_PASSI_GRIGLIA[-1])
    for passo in _PASSI_GRIGLIA:
        if passo * scala >= minimo_pixel:
            return float(passo)
    return float(_PASSI_GRIGLIA[-1])


def righe_griglia(minimo: float, massimo: float, passo: float) -> list[float]:
    """Coordinate (multipli di ``passo``) tra ``minimo`` e ``massimo`` compresi (al massimo 400)."""
    if passo <= 0 or massimo < minimo:
        return []
    inizio = math.ceil(minimo / passo)
    fine = math.floor(massimo / passo)
    if fine - inizio > 400:
        return []
    return [float(i * passo) for i in range(inizio, fine + 1)]


def _numero_hud(v: float) -> str:
    v = 0.0 if abs(v) < 0.05 else v
    return f"{v:.0f}" if abs(v - round(v)) < 0.05 else f"{v:.1f}"


def testo_hud(x: float, y: float, direzione: float) -> str:
    """Riga dell'HUD con posizione e direzione: ``"X 120   Y -40   DIR 90°"``."""
    d = direzione % 360.0
    if abs(d - 360.0) < 0.05:
        d = 0.0
    return f"X {_numero_hud(x)}   Y {_numero_hud(y)}   DIR {_numero_hud(d)}°"


# ===========================================================================
# Cursori
# ===========================================================================

#: Valori di ``cursore`` -> nome del membro di ``Qt.CursorShape``.
CURSORI: dict[str, str] = {
    "freccia": "ArrowCursor",
    "mano": "PointingHandCursor",
    "mirino": "CrossCursor",
    "attesa": "WaitCursor",
    "testo": "IBeamCursor",
}


def nome_cursore_qt(valore: str) -> str | None:
    """Nome del cursore Qt per un valore di ``cursore``.

    ``""`` -> ``"ArrowCursor"``; un nome sconosciuto che termina con
    un'estensione d'immagine -> ``None`` (cursore da immagine, lo carica lo
    strato Qt); altri valori -> ErroreValore.
    """
    if not isinstance(valore, str):
        raise ErroreTipo("`cursore` vuole un testo, per esempio \"mano\".")
    chiave = valore.strip().lower()
    if not chiave:
        return CURSORI["freccia"]
    if chiave in CURSORI:
        return CURSORI[chiave]
    if chiave.startswith("immagine:") or _sembra_immagine(chiave):
        return None
    raise ErroreValore(f"Il cursore `{valore}` non esiste.",
                       suggerimento="Cursori: " + ", ".join(f'"{c}"' for c in CURSORI) + ".")


def percorso_cursore(valore: str) -> str:
    """Percorso dell'immagine di un cursore personalizzato (``"immagine: x.png"`` o ``"x.png"``)."""
    v = valore.strip()
    if v.lower().startswith("immagine:"):
        v = v.split(":", 1)[1].strip()
    return v


# ===========================================================================
# Animazioni
# ===========================================================================

ANIMAZIONI = ("nessuna", "dissolvenza", "zoom", "scorrimento", "rimbalzo")
DURATA_MINIMA = 120
DURATA_MASSIMA = 300

_ANIMAZIONI: dict[str, dict[str, Any]] = {
    "dissolvenza": {"durata": 200, "curva": ("OutCubic", "InCubic"), "opacita": True,
                    "scala": None, "spostamento": None},
    "zoom": {"durata": 220, "curva": ("OutCubic", "InCubic"), "opacita": True,
             "scala": 0.85, "spostamento": None},
    "scorrimento": {"durata": 250, "curva": ("OutCubic", "InCubic"), "opacita": True,
                    "scala": None, "spostamento": 40},
    "rimbalzo": {"durata": 300, "curva": ("OutBack", "InBack"), "opacita": True,
                 "scala": 0.6, "spostamento": None},
}


def parametri_animazione(nome: str, *, apertura: bool = True) -> dict | None:
    """Descrizione di un'animazione di apertura/chiusura, ``None`` per ``"nessuna"``.

    Chiavi del risultato:
      ``durata``      millisecondi (sempre tra 120 e 300)
      ``curva``       nome del membro di ``QEasingCurve.Type`` (``"OutCubic"``...)
      ``opacita``     (inizio, fine) come frazione dell'opacita' della finestra, o None
      ``scala``       (inizio, fine) della dimensione rispetto al centro, o None
      ``spostamento`` ((dx0, dy0), (dx1, dy1)) in pixel rispetto alla posizione vera, o None
    """
    if nome in ("", "nessuna", None):
        return None
    dati = _ANIMAZIONI.get(nome)
    if dati is None:
        raise ErroreValore(f"L'animazione `{nome}` non esiste.",
                           suggerimento="Animazioni: " + ", ".join(f'"{a}"' for a in ANIMAZIONI) + ".")
    durata = max(DURATA_MINIMA, min(DURATA_MASSIMA, int(dati["durata"])))
    curva = dati["curva"][0 if apertura else 1]
    opacita = ((0.0, 1.0) if apertura else (1.0, 0.0)) if dati["opacita"] else None
    scala = None
    if dati["scala"] is not None:
        scala = (dati["scala"], 1.0) if apertura else (1.0, dati["scala"])
    spostamento = None
    if dati["spostamento"] is not None:
        d = (0, int(dati["spostamento"]))
        spostamento = (d, (0, 0)) if apertura else ((0, 0), d)
    return {"nome": nome, "durata": durata, "curva": curva, "opacita": opacita,
            "scala": scala, "spostamento": spostamento}


def rettangolo_scalato(rettangolo: tuple[int, int, int, int], scala: float) -> tuple[int, int, int, int]:
    """Rettangolo ``(x, y, w, h)`` ridimensionato di ``scala`` attorno al suo centro."""
    x, y, w, h = rettangolo
    nw = max(1, int(round(w * scala)))
    nh = max(1, int(round(h * scala)))
    return (int(round(x + (w - nw) / 2)), int(round(y + (h - nh) / 2)), nw, nh)


# ===========================================================================
# Colori (con ripiego se leo.grafica.colori non e' ancora disponibile)
# ===========================================================================

_NOMI_RIPIEGO = {
    "nero": "#000000", "bianco": "#FFFFFF", "rosso": "#FF0000", "verde": "#008000", "blu": "#0000FF",
    "giallo": "#FFFF00", "grigio": "#808080", "arancione": "#FFA500", "viola": "#800080",
    "rosa": "#FFC0CB", "azzurro": "#87CEEB", "marrone": "#8B4513", "ciano": "#00FFFF", "oro": "#FFD700",
    "trasparente": "#00000000",
}


def _normalizza_colore(valore: str) -> str:
    """Usa ``colori.normalizza_colore`` se c'e', altrimenti un ripiego semplice."""
    try:
        from .colori import normalizza_colore
    except (ImportError, AttributeError):
        normalizza_colore = None
    if normalizza_colore is not None:
        try:
            return normalizza_colore(valore)
        except NotImplementedError:  # pragma: no cover - modulo segnaposto
            pass
    v = valore.strip()
    if v == "":
        return ""
    if v.lower() in _NOMI_RIPIEGO:
        return _NOMI_RIPIEGO[v.lower()]
    if re.fullmatch(r"#[0-9A-Fa-f]{3}", v):
        return "#" + "".join(ch * 2 for ch in v[1:]).upper()
    if re.fullmatch(r"#(?:[0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})", v):
        return v.upper()
    raise ErroreValore(f"`{valore}` non è un colore.",
                       suggerimento="Scrivi un colore come \"#FF8800\" o un nome come \"rosso\".")


def alfa_colore(colore: str) -> int:
    """Alfa (0-255) di un colore ``#RRGGBB[AA]`` normalizzato; 255 se manca."""
    if isinstance(colore, str) and len(colore) == 9 and colore.startswith("#"):
        try:
            return int(colore[7:9], 16)
        except ValueError:
            return 255
    return 255


# ===========================================================================
# Sfondi
# ===========================================================================

ESTENSIONI_IMMAGINE = (".png", ".jpg", ".jpeg", ".bmp", ".gif", ".webp", ".svg", ".ico")
MODI_IMMAGINE = ("riempi", "adatta", "estendi", "centra")

#: Motivi disegnati -> nome del membro di ``Qt.BrushStyle``.
MOTIVI: dict[str, str] = {
    "puntini": "Dense6Pattern",
    "puntini_fitti": "Dense4Pattern",
    "righe": "HorPattern",
    "colonne": "VerPattern",
    "quadretti": "CrossPattern",
    "diagonali": "BDiagPattern",
    "diagonali_inverse": "FDiagPattern",
    "rete": "DiagCrossPattern",
}

_DIREZIONI_SFUMATURA = {"verticale": 90.0, "orizzontale": 0.0, "diagonale": 45.0,
                        "diagonale_inversa": 135.0, "lineare": 90.0}

_ESEMPI_SFONDO = ('"#1E1E2E", "sfumatura: #0B0B0D, #E0182D", "immagine: sfondo.png", '
                  '"motivo: puntini"')


def _sembra_immagine(testo: str) -> bool:
    return testo.lower().endswith(ESTENSIONI_IMMAGINE)


def _parti(testo: str) -> list[str]:
    return [p.strip() for p in testo.split(",") if p.strip()]


def _angolo(parte: str) -> float | None:
    """``"45"``, ``"45°"``, ``"45 gradi"``, ``"angolo 45"`` -> 45.0; altrimenti None."""
    p = parte.strip().lower()
    if p.startswith("angolo"):
        p = p[len("angolo"):].strip(" :=")
    p = p.replace("°", "").replace("gradi", "").strip()
    try:
        return float(p) % 360.0
    except ValueError:
        return None


def analizza_sfondo(valore: Any) -> dict:
    """Interpreta il valore di ``sfondo`` della Finestra.

    Risultati (``tipo`` e campi):
      ``{"tipo": "nessuno"}``                                      (``""``: colore del tema)
      ``{"tipo": "colore", "colore": "#RRGGBB[AA]"}``
      ``{"tipo": "sfumatura", "forma": "lineare"|"radiale", "colori": [...], "angolo": 90.0}``
      ``{"tipo": "immagine", "percorso": "x.png", "modo": "riempi"}``
      ``{"tipo": "motivo", "percorso": "x.png"}``                  (immagine ripetuta)
      ``{"tipo": "motivo", "motivo": "puntini", "stile_qt": "Dense6Pattern",
         "colore": "#RRGGBB[AA]", "sfondo": "#RRGGBB" | ""}``

    ErroreTipo se non e' un testo, ErroreValore se non si capisce.
    """
    if not isinstance(valore, str):
        raise ErroreTipo("`sfondo` vuole un testo: un colore, una sfumatura, un'immagine o un motivo.",
                         suggerimento="Esempi: " + _ESEMPI_SFONDO + ".")
    testo = valore.strip()
    if not testo:
        return {"tipo": "nessuno"}
    minuscolo = testo.lower()

    if ":" in testo:
        chiave, resto = testo.split(":", 1)
        parole = chiave.strip().lower().split()
        if parole and parole[0] == "sfumatura":
            return _analizza_sfumatura(testo, parole[1:], resto)
        if parole == ["immagine"]:
            return _analizza_immagine(resto)
        if parole == ["motivo"]:
            return _analizza_motivo(resto)
        if parole and parole[0] in ("immagine", "motivo", "sfumatura", "colore"):
            pass
        elif not re.match(r"^[a-zA-Z]:[\\/]", testo):  # "C:\..." e' un percorso
            raise ErroreValore(f"Non capisco lo sfondo `{valore}`.",
                               suggerimento="Esempi: " + _ESEMPI_SFONDO + ".")
        if parole == ["colore"]:
            return {"tipo": "colore", "colore": _normalizza_colore(resto.strip())}
    if _sembra_immagine(minuscolo):
        return {"tipo": "immagine", "percorso": testo, "modo": "riempi"}
    try:
        return {"tipo": "colore", "colore": _normalizza_colore(testo)}
    except ErroreValore:
        raise ErroreValore(f"Non capisco lo sfondo `{valore}`.",
                           suggerimento="Esempi: " + _ESEMPI_SFONDO + ".") from None


def _analizza_sfumatura(testo: str, parole: list[str], resto: str) -> dict:
    # Prima prova il contratto di leo.grafica.colori, se c'e'.
    risultato = _sfumatura_da_colori("sfumatura: " + resto.strip())
    forma = "lineare"
    angolo = 90.0
    direzione: float | None = None
    for p in parole:
        if p == "radiale":
            forma = "radiale"
        elif p == "lineare":
            forma = "lineare"
        elif p in _DIREZIONI_SFUMATURA:
            direzione = _DIREZIONI_SFUMATURA[p]
        else:
            raise ErroreValore(f"Nella sfumatura non capisco `{p}`.",
                               suggerimento="Scrivi per esempio \"sfumatura: #0B0B0D, #E0182D\" o "
                                            "\"sfumatura orizzontale: rosso, giallo\".")
    if risultato is not None:
        if forma == "radiale":
            risultato["forma"] = "radiale"
        if direzione is not None:
            risultato["angolo"] = direzione
        return risultato
    if direzione is not None:
        angolo = direzione
    colori: list[str] = []
    for parte in _parti(resto):
        a = _angolo(parte)
        if a is not None:
            angolo = a
            continue
        colori.append(_normalizza_colore(parte))
    if len(colori) < 2:
        raise ErroreValore("Una sfumatura ha bisogno di almeno due colori.",
                           suggerimento="Esempio: \"sfumatura: #0B0B0D, #E0182D\".")
    return {"tipo": "sfumatura", "forma": forma, "colori": colori, "angolo": angolo}


def _sfumatura_da_colori(testo: str) -> dict | None:
    """Adatta il risultato di ``colori.analizza_sfumatura`` (se disponibile) al formato di questo modulo."""
    try:
        from .colori import analizza_sfumatura
    except (ImportError, AttributeError):
        return None
    try:
        d = analizza_sfumatura(testo)
    except (NotImplementedError, ErroreValore, ErroreTipo):
        return None  # il ripiego qui sotto da' un messaggio preciso (o accetta l'angolo in mezzo)
    if not isinstance(d, dict):
        return None
    colori = d.get("colori") or d.get("fermate")
    if not isinstance(colori, (list, tuple)) or len(colori) < 2:
        return None
    lista: list[str] = []
    for c in colori:
        if isinstance(c, (list, tuple)) and c:  # (posizione, colore) o (colore, posizione)
            c = next((x for x in c if isinstance(x, str)), None)
        if not isinstance(c, str):
            return None
        lista.append(_normalizza_colore(c))
    angolo = d.get("angolo", 90.0)
    try:
        angolo = float(angolo) % 360.0
    except (TypeError, ValueError):
        angolo = 90.0
    forma = "radiale" if d.get("forma") == "radiale" or d.get("tipo") == "radiale" else "lineare"
    return {"tipo": "sfumatura", "forma": forma, "colori": lista, "angolo": angolo}


def _analizza_immagine(resto: str) -> dict:
    parti = _parti(resto)
    if not parti:
        raise ErroreValore("Manca il percorso dell'immagine di sfondo.",
                           suggerimento="Esempio: \"immagine: sfondo.png\".")
    percorso = parti[0]
    modo = "riempi"
    if len(parti) > 1:
        modo = parti[1].lower()
        if modo not in MODI_IMMAGINE:
            raise ErroreValore(f"`{parti[1]}` non è un modo valido per l'immagine di sfondo.",
                               suggerimento="Modi: " + ", ".join(f'"{m}"' for m in MODI_IMMAGINE) + ".")
    return {"tipo": "immagine", "percorso": percorso, "modo": modo}


def _analizza_motivo(resto: str) -> dict:
    parti = _parti(resto)
    if not parti:
        raise ErroreValore("Manca il motivo dello sfondo.",
                           suggerimento="Esempi: \"motivo: puntini\", \"motivo: piastrella.png\".")
    primo = parti[0]
    chiave = primo.lower().replace(" ", "_")
    if chiave in MOTIVI:
        colore = _normalizza_colore(parti[1]) if len(parti) > 1 else "#00000040"
        fondo = _normalizza_colore(parti[2]) if len(parti) > 2 else ""
        return {"tipo": "motivo", "motivo": chiave, "stile_qt": MOTIVI[chiave], "colore": colore,
                "sfondo": fondo}
    if _sembra_immagine(primo) or "/" in primo or "\\" in primo:
        return {"tipo": "motivo", "percorso": primo}
    vicini = difflib.get_close_matches(chiave, list(MOTIVI), n=1)
    suggerimento = (f"Forse intendevi \"{vicini[0]}\"?" if vicini else
                    "Motivi: " + ", ".join(f'"{m}"' for m in MOTIVI) + ", oppure un'immagine da ripetere.")
    raise ErroreValore(f"Il motivo `{primo}` non esiste.", suggerimento=suggerimento)


def punti_sfumatura(angolo: float, larghezza: float, altezza: float) -> tuple[float, float, float, float]:
    """Estremi ``(x1, y1, x2, y2)`` di una sfumatura lineare che attraversa il rettangolo.

    ``angolo`` in gradi: 0 = verso destra, 90 = verso il basso.
    """
    rad = math.radians(angolo)
    dx, dy = math.cos(rad), math.sin(rad)
    mezza = (abs(larghezza * dx) + abs(altezza * dy)) / 2.0
    cx, cy = larghezza / 2.0, altezza / 2.0
    return (cx - dx * mezza, cy - dy * mezza, cx + dx * mezza, cy + dy * mezza)


def sfondo_trasparente(valore: Any) -> bool:
    """Vero se lo sfondo ha parti trasparenti (serve la finestra traslucida)."""
    try:
        d = analizza_sfondo(valore)
    except (ErroreValore, ErroreTipo):
        return False
    if d["tipo"] == "colore":
        return alfa_colore(d["colore"]) < 255
    if d["tipo"] == "sfumatura":
        return any(alfa_colore(c) < 255 for c in d["colori"])
    if d["tipo"] == "motivo" and "motivo" in d:
        return d.get("sfondo", "") != "" and alfa_colore(d["sfondo"]) < 255
    return False


# ===========================================================================
# Menu
# ===========================================================================

def _modello(c: Any):
    """Accetta ModelloControllo o ControlloVivo (che ha ``.modello``)."""
    return getattr(c, "modello", c)


def _lista_controlli(controlli: Any) -> list:
    if hasattr(controlli, "controlli") and hasattr(controlli, "finestra"):
        controlli = controlli.controlli
    return [_modello(c) for c in controlli]


def menu_da_modelli(controlli: Any) -> list[dict]:
    """Albero dei menu da ``BarraMenu`` e ``VoceMenu``.

    ``controlli``: lista di ModelloControllo/ControlloVivo o una ModelloMaschera.
    Restituisce le voci di primo livello (in ordine: prima le BarraMenu nel loro
    ordine, poi le voci nell'ordine della maschera). Ogni nodo::

        {"nome": "VoceSalva", "testo": "Salva", "scorciatoia": "Ctrl+S",
         "spuntabile": False, "spuntata": False, "separatore": False, "figli": [...]}

    Una voce con testo ``"-"`` e' un separatore. Le ``VoceMenu`` con
    ``contenitore`` vuoto o sconosciuto stanno al primo livello; quelle che
    formano un giro (A dentro B dentro A) si ignorano.
    """
    lista = _lista_controlli(controlli)
    barre = [c.nome for c in lista if c.tipo == "BarraMenu"]
    voci = [c for c in lista if c.tipo == "VoceMenu"]
    nomi_voci = {c.nome for c in voci}
    figli: dict[str, list] = {}
    radici: list = []
    for v in voci:
        cont = v.contenitore or ""
        if cont in nomi_voci and cont != v.nome:
            figli.setdefault(cont, []).append(v)
        elif cont in barre:
            figli.setdefault(cont, []).append(v)
        else:
            radici.append(v)

    def nodo(v, visti: frozenset) -> dict:
        p = v.proprieta
        testo = str(p.get("testo", "") or "")
        d = {
            "nome": v.nome,
            "testo": testo,
            "scorciatoia": str(p.get("scorciatoia", "") or ""),
            "spuntabile": bool(p.get("spuntabile", False)),
            "spuntata": bool(p.get("spuntata", False)),
            "separatore": testo.strip() == "-",
            "figli": [],
        }
        visti = visti | {v.nome}
        for f in figli.get(v.nome, []):
            if f.nome not in visti:
                d["figli"].append(nodo(f, visti))
        return d

    albero: list[dict] = []
    for b in barre:
        for v in figli.get(b, []):
            albero.append(nodo(v, frozenset()))
    for v in radici:
        albero.append(nodo(v, frozenset()))
    return albero


def nomi_nel_menu(albero: list[dict]) -> list[str]:
    """Tutti i nomi delle voci di un albero (in profondita')."""
    nomi: list[str] = []
    for n in albero:
        nomi.append(n["nome"])
        nomi.extend(nomi_nel_menu(n["figli"]))
    return nomi


_TASTI_SCORCIATOIA = {
    "ctrl": "Ctrl", "control": "Ctrl", "controllo": "Ctrl",
    "maiusc": "Shift", "maiuscolo": "Shift", "shift": "Shift",
    "alt": "Alt", "altgr": "AltGr", "meta": "Meta", "cmd": "Meta", "win": "Meta",
    "canc": "Del", "elimina": "Del", "del": "Del",
    "invio": "Return", "enter": "Return", "return": "Return",
    "esc": "Esc", "escape": "Esc", "spazio": "Space", "space": "Space",
    "ins": "Ins", "inserisci": "Ins", "inizio": "Home", "home": "Home", "fine": "End", "end": "End",
    "pagsu": "PgUp", "pgup": "PgUp", "paggiù": "PgDown", "paggiu": "PgDown", "pgdown": "PgDown",
    "su": "Up", "giù": "Down", "giu": "Down", "sinistra": "Left", "destra": "Right",
    "tab": "Tab", "indietro": "Backspace", "backspace": "Backspace",
    "più": "+", "piu": "+", "meno": "-",
}


def scorciatoia_qt(testo: str) -> str:
    """Traduce una scorciatoia scritta in italiano nel formato di ``QKeySequence``.

    ``"Ctrl+Maiusc+s"`` -> ``"Ctrl+Shift+S"``; ``"Canc"`` -> ``"Del"``; ``""`` -> ``""``.
    """
    if not isinstance(testo, str):
        raise ErroreTipo("`scorciatoia` vuole un testo, per esempio \"Ctrl+S\".")
    t = testo.strip()
    if not t:
        return ""
    parti = [p.strip() for p in re.split(r"\s*\+\s*(?=.)", t)]
    risultato = []
    for p in parti:
        if not p:
            continue
        chiave = p.lower()
        if chiave in _TASTI_SCORCIATOIA:
            risultato.append(_TASTI_SCORCIATOIA[chiave])
        elif re.fullmatch(r"f\d{1,2}", chiave):
            risultato.append(chiave.upper())
        elif len(p) == 1:
            risultato.append(p.upper())
        else:
            risultato.append(p[:1].upper() + p[1:])
    return "+".join(risultato)


# ===========================================================================
# Ordine di creazione dei controlli
# ===========================================================================

def ordine_creazione(maschera: Any) -> list[str]:
    """Nomi dei controlli (finestra esclusa) in un ordine in cui ogni
    contenitore viene prima dei controlli che contiene.

    A parita', si rispetta l'ordine della maschera. Un contenitore
    sconosciuto vale come la finestra; un giro (A dentro B dentro A) viene
    spezzato senza perdere controlli.
    """
    controlli = [_modello(c) for c in maschera.controlli]
    per_nome = {c.nome: c for c in controlli}
    nome_finestra = maschera.finestra.nome
    ordine: list[str] = []
    fatti: set[str] = set()
    in_corso: set[str] = set()

    def visita(c) -> None:
        if c.nome in fatti or c.nome in in_corso:
            return
        in_corso.add(c.nome)
        cont = c.contenitore or ""
        if cont and cont != nome_finestra and cont != c.nome and cont in per_nome:
            visita(per_nome[cont])
        in_corso.discard(c.nome)
        if c.nome not in fatti:
            fatti.add(c.nome)
            ordine.append(c.nome)

    for c in controlli:
        visita(c)
    return ordine


# ===========================================================================
# Stile della finestra: cornice, barra del titolo, ombra, trascinamento
# ===========================================================================

ALTEZZA_BARRA = 32
MARGINE_OMBRA = 24
MARGINE_RIDIMENSIONAMENTO = 6


def forma_rettangolare(forma: Any) -> bool:
    """Vero per la forma ``"rettangolo"`` (testo o oggetto Forma)."""
    if forma in ("", None, "rettangolo"):
        return True
    return getattr(forma, "tipo", None) == "rettangolo"


def _forma_arrotondata(forma: Any, raggio: int) -> bool:
    if forma == "arrotondata" or getattr(forma, "tipo", None) == "arrotondata":
        return True
    return forma_rettangolare(forma) and raggio > 0


def stile_finestra(proprieta: dict) -> dict:
    """Decide come costruire la finestra dalle sue proprieta' (valori del modello).

    Risultato::

        {"senza_cornice": bool,   # niente cornice del sistema
         "barra": "sistema" | "personalizzata" | "nascosta",   # barra effettiva
         "pulsanti": "sistema" | "personalizzati" | "nascosti", # pulsanti effettivi
         "ombra": bool, "margine_ombra": int,
         "traslucida": bool,      # serve WA_TranslucentBackground
         "trascina": "sistema" | "barra" | "finestra" | <nome controllo>,
         "rettangolare": bool}

    Regole: una forma non rettangolare (o angoli arrotondati) non puo' avere
    la cornice del sistema: con ``barra_titolo = "sistema"`` diventa
    ``"personalizzata"`` per i rettangoli arrotondati e ``"nascosta"`` per le
    altre forme. L'ombra si disegna solo senza cornice (con la cornice c'e'
    gia' quella del sistema). Con la barra nascosta e ``trascinabile_da``
    vuoto la finestra si trascina da un punto qualsiasi dello sfondo, per non
    restare bloccati.
    """
    forma = proprieta.get("forma", "rettangolo")
    raggio = int(proprieta.get("raggio_angoli", 0) or 0)
    rettangolare = forma_rettangolare(forma) and raggio <= 0
    barra = proprieta.get("barra_titolo", "sistema") or "sistema"
    if barra == "sistema" and not rettangolare:
        barra = "personalizzata" if _forma_arrotondata(forma, raggio) else "nascosta"
    senza_cornice = barra != "sistema"
    pulsanti = proprieta.get("pulsanti_finestra", "sistema") or "sistema"
    if barra == "nascosta":
        pulsanti = "nascosti"
    elif barra == "sistema" and pulsanti == "personalizzati":
        pulsanti = "sistema"
    ombra = bool(proprieta.get("ombra", False)) and senza_cornice
    traslucida = senza_cornice and (ombra or sfondo_trasparente(proprieta.get("sfondo", "")))
    trascinabile = str(proprieta.get("trascinabile_da", "") or "")
    if trascinabile == "finestra":
        trascina = "finestra"
    elif trascinabile:
        trascina = trascinabile
    elif barra == "personalizzata":
        trascina = "barra"
    elif barra == "nascosta":
        trascina = "finestra"
    else:
        trascina = "sistema"
    return {
        "senza_cornice": senza_cornice,
        "barra": barra,
        "pulsanti": pulsanti,
        "ombra": ombra,
        "margine_ombra": MARGINE_OMBRA if ombra else 0,
        "traslucida": traslucida,
        "trascina": trascina,
        "rettangolare": rettangolare,
    }


def pulsanti_barra(larghezza: int, *, stile: str = "sistema", ridimensionabile: bool = True,
                   altezza: int = ALTEZZA_BARRA) -> dict[str, tuple[int, int, int, int]]:
    """Rettangoli ``(x, y, w, h)`` dei pulsanti disegnati nella barra personalizzata.

    ``stile``: ``"sistema"`` (riquadri larghi 46 px a destra, come Windows),
    ``"personalizzati"`` (tre cerchi colorati da 14 px a destra), ``"nascosti"``
    (nessuno). ``ingrandisci`` c'e' solo se la finestra e' ridimensionabile.
    Ordine da destra: chiudi, ingrandisci, riduci.
    """
    if stile == "nascosti":
        return {}
    nomi = ["chiudi"] + (["ingrandisci"] if ridimensionabile else []) + ["riduci"]
    pulsanti: dict[str, tuple[int, int, int, int]] = {}
    if stile == "personalizzati":
        diametro = 14
        spazio = 8
        y = (altezza - diametro) // 2
        x = larghezza - spazio - diametro
        for n in nomi:
            pulsanti[n] = (x, y, diametro, diametro)
            x -= diametro + spazio
        return pulsanti
    largo = 46
    x = larghezza - largo
    for n in nomi:
        pulsanti[n] = (x, 0, largo, altezza)
        x -= largo
    return pulsanti


def pulsante_in(pulsanti: dict[str, tuple[int, int, int, int]], x: float, y: float) -> str | None:
    """Nome del pulsante sotto il punto, o None (i cerchi hanno 3 px di tolleranza)."""
    for nome, (px, py, pw, ph) in pulsanti.items():
        margine = 3 if pw == ph and pw < 20 else 0
        if px - margine <= x < px + pw + margine and py - margine <= y < py + ph + margine:
            return nome
    return None


def bordo_ridimensionamento(x: float, y: float, larghezza: int, altezza: int,
                            margine: int = MARGINE_RIDIMENSIONAMENTO) -> str | None:
    """Bordo della finestra senza cornice sotto il punto, per ridimensionarla.

    Restituisce ``"N" "S" "E" "O" "NE" "NO" "SE" "SO"`` o None.
    """
    if x < 0 or y < 0 or x >= larghezza or y >= altezza:
        return None
    nord = y < margine
    sud = y >= altezza - margine
    ovest = x < margine
    est = x >= larghezza - margine
    verticale = "N" if nord else ("S" if sud else "")
    orizzontale = "O" if ovest else ("E" if est else "")
    risultato = verticale + orizzontale
    return risultato or None


# ===========================================================================
# Tasti
# ===========================================================================

_NOMI_TASTI = {
    "Key_Return": "Invio", "Key_Enter": "Invio", "Key_Escape": "Esc", "Key_Space": "Spazio",
    "Key_Tab": "Tab", "Key_Backtab": "Tab", "Key_Backspace": "Indietro", "Key_Delete": "Canc",
    "Key_Insert": "Ins", "Key_Home": "Inizio", "Key_End": "Fine", "Key_PageUp": "PagSu",
    "Key_PageDown": "PagGiù", "Key_Left": "Sinistra", "Key_Right": "Destra", "Key_Up": "Su",
    "Key_Down": "Giù", "Key_Shift": "Maiusc", "Key_Control": "Ctrl", "Key_Alt": "Alt",
    "Key_AltGr": "AltGr", "Key_Meta": "Meta", "Key_CapsLock": "BloccaMaiusc",
    "Key_NumLock": "BloccaNum", "Key_Print": "Stamp", "Key_Pause": "Pausa", "Key_Menu": "Menu",
}


def nome_tasto(nome_qt: str, testo: str = "") -> str:
    """Nome italiano del tasto per l'evento ``tasto``.

    ``nome_qt`` e' il nome del membro di ``Qt.Key`` (``"Key_A"``, ``"Key_Return"``);
    ``testo`` e' il testo prodotto dal tasto. Lettere e cifre -> ``"A"``, ``"7"``;
    tasti speciali -> ``"Invio"``, ``"Esc"``, ``"Su"``, ``"F5"``...
    """
    if nome_qt in _NOMI_TASTI:
        return _NOMI_TASTI[nome_qt]
    if nome_qt.startswith("Key_"):
        resto = nome_qt[4:]
        if len(resto) == 1:
            return resto.upper()
        if re.fullmatch(r"F\d{1,2}", resto):
            return resto
    if testo and testo.isprintable():
        return testo
    return nome_qt[4:] if nome_qt.startswith("Key_") else nome_qt


def dati_tasto(nome_qt: str, testo: str = "", modificatori: Iterable[str] = ()) -> dict:
    """Dati dell'evento ``tasto``: ``{"tasto", "testo", "ctrl", "alt", "maiusc"}``."""
    mod = set(modificatori)
    return {
        "tasto": nome_tasto(nome_qt, testo),
        "testo": testo if (testo and testo.isprintable()) else "",
        "ctrl": "ctrl" in mod,
        "alt": "alt" in mod,
        "maiusc": "maiusc" in mod,
    }


# ===========================================================================
# Avvisi sui gestori
# ===========================================================================

def _eventi_gioco() -> tuple[str, ...]:
    """Gli eventi delle dinamiche dei giochi (tocca, raccoglie, colpito...): validi per ogni controllo."""
    try:
        from .giochi.dinamiche import EVENTI_GIOCO
        return EVENTI_GIOCO
    except Exception:  # noqa: BLE001
        return ()


def avvisi_gestori(gestori: Iterable[tuple[str, str]], eventi_per_controllo: dict[str, Iterable[str]],
                   tipi: dict[str, str] | None = None, *, tollerante: bool = False) -> list[str]:
    """Avvisi (non errori) per i ``quando`` che non verranno mai chiamati.

    ``gestori``: coppie (controllo, evento) registrate dal codice;
    ``eventi_per_controllo``: nome del controllo -> eventi del suo tipo;
    ``tipi``: nome del controllo -> nome del tipo (solo per il messaggio);
    ``tollerante``: modalita' normale, in cui maiuscole diverse nei nomi del
    controllo e dell'evento (``pulsante1.Clic``) vanno bene lo stesso (il
    runtime collega comunque il gestore); con ``False`` (``--rigoroso``) i nomi
    devono essere esatti e l'avviso spiega che le maiuscole contano.
    """
    from ..tokens import SINONIMI_EVENTI

    tipi = tipi or {}
    avvisi: list[str] = []
    nomi = list(eventi_per_controllo)
    per_minuscolo: dict[str, list[str]] = {}
    for n in nomi:
        per_minuscolo.setdefault(n.lower(), []).append(n)
    for controllo, evento in gestori:
        intestazione = f"Il gestore `quando {controllo}.{evento}` non verrà mai chiamato"
        simili = per_minuscolo.get(str(controllo).lower(), [])
        vero = controllo if controllo in eventi_per_controllo else None
        if vero is None and tollerante and len(simili) == 1:
            vero = simili[0]
        if vero is None:
            if len(simili) == 1 and not tollerante:
                avvisi.append(f"{intestazione}: in modalità rigorosa le maiuscole contano, il controllo "
                              f"si chiama `{simili[0]}` (non `{controllo}`).")
                continue
            vicini = difflib.get_close_matches(controllo, nomi, n=1, cutoff=0.6)
            testo = f"{intestazione}: il controllo `{controllo}` non esiste."
            if vicini:
                testo += f" Forse intendevi `{vicini[0]}`?"
            avvisi.append(testo)
            continue
        eventi = list(eventi_per_controllo[vero])
        if evento in eventi or evento in _eventi_gioco():
            continue
        minuscolo = str(evento).lower()
        normale = SINONIMI_EVENTI.get(minuscolo, minuscolo)
        uguali = [e for e in eventi if e.lower() == normale]
        if tollerante and uguali:
            continue
        tipo = tipi.get(vero)
        chi = f"`{vero}` ({tipo})" if tipo else f"`{vero}`"
        if uguali:
            avvisi.append(f"{intestazione}: in modalità rigorosa le maiuscole contano, l'evento di {chi} "
                          f"si chiama `{uguali[0]}` (non `{evento}`).")
            continue
        testo = f"{intestazione}: {chi} non ha l'evento `{evento}`."
        vicini = difflib.get_close_matches(evento, eventi, n=1, cutoff=0.6)
        if vicini:
            testo += f" Forse intendevi `{vicini[0]}`?"
        elif eventi:
            testo += " Eventi disponibili: " + ", ".join(f"`{e}`" for e in eventi) + "."
        else:
            testo += " Questo controllo non ha eventi."
        avvisi.append(testo)
    return avvisi


# ===========================================================================
# Ancoraggi annidati
# ===========================================================================

def _calcola_rettangolo_ripiego(rettangolo, ancoraggio, dimensione_originale, dimensione_nuova):
    """Stesse regole di ``ancoraggi.calcola_rettangolo`` (Windows Forms)."""
    x, y, w, h = rettangolo
    dw = dimensione_nuova[0] - dimensione_originale[0]
    dh = dimensione_nuova[1] - dimensione_originale[1]
    anc = set(ancoraggio)
    if "sinistra" in anc and "destra" in anc:
        w += dw
    elif "destra" in anc:
        x += dw
    elif "sinistra" not in anc:
        x += dw / 2
    if "alto" in anc and "basso" in anc:
        h += dh
    elif "basso" in anc:
        y += dh
    elif "alto" not in anc:
        y += dh / 2
    return (int(round(x)), int(round(y)), max(0, int(round(w))), max(0, int(round(h))))


def _calcola_rettangolo(rettangolo, ancoraggio, dimensione_originale, dimensione_nuova):
    try:
        from .ancoraggi import calcola_rettangolo
    except (ImportError, AttributeError):
        calcola_rettangolo = None
    if calcola_rettangolo is not None:
        try:
            r = calcola_rettangolo(tuple(rettangolo), list(ancoraggio), tuple(dimensione_originale),
                                   tuple(dimensione_nuova))
            return tuple(int(v) for v in r)
        except NotImplementedError:  # pragma: no cover
            pass
    return _calcola_rettangolo_ripiego(rettangolo, ancoraggio, dimensione_originale, dimensione_nuova)


class AncoraggiFinestra:
    """Ancoraggi di tutti i controlli di una finestra, anche dentro i contenitori.

    Ogni controllo e' registrato con il suo rettangolo (relativo al
    contenitore), l'ancoraggio e la dimensione del contenitore in quel momento
    (la *base*). Il nuovo rettangolo si calcola sempre dal rettangolo
    registrato e dalla base, quindi gli errori non si accumulano. I
    contenitori si calcolano prima dei figli, e i figli usano la nuova
    dimensione del loro contenitore.
    """

    def __init__(self, dimensione: tuple[int, int]) -> None:
        self.dimensione = (int(dimensione[0]), int(dimensione[1]))
        self._voci: dict[str, tuple[str, tuple[int, int, int, int], list[str], tuple[int, int]]] = {}
        self._correnti: dict[str, tuple[int, int, int, int]] = {}

    def _dimensione_contenitore(self, contenitore: str) -> tuple[int, int]:
        if contenitore and contenitore in self._correnti:
            r = self._correnti[contenitore]
            return (r[2], r[3])
        return self.dimensione

    def registra(self, nome: str, contenitore: str, rettangolo: tuple[int, int, int, int],
                 ancoraggio: Iterable[str], base: tuple[int, int] | None = None) -> None:
        """Registra (o registra di nuovo, dopo uno spostamento da codice) un controllo.

        ``contenitore`` "" = la finestra. ``base`` predefinita: dimensione
        attuale del contenitore.
        """
        if contenitore not in self._voci or contenitore == nome:
            contenitore = ""
        rett = tuple(int(v) for v in rettangolo)
        if base is None:
            base = self._dimensione_contenitore(contenitore)
        self._voci[nome] = (contenitore, rett, list(ancoraggio), (int(base[0]), int(base[1])))
        self._correnti[nome] = rett

    def rimuovi(self, nome: str) -> None:
        self._voci.pop(nome, None)
        self._correnti.pop(nome, None)

    def __contains__(self, nome: str) -> bool:
        return nome in self._voci

    def rettangolo(self, nome: str) -> tuple[int, int, int, int] | None:
        """Rettangolo attuale di un controllo registrato."""
        return self._correnti.get(nome)

    def _ordine(self, radici: Iterable[str] | None = None) -> list[str]:
        figli: dict[str, list[str]] = {}
        for nome, (cont, *_resto) in self._voci.items():
            figli.setdefault(cont, []).append(nome)
        ordine: list[str] = []
        visti: set[str] = set()

        def scendi(padre: str) -> None:
            for f in figli.get(padre, []):
                if f not in visti:
                    visti.add(f)
                    ordine.append(f)
                    scendi(f)

        if radici is None:
            scendi("")
            for nome in self._voci:  # eventuali giri: non si perde nessuno
                if nome not in visti:
                    visti.add(nome)
                    ordine.append(nome)
                    scendi(nome)
        else:
            for r in radici:
                visti.add(r)
                scendi(r)
        return ordine

    def _calcola(self, nome: str) -> tuple[int, int, int, int]:
        cont, rett, anc, base = self._voci[nome]
        nuova = self._dimensione_contenitore(cont)
        r = _calcola_rettangolo(rett, anc, base, nuova)
        self._correnti[nome] = r
        return r

    def aggiorna(self, dimensione_nuova: tuple[int, int]) -> dict[str, tuple[int, int, int, int]]:
        """Nuova dimensione della finestra -> nuovi rettangoli di tutti i controlli registrati."""
        self.dimensione = (int(dimensione_nuova[0]), int(dimensione_nuova[1]))
        return {nome: self._calcola(nome) for nome in self._ordine()}

    def sposta(self, nome: str, rettangolo: tuple[int, int, int, int]) -> dict[str, tuple[int, int, int, int]]:
        """Il codice ha spostato/ridimensionato ``nome``: lo registra di nuovo e
        restituisce i nuovi rettangoli dei controlli che contiene (non di ``nome``)."""
        if nome not in self._voci:
            return {}
        cont, _vecchio, anc, _base = self._voci[nome]
        self.registra(nome, cont, rettangolo, anc)
        return {figlio: self._calcola(figlio) for figlio in self._ordine([nome])}

    def cambia_ancoraggio(self, nome: str, ancoraggio: Iterable[str]) -> None:
        """Nuovo ancoraggio da codice: la base diventa la situazione attuale."""
        if nome in self._voci:
            cont = self._voci[nome][0]
            self.registra(nome, cont, self._correnti[nome], ancoraggio)


# ===========================================================================
# Stili pronti dei controlli (proprieta' ``stile``)
# ===========================================================================
# ``stile`` di Pulsante, PulsanteImmagine ed Etichetta: colori, bordo
# arrotondato e stati "mouse sopra" / "premuto" coerenti col tema della
# finestra (``tema_controlli``). "normale" non cambia niente: vale il tema.

#: Stili ammessi (nome canonico, nell'ordine del pannello Proprieta').
STILI_CONTROLLI = ("normale", "principale", "secondario", "pericolo", "successo", "contorno", "testo")
STILE_PREDEFINITO = "normale"

#: Altri nomi accettati dal codice (``Pulsante1.stile = "primario"``).
SINONIMI_STILI = {
    "normale": "normale", "predefinito": "normale", "nessuno": "normale", "standard": "normale", "base": "normale",
    "principale": "principale", "primario": "principale", "accento": "principale", "evidenziato": "principale",
    "importante": "principale",
    "secondario": "secondario", "neutro": "secondario", "grigio": "secondario", "tenue": "secondario",
    "pericolo": "pericolo", "pericoloso": "pericolo", "errore": "pericolo", "elimina": "pericolo",
    "distruttivo": "pericolo", "avviso": "pericolo",
    "successo": "successo", "conferma": "successo", "ok": "successo", "riuscito": "successo",
    "positivo": "successo",
    "contorno": "contorno", "bordo": "contorno", "bordato": "contorno", "vuoto": "contorno",
    "delineato": "contorno",
    "testo": "testo", "solo_testo": "testo", "collegamento": "testo", "link": "testo",
    "trasparente": "testo", "piatto": "testo",
}

#: Raggio degli angoli (pixel) per tema: segue il QSS del tema.
_RAGGI_TEMI = {"moderno": 6, "classico": 2, "piatto": 4, "futuristico": 3}

#: Colori "di significato" (chiari, scuri): testo bianco con contrasto WCAG AA.
_PERICOLO = ("#B42318", "#D92D20")
_SUCCESSO = ("#177245", "#1A7F4B")


def normalizza_stile(valore: Any) -> str:
    """Nome canonico di uno stile (``"Primario"`` -> ``"principale"``); ErroreValore se sconosciuto."""
    if valore is None:
        return STILE_PREDEFINITO
    if not isinstance(valore, str):
        raise ErroreTipo("Lo stile di un controllo si scrive come testo, per esempio \"principale\".")
    chiave = valore.strip().casefold().replace(" ", "_").replace("-", "_").replace("'", "")
    for a, b in (("à", "a"), ("è", "e"), ("é", "e"), ("ì", "i"), ("ò", "o"), ("ù", "u")):
        chiave = chiave.replace(a, b)
    if chiave == "":
        return STILE_PREDEFINITO
    if chiave in SINONIMI_STILI:
        return SINONIMI_STILI[chiave]
    vicini = difflib.get_close_matches(chiave, list(SINONIMI_STILI), n=1, cutoff=0.6)
    suggerimento = (f"Forse intendevi \"{SINONIMI_STILI[vicini[0]]}\"? " if vicini else "") + \
        "Stili: " + ", ".join(f'"{s}"' for s in STILI_CONTROLLI) + "."
    raise ErroreValore(f"Lo stile `{valore}` non esiste.", suggerimento=suggerimento)


def mescola(colore1: str, colore2: str, quanto: float) -> str:
    """Colore tra ``colore1`` (0) e ``colore2`` (1), ``#RRGGBB``."""
    r1, g1, b1 = _rgb(colore1)
    r2, g2, b2 = _rgb(colore2)
    q = max(0.0, min(1.0, float(quanto)))
    return "#" + "".join(f"{int(round(a + (b - a) * q)):02X}" for a, b in ((r1, r2), (g1, g2), (b1, b2)))


def _trasparente(colore: str, alfa: int) -> str:
    """``#RRGGBB`` + alfa (0-255) -> ``#RRGGBBAA``."""
    r, g, b = _rgb(colore)
    return f"#{r:02X}{g:02X}{b:02X}{max(0, min(255, int(alfa))):02X}"


def colori_stile(stile: str, tema: str = TEMA_PREDEFINITO) -> dict[str, Any] | None:
    """Colori di uno stile nel tema: None per "normale" (vale il foglio del tema).

    Chiavi: ``sfondo``, ``testo``, ``bordo``, ``sfondo_sopra``, ``bordo_sopra``,
    ``sfondo_premuto``, ``testo_premuto``, ``sfondo_disabilitato``,
    ``testo_disabilitato``, ``fuoco`` (bordo col fuoco), ``raggio`` (pixel),
    ``pieno`` (vero se il testo sta su un fondo colorato).
    """
    stile = normalizza_stile(stile)
    if stile == STILE_PREDEFINITO:
        return None
    tema = _tema_valido(tema or TEMA_PREDEFINITO)
    c = _COLORI_TEMI[tema]
    scuro = tema in TEMI_SCURI
    sfondo_finestra = c["sfondo"]
    luce, ombra = ("#FFFFFF", "#000000")
    raggio = _RAGGI_TEMI.get(tema, 4)
    accento_testo = c.get("accento_chiaro", c["accento"]) if scuro else c["accento"]

    def pieno(base: str, testo: str) -> dict[str, Any]:
        # sopra: un poco piu' chiaro sui temi scuri, un poco piu' scuro su quelli chiari
        sopra = mescola(base, luce, 0.12) if scuro else mescola(base, ombra, 0.12)
        premuto = mescola(base, ombra, 0.22)
        return {"sfondo": base, "testo": testo, "bordo": base, "sfondo_sopra": sopra, "bordo_sopra": sopra,
                "sfondo_premuto": premuto, "testo_premuto": testo,
                "sfondo_disabilitato": mescola(base, sfondo_finestra, 0.55),
                "testo_disabilitato": mescola(testo, sfondo_finestra, 0.35),
                "fuoco": mescola(base, luce if scuro else ombra, 0.35), "raggio": raggio, "pieno": True}

    if stile == "principale":
        return pieno(c["accento"], c["testo_accento"])
    if stile == "pericolo":
        return pieno(_PERICOLO[1] if scuro else _PERICOLO[0], "#FFFFFF")
    if stile == "successo":
        return pieno(_SUCCESSO[1] if scuro else _SUCCESSO[0], "#FFFFFF")
    if stile == "secondario":
        base = mescola(sfondo_finestra, c["testo"], 0.12 if scuro else 0.08)
        return {"sfondo": base, "testo": c["testo"], "bordo": mescola(base, c["testo"], 0.15),
                "sfondo_sopra": mescola(sfondo_finestra, c["testo"], 0.18 if scuro else 0.13),
                "bordo_sopra": mescola(base, c["testo"], 0.3),
                "sfondo_premuto": mescola(sfondo_finestra, c["testo"], 0.25 if scuro else 0.2),
                "testo_premuto": c["testo"], "sfondo_disabilitato": base,
                "testo_disabilitato": c["testo_disabilitato"], "fuoco": c["accento"], "raggio": raggio,
                "pieno": False}
    if stile == "contorno":
        return {"sfondo": "transparent", "testo": accento_testo, "bordo": accento_testo,
                "sfondo_sopra": _trasparente(c["accento"], 0x24 if scuro else 0x14), "bordo_sopra": accento_testo,
                "sfondo_premuto": _trasparente(c["accento"], 0x40 if scuro else 0x2A),
                "testo_premuto": accento_testo, "sfondo_disabilitato": "transparent",
                "testo_disabilitato": c["testo_disabilitato"], "fuoco": accento_testo, "raggio": raggio,
                "pieno": False}
    # "testo": niente fondo ne' bordo, solo la scritta nel colore d'accento
    return {"sfondo": "transparent", "testo": accento_testo, "bordo": "transparent",
            "sfondo_sopra": _trasparente(c["accento"], 0x1F if scuro else 0x12), "bordo_sopra": "transparent",
            "sfondo_premuto": _trasparente(c["accento"], 0x38 if scuro else 0x24),
            "testo_premuto": accento_testo, "sfondo_disabilitato": "transparent",
            "testo_disabilitato": c["testo_disabilitato"], "fuoco": _trasparente(c["accento"], 0x80),
            "raggio": raggio, "pieno": False}


def foglio_stile_controllo(stile: str, tema: str = TEMA_PREDEFINITO, nome: str = "leo", *,
                           colore_testo: str = "", colore_sfondo: str = "") -> str:
    """Foglio di stile QSS di un controllo con lo ``stile`` dato ("" per "normale").

    Le regole usano il selettore ``#nome`` (solo quel widget) e hanno gli stati
    ``:hover``, ``:pressed``, ``:disabled`` e ``:focus``. ``colore_testo`` e
    ``colore_sfondo`` del controllo, se indicati, vincono sui colori dello stile.
    """
    colori = colori_stile(stile, tema)
    if colori is None:
        return ""
    k = dict(colori)
    if colore_testo:
        k["testo"] = k["testo_premuto"] = colore_testo
    if colore_sfondo:
        base = _normalizza_colore(colore_sfondo)
        k["sfondo"] = base
        if len(base) == 7:  # colore pieno: stati calcolati da quello
            k["sfondo_sopra"] = mescola(base, "#000000", 0.12)
            k["sfondo_premuto"] = mescola(base, "#000000", 0.22)
            if k["pieno"]:
                k["bordo"] = k["bordo_sopra"] = base
    q = {chiave: _qss_colore(v) if isinstance(v, str) else v for chiave, v in k.items()}
    n = nome or "leo"
    return (
        f"#{n} {{ background-color: {q['sfondo']}; color: {q['testo']}; border: 1px solid {q['bordo']}; "
        f"border-radius: {q['raggio']}px; padding: 4px 12px; }}\n"
        f"#{n}:hover {{ background-color: {q['sfondo_sopra']}; border-color: {q['bordo_sopra']}; }}\n"
        f"#{n}:pressed {{ background-color: {q['sfondo_premuto']}; color: {q['testo_premuto']}; }}\n"
        f"#{n}:focus {{ border: 1px solid {q['fuoco']}; }}\n"
        f"#{n}:disabled {{ background-color: {q['sfondo_disabilitato']}; color: {q['testo_disabilitato']}; "
        f"border-color: {q['sfondo_disabilitato']}; }}\n"
    )


def colori_partenza(tipo_controllo: str, tema: str = TEMA_PREDEFINITO) -> dict[str, str]:
    """Colori "attuali" di un controllo con i colori predefiniti (``""``), per le animazioni.

    ``anima(Pulsante1, "colore_sfondo", "rosso")`` parte dal colore del
    pulsante nel tema; per i controlli senza fondo proprio (``colore_sfondo``
    assente qui) si parte dal colore d'arrivo trasparente.
    """
    try:
        c = _COLORI_TEMI[_tema_valido(tema or TEMA_PREDEFINITO)]
    except ErroreValore:
        c = _COLORI_TEMI[TEMA_PREDEFINITO]
    colori = {"colore_testo": c["testo"], "sfondo": c["sfondo"]}
    if tipo_controllo in ("Pulsante", "PulsanteImmagine", "SelettoreColore"):
        colori["colore_sfondo"] = c["pulsante"]
        if tipo_controllo != "SelettoreColore" and c is _COLORI_TEMI["piatto"]:
            colori["colore_testo"] = c["testo_accento"]
    elif tipo_controllo in ("CasellaTesto", "CasellaPassword", "AreaTesto", "CasellaNumero", "Elenco",
                            "MenuATendina", "Tabella", "Albero", "SelettoreData"):
        colori["colore_sfondo"] = c["campo"]
    return colori
