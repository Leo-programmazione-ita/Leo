"""Modello puro (senza Qt) di maschere e controlli - CONTRATTO CONDIVISO.

* :class:`ModelloControllo` / :class:`ModelloMaschera`: dati di una ``.maschera``
  (usati da Leo Studio per progettare e dal runtime per costruire la finestra).
* :class:`ControlloVivo`: il controllo durante l'esecuzione, visto dal codice
  Leo (implementa ``OggettoControllo``). Valida i valori con i metadati del
  catalogo e avvisa gli ``osservatori`` (lo strato Qt) a ogni modifica.

Flusso durante l'esecuzione:
    codice Leo  --scrivi(p, v)-->  ControlloVivo  --osservatore(c, p, v)-->  widget Qt
    widget Qt (l'utente scrive)  --aggiorna_da_interfaccia(p, v)-->  ControlloVivo (senza avvisare)
"""

from __future__ import annotations

import copy
from dataclasses import dataclass, field
from typing import Any, Callable

from .. import permessi as _permessi
from ..errori import ErroreNome, ErroreValore
from ..valori import OggettoControllo, Richiamabile, FunzioneNativa, MetodoLegato


@dataclass
class ModelloControllo:
    """Un controllo in una maschera. ``proprieta`` NON contiene ``nome`` e ``tipo``.

    ``contenitore``: nome del controllo che lo contiene ("" = la finestra).
    ``scheda``: indice della scheda se il contenitore e' un controllo ``Schede``.
    """

    tipo: str
    nome: str
    proprieta: dict[str, Any] = field(default_factory=dict)
    contenitore: str = ""
    scheda: int | None = None

    def get(self, nome: str, predefinito: Any = None) -> Any:
        return self.proprieta.get(nome, predefinito)

    @property
    def rettangolo(self) -> tuple[int, int, int, int]:
        """(sinistra, alto, larghezza, altezza) in pixel."""
        p = self.proprieta
        return (int(p.get("sinistra", 0)), int(p.get("alto", 0)),
                int(p.get("larghezza", 0)), int(p.get("altezza", 0)))

    def imposta_rettangolo(self, sinistra: int, alto: int, larghezza: int, altezza: int) -> None:
        self.proprieta.update(sinistra=int(sinistra), alto=int(alto),
                              larghezza=max(0, int(larghezza)), altezza=max(0, int(altezza)))

    def copia(self) -> "ModelloControllo":
        return copy.deepcopy(self)


@dataclass
class ModelloMaschera:
    """Una finestra progettata: la finestra stessa + i controlli, in ordine
    (l'ordine e' quello di disegno e di tabulazione)."""

    finestra: ModelloControllo
    controlli: list[ModelloControllo] = field(default_factory=list)
    versione: int = 1

    @classmethod
    def nuova(cls, nome: str = "Finestra1", *, larghezza: int = 640, altezza: int = 480,
              titolo: str | None = None) -> "ModelloMaschera":
        f = ModelloControllo("Finestra", nome, {"testo": titolo if titolo is not None else nome,
                                                "larghezza": larghezza, "altezza": altezza})
        return cls(f, [])

    @property
    def nome(self) -> str:
        return self.finestra.nome

    def tutti(self) -> list[ModelloControllo]:
        return [self.finestra, *self.controlli]

    def nomi(self) -> list[str]:
        return [c.nome for c in self.tutti()]

    def trova(self, nome: str) -> ModelloControllo | None:
        for c in self.tutti():
            if c.nome == nome:
                return c
        return None

    def figli_di(self, nome_contenitore: str) -> list[ModelloControllo]:
        """Controlli direttamente dentro ``nome_contenitore`` ("" o nome finestra = la finestra)."""
        chiave = "" if nome_contenitore == self.finestra.nome else nome_contenitore
        return [c for c in self.controlli if c.contenitore == chiave]

    def nuovo_nome(self, tipo: str, prefisso: str = "") -> str:
        """Primo nome libero ``<Prefisso><n>`` (Pulsante1, Pulsante2, ...)."""
        base = prefisso or tipo
        esistenti = set(self.nomi())
        n = 1
        while f"{base}{n}" in esistenti:
            n += 1
        return f"{base}{n}"

    def aggiungi(self, controllo: ModelloControllo, posizione: int | None = None) -> None:
        if self.trova(controllo.nome) is not None:
            raise ErroreValore(f"Esiste già un controllo chiamato `{controllo.nome}`.")
        if posizione is None:
            self.controlli.append(controllo)
        else:
            self.controlli.insert(posizione, controllo)

    def rimuovi(self, nome: str) -> list[ModelloControllo]:
        """Rimuove il controllo e (ricorsivamente) quelli che contiene; restituisce i rimossi."""
        rimossi: list[ModelloControllo] = []
        da_togliere = {nome}
        cambiato = True
        while cambiato:
            cambiato = False
            for c in self.controlli:
                if c.contenitore in da_togliere and c.nome not in da_togliere:
                    da_togliere.add(c.nome)
                    cambiato = True
        for c in list(self.controlli):
            if c.nome in da_togliere:
                self.controlli.remove(c)
                rimossi.append(c)
        return rimossi

    def rinomina(self, vecchio: str, nuovo: str) -> None:
        if self.trova(nuovo) is not None:
            raise ErroreValore(f"Esiste già un controllo chiamato `{nuovo}`.")
        c = self.trova(vecchio)
        if c is None:
            raise ErroreNome(f"Il controllo `{vecchio}` non esiste.", nome=vecchio)
        c.nome = nuovo
        for figlio in self.controlli:
            if figlio.contenitore == vecchio:
                figlio.contenitore = nuovo


# ===========================================================================
# Controllo durante l'esecuzione
# ===========================================================================

Osservatore = Callable[["ControlloVivo", str, Any], None]


class ControlloVivo(OggettoControllo):
    """Controllo in esecuzione, visto dal codice Leo.

    ``modello``: il ModelloControllo (valori correnti in ``modello.proprieta``).
    I valori mancanti vengono dai predefiniti del catalogo.
    """

    def __init__(self, modello: ModelloControllo, tipo=None) -> None:
        from .metadati import tipo_controllo

        self.modello = modello
        self.tipo = tipo if tipo is not None else tipo_controllo(modello.tipo)
        self.nome = modello.nome
        self.tipo_controllo = modello.tipo
        self.osservatori: list[Osservatore] = []
        valori = self.tipo.valori_predefiniti()
        valori.update(modello.proprieta)
        modello.proprieta = valori

    # --- OggettoControllo -------------------------------------------------
    def leggi(self, proprieta: str) -> Any:
        proprieta = self.tipo.risolvi_nome(proprieta)
        if proprieta == "nome":  # anche `Nome`: il nome vive fuori da `modello.proprieta`
            return self.nome
        if proprieta == "tipo" or (isinstance(proprieta, str) and proprieta.lower() == "tipo"
                                   and proprieta not in self.tipo.proprieta):
            return self.tipo_controllo
        self.tipo.proprieta_o_errore(proprieta)
        return self.modello.proprieta.get(proprieta)

    def scrivi(self, proprieta: str, valore: Any) -> None:
        proprieta = self.tipo.risolvi_nome(proprieta)
        meta = self.tipo.proprieta_o_errore(proprieta)
        if meta.sola_lettura or meta.solo_progettazione:
            raise ErroreValore(f"La proprietà `{proprieta}` di `{self.nome}` non si può cambiare dal codice.")
        valore = meta.converti(valore)
        self.modello.proprieta[proprieta] = valore
        self.avvisa(proprieta, valore)

    def metodo(self, nome: str) -> Richiamabile | None:
        vero = self.tipo.risolvi_metodo(nome)  # `Elenco1.Aggiungi(...)` va bene lo stesso
        if vero is None:
            return None
        nativa = FunzioneNativa(vero, self.tipo.metodi[vero])
        if _permessi.politica_attiva() is not None:     # Fotocamera1.scatta(), RichiestaWeb1.invia()...
            nativa = _permessi.proteggi_controllo(self.tipo_controllo, vero, self, nativa)
        return MetodoLegato(self, nativa)

    def elenco_proprieta(self) -> list[str]:
        return sorted(self.tipo.proprieta)

    # --- per lo strato Qt ---------------------------------------------------
    def aggiorna_da_interfaccia(self, proprieta: str, valore: Any) -> None:
        """L'utente ha cambiato il widget (es. ha scritto): aggiorna senza avvisare."""
        self.modello.proprieta[proprieta] = valore

    def avvisa(self, proprieta: str, valore: Any) -> None:
        for o in list(self.osservatori):
            o(self, proprieta, valore)
