"""Modelli pronti per le app nuove fatte sul telefono ("Nuova app con finestre").

Ogni modello e' un'app completa e funzionante, pensata per il telefono (360x640): la finestra con
gli oggetti gia' sistemati e il codice degli eventi gia' scritto, da provare subito e poi cambiare.
E' il modo piu' veloce per chi non ha mai programmato: si parte da qualcosa che funziona e si
guarda come e' fatto.
"""

from __future__ import annotations

import os
from typing import Any, Callable

L, A = 360, 640          # misura della finestra per il telefono


def _c(nome: str, tipo: str, x: int, y: int, w: int, h: int, **p: Any) -> dict:
    return {"nome": nome, "tipo": tipo, "contenitore": "", "sinistra": x, "alto": y, "larghezza": w, "altezza": h,
            **p}


_LARGO = ["alto", "sinistra", "destra"]


def _titolo(nome: str) -> dict:
    return _c("Titolo", "Etichetta", 20, 28, 320, 40, testo=nome, dimensione_carattere=20, grassetto=True,
              ancoraggio=_LARGO)


# ---------------------------------------------------------------------------------------------------
def _saluto(nome: str) -> tuple[list[dict], str]:
    controlli = [
        _c("Titolo", "Etichetta", 20, 28, 320, 40, testo=nome, dimensione_carattere=20),
        _c("Etichetta1", "Etichetta", 20, 84, 320, 24, testo="Come ti chiami?"),
        _c("CasellaNome", "CasellaTesto", 20, 114, 320, 40, segnaposto="Scrivi qui", ancoraggio=_LARGO),
        _c("PulsanteSaluta", "Pulsante", 20, 170, 320, 44, testo="Saluta", ancoraggio=_LARGO),
    ]
    codice = ('quando PulsanteSaluta.clic fai\n'
              '    se vuota(CasellaNome.testo) allora\n'
              '        messaggio("Scrivi prima il tuo nome")\n'
              '    altrimenti\n'
              '        Etichetta1.testo = "Ciao, {CasellaNome.testo}!"\n'
              '    fine\n'
              'fine\n')
    return controlli, codice


def _contatore(nome: str) -> tuple[list[dict], str]:
    controlli = [
        _titolo(nome),
        _c("Numero", "Etichetta", 20, 100, 320, 120, testo="0", dimensione_carattere=64, grassetto=True,
           allineamento="centro", ancoraggio=_LARGO),
        _c("PulsanteMeno", "Pulsante", 20, 250, 150, 64, testo="−1", dimensione_carattere=20, raggio_angoli=32,
           stile="secondario"),
        _c("PulsantePiu", "Pulsante", 190, 250, 150, 64, testo="+1", dimensione_carattere=20, raggio_angoli=32,
           ombra=True),
        _c("PulsanteAzzera", "Pulsante", 20, 334, 320, 44, testo="Azzera", stile="contorno", ancoraggio=_LARGO),
    ]
    codice = ('# Un contatore: tocca +1 e -1. `conteggio` e\' una variabile che ricorda il numero.\n'
              'variabile conteggio = 0\n\n'
              'funzione mostra()\n'
              '    Numero.testo = "{conteggio}"\n'
              'fine\n\n'
              'quando PulsantePiu.clic fai\n'
              '    conteggio = conteggio + 1\n'
              '    mostra()\n'
              'fine\n\n'
              'quando PulsanteMeno.clic fai\n'
              '    conteggio = conteggio - 1\n'
              '    mostra()\n'
              'fine\n\n'
              'quando PulsanteAzzera.clic fai\n'
              '    conteggio = 0\n'
              '    mostra()\n'
              'fine\n')
    return controlli, codice


def _lista(nome: str) -> tuple[list[dict], str]:
    controlli = [
        _titolo(nome),
        _c("CasellaCosa", "CasellaTesto", 20, 84, 236, 44, segnaposto="Cosa devi comprare?", ancoraggio=_LARGO),
        _c("PulsanteAggiungi", "Pulsante", 266, 84, 74, 44, testo="+", dimensione_carattere=20,
           ancoraggio=["alto", "destra"]),
        _c("ElencoSpesa", "Elenco", 20, 140, 320, 372, ancoraggio=["alto", "sinistra", "destra", "basso"]),
        _c("PulsanteTogli", "Pulsante", 20, 524, 155, 44, testo="Togli", stile="pericolo",
           ancoraggio=["basso", "sinistra"]),
        _c("PulsanteSvuota", "Pulsante", 185, 524, 155, 44, testo="Svuota", stile="contorno",
           ancoraggio=["basso", "destra"]),
        _c("Conteggio", "Etichetta", 20, 580, 320, 24, testo="La lista è vuota", allineamento="centro",
           ancoraggio=["basso", "sinistra", "destra"]),
    ]
    codice = ('# Lista della spesa: scrivi, tocca + (o Invio), tocca una voce per selezionarla.\n\n'
              'funzione conta()\n'
              '    variabile n = lunghezza(ElencoSpesa.elementi)\n'
              '    se n == 0 allora\n'
              '        Conteggio.testo = "La lista è vuota"\n'
              '    altrimenti\n'
              '        Conteggio.testo = "Cose da comprare: {n}"\n'
              '    fine\n'
              'fine\n\n'
              'funzione aggiungi_voce()\n'
              '    se non vuota(CasellaCosa.testo) allora\n'
              '        ElencoSpesa.aggiungi(CasellaCosa.testo)\n'
              '        CasellaCosa.testo = ""\n'
              '        conta()\n'
              '    fine\n'
              'fine\n\n'
              'quando PulsanteAggiungi.clic fai\n'
              '    aggiungi_voce()\n'
              'fine\n\n'
              'quando CasellaCosa.invio fai\n'
              '    aggiungi_voce()\n'
              'fine\n\n'
              'quando PulsanteTogli.clic fai\n'
              '    se ElencoSpesa.indice_selezionato >= 0 allora\n'
              '        ElencoSpesa.rimuovi(ElencoSpesa.indice_selezionato)\n'
              '        conta()\n'
              '    altrimenti\n'
              '        messaggio("Tocca prima una voce della lista")\n'
              '    fine\n'
              'fine\n\n'
              'quando PulsanteSvuota.clic fai\n'
              '    ElencoSpesa.svuota()\n'
              '    conta()\n'
              'fine\n')
    return controlli, codice


def _timer(nome: str) -> tuple[list[dict], str]:
    controlli = [
        _titolo(nome),
        _c("Conto", "ContoAllaRovescia", 20, 90, 320, 110, secondi=300, rimanenti=300, ancoraggio=_LARGO),
        _c("EtichettaMinuti", "Etichetta", 20, 218, 180, 44, testo="Minuti:"),
        _c("Minuti", "CasellaNumero", 210, 218, 130, 44, valore=5, minimo=1, massimo=180,
           ancoraggio=["alto", "destra"]),
        _c("PulsanteAvvia", "Pulsante", 20, 280, 100, 48, testo="Avvia", raggio_angoli=24),
        _c("PulsantePausa", "Pulsante", 130, 280, 100, 48, testo="Pausa", stile="secondario", raggio_angoli=24),
        _c("PulsanteAzzera", "Pulsante", 240, 280, 100, 48, testo="Azzera", stile="contorno", raggio_angoli=24),
        _c("Stato", "Etichetta", 20, 348, 320, 30, testo="Pronto", allineamento="centro", ancoraggio=_LARGO),
        _invisibile("Vibrazione1", "Vibrazione"),
    ]
    codice = ('# Timer da cucina: scegli i minuti, poi Avvia. Alla fine il telefono vibra.\n\n'
              'quando Minuti.cambio fai\n'
              '    Conto.secondi = Minuti.valore * 60\n'
              '    Conto.azzera()\n'
              'fine\n\n'
              'quando PulsanteAvvia.clic fai\n'
              '    Conto.avvia()\n'
              '    Stato.testo = "In corso..."\n'
              'fine\n\n'
              'quando PulsantePausa.clic fai\n'
              '    Conto.ferma()\n'
              '    Stato.testo = "In pausa"\n'
              'fine\n\n'
              'quando PulsanteAzzera.clic fai\n'
              '    Conto.azzera()\n'
              '    Stato.testo = "Pronto"\n'
              'fine\n\n'
              'quando Conto.scadenza fai\n'
              '    Stato.testo = "Tempo scaduto!"\n'
              '    Vibrazione1.schema([0, 400, 200, 400, 200, 400])\n'
              '    messaggio("Il tempo è finito!")\n'
              'fine\n')
    return controlli, codice


def _quiz(nome: str) -> tuple[list[dict], str]:
    controlli = [
        _titolo(nome),
        _c("Domanda", "Etichetta", 20, 84, 320, 96, testo="Domanda", dimensione_carattere=18,
           ancoraggio=_LARGO),
        _c("Risposta1", "Pulsante", 20, 196, 320, 50, testo="Risposta 1", stile="secondario", ancoraggio=_LARGO),
        _c("Risposta2", "Pulsante", 20, 258, 320, 50, testo="Risposta 2", stile="secondario", ancoraggio=_LARGO),
        _c("Risposta3", "Pulsante", 20, 320, 320, 50, testo="Risposta 3", stile="secondario", ancoraggio=_LARGO),
        _c("Punti", "Etichetta", 20, 390, 320, 30, testo="Punti: 0", allineamento="centro", ancoraggio=_LARGO),
        _c("PulsanteRicomincia", "Pulsante", 20, 440, 320, 44, testo="Ricomincia", visibile=False,
           ancoraggio=_LARGO),
    ]
    codice = ('# Quiz: ogni domanda ha tre risposte e il numero di quella giusta (1, 2 o 3).\n'
              '# Aggiungi le tue domande alla lista!\n'
              'variabile domande = [\n'
              '    ["Qual è la capitale d\'Italia?", "Milano", "Roma", "Napoli", 2],\n'
              '    ["Quante zampe ha un ragno?", "Otto", "Sei", "Quattro", 1],\n'
              '    ["Di che colore è il cielo sereno?", "Verde", "Rosso", "Azzurro", 3]\n'
              ']\n'
              'variabile numero = 0\n'
              'variabile punti = 0\n\n'
              'funzione mostra_domanda()\n'
              '    se numero >= lunghezza(domande) allora\n'
              '        Domanda.testo = "Finito! Risposte giuste: {punti} su {lunghezza(domande)}."\n'
              '        Risposta1.visibile = falso\n'
              '        Risposta2.visibile = falso\n'
              '        Risposta3.visibile = falso\n'
              '        PulsanteRicomincia.visibile = vero\n'
              '    altrimenti\n'
              '        variabile d = domande[numero]\n'
              '        Domanda.testo = d[0]\n'
              '        Risposta1.testo = d[1]\n'
              '        Risposta2.testo = d[2]\n'
              '        Risposta3.testo = d[3]\n'
              '    fine\n'
              '    Punti.testo = "Punti: {punti}"\n'
              'fine\n\n'
              'funzione rispondi(scelta)\n'
              '    se scelta == domande[numero][4] allora\n'
              '        punti = punti + 1\n'
              '        messaggio("Giusto!")\n'
              '    altrimenti\n'
              '        messaggio("Sbagliato!")\n'
              '    fine\n'
              '    numero = numero + 1\n'
              '    mostra_domanda()\n'
              'fine\n\n'
              'quando Finestra1.apertura fai\n'
              '    mostra_domanda()\n'
              'fine\n\n'
              'quando Risposta1.clic fai\n'
              '    rispondi(1)\n'
              'fine\n\n'
              'quando Risposta2.clic fai\n'
              '    rispondi(2)\n'
              'fine\n\n'
              'quando Risposta3.clic fai\n'
              '    rispondi(3)\n'
              'fine\n\n'
              'quando PulsanteRicomincia.clic fai\n'
              '    numero = 0\n'
              '    punti = 0\n'
              '    Risposta1.visibile = vero\n'
              '    Risposta2.visibile = vero\n'
              '    Risposta3.visibile = vero\n'
              '    PulsanteRicomincia.visibile = falso\n'
              '    mostra_domanda()\n'
              'fine\n')
    return controlli, codice


def _scheda(nome: str) -> tuple[list[dict], str]:
    controlli = [
        _titolo(nome),
        _c("EtichettaCF", "Etichetta", 20, 80, 320, 22, testo="Codice fiscale"),
        _c("CF", "CasellaCodiceFiscale", 20, 104, 320, 44, ancoraggio=_LARGO),
        _c("EtichettaComune", "Etichetta", 20, 160, 320, 22, testo="Comune di residenza"),
        _c("Comune", "SelettoreComune", 20, 184, 320, 44, ancoraggio=_LARGO),
        _c("EtichettaIBAN", "Etichetta", 20, 240, 320, 22, testo="IBAN"),
        _c("IBAN", "CasellaIBAN", 20, 264, 320, 44, ancoraggio=_LARGO),
        _c("Riepilogo", "Etichetta", 20, 324, 320, 110, testo="Compila i campi: diventano verdi quando sono giusti.",
           colore_bordo="#8E8E93", raggio_angoli=12, ancoraggio=_LARGO),
    ]
    codice = ('# Scheda dati: i campi italiani si controllano da soli (verde = giusto, rosso = sbagliato).\n\n'
              'funzione riepiloga()\n'
              '    variabile righe = []\n'
              '    se CF.valido allora\n'
              '        righe.aggiungi("Nato il {CF.data_nascita} ({CF.sesso})")\n'
              '    fine\n'
              '    se lunghezza(Comune.comune) > 0 allora\n'
              '        variabile c = Comune.comune\n'
              '        righe.aggiungi("Vive a " + c["nome"] + " (" + c["sigla"] + "), " + c["regione"])\n'
              '    fine\n'
              '    se IBAN.valido allora\n'
              '        righe.aggiungi("IBAN valido")\n'
              '    fine\n'
              '    se lunghezza(righe) == 0 allora\n'
              '        Riepilogo.testo = "Compila i campi: diventano verdi quando sono giusti."\n'
              '    altrimenti\n'
              '        Riepilogo.testo = "\\n".unisci(righe)\n'
              '    fine\n'
              'fine\n\n'
              'quando CF.valido fai\n'
              '    riepiloga()\n'
              'fine\n\n'
              'quando Comune.selezione fai\n'
              '    riepiloga()\n'
              'fine\n\n'
              'quando IBAN.valido fai\n'
              '    riepiloga()\n'
              'fine\n')
    return controlli, codice


def _effetti(nome: str) -> tuple[list[dict], str]:
    controlli = [
        _c("Titolo", "Etichetta", 20, 28, 320, 40, testo=nome, dimensione_carattere=20, grassetto=True,
           allineamento="centro", ancoraggio=_LARGO, animazione_entrata="caduta", durata_entrata=900),
        _c("Rombo", "Etichetta", 20, 90, 100, 90, testo="◆", dimensione_carattere=48, allineamento="centro",
           colore_testo="#FFCC00", animazione_entrata="zoom", ritardo_entrata=200, effetto_continuo="ruota"),
        _c("Triangolo", "Etichetta", 130, 90, 100, 90, testo="▲", dimensione_carattere=48, allineamento="centro",
           colore_testo="#D7132A", animazione_entrata="rimbalzo", ritardo_entrata=350, effetto_continuo="battito"),
        _c("Palla", "Etichetta", 240, 90, 100, 90, testo="●", dimensione_carattere=48, allineamento="centro",
           colore_testo="#0A84FF", animazione_entrata="caduta", ritardo_entrata=500, effetto_continuo="galleggia"),
        _c("PulsanteRimbalza", "Pulsante", 20, 210, 155, 52, testo="Rimbalza", raggio_angoli=26,
           effetto_tocco="affonda", animazione_entrata="scorri_destra", ritardo_entrata=600),
        _c("PulsanteGira", "Pulsante", 185, 210, 155, 52, testo="Gira", raggio_angoli=26, effetto_tocco="onda",
           animazione_entrata="scorri_sinistra", ritardo_entrata=650),
        _c("PulsanteVola", "Pulsante", 20, 276, 155, 52, testo="Vola", raggio_angoli=26, stile="secondario",
           effetto_tocco="affonda", animazione_entrata="scorri_destra", ritardo_entrata=700),
        _c("PulsanteSparisci", "Pulsante", 185, 276, 155, 52, testo="Sparisci", raggio_angoli=26,
           stile="secondario", effetto_tocco="onda", animazione_entrata="scorri_sinistra", ritardo_entrata=750),
        _c("Messaggio", "Etichetta", 20, 350, 320, 56, testo="Tocca un pulsante!", allineamento="centro",
           colore_sfondo="#F2F2F7", raggio_angoli=14, ancoraggio=_LARGO, animazione_entrata="dissolvenza",
           ritardo_entrata=900, effetto_tocco="brilla"),
    ]
    codice = ('# Effetti speciali. Senza codice: nel pannello delle proprietà di ogni oggetto, gruppo "Effetti"\n'
              '# (come entra, un effetto che si ripete, cosa fa quando lo tocchi). Con il codice: i comandi\n'
              '# rimbalza(), ruota(), capovolgi(), brilla(), vola_a(x, y), mostra_con(...), nascondi_con(...).\n\n'
              'quando PulsanteRimbalza.clic fai\n'
              '    Palla.rimbalza(3)\n'
              '    Messaggio.testo = "Palla.rimbalza(3)"\n'
              'fine\n\n'
              'quando PulsanteGira.clic fai\n'
              '    Rombo.ruota(2)\n'
              '    Triangolo.capovolgi()\n'
              '    Messaggio.testo = "Rombo.ruota(2) e Triangolo.capovolgi()"\n'
              'fine\n\n'
              'funzione torna_a_casa()\n'
              '    Palla.vola_a(240, 90, 0.6, "elastica")\n'
              'fine\n\n'
              'quando PulsanteVola.clic fai\n'
              '    Palla.vola_a(20, 440, 0.8, "rimbalzo", poi = torna_a_casa)\n'
              '    Messaggio.testo = "Palla.vola_a(20, 440) e poi torna a casa"\n'
              'fine\n\n'
              'quando PulsanteSparisci.clic fai\n'
              '    se Triangolo.visibile allora\n'
              '        Triangolo.nascondi_con("zoom")\n'
              '        PulsanteSparisci.testo = "Ricompari"\n'
              '    altrimenti\n'
              '        Triangolo.mostra_con("rimbalzo")\n'
              '        PulsanteSparisci.testo = "Sparisci"\n'
              '    fine\n'
              '    Messaggio.brilla()\n'
              'fine\n')
    return controlli, codice


# --- hardware del telefono (scheda "Telefono": leo.grafica.web.hardware) ---------------------------
def _invisibile(nome: str, tipo: str, **p: Any) -> dict:
    return {"nome": nome, "tipo": tipo, "contenitore": "", **p}


def _pappagallo(nome: str) -> tuple[list[dict], str]:
    controlli = [
        _titolo(nome),
        _c("Spiegazione", "Etichetta", 20, 76, 320, 48, testo="Tocca il microfono e parla: il telefono ripete "
           "quello che dici.", ancoraggio=_LARGO),
        _c("Microfono", "Dettatura", 20, 140, 320, 72, ancoraggio=_LARGO),
        _c("Veloce", "Interruttore", 20, 232, 320, 40, testo="Voce veloce", ancoraggio=_LARGO),
        _c("Stato", "Etichetta", 20, 290, 320, 30, testo="", allineamento="centro", ancoraggio=_LARGO),
        _invisibile("VoceTelefono", "Voce"),
        _invisibile("Vibrazione1", "Vibrazione"),
    ]
    codice = ('# Pappagallo: la Dettatura trasforma la voce in testo, la Voce lo legge ad alta voce.\n\n'
              'quando Microfono.frase_riconosciuta fai\n'
              '    Stato.testo = "Hai detto: {evento["testo"]}"\n'
              '    VoceTelefono.leggi(evento["testo"])\n'
              'fine\n\n'
              'quando VoceTelefono.fine_lettura fai\n'
              '    Vibrazione1.vibra(60)\n'
              '    Stato.testo = "Tocca di nuovo il microfono"\n'
              'fine\n\n'
              'quando Veloce.cambio fai\n'
              '    se Veloce.acceso allora\n'
              '        VoceTelefono.velocita = 5\n'
              '    altrimenti\n'
              '        VoceTelefono.velocita = 0\n'
              '    fine\n'
              'fine\n')
    return controlli, codice


def _bussola(nome: str) -> tuple[list[dict], str]:
    controlli = [
        _titolo(nome),
        _c("Bussola1", "Bussola", 60, 80, 240, 240),
        _c("Livella1", "Livella", 100, 336, 160, 160),
        _c("PulsanteTorcia", "Pulsante", 20, 516, 320, 48, testo="Accendi la torcia", ancoraggio=_LARGO),
        _c("Stato", "Etichetta", 20, 576, 320, 30, testo="", allineamento="centro", ancoraggio=_LARGO),
        _invisibile("Torcia1", "Torcia"),
        _invisibile("Vibrazione1", "Vibrazione"),
    ]
    codice = ('# Bussola e livella: si muovono da sole quando giri o inclini il telefono.\n\n'
              'variabile era_in_piano = vero\n\n'
              'quando Bussola1.cambio fai\n'
              '    Stato.testo = "Guardi verso {evento["punto_cardinale"]}"\n'
              'fine\n\n'
              'quando Livella1.cambio fai\n'
              '    # quando il telefono torna in piano fa un colpetto\n'
              '    se evento["in_piano"] e non era_in_piano allora\n'
              '        Vibrazione1.vibra(80)\n'
              '    fine\n'
              '    era_in_piano = evento["in_piano"]\n'
              'fine\n\n'
              'quando PulsanteTorcia.clic fai\n'
              '    Torcia1.commuta()\n'
              '    se Torcia1.accesa allora\n'
              '        PulsanteTorcia.testo = "Spegni la torcia"\n'
              '    altrimenti\n'
              '        PulsanteTorcia.testo = "Accendi la torcia"\n'
              '    fine\n'
              'fine\n')
    return controlli, codice


#: chiave -> (titolo, descrizione, icona, costruttore). L'icona e' un nome (niente emoji): la disegna
#: l'app (``ICONE_MODELLI`` in ``android/app/src/main/assets/web/app.js``).
MODELLI: dict[str, tuple[str, str, str, Callable[[str], tuple[list[dict], str]]]] = {
    "saluto": ("Saluto", "Una casella e un pulsante: il primo passo", "fumetto", _saluto),
    "contatore": ("Contatore", "Un numero grande con +1, −1 e Azzera", "numeri", _contatore),
    "lista": ("Lista della spesa", "Aggiungi, togli e svuota una lista", "lista", _lista),
    "timer": ("Timer da cucina", "Conto alla rovescia con allarme", "clessidra", _timer),
    "quiz": ("Quiz", "Domande con tre risposte e i punti", "domanda", _quiz),
    "scheda": ("Scheda dati", "Codice fiscale, comune e IBAN che si controllano da soli", "tessera", _scheda),
    "effetti": ("Effetti speciali", "Oggetti che entrano, girano, rimbalzano e brillano", "scintille", _effetti),
    "pappagallo": ("Pappagallo", "Parli e il telefono ripete quello che hai detto", "microfono", _pappagallo),
    "bussola": ("Bussola e livella", "Bussola, livella a bolla e torcia del telefono", "bussola", _bussola),
}


def elenco_modelli() -> list[dict]:
    return [{"chiave": k, "titolo": t, "descrizione": d, "icona": i} for k, (t, d, i, _f) in MODELLI.items()]


def costruisci(chiave: str, nome: str) -> tuple[dict, str]:
    """(modello della maschera, codice) del modello ``chiave`` per un'app che si chiama ``nome``."""
    _t, _d, _i, f = MODELLI.get(chiave) or MODELLI["saluto"]
    controlli, codice = f(nome)
    maschera = {"versione": 1,
                "finestra": {"nome": "Finestra1", "tipo": "Finestra", "testo": nome, "larghezza": L, "altezza": A},
                "controlli": controlli}
    return maschera, "# Codice degli eventi di Finestra1\n\n" + codice


_ANTEPRIME: dict[str, dict] = {}


def anteprima(chiave: str) -> dict:
    """La finestra del modello ``chiave`` gia' pronta per ``LeoFinestre.disegna`` (la miniatura nella scelta
    del modello sul telefono): la stessa che riceve il disegnatore dopo "Crea", calcolata una volta sola."""
    if chiave not in _ANTEPRIME:
        import tempfile

        from .disegnatore import leggi_maschera_json, salva_maschera_json

        titolo = (MODELLI.get(chiave) or MODELLI["saluto"])[0]
        maschera, _codice = costruisci(chiave, titolo)
        with tempfile.TemporaryDirectory(prefix="leo_anteprima_") as cartella:
            percorso = os.path.join(cartella, "Finestra1.maschera")
            salva_maschera_json(percorso, maschera)
            _ANTEPRIME[chiave] = leggi_maschera_json(percorso)
    return _ANTEPRIME[chiave]


def elenco_modelli_con_anteprima() -> list[dict]:
    return [{**m, "anteprima": anteprima(m["chiave"])} for m in elenco_modelli()]


__all__ = ["MODELLI", "elenco_modelli", "elenco_modelli_con_anteprima", "anteprima", "costruisci"]
