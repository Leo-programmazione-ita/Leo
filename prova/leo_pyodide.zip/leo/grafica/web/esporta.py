"""Esporta un progetto Leo (con finestre) come SITO WEB statico: una cartella di file
HTML/JS/CSS che gira nel browser (Pyodide + finestre.js), pronta da pubblicare.

La logica Leo gira sotto Pyodide dentro un Web Worker; le finestre sono disegnate da
``finestre.js`` sul thread principale. Il ponte fra i due è ``canale_sab.py`` +
``modello_sito/{bootstrap,lavoratore}.js`` (SharedArrayBuffer). Vedi
``docs/analisi/2026-10-19_architettura_leo_web_export.md``.

Uso da Python::

    from leo.grafica.web.esporta import esporta_sito
    esporta_sito("esempi/calcolatrice_tascabile", "/tmp/sito")

Poi ``python /tmp/sito/avvia.py`` e apri http://localhost:8000.
"""

from __future__ import annotations

import base64
import json
import re
import shutil
from pathlib import Path

RADICE = Path(__file__).resolve().parents[3]
MODELLO = Path(__file__).resolve().parent / "modello_sito"
ASSET_WEB = RADICE / "android" / "app" / "src" / "main" / "assets" / "web"

#: asset necessari all'ESECUZIONE (renderer + disegni dei controlli + stili)
ASSET_NECESSARI = [
    "finestre.js", "finestre.css", "giochi.js",
    "finestre_dati.js", "finestre_quotidiani.js", "finestre_quotidiani.css",
    "stili_oggetti.js", "stili_oggetti.css", "icone_controlli.js", "stemma.svg",
]

ESTENSIONI_TESTO = {".leo", ".toml", ".maschera", ".txt", ".json", ".md", ".csv"}


#: dati minimi che servono a ESEGUIRE nel browser (sinonimi) e ai messaggi d'errore ricchi
_DATI_FILE = ("sinonimi.toml", "vocabolario.toml", "altri_linguaggi.toml")
_DATI_CARTELLE = ("vocabolario",)
_IGNORA = {"__pycache__", ".DS_Store", "Thumbs.db"}


def _cartella_dati() -> Path:
    try:
        from ...percorsi import file_dati
        return Path(file_dati("sinonimi.toml")).resolve().parent
    except Exception:  # noqa: BLE001
        return RADICE / "dati"


def _archivio_leo() -> bytes:
    """Lo zip con tutto ``leo/`` (tranne studio e grafica/qt) piu' i dati minimi.

    Costruito DENTRO il pacchetto ``leo`` (via ``leo.__file__``), cosi' funziona anche da un
    eseguibile impacchettato con PyInstaller, non solo dall'albero di sviluppo.
    """
    import io
    import os
    import zipfile

    import leo as _leo
    pacchetto = Path(_leo.__file__).resolve().parent
    dati = _cartella_dati()
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for radice, cartelle, file in os.walk(pacchetto):
            rel = Path(radice).relative_to(pacchetto)
            tenute = []
            for c in sorted(cartelle):
                rc = rel / c
                if rc.parts[:1] == ("studio",) or rc.parts[:2] == ("grafica", "qt") or c in _IGNORA:
                    continue
                tenute.append(c)
            cartelle[:] = tenute
            for nome in sorted(file):
                if nome.endswith((".pyc", ".pyo")) or nome in _IGNORA:
                    continue
                zf.write(Path(radice) / nome, "leo/" + (rel / nome).as_posix())
        for nome in _DATI_FILE:
            fp = dati / nome
            if fp.is_file():
                zf.write(fp, "dati/" + nome)
        for sotto in _DATI_CARTELLE:
            base = dati / sotto
            if base.is_dir():
                for r, _c, fs in os.walk(base):
                    rr = Path(r).relative_to(dati)
                    for nome in sorted(fs):
                        if nome.endswith((".pyc", ".pyo")):
                            continue
                        zf.write(Path(r) / nome, "dati/" + (rr / nome).as_posix())
    return buffer.getvalue()


def _html_sicuro(testo: str) -> str:
    return testo.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _dati_progetto(cartella: Path) -> dict:
    """Nome e finestra iniziale dal ``progetto.toml`` (con ripieghi se manca il lettore TOML)."""
    nome, iniziale = cartella.name, ""
    toml = cartella / "progetto.toml"
    if not toml.is_file():
        return {"nome": nome, "iniziale": iniziale}
    testo = toml.read_text(encoding="utf-8")
    try:
        import tomllib  # Python 3.11+
        dati = tomllib.loads(testo)
        prog = dati.get("progetto", {})
        nome = str(prog.get("nome", nome))
        iniziale = str(prog.get("finestra_iniziale", iniziale))
    except Exception:  # noqa: BLE001 - ripiego a regex se tomllib manca o il file è strano
        m = re.search(r'(?m)^\s*nome\s*=\s*"([^"]*)"', testo)
        if m:
            nome = m.group(1)
        m = re.search(r'(?m)^\s*finestra_iniziale\s*=\s*"([^"]*)"', testo)
        if m:
            iniziale = m.group(1)
    return {"nome": nome, "iniziale": iniziale}


def _file_di_testo(cartella: Path) -> dict[str, str]:
    """I file di testo del progetto come {percorso relativo (posix): contenuto}."""
    file: dict[str, str] = {}
    for p in sorted(cartella.rglob("*")):
        if p.is_file() and p.suffix.lower() in ESTENSIONI_TESTO:
            try:
                file[p.relative_to(cartella).as_posix()] = p.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
    return file


#: risorse binarie del progetto (immagini, suoni) oltre un filtro di dimensione
LIMITE_RISORSA = 6 * 1024 * 1024  # 6 MB per file


def _risorse_binarie(cartella: Path) -> dict[str, str]:
    """I file NON di testo del progetto come {percorso relativo: base64} (immagini, ecc.)."""
    fuori: dict[str, str] = {}
    for p in sorted(cartella.rglob("*")):
        if not p.is_file() or p.suffix.lower() in ESTENSIONI_TESTO or p.name.startswith("."):
            continue
        try:
            dati = p.read_bytes()
        except OSError:
            continue
        if len(dati) > LIMITE_RISORSA:
            continue
        fuori[p.relative_to(cartella).as_posix()] = base64.b64encode(dati).decode("ascii")
    return fuori


def esporta_sito(progetto, uscita, *, edizione: str | None = None, titolo: str | None = None) -> Path:
    """Scrive in ``uscita`` il sito web del progetto in ``progetto``; restituisce la cartella.

    ``edizione`` decide il colore d'accento (rosso per la Suite, il colore del logo per le altre);
    se è ``None`` usa l'edizione corrente.
    """
    cartella = Path(progetto).resolve()
    ha_maschere = any(cartella.glob("*.maschera"))
    if not (cartella / "progetto.toml").is_file() and not ha_maschere:
        raise ValueError(f"{cartella} non sembra un progetto Leo con finestre "
                         f"(manca progetto.toml e nessun file .maschera).")
    dest = Path(uscita).resolve()
    dest.mkdir(parents=True, exist_ok=True)

    meta = _dati_progetto(cartella)
    titolo = titolo or meta["nome"]

    try:
        from ...edizioni import colore_edizione, edizione_corrente
        ed = edizione or edizione_corrente()
        accento = colore_edizione(ed)
    except Exception:  # noqa: BLE001
        accento = "#E0182D"

    # 1) il pacchetto Leo per il browser
    (dest / "leo.zip").write_bytes(_archivio_leo())

    # 2) i file del progetto (il worker li scrive nel filesystem di Pyodide)
    prog = {"file": _file_di_testo(cartella), "binario": _risorse_binarie(cartella),
            "principale": meta["iniziale"]}
    # Carica `cryptography` nel worker SOLO se l'app usa davvero la cifratura (altrimenti ogni app
    # si porterebbe ~15 MB inutili). Lo rileva dal testo dei .leo del progetto.
    _CRYPTO_FN = ("cifra_testo", "decifra_testo", "cifra_file", "decifra_file",
                  "cifra_per", "decifra_da", "cifra_file_per", "decifra_file_da")
    prog["cifratura"] = any(any(fn in t for fn in _CRYPTO_FN) for t in prog["file"].values())
    (dest / "progetto.json").write_text(json.dumps(prog, ensure_ascii=False), encoding="utf-8")

    # 3) gli asset dell'interfaccia (renderer + controlli)
    dest_asset = dest / "assets" / "web"
    dest_asset.mkdir(parents=True, exist_ok=True)
    mancanti = []
    for nome in ASSET_NECESSARI:
        sorgente = ASSET_WEB / nome
        if sorgente.is_file():
            shutil.copy2(sorgente, dest_asset / nome)
        else:
            mancanti.append(nome)

    # 4) index.html con titolo e configurazione
    config = {"titolo": titolo, "accento": accento, "tema": "scuro"}
    html = (MODELLO / "index.html").read_text(encoding="utf-8")
    html = html.replace("__TITOLO__", _html_sicuro(titolo))
    html = html.replace("__ACCENTO__", accento)
    html = html.replace("__CONFIG__", json.dumps(config, ensure_ascii=False))
    (dest / "index.html").write_text(html, encoding="utf-8")

    # PWA: manifest (riempito) + service worker (installabile su iPhone/Android "Aggiungi a Home")
    manifest = (MODELLO / "app.webmanifest").read_text(encoding="utf-8")
    manifest = manifest.replace("__TITOLO__", titolo.replace('"', "'")).replace("__ACCENTO__", accento)
    (dest / "app.webmanifest").write_text(manifest, encoding="utf-8")
    shutil.copy2(MODELLO / "service-worker.js", dest / "service-worker.js")

    # 5) i file statici del modello
    for nome in ("bootstrap.js", "lavoratore.js", "avvia.py", "_headers", "netlify.toml", "LEGGIMI.txt"):
        shutil.copy2(MODELLO / nome, dest / nome)

    if mancanti:
        (dest / "LEGGIMI.txt").open("a", encoding="utf-8").write(
            "\nAvviso: asset non trovati e non copiati: " + ", ".join(mancanti) + "\n")
    return dest


# ===========================================================================
#  Export "disegno": uno SCRIPT Leo (tartaruga/grafica da codice) come sito web.
#  La pagina fa girare lo script sotto Pyodide (thread principale, niente finestre
#  ne' SharedArrayBuffer) e mostra il disegno SVG della tartaruga piu' l'uscita di
#  `stampa`. Essendo non interattivo non servono gli header COOP/COEP.
# ===========================================================================

_RUNNER_DISEGNO = r"""
import os, sys, io, json
cwd = os.getcwd()
if cwd not in sys.path:
    sys.path.insert(0, cwd)
os.environ['LEO_DATI'] = os.path.join(cwd, 'dati')
with open('programma.leo', 'w', encoding='utf-8') as _f:
    _f.write(_codice_leo)
import leo.piattaforma as _pf
_pf.SOSTITUTI['web'] = True
from leo.esecuzione import esegui_file
from leo import tartaruga as _T
_cat = io.StringIO(); _old = sys.stdout; sys.stdout = _cat
_err = None; _interp = None
try:
    _interp = esegui_file('programma.leo')
except BaseException as _e:
    _err = str(_e)
    _causa = getattr(_e, '__cause__', None) or getattr(_e, '__context__', None)
    if _causa is not None:
        _err = _err + '  [' + type(_causa).__name__ + ': ' + str(_causa) + ']'
finally:
    sys.stdout = _old
_t = None
try:
    _t = _T.tartaruga_di(_interp, crea=False) if _interp is not None else None
except Exception:
    _t = None
if _t is None and _T._IN_ATTESA:
    _t = _T._IN_ATTESA[-1]
_svg = _t.svg() if (_t and _t.elementi) else ''
json.dumps({'svg': _svg, 'stampa': _cat.getvalue(), 'errore': _err})
"""

_INDICE_DISEGNO = """<!doctype html>
<html lang="it">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>__TITOLO__</title>
<meta name="theme-color" content="__ACCENTO__">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="__TITOLO__">
<style>
  :root { --accento: __ACCENTO__; }
  html, body { margin: 0; min-height: 100%; background: #0B0B0D; color: #ECECEF;
    font-family: "Segoe UI", Inter, system-ui, sans-serif; }
  .barra { display: flex; align-items: center; gap: 10px; padding: 14px 18px;
    border-bottom: 1px solid #1d1d22; }
  .barra b { font-size: 16px; }
  .punto { width: 10px; height: 10px; border-radius: 50%; background: var(--accento); }
  main { display: flex; flex-direction: column; align-items: center; gap: 16px; padding: 22px; }
  #disegno { max-width: min(92vw, 720px); width: 100%; background: #fff; border-radius: 12px;
    padding: 10px; box-shadow: 0 10px 44px rgba(0,0,0,.45); }
  #disegno svg { display: block; width: 100%; height: auto; }
  pre#stampa { white-space: pre-wrap; max-width: 720px; width: 100%; background: #141418;
    border: 1px solid #26262c; border-radius: 10px; padding: 12px; color: #c9c9d0; font-size: 13px; }
  .stato { color: #9c9ca6; font-size: 15px; text-align: center; line-height: 1.5; }
  .stato.errore { color: #FFB020; }
</style>
</head>
<body>
<div class="barra"><span class="punto"></span><b>__TITOLO__</b></div>
<main>
  <div id="stato" class="stato">Avvio di Leo… (il primo caricamento scarica Python, può volerci qualche secondo)</div>
  <div id="disegno" hidden></div>
  <pre id="stampa" hidden></pre>
</main>
<script src="https://cdn.jsdelivr.net/pyodide/v0.26.4/full/pyodide.js"></script>
<script>
"use strict";
var BASE = "https://cdn.jsdelivr.net/pyodide/v0.26.4/full/";
var RUNNER = __RUNNER__;
async function main() {
  var stato = document.getElementById("stato");
  try {
    var py = await loadPyodide({ indexURL: BASE });
    var zip = new Uint8Array(await (await fetch("leo.zip?b=__STAMP__")).arrayBuffer());
    var codice = await (await fetch("programma.leo?b=__STAMP__")).text();
    try { await py.loadPackage("cryptography"); } catch (e) { /* senza: la cifratura non e' disponibile, il resto funziona */ }
    py.unpackArchive(zip, "zip");
    py.globals.set("_codice_leo", codice);
    var out = py.runPython(RUNNER);
    var r = JSON.parse(out);
    stato.hidden = true;
    if (r.svg) { var d = document.getElementById("disegno"); d.innerHTML = r.svg; d.hidden = false; }
    if (r.stampa && r.stampa.trim()) { var p = document.getElementById("stampa"); p.textContent = r.stampa; p.hidden = false; }
    if (r.errore) { stato.hidden = false; stato.className = "stato errore"; stato.textContent = "Errore: " + r.errore; }
    else if (!r.svg) { stato.hidden = false; stato.textContent = "Il programma è andato a buon fine ma non ha disegnato nulla."; }
  } catch (e) {
    stato.className = "stato errore";
    stato.textContent = "Errore: " + (e && e.message ? e.message : e);
  }
}
main();
</script>
</body>
</html>
"""


def esporta_disegno(script, uscita, *, edizione=None, titolo=None):
    """Esporta uno SCRIPT Leo (tartaruga/grafica da codice) come mini-sito web.

    La pagina esegue lo script sotto Pyodide e mostra il disegno SVG piu' l'uscita di `stampa`.
    Restituisce la cartella di destinazione.
    """
    import json as _json

    percorso = Path(script).resolve()
    if percorso.is_dir():
        candidati = sorted(percorso.glob("*.leo"))
        if not candidati:
            raise ValueError(f"{percorso} non contiene nessun file .leo da disegnare.")
        percorso = candidati[0]
    if not percorso.is_file():
        raise ValueError(f"{percorso} non e' un file .leo.")

    dest = Path(uscita).resolve()
    dest.mkdir(parents=True, exist_ok=True)
    titolo = titolo or percorso.stem.replace("_", " ").strip().capitalize()

    try:
        from ...edizioni import colore_edizione, edizione_corrente
        ed = edizione or edizione_corrente()
        accento = colore_edizione(ed)
    except Exception:  # noqa: BLE001
        accento = "#E0182D"

    (dest / "leo.zip").write_bytes(_archivio_leo())
    (dest / "programma.leo").write_text(percorso.read_text(encoding="utf-8"), encoding="utf-8")
    for altro in sorted(percorso.parent.glob("*.leo")):
        if altro.name != percorso.name:
            try:
                (dest / altro.name).write_text(altro.read_text(encoding="utf-8"), encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                pass

    runner_js = _json.dumps(_RUNNER_DISEGNO)
    import time as _time
    stamp = str(int(_time.time()))
    html = (_INDICE_DISEGNO
            .replace("__RUNNER__", runner_js)
            .replace("__TITOLO__", _html_sicuro(titolo))
            .replace("__ACCENTO__", accento)
            .replace("__STAMP__", stamp))
    (dest / "index.html").write_text(html, encoding="utf-8")

    avvia_semplice = (
        "#!/usr/bin/env python3\n"
        '"""Micro server per provare in locale un disegno Leo (multithread, senza COOP/COEP)."""\n'
        "import http.server, sys\n"
        "PORTA = int(sys.argv[1]) if len(sys.argv) > 1 else 8000\n"
        "class Gestore(http.server.SimpleHTTPRequestHandler):\n"
        "    def log_message(self, *a):\n"
        "        pass\n"
        "http.server.ThreadingHTTPServer.allow_reuse_address = True\n"
        "with http.server.ThreadingHTTPServer(('', PORTA), Gestore) as s:\n"
        "    print(f'Leo: apri  http://localhost:{PORTA}   (Ctrl+C per fermare)')\n"
        "    try:\n"
        "        s.serve_forever()\n"
        "    except KeyboardInterrupt:\n"
        "        print()\n"
    )
    (dest / "avvia.py").write_text(avvia_semplice, encoding="utf-8")
    (dest / "LEGGIMI.txt").write_text(
        "Mini-sito di un disegno Leo (tartaruga).\n\n"
        "Provalo:   python avvia.py    poi apri http://localhost:8000\n"
        "Non usa SharedArrayBuffer: va bene anche un hosting statico qualunque (anche GitHub Pages).\n",
        encoding="utf-8")
    return dest
