"""CanaleWeb per il browser: il ponte fra l'interprete Leo (in Pyodide, dentro un Web Worker)
e la pagina che disegna le finestre (``finestre.js`` sul thread principale).

Perché serve un ponte diverso da quello di Android: lì l'interprete gira su un thread Chaquopy
e la pagina su quello dell'interfaccia. Nel browser l'interprete gira in un **Web Worker** e la
pagina sul thread principale. ``ProgrammaWeb.esegui()`` è un ciclo bloccante (``ricevi(attesa)``
aspetta gli eventi): nel worker si può aspettare davvero con ``Atomics.wait`` su un
``SharedArrayBuffer`` condiviso col main, senza congelare l'interfaccia.

Questo modulo è volutamente sottile: la logica di ``Atomics`` sta nel JavaScript del lavoratore
(``lavoratore.js``), che passa qui due funzioni:

* ``posta(json)``  -> manda i messaggi alla pagina (``postMessage``: non blocca);
* ``attendi(ms)``  -> aspetta gli eventi dalla pagina via SAB e li ridà come testo JSON (o ``None``).

Gira solo sotto Pyodide; su CPython normale ``posta``/``attendi`` sono ``None`` e il canale non fa nulla.
"""

from __future__ import annotations

import json
from typing import Any

from .programma import CanaleWeb, compatta_messaggi, messaggi_json


class CanaleWebSAB(CanaleWeb):
    """Canale verso la pagina basato su ``postMessage`` (uscita) e ``SharedArrayBuffer`` (entrata)."""

    def __init__(self, posta: Any = None, attendi: Any = None) -> None:
        self._posta = posta        # JS: (str) -> None   — manda i messaggi al thread principale
        self._attendi = attendi    # JS: (int) -> str|None — aspetta gli eventi (Atomics.wait) e li ridà

    def invia(self, messaggi: list[dict]) -> None:
        if not messaggi or self._posta is None:
            return
        self._posta(messaggi_json(compatta_messaggi(messaggi)))

    def ricevi(self, attesa: float) -> list[dict] | None:
        if self._attendi is None:
            return []
        try:
            secondi = float(attesa)
        except (TypeError, ValueError):
            secondi = 0.0
        import math
        if not math.isfinite(secondi):
            secondi = 60.0
        millisecondi = int(min(60000.0, max(0.0, secondi * 1000)))
        testo = self._attendi(millisecondi)
        if not testo:
            return []   # timeout: nessun evento (NON None: None = interfaccia chiusa)
        try:
            dati = json.loads(str(testo))
        except (ValueError, TypeError):
            return []
        return dati if isinstance(dati, list) else []
