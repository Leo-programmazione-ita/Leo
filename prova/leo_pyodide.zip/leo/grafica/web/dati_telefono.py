"""Motore del telefono per gli oggetti "dati, cruscotti e telefono" e per quelli portati dal PC.

Si aggancia a ``leo.grafica.web.hardware`` (che chiama le funzioni qui sotto per i tipi di
:data:`TIPI`) e usa lo stesso canale verso ``Leo.hardware`` (vedi ``android/CONTRATTO.md``,
"Hardware del telefono", azioni ``fonometro_*``, ``registra_*``, ``rete*``, ``orientamento_blocca``).

* sensori del telefono gia' esistenti: ``Contapassi`` (passi), ``SensoreLuce`` (luce),
  ``SensoreProssimità`` (prossimita), ``Barometro`` (pressione), ``Movimento`` (accelerometro);
* azioni nuove: ``Fonometro`` (microfono), ``RegistratoreAudio``, ``StatoRete``, ``OrientamentoSchermo``;
* eventi che nascono dal codice: ``Cruscotto.cambio_zona``, ``AnelloAvanzamento.completato``,
  ``Oscilloscopio.soglia_superata``;
* oggetti portati dal PC che vogliono Python: ``DialogoFile`` (i file del progetto in un foglio di
  scelte), ``Video`` (il file del progetto per il ``<video>`` della pagina), ``Tutor`` (le spiegazioni
  dei controlli).

Il disegno e i tocchi sono in ``android/app/src/main/assets/web/finestre_dati.js``.
"""

from __future__ import annotations

import os
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

from ...errori import ErroreFile, ErroreValore
from .. import logica_dati_telefono as L

if TYPE_CHECKING:  # pragma: no cover
    from ..modello import ControlloVivo
    from .programma import FinestraWeb, ProgrammaWeb

#: Oggetti nuovi di ``catalogo_dati_telefono`` che hanno bisogno del motore.
TIPI_NUOVI = frozenset({"Cruscotto", "AnelloAvanzamento", "GraficoDalVivo", "TabellaOrdinabile", "Contapassi",
                        "SensoreLuce", "SensoreProssimità", "Barometro", "Movimento", "Fonometro",
                        "RegistratoreAudio", "StatoRete", "OrientamentoSchermo"})
#: Oggetti che prima c'erano solo sul PC e che qui hanno bisogno di Python.
TIPI_PORTATI = frozenset({"Oscilloscopio", "DialogoFile", "Video", "Tutor", "ModuloAutomatico"})
TIPI = TIPI_NUOVI | TIPI_PORTATI

#: Sensore del telefono usato da ogni oggetto (il resto lo fa hardware.py: avvio condiviso, ritmo...).
SENSORI: dict[str, str] = {"Contapassi": "passi", "SensoreLuce": "luce", "SensoreProssimità": "prossimita",
                           "Barometro": "pressione", "Movimento": "accelerometro"}
#: Ritmo delle letture (ms) degli oggetti senza la proprieta' `intervallo`.
INTERVALLI = {"Contapassi": 500, "Movimento": 50}
#: Ogni quanti millisecondi il fonometro manda il livello del rumore.
INTERVALLO_FONOMETRO = 200
#: Per quanti secondi il Barometro ricorda le letture (per la tendenza).
MEMORIA_BAROMETRO = 15 * 60


def _hw():
    from . import hardware

    return hardware


def _imposta(programma, finestra, vivo, proprieta: str, valore: Any) -> bool:
    return _hw()._imposta(programma, finestra, vivo, proprieta, valore)


def _emetti(programma, finestra, nome: str, evento: str, dati: dict) -> None:
    programma.emetti_evento(nome, evento, dati, finestra=finestra.nome)


def _num(v: Any, predefinito: float = 0.0) -> float:
    return _hw()._numero(v, predefinito)


def _stato(vivo: "ControlloVivo") -> dict:
    """Memoria del motore per un controllo (letture precedenti, base dei passi...)."""
    s = getattr(vivo, "_stato_dati_telefono", None)
    if s is None:
        s = {}
        try:
            vivo._stato_dati_telefono = s
        except AttributeError:  # pragma: no cover - ControlloVivo accetta attributi
            pass
    return s


def intervallo(vivo: "ControlloVivo") -> int:
    """Ritmo delle letture del sensore dell'oggetto (ms)."""
    p = vivo.modello.proprieta
    if "intervallo" in p:
        try:
            return max(20, int(p.get("intervallo") or 100))
        except (TypeError, ValueError):
            return 100
    return INTERVALLI.get(vivo.tipo_controllo, 100)


# ===========================================================================
# Azioni (metodi dei controlli)
# ===========================================================================

def azioni(finestra: "FinestraWeb", vivo: "ControlloVivo") -> dict[str, Callable[..., Any]]:
    tipo = vivo.tipo_controllo
    p = finestra.programma
    nome = vivo.nome
    prop = vivo.modello.proprieta
    hw = _hw()

    def manda(richiesta: dict, **opzioni: Any) -> dict | None:
        return hw.richiedi(p, finestra, nome, richiesta, **opzioni)

    tabella: dict[str, Callable[..., Any]] = {}
    if tipo == "Contapassi":
        def azzera() -> None:
            s = _stato(vivo)
            s["base"] = s.get("ultimo")
            _imposta(p, finestra, vivo, "passi", 0)
            _imposta(p, finestra, vivo, "distanza", 0.0)
            s["raggiunto"] = False
        tabella["azzera"] = azzera
    elif tipo == "Movimento":
        def azzera_scosse() -> None:
            _stato(vivo).pop("rilevatore", None)
            _imposta(p, finestra, vivo, "scosse", 0)
        tabella["azzera"] = azzera_scosse
    elif tipo == "Fonometro":
        tabella["avvia"] = lambda: _fonometro(p, finestra, vivo, True)
        tabella["ferma"] = lambda: _fonometro(p, finestra, vivo, False)
    elif tipo == "RegistratoreAudio":
        def registra() -> None:
            if prop.get("registrando"):
                return
            manda({"azione": "registra_avvia", "cartella": _cartella_registrazioni(p, vivo),
                   "durata_massima_s": max(1, hw._intero(prop.get("durata_massima"), 300))})
            _imposta(p, finestra, vivo, "registrando", True)

        def ferma() -> None:
            if prop.get("registrando"):
                manda({"azione": "registra_ferma"})
            else:
                manda({"azione": "suono_ferma"})

        def riproduci(percorso: str) -> None:
            manda({"azione": "suono", "file": _file_esistente(p, str(percorso)), "volume": 1.0, "ripeti": False})
        tabella["registra"] = registra
        tabella["ferma"] = ferma
        tabella["riproduci"] = riproduci
    elif tipo == "StatoRete":
        def aggiorna() -> bool:
            r = manda({"azione": "rete"}, aspetta=True)
            if r and r.get("ok") is not False:
                _rete(p, finestra, vivo, r)
            return bool(prop.get("connesso"))
        tabella["aggiorna"] = aggiorna
    elif tipo == "DialogoFile":
        tabella["mostra"] = lambda: _dialogo_file(p, finestra, vivo)
    elif tipo == "Video":
        for azione in ("riproduci", "pausa", "ferma"):
            tabella[azione] = (lambda a: lambda: _video_azione(p, finestra, vivo, a))(azione)
    return tabella


def _fonometro(programma, finestra, vivo, acceso: bool) -> None:
    if acceso:
        _hw().richiedi(programma, finestra, vivo.nome, {"azione": "fonometro_avvia",
                                                       "intervallo_ms": INTERVALLO_FONOMETRO})
    elif vivo.modello.proprieta.get("attivo") or _stato(vivo).get("acceso"):
        _hw().richiedi(programma, finestra, vivo.nome, {"azione": "fonometro_ferma"})
    _stato(vivo)["acceso"] = acceso
    _imposta(programma, finestra, vivo, "attivo", acceso)


def _cartella_progetto(programma) -> Path:
    return Path(programma.cartella)


def _cartella_registrazioni(programma, vivo) -> str:
    nome = str(vivo.modello.proprieta.get("cartella") or "registrazioni").strip() or "registrazioni"
    cartella = Path(os.path.expanduser(nome))
    if not cartella.is_absolute():
        cartella = _cartella_progetto(programma) / cartella
    try:
        cartella.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise ErroreFile(f"Non riesco a creare la cartella delle registrazioni `{nome}`: {e.strerror or e}.") from None
    return str(cartella.resolve())


def _file_esistente(programma, file: str) -> str:
    percorso = Path(os.path.expanduser(file))
    if not percorso.is_absolute():
        percorso = _cartella_progetto(programma) / percorso
    if not percorso.is_file():
        raise ErroreFile(f"Non trovo il file `{file}`.")
    return str(percorso.resolve())


# --- DialogoFile: i file del progetto in un foglio di scelte ------------------------------------

#: Quanti file al massimo nel foglio di scelte.
MASSIMO_FILE = 300


def estensioni_filtro(filtro: str) -> list[str]:
    """``"Immagini (*.png *.jpg);;Tutti (*.*)"`` -> ``[".png", ".jpg"]`` (lista vuota = tutti i file)."""
    import re

    estensioni: list[str] = []
    for gruppo in str(filtro or "").split(";;"):
        for e in re.findall(r"\*(\.[\w]+)", gruppo):
            if e.lower() not in estensioni:
                estensioni.append(e.lower())
        if "*.*" in gruppo or "*)" in gruppo.replace(" ", ""):
            return []
        if estensioni:
            break
    return estensioni


def file_del_progetto(cartella: Path, estensioni: list[str], cartelle: bool = False) -> list[str]:
    """Percorsi (relativi, con "/") dei file (o delle sottocartelle) del progetto, senza quelli di Leo."""
    risultato: list[str] = []
    base = Path(cartella)
    for radice, dirs, files in os.walk(base):
        dirs[:] = sorted(d for d in dirs if not d.startswith((".", "__")))
        rel = Path(radice).relative_to(base)
        if cartelle:
            for d in dirs:
                risultato.append((rel / d).as_posix())
        else:
            for f in sorted(files):
                if f.startswith(".") or f.endswith((".maschera", ".pyc")) or f == "progetto.toml":
                    continue
                if estensioni and Path(f).suffix.lower() not in estensioni:
                    continue
                risultato.append((rel / f).as_posix())
        if len(risultato) >= MASSIMO_FILE:
            break
    return risultato[:MASSIMO_FILE]


def _dialogo_file(programma, finestra, vivo) -> Any:
    prop = vivo.modello.proprieta
    modalita = str(prop.get("modalita") or "apri")
    titolo = str(prop.get("titolo") or ("Salva" if modalita == "salva" else "Apri"))
    base = _cartella_progetto(programma)
    if modalita == "salva":
        nome = programma.dialogo("testo", "Come si chiama il file?", titolo)
        nome = str(nome or "").strip()
        if not nome:
            return None
        if any(x in nome for x in ("..", "\\")) or nome.startswith("/"):
            raise ErroreValore("Il nome del file non può contenere \"..\", \"\\\" o cominciare con \"/\".")
        estensioni = estensioni_filtro(str(prop.get("filtro") or ""))
        if estensioni and not Path(nome).suffix:
            nome += estensioni[0]
        scelto = str((base / nome).resolve())
    else:
        cartelle = modalita == "cartella"
        voci = file_del_progetto(base, [] if cartelle else estensioni_filtro(str(prop.get("filtro") or "")),
                                 cartelle=cartelle)
        if cartelle:
            voci = ["(la cartella del progetto)"] + voci
        if not voci:
            programma.dialogo("messaggio", "Nella cartella del progetto non ci sono file da aprire.", titolo)
            return None
        indice = programma.richiesta_interfaccia(finestra, vivo.nome, "scegli", [voci, titolo], attesa=600.0)
        if not isinstance(indice, (int, float)) or isinstance(indice, bool) or not 0 <= int(indice) < len(voci):
            return None
        voce = voci[int(indice)]
        scelto = str(base.resolve()) if cartelle and int(indice) == 0 else str((base / voce).resolve())
    vivo.aggiorna_da_interfaccia("percorso", scelto)
    programma.emetti_dopo(vivo.nome, "scelta", {"percorso": scelto})
    return scelto


# --- Video ----------------------------------------------------------------------------------------

def _sorgente_video(programma, vivo) -> str:
    """Il file del Video come indirizzo ``file://`` per il ``<video>`` della pagina ("" se non c'e')."""
    file = str(vivo.modello.proprieta.get("file") or "").strip()
    if not file:
        return ""
    percorso = Path(os.path.expanduser(file))
    if not percorso.is_absolute():
        percorso = _cartella_progetto(programma) / percorso
    if not percorso.is_file():
        programma._avviso(f"`{vivo.nome}`: non trovo il video `{file}` nella cartella del progetto.")
        return ""
    return percorso.resolve().as_uri()


def _video_azione(programma, finestra, vivo, azione: str) -> None:
    if azione == "riproduci" and not str(vivo.modello.proprieta.get("file") or "").strip():
        raise ErroreValore("Non c'è nessun file da riprodurre.", suggerimento="Imposta prima la proprietà `file`.")
    programma.azione_interfaccia(finestra, vivo.nome, azione, [])


# ===========================================================================
# Apertura, chiusura, proprieta' cambiate dal codice
# ===========================================================================

def apertura(programma: "ProgrammaWeb", finestra: "FinestraWeb") -> None:
    """La finestra si e' aperta (i sensori li avvia gia' hardware.apertura)."""
    hw = _hw()
    for vivo in finestra.vivi.values():
        tipo = vivo.tipo_controllo
        p = vivo.modello.proprieta
        if tipo == "StatoRete":
            hw.richiedi(programma, finestra, vivo.nome, {"azione": "rete"}, risposta=True)
            hw.richiedi(programma, finestra, vivo.nome, {"azione": "rete_segui", "attiva": True})
        elif tipo == "OrientamentoSchermo" and str(p.get("blocco") or "libero") != "libero":
            hw.richiedi(programma, finestra, vivo.nome, {"azione": "orientamento_blocca",
                                                        "orientamento": str(p.get("blocco"))})
        elif tipo == "Fonometro" and p.get("attivo"):
            _fonometro(programma, finestra, vivo, True)
        elif tipo == "RegistratoreAudio":
            if p.get("registrando"):
                vivo.aggiorna_da_interfaccia("registrando", False)
            try:
                programma.accoda_proprieta(finestra, vivo, "_cartella", _cartella_registrazioni(programma, vivo))
            except ErroreFile as e:
                programma._avviso(f"`{vivo.nome}`: {e.messaggio if hasattr(e, 'messaggio') else e}")
        elif tipo == "Video":
            programma.accoda_proprieta(finestra, vivo, "_sorgente", _sorgente_video(programma, vivo))
        elif tipo == "Tutor":
            programma.accoda_proprieta(finestra, vivo, "_spiegazioni", spiegazioni_tutor(finestra, vivo))
        elif tipo == "ModuloAutomatico":
            programma.accoda_proprieta(finestra, vivo, "_campi", campi_modulo(p.get("campi")))
        _ricorda(vivo)


def chiusura(programma: "ProgrammaWeb", finestra: "FinestraWeb") -> None:
    hw = _hw()
    for vivo in finestra.vivi.values():
        tipo = vivo.tipo_controllo
        p = vivo.modello.proprieta
        if tipo == "StatoRete":
            hw.richiedi(programma, finestra, vivo.nome, {"azione": "rete_segui", "attiva": False})
        elif tipo == "OrientamentoSchermo" and str(p.get("blocco") or "libero") != "libero":
            hw.richiedi(programma, finestra, vivo.nome, {"azione": "orientamento_blocca", "orientamento": "libero"})
        elif tipo == "Fonometro" and (p.get("attivo") or _stato(vivo).get("acceso")):
            hw.richiedi(programma, finestra, vivo.nome, {"azione": "fonometro_ferma"})
            _stato(vivo)["acceso"] = False
            vivo.aggiorna_da_interfaccia("attivo", False)
        elif tipo == "RegistratoreAudio" and p.get("registrando"):
            hw.richiedi(programma, finestra, vivo.nome, {"azione": "registra_ferma"})


def spiegazioni_tutor(finestra: "FinestraWeb", tutor: "ControlloVivo") -> dict[str, str]:
    """{nome del controllo: testo del fumetto} per i controlli della finestra (come il Tutor del PC)."""
    from ..logica_dante import testo_tutor

    testi = tutor.modello.proprieta.get("testi")
    risultato = {}
    for nome, vivo in finestra.vivi.items():
        if vivo is tutor:
            continue
        tipo = vivo.tipo_controllo
        risultato[nome] = testo_tutor(nome, tipo, testi, getattr(vivo.tipo, "descrizione", ""))
    return risultato


def campi_modulo(campi: Any) -> list[dict]:
    """I campi del ModuloAutomatico gia' capiti da Python (come sul PC: 5.0 e' un decimale, 5 un intero)."""
    from ..logica_dante import campi_da_dizionario

    return [{"nome": f.nome, "etichetta": f.etichetta, "tipo": f.tipo, "valore": f.valore, "scelte": list(f.scelte),
             "minimo": f.minimo, "massimo": f.massimo} for f in campi_da_dizionario(campi)]


#: Proprieta' che fanno partire un evento anche quando le cambia il codice (solo se il valore cambia).
_SEGUITE = {"Cruscotto": ("valore", "soglia_attenzione", "soglia_pericolo"),
            "AnelloAvanzamento": ("valore", "minimo", "massimo"), "Oscilloscopio": ("valori",)}


def _ricorda(vivo: "ControlloVivo") -> None:
    p = vivo.modello.proprieta
    s = _stato(vivo)
    if vivo.tipo_controllo == "Cruscotto":
        s["zona"] = L.zona_cruscotto(p.get("valore"), p.get("soglia_attenzione"), p.get("soglia_pericolo"))
        p["zona"] = s["zona"]
    elif vivo.tipo_controllo == "AnelloAvanzamento":
        s["pieno"] = L.frazione(p.get("valore"), p.get("minimo"), p.get("massimo")) >= 1.0
        p["completato"] = s["pieno"]
    elif vivo.tipo_controllo == "Oscilloscopio":
        valori = p.get("valori") if isinstance(p.get("valori"), list) else []
        s["ultimo"] = valori[-1] if valori else None


def osserva(finestra: "FinestraWeb", vivo: "ControlloVivo", proprieta: str, valore: Any) -> None:
    """Il codice ha cambiato una proprieta'."""
    tipo = vivo.tipo_controllo
    p = finestra.programma
    prop = vivo.modello.proprieta
    s = _stato(vivo)
    if proprieta in _SEGUITE.get(tipo, ()):
        if tipo == "Cruscotto":
            zona = L.zona_cruscotto(prop.get("valore"), prop.get("soglia_attenzione"), prop.get("soglia_pericolo"))
            if zona != s.get("zona", "normale"):
                s["zona"] = zona
                _imposta(p, finestra, vivo, "zona", zona)
                p.emetti_dopo(vivo.nome, "cambio_zona", {"zona": zona, "valore": prop.get("valore")})
        elif tipo == "AnelloAvanzamento":
            pieno = L.frazione(prop.get("valore"), prop.get("minimo"), prop.get("massimo")) >= 1.0
            if pieno != s.get("pieno", False):
                s["pieno"] = pieno
                _imposta(p, finestra, vivo, "completato", pieno)
                if pieno:
                    p.emetti_dopo(vivo.nome, "completato", {"valore": prop.get("valore")})
        elif tipo == "Oscilloscopio":
            valori = valore if isinstance(valore, list) else []
            nuovo = valori[-1] if valori else None
            if isinstance(nuovo, (int, float)) and not isinstance(nuovo, bool):
                from ..logica_dante import soglia_superata

                prima = s.get("ultimo")
                if soglia_superata(prima if isinstance(prima, (int, float)) else None, nuovo,
                                   _num(prop.get("soglia"), 80.0)):
                    p.emetti_dopo(vivo.nome, "soglia_superata", {"valore": nuovo})
            s["ultimo"] = nuovo
        return
    if not finestra.aperta:
        return
    hw = _hw()
    if tipo == "Fonometro" and proprieta == "attivo" and bool(valore) != bool(s.get("acceso")):
        _fonometro(p, finestra, vivo, bool(valore))
    elif tipo == "OrientamentoSchermo" and proprieta == "blocco":
        hw.richiedi(p, finestra, vivo.nome, {"azione": "orientamento_blocca", "orientamento": str(valore or "libero")})
    elif tipo == "Video" and proprieta == "file":
        p.accoda_proprieta(finestra, vivo, "_sorgente", _sorgente_video(p, vivo))
    elif tipo == "ModuloAutomatico" and proprieta == "campi":
        p.accoda_proprieta(finestra, vivo, "_campi", campi_modulo(valore))
    elif tipo == "Tutor" and proprieta == "testi":
        p.accoda_proprieta(finestra, vivo, "_spiegazioni", spiegazioni_tutor(finestra, vivo))
    elif tipo == "RegistratoreAudio" and proprieta == "cartella":
        p.accoda_proprieta(finestra, vivo, "_cartella", _cartella_registrazioni(p, vivo))


# ===========================================================================
# Letture dei sensori ed eventi del telefono
# ===========================================================================

def lettura(programma, finestra, vivo, sensore: str, valori: list[float]) -> None:
    """Una lettura del sensore dell'oggetto (gia' al suo ritmo, vedi hardware._lettura)."""
    tipo = vivo.tipo_controllo
    s = _stato(vivo)
    p = vivo.modello.proprieta
    if tipo == "Contapassi":
        grezzo = int(valori[0])
        s["ultimo"] = grezzo
        if s.get("base") is None:
            s["base"] = grezzo - int(p.get("passi") or 0)
        passi = max(0, grezzo - int(s["base"]))
        if passi == p.get("passi") and "distanza" in s:
            return
        distanza = L.distanza_passi(passi, p.get("lunghezza_passo", 0.7))
        s["distanza"] = distanza
        _imposta(programma, finestra, vivo, "passi", passi)
        _imposta(programma, finestra, vivo, "distanza", distanza)
        _emetti(programma, finestra, vivo.nome, "cambio", {"passi": passi, "distanza": distanza})
        obiettivo = max(1, int(p.get("obiettivo") or 1))
        if passi >= obiettivo and not s.get("raggiunto"):
            s["raggiunto"] = True
            _emetti(programma, finestra, vivo.nome, "obiettivo_raggiunto", {"passi": passi})
        elif passi < obiettivo:
            s["raggiunto"] = False
    elif tipo == "SensoreLuce":
        luce = round(max(0.0, valori[0]), 1)
        livello = L.livello_luce(luce)
        prima = p.get("luce")
        if isinstance(prima, (int, float)) and abs(prima - luce) < max(0.5, prima * 0.02) and "letta" in s:
            return
        s["letta"] = True
        soglia = _num(p.get("soglia_buio"), 10.0)
        era_buio = s.get("buio")
        buio = luce < soglia
        _imposta(programma, finestra, vivo, "luce", luce)
        _imposta(programma, finestra, vivo, "livello", livello)
        _emetti(programma, finestra, vivo.nome, "cambio", {"luce": luce, "livello": livello})
        if era_buio is not None and buio != era_buio:
            _emetti(programma, finestra, vivo.nome, "buio" if buio else "luce", {"luce": luce})
        elif era_buio is None and buio:
            _emetti(programma, finestra, vivo.nome, "buio", {"luce": luce})
        s["buio"] = buio
    elif tipo == "SensoreProssimità":
        distanza = round(max(0.0, valori[0]), 1)
        # molti telefoni dicono solo 0 (vicino) o il massimo (lontano): vicino = meno di 3 cm
        vicino = distanza < 3.0
        prima = s.get("vicino")
        _imposta(programma, finestra, vivo, "distanza", distanza)
        if prima == vicino:
            return
        s["vicino"] = vicino
        _imposta(programma, finestra, vivo, "vicino", vicino)
        if prima is not None or vicino:
            _emetti(programma, finestra, vivo.nome, "avvicinamento" if vicino else "allontanamento",
                    {"distanza": distanza})
    elif tipo == "Barometro":
        pressione = round(valori[0], 1)
        adesso = time.monotonic()
        storia = s.setdefault("storia", [])
        storia.append((adesso, pressione))
        while storia and adesso - storia[0][0] > MEMORIA_BAROMETRO:
            storia.pop(0)
        altitudine = L.altitudine_da_pressione(pressione, p.get("pressione_mare", 1013.25))
        tendenza = L.tendenza_pressione(storia)
        prima = (p.get("pressione"), p.get("tendenza"))
        if prima == (pressione, tendenza) and "letta" in s:
            return
        s["letta"] = True
        _imposta(programma, finestra, vivo, "pressione", pressione)
        _imposta(programma, finestra, vivo, "altitudine", altitudine)
        _imposta(programma, finestra, vivo, "tendenza", tendenza)
        _emetti(programma, finestra, vivo.nome, "cambio", {"pressione": pressione, "altitudine": altitudine,
                                                          "tendenza": tendenza})
    elif tipo == "Movimento":
        if len(valori) < 3:
            return
        rilevatore = s.get("rilevatore")
        if rilevatore is None:
            rilevatore = s["rilevatore"] = L.RilevatoreScosse()
            rilevatore.scosse = int(p.get("scosse") or 0)
        forza = rilevatore.lettura(valori[0], valori[1], valori[2], time.monotonic(),
                                   str(p.get("sensibilita") or "media"))
        if forza is None:
            return
        _imposta(programma, finestra, vivo, "scosse", rilevatore.scosse)
        _imposta(programma, finestra, vivo, "forza", forza)
        _emetti(programma, finestra, vivo.nome, "scossa", {"forza": forza, "scosse": rilevatore.scosse})


def _rete(programma, finestra, vivo, r: dict) -> None:
    if "connesso" not in r:
        return
    connesso = bool(r.get("connesso"))
    tipo = str(r.get("tipo_rete") or r.get("rete") or ("nessuna" if not connesso else "altro"))
    a_consumo = bool(r.get("a_consumo", False))
    cambiato = _imposta(programma, finestra, vivo, "connesso", connesso)
    cambiato = _imposta(programma, finestra, vivo, "tipo_rete", tipo) or cambiato
    _imposta(programma, finestra, vivo, "a_consumo", a_consumo)
    s = _stato(vivo)
    if cambiato or not s.get("letta"):
        if s.get("letta"):
            programma.emetti_dopo(vivo.nome, "cambio", {"connesso": connesso, "tipo_rete": tipo})
        s["letta"] = True


def risposta(programma, finestra, vivo, r: dict) -> bool:
    """Risposta immediata del telefono (vero se gestita qui)."""
    if vivo.tipo_controllo == "StatoRete" and r.get("ok") is not False and r.get("azione") == "rete":
        _rete(programma, finestra, vivo, r)
        return True
    if r.get("ok") is False:
        messaggio = str(r.get("errore") or "il telefono non ha potuto farlo")
        if vivo.tipo_controllo == "Fonometro":
            _stato(vivo)["acceso"] = False
            _imposta(programma, finestra, vivo, "attivo", False)
        elif vivo.tipo_controllo == "RegistratoreAudio":
            _imposta(programma, finestra, vivo, "registrando", False)
            _emetti(programma, finestra, vivo.nome, "errore", {"messaggio": messaggio})
        programma._avviso(f"`{vivo.nome}`: {messaggio}")
        return True
    return False


def gestisci(programma, finestra, vivo, tipo: str, evento: dict) -> None:
    """Un evento del telefono per un oggetto di questo modulo."""
    t = vivo.tipo_controllo
    if tipo == "errore":
        messaggio = _hw()._errore(programma, finestra, vivo, evento)
        if t == "Fonometro":
            _stato(vivo)["acceso"] = False
            _imposta(programma, finestra, vivo, "attivo", False)
        elif t == "RegistratoreAudio":
            _imposta(programma, finestra, vivo, "registrando", False)
            _emetti(programma, finestra, vivo.nome, "errore", {"messaggio": messaggio})
        return
    if t == "Fonometro" and tipo == "fonometro":
        livello = round(max(0.0, min(140.0, _num(evento.get("decibel")))), 1)
        p = vivo.modello.proprieta
        s = _stato(vivo)
        if not s.get("acceso"):
            s["acceso"] = True
            _imposta(programma, finestra, vivo, "attivo", True)
        _imposta(programma, finestra, vivo, "livello", livello)
        if livello > _num(p.get("massimo"), 0.0):
            _imposta(programma, finestra, vivo, "massimo", livello)
        _emetti(programma, finestra, vivo.nome, "cambio", {"livello": livello})
        soglia = _num(p.get("soglia"), 85.0)
        sopra = livello >= soglia
        if sopra and not s.get("sopra"):
            _emetti(programma, finestra, vivo.nome, "troppo_rumore", {"livello": livello})
        s["sopra"] = sopra
    elif t == "RegistratoreAudio":
        if tipo == "registrazione_inizio":
            _imposta(programma, finestra, vivo, "registrando", True)
        elif tipo == "registrazione_fine":
            file = str(evento.get("file") or "")
            durata = round(max(0.0, _num(evento.get("durata"))), 1)
            _imposta(programma, finestra, vivo, "registrando", False)
            if file:
                _imposta(programma, finestra, vivo, "ultimo_file", file)
                _imposta(programma, finestra, vivo, "durata", durata)
                _emetti(programma, finestra, vivo.nome, "fine_registrazione", {"file": file, "durata": durata})
    elif t == "StatoRete" and tipo == "rete":
        _rete(programma, finestra, vivo, evento)


__all__ = ["TIPI", "TIPI_NUOVI", "TIPI_PORTATI", "SENSORI", "azioni", "apertura", "chiusura", "osserva",
           "lettura", "gestisci", "risposta", "intervallo", "spiegazioni_tutor", "estensioni_filtro",
           "file_del_progetto"]
