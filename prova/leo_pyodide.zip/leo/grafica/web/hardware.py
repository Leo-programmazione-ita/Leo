"""L'hardware del telefono nei programmi con finestre (motore web, senza Qt).

Il motore Python non parla con Android: manda alla pagina il messaggio
``{"op": "hardware", "f": finestra, "c": controllo, "richiesta": {...}}`` e ``finestre.js`` lo passa a
``window.Leo.hardware``; gli eventi del telefono (letture dei sensori, foto scattata, frase
riconosciuta...) tornano come ``{"tipo": "hardware", "f", "c", "evento": {...}}``. Qui questi eventi
diventano proprieta' aggiornate ed eventi Leo (``quando Bussola1.cambio fai``).
Contratto: ``android/CONTRATTO.md``, sezione "Hardware del telefono".

Il programma (:class:`~leo.grafica.web.programma.ProgrammaWeb`) usa quattro funzioni:

* :func:`azioni`: i metodi dei controlli che parlano con il telefono (``Voce1.leggi``...);
* :func:`apertura` / :func:`chiusura`: sensori, bussola, livella e batteria partono da soli quando
  la finestra si apre e si fermano quando si chiude;
* :func:`osserva`: il codice ha cambiato una proprieta' (``Sensore1.tipo_sensore``, ``Fotocamera1.attiva``);
* :func:`gestisci_evento`: un evento del telefono.

Piu' controlli possono usare lo stesso sensore (una Livella e un Sensore "accelerometro"): il
sensore si avvia una volta sola (con l'intervallo piu' breve) e ogni controllo riceve le letture
al suo ritmo; si ferma quando l'ultimo controllo che lo usa smette.
"""

from __future__ import annotations

import math
import os
import time
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

from ...errori import ErroreFile, ErroreValore

if TYPE_CHECKING:  # pragma: no cover
    from ..modello import ControlloVivo
    from .programma import FinestraWeb, ProgrammaWeb

#: Controlli che usano l'hardware del telefono (le loro azioni passano da qui).
TIPI_HARDWARE = frozenset({"Sensore", "Fotocamera", "LettoreQR", "Dettatura", "Voce", "Suono", "Notifica",
                           "Bussola", "Livella", "Vibrazione", "Torcia", "Posizione", "Batteria", "Condivisione"})

#: Sensori del telefono (nomi del contratto) e unita' di misura dei valori.
UNITA_SENSORI: dict[str, str] = {
    "accelerometro": "m/s²", "giroscopio": "°/s", "bussola": "°", "magnetometro": "µT", "luce": "lx",
    "prossimita": "cm", "pressione": "hPa", "passi": "passi", "gravita": "m/s²", "orientamento": "°",
}
#: Sensori con tre valori (x, y, z): ``valore`` e' quanto e' forte (la lunghezza del vettore).
SENSORI_XYZ = frozenset({"accelerometro", "giroscopio", "magnetometro", "gravita"})
#: ``tipo_sensore`` di Leo -> sensore del telefono ("distanza" della Pico = prossimita' del telefono).
_SENSORE_TELEFONO = {**{k: k for k in UNITA_SENSORI}, "distanza": "prossimita"}

#: Nome di controllo ("c") delle richieste dei sensori: uno solo per sensore, qualunque controllo lo usi
#: (sul telefono un sensore e' uno per nome e per ``c``; le letture vanno poi ai controlli iscritti).
C_SENSORI = "_sensori"
#: Ogni quanti secondi si rilegge la batteria mentre la finestra e' aperta.
INTERVALLO_BATTERIA = 60.0
#: Attesa massima della risposta del telefono per i metodi che la aspettano (secondi).
ATTESA_RISPOSTA = 5.0
#: Gravita' terrestre (m/s²), per la livella.
_G = 9.80665


# ===========================================================================
# Stato (uno per programma)
# ===========================================================================

class _Iscritto:
    """Un controllo che riceve le letture di un sensore."""

    __slots__ = ("finestra", "nome", "intervallo", "ultimo")

    def __init__(self, finestra: str, nome: str, intervallo: int) -> None:
        self.finestra = finestra
        self.nome = nome
        self.intervallo = max(10, int(intervallo))
        self.ultimo = 0.0


class StatoHardware:
    """Sensori avviati, risposte attese, letture della voce e temporizzatori della batteria."""

    def __init__(self) -> None:
        self.iscritti: dict[str, list[_Iscritto]] = {}      # sensore -> controlli che lo usano
        self.avviati: dict[str, int] = {}                   # sensore -> intervallo chiesto al telefono
        self.risposte: dict[int, dict] = {}                 # id -> risposta del telefono (metodi che aspettano)
        self.letture: dict[tuple[str, str], int] = {}       # (finestra, Voce) -> id della lettura in corso
        self.suoni: dict[tuple[str, str], int] = {}         # (finestra, Suono) -> id della riproduzione
        self.batterie: dict[str, Any] = {}                  # finestra -> temporizzatore della batteria
        self.sensori_id: dict[int, str] = {}                # id di `sensore_avvia` -> sensore (per gli errori)
        self.numero = 0

    def nuovo_id(self) -> int:
        self.numero += 1
        return self.numero


def stato(programma: "ProgrammaWeb") -> StatoHardware:
    s = getattr(programma, "_stato_hardware", None)
    if s is None:
        s = StatoHardware()
        programma._stato_hardware = s
    return s


# ===========================================================================
# Richieste verso il telefono
# ===========================================================================

def richiedi(programma: "ProgrammaWeb", finestra: "FinestraWeb", controllo: str, richiesta: dict, *,
             aspetta: bool = False, risposta: bool = False, attesa: float = ATTESA_RISPOSTA) -> dict | None:
    """Manda una richiesta al telefono; con ``aspetta`` restituisce la risposta (None se non arriva).

    ``risposta``: la pagina rimanda la risposta come evento anche senza aspettarla (batteria).
    Intanto che si aspetta, gli altri eventi (tocchi, letture) restano in coda per dopo.
    """
    s = stato(programma)
    numero = s.nuovo_id()
    r = dict(richiesta)
    r["id"] = numero
    messaggio: dict[str, Any] = {"op": "hardware", "f": finestra.nome, "c": controllo, "richiesta": r}
    if aspetta or risposta:
        messaggio["risposta"] = True
    programma.accoda(messaggio)
    if not aspetta:
        return None
    programma.svuota()
    return programma.aspetta_risposta(lambda: s.risposte.pop(numero, None), attesa)


def _sensore_di(vivo: "ControlloVivo") -> str | None:
    """Il sensore del telefono che serve al controllo (None se sul telefono non c'e')."""
    tipo = vivo.tipo_controllo
    if tipo == "Bussola":
        return "bussola"
    if tipo == "Livella":
        return "accelerometro"
    if tipo == "Sensore":
        return _SENSORE_TELEFONO.get(str(vivo.modello.proprieta.get("tipo_sensore") or ""))
    return _dati.SENSORI.get(tipo)


def _intervallo(vivo: "ControlloVivo") -> int:
    if vivo.tipo_controllo in _dati.SENSORI:
        return _dati.intervallo(vivo)
    try:
        return max(20, int(vivo.modello.proprieta.get("intervallo", 100) or 100))
    except (TypeError, ValueError):
        return 100


def _iscrivi(programma: "ProgrammaWeb", finestra: "FinestraWeb", vivo: "ControlloVivo") -> None:
    sensore = _sensore_di(vivo)
    if vivo.tipo_controllo == "Sensore":
        if sensore is None:
            tipo = str(vivo.modello.proprieta.get("tipo_sensore") or "")
            _nota(programma, finestra, vivo, f"«{tipo}» sul telefono non c'è")
            _imposta(programma, finestra, vivo, "unita", "")
            programma._avviso(f"`{vivo.nome}`: sul telefono il sensore \"{tipo}\" non c'è (serve la scheda Pico). "
                              "Sensori del telefono: " + ", ".join(UNITA_SENSORI) + ".")
            return
        _nota(programma, finestra, vivo, "")
        _imposta(programma, finestra, vivo, "unita", UNITA_SENSORI[sensore])
    if sensore is None:
        return
    s = stato(programma)
    lista = s.iscritti.setdefault(sensore, [])
    lista[:] = [i for i in lista if (i.finestra, i.nome) != (finestra.nome, vivo.nome)]
    iscritto = _Iscritto(finestra.nome, vivo.nome, _intervallo(vivo) if vivo.tipo_controllo != "Sensore"
                         else max(20, _intero(vivo.modello.proprieta.get("intervallo"), 1000)))
    lista.append(iscritto)
    minimo = min(i.intervallo for i in lista)
    if s.avviati.get(sensore) != minimo:
        s.avviati[sensore] = minimo
        richiedi(programma, finestra, C_SENSORI, {"azione": "sensore_avvia", "sensore": sensore,
                                                  "intervallo_ms": minimo})
        s.sensori_id[s.numero] = sensore


def _disiscrivi(programma: "ProgrammaWeb", finestra: "FinestraWeb", nome: str) -> None:
    s = stato(programma)
    for sensore, lista in list(s.iscritti.items()):
        prima = len(lista)
        lista[:] = [i for i in lista if (i.finestra, i.nome) != (finestra.nome, nome)]
        if len(lista) == prima:
            continue
        if not lista:
            del s.iscritti[sensore]
            s.avviati.pop(sensore, None)
            richiedi(programma, finestra, C_SENSORI, {"azione": "sensore_ferma", "sensore": sensore})


def _intero(v: Any, predefinito: int) -> int:
    try:
        return int(v)
    except (TypeError, ValueError):
        return predefinito


# ===========================================================================
# Proprieta' ed eventi
# ===========================================================================

def _imposta(programma: "ProgrammaWeb", finestra: "FinestraWeb", vivo: "ControlloVivo", proprieta: str,
             valore: Any) -> bool:
    """Proprieta' che cambia per il telefono: nel modello e sullo schermo. Vero se e' cambiata."""
    if vivo.modello.proprieta.get(proprieta) == valore and proprieta in vivo.modello.proprieta:
        return False
    vivo.aggiorna_da_interfaccia(proprieta, valore)
    if finestra.costruita:
        programma.accoda_proprieta(finestra, vivo, proprieta, valore)
    return True


def _nota(programma: "ProgrammaWeb", finestra: "FinestraWeb", vivo: "ControlloVivo", testo: str) -> None:
    """Scritta di servizio sul controllo (``_nota``: "non c'e' sul telefono"), solo per il disegno."""
    if finestra.costruita:
        programma.accoda_proprieta(finestra, vivo, "_nota", testo)


def _emetti(programma: "ProgrammaWeb", finestra: "FinestraWeb", nome: str, evento: str, dati: dict) -> None:
    programma.emetti_evento(nome, evento, dati, finestra=finestra.nome)


def _numero(v: Any, predefinito: float = 0.0) -> float:
    try:
        n = float(v)
    except (TypeError, ValueError):
        return predefinito
    return n if math.isfinite(n) else predefinito


# ===========================================================================
# Azioni (metodi dei controlli)
# ===========================================================================

def azioni(finestra: "FinestraWeb", vivo: "ControlloVivo") -> dict[str, Callable[..., Any]]:
    """I metodi del controllo che vanno al telefono (tabella ``azione -> funzione(*argomenti)``)."""
    tipo = vivo.tipo_controllo
    if tipo not in TIPI_HARDWARE:
        return {}
    if tipo in _dati.TIPI:
        return _dati.azioni(finestra, vivo)
    p = finestra.programma
    nome = vivo.nome
    prop = vivo.modello.proprieta

    def manda(richiesta: dict, **opzioni: Any) -> dict | None:
        return richiedi(p, finestra, nome, richiesta, **opzioni)

    tabella: dict[str, Callable[..., Any]] = {}
    if tipo == "Vibrazione":
        tabella["vibra"] = lambda ms=300: manda({"azione": "vibra", "ms": int(ms)})
        tabella["schema"] = lambda schema: manda({"azione": "vibra", "schema": [int(x) for x in schema]})
    elif tipo == "Torcia":
        def torcia(accesa: bool) -> bool:
            r = manda({"azione": "torcia", "accesa": accesa}, aspetta=True)
            riuscita = bool(r and r.get("ok"))
            if riuscita:
                _imposta(p, finestra, vivo, "accesa", accesa)
            return riuscita
        tabella["accendi"] = lambda: torcia(True)
        tabella["spegni"] = lambda: torcia(False)
    elif tipo == "Posizione":
        def avvia() -> None:
            _imposta(p, finestra, vivo, "attiva", True)
            manda({"azione": "posizione_avvia", "continua": bool(prop.get("continua", True)),
                   "precisa": bool(prop.get("precisa", True))})

        def ferma() -> None:
            if prop.get("attiva"):
                manda({"azione": "posizione_ferma"})
            _imposta(p, finestra, vivo, "attiva", False)
        tabella["avvia"] = avvia
        tabella["ferma"] = ferma
    elif tipo == "Batteria":
        def aggiorna() -> int:
            r = manda({"azione": "batteria"}, aspetta=True)
            if r:
                _batteria(p, finestra, vivo, r)
            return int(prop.get("livello", -1))
        tabella["aggiorna"] = aggiorna
    elif tipo == "Condivisione":
        tabella["condividi"] = lambda testo: manda({"azione": "condividi", "testo": str(testo)})
    elif tipo == "Voce":
        def leggi(testo: str) -> None:
            manda({"azione": "parla", "testo": str(testo), "velocita": _intero(prop.get("velocita"), 0),
                   "lingua": "it-IT"})
            stato(p).letture[(finestra.nome, nome)] = stato(p).numero      # id della richiesta appena mandata

        def ferma_voce() -> None:
            stato(p).letture.pop((finestra.nome, nome), None)
            manda({"azione": "parla_ferma"})
        tabella["leggi"] = leggi
        tabella["ferma"] = ferma_voce
    elif tipo == "Suono":
        def riproduci() -> None:
            percorso = _file_progetto(p, str(prop.get("file") or ""))
            volume = max(0, min(100, _intero(prop.get("volume"), 100)))
            manda({"azione": "suono", "file": percorso, "volume": volume / 100,
                   "ripeti": bool(prop.get("ripeti", False))})
            stato(p).suoni[(finestra.nome, nome)] = stato(p).numero

        def ferma_suono() -> None:
            stato(p).suoni.pop((finestra.nome, nome), None)
            manda({"azione": "suono_ferma"})
        tabella["riproduci"] = riproduci
        tabella["pausa"] = ferma_suono          # sul telefono la pausa ferma il suono
        tabella["ferma"] = ferma_suono
    elif tipo == "Dettatura":
        def ascolta() -> None:
            _imposta(p, finestra, vivo, "in_ascolto", True)
            manda({"azione": "ascolta", "lingua": str(prop.get("lingua") or "it-IT")})

        def ferma_ascolto() -> None:
            _imposta(p, finestra, vivo, "in_ascolto", False)
        tabella["ascolta"] = ascolta
        tabella["ferma"] = ferma_ascolto
    elif tipo == "Fotocamera":
        def scatta(_percorso: str = "") -> None:
            _imposta(p, finestra, vivo, "attiva", True)
            manda({"azione": "foto", "anteriore": bool(prop.get("anteriore", False))})
        tabella["scatta"] = scatta
    elif tipo == "Sensore":
        tabella["leggi"] = lambda: prop.get("valore", 0.0)
    elif tipo == "Notifica":
        def mostra(testo: Any = None) -> None:
            t = str(prop.get("testo") or "") if testo is None else str(testo)
            p.azione_interfaccia(finestra, nome, "mostra", [t] if testo is not None else [])
            manda({"azione": "notifica", "titolo": str(prop.get("titolo") or "Leo"), "testo": t})
        tabella["mostra"] = mostra
    return tabella


def _file_progetto(programma: "ProgrammaWeb", file: str) -> str:
    """Percorso vero di un file del progetto (per Android)."""
    if not file.strip():
        raise ErroreValore("Il Suono non ha un file: imposta prima la proprietà `file`.")
    if file.strip().lower().startswith("galleria:"):
        from ...galleria import risolvi                  # errori chiari: nome sbagliato, extra non scaricato...

        return str(risolvi(file, programma.cartella))
    percorso = Path(os.path.expanduser(file))
    if not percorso.is_absolute():
        percorso = Path(programma.cartella) / percorso
    if not percorso.is_file():
        raise ErroreFile(f"Non trovo il file del suono `{file}`.",
                         suggerimento="Metti il file nella cartella del progetto e scrivi il suo nome in `file`.")
    return str(percorso.resolve())


# ===========================================================================
# Apertura e chiusura della finestra, proprieta' cambiate dal codice
# ===========================================================================

def apertura(programma: "ProgrammaWeb", finestra: "FinestraWeb") -> None:
    """La finestra si e' aperta: partono sensori, bussole, livelle e la lettura della batteria."""
    batterie = False
    for vivo in finestra.vivi.values():
        if vivo.tipo_controllo in _CON_SENSORE:
            _iscrivi(programma, finestra, vivo)
        elif vivo.tipo_controllo == "Batteria":
            batterie = True
            richiedi(programma, finestra, vivo.nome, {"azione": "batteria"}, risposta=True)
        elif vivo.tipo_controllo == "Fotocamera" and vivo.modello.proprieta.get("attiva"):
            vivo.aggiorna_da_interfaccia("attiva", False)          # sul telefono niente anteprima continua
        elif vivo.tipo_controllo == "LettoreQR" and vivo.modello.proprieta.get("attivo"):
            vivo.aggiorna_da_interfaccia("attivo", False)
    if batterie:
        s = stato(programma)
        vecchio = s.batterie.pop(finestra.nome, None)
        if vecchio is not None:
            vecchio.stop()

        def rileggi() -> None:
            if not finestra.aperta:
                return
            for v in finestra.vivi.values():
                if v.tipo_controllo == "Batteria":
                    richiedi(programma, finestra, v.nome, {"azione": "batteria"}, risposta=True)
            programma.svuota()
        s.batterie[finestra.nome] = programma.pianificatore.aggiungi(INTERVALLO_BATTERIA, rileggi, ripeti=True)
    _dati.apertura(programma, finestra)


def chiusura(programma: "ProgrammaWeb", finestra: "FinestraWeb") -> None:
    """La finestra si chiude: si ferma tutto cio' che i suoi controlli avevano acceso."""
    s = stato(programma)
    voce = s.batterie.pop(finestra.nome, None)
    if voce is not None:
        voce.stop()
    for vivo in finestra.vivi.values():
        tipo = vivo.tipo_controllo
        p = vivo.modello.proprieta
        if tipo in _CON_SENSORE:
            _disiscrivi(programma, finestra, vivo.nome)
        elif tipo == "Posizione" and p.get("attiva"):
            richiedi(programma, finestra, vivo.nome, {"azione": "posizione_ferma"})
            vivo.aggiorna_da_interfaccia("attiva", False)
        elif tipo == "Torcia" and p.get("accesa"):
            richiedi(programma, finestra, vivo.nome, {"azione": "torcia", "accesa": False})
            vivo.aggiorna_da_interfaccia("accesa", False)
        elif tipo == "Voce" and s.letture.pop((finestra.nome, vivo.nome), None) is not None:
            richiedi(programma, finestra, vivo.nome, {"azione": "parla_ferma"})
        elif tipo == "Suono" and s.suoni.pop((finestra.nome, vivo.nome), None) is not None:
            richiedi(programma, finestra, vivo.nome, {"azione": "suono_ferma"})
    _dati.chiusura(programma, finestra)


def osserva(finestra: "FinestraWeb", vivo: "ControlloVivo", proprieta: str, valore: Any) -> None:
    """Il codice ha cambiato una proprieta' di un controllo dell'hardware."""
    tipo = vivo.tipo_controllo
    p = finestra.programma
    if tipo in _dati.TIPI:
        _dati.osserva(finestra, vivo, proprieta, valore)
    if tipo in _CON_SENSORE and proprieta in ("tipo_sensore", "intervallo"):
        if finestra.aperta:
            _disiscrivi(p, finestra, vivo.nome)
            _iscrivi(p, finestra, vivo)
    elif tipo == "Fotocamera" and proprieta == "attiva" and valore is True and finestra.aperta:
        richiedi(p, finestra, vivo.nome, {"azione": "foto",
                                          "anteriore": bool(vivo.modello.proprieta.get("anteriore", False))})
    elif tipo == "LettoreQR" and proprieta == "attivo" and valore is True and finestra.aperta:
        richiedi(p, finestra, vivo.nome, {"azione": "scansiona"})


# ===========================================================================
# Eventi dal telefono
# ===========================================================================

def gestisci_evento(programma: "ProgrammaWeb", finestra: "FinestraWeb", ev: dict) -> None:
    """``{"tipo": "hardware", "f", "c", "evento": {"tipo": ..., ...}}`` arrivato dalla pagina."""
    evento = ev.get("evento")
    if not isinstance(evento, dict):
        return
    tipo = str(evento.get("tipo") or "")
    s = stato(programma)
    nome = str(ev.get("c") or "")
    vivo = finestra.vivi.get(nome)
    if tipo == "risposta":
        try:
            numero = int(evento.get("id"))
        except (TypeError, ValueError):
            numero = None
        if numero is not None:
            s.risposte[numero] = evento
            if len(s.risposte) > 50:                       # risposte che nessuno aspetta piu'
                for k in sorted(s.risposte)[:-50]:
                    del s.risposte[k]
        if vivo is not None:
            _risposta(programma, finestra, vivo, evento)
        return
    if tipo == "sensore":
        _lettura(programma, finestra, evento)
        return
    if tipo == "errore" and evento.get("azione") == "sensore_avvia":
        _errore_sensore(programma, evento)
        return
    if vivo is None:
        return
    gestore = _GESTORI.get(vivo.tipo_controllo)
    if gestore is not None:
        gestore(programma, finestra, vivo, tipo, evento)
    elif vivo.tipo_controllo in _dati.TIPI:
        _dati.gestisci(programma, finestra, vivo, tipo, evento)


def _risposta(programma: "ProgrammaWeb", finestra: "FinestraWeb", vivo: "ControlloVivo", r: dict) -> None:
    """Risposta immediata del telefono: la batteria, oppure un errore (niente flash, sensore mancante...)."""
    if vivo.tipo_controllo in _dati.TIPI and _dati.risposta(programma, finestra, vivo, r):
        return
    if vivo.tipo_controllo == "Batteria" and r.get("ok") is not False:
        _batteria(programma, finestra, vivo, r)
        return
    if r.get("ok") is False:
        messaggio = str(r.get("errore") or "il telefono non ha potuto farlo")
        programma._avviso(f"`{vivo.nome}`: {messaggio}")
        if vivo.tipo_controllo == "Sensore":
            _nota(programma, finestra, vivo, messaggio)
        elif vivo.tipo_controllo == "Posizione":
            _imposta(programma, finestra, vivo, "attiva", False)
            _emetti(programma, finestra, vivo.nome, "errore", {"messaggio": messaggio})
        elif vivo.tipo_controllo == "Dettatura":
            _imposta(programma, finestra, vivo, "in_ascolto", False)
        elif vivo.tipo_controllo == "Fotocamera":
            _imposta(programma, finestra, vivo, "attiva", False)
        elif vivo.tipo_controllo == "LettoreQR":
            _imposta(programma, finestra, vivo, "attivo", False)


def _batteria(programma: "ProgrammaWeb", finestra: "FinestraWeb", vivo: "ControlloVivo", r: dict) -> None:
    if "livello" not in r:
        return
    livello = max(0, min(100, int(round(_numero(r.get("livello"), 0)))))
    in_carica = bool(r.get("in_carica", False))
    cambiato = _imposta(programma, finestra, vivo, "livello", livello)
    cambiato = _imposta(programma, finestra, vivo, "in_carica", in_carica) or cambiato
    if cambiato:
        programma.emetti_dopo(vivo.nome, "cambio", {"livello": livello, "in_carica": in_carica})


# --- sensori ------------------------------------------------------------------------------

def _lettura(programma: "ProgrammaWeb", finestra_evento: "FinestraWeb", evento: dict) -> None:
    sensore = str(evento.get("sensore") or "")
    valori = [_numero(v) for v in evento.get("valori") or [] if isinstance(v, (int, float))]
    if not valori:
        return
    adesso = time.monotonic() * 1000
    for iscritto in list(stato(programma).iscritti.get(sensore, [])):
        finestra = programma.finestre.get(iscritto.finestra)
        vivo = finestra.vivi.get(iscritto.nome) if finestra is not None else None
        if vivo is None or not finestra.aperta:
            continue
        # al ritmo del controllo (un po' di margine: le letture non arrivano precise al millisecondo)
        if adesso - iscritto.ultimo < iscritto.intervallo * 0.8:
            continue
        iscritto.ultimo = adesso
        if vivo.tipo_controllo == "Sensore":
            _lettura_sensore(programma, finestra, vivo, sensore, valori)
        elif vivo.tipo_controllo == "Bussola":
            _lettura_bussola(programma, finestra, vivo, valori)
        elif vivo.tipo_controllo == "Livella":
            _lettura_livella(programma, finestra, vivo, valori)
        elif vivo.tipo_controllo in _dati.SENSORI:
            _dati.lettura(programma, finestra, vivo, sensore, valori)


def _errore_sensore(programma: "ProgrammaWeb", evento: dict) -> None:
    """Il telefono non ha il sensore (o non lo sa avviare): lo dicono tutti i controlli che lo usano."""
    s = stato(programma)
    messaggio = str(evento.get("errore") or "sensore non disponibile")
    try:
        sensore = s.sensori_id.get(int(evento.get("id")))
    except (TypeError, ValueError):
        sensore = None
    programma._avviso(messaggio)
    if sensore is None:
        return
    s.avviati.pop(sensore, None)             # un nuovo avvio (tipo_sensore cambiato) riprova
    for iscritto in s.iscritti.get(sensore, []):
        finestra = programma.finestre.get(iscritto.finestra)
        vivo = finestra.vivi.get(iscritto.nome) if finestra is not None else None
        if vivo is not None:
            _nota(programma, finestra, vivo, messaggio)


def dati_sensore(sensore: str, valori: list[float]) -> dict:
    """``{valore, x, y, z}`` di una lettura (per i sensori con tre assi ``valore`` e' la lunghezza)."""
    x = valori[0] if valori else 0.0
    y = valori[1] if len(valori) > 1 else 0.0
    z = valori[2] if len(valori) > 2 else 0.0
    if sensore in SENSORI_XYZ:
        valore = math.sqrt(x * x + y * y + z * z)
    elif sensore == "bussola":
        valore = x % 360
    else:
        valore = x
    return {"valore": round(valore, 3), "x": round(x, 3), "y": round(y, 3), "z": round(z, 3)}


def _lettura_sensore(programma, finestra, vivo, sensore: str, valori: list[float]) -> None:
    dati = dati_sensore(sensore, valori)
    for k, v in dati.items():
        _imposta(programma, finestra, vivo, k, v)
    _emetti(programma, finestra, vivo.nome, "lettura", dati)


def _lettura_bussola(programma, finestra, vivo, valori: list[float]) -> None:
    from ..catalogo_telefono import punto_cardinale

    direzione = round(valori[0] % 360, 1)
    prima = _numero(vivo.modello.proprieta.get("direzione"), -999.0)
    diff = abs((direzione - prima + 180) % 360 - 180)
    if diff < 1.0:
        return
    punto = punto_cardinale(direzione)
    _imposta(programma, finestra, vivo, "direzione", direzione)
    _imposta(programma, finestra, vivo, "punto_cardinale", punto)
    _emetti(programma, finestra, vivo.nome, "cambio", {"direzione": direzione, "punto_cardinale": punto})


def inclinazioni(x: float, y: float, z: float) -> tuple[float, float]:
    """(inclinazione_x, inclinazione_y) in gradi dall'accelerometro; telefono appoggiato in piano: (0, 0).

    ``inclinazione_x`` e' positiva quando il lato destro del telefono e' piu' alto del sinistro,
    ``inclinazione_y`` quando la cima e' piu' alta del fondo: la bolla va verso il lato piu' alto.
    (In piano l'accelerometro legge circa (0, 0, 9.8); alzando il lato destro ``x`` cresce.)
    """
    g = math.sqrt(x * x + y * y + z * z) or _G
    ix = math.degrees(math.asin(max(-1.0, min(1.0, x / g))))
    iy = math.degrees(math.asin(max(-1.0, min(1.0, y / g))))
    return round(ix, 1) + 0.0, round(iy, 1) + 0.0


def _lettura_livella(programma, finestra, vivo, valori: list[float]) -> None:
    if len(valori) < 3:
        return
    ix, iy = inclinazioni(valori[0], valori[1], valori[2])
    p = vivo.modello.proprieta
    try:
        tolleranza = float(p.get("tolleranza", 2.0))
    except (TypeError, ValueError):
        tolleranza = 2.0
    in_piano = abs(ix) <= tolleranza and abs(iy) <= tolleranza
    prima = (_numero(p.get("inclinazione_x"), 999.0), _numero(p.get("inclinazione_y"), 999.0),
             bool(p.get("in_piano", True)))
    if abs(prima[0] - ix) < 0.5 and abs(prima[1] - iy) < 0.5 and prima[2] == in_piano:
        return
    _imposta(programma, finestra, vivo, "inclinazione_x", ix)
    _imposta(programma, finestra, vivo, "inclinazione_y", iy)
    _imposta(programma, finestra, vivo, "in_piano", in_piano)
    _emetti(programma, finestra, vivo.nome, "cambio", {"inclinazione_x": ix, "inclinazione_y": iy,
                                                       "in_piano": in_piano})


# --- gli altri controlli ----------------------------------------------------------------------

def _errore(programma, finestra, vivo, evento: dict) -> str:
    messaggio = str(evento.get("errore") or evento.get("messaggio") or "errore del telefono")
    programma._avviso(f"`{vivo.nome}`: {messaggio}")
    return messaggio


def _evento_fotocamera(programma, finestra, vivo, tipo: str, evento: dict) -> None:
    if tipo == "foto":
        file = str(evento.get("file") or "")
        _imposta(programma, finestra, vivo, "attiva", False)
        _imposta(programma, finestra, vivo, "ultima_foto", file)
        _emetti(programma, finestra, vivo.nome, "scatto", {"file": file, "percorso": file})
    elif tipo in ("annullata", "errore"):
        if tipo == "errore":
            _errore(programma, finestra, vivo, evento)
        _imposta(programma, finestra, vivo, "attiva", False)


def _evento_lettore_qr(programma, finestra, vivo, tipo: str, evento: dict) -> None:
    if tipo == "codice":
        testo = str(evento.get("testo") or "")
        formato = str(evento.get("formato") or "")
        _imposta(programma, finestra, vivo, "attivo", False)
        _imposta(programma, finestra, vivo, "ultimo_codice", testo)
        _emetti(programma, finestra, vivo.nome, "codice_letto", {"testo": testo, "formato": formato})
    elif tipo in ("annullata", "errore"):
        if tipo == "errore":
            _errore(programma, finestra, vivo, evento)
        _imposta(programma, finestra, vivo, "attivo", False)


def _evento_dettatura(programma, finestra, vivo, tipo: str, evento: dict) -> None:
    if tipo == "ascoltato":
        testo = str(evento.get("testo") or "")
        alternative = [str(x) for x in evento.get("alternative") or [] if isinstance(x, str)]
        _imposta(programma, finestra, vivo, "in_ascolto", False)
        _imposta(programma, finestra, vivo, "testo", testo)
        _emetti(programma, finestra, vivo.nome, "frase_riconosciuta", {"testo": testo, "alternative": alternative})
    elif tipo in ("errore", "annullata"):
        if tipo == "errore":
            _errore(programma, finestra, vivo, evento)
        _imposta(programma, finestra, vivo, "in_ascolto", False)


def _evento_voce(programma, finestra, vivo, tipo: str, evento: dict) -> None:
    if tipo != "parlato_fine":
        if tipo == "errore":
            _errore(programma, finestra, vivo, evento)
        return
    chiave = (finestra.nome, vivo.nome)
    attesa = stato(programma).letture.get(chiave)
    if attesa is None:
        return                                  # lettura fermata con `ferma()`: niente `fine_lettura`
    numero = evento.get("id")
    if isinstance(numero, int) and numero != attesa:
        return                                  # fine di una lettura vecchia (ne e' partita un'altra)
    stato(programma).letture.pop(chiave, None)
    if evento.get("interrotto"):
        return                                  # fermata dal telefono (app in secondo piano): non e' finita
    _emetti(programma, finestra, vivo.nome, "fine_lettura", {})


def _evento_suono(programma, finestra, vivo, tipo: str, evento: dict) -> None:
    if tipo != "suono_fine":
        if tipo == "errore":
            _errore(programma, finestra, vivo, evento)
        return
    chiave = (finestra.nome, vivo.nome)
    attesa = stato(programma).suoni.get(chiave)
    numero = evento.get("id")
    if attesa is None or (isinstance(numero, int) and numero != attesa):
        return
    stato(programma).suoni.pop(chiave, None)
    if evento.get("interrotto"):
        return
    _emetti(programma, finestra, vivo.nome, "fine_riproduzione", {})


def _evento_posizione(programma, finestra, vivo, tipo: str, evento: dict) -> None:
    if tipo == "posizione":
        p = vivo.modello.proprieta
        dati = {
            "latitudine": round(_numero(evento.get("latitudine")), 7),
            "longitudine": round(_numero(evento.get("longitudine")), 7),
            "precisione": round(max(0.0, _numero(evento.get("precisione"))), 1),
            "altitudine": round(_numero(evento.get("altitudine")), 1),
            "velocita": round(max(0.0, _numero(evento.get("velocita"))) * 3.6, 1),    # m/s -> km/h
        }
        for k, v in dati.items():
            _imposta(programma, finestra, vivo, k, v)
        if not p.get("continua", True):
            _imposta(programma, finestra, vivo, "attiva", False)
        _emetti(programma, finestra, vivo.nome, "cambio", dati)
    elif tipo == "errore":
        messaggio = _errore(programma, finestra, vivo, evento)
        _imposta(programma, finestra, vivo, "attiva", False)
        _emetti(programma, finestra, vivo.nome, "errore", {"messaggio": messaggio})


def _evento_torcia(programma, finestra, vivo, tipo: str, evento: dict) -> None:
    if tipo == "errore":
        _errore(programma, finestra, vivo, evento)
        _imposta(programma, finestra, vivo, "accesa", False)


def _evento_batteria(programma, finestra, vivo, tipo: str, evento: dict) -> None:
    if tipo == "batteria":
        _batteria(programma, finestra, vivo, evento)


def _evento_generico(programma, finestra, vivo, tipo: str, evento: dict) -> None:
    if tipo == "errore":
        _errore(programma, finestra, vivo, evento)


_GESTORI: dict[str, Callable[..., None]] = {
    "Fotocamera": _evento_fotocamera,
    "LettoreQR": _evento_lettore_qr,
    "Dettatura": _evento_dettatura,
    "Voce": _evento_voce,
    "Suono": _evento_suono,
    "Posizione": _evento_posizione,
    "Torcia": _evento_torcia,
    "Batteria": _evento_batteria,
    "Vibrazione": _evento_generico,
    "Condivisione": _evento_generico,
    "Notifica": _evento_generico,
    "Sensore": _evento_generico,
    "Bussola": _evento_generico,
    "Livella": _evento_generico,
}

# Oggetti "dati, cruscotti e telefono" e quelli portati dal PC (Contapassi, Fonometro, StatoRete, Video...).
from . import dati_telefono as _dati  # noqa: E402 (usa le funzioni qui sopra)

TIPI_HARDWARE = TIPI_HARDWARE | _dati.TIPI
#: Controlli che ricevono le letture di un sensore del telefono.
_CON_SENSORE = frozenset({"Sensore", "Bussola", "Livella"}) | frozenset(_dati.SENSORI)

__all__ = ["TIPI_HARDWARE", "UNITA_SENSORI", "SENSORI_XYZ", "StatoHardware", "stato", "richiedi", "azioni",
           "apertura", "chiusura", "osserva", "gestisci_evento", "dati_sensore", "inclinazioni"]
