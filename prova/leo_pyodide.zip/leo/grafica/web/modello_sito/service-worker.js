/* Service worker del sito Leo esportato: rende l'app usabile offline (tranne il primo
 * avvio, che scarica Python dal CDN). Mette in cache i file locali e li serve dalla cache. */
"use strict";
var CACHE = "leo-sito-v1";
var LOCALI = ["./", "index.html", "bootstrap.js", "lavoratore.js", "leo.zip", "progetto.json",
  "assets/web/finestre.js", "assets/web/finestre.css", "assets/web/giochi.js",
  "assets/web/finestre_dati.js", "assets/web/finestre_quotidiani.js", "assets/web/finestre_quotidiani.css",
  "assets/web/stili_oggetti.js", "assets/web/stili_oggetti.css", "assets/web/icone_controlli.js",
  "assets/web/stemma.svg", "app.webmanifest"];
self.addEventListener("install", function (e) {
  e.waitUntil(caches.open(CACHE).then(function (c) { return c.addAll(LOCALI).catch(function () {}); }));
  self.skipWaiting();
});
self.addEventListener("activate", function (e) {
  e.waitUntil(caches.keys().then(function (chiavi) {
    return Promise.all(chiavi.map(function (k) { return k === CACHE ? null : caches.delete(k); }));
  }));
  self.clients.claim();
});
self.addEventListener("fetch", function (e) {
  var u = new URL(e.request.url);
  if (e.request.method !== "GET" || u.origin !== self.location.origin) return;  // CDN: lascia alla rete
  e.respondWith(caches.match(e.request).then(function (r) {
    return r || fetch(e.request).then(function (resp) {
      var copia = resp.clone();
      caches.open(CACHE).then(function (c) { try { c.put(e.request, copia); } catch (x) {} });
      return resp;
    }).catch(function () { return caches.match("index.html"); });
  }));
});
