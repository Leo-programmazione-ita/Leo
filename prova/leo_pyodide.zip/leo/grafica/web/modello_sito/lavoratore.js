/* Lavoratore (Web Worker) di un sito Leo esportato.
 *
 * Qui gira l'interprete Leo dentro Pyodide (CPython in WebAssembly). Riceve dal thread
 * principale un SharedArrayBuffer e la configurazione, carica il pacchetto `leo/` dallo
 * zip, scrive i file del progetto e avvia `esegui_progetto_web`. I messaggi verso la pagina
 * vanno con postMessage (`_posta`); gli eventi dalla pagina arrivano via SAB, aspettati con
 * Atomics.wait (`_attendi`) senza congelare l'interfaccia (vedi canale_sab.py e
 * docs/analisi/2026-10-19_architettura_leo_web_export.md). JavaScript "classico".
 */
"use strict";

var PYODIDE_BASE = "https://cdn.jsdelivr.net/pyodide/v0.26.4/full/";

var ctrl = null;       // Int32Array sul SAB: [0]=stato (0 fermo,1 aspetto,2 consegnato), [1]=lunghezza
var buf = null;        // Uint8Array sul SAB: i byte degli eventi (testo JSON)
var decoder = new TextDecoder();

// Manda i messaggi di Python alla pagina (non blocca).
function _posta(testo) {
  self.postMessage({ t: "msg", d: String(testo) });
}

// Aspetta gli eventi dalla pagina via SAB; ridà il testo JSON o null (timeout).
function _attendi(ms) {
  Atomics.store(ctrl, 0, 1);              // "sto aspettando"
  Atomics.notify(ctrl, 0);
  Atomics.wait(ctrl, 0, 1, ms > 0 ? ms : 0);
  if (Atomics.load(ctrl, 0) !== 2) {      // scaduto senza consegna
    Atomics.compareExchange(ctrl, 0, 1, 0);
    return null;
  }
  var n = Atomics.load(ctrl, 1);
  var copia = buf.slice(0, n);            // copia NON condivisa (TextDecoder non legge i SAB)
  Atomics.store(ctrl, 0, 0);             // consumato
  Atomics.notify(ctrl, 0);
  return decoder.decode(copia);
}

var RUNNER = [
  "import os, sys, json",
  "from js import _progetto_json",
  "cwd = os.getcwd()",
  "if cwd not in sys.path:",
  "    sys.path.insert(0, cwd)",
  "os.environ['LEO_DATI'] = os.path.join(cwd, 'dati')",
  "prog = json.loads(_progetto_json)",
  "base = os.path.join(cwd, 'progetto')",
  "for rel, testo in (prog.get('file') or {}).items():",
  "    percorso = os.path.join(base, *rel.split('/'))",
  "    os.makedirs(os.path.dirname(percorso) or base, exist_ok=True)",
  "    with open(percorso, 'w', encoding='utf-8') as f:",
  "        f.write(testo)",
  "import base64",
  "for rel, b64 in (prog.get('binario') or {}).items():",
  "    percorso = os.path.join(base, *rel.split('/'))",
  "    os.makedirs(os.path.dirname(percorso) or base, exist_ok=True)",
  "    with open(percorso, 'wb') as f:",
  "        f.write(base64.b64decode(b64))",
  "from js import _posta, _attendi",
  "from leo.grafica.web.canale_sab import CanaleWebSAB",
  "from leo.grafica.web.programma import esegui_progetto_web",
  "canale = CanaleWebSAB(posta=_posta, attendi=_attendi)",
  "codice = esegui_progetto_web(base, canale)",
  "int(codice) if codice is not None else 0",
].join("\n");

async function avvia(dati) {
  ctrl = new Int32Array(dati.sab, 0, 4);
  buf = new Uint8Array(dati.sab, 16);
  try {
    importScripts(PYODIDE_BASE + "pyodide.js");
    var pyodide = await loadPyodide({ indexURL: PYODIDE_BASE });
    var risposta = await fetch("leo.zip");
    var buffer = new Uint8Array(await risposta.arrayBuffer());
    pyodide.unpackArchive(buffer, "zip");   // estrae leo/ e dati/ nella cartella di lavoro
    var rp = await fetch("progetto.json");
    self._progetto_json = await rp.text();
    try {
      var _cfg = JSON.parse(self._progetto_json);
      if (_cfg && _cfg.cifratura) { await pyodide.loadPackage("cryptography"); }
    } catch (e) { /* senza: la cifratura dira' "non disponibile", il resto funziona */ }
    self.postMessage({ t: "pronto" });
    await pyodide.runPythonAsync(RUNNER);   // blocca qui finché il programma Leo gira
    self.postMessage({ t: "fine" });
  } catch (e) {
    self.postMessage({ t: "errore", d: (e && e.message) ? e.message : String(e) });
  }
}

self.onmessage = function (e) {
  if (e.data && e.data.t === "avvia") avvia(e.data);
};
