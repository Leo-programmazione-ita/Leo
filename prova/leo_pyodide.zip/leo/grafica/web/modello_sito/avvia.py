#!/usr/bin/env python3
"""Micro server per provare in locale un sito Leo esportato.

Manda gli header COOP/COEP che servono a SharedArrayBuffer (l'interprete Leo gira nel
browser dentro un Web Worker e li richiede). NON si puo' aprire index.html con un doppio
clic (file://): va servito.

Server MULTITHREAD: il browser chiede molti file insieme (finestre.js, giochi.js, leo.zip...)
e un server a un filo solo resetterebbe le connessioni in parallelo (ERR_CONNECTION_RESET).

Uso:   python avvia.py           -> http://localhost:8000
       python avvia.py 9000      -> un'altra porta
"""
import http.server
import sys

PORTA = int(sys.argv[1]) if len(sys.argv) > 1 else 8000


class Gestore(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header("Cross-Origin-Opener-Policy", "same-origin")
        self.send_header("Cross-Origin-Embedder-Policy", "credentialless")
        self.send_header("Cross-Origin-Resource-Policy", "cross-origin")
        super().end_headers()

    def log_message(self, *a):  # silenzioso
        pass


http.server.ThreadingHTTPServer.allow_reuse_address = True
with http.server.ThreadingHTTPServer(("", PORTA), Gestore) as server:
    print(f"Leo: apri  http://localhost:{PORTA}   (Ctrl+C per fermare)")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nFermato.")
