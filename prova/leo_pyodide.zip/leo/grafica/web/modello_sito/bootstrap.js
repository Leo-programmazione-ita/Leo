/* Ponte sul thread principale di un sito Leo esportato.
 *
 * Crea il SharedArrayBuffer, avvia il lavoratore (Pyodide), e collega i due versi:
 *  - messaggi Python -> pagina: arrivano con postMessage, li applica LeoFinestre.esecuzione;
 *  - eventi pagina -> Python: li mette in coda e li consegna al worker via SAB quando li aspetta.
 * JavaScript "classico". Vedi docs/analisi/2026-10-19_architettura_leo_web_export.md.
 */
"use strict";
(function () {
  var CFG = window.LEO_SITO || {};
  var contenitore = document.getElementById("finestre");
  var stato = document.getElementById("stato");

  function mostraStato(t) {
    if (!stato) return;
    stato.textContent = t || "";
    stato.className = "stato";
    stato.style.display = t ? "" : "none";
  }
  function mostraErrore(t) {
    if (stato) { stato.textContent = "Errore: " + t; stato.className = "stato errore"; stato.style.display = ""; }
    if (window.console) console.error("Leo:", t);
  }

  if (typeof SharedArrayBuffer === "undefined" || typeof Atomics === "undefined") {
    mostraErrore("questo sito va SERVITO con gli header COOP/COEP, non aperto col doppio clic. "
      + "Avvialo con «python avvia.py» (o un host che li manda). Vedi LEGGIMI.txt.");
    return;
  }
  if (!window.LeoFinestre) { mostraErrore("finestre.js non è stato caricato."); return; }

  var sab = new SharedArrayBuffer(16 + 512 * 1024);
  var ctrl = new Int32Array(sab, 0, 4);
  var buf = new Uint8Array(sab, 16);
  var encoder = new TextEncoder();
  var coda = [];

  var exec = window.LeoFinestre.esecuzione({
    contenitore: contenitore,
    tema: CFG.tema || "scuro",
    accento: CFG.accento || null,
    invia: function (eventi) {
      if (!eventi || !eventi.length) return;
      for (var i = 0; i < eventi.length; i++) coda.push(eventi[i]);
    },
    avviso: function (t) { if (window.console) console.warn("Leo:", t); },
    larghezza: function () { return contenitore ? contenitore.clientWidth : window.innerWidth; },
    altezza: function () { return contenitore ? contenitore.clientHeight : window.innerHeight; }
  });

  function consegnaUno(lista) {
    var bytes = encoder.encode(JSON.stringify(lista));
    if (bytes.length > buf.length) return false;
    buf.set(bytes);
    Atomics.store(ctrl, 1, bytes.length);
    Atomics.store(ctrl, 0, 2);
    Atomics.notify(ctrl, 0);
    return true;
  }
  function consegna() {
    if (Atomics.load(ctrl, 0) === 1 && coda.length) {
      if (consegnaUno(coda)) coda = [];
      else { var uno = coda.shift(); consegnaUno([uno]); }  // evento troppo grande: uno per volta
    }
    requestAnimationFrame(consegna);
  }
  requestAnimationFrame(consegna);

  var lavoratore = new Worker("lavoratore.js");
  lavoratore.onmessage = function (e) {
    var m = e.data || {};
    if (m.t === "msg") { try { exec.ricevi(m.d); } catch (err) { if (window.console) console.warn(err); } }
    else if (m.t === "pronto") { mostraStato(""); }
    else if (m.t === "fine") { /* il programma è terminato: le finestre restano */ }
    else if (m.t === "errore") { mostraErrore(m.d); }
  };

  mostraStato("Avvio di Leo… (il primo caricamento scarica Python, può volerci qualche secondo)");
  lavoratore.postMessage({ t: "avvia", sab: sab });
})();
