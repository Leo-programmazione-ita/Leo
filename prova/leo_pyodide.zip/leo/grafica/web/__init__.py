"""Finestre di Leo disegnate da un'interfaccia web (senza Qt): il motore per Android.

Il modulo :mod:`leo.grafica.web.programma` esegue un progetto con finestre come
``leo.grafica.qt.applicazione``, ma al posto dei widget Qt manda dei messaggi a
un "canale" (sull'app Android: la WebView, che disegna i controlli con
``assets/web/finestre.js``) e riceve da li' gli eventi. Il protocollo e' in
``android/CONTRATTO.md`` ("Finestre").
"""

from .programma import (CanaleWeb, PonteWeb, ProgrammaWeb, TIPI_SUPPORTATI_WEB, esegui_progetto_web,
                        modello_per_web)

__all__ = ["CanaleWeb", "PonteWeb", "ProgrammaWeb", "TIPI_SUPPORTATI_WEB", "esegui_progetto_web",
           "modello_per_web"]
