"""Aiuti per il disegnatore di finestre dell'app Android (``assets/web/disegna.js``), senza Qt.

Il disegnatore lavora sui dati della maschera nel formato di :func:`modello_per_web` (quello dei file
``.maschera`` in JSON) e usa :func:`LeoFinestre.disegna` per mostrarli; qui ci sono le cose che
servono dal lato di Leo:

* :func:`catalogo_disegnatore`: i controlli che il telefono sa disegnare, con le proprieta' da mostrare
  nel pannello (tipo, predefinito, scelte, limiti) e gli eventi;
* :func:`leggi_maschera_json` / :func:`salva_maschera_json`: lettura e scrittura del file ``.maschera``
  (con gli stessi controlli di Leo Studio: nomi doppi, tipi sconosciuti, valori sbagliati);
* :func:`crea_progetto_telefono`: un progetto nuovo con una finestra fatta per il telefono.
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any

from ...errori import ErroreDante, ErroreValore
from ..maschera import carica_maschera, leggi_maschera_da_dizionario, salva_maschera
from ..metadati import carica_catalogo
from .programma import TIPI_SUPPORTATI_WEB, modello_per_web, valore_json

#: Misura della finestra di un'app per il telefono (px logici: si scala sullo schermo vero).
LARGHEZZA_TELEFONO = 360
ALTEZZA_TELEFONO = 640

#: Proprieta' che il pannello non mostra (le gestisce il disegnatore a parte, o non servono qui).
_NASCOSTE = {"nome", "tipo", "contenitore", "scheda", "sinistra", "alto", "larghezza", "altezza"}

#: Ordine delle schede nella tavolozza (le altre dopo, in ordine alfabetico).
_ORDINE_SCHEDE = ("Base", "Inserimento", "Scelta", "Contenitori", "Visualizzazione", "Telefono", "Indicatori",
                  "Italia", "Produttività", "Dati", "Disegno", "Giochi", "Media", "Hardware", "Sicurezza", "Sviluppo",
                  "Didattica")

#: Controlli invisibili che hanno senso sul telefono (compaiono nella striscia sotto la finestra).
_INVISIBILI_UTILI = {"Timer", "Appunti", "Notifica", "MenuContestuale", "BancaDati", "RichiestaWeb", "Cifratura",
                     "Voce", "Suono", "Vibrazione", "Torcia", "Posizione", "Batteria", "Condivisione",
                     "Movimento", "StatoRete", "OrientamentoSchermo", "DialogoFile"}


def _proprieta_json(p: Any) -> dict:
    d: dict[str, Any] = {"nome": p.nome, "tipo": p.tipo, "predefinito": valore_json(p.predefinito),
                         "gruppo": p.gruppo, "descrizione": p.descrizione}
    if p.scelte:
        d["scelte"] = list(p.scelte)
    if p.minimo is not None:
        d["minimo"] = p.minimo
    if p.massimo is not None:
        d["massimo"] = p.massimo
    return d


def catalogo_disegnatore() -> dict:
    """``{"schede": [nomi], "tipi": [{nome, scheda, descrizione, larghezza, altezza, contenitore,
    invisibile, evento, eventi, prefisso, proprieta: [...]}], "finestra": {...}, "effetti": {proprieta:
    {scelta: spiegazione}}}`` per i controlli del telefono."""
    catalogo = carica_catalogo()
    tipi = []
    for nome, t in catalogo.items():
        if nome == "Finestra":
            continue
        if nome not in TIPI_SUPPORTATI_WEB and nome not in _INVISIBILI_UTILI:
            continue
        if t.invisibile and nome not in _INVISIBILI_UTILI:
            continue
        tipi.append({
            "nome": nome, "scheda": t.scheda, "descrizione": t.descrizione,
            "larghezza": int(t.dimensione_predefinita[0]), "altezza": int(t.dimensione_predefinita[1]),
            "contenitore": bool(t.contenitore), "invisibile": bool(t.invisibile),
            "evento": t.evento_predefinito or "", "eventi": list(t.eventi), "prefisso": t.prefisso_nome or nome,
            "proprieta": [_proprieta_json(p) for k, p in t.proprieta.items()
                          if k not in _NASCOSTE and not p.sola_lettura],
        })
    finestra = catalogo["Finestra"]
    schede = sorted({t["scheda"] for t in tipi},
                    key=lambda s: (_ORDINE_SCHEDE.index(s) if s in _ORDINE_SCHEDE else len(_ORDINE_SCHEDE), s))
    tipi.sort(key=lambda t: (schede.index(t["scheda"]), t["nome"]))
    from .. import effetti as ef

    return {
        "schede": schede,
        "tipi": tipi,
        # cosa fa ogni effetto (gruppo "Effetti" del pannello: la spiegazione della scelta fatta)
        "effetti": {"animazione_entrata": dict(ef.DESCRIZIONI_ENTRATE),
                    "effetto_continuo": dict(ef.DESCRIZIONI_CONTINUI),
                    "effetto_tocco": dict(ef.DESCRIZIONI_TOCCHI)},
        "finestra": {"eventi": list(finestra.eventi), "evento": finestra.evento_predefinito or "apertura",
                     "proprieta": [_proprieta_json(p) for k, p in finestra.proprieta.items()
                                   if k not in _NASCOSTE and not p.sola_lettura]},
    }


def leggi_maschera_json(percorso: str | os.PathLike) -> dict:
    """La maschera nel formato di ``LeoFinestre.disegna`` (solo i valori scritti nel file)."""
    return modello_per_web(carica_maschera(percorso))


def _pulisci(d: Any) -> Any:
    """Toglie i campi di servizio dell'interfaccia (quelli che iniziano con `_`)."""
    if isinstance(d, dict):
        return {k: _pulisci(v) for k, v in d.items() if not str(k).startswith("_")}
    if isinstance(d, list):
        return [_pulisci(v) for v in d]
    return d


def salva_maschera_json(percorso: str | os.PathLike, modello: dict | str) -> None:
    """Salva i dati del disegnatore nel file ``.maschera`` (ErroreValore se non sono validi)."""
    if isinstance(modello, str):
        try:
            modello = json.loads(modello)
        except ValueError as e:
            raise ErroreValore(f"I dati della finestra non sono validi: {e}.") from None
    if not isinstance(modello, dict):
        raise ErroreValore("I dati della finestra non sono validi.")
    dati = _pulisci(modello)
    dati = {"maschera": {"versione": int(dati.get("versione", 1) or 1)},
            "finestra": dati.get("finestra") or {}, "controlli": dati.get("controlli") or []}
    maschera = leggi_maschera_da_dizionario(dati)
    catalogo = carica_catalogo()
    for c in maschera.tutti():
        tipo = catalogo.get(c.tipo)
        if tipo is None:
            raise ErroreValore(f"`{c.tipo}` non è un controllo di Leo.")
        for k, v in list(c.proprieta.items()):
            p = tipo.proprieta.get(k)
            if p is None or k in ("nome", "tipo"):
                continue
            try:
                c.proprieta[k] = p.converti(v)
            except ErroreDante as e:
                raise ErroreValore(f"{c.nome}.{k}: {e.messaggio}") from None
    salva_maschera(percorso, maschera)


_NOME_VALIDO = re.compile(r"^[^\\/:*?\"<>|\x00-\x1f]{1,60}$")


def nome_progetto_valido(nome: str) -> str:
    n = (nome or "").strip()
    if not n or n.startswith(".") or ".." in n or not _NOME_VALIDO.match(n):
        raise ErroreValore("Il nome dell'app non può essere vuoto né contenere / \\ : * ? \" < > |.")
    return n


def crea_progetto_telefono(cartella_programmi: str | os.PathLike, nome: str, modello: str = "saluto") -> str:
    """Crea ``cartella_programmi/nome`` con una finestra per il telefono, partendo da uno dei
    :data:`modelli_app.MODELLI` (un'app gia' funzionante); restituisce il nome usato."""
    from ...progetto import crea_progetto
    from .modelli_app import costruisci

    nome = nome_progetto_valido(nome)
    cartella = Path(cartella_programmi) / nome
    if cartella.exists():
        raise ErroreValore(f"C'è già un programma che si chiama `{nome}`.")
    crea_progetto(cartella, nome, con_finestra=True)
    maschera, codice = costruisci(modello or "saluto", nome)
    salva_maschera_json(cartella / "Finestra1.maschera", maschera)
    (cartella / "Finestra1.leo").write_text(codice, encoding="utf-8")
    return nome


__all__ = ["catalogo_disegnatore", "leggi_maschera_json", "salva_maschera_json", "crea_progetto_telefono",
           "nome_progetto_valido", "LARGHEZZA_TELEFONO", "ALTEZZA_TELEFONO"]
