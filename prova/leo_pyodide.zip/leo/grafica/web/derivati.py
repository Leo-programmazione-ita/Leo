"""Valori calcolati dei controlli "intelligenti" per le finestre sul telefono (senza Qt).

Sul PC questi calcoli li fanno i widget di ``qt/widget_dante.py`` mentre si scrive; sul
telefono l'interfaccia (``finestre.js``) manda a Python il testo scritto e Python risponde con
i valori calcolati, usando gli stessi servizi puri (``servizi/italia.py``, ``servizi/sicurezza.py``,
``servizi/qr.py``):

* :func:`proprieta_calcolate`: proprieta' vere del controllo (``valido``, ``banca``,
  ``punteggio``, ``livello``, ``consigli``, ``comune``...), che il codice Leo puo' leggere;
* :func:`extra_web`: dati che servono solo al disegno e cominciano con ``_`` (la matrice del
  QR, il colore della barra della password, i comuni suggeriti).
"""

from __future__ import annotations

from typing import Any

#: Caselle che si controllano da sole mentre si scrive (servizio ``italia``).
CASELLE_VALIDATE = ("CasellaCodiceFiscale", "CasellaIBAN", "CasellaTarga")

#: Quanti comuni si suggeriscono al massimo mentre si scrive.
MASSIMO_SUGGERIMENTI = 12


def _italia() -> Any:
    try:
        from ..servizi import italia
    except Exception:  # noqa: BLE001 - servizio mancante: nessun calcolo
        return None
    return italia


def _testo(v: Any) -> str:
    return v if isinstance(v, str) else ("" if v is None else str(v))


def _verifica_casella(tipo: str, testo: str) -> dict:
    """``{"valido": bool, ...proprieta' estratte}`` come ``CasellaValidata`` di widget_dante."""
    vuote = {"CasellaCodiceFiscale": {"data_nascita": "", "sesso": "", "comune": ""},
             "CasellaIBAN": {"banca": ""}, "CasellaTarga": {"tipo_targa": ""}}[tipo]
    italia = _italia()
    if italia is None or not testo.strip():
        return {"valido": False, **vuote}
    funzione = {"CasellaCodiceFiscale": "verifica_codice_fiscale", "CasellaIBAN": "verifica_iban",
                "CasellaTarga": "verifica_targa"}[tipo]
    try:
        r = getattr(italia, funzione)(testo)
    except Exception:  # noqa: BLE001 - testo strano: semplicemente non valido
        return {"valido": False, **vuote}
    valido = bool(r and r.get("valido"))
    if not valido:
        return {"valido": False, **vuote}
    if tipo == "CasellaCodiceFiscale":
        return {"valido": True, "data_nascita": _testo(r.get("data_nascita")), "sesso": _testo(r.get("sesso")),
                "comune": _testo(r.get("comune"))}
    if tipo == "CasellaIBAN":
        return {"valido": True, "banca": _testo(r.get("banca"))}
    return {"valido": True, "tipo_targa": _testo(r.get("tipo"))}


def _valuta_password(testo: str) -> dict:
    if not testo:
        return {"punteggio": 0, "livello": "", "consigli": []}
    try:
        from ..servizi import sicurezza

        r = sicurezza.valuta_password(testo)
    except Exception as e:  # noqa: BLE001
        return {"punteggio": 0, "livello": "", "consigli": [str(e)]}
    return {"punteggio": int(r.get("punteggio", 0) or 0), "livello": _testo(r.get("livello")),
            "consigli": [_testo(c) for c in (r.get("consigli") or [])]}


def comune_esatto(testo: str) -> dict:
    """Il comune che si chiama esattamente ``testo`` (``{}`` se non c'e' o se sono piu' d'uno)."""
    italia = _italia()
    if italia is None or not testo.strip():
        return {}
    try:
        trovati = list(italia.cerca_comuni(testo.strip(), 20))
    except Exception:  # noqa: BLE001
        return {}
    esatti = [c for c in trovati if _testo(c.get("nome")).lower() == testo.strip().lower()]
    return dict(esatti[0]) if len(esatti) == 1 else {}


def suggerimenti_comuni(testo: str) -> list[dict]:
    italia = _italia()
    if italia is None or len(testo.strip()) < 2:
        return []
    try:
        return [dict(c) for c in italia.cerca_comuni(testo.strip(), MASSIMO_SUGGERIMENTI)]
    except Exception:  # noqa: BLE001
        return []


def proprieta_calcolate(tipo: str, p: dict, proprieta: str) -> dict:
    """Proprieta' vere da aggiornare dopo che ``proprieta`` e' cambiata (``{}`` se nessuna)."""
    if tipo in CASELLE_VALIDATE and proprieta == "testo":
        return _verifica_casella(tipo, _testo(p.get("testo")))
    if tipo == "MisuratorePassword" and proprieta == "testo":
        return _valuta_password(_testo(p.get("testo")))
    if tipo == "CalendarioFestività" and proprieta == "data":
        italia = _italia()
        festa = ""
        if italia is not None and _testo(p.get("data")).strip():
            try:
                festa = _testo(italia.e_festivo(_testo(p.get("data")).strip()) or "")
            except Exception:  # noqa: BLE001 - data non valida: nessuna festa
                festa = ""
        return {"festivita": festa if p.get("mostra_festivita", True) is not False else ""}
    if tipo == "SelettoreComune" and proprieta == "testo":
        comune = comune_esatto(_testo(p.get("testo")))
        attuale = p.get("comune") if isinstance(p.get("comune"), dict) else {}
        # se il testo e' ancora il nome del comune scelto lo si tiene (anche se ci sono omonimi)
        if not comune and attuale and _testo(attuale.get("nome")).lower() == _testo(p.get("testo")).strip().lower():
            return {}
        return {"comune": comune}
    return {}


def extra_web(tipo: str, p: dict, proprieta: str | None = None) -> dict:
    """Dati per il disegno (chiavi con ``_``). ``proprieta`` None = tutti quelli iniziali."""
    extra: dict[str, Any] = {}
    if tipo == "GeneratoreQR" and proprieta in (None, "testo", "correzione"):
        testo = _testo(p.get("testo"))
        try:
            from ..servizi import qr

            matrice = qr.matrice_qr(testo, _testo(p.get("correzione")) or "M") if testo else []
            extra["_qr"] = ["".join("1" if m else "0" for m in riga) for riga in matrice]
        except Exception:  # noqa: BLE001 - testo troppo lungo o servizio mancante
            extra["_qr"] = []
        extra["_qr_testo"] = testo
    if tipo == "MisuratorePassword" and proprieta in (None, "testo", "punteggio", "livello"):
        try:
            from ..logica_dante import colore_password

            extra["_colore"] = colore_password(_testo(p.get("livello")), p.get("punteggio", 0))
        except Exception:  # noqa: BLE001
            extra["_colore"] = "#8E8E93"
    return extra


__all__ = ["CASELLE_VALIDATE", "proprieta_calcolate", "extra_web", "suggerimenti_comuni", "comune_esatto"]
