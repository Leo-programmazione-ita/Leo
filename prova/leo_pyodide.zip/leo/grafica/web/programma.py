"""Esecuzione di un progetto con finestre disegnate da un'interfaccia web (senza Qt).

E' lo stesso lavoro di ``leo.grafica.qt.applicazione._Programma`` (carica le
maschere, crea i ``ControlloVivo``, esegue il codice delle finestre, apre la
finestra iniziale e chiama i gestori ``quando``), ma al posto dei widget Qt ci
sono dei **messaggi** verso un canale e degli **eventi** che arrivano dal
canale. Tutto gira in un solo thread (quello del programma): il ciclo degli
eventi e' :meth:`ProgrammaWeb._ciclo`, che aspetta gli eventi del canale e fa
scattare i temporizzatori (``Timer``, ``ogni``/``dopo``, animazioni).

Il canale (:class:`CanaleWeb`) ha due metodi:

* ``invia(messaggi)``: una lista di messaggi (dizionari JSON) verso l'interfaccia,
  mandata a gruppi (alla fine di ogni gestore, prima di ogni attesa);
* ``ricevi(attesa)``: la lista degli eventi arrivati entro ``attesa`` secondi
  (lista vuota se non e' arrivato niente; ``None`` se il canale e' chiuso).

Protocollo completo: ``android/CONTRATTO.md``, sezione "Finestre".

Le proprieta' che l'utente cambia nell'interfaccia (testo di una casella,
valore di un cursore...) arrivano con gli eventi (campo ``agg``) e vengono
scritte nel modello con ``aggiorna_da_interfaccia``: il codice Leo le legge
subito, senza chiamate sincrone verso l'interfaccia.
"""

from __future__ import annotations

import base64
import copy
import heapq
import itertools
import json
import math
import mimetypes
import os
import sys
import time
import traceback
from pathlib import Path
from typing import Any, Callable

from ...errori import (ErroreDante, ErroreNome, ErroreRicorsione, ErroreSintassi, ErroreValore,
                       SegnaleFermaProgramma)
from .. import azioni
from ..modello import ControlloVivo, ModelloMaschera
from ..ponte import PonteGrafico
from ..logica_quotidiani import TIPI_QUOTIDIANI, percorsi_immagine as _percorsi_quotidiani
from ..giochi import web as giochi_web
from . import derivati, hardware

#: Controlli che l'interfaccia web sa disegnare (gli altri compaiono come riquadri
#: "non disponibile sul telefono"). Deve restare uguale a ``SUPPORTATI`` di
#: ``android/app/src/main/assets/web/finestre.js`` (lo controlla un test).
TIPI_SUPPORTATI_WEB = frozenset({
    # classici
    "Finestra", "Etichetta", "Pulsante", "PulsanteImmagine", "Collegamento",
    "CasellaTesto", "CasellaPassword", "AreaTesto", "CasellaNumero", "SelettoreData", "SelettoreColore",
    "Cursore", "CasellaSpunta", "Scelta", "Interruttore", "Elenco", "MenuATendina",
    "Riquadro", "Schede", "PannelloScorrevole", "Divisore",
    "Immagine", "BarraAvanzamento", "BarraStato", "Tabella", "Albero", "Grafico",
    "Tela", "Linea", "Forma", "BarraStrumenti",
    "BarraMenu", "VoceMenu", "MenuContestuale",
    "Timer", "Appunti", "Suggerimento",
    # inventati per Leo
    "Led", "Semaforo", "Valutazione", "Quadrante", "Punteggio", "Registro", "Galleria", "Notifica",
    "Cifratura", "BancaDati", "RichiestaWeb",
    # cassetta degli attrezzi del telefono, seconda infornata
    "CasellaCodiceFiscale", "CasellaIBAN", "CasellaTarga", "CasellaImporto", "SelettoreComune",
    "CalendarioFestività", "MisuratorePassword", "ContoAllaRovescia", "Joystick", "GeneratoreQR",
    "EditorCodice", "Terminale", "Lavagna", "Kanban",
    # hardware del telefono (leo.grafica.web.hardware)
    "Sensore", "Fotocamera", "LettoreQR", "Dettatura", "Voce", "Suono",
    "Bussola", "Livella", "Vibrazione", "Torcia", "Posizione", "Batteria", "Condivisione",
    # dati, cruscotti e telefono (finestre_dati.js, leo.grafica.web.dati_telefono) e oggetti portati dal PC
    "Cruscotto", "AnelloAvanzamento", "GraficoDalVivo", "TabellaOrdinabile", "Contapassi", "SensoreLuce",
    "SensoreProssimità", "Barometro", "Movimento", "Fonometro", "RegistratoreAudio", "StatoRete",
    "OrientamentoSchermo", "Oscilloscopio", "Mappa", "ModuloAutomatico", "Diagramma", "Video", "DialogoFile",
    "Tutor",
    # oggetti da gioco (giochi.js; vedi leo.grafica.giochi.web)
    "Personaggio", "MondoAPiastrelle", "Piattaforma", "Moneta", "Nemico", "Proiettile", "Ostacolo", "Porta",
    "SfondoCheScorre", "Telecamera", "Vite", "Classifica", "TimerDiGioco", "PulsanteGioco", "FrecceDirezionali",
    "Dado", "MazzoDiCarte", "Scacchiera", "Particelle", "Pianoforte", "RuotaDellaFortuna", "Bersaglio", "Labirinto",
}) | frozenset(TIPI_QUOTIDIANI)  # scheda "Tutti i giorni" (assets/web/finestre_quotidiani.js)

#: Controlli invisibili che funzionano senza interfaccia (tutto in Python).
_INVISIBILI_SENZA_INTERFACCIA = frozenset({"Timer", "Appunti", "Suggerimento", "Cifratura", "BancaDati",
                                           "RichiestaWeb", "BarraMenu", "VoceMenu", "MenuContestuale",
                                           "Notifica"})

#: Dimensione massima di un'immagine mandata all'interfaccia (come ``data:`` URI).
LIMITE_RISORSA = 4 * 1024 * 1024

#: Intervallo dei fotogrammi delle animazioni (secondi).
PASSO_ANIMAZIONE = 1 / 30

#: Attesa massima di ``ricevi`` quando non c'e' niente da fare (secondi): ogni
#: tanto si controlla comunque se qualcuno ha chiesto di fermare il programma.
_ATTESA_MASSIMA = 0.2

#: In un giro del ciclo degli eventi (gestori e temporizzatori scaduti insieme) i messaggi partono
#: tutti insieme alla fine del giro, se il giro non dura piu' di cosi' (secondi): un solo invio verso
#: la pagina invece di uno per gestore.
_DURATA_GRUPPO = 0.03


def _intero(v: Any, predefinito: int = 0) -> int:
    try:
        if isinstance(v, bool):
            return predefinito
        return int(v)
    except (TypeError, ValueError):
        return predefinito


def _avviso_stderr(testo: str) -> None:
    try:
        sys.stderr.write(f"Avviso: {testo}\n")
    except Exception:  # noqa: BLE001
        pass


# ===========================================================================
# Canale
# ===========================================================================

class CanaleWeb:
    """Interfaccia del canale verso l'interfaccia web (da sottoclassare)."""

    def invia(self, messaggi: list[dict]) -> None:  # pragma: no cover - da sottoclassare
        raise NotImplementedError

    def ricevi(self, attesa: float) -> list[dict] | None:  # pragma: no cover - da sottoclassare
        raise NotImplementedError


# ===========================================================================
# Valori Leo -> JSON
# ===========================================================================

def valore_json(v: Any, profondita: int = 0) -> Any:
    """Un valore Leo in forma JSON (le forme diventano dizionari, il resto testo)."""
    if v is None or isinstance(v, (bool, int, str)):
        return v
    if isinstance(v, float):
        return v if math.isfinite(v) else None
    if profondita > 40:
        return None
    if isinstance(v, (list, tuple)):
        return [valore_json(x, profondita + 1) for x in v]
    if isinstance(v, dict):
        return {str(k): valore_json(x, profondita + 1) for k, x in v.items()}
    a_diz = getattr(v, "a_dizionario", None)
    if callable(a_diz):
        try:
            return valore_json(a_diz(), profondita + 1)
        except Exception:  # noqa: BLE001
            pass
    try:
        from ...valori import rappresenta

        return rappresenta(v)
    except Exception:  # noqa: BLE001
        return str(v)


def _colore_web(valore: Any) -> Any:
    """Colori sempre ``#RRGGBB[AA]`` verso l'interfaccia (i nomi italiani li conosce Python)."""
    if not isinstance(valore, str) or not valore.strip():
        return valore
    try:
        from ..colori import normalizza_colore

        return normalizza_colore(valore)
    except Exception:  # noqa: BLE001 - valore strano nella maschera: lo si manda com'e'
        return valore


def proprieta_web(vivo: ControlloVivo, nome: str, valore: Any) -> Any:
    """Valore di una proprieta' pronto per l'interfaccia (colori normalizzati, JSON)."""
    meta = vivo.tipo.proprieta.get(nome)
    if meta is not None and meta.tipo == "colore" and nome != "sfondo":
        return _colore_web(valore)
    return valore_json(valore)


def sfondo_web(valore: Any) -> dict:
    """``Finestra.sfondo`` gia' interpretato (``temi_controlli.analizza_sfondo``) per l'interfaccia."""
    try:
        from .. import temi_controlli as tc

        return valore_json(tc.analizza_sfondo(valore if isinstance(valore, str) else ""))
    except Exception:  # noqa: BLE001
        return {"tipo": "nessuno"}


def modello_per_web(maschera: ModelloMaschera, vivi: dict[str, ControlloVivo] | None = None) -> dict:
    """La maschera nel formato dei dati dell'interfaccia (lo stesso dei file ``.maschera``).

    ``{"versione": 1, "finestra": {"nome", "tipo", ...proprieta'}, "controlli": [{"nome", "tipo",
    "contenitore", "scheda"?, ...proprieta'}]}``. Con ``vivi`` le proprieta' sono quelle
    correnti (con i predefiniti del catalogo); in piu' la finestra ha ``_sfondo`` (lo sfondo
    interpretato). E' anche il formato di ``LeoFinestre.disegna`` in ``finestre.js``.
    """
    def voce(modello, finestra: bool) -> dict:
        vivo = (vivi or {}).get(modello.nome)
        d: dict[str, Any] = {"nome": modello.nome, "tipo": modello.tipo}
        if not finestra:
            d["contenitore"] = modello.contenitore or ""
            if modello.scheda is not None:
                d["scheda"] = int(modello.scheda)
        for k, v in modello.proprieta.items():
            if k in ("nome", "tipo", "contenitore", "scheda"):
                continue
            d[k] = proprieta_web(vivo, k, v) if vivo is not None else valore_json(v)
        if finestra:
            d["_sfondo"] = sfondo_web(modello.proprieta.get("sfondo", ""))
        return d

    return {"versione": int(getattr(maschera, "versione", 1) or 1),
            "finestra": voce(maschera.finestra, True),
            "controlli": [voce(c, False) for c in maschera.controlli]}


# ===========================================================================
# Tempo: temporizzatori del ciclo degli eventi
# ===========================================================================

class _Voce:
    """Un temporizzatore del ciclo: ``stop()`` lo ferma (per ``ferma_temporizzatori``)."""

    __slots__ = ("funzione", "intervallo", "ripeti", "attivo", "scadenza")

    def __init__(self, funzione: Callable[[], None], intervallo: float, ripeti: bool) -> None:
        self.funzione = funzione
        self.intervallo = max(0.0, float(intervallo))
        self.ripeti = bool(ripeti)
        self.attivo = True
        self.scadenza = 0.0

    def stop(self) -> None:
        self.attivo = False

    def isActive(self) -> bool:  # noqa: N802 - come QTimer (usato da qualche strumento)
        return self.attivo


class Pianificatore:
    """Coda dei temporizzatori in ordine di scadenza (tutto nel thread del programma)."""

    def __init__(self, orologio: Callable[[], float] = time.monotonic) -> None:
        self._coda: list[tuple[float, int, _Voce]] = []
        self._numero = itertools.count()
        self.orologio = orologio

    def aggiungi(self, secondi: float, funzione: Callable[[], None], ripeti: bool = False) -> _Voce:
        voce = _Voce(funzione, secondi, ripeti)
        self._metti(voce, self.orologio() + voce.intervallo)
        return voce

    def _metti(self, voce: _Voce, scadenza: float) -> None:
        voce.scadenza = scadenza
        heapq.heappush(self._coda, (scadenza, next(self._numero), voce))

    def prossima(self) -> float | None:
        while self._coda and not self._coda[0][2].attivo:
            heapq.heappop(self._coda)
        return self._coda[0][0] if self._coda else None

    def scadute(self, adesso: float | None = None) -> list[_Voce]:
        """Toglie e restituisce le voci scadute (quelle da ripetere tornano in coda)."""
        adesso = self.orologio() if adesso is None else adesso
        pronte: list[_Voce] = []
        while self._coda and self._coda[0][0] <= adesso:
            _s, _n, voce = heapq.heappop(self._coda)
            if not voce.attivo:
                continue
            pronte.append(voce)
            if voce.ripeti:
                # niente raffiche dopo una pausa lunga: si riparte da adesso
                self._metti(voce, max(voce.scadenza + max(voce.intervallo, 0.001), adesso))
            else:
                voce.attivo = False
        return pronte

    def svuota(self) -> None:
        for _s, _n, voce in self._coda:
            voce.attivo = False
        self._coda.clear()


# ===========================================================================
# Animazioni (anima, scuoti, lampeggia...)
# ===========================================================================

class MotoreAnimazioniWeb:
    """Come ``MotoreAnimazioniQt``, ma i fotogrammi li fa la pagina.

    Per ogni animazione Python manda **un solo messaggio** (``{"op": "animazione", ...}``,
    con i fotogrammi chiave e la curva: vedi ``android/CONTRATTO.md``) e la pagina la fa
    girare da sola (``requestAnimationFrame``), senza 30 messaggi al secondo attraverso il
    ponte. Python tiene lo stesso tempo con un solo temporizzatore: alla fine scrive i valori
    finali nei ``ControlloVivo`` (la pagina, che li ha già, li riceve con l'``imposta`` di
    sempre e chiude l'animazione), fa le azioni finali (``dissolvi`` nasconde...) e chiama
    ``poi`` come un gestore ``quando``. Gli effetti grafici (``rimbalza``, ``mostra_con``...)
    sono un messaggio ``{"op": "effetto", ...}`` (vedi :class:`FinestraWeb`).

    Durante l'animazione i valori intermedi si calcolano quando servono
    (:meth:`sincronizza`, prima di ogni gestore): leggere ``Pulsante1.alto`` a metà
    animazione dà il valore giusto anche se la pagina non ha mandato niente.
    """

    def __init__(self, programma: "ProgrammaWeb", *, riduci: bool = False) -> None:
        from ...libreria.animazioni import GestoreAnimazioni

        self.gestore = GestoreAnimazioni()
        self._programma = programma
        self._riduci = bool(riduci)
        self._chiuso = False
        self._corse: dict[int, tuple[Any, float, _Voce]] = {}
        self._numero = itertools.count(1)

    def colori_predefiniti(self, controllo: Any) -> dict:
        try:
            return self._programma.colori_partenza(controllo)
        except Exception:  # noqa: BLE001
            return {}

    def avvia(self, animazione: Any) -> None:
        from ...libreria.animazioni import avvisa_effetto

        if self._chiuso:
            return
        self.sincronizza()  # si parte dai valori di adesso (anche a meta' di un'altra animazione)
        for vecchia in self.gestore.avvia(animazione):
            self._dimentica(vecchia)
        if self._riduci or animazione.millisecondi <= 0:
            self._completa(animazione)
            return
        avvisa_effetto(animazione)
        if animazione.tracce:
            self._manda(animazione)
        voce = self._programma.pianificatore.aggiungi(animazione.millisecondi / 1000.0,
                                                      lambda a=animazione: self._completa(a))
        self._corse[id(animazione)] = (animazione, time.monotonic(), voce)

    def _manda(self, animazione: Any) -> None:
        """Il messaggio ``animazione`` per ogni finestra toccata (di solito una sola)."""
        from ...libreria.animazioni import _limita

        numero = next(self._numero)
        animazione.motore = numero
        per_finestra: dict[str, list[dict]] = {}
        for t in animazione.tracce:
            finestra = self._programma.finestra_di(t.controllo)
            if finestra is None or not finestra.costruita:
                continue
            chiave = [[round(float(pos), 4), proprieta_web(t.controllo, t.proprieta, _limita(t.controllo, t.proprieta, v))]
                      for pos, v in t.fotogrammi]
            per_finestra.setdefault(finestra.nome, []).append(
                {"c": t.controllo.nome, "p": t.proprieta, "tipo": t.tipo, "k": chiave})
        for nome, tracce in per_finestra.items():
            self._programma.accoda({"op": "animazione", "f": nome, "id": numero, "durata": animazione.millisecondi,
                                    "curva": animazione.curva, "tracce": tracce})

    def sincronizza(self) -> None:
        """Scrive nei controlli (senza mandare niente alla pagina) i valori di questo istante."""
        from ...libreria.animazioni import _limita, applica_curva

        if not self._corse:
            return
        adesso = time.monotonic()
        for animazione, inizio, _voce in list(self._corse.values()):
            durata = animazione.millisecondi / 1000.0
            t = (adesso - inizio) / durata if durata > 0 else 1.0
            if animazione.finita or animazione.sostituita or t >= 1.0:
                continue
            p = applica_curva(animazione.curva, max(0.0, t))
            for traccia in animazione.tracce:
                valore = _limita(traccia.controllo, traccia.proprieta, traccia.valore(p))
                traccia.controllo.aggiorna_da_interfaccia(traccia.proprieta, valore)

    def _dimentica(self, animazione: Any) -> None:
        corsa = self._corse.pop(id(animazione), None)
        if corsa is not None:
            corsa[2].stop()

    def _completa(self, animazione: Any) -> None:
        self._dimentica(animazione)
        poi = self.gestore.completa(animazione)
        if poi is not None and not self._chiuso:
            self._programma.pianificatore.aggiungi(0, lambda f=poi: self._programma.esegui_poi(f))

    def ferma(self, controllo: Any = None) -> None:
        """Ferma dove si trovano: la pagina si ferma e riceve i valori di Python (niente ``poi``)."""
        from ...libreria.animazioni import ferma_effetti

        self.sincronizza()
        fermate = self.gestore.ferma_controllo(controllo)
        for a in fermate:
            self._dimentica(a)
        ferma_effetti(fermate)
        if self._chiuso:
            return
        for a in fermate:
            if a.motore is None:
                continue
            finestre = {}
            for t in a.tracce:
                finestra = self._programma.finestra_di(t.controllo)
                if finestra is not None and finestra.costruita:
                    finestre[finestra.nome] = finestra
            for nome in finestre:
                self._programma.accoda({"op": "ferma_animazioni", "f": nome, "id": [a.motore]})
            for t in a.tracce:
                finestra = self._programma.finestra_di(t.controllo)
                if finestra is not None and finestra.costruita:
                    self._programma.accoda_proprieta(finestra, t.controllo, t.proprieta,
                                                     t.controllo.modello.proprieta.get(t.proprieta))

    def aspetta(self) -> None:
        """Lascia girare il ciclo finche' le animazioni non finiscono."""
        if self._chiuso or not self.gestore.attive:
            return
        rimanente = max((a.millisecondi for a in self.gestore.attive), default=0) / 1000.0
        self._programma.gira_fino(time.monotonic() + rimanente + 0.5,
                                  finche=lambda: bool(self.gestore.attive))

    def chiudi(self) -> None:
        self._chiuso = True
        self.ferma(None)


# ===========================================================================
# Ponte con l'interprete
# ===========================================================================

class PonteWeb(PonteGrafico):
    """Ponte grafico verso l'interfaccia web: finestre di dialogo, attese, temporizzatori."""

    def __init__(self, programma: "ProgrammaWeb") -> None:
        self._programma = programma

    @property
    def animatore(self) -> Any:
        return self._programma.animatore

    def messaggio(self, testo: str, titolo: str = "Leo") -> None:
        self._programma.dialogo("messaggio", str(testo), str(titolo))

    def domanda(self, testo: str, titolo: str = "Leo") -> bool:
        return bool(self._programma.dialogo("domanda", str(testo), str(titolo)))

    def apri_finestra(self, nome: str) -> None:
        self._programma.apri_finestra(nome)

    def chiudi_finestra(self, nome: str) -> None:
        self._programma.chiudi_finestra(nome)

    def attendi(self, secondi: float) -> None:
        """L'interfaccia resta viva: intanto arrivano gli eventi e scattano i temporizzatori."""
        self._programma.gira_fino(time.monotonic() + max(0.0, float(secondi)))
        self._programma.controlla_arresto()
        self._programma.sincronizza_animazioni()

    def pianifica_temporizzatore(self, secondi: float, funzione: Any, ripeti: bool) -> Any:
        """``ogni``/``dopo``: il corpo gira come un gestore ``quando``."""
        p = self._programma
        return p.pianificatore.aggiungi(float(secondi), lambda: p.esegui_poi(funzione), ripeti=bool(ripeti))

    def scegli_file(self, titolo: str = "Apri", modalita: str = "apri",
                    filtro: str = "Tutti i file (*.*)") -> str | None:
        raise azioni.errore_non_disponibile("La scelta di un file (DialogoFile) sul telefono")

    def chiedi_testo(self, domanda: str) -> str:
        """``chiedi()`` nei programmi con finestre: una finestrella con una casella."""
        risposta = self._programma.dialogo("testo", str(domanda or ""), "Leo")
        return risposta if isinstance(risposta, str) else ""

    def controlla_arresto(self) -> None:
        self._programma.controlla_arresto()


# ===========================================================================
# Finestra
# ===========================================================================

class FinestraWeb:
    """Stato di una finestra: se l'interfaccia l'ha gia' costruita e se e' aperta."""

    def __init__(self, programma: "ProgrammaWeb", maschera: ModelloMaschera,
                 vivi: dict[str, ControlloVivo]) -> None:
        self.programma = programma
        self.maschera = maschera
        self.vivi = vivi
        self.nome = maschera.finestra.nome
        self.costruita = False      # l'interfaccia ha ricevuto il modello
        self.aperta = False
        self.chiusura_in_corso = False
        self.timer: dict[str, _Voce] = {}
        self._disegni_mandati: dict[str, tuple[int, int]] = {}   # Tela: (id della lista, quanti)
        self._precedenti: dict[str, Any] = {}                     # valori precedenti (vedi SEGUITE)
        from .. import effetti

        for vivo in vivi.values():
            vivo.osservatori.append(self._osserva)
            self._collega_azioni(vivo)
            if not getattr(vivo.tipo, "invisibile", False):
                effetti.aggiungi_vista(vivo, lambda dati, v=vivo: self._effetto(v, dati))
        self._correggi_scelte()
        self._valori_iniziali()
        giochi_web.prepara_finestra(self)                   # oggetti da gioco: classifica, mazzo, labirinto...

    # --- eventi che nascono dal codice (come in widget_dante) ---------------------
    #: Proprieta' il cui cambio fa partire un evento anche quando lo cambia il codice; come sul PC
    #: l'evento parte solo se il valore cambia davvero (serve il valore precedente).
    SEGUITE = {"Punteggio": "valore", "Quadrante": "valore", "Galleria": "indice", "Led": "acceso",
               "Semaforo": "stato", "Registro": "voci"}

    def ricorda(self, vivo: ControlloVivo) -> None:
        """Il valore attuale della proprieta' seguita di ``vivo`` (dopo un cambio dall'interfaccia)."""
        proprieta = self.SEGUITE.get(vivo.tipo_controllo)
        if proprieta is not None:
            self._precedenti[vivo.nome] = copy.deepcopy(vivo.modello.proprieta.get(proprieta))

    def _eventi_da_codice(self, vivo: ControlloVivo, proprieta: str, valore: Any) -> None:
        tipo = vivo.tipo_controllo
        if self.SEGUITE.get(tipo) != proprieta:
            return
        p = vivo.modello.proprieta
        emetti = self.programma.emetti_dopo
        prima = self._precedenti.get(vivo.nome)
        self.ricorda(vivo)
        if tipo == "Quadrante":
            try:
                from ..logica_dante import soglia_superata

                if soglia_superata(prima, valore, p.get("soglia", 80)):
                    emetti(vivo.nome, "soglia_superata", {"valore": valore})
            except Exception:  # noqa: BLE001
                pass
            return
        if tipo == "Registro":
            vecchie = prima if isinstance(prima, list) else []
            nuove = valore if isinstance(valore, list) else []
            # voci aggiunte in fondo (aggiungi): un evento per ciascuna, come sul PC
            if len(nuove) > len(vecchie) and nuove[:len(vecchie)] == vecchie:
                for voce in nuove[len(vecchie):]:
                    if isinstance(voce, dict):
                        emetti(vivo.nome, "nuova_voce", {"livello": str(voce.get("livello", "info")),
                                                         "testo": str(voce.get("testo", ""))})
            return
        if tipo == "Led":
            if bool(prima) != bool(valore):
                emetti(vivo.nome, "cambio", {"valore": bool(valore)})
            return
        if valore == prima:
            return
        if tipo == "Punteggio":
            emetti(vivo.nome, "cambio", {"valore": valore})
            try:
                if int(valore) > int(p.get("record", 0) or 0):
                    vivo.aggiorna_da_interfaccia("record", int(valore))
                    if self.costruita:
                        self.programma.accoda_proprieta(self, vivo, "record", int(valore))
                    emetti(vivo.nome, "nuovo_record", {"valore": int(valore)})
            except (TypeError, ValueError):
                pass
        elif tipo == "Galleria":
            emetti(vivo.nome, "cambio_immagine", {"indice": valore})
        elif tipo == "Semaforo":
            emetti(vivo.nome, "cambio", {"valore": valore})

    def _valori_iniziali(self) -> None:
        """Come i widget Qt al primo disegno: data di oggi, numeri nei limiti."""
        from .. import logica_controlli as logica

        for vivo in self.vivi.values():
            p = vivo.modello.proprieta
            if vivo.tipo_controllo == "SelettoreData":
                try:
                    anno, mese, giorno = logica.data_o_oggi(logica.testo_valore(p.get("data", "")))
                    vivo.aggiorna_da_interfaccia("data", logica.formatta_data(anno, mese, giorno))
                except Exception:  # noqa: BLE001
                    pass
            elif vivo.tipo_controllo in ("CasellaNumero", "Cursore", "BarraAvanzamento"):
                try:
                    minimo, massimo = float(p.get("minimo", 0)), float(p.get("massimo", 100))
                    v = p.get("valore", 0)
                    limitato = logica.limita(float(v), minimo, massimo)
                    if limitato != float(v):
                        vivo.aggiorna_da_interfaccia("valore", type(v)(limitato) if isinstance(v, int) else limitato)
                except (TypeError, ValueError):
                    pass
            self.ricorda(vivo)
        for vivo in self.vivi.values():
            if vivo.tipo_controllo in derivati.CASELLE_VALIDATE or vivo.tipo_controllo in ("MisuratorePassword",
                                                                                           "SelettoreComune"):
                self.aggiorna_derivati(vivo, "testo", manda=False)
            elif vivo.tipo_controllo == "CalendarioFestività":
                if not str(vivo.modello.proprieta.get("data") or "").strip():
                    try:
                        anno, mese, giorno = logica.data_o_oggi("")
                        vivo.aggiorna_da_interfaccia("data", logica.formatta_data(anno, mese, giorno))
                    except Exception:  # noqa: BLE001
                        pass
                self.aggiorna_derivati(vivo, "data", manda=False)
            if vivo.tipo_controllo == "MisuratorePassword" and vivo.modello.proprieta.get("controllo"):
                seguita = self.vivi.get(str(vivo.modello.proprieta.get("controllo")))
                if seguita is not None:
                    self.aggiorna_derivati(seguita, "testo", manda=False)

    # --- valori calcolati (caselle che si controllano da sole, misuratore, QR, comuni) ---------
    def aggiorna_derivati(self, vivo: ControlloVivo, proprieta: str, *, manda: bool,
                          da_interfaccia: bool = False) -> None:
        """Dopo che ``proprieta`` di ``vivo`` e' cambiata: proprieta' calcolate, dati per il disegno
        ed eventi (``valido``, ``cambio`` del misuratore), come i widget di widget_dante sul PC."""
        tipo = vivo.tipo_controllo
        p = vivo.modello.proprieta
        prima = {k: p.get(k) for k in ("valido", "punteggio", "livello")}
        cambiate: dict[str, Any] = {}
        for k, v in derivati.proprieta_calcolate(tipo, p, proprieta).items():
            if p.get(k) != v:
                vivo.aggiorna_da_interfaccia(k, v)
                cambiate[k] = v
        extra = derivati.extra_web(tipo, p, proprieta) if (tipo in ("GeneratoreQR", "MisuratorePassword")) else {}
        if tipo == "SelettoreComune" and proprieta == "testo" and da_interfaccia:
            extra["_suggerimenti"] = derivati.suggerimenti_comuni(str(p.get("testo") or ""))
        if manda and self.costruita:
            for k, v in {**cambiate, **extra}.items():
                self.programma.accoda_proprieta(self, vivo, k, v)
        if manda:
            emetti = self.programma.emetti_dopo
            if tipo in derivati.CASELLE_VALIDATE and "valido" in cambiate and bool(prima["valido"]) != bool(p.get("valido")):
                emetti(vivo.nome, "valido", {"valore": bool(p.get("valido")), "testo": str(p.get("testo") or "")})
            if tipo == "MisuratorePassword" and (prima["punteggio"], prima["livello"]) != (p.get("punteggio"), p.get("livello")):
                emetti(vivo.nome, "cambio", {"punteggio": p.get("punteggio"), "livello": p.get("livello")})
        # i MisuratorePassword che seguono questo controllo (proprieta' `controllo`)
        if proprieta == "testo" and tipo != "MisuratorePassword":
            for altro in self.vivi.values():
                if altro.tipo_controllo == "MisuratorePassword" \
                        and str(altro.modello.proprieta.get("controllo") or "") == vivo.nome:
                    testo = str(p.get("testo") or "")
                    if altro.modello.proprieta.get("testo") != testo:
                        altro.aggiorna_da_interfaccia("testo", testo)
                        if manda and self.costruita:
                            self.programma.accoda_proprieta(self, altro, "testo", testo)
                    self.aggiorna_derivati(altro, "testo", manda=manda)

    # --- Scelta: una sola selezionata per gruppo (come widget._sistema_scelte) ----
    def _correggi_scelte(self) -> None:
        from .. import logica_controlli as logica

        per_nome = {v.nome: v for v in self.vivi.values()}
        for nomi in logica.gruppi_esclusivi(v.modello for v in self.vivi.values()).values():
            voci = [(n, "", bool(per_nome[n].modello.proprieta.get("selezionata"))) for n in nomi]
            for nome in logica.correggi_gruppi_iniziali(voci):
                per_nome[nome].aggiorna_da_interfaccia("selezionata", False)

    def _spegni_sorelle(self, vivo: ControlloVivo) -> None:
        """Il codice ha selezionato una Scelta: le altre dello stesso gruppo si spengono."""
        from .. import logica_controlli as logica

        m = vivo.modello
        sorelle = [v for v in self.vivi.values() if v.tipo_controllo == "Scelta"
                   and (v.modello.contenitore or "") == (m.contenitore or "") and v.modello.scheda == m.scheda]
        voci = [(v.nome, str(v.modello.proprieta.get("gruppo", "") or ""), bool(v.modello.proprieta.get("selezionata")))
                for v in sorelle]
        for nome in logica.scelte_da_spegnere(voci, vivo.nome):
            altra = self.vivi[nome]
            altra.aggiorna_da_interfaccia("selezionata", False)
            if self.costruita:
                self.programma.accoda_proprieta(self, altra, "selezionata", False)

    # --- azioni che vogliono l'interfaccia -----------------------------------
    def _collega_azioni(self, vivo: ControlloVivo) -> None:
        tipo = vivo.tipo_controllo
        nome = vivo.nome
        tabella: dict[str, Callable[..., Any]] = {}
        manda = self.programma.azione_interfaccia
        if tipo in ("CasellaTesto", "CasellaPassword"):
            tabella["seleziona_tutto"] = lambda: manda(self, nome, "seleziona_tutto", [])
        elif tipo == "SelettoreColore":
            tabella["scegli"] = lambda: self._scegli_colore(vivo)
        elif tipo == "BarraStato":
            tabella["mostra_messaggio"] = lambda testo, ms=0: manda(self, nome, "mostra_messaggio", [testo, ms])
        elif tipo == "Collegamento":
            tabella["apri"] = lambda indirizzo: manda(self, nome, "apri", [indirizzo])
        elif tipo == "MenuContestuale":
            tabella["mostra"] = lambda: manda(self, nome, "mostra", [])
        elif tipo == "Notifica":
            tabella["mostra"] = lambda *a: manda(self, nome, "mostra", [valore_json(x) for x in a])
        elif tipo == "Albero":
            tabella["espandi_tutto"] = lambda: manda(self, nome, "espandi_tutto", [])
        elif tipo == "Tela":
            tabella["salva"] = lambda percorso: self._salva_immagine(vivo, percorso)
        elif tipo == "Lavagna":
            tabella["pulisci"] = lambda: manda(self, nome, "pulisci", [])
            tabella["annulla"] = lambda: manda(self, nome, "annulla", [])
            tabella["salva"] = lambda percorso: self._salva_immagine(vivo, percorso)
        elif tipo == "EditorCodice":
            tabella["vai_a_riga"] = lambda n: manda(self, nome, "vai_a_riga", [n])
        tabella.update(hardware.azioni(self, vivo))          # fotocamera, voce, sensori, torcia...
        if not tabella:
            return

        def gestore(azione: str, argomenti: list) -> Any:
            f = tabella.get(azione)
            if f is None:
                return azioni.NON_GESTITA
            risultato = f(*argomenti)
            return None if risultato is azioni.NON_GESTITA else risultato

        azioni.imposta_gestore(vivo, gestore)

    @staticmethod
    def _non_disponibile(cosa: str) -> Callable[..., Any]:
        def f(*_argomenti: Any) -> Any:
            raise azioni.errore_non_disponibile(cosa)
        return f

    def _scegli_colore(self, vivo: ControlloVivo) -> Any:
        """``SelettoreColore.scegli()``: la finestrella dei colori; se il colore cambia parte ``cambio``, come
        sul PC (il catalogo poi scrive ``colore``)."""
        prima = str(vivo.modello.proprieta.get("colore", "") or "")
        scelto = self.programma.dialogo("colore", "Scegli un colore", "Leo", valore=prima)
        if isinstance(scelto, str) and scelto and _colore_web(scelto) != _colore_web(prima):
            self.programma.emetti_dopo(vivo.nome, "cambio", {"valore": scelto})
        return scelto

    def _salva_immagine(self, vivo: ControlloVivo, percorso: Any) -> None:
        """``Tela.salva`` / ``Lavagna.salva``: la pagina manda il disegno come immagine, qui si scrive il file
        (nella cartella del progetto se il percorso non e' completo). PNG, oppure JPEG per .jpg/.jpeg."""
        from ...errori import ErroreFile

        testo = str(percorso or "").strip()
        if not testo:
            raise ErroreValore(f"`{vivo.nome}.salva`: indica il nome del file, per esempio \"disegno.png\".")
        p = Path(os.path.expanduser(testo))
        if not p.is_absolute():
            p = self.programma.cartella / p
        tipo = "image/jpeg" if p.suffix.lower() in (".jpg", ".jpeg") else "image/png"
        dati = self.programma.richiesta_interfaccia(self, vivo.nome, "immagine", [tipo])
        if not isinstance(dati, str) or not dati.startswith("data:") or "," not in dati:
            raise ErroreValore(f"Non riesco a salvare il disegno di `{vivo.nome}`: il telefono non l'ha mandato.")
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(base64.b64decode(dati.split(",", 1)[1]))
        except (OSError, ValueError) as e:
            raise ErroreFile(f"Non riesco a scrivere `{testo}`: {getattr(e, 'strerror', None) or e}.") from None

    # --- codice Leo -> interfaccia ------------------------------------------------
    def _osserva(self, vivo: ControlloVivo, proprieta: str, valore: Any) -> None:
        if vivo.tipo_controllo == "Timer":
            self._aggiorna_timer(vivo)
            return
        if vivo.tipo_controllo in hardware.TIPI_HARDWARE:
            hardware.osserva(self, vivo, proprieta, valore)
        self._eventi_da_codice(vivo, proprieta, valore)
        if proprieta in ("testo", "correzione", "controllo", "data"):
            if proprieta == "controllo" and vivo.tipo_controllo == "MisuratorePassword":
                seguita = self.vivi.get(str(valore or ""))
                if seguita is not None:
                    vivo.aggiorna_da_interfaccia("testo", str(seguita.modello.proprieta.get("testo") or ""))
                    if self.costruita:
                        self.programma.accoda_proprieta(self, vivo, "testo", vivo.modello.proprieta["testo"])
                    self.aggiorna_derivati(vivo, "testo", manda=True)
            else:
                self.aggiorna_derivati(vivo, proprieta, manda=True)
        if vivo.tipo_controllo == "Scelta" and proprieta in ("selezionata", "gruppo") \
                and vivo.modello.proprieta.get("selezionata"):
            self._spegni_sorelle(vivo)
        if not self.costruita:
            return
        if vivo.tipo_controllo == "Tela" and proprieta == "disegni":
            self._manda_disegni(vivo, valore)
            return
        self.programma.accoda_proprieta(self, vivo, proprieta, valore)

    def _effetto(self, vivo: ControlloVivo, dati: dict) -> None:
        """Effetto grafico (``rimbalza``, ``mostra_con``...): lo disegna la pagina con le animazioni CSS."""
        if self.costruita and self.aperta:
            self.programma.accoda({"op": "effetto", "f": self.nome, "c": vivo.nome, **valore_json(dati)})

    def _manda_disegni(self, vivo: ControlloVivo, disegni: Any) -> None:
        lista = disegni if isinstance(disegni, list) else []
        mandati = self._disegni_mandati.get(vivo.nome)
        if mandati is not None and mandati[0] == id(lista) and len(lista) >= mandati[1]:
            nuovi = lista[mandati[1]:]
            if nuovi:
                self.programma.accoda({"op": "disegni", "f": self.nome, "c": vivo.nome,
                                       "aggiungi": valore_json(nuovi)})
        else:
            self.programma.accoda_proprieta(self, vivo, "disegni", lista)
        self._disegni_mandati[vivo.nome] = (id(lista), len(lista))

    def modello(self) -> dict:
        m = modello_per_web(self.maschera, self.vivi)
        for voce in m.get("controlli", []):
            vivo = self.vivi.get(voce.get("nome"))
            if vivo is not None:
                voce.update(derivati.extra_web(vivo.tipo_controllo, vivo.modello.proprieta))
        for vivo in self.vivi.values():
            if vivo.tipo_controllo == "Tela":
                d = vivo.modello.proprieta.get("disegni")
                lista = d if isinstance(d, list) else []
                self._disegni_mandati[vivo.nome] = (id(lista), len(lista))
        return m

    # --- Timer (tutto in Python) -------------------------------------------------
    def avvia_timer(self) -> None:
        for vivo in self.vivi.values():
            if vivo.tipo_controllo == "Timer":
                self._aggiorna_timer(vivo)

    def _aggiorna_timer(self, vivo: ControlloVivo) -> None:
        if not self.costruita:          # i Timer partono quando la finestra si apre (come in Qt)
            return
        vecchio = self.timer.pop(vivo.nome, None)
        if vecchio is not None:
            vecchio.stop()
        p = vivo.modello.proprieta
        if not p.get("attivo", True):
            return
        try:
            intervallo = max(1, int(p.get("intervallo", 1000) or 1000)) / 1000.0
        except (TypeError, ValueError):
            intervallo = 1.0
        nome = vivo.nome
        self.timer[nome] = self.programma.pianificatore.aggiungi(
            intervallo, lambda: self.programma.emetti_evento(nome, "scatto", {}), ripeti=True)

    def ferma_timer(self) -> None:
        for voce in self.timer.values():
            voce.stop()
        self.timer.clear()


# ===========================================================================
# Programma
# ===========================================================================

class ProgrammaWeb:
    """Un progetto con finestre in esecuzione, disegnato da un'interfaccia web.

    ``cartella``: cartella del progetto (con ``progetto.toml`` e le ``.maschera``).
    ``canale``: vedi :class:`CanaleWeb`.
    ``uscita``: dove va ``stampa`` (predefinito: ``sys.stdout``).
    ``errore(errore, sorgente, fatale)``: chiamata per ogni errore Leo, prima della
    finestrella (sull'app Android va nella console); predefinito: ``sys.stderr``.
    ``interprete_creato(interprete)``: chiamata appena l'interprete esiste (per ``ferma``).
    """

    def __init__(self, cartella: str | os.PathLike, canale: CanaleWeb, *,
                 uscita: Callable[[str], None] | None = None,
                 errore: Callable[[ErroreDante, str | None, bool], None] | None = None,
                 avviso: Callable[[str], None] | None = None,
                 rigoroso: bool = False, riduci_animazioni: bool = False,
                 interprete_creato: Callable[[Any], None] | None = None) -> None:
        self.cartella = Path(cartella)
        self.canale = canale
        self._uscita = uscita
        self._errore_esterno = errore
        self._avviso = avviso or _avviso_stderr
        self.rigoroso = bool(rigoroso)
        self._interprete_creato = interprete_creato
        self.progetto: Any = None
        self.maschere: dict[str, ModelloMaschera] = {}
        self.vivi: dict[str, dict[str, ControlloVivo]] = {}
        self.finestre: dict[str, FinestraWeb] = {}
        self.alias: dict[str, str] = {}
        self.sorgenti: dict[str, str] = {}
        self.ponte = PonteWeb(self)
        self.pianificatore = Pianificatore()
        self.interprete: Any = None
        self.fermato = False
        self.codice_uscita = 0
        self.nome_iniziale = ""
        self._uscita_richiesta = False       # ferma() da un altro thread
        self._in_uscita: list[dict] = []
        self._gruppo = 0                     # giri del ciclo in corso (vedi _svuota_fine_gestore)
        self._inizio_gruppo = 0.0
        self._rimandati: list[dict] = []
        self._risposte: dict[int, Any] = {}
        self._id_dialogo = itertools.count(1)
        self._risorse_mandate: set[str] = set()
        self._errore_aperto = False
        self._chiuso = False                 # il canale ha risposto None
        self.animatore: Any = None
        self._riduci_animazioni = bool(riduci_animazioni)

    # ------------------------------------------------------------------ avvio
    def esegui(self) -> int:
        """Esegue il progetto fino alla chiusura della finestra iniziale; codice d'uscita."""
        try:
            return self._esegui()
        except SegnaleFermaProgramma:
            return self.codice_uscita
        finally:
            self._chiudi_tutto()

    def _esegui(self) -> int:
        from ...esecuzione import esegui_sorgente
        from ...interprete import Interprete
        from ...progetto import carica_progetto
        from ..metadati import carica_catalogo

        try:
            self.progetto = carica_progetto(self.cartella)
        except ErroreDante as e:
            self.mostra_errore(e, fatale=True)
            return 1
        self.rigoroso = self.rigoroso or bool(self.progetto.rigoroso)
        carica_catalogo()
        self._carica_personalizzati()
        self.animatore = self._crea_animatore()
        opzioni_interprete: dict[str, Any] = {}
        if self._uscita is not None:
            opzioni_interprete["uscita"] = self._uscita
        self.interprete = Interprete(nome_file=f"{self.progetto.nome}", ponte_grafico=self.ponte,
                                     ingresso=self.ponte.chiedi_testo,
                                     dichiarazione_implicita=self.progetto.stile.dichiarazione_implicita,
                                     **opzioni_interprete)
        self.interprete.percorsi_moduli.append(str(self.cartella))
        if self.rigoroso:
            self.interprete.tollerante = False
        if self._interprete_creato is not None:
            self._interprete_creato(self.interprete)
        if self._uscita_richiesta:
            return 0
        if not self._carica_maschere():
            return 1
        opzioni = self._opzioni_lessico()
        for nome in list(self.maschere):
            percorso = self.progetto.percorso_codice(nome)
            if not percorso.is_file():
                continue
            try:
                with open(percorso, "r", encoding="utf-8-sig") as f:
                    sorgente = f.read()
            except OSError as e:
                from ...errori import ErroreFile

                self.mostra_errore(ErroreFile(f"Non riesco a leggere `{percorso.name}`: {e.strerror or e}."),
                                   fatale=True)
                return 1
            self.sorgenti[percorso.name] = sorgente
            try:
                esegui_sorgente(sorgente, percorso.name, interprete=self.interprete, **opzioni)
            except ErroreSintassi as e:
                self.mostra_errore(e, fatale=True)
                return 1
            except SegnaleFermaProgramma:
                return self.codice_uscita
            except ErroreDante as e:
                self.mostra_errore(e)
            except RecursionError:
                self.mostra_errore(ErroreRicorsione("Troppe chiamate annidate."))
            if self.fermato or self._fermo_richiesto():
                return self.codice_uscita
        self._avvisi_gestori()
        iniziale = self.progetto.finestra_iniziale or (next(iter(self.maschere)) if self.maschere else "")
        chiave = self.alias.get(iniziale, iniziale)
        if chiave not in self.maschere:
            self.mostra_errore(ErroreNome(f"La finestra iniziale `{iniziale}` non esiste nel progetto.",
                                          suggerimento=self._suggerisci_finestra(iniziale), nome=iniziale),
                               fatale=True)
            return 1
        self.nome_iniziale = chiave
        self.apri_finestra(chiave)
        self._ciclo()
        return self.codice_uscita

    def _opzioni_lessico(self) -> dict:
        opzioni: dict = {"rigoroso": self.rigoroso, "stile": self.progetto.stile}
        if self.progetto.file_sinonimi is not None:
            opzioni["sinonimi_extra"] = [self.progetto.file_sinonimi]
        if self.progetto.sinonimi:
            opzioni["dizionari_sinonimi"] = [self.progetto.sinonimi]
        return opzioni

    def _carica_personalizzati(self) -> None:
        try:
            from ..personalizzati import carica_controlli_personalizzati

            carica_controlli_personalizzati(self.cartella)
        except ErroreDante as e:
            self._avviso(f"controlli personalizzati: {e.messaggio}")
        except Exception as e:  # noqa: BLE001 - un .controllo rotto non impedisce l'avvio
            self._avviso(f"non riesco a caricare i controlli personalizzati: {e}")

    def _crea_animatore(self) -> Any:
        try:
            motore = MotoreAnimazioniWeb(self, riduci=self._riduci_animazioni)
            from ...libreria.animazioni import imposta_motore

            imposta_motore(motore)
            return motore
        except Exception:  # noqa: BLE001 - senza animazioni il programma funziona lo stesso
            return None

    def finestra_di(self, controllo: Any) -> "FinestraWeb | None":
        """La finestra che contiene il ``ControlloVivo`` (None se non e' di nessuna)."""
        for finestra in self.finestre.values():
            if finestra.vivi.get(getattr(controllo, "nome", None)) is controllo:
                return finestra
        return None

    def sincronizza_animazioni(self) -> None:
        """Prima di eseguire codice Leo: i valori delle animazioni in corso a questo istante."""
        sincronizza = getattr(self.animatore, "sincronizza", None)
        if callable(sincronizza):
            try:
                sincronizza()
            except Exception:  # noqa: BLE001 - solo valori intermedi: mai un errore per questo
                traceback.print_exc()

    def colori_partenza(self, controllo: Any) -> dict:
        from .. import temi_controlli as tc

        tema = "moderno"
        for chiave, vivi in self.vivi.items():
            if any(v is controllo for v in vivi.values()):
                finestra = vivi.get(chiave)
                if finestra is not None:
                    tema = str(finestra.modello.proprieta.get("tema_controlli", "moderno") or "moderno")
                break
        return tc.colori_partenza(getattr(controllo, "tipo_controllo", ""), tema)

    def _carica_maschere(self) -> bool:
        from ..maschera import carica_maschera

        nomi = list(self.progetto.finestre)
        if self.progetto.finestra_iniziale and self.progetto.finestra_iniziale not in nomi \
                and self.progetto.percorso_maschera(self.progetto.finestra_iniziale).is_file():
            nomi.insert(0, self.progetto.finestra_iniziale)
        for nome in nomi:
            percorso = self.progetto.percorso_maschera(nome)
            try:
                maschera = carica_maschera(percorso)
            except ErroreDante as e:
                if e.nome_file == "<sorgente>":
                    e.nome_file = percorso.name
                self.mostra_errore(e, fatale=True)
                return False
            chiave = maschera.nome
            if chiave != nome:
                self._avviso(f"il file `{percorso.name}` contiene la finestra `{chiave}`: nel codice si chiama "
                             f"`{chiave}`.")
                self.alias[nome] = chiave
            if chiave in self.maschere:
                self._avviso(f"la finestra `{chiave}` compare due volte nel progetto: uso la prima.")
                continue
            self.maschere[chiave] = maschera
            self.vivi[chiave] = self._crea_vivi(maschera)
            self.finestre[chiave] = FinestraWeb(self, maschera, self.vivi[chiave])
        return True

    def _crea_vivi(self, maschera: ModelloMaschera) -> dict[str, ControlloVivo]:
        vivi: dict[str, ControlloVivo] = {}
        for modello in maschera.tutti():
            try:
                vivo = ControlloVivo(modello)
            except ErroreDante as e:
                self._avviso(f"`{modello.nome}` in `{maschera.nome}`: {e.messaggio}")
                continue
            vivo.cartella_progetto = self.cartella
            vivi[modello.nome] = vivo
            try:
                self.interprete.globale.dichiara(modello.nome, vivo, costante=True)
            except ErroreDante:
                self._avviso(f"il nome `{modello.nome}` è usato in più finestre (o per altro): nel codice "
                             f"`{modello.nome}` indica il primo.")
        visibili, invisibili = set(), set()
        for m in maschera.controlli:
            vivo = vivi.get(m.nome)
            if m.tipo in TIPI_SUPPORTATI_WEB or vivo is None:
                continue
            (invisibili if getattr(vivo.tipo, "invisibile", False) else visibili).add(m.tipo)
        if visibili:
            self._avviso(f"nella finestra `{maschera.nome}` ci sono controlli che sul telefono non ci sono "
                         f"ancora: {', '.join(sorted(visibili))} (al loro posto compare un riquadro).")
        if invisibili:
            self._avviso(f"nella finestra `{maschera.nome}` ci sono controlli invisibili che sul telefono non "
                         f"funzionano: {', '.join(sorted(invisibili))}.")
        return vivi

    def _avvisi_gestori(self) -> None:
        from .. import temi_controlli as tc

        eventi: dict[str, tuple] = {}
        tipi: dict[str, str] = {}
        for vivi in self.vivi.values():
            for nome, vivo in vivi.items():
                if nome not in eventi:
                    eventi[nome] = tuple(vivo.tipo.eventi)
                    tipi[nome] = vivo.tipo_controllo
        tollerante = bool(getattr(self.interprete, "tollerante", True)) and not self.rigoroso
        try:
            avvisi = tc.avvisi_gestori(list(self.interprete.gestori_evento), eventi, tipi, tollerante=tollerante)
        except Exception:  # noqa: BLE001 - solo consigli
            return
        for testo in avvisi:
            self._avviso(testo)

    def _suggerisci_finestra(self, nome: str) -> str | None:
        import difflib

        vicini = difflib.get_close_matches(nome, list(self.maschere), n=1)
        if vicini:
            return f"Forse intendevi `{vicini[0]}`?"
        if self.maschere:
            return "Finestre del progetto: " + ", ".join(f"`{n}`" for n in self.maschere) + "."
        return None

    # ------------------------------------------------------------------ messaggi verso l'interfaccia
    def accoda(self, messaggio: dict) -> None:
        self._in_uscita.append(messaggio)

    def accoda_proprieta(self, finestra: FinestraWeb, vivo: ControlloVivo, proprieta: str, valore: Any) -> None:
        """``imposta`` di una proprieta'; quelle consecutive dello stesso controllo si uniscono."""
        valore_web = proprieta_web(vivo, proprieta, valore)
        self._risorse_per(vivo, proprieta, valore)
        if vivo.tipo_controllo == "Finestra" and proprieta == "sfondo":
            valori = {"sfondo": valore_web, "_sfondo": sfondo_web(valore)}
        else:
            valori = {proprieta: valore_web}
        ultimo = self._in_uscita[-1] if self._in_uscita else None
        if ultimo is not None and ultimo.get("op") == "imposta" and ultimo.get("f") == finestra.nome \
                and ultimo.get("c") == vivo.nome:
            ultimo["p"].update(valori)
            return
        self.accoda({"op": "imposta", "f": finestra.nome, "c": vivo.nome, "p": valori})

    def azione_interfaccia(self, finestra: FinestraWeb, nome: str, azione: str, argomenti: list) -> None:
        if finestra.costruita:
            self.accoda({"op": "azione", "f": finestra.nome, "c": nome, "azione": azione,
                         "argomenti": valore_json(list(argomenti))})

    def richiesta_interfaccia(self, finestra: FinestraWeb, nome: str, azione: str, argomenti: list,
                              attesa: float = 15.0) -> Any:
        """Azione dell'interfaccia che risponde con un valore (``{"op": "azione", ..., "id"}`` ->
        ``{"tipo": "risposta", "id", "valore"}``); ``None`` se non risponde entro ``attesa`` secondi."""
        if not finestra.costruita or not finestra.aperta:
            return None
        numero = next(self._id_dialogo)
        self.accoda({"op": "azione", "f": finestra.nome, "c": nome, "azione": azione,
                     "argomenti": valore_json(list(argomenti)), "id": numero})
        self.svuota()
        vuoto = object()

        def prendi() -> Any:
            if numero not in self._risposte:
                return None
            valore = self._risposte.pop(numero)
            return vuoto if valore is None else valore

        r = self.aspetta_risposta(prendi, attesa)
        return None if r is vuoto else r

    def _apri_gruppo(self) -> None:
        if not self._gruppo:
            self._inizio_gruppo = time.monotonic()
        self._gruppo += 1

    def _svuota_fine_gestore(self) -> None:
        """Fine di un gestore o di un temporizzatore. Dentro un giro breve del ciclo degli eventi i
        messaggi aspettano la fine del giro (il ciclo svuota prima di ogni attesa); chi aspetta davvero
        (finestrelle, ``attendi``, risposte del telefono) chiama :meth:`svuota`. Se il programma sta
        finendo si manda subito (alla fine resta solo ``fine``)."""
        if self._gruppo and not self.fermato and time.monotonic() - self._inizio_gruppo < _DURATA_GRUPPO:
            return
        self.svuota()

    def svuota(self) -> None:
        """Manda all'interfaccia i messaggi in attesa (uno solo invio per gruppo)."""
        if not self._in_uscita or self._chiuso:
            self._in_uscita.clear()
            return
        messaggi, self._in_uscita = compatta_messaggi(self._in_uscita), []
        try:
            self.canale.invia(messaggi)
        except SegnaleFermaProgramma:
            raise
        except Exception:  # noqa: BLE001 - interfaccia chiusa: il programma si ferma
            traceback.print_exc()
            self._chiuso = True
            self.termina()

    # --- immagini -------------------------------------------------------------
    def _risorse_per(self, vivo: ControlloVivo, proprieta: str, valore: Any) -> None:
        percorsi = self._percorsi_immagine(vivo, proprieta, valore)
        mappa: dict[str, str] = {}
        for p in percorsi:
            if p in self._risorse_mandate:
                continue
            self._risorse_mandate.add(p)
            dati = self._data_uri(p)
            if dati:
                mappa[p] = dati
        if mappa:
            self.accoda({"op": "risorse", "mappa": mappa})

    def _percorsi_immagine(self, vivo: ControlloVivo, proprieta: str, valore: Any) -> list[str]:
        meta = vivo.tipo.proprieta.get(proprieta)
        if meta is None:
            return []
        if meta.tipo == "immagine" and isinstance(valore, str) and valore.strip():
            return [valore.strip()]
        if vivo.tipo_controllo == "Finestra" and proprieta == "sfondo":
            s = sfondo_web(valore)
            if s.get("tipo") in ("immagine", "motivo") and s.get("percorso"):
                return [str(s["percorso"])]
        if proprieta in ("immagini", "fotogrammi") and isinstance(valore, list):
            return [str(x).strip() for x in valore if isinstance(x, str) and x.strip()]
        return _percorsi_quotidiani(vivo.tipo_controllo, proprieta, valore)

    def _data_uri(self, percorso: str) -> str | None:
        if percorso.strip().lower().startswith("galleria:"):
            from ...galleria import percorso_vero       # elemento della galleria: il suo file vero

            vero = percorso_vero(percorso, self.cartella)
            if vero is None:
                return None
            percorso = vero
        p = Path(os.path.expanduser(percorso))
        if not p.is_absolute():
            p = self.cartella / p
        try:
            if not p.is_file() or p.stat().st_size > LIMITE_RISORSA:
                return None
            dati = p.read_bytes()
        except OSError:
            return None
        tipo = mimetypes.guess_type(p.name)[0] or "application/octet-stream"
        if p.suffix.lower() == ".svg":
            tipo = "image/svg+xml"
        return f"data:{tipo};base64,{base64.b64encode(dati).decode('ascii')}"

    def _risorse_finestra(self, finestra: FinestraWeb) -> None:
        for vivo in finestra.vivi.values():
            for proprieta, valore in vivo.modello.proprieta.items():
                self._risorse_per(vivo, proprieta, valore)

    # ------------------------------------------------------------------ finestre
    def _chiave(self, nome: Any) -> str:
        if not isinstance(nome, str):
            from ...valori import nome_tipo

            raise ErroreValore(f"Il nome di una finestra è un testo, non `{nome_tipo(nome)}`.",
                               suggerimento="Scrivi per esempio `apri_finestra(\"Finestra2\")`.")
        chiave = self.alias.get(nome, nome)
        if chiave not in self.maschere:
            raise ErroreNome(f"La finestra `{nome}` non esiste.", suggerimento=self._suggerisci_finestra(nome),
                             nome=nome)
        return chiave

    def apri_finestra(self, nome: str) -> None:
        if self.fermato:
            return
        chiave = self._chiave(nome)
        finestra = self.finestre[chiave]
        vivo = finestra.vivi.get(chiave)
        if finestra.aperta:
            if vivo is not None:
                vivo.aggiorna_da_interfaccia("visibile", True)
            self.accoda({"op": "mostra", "nome": chiave})
            return
        if vivo is not None:
            vivo.aggiorna_da_interfaccia("visibile", True)
        self._risorse_finestra(finestra)
        self.accoda({"op": "finestra", "nome": chiave, "iniziale": chiave == self.nome_iniziale,
                     "modello": finestra.modello(), "gestori": self._gestori_di(finestra),
                     "menu": self._menu_di(finestra)})
        finestra.costruita = True
        finestra.aperta = True
        finestra.avvia_timer()
        hardware.apertura(self, finestra)              # sensori, bussole, livelle, batteria
        self.svuota()
        self.emetti_evento(chiave, "apertura", {}, finestra=chiave)

    def _gestori_di(self, finestra: FinestraWeb) -> list[list[str]]:
        """Coppie [controllo, evento] con un gestore: l'interfaccia manda solo gli eventi utili."""
        risultato = []
        trova = getattr(self.interprete, "trova_gestore", None)
        for nome, vivo in finestra.vivi.items():
            for evento in vivo.tipo.eventi:
                try:
                    c = trova(nome, evento) if callable(trova) else None
                except Exception:  # noqa: BLE001
                    c = None
                if c is not None:
                    risultato.append([nome, evento])
        return risultato

    def _menu_di(self, finestra: FinestraWeb) -> list[dict]:
        try:
            from .. import temi_controlli as tc

            return valore_json(tc.menu_da_modelli(finestra.maschera))
        except Exception:  # noqa: BLE001
            return []

    def chiudi_finestra(self, nome: str) -> None:
        chiave = self._chiave(nome)
        finestra = self.finestre.get(chiave)
        if finestra is not None and finestra.aperta:
            self._chiudi(finestra, evento=True)
        elif chiave == self.nome_iniziale:
            self.termina()

    def _chiudi(self, finestra: FinestraWeb, *, evento: bool) -> None:
        if finestra.chiusura_in_corso or not finestra.aperta:
            return
        finestra.chiusura_in_corso = True
        try:
            if evento:
                self.emetti_evento(finestra.nome, "chiusura", {}, finestra=finestra.nome)
        finally:
            finestra.chiusura_in_corso = False
        finestra.aperta = False
        hardware.chiusura(self, finestra)              # si ferma cio' che i suoi controlli avevano acceso
        self.accoda({"op": "chiudi", "nome": finestra.nome})
        self.svuota()
        if self.fermato:
            return
        if finestra.nome == self.nome_iniziale or not any(f.aperta for f in self.finestre.values()):
            self.termina()

    def termina(self, codice: int = 0) -> None:
        """Ferma il programma: chiude tutte le finestre ed esce dal ciclo degli eventi."""
        if self.fermato:
            return
        self.fermato = True
        self.codice_uscita = self.codice_uscita or codice
        if self.interprete is not None:
            try:
                self.interprete.ferma()
            except Exception:  # noqa: BLE001
                pass

    def _chiudi_tutto(self) -> None:
        self.fermato = True
        if self.animatore is not None:
            try:
                self.animatore.chiudi()
                from ...libreria.animazioni import imposta_motore, motore_attivo

                if motore_attivo() is self.animatore:
                    imposta_motore(None)
            except Exception:  # noqa: BLE001
                pass
        for f in self.finestre.values():
            f.ferma_timer()
        self.pianificatore.svuota()
        self._in_uscita = [{"op": "fine"}]
        try:
            if not self._chiuso:
                self.canale.invia(self._in_uscita)
        except Exception:  # noqa: BLE001
            pass
        self._in_uscita = []

    # ------------------------------------------------------------------ arresto
    def ferma(self) -> None:
        """Da qualunque thread: il programma si ferma il prima possibile."""
        self._uscita_richiesta = True
        i = self.interprete
        if i is not None:
            try:
                i.ferma()
            except Exception:  # noqa: BLE001
                pass

    def _fermo_richiesto(self) -> bool:
        if self._uscita_richiesta:
            return True
        i = self.interprete
        return bool(i is not None and getattr(i, "_ferma_richiesta", False))

    def controlla_arresto(self) -> None:
        if self.fermato or self._fermo_richiesto():
            raise SegnaleFermaProgramma()

    # ------------------------------------------------------------------ ciclo degli eventi
    def _ciclo(self) -> None:
        self.gira_fino(None)

    def gira_fino(self, scadenza: float | None, finche: Callable[[], bool] | None = None) -> None:
        """Ciclo degli eventi fino a ``scadenza`` (None = fino alla fine del programma).

        ``finche``: se indicata, il ciclo finisce anche quando restituisce falso.
        """
        annidato = scadenza is not None
        while not self.fermato:
            if self._fermo_richiesto():
                if annidato:
                    raise SegnaleFermaProgramma()
                self.termina(0)
                break
            self.svuota()
            adesso = time.monotonic()
            if scadenza is not None and adesso >= scadenza:
                return
            if finche is not None and not finche():
                return
            if self._rimandati and not annidato:
                self._gestisci(self._rimandati.pop(0))
                continue
            scadute = self.pianificatore.scadute(adesso)
            if scadute:
                self._apri_gruppo()
                try:
                    for voce in scadute:
                        if self.fermato:
                            break
                        self._esegui_voce(voce)
                finally:
                    self._gruppo -= 1
                continue
            prossima = self.pianificatore.prossima()
            attesa = _ATTESA_MASSIMA
            if prossima is not None:
                attesa = min(attesa, max(0.0, prossima - adesso))
            if scadenza is not None:
                attesa = min(attesa, max(0.0, scadenza - adesso))
            eventi = self._ricevi(attesa)
            if eventi is None:
                self.termina(0)
                break
            self._apri_gruppo()
            try:
                for ev in eventi:
                    if self.fermato:
                        break
                    self._gestisci(ev)
            finally:
                self._gruppo -= 1
        if annidato and self.fermato:
            raise SegnaleFermaProgramma()

    def _ricevi(self, attesa: float) -> list[dict] | None:
        if self._chiuso:
            return None
        try:
            eventi = self.canale.ricevi(attesa)
        except Exception:  # noqa: BLE001 - interfaccia chiusa
            traceback.print_exc()
            self._chiuso = True
            return None
        if eventi is None:
            self._chiuso = True
            return None
        return [e for e in eventi if isinstance(e, dict)]

    def _esegui_voce(self, voce: _Voce) -> None:
        try:
            voce.funzione()
        except SegnaleFermaProgramma:
            self.termina()
        except ErroreDante as e:
            self.mostra_errore(e)
        except Exception as e:  # noqa: BLE001
            traceback.print_exc()
            self.mostra_errore(ErroreValore(f"Errore interno di Leo in un temporizzatore: {e}"))

    # --- eventi dall'interfaccia --------------------------------------------------
    def _gestisci(self, ev: dict) -> None:
        tipo = ev.get("tipo")
        if tipo == "risposta":
            try:
                self._risposte[int(ev.get("id"))] = ev.get("valore")
            except (TypeError, ValueError):
                pass
            return
        finestra = self.finestre.get(str(ev.get("f", "")))
        agg = ev.get("agg")
        if finestra is not None and isinstance(agg, dict):
            self._applica_aggiornamenti(finestra, agg)
        if tipo == "sincronizza" or finestra is None:
            return
        if tipo == "hardware":
            hardware.gestisci_evento(self, finestra, ev)
            return
        if tipo == "gioco":
            giochi_web.gestisci(self, finestra, ev)
            return
        if tipo == "evento":
            nome = str(ev.get("c", ""))
            evento = str(ev.get("e", ""))
            dati = ev.get("d") if isinstance(ev.get("d"), dict) else {}
            vivo = finestra.vivi.get(nome)
            if vivo is None or not evento:
                return
            dati = self._normalizza_evento(vivo, evento, dict(dati))
            finestra.ricorda(vivo)
            if dati is None:
                return
            self.emetti_evento(nome, evento, dati, finestra=finestra.nome)
        elif tipo == "dimensione":
            vivo = finestra.vivi.get(finestra.nome)
            try:
                larghezza, altezza = int(ev.get("larghezza")), int(ev.get("altezza"))
            except (TypeError, ValueError):
                return
            if vivo is not None:
                vivo.aggiorna_da_interfaccia("larghezza", larghezza)
                vivo.aggiorna_da_interfaccia("altezza", altezza)
            self.emetti_evento(finestra.nome, "ridimensionamento", {"larghezza": larghezza, "altezza": altezza},
                               finestra=finestra.nome)
        elif tipo == "chiusura":
            if finestra.aperta:
                self._chiudi(finestra, evento=True)

    def _applica_aggiornamenti(self, finestra: FinestraWeb, agg: dict) -> None:
        for nome, valori in agg.items():
            vivo = finestra.vivi.get(str(nome))
            if vivo is None or not isinstance(valori, dict):
                continue
            for proprieta, valore in valori.items():
                if proprieta not in vivo.tipo.proprieta or proprieta == "nome":
                    continue
                vivo.aggiorna_da_interfaccia(proprieta, self._valore_da_interfaccia(vivo, proprieta, valore))
                if proprieta in ("testo", "data"):
                    finestra.aggiorna_derivati(vivo, proprieta, manda=True, da_interfaccia=True)
            finestra.ricorda(vivo)

    @staticmethod
    def _valore_da_interfaccia(vivo: ControlloVivo, proprieta: str, valore: Any) -> Any:
        meta = vivo.tipo.proprieta[proprieta]
        if meta.tipo == "intero" and isinstance(valore, float) and valore.is_integer():
            return int(valore)
        if meta.tipo == "decimale" and isinstance(valore, int) and not isinstance(valore, bool):
            return float(valore)
        return valore

    def _normalizza_evento(self, vivo: ControlloVivo, evento: str, dati: dict) -> dict | None:
        """Dati dell'evento come li produce lo strato Qt (con la logica pura di ``logica_controlli``)."""
        from .. import logica_controlli as logica

        tipo = vivo.tipo_controllo
        p = vivo.modello.proprieta
        if tipo in ("Elenco", "MenuATendina") and evento == "selezione":
            elementi = p.get("elementi") if isinstance(p.get("elementi"), list) else []
            indici = dati.get("indici")
            if not isinstance(indici, list):
                indici = [dati.get("indice", -1)]
            indici = logica.normalizza_indici([i for i in indici if isinstance(i, (int, float))
                                               and not isinstance(i, bool)], len(elementi))
            multipla = bool(p.get("multipla", False)) and tipo == "Elenco"
            risultato = logica.dati_evento_selezione(elementi, indici, multipla)
            vivo.aggiorna_da_interfaccia("indice_selezionato", risultato["indice"])
            vivo.aggiorna_da_interfaccia("selezione", risultato["elemento"])
            return risultato
        if tipo == "CasellaNumero" and evento == "cambio":
            try:
                decimali = int(p.get("decimali", 0) or 0)
                valore = logica.valore_numero(float(dati.get("valore", p.get("valore", 0))), decimali)
                minimo, massimo = float(p.get("minimo", 0)), float(p.get("massimo", 100))
                valore = type(valore)(logica.limita(valore, minimo, massimo))
            except (TypeError, ValueError, ErroreDante):
                return None
            vivo.aggiorna_da_interfaccia("valore", valore)
            return {"valore": valore}
        if tipo == "Cursore" and evento == "cambio":
            try:
                valore = int(round(float(dati.get("valore", 0))))
            except (TypeError, ValueError):
                return None
            vivo.aggiorna_da_interfaccia("valore", valore)
            return {"valore": valore}
        if tipo == "Tabella":
            grezze = p.get("righe") if isinstance(p.get("righe"), list) else []
            righe = [list(r) if isinstance(r, list) else [r] for r in grezze]
            try:
                r, k = int(dati.get("riga", -1)), int(dati.get("colonna", 0))
            except (TypeError, ValueError):
                return None
            if evento == "modifica_cella":
                if not 0 <= r < len(righe) or k < 0:
                    return None
                while len(righe[r]) <= k:
                    righe[r].append("")
                valore = logica.converti_cella(str(dati.get("testo", "")), righe[r][k])
                righe[r][k] = valore
                vivo.aggiorna_da_interfaccia("righe", righe)
                return {"riga": r, "colonna": k, "valore": valore}
            if evento == "selezione":
                vivo.aggiorna_da_interfaccia("riga_selezionata", r)
                valore = righe[r][k] if 0 <= r < len(righe) and 0 <= k < len(righe[r]) else None
                return {"riga": r, "colonna": k, "valore": valore}
        if tipo == "Schede" and evento == "cambio_scheda":
            try:
                indice = int(dati.get("indice", 0))
            except (TypeError, ValueError):
                return None
            vivo.aggiorna_da_interfaccia("scheda_corrente", indice)
            return {"indice": indice}
        if tipo == "Valutazione" and evento == "cambio":
            try:
                valore = int(dati.get("valore", 0))
            except (TypeError, ValueError):
                return None
            vivo.aggiorna_da_interfaccia("valore", valore)
            return {"valore": valore}
        if tipo == "BarraStrumenti" and evento == "clic" and "indice" in dati:
            pulsanti = p.get("pulsanti") if isinstance(p.get("pulsanti"), list) else []
            return logica.dati_evento_barra(pulsanti, _intero(dati.get("indice"), -1))
        if tipo == "MenuContestuale" and evento == "clic" and "indice" in dati:
            voci = p.get("voci") if isinstance(p.get("voci"), list) else []
            return logica.dati_evento_menu(voci, _intero(dati.get("indice"), -1))
        if tipo == "Grafico" and evento == "clic" and "indice" in dati:
            risultato = logica.dati_evento_grafico(p.get("dati"), _intero(dati.get("indice"), -1))
            risultato.update({k: dati[k] for k in ("x", "y") if k in dati})
            return risultato
        if tipo == "Galleria" and evento == "cambio_immagine":
            indice = _intero(dati.get("indice"), 0)
            vivo.aggiorna_da_interfaccia("indice", indice)
            return {"indice": indice}
        if tipo == "CasellaImporto" and evento == "cambio":
            try:
                valore = round(float(dati.get("valore", p.get("valore", 0.0))), max(0, _intero(p.get("decimali"), 2)))
            except (TypeError, ValueError):
                return None
            vivo.aggiorna_da_interfaccia("valore", valore)
            return {"valore": valore}
        if tipo == "Joystick" and evento == "movimento":
            try:
                x, y = float(dati.get("x", 0.0)), float(dati.get("y", 0.0))
            except (TypeError, ValueError):
                return None
            x, y = max(-1.0, min(1.0, x)), max(-1.0, min(1.0, y))
            vivo.aggiorna_da_interfaccia("x", x)
            vivo.aggiorna_da_interfaccia("y", y)
            return {"x": x, "y": y, "angolo": float(dati.get("angolo", 0.0) or 0.0),
                    "forza": float(dati.get("forza", 0.0) or 0.0)}
        if tipo == "EditorCodice" and evento == "cambio":
            return {"valore": str(p.get("testo") or "")}
        if tipo == "Terminale" and evento == "comando":
            return {"testo": str(dati.get("testo", ""))}
        if tipo == "SelettoreComune" and evento == "selezione":
            comune = p.get("comune") if isinstance(p.get("comune"), dict) else {}
            return {"comune": comune}
        if tipo == "CalendarioFestività" and evento == "selezione":
            return {"data": str(p.get("data") or ""), "festivita": str(p.get("festivita") or "")}
        if tipo == "VoceMenu" and evento == "clic" and p.get("spuntabile"):
            spuntata = not bool(p.get("spuntata", False))
            vivo.aggiorna_da_interfaccia("spuntata", spuntata)
            dati.setdefault("spuntata", spuntata)
        return dati

    # --- gestori quando ------------------------------------------------------------
    def emetti_evento(self, controllo: str, evento: str, dati: dict, *, finestra: str | None = None) -> bool:
        """Chiama il gestore ``quando controllo.evento``; gli errori si mostrano e il programma continua."""
        if self.fermato or self.interprete is None:
            return False
        self.sincronizza_animazioni()
        esiste = False
        try:
            esiste = bool(self.interprete.chiama_gestore(controllo, evento, dati))
        except SegnaleFermaProgramma:
            self.termina()
            return esiste
        except ErroreDante as e:
            esiste = True
            self.mostra_errore(e)
        except RecursionError:
            self.mostra_errore(ErroreRicorsione(f"Troppe chiamate annidate nel gestore `{controllo}.{evento}`."))
        except Exception as e:  # noqa: BLE001 - errore interno: si mostra, il programma continua
            traceback.print_exc()
            self.mostra_errore(ErroreValore(f"Errore interno di Leo nel gestore `{controllo}.{evento}`: {e}"))
        if self.interprete is not None and (self.interprete.fermato or self._uscita_richiesta):
            self.termina()
        self._svuota_fine_gestore()
        return esiste

    def emetti_dopo(self, controllo: str, evento: str, dati: dict) -> None:
        """Evento che nasce dal codice (es. ``nuovo_record``): parte appena il gestore attuale finisce."""
        trova = getattr(self.interprete, "trova_gestore", None)
        try:
            if callable(trova) and trova(controllo, evento) is None:
                return
        except Exception:  # noqa: BLE001
            return
        self.pianificatore.aggiungi(0, lambda: self.emetti_evento(controllo, evento, dict(dati)))

    def esegui_poi(self, funzione: Any) -> None:
        """Corpo di ``ogni``/``dopo`` e ``poi`` delle animazioni: come un gestore ``quando``."""
        if self.fermato or self.interprete is None:
            return
        self.sincronizza_animazioni()
        try:
            self.interprete.chiama(funzione, [])
        except SegnaleFermaProgramma:
            self.termina()
            return
        except ErroreDante as e:
            self.mostra_errore(e)
        except RecursionError:
            self.mostra_errore(ErroreRicorsione("Troppe chiamate annidate in un temporizzatore."))
        if self.interprete is not None and self.interprete.fermato:
            self.termina()
        self._svuota_fine_gestore()

    # --- finestre di dialogo ------------------------------------------------------
    def dialogo(self, tipo: str, testo: str, titolo: str = "Leo", **altro: Any) -> Any:
        """Finestrella modale nell'interfaccia; aspetta la risposta (gli altri eventi aspettano).

        ``tipo``: "messaggio" (-> None), "domanda" (-> bool), "testo" (-> str), "colore" (-> str o None),
        "errore" (-> "ferma" o "continua").
        """
        self.controlla_arresto()
        numero = next(self._id_dialogo)
        messaggio = {"op": "dialogo", "id": numero, "tipo": tipo, "titolo": titolo, "testo": testo}
        messaggio.update({k: valore_json(v) for k, v in altro.items()})
        self.accoda(messaggio)
        self.svuota()
        while numero not in self._risposte:
            if self.fermato or self._fermo_richiesto():
                raise SegnaleFermaProgramma()
            eventi = self._ricevi(_ATTESA_MASSIMA)
            if eventi is None:
                self.termina()
                raise SegnaleFermaProgramma()
            for ev in eventi:
                if ev.get("tipo") == "risposta" or ev.get("tipo") == "sincronizza":
                    self._gestisci(ev)
                else:
                    self._rimandati.append(ev)   # clic arrivati prima della finestrella: dopo
        valore = self._risposte.pop(numero)
        if tipo == "domanda":
            return valore is True or valore == "si"
        if tipo == "testo":
            return "" if valore is None else str(valore)
        if tipo == "colore":
            return str(valore) if isinstance(valore, str) and valore else None
        return valore

    # --- risposte dell'hardware del telefono ---------------------------------------------
    def aspetta_risposta(self, prendi: Callable[[], Any], attesa: float) -> Any:
        """Aspetta (al massimo ``attesa`` secondi) che ``prendi()`` restituisca qualcosa (non None).

        Per i metodi che vogliono la risposta del telefono (``Torcia1.accendi()``, ``Batteria1.aggiorna()``):
        intanto arrivano solo le risposte; gli altri eventi (tocchi, letture) restano per dopo.
        """
        scadenza = time.monotonic() + max(0.0, float(attesa))
        while True:
            r = prendi()
            if r is not None:
                return r
            if self.fermato or self._fermo_richiesto():
                raise SegnaleFermaProgramma()
            resto = scadenza - time.monotonic()
            if resto <= 0:
                return None
            eventi = self._ricevi(min(_ATTESA_MASSIMA, resto))
            if eventi is None:
                self.termina()
                raise SegnaleFermaProgramma()
            for ev in eventi:
                tipo = ev.get("tipo")
                interno = ev.get("evento") if isinstance(ev.get("evento"), dict) else {}
                if tipo in ("risposta", "sincronizza") or (tipo == "hardware" and interno.get("tipo") == "risposta"):
                    self._gestisci(ev)
                else:
                    self._rimandati.append(ev)

    # --- errori ----------------------------------------------------------------------
    def mostra_errore(self, errore: ErroreDante, *, fatale: bool = False) -> None:
        sorgente = self.sorgenti.get(getattr(errore, "nome_file", "") or "")
        if self._errore_esterno is not None:
            try:
                self._errore_esterno(errore, sorgente, fatale)
            except Exception:  # noqa: BLE001
                traceback.print_exc()
        else:
            try:
                testo = errore.formatta(sorgente)
            except Exception:  # noqa: BLE001
                testo = errore.breve()
            _avviso_stderr(testo)
        if fatale or self._errore_aperto or not any(f.aperta for f in self.finestre.values()):
            return
        self._errore_aperto = True
        try:
            scelta = self.dialogo("errore", errore.breve(), "Errore nel programma")
        except SegnaleFermaProgramma:
            scelta = "ferma"
        finally:
            self._errore_aperto = False
        if scelta == "ferma":
            self.codice_uscita = 1
            self.termina(1)


def esegui_progetto_web(cartella: str | os.PathLike, canale: CanaleWeb, **opzioni: Any) -> int:
    """Esegue il progetto con finestre nella ``cartella`` usando il ``canale``; codice d'uscita."""
    return ProgrammaWeb(cartella, canale, **opzioni).esegui()


def compatta_messaggi(messaggi: list[dict]) -> list[dict]:
    """Un gruppo di messaggi piu' corto, con lo stesso effetto nella pagina (che applica il gruppo tutto
    insieme, senza disegnare nel mezzo):

    * gli ``imposta`` dello stesso controllo diventano uno solo, al posto del primo, finche' in mezzo non
      c'e' un messaggio d'altro tipo (``finestra``, ``azione``, ``risorse``...: l'ordine con quelli conta);
      una proprieta' impostata di nuovo passa in fondo (come nell'ordine vero);
    * i ``disegni`` consecutivi della stessa tela diventano uno.
    """
    if len(messaggi) < 2:
        return messaggi
    fuori: list[dict] = []
    visti: dict[tuple, dict] = {}
    for m in messaggi:
        op = m.get("op")
        if op == "imposta" and isinstance(m.get("p"), dict):
            chiave = (m.get("f"), m.get("c"))
            primo = visti.get(chiave)
            if primo is not None:
                p = primo["p"]
                for k, v in m["p"].items():
                    p.pop(k, None)
                    p[k] = v
                continue
            visti[chiave] = m
        else:
            visti = {}
            if op == "disegni" and fuori:
                ultimo = fuori[-1]
                if (ultimo.get("op") == "disegni" and ultimo.get("f") == m.get("f") and ultimo.get("c") == m.get("c")
                        and isinstance(ultimo.get("aggiungi"), list) and isinstance(m.get("aggiungi"), list)):
                    ultimo["aggiungi"] = ultimo["aggiungi"] + m["aggiungi"]
                    continue
        fuori.append(m)
    return fuori


def messaggi_json(messaggi: list[dict]) -> str:
    """I messaggi come testo JSON (per i canali che passano testo)."""
    return json.dumps(messaggi, ensure_ascii=False, separators=(",", ":"))


__all__ = ["CanaleWeb", "PonteWeb", "ProgrammaWeb", "FinestraWeb", "Pianificatore", "MotoreAnimazioniWeb",
           "TIPI_SUPPORTATI_WEB", "LIMITE_RISORSA", "modello_per_web", "valore_json", "proprieta_web",
           "sfondo_web", "esegui_progetto_web", "messaggi_json", "compatta_messaggi"]
