"""Catalogo dei 43 controlli inventati per Leo (CONTRATTI.md §13.1 e tabella
"Controlli inventati per Leo" di PROGETTO.md).

API:
    tipi() -> list[TipoControllo]     # oggetti NUOVI a ogni chiamata (43 tipi)
    DATI_EVENTI                       # tipo -> evento -> chiavi del dizionario `evento`

All'import il modulo registra i 43 tipi nel catalogo condiviso
(``for t in tipi(): registra(t)``). I test contano con :func:`tipi` e non
svuotano mai ``metadati.CATALOGO``.

Metodi dei controlli: funzioni ``f(controllo_vivo, *argomenti)``.

* Quelli *puri* cambiano ``controllo.modello.proprieta`` e chiamano
  ``controllo.avvisa(proprieta, valore)`` (il widget Qt, se c'e', si aggiorna
  tramite l'osservatore): Led, Punteggio, Galleria, Oscilloscopio, Registro,
  Kanban, Diagramma, Mappa, ContoAllaRovescia, Scena, Sprite.sposta...
* Quelli che richiedono il widget o un dispositivo usano
  ``azioni.richiedi_interfaccia(controllo, "<nome_metodo>", *argomenti)``; se
  il controllo non ha interfaccia usano un ripiego chiaro (simulazione,
  servizio puro, nessuna operazione) oppure ``azioni.errore_non_disponibile``.
* Cifratura e BancaDati usano i servizi puri ``servizi.sicurezza`` e
  ``servizi.bancadati`` (import pigri, una banca dati per controllo).
"""

from __future__ import annotations

import copy
import os
from typing import Any, Callable

from ..errori import ErroreFile, ErroreTipo, ErroreValore
from ..valori import e_intero, e_numero, nome_tipo
from .metadati import Proprieta, TipoControllo, registra

__all__ = ["tipi", "DATI_EVENTI", "SCHEDE"]

#: Schede della casella dei controlli usate dai controlli inventati, nell'ordine.
SCHEDE = ("Italia", "Hardware", "Giochi", "Media", "Dati e rete", "Sicurezza",
          "Produttività", "Indicatori", "Sviluppo", "Didattica")

_NON_DISPONIBILE = "non disponibile su questo computer"

#: ``Sensore.tipo_sensore``: sensori della scheda Pico e sensori del telefono (app Leo).
SENSORI_PICO = ("temperatura", "luce", "distanza", "analogico")
SENSORI_TELEFONO = ("accelerometro", "giroscopio", "bussola", "magnetometro", "prossimita", "pressione",
                    "passi", "orientamento", "gravita")


# ===========================================================================
# Collegamento con l'interfaccia (leo.grafica.azioni, con ripiego locale)
# ===========================================================================

def _ha_interfaccia(controllo: Any) -> bool:
    return callable(getattr(controllo, "gestore_azioni", None))


def _richiedi(controllo: Any, azione: str, *argomenti: Any, predefinito: Any = None) -> Any:
    """Chiede al widget di eseguire ``azione`` (vedi ``azioni.richiedi_interfaccia``)."""
    try:
        from .azioni import richiedi_interfaccia
    except (ImportError, AttributeError):
        richiedi_interfaccia = None
    if richiedi_interfaccia is not None:
        return richiedi_interfaccia(controllo, azione, *argomenti, predefinito=predefinito)
    gestore = getattr(controllo, "gestore_azioni", None)
    if callable(gestore):
        return gestore(azione, list(argomenti))
    return predefinito


_NON_GESTITA = object()


def _interfaccia(controllo: Any, azione: str, *argomenti: Any) -> tuple[bool, Any]:
    """(gestita, risultato): gestita e' falso se non c'e' widget o se il widget non conosce l'azione."""
    if not _ha_interfaccia(controllo):
        return False, None
    risultato = _richiedi(controllo, azione, *argomenti, predefinito=_NON_GESTITA)
    if risultato is _NON_GESTITA:
        return False, None
    try:
        from .azioni import NON_GESTITA
    except (ImportError, AttributeError):
        NON_GESTITA = _NON_GESTITA
    if risultato is NON_GESTITA:
        return False, None
    return True, risultato


def _non_disponibile(cosa: str) -> ErroreValore:
    """ErroreValore "<cosa>: non disponibile su questo computer." (da ``azioni`` se c'e')."""
    try:
        from .azioni import errore_non_disponibile
    except (ImportError, AttributeError):
        errore_non_disponibile = None
    if errore_non_disponibile is not None:
        try:
            errore = errore_non_disponibile(cosa)
            if isinstance(errore, ErroreValore):
                return errore
        except Exception:  # noqa: BLE001 - un modulo incompleto non deve impedire il messaggio
            pass
    return ErroreValore(f"{cosa}: {_NON_DISPONIBILE}.",
                        suggerimento="Serve la finestra del programma (progetto grafico) o il dispositivo collegato.")


# ===========================================================================
# Utilita' per i metodi
# ===========================================================================

def _imposta(controllo: Any, proprieta: str, valore: Any) -> None:
    """Cambia una proprieta' (anche di sola lettura) e avvisa l'interfaccia."""
    controllo.modello.proprieta[proprieta] = valore
    controllo.avvisa(proprieta, valore)


def _valore(controllo: Any, proprieta: str, predefinito: Any = None) -> Any:
    v = controllo.modello.proprieta.get(proprieta, predefinito)
    return predefinito if v is None else v


def _intero(valore: Any, cosa: str) -> int:
    if isinstance(valore, float) and valore.is_integer():
        valore = int(valore)
    if not e_intero(valore):
        raise ErroreTipo(f"{cosa} deve essere un numero intero, non `{nome_tipo(valore)}`.")
    return valore


def _numero(valore: Any, cosa: str) -> int | float:
    if not e_numero(valore):
        raise ErroreTipo(f"{cosa} deve essere un numero, non `{nome_tipo(valore)}`.")
    if isinstance(valore, float) and (valore != valore or valore in (float("inf"), float("-inf"))):
        raise ErroreValore(f"{cosa} deve essere un numero finito.")
    return valore


def _testo(valore: Any, cosa: str) -> str:
    if not isinstance(valore, str):
        raise ErroreTipo(f"{cosa} deve essere un testo, non `{nome_tipo(valore)}`.",
                         suggerimento="Per convertire usa `testo(...)`.")
    return valore


def _dizionario(valore: Any, cosa: str) -> dict:
    if not isinstance(valore, dict):
        raise ErroreTipo(f"{cosa} deve essere un dizionario, non `{nome_tipo(valore)}`.")
    return valore


def _lista(valore: Any, cosa: str) -> list:
    if not isinstance(valore, list):
        raise ErroreTipo(f"{cosa} deve essere una lista, non `{nome_tipo(valore)}`.")
    return valore


def _percorso(valore: Any, controllo: Any) -> str:
    """Percorso di un file, relativo alla cartella del progetto se il controllo la conosce."""
    p = _testo(valore, "Il percorso")
    if not p.strip():
        raise ErroreValore("Il percorso del file è vuoto.")
    cartella = getattr(controllo, "cartella_progetto", None)
    if cartella and not os.path.isabs(p):
        return os.path.join(os.fspath(cartella), p)
    return p


# ===========================================================================
# Hardware
# ===========================================================================

_PIN_MASSIMO = 29  # GP0..GP28 della Pico (GP25 = LED sulla scheda)


def _pin(valore: Any) -> int:
    pin = _intero(valore, "Il numero del pin")
    if not 0 <= pin < _PIN_MASSIMO:
        raise ErroreValore(f"Il pin {pin} non esiste sulla Pico.", suggerimento="I pin vanno da 0 a 28 (GP0-GP28).")
    return pin


def _pico_simulata(controllo: Any) -> dict:
    stato = getattr(controllo, "_pin_simulati", None)
    if stato is None:
        stato = {}
        controllo._pin_simulati = stato
    return stato


def _pico_controlla_connessa(controllo: Any) -> None:
    if not _valore(controllo, "connessa", False):
        raise ErroreValore(f"La scheda `{controllo.nome}` non è connessa.",
                           suggerimento=f"Chiama prima `{controllo.nome}.connetti()`.")


def _pico_connetti(c):
    """Collega la scheda (USB, Wi-Fi o simulata)."""
    gestita, risultato = _interfaccia(c, "connetti")
    if gestita:
        return risultato
    if _valore(c, "simulata", False):
        _imposta(c, "connessa", True)
        return None
    raise _non_disponibile("La scheda Pico")


def _pico_disconnetti(c):
    """Scollega la scheda."""
    gestita, risultato = _interfaccia(c, "disconnetti")
    if gestita:
        return risultato
    if _valore(c, "connessa", False):
        _imposta(c, "connessa", False)
    return None


def _pico_scrivi_pin(c, pin, valore):
    """Scrive su un pin: `vero`/`falso`, 0/1 oppure un decimale tra 0 e 1 (PWM)."""
    pin = _pin(pin)
    if isinstance(valore, bool):
        pass
    elif e_numero(valore):
        if not 0 <= valore <= 1:
            raise ErroreValore("Il valore di un pin va da 0 a 1.", suggerimento="Usa `vero`/`falso`, 0/1 o un decimale come 0.5.")
    else:
        raise ErroreTipo(f"Il valore del pin deve essere logico o numero, non `{nome_tipo(valore)}`.")
    gestita, risultato = _interfaccia(c, "scrivi_pin", pin, valore)
    if gestita:
        return risultato
    if _valore(c, "simulata", False):
        _pico_controlla_connessa(c)
        _pico_simulata(c)[pin] = valore
        return None
    raise _non_disponibile("La scheda Pico")


def _pico_leggi_pin(c, pin):
    """Legge un pin digitale: 0 oppure 1."""
    pin = _pin(pin)
    gestita, risultato = _interfaccia(c, "leggi_pin", pin)
    if gestita:
        return risultato
    if _valore(c, "simulata", False):
        _pico_controlla_connessa(c)
        v = _pico_simulata(c).get(pin, 0)
        if isinstance(v, bool):
            return 1 if v else 0
        return 1 if v >= 0.5 else 0
    raise _non_disponibile("La scheda Pico")


def _led_accendi(c):
    """Accende il LED."""
    _imposta(c, "acceso", True)


def _led_spegni(c):
    """Spegne il LED."""
    _imposta(c, "acceso", False)


def _led_commuta(c):
    """Accende il LED se e' spento, lo spegne se e' acceso."""
    _imposta(c, "acceso", not _valore(c, "acceso", False))


def _sensore_leggi(c):
    """Legge subito il sensore e restituisce il valore."""
    gestita, v = _interfaccia(c, "leggi")
    if gestita:
        if e_numero(v):
            c.aggiorna_da_interfaccia("valore", float(v))
            return v
        return _valore(c, "valore", 0.0)
    raise _non_disponibile("Il sensore")


def _oscilloscopio_aggiungi(c, v):
    """Aggiunge un valore al grafico (i piu' vecchi escono oltre `campioni`)."""
    v = _numero(v, "Il valore")
    valori = list(_valore(c, "valori", []))
    valori.append(v)
    campioni = max(1, int(_valore(c, "campioni", 200)))
    if len(valori) > campioni:
        valori = valori[-campioni:]
    _imposta(c, "valori", valori)


def _oscilloscopio_svuota(c):
    """Cancella tutti i valori."""
    _imposta(c, "valori", [])


def _seriale_apri(c):
    """Apre la porta seriale."""
    gestita, risultato = _interfaccia(c, "apri")
    if gestita:
        return risultato
    raise _non_disponibile("La porta seriale")


def _seriale_chiudi(c):
    """Chiude la porta seriale."""
    gestita, risultato = _interfaccia(c, "chiudi")
    if gestita:
        return risultato
    if _valore(c, "aperta", False):
        _imposta(c, "aperta", False)
    return None


def _seriale_invia(c, testo):
    """Invia un testo sulla porta seriale."""
    testo = _testo(testo, "Il testo da inviare")
    gestita, risultato = _interfaccia(c, "invia", testo)
    if gestita:
        return risultato
    raise _non_disponibile("La porta seriale")


# ===========================================================================
# Giochi
# ===========================================================================

def _scena_avvia(c):
    """Fa partire l'aggiornamento della scena (evento `fotogramma`)."""
    _imposta(c, "attiva", True)


def _scena_ferma(c):
    """Mette in pausa la scena."""
    _imposta(c, "attiva", False)


def _sprite_sposta(c, dx, dy):
    """Sposta lo sprite di `dx` pixel in orizzontale e `dy` in verticale."""
    dx = _numero(dx, "`dx`")
    dy = _numero(dy, "`dy`")
    _imposta(c, "sinistra", int(round(_valore(c, "sinistra", 0) + dx)))
    _imposta(c, "alto", int(round(_valore(c, "alto", 0) + dy)))


def _sprite_tocca(c, nome):
    """Vero se lo sprite tocca il controllo `nome` (serve la finestra del programma)."""
    if not isinstance(nome, str):
        nome = getattr(nome, "nome", nome)
    nome = _testo(nome, "Il nome del controllo")
    gestita, risultato = _interfaccia(c, "tocca", nome)
    return bool(risultato) if gestita else False


def _punteggio_aggiungi(c, n):
    """Aggiunge `n` punti (anche negativi); aggiorna il record se lo supera."""
    n = _intero(n, "Il numero di punti")
    valore = int(_valore(c, "valore", 0)) + n
    _imposta(c, "valore", valore)
    if valore > int(_valore(c, "record", 0)):
        _imposta(c, "record", valore)


def _punteggio_azzera(c):
    """Riporta il punteggio a 0 (il record resta)."""
    _imposta(c, "valore", 0)


# ===========================================================================
# Media
# ===========================================================================

def _fotocamera_avvia(c):
    """Accende l'anteprima della fotocamera."""
    _imposta(c, "attiva", True)


def _fotocamera_ferma(c):
    """Spegne la fotocamera."""
    _imposta(c, "attiva", False)


def _fotocamera_scatta(c, percorso=""):
    """Scatta una foto e restituisce il percorso del file salvato."""
    percorso = _testo(percorso, "Il percorso") if percorso else ""
    if percorso:
        percorso = _percorso(percorso, c)
    gestita, risultato = _interfaccia(c, "scatta", percorso)
    if gestita:
        return risultato
    raise _non_disponibile("La fotocamera")


def _dettatura_ascolta(c):
    """Comincia ad ascoltare (evento `frase_riconosciuta`)."""
    gestita, risultato = _interfaccia(c, "ascolta")
    if gestita:
        return risultato
    raise _non_disponibile("Il riconoscimento della voce")


def _dettatura_ferma(c):
    """Smette di ascoltare."""
    gestita, risultato = _interfaccia(c, "ferma")
    if gestita:
        return risultato
    if _valore(c, "in_ascolto", False):
        _imposta(c, "in_ascolto", False)
    return None


def _voce_leggi(c, testo):
    """Legge il testo ad alta voce."""
    testo = _testo(testo, "Il testo da leggere")
    gestita, risultato = _interfaccia(c, "leggi", testo)
    if gestita:
        return risultato
    try:
        from .servizi import voce
        disponibile = voce.sintesi_disponibile()
    except (ImportError, AttributeError):
        voce, disponibile = None, False
    if voce is None or not disponibile:
        raise _non_disponibile("La lettura ad alta voce")
    voce.leggi_ad_alta_voce(testo, velocita=int(_valore(c, "velocita", 0)), volume=int(_valore(c, "volume", 100)))
    return None


def _voce_ferma(c):
    """Interrompe la lettura."""
    gestita, risultato = _interfaccia(c, "ferma")
    if gestita:
        return risultato
    try:
        from .servizi import voce
        voce.ferma_lettura()
    except (ImportError, AttributeError):
        pass
    return None


def _lettore_qr_avvia(c):
    """Accende la fotocamera e comincia a cercare codici QR."""
    _imposta(c, "attivo", True)


def _lettore_qr_ferma(c):
    """Smette di cercare codici QR."""
    _imposta(c, "attivo", False)


def _generatore_qr_salva(c, percorso):
    """Salva il codice QR come immagine (.png oppure .svg)."""
    percorso = _percorso(percorso, c)
    gestita, risultato = _interfaccia(c, "salva", percorso)
    if gestita:
        return risultato
    try:
        from .servizi import qr
    except ImportError:
        raise _non_disponibile("Il generatore di codici QR") from None
    testo = str(_valore(c, "testo", ""))
    colore = str(_valore(c, "colore", "#000000")) or "#000000"
    correzione = str(_valore(c, "correzione", "M"))
    try:
        if percorso.lower().endswith(".svg"):
            svg = qr.svg_qr(testo, colore=colore, correzione=correzione)
            with open(percorso, "w", encoding="utf-8") as f:
                f.write(svg)
        else:
            qr.png_qr(testo, percorso, colore=colore, correzione=correzione)
    except AttributeError:
        raise _non_disponibile("Il generatore di codici QR") from None
    except OSError as e:
        raise ErroreFile(f"Non riesco a salvare `{percorso}`: {e.strerror or e}.") from e
    return None


def _galleria_vai(c, passo: int) -> None:
    immagini = _valore(c, "immagini", [])
    n = len(immagini) if isinstance(immagini, list) else 0
    if n == 0:
        _imposta(c, "indice", 0)
        return
    indice = (int(_valore(c, "indice", 0)) + passo) % n
    _imposta(c, "indice", indice)


def _galleria_avanti(c):
    """Passa all'immagine successiva (dopo l'ultima torna alla prima)."""
    _galleria_vai(c, 1)


def _galleria_indietro(c):
    """Torna all'immagine precedente (prima della prima va all'ultima)."""
    _galleria_vai(c, -1)


# ===========================================================================
# Dati e rete
# ===========================================================================

def _banca(c):
    """La BancaDati del controllo (una per controllo, riaperta se cambia `file`)."""
    file = str(_valore(c, "file", "dati.db")) or ":memory:"
    if file != ":memory:":
        file = _percorso(file, c)
    attuale = getattr(c, "_banca_dati", None)
    if attuale is not None and attuale[0] == file:
        return attuale[1]
    try:
        from .servizi.bancadati import BancaDati
    except (ImportError, AttributeError):
        raise _non_disponibile("La banca dati") from None
    if attuale is not None:
        try:
            attuale[1].chiudi()
        except Exception:  # noqa: BLE001 - chiusura di cortesia
            pass
    istanza = BancaDati(file)
    c._banca_dati = (file, istanza)
    return istanza


def _bd_via_interfaccia(c, metodo, *argomenti):
    """Nella finestra il widget BancaDati esegue l'operazione ed emette `errore`
    (se il programma lo gestisce l'errore non si ripete): (gestita, risultato)."""
    return _interfaccia(c, metodo, *argomenti)


def _bd_crea_tabella(c, nome, colonne):
    """Crea la tabella `nome` con le colonne {"nome": "testo", "eta": "intero", ...}."""
    nome, colonne = _testo(nome, "Il nome della tabella"), _dizionario(colonne, "Le colonne")
    gestita, risultato = _bd_via_interfaccia(c, "crea_tabella", nome, colonne)
    if gestita:
        return risultato
    return _banca(c).crea_tabella(nome, colonne)


def _bd_inserisci(c, tabella, riga):
    """Inserisce una riga (dizionario colonna -> valore); restituisce il suo numero."""
    tabella, riga = _testo(tabella, "Il nome della tabella"), _dizionario(riga, "La riga")
    gestita, risultato = _bd_via_interfaccia(c, "inserisci", tabella, riga)
    if gestita:
        return risultato
    return _banca(c).inserisci(tabella, riga)


def _bd_cerca(c, tabella, condizioni=None):
    """Righe della tabella che rispettano le condizioni (dizionario), come lista di dizionari."""
    if condizioni is not None:
        _dizionario(condizioni, "Le condizioni")
    tabella = _testo(tabella, "Il nome della tabella")
    gestita, risultato = _bd_via_interfaccia(c, "cerca", tabella, condizioni)
    if gestita:
        return risultato
    return _banca(c).cerca(tabella, condizioni)


def _bd_aggiorna(c, tabella, condizioni, valori):
    """Cambia i valori delle righe che rispettano le condizioni; restituisce quante."""
    tabella = _testo(tabella, "Il nome della tabella")
    condizioni, valori = _dizionario(condizioni, "Le condizioni"), _dizionario(valori, "I valori")
    gestita, risultato = _bd_via_interfaccia(c, "aggiorna", tabella, condizioni, valori)
    if gestita:
        return risultato
    return _banca(c).aggiorna(tabella, condizioni, valori)


def _bd_elimina(c, tabella, condizioni):
    """Elimina le righe che rispettano le condizioni; restituisce quante."""
    tabella, condizioni = _testo(tabella, "Il nome della tabella"), _dizionario(condizioni, "Le condizioni")
    gestita, risultato = _bd_via_interfaccia(c, "elimina", tabella, condizioni)
    if gestita:
        return risultato
    return _banca(c).elimina(tabella, condizioni)


def _bd_esegui(c, sql, parametri=None):
    """Esegue un comando SQL con parametri facoltativi; restituisce le righe."""
    if parametri is not None and not isinstance(parametri, (list, dict)):
        raise ErroreTipo(f"I parametri devono essere una lista o un dizionario, non `{nome_tipo(parametri)}`.")
    sql = _testo(sql, "Il comando SQL")
    gestita, risultato = _bd_via_interfaccia(c, "esegui", sql, parametri)
    if gestita:
        return risultato
    return _banca(c).esegui(sql, parametri)


def _richiesta_invia(c, dati=None):
    """Invia la richiesta a `indirizzo`. Nella finestra la risposta arriva con l'evento
    `risposta`; senza finestra la richiesta e' sincrona e restituisce la risposta."""
    indirizzo = str(_valore(c, "indirizzo", "")).strip()
    if not indirizzo:
        raise ErroreValore(f"`{c.nome}.indirizzo` è vuoto.", suggerimento=f"Scrivi prima `{c.nome}.indirizzo = \"https://...\"`.")
    gestita, risultato = _interfaccia(c, "invia", dati)
    if gestita:
        return risultato
    try:
        from .servizi.rete import scarica
    except (ImportError, AttributeError):
        raise _non_disponibile("La rete") from None
    return scarica(indirizzo, metodo=str(_valore(c, "metodo", "GET")), dati=dati)


def _server_avvia(c):
    """Avvia il piccolo sito locale (evento `richiesta`)."""
    gestita, risultato = _interfaccia(c, "avvia")
    if gestita:
        return risultato
    raise _non_disponibile("Il server web")


def _server_ferma(c):
    """Ferma il sito locale."""
    gestita, risultato = _interfaccia(c, "ferma")
    if gestita:
        return risultato
    if _valore(c, "attivo", False):
        _imposta(c, "attivo", False)
    return None


def _mappa_aggiungi_segnaposto(c, lat, lon, etichetta=""):
    """Aggiunge un segnaposto alla latitudine e longitudine indicate."""
    lat = _numero(lat, "La latitudine")
    lon = _numero(lon, "La longitudine")
    etichetta = _testo(etichetta, "L'etichetta")
    if not -90 <= lat <= 90:
        raise ErroreValore("La latitudine va da -90 a 90.")
    if not -180 <= lon <= 180:
        raise ErroreValore("La longitudine va da -180 a 180.")
    segnaposti = copy.deepcopy(_valore(c, "segnaposti", []))
    segnaposti.append([lat, lon, etichetta])
    _imposta(c, "segnaposti", segnaposti)


def _mappa_svuota(c):
    """Toglie tutti i segnaposti."""
    _imposta(c, "segnaposti", [])


# ===========================================================================
# Sicurezza
# ===========================================================================

def _sicurezza():
    try:
        from .servizi import sicurezza
        return sicurezza
    except ImportError:
        return None


def _cifratura_impronta(c, testo):
    """Impronta (hash) del testo con l'algoritmo scelto, in esadecimale."""
    testo = _testo(testo, "Il testo")
    algoritmo = str(_valore(c, "algoritmo", "sha256"))
    s = _sicurezza()
    if s is not None and hasattr(s, "impronta"):
        return s.impronta(testo, algoritmo)
    import hashlib

    return hashlib.new(algoritmo, testo.encode("utf-8")).hexdigest()


def _cifratura_cifra(c, testo, chiave):
    """Cifra il testo con la chiave (AES-256-GCM, la chiave ricavata con scrypt)."""
    testo = _testo(testo, "Il testo")
    chiave = _testo(chiave, "La chiave")
    s = _sicurezza()
    if s is None or not hasattr(s, "cifra"):
        raise _non_disponibile("La cifratura")
    return s.cifra(testo, chiave)


def _cifratura_decifra(c, testo, chiave):
    """Decifra un testo cifrato con `cifra` usando la stessa chiave."""
    testo = _testo(testo, "Il testo cifrato")
    chiave = _testo(chiave, "La chiave")
    s = _sicurezza()
    if s is None or not hasattr(s, "decifra"):
        raise _non_disponibile("La cifratura")
    return s.decifra(testo, chiave)


def _cifratura_genera_password(c, lunghezza=16):
    """Password casuale e robusta della lunghezza indicata (predefinita 16)."""
    lunghezza = _intero(lunghezza, "La lunghezza")
    if not 4 <= lunghezza <= 256:
        raise ErroreValore("La lunghezza della password va da 4 a 256 caratteri.")
    s = _sicurezza()
    if s is not None and hasattr(s, "genera_password"):
        return s.genera_password(lunghezza)
    import secrets
    import string

    alfabeto = string.ascii_letters + string.digits + "!?#$%&*+-=_@"
    while True:
        pw = "".join(secrets.choice(alfabeto) for _ in range(lunghezza))
        if (any(ch.islower() for ch in pw) and any(ch.isupper() for ch in pw)
                and any(ch.isdigit() for ch in pw)):
            return pw


LIVELLI_REGISTRO = ("debug", "info", "avviso", "errore")


def _registro_aggiungi(c, testo, livello="info"):
    """Aggiunge una voce con l'ora attuale e il livello (debug, info, avviso, errore)."""
    import time

    testo = _testo(testo, "Il testo")
    livello = _testo(livello, "Il livello")
    if livello not in LIVELLI_REGISTRO:
        raise ErroreValore(f"`{livello}` non è un livello del registro.",
                           suggerimento="Livelli: " + ", ".join(f'"{x}"' for x in LIVELLI_REGISTRO) + ".")
    voce = {"ora": time.strftime("%H:%M:%S"), "livello": livello, "testo": testo}
    voci = list(_valore(c, "voci", []))
    voci.append(voce)
    _imposta(c, "voci", voci)
    return None


def _registro_esporta(c, percorso):
    """Salva le voci in un file di testo (.txt) o CSV (.csv)."""
    import csv

    percorso = _percorso(percorso, c)
    voci = list(_valore(c, "voci", []))
    try:
        with open(percorso, "w", encoding="utf-8", newline="") as f:
            if percorso.lower().endswith(".csv"):
                scrittore = csv.writer(f, delimiter=";")
                scrittore.writerow(["ora", "livello", "testo"])
                for v in voci:
                    scrittore.writerow([v.get("ora", ""), v.get("livello", ""), v.get("testo", "")])
            else:
                for v in voci:
                    f.write(f"{v.get('ora', '')} [{v.get('livello', '')}] {v.get('testo', '')}\n")
    except OSError as e:
        raise ErroreFile(f"Non riesco a scrivere `{percorso}`: {e.strerror or e}.") from e
    return None


def _registro_svuota(c):
    """Cancella tutte le voci."""
    _imposta(c, "voci", [])


# ===========================================================================
# Produttivita'
# ===========================================================================

def _lavagna_pulisci(c):
    """Cancella il disegno."""
    gestita, risultato = _interfaccia(c, "pulisci")
    if gestita:
        return risultato
    return None


def _lavagna_annulla(c):
    """Toglie l'ultimo tratto."""
    gestita, risultato = _interfaccia(c, "annulla")
    if gestita:
        return risultato
    return None


def _lavagna_salva(c, percorso):
    """Salva il disegno come immagine PNG."""
    percorso = _percorso(percorso, c)
    gestita, risultato = _interfaccia(c, "salva", percorso)
    if gestita:
        return risultato
    raise _non_disponibile("Il salvataggio della lavagna")


def _kanban_colonna(c, colonna) -> str:
    colonna = _testo(colonna, "La colonna")
    colonne = _valore(c, "colonne", [])
    if colonna not in colonne:
        raise ErroreValore(f"La colonna `{colonna}` non esiste in `{c.nome}`.",
                           suggerimento="Colonne: " + ", ".join(f'"{x}"' for x in colonne) + ".")
    return colonna


def _kanban_aggiungi_scheda(c, colonna, testo):
    """Aggiunge una scheda con il testo in fondo alla colonna."""
    colonna = _kanban_colonna(c, colonna)
    testo = _testo(testo, "Il testo della scheda")
    schede = copy.deepcopy(_valore(c, "schede", {}))
    schede.setdefault(colonna, []).append(testo)
    _imposta(c, "schede", schede)


def _kanban_rimuovi_scheda(c, colonna, testo):
    """Toglie la prima scheda con quel testo dalla colonna."""
    colonna = _kanban_colonna(c, colonna)
    testo = _testo(testo, "Il testo della scheda")
    schede = copy.deepcopy(_valore(c, "schede", {}))
    elenco = schede.get(colonna, [])
    if testo not in elenco:
        raise ErroreValore(f"Nella colonna `{colonna}` non c'è la scheda `{testo}`.")
    elenco.remove(testo)
    schede[colonna] = elenco
    _imposta(c, "schede", schede)


def _diagramma_id(valore) -> Any:
    if isinstance(valore, bool) or not isinstance(valore, (str, int)):
        raise ErroreTipo(f"L'identificativo di un nodo deve essere un testo o un intero, non `{nome_tipo(valore)}`.")
    return valore


def _diagramma_aggiungi_nodo(c, id, testo, x=None, y=None):  # noqa: A002 - nome Leo del parametro
    """Aggiunge un riquadro; senza `x` e `y` lo mette nel primo posto libero della griglia."""
    id = _diagramma_id(id)  # noqa: A001
    testo = _testo(testo, "Il testo del nodo")
    nodi = copy.deepcopy(_valore(c, "nodi", []))
    if any(n and n[0] == id for n in nodi):
        raise ErroreValore(f"Nel diagramma c'è già un nodo `{id}`.")
    if (x is None) != (y is None):
        raise ErroreValore("Indica sia `x` sia `y`, oppure nessuno dei due.")
    if x is None:
        n = len(nodi)
        x, y = 20 + (n % 4) * 140, 20 + (n // 4) * 90
    else:
        x = _numero(x, "`x`")
        y = _numero(y, "`y`")
    nodi.append([id, testo, x, y])
    _imposta(c, "nodi", nodi)


def _diagramma_collega(c, da, a):
    """Collega con una freccia il nodo `da` al nodo `a`."""
    da, a = _diagramma_id(da), _diagramma_id(a)
    ids = [n[0] for n in _valore(c, "nodi", []) if n]
    for x in (da, a):
        if x not in ids:
            raise ErroreValore(f"Nel diagramma non c'è il nodo `{x}`.",
                               suggerimento="Aggiungilo prima con `aggiungi_nodo(...)`.")
    collegamenti = copy.deepcopy(_valore(c, "collegamenti", []))
    if [da, a] not in collegamenti:
        collegamenti.append([da, a])
        _imposta(c, "collegamenti", collegamenti)


def _diagramma_svuota(c):
    """Toglie tutti i nodi e i collegamenti."""
    _imposta(c, "collegamenti", [])
    _imposta(c, "nodi", [])


def _conto_avvia(c):
    """Fa partire (o riprendere) il conto alla rovescia."""
    if not getattr(c, "_conto_avviato", False) or int(_valore(c, "rimanenti", 0)) <= 0:
        _imposta(c, "rimanenti", int(_valore(c, "secondi", 60)))
    c._conto_avviato = True
    _imposta(c, "attivo", True)


def _conto_ferma(c):
    """Mette in pausa il conto alla rovescia."""
    _imposta(c, "attivo", False)


def _conto_azzera(c):
    """Ferma e riporta il conto a `secondi`."""
    c._conto_avviato = False
    _imposta(c, "attivo", False)
    _imposta(c, "rimanenti", int(_valore(c, "secondi", 60)))


def _notifica_mostra(c, testo=None):
    """Mostra la notifica del sistema (con il testo indicato o con `testo`)."""
    if testo is not None:
        testo = _testo(testo, "Il testo della notifica")
    else:
        testo = str(_valore(c, "testo", ""))
    gestita, risultato = _interfaccia(c, "mostra", testo)
    if gestita:
        return risultato
    raise _non_disponibile("Le notifiche")


# ===========================================================================
# Sviluppo e didattica
# ===========================================================================

def _terminale_scrivi(c, testo):
    """Aggiunge il testo in fondo al terminale."""
    from ..valori import rappresenta

    testo = testo if isinstance(testo, str) else rappresenta(testo)
    nuovo = str(_valore(c, "testo", "")) + testo
    gestita, _ = _interfaccia(c, "scrivi", testo)
    if gestita:
        c.aggiorna_da_interfaccia("testo", nuovo)
        return None
    _imposta(c, "testo", nuovo)
    return None


def _terminale_pulisci(c):
    """Cancella il contenuto del terminale."""
    gestita, _ = _interfaccia(c, "pulisci")
    if gestita:
        c.aggiorna_da_interfaccia("testo", "")
        return None
    _imposta(c, "testo", "")
    return None


def _editor_vai_a_riga(c, n):
    """Porta il cursore alla riga `n` (dalla 1)."""
    n = _intero(n, "Il numero di riga")
    if n < 1:
        raise ErroreValore("Le righe si contano da 1.")
    gestita, risultato = _interfaccia(c, "vai_a_riga", n)
    if gestita:
        return risultato
    return None


def _assistente_chiedi(c, domanda):
    """Fa una domanda all'assistente. Nella finestra la risposta arriva con l'evento
    `risposta`; senza finestra la domanda e' sincrona e restituisce la risposta."""
    domanda = _testo(domanda, "La domanda")
    if not domanda.strip():
        raise ErroreValore("La domanda è vuota.")
    gestita, risultato = _interfaccia(c, "chiedi", domanda)
    if gestita:
        return risultato
    try:
        from .servizi.assistente import Assistente
    except (ImportError, AttributeError):
        raise _non_disponibile("L'assistente") from None
    chiave = (str(_valore(c, "chiave_api", "")), str(_valore(c, "modello", "")), str(_valore(c, "istruzioni", "")))
    attuale = getattr(c, "_assistente", None)
    if attuale is None or attuale[0] != chiave:
        attuale = (chiave, Assistente(chiave=chiave[0], modello=chiave[1], istruzioni=chiave[2]))
        c._assistente = attuale
    return attuale[1].chiedi(domanda)


# ===========================================================================
# Definizione dei tipi
# ===========================================================================

def _p(nome: str, tipo: str, predefinito: Any = None, descrizione: str = "", gruppo: str = "Dati", *,
       scelte: tuple[str, ...] = (), minimo: float | None = None, massimo: float | None = None) -> Proprieta:
    if tipo == "scelta" and predefinito is None:
        predefinito = scelte[0]
    return Proprieta(nome, tipo, predefinito, gruppo, descrizione, scelte=tuple(scelte),
                     minimo=minimo, massimo=massimo)


def _sl(nome: str, tipo: str, predefinito: Any, descrizione: str) -> Proprieta:
    """Proprieta' di sola lettura (calcolata dal controllo)."""
    return Proprieta(nome, tipo, predefinito, "Dati", descrizione, sola_lettura=True)


def _t(nome: str, scheda: str, descrizione: str, versione: int, proprieta: list[Proprieta],
       eventi: tuple[str, ...], evento_predefinito: str | None, *, icona: str,
       dimensione: tuple[int, int] = (100, 30), invisibile: bool = False, contenitore: bool = False,
       metodi: dict[str, Callable[..., Any]] | None = None, prefisso: str = "") -> TipoControllo:
    return TipoControllo(
        nome=nome, scheda=scheda, descrizione=descrizione, versione=versione,
        proprieta={p.nome: p for p in proprieta}, eventi=tuple(eventi),
        evento_predefinito=evento_predefinito, invisibile=invisibile, contenitore=contenitore,
        dimensione_predefinita=dimensione, icona=icona, metodi=dict(metodi or {}), prefisso_nome=prefisso,
    )


#: Dati degli eventi (chiavi del dizionario `evento` nel gestore) per ogni tipo.
DATI_EVENTI: dict[str, dict[str, tuple[str, ...]]] = {
    "CasellaCodiceFiscale": {"valido": ("valore", "testo"), "cambio": ("valore",)},
    "CasellaIBAN": {"valido": ("valore", "testo"), "cambio": ("valore",)},
    "CasellaTarga": {"valido": ("valore", "testo"), "cambio": ("valore",)},
    "SelettoreComune": {"selezione": ("comune",)},
    "CasellaImporto": {"cambio": ("valore",)},
    "CalendarioFestività": {"selezione": ("data", "festivita")},
    "SchedaPico": {"connessione": ("connessa",), "errore": ("messaggio",)},
    "Led": {"cambio": ("valore",)},
    "PulsanteFisico": {"pressione": (), "rilascio": ()},
    "Sensore": {"lettura": ("valore", "x", "y", "z")},
    "Oscilloscopio": {"soglia_superata": ("valore",)},
    "PortaSeriale": {"ricezione": ("testo",)},
    "Scena": {"fotogramma": ("tempo",), "tasto": ("tasto", "testo", "ctrl", "alt", "maiusc")},
    "Sprite": {"collisione": ("con",), "uscita_bordo": ("bordo",)},
    "Fisica": {"urto": ("sprite", "bordo")},
    "Joystick": {"movimento": ("x", "y")},
    "Punteggio": {"nuovo_record": ("valore",), "cambio": ("valore",)},
    "Fotocamera": {"scatto": ("percorso", "file")},
    "Dettatura": {"frase_riconosciuta": ("testo", "alternative")},
    "Voce": {"fine_lettura": ()},
    "LettoreQR": {"codice_letto": ("testo", "formato")},
    "GeneratoreQR": {},
    "Galleria": {"cambio_immagine": ("indice",)},
    "BancaDati": {"errore": ("messaggio",)},
    "ModuloAutomatico": {"invio": ("valori",)},
    "RichiestaWeb": {"risposta": ("stato", "testo", "json"), "errore": ("messaggio",)},
    "ServerWeb": {"richiesta": ("percorso", "metodo", "parametri", "corpo")},
    "Mappa": {"clic_mappa": ("lat", "lon")},
    "Cifratura": {},
    "MisuratorePassword": {"cambio": ("punteggio", "livello")},
    "Registro": {"nuova_voce": ("livello", "testo")},
    "Lavagna": {"tratto": ("punti",)},
    "Kanban": {"spostamento_scheda": ("scheda", "da", "a")},
    "Diagramma": {"collegamento": ("da", "a")},
    "ContoAllaRovescia": {"scadenza": ()},
    "Notifica": {"clic": ()},
    "Quadrante": {"soglia_superata": ("valore",)},
    "Semaforo": {"cambio": ("valore",)},
    "Valutazione": {"cambio": ("valore",)},
    "Terminale": {"comando": ("testo",)},
    "EditorCodice": {"cambio": ("valore",)},
    "Tutor": {"aiuto_chiesto": ("controllo",)},
    "Assistente": {"risposta": ("testo",), "errore": ("messaggio",)},
}


def _italia() -> list[TipoControllo]:
    return [
        _t("CasellaCodiceFiscale", "Italia",
           "Casella per il codice fiscale: controlla formato e carattere di controllo, ricava data di nascita e sesso",
           2, [
               _p("testo", "testo", "", "Codice fiscale scritto", "Aspetto"),
               _sl("valido", "logico", False, "Vero se il codice fiscale è corretto"),
               _sl("data_nascita", "testo", "", "Data di nascita ricavata (GG/MM/AAAA)"),
               _sl("sesso", "testo", "", "Sesso ricavato: \"M\" o \"F\""),
               _sl("comune", "testo", "", "Comune di nascita, se conosciuto"),
           ], ("valido", "cambio"), "valido", icona="id-card", dimensione=(200, 28)),
        _t("CasellaIBAN", "Italia", "Casella per l'IBAN: verifica le cifre di controllo e mostra la banca", 2, [
            _p("testo", "testo", "", "IBAN scritto", "Aspetto"),
            _sl("valido", "logico", False, "Vero se l'IBAN è corretto"),
            _sl("banca", "testo", "", "Nome della banca, se conosciuta"),
        ], ("valido", "cambio"), "valido", icona="landmark", dimensione=(280, 28)),
        _t("CasellaTarga", "Italia", "Casella che accetta solo targhe italiane valide", 2, [
            _p("testo", "testo", "", "Targa scritta", "Aspetto"),
            _sl("valido", "logico", False, "Vero se la targa è valida"),
            _sl("tipo_targa", "testo", "", "Tipo di targa: auto, moto, ciclomotore, storica"),
        ], ("valido", "cambio"), "valido", icona="car", dimensione=(120, 28)),
        _t("SelettoreComune", "Italia", "Cerca tra i comuni italiani e restituisce provincia, regione e CAP", 2, [
            _p("testo", "testo", "", "Testo scritto nella ricerca", "Aspetto"),
            _sl("comune", "dizionario", {}, "Comune scelto: nome, provincia, sigla, regione, cap, codice_catastale"),
        ], ("selezione",), "selezione", icona="map-pin", dimensione=(220, 28)),
        _t("CasellaImporto", "Italia", "Casella per gli euro, scritti all'italiana (1.234,50 €)", 2, [
            _p("valore", "decimale", 0.0, "Importo in euro"),
            _p("mostra_simbolo", "logico", True, "Mostra il simbolo €", "Aspetto"),
            _p("decimali", "intero", 2, "Cifre dopo la virgola", "Aspetto", minimo=0, massimo=6),
        ], ("cambio",), "cambio", icona="euro", dimensione=(140, 28)),
        _t("CalendarioFestività", "Italia", "Calendario con le festività italiane, Pasqua compresa", 2, [
            _p("data", "testo", "", "Giorno scelto, GG/MM/AAAA; se non lo scegli, oggi"),
            _p("mostra_festivita", "logico", True, "Evidenzia le festività", "Aspetto"),
            _sl("festivita", "testo", "", "Nome della festività del giorno scelto (\"\" se non è festa)"),
        ], ("selezione",), "selezione", icona="calendar-days", dimensione=(280, 220)),
    ]


def _hardware() -> list[TipoControllo]:
    return [
        _t("SchedaPico", "Hardware", "Collega una Raspberry Pi Pico via USB o Wi-Fi", 3, [
            _p("porta", "testo", "auto", "Porta USB (\"auto\" = cerca da sola)", "Comportamento"),
            _p("indirizzo", "testo", "", "Indirizzo IP della Pico W (Wi-Fi)", "Comportamento"),
            _p("simulata", "logico", False, "Simula la scheda senza hardware", "Comportamento"),
            _sl("connessa", "logico", False, "Vero quando la scheda è collegata"),
        ], ("connessione", "errore"), "connessione", icona="cpu", dimensione=(140, 40),
           metodi={"connetti": _pico_connetti, "disconnetti": _pico_disconnetti,
                   "scrivi_pin": _pico_scrivi_pin, "leggi_pin": _pico_leggi_pin}),
        _t("Led", "Hardware", "LED sullo schermo che ne accende uno vero su un pin", 3, [
            _p("acceso", "logico", False, "Vero se il LED è acceso"),
            _p("colore", "colore", "#FF3B30", "Colore della luce", "Aspetto"),
            _p("scheda_pico", "testo", "", "Nome della SchedaPico collegata", "Comportamento"),
            _p("pin", "intero", -1, "Pin della scheda (-1 per nessuno)", "Comportamento", minimo=-1, massimo=28),
        ], ("cambio",), "cambio", icona="lightbulb", dimensione=(32, 32),
           metodi={"accendi": _led_accendi, "spegni": _led_spegni, "commuta": _led_commuta}),
        _t("PulsanteFisico", "Hardware", "Mostra e segnala un pulsante reale collegato alla scheda", 3, [
            _sl("premuto", "logico", False, "Vero mentre il pulsante è premuto"),
            _p("scheda_pico", "testo", "", "Nome della SchedaPico collegata", "Comportamento"),
            _p("pin", "intero", -1, "Pin della scheda (-1 per nessuno)", "Comportamento", minimo=-1, massimo=28),
        ], ("pressione", "rilascio"), "pressione", icona="circle-dot", dimensione=(60, 60)),
        _t("Sensore", "Hardware", "Legge un sensore del telefono (accelerometro, luce, bussola...) "
           "o della scheda Pico e ne mostra il valore", 3, [
            _p("tipo_sensore", "scelta", "temperatura", "Che cosa misura. Sul telefono: luce, distanza e "
               "i sensori da accelerometro in poi; temperatura e analogico solo con la scheda Pico", "Comportamento", scelte=SENSORI_PICO + SENSORI_TELEFONO),
            _sl("valore", "decimale", 0.0, "Ultimo valore letto (per i sensori con x, y, z: quanto è forte)"),
            _sl("x", "decimale", 0.0, "Primo valore (accelerometro, giroscopio, gravità, magnetometro)"),
            _sl("y", "decimale", 0.0, "Secondo valore"),
            _sl("z", "decimale", 0.0, "Terzo valore"),
            _sl("unita", "testo", "", "Unità di misura del valore"),
            _p("scheda_pico", "testo", "", "Nome della SchedaPico collegata", "Comportamento"),
            _p("pin", "intero", 26, "Pin della scheda", "Comportamento", minimo=-1, massimo=28),
            _p("intervallo", "intero", 1000, "Millisecondi tra una lettura e l'altra", "Comportamento", minimo=10),
        ], ("lettura",), "lettura", icona="thermometer", dimensione=(140, 60),
           metodi={"leggi": _sensore_leggi}),
        _t("Oscilloscopio", "Hardware", "Grafico in tempo reale di un segnale", 3, [
            _sl("valori", "lista", [], "Valori mostrati, dal più vecchio"),
            _p("minimo", "decimale", 0.0, "Valore in basso", "Aspetto"),
            _p("massimo", "decimale", 100.0, "Valore in alto", "Aspetto"),
            _p("soglia", "decimale", 80.0, "Sopra questo valore arriva `soglia_superata`"),
            _p("campioni", "intero", 200, "Quanti valori tenere", minimo=2),
        ], ("soglia_superata",), "soglia_superata", icona="activity", dimensione=(320, 160),
           metodi={"aggiungi": _oscilloscopio_aggiungi, "svuota": _oscilloscopio_svuota}),
        _t("PortaSeriale", "Hardware", "Invisibile: invia e riceve dati su una porta seriale", 3, [
            _p("porta", "testo", "", "Nome della porta (es. \"COM3\")", "Comportamento"),
            _p("velocita", "intero", 115200, "Velocità in baud", "Comportamento", minimo=1),
            _sl("aperta", "logico", False, "Vero quando la porta è aperta"),
        ], ("ricezione",), "ricezione", icona="cable", invisibile=True,
           metodi={"apri": _seriale_apri, "chiudi": _seriale_chiudi, "invia": _seriale_invia}),
    ]


def _giochi() -> list[TipoControllo]:
    return [
        _t("Scena", "Giochi", "Area di gioco aggiornata 60 volte al secondo", 2, [
            _p("attiva", "logico", True, "Se falso la scena è in pausa", "Comportamento"),
            _p("fotogrammi_al_secondo", "intero", 60, "Aggiornamenti al secondo", "Comportamento",
               minimo=1, massimo=240),
        ], ("fotogramma", "tasto"), "fotogramma", icona="gamepad-2", dimensione=(400, 300), contenitore=True,
           metodi={"avvia": _scena_avvia, "ferma": _scena_ferma}),
        _t("Sprite", "Giochi", "Personaggio animato con collisioni", 2, [
            _p("immagine", "immagine", "", "Immagine dello sprite", "Aspetto"),
            _p("fotogrammi", "lista", [], "Immagini dell'animazione", "Aspetto"),
            _p("velocita_x", "decimale", 0.0, "Pixel al secondo in orizzontale"),
            _p("velocita_y", "decimale", 0.0, "Pixel al secondo in verticale"),
            _p("angolo", "decimale", 0.0, "Rotazione in gradi", "Aspetto"),
        ], ("collisione", "uscita_bordo"), "collisione", icona="ghost", dimensione=(64, 64),
           metodi={"sposta": _sprite_sposta, "tocca": _sprite_tocca}),
        _t("Fisica", "Giochi", "Invisibile: gravità e rimbalzi per gli sprite", 3, [
            _p("gravita", "decimale", 980.0, "Accelerazione verso il basso, in pixel/s²"),
            _p("rimbalzo", "decimale", 0.6, "Energia conservata a ogni rimbalzo (0-1)", minimo=0, massimo=1),
            _p("attiva", "logico", True, "Se falso la fisica è ferma", "Comportamento"),
            _p("sprite", "lista", [], "Nomi degli sprite soggetti alla fisica"),
        ], ("urto",), "urto", icona="orbit", invisibile=True),
        _t("Joystick", "Giochi", "Levetta sullo schermo o gamepad vero", 2, [
            _sl("x", "decimale", 0.0, "Posizione orizzontale da -1 a 1"),
            _sl("y", "decimale", 0.0, "Posizione verticale da -1 a 1"),
            _p("usa_gamepad", "logico", False, "Usa un gamepad collegato", "Comportamento"),
        ], ("movimento",), "movimento", icona="joystick", dimensione=(120, 120)),
        _t("Punteggio", "Giochi", "Contatore animato che ricorda il record", 2, [
            _p("valore", "intero", 0, "Punti attuali"),
            _sl("record", "intero", 0, "Punteggio più alto raggiunto"),
            _p("nome_record", "testo", "", "Nome con cui salvare il record; se resta vuoto, non si salva", "Comportamento"),
        ], ("nuovo_record", "cambio"), "nuovo_record", icona="trophy", dimensione=(140, 48),
           metodi={"aggiungi": _punteggio_aggiungi, "azzera": _punteggio_azzera}),
    ]


def _media() -> list[TipoControllo]:
    return [
        _t("Fotocamera", "Media", "Anteprima dalla webcam e scatto (sul telefono: scatta con la fotocamera)", 3, [
            _p("attiva", "logico", False, "Vero quando l'anteprima è accesa", "Comportamento"),
            _p("dispositivo", "testo", "", "Nome della fotocamera; se non lo scegli, quella principale", "Comportamento"),
            _p("anteriore", "logico", False, "Sul telefono: usa la fotocamera davanti (per i selfie)", "Comportamento"),
            _sl("ultima_foto", "testo", "", "Percorso del file dell'ultima foto scattata"),
        ], ("scatto",), "scatto", icona="camera", dimensione=(320, 240),
           metodi={"avvia": _fotocamera_avvia, "ferma": _fotocamera_ferma, "scatta": _fotocamera_scatta}),
        _t("Dettatura", "Media", "Trasforma la voce in testo in italiano", 3, [
            _p("lingua", "testo", "it-IT", "Lingua da riconoscere", "Comportamento"),
            _sl("in_ascolto", "logico", False, "Vero mentre ascolta"),
            _sl("testo", "testo", "", "Ultima frase riconosciuta"),
        ], ("frase_riconosciuta",), "frase_riconosciuta", icona="mic", dimensione=(240, 80),
           metodi={"ascolta": _dettatura_ascolta, "ferma": _dettatura_ferma}),
        _t("Voce", "Media", "Invisibile: legge un testo ad alta voce", 3, [
            _p("velocita", "intero", 0, "Velocità della voce (-10 lenta, 10 veloce)", "Comportamento",
               minimo=-10, massimo=10),
            _p("volume", "intero", 100, "Volume (0-100)", "Comportamento", minimo=0, massimo=100),
        ], ("fine_lettura",), "fine_lettura", icona="volume-2", invisibile=True,
           metodi={"leggi": _voce_leggi, "ferma": _voce_ferma}),
        _t("LettoreQR", "Media", "Legge codici QR dalla fotocamera", 3, [
            _p("attivo", "logico", False, "Vero mentre cerca codici", "Comportamento"),
            _sl("ultimo_codice", "testo", "", "Testo dell'ultimo codice letto"),
        ], ("codice_letto",), "codice_letto", icona="scan-line", dimensione=(240, 240),
           metodi={"avvia": _lettore_qr_avvia, "ferma": _lettore_qr_ferma}),
        _t("GeneratoreQR", "Media", "Mostra il codice QR di un testo o di un link", 2, [
            _p("testo", "testo", "https://", "Testo o indirizzo da codificare"),
            _p("colore", "colore", "#000000", "Colore dei quadratini", "Aspetto"),
            _p("correzione", "scelta", "M", "Livello di correzione degli errori", "Comportamento",
               scelte=("L", "M", "Q", "H")),
        ], (), None, icona="qr-code", dimensione=(160, 160),
           metodi={"salva": _generatore_qr_salva}),
        _t("Galleria", "Media", "Scorre immagini con frecce o trascinando", 2, [
            _p("immagini", "lista", [], "Percorsi delle immagini"),
            _p("indice", "intero", 0, "Immagine mostrata (dalla 0)", minimo=0),
            _p("automatica", "logico", False, "Scorre da sola", "Comportamento"),
            _p("intervallo", "intero", 3000, "Millisecondi tra un'immagine e l'altra", "Comportamento", minimo=100),
        ], ("cambio_immagine",), "cambio_immagine", icona="images", dimensione=(320, 240),
           metodi={"avanti": _galleria_avanti, "indietro": _galleria_indietro}),
    ]


def _dati_e_rete() -> list[TipoControllo]:
    return [
        _t("BancaDati", "Dati e rete", "Invisibile: archivio SQLite con comandi in italiano", 2, [
            _p("file", "testo", "dati.db", "File della banca dati (\":memory:\" = solo in memoria)", "Comportamento"),
        ], ("errore",), "errore", icona="database", invisibile=True,
           metodi={"crea_tabella": _bd_crea_tabella, "inserisci": _bd_inserisci, "cerca": _bd_cerca,
                   "aggiorna": _bd_aggiorna, "elimina": _bd_elimina, "esegui": _bd_esegui}),
        _t("ModuloAutomatico", "Dati e rete", "Crea da solo i campi a partire da un dizionario", 2, [
            _p("campi", "dizionario", {}, "Campi da mostrare: nome -> valore iniziale"),
            _sl("valori", "dizionario", {}, "Valori scritti nei campi"),
            _p("testo_pulsante", "testo", "Invia", "Testo del pulsante di invio", "Aspetto"),
        ], ("invio",), "invio", icona="clipboard-list", dimensione=(300, 200)),
        _t("RichiestaWeb", "Dati e rete", "Invisibile: scarica dati da un indirizzo", 2, [
            _p("indirizzo", "testo", "", "Indirizzo web (https://...)", "Comportamento"),
            _p("metodo", "scelta", "GET", "Metodo HTTP", "Comportamento", scelte=("GET", "POST", "PUT", "DELETE")),
            _sl("in_corso", "logico", False, "Vero mentre aspetta la risposta"),
        ], ("risposta", "errore"), "risposta", icona="globe", invisibile=True,
           metodi={"invia": _richiesta_invia}),
        _t("ServerWeb", "Dati e rete", "Invisibile: rende il programma un piccolo sito locale", 3, [
            _p("porta", "intero", 8080, "Porta del sito", "Comportamento", minimo=1, massimo=65535),
            _p("attivo", "logico", False, "Vero quando il sito è acceso", "Comportamento"),
            _sl("indirizzo", "testo", "", "Indirizzo del sito (http://127.0.0.1:porta)"),
            _p("risposta", "testo", "OK", "Risposta da inviare (la imposta il gestore di `richiesta`)"),
        ], ("richiesta",), "richiesta", icona="server", invisibile=True,
           metodi={"avvia": _server_avvia, "ferma": _server_ferma}),
        _t("Mappa", "Dati e rete", "Mappa con segnaposti", 3, [
            _p("centro", "lista", [41.9, 12.5], "Centro della mappa: [latitudine, longitudine]"),
            _p("zoom", "intero", 6, "Ingrandimento (0 = mondo, 19 = strada)", "Aspetto", minimo=0, massimo=19),
            _p("segnaposti", "lista", [], "Segnaposti: [latitudine, longitudine, etichetta]"),
        ], ("clic_mappa",), "clic_mappa", icona="map", dimensione=(400, 300),
           metodi={"aggiungi_segnaposto": _mappa_aggiungi_segnaposto, "svuota": _mappa_svuota}),
    ]


def _sicurezza_tipi() -> list[TipoControllo]:
    return [
        _t("Cifratura", "Sicurezza", "Invisibile: impronte (hash), cifratura AES-256-GCM e generatore di password", 2, [
            _p("algoritmo", "scelta", "sha256", "Algoritmo delle impronte (sha1 e md5 non sono sicuri: solo per "
               "confrontare impronte vecchie)", "Comportamento",
               scelte=("sha256", "sha512", "sha1", "md5")),
        ], (), None, icona="lock", invisibile=True,
           metodi={"impronta": _cifratura_impronta, "cifra": _cifratura_cifra, "decifra": _cifratura_decifra,
                   "genera_password": _cifratura_genera_password}),
        _t("MisuratorePassword", "Sicurezza", "Barra di robustezza della password con consigli in italiano", 2, [
            _p("testo", "testo", "", "Password da valutare"),
            _p("controllo", "testo", "", "Nome della CasellaPassword da seguire", "Comportamento"),
            _sl("punteggio", "intero", 0, "Robustezza da 0 a 100"),
            _sl("livello", "testo", "", "Livello: debolissima, debole, media, forte, fortissima"),
            _sl("consigli", "lista", [], "Consigli per migliorarla"),
        ], ("cambio",), "cambio", icona="shield-check", dimensione=(220, 60)),
        _t("Registro", "Sicurezza", "Elenco di eventi con livelli e filtri, esportabile", 2, [
            _sl("voci", "lista", [], "Voci: dizionari con ora, livello e testo"),
            _p("livello_minimo", "scelta", "debug", "Mostra solo le voci da questo livello in su", "Comportamento",
               scelte=LIVELLI_REGISTRO),
        ], ("nuova_voce",), "nuova_voce", icona="scroll-text", dimensione=(360, 180),
           metodi={"aggiungi": _registro_aggiungi, "esporta": _registro_esporta, "svuota": _registro_svuota}),
    ]


def _produttivita() -> list[TipoControllo]:
    return [
        _t("Lavagna", "Produttività", "Disegno a mano libera, salvabile come immagine", 2, [
            _p("colore_penna", "colore", "#000000", "Colore della penna", "Aspetto"),
            _p("spessore_penna", "intero", 3, "Spessore della penna in pixel", "Aspetto", minimo=1, massimo=100),
            _p("gomma", "logico", False, "Se vero cancella invece di disegnare", "Comportamento"),
        ], ("tratto",), "tratto", icona="pen-tool", dimensione=(360, 240),
           metodi={"pulisci": _lavagna_pulisci, "salva": _lavagna_salva, "annulla": _lavagna_annulla}),
        _t("Kanban", "Produttività", "Colonne con schede da trascinare", 3, [
            _p("colonne", "lista", ["Da fare", "In corso", "Fatto"], "Titoli delle colonne"),
            _p("schede", "dizionario", {}, "Schede per colonna: colonna -> lista di testi"),
        ], ("spostamento_scheda",), "spostamento_scheda", icona="kanban", dimensione=(480, 300),
           metodi={"aggiungi_scheda": _kanban_aggiungi_scheda, "rimuovi_scheda": _kanban_rimuovi_scheda}),
        _t("Diagramma", "Produttività", "Riquadri e frecce da collegare col mouse", 3, [
            _p("nodi", "lista", [], "Riquadri: [id, testo, x, y]"),
            _p("collegamenti", "lista", [], "Frecce: [da, a]"),
        ], ("collegamento",), "collegamento", icona="workflow", dimensione=(400, 300),
           metodi={"aggiungi_nodo": _diagramma_aggiungi_nodo, "collega": _diagramma_collega,
                   "svuota": _diagramma_svuota}),
        _t("ContoAllaRovescia", "Produttività", "Timer visibile con allarme", 2, [
            _p("secondi", "intero", 60, "Durata in secondi", "Comportamento", minimo=0),
            _sl("rimanenti", "intero", 60, "Secondi che mancano"),
            _p("attivo", "logico", False, "Vero mentre conta", "Comportamento"),
            _p("formato", "scelta", "mm:ss", "Come mostrare il tempo", "Aspetto",
               scelte=("mm:ss", "hh:mm:ss", "secondi")),
        ], ("scadenza",), "scadenza", icona="timer", dimensione=(140, 48),
           metodi={"avvia": _conto_avvia, "ferma": _conto_ferma, "azzera": _conto_azzera}),
        _t("Notifica", "Produttività", "Invisibile: notifica del sistema operativo", 2, [
            _p("titolo", "testo", "Leo", "Titolo della notifica"),
            _p("testo", "testo", "", "Testo della notifica"),
        ], ("clic",), "clic", icona="bell", invisibile=True,
           metodi={"mostra": _notifica_mostra}),
    ]


def _indicatori() -> list[TipoControllo]:
    return [
        _t("Quadrante", "Indicatori", "Lancetta analogica, come un tachimetro", 2, [
            _p("valore", "decimale", 0.0, "Valore indicato dalla lancetta"),
            _p("minimo", "decimale", 0.0, "Inizio della scala", "Aspetto"),
            _p("massimo", "decimale", 100.0, "Fine della scala", "Aspetto"),
            _p("soglia", "decimale", 80.0, "Sopra questo valore arriva `soglia_superata`"),
            _p("unita", "testo", "", "Unità di misura mostrata", "Aspetto"),
        ], ("soglia_superata",), "soglia_superata", icona="gauge", dimensione=(160, 160)),
        _t("Semaforo", "Indicatori", "Stato rosso, giallo o verde", 1, [
            _p("stato", "scelta", "rosso", "Luce accesa", scelte=("rosso", "giallo", "verde", "spento")),
            _p("orientamento", "scelta", "verticale", "Disposizione delle luci", "Aspetto",
               scelte=("verticale", "orizzontale")),
        ], ("cambio",), "cambio", icona="traffic-cone", dimensione=(60, 160)),
        _t("Valutazione", "Indicatori", "Voto a stelle", 2, [
            _p("valore", "intero", 0, "Stelle piene", minimo=0),
            _p("massimo", "intero", 5, "Numero di stelle", "Aspetto", minimo=1, massimo=20),
            _p("sola_lettura", "logico", False, "Se vero non si può cliccare", "Comportamento"),
        ], ("cambio",), "cambio", icona="star", dimensione=(150, 30)),
    ]


def _sviluppo_didattica() -> list[TipoControllo]:
    return [
        _t("Terminale", "Sviluppo", "Console di comandi dentro la finestra", 2, [
            _p("prompt", "testo", "> ", "Testo davanti alla riga dei comandi", "Aspetto"),
            _sl("testo", "testo", "", "Tutto il testo mostrato"),
        ], ("comando",), "comando", icona="terminal", dimensione=(400, 200),
           metodi={"scrivi": _terminale_scrivi, "pulisci": _terminale_pulisci}),
        _t("EditorCodice", "Sviluppo", "Editor con i colori della sintassi di Leo", 3, [
            _p("testo", "testo", "", "Codice scritto"),
            _p("tema", "scelta", "nero", "Tema dei colori", "Aspetto", scelte=("nero", "bianco", "alto_contrasto")),
            _p("sola_lettura", "logico", False, "Se vero il codice non si può modificare", "Comportamento"),
        ], ("cambio",), "cambio", icona="code", dimensione=(400, 240),
           metodi={"vai_a_riga": _editor_vai_a_riga}),
        _t("Tutor", "Didattica", "Fumetto che spiega il controllo sotto il mouse", 2, [
            _p("attivo", "logico", True, "Se vero mostra le spiegazioni", "Comportamento"),
            _p("testi", "dizionario", {}, "Spiegazioni personalizzate: nome controllo -> testo"),
        ], ("aiuto_chiesto",), "aiuto_chiesto", icona="graduation-cap", dimensione=(40, 40)),
        _t("Assistente", "Didattica", "Chat con un modello di IA (serve una chiave API)", 3, [
            _p("chiave_api", "testo", "", "Chiave API; se resta vuota, quella delle impostazioni", "Comportamento"),
            _p("modello", "testo", "", "Modello da usare; se non lo scegli, quello predefinito", "Comportamento"),
            _p("istruzioni", "testo", "", "Istruzioni di sistema per l'assistente", "Comportamento"),
            _sl("in_attesa", "logico", False, "Vero mentre aspetta la risposta"),
        ], ("risposta", "errore"), "risposta", icona="bot", dimensione=(320, 300),
           metodi={"chiedi": _assistente_chiedi}),
    ]


def tipi() -> list[TipoControllo]:
    """I 43 controlli inventati per Leo, come oggetti NUOVI a ogni chiamata.

    Gli oggetti non sono ancora passati da ``registra`` (niente proprieta'
    comuni ne' evento ``clic`` aggiunti).
    """
    return [*_italia(), *_hardware(), *_giochi(), *_media(), *_dati_e_rete(),
            *_sicurezza_tipi(), *_produttivita(), *_indicatori(), *_sviluppo_didattica()]


for _tipo in tipi():
    registra(_tipo)
del _tipo
