"""Sistemazione automatica degli oggetti di una finestra, senza Qt.

* :func:`sistema_da_solo`: "Sistema gli oggetti da solo" del disegnatore del telefono
  (``sistemaDaSolo`` in ``android/app/src/main/assets/web/disegna.js``) e di Leo Studio: gli oggetti
  vanno in colonna a tutta larghezza, con margini e spazi uguali; quelli che stanno sulla stessa riga
  restano affiancati e si dividono la larghezza in proporzione.
* :func:`adatta_alla_larghezza`: porta una finestra pensata per il telefono (360 di larghezza) su una
  finestra piu' larga (per esempio da PC), allargando le righe e centrando gli oggetti piccoli.

Gli oggetti sono dizionari con ``nome``, ``tipo``, ``sinistra``, ``alto``, ``larghezza``, ``altezza``
(le misure mancanti valgono come nel disegnatore: 100 di larghezza, 30 di altezza). Qui si passano
solo gli oggetti da sistemare: quelli visibili e non dentro un contenitore.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any, Iterable

from .stili_app import CAMPI, PULSANTI

MARGINE = 20
SPAZIO = 12
#: Altezza minima di pulsanti e campi sul telefono (un dito ci sta comodo).
MINIMO_TOCCO = 44
#: Altezza minima di pulsanti e campi in una finestra da PC (si usa il mouse).
MINIMO_PC = 32

LARGO = ["alto", "sinistra", "destra"]
AFFIANCATO = ["alto", "sinistra"]


def _intero(v: Any, predefinito: int = 0) -> int:
    """Come ``intero`` di disegna.js: il numero intero all'inizio del valore, altrimenti il predefinito."""
    if isinstance(v, bool):
        return predefinito
    if isinstance(v, (int, float)) and math.isfinite(v):
        return int(v)
    testo = str(v if v is not None else "").strip()
    cifre = ""
    for i, ch in enumerate(testo):
        if ch.isdigit() or (i == 0 and ch in "+-"):
            cifre += ch
        else:
            break
    try:
        return int(cifre)
    except ValueError:
        return predefinito


def _arrotonda(x: float) -> int:
    """``Math.round`` di JavaScript (le meta' vanno in su)."""
    return math.floor(x + 0.5)


def raggruppa_in_righe(oggetti: Iterable[dict]) -> list[list[dict]]:
    """Gli oggetti divisi in righe, dall'alto in basso; in ogni riga da sinistra a destra.

    Un oggetto sta nella riga di prima se comincia prima di meta' della piu' bassa delle due altezze
    (la sua e quella della riga) dal fondo della riga.
    """
    ordinati = sorted(oggetti, key=lambda c: (_intero(c.get("alto")), _intero(c.get("sinistra"))))
    righe: list[dict] = []
    for c in ordinati:
        y, h = _intero(c.get("alto")), _intero(c.get("altezza"), 30)
        ult = righe[-1] if righe else None
        if ult is not None and y < ult["fondo"] - min(h, ult["alt"]) / 2:
            ult["c"].append(c)
            ult["fondo"] = max(ult["fondo"], y + h)
            ult["alt"] = max(ult["alt"], h)
        else:
            righe.append({"c": [c], "fondo": y + h, "alt": h})
    return [sorted(r["c"], key=lambda c: _intero(c.get("sinistra"))) for r in righe]


@dataclass
class Sistemazione:
    """Il risultato: rettangolo ``(sinistra, alto, larghezza, altezza)`` e ancoraggio di ogni oggetto,
    e la nuova altezza della finestra (None se quella di prima basta)."""

    rettangoli: dict[str, tuple[int, int, int, int]] = field(default_factory=dict)
    ancoraggi: dict[str, list[str]] = field(default_factory=dict)
    altezza_finestra: int | None = None


def sistema_da_solo(oggetti: Iterable[dict], larghezza_finestra: Any, altezza_finestra: Any, *,
                    margine: int = MARGINE, spazio: int = SPAZIO, minimo: int = MINIMO_TOCCO) -> Sistemazione:
    """Mette in colonna gli oggetti, a tutta larghezza, con margini e spazi uguali (vedi il modulo).

    ``minimo``: altezza minima di pulsanti e campi a una riga (non di elenchi e aree di testo).
    """
    W = _intero(larghezza_finestra, 360)
    M = int(margine)
    risultato = Sistemazione()
    y = M + 8
    for riga in raggruppa_in_righe(oggetti):
        larghi = sum(max(20, _intero(c.get("larghezza"), 100)) for c in riga)
        utile = W - 2 * M - spazio * (len(riga) - 1)
        x, alt = M, 0
        for k, c in enumerate(riga):
            tipo = c.get("tipo", "")
            alto_minimo = minimo if tipo in PULSANTI or (tipo in CAMPI and tipo not in ("Elenco", "AreaTesto")) else 0
            if k == len(riga) - 1:
                w = W - M - x
            else:
                w = _arrotonda(utile * max(20, _intero(c.get("larghezza"), 100)) / larghi)
            h = max(alto_minimo, _intero(c.get("altezza"), 30))
            risultato.rettangoli[c["nome"]] = (x, y, max(20, w), h)
            risultato.ancoraggi[c["nome"]] = list(LARGO if len(riga) == 1 else AFFIANCATO)
            x += w + spazio
            alt = max(alt, h)
        y += alt + spazio
    if y + M > _intero(altezza_finestra, 640):
        risultato.altezza_finestra = y + M
    return risultato


def adatta_alla_larghezza(oggetti: Iterable[dict], da: int, a: int, *, margine: int = MARGINE,
                          largo: float = 0.9) -> dict[str, tuple[int, int, int, int]]:
    """Nuovi rettangoli per portare gli oggetti da una finestra larga ``da`` a una larga ``a``.

    La distanza dai margini si allarga in proporzione: le righe con piu' oggetti, e gli oggetti gia'
    larghi quasi quanto la finestra (almeno ``largo`` dello spazio utile), si allungano; gli altri
    (una bussola, un'immagine) tengono la loro misura e restano centrati allo stesso punto.
    Le altezze e la posizione in verticale non cambiano.
    """
    utile_da = max(1, da - 2 * margine)
    k = (a - 2 * margine) / utile_da
    nuovi: dict[str, tuple[int, int, int, int]] = {}
    for riga in raggruppa_in_righe(oggetti):
        for c in riga:
            x, y = _intero(c.get("sinistra")), _intero(c.get("alto"))
            w, h = _intero(c.get("larghezza"), 100), _intero(c.get("altezza"), 30)
            ancoraggio = c.get("ancoraggio") or []
            allunga = len(riga) > 1 or w >= largo * utile_da or "destra" in ancoraggio
            if allunga:
                nuovi[c["nome"]] = (_arrotonda(margine + (x - margine) * k), y, _arrotonda(w * k), h)
            else:
                centro = margine + (x + w / 2 - margine) * k
                nuovi[c["nome"]] = (_arrotonda(centro - w / 2), y, w, h)
    return nuovi


__all__ = ["sistema_da_solo", "adatta_alla_larghezza", "raggruppa_in_righe", "Sistemazione", "MARGINE", "SPAZIO",
           "MINIMO_TOCCO", "MINIMO_PC"]
