"""Logica pura (senza Qt e senza pagina) dei controlli della scheda "Tutti i giorni".

Qui c'e' tutto quello che serve uguale sul computer (``leo.grafica.qt.widget_quotidiani``),
nel disegnatore di Leo Studio e sul telefono (``assets/web/finestre_quotidiani.js``):

* le **icone** disegnate a linee (:data:`ICONE`) e quelle colorate del meteo
  (:data:`ICONE_METEO`), scritte in un piccolo linguaggio a comandi (lo stesso delle icone di
  Leo Studio: ``l`` spezzata, ``g`` poligono, ``r`` rettangolo, ``c`` cerchio, ``e`` ellisse,
  ``a`` arco, ``p`` percorso SVG assoluto; con ``f`` davanti la figura e' piena);
  :func:`analizza_icona` le trasforma in figure semplici;
* le **date e le ore** (calendario del mese con il lunedi' per primo, ``"HH:MM"``);
* la normalizzazione delle **liste** scritte dal programma (testi semplici o dizionari);
* la **firma** salvata come immagine PNG (:func:`png_da_tratti`), senza librerie esterne;
* i **percorsi delle immagini** da mandare al telefono (:func:`percorsi_immagine`).
"""

from __future__ import annotations

import calendar
import datetime as _dt
import math
import re
import struct
import zlib
from typing import Any

#: I venti controlli della scheda "Tutti i giorni" (nell'ordine della casella). Sta qui, e non nel
#: catalogo, cosi' chi ne ha bisogno (il motore del telefono) non registra i tipi solo importandolo.
TIPI_QUOTIDIANI: tuple[str, ...] = (
    "CalendarioMese", "Chat", "ListaSchede", "SelettoreOrario", "FirmaAMano", "Gradimento", "CasellaPIN",
    "CampoRicerca", "Tag", "Fisarmonica", "BarraSchede", "PulsanteFluttuante", "Avviso", "ListaCoseDaFare",
    "Contatore", "Carosello", "Orologio", "Meteo", "SchedaProfilo", "IndicatorePassi",
)

# ===========================================================================
# Icone
# ===========================================================================

#: Icone a linea (griglia 24x24, tratto 2). I nomi sono quelli che si scrivono nelle proprieta'
#: ``icona`` (PulsanteFluttuante) e nelle voci della BarraSchede.
ICONE: dict[str, str] = {
    "casa": "l 3 10.5 12 3 21 10.5; l 5 9 5 20 10 20 10 14 14 14 14 20 19 20 19 9",
    "cerca": "c 11 11 7; l 16.2 16.2 21 21",
    "cuore": ("p M12 20 C12 20 3 14.5 3 8.6 C3 5.6 5.3 3.5 8 3.5 C9.8 3.5 11.2 4.5 12 6 "
              "C12.8 4.5 14.2 3.5 16 3.5 C18.7 3.5 21 5.6 21 8.6 C21 14.5 12 20 12 20 Z"),
    "profilo": "c 12 8 4; p M4 21 C4 16.6 7.6 14 12 14 C16.4 14 20 16.6 20 21",
    "amici": ("c 9 8 3.5; p M2.5 20 C2.5 16 5.5 13.5 9 13.5 C12.5 13.5 15.5 16 15.5 20; "
              "c 17 9 2.8; p M17 13.5 C19.8 13.5 21.5 15.5 21.5 18.5"),
    "impostazioni": "l 4 6 20 6; l 4 12 20 12; l 4 18 20 18; fc 9 6 2.2; fc 15 12 2.2; fc 7.5 18 2.2",
    "messaggi": "p M6 4 H18 Q20 4 20 6 V14 Q20 16 18 16 H10 L6 20 V16 Q4 16 4 14 V6 Q4 4 6 4 Z",
    "carrello": "l 2 3 5 3 7.5 15 18.5 15 21 7 6 7; fc 9 19.5 1.6; fc 17 19.5 1.6",
    "stella": "g 12 2.5 14.9 8.6 21.5 9.4 16.6 14 17.9 20.6 12 17.3 6.1 20.6 7.4 14 2.5 9.4 9.1 8.6",
    "mappa": "g 3 6 9 3 15 6 21 3 21 18 15 21 9 18 3 21; l 9 3 9 18; l 15 6 15 21",
    "posizione": ("p M12 22 C12 22 19 15 19 9.5 C19 5.4 15.9 2 12 2 C8.1 2 5 5.4 5 9.5 C5 15 12 22 12 22 Z; "
                  "c 12 9.5 2.5"),
    "fotocamera": ("p M4 7 H7.5 L9 5 H15 L16.5 7 H20 Q21 7 21 8 V18 Q21 19 20 19 H4 Q3 19 3 18 V8 Q3 7 4 7 Z; "
                   "c 12 13 3.5"),
    "immagine": "r 3 3 18 18 2; fc 9 9 1.8; l 21 15 16 10 5 21",
    "musica": "l 9 18 9 5 20 3 20 16; c 6.5 18 2.5; c 17.5 16 2.5",
    "calendario": "r 3 5 18 16 2; l 3 10 21 10; l 8 3 8 7; l 16 3 16 7",
    "orologio": "c 12 12 9.5; l 12 7 12 12 15.5 14",
    "più": "l 12 5 12 19; l 5 12 19 12",
    "meno": "l 5 12 19 12",
    "matita": "g 16 3 21 8 8 21 3 21 3 16; l 13.5 5.5 18.5 10.5",
    "campanella": ("p M6 8 C6 4.7 8.7 2 12 2 C15.3 2 18 4.7 18 8 C18 15 21 17 21 17 H3 C3 17 6 15 6 8 Z; "
                   "p M10.3 21 C10.6 21.6 11.3 22 12 22 C12.7 22 13.4 21.6 13.7 21"),
    "condividi": "c 18 5 3; c 6 12 3; c 18 19 3; l 8.6 13.5 15.4 17.5; l 15.4 6.5 8.6 10.5",
    "posta": "r 3 5 18 14 2; l 3 7 12 13 21 7",
    "telefono": "r 6 2 12 20 2; l 11 18 13 18",
    "spunta": "l 5 12.5 10 17.5 19 7",
    "chiudi": "l 6 6 18 18; l 18 6 6 18",
    "info": "c 12 12 10; l 12 11 12 17; fc 12 7.5 1.2",
    "attenzione": "g 12 3 22 20 2 20; l 12 9.5 12 14; fc 12 17 1.1",
    "errore": "c 12 12 10; l 9 9 15 15; l 15 9 9 15",
    "gioco": ("p M7 7 H17 C19.8 7 22 9.5 22 13 C22 16 20.5 18 18.5 18 C16.5 18 15.5 16 14 16 H10 "
              "C8.5 16 7.5 18 5.5 18 C3.5 18 2 16 2 13 C2 9.5 4.2 7 7 7 Z; l 6 12 10 12; l 8 10 8 14; "
              "fc 15.5 11 1.1; fc 17.8 13.3 1.1"),
    "libro": "p M3 4 H9 Q12 4 12 7 V21 Q12 19 9 19 H3 Z; p M21 4 H15 Q12 4 12 7 V21 Q12 19 15 19 H21 Z",
    "lista": "l 9 6 20 6; l 9 12 20 12; l 9 18 20 18; fc 5 6 1.3; fc 5 12 1.3; fc 5 18 1.3",
    "cestino": "l 4 7 20 7; l 6 7 7 20 17 20 18 7; l 10 3.5 14 3.5; l 10 11 10 16; l 14 11 14 16",
    "invia": "g 3 11 21 3 13 21 11 13; l 11 13 21 3",
    "su": "l 6 15 12 9 18 15",
    "giu": "l 6 9 12 15 18 9",
    "sinistra": "l 15 6 9 12 15 18",
    "destra": "l 9 6 15 12 9 18",
    "lampadina": ("p M9 18 V16 C7.2 14.8 6 12.9 6 10.5 C6 7 8.7 4 12 4 C15.3 4 18 7 18 10.5 C18 12.9 16.8 14.8 15 16 "
                  "V18 Z; l 9.5 21 14.5 21"),
    "regalo": "r 3 8 18 5 1; l 5 13 5 21 19 21 19 13; l 12 8 12 21; p M12 8 C12 8 11 3 8 3.5 C5.5 4 6.5 8 12 8; "
              "p M12 8 C12 8 13 3 16 3.5 C18.5 4 17.5 8 12 8",
}

#: Nomi delle icone, nell'ordine con cui compaiono negli elenchi a scelta.
NOMI_ICONE: tuple[str, ...] = tuple(ICONE)

#: Icone dei venti tipi nella casella dei controlli (Leo Studio e disegnatore del telefono): il nome e'
#: quello del campo ``icona`` del catalogo. Stesso linguaggio e stessa griglia delle icone di Studio.
ICONE_TIPI: dict[str, str] = {
    "calendario_mese": "r 3 4 18 17 2; l 3 9 21 9; l 8 2 8 6; l 16 2 16 6; fr 7 12 3 3 0; fr 14 16 3 3 0",
    "chat": ("p M4 5 H16 Q18 5 18 7 V13 Q18 15 16 15 H9 L5 18.5 V15 H4 Q2 15 2 13 V7 Q2 5 4 5 Z; "
             "p M20.5 9 Q22 9 22 10.5 V16 Q22 17.5 20.5 17.5 H20 V20.5 L16.5 17.5 H12"),
    "lista_schede": "r 3 3 6 6 1; l 12 4.5 21 4.5; l 12 7.5 18 7.5; r 3 15 6 6 1; l 12 16.5 21 16.5; l 12 19.5 18 19.5",
    "selettore_orario": "c 12 13 8.5; l 12 8.5 12 13 15 15; l 9.5 2 14.5 2; l 19 5.5 20.5 4",
    "firma": "p M3 17 C5 12 7 8 8.5 8 C10.5 8 8 17 10 17 C11.5 17 12.5 11 14 11 C15.5 11 14.5 16 16 16 C17 16 18 14 19 13; l 3 21 21 21",
    "gradimento": "c 12 12 9.5; fc 8.8 10 1.1; fc 15.2 10 1.1; p M8 14.5 Q12 18 16 14.5",
    "casella_pin": "r 2 7 20 10 2; fc 7 12 1.4; fc 12 12 1.4; fc 17 12 1.4",
    "campo_ricerca": "r 2 6 20 12 6; c 8.5 12 2.8; l 10.6 14.1 12.5 16; l 15 12 19 12",
    "tag": "g 3 3 11 3 21 13 13 21 3 11; fc 7.5 7.5 1.3",
    "fisarmonica": "r 3 3 18 5 1; l 16 5 17 6 18 5; r 3 10 18 11 1; l 6 14 18 14; l 6 17 14 17",
    "barra_schede": "r 2 3 20 18 2; l 2 15 22 15; fc 6.5 18 1.1; fc 12 18 1.1; fc 17.5 18 1.1",
    "fluttuante": "r 3 3 18 18 2; c 15.5 15.5 4; l 15.5 13.5 15.5 17.5; l 13.5 15.5 17.5 15.5",
    "avviso_scomparsa": "r 3 3 18 18 2; r 5 14 14 5 2; l 7.5 16.5 13 16.5",
    "cose_da_fare": "r 3 4 5 5 1; l 4.3 6.6 5.3 7.6 7 5.6; l 11 6.5 21 6.5; r 3 14 5 5 1; l 11 16.5 21 16.5",
    "contatore": "r 2 7 20 10 5; l 5.5 12 8.5 12; l 15.5 12 18.5 12; l 17 10.5 17 13.5; l 12 9.5 12 14.5",
    "carosello": "r 6 5 12 14 1.5; p M4 7 H3 Q2 7 2 8 V16 Q2 17 3 17 H4; p M20 7 H21 Q22 7 22 8 V16 Q22 17 21 17 H20; "
                 "fc 10 21.5 0.8; fc 12 21.5 0.8; fc 14 21.5 0.8",
    "orologio_analogico": "c 12 12 9.5; l 12 6.5 12 12 16 14; l 12 2.5 12 3.8; l 21.5 12 20.2 12; l 12 21.5 12 20.2; l 2.5 12 3.8 12",
    "meteo": "c 8.5 8.5 3.2; l 8.5 2 8.5 3; l 2 8.5 3 8.5; l 3.9 3.9 4.6 4.6; l 13.1 3.9 12.4 4.6; "
             "p M8 20 H18 C20.2 20 22 18.4 22 16.3 C22 14.2 20.2 12.6 18.2 12.6 C17.5 10.4 15.4 9 13 9 "
             "C10.2 9 7.9 11.1 7.7 13.8 C5.6 14 4 15.5 4 17.3 C4 18.8 5.6 20 8 20 Z",
    "scheda_profilo": "r 3 3 18 18 2; c 12 10 3; p M7 18 C7.6 15.6 9.6 14.3 12 14.3 C14.4 14.3 16.4 15.6 17 18",
    "indicatore_passi": "c 4.5 12 2.5; c 12 12 2.5; c 19.5 12 2.5; l 7 12 9.5 12; l 14.5 12 17 12; fc 4.5 12 1",
}

#: Tipo -> nome della sua icona in :data:`ICONE_TIPI` (lo stesso del campo ``icona`` del catalogo).
ICONA_DEL_TIPO: dict[str, str] = {
    "CalendarioMese": "calendario_mese",
    "Chat": "chat",
    "ListaSchede": "lista_schede",
    "SelettoreOrario": "selettore_orario",
    "FirmaAMano": "firma",
    "Gradimento": "gradimento",
    "CasellaPIN": "casella_pin",
    "CampoRicerca": "campo_ricerca",
    "Tag": "tag",
    "Fisarmonica": "fisarmonica",
    "BarraSchede": "barra_schede",
    "PulsanteFluttuante": "fluttuante",
    "Avviso": "avviso_scomparsa",
    "ListaCoseDaFare": "cose_da_fare",
    "Contatore": "contatore",
    "Carosello": "carosello",
    "Orologio": "orologio_analogico",
    "Meteo": "meteo",
    "SchedaProfilo": "scheda_profilo",
    "IndicatorePassi": "indicatore_passi",
}

#: Parole per trovare i controlli nella casella di Leo Studio (oltre al nome e alla descrizione).
SINONIMI_RICERCA: dict[str, tuple[str, ...]] = {
    "CalendarioMese": ("calendario", "agenda", "impegni", "appuntamenti", "date"),
    "Chat": ("messaggi", "conversazione", "bolle", "messaggistica"),
    "ListaSchede": ("elenco", "card", "schede", "lista con immagini"),
    "SelettoreOrario": ("ora", "orario", "sveglia", "time picker"),
    "FirmaAMano": ("firma", "autografo", "signature"),
    "Gradimento": ("soddisfazione", "sondaggio", "feedback", "voto", "faccine"),
    "CasellaPIN": ("pin", "codice", "otp", "codice di verifica"),
    "CampoRicerca": ("ricerca", "cerca", "search", "filtro", "suggerimenti"),
    "Tag": ("etichette", "chip", "filtri", "categorie"),
    "Fisarmonica": ("faq", "domande", "accordion", "sezioni"),
    "BarraSchede": ("navigazione", "tab bar", "menu in basso", "pagine"),
    "PulsanteFluttuante": ("fab", "azione principale", "pulsante tondo"),
    "Avviso": ("toast", "snackbar", "messaggio", "notifica breve"),
    "ListaCoseDaFare": ("todo", "attivita", "checklist", "compiti"),
    "Contatore": ("quantita", "stepper", "piu meno"),
    "Carosello": ("slider", "galleria", "diapositive", "immagini", "onboarding"),
    "Orologio": ("ora", "lancette", "tempo", "sveglia"),
    "Meteo": ("tempo", "previsioni", "temperatura", "weather"),
    "SchedaProfilo": ("profilo", "utente", "avatar", "persona"),
    "IndicatorePassi": ("passi", "stepper", "procedura", "wizard", "avanzamento"),
}

#: Spiegazione degli eventi nuovi di questa scheda (pannello degli eventi di Leo Studio).
DESCRIZIONI_EVENTI: dict[str, str] = {
    "cambio_mese": "Quando si passa a un altro mese: in `mese` e `anno` c'è quello mostrato.",
    "firma": "Quando si finisce un tratto della firma: in `tratti` c'è quanti sono.",
    "completato": "Quando tutte le cifre sono scritte: in `valore` c'è il codice.",
    "ricerca": "Quando si conferma la ricerca (Invio o un suggerimento): in `testo` c'è cosa cercare.",
    "rimozione": "Quando si toglie un elemento: in `elemento` (o `testo`) c'è quale.",
    "spunta": "Quando si mette o si toglie una spunta: `indice`, `testo` e `fatto`.",
    "aggiunta": "Quando si aggiunge un elemento dalla casella: in `testo` c'è quale.",
    "clic_azione": "Quando si tocca il pulsante dell'avviso (per esempio \"Annulla\").",
    "clic_pulsante": "Quando si tocca il pulsante della scheda: in `seguito` c'è se è acceso.",
    "sveglia": "All'ora della sveglia: in `ora` c'è l'ora (\"HH:MM\").",
}

#: Sinonimi delle icone (chiave gia' semplificata: minuscole senza accenti).
SINONIMI_ICONE: dict[str, str] = {
    "home": "casa", "inizio": "casa", "ricerca": "cerca", "lente": "cerca", "preferiti": "cuore",
    "persona": "profilo", "utente": "profilo", "io": "profilo", "account": "profilo", "gruppo": "amici",
    "regolazioni": "impostazioni", "opzioni": "impostazioni", "chat": "messaggi", "messaggio": "messaggi",
    "spesa": "carrello", "negozio": "carrello", "foto": "fotocamera", "camera": "fotocamera",
    "immagini": "immagine", "musica": "musica", "calendario": "calendario", "ora": "orologio",
    "tempo": "orologio", "piu": "più", "aggiungi": "più", "+": "più", "-": "meno", "scrivi": "matita",
    "modifica": "matita", "notifiche": "campanella", "avvisi": "campanella", "email": "posta",
    "lettera": "posta", "fatto": "spunta", "ok": "spunta", "x": "chiudi", "informazione": "info",
    "avviso": "attenzione", "giochi": "gioco", "leggi": "libro", "elenco": "lista", "elimina": "cestino",
    "manda": "invia", "idea": "lampadina", "dove": "posizione", "luogo": "posizione",
}

#: Colori del meteo (uguali su sfondo chiaro e scuro).
COLORI_METEO = {"sole": "#FFB300", "nuvola": "#B7C3D1", "nuvola_scura": "#7C8898", "goccia": "#2F80ED",
                "lampo": "#FFC400", "neve": "#7CC4FA", "nebbia": "#9AA5B1", "vento": "#6FA3D0", "luna": "#F2C94C"}

_RAGGI_SOLE = ("l 12 1.5 12 3.8; l 12 20.2 12 22.5; l 1.5 12 3.8 12; l 20.2 12 22.5 12; l 4.6 4.6 6.2 6.2; "
               "l 17.8 17.8 19.4 19.4; l 4.6 19.4 6.2 17.8; l 17.8 6.2 19.4 4.6")
_NUVOLA = "fc 7.5 15 4; fc 12.5 11.5 5.5; fc 17.5 14.8 4.2; fr 7.5 13 10 6 0"
_NUVOLA_ALTA = "fc 7.5 11.5 4; fc 12.5 8 5.5; fc 17.5 11.3 4.2; fr 7.5 9.5 10 6 0"

#: Icone colorate del meteo: condizione -> [(disegno, colore)] (dal fondo verso chi guarda).
ICONE_METEO: dict[str, list[tuple[str, str]]] = {
    "sole": [("fc 12 12 5", "sole"), (_RAGGI_SOLE, "sole")],
    "poco_nuvoloso": [("fc 9 8.5 4", "sole"),
                      ("l 9 1.5 9 3; l 2 8.5 3.5 8.5; l 4 3.5 5.1 4.6; l 14 3.5 12.9 4.6", "sole"),
                      ("fc 9.5 16.5 3.6; fc 14 13.3 5; fc 18.4 16.6 3.4; fr 9.5 15 9 5.1 0", "nuvola")],
    "nuvoloso": [("fc 16.5 9 3.6; fc 19.5 11 2.5; fr 16.5 9.5 3.2 4 0", "nuvola_scura"), (_NUVOLA, "nuvola")],
    "pioggia": [(_NUVOLA_ALTA, "nuvola_scura"), ("l 8 18 7 21.5; l 12 18 11 21.5; l 16 18 15 21.5", "goccia")],
    "temporale": [(_NUVOLA_ALTA, "nuvola_scura"), ("fg 12.5 14.5 8.5 19.5 11.3 19.5 9.8 23.5 15.5 17.8 12.6 17.8 "
                                                   "14.3 14.5", "lampo")],
    "neve": [(_NUVOLA_ALTA, "nuvola"), ("fc 7.5 19 1.3; fc 12 21.5 1.3; fc 16.5 19 1.3; fc 12 17.2 1", "neve")],
    "nebbia": [("fc 9 8.5 3.2; fc 13.5 6.5 4.2; fc 17 8.8 3; fr 9 7.5 8 4.3 0", "nuvola"),
               ("l 3 14 21 14; l 5 17.5 19 17.5; l 3 21 21 21", "nebbia")],
    "vento": [("p M3 9 H14 C16.5 9 17.5 7.5 17.5 6 C17.5 4.5 16.3 3.5 15 3.5 C13.8 3.5 12.8 4.3 12.6 5.4; "
               "p M3 14 H18.5 C20.5 14 21.8 15.4 21.8 17 C21.8 18.6 20.5 20 18.8 20 C17.5 20 16.4 19.1 16.2 18; "
               "l 3 19 10 19", "vento")],
    "notte": [("fp M19.5 14.8 C18.5 15.3 17.3 15.6 16 15.6 C11.6 15.6 8 12 8 7.6 C8 6.2 8.4 4.9 9 3.8 "
               "C5.5 5 3 8.4 3 12.3 C3 17.3 7.1 21.3 12.1 21.3 C15.6 21.3 18.6 19.4 20.1 16.4 Z", "luna"),
              ("fc 17 5 0.9; fc 20.5 8.5 0.7", "luna")],
}

#: Cielo dietro il Meteo: condizione -> (colore in alto, colore in basso).
CIELI_METEO: dict[str, tuple[str, str]] = {
    "sole": ("#56B3FA", "#2C74E0"), "poco_nuvoloso": ("#6AA8E8", "#3F6FB8"), "nuvoloso": ("#8B9BB0", "#5D6B80"),
    "pioggia": ("#6C7C93", "#3E4B5E"), "temporale": ("#5A5470", "#2B2839"), "neve": ("#9CC3E6", "#6E97C2"),
    "nebbia": ("#A3AEBB", "#737F8D"), "vento": ("#71A6D6", "#4679AE"), "notte": ("#26345A", "#0E1530"),
}

#: Condizioni del meteo e come si leggono.
CONDIZIONI_METEO: dict[str, str] = {
    "sole": "Sereno", "poco_nuvoloso": "Poco nuvoloso", "nuvoloso": "Nuvoloso", "pioggia": "Pioggia",
    "temporale": "Temporale", "neve": "Neve", "nebbia": "Nebbia", "vento": "Ventoso", "notte": "Notte serena",
}

#: Altri modi di dire le condizioni -> condizione vera.
SINONIMI_METEO: dict[str, str] = {
    "sereno": "sole", "soleggiato": "sole", "bel_tempo": "sole", "nuvole": "nuvoloso", "coperto": "nuvoloso",
    "variabile": "poco_nuvoloso", "parzialmente_nuvoloso": "poco_nuvoloso", "piove": "pioggia",
    "pioggerella": "pioggia", "acquazzone": "pioggia", "temporali": "temporale", "fulmini": "temporale",
    "nevica": "neve", "foschia": "nebbia", "ventoso": "vento", "luna": "notte", "sereno_notte": "notte",
}

#: Colori dei cinque livelli del Gradimento (dal piu' basso al piu' alto): leggibili su chiaro e scuro.
COLORI_GRADIMENTO = ("#E5484D", "#F76B15", "#E2A336", "#46A758", "#12A594")
#: Curvatura della bocca (negativa = scontento, positiva = contento), in frazioni del raggio.
BOCCHE_GRADIMENTO = (-0.30, -0.14, 0.0, 0.18, 0.34)
#: Le parole predefinite dei cinque livelli.
TESTI_GRADIMENTO = ("Pessimo", "Scarso", "Nella media", "Buono", "Ottimo")

#: Diapositive d'esempio del Carosello (senza immagini: schede di testo su fondo sfumato).
DIAPOSITIVE_ESEMPIO = (
    {"titolo": "Benvenuto", "testo": "Scorri con il dito per vedere le novità"},
    {"titolo": "Tutto sincronizzato", "testo": "I tuoi dati su telefono e computer"},
    {"titolo": "Pronto a partire", "testo": "Tocca Inizia quando vuoi"},
)

#: Sfumature delle diapositive senza immagine (una dopo l'altra).
SFUMATURE_CAROSELLO = (("#E0182D", "#7A0A16"), ("#2B2B33", "#0B0B0D"), ("#C8102E", "#3A0710"),
                       ("#3A3A44", "#16161A"))

#: Colori delle voci del CalendarioMese quando il programma non ne sceglie uno.
COLORI_IMPEGNI = ("#0A84FF", "#FF9F0A", "#30B158", "#AF52DE", "#FF375F", "#5AC8FA")

#: Livelli dell'Avviso: livello -> (icona, colore).
LIVELLI_AVVISO: dict[str, tuple[str, str]] = {
    "informazione": ("info", "#0A84FF"),
    "successo": ("spunta", "#30B158"),
    "attenzione": ("attenzione", "#FF9F0A"),
    "errore": ("errore", "#FF3B30"),
}


def colore_da(testo: Any, inizio: int = 0) -> str:
    """Colore stabile per un testo (iniziali delle schede, avatar): lo stesso calcolo del telefono."""
    h = int(inizio)
    dati = str(testo or "").encode("utf-16-le")        # come charCodeAt di JavaScript (unita' UTF-16)
    for i in range(0, len(dati), 2):
        h = (h * 31 + (dati[i] | dati[i + 1] << 8)) % 997
    return COLORI_IMPEGNI[h % len(COLORI_IMPEGNI)]


def iniziali(nome: Any) -> str:
    """``"Ada Lovelace"`` -> ``"AL"`` (come sul telefono)."""
    parti = str(nome or "").split()
    if not parti:
        return "?"
    return (parti[0][0] + (parti[-1][0] if len(parti) > 1 else "")).upper()


def _chiave(nome: Any) -> str:
    import unicodedata

    t = unicodedata.normalize("NFD", str(nome).strip().casefold())
    t = "".join(ch for ch in t if not unicodedata.combining(ch))
    return t.replace(" ", "_").replace("-", "_")


def nome_icona(nome: Any, predefinita: str = "") -> str:
    """Nome vero di un'icona: ``"Casa"`` -> ``"casa"``, ``"home"`` -> ``"casa"``, ``"+"`` -> ``"più"``."""
    if isinstance(nome, str):
        if nome in ICONE:
            return nome
        k = _chiave(nome)
        for vero in ICONE:
            if _chiave(vero) == k:
                return vero
        if k in SINONIMI_ICONE:
            return SINONIMI_ICONE[k]
        if nome.strip() in SINONIMI_ICONE:
            return SINONIMI_ICONE[nome.strip()]
    return predefinita


def nome_condizione(nome: Any) -> str:
    """Condizione del meteo vera (``"Sereno"`` -> ``"sole"``); ``""`` se non si riconosce."""
    if not isinstance(nome, str):
        return ""
    k = _chiave(nome)
    if k in ICONE_METEO:
        return k
    return SINONIMI_METEO.get(k, "")


# --- il piccolo linguaggio delle icone ------------------------------------------------------------

_NUMERO = r"-?\d+(?:\.\d+)?"


def analizza_icona(testo: str) -> list[dict]:
    """``"c 12 12 3; fr 2 2 4 4 1"`` -> ``[{"figura": "cerchio", "piena": False, ...}, ...]``.

    Figure: ``spezzata``/``poligono`` (``punti``), ``rettangolo`` (``x y l a raggio``),
    ``cerchio`` (``cx cy r``), ``ellisse`` (``cx cy rx ry``), ``arco`` (``cx cy r inizio ampiezza``),
    ``percorso`` (``comandi``: lista di ``(lettera, numeri)`` con M L H V Q C Z assoluti).
    I comandi sconosciuti si saltano.
    """
    figure: list[dict] = []
    for pezzo in str(testo).split(";"):
        pezzo = pezzo.strip()
        if not pezzo:
            continue
        comando, _, resto = pezzo.partition(" ")
        piena = comando.startswith("f") and len(comando) == 2
        lettera = comando[1:] if piena else comando
        if lettera == "p":
            comandi = []
            for m in re.finditer(r"([MLHVQCZ])([^MLHVQCZ]*)", resto):
                numeri = [float(x) for x in re.findall(_NUMERO, m.group(2))]
                comandi.append((m.group(1), numeri))
            figure.append({"figura": "percorso", "piena": piena, "comandi": comandi})
            continue
        numeri = [float(x) for x in re.findall(_NUMERO, resto)]
        if lettera in ("l", "g") and len(numeri) >= 4:
            punti = [(numeri[i], numeri[i + 1]) for i in range(0, len(numeri) - 1, 2)]
            figure.append({"figura": "spezzata" if lettera == "l" else "poligono", "piena": piena, "punti": punti})
        elif lettera == "r" and len(numeri) >= 4:
            figure.append({"figura": "rettangolo", "piena": piena, "x": numeri[0], "y": numeri[1],
                           "l": numeri[2], "a": numeri[3], "raggio": numeri[4] if len(numeri) > 4 else 0.0})
        elif lettera == "c" and len(numeri) >= 3:
            figure.append({"figura": "cerchio", "piena": piena, "cx": numeri[0], "cy": numeri[1], "r": numeri[2]})
        elif lettera == "e" and len(numeri) >= 4:
            figure.append({"figura": "ellisse", "piena": piena, "cx": numeri[0], "cy": numeri[1],
                           "rx": numeri[2], "ry": numeri[3]})
        elif lettera == "a" and len(numeri) >= 5:
            figure.append({"figura": "arco", "piena": piena, "cx": numeri[0], "cy": numeri[1], "r": numeri[2],
                           "inizio": numeri[3], "ampiezza": numeri[4]})
    return figure


# ===========================================================================
# Date e ore
# ===========================================================================

GIORNI_BREVI = ("L", "M", "M", "G", "V", "S", "D")
MESI = ("gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio", "agosto", "settembre",
        "ottobre", "novembre", "dicembre")

_RE_DATA = re.compile(r"^\s*(\d{1,2})\s*[/.\-]\s*(\d{1,2})\s*[/.\-]\s*(\d{4})\s*$")
_RE_ORA = re.compile(r"^\s*(\d{1,2})\s*[:.]\s*(\d{1,2})(?:\s*[:.]\s*(\d{1,2}))?\s*$")


def leggi_data(testo: Any) -> tuple[int, int, int] | None:
    """``"05/09/2026"`` -> ``(2026, 9, 5)``; ``None`` se non e' una data vera."""
    if not isinstance(testo, str):
        return None
    m = _RE_DATA.match(testo)
    if not m:
        return None
    g, me, a = int(m.group(1)), int(m.group(2)), int(m.group(3))
    try:
        _dt.date(a, me, g)
    except ValueError:
        return None
    return a, me, g


def scrivi_data(anno: int, mese: int, giorno: int) -> str:
    return f"{int(giorno):02d}/{int(mese):02d}/{int(anno):04d}"


def oggi_testo(oggi: _dt.date | None = None) -> str:
    d = oggi or _dt.date.today()
    return scrivi_data(d.year, d.month, d.day)


def griglia_mese(anno: int, mese: int) -> list[list[int]]:
    """Settimane del mese (lunedi' per primo); 0 dove il giorno e' di un altro mese."""
    return [list(settimana) for settimana in calendar.Calendar(firstweekday=0).monthdayscalendar(anno, mese)]


def mese_mostrato(data: Any, mese: Any, anno: Any, oggi: _dt.date | None = None) -> tuple[int, int]:
    """(anno, mese) che il CalendarioMese deve mostrare: ``mese``/``anno`` se ci sono, se no quello
    del giorno scelto, se no quello di oggi."""
    d = leggi_data(data) or (lambda o: (o.year, o.month, o.day))(oggi or _dt.date.today())
    m = mese if isinstance(mese, int) and not isinstance(mese, bool) and 1 <= mese <= 12 else d[1]
    a = anno if isinstance(anno, int) and not isinstance(anno, bool) and 1 <= anno <= 9999 else d[0]
    return a, m


def sposta_mese(anno: int, mese: int, passi: int) -> tuple[int, int]:
    """(2026, 12) + 1 -> (2027, 1)."""
    n = anno * 12 + (mese - 1) + passi
    return max(1, min(9999, n // 12)), n % 12 + 1


def leggi_ora(testo: Any) -> tuple[int, int, int] | None:
    """``"8:05"`` -> ``(8, 5, 0)``; ``"23:59:30"`` -> ``(23, 59, 30)``; ``None`` se non e' un'ora vera."""
    if not isinstance(testo, str):
        return None
    m = _RE_ORA.match(testo)
    if not m:
        return None
    h, mi, s = int(m.group(1)), int(m.group(2)), int(m.group(3) or 0)
    if not (0 <= h <= 23 and 0 <= mi <= 59 and 0 <= s <= 59):
        return None
    return h, mi, s


def scrivi_ora(ore: int, minuti: int) -> str:
    return f"{int(ore) % 24:02d}:{int(minuti) % 60:02d}"


def normalizza_ora(testo: Any, predefinita: str = "00:00") -> str:
    """``"8:5"`` -> ``"08:05"``; un testo che non e' un'ora da' ``predefinita``."""
    o = leggi_ora(testo)
    return scrivi_ora(o[0], o[1]) if o else predefinita


def somma_minuti(ora: str, minuti: int) -> str:
    """``somma_minuti("23:50", 15)`` -> ``"00:05"`` (gira sulle 24 ore)."""
    o = leggi_ora(ora) or (0, 0, 0)
    totale = (o[0] * 60 + o[1] + int(minuti)) % (24 * 60)
    return scrivi_ora(totale // 60, totale % 60)


# ===========================================================================
# Liste scritte dal programma (testi semplici o dizionari)
# ===========================================================================

def _t(v: Any) -> str:
    if v is None:
        return ""
    if v is True:
        return "vero"
    if v is False:
        return "falso"
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return v if isinstance(v, str) else str(v)


def _lista(v: Any) -> list:
    return v if isinstance(v, list) else []


def schede_lista(valore: Any) -> list[dict]:
    """Elementi della ListaSchede: ``[{"titolo", "sottotitolo", "immagine"}]``."""
    r = []
    for x in _lista(valore):
        if isinstance(x, dict):
            r.append({"titolo": _t(x.get("titolo", x.get("testo", ""))), "sottotitolo": _t(x.get("sottotitolo", "")),
                      "immagine": _t(x.get("immagine", "")), "colore": _t(x.get("colore", ""))})
        else:
            r.append({"titolo": _t(x), "sottotitolo": "", "immagine": "", "colore": ""})
    return r


def cose_da_fare(valore: Any) -> list[dict]:
    """Elementi della ListaCoseDaFare: ``[{"testo", "fatto"}]``."""
    r = []
    for x in _lista(valore):
        if isinstance(x, dict):
            r.append({"testo": _t(x.get("testo", "")), "fatto": x.get("fatto") is True})
        else:
            r.append({"testo": _t(x), "fatto": False})
    return r


def messaggi_chat(valore: Any) -> list[dict]:
    """Messaggi della Chat: ``[{"testo", "mio", "autore", "ora"}]``."""
    r = []
    for x in _lista(valore):
        if isinstance(x, dict):
            r.append({"testo": _t(x.get("testo", "")), "mio": x.get("mio") is True, "autore": _t(x.get("autore", "")),
                      "ora": _t(x.get("ora", ""))})
        else:
            r.append({"testo": _t(x), "mio": False, "autore": "", "ora": ""})
    return r


def sezioni_fisarmonica(valore: Any) -> list[dict]:
    """Sezioni della Fisarmonica: ``[{"titolo", "testo"}]`` (anche da un dizionario titolo -> testo)."""
    if isinstance(valore, dict):
        return [{"titolo": _t(k), "testo": _t(v)} for k, v in valore.items()]
    r = []
    for x in _lista(valore):
        if isinstance(x, dict):
            r.append({"titolo": _t(x.get("titolo", "")), "testo": _t(x.get("testo", ""))})
        else:
            r.append({"titolo": _t(x), "testo": ""})
    return r


def voci_barra(valore: Any) -> list[dict]:
    """Voci della BarraSchede: ``[{"testo", "icona"}]``; l'icona si indovina dal testo se manca."""
    r = []
    for x in _lista(valore):
        if isinstance(x, dict):
            testo = _t(x.get("testo", ""))
            icona = nome_icona(x.get("icona", ""), "") or nome_icona(testo, "stella")
        else:
            testo = _t(x)
            icona = nome_icona(testo, "stella")
        r.append({"testo": testo, "icona": icona})
    return r


def impegni_calendario(valore: Any) -> list[dict]:
    """Impegni del CalendarioMese: ``[{"data", "testo", "colore"}]`` con date valide (colore scelto se manca)."""
    r = []
    for i, x in enumerate(_lista(valore)):
        if not isinstance(x, dict):
            continue
        d = leggi_data(x.get("data"))
        if d is None:
            continue
        colore = _t(x.get("colore", "")) or COLORI_IMPEGNI[i % len(COLORI_IMPEGNI)]
        r.append({"data": scrivi_data(*d), "testo": _t(x.get("testo", "")), "colore": colore})
    return r


def previsioni_meteo(valore: Any) -> list[dict]:
    """Previsioni del Meteo: ``[{"giorno", "condizione", "minima", "massima"}]``."""
    r = []
    for x in _lista(valore):
        if isinstance(x, dict):
            r.append({"giorno": _t(x.get("giorno", "")), "condizione": nome_condizione(x.get("condizione")) or "sole",
                      "minima": x.get("minima"), "massima": x.get("massima")})
    return r


def diapositive(valore: Any) -> list[dict]:
    """Diapositive del Carosello: ``[{"immagine", "titolo", "testo"}]`` (un testo semplice e' un percorso
    se sembra un'immagine, altrimenti il titolo)."""
    r = []
    for x in _lista(valore):
        if isinstance(x, dict):
            r.append({"immagine": _t(x.get("immagine", "")).strip(), "titolo": _t(x.get("titolo", "")),
                      "testo": _t(x.get("testo", x.get("didascalia", "")))})
        else:
            t = _t(x).strip()
            r.append({"immagine": t, "titolo": "", "testo": ""} if e_immagine(t) else
                     {"immagine": "", "titolo": t, "testo": ""})
    return r


def testi(valore: Any) -> list[str]:
    return [_t(x) for x in _lista(valore)]


# ===========================================================================
# Immagini da mandare al telefono
# ===========================================================================

def percorsi_immagine(tipo: str, proprieta: str, valore: Any) -> list[str]:
    """Percorsi delle immagini dentro le liste dei controlli della scheda (per il telefono)."""
    if tipo == "ListaSchede" and proprieta == "elementi":
        return [x["immagine"].strip() for x in schede_lista(valore) if x["immagine"].strip()]
    if tipo == "Carosello" and proprieta == "diapositive":
        return [x["immagine"] for x in diapositive(valore) if x["immagine"]]
    return []


def e_immagine(testo: str) -> bool:
    """Vero se il testo e' il percorso di un'immagine (``.png``, ``.jpg``... o ``galleria:``)."""
    t = str(testo).strip().lower()
    return t.startswith("galleria:") or t.endswith((".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp", ".bmp"))


# ===========================================================================
# Firma: immagine PNG dai tratti (senza librerie esterne)
# ===========================================================================

def _rgb(colore: str) -> tuple[int, int, int]:
    t = str(colore or "").strip().lstrip("#")
    if len(t) == 3:
        t = "".join(c * 2 for c in t)
    try:
        return int(t[0:2], 16), int(t[2:4], 16), int(t[4:6], 16)
    except (ValueError, IndexError):
        return 17, 17, 17


def punti_tratto(tratto: Any) -> list[tuple[float, float]]:
    punti = []
    for p in _lista(tratto):
        if isinstance(p, (list, tuple)) and len(p) >= 2:
            try:
                x, y = float(p[0]), float(p[1])
            except (TypeError, ValueError):
                continue
            if math.isfinite(x) and math.isfinite(y):
                punti.append((x, y))
    return punti


def png_da_tratti(tratti: Any, larghezza: int, altezza: int, colore: str = "#111111", spessore: float = 3.0,
                  sfondo: str | None = None) -> bytes:
    """Immagine PNG (RGBA, fondo trasparente se ``sfondo`` e' None) con i tratti disegnati."""
    w, h = max(1, int(larghezza)), max(1, int(altezza))
    r0, g0, b0 = _rgb(colore)
    alfa = bytearray(w * h)
    raggio = max(0.5, float(spessore) / 2)

    def punto(cx: float, cy: float) -> None:
        x0, x1 = int(math.floor(cx - raggio - 1)), int(math.ceil(cx + raggio + 1))
        y0, y1 = int(math.floor(cy - raggio - 1)), int(math.ceil(cy + raggio + 1))
        for y in range(max(0, y0), min(h, y1 + 1)):
            for x in range(max(0, x0), min(w, x1 + 1)):
                d = math.hypot(x + 0.5 - cx, y + 0.5 - cy)
                a = raggio + 0.5 - d
                if a > 0:
                    v = 255 if a >= 1 else int(a * 255)
                    i = y * w + x
                    if v > alfa[i]:
                        alfa[i] = v

    for tratto in _lista(tratti):
        punti = punti_tratto(tratto)
        if len(punti) == 1:
            punto(*punti[0])
        for (xa, ya), (xb, yb) in zip(punti, punti[1:]):
            passi = max(1, int(math.hypot(xb - xa, yb - ya) / max(0.5, raggio / 2)))
            for k in range(passi + 1):
                t = k / passi
                punto(xa + (xb - xa) * t, ya + (yb - ya) * t)
    righe = bytearray()
    fondo = _rgb(sfondo) if sfondo else None
    for y in range(h):
        righe.append(0)
        for x in range(w):
            a = alfa[y * w + x]
            if fondo is None:
                righe += bytes((r0, g0, b0, a))
            else:
                q = a / 255
                righe += bytes((round(fondo[0] + (r0 - fondo[0]) * q), round(fondo[1] + (g0 - fondo[1]) * q),
                                round(fondo[2] + (b0 - fondo[2]) * q), 255))

    def blocco(tipo: bytes, dati: bytes) -> bytes:
        return struct.pack(">I", len(dati)) + tipo + dati + struct.pack(">I", zlib.crc32(tipo + dati) & 0xFFFFFFFF)

    return (b"\x89PNG\r\n\x1a\n" + blocco(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
            + blocco(b"IDAT", zlib.compress(bytes(righe), 6)) + blocco(b"IEND", b""))


__all__ = ["TIPI_QUOTIDIANI", "ICONE", "NOMI_ICONE", "SINONIMI_ICONE", "ICONE_METEO", "COLORI_METEO", "CONDIZIONI_METEO",
           "SINONIMI_METEO", "COLORI_FACCINE", "BOCCHE_FACCINE", "ADESIVI_PREDEFINITI", "COLORI_IMPEGNI",
           "LIVELLI_AVVISO", "GIORNI_BREVI", "MESI", "nome_icona", "nome_condizione", "analizza_icona",
           "leggi_data", "scrivi_data", "oggi_testo", "griglia_mese", "mese_mostrato", "sposta_mese",
           "leggi_ora", "scrivi_ora", "normalizza_ora", "somma_minuti", "schede_lista", "cose_da_fare",
           "messaggi_chat", "sezioni_fisarmonica", "voci_barra", "impegni_calendario", "previsioni_meteo",
           "testi", "percorsi_immagine", "e_immagine", "punti_tratto", "png_da_tratti"]
