"""Logica pura (senza Qt) dei controlli inventati di Leo.

Qui c'e' tutto quello che i widget di ``leo/grafica/qt/widget_dante.py``
calcolano senza bisogno dell'interfaccia, cosi' si puo' provare con
``unittest`` anche dove PySide6 non c'e':

* **Mappa**: proiezione Web Mercator (quella di OpenStreetMap), conversione
  tra coordinate geografiche e punti sullo schermo, spostamento e zoom
  attorno a un punto, tessere visibili.
* **Kanban**: colonne e schede (aggiunta, rimozione, spostamento).
* **Diagramma**: grafo di riquadri e frecce (:class:`GrafoDiagramma`).
* **Galleria**: indice circolare e trascinamento.
* **ContoAllaRovescia**: formati ``mm:ss``, ``hh:mm:ss``, ``secondi``.
* **Valutazione**: voto dal punto cliccato.
* **ModuloAutomatico**: campi generati da un dizionario.
* **MisuratorePassword**: colore della barra per livello/punteggio.
* **Semaforo**: colori delle tre luci.
* Varie: angolo della lancetta del ``Quadrante``, soglie, levetta del
  ``Joystick``, collisioni e bordi degli ``Sprite``, date ``GG/MM/AAAA``,
  animazione del ``Punteggio``, testo del ``Tutor``.

Solo libreria standard; compatibile con Python 3.10.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from datetime import date
from typing import Any, Iterable

from ..errori import ErroreTipo, ErroreValore

# ===========================================================================
# Mappa: proiezione Web Mercator
# ===========================================================================

#: Dimensione in pixel di una tessera di OpenStreetMap.
DIMENSIONE_TESSERA = 256
#: Latitudine massima rappresentabile in Web Mercator.
LATITUDINE_MASSIMA = 85.05112878
ZOOM_MINIMO = 0
ZOOM_MASSIMO = 19
#: Indirizzo delle tessere (politica d'uso di OpenStreetMap: User-Agent obbligatorio).
URL_TESSERE = "https://tile.openstreetmap.org/{z}/{x}/{y}.png"
USER_AGENT_MAPPA = "Leo/1.0 (linguaggio didattico in italiano; controllo Mappa)"


def limita_zoom(zoom: Any) -> int:
    """Zoom intero tra :data:`ZOOM_MINIMO` e :data:`ZOOM_MASSIMO`."""
    try:
        z = int(round(float(zoom)))
    except (TypeError, ValueError):
        z = 6
    return max(ZOOM_MINIMO, min(ZOOM_MASSIMO, z))


def limita_latitudine(lat: float) -> float:
    return max(-LATITUDINE_MASSIMA, min(LATITUDINE_MASSIMA, float(lat)))


def normalizza_longitudine(lon: float) -> float:
    """Porta la longitudine in [-180, 180)."""
    lon = float(lon)
    return ((lon + 180.0) % 360.0) - 180.0


def dimensione_mondo(zoom: int) -> int:
    """Lato in pixel del mondo intero a questo zoom."""
    return DIMENSIONE_TESSERA * (2 ** limita_zoom(zoom))


def lonlat_a_pixel(lat: float, lon: float, zoom: int) -> tuple[float, float]:
    """Coordinate geografiche -> pixel "del mondo" (0,0 = angolo nord-ovest)."""
    lat = limita_latitudine(lat)
    n = dimensione_mondo(zoom)
    x = (float(lon) + 180.0) / 360.0 * n
    s = math.sin(math.radians(lat))
    y = (0.5 - math.log((1 + s) / (1 - s)) / (4 * math.pi)) * n
    return x, y


def pixel_a_lonlat(x: float, y: float, zoom: int) -> tuple[float, float]:
    """Pixel del mondo -> ``(lat, lon)``; la longitudine si riporta in [-180, 180)."""
    n = dimensione_mondo(zoom)
    lon = normalizza_longitudine(x / n * 360.0 - 180.0)
    yy = max(0.0, min(float(n), float(y)))
    lat = math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * yy / n))))
    return limita_latitudine(lat), lon


def centro_da_valore(valore: Any, predefinito: tuple[float, float] = (41.9, 12.5)) -> tuple[float, float]:
    """``[lat, lon]`` (proprieta' ``centro``) -> tupla valida; se non va bene il predefinito."""
    try:
        lat, lon = float(valore[0]), float(valore[1])
    except (TypeError, ValueError, IndexError, KeyError):
        return predefinito
    if not (math.isfinite(lat) and math.isfinite(lon)):
        return predefinito
    return limita_latitudine(lat), normalizza_longitudine(lon)


def lonlat_a_schermo(lat: float, lon: float, centro: tuple[float, float], zoom: int,
                     larghezza: int, altezza: int) -> tuple[float, float]:
    """Punto geografico -> punto nel widget (il centro della mappa e' al centro del widget)."""
    cx, cy = lonlat_a_pixel(centro[0], centro[1], zoom)
    px, py = lonlat_a_pixel(lat, lon, zoom)
    n = dimensione_mondo(zoom)
    dx = px - cx
    # la via piu' corta attorno al mondo (il mondo si ripete in orizzontale)
    if dx > n / 2:
        dx -= n
    elif dx < -n / 2:
        dx += n
    return larghezza / 2 + dx, altezza / 2 + (py - cy)


def schermo_a_lonlat(x: float, y: float, centro: tuple[float, float], zoom: int,
                     larghezza: int, altezza: int) -> tuple[float, float]:
    """Punto nel widget -> ``(lat, lon)``."""
    cx, cy = lonlat_a_pixel(centro[0], centro[1], zoom)
    return pixel_a_lonlat(cx + (x - larghezza / 2), cy + (y - altezza / 2), zoom)


def sposta_centro(centro: tuple[float, float], zoom: int, dx: float, dy: float) -> tuple[float, float]:
    """Nuovo centro dopo aver trascinato la mappa di (dx, dy) pixel (verso destra/basso)."""
    cx, cy = lonlat_a_pixel(centro[0], centro[1], zoom)
    return pixel_a_lonlat(cx - dx, cy - dy, zoom)


def zoom_verso_punto(centro: tuple[float, float], zoom: int, nuovo_zoom: int, x: float, y: float,
                     larghezza: int, altezza: int) -> tuple[tuple[float, float], int]:
    """Cambia zoom tenendo fermo il punto geografico che sta sotto (x, y)."""
    zoom = limita_zoom(zoom)
    nuovo_zoom = limita_zoom(nuovo_zoom)
    if nuovo_zoom == zoom:
        return centro, zoom
    lat, lon = schermo_a_lonlat(x, y, centro, zoom, larghezza, altezza)
    px, py = lonlat_a_pixel(lat, lon, nuovo_zoom)
    nuovo_centro = pixel_a_lonlat(px - (x - larghezza / 2), py - (y - altezza / 2), nuovo_zoom)
    return nuovo_centro, nuovo_zoom


def tessere_visibili(centro: tuple[float, float], zoom: int, larghezza: int, altezza: int
                     ) -> list[tuple[int, int, int, float, float]]:
    """Tessere da disegnare: ``(z, tx, ty, x_schermo, y_schermo)``.

    ``tx`` e' gia' riportato nell'intervallo valido (il mondo si ripete in
    orizzontale); le tessere fuori dal mondo in verticale non compaiono.
    """
    z = limita_zoom(zoom)
    cx, cy = lonlat_a_pixel(centro[0], centro[1], z)
    sinistra = cx - larghezza / 2
    alto = cy - altezza / 2
    quante = 2 ** z
    t = DIMENSIONE_TESSERA
    risultato = []
    tx0 = int(math.floor(sinistra / t))
    tx1 = int(math.floor((sinistra + larghezza - 1) / t))
    ty0 = max(0, int(math.floor(alto / t)))
    ty1 = min(quante - 1, int(math.floor((alto + altezza - 1) / t)))
    for ty in range(ty0, ty1 + 1):
        for tx in range(tx0, tx1 + 1):
            risultato.append((z, tx % quante, ty, tx * t - sinistra, ty * t - alto))
    return risultato


def url_tessera(z: int, x: int, y: int) -> str:
    return URL_TESSERE.format(z=z, x=x, y=y)


def segnaposti_da_valore(valore: Any) -> list[tuple[float, float, str]]:
    """Proprieta' ``segnaposti`` (``[[lat, lon, etichetta], ...]``) -> tuple valide (le altre si saltano)."""
    risultato = []
    if not isinstance(valore, list):
        return risultato
    for elemento in valore:
        if not isinstance(elemento, (list, tuple)) or len(elemento) < 2:
            continue
        try:
            lat, lon = float(elemento[0]), float(elemento[1])
        except (TypeError, ValueError):
            continue
        etichetta = str(elemento[2]) if len(elemento) > 2 and elemento[2] is not None else ""
        risultato.append((lat, lon, etichetta))
    return risultato


def passo_griglia(zoom: int) -> float:
    """Distanza in gradi tra le righe della griglia dello sfondo neutro (senza rete)."""
    z = limita_zoom(zoom)
    for passo in (30.0, 10.0, 5.0, 2.0, 1.0, 0.5, 0.2, 0.1, 0.05, 0.02, 0.01, 0.005, 0.002, 0.001):
        # circa 100 pixel tra una riga e l'altra
        if passo / 360.0 * dimensione_mondo(z) <= 160:
            return passo
    return 0.001


# ===========================================================================
# Kanban
# ===========================================================================

def normalizza_schede(colonne: Any, schede: Any) -> dict[str, list[str]]:
    """Dizionario colonna -> lista di testi, con tutte le colonne (nell'ordine di ``colonne``).

    Le colonne presenti in ``schede`` ma non in ``colonne`` si aggiungono in fondo.
    """
    elenco = [str(c) for c in colonne] if isinstance(colonne, list) else []
    risultato: dict[str, list[str]] = {c: [] for c in elenco}
    if isinstance(schede, dict):
        for colonna, carte in schede.items():
            chiave = str(colonna)
            if isinstance(carte, list):
                valori = [str(c) for c in carte]
            elif carte is None:
                valori = []
            else:
                valori = [str(carte)]
            risultato.setdefault(chiave, [])
            risultato[chiave].extend(valori)
    return risultato


def _colonna_o_errore(schede: dict[str, list[str]], colonna: str) -> list[str]:
    if colonna not in schede:
        raise ErroreValore(f"La colonna `{colonna}` non esiste.",
                           suggerimento="Colonne: " + ", ".join(f'"{c}"' for c in schede) + ".")
    return schede[colonna]


def aggiungi_scheda(schede: dict[str, list[str]], colonna: str, testo: str) -> dict[str, list[str]]:
    """Nuovo dizionario con ``testo`` in fondo a ``colonna``."""
    nuove = {k: list(v) for k, v in schede.items()}
    _colonna_o_errore(nuove, colonna).append(str(testo))
    return nuove


def rimuovi_scheda(schede: dict[str, list[str]], colonna: str, testo: str) -> dict[str, list[str]]:
    """Nuovo dizionario senza la prima scheda ``testo`` di ``colonna``."""
    nuove = {k: list(v) for k, v in schede.items()}
    carte = _colonna_o_errore(nuove, colonna)
    if testo not in carte:
        raise ErroreValore(f"Nella colonna `{colonna}` non c'è la scheda \"{testo}\".")
    carte.remove(testo)
    return nuove


def sposta_scheda(schede: dict[str, list[str]], scheda: str, da: str, a: str,
                  posizione: int | None = None) -> dict[str, list[str]]:
    """Sposta la scheda ``scheda`` dalla colonna ``da`` alla colonna ``a``.

    ``posizione``: indice nella colonna di arrivo (None = in fondo). Se ``da ==
    a`` riordina la colonna. Restituisce un dizionario nuovo.
    """
    nuove = {k: list(v) for k, v in schede.items()}
    partenza = _colonna_o_errore(nuove, da)
    arrivo = _colonna_o_errore(nuove, a)
    if scheda not in partenza:
        raise ErroreValore(f"Nella colonna `{da}` non c'è la scheda \"{scheda}\".")
    vecchio_indice = partenza.index(scheda)
    partenza.pop(vecchio_indice)
    if posizione is None:
        arrivo.append(scheda)
    else:
        p = int(posizione)
        if da == a and p > vecchio_indice:
            p -= 1
        arrivo.insert(max(0, min(len(arrivo), p)), scheda)
    return nuove


def colonna_da_x(x: float, larghezza: float, numero_colonne: int) -> int:
    """Indice della colonna sotto la coordinata ``x`` (colonne di uguale larghezza)."""
    if numero_colonne <= 0 or larghezza <= 0:
        return -1
    i = int(x // (larghezza / numero_colonne))
    return max(0, min(numero_colonne - 1, i))


def indice_da_y(y: float, alto_prima: float, altezza_scheda: float, spazio: float, quante: int) -> int:
    """Posizione d'inserimento in una colonna dato ``y`` (0..quante)."""
    if altezza_scheda + spazio <= 0:
        return quante
    i = int(math.floor((y - alto_prima + (altezza_scheda + spazio) / 2) / (altezza_scheda + spazio)))
    return max(0, min(quante, i))


# ===========================================================================
# Diagramma
# ===========================================================================

@dataclass
class NodoDiagramma:
    id: str                 # chiave interna (testo)
    testo: str
    x: float
    y: float
    larghezza: float = 120.0
    altezza: float = 48.0
    originale: Any = None   # id com'era nel codice Leo (testo o intero)

    @property
    def id_dante(self) -> Any:
        return self.id if self.originale is None else self.originale

    @property
    def rettangolo(self) -> tuple[float, float, float, float]:
        return (self.x, self.y, self.larghezza, self.altezza)

    @property
    def centro(self) -> tuple[float, float]:
        return (self.x + self.larghezza / 2, self.y + self.altezza / 2)

    def contiene(self, px: float, py: float) -> bool:
        return self.x <= px <= self.x + self.larghezza and self.y <= py <= self.y + self.altezza


@dataclass
class GrafoDiagramma:
    """Riquadri (nodi) e frecce (collegamenti) del controllo ``Diagramma``.

    Formato delle proprieta' Leo: ``nodi`` = ``[[id, testo, x, y], ...]``,
    ``collegamenti`` = ``[[da, a], ...]``.
    """

    nodi: dict[str, NodoDiagramma] = field(default_factory=dict)
    collegamenti: list[tuple[str, str]] = field(default_factory=list)
    larghezza_nodo: float = 120.0
    altezza_nodo: float = 48.0

    # --- conversione dalle/alle proprieta' --------------------------------
    @classmethod
    def da_proprieta(cls, nodi: Any, collegamenti: Any, *, larghezza_nodo: float = 120.0,
                     altezza_nodo: float = 48.0) -> "GrafoDiagramma":
        g = cls(larghezza_nodo=larghezza_nodo, altezza_nodo=altezza_nodo)
        if isinstance(nodi, list):
            for voce in nodi:
                if not isinstance(voce, (list, tuple)) or not voce:
                    continue
                ident = voce[0]
                testo = str(voce[1]) if len(voce) > 1 and voce[1] is not None else str(ident)
                try:
                    x = float(voce[2]) if len(voce) > 2 else None
                    y = float(voce[3]) if len(voce) > 3 else None
                except (TypeError, ValueError):
                    x = y = None
                g.aggiungi_nodo(ident, testo, x, y, sostituisci=True)
        if isinstance(collegamenti, list):
            for voce in collegamenti:
                if isinstance(voce, (list, tuple)) and len(voce) >= 2:
                    g.collega(str(voce[0]), str(voce[1]))
        return g

    def nodi_proprieta(self) -> list[list]:
        """Formato della proprieta' ``nodi``, con gli id com'erano (testo o intero)."""
        return [[n.id_dante, n.testo, _numero_pulito(n.x), _numero_pulito(n.y)] for n in self.nodi.values()]

    def collegamenti_proprieta(self) -> list[list]:
        return [[self.id_dante(da), self.id_dante(a)] for da, a in self.collegamenti]

    def id_dante(self, chiave: str) -> Any:
        """L'id Leo (testo o intero) del nodo con chiave interna ``chiave``."""
        nodo = self.nodi.get(chiave)
        return nodo.id_dante if nodo is not None else chiave

    # --- modifiche -----------------------------------------------------------
    def posizione_libera(self) -> tuple[float, float]:
        """Una posizione per un nodo senza coordinate: a scacchiera, 4 per riga."""
        i = len(self.nodi)
        return (20 + (i % 4) * (self.larghezza_nodo + 40), 20 + (i // 4) * (self.altezza_nodo + 40))

    def aggiungi_nodo(self, ident: Any, testo: str, x: float | None = None, y: float | None = None,
                      *, sostituisci: bool = False) -> NodoDiagramma:
        originale = ident if isinstance(ident, int) and not isinstance(ident, bool) else None
        ident = str(ident)
        if ident in self.nodi and not sostituisci:
            raise ErroreValore(f"Nel diagramma c'è già un nodo `{ident}`.")
        if x is None or y is None:
            lx, ly = self.posizione_libera()
            x = lx if x is None else x
            y = ly if y is None else y
        nodo = NodoDiagramma(ident, str(testo), float(x), float(y), self.larghezza_nodo, self.altezza_nodo,
                             originale)
        self.nodi[ident] = nodo
        return nodo

    def rimuovi_nodo(self, ident: Any) -> None:
        ident = str(ident)
        self.nodi.pop(ident, None)
        self.collegamenti = [(da, a) for da, a in self.collegamenti if da != ident and a != ident]

    def collega(self, da: Any, a: Any) -> bool:
        """Aggiunge la freccia ``da -> a``; False se non si puo' (nodo mancante, se stesso, doppione)."""
        da, a = str(da), str(a)
        if da == a or da not in self.nodi or a not in self.nodi:
            return False
        if (da, a) in self.collegamenti:
            return False
        self.collegamenti.append((da, a))
        return True

    def scollega(self, da: Any, a: Any) -> bool:
        da, a = str(da), str(a)
        if (da, a) in self.collegamenti:
            self.collegamenti.remove((da, a))
            return True
        return False

    def sposta_nodo(self, ident: Any, x: float, y: float, area: tuple[float, float] | None = None) -> None:
        nodo = self.nodi[str(ident)]
        if area is not None:
            x = max(0.0, min(float(x), max(0.0, area[0] - nodo.larghezza)))
            y = max(0.0, min(float(y), max(0.0, area[1] - nodo.altezza)))
        nodo.x, nodo.y = float(x), float(y)

    def svuota(self) -> None:
        self.nodi.clear()
        self.collegamenti.clear()

    # --- interrogazioni ------------------------------------------------------
    def nodo_in(self, x: float, y: float) -> str | None:
        """Il nodo piu' in alto (l'ultimo disegnato) che contiene il punto."""
        for nodo in reversed(list(self.nodi.values())):
            if nodo.contiene(x, y):
                return nodo.id
        return None

    def porta_al_fronte(self, ident: str) -> None:
        nodo = self.nodi.pop(ident, None)
        if nodo is not None:
            self.nodi[ident] = nodo

    def segmento_freccia(self, da: str, a: str) -> tuple[tuple[float, float], tuple[float, float]] | None:
        """Estremi della freccia tra i bordi dei due riquadri (None se mancano o si sovrappongono)."""
        n1, n2 = self.nodi.get(da), self.nodi.get(a)
        if n1 is None or n2 is None:
            return None
        c1, c2 = n1.centro, n2.centro
        p1 = punto_sul_bordo(n1.rettangolo, c2)
        p2 = punto_sul_bordo(n2.rettangolo, c1)
        return p1, p2

    def collegati_a(self, ident: str) -> list[str]:
        return [a for da, a in self.collegamenti if da == ident] + [da for da, a in self.collegamenti if a == ident]


def punto_sul_bordo(rett: tuple[float, float, float, float], verso: tuple[float, float]) -> tuple[float, float]:
    """Punto dove la retta dal centro di ``rett`` verso ``verso`` esce dal rettangolo."""
    x, y, w, h = rett
    cx, cy = x + w / 2, y + h / 2
    dx, dy = verso[0] - cx, verso[1] - cy
    if dx == 0 and dy == 0:
        return cx, cy
    fattori = []
    if dx != 0:
        fattori.append((w / 2) / abs(dx))
    if dy != 0:
        fattori.append((h / 2) / abs(dy))
    t = min(fattori)
    return cx + dx * t, cy + dy * t


def punte_freccia(p1: tuple[float, float], p2: tuple[float, float], lunghezza: float = 10.0,
                  apertura_gradi: float = 25.0) -> tuple[tuple[float, float], tuple[float, float]]:
    """I due punti laterali della punta di una freccia che arriva in ``p2``."""
    angolo = math.atan2(p2[1] - p1[1], p2[0] - p1[0])
    a = math.radians(apertura_gradi)
    s1 = (p2[0] - lunghezza * math.cos(angolo - a), p2[1] - lunghezza * math.sin(angolo - a))
    s2 = (p2[0] - lunghezza * math.cos(angolo + a), p2[1] - lunghezza * math.sin(angolo + a))
    return s1, s2


def _numero_pulito(v: float) -> int | float:
    return int(v) if float(v).is_integer() else round(float(v), 2)


# ===========================================================================
# Galleria
# ===========================================================================

def indice_circolare(indice: int, passo: int, quante: int) -> int:
    """Indice dopo ``passo`` avanti (o indietro se negativo), ricominciando dall'inizio."""
    if quante <= 0:
        return 0
    return (int(indice) + int(passo)) % quante


def indice_valido(indice: Any, quante: int) -> int:
    """Indice riportato tra 0 e quante-1 (0 se la lista e' vuota)."""
    if quante <= 0:
        return 0
    try:
        i = int(indice)
    except (TypeError, ValueError):
        return 0
    return max(0, min(quante - 1, i))


def passo_trascinamento(dx: float, larghezza: float, soglia: float = 0.15) -> int:
    """Trascinando verso sinistra oltre la soglia (frazione della larghezza) -> +1 (avanti); verso destra -> -1."""
    limite = max(20.0, larghezza * soglia)
    if dx <= -limite:
        return 1
    if dx >= limite:
        return -1
    return 0


# ===========================================================================
# ContoAllaRovescia
# ===========================================================================

FORMATI_CONTO = ("mm:ss", "hh:mm:ss", "secondi")


def formatta_tempo(secondi: float, formato: str = "mm:ss") -> str:
    """Tempo rimasto in forma leggibile.

    ``mm:ss``: minuti totali e secondi (``125:07`` se servono); ``hh:mm:ss``;
    ``secondi``: solo il numero. I secondi si arrotondano per eccesso, cosi' il
    display arriva a ``00:00`` solo alla scadenza.
    """
    s = max(0, int(math.ceil(float(secondi) - 1e-9)))
    if formato == "secondi":
        return str(s)
    if formato == "hh:mm:ss":
        return f"{s // 3600:02d}:{(s % 3600) // 60:02d}:{s % 60:02d}"
    return f"{s // 60:02d}:{s % 60:02d}"


def rimanenti_interi(secondi_totali: float, trascorsi: float) -> int:
    """Secondi interi rimasti (per eccesso), mai negativi."""
    return max(0, int(math.ceil(float(secondi_totali) - float(trascorsi) - 1e-9)))


# ===========================================================================
# Valutazione
# ===========================================================================

def valore_da_punto(x: float, larghezza: float, massimo: int) -> int:
    """Stelle scelte cliccando in ``x`` su un controllo largo ``larghezza`` con ``massimo`` stelle.

    Il valore va da 1 a ``massimo`` (0 solo se il clic e' fuori a sinistra).
    """
    massimo = max(1, int(massimo))
    if larghezza <= 0 or x < 0:
        return 0
    passo = larghezza / massimo
    return max(1, min(massimo, int(x // passo) + 1))


def valore_valutazione(valore: Any, massimo: Any) -> int:
    try:
        m = max(1, int(massimo))
    except (TypeError, ValueError):
        m = 5
    try:
        v = int(valore)
    except (TypeError, ValueError):
        v = 0
    return max(0, min(m, v))


# ===========================================================================
# ModuloAutomatico
# ===========================================================================

TIPI_CAMPO = ("testo", "password", "area", "intero", "decimale", "logico", "scelta", "data")


@dataclass
class CampoModulo:
    nome: str
    etichetta: str
    tipo: str
    valore: Any
    scelte: list[str] = field(default_factory=list)
    minimo: float | None = None
    massimo: float | None = None


def etichetta_da_nome(nome: str) -> str:
    """``data_di_nascita`` -> ``Data di nascita``."""
    testo = re.sub(r"[_\s]+", " ", str(nome)).strip()
    return testo[:1].upper() + testo[1:] if testo else ""


def _tipo_da_valore(nome: str, valore: Any) -> str:
    if isinstance(valore, bool):
        return "logico"
    if isinstance(valore, int):
        return "intero"
    if isinstance(valore, float):
        return "decimale"
    if isinstance(valore, list):
        return "scelta"
    if isinstance(valore, str):
        minuscolo = nome.lower()
        if "password" in minuscolo or "parola_chiave" in minuscolo:
            return "password"
        if "\n" in valore or len(valore) > 80:
            return "area"
        if re.fullmatch(r"\d{2}/\d{2}/\d{4}", valore) or minuscolo.startswith("data"):
            return "data"
        return "testo"
    return "testo"


def campi_da_dizionario(campi: Any) -> list[CampoModulo]:
    """Campi del ``ModuloAutomatico`` a partire dalla proprieta' ``campi``.

    Ogni voce ``nome: valore`` diventa un campo; il tipo si ricava dal valore:
    logico -> casella di spunta, intero/decimale -> casella numerica, lista ->
    menu a tendina (primo elemento selezionato), testo -> casella di testo
    (``password`` nel nome -> caratteri nascosti, testo lungo o con a capo ->
    area di testo, ``GG/MM/AAAA`` o nome che inizia con ``data`` -> data).
    Un dizionario come valore descrive il campo per esteso:
    ``{"tipo": "scelta", "etichetta": "Classe", "scelte": [...], "valore": ...,
    "minimo": 0, "massimo": 10}``.
    """
    risultato: list[CampoModulo] = []
    if not isinstance(campi, dict):
        return risultato
    for nome, valore in campi.items():
        nome = str(nome)
        if isinstance(valore, dict):
            tipo = str(valore.get("tipo", "")) or _tipo_da_valore(nome, valore.get("valore", ""))
            if tipo not in TIPI_CAMPO:
                tipo = "testo"
            etichetta = str(valore.get("etichetta", "") or etichetta_da_nome(nome))
            scelte = [str(s) for s in valore.get("scelte", [])] if isinstance(valore.get("scelte"), list) else []
            iniziale = valore.get("valore")
            campo = CampoModulo(nome, etichetta, tipo, None, scelte,
                                _numero_o_none(valore.get("minimo")), _numero_o_none(valore.get("massimo")))
            campo.valore = _valore_iniziale(campo, iniziale)
        else:
            tipo = _tipo_da_valore(nome, valore)
            scelte = [str(s) for s in valore] if isinstance(valore, list) else []
            campo = CampoModulo(nome, etichetta_da_nome(nome), tipo, None, scelte)
            campo.valore = _valore_iniziale(campo, None if isinstance(valore, list) else valore)
        risultato.append(campo)
    return risultato


def _numero_o_none(v: Any) -> float | None:
    if isinstance(v, bool) or v is None:
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


def _valore_iniziale(campo: CampoModulo, valore: Any) -> Any:
    t = campo.tipo
    if t == "logico":
        return bool(valore) if isinstance(valore, bool) else False
    if t == "intero":
        try:
            return int(valore) if valore is not None and not isinstance(valore, bool) else 0
        except (TypeError, ValueError):
            return 0
    if t == "decimale":
        try:
            return float(valore) if valore is not None and not isinstance(valore, bool) else 0.0
        except (TypeError, ValueError):
            return 0.0
    if t == "scelta":
        if valore is not None and str(valore) in campo.scelte:
            return str(valore)
        return campo.scelte[0] if campo.scelte else ""
    return "" if valore is None else str(valore)


def valori_iniziali(campi: list[CampoModulo]) -> dict[str, Any]:
    return {c.nome: c.valore for c in campi}


def converti_valore_campo(campo: CampoModulo, testo: Any) -> Any:
    """Valore Leo di un campo dal contenuto del widget (testo o numero)."""
    t = campo.tipo
    if t == "logico":
        return bool(testo)
    if t == "intero":
        try:
            return int(float(str(testo).replace(",", ".")))
        except ValueError:
            raise ErroreValore(f"Il campo \"{campo.etichetta}\" vuole un numero intero.")
    if t == "decimale":
        try:
            return float(str(testo).replace(",", "."))
        except ValueError:
            raise ErroreValore(f"Il campo \"{campo.etichetta}\" vuole un numero.")
    return "" if testo is None else str(testo)


# ===========================================================================
# MisuratorePassword e Semaforo: colori
# ===========================================================================

COLORI_LIVELLO = {
    "debolissima": "#E5484D",
    "molto debole": "#E5484D",
    "debole": "#F76B15",
    "media": "#F5C518",
    "discreta": "#F5C518",
    "buona": "#8BC34A",
    "forte": "#30A46C",
    "fortissima": "#1F8A4C",
    "molto forte": "#1F8A4C",
}
_SCALA_PASSWORD = ((0.0, "#E5484D"), (0.35, "#F76B15"), (0.6, "#F5C518"), (0.8, "#8BC34A"), (1.0, "#30A46C"))


def frazione_punteggio(punteggio: Any) -> float:
    """Punteggio della password (0-100, come ``servizi.sicurezza.valuta_password``) -> frazione 0..1."""
    try:
        p = float(punteggio)
    except (TypeError, ValueError):
        return 0.0
    return max(0.0, min(1.0, p / 100.0))


def colore_password(livello: str = "", punteggio: Any = 0) -> str:
    """Colore della barra del ``MisuratorePassword``.

    Se ``livello`` e' uno dei nomi noti ("debolissima", "debole", "media", "forte",
    "fortissima"...) si usa
    il suo colore; altrimenti il colore si ricava dal punteggio (rosso -> verde).
    """
    chiave = str(livello or "").strip().lower()
    if chiave in COLORI_LIVELLO:
        return COLORI_LIVELLO[chiave]
    f = frazione_punteggio(punteggio)
    colore = _SCALA_PASSWORD[0][1]
    for soglia, c in _SCALA_PASSWORD:
        if f >= soglia:
            colore = c
    return colore


STATI_SEMAFORO = ("rosso", "giallo", "verde", "spento")
COLORI_SEMAFORO_ACCESI = ("#FF3B30", "#FFCC00", "#34C759")
COLORI_SEMAFORO_SPENTI = ("#4A1D1B", "#4A3F12", "#173A22")


def colori_semaforo(stato: str) -> tuple[str, str, str]:
    """Colori delle tre luci (rossa, gialla, verde) per lo ``stato``."""
    accesa = {"rosso": 0, "giallo": 1, "verde": 2}.get(str(stato), -1)
    return tuple(COLORI_SEMAFORO_ACCESI[i] if i == accesa else COLORI_SEMAFORO_SPENTI[i]
                 for i in range(3))  # type: ignore[return-value]


def stato_semaforo_successivo(stato: str) -> str:
    """Ciclo verde -> giallo -> rosso -> verde (spento -> verde)."""
    return {"verde": "giallo", "giallo": "rosso", "rosso": "verde"}.get(str(stato), "verde")


# ===========================================================================
# Quadrante, soglie
# ===========================================================================

def angolo_lancetta(valore: float, minimo: float, massimo: float,
                    inizio: float = -135.0, fine: float = 135.0) -> float:
    """Angolo (gradi, 0 = in alto, positivo in senso orario) della lancetta; valore limitato all'intervallo."""
    try:
        v, lo, hi = float(valore), float(minimo), float(massimo)
    except (TypeError, ValueError):
        return inizio
    if hi == lo:
        return inizio
    if hi < lo:
        lo, hi = hi, lo
    f = (min(max(v, lo), hi) - lo) / (hi - lo)
    return inizio + f * (fine - inizio)


def soglia_superata(precedente: float | None, nuovo: float, soglia: float) -> bool:
    """Vero quando il valore passa da sotto (o uguale) a sopra la soglia."""
    try:
        n, s = float(nuovo), float(soglia)
    except (TypeError, ValueError):
        return False
    if n <= s:
        return False
    if precedente is None:
        return True
    try:
        return float(precedente) <= s
    except (TypeError, ValueError):
        return True


def tacche_quadrante(minimo: float, massimo: float, quante: int = 10) -> list[float]:
    """Valori delle tacche principali (``quante`` intervalli uguali)."""
    quante = max(1, int(quante))
    lo, hi = float(minimo), float(massimo)
    return [lo + (hi - lo) * i / quante for i in range(quante + 1)]


def testo_numero(v: float) -> str:
    """Numero corto per etichette: ``80`` invece di ``80.0``, al massimo 2 decimali."""
    v = float(v)
    if v.is_integer():
        return str(int(v))
    return f"{v:.2f}".rstrip("0").rstrip(".")


# ===========================================================================
# Giochi: joystick, sprite, punteggio
# ===========================================================================

def joystick_da_punto(dx: float, dy: float, raggio: float) -> tuple[float, float, float, float]:
    """Posizione della levetta -> ``(x, y, angolo, forza)``.

    Stesse convenzioni di ``servizi.giochi.joystick_da_punto`` (di cui e' il
    ripiego): ``x``, ``y`` tra -1 e 1 con la direzione dello schermo (``y``
    positivo = in basso), il punto viene riportato dentro il cerchio di raggio
    ``raggio``; ``angolo`` in gradi (0 = destra, 90 = alto, 270 = basso);
    ``forza`` tra 0 e 1.
    """
    if raggio <= 0:
        return 0.0, 0.0, 0.0, 0.0
    distanza = math.hypot(dx, dy)
    if distanza > raggio:
        dx, dy = dx * raggio / distanza, dy * raggio / distanza
        distanza = raggio
    x = dx / raggio
    y = dy / raggio
    angolo = math.degrees(math.atan2(-dy, dx)) % 360.0 if distanza > 0 else 0.0
    return round(x, 4), round(y, 4), round(angolo, 2), round(distanza / raggio, 4)


def rettangoli_sovrapposti(r1: tuple[float, float, float, float], r2: tuple[float, float, float, float]) -> bool:
    """Vero se i due rettangoli ``(x, y, w, h)`` si sovrappongono (toccarsi sul bordo non conta)."""
    x1, y1, w1, h1 = r1
    x2, y2, w2, h2 = r2
    return x1 < x2 + w2 and x2 < x1 + w1 and y1 < y2 + h2 and y2 < y1 + h1


def bordo_superato(rett: tuple[float, float, float, float], area: tuple[float, float]) -> str | None:
    """Bordo dell'area da cui il rettangolo e' uscito del tutto: "sinistra", "destra", "alto", "basso" o None."""
    x, y, w, h = rett
    aw, ah = area
    if x + w <= 0:
        return "sinistra"
    if x >= aw:
        return "destra"
    if y + h <= 0:
        return "alto"
    if y >= ah:
        return "basso"
    return None


def valore_animato(inizio: float, fine: float, t: float) -> float:
    """Valore intermedio (curva morbida "ease-out") con ``t`` tra 0 e 1."""
    t = max(0.0, min(1.0, float(t)))
    morbido = 1 - (1 - t) ** 3
    return inizio + (fine - inizio) * morbido


# ===========================================================================
# Date (CalendarioFestivita') e Tutor
# ===========================================================================

def data_da_testo(testo: Any) -> date | None:
    """``"25/12/2024"`` -> ``date``; None se vuoto o non valido."""
    if not isinstance(testo, str):
        return None
    m = re.fullmatch(r"\s*(\d{1,2})/(\d{1,2})/(\d{4})\s*", testo)
    if not m:
        return None
    try:
        return date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
    except ValueError:
        return None


def testo_da_data(d: date) -> str:
    return f"{d.day:02d}/{d.month:02d}/{d.year:04d}"


def testo_tutor(nome: str, tipo: str, testi: Any, descrizione: str = "") -> str:
    """Testo del fumetto del ``Tutor`` per il controllo ``nome`` di tipo ``tipo``.

    Prima il testo scritto dal programmatore in ``testi`` (per nome o per
    tipo), poi la descrizione del catalogo.
    """
    if isinstance(testi, dict):
        for chiave in (nome, tipo):
            if chiave and chiave in testi and testi[chiave] not in (None, ""):
                return str(testi[chiave])
    if descrizione:
        return f"{nome} ({tipo}): {descrizione}" if nome and tipo else descrizione
    if nome and tipo:
        return f"{nome} ({tipo})"
    return nome or tipo or ""


def riga_valida(testo: str, n: int) -> int:
    """Numero di riga valido (1..righe) per ``vai_a_riga`` dell'``EditorCodice``."""
    righe = max(1, (testo or "").count("\n") + 1)
    try:
        r = int(n)
    except (TypeError, ValueError):
        raise ErroreTipo("`vai_a_riga` vuole un numero di riga intero.")
    return max(1, min(righe, r))


def storia_comandi_scorri(storia: list[str], posizione: int, passo: int) -> int:
    """Nuova posizione nella storia dei comandi del ``Terminale`` (``len(storia)`` = riga nuova vuota)."""
    return max(0, min(len(storia), posizione + passo))


def dati_a_testo(valori: Iterable[Any]) -> list[str]:
    """Elementi di una lista Leo come testi (per immagini, voci, ...)."""
    return [str(v) for v in valori] if isinstance(valori, (list, tuple)) else []
