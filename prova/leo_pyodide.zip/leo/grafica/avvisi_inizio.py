"""Avviso per le condizioni del blocco ``inizio`` che leggono i controlli di inserimento.

Errore tipico di chi comincia, in un programma a finestre::

    inizio
        se CasellaTesto1.testo == "Red" allora
            Finestra1.colore = "rosso"
        fine
    fine

Il blocco ``inizio`` (e in generale il codice fuori da funzioni e ``quando``)
parte **una volta sola**, quando si apre il programma: la casella e' ancora
vuota e la condizione non viene mai piu' controllata. La forma giusta e'
``quando CasellaTesto1.cambio fai ... fine``.

:func:`avvisi_inizio` e' una funzione pura (niente Qt): riceve l'albero
sintattico (o il sorgente) e i controlli delle finestre e restituisce gli
avvisi. Non blocca mai niente: e' solo un consiglio, stampato come gli altri
avvisi del programma a finestre (terminale / pannello Uscita di Leo Studio).

Quali proprieta' "cambiano per mano dell'utente" lo dice il catalogo dei
controlli (:mod:`leo.grafica.catalogo_classici`, :mod:`leo.grafica.catalogo_dante`):
i tipi con l'evento ``cambio`` o ``selezione`` e le loro proprieta' del gruppo
``Dati`` (piu' ``testo`` per le caselle), tolte quelle di configurazione
(``minimo``, ``massimo``, ``elementi``...).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping

from .. import nodi as N

__all__ = ["AvvisoInizio", "avvisi_inizio", "proprieta_utente", "evento_principale"]

#: Tipi con ``cambio`` che pero' cambia il programma, non l'utente (spie, punteggi...).
_TIPI_NON_UTENTE = frozenset({"Led", "Punteggio", "Semaforo", "Appunti", "Timer"})

#: Proprieta' ``Dati`` che sono configurazione, non la scelta dell'utente.
_PROPRIETA_CONFIGURAZIONE = frozenset({
    "elementi", "minimo", "massimo", "passo", "minimo_data", "massimo_data", "colonne", "righe",
    "schede", "decimali", "record", "campi",
})

_EVENTI_UTENTE = ("cambio", "selezione")


def _tipo(nome_tipo: str) -> Any:
    from .metadati import carica_catalogo

    return carica_catalogo().get(nome_tipo)


def evento_principale(nome_tipo: str) -> str | None:
    """Evento con cui reagire alle modifiche dell'utente (``cambio``, ``selezione``); None se non c'e'."""
    tipo = _tipo(nome_tipo)
    if tipo is None or nome_tipo in _TIPI_NON_UTENTE:
        return None
    eventi = tuple(tipo.eventi)
    if tipo.evento_predefinito in _EVENTI_UTENTE:
        return tipo.evento_predefinito
    for e in _EVENTI_UTENTE:
        if e in eventi:
            return e
    return None


def proprieta_utente(nome_tipo: str) -> frozenset[str]:
    """Proprieta' di ``nome_tipo`` che cambiano quando l'utente scrive, sceglie, sposta..."""
    tipo = _tipo(nome_tipo)
    if tipo is None or evento_principale(nome_tipo) is None:
        return frozenset()
    nomi = {p.nome for p in tipo.proprieta.values()
            if getattr(p, "gruppo", "") == "Dati" and p.nome not in _PROPRIETA_CONFIGURAZIONE}
    if "testo" in tipo.proprieta and tipo.scheda != "Scelta":
        nomi.add("testo")       # CasellaTesto, CasellaCodiceFiscale... (non l'etichetta di una CasellaSpunta)
    return frozenset(nomi)


@dataclass
class AvvisoInizio:
    """Un avviso: la condizione alla ``riga`` legge ``controllo.proprieta`` all'avvio."""

    riga: int
    colonna: int
    controllo: str
    proprieta: str
    evento: str
    testo: str


# ---------------------------------------------------------------------------
# Visita dell'albero
# ---------------------------------------------------------------------------

#: Istruzioni il cui corpo NON parte all'avvio (funzioni, eventi, temporizzatori, test...).
_CORPI_DIFFERITI = (N.DefinizioneFunzione, N.Evento, N.Temporizzatore, N.BloccoVerifica)


def _figli_espressione(espr: Any) -> Iterable[Any]:
    """Sotto-espressioni lette subito (non entra nelle funzioni anonime e in ``in parallelo``)."""
    if isinstance(espr, (N.FunzioneAnonima, N.Parallelo)) or not isinstance(espr, N.Nodo):
        return
    for valore in vars(espr).values():
        if isinstance(valore, N.Nodo):
            yield valore
        elif isinstance(valore, (list, tuple)):
            for v in valore:
                if isinstance(v, N.Nodo):
                    yield v
                elif isinstance(v, tuple):          # coppie dei dizionari
                    yield from (x for x in v if isinstance(x, N.Nodo))


def _letture(espr: Any) -> Iterable[N.Attributo]:
    """Tutti gli ``Attributo`` letti in un'espressione."""
    pila = [espr]
    while pila:
        nodo = pila.pop()
        if isinstance(nodo, N.Attributo):
            yield nodo
        pila.extend(_figli_espressione(nodo))


def _condizioni(istruzioni: Iterable[Any]) -> Iterable[tuple[Any, Any]]:
    """(istruzione di partenza, espressione di condizione) eseguite all'avvio."""
    for istr in istruzioni:
        if isinstance(istr, _CORPI_DIFFERITI):
            continue
        if isinstance(istr, N.Se):
            for ramo in istr.rami:
                yield ramo, ramo.condizione
                yield from _condizioni(ramo.corpo)
            yield from _condizioni(istr.altrimenti or ())
        elif isinstance(istr, N.Mentre):
            yield istr, istr.condizione
            yield from _condizioni(istr.corpo)
        elif isinstance(istr, N.Scegli):
            yield istr, istr.valore
            for caso in istr.casi:
                yield from _condizioni(caso.corpo)
            yield from _condizioni(istr.altrimenti or ())
        elif isinstance(istr, (N.PerOgni, N.Ripeti)):
            yield from _condizioni(istr.corpo)
        elif isinstance(istr, N.Prova):
            yield from _condizioni(istr.corpo)
            for cattura in istr.catture:
                yield from _condizioni(cattura.corpo)
            yield from _condizioni(istr.infine or ())


# ---------------------------------------------------------------------------
# Testo dell'avviso
# ---------------------------------------------------------------------------

def _stato(valore: Any, proprieta: str) -> str:
    if isinstance(valore, bool):
        return f"è ancora `{'vero' if valore else 'falso'}`"
    if valore is None or valore == "":
        return "è ancora vuoto" if proprieta != "data" else "ha ancora il valore iniziale"
    if isinstance(valore, (int, float)):
        return f"vale ancora {valore}"
    if isinstance(valore, str):
        return f"vale ancora \"{valore}\""
    return "ha ancora il valore iniziale"


def _azione(nome_tipo: str) -> str:
    tipo = _tipo(nome_tipo)
    scheda = getattr(tipo, "scheda", "")
    if nome_tipo in ("CasellaNumero", "Cursore", "Valutazione", "CasellaImporto"):
        return "a quello che fa l'utente"
    if scheda in ("Scelta", "Dati") or nome_tipo.startswith("Selettore") or evento_principale(nome_tipo) == "selezione":
        return "a quello che sceglie l'utente"
    return "a quello che scrive l'utente"


def _testo(nome: str, proprieta: str, evento: str, nome_tipo: str, valore: Any, riga: int,
           nome_file: str, dentro_inizio: bool, pulsante: str) -> str:
    dove = f"alla riga {riga}" + (f" di `{nome_file}`" if nome_file and not nome_file.startswith("<") else "")
    chi = ("Il blocco `inizio` parte" if dentro_inizio
           else "Il codice fuori da `quando` e dalle funzioni parte")
    return (f"{chi} una volta sola, quando si apre il programma: in quel momento "
            f"`{nome}.{proprieta}` {_stato(valore, proprieta)} e la condizione {dove} non verrà più "
            f"controllata. Per reagire {_azione(nome_tipo)} usa un evento:\n"
            f"    quando {nome}.{evento} fai\n"
            f"        ...\n"
            f"    fine\n"
            f"(oppure `quando {pulsante}.clic fai` se vuoi controllare quando si preme un pulsante).")


# ---------------------------------------------------------------------------
# Funzione principale
# ---------------------------------------------------------------------------

def _risolvi(nome: str, controlli: Mapping[str, str], per_minuscolo: dict[str, list[str]],
             tollerante: bool) -> str | None:
    if nome in controlli:
        return nome
    simili = per_minuscolo.get(nome.lower(), [])
    if tollerante and len(simili) == 1:
        return simili[0]
    return None


def avvisi_inizio(programma: Any, controlli: Mapping[str, str], *,
                  valori: Mapping[str, Mapping[str, Any]] | None = None,
                  nome_file: str = "", tollerante: bool = True,
                  **opzioni: Any) -> list[AvvisoInizio]:
    """Avvisi per le condizioni eseguite all'avvio che leggono un controllo di inserimento.

    ``programma``: un :class:`leo.nodi.Programma` oppure il sorgente (testo;
    se non si analizza non ci sono avvisi: l'errore lo mostra l'esecuzione);
    ``controlli``: nome del controllo -> nome del tipo (``"CasellaTesto"``);
    ``valori``: facoltativo, nome -> proprieta' della maschera (per dire "e' ancora vuoto");
    ``tollerante``: maiuscole diverse nei nomi dei controlli vanno bene (modalita' normale);
    ``opzioni``: passate a ``esecuzione.analizza`` quando ``programma`` e' un testo.
    """
    if isinstance(programma, str):
        from ..errori import ErroreDante
        from ..esecuzione import analizza

        try:
            programma = analizza(programma, nome_file or "<sorgente>", **opzioni)
        except (ErroreDante, RecursionError):
            return []
    if not isinstance(programma, N.Programma) or not controlli:
        return []
    nome_file = nome_file or getattr(programma, "nome_file", "")
    valori = valori or {}
    per_minuscolo: dict[str, list[str]] = {}
    for n in controlli:
        per_minuscolo.setdefault(n.lower(), []).append(n)
    pulsanti = [n for n, t in controlli.items() if t in ("Pulsante", "PulsanteImmagine")]
    pulsante = pulsanti[0] if pulsanti else "Pulsante1"
    finestre = {n for n, t in controlli.items() if t == "Finestra"}

    istruzioni = list(programma.istruzioni)
    blocco = getattr(programma, "blocco_inizio", None)
    indice_inizio = blocco[1] if blocco else None

    avvisi: list[AvvisoInizio] = []
    visti: set[tuple[str, str]] = set()
    for posizione, istr in enumerate(istruzioni):
        dentro_inizio = indice_inizio is not None and posizione >= indice_inizio
        for nodo, condizione in _condizioni([istr]):
            for lettura in sorted(_letture(condizione), key=lambda a: (a.riga, a.colonna)):
                oggetto = lettura.oggetto
                # `Finestra1.CasellaTesto1.testo` come `CasellaTesto1.testo`
                if isinstance(oggetto, N.Attributo) and isinstance(oggetto.oggetto, N.Nome) \
                        and _risolvi(oggetto.oggetto.nome, controlli, per_minuscolo, tollerante) in finestre:
                    nome_scritto = oggetto.nome
                elif isinstance(oggetto, N.Nome):
                    nome_scritto = oggetto.nome
                else:
                    continue
                vero = _risolvi(nome_scritto, controlli, per_minuscolo, tollerante)
                if vero is None:
                    continue
                nome_tipo = controlli[vero]
                evento = evento_principale(nome_tipo)
                if evento is None:
                    continue
                tipo = _tipo(nome_tipo)
                prop = tipo.risolvi_nome(lettura.nome) if tollerante else lettura.nome
                if prop not in proprieta_utente(nome_tipo) or (vero, prop) in visti:
                    continue
                visti.add((vero, prop))
                valore = (valori.get(vero) or {}).get(prop, tipo.proprieta[prop].predefinito)
                riga = lettura.riga or getattr(nodo, "riga", 0) or istr.riga
                avvisi.append(AvvisoInizio(
                    riga=riga, colonna=lettura.colonna, controllo=vero, proprieta=prop, evento=evento,
                    testo=_testo(vero, prop, evento, nome_tipo, valore, riga, nome_file, dentro_inizio, pulsante)))
    return avvisi
