"""Controlli personalizzati (versione 3): nuovi controlli composti da quelli esistenti.

Un controllo personalizzato e' un file ``<NomeTipo>.controllo`` nella cartella
del progetto (o nella sua sottocartella ``controlli/``). Il formato e' lo
stesso della ``.maschera`` (TOML): ``[finestra]`` e' la radice del controllo
(le sue ``larghezza``/``altezza`` sono la dimensione predefinita) e
``[[controlli]]`` sono i controlli che lo compongono, con coordinate relative
alla radice. In piu' c'e' la sezione ``[controllo]``::

    [maschera]
    versione = 1

    [controllo]
    scheda = "Personalizzati"          # scheda della casella (predefinita)
    descrizione = "Nome, via e citta'"
    proprieta_esposte = { titolo = "Etichetta1.testo", via = "CasellaVia.testo" }

    [finestra]
    nome = "ModuloIndirizzo"
    tipo = "Finestra"
    larghezza = 300
    altezza = 90

    [[controlli]]
    nome = "Etichetta1"
    tipo = "Etichetta"
    ...

Il nome del tipo e' quello del file (``ModuloIndirizzo.controllo``), oppure
``[controllo].nome`` se presente. Le *proprieta' esposte* diventano proprieta'
del nuovo tipo e vengono inoltrate ai controlli interni.

API (note_generali, mini-contratto 6):
    COMPOSIZIONI: dict[str, ModelloMaschera]
    carica_controlli_personalizzati(cartella) -> list[str]
    rimuovi_controlli_personalizzati(nomi) -> None
    salva_controllo_personalizzato(maschera, nomi, nome_tipo, cartella, *,
                                   descrizione="", proprieta_esposte=None) -> Path
In piu':
    PROPRIETA_ESPOSTE: dict[str, dict[str, tuple[str, str]]]   # tipo -> esposta -> (figlio, proprieta')
    AVVISI: list[str]                                          # problemi dell'ultimo caricamento
    SCHEDA_PREDEFINITA = "Personalizzati"
    leggi_controllo_personalizzato(percorso) -> tuple[str, ModelloMaschera, dict]
    modelli_figli(nome_tipo, istanza) -> list[ModelloControllo]
    collega_proprieta_esposte(composito, figli) -> None
"""

from __future__ import annotations

import copy
import os
from pathlib import Path
from typing import Any, Iterable

from ..errori import ErroreFile, ErroreValore
from ..tomlutil import ErroreToml, carica_toml, leggi_toml, scrivi_toml
from .maschera import leggi_maschera_da_dizionario, scrivi_maschera
from .metadati import CATALOGO, Proprieta, TipoControllo, proprieta_comuni, registra
from .modello import ModelloControllo, ModelloMaschera

__all__ = [
    "COMPOSIZIONI", "PROPRIETA_ESPOSTE", "AVVISI", "SCHEDA_PREDEFINITA", "ESTENSIONE",
    "carica_controlli_personalizzati", "rimuovi_controlli_personalizzati",
    "salva_controllo_personalizzato", "leggi_controllo_personalizzato",
    "modelli_figli", "collega_proprieta_esposte",
]

SCHEDA_PREDEFINITA = "Personalizzati"
ESTENSIONE = ".controllo"

#: Composizioni dei controlli personalizzati caricati: tipo -> maschera (radice + figli).
COMPOSIZIONI: dict[str, ModelloMaschera] = {}

#: Proprieta' esposte: tipo -> nome esposto -> (nome del figlio, proprieta' del figlio).
PROPRIETA_ESPOSTE: dict[str, dict[str, tuple[str, str]]] = {}

#: Problemi trovati nell'ultimo :func:`carica_controlli_personalizzati` (file saltati).
AVVISI: list[str] = []

#: Tipi registrati da questo modulo (gli unici che si possono togliere).
_REGISTRATI: set[str] = set()

#: Proprieta' che ogni controllo visibile ha gia' e che non si possono esporre.
_RISERVATE = frozenset(proprieta_comuni()) | {"tipo"}


# ===========================================================================
# Utilita'
# ===========================================================================

def _tipo_noto(nome: str) -> TipoControllo | None:
    """Metadati di un tipo del catalogo, senza sollevare (catalogo caricato se possibile)."""
    try:
        from .metadati import carica_catalogo

        carica_catalogo()
    except Exception:  # noqa: BLE001 - i cataloghi degli altri possono essere incompleti
        pass
    return CATALOGO.get(nome)


def _e_incorporato(nome: str) -> bool:
    """Vero se ``nome`` e' un tipo del catalogo che non viene da un ``.controllo``."""
    return nome not in _REGISTRATI and _tipo_noto(nome) is not None


def _controlla_nome_tipo(nome_tipo: Any) -> str:
    if not isinstance(nome_tipo, str) or not nome_tipo.isidentifier():
        raise ErroreValore(f"`{nome_tipo}` non va bene come nome di un controllo.",
                           suggerimento="Usa una parola sola, senza spazi, es. \"ModuloIndirizzo\".")
    if nome_tipo[0] == "_":
        raise ErroreValore("Il nome di un controllo non può iniziare con `_`.")
    if nome_tipo in ("Finestra",) or _e_incorporato(nome_tipo):
        raise ErroreValore(f"Esiste già un controllo di serie chiamato `{nome_tipo}`.",
                           suggerimento="Scegli un altro nome per il tuo controllo.")
    return nome_tipo


def _analizza_esposte(esposte: Any, composizione: ModelloMaschera, dove: str) -> dict[str, tuple[str, str]]:
    """``{"titolo": "Etichetta1.testo"}`` -> ``{"titolo": ("Etichetta1", "testo")}`` controllato."""
    if esposte is None:
        return {}
    if not isinstance(esposte, dict):
        raise ErroreValore(f"{dove}: `proprieta_esposte` deve essere una tabella, es. {{ testo = \"Etichetta1.testo\" }}.")
    risultato: dict[str, tuple[str, str]] = {}
    for nome, destinazione in esposte.items():
        if not isinstance(nome, str) or not nome.isidentifier():
            raise ErroreValore(f"{dove}: `{nome}` non va bene come nome di proprietà.")
        if nome in _RISERVATE:
            raise ErroreValore(f"{dove}: la proprietà `{nome}` esiste già in ogni controllo e non si può esporre.",
                               suggerimento="Scegli un altro nome, es. `testo_etichetta`.")
        if not isinstance(destinazione, str) or destinazione.count(".") != 1:
            raise ErroreValore(f"{dove}: la proprietà esposta `{nome}` deve indicare \"Controllo.proprieta\".")
        figlio, prop = (parte.strip() for parte in destinazione.split("."))
        modello = composizione.trova(figlio)
        if modello is None or modello is composizione.finestra:
            raise ErroreValore(f"{dove}: la proprietà esposta `{nome}` si riferisce a `{figlio}`, "
                               "che non fa parte del controllo.")
        tipo = _tipo_noto(modello.tipo)
        if tipo is not None and prop not in tipo.proprieta:
            raise ErroreValore(f"{dove}: il controllo `{figlio}` ({modello.tipo}) non ha la proprietà `{prop}`.")
        if tipo is not None and (tipo.proprieta[prop].sola_lettura or tipo.proprieta[prop].solo_progettazione):
            raise ErroreValore(f"{dove}: la proprietà `{figlio}.{prop}` non si può cambiare e non si può esporre.")
        risultato[nome] = (figlio, prop)
    return risultato


def _proprieta_esposta(nome: str, figlio: ModelloControllo, prop: str) -> Proprieta:
    """Metadati della proprieta' esposta: copia di quelli del figlio, con il valore del figlio come predefinito."""
    tipo = _tipo_noto(figlio.tipo)
    base = tipo.proprieta.get(prop) if tipo is not None else None
    if base is None:
        return Proprieta(nome, "qualsiasi", copy.deepcopy(figlio.proprieta.get(prop)), "Dati",
                         f"Inoltrata a {figlio.nome}.{prop}")
    p = copy.deepcopy(base)
    p.nome = nome
    p.gruppo = "Dati"
    p.descrizione = f"Inoltrata a {figlio.nome}.{prop}" + (f" ({base.descrizione})" if base.descrizione else "")
    if prop in figlio.proprieta:
        p.predefinito = copy.deepcopy(figlio.proprieta[prop])
    return p


# ===========================================================================
# Lettura e caricamento
# ===========================================================================

def leggi_controllo_personalizzato(percorso: str | os.PathLike) -> tuple[str, ModelloMaschera, dict]:
    """Legge un file ``.controllo``: (nome del tipo, composizione, sezione ``[controllo]``).

    ``ErroreFile`` se non si legge, ``ErroreValore`` se e' malformato.
    """
    percorso = Path(percorso)
    try:
        dati = carica_toml(percorso)
    except ErroreToml as e:
        raise ErroreValore(f"`{percorso.name}` non è un TOML valido: {e.messaggio}.", e.riga) from None
    intestazione = dati.get("controllo", {})
    if not isinstance(intestazione, dict):
        raise ErroreValore(f"`{percorso.name}`: `[controllo]` deve essere una tabella.")
    composizione = leggi_maschera_da_dizionario(dati)
    nome_tipo = intestazione.get("nome") or percorso.stem
    if not isinstance(nome_tipo, str) or not nome_tipo.isidentifier():
        raise ErroreValore(f"`{percorso.name}`: `{nome_tipo}` non va bene come nome di un controllo.")
    return nome_tipo, composizione, intestazione


def _tipo_da_composizione(nome_tipo: str, composizione: ModelloMaschera, intestazione: dict,
                          esposte: dict[str, tuple[str, str]]) -> TipoControllo:
    radice = composizione.finestra
    larghezza = int(radice.proprieta.get("larghezza", 200) or 200)
    altezza = int(radice.proprieta.get("altezza", 100) or 100)
    scheda = intestazione.get("scheda") or SCHEDA_PREDEFINITA
    descrizione = intestazione.get("descrizione") or f"Controllo personalizzato fatto di {len(composizione.controlli)} controlli"
    proprieta = {nome: _proprieta_esposta(nome, composizione.trova(figlio), prop)
                 for nome, (figlio, prop) in esposte.items()}
    return TipoControllo(
        nome=nome_tipo, scheda=str(scheda), descrizione=str(descrizione), versione=3,
        proprieta=proprieta, eventi=("clic",), evento_predefinito="clic",
        dimensione_predefinita=(max(1, larghezza), max(1, altezza)), icona="puzzle",
    )


def _file_controlli(cartella: Path) -> list[Path]:
    trovati: list[Path] = []
    for dove in (cartella, cartella / "controlli"):
        if dove.is_dir():
            trovati.extend(sorted(p for p in dove.iterdir() if p.suffix == ESTENSIONE and p.is_file()))
    return trovati


def carica_controlli_personalizzati(cartella: str | os.PathLike) -> list[str]:
    """Registra nel catalogo i controlli ``*.controllo`` della cartella del progetto.

    Cerca nella cartella e nella sua sottocartella ``controlli/``. Restituisce
    i nomi dei tipi registrati. I file con problemi vengono saltati e
    descritti in :data:`AVVISI`; un file che userebbe il nome di un controllo
    di serie non lo sostituisce mai. Ricaricare lo stesso controllo lo aggiorna.
    """
    AVVISI.clear()
    cartella = Path(cartella)
    if not cartella.is_dir():
        AVVISI.append(f"La cartella `{cartella}` non esiste.")
        return []
    registrati: list[str] = []
    for percorso in _file_controlli(cartella):
        try:
            nome_tipo, composizione, intestazione = leggi_controllo_personalizzato(percorso)
            if nome_tipo in registrati:
                raise ErroreValore(f"il controllo `{nome_tipo}` è definito due volte.")
            if nome_tipo == "Finestra" or _e_incorporato(nome_tipo):
                raise ErroreValore(f"`{nome_tipo}` è già un controllo di serie.")
            esposte = _analizza_esposte(intestazione.get("proprieta_esposte"), composizione, percorso.name)
            tipo = _tipo_da_composizione(nome_tipo, composizione, intestazione, esposte)
        except (ErroreValore, ErroreFile) as e:
            AVVISI.append(f"{percorso.name}: {e.messaggio}")
            continue
        # copia anche nella radice in memoria (non nel file): lo strato Qt la legge da li'
        composizione.finestra.proprieta["proprieta_esposte"] = {k: f"{f}.{p}" for k, (f, p) in esposte.items()}
        registra(tipo)
        _REGISTRATI.add(nome_tipo)
        COMPOSIZIONI[nome_tipo] = composizione
        PROPRIETA_ESPOSTE[nome_tipo] = esposte
        registrati.append(nome_tipo)
    return registrati


def rimuovi_controlli_personalizzati(nomi: Iterable[str]) -> None:
    """Toglie dal catalogo i controlli personalizzati indicati (mai quelli di serie)."""
    if isinstance(nomi, str):
        nomi = [nomi]
    for nome in list(nomi):
        if nome not in _REGISTRATI:
            continue
        _REGISTRATI.discard(nome)
        CATALOGO.pop(nome, None)
        COMPOSIZIONI.pop(nome, None)
        PROPRIETA_ESPOSTE.pop(nome, None)


# ===========================================================================
# Creazione da Leo Studio
# ===========================================================================

def _con_discendenti(maschera: ModelloMaschera, nomi: list[str]) -> list[str]:
    scelti = set(nomi)
    cambiato = True
    while cambiato:
        cambiato = False
        for c in maschera.controlli:
            if c.contenitore in scelti and c.nome not in scelti:
                scelti.add(c.nome)
                cambiato = True
    return [c.nome for c in maschera.controlli if c.nome in scelti]  # ordine della maschera


def salva_controllo_personalizzato(maschera: ModelloMaschera, nomi: Iterable[str], nome_tipo: str,
                                   cartella: str | os.PathLike, *, descrizione: str = "",
                                   proprieta_esposte: dict[str, str] | None = None) -> Path:
    """Crea ``<cartella>/<nome_tipo>.controllo`` dai controlli ``nomi`` della maschera.

    I controlli contenuti in quelli scelti vengono presi anche loro. I controlli
    scelti devono stare nello stesso contenitore; le loro coordinate diventano
    relative al rettangolo che li racchiude tutti, che da' la dimensione del
    nuovo controllo. ``proprieta_esposte``: ``{"titolo": "Etichetta1.testo"}``.
    Restituisce il percorso del file scritto (sovrascrive un file uguale).
    """
    nome_tipo = _controlla_nome_tipo(nome_tipo)
    nomi = [nomi] if isinstance(nomi, str) else list(nomi)
    if not nomi:
        raise ErroreValore("Scegli almeno un controllo da mettere nel nuovo controllo.")
    for n in nomi:
        c = maschera.trova(n)
        if c is None:
            raise ErroreValore(f"Nella finestra non c'è il controllo `{n}`.")
        if c is maschera.finestra:
            raise ErroreValore("La finestra non può far parte di un controllo personalizzato.")
    tutti = _con_discendenti(maschera, nomi)
    scelti = set(tutti)
    principali = [maschera.trova(n) for n in tutti if maschera.trova(n).contenitore not in scelti]
    contenitori = {c.contenitore for c in principali}
    if len(contenitori) > 1:
        raise ErroreValore("I controlli scelti devono stare tutti nello stesso contenitore.",
                           suggerimento="Scegli controlli che stanno tutti nella finestra o tutti nello stesso riquadro.")
    rettangoli = [c.rettangolo for c in principali]
    sinistra = min(r[0] for r in rettangoli)
    alto = min(r[1] for r in rettangoli)
    destra = max(r[0] + r[2] for r in rettangoli)
    basso = max(r[1] + r[3] for r in rettangoli)
    larghezza, altezza = max(1, destra - sinistra), max(1, basso - alto)

    radice = ModelloControllo("Finestra", nome_tipo, {"testo": nome_tipo, "larghezza": larghezza, "altezza": altezza})
    composizione = ModelloMaschera(radice, [])
    for n in tutti:
        c = maschera.trova(n).copia()
        if c.contenitore not in scelti:
            c.contenitore = ""
            c.scheda = None
            x, y, w, h = c.rettangolo
            c.imposta_rettangolo(x - sinistra, y - alto, w, h)
        composizione.aggiungi(c)
    esposte = _analizza_esposte(proprieta_esposte or {}, composizione, f"`{nome_tipo}`")
    if not isinstance(descrizione, str):
        raise ErroreValore("La descrizione deve essere un testo.")

    dati = leggi_toml(scrivi_maschera(composizione))
    intestazione: dict[str, Any] = {"scheda": SCHEDA_PREDEFINITA}
    if descrizione:
        intestazione["descrizione"] = descrizione
    if esposte:
        intestazione["proprieta_esposte"] = {k: f"{f}.{p}" for k, (f, p) in esposte.items()}
    ordinato: dict[str, Any] = {"maschera": dati.pop("maschera"), "controllo": intestazione}
    ordinato.update(dati)
    testo = ("# Controllo personalizzato creato con Leo Studio: si usa come un controllo qualunque.\n"
             + scrivi_toml(ordinato))

    cartella = Path(cartella)
    percorso = cartella / f"{nome_tipo}{ESTENSIONE}"
    import tempfile

    try:
        cartella.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(prefix=".tmp_", suffix=ESTENSIONE, dir=cartella)
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(testo)
        os.replace(tmp, percorso)
    except OSError as e:
        raise ErroreFile(f"Non riesco a salvare `{percorso}`: {e.strerror or e}.") from e
    return percorso


# ===========================================================================
# Aiuti per il runtime e per Studio
# ===========================================================================

def modelli_figli(nome_tipo: str, istanza: ModelloControllo) -> list[ModelloControllo]:
    """Copie dei controlli che compongono ``istanza`` (un controllo di tipo ``nome_tipo``).

    I nomi diventano ``<istanza>_<figlio>`` (es. ``ModuloIndirizzo1_Etichetta1``)
    e i figli diretti hanno come contenitore l'istanza; i valori delle
    proprieta' esposte presenti nell'istanza sono gia' applicati ai figli.
    """
    composizione = COMPOSIZIONI.get(nome_tipo)
    if composizione is None:
        raise ErroreValore(f"Il controllo personalizzato `{nome_tipo}` non è caricato.")
    prefisso = f"{istanza.nome}_"
    figli: list[ModelloControllo] = []
    mappa: dict[str, ModelloControllo] = {}
    for c in composizione.controlli:
        nuovo = c.copia()
        nuovo.nome = prefisso + c.nome
        nuovo.contenitore = istanza.nome if not c.contenitore else prefisso + c.contenitore
        figli.append(nuovo)
        mappa[c.nome] = nuovo
    for esposta, (figlio, prop) in PROPRIETA_ESPOSTE.get(nome_tipo, {}).items():
        if esposta in istanza.proprieta and figlio in mappa:
            mappa[figlio].proprieta[prop] = copy.deepcopy(istanza.proprieta[esposta])
    return figli


def collega_proprieta_esposte(composito: Any, figli: dict[str, Any]) -> None:
    """Inoltra le proprieta' esposte di un controllo vivo ai suoi figli vivi.

    ``composito``: ControlloVivo del tipo personalizzato; ``figli``: nome del
    figlio NELLA COMPOSIZIONE (es. ``"Etichetta1"``) -> oggetto con ``scrivi``.
    Copia subito i valori attuali e aggiunge un osservatore che inoltra
    ogni cambiamento successivo.
    """
    esposte = PROPRIETA_ESPOSTE.get(getattr(composito, "tipo_controllo", ""), {})
    if not esposte:
        return

    def _inoltra(proprieta: str, valore: Any) -> None:
        destinazione = esposte.get(proprieta)
        if destinazione is None:
            return
        figlio = figli.get(destinazione[0])
        if figlio is not None:
            figlio.scrivi(destinazione[1], valore)

    for esposta in esposte:
        _inoltra(esposta, composito.leggi(esposta))
    composito.osservatori.append(lambda _c, proprieta, valore: _inoltra(proprieta, valore))
