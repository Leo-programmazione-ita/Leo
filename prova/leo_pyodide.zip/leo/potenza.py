"""Costrutti "potenti" di Leo: il motore a tempo di esecuzione.

* **Temporizzatori** (``ogni 2 secondi fai ... fine``, ``dopo 3 secondi fai ...
  fine``, ``ferma_temporizzatori()``): nei programmi testuali un piccolo ciclo
  degli eventi tiene vivo il programma finche' ci sono temporizzatori attivi
  (Ctrl+C lo chiude in modo pulito); nei programmi a finestre il ponte grafico
  usa il ciclo di Qt (``PonteQt.pianifica_temporizzatore``).
* **Lavori in parallelo** (``in parallelo fai ... fine`` e ``aspetta(lavoro)``):
  il corpo gira in un altro filo con un *interprete figlio* che condivide le
  variabili del programma ma ha contatori, file corrente e percorso di
  esecuzione suoi (l'interprete ad albero, che non condivide cache con il
  programma). Dal lavoro non si toccano i controlli grafici ne' le finestrelle:
  errore chiaro. Il risultato (``restituisci``) e gli errori si raccolgono con
  ``aspetta``; un errore mai raccolto ferma il programma alla fine.
* **Verifiche incorporate** (``verifica "nome" fai ... fine`` con ``aspettati``):
  :func:`esegui_verifiche` prepara il programma (funzioni, variabili, costanti,
  ``importa``, ``quando``: il resto non parte) ed esegue ogni verifica in un
  ambiente suo, raccogliendo valore atteso e ottenuto. ``leo verifica`` stampa
  il rapporto (:func:`rapporto`).
* **Formati nell'interpolazione** (``{prezzo:2}``, ``{n:migliaia}``):
  :func:`normalizza_formato` (usata dal parser) e :func:`formatta_numero`.

Perche' ``in parallelo`` e non solo una funzione ``esegui_in_background``: la
sintassi e' la stessa degli altri blocchi (una funzione non avrebbe reso il
lavoro piu' sicuro: il rischio vero e' eseguire codice Leo in due fili con lo
stesso interprete, ed e' quello che l'interprete figlio evita).
"""

from __future__ import annotations

import heapq
import itertools
import re
import sys
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable

from . import registro
from .errori import (ErroreDante, ErroreNome, ErroreRicorsione, ErroreTipo, ErroreValore,
                     SegnaleFermaProgramma)
from .valori import FunzioneNativa, MetodoLegato, OggettoControllo, nome_tipo, rappresenta, tipo_con_articolo

__all__ = [
    "normalizza_formato", "formatta_numero", "Temporizzatori", "Lavoro", "avvia_lavoro",
    "EsitoVerifica", "RapportoVerifiche", "esegui_verifiche", "rapporto",
]


# ===========================================================================
# Formati nell'interpolazione: {prezzo:2}, {n:migliaia}
# ===========================================================================

#: Massimo numero di decimali in un formato.
DECIMALI_MASSIMI = 20

_SEPARATORI_FORMATO = re.compile(r"[\s,]+")


def normalizza_formato(testo: str | None) -> str | None:
    """Forma canonica di un formato (``"2"``, ``"migliaia"``, ``"migliaia 2"``) o
    None se il formato non e' valido. Parti ammesse, in qualunque ordine e
    separate da spazi o virgole: un numero di decimali (0-20) e ``migliaia``."""
    if testo is None:
        return None
    parti = [p for p in _SEPARATORI_FORMATO.split(str(testo).strip().lower()) if p]
    if not parti:
        return None
    decimali: int | None = None
    migliaia = False
    for p in parti:
        if p.isdigit() and decimali is None and int(p) <= DECIMALI_MASSIMI:
            decimali = int(p)
        elif p == "migliaia" and not migliaia:
            migliaia = True
        else:
            return None
    if migliaia:
        return "migliaia" if decimali is None else f"migliaia {decimali}"
    return str(decimali)


def _raggruppa(cifre: str) -> str:
    """``"1234567"`` -> ``"1.234.567"`` (separatore delle migliaia all'italiana)."""
    gruppi = []
    while len(cifre) > 3:
        gruppi.append(cifre[-3:])
        cifre = cifre[:-3]
    gruppi.append(cifre)
    return ".".join(reversed(gruppi))


def _cifre_formato(valore: int | float, decimali: int | None) -> str:
    """Cifre di ``valore`` (finito) col punto decimale, senza notazione
    scientifica: gli interi con l'aritmetica intera esatta (anche enormi), i
    decimali arrotondati come ``arrotonda`` (meta' lontano da zero, partendo dal
    decimale piu' corto che li rappresenta: ``2.675`` -> ``2.68``). Mai ``-0``."""
    if isinstance(valore, int):
        testo = rappresenta(valore)
        if decimali and "e" not in testo:
            testo += "." + "0" * decimali
        return testo
    if decimali is None:
        testo = rappresenta(valore)
        if "e" not in testo.lower():
            return testo
    # `decimal` solo qui (numeri scientifici/arrotondati): non si carica all'avvio
    from decimal import ROUND_HALF_UP, Decimal, localcontext

    numero = Decimal(repr(valore))
    with localcontext() as ctx:
        ctx.prec = max(28, numero.adjusted() + (decimali or 0) + 10)
        if decimali is not None:
            numero = numero.quantize(Decimal(1).scaleb(-decimali), rounding=ROUND_HALF_UP)
        if numero.is_zero():
            numero = abs(numero)
        testo = format(numero, "f")
    if decimali is None and "." in testo:
        testo = testo.rstrip("0").rstrip(".")
    return testo


def formatta_numero(valore: Any, formato: str) -> str:
    """Scrive ``valore`` con il ``formato`` (gia' normalizzato).

    * ``"2"``: due decimali col punto, come i numeri di Leo (``3.50``);
    * ``"migliaia"``: separatore delle migliaia all'italiana (``1.234.567``,
      ``1.234,5``);
    * ``"migliaia 2"``: entrambi (``1.234,50``), utile per gli importi.
    """
    spec = normalizza_formato(formato)
    if spec is None:  # pragma: no cover - il parser controlla prima
        raise ErroreValore(f"Non conosco il formato `{formato}`.")
    if isinstance(valore, bool) or not isinstance(valore, (int, float)):
        raise ErroreTipo(
            f"Il formato `:{formato}` vale solo per i numeri, ma qui c'è un valore di tipo `{nome_tipo(valore)}`.",
            suggerimento="Togli il formato (`{nome}`) oppure trasforma prima il valore in numero "
                         "con `decimale(...)`.")
    if isinstance(valore, float) and (valore != valore or valore in (float("inf"), float("-inf"))):
        return rappresenta(valore)
    parti = spec.split()
    migliaia = parti[0] == "migliaia"
    decimali = int(parti[-1]) if parti[-1].isdigit() else None
    testo = _cifre_formato(valore, decimali)
    if not migliaia or "e" in testo:
        return testo
    segno = ""
    if testo.startswith("-"):
        segno, testo = "-", testo[1:]
    intera, _, frazione = testo.partition(".")
    return segno + _raggruppa(intera) + ("," + frazione if frazione else "")


# ===========================================================================
# Temporizzatori
# ===========================================================================

#: Pausa massima del ciclo degli eventi testuale (si controlla spesso Ctrl+C).
PASSO_ATTESA = 0.05


class Temporizzatori:
    """I temporizzatori di un interprete (``ogni``/``dopo``).

    Nei programmi testuali sono una coda ordinata per scadenza, servita da
    :meth:`ciclo` alla fine del programma; nei programmi a finestre il ponte
    grafico li affida al ciclo di Qt (metodo ``pianifica_temporizzatore(secondi,
    funzione, ripeti)`` che restituisce un oggetto con ``stop()``)."""

    def __init__(self, interprete: Any) -> None:
        self.it = interprete
        self._coda: list[list] = []          # [scadenza, numero, funzione, intervallo | None, attivo]
        self._numero = itertools.count()
        self._grafici: list[Any] = []
        self._generazione = 0
        #: Vero se il ciclo e' finito per un arresto (Ctrl+C) con temporizzatori ancora attivi.
        self.interrotto = False
        #: Vero mentre il ciclo degli eventi testuale gira.
        self.in_ciclo = False

    # --- API ---
    def pianifica(self, secondi: float, funzione: Any, ripeti: bool) -> None:
        ponte = getattr(self.it, "ponte_grafico", None)
        pianifica = getattr(ponte, "pianifica_temporizzatore", None)
        if callable(pianifica):
            maniglia = pianifica(float(secondi), funzione, bool(ripeti))
            if maniglia is not None:
                self._grafici.append(maniglia)
            return
        voce = [time.monotonic() + secondi, next(self._numero), funzione, secondi if ripeti else None, True]
        heapq.heappush(self._coda, voce)

    @property
    def attivi(self) -> int:
        """Quanti temporizzatori aspettano di scattare (solo quelli testuali)."""
        return sum(1 for v in self._coda if v[4])

    def in_attesa(self) -> bool:
        return any(v[4] for v in self._coda)

    def ferma_tutti(self) -> int:
        """Ferma tutti i temporizzatori; restituisce quanti erano attivi."""
        quanti = self.attivi
        for voce in self._coda:
            voce[4] = False
        self._coda.clear()
        self._generazione += 1
        for maniglia in self._grafici:
            try:
                attivo = maniglia.isActive() if callable(getattr(maniglia, "isActive", None)) else True
                maniglia.stop()
            except Exception:  # noqa: BLE001 - un temporizzatore gia' distrutto non importa
                continue
            quanti += 1 if attivo else 0
        self._grafici.clear()
        return quanti

    # --- ciclo degli eventi testuale ---
    def ciclo(self, lavori: Callable[[], bool] = lambda: False) -> None:
        """Serve i temporizzatori finche' ce ne sono (o finche' ``lavori()`` dice
        che c'e' ancora un lavoro in parallelo da aspettare). Un arresto
        (``interprete.ferma()``, Ctrl+C) svuota la coda e solleva
        ``SegnaleFermaProgramma``."""
        self.in_ciclo = True
        try:
            self._ciclo(lavori)
        except KeyboardInterrupt:
            # programma eseguito nel filo principale: Ctrl+C arriva qui
            self.interrotto = True
            self.ferma_tutti()
            raise
        finally:
            self.in_ciclo = False

    def _ciclo(self, lavori: Callable[[], bool]) -> None:
        it = self.it
        while True:
            while self._coda and not self._coda[0][4]:
                heapq.heappop(self._coda)
            if not self._coda and not lavori():
                return
            if it.fermato:
                self.interrotto = True
                self.ferma_tutti()
                raise SegnaleFermaProgramma()
            adesso = time.monotonic()
            if not self._coda or self._coda[0][0] > adesso:
                attesa = PASSO_ATTESA if not self._coda else min(PASSO_ATTESA, self._coda[0][0] - adesso)
                time.sleep(max(0.0, attesa))
                continue
            voce = heapq.heappop(self._coda)
            generazione = self._generazione
            intervallo = voce[3]
            if intervallo is not None:
                # si ripianifica prima di chiamare: `ferma_temporizzatori()` nel corpo lo ferma
                voce[0] = max(voce[0] + intervallo, time.monotonic())
                voce[1] = next(self._numero)
                heapq.heappush(self._coda, voce)
            else:
                voce[4] = False
            try:
                it.chiama(voce[2], [])
            except BaseException:
                if it.fermato:
                    self.interrotto = True
                if generazione == self._generazione:
                    self.ferma_tutti()
                raise


# ===========================================================================
# Lavori in parallelo (il motore e' in leo/parallelo.py e leo/parallelo_processi.py)
# ===========================================================================

# Il motore `parallelo` (e con lui `queue`) si importa al primo uso vero di un
# lavoro `in parallelo`, non all'avvio: i nomi ri-esportati (`Lavoro`,
# `avvia_lavoro`...) arrivano da `__getattr__` del modulo (in fondo al file),
# cosi' `potenza.avvia_lavoro` e simili continuano a funzionare come prima.
_NOMI_PARALLELO = frozenset((
    "DIMENSIONE_PILA_LAVORO", "Lavoro", "_PonteParallelo", "avvia_lavoro",
    "errore_non_raccolto", "ferma_lavori", "lavori_in_corso"))


@registro.funzione("aspetta", interprete=True)
def _aspetta(interprete, lavoro, secondi=None, annulla=False):
    """aspetta(lavoro, secondi = nulla, annulla = falso): aspetta la fine di un lavoro `in parallelo` e ne restituisce il risultato.

    Il risultato e' il valore di `restituisci` nel lavoro; se il lavoro e' finito con un
    errore, `aspetta` lo ripete qui. Con `secondi` aspetta al massimo quel tempo (poi c'e'
    un errore; con `annulla = vero` il lavoro viene anche fermato). Accetta anche una lista
    di lavori (e da' la lista dei risultati).
    """
    from . import parallelo as _parallelo
    from .parallelo import Lavoro

    if isinstance(lavoro, (int, float)) and not isinstance(lavoro, bool):
        raise ErroreTipo("`aspetta` serve ad attendere la fine di un lavoro avviato con `avvia_lavoro` "
                         "(o `in parallelo`), non dei secondi.",
                         suggerimento=f"Per fermarti {rappresenta(lavoro)} secondi usa `attendi({rappresenta(lavoro)})`.")
    if not isinstance(lavoro, (Lavoro, list)):
        raise ErroreTipo(f"`aspetta` vuole un lavoro avviato con `avvia_lavoro` (o `in parallelo`), "
                         f"non un valore di tipo `{nome_tipo(lavoro)}`.",
                         suggerimento="Per esempio `variabile l = in parallelo fai ... fine` e poi `aspetta(l)`; "
                                      "per una pausa di qualche secondo usa invece `attendi(2)`.")
    if secondi is not None and (isinstance(secondi, bool) or not isinstance(secondi, (int, float))):
        raise ErroreTipo(f"Il tempo massimo di `aspetta` è un numero di secondi, non un valore di tipo "
                         f"`{nome_tipo(secondi)}`.")
    return _parallelo.aspetta(interprete, lavoro, secondi, bool(annulla))


@registro.funzione("ferma_temporizzatori", interprete=True)
def _ferma_temporizzatori(interprete):
    """ferma_temporizzatori(): ferma tutti i temporizzatori `ogni`/`dopo`; restituisce quanti erano attivi.

    Un programma testuale resta vivo finche' ci sono temporizzatori: fermarli lo lascia finire.
    """
    temporizzatori = interprete.__dict__.get("_temporizzatori")
    return temporizzatori.ferma_tutti() if temporizzatori is not None else 0


# ===========================================================================
# Verifiche incorporate: leo verifica
# ===========================================================================

@dataclass
class EsitoVerifica:
    """Esito di un blocco ``verifica "nome" fai ... fine``."""

    nome: str
    riga: int
    riuscita: bool
    messaggio: str = ""
    riga_errore: int = 0
    codice: str = ""                 # la riga del sorgente che non va
    atteso: str | None = None
    ottenuto: str | None = None
    uscita: str = ""                 # quello che la verifica ha stampato
    file_errore: str = ""            # file dell'errore, se non e' quello delle verifiche (modulo importato)
    chiamate: list[str] = field(default_factory=list)  # righe della pila delle chiamate (se l'errore e' in una funzione)


@dataclass
class RapportoVerifiche:
    """Le verifiche di un file."""

    nome_file: str
    esiti: list[EsitoVerifica] = field(default_factory=list)
    errore: ErroreDante | None = None     # errore di sintassi o nella preparazione
    sorgente: str = ""

    @property
    def riuscite(self) -> int:
        return sum(1 for e in self.esiti if e.riuscita)

    @property
    def fallite(self) -> int:
        return sum(1 for e in self.esiti if not e.riuscita)


def _preparazione(istruzione: Any) -> bool:
    from . import nodi as N

    if isinstance(istruzione, (N.Dichiarazione, N.DefinizioneFunzione, N.Evento, N.Importa)):
        return True
    if isinstance(istruzione, N.Assegnazione):
        return isinstance(istruzione.bersaglio, N.Nome)
    if isinstance(istruzione, N.AssegnazioneMultipla):
        return all(isinstance(b, N.Nome) for b in istruzione.bersagli)
    return False


def _niente_ingresso(domanda: str) -> str:
    raise ErroreValore("Durante `leo verifica` il programma non può leggere dalla tastiera (`chiedi`).",
                       suggerimento="Nelle verifiche passa i dati direttamente alle funzioni: "
                                    "`aspettati calcola(3) == 9`.")


def esegui_verifiche(sorgente: str, nome_file: str = "<sorgente>", *, cartella: str | None = None,
                     **opzioni: Any) -> RapportoVerifiche:
    """Analizza il programma, lo prepara ed esegue le sue verifiche.

    Si eseguono solo le istruzioni di preparazione (funzioni, variabili,
    costanti, ``importa``, ``quando``): stampe, domande, cicli e temporizzatori
    del programma non partono. Ogni verifica ha un ambiente suo (le variabili
    create in una verifica non si vedono nelle altre)."""
    from . import nodi as N
    from .esecuzione import analizza
    from .interprete import Interprete
    from .stile import Stile

    rapporto_file = RapportoVerifiche(nome_file, sorgente=sorgente)
    righe = sorgente.lstrip("﻿").replace("\r\n", "\n").replace("\r", "\n").split("\n")
    try:
        programma = analizza(sorgente, nome_file, **opzioni)
    except ErroreDante as e:
        rapporto_file.errore = e
        return rapporto_file
    stile = Stile.da_sorgente(sorgente, opzioni.get("stile"))
    uscita: list[str] = []
    interprete = Interprete(nome_file=nome_file, sorgente=sorgente, uscita=uscita.append,
                            ingresso=_niente_ingresso, dichiarazione_implicita=stile.dichiarazione_implicita)
    if cartella:
        interprete.percorsi_moduli.append(str(cartella))
    preparazione = [i for i in programma.istruzioni if _preparazione(i)]
    verifiche = [i for i in programma.istruzioni if isinstance(i, N.BloccoVerifica)]
    try:
        interprete.esegui(N.Programma(preparazione, nome_file=nome_file))
    except ErroreDante as e:
        rapporto_file.errore = e
        return rapporto_file
    for blocco in verifiche:
        uscita.clear()
        try:
            nome = rappresenta(interprete.valuta(blocco.nome, interprete.globale))
        except ErroreDante:
            nome = f"verifica della riga {blocco.riga}"
        esito = EsitoVerifica(nome, blocco.riga, True)
        try:
            interprete.esegui_blocco(blocco.corpo, interprete.globale.figlio("verifica"))
        except ErroreDante as e:
            esito.riuscita = False
            esito.riga_errore = e.riga or blocco.riga
            _pila_verifica(interprete, e, nome, nome_file, esito)
            if getattr(e, "aspettativa", False):
                esito.messaggio = e.messaggio
                esito.atteso = getattr(e, "atteso", None)
                esito.ottenuto = getattr(e, "ottenuto", None)
            else:
                esito.messaggio = f"Errore inatteso: {e.tipo}: {e.messaggio}"
        except SegnaleFermaProgramma:
            esito.riuscita = False
            esito.riga_errore = blocco.riga
            esito.messaggio = "Il programma è stato fermato durante la verifica."
        except RecursionError:
            esito.riuscita = False
            esito.riga_errore = blocco.riga
            esito.messaggio = "Troppe chiamate annidate."
        finally:
            temporizzatori = interprete.__dict__.get("_temporizzatori")
            if temporizzatori is not None:
                temporizzatori.ferma_tutti()
        if not esito.riuscita:
            righe_errore = righe
            if esito.file_errore:  # errore dentro un file importato: la riga e' di quel file
                testo = interprete.sorgenti_moduli.get(esito.file_errore)
                righe_errore = testo.replace("\r\n", "\n").replace("\r", "\n").split("\n") if testo else []
            if 0 < esito.riga_errore <= len(righe_errore):
                esito.codice = righe_errore[esito.riga_errore - 1].strip()
            esito.uscita = "".join(uscita)
        rapporto_file.esiti.append(esito)
    return rapporto_file


def _pila_verifica(interprete: Any, errore: ErroreDante, nome: str, nome_file: str, esito: EsitoVerifica) -> None:
    """Completa l'esito di una verifica fallita con il file dell'errore e la pila delle chiamate."""
    from .pila import chiudi, righe_pila

    chiudi(errore, "verifica", f"\"{nome}\"", nome_file)
    if errore.riga and errore.nome_file and errore.nome_file not in ("<sorgente>", nome_file):
        esito.file_errore = errore.nome_file
    righe = righe_pila(errore)
    if righe:
        esito.chiamate = [r.strip() for r in righe[1:]]


def _colora(testo: str, codice: str, colori: bool) -> str:
    return f"\033[{codice}m{testo}\033[0m" if colori else testo


def rapporto(rapporti: list[RapportoVerifiche], *, colori: bool = False,
             formatta_errore: Callable[[ErroreDante, str], str] | None = None) -> str:
    """Testo del rapporto di ``leo verifica`` (verde le riuscite, rosso le altre)."""
    righe: list[str] = []
    riuscite = fallite = errori = 0
    for r in rapporti:
        righe.append(_colora(r.nome_file, "1", colori))
        if r.errore is not None:
            errori += 1
            testo = formatta_errore(r.errore, r.sorgente) if formatta_errore else r.errore.breve()
            righe.append(_colora("  NO  il programma non si prepara:", "31", colori))
            righe.extend("    " + x for x in testo.rstrip().split("\n"))
            righe.append("")
            continue
        if not r.esiti:
            righe.append("  (nessuna verifica: aggiungi `verifica \"nome\" fai ... fine`)")
            righe.append("")
            continue
        for e in r.esiti:
            if e.riuscita:
                riuscite += 1
                righe.append(_colora(f"  ok  {e.nome}", "32", colori))
                continue
            fallite += 1
            dove = f"riga {e.riga_errore or e.riga}" + (f" di {e.file_errore}" if e.file_errore else "")
            righe.append(_colora(f"  NO  {e.nome}", "31", colori) + f"  ({dove})")
            if e.codice:
                righe.append(f"      {e.codice}")
            righe.append(f"      {e.messaggio}")
            if e.chiamate:
                righe.append("      Chiamate (dalla più recente):")
                righe.extend("        " + x for x in e.chiamate)
            if e.atteso is not None or e.ottenuto is not None:
                righe.append("      atteso:   " + _colora(str(e.atteso), "32", colori))
                righe.append("      ottenuto: " + _colora(str(e.ottenuto), "31", colori))
            if e.uscita.strip():
                righe.append("      ha stampato:")
                righe.extend("        " + x for x in e.uscita.rstrip("\n").split("\n")[-10:])
        righe.append("")
    totale = riuscite + fallite
    parola = "verifica" if totale == 1 else "verifiche"
    riepilogo = f"{totale} {parola}: {riuscite} riuscit{'a' if riuscite == 1 else 'e'}"
    if fallite:
        riepilogo += f", {fallite} non riuscit{'a' if fallite == 1 else 'e'}"
    if errori:
        riepilogo += f"; {errori} file con errori"
    riepilogo += "."
    tutto_bene = not fallite and not errori
    righe.append(_colora(riepilogo, "32" if tutto_bene else "31", colori))
    return "\n".join(righe)



def __getattr__(nome: str):
    """I nomi ri-esportati da ``leo.parallelo`` si risolvono alla prima lettura
    (``potenza.avvia_lavoro``, ``potenza.Lavoro``...), importando il motore solo
    allora: all'avvio ``parallelo`` (e ``queue``) non si caricano."""
    if nome in _NOMI_PARALLELO:
        from . import parallelo

        return getattr(parallelo, nome)
    raise AttributeError(f"module {__name__!r} has no attribute {nome!r}")
