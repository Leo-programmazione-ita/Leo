"""Categorie di colorazione della sintassi - CONTRATTO CONDIVISO.

Le categorie sono le chiavi dei temi (``dati/temi/*.toml``, sezione
``[categorie.<nome>]``). La parte STATICA (parola chiave -> categoria) e' qui;
la colorazione di un intero sorgente (contesto: funzioni utente, controlli,
proprieta', interpolazione) e' in ``leo.colorazione`` (da implementare).
"""

from __future__ import annotations

from enum import Enum

from .tokens import TipoToken


class Categoria(str, Enum):
    TESTO_NORMALE = "testo_normale"       # nomi sconosciuti e testo normale
    FLUSSO = "flusso"                     # se, allora, mentre, per ogni, fine...
    DICHIARAZIONI = "dichiarazioni"       # crea variabile, costante, funzione, restituisci, quando, inizio
    ERRORI = "errori"                     # prova, cattura, infine, lancia, ErroreValore...
    LOGICI = "logici"                     # e, o, non, è, non è, in
    VALORI_SPECIALI = "valori_speciali"   # vero, falso, nulla
    NUMERI = "numeri"                     # 42, 3.14, ".." di 1..10
    TESTI = "testi"                       # "ciao"
    INTERPOLAZIONE = "interpolazione"     # {nome} dentro un testo (graffe comprese)
    LIBRERIA = "libreria"                 # stampa, lunghezza, chiedi
    FUNZIONI_UTENTE = "funzioni_utente"   # funzioni definite nel programma
    CONTROLLI = "controlli"               # Pulsante1, CasellaNome
    PROPRIETA = "proprieta"               # .testo, .clic
    COMMENTI = "commenti"                 # # nota, #[ ... ]#
    # --- categorie di contesto (giro colori): nei temi senza queste chiavi si
    # usa la ricaduta di ``leo.temi.RICADUTE`` (cosi' i temi vecchi restano uguali)
    VARIABILI = "variabili"               # nomi dichiarati o assegnati: x = 1, per ogni x in
    COSTANTI = "costanti"                 # costante IVA = 22, PI_GRECO
    PARAMETRI = "parametri"               # parametri di una funzione, nel suo corpo (e `evento`)
    CAMPI = "campi"                       # campi di un oggetto: errore.tipo, persona.nome
    EVENTI = "eventi"                     # quando Pulsante1.clic
    OPERATORI = "operatori"               # + - * / = == < ...
    PUNTEGGIATURA = "punteggiatura"       # ( ) [ ] { } , . :


#: Colorazione statica dei token di parola chiave.
CATEGORIA_PAROLE_CHIAVE: dict[TipoToken, Categoria] = {
    **{t: Categoria.FLUSSO for t in (
        TipoToken.SE, TipoToken.ALLORA, TipoToken.ALTRIMENTI, TipoToken.ALTRIMENTI_SE,
        TipoToken.MENTRE, TipoToken.PER_OGNI, TipoToken.RIPETI, TipoToken.VOLTE,
        TipoToken.FAI, TipoToken.FINE, TipoToken.INTERROMPI, TipoToken.CONTINUA,
        # frasi di zucchero: aumenta x di 1, anima P.alto a 10 in 1 secondi con curva "..."
        TipoToken.AUMENTA, TipoToken.DIMINUISCI, TipoToken.ANIMA, TipoToken.PAROLA_DI_FRASE)},
    **{t: Categoria.DICHIARAZIONI for t in (
        TipoToken.VARIABILE, TipoToken.COSTANTE, TipoToken.FUNZIONE,
        TipoToken.RESTITUISCI, TipoToken.QUANDO,
        # `inizio ... fine`: dichiara il programma principale, come `funzione`/`quando`
        TipoToken.INIZIO)},
    **{t: Categoria.ERRORI for t in (
        TipoToken.PROVA, TipoToken.CATTURA, TipoToken.INFINE, TipoToken.LANCIA, TipoToken.COME)},
    **{t: Categoria.LOGICI for t in (
        TipoToken.E, TipoToken.O, TipoToken.NON, TipoToken.E_ACCENTATA,
        TipoToken.NON_E_ACCENTATA, TipoToken.IN)},
    **{t: Categoria.VALORI_SPECIALI for t in (TipoToken.VERO, TipoToken.FALSO, TipoToken.NULLA)},
    TipoToken.INTERO: Categoria.NUMERI,
    TipoToken.DECIMALE: Categoria.NUMERI,
    TipoToken.PUNTO_PUNTO: Categoria.NUMERI,
    TipoToken.TESTO: Categoria.TESTI,
    TipoToken.TESTO_INTERPOLATO: Categoria.TESTI,
    TipoToken.COMMENTO: Categoria.COMMENTI,
    # operatori e punteggiatura (giro colori)
    **{t: Categoria.OPERATORI for t in (
        TipoToken.PIU, TipoToken.MENO, TipoToken.ASTERISCO, TipoToken.BARRA, TipoToken.DOPPIA_BARRA,
        TipoToken.PERCENTUALE, TipoToken.CIRCONFLESSO, TipoToken.TRE_PUNTI, TipoToken.CATENA,
        TipoToken.UGUALE_UGUALE, TipoToken.DIVERSO, TipoToken.MINORE, TipoToken.MINORE_UGUALE,
        TipoToken.MAGGIORE, TipoToken.MAGGIORE_UGUALE, TipoToken.ASSEGNA, TipoToken.PIU_ASSEGNA,
        TipoToken.MENO_ASSEGNA, TipoToken.PER_ASSEGNA, TipoToken.DIVISO_ASSEGNA)},
    **{t: Categoria.PUNTEGGIATURA for t in (
        TipoToken.PARENTESI_APERTA, TipoToken.PARENTESI_CHIUSA, TipoToken.QUADRA_APERTA,
        TipoToken.QUADRA_CHIUSA, TipoToken.GRAFFA_APERTA, TipoToken.GRAFFA_CHIUSA,
        TipoToken.VIRGOLA, TipoToken.PUNTO, TipoToken.DUE_PUNTI)},
}


def categoria_statica(tipo: TipoToken) -> Categoria:
    """Categoria di un tipo di token senza contesto (NOME -> TESTO_NORMALE)."""
    return CATEGORIA_PAROLE_CHIAVE.get(tipo, Categoria.TESTO_NORMALE)
