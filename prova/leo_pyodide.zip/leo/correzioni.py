"""Autocorrezione con conferma (docs/CONTRATTI.md, sezione 9; PROGETTO.md, "Autocorrezione con conferma").

API del contratto::

    proponi_correzioni(sorgente, nome_file="<sorgente>", **opzioni_lessico) -> list[Correzione]
    applica_correzioni(sorgente, correzioni) -> str
    differenze(prima, dopo, nome_file) -> str
    descrivi(correzioni, sorgente, nome_file) -> str
    chiedi_conferma(correzioni, sorgente, nome_file, *, ingresso=input, uscita=print) -> list[Correzione]
    correggi_file(percorso, *, ingresso=input, uscita=print) -> bool

Funzioni pubbliche in piu'::

    uniforma_stile(sorgente, stile, nome_file="<sorgente>") -> list[Correzione]
    assegnazioni_senza_dichiarazione(programma, nomi_noti=()) -> list[Assegnazione]

Come funziona :func:`proponi_correzioni`
----------------------------------------
1. Analizza il sorgente con ``recupero=True``: a ogni ``ErroreSintassi``
   prende la prima ``Correzione`` proposta da lexer/parser, la applica su una
   copia e rianalizza (al massimo 20 giri).
2. Se alla fine il sorgente si analizza senza errori aggiunge, con un'analisi
   statica dell'AST, ``variabile`` alla prima assegnazione di un nome mai
   dichiarato ne' predefinito (se lo stile non e' implicito) e riallinea le
   righe dello stesso blocco scritte con rientri diversi.
3. Tutte le correzioni vengono riportate alle posizioni del sorgente
   ORIGINALE (le correzioni che si toccano vengono fuse in una sola), cosi'
   :func:`applica_correzioni` le puo' applicare in un colpo solo, dal fondo
   verso l'inizio.
4. La lista si restituisce solo se il sorgente corretto si analizza senza
   errori; altrimenti ``[]``. Le alternative (correzioni ugualmente
   plausibili) restano solo se anche con loro il file diventa analizzabile.

Mai correzioni di logica: nomi, valori e operazioni restano dell'utente.
Per questo ``contatre = 5`` dopo ``variabile contatore = 0`` NON diventa
``variabile contatre = 5`` (creerebbe di nascosto una variabile per un errore
di battitura): si propone ``contatore = 5``, segnato "da confermare", che
:func:`chiedi_conferma` chiede sempre da solo. ``[n per n in l]`` (o ``for``)
diventa ``[n per ogni n in l]``, non ``[n, per, n in l]``.

Suggerimenti non bloccanti (``Correzione.facoltativa = True``): forme che
Leo capisce comunque ma che conviene scrivere in forma canonica. Il
programma funziona anche senza applicarli; :func:`descrivi` li conta a parte
e ne mostra il motivo nella riga ``nota:``.

* ``se x fai`` -> ``se x allora`` (e ``quando``/``mentre``/``per ogni`` con
  ``allora`` -> ``fai``, ``caso 1 fai`` -> ``caso 1 allora``);
* ``finestra1`` -> ``Finestra1``: un nome mai dichiarato che differisce solo
  per maiuscole da UN nome noto (programma, libreria, ``nomi_noti``, controlli
  della maschera accanto al file ``Finestra1.leo`` -> ``Finestra1.maschera``);
* ``rosso`` -> ``"rosso"``: un colore scritto senza virgolette.

Costrutti recenti riconosciuti: ``per ogni k, v``, liste compresse (le loro
variabili valgono solo dentro), ``variabile a, b = ...`` e ``a, b = ...``,
rami di ``scegli``, ``importa`` (alias, moduli di libreria, nomi dei file
``.leo`` importati; se un modulo non si trova, niente proposte sui nomi).
"""

from __future__ import annotations

import difflib
import os
import re
import shutil
import sys
from dataclasses import dataclass, field, fields, is_dataclass
from pathlib import Path
from typing import Any, Callable, Iterable

from . import e_sorgente, nodi, nome_modulo_implicito, nomi_file_modulo
from .errori import Correzione, ErroreDante, ErroreSintassi
from .stile import Stile

__all__ = [
    "proponi_correzioni",
    "applica_correzioni",
    "differenze",
    "descrivi",
    "chiedi_conferma",
    "correggi_file",
    "uniforma_stile",
    "assegnazioni_senza_dichiarazione",
    "assegnazioni_multiple_senza_dichiarazione",
    "nomi_dichiarati",
    "nomi_importati",
    "nomi_tollerati",
    "nomi_da_maschera",
    "controlli_da_maschera",
    "nomi_dei_controlli_sbagliati",
    "suggerimenti_di_forma",
    "tolleranze_da_formattare",
    "Tolleranza",
    "DOMANDA",
]

#: Numero massimo di correzioni di sintassi applicate una dopo l'altra.
GIRI_MASSIMI = 20

#: Domanda di conferma (testo esatto di PROGETTO.md, "Come si conferma").
DOMANDA = "Applico le correzioni? [s]ì  [n]o  [u]na alla volta  [v]edi le differenze"

_MOTIVO_RIENTRO = "rientro diverso dalle altre righe dello stesso blocco"

_SI = {"s", "si", "sì", "sí", "y", "yes"}
_NO = {"n", "no"}


# ---------------------------------------------------------------------------
# Posizioni
# ---------------------------------------------------------------------------

def _inizi_righe(testo: str) -> list[int]:
    """Posizione assoluta dell'inizio di ogni riga (``\\n``, ``\\r\\n`` e ``\\r``)."""
    inizi = [0]
    i = 0
    n = len(testo)
    while i < n:
        c = testo[i]
        if c == "\n":
            inizi.append(i + 1)
        elif c == "\r":
            if i + 1 < n and testo[i + 1] == "\n":
                i += 1
            inizi.append(i + 1)
        i += 1
    return inizi


def _righe(testo: str) -> list[str]:
    """Righe del testo senza caratteri di a capo."""
    return testo.replace("\r\n", "\n").replace("\r", "\n").split("\n")


def _fine_riga(testo: str, inizi: list[int], riga: int) -> int:
    """Posizione assoluta della fine (esclusa) del contenuto della riga."""
    if riga < len(inizi):
        fine = inizi[riga] - 1
        if fine > 0 and testo[fine] == "\n" and testo[fine - 1] == "\r":
            fine -= 1
        return fine
    return len(testo)


def _posizione(testo: str, riga: int, colonna: int, inizi: list[int] | None = None) -> int:
    """Da (riga, colonna) 1-based a posizione assoluta; ValueError se fuori dal testo."""
    if inizi is None:
        inizi = _inizi_righe(testo)
    if riga == len(inizi) + 1 and colonna == 1:
        return len(testo)                         # riga "numero_righe + 1": in fondo al file
    if not 1 <= riga <= len(inizi):
        raise ValueError(f"La correzione indica la riga {riga}, ma il testo ne ha {len(inizi)}.")
    fine = _fine_riga(testo, inizi, riga)
    posizione = inizi[riga - 1] + colonna - 1
    if colonna < 1 or posizione > fine:
        raise ValueError(f"La correzione indica la colonna {colonna}, fuori dalla riga {riga}.")
    return posizione


def _riga_colonna(testo: str, posizione: int, inizi: list[int] | None = None) -> tuple[int, int]:
    import bisect

    if inizi is None:
        inizi = _inizi_righe(testo)
    riga = bisect.bisect_right(inizi, posizione)
    return riga, posizione - inizi[riga - 1] + 1


def _intervallo(testo: str, c: Correzione, inizi: list[int] | None = None) -> tuple[int, int, str]:
    """(inizio, fine, testo nuovo) di una correzione; verifica ``prima``."""
    inizio = _posizione(testo, c.riga, c.colonna, inizi)
    fine = inizio + len(c.prima)
    if testo[inizio:fine] != c.prima:
        trovato = testo[inizio:fine]
        raise ValueError(
            f"La correzione alla riga {c.riga}, colonna {c.colonna} non corrisponde al testo: "
            f"attendevo {c.prima!r} e ho trovato {trovato!r}.")
    dopo = c.dopo
    if inizio == len(testo) and testo and not testo.endswith(("\n", "\r")) \
            and c.riga == len(_inizi_righe(testo)) + 1 and not dopo.startswith("\n"):
        dopo = "\n" + dopo                         # riga aggiunta in fondo a un file senza a capo finale
    return inizio, fine, dopo


# ---------------------------------------------------------------------------
# Applicazione e differenze
# ---------------------------------------------------------------------------

def applica_correzioni(sorgente: str, correzioni: list[Correzione]) -> str:
    """Applica le correzioni (tutte riferite a ``sorgente``) dal fondo verso l'inizio.

    ``ValueError`` se il ``prima`` di una correzione non coincide col sorgente,
    se una posizione e' fuori dal testo o se due correzioni si sovrappongono.
    Piu' inserimenti nello stesso punto restano nell'ordine della lista.
    """
    inizi = _inizi_righe(sorgente)
    intervalli = []
    for indice, c in enumerate(correzioni):
        inizio, fine, dopo = _intervallo(sorgente, c, inizi)
        intervalli.append((inizio, fine, indice, dopo))
    intervalli.sort(key=lambda x: (x[0], x[1], x[2]))
    for (a1, f1, i1, _), (a2, f2, i2, _) in zip(intervalli, intervalli[1:]):
        if a2 < f1:
            c1, c2 = correzioni[i1], correzioni[i2]
            raise ValueError(f"Le correzioni alla riga {c1.riga} e alla riga {c2.riga} si sovrappongono.")
    risultato = sorgente
    for inizio, fine, _, dopo in reversed(intervalli):
        risultato = risultato[:inizio] + dopo + risultato[fine:]
    return risultato


def differenze(prima: str, dopo: str, nome_file: str) -> str:
    """Differenze in formato unificato (``difflib``); "" se i testi sono uguali."""
    if prima == dopo:
        return ""
    righe = difflib.unified_diff(
        _righe(prima), _righe(dopo),
        fromfile=f"{nome_file} (originale)", tofile=f"{nome_file} (corretto)", lineterm="")
    return "\n".join(righe)


# ---------------------------------------------------------------------------
# Tracciamento delle correzioni sul sorgente originale
# ---------------------------------------------------------------------------

@dataclass
class _Modifica:
    """Modifica espressa sul sorgente ORIGINALE: ``originale[inizio:fine]`` -> ``testo``."""

    inizio: int
    fine: int
    testo: str
    motivi: list[str]
    cosmetica: bool = False
    alternative: list[tuple[int, int, str, str]] = field(default_factory=list)
    facoltativa: bool = False
    da_confermare: bool = False


def _segna_da_confermare(c: Correzione) -> Correzione:
    """Segna una correzione che cambia un nome (``contatre`` -> ``contatore``):
    potrebbe cambiare la logica, quindi :func:`chiedi_conferma` la chiede
    sempre da sola, anche quando si risponde ``s`` a tutte."""
    c.da_confermare = True  # type: ignore[attr-defined]
    return c


def _da_confermare(c: Correzione) -> bool:
    return bool(getattr(c, "da_confermare", False))


class _Tracciato:
    """Applica correzioni una dopo l'altra tenendo le posizioni sull'originale."""

    def __init__(self, originale: str) -> None:
        self.originale = originale
        self.corrente = originale
        self.modifiche: list[_Modifica] = []

    def _segmenti(self) -> list[tuple[int, int, int]]:
        """Per ogni modifica: (inizio e fine nel testo corrente, scarto accumulato prima di lei)."""
        risultato = []
        scarto = 0
        for m in self.modifiche:
            inizio = m.inizio + scarto
            risultato.append((inizio, inizio + len(m.testo), scarto))
            scarto += len(m.testo) - (m.fine - m.inizio)
        return risultato

    def _scarto_prima(self, posizione: int, segmenti) -> int:
        scarto = 0
        for (inizio, fine, s), m in zip(segmenti, self.modifiche):
            if fine <= posizione:
                scarto = s + len(m.testo) - (m.fine - m.inizio)
        return scarto

    def _originale_di(self, p: int, q: int) -> tuple[int, int] | None:
        """Posizioni originali di un tratto del testo corrente che non tocca modifiche."""
        segmenti = self._segmenti()
        if any(inizio <= q and p <= fine for inizio, fine, _ in segmenti):
            return None
        scarto = self._scarto_prima(p, segmenti)
        return p - scarto, q - scarto

    def aggiungi(self, p: int, q: int, testo: str, motivo: str, *, cosmetica: bool = False,
                 alternative: Iterable[tuple[int, int, str, str]] = (), facoltativa: bool = False,
                 da_confermare: bool = False) -> None:
        """Applica ``corrente[p:q] -> testo`` (posizioni nel testo corrente)."""
        segmenti = self._segmenti()
        toccate = [i for i, (inizio, fine, _) in enumerate(segmenti) if inizio <= q and p <= fine]
        nuovo = self.corrente[:p] + testo + self.corrente[q:]
        if p == q and len(toccate) == 1:
            # inserimento puro sul bordo di una modifica precedente (per esempio due
            # `fine` mancanti uno dopo l'altro): resta una correzione a parte
            j = toccate[0]
            inizio_j, fine_j, _ = segmenti[j]
            m_j = self.modifiche[j]
            if inizio_j < fine_j and p in (inizio_j, fine_j):
                dopo = p == fine_j
                posizione = m_j.fine if dopo else m_j.inizio
                m = _Modifica(posizione, posizione, testo, [motivo], cosmetica, facoltativa=facoltativa,
                              da_confermare=da_confermare)
                self.modifiche.insert(j + 1 if dopo else j, m)
                self.corrente = nuovo
                return
        if not toccate:
            scarto = self._scarto_prima(p, segmenti)
            originali = []
            for ap, aq, at, am in alternative:
                pos = self._originale_di(ap, aq)
                if pos is not None:
                    originali.append((pos[0], pos[1], at, am))
            m = _Modifica(p - scarto, q - scarto, testo, [motivo], cosmetica, originali, facoltativa,
                          da_confermare)
            indice = 0
            while indice < len(self.modifiche) and self.modifiche[indice].inizio <= m.inizio:
                indice += 1
            self.modifiche.insert(indice, m)
        else:
            primo, ultimo = toccate[0], toccate[-1]
            ini_primo, _, scarto_primo = segmenti[primo]
            _, fine_ultimo, scarto_ultimo = segmenti[ultimo]
            m_primo, m_ultimo = self.modifiche[primo], self.modifiche[ultimo]
            basso, alto = min(p, ini_primo), max(q, fine_ultimo)
            orig_inizio = m_primo.inizio if basso == ini_primo else basso - scarto_primo
            scarto_dopo = scarto_ultimo + len(m_ultimo.testo) - (m_ultimo.fine - m_ultimo.inizio)
            orig_fine = m_ultimo.fine if alto == fine_ultimo else alto - scarto_dopo
            testo_fuso = nuovo[basso:alto + len(testo) - (q - p)]
            motivi: list[str] = []
            coinvolte = self.modifiche[primo:ultimo + 1]
            for x in coinvolte:
                for mot in x.motivi:
                    if mot not in motivi:
                        motivi.append(mot)
            if not cosmetica and motivo not in motivi:
                motivi.append(motivo)
            if all(x.cosmetica for x in coinvolte) and cosmetica and motivo not in motivi:
                motivi.append(motivo)
            fusa = _Modifica(orig_inizio, orig_fine, testo_fuso, motivi,
                             cosmetica and all(x.cosmetica for x in coinvolte),
                             facoltativa=facoltativa and all(x.facoltativa for x in coinvolte),
                             da_confermare=da_confermare or any(x.da_confermare for x in coinvolte))
            self.modifiche[primo:ultimo + 1] = [fusa]
        self.corrente = nuovo

    def correzioni(self) -> list[Correzione]:
        inizi = _inizi_righe(self.originale)
        risultato = []
        for m in self.modifiche:
            riga, colonna = _riga_colonna(self.originale, m.inizio, inizi)
            alternative = []
            for a, b, t, mot in m.alternative:
                r, c = _riga_colonna(self.originale, a, inizi)
                alternative.append(Correzione(r, c, self.originale[a:b], t, mot))
            correzione = Correzione(riga, colonna, self.originale[m.inizio:m.fine], m.testo,
                                    "; ".join(m.motivi), alternative, m.facoltativa)
            if m.da_confermare:
                _segna_da_confermare(correzione)
            risultato.append(correzione)
        return risultato


# ---------------------------------------------------------------------------
# Analisi statica: `variabile` dimenticato
# ---------------------------------------------------------------------------

class _Ambito:
    __slots__ = ("dichiarati", "impliciti")

    def __init__(self, nomi: Iterable[str] = ()) -> None:
        self.dichiarati: set[str] = set(nomi)
        self.impliciti: set[str] = set()


# ---------------------------------------------------------------------------
# Moduli importati: quali nomi portano nel programma
# ---------------------------------------------------------------------------

def _cartella_di(nome_file: str | None) -> Path | None:
    """Cartella del programma (None se ``nome_file`` non e' un percorso vero)."""
    if not nome_file or nome_file.startswith("<"):
        return None
    try:
        cartella = Path(nome_file).resolve().parent
    except (OSError, ValueError):
        return None
    return cartella if cartella.is_dir() else None


def _e_modulo_libreria(nome: str) -> bool:
    """``importa matematica``: esiste ``leo/libreria/matematica.py``?"""
    if not nome.isidentifier():
        return False
    radice = Path(__file__).resolve().parent / "libreria"
    if (radice / f"{nome}.py").is_file() or (radice / nome / "__init__.py").is_file():
        return True
    if not getattr(sys, "frozen", False):
        return False
    # nell'eseguibile (PyInstaller) i moduli stanno nell'archivio, non in file .py
    try:
        import importlib.util

        return importlib.util.find_spec(f"{__package__}.libreria.{nome}") is not None
    except (ImportError, ValueError):
        return False


def _file_modulo(modulo: str, cartelle: list[Path]) -> Path | None:
    nomi = nomi_file_modulo(modulo)
    if Path(nomi[0]).is_absolute():
        return next((Path(n) for n in nomi if Path(n).is_file()), None)
    for cartella in cartelle:
        for nome in nomi:
            candidato = cartella / nome
            if candidato.is_file():
                return candidato.resolve()
    return None


def nomi_importati(importa: nodi.Importa, cartella: Path | None = None,
                   _visitati: frozenset = frozenset()) -> set[str] | None:
    """Nomi che ``importa`` aggiunge al programma.

    * ``importa x come m`` -> ``{"m"}``;
    * ``importa matematica`` (modulo di libreria) -> ``{"matematica"}`` (le sue
      funzioni sono gia' disponibili, il nome del modulo si usa col punto);
    * ``importa "forme.leo"`` -> i nomi dichiarati al livello esterno del file
      (letto dalla cartella del programma o da quella corrente) piu' ``forme``.

    None se il file non si trova o non si riesce a leggere: i nomi sono
    sconosciuti, quindi chi analizza deve essere prudente.
    """
    if importa.alias is not None:
        return {importa.alias}
    modulo = importa.modulo
    e_file = e_sorgente(modulo) or "/" in modulo or "\\" in modulo
    cartelle = [c for c in (cartella, Path.cwd()) if c is not None]
    percorso = _file_modulo(modulo, cartelle)
    if percorso is None:
        if not e_file and _e_modulo_libreria(modulo):
            implicito = nome_modulo_implicito(modulo)
            return {implicito} if implicito else set()
        return None
    nomi = _nomi_del_file(percorso, _visitati)
    if nomi is not None:
        implicito = nome_modulo_implicito(percorso.stem)
        if implicito:
            nomi.add(implicito)
    return nomi


def _nomi_del_file(percorso: Path, _visitati: frozenset) -> set[str] | None:
    """Nomi dichiarati al livello esterno del file ``percorso`` (e dei file che
    importa senza ``come``); None se non si riesce a leggerlo."""
    if str(percorso) in _visitati:
        return set()                     # importazione circolare: la segnala l'interprete
    try:
        from .esecuzione import analizza

        testo = percorso.read_text(encoding="utf-8-sig")
        programma = analizza(testo, str(percorso))
    except (ErroreDante, OSError, UnicodeDecodeError, ImportError):
        return None
    nomi: set[str] = set()
    for ist in programma.istruzioni:
        if isinstance(ist, nodi.DichiarazioneMultipla):
            nomi.update(ist.nomi or [ist.nome])
        elif isinstance(ist, (nodi.Dichiarazione, nodi.DefinizioneFunzione)):
            nomi.add(ist.nome)
        elif isinstance(ist, nodi.Assegnazione) and isinstance(ist.bersaglio, nodi.Nome):
            nomi.add(ist.bersaglio.nome)          # stile implicito
        elif isinstance(ist, nodi.Importa):
            interni = nomi_importati(ist, percorso.parent, _visitati | {str(percorso)})
            if interni is None:
                return None
            if ist.alias is None:        # il nome implicito del modulo interno resta nel file
                interno = _file_modulo(ist.modulo, [percorso.parent, Path.cwd()])
                implicito = nome_modulo_implicito(interno.stem if interno else ist.modulo)
                interni = interni - {implicito} if implicito not in nomi else interni
            nomi.update(interni)
    nomi |= {n for ist in programma.istruzioni if isinstance(ist, (nodi.DefinizioneStruttura, nodi.DefinizioneTipo))
             for n in [ist.nome] + [v.nome for v in getattr(ist, "varianti", [])]}
    # `pubblica` e nomi con `_`: chi importa vede solo quelli (leo/controllo)
    pubblici = getattr(programma, "pubblici", None)
    return {n for n in nomi if not n.startswith("_") and (pubblici is None or n in pubblici)}


class _CercaDichiarazioni:
    """Trova le assegnazioni ``nome = valore`` a nomi mai dichiarati.

    Simula gli ambiti di Leo: ogni blocco ne apre uno nuovo, ``per ogni``
    dichiara le sue variabili, ``cattura ... come e`` dichiara ``e``, ogni
    ``caso`` di ``scegli`` e' un blocco, ``importa`` dichiara l'alias o i nomi
    del modulo, i corpi di funzioni ed eventi si analizzano alla fine (possono
    usare nomi dichiarati dopo la loro definizione). Un'assegnazione viene
    segnalata solo se il nome non e' visibile e non viene dichiarato piu'
    avanti nello stesso ambito.

    Se il programma importa un modulo che non si riesce a leggere (``opaco``)
    non si segnala nulla: quei nomi potrebbero venire dal modulo.
    """

    def __init__(self, predefiniti: set[str], cartella: Path | None = None, *,
                 maiuscole_tollerate: bool = False) -> None:
        self.predefiniti = predefiniti
        self.cartella = cartella
        self.maiuscole_tollerate = maiuscole_tollerate
        self.candidati: list[tuple[nodi.Assegnazione, _Ambito]] = []
        self.multiple: list[tuple[nodi.AssegnazioneMultipla, _Ambito]] = []
        self.rinviati: list[tuple[list, list[_Ambito]]] = []
        self.opaco = False
        #: per ogni assegnazione candidata (``id``): i nomi dichiarati visibili in quel punto
        self.visibili: dict[int, frozenset[str]] = {}

    def _visibile(self, nome: str, catena: list[_Ambito]) -> bool:
        if nome in self.predefiniti:
            return True
        if any(nome in a.dichiarati or nome in a.impliciti for a in catena):
            return True
        if self.maiuscole_tollerate:
            # come l'interprete (tollerante): `Contatore = 5` assegna a `contatore`
            # se nell'ambito piu' vicino che ne ha uno c'e' un solo nome simile
            minuscolo = nome.lower()
            for a in reversed(catena):
                simili = {n for n in a.dichiarati | a.impliciti if n.lower() == minuscolo}
                if simili:
                    return len(simili) == 1
        return False

    def analizza(self, programma: nodi.Programma) -> None:
        globale = _Ambito()
        self.blocco(programma.istruzioni, [globale])
        while self.rinviati:
            corpo, catena = self.rinviati.pop(0)
            self.blocco(corpo, catena)

    def programma(self, programma: nodi.Programma) -> list[nodi.Assegnazione]:
        self.analizza(programma)
        if self.opaco:
            return []
        return [a for a, ambito in self.candidati if a.bersaglio.nome not in ambito.dichiarati]

    def assegnazioni_multiple(self) -> list[nodi.AssegnazioneMultipla]:
        """``a, b = 1, 2`` con tutti i nomi mai dichiarati (dopo :meth:`analizza`)."""
        if self.opaco:
            return []
        return [a for a, ambito in self.multiple
                if not any(b.nome in ambito.dichiarati for b in a.bersagli)]

    def blocco(self, istruzioni: list, catena: list[_Ambito]) -> None:
        for istruzione in istruzioni or []:
            self.istruzione(istruzione, catena)

    def _figlio(self, corpo: list | None, catena: list[_Ambito], nomi: Iterable[str] = ()) -> None:
        if corpo is not None:
            self.blocco(corpo, catena + [_Ambito(nomi)])

    def _rinvia(self, parametri: list, corpo: list, catena: list[_Ambito], nomi: Iterable[str] = ()) -> None:
        ambito = _Ambito(nomi)
        for p in parametri or []:
            ambito.dichiarati.add(p.nome)
            if p.predefinito is not None:
                self.espressione(p.predefinito, catena)
        self.rinviati.append((corpo, catena + [ambito]))

    def istruzione(self, ist: Any, catena: list[_Ambito]) -> None:
        corrente = catena[-1]
        if isinstance(ist, nodi.DichiarazioneMultipla):
            self.espressione(ist.valore, catena)
            corrente.dichiarati.update(ist.nomi or [ist.nome])
        elif isinstance(ist, nodi.Dichiarazione):
            self.espressione(ist.valore, catena)
            corrente.dichiarati.add(ist.nome)
        elif isinstance(ist, nodi.Assegnazione):
            self.espressione(ist.valore, catena)
            bersaglio = ist.bersaglio
            if isinstance(bersaglio, nodi.Nome):
                if ist.operatore == "=" and not self._visibile(bersaglio.nome, catena):
                    self.candidati.append((ist, corrente))
                    self.visibili[id(ist)] = frozenset().union(*(a.dichiarati for a in catena))
                    corrente.impliciti.add(bersaglio.nome)
            else:
                self.espressione(bersaglio, catena)
        elif isinstance(ist, nodi.AssegnazioneMultipla):
            self.espressione(ist.valore, catena)
            bersagli = ist.bersagli or []
            nomi = [b.nome for b in bersagli if isinstance(b, nodi.Nome)]
            if nomi and len(nomi) == len(bersagli) and len(set(nomi)) == len(nomi) \
                    and not any(self._visibile(n, catena) for n in nomi):
                self.multiple.append((ist, corrente))
                corrente.impliciti.update(nomi)
            for b in bersagli:
                if not isinstance(b, nodi.Nome):
                    self.espressione(b, catena)
        elif isinstance(ist, nodi.DefinizioneFunzione):
            corrente.dichiarati.add(ist.nome)
            self._rinvia(ist.parametri, ist.corpo, catena)
        elif isinstance(ist, nodi.Se):
            for ramo in ist.rami:
                self.espressione(ramo.condizione, catena)
                self._figlio(ramo.corpo, catena)
            self._figlio(ist.altrimenti, catena)
        elif isinstance(ist, nodi.Scegli):
            self.espressione(ist.valore, catena)
            for caso in ist.casi:
                self.espressione(caso.schemi, catena)
                self._figlio(caso.corpo, catena)
            self._figlio(ist.altrimenti, catena)
        elif isinstance(ist, nodi.Mentre):
            self.espressione(ist.condizione, catena)
            self._figlio(ist.corpo, catena)
        elif isinstance(ist, nodi.Ripeti):
            self.espressione(ist.volte, catena)
            self._figlio(ist.corpo, catena)
        elif isinstance(ist, nodi.PerOgni):
            self.espressione(ist.iterabile, catena)
            self._figlio(ist.corpo, catena, ist.variabili or [ist.variabile])
        elif isinstance(ist, nodi.Prova):
            self._figlio(ist.corpo, catena)
            for cattura in ist.catture:
                nomi = [cattura.nome_variabile] if cattura.nome_variabile else []
                self._figlio(cattura.corpo, catena, nomi)
            self._figlio(ist.infine, catena)
        elif isinstance(ist, nodi.Evento):
            self._rinvia([], ist.corpo, catena, ["evento"])
        elif isinstance(ist, nodi.Importa):
            nomi = nomi_importati(ist, self.cartella)
            if nomi is None:
                self.opaco = True
            else:
                corrente.dichiarati.update(nomi)
        else:
            self.espressione(ist, catena)

    def espressione(self, nodo: Any, catena: list[_Ambito]) -> None:
        """Cerca funzioni anonime dentro un nodo qualsiasi."""
        if isinstance(nodo, nodi.FunzioneAnonima):
            self._rinvia(nodo.parametri, nodo.corpo, catena)
            return
        if isinstance(nodo, nodi.ListaCompresa):
            # le variabili della lista compressa valgono solo al suo interno
            interna = catena + [_Ambito(nodo.variabili)]
            self.espressione(nodo.iterabile, catena)
            self.espressione(nodo.elemento, interna)
            if nodo.condizione is not None:
                self.espressione(nodo.condizione, interna)
            return
        if isinstance(nodo, (list, tuple)):
            for x in nodo:
                self.espressione(x, catena)
            return
        if is_dataclass(nodo) and isinstance(nodo, nodi.Nodo):
            for f in fields(nodo):
                valore = getattr(nodo, f.name)
                if isinstance(valore, (nodi.Nodo, list, tuple)):
                    self.espressione(valore, catena)


def _nomi_predefiniti() -> set[str]:
    nomi: set[str] = set()
    try:
        from .errori import TIPI_ERRORE
        from . import registro

        nomi.update(TIPI_ERRORE)
        try:
            registro.carica_libreria()
        except Exception:  # libreria incompleta: si usa quello che c'e'
            pass
        nomi.update(registro.FUNZIONI)
        nomi.update(registro.COSTANTI)
    except ImportError:  # pragma: no cover
        pass
    return nomi


def _cartella_programma(programma: nodi.Programma, cartella: str | os.PathLike | None) -> Path | None:
    if cartella is not None:
        return Path(cartella)
    return _cartella_di(getattr(programma, "nome_file", None))


def assegnazioni_senza_dichiarazione(programma: nodi.Programma,
                                     nomi_noti: Iterable[str] = (), *,
                                     cartella: str | os.PathLike | None = None,
                                     maiuscole_tollerate: bool = True) -> list[nodi.Assegnazione]:
    """Assegnazioni ``nome = valore`` dove ``nome`` non e' mai stato dichiarato.

    ``nomi_noti``: nomi gia' definiti altrove (REPL, controlli grafici).
    Le funzioni di libreria, le costanti e i tipi di errore contano come dichiarati.
    ``cartella``: dove cercare i file di ``importa`` (predefinita: quella di
    ``programma.nome_file``, poi quella corrente). ``maiuscole_tollerate``: un
    nome che differisce solo per le maiuscole da UN nome visibile
    (``Contatore = 5`` dopo ``variabile contatore = 0``) non e' una dichiarazione
    mancante, perche' l'interprete assegna a quel nome (False con lo stile a
    dichiarazione implicita, dove ``Contatore = 5`` crea un nome nuovo).
    """
    predefiniti = _nomi_predefiniti() | set(nomi_noti)
    return _CercaDichiarazioni(predefiniti, _cartella_programma(programma, cartella),
                               maiuscole_tollerate=maiuscole_tollerate).programma(programma)


def _assegnazioni_con_nomi_simili(programma: nodi.Programma, nomi_noti: Iterable[str] = (), *,
                                  cartella: Path | None = None
                                  ) -> list[tuple[nodi.Assegnazione, list[str]]]:
    """Come :func:`assegnazioni_senza_dichiarazione`, ma con ogni assegnazione
    i nomi visibili in quel punto molto simili al suo (stessa misura dei
    suggerimenti di ``ErroreNome``: ``suggerimenti.simili``, distanza <= 2).

    ``contatre = 5`` dopo ``variabile contatore = 0`` -> ``["contatore"]``:
    e' quasi certamente un errore di battitura, non una variabile nuova.
    Se pero' il nome viene anche letto altrove (fuori dal valore della sua
    assegnazione), l'utente lo usa di proposito: niente nomi simili, perche'
    li' manca davvero ``variabile``."""
    from .suggerimenti import simili

    noti = set(nomi_noti)
    cerca = _CercaDichiarazioni(_nomi_predefiniti() | noti, cartella, maiuscole_tollerate=True)
    candidate = cerca.programma(programma)
    letti: dict[str, set[int]] = {}
    if candidate:
        for n, uso in _usi_di_nomi(programma):
            if uso != "bersaglio":
                letti.setdefault(n.nome, set()).add(id(n))
    risultato = []
    for a in candidate:
        nome = a.bersaglio.nome
        nel_valore = {id(n) for n, _ in _usi_di_nomi(a.valore)}
        if letti.get(nome, set()) - nel_valore:
            risultato.append((a, []))
            continue
        visibili = cerca.visibili.get(id(a), frozenset()) | noti
        risultato.append((a, simili(nome, visibili, 2)))
    return risultato


def assegnazioni_multiple_senza_dichiarazione(programma: nodi.Programma,
                                              nomi_noti: Iterable[str] = (), *,
                                              cartella: str | os.PathLike | None = None,
                                              maiuscole_tollerate: bool = True,
                                              ) -> list[nodi.AssegnazioneMultipla]:
    """``a, b = 1, 2`` dove nessuno dei nomi e' mai stato dichiarato (manca ``variabile``)."""
    predefiniti = _nomi_predefiniti() | set(nomi_noti)
    cerca = _CercaDichiarazioni(predefiniti, _cartella_programma(programma, cartella),
                                maiuscole_tollerate=maiuscole_tollerate)
    cerca.analizza(programma)
    return cerca.assegnazioni_multiple()


# ---------------------------------------------------------------------------
# Analisi statica: nomi di altri linguaggi (`print`, `len`, `True`...)
# ---------------------------------------------------------------------------

_VALORI_PAROLA = {"vero", "falso", "nulla"}


def _nodi(nodo: Any):
    """Tutti i nodi dentro ``nodo`` (compreso), in profondita'."""
    pila = [nodo]
    while pila:
        n = pila.pop()
        if isinstance(n, (list, tuple)):
            pila.extend(reversed(n))
            continue
        if not (is_dataclass(n) and isinstance(n, nodi.Nodo)):
            continue
        yield n
        for f in reversed(fields(n)):
            valore = getattr(n, f.name)
            if isinstance(valore, (nodi.Nodo, list, tuple)):
                pila.append(valore)


def nomi_dichiarati(programma: nodi.Programma, *, cartella: str | os.PathLike | None = None
                    ) -> tuple[set[str], bool]:
    """Tutti i nomi dichiarati in un punto qualunque del programma e se il
    programma importa moduli che non si riescono a leggere (``opaco``).

    Contano: dichiarazioni (anche multiple), funzioni e parametri, variabili di
    ``per ogni`` e delle liste compresse, ``cattura ... come e``, assegnazioni a
    un nome (stile implicito), ``evento`` e i controlli dei gestori ``quando``,
    gli alias e i nomi dei moduli importati.
    """
    base = _cartella_programma(programma, cartella)
    dichiarati: set[str] = set()
    opaco = False
    for n in _nodi(programma):
        if isinstance(n, nodi.DichiarazioneMultipla):
            dichiarati.update(n.nomi or [n.nome])
        elif isinstance(n, (nodi.Dichiarazione, nodi.DefinizioneFunzione, nodi.Parametro)):
            dichiarati.add(n.nome)
        elif isinstance(n, nodi.PerOgni):
            dichiarati.update(n.variabili or [n.variabile])
        elif isinstance(n, nodi.ListaCompresa):
            dichiarati.update(n.variabili)
        elif isinstance(n, nodi.Cattura) and n.nome_variabile:
            dichiarati.add(n.nome_variabile)
        elif isinstance(n, nodi.Assegnazione) and isinstance(n.bersaglio, nodi.Nome):
            dichiarati.add(n.bersaglio.nome)
        elif isinstance(n, nodi.AssegnazioneMultipla):
            dichiarati.update(b.nome for b in n.bersagli if isinstance(b, nodi.Nome))
        elif isinstance(n, nodi.Evento):
            dichiarati.update(("evento", n.controllo))
        elif isinstance(n, nodi.Importa):
            importati = nomi_importati(n, base)
            if importati is None:
                opaco = True
            else:
                dichiarati.update(importati)
    dichiarati |= _nomi_dei_costrutti(programma)
    return dichiarati, opaco


def _nomi_dei_costrutti(programma: nodi.Programma) -> set[str]:
    """Strutture, tipi, varianti, `questo`, `risultato` (leo/controllo/analisi.py)."""
    try:
        from .controllo.analisi import nomi_dei_costrutti
    except ImportError:  # pragma: no cover
        return set()
    return nomi_dei_costrutti(programma)


def nomi_di_altri_linguaggi(programma: nodi.Programma,
                            nomi_noti: Iterable[str] = ()) -> list[tuple[nodi.Nome, str]]:
    """Nomi usati ma mai dichiarati che in un altro linguaggio indicano una
    funzione o un valore di Leo: ``print`` -> ``stampa``, ``len`` ->
    ``lunghezza``, ``True`` -> ``vero``, ``None`` -> ``nulla``.

    Restituisce (nodo ``Nome``, parola di Leo). Un nome dichiarato in un punto
    qualunque del programma (o in ``nomi_noti``) non viene mai toccato, e
    nemmeno un nome con l'iniziale maiuscola che non indichi un valore
    (potrebbe essere un controllo grafico). Se il programma importa un modulo
    che non si riesce a leggere non si propone nulla.
    """
    try:
        from .suggerimenti import parola_altro_linguaggio
    except Exception:  # noqa: BLE001 - suggerimenti non disponibili
        return []
    predefiniti = _nomi_predefiniti()
    dichiarati, opaco = nomi_dichiarati(programma)
    if opaco:
        return []
    dichiarati |= set(nomi_noti) | predefiniti
    usati = [n for n in _nodi(programma) if isinstance(n, nodi.Nome)]
    risultato = []
    for n in usati:
        if n.nome in dichiarati or len(n.nome) < 2:
            continue
        try:
            leo = parola_altro_linguaggio(n.nome)
        except Exception:  # noqa: BLE001
            leo = None
        if not leo or leo == n.nome:
            continue
        # un nome con l'iniziale maiuscola puo' essere un controllo grafico
        # (`Pulsante1`), che il codice usa senza dichiararlo: si tocca solo se
        # indica un valore (`True`, `None`)
        if leo in _VALORI_PAROLA or (leo in predefiniti and not n.nome[:1].isupper()):
            risultato.append((n, leo))
    return risultato


# ---------------------------------------------------------------------------
# Suggerimenti non bloccanti: forme che Leo capisce ma che non sono canoniche
# ---------------------------------------------------------------------------

def _usi_di_nomi(programma: nodi.Programma):
    """(nodo ``Nome``, uso) per ogni nome letto dal programma.

    ``uso``: ``"valore"`` (un valore qualunque), ``"chiamata"`` (``f(...)``),
    ``"oggetto"`` (``x.campo``), ``"testo"`` (dentro ``{...}`` di un testo) o
    ``"bersaglio"`` (a sinistra di ``=``).
    """
    pila: list[tuple[Any, str]] = [(programma, "valore")]
    while pila:
        n, uso = pila.pop()
        if isinstance(n, (list, tuple)):
            pila.extend((x, uso) for x in reversed(n))
            continue
        if not (is_dataclass(n) and isinstance(n, nodi.Nodo)):
            continue
        if isinstance(n, nodi.Nome):
            yield n, uso
            continue
        interno = "testo" if isinstance(n, nodi.TestoInterpolato) else ("testo" if uso == "testo" else "valore")
        for f in reversed(fields(n)):
            valore = getattr(n, f.name)
            if not isinstance(valore, (nodi.Nodo, list, tuple)):
                continue
            figlio = interno
            if interno != "testo":
                if isinstance(n, nodi.Chiamata) and f.name == "funzione":
                    figlio = "chiamata"
                elif isinstance(n, nodi.Attributo) and f.name == "oggetto":
                    figlio = "oggetto"
                elif isinstance(n, (nodi.Assegnazione,)) and f.name == "bersaglio":
                    figlio = "bersaglio"
                elif isinstance(n, nodi.AssegnazioneMultipla) and f.name == "bersagli":
                    figlio = "bersaglio"
            pila.append((valore, figlio))


def _colori_nominati() -> dict[str, str]:
    try:
        from .grafica.colori import COLORI_NOMINATI

        return COLORI_NOMINATI
    except Exception:  # noqa: BLE001 - grafica non disponibile
        return {}


def nomi_da_maschera(nome_file: str | os.PathLike | None) -> set[str]:
    """Nomi dei controlli della maschera accanto al programma (``Finestra1.leo``
    -> ``Finestra1.maschera``): la finestra e i suoi controlli. Vuoto se non c'e'."""
    return set(controlli_da_maschera(nome_file))


def controlli_da_maschera(nome_file: str | os.PathLike | None) -> dict[str, str]:
    """Come :func:`nomi_da_maschera`, con il tipo di ogni controllo:
    ``{"Finestra1": "Finestra", "Etichetta1": "Etichetta", ...}`` (tipo ``""``
    se la maschera non lo dice). Vuoto se la maschera non c'e'."""
    if not nome_file or str(nome_file).startswith("<"):
        return {}
    try:
        maschera = Path(nome_file).with_suffix(".maschera")
        if not maschera.is_file():
            return {}
        from .tomlutil import carica_toml

        dati = carica_toml(maschera)
    except Exception:  # noqa: BLE001 - maschera illeggibile: nessun nome in piu'
        return {}
    controlli: dict[str, str] = {}

    def aggiungi(voce: Any) -> None:
        if isinstance(voce, dict) and isinstance(voce.get("nome"), str) and voce["nome"].isidentifier():
            tipo = voce.get("tipo")
            controlli.setdefault(voce["nome"], tipo if isinstance(tipo, str) else "")

    if isinstance(dati, dict):
        aggiungi(dati.get("finestra"))
        for controllo in dati.get("controlli") or []:
            aggiungi(controllo)
    return controlli


@dataclass
class NomeControlloSbagliato:
    """Un nome di controllo scritto male nel codice di una finestra: il TIPO al
    posto del nome (``etichetta`` per ``Etichetta1``) o, in ``quando``, il nome
    con le maiuscole sbagliate (``quando pulsante1.clic``: il gestore non
    verrebbe mai chiamato). ``riga``/``colonna``: dove comincia il nome scritto."""

    riga: int
    colonna: int
    scritto: str
    giusto: str
    motivo: str


def _proprieta_dopo(righe: list[str], riga: int, colonna: int, nome: str) -> str | None:
    """``testo`` se nel sorgente, dopo ``nome``, c'e' ``.testo``."""
    import re

    if not 1 <= riga <= len(righe):
        return None
    m = re.match(re.escape(nome) + r"\s*\.\s*([^\W\d]\w*)", righe[riga - 1][colonna - 1:])
    return m.group(1) if m else None


def _colonna_del_nome(righe: list[str], riga: int, da_colonna: int, nome: str) -> int | None:
    """Colonna (1-based) della prima volta che ``nome`` compare come parola intera
    sulla riga, a partire da ``da_colonna`` (fuori dai testi e dai commenti)."""
    import re

    if not 1 <= riga <= len(righe):
        return None
    testo = righe[riga - 1]
    for m in re.finditer(r"(?<![\w])" + re.escape(nome) + r"(?![\w])", testo):
        if m.start() + 1 < da_colonna:
            continue
        prima = testo[:m.start()]
        if prima.count('"') % 2 == 1 or "#" in prima:
            continue
        return m.start() + 1
    return None


def nomi_dei_controlli_sbagliati(programma: nodi.Programma, sorgente: str, controlli: dict[str, str], *,
                                 nomi_noti: Iterable[str] = (),
                                 cartella: str | os.PathLike | None = None) -> list[NomeControlloSbagliato]:
    """Nomi di controlli scritti male nel codice di una finestra (``controlli``:
    nome -> tipo, per esempio da :func:`controlli_da_maschera`).

    * il TIPO al posto del nome: ``etichetta.testo = "x"`` mentre nella finestra
      c'e' una sola etichetta, ``Etichetta1`` (anche in ``quando``);
    * in ``quando``, il nome con le maiuscole sbagliate (``quando pulsante1.clic``
      per ``Pulsante1``): nel codice normale Leo lo tollera gia' (vedi
      :func:`nomi_tollerati`), nei gestori no.
    """
    if not controlli:
        return []
    from .suggerimenti import frase_tipo_come_nome

    dichiarati, opaco = nomi_dichiarati(programma, cartella=cartella)
    if opaco:
        return []
    noti = dichiarati | _nomi_predefiniti() | set(nomi_noti) | set(controlli)
    per_tipo: dict[str, list[str]] = {}
    for nome, tipo in controlli.items():
        if tipo:
            per_tipo.setdefault(tipo.lower(), []).append(nome)
    righe = _righe(sorgente)

    def del_tipo(scritto: str) -> str | None:
        candidati = per_tipo.get(scritto.lower(), [])
        return candidati[0] if len(candidati) == 1 else None

    risultato: list[NomeControlloSbagliato] = []
    for n, uso in _usi_di_nomi(programma):
        if n.nome in noti or uso not in ("oggetto", "valore"):
            continue
        giusto = del_tipo(n.nome)
        if giusto is None:
            continue
        proprieta = _proprieta_dopo(righe, n.riga, n.colonna, n.nome) if uso == "oggetto" else None
        risultato.append(NomeControlloSbagliato(n.riga, n.colonna, n.nome, giusto,
                                                frase_tipo_come_nome(n.nome, [giusto], proprieta)))
    per_minuscolo: dict[str, list[str]] = {}
    for nome in controlli:
        per_minuscolo.setdefault(nome.lower(), []).append(nome)
    for ev in _nodi(programma):
        # (i nomi dei gestori contano come "dichiarati": qui si guardano solo i controlli veri)
        if not isinstance(ev, nodi.Evento) or ev.controllo in controlli or ev.controllo in set(nomi_noti):
            continue
        scritto = ev.controllo
        giusto = del_tipo(scritto)
        if giusto is not None:
            motivo = frase_tipo_come_nome(scritto, [giusto])
            motivo = motivo.rsplit(" Scrivi ", 1)[0] + f" Scrivi `quando {giusto}.{ev.evento}`."
        else:
            simili_maiuscole = per_minuscolo.get(scritto.lower(), [])
            if len(simili_maiuscole) != 1:
                continue
            giusto = simili_maiuscole[0]
            motivo = (f"il controllo si chiama `{giusto}`, non `{scritto}`: in Leo maiuscole e minuscole "
                      f"contano e con `{scritto}` il gestore non verrebbe mai chiamato")
        colonna = _colonna_del_nome(righe, ev.riga, ev.colonna, scritto)
        if colonna is None:
            continue
        risultato.append(NomeControlloSbagliato(ev.riga, colonna, scritto, giusto, motivo))
    return risultato


@dataclass
class Tolleranza:
    """Un nome scritto in una forma tollerata: ``finestra1`` per ``Finestra1``
    (``tipo = "maiuscole"``) o ``rosso`` senza virgolette (``tipo = "colore"``).
    ``canonico``: il testo da scrivere al posto del nome."""

    nodo: nodi.Nome
    tipo: str
    canonico: str


def _dichiarati_per_tolleranze(programma: nodi.Programma, dichiarazione_implicita: bool,
                               cartella: str | os.PathLike | None) -> tuple[set[str], bool, set[int]]:
    """Come :func:`nomi_dichiarati`, ma un'assegnazione dichiara un nome solo
    quando lo fa davvero anche l'interprete: con lo stile a dichiarazione
    implicita e con ``=`` (``Contatore += 1`` non dichiara mai nulla; senza lo
    stile implicito ``Contatore = 5`` assegna a ``contatore``). Restituisce
    anche gli ``id()`` dei nomi a sinistra di un'assegnazione che l'interprete
    risolve con la tolleranza delle maiuscole."""
    tutti, opaco = nomi_dichiarati(programma, cartella=cartella)
    assegnati: set[str] = set()
    altri: set[str] = set()
    tollerati: set[int] = set()
    for n in _nodi(programma):
        if isinstance(n, nodi.Assegnazione) and isinstance(n.bersaglio, nodi.Nome):
            composta = n.operatore != "="
            if dichiarazione_implicita and not composta:
                altri.add(n.bersaglio.nome)
            else:
                assegnati.add(n.bersaglio.nome)
                tollerati.add(id(n.bersaglio))
        elif isinstance(n, nodi.AssegnazioneMultipla):
            for b in n.bersagli:
                if isinstance(b, nodi.Nome):
                    if dichiarazione_implicita:
                        altri.add(b.nome)
                    else:
                        assegnati.add(b.nome)
                        tollerati.add(id(b))
    # un nome solo assegnato (mai dichiarato in altro modo) non e' dichiarato
    solo_assegnati = assegnati - altri - _dichiarati_non_da_assegnazioni(programma, cartella)
    return (tutti - solo_assegnati) | altri, opaco, tollerati


def _dichiarati_non_da_assegnazioni(programma: nodi.Programma, cartella: str | os.PathLike | None,
                                    *, gestori: bool = True) -> set[str]:
    """Nomi dichiarati da qualcosa che non e' un'assegnazione (dichiarazioni,
    funzioni, parametri, cicli, ``cattura``, gestori, importazioni)."""
    trovati: set[str] = set()
    for n in _nodi(programma):
        if isinstance(n, nodi.DichiarazioneMultipla):
            trovati.update(n.nomi or [n.nome])
        elif isinstance(n, (nodi.Dichiarazione, nodi.DefinizioneFunzione, nodi.Parametro)):
            trovati.add(n.nome)
        elif isinstance(n, nodi.PerOgni):
            trovati.update(n.variabili or [n.variabile])
        elif isinstance(n, nodi.ListaCompresa):
            trovati.update(n.variabili)
        elif isinstance(n, nodi.Cattura) and n.nome_variabile:
            trovati.add(n.nome_variabile)
        elif isinstance(n, nodi.Evento):
            trovati.update(("evento", n.controllo) if gestori else ("evento",))
        elif isinstance(n, nodi.Importa):
            # i nomi importati: nel dubbio contano come dichiarati
            trovati.update(nomi_importati(n, _cartella_programma(programma, cartella)) or ())
    return trovati | _nomi_dei_costrutti(programma)


def nomi_tollerati(programma: nodi.Programma, nomi_noti: Iterable[str] = (), *,
                   cartella: str | os.PathLike | None = None,
                   dichiarazione_implicita: bool | None = None) -> list[Tolleranza]:
    """Nomi che l'interprete capisce solo grazie alla modalita' tollerante.

    Come ``Interprete._nome_tollerante``: un nome mai dichiarato che differisce
    solo per maiuscole/minuscole da UN solo nome noto (del programma, della
    libreria, di ``nomi_noti`` come i controlli della maschera) diventa quel
    nome; altrimenti, se e' il nome di un colore (``rosso``), diventa il testo
    ``"rosso"``. Se il programma importa moduli illeggibili non si propone nulla.

    ``dichiarazione_implicita``: se e' indicato (lo stile del programma), le
    assegnazioni contano come l'interprete: ``Contatore += 1`` e, senza lo stile
    implicito, ``Contatore = 5`` non dichiarano ``Contatore`` e vengono
    proposti anch'essi (``contatore += 1``). ``None``: ogni assegnazione a un
    nome conta come dichiarazione e i nomi a sinistra di ``=`` non si toccano.
    """
    if dichiarazione_implicita is None:
        dichiarati, opaco = nomi_dichiarati(programma, cartella=cartella)
        bersagli_tollerati: set[int] = set()
    else:
        dichiarati, opaco, bersagli_tollerati = _dichiarati_per_tolleranze(
            programma, dichiarazione_implicita, cartella)
        # `quando pulsante1.clic` con `Pulsante1` tra i nomi noti (maschera): il
        # gestore non dichiara `pulsante1`, e' il controllo scritto male
        minuscoli_noti: dict[str, int] = {}
        for nome in set(nomi_noti):
            minuscoli_noti[nome.lower()] = minuscoli_noti.get(nome.lower(), 0) + 1
        altri = _dichiarati_non_da_assegnazioni(programma, cartella, gestori=False)
        for ev in _nodi(programma):
            if (isinstance(ev, nodi.Evento) and ev.controllo not in nomi_noti
                    and ev.controllo not in altri and minuscoli_noti.get(ev.controllo.lower()) == 1):
                dichiarati.discard(ev.controllo)
    if opaco:
        return []
    noti = dichiarati | _nomi_predefiniti() | set(nomi_noti)
    per_minuscolo: dict[str, set[str]] = {}
    for nome in noti:
        per_minuscolo.setdefault(nome.lower(), set()).add(nome)
    colori = _colori_nominati()
    risultato: list[Tolleranza] = []
    for n, uso in _usi_di_nomi(programma):
        if n.nome in noti or (uso == "bersaglio" and id(n) not in bersagli_tollerati):
            continue
        candidati = per_minuscolo.get(n.nome.lower(), set()) - {n.nome}
        if uso == "oggetto" and n.nome[:1].isupper():
            # `Colore.testo`: probabilmente un controllo grafico che il codice non
            # dichiara; si propone solo un nome del programma, mai uno della libreria
            candidati &= dichiarati | set(nomi_noti)
        if len(candidati) == 1:
            risultato.append(Tolleranza(n, "maiuscole", next(iter(candidati))))
        elif not candidati and uso == "valore" and n.nome.lower() in colori:
            risultato.append(Tolleranza(n, "colore", '"' + n.nome.lower() + '"'))
    return risultato


_REGOLA_PAROLA = {
    "allora": "`se`, `altrimenti se` e `caso` terminano con `allora`",
    "fai": "`mentre`, `per ogni` e `quando` terminano con `fai`",
}


def _motivo_tolleranza(t: Tolleranza, rigoroso: bool) -> str:
    inizio = "con --rigoroso questo è un errore" if rigoroso else "funziona anche così"
    if t.tipo == "maiuscole":
        return (f"{inizio}, ma il nome si scrive `{t.canonico}`: "
                "in Leo maiuscole e minuscole contano")
    return f"{inizio}, ma i colori sono testi: si scrive `{t.canonico}`, tra virgolette"


# ---------------------------------------------------------------------------
# Analisi statica: rientri incoerenti
# ---------------------------------------------------------------------------

def _rientri_incoerenti(token: list, righe: list[str]) -> list[tuple[int, str, str]]:
    """Righe dello stesso blocco con rientri diversi: (riga, rientro attuale, rientro voluto).

    Il rientro voluto e' quello della maggioranza delle righe del blocco (a
    parita', quello della prima). Le righe di continuazione (dentro parentesi o
    che cominciano con ``|>``), i commenti e le righe dentro commenti su piu'
    righe non si toccano. ``scegli`` ha due livelli: i rami ``caso`` e
    ``altrimenti`` formano un gruppo, i corpi di ogni ramo un altro; le parole
    chiave dentro parentesi (liste compresse) non aprono blocchi.
    """
    from .formattatore import _apre_blocco_tipi, _apre_scegli, _e_caso, _e_etichetta
    from .tokens import TipoToken as T

    aprono = {T.SE, T.MENTRE, T.PER_OGNI, T.RIPETI, T.FUNZIONE, T.PROVA, T.QUANDO, T.INIZIO}
    rientrano = {T.FINE, T.ALTRIMENTI, T.ALTRIMENTI_SE, T.CATTURA, T.INFINE}
    aperte = {T.PARENTESI_APERTA, T.QUADRA_APERTA, T.GRAFFA_APERTA}
    chiuse = {T.PARENTESI_CHIUSA, T.QUADRA_CHIUSA, T.GRAFFA_CHIUSA}

    per_riga: dict[int, list] = {}
    for t in token:
        if t.tipo not in (T.FINE_FILE, T.COMMENTO):
            per_riga.setdefault(t.riga, []).append(t)

    gruppi: dict[int, list[tuple[int, str]]] = {}
    # identificativi dei gruppi aperti; `scegli` ne apre due (rami e corpi)
    pila: list[int] = [0]
    larghezze: list[int] = []        # quanti identificativi ha aperto ogni blocco
    prossimo = 1
    parentesi = 0
    inizio = True
    for r in range(1, len(righe) + 1):
        elenco = per_riga.get(r, [])
        if elenco and parentesi == 0 and elenco[0].tipo is not T.CATENA:
            primo = elenco[0]
            if primo.colonna == len(righe[r - 1]) - len(righe[r - 1].lstrip(" \t")) + 1:
                if primo.tipo is T.FINE and larghezze:
                    gruppo = pila[-1 - larghezze[-1]]
                elif primo.tipo in rientrano and len(pila) > 1:
                    gruppo = pila[-2]
                elif larghezze and larghezze[-1] == 2 and _e_caso(elenco, 0):
                    gruppo = pila[-2]
                else:
                    gruppo = pila[-1]
                rientro = righe[r - 1][:primo.colonna - 1]
                gruppi.setdefault(gruppo, []).append((r, rientro))
        salta = False
        for k, t in enumerate(elenco):
            if salta:
                salta = False
                if _e_etichetta(t):
                    continue
            if t.tipo is T.FINE_RIGA:
                if parentesi == 0:
                    inizio = True
                continue
            all_inizio, inizio = inizio, False
            if t.tipo in aperte:
                parentesi += 1
            elif t.tipo in chiuse:
                parentesi = max(0, parentesi - 1)
            elif parentesi > 0:
                continue
            elif t.tipo in aprono or _apre_blocco_tipi(elenco, k):
                pila.append(prossimo)
                prossimo += 1
                larghezze.append(1)
            elif all_inizio and _apre_scegli(elenco, k):
                pila.extend((prossimo, prossimo + 1))
                prossimo += 2
                larghezze.append(2)
            elif t.tipo is T.FINE:
                if larghezze:
                    del pila[-larghezze.pop():]
                salta = True

    risultato = []
    for voci in gruppi.values():
        conteggi: dict[str, int] = {}
        for _, rientro in voci:
            conteggi[rientro] = conteggi.get(rientro, 0) + 1
        if len(conteggi) < 2:
            continue
        ordine = [rientro for _, rientro in voci]
        voluto = max(conteggi, key=lambda x: (conteggi[x], -ordine.index(x)))
        for r, rientro in voci:
            if rientro != voluto:
                risultato.append((r, rientro, voluto))
    return sorted(risultato)


# ---------------------------------------------------------------------------
# Proposta delle correzioni
# ---------------------------------------------------------------------------

def _analizza(sorgente: str, nome_file: str, opzioni: dict[str, Any]):
    from .esecuzione import analizza

    return analizza(sorgente, nome_file, recupero=True, **opzioni)


def _token(sorgente: str, nome_file: str, opzioni: dict[str, Any]) -> list:
    from .esecuzione import tokenizza

    return tokenizza(sorgente, nome_file, **opzioni)


def _si_analizza(sorgente: str, nome_file: str, opzioni: dict[str, Any]) -> bool:
    try:
        _analizza(sorgente, nome_file, opzioni)
        return True
    except ErroreDante:
        return False


def proponi_correzioni(sorgente: str, nome_file: str = "<sorgente>", **opzioni_lessico: Any) -> list[Correzione]:
    """Correzioni di forma che rendono il sorgente analizzabile (lista vuota se non ce ne sono
    o se non si arriva a un sorgente senza errori).

    ``opzioni_lessico``: come per ``leo.esecuzione.analizza`` (``rigoroso``,
    ``stile``, ``sinonimi_extra``, ``dizionari_sinonimi``); in piu'
    ``nomi_noti`` (nomi gia' definiti, per il REPL) e ``controlli`` (nome ->
    tipo dei controlli della finestra, oltre a quelli della maschera accanto al
    file), che non vengono passate al lexer.
    """
    opzioni = dict(opzioni_lessico)
    nomi_noti = tuple(opzioni.pop("nomi_noti", ()) or ())
    controlli = opzioni.pop("controlli", None) or {}
    if sorgente is None:
        return []
    try:
        return _proponi(sorgente, nome_file, opzioni, nomi_noti, dict(controlli))
    except (ImportError, NotImplementedError, RecursionError):
        return []


_PER_IN_LISTA = re.compile(r"[ \t]*(?P<per>[^\W\d]\w*)[ \t]+(?P<nomi>[^\W\d]\w*(?:[ \t]*,[ \t]*[^\W\d]\w*)*)"
                           r"[ \t]+in\b")


def _aperta_in(testo: str, posizione: int) -> str | None:
    """La parentesi aperta (sulla stessa riga) che contiene ``posizione``, o None.

    Le stringhe tra virgolette non contano (basta una stima: serve solo a
    riconoscere ``[... per n in ...]``)."""
    inizio = max(testo.rfind("\n", 0, posizione), testo.rfind("\r", 0, posizione)) + 1
    pila: list[str] = []
    virgolette = None
    for c in testo[inizio:posizione]:
        if virgolette:
            if c == virgolette:
                virgolette = None
        elif c in "\"'":
            virgolette = c
        elif c in "([{":
            pila.append(c)
        elif c in ")]}" and pila:
            pila.pop()
    return pila[-1] if pila else None


def _per_ogni_in_lista(corrente: str, p: int, q: int, testo: str) -> tuple[int, int, str, str] | None:
    """``[n per n in l]`` (o ``[n for n in l]``): al posto della virgola
    proposta davanti a ``per`` si propone ``per ogni``.

    ``(p, q, testo)`` e' la correzione del parser; se non e' l'inserimento di
    una virgola dentro ``[...]`` davanti a ``per``/``for``/``foreach`` seguito
    da uno o piu' nomi e da ``in``, None."""
    if p != q or testo != "," or _aperta_in(corrente, p) != "[":
        return None
    trovato = _PER_IN_LISTA.match(corrente, p)
    if trovato is None:
        return None
    parola = trovato.group("per")
    if parola == "per":
        motivo = "nelle liste compresse si scrive `per ogni`"
    else:
        from .suggerimenti import parola_altro_linguaggio

        if parola_altro_linguaggio(parola) != "per ogni":
            return None
        motivo = f"`{parola}` non è una parola di Leo: nelle liste compresse si scrive `per ogni`"
    return trovato.start("per"), trovato.end("per"), "per ogni", motivo


def _sospetta(corrente: str, p: int, q: int, testo: str) -> bool:
    """La correzione del parser raddoppia una parola chiave, ne infila una fuori posto
    o mette una virgola accanto a un operatore scritto a parole (:mod:`leo.forme_parlate`)."""
    try:
        from .forme_parlate import correzione_sospetta
    except ImportError:  # pragma: no cover
        return False
    inizi = _inizi_righe(corrente)
    riga, colonna = _riga_colonna(corrente, p, inizi)
    if not 1 <= riga <= len(inizi):
        return False
    testo_riga = corrente[inizi[riga - 1]:_fine_riga(corrente, inizi, riga)]
    if q > inizi[riga - 1] + len(testo_riga):
        return False                    # correzione su piu' righe: non e' di questo tipo
    from .forme_parlate import nomi_definiti

    return correzione_sospetta(testo_riga, colonna, corrente[p:q], testo,
                               nomi_noti=nomi_definiti(corrente)) is not None


def _proponi(sorgente: str, nome_file: str, opzioni: dict[str, Any], nomi_noti: tuple,
             controlli_extra: dict[str, str] | None = None) -> list[Correzione]:
    controlli_extra = controlli_extra or {}
    tracciato = _Tracciato(sorgente)
    visti = {sorgente}
    programma = None
    for giro in range(GIRI_MASSIMI + 1):
        try:
            programma = _analizza(tracciato.corrente, nome_file, opzioni)
            break
        except ErroreSintassi as errore:
            if giro == GIRI_MASSIMI or not errore.correzioni:
                return []
            prima = errore.correzioni[0]
            corrente = tracciato.corrente
            try:
                p, q, testo = _intervallo(corrente, prima)
            except ValueError:
                return []
            alternative = []
            for alt in prima.alternative:
                try:
                    ap, aq, at = _intervallo(corrente, alt)
                except ValueError:
                    continue
                alternative.append((ap, aq, at, alt.motivo or prima.motivo))
            motivo = prima.motivo or errore.messaggio
            per_ogni = _per_ogni_in_lista(corrente, p, q, testo)
            if per_ogni is not None:
                # `[n per n in l]`: non mancano virgole, manca `ogni`
                p, q, testo, motivo = per_ogni
                alternative = []
            elif _sospetta(corrente, p, q, testo):
                # `se x è uguale allora a 5 allora`, `stampa(3, più, 4)`: meglio nessuna proposta
                return []
            tracciato.aggiungi(p, q, testo, motivo, alternative=alternative)
            if tracciato.corrente in visti:
                return []                       # nessun progresso: ci si ferma
            visti.add(tracciato.corrente)
        except ErroreDante:
            return []
    if programma is None:
        return []

    corrente = tracciato.corrente
    stile = Stile.da_sorgente(corrente, opzioni.get("stile"))
    cartella = _cartella_di(nome_file)
    nomi_noti = tuple(nomi_noti) + tuple(nomi_da_maschera(nome_file))

    # `variabile` dimenticato alla prima assegnazione
    if not stile.dichiarazione_implicita:
        forma = stile.forma_scritta("variabili") or "variabile"
        inizi = _inizi_righe(corrente)
        inserimenti: list[tuple[int, str]] = []
        rinomini: list[tuple[int, str, list[str]]] = []
        for a, simili_a in _assegnazioni_con_nomi_simili(programma, nomi_noti, cartella=cartella):
            try:
                posizione = _posizione(corrente, a.riga, a.colonna, inizi)
            except ValueError:
                continue
            nome = a.bersaglio.nome
            if simili_a:
                # `contatre = 5` dopo `variabile contatore = 0`: e' un errore di
                # battitura, `variabile` creerebbe di nascosto una variabile nuova
                if corrente[posizione:posizione + len(nome)] == nome:
                    rinomini.append((posizione, nome, simili_a))
                continue
            inserimenti.append((posizione, f"`{nome}` non è mai stato dichiarato: manca `{forma}`"))
        for a in assegnazioni_multiple_senza_dichiarazione(programma, nomi_noti, cartella=cartella):
            try:
                posizione = _posizione(corrente, a.riga, a.colonna, inizi)
            except ValueError:
                continue
            nomi = ", ".join(f"`{b.nome}`" for b in a.bersagli)
            inserimenti.append((posizione, f"{nomi} non sono mai stati dichiarati: manca `{forma}`"))
        modifiche = [(posizione, 0, forma + " ", motivo, []) for posizione, motivo in inserimenti]
        for posizione, nome, simili_a in rinomini:
            def _motivo(giusto: str, nome: str = nome) -> str:
                return (f"`{nome}` non è mai stato dichiarato: forse intendevi `{giusto}`? "
                        f"(se vuoi una variabile nuova, scrivi `{forma} {nome} = ...`)")
            alternative = [(posizione, posizione + len(nome), altro, _motivo(altro)) for altro in simili_a[1:]]
            modifiche.append((posizione, len(nome), simili_a[0], _motivo(simili_a[0]), alternative))
        for posizione, lunghezza, testo, motivo, alternative in sorted(modifiche, key=lambda x: x[0],
                                                                        reverse=True):
            tracciato.aggiungi(posizione, posizione + lunghezza, testo, motivo, alternative=alternative,
                               da_confermare=lunghezza > 0)

    # parole di altri linguaggi usate come nomi (`print` -> `stampa`)
    corrente = tracciato.corrente
    try:
        programma = _analizza(corrente, nome_file, opzioni)
    except ErroreDante:
        programma = None
    if programma is not None:
        inizi = _inizi_righe(corrente)
        sostituzioni = []
        for nodo, parola in nomi_di_altri_linguaggi(programma, nomi_noti):
            try:
                posizione = _posizione(corrente, nodo.riga, nodo.colonna, inizi)
            except ValueError:
                continue
            if corrente[posizione:posizione + len(nodo.nome)] == nodo.nome:
                sostituzioni.append((posizione, nodo.nome, parola))
        for posizione, nome, parola in sorted(sostituzioni, reverse=True):
            tracciato.aggiungi(posizione, posizione + len(nome), parola,
                               f"`{nome}` non è una parola di Leo: si scrive `{parola}`")

    # nomi dei controlli scritti male (`etichetta.testo` per `Etichetta1.testo`,
    # `quando pulsante1.clic` per `Pulsante1`)
    controlli = dict(controlli_extra)
    controlli.update(controlli_da_maschera(nome_file))
    if controlli:
        corrente = tracciato.corrente
        try:
            programma = _analizza(corrente, nome_file, opzioni)
        except ErroreDante:
            programma = None
        if programma is not None:
            inizi = _inizi_righe(corrente)
            sostituzioni_controlli = []
            for sbagliato in nomi_dei_controlli_sbagliati(programma, corrente, controlli,
                                                          nomi_noti=nomi_noti, cartella=cartella):
                try:
                    posizione = _posizione(corrente, sbagliato.riga, sbagliato.colonna, inizi)
                except ValueError:
                    continue
                if corrente[posizione:posizione + len(sbagliato.scritto)] == sbagliato.scritto:
                    sostituzioni_controlli.append((posizione, sbagliato))
            fatte: set[int] = set()
            for posizione, sbagliato in sorted(sostituzioni_controlli, key=lambda x: x[0], reverse=True):
                if posizione in fatte:
                    continue
                fatte.add(posizione)
                tracciato.aggiungi(posizione, posizione + len(sbagliato.scritto), sbagliato.giusto,
                                   sbagliato.motivo)

    # suggerimenti non bloccanti: forme tollerate -> forma canonica
    _suggerisci_forme_canoniche(tracciato, nome_file, opzioni, nomi_noti, cartella)

    # rientri incoerenti (solo estetica)
    corrente = tracciato.corrente
    try:
        token = _token(corrente, nome_file, opzioni)
    except ErroreDante:
        token = []
    inizi = _inizi_righe(corrente)
    for riga, attuale, voluto in reversed(_rientri_incoerenti(token, _righe(corrente))):
        inizio = inizi[riga - 1]
        tracciato.aggiungi(inizio, inizio + len(attuale), voluto, _MOTIVO_RIENTRO, cosmetica=True)

    correzioni = tracciato.correzioni()
    if not correzioni:
        return []
    try:
        finale = applica_correzioni(sorgente, correzioni)
    except ValueError:
        return []
    if finale != tracciato.corrente or not _si_analizza(finale, nome_file, opzioni):
        return []

    # alternative: restano solo quelle che portano anch'esse a un file analizzabile
    for i, c in enumerate(correzioni):
        valide = []
        for alt in c.alternative:
            prova = correzioni[:i] + [alt] + correzioni[i + 1:]
            try:
                testo = applica_correzioni(sorgente, prova)
            except ValueError:
                continue
            if _si_analizza(testo, nome_file, opzioni):
                valide.append(alt)
        c.alternative = valide
    return correzioni


def _suggerisci_forme_canoniche(tracciato: _Tracciato, nome_file: str, opzioni: dict[str, Any],
                                nomi_noti: tuple, cartella: Path | None) -> None:
    """Aggiunge (come correzioni facoltative) le forme che Leo accetta per
    tolleranza: ``se x fai`` -> ``se x allora``, ``quando P.clic allora`` ->
    ``fai``, ``ripeti 3 volte fai`` -> ``ripeti 3 volte``, ``finestra1`` ->
    ``Finestra1``, ``Contatore += 1`` -> ``contatore += 1``, ``rosso`` -> ``"rosso"``."""
    corrente = tracciato.corrente
    for p, q, testo, motivo in _forme_canoniche(corrente, nome_file, opzioni, nomi_noti, cartella):
        tracciato.aggiungi(p, q, testo, motivo, facoltativa=True)


def _seguito_da_punto(corrente: str, inizi: list[int], nodo: nodi.Nome) -> bool:
    """Nel sorgente, dopo il nome c'e' un ``.`` (``Titolo.testo``)?"""
    try:
        posizione = _posizione(corrente, nodo.riga, nodo.colonna, inizi) + len(nodo.nome)
    except ValueError:
        return True
    return corrente[posizione:].lstrip(" \t").startswith(".")


def _aspetto_di_controllo(nome: str) -> bool:
    """Il nome sembra quello di un controllo di una finestra (``Pulsante1``, ``Finestra2``)?"""
    return nome[:1].isupper() and nome[-1:].isdigit()


def _forme_canoniche(corrente: str, nome_file: str, opzioni: dict[str, Any], nomi_noti: tuple,
                     cartella: Path | None, *, per_formatta: bool = False,
                     controlli: dict[str, str] | None = None) -> list[tuple[int, int, str, str]]:
    """Le tolleranze di ``corrente`` (che deve analizzarsi senza errori):
    ``(inizio, fine, testo canonico, motivo)`` sulle posizioni di ``corrente``,
    senza sovrapposizioni, dall'ultima alla prima.

    ``per_formatta``: solo le sostituzioni che di sicuro non cambiano il
    significato del programma (``leo formatta`` le applica senza chiedere):
    niente maiuscole di un nome che e' anche un colore (una variabile vince sul
    colore solo se e' visibile in quel punto), niente maiuscole di nomi che
    potrebbero essere controlli di una finestra quando la maschera non si
    conosce, niente eventi che diventerebbero doppi; in piu' i nomi dei
    controlli nei ``quando`` (``quando pulsante1.clic`` -> ``Pulsante1``) se
    ``controlli`` (dalla maschera) li conosce.
    """
    from .formattatore import parole_di_blocco_scambiate, parole_in_piu_dopo_volte
    from .tokens import SINONIMI_EVENTI

    rigoroso = bool(opzioni.get("rigoroso"))
    inizio_motivo = "con --rigoroso questo è un errore" if rigoroso else "funziona anche così"
    inizi = _inizi_righe(corrente)
    sostituzioni: list[tuple[int, int, str, str]] = []
    try:
        token = _token(corrente, nome_file, opzioni)
    except ErroreDante:
        token = []
    try:
        programma = _analizza(corrente, nome_file, opzioni)
    except ErroreDante:
        programma = None
    controlli = controlli or {}

    # gestori che, con la tolleranza, risponderebbero allo stesso evento: non si toccano
    def _chiave(controllo: str, evento: str) -> tuple[str, str]:
        ev = str(evento).lower()
        return str(controllo).lower(), SINONIMI_EVENTI.get(ev, ev)

    conteggio_gestori: dict[tuple[str, str], int] = {}
    for n in _nodi(programma) if programma is not None else ():
        if isinstance(n, nodi.Evento):
            k = _chiave(n.controllo, n.evento)
            conteggio_gestori[k] = conteggio_gestori.get(k, 0) + 1

    def _gestore_doppio(controllo: str, evento: str) -> bool:
        return conteggio_gestori.get(_chiave(controllo, evento), 0) > 1

    for posizione, scritto, voluto, controllo in _eventi_all_inglese(token, corrente, inizi):
        if per_formatta and _gestore_doppio(controllo, scritto):
            continue
        sostituzioni.append((posizione, posizione + len(scritto), voluto,
                             f"{inizio_motivo}, ma l'evento si scrive `{voluto}`"))
    for t, voluto in parole_di_blocco_scambiate(token):
        try:
            posizione = _posizione(corrente, t.riga, t.colonna, inizi)
        except ValueError:
            continue
        scritto = corrente[posizione:posizione + t.lunghezza]
        if not scritto or scritto == voluto:
            continue
        sostituzioni.append((posizione, posizione + len(scritto), voluto,
                             f"funziona anche così, ma si scrive `{voluto}`: {_REGOLA_PAROLA[voluto]}"))
    for volte, extra in parole_in_piu_dopo_volte(token):
        try:
            p = _posizione(corrente, volte.riga, volte.colonna, inizi) + volte.lunghezza
            q = _posizione(corrente, extra.riga, extra.colonna, inizi) + extra.lunghezza
        except ValueError:
            continue
        scritto = corrente[q - extra.lunghezza:q]
        sostituzioni.append((p, q, "",
                             f"{inizio_motivo}, ma dopo `volte` non serve `{scritto}`: "
                             "si scrive `ripeti 3 volte` e il blocco comincia sulla riga dopo"))
    if programma is not None:
        stile = Stile.da_sorgente(corrente, opzioni.get("stile"))
        ha_eventi = bool(conteggio_gestori)   # un programma a finestre
        colori = _colori_nominati()
        for tolleranza in nomi_tollerati(programma, nomi_noti, cartella=cartella,
                                         dichiarazione_implicita=stile.dichiarazione_implicita):
            nodo = tolleranza.nodo
            if per_formatta and tolleranza.tipo == "maiuscole":
                if nodo.nome.lower() in colori:
                    continue
                if not controlli and (_aspetto_di_controllo(nodo.nome)
                                      or _aspetto_di_controllo(tolleranza.canonico)
                                      or (ha_eventi and _seguito_da_punto(corrente, inizi, nodo))):
                    continue      # forse un controllo della finestra che qui non si conosce
            try:
                posizione = _posizione(corrente, nodo.riga, nodo.colonna, inizi)
            except ValueError:
                continue
            if corrente[posizione:posizione + len(nodo.nome)] != nodo.nome:
                continue
            sostituzioni.append((posizione, posizione + len(nodo.nome), tolleranza.canonico,
                                 _motivo_tolleranza(tolleranza, rigoroso)))
        if per_formatta and controlli:
            # `quando pulsante1.clic fai` -> `quando Pulsante1.clic fai` (nomi della maschera)
            per_minuscolo: dict[str, list[str]] = {}
            for nome in controlli:
                per_minuscolo.setdefault(nome.lower(), []).append(nome)
            righe = _righe(corrente)
            for ev in _nodi(programma):
                if not isinstance(ev, nodi.Evento) or ev.controllo in controlli:
                    continue
                simili = per_minuscolo.get(ev.controllo.lower(), [])
                if len(simili) != 1 or _gestore_doppio(ev.controllo, ev.evento):
                    continue
                colonna = _colonna_del_nome(righe, ev.riga, ev.colonna, ev.controllo)
                if colonna is None:
                    continue
                try:
                    posizione = _posizione(corrente, ev.riga, colonna, inizi)
                except ValueError:
                    continue
                sostituzioni.append((posizione, posizione + len(ev.controllo), simili[0],
                                     f"{inizio_motivo}, ma il controllo si chiama `{simili[0]}`"))
    risultato: list[tuple[int, int, str, str]] = []
    occupate: list[tuple[int, int]] = []
    for p, q, testo, motivo in sorted(sostituzioni, reverse=True):
        if any(p < b and a < q for a, b in occupate):
            continue
        occupate.append((p, q))
        risultato.append((p, q, testo, motivo))
    return risultato


def tolleranze_da_formattare(sorgente: str, nome_file: str = "<formatta>", *,
                             controlli: dict[str, str] | None = None,
                             nomi_noti: Iterable[str] = (), **opzioni_lessico: Any) -> list[Correzione]:
    """Le tolleranze che ``leo formatta`` riporta alla forma canonica (GUIDA,
    §15): gli stessi suggerimenti facoltativi di :func:`suggerimenti_di_forma`,
    ma solo quelli che di sicuro non cambiano cio' che fa il programma.

    ``[]`` se il sorgente non si analizza senza errori. ``controlli``: nome ->
    tipo dei controlli della finestra (None = dalla maschera accanto a
    ``nome_file``, se c'e'). Le correzioni non si sovrappongono e si applicano
    con :func:`applica_correzioni`.
    """
    if sorgente is None:
        return []
    opzioni = dict(opzioni_lessico)
    if controlli is None:
        controlli = controlli_da_maschera(nome_file)
    try:
        _analizza(sorgente, nome_file, opzioni)
        noti = tuple(nomi_noti) + tuple(controlli)
        trovate = _forme_canoniche(sorgente, nome_file, opzioni, noti, _cartella_di(nome_file),
                                   per_formatta=True, controlli=controlli)
    except (ErroreDante, ImportError, NotImplementedError, RecursionError):
        return []
    inizi = _inizi_righe(sorgente)
    correzioni = []
    for p, q, testo, motivo in reversed(trovate):
        riga, colonna = _riga_colonna(sorgente, p, inizi)
        correzioni.append(Correzione(riga, colonna, sorgente[p:q], testo, motivo, [], True))
    return correzioni


def _eventi_all_inglese(token: list, corrente: str, inizi: list[int]) -> list[tuple[int, str, str, str]]:
    """``quando P.click fai``: (posizione, scritto, forma giusta, controllo) per
    gli eventi scritti con un sinonimo tollerato (``click`` -> ``clic``)."""
    from .tokens import SINONIMI_EVENTI, TipoToken as T

    significativi = [t for t in token if t.tipo is not T.COMMENTO]
    trovati: list[tuple[int, str, str, str]] = []
    for k, t in enumerate(significativi):
        if t.tipo is not T.QUANDO or k + 3 >= len(significativi):
            continue
        nome, punto, evento = significativi[k + 1:k + 4]
        if (nome.tipo is not T.NOME or punto.tipo is not T.PUNTO or evento.tipo is not T.NOME
                or evento.riga != t.riga or not evento.lunghezza):
            continue
        voluto = SINONIMI_EVENTI.get(str(evento.valore).lower())
        if voluto is None:
            continue
        try:
            posizione = _posizione(corrente, evento.riga, evento.colonna, inizi)
        except ValueError:
            continue
        scritto = corrente[posizione:posizione + evento.lunghezza]
        if scritto.lower() in SINONIMI_EVENTI:
            trovati.append((posizione, scritto, voluto, str(nome.valore)))
    return trovati


def suggerimenti_di_forma(sorgente: str, nome_file: str = "<sorgente>", **opzioni_lessico: Any) -> list[Correzione]:
    """Solo i suggerimenti non bloccanti (``Correzione.facoltativa``) per un
    sorgente che si analizza senza errori: forme tollerate da riportare alla
    forma canonica. ``[]`` se non ce ne sono o se il sorgente ha errori."""
    return [c for c in proponi_correzioni(sorgente, nome_file, **opzioni_lessico) if c.facoltativa]


# ---------------------------------------------------------------------------
# Uniformare lo stile
# ---------------------------------------------------------------------------

def uniforma_stile(sorgente: str, stile: Stile, nome_file: str = "<sorgente>") -> list[Correzione]:
    """Correzioni di forma che riportano allo stile del progetto le forme di altri stili.

    Esempio: con lo stile ``sia``, ``variabile x = 0`` -> ``sia x = 0``; con
    lo stile ``al``, ``quando P.clic fai`` -> ``al clic di P fai``. Restituisce
    ``[]`` se il file e' gia' uniforme o se non si riesce a leggerlo.
    """
    from .formattatore import modifiche_di_stile

    stile = stile or Stile()
    try:
        modifiche = modifiche_di_stile(sorgente, stile)
    except (ErroreDante, ImportError):
        return []
    righe = _righe(sorgente)
    correzioni = []
    for m in sorted(modifiche, key=lambda m: (m.riga, m.inizio)):
        testo = righe[m.riga - 1]
        prima = testo[m.inizio - 1:m.fine - 1]
        if m.campo == "variabili" and m.voluto == "implicita":
            motivo = "con la dichiarazione implicita non serve `variabile`"
        else:
            motivo = f"stile del progetto: `{m.voluto}` al posto di `{m.trovato}`"
        correzioni.append(Correzione(m.riga, m.inizio, prima, m.testo, motivo))
    return correzioni


# ---------------------------------------------------------------------------
# Descrizione e conferma
# ---------------------------------------------------------------------------

def _etichetta(testo: str) -> str:
    return f"{testo:<10}" if len(testo) < 10 else testo + " "


def _inserimento_di_righe(c: Correzione, righe: list[str]) -> tuple[int, str] | None:
    """Se la correzione aggiunge righe intere: (riga dopo cui si inserisce, testo inserito)."""
    if c.prima or not c.dopo.strip():
        return None
    if c.dopo.startswith("\n") and 1 <= c.riga <= len(righe) and c.colonna == len(righe[c.riga - 1]) + 1:
        return c.riga, c.dopo[1:]
    if c.colonna == 1 and c.dopo.endswith("\n"):
        return c.riga - 1, c.dopo[:-1]
    return None


def _e_rientro(c: Correzione) -> bool:
    return (c.colonna == 1 and not c.prima.strip(" \t") and not c.dopo.strip(" \t")
            and "\n" not in c.prima + c.dopo and c.prima != c.dopo)


def _descrivi_rientro(rientro: str) -> str:
    if not rientro:
        return "togliere il rientro"
    if set(rientro) == {" "}:
        n = len(rientro)
        return f"riallineare la riga a {n} spazi" if n != 1 else "riallineare la riga a 1 spazio"
    if set(rientro) == {"\t"}:
        n = len(rientro)
        return f"riallineare la riga a {n} tabulazioni" if n != 1 else "riallineare la riga a 1 tabulazione"
    return "riallineare la riga come le altre dello stesso blocco"


def _righe_toccate(c: Correzione, sorgente: str) -> tuple[list[str], list[str]]:
    """Righe del sorgente toccate dalla correzione, prima e dopo averla applicata."""
    righe = _righe(sorgente)
    ultima = min(len(righe), c.riga + c.prima.count("\n"))
    prima = righe[c.riga - 1:ultima] if c.riga <= len(righe) else []
    try:
        dopo_testo = applica_correzioni(sorgente, [c])
    except ValueError:
        return prima, []
    nuove = _righe(dopo_testo)
    ultima_nuova = min(len(nuove), c.riga + c.dopo.count("\n"))
    return prima, nuove[c.riga - 1:ultima_nuova]


def _testo_proposta(c: Correzione, sorgente: str) -> list[str]:
    righe = _righe(sorgente)
    inserimento = _inserimento_di_righe(c, righe)
    if inserimento is not None:
        dopo_riga, testo = inserimento
        inserite = [f"`{r.strip()}`" for r in testo.split("\n") if r.strip()]
        inserito = inserite[0] if len(inserite) == 1 else (", ".join(inserite[:-1]) + " e " + inserite[-1])
        inserito = inserito[1:-1]       # gli apici esterni li aggiunge la frase
        if dopo_riga <= 0:
            return [f"inserire `{inserito}` all'inizio del file"]
        return [f"inserire `{inserito}` dopo la riga {dopo_riga}"]
    if _e_rientro(c):
        return [_descrivi_rientro(c.dopo)]
    _, dopo = _righe_toccate(c, sorgente)
    dopo = [r.strip() for r in dopo]
    return dopo or [""]


def _voce(c: Correzione, sorgente: str) -> list[str]:
    """Le righe di testo che descrivono una correzione (con eventuali alternative)."""
    righe = _righe(sorgente)
    inserimento = _inserimento_di_righe(c, righe)
    rientro = " " * 12
    if inserimento is not None:
        numero = inserimento[0] + 1
        intestazione = [c.motivo or "riga mancante"]
    elif _e_rientro(c):
        numero = c.riga
        intestazione = [c.motivo or _MOTIVO_RIENTRO]
    else:
        numero = c.riga
        prima, _ = _righe_toccate(c, sorgente)
        intestazione = [r.strip() for r in prima] or [c.motivo]
    testo = [f"  {_etichetta(f'riga {numero}:')}{intestazione[0]}"]
    testo += [rientro + r for r in intestazione[1:]]
    if c.alternative:
        testo.append(f"  {_etichetta('proposte:')}".rstrip())
        for n, candidata in enumerate([c] + list(c.alternative), 1):
            proposta = _testo_proposta(candidata, sorgente)
            testo.append(f"    {n}. {proposta[0]}")
            testo += ["       " + r for r in proposta[1:]]
    else:
        proposta = _testo_proposta(c, sorgente)
        testo.append(f"  {_etichetta('proposta:')}{proposta[0]}")
        testo += [rientro + r for r in proposta[1:]]
    if (getattr(c, "facoltativa", False) or _da_confermare(c)) and c.motivo:
        testo.append(f"  {_etichetta('nota:')}{c.motivo}")
    return testo


def descrivi(correzioni: list[Correzione], sorgente: str, nome_file: str) -> str:
    """Testo di PROGETTO.md "Come si conferma" (i suggerimenti facoltativi si
    contano a parte e mostrano il motivo nella riga ``nota:``)::

        Ho trovato 2 errori di forma in voti.leo:

          riga 4:   se media >= 18
          proposta: se media >= 18 allora

          riga 9:   manca `fine` per il blocco `per ogni` aperto alla riga 6
          proposta: inserire `fine` dopo la riga 8
    """
    facoltative = sum(1 for c in correzioni if getattr(c, "facoltativa", False))
    n = len(correzioni) - facoltative
    parola = "errore" if n == 1 else "errori"
    consigli = f"{facoltative} {'suggerimento' if facoltative == 1 else 'suggerimenti'}"
    if not facoltative:
        parti = [f"Ho trovato {n} {parola} di forma in {nome_file}:"]
    elif not n:
        parti = [f"Ho {consigli} di forma per {nome_file} (il programma funziona anche così):"]
    else:
        parti = [f"Ho trovato {n} {parola} di forma in {nome_file} e ho {consigli} facoltativi:"
                 if facoltative > 1 else
                 f"Ho trovato {n} {parola} di forma in {nome_file} e ho 1 suggerimento facoltativo:"]
    for c in correzioni:
        parti.append("")
        parti.extend(_voce(c, sorgente))
    return "\n".join(parti)


def _chiedi(ingresso: Callable[[str], str], uscita: Callable[..., Any], domanda: str | None) -> str | None:
    """Mostra la domanda e legge la risposta (minuscola, senza spazi); None se l'ingresso finisce."""
    if domanda is not None:
        uscita(domanda)
    try:
        risposta = ingresso("> ")
    except (EOFError, KeyboardInterrupt):
        return None
    if risposta is None:
        return None
    return str(risposta).strip().lower()


def _scegli_alternativa(c: Correzione, ingresso, uscita, *, descrizione: str | None = None) -> Correzione | None:
    """Scelta numerata tra la correzione e le sue alternative; None = nessuna."""
    candidate = [c] + list(c.alternative)
    numeri = "  ".join(f"[{i}]" for i in range(1, len(candidate) + 1))
    domanda = f"Quale proposta scegli per la riga {c.riga}? {numeri}  [n]essuna"
    if descrizione:
        uscita(descrizione)
    risposta = _chiedi(ingresso, uscita, domanda)
    while True:
        if risposta is None or risposta in _NO or risposta == "nessuna":
            return None
        if risposta.isdigit() and 1 <= int(risposta) <= len(candidate):
            scelta = candidate[int(risposta) - 1]
            return Correzione(scelta.riga, scelta.colonna, scelta.prima, scelta.dopo, scelta.motivo)
        risposta = _chiedi(ingresso, uscita,
                           f"Rispondi con un numero da 1 a {len(candidate)} oppure con n.")


def chiedi_conferma(correzioni: list[Correzione], sorgente: str, nome_file: str, *,
                    ingresso: Callable[[str], str] = input,
                    uscita: Callable[..., Any] = print) -> list[Correzione]:
    """Mostra le correzioni e chiede conferma; restituisce quelle accettate (``[]`` = nessuna).

    Risposte: ``s`` tutte, ``n`` nessuna, ``u`` una alla volta, ``v`` mostra le
    differenze e ripete la domanda. Per le correzioni con alternative si
    sceglie per numero. Se l'ingresso finisce (EOF, Ctrl+C) non si applica nulla.
    """
    correzioni = list(correzioni)
    if not correzioni:
        return []
    uscita(descrivi(correzioni, sorgente, nome_file))
    uscita("")
    risposta = _chiedi(ingresso, uscita, DOMANDA)
    while True:
        if risposta is None or risposta in _NO:
            return []
        if risposta in _SI:
            scelte = []
            for c in correzioni:
                if c.alternative:
                    scelta = _scegli_alternativa(c, ingresso, uscita)
                    if scelta is not None:
                        scelte.append(scelta)
                elif _da_confermare(c):
                    # cambia un nome: si chiede sempre da sola
                    uscita("\n".join(_voce(c, sorgente)))
                    r = _chiedi(ingresso, uscita, "Cambio questo nome? [s]ì  [n]o")
                    while r is not None and r not in _SI and r not in _NO:
                        r = _chiedi(ingresso, uscita, "Rispondi con s oppure n.")
                    if r is None:
                        return []
                    if r in _SI:
                        scelte.append(c)
                else:
                    scelte.append(c)
            return scelte
        if risposta in ("u", "una", "una alla volta"):
            scelte = []
            for c in correzioni:
                voce = "\n".join(_voce(c, sorgente))
                if c.alternative:
                    scelta = _scegli_alternativa(c, ingresso, uscita, descrizione=voce)
                    if scelta is not None:
                        scelte.append(scelta)
                    continue
                uscita(voce)
                r = _chiedi(ingresso, uscita, "Applico questa correzione? [s]ì  [n]o")
                while r is not None and r not in _SI and r not in _NO:
                    r = _chiedi(ingresso, uscita, "Rispondi con s oppure n.")
                if r is None:
                    return []
                if r in _SI:
                    scelte.append(c)
            return scelte
        if risposta in ("v", "vedi", "vedi le differenze"):
            try:
                dopo = applica_correzioni(sorgente, correzioni)
                uscita(differenze(sorgente, dopo, nome_file))
            except ValueError as e:
                uscita(f"Non riesco a mostrare le differenze: {e}")
            uscita("")
            risposta = _chiedi(ingresso, uscita, DOMANDA)
            continue
        risposta = _chiedi(ingresso, uscita, "Rispondi con s, n, u oppure v.")


# ---------------------------------------------------------------------------
# File
# ---------------------------------------------------------------------------

def correggi_file(percorso: str | os.PathLike, *, ingresso: Callable[[str], str] = input,
                  uscita: Callable[..., Any] = print, **opzioni_lessico: Any) -> bool:
    """Propone le correzioni di un file, chiede conferma e, se accettate, lo corregge.

    Prima di scrivere salva la copia ``nome.leo.bak`` e poi stampa
    ``Corretto voti.leo (copia dell'originale in voti.leo.bak).``.
    Restituisce True se il file e' stato corretto. Se il file sta in un
    progetto e non si indicano ``stile``/``dizionari_sinonimi``, si usano quelli
    di ``progetto.toml``. Con la risposta ``n`` il file non viene toccato.
    """
    percorso = Path(percorso)
    nome = percorso.name
    try:
        dati = percorso.read_bytes()
    except OSError:
        return False
    bom = dati.startswith(b"\xef\xbb\xbf")
    try:
        testo = dati.decode("utf-8-sig")
    except UnicodeDecodeError:
        return False
    a_capo = "\r\n" if "\r\n" in testo else "\n"
    sorgente = testo.replace("\r\n", "\n").replace("\r", "\n")

    opzioni = dict(opzioni_lessico)
    if "stile" not in opzioni and "dizionari_sinonimi" not in opzioni:
        opzioni.update(_opzioni_progetto(percorso))

    correzioni = proponi_correzioni(sorgente, nome, **opzioni)
    if not correzioni:
        return False
    scelte = chiedi_conferma(correzioni, sorgente, nome, ingresso=ingresso, uscita=uscita)
    if not scelte:
        return False
    try:
        nuovo = applica_correzioni(sorgente, scelte)
    except ValueError as e:
        uscita(f"Non ho potuto correggere {nome}: {e}")
        return False
    if nuovo == sorgente:
        return False
    copia = percorso.with_name(nome + ".bak")
    try:
        shutil.copyfile(percorso, copia)
        if a_capo != "\n":
            nuovo = nuovo.replace("\n", a_capo)
        with open(percorso, "w", encoding="utf-8-sig" if bom else "utf-8", newline="") as f:
            f.write(nuovo)
    except OSError as e:
        uscita(f"Non ho potuto scrivere {nome}: {e.strerror or e}.")
        return False
    uscita("")
    uscita(f"Corretto {nome} (copia dell'originale in {copia.name}).")
    return True


def _opzioni_progetto(percorso: Path) -> dict[str, Any]:
    """Stile, sinonimi e modalita' rigorosa del progetto che contiene il file."""
    try:
        from .progetto import carica_progetto, e_progetto

        cartella = percorso.parent
        if not e_progetto(cartella):
            return {}
        progetto = carica_progetto(cartella)
        opzioni: dict[str, Any] = {"stile": progetto.stile, "rigoroso": progetto.rigoroso}
        if progetto.sinonimi:
            opzioni["dizionari_sinonimi"] = [progetto.sinonimi]
        if progetto.file_sinonimi:
            opzioni["sinonimi_extra"] = [progetto.file_sinonimi]
        return opzioni
    except (ErroreDante, OSError, ImportError):
        return {}
