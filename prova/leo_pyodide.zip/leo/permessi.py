"""Permessi dei programmi Leo: che cosa un programma può fare fuori da sé.

Un programma Leo, come un'app del telefono, dichiara che cosa gli serve; chi lo
esegue lo vede prima e decide. Il modello è quello di Deno, più semplice.

Categorie (:data:`CATEGORIE`)
-----------------------------
``file``      file e cartelle FUORI dalla cartella del programma;
``rete``      Internet e altri computer (``localhost`` escluso, salvo dichiarazione);
``sistema``   impostazioni del computer: registro di Windows, avvio automatico,
              spegnimento, finestre di altri programmi, variabili d'ambiente...;
``processi``  avviare, elencare o chiudere programmi, eseguire comandi;
``appunti``   leggere e scrivere gli appunti (copia e incolla);
``hardware``  fotocamera, microfono, posizione, porte seriali, schede collegate.

Dichiarazione
-------------
In cima al programma (prima riga di codice, anche dopo commenti)::

    permessi: rete "api.meteo.it", file "dati/", sistema no, processi no, appunti no, hardware "fotocamera"

(si può scrivere anche ``#permessi: ...``) oppure in ``progetto.toml``::

    [permessi]
    rete = ["api.meteo.it"]
    file = ["dati/"]
    sistema = "no"
    hardware = ["fotocamera"]

Valori: ``sì`` (tutto), ``no`` (mai, nemmeno chiedendo), ``chiedi``, oppure uno o
più testi tra virgolette (siti per ``rete``, cartelle per ``file``, dispositivi
per ``hardware``). Un elenco è un recinto: il resto è negato.

Senza dichiarazione (:func:`regola_predefinita`): la cartella del programma, la
cartella da cui lo lanci (se non è la cartella personale o la radice) e la
cartella temporanea sono libere; ``localhost`` è libero; per tutto il resto Leo
chiede la prima volta. Ciò che il programma dichiara (oltre ai predefiniti) va
approvato da chi lo esegue, una volta sola (la scelta si ricorda); un programma
firmato da una chiave fidata (``leo.firma_codice``) è approvato da sé.

Il punto centrale
-----------------
Ogni funzione della libreria passa da :func:`proteggi` quando si registra
(``registro.inserisci``, ``oggetti.metodo_oggetto``, metodi dei controlli in
``grafica.modello``): se la tabella :data:`MODULI` (per modulo, con eccezioni per
nome) le dà una categoria, o se ha un parametro che è un percorso
(:data:`PARAMETRI_PERCORSO`), la funzione vera viene avvolta da un custode. Le
funzioni nuove sono coperte da sé: basta che stiano in un modulo della tabella o
che chiamino ``percorso`` il loro parametro. Senza una politica attiva (test,
uso da Python, REPL) il custode non fa niente.

API principale
--------------
    Politica(...)                            regole di un'esecuzione
    prepara(percorso, sorgente=None, ...)    -> Politica per un programma o un progetto
    attiva(politica) / disattiva() / in_uso(politica)
    attiva_per_programma(percorso, sorgente, ...)   comodità per chi esegue (CLI, Studio, telefono)
    leggi_dichiarazione(sorgente) / dichiarazione_da_toml(dati)
    analizza_bisogni(sorgente, nome_file) -> list[Bisogno]
    riepilogo(percorso, sorgente=None) -> Riepilogo   (testo per `leo spiega` e per la richiesta)
    proteggi(nativa, modulo=None, nome=None) -> nativa (avvolta se serve)
    classifica(modulo, nome, funzione) -> Custodia | None
"""

from __future__ import annotations

import functools
import os
import re
import sys
import _thread
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable, Iterable, Iterator

from .errori import ErroreFile, ErroreValore

if TYPE_CHECKING:
    from pathlib import Path

__all__ = [
    "CATEGORIE", "NOMI_CATEGORIE", "DESCRIZIONI", "DISPOSITIVI", "ErrorePermesso", "Regola", "Dichiarazione",
    "Politica", "Custodia", "Bisogno", "Riepilogo", "leggi_dichiarazione", "dichiarazione_da_toml",
    "classifica", "proteggi", "proteggi_controllo", "attiva", "disattiva", "in_uso", "politica_attiva",
    "prepara", "attiva_per_programma", "analizza_bisogni", "riepilogo", "MODULI", "PARAMETRI_PERCORSO",
]

# ===========================================================================
# Categorie
# ===========================================================================

CATEGORIE: tuple[str, ...] = ("file", "rete", "sistema", "processi", "appunti", "hardware")

NOMI_CATEGORIE = {
    "file": "File",
    "rete": "Rete",
    "sistema": "Sistema",
    "processi": "Programmi e comandi",
    "appunti": "Appunti",
    "hardware": "Hardware",
}

DESCRIZIONI = {
    "file": "leggere e scrivere file fuori dalla cartella del programma",
    "rete": "collegarsi a Internet o ad altri computer",
    "sistema": "leggere o cambiare le impostazioni del computer (registro di Windows, avvio automatico, "
               "spegnimento, finestre di altri programmi, variabili d'ambiente)",
    "processi": "avviare, elencare o chiudere altri programmi ed eseguire comandi",
    "appunti": "leggere e scrivere gli appunti (copia e incolla)",
    "hardware": "usare fotocamera, microfono, posizione, porte seriali e schede collegate",
}

#: Dispositivi riconosciuti per ``hardware`` (altri nomi sono accettati così come sono).
DISPOSITIVI = ("fotocamera", "microfono", "posizione", "torcia", "seriale", "bluetooth", "usb", "nfc", "sensori")

_SINONIMI_CATEGORIE = {
    "file": "file", "files": "file", "cartelle": "file", "disco": "file",
    "rete": "rete", "internet": "rete", "web": "rete",
    "sistema": "sistema", "registro": "sistema", "computer": "sistema",
    "processi": "processi", "processo": "processi", "programmi": "processi", "comandi": "processi",
    "appunti": "appunti",
    "hardware": "hardware", "dispositivi": "hardware",
}

_SI = {"sì", "si", "sí", "vero", "tutto", "tutti", "true", "yes"}
_NO = {"no", "falso", "niente", "nessuno", "false", "mai"}
_CHIEDI = {"chiedi", "chiedere", "domanda"}


class ErrorePermesso(ErroreFile):
    """Il programma ha provato a fare una cosa per cui non ha il permesso.

    È una sottoclasse di ``ErroreFile`` (come ``PermissionError`` di Python è un
    ``OSError``): nei programmi si chiama ``ErroreFile`` e ``cattura ErroreFile`` la
    prende; il messaggio dice sempre quale permesso manca."""

    @property
    def tipo(self) -> str:
        return "ErroreFile"


# ===========================================================================
# Regole e dichiarazioni
# ===========================================================================

@dataclass(frozen=True)
class Regola:
    """Che cosa vale per una categoria.

    ``modo``: ``"si"``, ``"no"``, ``"chiedi"`` oppure ``"elenco"`` (solo i ``valori``)."""

    modo: str
    valori: tuple[str, ...] = ()

    def testo(self) -> str:
        if self.modo == "elenco":
            return ", ".join(f'"{v}"' for v in self.valori)
        return {"si": "sì", "no": "no", "chiedi": "chiedi"}[self.modo]


@dataclass
class Dichiarazione:
    """Permessi dichiarati da un programma o da un progetto (categoria -> Regola)."""

    regole: dict[str, Regola] = field(default_factory=dict)
    origine: str = ""            # "programma", "progetto.toml" o ""

    def __bool__(self) -> bool:
        return bool(self.regole)

    def impronta(self) -> str:
        import hashlib
        import json

        dati = {k: [r.modo, list(r.valori)] for k, r in sorted(self.regole.items())}
        return hashlib.sha256(json.dumps(dati, ensure_ascii=False).encode("utf-8")).hexdigest()[:16]

    def testo(self) -> str:
        return ", ".join(f"{c} {self.regole[c].testo()}" for c in CATEGORIE if c in self.regole)

    def unisci(self, altra: "Dichiarazione") -> "Dichiarazione":
        """Questa dichiarazione completata da ``altra`` (vince questa dove dicono entrambe)."""
        regole = dict(altra.regole)
        regole.update(self.regole)
        return Dichiarazione(regole, self.origine or altra.origine)


def _categoria(parola: str, dove: str) -> str:
    c = _SINONIMI_CATEGORIE.get(parola.strip().lower())
    if c is None:
        raise ErroreValore(
            f"Nei permessi {dove} non conosco la categoria `{parola}`.",
            suggerimento="Le categorie sono: " + ", ".join(CATEGORIE)
                         + ". Esempio: `permessi: rete \"api.meteo.it\", file \"dati/\", sistema no`.")
    return c


def _regola_da_parole(categoria: str, valori: list[str], parole: list[str], dove: str) -> Regola:
    parole = [p.lower() for p in parole]
    if valori and parole:
        raise ErroreValore(f"Nei permessi {dove}, per `{categoria}` metti o dei testi tra virgolette o una "
                           f"parola (sì, no, chiedi), non tutti e due.")
    if valori:
        return Regola("elenco", tuple(_normalizza_valore(categoria, v) for v in valori))
    if not parole:
        return Regola("si")
    if len(parole) == 1:
        p = parole[0]
        if p in _SI:
            return Regola("si")
        if p in _NO:
            return Regola("no")
        if p in _CHIEDI:
            return Regola("chiedi")
        if categoria == "hardware":         # hardware fotocamera (senza virgolette)
            return Regola("elenco", (p,))
    raise ErroreValore(f"Nei permessi {dove} non capisco `{categoria} {' '.join(parole)}`.",
                       suggerimento='Usa `sì`, `no`, `chiedi` o dei testi tra virgolette, per esempio '
                                    '`rete "api.meteo.it"`.')


def _normalizza_valore(categoria: str, valore: str) -> str:
    v = valore.strip()
    if categoria == "rete":
        return _host(v) or v.lower()
    if categoria == "hardware":
        return v.lower()
    return v


_RIGA_PERMESSI = re.compile(r"^\s*#?\s*permessi\s*:(.*)$", re.IGNORECASE)
_ELEMENTO = re.compile(r'"([^"]*)"|([^\s",]+)|(,)')


def leggi_dichiarazione(sorgente: str) -> Dichiarazione:
    """La riga ``permessi: ...`` in cima al sorgente (prima del codice), se c'è.

    ``ErroreValore`` in italiano se la riga c'è ma non si capisce."""
    for riga in sorgente.splitlines():
        testo = riga.strip()
        if not testo:
            continue
        m = _RIGA_PERMESSI.match(testo)
        if m:
            return _analizza_elenco(m.group(1), "in cima al programma")
        if testo.startswith("#"):
            continue
        break           # prima riga di codice: niente dichiarazione
    return Dichiarazione()


def _analizza_elenco(testo: str, dove: str) -> Dichiarazione:
    regole: dict[str, Regola] = {}
    gruppi: list[list[tuple[str, bool]]] = [[]]
    for m in _ELEMENTO.finditer(testo.split(" # ")[0]):
        if m.group(3):
            gruppi.append([])
        elif m.group(1) is not None:
            gruppi[-1].append((m.group(1), True))
        else:
            gruppi[-1].append((m.group(2), False))
    precedente: str | None = None
    for gruppo in gruppi:
        if not gruppo:
            continue
        nome, tra_virgolette = gruppo[0]
        if tra_virgolette and precedente is not None and all(q for _, q in gruppo):
            gruppo = [(precedente, False), *gruppo]      # rete "a.it", "b.it"
            nome, tra_virgolette = gruppo[0]
        if tra_virgolette:
            raise ErroreValore(f"Nei permessi {dove} ogni voce comincia con la categoria, non con \"{nome}\".",
                               suggerimento='Per esempio `rete "api.meteo.it"`.')
        categoria = _categoria(nome, dove)
        valori = [v for v, q in gruppo[1:] if q]
        parole = [v for v, q in gruppo[1:] if not q]
        nuova = _regola_da_parole(categoria, valori, parole, dove)
        vecchia = regole.get(categoria)
        if vecchia is not None and vecchia.modo == "elenco" and nuova.modo == "elenco":
            nuova = Regola("elenco", vecchia.valori + nuova.valori)     # rete "a", rete "b"
        regole[categoria] = nuova
        precedente = categoria
    return Dichiarazione(regole, "programma")


def dichiarazione_da_toml(dati: Any) -> Dichiarazione:
    """La sezione ``[permessi]`` di ``progetto.toml`` (dizionario) come :class:`Dichiarazione`."""
    if not dati:
        return Dichiarazione()
    if not isinstance(dati, dict):
        raise ErroreValore("In `progetto.toml` la sezione [permessi] deve contenere voci come `rete = [\"sito.it\"]`.")
    regole: dict[str, Regola] = {}
    dove = "di progetto.toml"
    for chiave, valore in dati.items():
        categoria = _categoria(str(chiave), dove)
        if isinstance(valore, bool):
            regole[categoria] = Regola("si" if valore else "no")
        elif isinstance(valore, str):
            parola = valore.strip().lower()
            if parola in _SI or parola in _NO or parola in _CHIEDI:
                regole[categoria] = _regola_da_parole(categoria, [], [parola], dove)
            else:
                regole[categoria] = _regola_da_parole(categoria, [valore], [], dove)
        elif isinstance(valore, list) and all(isinstance(v, str) for v in valore):
            regole[categoria] = _regola_da_parole(categoria, list(valore), [], dove) if valore else Regola("no")
        else:
            raise ErroreValore(f"In `progetto.toml`, [permessi] {chiave} deve essere sì/no/chiedi o un elenco di testi.")
    return Dichiarazione(regole, "progetto.toml")


def regola_predefinita(categoria: str) -> Regola:
    """Senza dichiarazione: file e rete hanno una parte libera (vedi :meth:`Politica.libero`), poi si chiede."""
    return Regola("chiedi")


# ===========================================================================
# Risorse: percorsi e indirizzi
# ===========================================================================

def _normale(percorso: str) -> str:
    return os.path.normcase(os.path.realpath(os.path.abspath(os.path.expanduser(percorso))))


def dentro(percorso: str, radice: str) -> bool:
    """Vero se ``percorso`` è ``radice`` o sta sotto di essa (dopo i collegamenti simbolici)."""
    p, r = _normale(percorso), _normale(radice)
    try:
        return os.path.commonpath([p, r]) == r
    except ValueError:          # dischi diversi su Windows
        return False


def _host(indirizzo: str) -> str | None:
    """Il nome del computer di un indirizzo (``https://api.meteo.it:443/x`` -> ``api.meteo.it``)."""
    testo = str(indirizzo).strip()
    if not testo:
        return None
    if "://" in testo:
        from urllib.parse import urlsplit

        try:
            host = urlsplit(testo).hostname
        except ValueError:
            return None
        return host.lower() if host else None
    if testo.startswith("mailto:"):
        testo = testo[7:]
    if "@" in testo:
        testo = testo.rsplit("@", 1)[1]
    testo = testo.split("/", 1)[0]
    if testo.startswith("["):           # [::1]:8080
        return testo[1:testo.find("]")].lower() if "]" in testo else None
    if testo.count(":") == 1:
        testo = testo.split(":", 1)[0]
    if not testo or " " in testo:
        return None
    return testo.lower()


def e_locale(host: str | None) -> bool:
    """``localhost``, 127.x.x.x, ::1 e simili: questo stesso computer."""
    if not host:
        return False
    h = host.lower().rstrip(".")
    if h in ("localhost", "localhost.localdomain", "ip6-localhost") or h.endswith(".localhost"):
        return True
    import ipaddress

    try:
        ip = ipaddress.ip_address(h)
    except ValueError:
        return False
    return ip.is_loopback or ip.is_unspecified


def host_corrisponde(host: str, modello: str) -> bool:
    """``api.meteo.it`` va bene per ``api.meteo.it``, ``*.meteo.it`` e ``meteo.it`` (sottodomini compresi)."""
    h, m = host.lower().rstrip("."), modello.lower().rstrip(".")
    if m in ("*", ""):
        return True
    if m.startswith("*."):
        return h.endswith(m[1:]) or h == m[2:]
    return h == m or h.endswith("." + m)


# ===========================================================================
# Classificazione delle funzioni (la tabella centrale)
# ===========================================================================

#: Nomi dei parametri che contengono un percorso di file o cartella.
PARAMETRI_PERCORSO = frozenset({
    "percorso", "percorsi", "cartella", "origine", "destinazione", "archivio", "file", "nome_file",
    "cartella_lavoro", "cartella_destinazione", "file_destinazione", "sorgente_file", "immagine_file",
    "percorso_file", "percorso_cartella", "sorgente", "allegati", "allegato",
})

#: Parametri-percorso che valgono solo in un modulo (altrove lo stesso nome è un testo qualunque:
#: ``menu(..., uscita = "Esci")``, ``modello_html(modello, ...)``).
PARAMETRI_PERCORSO_MODULO: dict[str, frozenset[str]] = {
    "ufficio": frozenset({"uscita", "sorgenti", "immagini", "modello"}),
    "immagini": frozenset({"immagini"}),
}

#: Parametri che contengono l'indirizzo di un computer (per la categoria ``rete``).
PARAMETRI_INDIRIZZO = ("indirizzo", "url", "sito", "server", "host", "destinatario_host", "indirizzi", "pagina_web")


@dataclass(frozen=True)
class Custodia:
    """Che cosa controllare per una funzione.

    ``categoria``: categoria fissa (o None: solo i percorsi); ``dispositivo``: per
    ``hardware``; ``percorsi``: controllare i parametri-percorso (categoria ``file``)."""

    categoria: str | None = None
    dispositivo: str | None = None
    percorsi: bool = False
    concede: bool = False         # il risultato (percorsi scelti dall'utente in un dialogo) diventa permesso
    extra: frozenset = frozenset()  # altri parametri-percorso di questo modulo (PARAMETRI_PERCORSO_MODULO)


#: modulo della libreria (ultimo pezzo del nome) -> (categoria predefinita, {nome: categoria o None})
#: ``None`` come categoria del modulo: solo le eccezioni e i percorsi. Le eccezioni accettano
#: modelli (``scegli_*``). Le funzioni che solo calcolano (non toccano niente) sono ``None``.
MODULI: dict[str, tuple[str | None, dict[str, str | None]]] = {
    "internet": ("rete", {
        "spiega_stato_http": None, "codifica_url": None, "decodifica_url": None, "componi_url": None,
        "server_web": None, "rispondi": None, "server_web.*": None,   # server su questo computer
    }),
    "rete_sistema": ("rete", {
        "e_indirizzo_ip": None, "indirizzo_in_rete": None, "info_indirizzo_ip": None,
        "sistema_operativo": None, "memoria_sistema": None, "spazio_disco": None, "info_sistema": "sistema",
        "avvia_in_sfondo": "processi", "osserva_cartella": "file", "porta_libera": None,
    }),
    # tutto in "piattaforma" solo LEGGE la configurazione del computer (processori, carico, PATH, separatori):
    # non tocca niente e non esegue niente, quindi nessuna funzione chiede permessi.
    "piattaforma": (None, {}),
    "rete_bassa": ("rete", {
        # catture: aprirle/scriverle tocca il disco; analizzarle (metodi di `cattura`) non tocca niente
        "apri_cattura": "file", "genera_cattura_prova": "file",
        "certificato_da_file": "file", "controlla_catena_file": "file",
        "cattura.*": None,
        # informazioni del proprio sistema (lettura della configurazione locale)
        "interfacce_rete": "sistema", "indirizzi_locali": "sistema", "indirizzo_locale": "sistema",
        "connessioni_aperte": "sistema", "tabella_routing": "sistema", "gateway_predefinito": "sistema",
        "server_dns_sistema": "sistema",
        # analisi di una cattura già aperta: non tocca niente
        "riassunto_cattura": None, "estrai_payload": None,
        # il resto (DNS via rete, certificati TLS, indirizzo pubblico) -> categoria "rete"
    }),
    "web": ("rete", {
        "analizza_html": None, "html_in_testo": None, "proteggi_html": None, "tabella_in_html": None,
        "modello_html": None, "parti_url": None, "dominio_url": None, "parametri_url": None,
        "url_assoluto": None, "e_url": None, "risposta_web": None, "reindirizza": None, "sito_web": None,
        "sessione_web": None,               # crearla non collega niente: lo fanno i suoi metodi
    }),
    "web_pro": ("rete", {
        # il cliente (ottieni_pagina, invia_json, invia_dati) -> rete (categoria del modulo)
        "componi_risposta": None,           # solo costruisce un dizionario di risposta
        "crea_server_web": None, "aggiungi_rotta": None, "ferma_server": None,
        "avvia_server": None,               # server su questo computer (come `server_web`)
        "server_web_pro.*": None, "risposta_web.*": None,
    }),
    "sistema": ("sistema", {
        "pid_corrente": None, "architettura": None, "versione_windows": None, "info_windows": None,
        "tempo_accensione": None, "tempo_accensione_testo": None,
        "cartella_*": None, "sezioni_impostazioni": None, "espandi_variabili_ambiente": "sistema",
        "*appunti*": "appunti", "copia_file_negli_appunti": "appunti",
        "elenca_processi": "processi", "trova_processi": "processi", "processo_esiste": "processi",
        "termina_processo": "processi", "avvia_programma": "processi",
        "apri_con_programma_predefinito": "processi", "apri_in_esplora_file": "processi",
        "seleziona_in_esplora_file": "processi", "apri_indirizzo_web": "processi",
        "apri_impostazioni_windows": "processi", "esegui_comando": "processi", "esegui_powershell": "processi",
        "programma_predefinito": None, "nome_programma_predefinito": None,
        "sposta_nel_cestino": "file", "elementi_nel_cestino": None, "dimensione_cestino": None,
        "destinazione_collegamento": "file", "info_collegamento": "file",
    }),
    "desktop": ("sistema", {
        "numero_schermi": None, "elenca_schermi": None, "schermo_principale": None, "risoluzione_schermo": None,
        "scala_schermo": None, "area_di_lavoro": None, "frequenza_schermo": None, "mostra_notifica": None,
        "messaggio_windows": None, "domanda_windows": None, "scegli_*": None, "chiedi_colore": None,
        "tema_windows": None, "tema_scuro_attivo": None, "colore_accento": None, "suono_di_sistema": None,
        "suoni_di_sistema": None, "sfondo_desktop": None,
    }),
    "computer": ("sistema", {
        "info_batteria": None, "ha_batteria": None, "percentuale_batteria": None, "batteria_in_carica": None,
        "tempo_batteria_rimasto": None, "uso_cpu": None, "numero_core": None, "info_memoria": None,
        "memoria_totale": None, "memoria_libera": None, "uso_memoria": None, "fuso_orario": None,
        "ora_utc": None, "elenca_caratteri": None, "carattere_installato": None, "volume_principale": None,
        "e_muto": None, "luminosita_schermo": None, "spazio_libero": None, "spazio_totale": None,
        "elenca_unita": None, "info_unita": None, "numero_core_logici": None,
        "processi_piu_pesanti": "processi",
        "ip_pubblico": "rete", "invia_ping": "rete", "sincronizzazione_ora": "rete",
        "stampa_documento": "processi",
    }),
    "programmi": (None, {}),          # apri_registro: il percorso del registro si controlla come ogni file
}

#: Regole per nome valide in TUTTI i moduli (dopo la tabella del modulo): dispositivi hardware.
_NOMI_HARDWARE = (
    (re.compile(r"fotocamera|scatta_foto|registra_video"), "fotocamera"),
    (re.compile(r"microfono|registra_audio|registra_suono"), "microfono"),
    (re.compile(r"posizione_gps|gps_attuale|dove_sono|localizza"), "posizione"),
    (re.compile(r"bluetooth"), "bluetooth"),
    (re.compile(r"porta_seriale|seriale_"), "seriale"),
    (re.compile(r"\bnfc|_nfc"), "nfc"),
)

#: Funzioni che solo calcolano un percorso (niente accesso al disco): nessun controllo.
_SOLO_CALCOLO = frozenset({
    "unisci_percorso", "unisci_percorsi", "nome_file", "nome_senza_estensione", "estensione_file",
    "cambia_estensione", "cartella_di", "percorso_completo", "percorso_relativo", "dimensione_leggibile",
    "cartella_corrente", "cambia_cartella", "parti_percorso",
})


def _eccezione(tabella: dict[str, str | None], nome: str) -> tuple[bool, str | None]:
    if nome in tabella:
        return True, tabella[nome]
    for modello, categoria in tabella.items():
        if "*" in modello and _corrisponde_modello(nome, modello):
            return True, categoria
    return False, None


def _corrisponde_modello(nome: str, modello: str) -> bool:
    import fnmatch

    return fnmatch.fnmatchcase(nome, modello)


def _parametri(funzione: Callable) -> tuple[str, ...]:
    import inspect

    try:
        funzione = inspect.unwrap(funzione)     # funzioni avvolte (@functools.wraps): i parametri veri
    except ValueError:
        pass
    codice = getattr(funzione, "__code__", None)
    if codice is None:
        return ()
    n = codice.co_argcount + codice.co_kwonlyargcount
    return tuple(codice.co_varnames[:n])


def classifica(modulo: str, nome: str, funzione: Callable | None = None) -> Custodia | None:
    """La :class:`Custodia` di una funzione della libreria, o None se non tocca niente.

    ``modulo``: nome del modulo Python (``leo.libreria.internet``) o il suo ultimo pezzo;
    ``nome``: nome Leo della funzione (per i metodi ``tipo.nome`` o solo ``nome``)."""
    breve = modulo.rsplit(".", 1)[-1]
    semplice = nome.rsplit(".", 1)[-1]
    categoria: str | None = None
    trovata = False
    voce = MODULI.get(breve)
    if voce is not None:
        trovata, categoria = _eccezione(voce[1], nome)
        if not trovata and nome != semplice:
            trovata, categoria = _eccezione(voce[1], semplice)
        if not trovata:
            categoria = voce[0]
    dispositivo = None
    if categoria is None and not trovata:
        for modello, disp in _NOMI_HARDWARE:
            if modello.search(semplice):
                categoria, dispositivo = "hardware", disp
                break
    if categoria == "file":
        return Custodia("file", percorsi=True)
    if categoria is not None:
        return Custodia(categoria, dispositivo)
    if _DIALOGHI_FILE.match(semplice):
        return Custodia(None, concede=True)
    if trovata or semplice in _SOLO_CALCOLO:    # eccezione esplicita: non tocca niente
        return None
    extra = PARAMETRI_PERCORSO_MODULO.get(breve, frozenset())
    if funzione is not None and (PARAMETRI_PERCORSO | extra).intersection(_parametri(funzione)):
        return Custodia(None, percorsi=True, extra=extra)
    return None


#: Dialoghi in cui l'utente sceglie un file: ciò che sceglie diventa permesso (l'ha deciso lui).
_DIALOGHI_FILE = re.compile(r"^(scegli_(file|piu_file|cartella)|chiedi_file|chiedi_cartella)")


# ===========================================================================
# Il custode
# ===========================================================================

_ATTIVA: "Politica | None" = None
_BLOCCO = _thread.RLock()


def politica_attiva() -> "Politica | None":
    return _ATTIVA


def attiva(politica: "Politica | None") -> "Politica | None":
    """Rende ``politica`` quella in vigore (per tutto il processo); restituisce la precedente."""
    global _ATTIVA
    precedente = _ATTIVA
    _ATTIVA = politica
    return precedente


def disattiva() -> None:
    attiva(None)


@contextmanager
def in_uso(politica: "Politica | None") -> Iterator["Politica | None"]:
    precedente = attiva(politica)
    try:
        yield politica
    finally:
        attiva(precedente)


def nuovo_interprete(interprete: Any) -> None:
    """Chiamata da ``Interprete.__init__``: la politica attiva conosce il suo interprete (per chiedere)."""
    p = _ATTIVA
    if p is not None and p.interprete is None:
        p.interprete = interprete


def _avvolgi(funzione: Callable, nome: str, custodia: Custodia) -> Callable:
    if getattr(funzione, "__leo_custodia__", None) is not None:
        return funzione
    firma_memo: list = []

    @functools.wraps(funzione)
    def custode(*argomenti: Any, **per_nome: Any) -> Any:
        politica = _ATTIVA
        if politica is None:
            return funzione(*argomenti, **per_nome)
        if custodia.concede:
            risultato = funzione(*argomenti, **per_nome)
            politica.concedi_scelti(risultato)
            return risultato
        politica.controlla_chiamata(nome, custodia, funzione, firma_memo, argomenti, per_nome)
        return funzione(*argomenti, **per_nome)

    custode.__leo_custodia__ = custodia  # type: ignore[attr-defined]
    return custode


def proteggi(nativa: Any, modulo: str | None = None, nome: str | None = None) -> Any:
    """Se la funzione nativa tocca qualcosa di protetto, avvolge la sua ``funzione`` con il custode.

    Restituisce ``nativa`` (cambiata sul posto). Chiamata da ``registro.inserisci`` e
    da ``oggetti.metodo_oggetto``: tutte le funzioni della libreria passano di qui."""
    funzione = getattr(nativa, "__dict__", {}).get("funzione")
    if funzione is None or getattr(funzione, "__leo_custodia__", None) is not None:
        return nativa
    modulo = modulo or getattr(funzione, "__module__", "") or ""
    if not modulo.startswith("leo."):
        return nativa
    nome = nome or getattr(nativa, "nome", "") or getattr(funzione, "__name__", "")
    custodia = classifica(modulo, nome, funzione)
    if custodia is not None:
        nativa.funzione = _avvolgi(funzione, nome, custodia)
    return nativa


#: Controlli grafici -> (categoria, dispositivo); i metodi in ``_METODI_LIBERI`` non chiedono.
CONTROLLI: dict[str, tuple[str, str | None]] = {
    "Fotocamera": ("hardware", "fotocamera"),
    "LettoreQR": ("hardware", "fotocamera"),
    "Torcia": ("hardware", "torcia"),
    "Dettatura": ("hardware", "microfono"),
    "Posizione": ("hardware", "posizione"),
    "PortaSeriale": ("hardware", "seriale"),
    "SchedaPico": ("hardware", "seriale"),
    "RichiestaWeb": ("rete", None),
    "Assistente": ("rete", None),
    "Appunti": ("appunti", None),
    "Fonometro": ("hardware", "microfono"),
    "RegistratoreAudio": ("hardware", "microfono"),
}
#: Metodi dei controlli in cui l'utente sceglie un file (ciò che sceglie diventa permesso).
_DIALOGHI_CONTROLLI = frozenset({("DialogoFile", "mostra")})
_METODI_LIBERI = frozenset({"ferma", "chiudi", "disconnetti", "spegni", "distanza_da", "mostra", "nascondi",
                            "azzera", "riproduci"})
#: Metodi dei controlli che scrivono un file (il primo argomento è il percorso).
_METODI_SALVA = frozenset({"salva", "esporta"})


def proteggi_controllo(tipo_controllo: str, nome_metodo: str, controllo: Any, nativa: Any) -> Any:
    """Custode per il metodo di un controllo grafico (``Fotocamera1.scatta()``)."""
    if _ATTIVA is None:
        return nativa
    if (tipo_controllo, nome_metodo) in _DIALOGHI_CONTROLLI:
        scegli = nativa.funzione

        def custode_dialogo(*argomenti: Any, **per_nome: Any) -> Any:
            risultato = scegli(*argomenti, **per_nome)
            politica = _ATTIVA
            if politica is not None:
                politica.concedi_scelti(risultato)      # l'ha scelto l'utente: il programma lo può usare
            return risultato

        nativa.funzione = custode_dialogo
        return nativa
    voce = CONTROLLI.get(tipo_controllo)
    if voce is not None and nome_metodo not in _METODI_LIBERI:
        categoria, dispositivo = voce
        funzione = nativa.funzione

        def custode(*argomenti: Any, **per_nome: Any) -> Any:
            politica = _ATTIVA
            if politica is not None:
                risorsa = dispositivo
                if categoria == "rete":
                    risorsa = None
                    for p in ("indirizzo", "url"):
                        try:
                            valore = controllo.leggi(p)
                        except Exception:  # noqa: BLE001 - proprietà assente
                            continue
                        if isinstance(valore, str) and valore:
                            risorsa = _host(valore)
                            break
                    for a in argomenti[1:]:
                        if isinstance(a, str) and "://" in a:
                            risorsa = _host(a)
                politica.verifica(categoria, risorsa, f"{getattr(controllo, 'nome', tipo_controllo)}.{nome_metodo}")
            return funzione(*argomenti, **per_nome)

        nativa.funzione = custode
    elif nome_metodo in _METODI_SALVA:
        funzione = nativa.funzione

        def custode_file(*argomenti: Any, **per_nome: Any) -> Any:
            politica = _ATTIVA
            if politica is not None:
                for a in list(argomenti[1:2]) + [per_nome.get("percorso")]:
                    if isinstance(a, str) and a:
                        politica.verifica_percorso(a, f"{getattr(controllo, 'nome', tipo_controllo)}.{nome_metodo}")
            return funzione(*argomenti, **per_nome)

        nativa.funzione = custode_file
    return nativa


# ===========================================================================
# Ricordi: le scelte dell'utente restano valide (per programma)
# ===========================================================================

def _file_ricordi() -> "Path":
    from pathlib import Path

    from . import variabile_ambiente

    scelto = variabile_ambiente("PERMESSI_FILE")
    if scelto:
        return Path(scelto)
    from .percorsi import cartella_utente

    return cartella_utente() / "permessi.json"


_BLOCCO_RICORDI = _thread.allocate_lock()


def leggi_ricordi() -> dict:
    try:
        with open(_file_ricordi(), "r", encoding="utf-8") as f:
            testo = f.read()
    except OSError:
        return {}            # nessun ricordo ancora: niente da leggere (niente import di json)
    try:
        import json

        dati = json.loads(testo)
        return dati if isinstance(dati, dict) else {}
    except ValueError:
        return {}


def _salva_ricordi(dati: dict) -> None:
    import json

    file = _file_ricordi()
    try:
        file.parent.mkdir(parents=True, exist_ok=True)
        temporaneo = file.with_suffix(".tmp")
        with open(temporaneo, "w", encoding="utf-8") as f:
            json.dump(dati, f, ensure_ascii=False, indent=1, sort_keys=True)
        os.replace(temporaneo, file)
    except OSError:
        pass            # ricordare è una comodità: se non si può, si chiederà di nuovo


def chiave_programma(percorso: str | os.PathLike) -> str:
    return _normale(os.fspath(percorso))


def ricordi_di(chiave: str) -> dict:
    with _BLOCCO_RICORDI:
        return dict(leggi_ricordi().get(chiave, {}))


def ricorda(chiave: str, *, concessi: Iterable[tuple[str, str]] = (), approvata: str | None = None) -> None:
    with _BLOCCO_RICORDI:
        dati = leggi_ricordi()
        voce = dati.setdefault(chiave, {})
        elenco = [list(x) for x in voce.get("concessi", [])]
        for c in concessi:
            if list(c) not in elenco:
                elenco.append(list(c))
        voce["concessi"] = elenco
        if approvata is not None:
            voce["dichiarazione_approvata"] = approvata
        _salva_ricordi(dati)


def dimentica(chiave: str | None = None) -> bool:
    """Cancella le scelte ricordate per un programma (o tutte con ``None``); vero se c'erano."""
    with _BLOCCO_RICORDI:
        dati = leggi_ricordi()
        if chiave is None:
            c = bool(dati)
            dati = {}
        else:
            c = dati.pop(chiave, None) is not None
        _salva_ricordi(dati)
        return c


# ===========================================================================
# Politica: le regole di un'esecuzione
# ===========================================================================

@dataclass
class Domanda:
    """Una richiesta di permesso da mostrare a chi usa il programma."""

    categoria: str
    risorsa: str | None
    funzione: str
    programma: str

    def testo(self) -> str:
        cosa = descrivi_risorsa(self.categoria, self.risorsa)
        return (f"Il programma «{self.programma}» vuole {cosa} (con `{self.funzione}`).\n"
                f"Permesso «{self.categoria}»: {DESCRIZIONI[self.categoria]}.")


def descrivi_risorsa(categoria: str, risorsa: str | None) -> str:
    if categoria == "file":
        if not risorsa:
            return "usare file fuori dalla sua cartella"
        if os.path.isfile(risorsa) or (os.path.splitext(risorsa.rstrip("/\\"))[1] and not os.path.isdir(risorsa)):
            return f"usare il file {risorsa}"
        return f"usare i file in {risorsa}"
    if categoria == "rete":
        return f"collegarsi a {risorsa}" if risorsa else "collegarsi a Internet"
    if categoria == "hardware":
        return f"usare {_ARTICOLI.get(risorsa or '', risorsa or 'l’hardware')}" if risorsa else "usare l’hardware"
    return {"sistema": "usare le impostazioni del computer", "processi": "avviare o controllare altri programmi",
            "appunti": "usare gli appunti"}[categoria]


_ARTICOLI = {"fotocamera": "la fotocamera", "microfono": "il microfono", "posizione": "la posizione (GPS)",
             "torcia": "la torcia", "seriale": "la porta seriale", "bluetooth": "il Bluetooth", "usb": "l’USB",
             "nfc": "l’NFC", "sensori": "i sensori"}

#: Risposte di una richiesta.
SI, SEMPRE, NO = "si", "sempre", "no"


class Politica:
    """Le regole di un'esecuzione: dichiarazione, predefiniti, permessi concessi.

    ``chiedi``: funzione ``(politica, Domanda) -> "si" | "sempre" | "no" | None`` (None = non si
    può chiedere); predefinita :func:`chiedi_automatico`."""

    def __init__(self, *, programma: str = "programma", cartella: str | None = None,
                 dichiarazione: Dichiarazione | None = None, permetti_tutto: bool = False,
                 permetti: Iterable[str] = (), chiave: str | None = None,
                 approvata: bool = False, chiedi: Callable | None = None,
                 cartella_corrente: str | None = None, ricorda_scelte: bool = True) -> None:
        self.programma = programma
        self.cartella = os.path.abspath(cartella) if cartella else None
        self.dichiarazione = dichiarazione or Dichiarazione()
        self.permetti_tutto = permetti_tutto
        self.permessi_forzati = {_categoria(c, "di --permetti") for c in permetti}
        self.chiave = chiave
        self.approvata = approvata
        self.chiedi = chiedi if chiedi is not None else chiedi_automatico
        self.interprete: Any = None
        self.ricorda_scelte = ricorda_scelte and chiave is not None
        self.concessi: set[tuple[str, str]] = set()
        self.negati: set[tuple[str, str]] = set()
        self.registro: list[tuple[str, str, str]] = []      # (categoria, risorsa, esito) per i test e Studio
        self.firma: Any = None                               # leo.firma_codice.EsitoFirma, se firmato
        self._blocco = _thread.RLock()
        radici = []
        if self.cartella:
            radici.append(self.cartella)
        corrente = cartella_corrente if cartella_corrente is not None else _cartella_corrente_sicura()
        if corrente:
            radici.append(corrente)
        import tempfile

        radici.append(tempfile.gettempdir())
        self.radici_libere = radici
        if chiave is not None:
            ricordi = ricordi_di(chiave)
            for c in ricordi.get("concessi", []):
                if isinstance(c, list) and len(c) == 2:
                    self.concessi.add((str(c[0]), str(c[1])))
            # `self.dichiarazione` per primo: senza dichiarazione non si calcola
            # l'impronta (niente hashlib all'avvio per un programma senza permessi)
            if self.dichiarazione and ricordi.get("dichiarazione_approvata") == self.dichiarazione.impronta():
                self.approvata = True

    # --- regole -----------------------------------------------------------------
    def regola(self, categoria: str) -> Regola:
        return self.dichiarazione.regole.get(categoria) or regola_predefinita(categoria)

    def libero(self, categoria: str, risorsa: str | None) -> bool:
        """Permesso senza chiedere niente a nessuno (predefiniti prudenti)."""
        if categoria == "file" and risorsa:
            return any(dentro(risorsa, r) for r in self.radici_libere)
        if categoria == "rete" and "rete" not in self.dichiarazione.regole:
            return e_locale(risorsa)
        return False

    def _nel_recinto(self, regola: Regola, categoria: str, risorsa: str | None) -> bool:
        if not risorsa:
            return False
        for v in regola.valori:
            if categoria == "file":
                base = v if os.path.isabs(os.path.expanduser(v)) else os.path.join(self.cartella or os.getcwd(), v)
                if dentro(risorsa, base):
                    return True
            elif categoria == "rete":
                if host_corrisponde(risorsa, v):
                    return True
            elif risorsa.lower() == v.lower():
                return True
        return False

    def _concesso(self, categoria: str, risorsa: str | None) -> bool:
        for c, r in self.concessi:
            if c != categoria:
                continue
            if r == "*" or r == (risorsa or "*"):
                return True
            if categoria == "file" and risorsa and dentro(risorsa, r):
                return True
            if categoria == "rete" and risorsa and host_corrisponde(risorsa, r):
                return True
        return False

    # --- verifica ------------------------------------------------------------------
    def verifica(self, categoria: str, risorsa: str | None, funzione: str) -> None:
        """Niente se il permesso c'è (eventualmente dopo averlo chiesto); altrimenti ``ErrorePermesso``."""
        if self.permetti_tutto or categoria in self.permessi_forzati:
            return
        if self.libero(categoria, risorsa):
            return
        self._verifica_pacchetto(categoria, risorsa, funzione)
        regola = self.regola(categoria)
        if regola.modo == "no":
            self._annota(categoria, risorsa, "negato dalla dichiarazione")
            raise ErrorePermesso(
                f"`{funzione}` vuole {descrivi_risorsa(categoria, risorsa)}, ma il programma stesso ha dichiarato "
                f"`{categoria} no` nei permessi.",
                suggerimento="Se serve davvero, cambia la riga `permessi:` in cima al programma "
                             f"(per esempio `{categoria} chiedi`).")
        if regola.modo == "elenco" and not self._nel_recinto(regola, categoria, risorsa):
            self._annota(categoria, risorsa, "fuori dalla dichiarazione")
            raise ErrorePermesso(
                f"`{funzione}` vuole {descrivi_risorsa(categoria, risorsa)}, ma il programma ha dichiarato "
                f"solo {categoria} {regola.testo()}.",
                suggerimento=f"Aggiungi la risorsa alla riga `permessi:` (per esempio `{categoria} "
                             f"{regola.testo()}, \"{risorsa or '...'}\"`).")
        if self._concesso(categoria, risorsa):
            return
        if regola.modo in ("si", "elenco") and self.approvata:
            return
        self._chiedi_o_nega(categoria, risorsa, funzione)

    def _verifica_pacchetto(self, categoria: str, risorsa: str | None, funzione: str) -> None:
        """Il codice di un pacchetto Leo installato usa solo le categorie che ha dichiarato
        (``permessi`` in pacchetto.toml, vedi :mod:`leo.permessi_pacchetti`)."""
        interprete = self.interprete
        file_chiamante = getattr(interprete, "_file_corrente", None) if interprete is not None else None
        if not file_chiamante:
            return
        percorsi = getattr(interprete, "__dict__", {}).get("file_dei_moduli") or {}
        file_chiamante = percorsi.get(file_chiamante, file_chiamante)
        if ".leo" not in str(file_chiamante):
            return
        from .permessi_pacchetti import controlla_categoria

        dispositivo = risorsa if categoria == "hardware" else None
        try:
            controlla_categoria(file_chiamante, categoria, dispositivo, funzione)
        except ErrorePermesso:
            self._annota(categoria, risorsa, "negato al pacchetto")
            raise

    def verifica_percorso(self, percorso: str, funzione: str) -> None:
        if "://" in percorso:
            schema = percorso.split("://", 1)[0].lower()
            if schema in ("http", "https", "ftp", "ws", "wss"):
                self.verifica("rete", _host(percorso), funzione)
                return
            if schema == "file":
                from urllib.parse import urlsplit
                percorso = urlsplit(percorso).path
            else:
                return
        if percorso.startswith(":") or percorso in ("", ":memoria:", ":memory:"):
            return
        self.verifica("file", os.path.abspath(os.path.expanduser(percorso)), funzione)

    def _chiedi_o_nega(self, categoria: str, risorsa: str | None, funzione: str) -> None:
        ambito = self._ambito(categoria, risorsa)
        with self._blocco:
            if (categoria, ambito) in self.negati:
                raise self._errore_negato(categoria, risorsa, funzione)
            if self._concesso(categoria, risorsa):
                return
            domanda = Domanda(categoria, risorsa, funzione, self.programma)
            try:
                risposta = self.chiedi(self, domanda)
            except ErrorePermesso:
                raise
            except Exception:  # noqa: BLE001 - una domanda che non riesce vale come "non posso chiedere"
                risposta = None
            if risposta is None:
                self._annota(categoria, risorsa, "non chiesto")
                raise self._errore_senza_domanda(categoria, risorsa, funzione)
            if risposta in (SI, SEMPRE):
                self.concessi.add((categoria, ambito))
                self._annota(categoria, risorsa, "concesso")
                if risposta == SEMPRE and self.ricorda_scelte and self.chiave:
                    ricorda(self.chiave, concessi=[(categoria, ambito)])
                return
            self.negati.add((categoria, ambito))
            self._annota(categoria, risorsa, "negato")
            raise self._errore_negato(categoria, risorsa, funzione)

    def _ambito(self, categoria: str, risorsa: str | None) -> str:
        """Fin dove vale un sì: la cartella per i file, il computer per la rete, tutta la categoria per il resto."""
        if not risorsa:
            return "*"
        if categoria == "file":
            return risorsa if os.path.isdir(risorsa) else os.path.dirname(risorsa) or risorsa
        return risorsa

    def _annota(self, categoria: str, risorsa: str | None, esito: str) -> None:
        if len(self.registro) < 1000:
            self.registro.append((categoria, risorsa or "", esito))

    def _errore_negato(self, categoria: str, risorsa: str | None, funzione: str) -> ErrorePermesso:
        return ErrorePermesso(f"Permesso negato: `{funzione}` non può {descrivi_risorsa(categoria, risorsa)}.",
                              suggerimento="Hai risposto di no. Se ti fidi del programma, rieseguilo e rispondi sì.")

    def _errore_senza_domanda(self, categoria: str, risorsa: str | None, funzione: str) -> ErrorePermesso:
        cosa = descrivi_risorsa(categoria, risorsa)
        esempio = f'{categoria} "{risorsa}"' if risorsa and categoria in ("rete", "file", "hardware") else f"{categoria} sì"
        return ErrorePermesso(
            f"`{funzione}` vuole {cosa}: serve il permesso «{categoria}», ma qui non posso chiederlo "
            f"(il programma non gira in un terminale né in una finestra).",
            suggerimento=f"Eseguilo da un terminale per rispondere, oppure aggiungi `--permetti {categoria}` "
                         f"(o `--permetti-tutto` se ti fidi del programma). Puoi anche dichiararlo in cima al "
                         f"programma con `permessi: {esempio}` e approvarlo una volta.")

    # --- approvazione della dichiarazione ---------------------------------------------
    def serve_approvazione(self) -> bool:
        """Vero se la dichiarazione concede più dei predefiniti e nessuno l'ha ancora approvata."""
        if self.permetti_tutto or self.approvata:
            return False
        return bool(voci_da_approvare(self.dichiarazione, self))

    def approva(self, *, ricorda_scelta: bool = True) -> None:
        self.approvata = True
        if ricorda_scelta and self.ricorda_scelte and self.chiave:
            ricorda(self.chiave, approvata=self.dichiarazione.impronta())

    def concedi(self, categoria: str, risorsa: str = "*", *, ricorda_scelta: bool = False) -> None:
        self.concessi.add((categoria, risorsa))
        if ricorda_scelta and self.ricorda_scelte and self.chiave:
            ricorda(self.chiave, concessi=[(categoria, risorsa)])

    def concedi_scelti(self, risultato: Any) -> None:
        """Percorsi scelti dall'utente in un dialogo: il programma li può usare."""
        for p in (risultato if isinstance(risultato, (list, tuple)) else [risultato]):
            if isinstance(p, str) and p:
                completo = os.path.abspath(os.path.expanduser(p))
                self.concessi.add(("file", completo))

    # --- dal custode delle funzioni -----------------------------------------------------
    def controlla_chiamata(self, nome: str, custodia: Custodia, funzione: Callable, memo: list,
                           argomenti: tuple, per_nome: dict) -> None:
        if self.permetti_tutto:
            return
        valori = _argomenti_per_nome(funzione, memo, argomenti, per_nome)
        if valori.get("senza_conferma") is True:
            # `senza_conferma = vero` salta la conferma della funzione, non il permesso
            nome = f"{nome}(senza_conferma = vero)"
        if custodia.categoria is not None and custodia.categoria != "file":
            risorsa = custodia.dispositivo
            if custodia.categoria == "rete":
                risorsa = _indirizzo_da(valori)
                if risorsa is not None and e_locale(risorsa) and nome in _SERVER_LOCALI:
                    return
            self.verifica(custodia.categoria, risorsa, nome)
            if custodia.categoria != "rete":
                return
            # rete: anche dove finiscono i file scaricati (scarica_file) o da dove partono gli allegati
        if custodia.percorsi or custodia.categoria in ("file", "rete"):
            trovato = False
            for parametro, valore in valori.items():
                if parametro not in PARAMETRI_PERCORSO and parametro not in custodia.extra:
                    continue
                for p in (valore if isinstance(valore, (list, tuple)) else [valore]):
                    if isinstance(p, str) and p:
                        trovato = True
                        self.verifica_percorso(p, nome)
                    elif isinstance(p, os.PathLike):
                        trovato = True
                        self.verifica_percorso(os.fspath(p), nome)
            if not trovato and custodia.categoria == "file":  # una funzione di file senza percorso leggibile
                self.verifica("file", None, nome)


_SERVER_LOCALI = frozenset({"server_tcp", "server_web"})


def _argomenti_per_nome(funzione: Callable, memo: list, argomenti: tuple, per_nome: dict) -> dict:
    """Gli argomenti di una chiamata per nome di parametro (con i valori predefiniti)."""
    if not memo:
        import inspect

        try:
            firma = inspect.signature(funzione)
        except (TypeError, ValueError):
            firma = None
        memo.append(firma)
    firma = memo[0]
    if firma is None:
        return dict(per_nome)
    try:
        legati = firma.bind_partial(*argomenti, **per_nome)
    except TypeError:
        return dict(per_nome)       # argomenti sbagliati: l'errore lo darà la funzione stessa
    legati.apply_defaults()
    return dict(legati.arguments)


def _indirizzo_da(valori: dict) -> str | None:
    for p in PARAMETRI_INDIRIZZO:
        v = valori.get(p)
        if isinstance(v, str) and v.strip():
            return _host(v)
        if isinstance(v, (list, tuple)):
            for x in v:
                if isinstance(x, str) and x.strip():
                    return _host(x)
    for v in valori.values():
        if isinstance(v, str) and "://" in v:
            return _host(v)
    return None


def _cartella_corrente_sicura() -> str | None:
    """La cartella corrente, se non è troppo larga (cartella personale, radice del disco o una loro madre)."""
    try:
        corrente = os.path.realpath(os.getcwd())
    except OSError:
        return None
    casa = os.path.realpath(os.path.expanduser("~"))
    if os.path.dirname(corrente) == corrente:          # radice
        return None
    if dentro(casa, corrente):                          # la casa o una cartella che la contiene
        return None
    return corrente


# ===========================================================================
# Come si chiede
# ===========================================================================

_BLOCCO_DOMANDE = _thread.allocate_lock()


def chiedi_automatico(politica: Politica, domanda: Domanda) -> str | None:
    """Chiede nel modo giusto: finestra se il programma ne ha, poi terminale, poi niente (None)."""
    interprete = politica.interprete
    ponte = getattr(interprete, "ponte_grafico", None) if interprete is not None else None
    with _BLOCCO_DOMANDE:
        if ponte is not None and hasattr(ponte, "domanda"):
            sì = ponte.domanda(domanda.testo() + "\n\nConsenti? La scelta vale anche le prossime volte.",
                               "Leo - permesso richiesto")
            return SEMPRE if sì else NO
        if terminale_interattivo():
            return chiedi_nel_terminale(domanda)
        if getattr(politica, "chiedi_con_ingresso", False) and interprete is not None:
            return _chiedi_con_ingresso(interprete, domanda)
    return None


def terminale_interattivo() -> bool:
    """Si può chiedere nel terminale: c'è una persona (TTY) oppure Leo Studio ha detto che risponde lui."""
    from . import variabile_ambiente

    if (variabile_ambiente("PERMESSI_DOMANDE") or "").strip() in ("1", "si", "terminale"):
        return True
    try:
        return bool(sys.stdin and sys.stdin.isatty() and sys.stderr and sys.stderr.isatty())
    except (AttributeError, ValueError, OSError):
        return False


def _risposta(testo: str) -> str | None:
    t = (testo or "").strip().lower()
    if t in ("s", "si", "sì", "y", "yes", "una", "1"):
        return SI
    if t in ("t", "sempre", "tutte", "2", "a"):
        return SEMPRE
    if t in ("n", "no", "0", ""):
        return NO
    return None


def chiedi_nel_terminale(domanda: Domanda, *, ingresso: Callable[[], str] | None = None,
                         uscita: Callable[[str], Any] | None = None) -> str:
    scrivi = uscita or (lambda t: (sys.stdout.flush(), sys.stderr.write(t), sys.stderr.flush()))
    leggi = ingresso or sys.stdin.readline
    scrivi("\n" + _riquadro("Permesso richiesto", domanda.testo().splitlines()) + "\n")
    for _ in range(3):
        scrivi("Consenti? [s = sì, questa volta / t = sì, sempre per questo programma / N = no] ")
        try:
            riga = leggi()
        except (EOFError, KeyboardInterrupt, OSError, ValueError):
            return NO
        if riga is None or riga == "":
            return NO
        r = _risposta(riga)
        if r is not None:
            return r
    return NO


def _chiedi_con_ingresso(interprete: Any, domanda: Domanda) -> str:
    """Telefono (programmi senza finestre): la richiesta arriva come domanda nella console."""
    titolo = NOMI_CATEGORIE.get(domanda.categoria, domanda.categoria)
    riga = interprete.leggi(f"Permesso richiesto ({titolo})\n{domanda.testo()}\n"
                            "Rispondi s (sì, questa volta), t (sì, sempre) o n (no): ")
    return _risposta(riga) or NO


def _riquadro(titolo: str, righe: list[str]) -> str:
    return "\n".join([f"== {titolo} ==", *(f"  {r}" for r in righe)])


# ===========================================================================
# Che cosa serve a un programma (analisi senza eseguirlo)
# ===========================================================================

@dataclass
class Bisogno:
    """Un'operazione protetta trovata nel codice."""

    categoria: str
    risorsa: str | None          # sito, cartella, dispositivo se si vede dal codice
    funzione: str
    riga: int
    file: str = ""


def _custodia_di(nome: str) -> Custodia | None:
    from . import registro

    registro.carica_libreria()
    f = registro.FUNZIONI.get(nome)
    if f is None:
        return None
    try:
        funzione = f.funzione           # importa il modulo pigro (serve solo qui)
    except AttributeError:
        return None
    custodia = getattr(funzione, "__leo_custodia__", None)
    if custodia is not None:
        return custodia
    return classifica(registro.modulo_python(f), nome, funzione)


def analizza_bisogni(sorgente: str, nome_file: str = "<sorgente>") -> list[Bisogno]:
    """Le chiamate a funzioni protette nel sorgente, con le risorse scritte come testo.

    ``scarica_json("https://api.meteo.it/oggi")`` -> Bisogno("rete", "api.meteo.it", ...).
    È un'analisi prudente dei token: trova anche le chiamate senza parentesi."""
    from .esecuzione import tokenizza
    from .tokens import TipoToken as T

    try:
        token = tokenizza(sorgente, nome_file, tollerante=True)
    except Exception:  # noqa: BLE001 - un sorgente rovinato: niente analisi
        return []
    trovati: list[Bisogno] = []
    visti: set[tuple] = set()
    memo: dict[str, Custodia | None] = {}
    for i, t in enumerate(token):
        if t.tipo is not T.NOME:
            continue
        nome = t.valore
        if nome not in memo:
            memo[nome] = _custodia_di(nome)
        custodia = memo[nome]
        if custodia is None:
            continue
        # il primo testo letterale dopo il nome (sulla stessa riga) è spesso la risorsa
        letterale = None
        for s in token[i + 1:i + 4]:
            if s.riga != t.riga:
                break
            if s.tipo is T.TESTO and isinstance(s.valore, str):
                letterale = s.valore
                break
        categoria = custodia.categoria or "file"
        risorsa: str | None = custodia.dispositivo
        if categoria == "rete":
            risorsa = _host(letterale) if letterale else None
        elif categoria == "file" or custodia.percorsi:
            if letterale is None:
                if custodia.categoria is None:
                    continue            # percorso calcolato: si vedrà durante l'esecuzione
                risorsa = None
            elif "://" in letterale and letterale.split("://")[0].lower() in ("http", "https"):
                categoria, risorsa = "rete", _host(letterale)
            else:
                risorsa = letterale
        chiave = (categoria, risorsa, nome)
        if chiave in visti:
            continue
        visti.add(chiave)
        trovati.append(Bisogno(categoria, risorsa, nome, t.riga, nome_file))
    return trovati


def bisogni_controlli(cartella: str | os.PathLike) -> list[Bisogno]:
    """Controlli protetti (Fotocamera, RichiestaWeb...) nelle finestre di un progetto."""
    from pathlib import Path

    trovati: list[Bisogno] = []
    try:
        maschere = sorted(Path(cartella).glob("*.maschera"))
    except OSError:
        return trovati
    for file in maschere:
        try:
            testo = file.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        for tipo, (categoria, dispositivo) in CONTROLLI.items():
            if re.search(r'tipo\s*=\s*"' + tipo + '"', testo):
                trovati.append(Bisogno(categoria, dispositivo, tipo, 0, file.name))
    return trovati


def voci_da_approvare(dichiarazione: Dichiarazione, politica: Politica | None = None) -> list[tuple[str, Regola]]:
    """Le voci della dichiarazione che concedono più dei predefiniti."""
    voci = []
    for categoria in CATEGORIE:
        regola = dichiarazione.regole.get(categoria)
        if regola is None or regola.modo in ("no", "chiedi"):
            continue
        if regola.modo == "elenco":
            if categoria == "file" and politica is not None and all(
                    politica.libero("file", os.path.join(politica.cartella or os.getcwd(), v)) for v in regola.valori):
                continue
            if categoria == "rete" and all(e_locale(v) for v in regola.valori):
                continue
        voci.append((categoria, regola))
    return voci


@dataclass
class Riepilogo:
    """Che cosa chiede un programma e che cosa userebbe (per `leo spiega`, Studio e telefono)."""

    programma: str
    dichiarazione: Dichiarazione
    bisogni: list[Bisogno]
    firma: Any = None                 # leo.firma_codice.EsitoFirma o None
    approvata: bool = False
    concessi: list[tuple[str, str]] = field(default_factory=list)

    def da_chiedere(self, politica: Politica | None = None) -> list[str]:
        """Righe da mostrare nella richiesta iniziale (vuoto: niente da chiedere)."""
        righe = []
        for categoria, regola in voci_da_approvare(self.dichiarazione, politica):
            righe.append(f"{NOMI_CATEGORIE[categoria]}: {regola.testo()} - {DESCRIZIONI[categoria]}")
        return righe

    def righe(self) -> list[str]:
        r: list[str] = []
        if self.firma is not None:
            r.append(f"Firma: {self.firma.descrizione()}")
        if self.dichiarazione:
            r.append(f"Dichiarati ({self.dichiarazione.origine}): {self.dichiarazione.testo()}")
            if self.approvata:
                r.append("Approvati: sì (la scelta è ricordata).")
        else:
            r.append("Il programma non dichiara permessi: valgono quelli predefiniti "
                     "(la sua cartella sì; rete, sistema e il resto chiedono la prima volta).")
        per_categoria: dict[str, list[Bisogno]] = {}
        for b in self.bisogni:
            per_categoria.setdefault(b.categoria, []).append(b)
        if not per_categoria:
            r.append("Usa: niente di protetto (solo la sua cartella e calcoli).")
        for categoria in CATEGORIE:
            elenco = per_categoria.get(categoria)
            if not elenco:
                continue
            risorse = sorted({b.risorsa for b in elenco if b.risorsa})
            funzioni = sorted({b.funzione for b in elenco})
            stato = self._stato(categoria, elenco)
            con = f"con {', '.join(f'`{f}`' for f in funzioni[:6])}{'...' if len(funzioni) > 6 else ''}"
            if categoria in ("rete", "file", "hardware"):
                dettaglio = ", ".join(risorse) if risorse else "indirizzi e percorsi calcolati durante l'esecuzione"
                r.append(f"{NOMI_CATEGORIE[categoria]}: {dettaglio} ({con}) - {stato}")
            else:
                r.append(f"{NOMI_CATEGORIE[categoria]} ({con}) - {stato}")
        return r

    def _stato(self, categoria: str, elenco: list[Bisogno]) -> str:
        from pathlib import Path

        regola = self.dichiarazione.regole.get(categoria)
        if regola is None:
            if categoria == "file" and all(b.risorsa and not os.path.isabs(os.path.expanduser(b.risorsa))
                                           and ".." not in Path(b.risorsa).parts for b in elenco):
                return "nella sua cartella: libero"
            if categoria == "rete" and elenco and all(e_locale(b.risorsa) for b in elenco):
                return "solo questo computer: libero"
            if categoria == "rete":
                return "non dichiarato: libero verso questo computer, per gli altri siti Leo chiederà"
            if categoria == "file":
                return "non dichiarato: libero nella sua cartella, altrove Leo chiederà"
            return "non dichiarato: Leo chiederà"
        if regola.modo == "no":
            return "dichiarato no: sarà negato"
        if regola.modo == "chiedi":
            return "Leo chiederà"
        if regola.modo == "si":
            return "dichiarato sì"
        fuori = [b.risorsa for b in elenco if b.risorsa and not _corrisponde_valori(categoria, b.risorsa, regola)]
        if fuori:
            return "ATTENZIONE: " + ", ".join(fuori) + " fuori dalla dichiarazione (sarà negato)"
        return "dichiarato"

    def testo(self) -> str:
        return "Permessi:\n" + "\n".join(f"- {r}" for r in self.righe())

    def a_dizionario(self) -> dict:
        return {
            "programma": self.programma,
            "dichiarati": {c: {"modo": r.modo, "valori": list(r.valori)} for c, r in self.dichiarazione.regole.items()},
            "bisogni": [{"categoria": b.categoria, "risorsa": b.risorsa, "funzione": b.funzione, "riga": b.riga,
                         "file": b.file} for b in self.bisogni],
            "righe": self.righe(),
            "da_chiedere": self.da_chiedere(),
            "approvata": self.approvata,
            "firma": self.firma.a_dizionario() if self.firma is not None else None,
        }


def _corrisponde_valori(categoria: str, risorsa: str, regola: Regola) -> bool:
    for v in regola.valori:
        if categoria == "rete" and host_corrisponde(risorsa, v):
            return True
        if categoria == "file":
            if os.path.isabs(os.path.expanduser(risorsa)):
                if not os.path.isabs(os.path.expanduser(v)):
                    continue
                if dentro(risorsa, v):
                    return True
            else:
                a = os.path.normpath(risorsa)
                b = os.path.normpath(v)
                if a == b or a.startswith(b.rstrip("/\\") + os.sep) or a.startswith(b.rstrip("/\\") + "/"):
                    return True
        if categoria not in ("rete", "file") and risorsa.lower() == v.lower():
            return True
    return False


# ===========================================================================
# Preparazione per chi esegue (CLI, Studio, telefono)
# ===========================================================================

def _cartella_e_dichiarazione(percorso: Path, sorgente: str | None) -> tuple[Path, Dichiarazione, list[Bisogno], str]:
    """(cartella del programma, dichiarazione, bisogni di tutti i suoi file, nome da mostrare)."""
    from pathlib import Path

    from .progetto import e_progetto

    percorso = Path(percorso)
    cartella, dichiarazione, _, nome = _cartella_e_dichiarazione_leggera(percorso, sorgente)
    bisogni: list[Bisogno] = []
    principale = None if percorso.is_dir() or percorso.name == "progetto.toml" else percorso
    file: list[Path] = []
    if e_progetto(cartella):
        file = sorted(cartella.glob("*.leo")) + sorted(cartella.glob("*.dante"))
        bisogni.extend(bisogni_controlli(cartella))
    elif principale is not None:
        file = [principale]
    for f in file:
        if principale is not None and sorgente is not None and f.resolve() == principale.resolve():
            testo = sorgente
        else:
            try:
                testo = f.read_text(encoding="utf-8-sig")
            except (OSError, UnicodeDecodeError):
                continue
        bisogni.extend(analizza_bisogni(testo, f.name))
    if principale is not None and sorgente is not None and not file:
        bisogni.extend(analizza_bisogni(sorgente, principale.name))
    return cartella, dichiarazione, bisogni, nome


def prepara(percorso: str | os.PathLike, sorgente: str | None = None, *, permetti_tutto: bool = False,
            permetti: Iterable[str] = (), chiedi: Callable | None = None, ricorda_scelte: bool = True,
            verifica_firma: bool = True) -> Politica:
    """La :class:`Politica` per eseguire il programma (o il progetto) in ``percorso``.

    Legge la dichiarazione (riga ``permessi:`` e ``[permessi]`` di progetto.toml), le scelte
    ricordate e la firma (un programma firmato da una chiave fidata è già approvato)."""
    from . import variabile_ambiente
    from pathlib import Path


    percorso = Path(percorso)
    cartella, dichiarazione, _, nome = _cartella_e_dichiarazione_leggera(percorso, sorgente)
    ambiente = (variabile_ambiente("PERMESSI") or "").strip().lower()
    if ambiente in ("tutto", "tutti", "sì", "si"):
        permetti_tutto = True
    elif ambiente:
        permetti = list(permetti) + [p.strip() for p in ambiente.split(",") if p.strip()]
    chiave = chiave_programma(percorso)
    politica = Politica(programma=nome, cartella=str(cartella), dichiarazione=dichiarazione,
                        permetti_tutto=permetti_tutto, permetti=permetti, chiave=chiave, chiedi=chiedi,
                        ricorda_scelte=ricorda_scelte)
    if verifica_firma:
        esito = _esito_firma(percorso, sorgente)
        if esito is not None and esito.valida and esito.fidata and dichiarazione:
            politica.approvata = True           # firmato da una chiave fidata: dichiarazione approvata
        politica.firma = esito
    return politica


def _cartella_e_dichiarazione_leggera(percorso: Path, sorgente: str | None) -> tuple[Path, Dichiarazione, None, str]:
    """Come :func:`_cartella_e_dichiarazione` ma senza analizzare il codice (veloce, a ogni esecuzione)."""
    from .progetto import carica_progetto, e_progetto

    if percorso.is_dir() or percorso.name == "progetto.toml":
        cartella = percorso if percorso.is_dir() else percorso.parent
        principale = None
    else:
        cartella = percorso.parent
        principale = percorso
    dichiarazione = Dichiarazione()
    nome = percorso.name
    if e_progetto(cartella):
        try:
            progetto = carica_progetto(cartella)
            nome = progetto.nome if principale is None else principale.name
            dichiarazione = dichiarazione_da_toml(progetto.extra.get("permessi"))
            if principale is None:
                principale = progetto.percorso_principale if not progetto.e_grafico else None
        except ErroreFile:
            pass
    if principale is not None:
        if sorgente is None:
            try:
                sorgente = principale.read_text(encoding="utf-8-sig")
            except (OSError, UnicodeDecodeError):
                sorgente = ""
        propria = leggi_dichiarazione(sorgente)
        if propria:
            dichiarazione = propria.unisci(dichiarazione)
    return cartella.resolve(), dichiarazione, None, nome


def _esito_firma(percorso: Path, sorgente: str | None) -> Any:
    try:
        from . import firma_codice
    except ImportError:
        return None
    try:
        if percorso.is_dir():
            return firma_codice.verifica_progetto(percorso)
        if sorgente is not None:
            return firma_codice.verifica_testo(sorgente)
        return firma_codice.verifica_file(percorso)
    except Exception:  # noqa: BLE001 - una firma illeggibile vale come assente
        return None


def riepilogo(percorso: str | os.PathLike, sorgente: str | None = None) -> Riepilogo:
    """Il :class:`Riepilogo` dei permessi di un programma o di un progetto (senza eseguirlo)."""
    from pathlib import Path

    percorso = Path(percorso)
    _, dichiarazione, bisogni, nome = _cartella_e_dichiarazione(percorso, sorgente)
    ricordi = ricordi_di(chiave_programma(percorso))
    approvata = bool(dichiarazione) and ricordi.get("dichiarazione_approvata") == dichiarazione.impronta()
    firma = _esito_firma(percorso, sorgente)
    if firma is not None and getattr(firma, "fidata", False) and dichiarazione:
        approvata = True
    concessi = [tuple(c) for c in ricordi.get("concessi", []) if isinstance(c, list) and len(c) == 2]
    return Riepilogo(nome, dichiarazione, bisogni, firma, approvata, concessi)  # type: ignore[arg-type]


def riepilogo_sorgente(sorgente: str, nome_file: str = "programma.leo") -> Riepilogo:
    """Riepilogo di un sorgente senza file (editor del telefono, anteprime)."""
    firma = None
    try:
        from . import firma_codice

        firma = firma_codice.verifica_testo(sorgente)
    except Exception:  # noqa: BLE001
        firma = None
    return Riepilogo(nome_file, leggi_dichiarazione(sorgente), analizza_bisogni(sorgente, nome_file), firma)


def riga_voce(categoria: str, regola: Regola) -> str:
    """Una voce della dichiarazione in parole: ``Rete: collegarsi a api.meteo.it``."""
    nome = NOMI_CATEGORIE[categoria]
    if regola.modo == "elenco":
        cose = [descrivi_risorsa(categoria, v) for v in regola.valori]
        if categoria in ("rete", "file", "hardware"):
            verbo = cose[0].split(" ", 1)[0]
            resto = [c.split(" ", 1)[1] if c.startswith(verbo + " ") else c for c in cose]
            return f"{nome}: {verbo} {_elenco_parole(resto)}"
        return f"{nome}: {_elenco_parole(cose)}"
    if regola.modo == "si":
        return f"{nome}: sì, tutto - {DESCRIZIONI[categoria]}"
    if regola.modo == "no":
        return f"{nome}: mai"
    return f"{nome}: chiederà ogni volta"


def _elenco_parole(cose: list[str]) -> str:
    return cose[0] if len(cose) == 1 else ", ".join(cose[:-1]) + " e " + cose[-1]


def righe_da_approvare(politica: Politica) -> list[str]:
    """Le righe della richiesta iniziale: le voci dichiarate oltre i predefiniti."""
    return [riga_voce(c, r) for c, r in voci_da_approvare(politica.dichiarazione, politica)]


def testo_richiesta(politica: Politica) -> str:
    """Il testo della richiesta iniziale (Studio, telefono): chi, che cosa, firma."""
    righe = [f"Il programma «{politica.programma}» chiede questi permessi:", ""]
    righe += [f"• {r}" for r in righe_da_approvare(politica)]
    mai = [NOMI_CATEGORIE[c].lower() for c in CATEGORIE
           if politica.dichiarazione.regole.get(c, Regola("chiedi")).modo == "no"]
    if mai:
        righe += ["", "Il programma stesso esclude: " + "; ".join(mai) + "."]
    firma = getattr(politica, "firma", None)
    righe += ["", f"Firma: {firma.descrizione()}" if firma is not None else "Firma: il programma non è firmato."]
    righe += ["", "Se li concedi, la scelta vale anche le prossime volte. Concedili solo se ti fidi di chi "
                  "ha scritto il programma."]
    return "\n".join(righe)


def chiedi_approvazione_terminale(politica: Politica, righe: list[str], *,
                                  ingresso: Callable[[], str] | None = None,
                                  uscita: Callable[[str], Any] | None = None) -> bool:
    """Mostra nel terminale che cosa il programma dichiara e chiede di approvarlo (una volta)."""
    scrivi = uscita or (lambda t: (sys.stderr.write(t), sys.stderr.flush()))
    leggi = ingresso or sys.stdin.readline
    testo = [f"Il programma «{politica.programma}» chiede questi permessi:", *(f"- {r}" for r in righe)]
    mai = [NOMI_CATEGORIE[c].lower() for c in CATEGORIE
           if politica.dichiarazione.regole.get(c, Regola("chiedi")).modo == "no"]
    if mai:
        testo.append("Il programma stesso esclude: " + "; ".join(mai) + ".")
    firma = getattr(politica, "firma", None)
    testo.append(f"Firma: {firma.descrizione()}" if firma is not None else "Firma: il programma non è firmato.")
    scrivi("\n" + _riquadro("Permessi", testo) + "\n")
    for _ in range(3):
        scrivi("Li concedi? La scelta vale anche le prossime volte. [s/N] ")
        try:
            riga = leggi()
        except (EOFError, KeyboardInterrupt, OSError, ValueError):
            return False
        r = _risposta(riga or "")
        if r in (SI, SEMPRE):
            return True
        if r == NO:
            return False
    return False


def attiva_per_programma(percorso: str | os.PathLike, sorgente: str | None = None, *,
                         permetti_tutto: bool = False, permetti: Iterable[str] = (),
                         approva: Callable[[Politica, list[str]], bool] | None = None,
                         chiedi: Callable | None = None) -> Politica:
    """Prepara e attiva la politica per un'esecuzione; chiede l'approvazione iniziale se serve e si può.

    ``approva(politica, righe) -> bool``: come chiedere l'approvazione (predefinito: nel
    terminale se c'è una persona; altrimenti si rimanda: le voci dichiarate si chiederanno
    al primo uso, o saranno negate se non si può chiedere). ``ErrorePermesso`` se l'utente
    rifiuta: il programma non parte."""
    politica = prepara(percorso, sorgente, permetti_tutto=permetti_tutto, permetti=permetti, chiedi=chiedi)
    if politica.serve_approvazione():
        righe = righe_da_approvare(politica)
        if approva is None and terminale_interattivo():
            approva = chiedi_approvazione_terminale
        if approva is not None:
            if approva(politica, righe):
                politica.approva()
            else:
                raise ErrorePermesso(f"Non hai concesso i permessi che «{politica.programma}» dichiara: "
                                     "il programma non è stato eseguito.",
                                     suggerimento="Leggi i permessi con `leo spiega` e rieseguilo se ti fidi.")
    attiva(politica)
    return politica
