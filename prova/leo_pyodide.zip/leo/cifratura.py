"""Cifratura vera di Leo: AES-256-GCM con la chiave ricavata dalla password (scrypt).

Stesso formato di ``cifra_testo``/``decifra_testo`` della libreria (modulo
``binario``): un testo cifrato da una parte si decifra dall'altra, sul PC e sul
telefono. Formato (poi in base64)::

    "LEO" | versione (1) | log2 N di scrypt | sale (16 byte) | nonce (12 byte) | testo cifrato + etichetta (16 byte)

L'intestazione è anche "dato associato" di GCM: non si può cambiare di nascosto.

Il cifrario non è scritto a mano: lo fa una libreria riconosciuta.

* PC ed eseguibili: il pacchetto ``cryptography`` (``pip install cryptography``);
* telefono (Chaquopy): ``javax.crypto`` di Android, attraverso il modulo ``java``;
* altrimenti un errore chiaro: Leo non ripiega su schemi fatti in casa.

La chiave si ricava con ``hashlib.scrypt`` (libreria standard) con un sale casuale.

API:
    cifra(dati: bytes, password: str) -> bytes
    decifra(cifrato: bytes, password: str) -> bytes        ErroreValore se password sbagliata o dati cambiati
    cifra_testo(testo: str, password: str) -> str          base64
    decifra_testo(testo: str, password: str) -> str
    motore() -> str | None                                 "cryptography", "android" o None
    e_cifrato_leo(dati: bytes) -> bool
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import secrets
from typing import Any

from .errori import ErroreValore

__all__ = ["cifra", "decifra", "cifra_testo", "decifra_testo", "motore", "e_cifrato_leo", "SPIEGAZIONE"]

MAGIA = b"LEO"
VERSIONE = 1
LOG_N = 15            # scrypt: N = 2**15, r = 8, p = 1 (circa 32 MB e un decimo di secondo)
SALE, NONCE, ETICHETTA = 16, 12, 16
TESTA = len(MAGIA) + 2 + SALE + NONCE

SPIEGAZIONE = ("Per cifrare serve una libreria crittografica riconosciuta: sul PC il pacchetto `cryptography` "
               "(installalo con `pip install cryptography`, su Windows anche con installa.bat); sul telefono "
               "Leo usa quella di Android. Leo non usa cifrari fatti in casa: non sarebbero sicuri.")


def _chiave(password: str, sale: bytes, log_n: int) -> bytes:
    return hashlib.scrypt(password.encode("utf-8", "surrogatepass"), salt=sale, n=2 ** log_n, r=8, p=1,
                          maxmem=256 * 1024 * 1024, dklen=32)


def _password(password: Any) -> str:
    if not isinstance(password, str):
        raise ErroreValore("La password (o chiave) di cifratura deve essere un testo.")
    if not password:
        raise ErroreValore("La password di cifratura è vuota.",
                           suggerimento="Usa una frase lunga che ricordi bene: senza password i dati non si "
                                        "recuperano più.")
    if len(password) > 4096:
        raise ErroreValore("La password di cifratura è troppo lunga (al massimo 4096 caratteri).")
    return password


# ---------------------------------------------------------------------------
# Motori: cryptography (PC) o javax.crypto (Android)
# ---------------------------------------------------------------------------

def _aes_cryptography():
    try:
        from cryptography.exceptions import InvalidTag
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError:
        return None

    def cifra_aes(chiave: bytes, nonce: bytes, dati: bytes, associati: bytes) -> bytes:
        return AESGCM(chiave).encrypt(nonce, dati, associati)

    def decifra_aes(chiave: bytes, nonce: bytes, dati: bytes, associati: bytes) -> bytes | None:
        try:
            return AESGCM(chiave).decrypt(nonce, dati, associati)
        except InvalidTag:
            return None

    return cifra_aes, decifra_aes


def _aes_android():
    try:
        from java import jarray, jbyte, jclass  # type: ignore[import-not-found]  # Chaquopy
    except ImportError:
        return None
    Cipher = jclass("javax.crypto.Cipher")
    SecretKeySpec = jclass("javax.crypto.spec.SecretKeySpec")
    GCMParameterSpec = jclass("javax.crypto.spec.GCMParameterSpec")

    def _java(b: bytes):
        return jarray(jbyte)([x - 256 if x > 127 else x for x in b])

    def _python(a: Any) -> bytes:
        return bytes((x + 256) % 256 for x in a)

    def _cipher(modo: int, chiave: bytes, nonce: bytes, associati: bytes):
        c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(modo, SecretKeySpec(_java(chiave), "AES"), GCMParameterSpec(ETICHETTA * 8, _java(nonce)))
        c.updateAAD(_java(associati))
        return c

    def cifra_aes(chiave: bytes, nonce: bytes, dati: bytes, associati: bytes) -> bytes:
        return _python(_cipher(Cipher.ENCRYPT_MODE, chiave, nonce, associati).doFinal(_java(dati)))

    def decifra_aes(chiave: bytes, nonce: bytes, dati: bytes, associati: bytes) -> bytes | None:
        try:
            return _python(_cipher(Cipher.DECRYPT_MODE, chiave, nonce, associati).doFinal(_java(dati)))
        except Exception:  # noqa: BLE001 - AEADBadTagException: password sbagliata o dati cambiati
            return None

    return cifra_aes, decifra_aes


def _motore() -> tuple[str, Any] | None:
    m = _aes_cryptography()
    if m is not None:
        return "cryptography", m
    m = _aes_android()
    if m is not None:
        return "android", m
    return None


def motore() -> str | None:
    """Quale libreria cifra su questo dispositivo (None: nessuna, la cifratura non è disponibile)."""
    m = _motore()
    return m[0] if m else None


def _serve_motore() -> Any:
    m = _motore()
    if m is None:
        raise ErroreValore("La cifratura non è disponibile su questo computer.", suggerimento=SPIEGAZIONE)
    return m[1]


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------

def e_cifrato_leo(dati: bytes) -> bool:
    return len(dati) >= TESTA + ETICHETTA and dati[:3] == MAGIA


def cifra(dati: bytes, password: str) -> bytes:
    cifra_aes, _ = _serve_motore()
    password = _password(password)
    sale, nonce = secrets.token_bytes(SALE), secrets.token_bytes(NONCE)
    testa = MAGIA + bytes((VERSIONE, LOG_N)) + sale + nonce
    return testa + cifra_aes(_chiave(password, sale, LOG_N), nonce, bytes(dati), testa)


def decifra(cifrato: bytes, password: str) -> bytes:
    if not e_cifrato_leo(cifrato):
        raise ErroreValore("Questi dati non sono stati cifrati da Leo (AES-256-GCM).")
    if cifrato[3] != VERSIONE or not 10 <= cifrato[4] <= 20:
        raise ErroreValore("Questi dati sono cifrati con una versione di Leo diversa.",
                           suggerimento="Aggiorna Leo e riprova.")
    _, decifra_aes = _serve_motore()
    password = _password(password)
    testa = cifrato[:TESTA]
    sale, nonce = testa[5:5 + SALE], testa[5 + SALE:]
    chiaro = decifra_aes(_chiave(password, sale, cifrato[4]), nonce, cifrato[TESTA:], testa)
    if chiaro is None:
        raise ErroreValore("Non riesco a decifrare: la password è sbagliata oppure i dati sono stati modificati.",
                           suggerimento="Controlla maiuscole e spazi della password.")
    return chiaro


def cifra_testo(testo: str, password: str) -> str:
    if not isinstance(testo, str):
        raise ErroreValore("Si può cifrare solo un testo.")
    return base64.b64encode(cifra(testo.encode("utf-8"), password)).decode("ascii")


def _da_base64(testo: str) -> bytes:
    try:
        return base64.b64decode("".join(str(testo).split()).encode("ascii"), validate=True)
    except (binascii.Error, ValueError, UnicodeEncodeError):
        raise ErroreValore("Questo non è un testo cifrato valido (base64 non corretto).",
                           suggerimento="Usa esattamente il testo prodotto da `cifra`.") from None


def decifra_testo(testo: str, password: str) -> str:
    chiaro = decifra(_da_base64(testo), password)
    try:
        return chiaro.decode("utf-8")
    except UnicodeDecodeError:
        raise ErroreValore("I dati decifrati non sono un testo (sono byte).") from None
