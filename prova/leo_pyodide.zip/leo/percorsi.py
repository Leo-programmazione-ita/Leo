"""Dove si trovano i file di dati di Leo (sinonimi, temi, vocabolario).

API:
    cartella_dati() -> Path          # dati/ del progetto Leo
    file_dati(*parti) -> Path        # es. file_dati("temi", "nero.toml")
    cartella_utente() -> Path        # impostazioni dell'utente (creata se manca)
    cartella_personale() -> Path     # ~/Leo: progetti e file dell'utente (non creata)

Ordine di ricerca di ``cartella_dati``: variabile d'ambiente ``LEO_DATI``
(o la vecchia ``DANTE_DATI``), poi ``<radice del repository>/dati`` (accanto
al pacchetto ``leo``), poi ``leo/dati`` (installazione come pacchetto).

Il linguaggio prima si chiamava Dante: se c'e' solo la vecchia cartella delle
impostazioni (``%APPDATA%\\Dante``, ``~/.config/dante``) viene COPIATA in
quella nuova (mai spostata o cancellata); se c'e' solo ``~/Dante`` e non
``~/Leo``, i progetti restano li' e si usa quella.
"""

from __future__ import annotations

import os
from pathlib import Path

from . import variabile_ambiente

_PACCHETTO = Path(__file__).resolve().parent


def cartella_dati() -> Path:
    env = variabile_ambiente("DATI")
    if env and Path(env).is_dir():
        return Path(env)
    for candidata in (_PACCHETTO.parent / "dati", _PACCHETTO / "dati"):
        if candidata.is_dir():
            return candidata
    return _PACCHETTO.parent / "dati"


def file_dati(*parti: str) -> Path:
    return cartella_dati().joinpath(*parti)


def _cartelle_utente() -> tuple[Path, Path]:
    """(nuova, vecchia) cartella delle impostazioni."""
    if os.name == "nt" and os.environ.get("APPDATA"):
        base = Path(os.environ["APPDATA"])
        return base / "Leo", base / "Dante"
    base = Path(os.environ.get("XDG_CONFIG_HOME") or (Path.home() / ".config"))
    return base / "leo", base / "dante"


def cartella_utente() -> Path:
    """Cartella per impostazioni e temi dell'utente.

    Windows: %APPDATA%\\Leo ; altrove: ~/.config/leo (o $XDG_CONFIG_HOME/leo).
    Se manca ma c'e' quella vecchia (``Dante``/``dante``), la copia (senza
    cancellare l'originale); se la copia non riesce usa quella vecchia.
    """
    base, vecchia = _cartelle_utente()
    if not base.exists() and vecchia.is_dir():
        import shutil  # solo qui: importarlo in cima costa ~2 ms a ogni avvio

        try:
            shutil.copytree(vecchia, base)
        except OSError:
            if not base.exists():
                return vecchia
    try:
        base.mkdir(parents=True, exist_ok=True)
    except OSError:
        pass
    return base


def cartella_personale() -> Path:
    """``~/Leo``: dove Studio propone i progetti nuovi e scrive ``studio_errori.txt``.

    Se ``~/Leo`` non c'e' ma c'e' ``~/Dante`` (installazioni precedenti), restituisce
    quella: i progetti non si spostano e non si perdono. Non crea la cartella.
    """
    nuova = Path.home() / "Leo"
    vecchia = Path.home() / "Dante"
    if not nuova.exists() and vecchia.is_dir():
        return vecchia
    return nuova
