"""Gerarchia degli errori di Leo e segnali di controllo (CONTRATTO CONDIVISO).

Gli errori Leo sono eccezioni Python. Le stesse istanze sono anche i VALORI
Leo che il programma vede in ``cattura ... come e``: i campi ``tipo``,
``messaggio``, ``riga``, ``colonna`` (e ``suggerimento``) sono leggibili da
Leo con il punto (``e.messaggio``).

Regola sulle posizioni: chi solleva un errore senza conoscere la posizione
(libreria, operazioni, ambiente) lascia ``riga = 0``; l'interprete, quando
l'eccezione attraversa la valutazione di un nodo, chiama
``errore.imposta_posizione(nodo.riga, nodo.colonna)`` che la imposta SOLO se
ancora a 0.

La formattazione completa del messaggio (con la riga di codice e i ``^^^``)
e' in ``leo.messaggi.formatta_errore``; ``ErroreDante.formatta`` vi delega.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class Correzione:
    """Una correzione di forma proposta (autocorrezione con conferma).

    Applicazione: nella riga ``riga`` (1-based) a partire dalla colonna
    ``colonna`` (1-based) il testo ``prima`` (che deve coincidere col sorgente)
    viene sostituito con ``dopo``. Inserimento puro: ``prima = ""``.
    Per inserire una riga intera prima della riga N: ``riga=N, colonna=1,
    prima="", dopo="    fine\\n"``; per aggiungerla in fondo al file
    ``riga = numero_righe + 1``.

    ``motivo``: frase in italiano mostrata all'utente (es. "manca `allora`").
    ``alternative``: se ci sono piu' correzioni plausibili dello stesso peso,
    ognuna e' un'altra :class:`Correzione` (l'utente sceglie per numero).
    ``facoltativa``: True per i suggerimenti non bloccanti, cioe' le forme che
    Leo capisce comunque (``se x fai``, ``finestra1`` per ``Finestra1``,
    ``rosso`` senza virgolette) ma che conviene riportare alla forma canonica.
    """

    riga: int
    colonna: int
    prima: str
    dopo: str
    motivo: str
    alternative: list["Correzione"] = field(default_factory=list)
    facoltativa: bool = False


@dataclass
class PassoPila:
    """Un passo della pila delle chiamate di un errore (dal piu' recente).

    ``genere``: ``"funzione"``, ``"anonima"``, ``"gestore"`` (``quando``),
    ``"speciale"`` (``in parallelo``, ``ogni``/``dopo``), ``"modulo"`` (il
    codice principale di un file importato) o ``"principale"``.
    ``nome``: nome della funzione (o del gestore, del file importato).
    ``nome_file``/``riga``: dove si trovava l'esecuzione in quel passo.
    ``argomenti``: testo breve degli argomenti (``"n = 3"``) o ``""``.
    """

    genere: str
    nome: str
    nome_file: str
    riga: int
    argomenti: str = ""


class ErroreDante(Exception):
    """Base di tutti gli errori del linguaggio.

    Campi (tutti leggibili da Leo):
      tipo         nome del tipo di errore, es. "ErroreValore" (= nome della classe)
      messaggio    frase in italiano, nomi del codice tra apici inversi
      riga,colonna posizione 1-based (0 = sconosciuta)
      suggerimento frase facoltativa ("forse intendevi `totale`?") o None
    Campi aggiuntivi Python:
      nome_file    file sorgente ("<sorgente>" se ignoto)
      lunghezza    quanti caratteri sottolineare con ^ (>= 1)
      pila_chiamate  passi della pila delle chiamate (vedi :class:`PassoPila`)
      sorgente_file  (facoltativo) testo del file ``nome_file`` quando non e'
                     il programma principale (errore dentro un file importato)
    """

    catturabile: bool = True

    #: Pila delle chiamate (lista di :class:`PassoPila`, dal passo piu' recente),
    #: costruita dall'interprete solo mentre l'errore risale le funzioni: se
    #: l'errore nasce al livello principale resta vuota.
    pila_chiamate: "list[PassoPila] | tuple" = ()
    #: Interno: riga del primo nodo attraversato nel passo corrente (0 = nessuno).
    _riga_qui: int = 0

    def __init__(
        self,
        messaggio: str = "",
        riga: int = 0,
        colonna: int = 0,
        suggerimento: str | None = None,
        *,
        nome_file: str = "<sorgente>",
        lunghezza: int = 1,
    ) -> None:
        super().__init__(messaggio)
        self.messaggio = messaggio
        self.riga = riga
        self.colonna = colonna
        self.suggerimento = suggerimento
        self.nome_file = nome_file
        self.lunghezza = max(1, lunghezza)

    @property
    def tipo(self) -> str:
        return type(self).__name__

    def imposta_posizione(self, riga: int, colonna: int, lunghezza: int | None = None) -> "ErroreDante":
        """Imposta la posizione solo se ancora sconosciuta. Restituisce self."""
        if not self.riga:
            self.riga = riga
            self.colonna = colonna
            if lunghezza:
                self.lunghezza = max(1, lunghezza)
        return self

    #: Campi visibili da Leo con ``e.<campo>``.
    CAMPI_DANTE: tuple[str, ...] = ("tipo", "messaggio", "riga", "colonna", "suggerimento")

    def campo(self, nome: str):
        """Legge un campo per il codice Leo; ErroreNome se non esiste."""
        if nome in self.CAMPI_DANTE:
            return getattr(self, nome)
        raise ErroreNome(
            f"Un errore non ha il campo `{nome}`.",
            suggerimento="I campi di un errore sono: " + ", ".join(f"`{c}`" for c in self.CAMPI_DANTE),
            nome=nome,
        )

    def formatta(self, sorgente: str | None = None, tema=None, colori: bool = False) -> str:
        """Messaggio completo in quattro parti (vedi leo.messaggi)."""
        try:
            from .messaggi import formatta_errore
        except ImportError:  # pragma: no cover - messaggi non ancora pronto
            formatta_errore = None
        if formatta_errore is None:
            return self.breve()
        try:
            return formatta_errore(self, sorgente, tema=tema, colori=colori)
        except NotImplementedError:  # pragma: no cover
            return self.breve()

    def breve(self) -> str:
        """Forma di una riga: ``ErroreNome (riga 7, colonna 11): messaggio``."""
        pos = f" (riga {self.riga}, colonna {self.colonna})" if self.riga else ""
        testo = f"{self.tipo}{pos}: {self.messaggio}"
        if self.suggerimento:
            testo += f"\nSuggerimento: {self.suggerimento}"
        return testo

    def __str__(self) -> str:
        return self.messaggio

    def __repr__(self) -> str:
        return f"{self.tipo}({self.messaggio!r}, riga={self.riga}, colonna={self.colonna})"


class ErroreSintassi(ErroreDante):
    """Il codice non rispetta la grammatica. NON catturabile da ``prova``.

    ``correzioni``: correzioni di forma proposte dal lexer/parser in modalita'
    di recupero (lista vuota se nessuna).
    """

    catturabile = False

    def __init__(self, messaggio: str = "", riga: int = 0, colonna: int = 0,
                 suggerimento: str | None = None, *, correzioni: list[Correzione] | None = None,
                 **kw) -> None:
        super().__init__(messaggio, riga, colonna, suggerimento, **kw)
        self.correzioni: list[Correzione] = list(correzioni or [])


class ErroreNome(ErroreDante):
    """Variabile o funzione non definita (o gia' dichiarata).

    ``nome``: l'identificatore coinvolto, usato per i suggerimenti.
    """

    def __init__(self, messaggio: str = "", riga: int = 0, colonna: int = 0,
                 suggerimento: str | None = None, *, nome: str | None = None, **kw) -> None:
        super().__init__(messaggio, riga, colonna, suggerimento, **kw)
        self.nome = nome


class ErroreTipo(ErroreDante):
    """Operazione tra tipi incompatibili (``"3" + 4``)."""


class ErroreValore(ErroreDante):
    """Valore del tipo giusto ma non valido (``intero("ciao")``)."""


class ErroreIndice(ErroreDante):
    """Indice fuori dalla lista/testo."""


class ErroreChiave(ErroreDante):
    """Chiave assente nel dizionario."""


class ErroreDivisione(ErroreDante):
    """Divisione (o resto) per zero."""


class ErroreRicorsione(ErroreDante):
    """Superato il limite di chiamate annidate (1.000)."""


class ErroreFile(ErroreDante):
    """File inesistente o non leggibile/scrivibile."""


#: Tipi di errore visibili da Leo per nome (``cattura ErroreValore``,
#: ``lancia ErroreValore("...")``). L'interprete li mette nell'ambiente
#: predefinito come costruttori: chiamarli con un testo crea l'istanza.
TIPI_ERRORE: dict[str, type[ErroreDante]] = {
    cls.__name__: cls
    for cls in (ErroreSintassi, ErroreNome, ErroreTipo, ErroreValore, ErroreIndice,
                ErroreChiave, ErroreDivisione, ErroreRicorsione, ErroreFile)
}


# ---------------------------------------------------------------------------
# Segnali di controllo del flusso (NON sono errori Leo: mai visibili all'utente)
# ---------------------------------------------------------------------------

class SegnaleControllo(Exception):
    """Base dei segnali usati dall'interprete per interrompi/continua/restituisci."""


class SegnaleInterrompi(SegnaleControllo):
    pass


class SegnaleContinua(SegnaleControllo):
    pass


class SegnaleRestituisci(SegnaleControllo):
    def __init__(self, valore=None) -> None:
        super().__init__()
        self.valore = valore


class SegnaleFermaProgramma(SegnaleControllo):
    """Chiede di fermare l'esecuzione (pulsante Stop, chiusura della finestra)."""
