"""Firma digitale dei programmi e dei progetti Leo (Ed25519).

Chi scrive un programma lo firma con la sua chiave privata; chi lo riceve vede
chi l'ha firmato e se qualcuno l'ha cambiato dopo. È la base dei pacchetti.

* Un file ``.leo`` firmato ha in fondo UNA riga di commento::

      #firma-leo: 1 ed25519 chiave=<pubblica> data=<quando> autore=<nome> firma=<firma>

  La firma copre tutto il testo sopra quella riga (con gli a capo normalizzati) e i
  dati della riga stessa. Il file resta un programma Leo valido e si può copiare.
* Un progetto firmato ha il file ``progetto.firma`` (JSON) con l'impronta SHA-256 di
  ogni file del progetto e la firma dell'elenco: se un file cambia, si aggiunge o si
  toglie, la verifica dice quale.

Firmare richiede il pacchetto facoltativo ``cryptography`` (``pip install
cryptography``): Leo non firma con codice fatto in casa. Verificare funziona anche
senza (sul telefono, negli eseguibili): c'è un verificatore Ed25519 in Python puro
che segue il riferimento dell'RFC 8032 (la verifica usa solo dati pubblici).

Le chiavi stanno nella cartella dell'utente (``chiavi/``): ``leo_ed25519.pem``
(privata, non darla a nessuno) e ``fidate.json`` (le chiavi pubbliche di cui ti
fidi). La tua chiave è sempre fidata. Un programma firmato da una chiave fidata
ha i permessi dichiarati già approvati (``leo.permessi``).

API:
    crea_chiave(sovrascrivi=False) -> str               chiave pubblica (testo)
    chiave_pubblica() -> str | None                      la tua, se c'è
    firma_testo(sorgente, autore=None) -> str            il sorgente con la riga di firma
    verifica_testo(sorgente) -> EsitoFirma | None        None: non firmato
    firma_file(percorso, autore=None) / verifica_file(percorso)
    firma_progetto(cartella, autore=None) / verifica_progetto(cartella)
    fidate() -> dict;  aggiungi_fidata(chiave, nome);  togli_fidata(chiave)
    impronta_chiave(chiave) -> "3F2A-9C1B-77D0-1E45"
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .errori import ErroreFile, ErroreValore


class _ModuloPigro:
    """Rimanda l'``import`` di un modulo pesante al primo uso vero.

    ``firma_codice`` viene importato a ogni esecuzione (il controllo della firma),
    ma ``base64``/``hashlib``/``datetime``/``json`` servono solo quando c'e'
    davvero una firma da leggere o scrivere: con un programma non firmato (il
    caso normale) non si toccano. Il proxy e' trasparente perche' ogni uso e'
    ``modulo.attributo`` (``base64.b64decode``, ``binascii.Error``...); il
    modulo vero si importa alla prima lettura di un attributo e resta in cache.
    """

    __slots__ = ("_nome", "_modulo")

    def __init__(self, nome: str) -> None:
        self._nome = nome
        self._modulo = None

    def __getattr__(self, attributo: str) -> Any:
        modulo = self._modulo
        if modulo is None:
            import importlib

            modulo = self._modulo = importlib.import_module(self._nome)
        return getattr(modulo, attributo)


base64 = _ModuloPigro("base64")
binascii = _ModuloPigro("binascii")
_dt = _ModuloPigro("datetime")
hashlib = _ModuloPigro("hashlib")
json = _ModuloPigro("json")

__all__ = ["EsitoFirma", "crea_chiave", "chiave_pubblica", "firma_testo", "verifica_testo", "firma_file",
           "verifica_file", "firma_progetto", "verifica_progetto", "fidate", "aggiungi_fidata", "togli_fidata",
           "impronta_chiave", "togli_firma", "verifica_ed25519", "cryptography_presente", "FILE_FIRMA_PROGETTO"]

VERSIONE = "1"
PREFISSO = "#firma-leo:"
FILE_FIRMA_PROGETTO = "progetto.firma"
_CONTESTO_FILE = b"leo-firma-1-file\n"
_CONTESTO_PROGETTO = b"leo-firma-1-progetto\n"
_ESTENSIONI_TESTO = {".leo", ".dante", ".toml", ".maschera", ".txt", ".json", ".csv", ".md", ".html", ".css",
                     ".js", ".ini", ".svg", ".xml", ".yaml", ".yml"}
_RIGA_FIRMA = re.compile(r"^#firma-leo:\s*(?P<v>\S+)\s+ed25519\s+(?P<campi>.*)$")

_SPIEGAZIONE_CRYPTOGRAPHY = (
    "Per firmare serve il pacchetto `cryptography`, che su questo computer non c'è. Installalo con "
    "`pip install cryptography` (su Windows anche con installa.bat). Leo non firma con codice fatto in casa: "
    "una firma deve essere sicura. Per VERIFICARE le firme invece non serve niente.")


# ===========================================================================
# Ed25519: cryptography se c'è, altrimenti verifica in Python puro (RFC 8032)
# ===========================================================================

def cryptography_presente() -> bool:
    try:
        from cryptography.hazmat.primitives.asymmetric import ed25519  # noqa: F401
    except ImportError:
        return False
    return True


_P = 2 ** 255 - 19
_D = -121665 * pow(121666, _P - 2, _P) % _P
_Q = 2 ** 252 + 27742317777372353535851937790883648493
_RADICE_MENO_UNO = pow(2, (_P - 1) // 4, _P)


def _somma(a: tuple, b: tuple) -> tuple:
    A = (a[1] - a[0]) * (b[1] - b[0]) % _P
    B = (a[1] + a[0]) * (b[1] + b[0]) % _P
    C = 2 * a[3] * b[3] * _D % _P
    D = 2 * a[2] * b[2] % _P
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F, G * H, F * G, E * H)


def _moltiplica(s: int, punto: tuple) -> tuple:
    risultato = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            risultato = _somma(risultato, punto)
        punto = _somma(punto, punto)
        s >>= 1
    return risultato


def _uguali(a: tuple, b: tuple) -> bool:
    return (a[0] * b[2] - b[0] * a[2]) % _P == 0 and (a[1] * b[2] - b[1] * a[2]) % _P == 0


def _recupera_x(y: int, segno: int) -> int | None:
    if y >= _P:
        return None
    x2 = (y * y - 1) * pow(_D * y * y + 1, _P - 2, _P)
    if x2 == 0:
        return None if segno else 0
    x = pow(x2, (_P + 3) // 8, _P)
    if (x * x - x2) % _P != 0:
        x = x * _RADICE_MENO_UNO % _P
    if (x * x - x2) % _P != 0:
        return None
    if (x & 1) != segno:
        x = _P - x
    return x


_GY = 4 * pow(5, _P - 2, _P) % _P
_GX = _recupera_x(_GY, 0)
_G = (_GX, _GY, 1, _GX * _GY % _P)


def _decomprimi(s: bytes) -> tuple | None:
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    segno = y >> 255
    y &= (1 << 255) - 1
    x = _recupera_x(y, segno)
    if x is None:
        return None
    return (x, y, 1, x * y % _P)


def _verifica_pura(pubblica: bytes, messaggio: bytes, firma: bytes) -> bool:
    """Verifica Ed25519 dell'RFC 8032 (sezione 6), solo libreria standard."""
    if len(pubblica) != 32 or len(firma) != 64:
        return False
    A = _decomprimi(pubblica)
    R = _decomprimi(firma[:32])
    if A is None or R is None:
        return False
    s = int.from_bytes(firma[32:], "little")
    if s >= _Q:
        return False
    h = int.from_bytes(hashlib.sha512(firma[:32] + pubblica + messaggio).digest(), "little") % _Q
    return _uguali(_moltiplica(s, _G), _somma(R, _moltiplica(h, A)))


def verifica_ed25519(pubblica: bytes, messaggio: bytes, firma: bytes) -> bool:
    """Vero se ``firma`` è una firma Ed25519 valida di ``messaggio`` con la chiave ``pubblica``."""
    try:
        from cryptography.exceptions import InvalidSignature
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
    except ImportError:
        return _verifica_pura(pubblica, messaggio, firma)
    try:
        Ed25519PublicKey.from_public_bytes(pubblica).verify(firma, messaggio)
        return True
    except (InvalidSignature, ValueError):
        return False


# ===========================================================================
# Chiavi
# ===========================================================================

def _cartella_chiavi() -> Path:
    from . import variabile_ambiente

    scelta = variabile_ambiente("CHIAVI")
    if scelta:
        return Path(scelta)
    from .percorsi import cartella_utente

    return cartella_utente() / "chiavi"


def _file_privata() -> Path:
    return _cartella_chiavi() / "leo_ed25519.pem"


def _b64(dati: bytes) -> str:
    return base64.b64encode(dati).decode("ascii")


def _da_b64(testo: str, cosa: str) -> bytes:
    try:
        return base64.b64decode(testo.strip().encode("ascii"), validate=True)
    except (binascii.Error, ValueError, UnicodeEncodeError):
        raise ErroreValore(f"{cosa} non è scritta bene (base64 non valido).") from None


def impronta_chiave(chiave: str) -> str:
    """Impronta breve e leggibile di una chiave pubblica, da confrontare a voce (``3F2A-9C1B-77D0-1E45``)."""
    try:
        grezza = base64.b64decode(chiave.strip().encode("ascii"))
    except (binascii.Error, ValueError, UnicodeEncodeError):
        grezza = chiave.encode("utf-8")
    h = hashlib.sha256(grezza).hexdigest()[:16].upper()
    return "-".join(h[i:i + 4] for i in range(0, 16, 4))


def _serve_cryptography():
    try:
        from cryptography.hazmat.primitives import serialization
        from cryptography.hazmat.primitives.asymmetric import ed25519
    except ImportError:
        raise ErroreValore("Non posso firmare: manca il pacchetto `cryptography`.",
                           suggerimento=_SPIEGAZIONE_CRYPTOGRAPHY) from None
    return ed25519, serialization


def crea_chiave(*, sovrascrivi: bool = False) -> str:
    """Crea la tua chiave di firma (se non c'è già) e restituisce la chiave pubblica da condividere."""
    ed25519, serialization = _serve_cryptography()
    file = _file_privata()
    if file.exists() and not sovrascrivi:
        esistente = chiave_pubblica()
        if esistente:
            return esistente
    privata = ed25519.Ed25519PrivateKey.generate()
    pem = privata.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                serialization.NoEncryption())
    try:
        file.parent.mkdir(parents=True, exist_ok=True)
        descrittore = os.open(file, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(descrittore, "wb") as f:
            f.write(pem)
    except OSError as e:
        raise ErroreFile(f"Non riesco a salvare la chiave in `{file}`: {e.strerror or e}.") from e
    return _b64(privata.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw))


def _carica_privata():
    ed25519, serialization = _serve_cryptography()
    file = _file_privata()
    try:
        dati = file.read_bytes()
    except OSError:
        raise ErroreFile("Non hai ancora una chiave di firma.",
                         suggerimento="Creala con `leo firma --crea-chiave` (una volta sola).") from None
    try:
        privata = serialization.load_pem_private_key(dati, password=None)
    except (ValueError, TypeError) as e:
        raise ErroreFile(f"La chiave di firma in `{file}` è rovinata o protetta da password: {e}.") from None
    if not isinstance(privata, ed25519.Ed25519PrivateKey):
        raise ErroreFile(f"La chiave in `{file}` non è una chiave Ed25519.")
    return privata, serialization


def chiave_pubblica() -> str | None:
    """La tua chiave pubblica (testo base64), o None se non hai ancora una chiave."""
    if not _file_privata().exists():
        return None
    try:
        privata, serialization = _carica_privata()
    except (ErroreFile, ErroreValore):
        return None
    return _b64(privata.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw))


def _file_fidate() -> Path:
    return _cartella_chiavi() / "fidate.json"


def fidate() -> dict[str, dict]:
    """Chiavi pubbliche fidate: chiave -> {"nome": ..., "aggiunta": ...}."""
    try:
        dati = json.loads(_file_fidate().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return {k: v for k, v in dati.items() if isinstance(v, dict)} if isinstance(dati, dict) else {}


def aggiungi_fidata(chiave: str, nome: str = "") -> str:
    """Aggiunge una chiave pubblica alle fidate; restituisce la sua impronta."""
    grezza = _da_b64(chiave, "La chiave pubblica")
    if len(grezza) != 32:
        raise ErroreValore("Questa non è una chiave pubblica Ed25519 (deve essere di 32 byte).")
    dati = fidate()
    dati[_b64(grezza)] = {"nome": nome or impronta_chiave(chiave), "aggiunta": _dt.date.today().isoformat()}
    file = _file_fidate()
    try:
        file.parent.mkdir(parents=True, exist_ok=True)
        file.write_text(json.dumps(dati, ensure_ascii=False, indent=1, sort_keys=True), encoding="utf-8")
    except OSError as e:
        raise ErroreFile(f"Non riesco a salvare `{file}`: {e.strerror or e}.") from e
    return impronta_chiave(chiave)


def togli_fidata(chiave: str) -> bool:
    dati = fidate()
    c = dati.pop(chiave.strip(), None) is not None
    if c:
        _file_fidate().write_text(json.dumps(dati, ensure_ascii=False, indent=1, sort_keys=True), encoding="utf-8")
    return c


def _e_fidata(chiave: str) -> tuple[bool, str]:
    """(fidata, nome con cui la conosci)."""
    propria = chiave_pubblica() if cryptography_presente() else None
    if propria and propria == chiave:
        return True, "la tua chiave"
    voce = fidate().get(chiave)
    if voce is not None:
        return True, str(voce.get("nome", ""))
    return False, ""


# ===========================================================================
# Esito
# ===========================================================================

@dataclass
class EsitoFirma:
    """Risultato di una verifica.

    ``stato``: ``"valida"`` (nessuno ha cambiato niente dopo la firma), ``"non_valida"``
    (cambiato, o firma falsa)."""

    stato: str
    autore: str = ""
    chiave: str = ""
    data: str = ""
    fidata: bool = False
    nome_fidata: str = ""
    modificati: list[str] = field(default_factory=list)
    motivo: str = ""

    @property
    def valida(self) -> bool:
        return self.stato == "valida"

    @property
    def impronta(self) -> str:
        return impronta_chiave(self.chiave) if self.chiave else ""

    def descrizione(self) -> str:
        if not self.valida:
            dettaglio = f" ({self.motivo})" if self.motivo else ""
            return f"NON VALIDA: il programma è stato modificato dopo la firma o la firma è falsa{dettaglio}."
        chi = f"«{self.autore}»" if self.autore else "un autore senza nome"
        quando = f" il {self.data[:10]}" if self.data else ""
        if self.fidata:
            noto = f", che conosci come «{self.nome_fidata}»" if self.nome_fidata and self.nome_fidata != self.autore else ""
            return f"firmato da {chi}{quando} con una chiave fidata ({self.impronta}{noto})."
        return (f"firmato da {chi}{quando}, chiave {self.impronta}: la firma è integra ma la chiave non è tra "
                f"quelle di cui ti fidi.")

    def a_dizionario(self) -> dict:
        return {"stato": self.stato, "autore": self.autore, "chiave": self.chiave, "impronta": self.impronta,
                "data": self.data, "fidata": self.fidata, "modificati": list(self.modificati),
                "descrizione": self.descrizione()}


# ===========================================================================
# File singoli
# ===========================================================================

def _normalizza(testo: str) -> str:
    if testo.startswith("﻿"):
        testo = testo[1:]
    return testo.replace("\r\n", "\n").replace("\r", "\n")


def _separa(sorgente: str) -> tuple[str, str | None]:
    """(contenuto firmato, riga di firma o None)."""
    testo = _normalizza(sorgente)
    righe = testo.split("\n")
    # la riga di firma è l'ultima riga non vuota
    k = len(righe) - 1
    while k >= 0 and not righe[k].strip():
        k -= 1
    if k >= 0 and righe[k].lstrip().startswith(PREFISSO):
        return "\n".join(righe[:k]) + "\n", righe[k].strip()
    return testo, None


def togli_firma(sorgente: str) -> str:
    return _separa(sorgente)[0]


def _codifica_autore(autore: str) -> str:
    return base64.urlsafe_b64encode(autore.encode("utf-8")).decode("ascii").rstrip("=")


def _decodifica_autore(testo: str) -> str:
    try:
        return base64.urlsafe_b64decode(testo + "=" * (-len(testo) % 4)).decode("utf-8")
    except (binascii.Error, ValueError, UnicodeDecodeError):
        return ""


def _messaggio_file(contenuto: str, chiave: str, data: str, autore_codificato: str) -> bytes:
    intestazione = f"chiave={chiave}\ndata={data}\nautore={autore_codificato}\n".encode("ascii")
    return _CONTESTO_FILE + intestazione + hashlib.sha256(contenuto.encode("utf-8")).digest()


def _adesso() -> str:
    return _dt.datetime.now().replace(microsecond=0).isoformat()


def _autore_predefinito() -> str:
    try:
        import getpass

        return getpass.getuser()
    except Exception:  # noqa: BLE001
        return ""


def firma_testo(sorgente: str, autore: str | None = None) -> str:
    """Il sorgente con la riga ``#firma-leo:`` in fondo (una firma precedente viene sostituita)."""
    privata, serialization = _carica_privata()
    contenuto, _ = _separa(sorgente)
    if not contenuto.endswith("\n"):
        contenuto += "\n"
    chiave = _b64(privata.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw))
    data = _adesso()
    autore_c = _codifica_autore(autore if autore is not None else _autore_predefinito())
    firma = privata.sign(_messaggio_file(contenuto, chiave, data, autore_c))
    return f"{contenuto}{PREFISSO} {VERSIONE} ed25519 chiave={chiave} data={data} autore={autore_c} firma={_b64(firma)}\n"


def verifica_testo(sorgente: str) -> EsitoFirma | None:
    """La verifica della firma in fondo al sorgente; None se il sorgente non è firmato."""
    contenuto, riga = _separa(sorgente)
    if riga is None:
        return None
    m = _RIGA_FIRMA.match(riga)
    if not m:
        return EsitoFirma("non_valida", motivo="riga di firma non riconosciuta")
    if m.group("v") != VERSIONE:
        return EsitoFirma("non_valida", motivo=f"versione di firma {m.group('v')} sconosciuta: aggiorna Leo")
    campi = dict(c.split("=", 1) for c in m.group("campi").split() if "=" in c)
    chiave, data, autore_c, firma = (campi.get(k, "") for k in ("chiave", "data", "autore", "firma"))
    autore = _decodifica_autore(autore_c)
    try:
        grezza_chiave = base64.b64decode(chiave, validate=True)
        grezza_firma = base64.b64decode(firma, validate=True)
    except (binascii.Error, ValueError):
        return EsitoFirma("non_valida", autore, chiave, data, motivo="firma scritta male")
    if not verifica_ed25519(grezza_chiave, _messaggio_file(contenuto, chiave, data, autore_c), grezza_firma):
        return EsitoFirma("non_valida", autore, chiave, data, motivo="il testo non corrisponde alla firma")
    fidata, nome = _e_fidata(chiave)
    return EsitoFirma("valida", autore, chiave, data, fidata, nome)


def _leggi(percorso: Path) -> str:
    try:
        return percorso.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeDecodeError) as e:
        raise ErroreFile(f"Non riesco a leggere `{percorso}`: {e}.") from e


def firma_file(percorso: str | os.PathLike, autore: str | None = None) -> EsitoFirma:
    p = Path(percorso)
    if p.is_dir():
        return firma_progetto(p, autore)
    firmato = firma_testo(_leggi(p), autore)
    try:
        p.write_text(firmato, encoding="utf-8", newline="\n")
    except OSError as e:
        raise ErroreFile(f"Non riesco a scrivere `{p}`: {e.strerror or e}.") from e
    return verifica_testo(firmato)  # type: ignore[return-value]


def verifica_file(percorso: str | os.PathLike) -> EsitoFirma | None:
    p = Path(percorso)
    if p.is_dir():
        return verifica_progetto(p)
    return verifica_testo(_leggi(p))


# ===========================================================================
# Progetti
# ===========================================================================

def _file_del_progetto(cartella: Path) -> dict[str, str]:
    """Percorso relativo (con /) -> impronta SHA-256, per tutti i file del progetto."""
    impronte: dict[str, str] = {}
    for radice, cartelle, file in os.walk(cartella):
        cartelle[:] = sorted(c for c in cartelle if not c.startswith(".") and c not in ("__pycache__",))
        for nome in sorted(file):
            if nome.startswith(".") or nome == FILE_FIRMA_PROGETTO or nome.endswith((".pyc", ".tmp")):
                continue
            completo = Path(radice) / nome
            relativo = completo.relative_to(cartella).as_posix()
            try:
                dati = completo.read_bytes()
            except OSError:
                continue
            if completo.suffix.lower() in _ESTENSIONI_TESTO:
                dati = dati.replace(b"\r\n", b"\n")
                if dati.startswith(b"\xef\xbb\xbf"):
                    dati = dati[3:]
            impronte[relativo] = hashlib.sha256(dati).hexdigest()
    return impronte


def _messaggio_progetto(dati: dict) -> bytes:
    senza = {k: v for k, v in dati.items() if k != "firma"}
    return _CONTESTO_PROGETTO + json.dumps(senza, sort_keys=True, ensure_ascii=False,
                                           separators=(",", ":")).encode("utf-8")


def firma_progetto(cartella: str | os.PathLike, autore: str | None = None) -> EsitoFirma:
    """Scrive ``progetto.firma`` con le impronte di tutti i file e la firma."""
    cartella = Path(cartella)
    if not (cartella / "progetto.toml").is_file():
        raise ErroreFile(f"`{cartella}` non è un progetto Leo (manca progetto.toml).",
                         suggerimento="Per un programma singolo firma il file .leo.")
    privata, serialization = _carica_privata()
    chiave = _b64(privata.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw))
    dati = {"formato": "leo-firma-" + VERSIONE, "algoritmo": "ed25519", "chiave": chiave, "data": _adesso(),
            "autore": autore if autore is not None else _autore_predefinito(),
            "file": _file_del_progetto(cartella)}
    dati["firma"] = _b64(privata.sign(_messaggio_progetto(dati)))
    file = cartella / FILE_FIRMA_PROGETTO
    try:
        file.write_text(json.dumps(dati, ensure_ascii=False, indent=1, sort_keys=True) + "\n", encoding="utf-8")
    except OSError as e:
        raise ErroreFile(f"Non riesco a scrivere `{file}`: {e.strerror or e}.") from e
    return verifica_progetto(cartella)  # type: ignore[return-value]


def verifica_progetto(cartella: str | os.PathLike) -> EsitoFirma | None:
    """Verifica ``progetto.firma``; None se il progetto non è firmato."""
    cartella = Path(cartella)
    file = cartella / FILE_FIRMA_PROGETTO
    if not file.is_file():
        return None
    try:
        dati = json.loads(file.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return EsitoFirma("non_valida", motivo=f"`{FILE_FIRMA_PROGETTO}` illeggibile")
    if not isinstance(dati, dict) or dati.get("algoritmo") != "ed25519":
        return EsitoFirma("non_valida", motivo="formato della firma sconosciuto")
    chiave, autore, data = str(dati.get("chiave", "")), str(dati.get("autore", "")), str(dati.get("data", ""))
    try:
        grezza_chiave = base64.b64decode(chiave, validate=True)
        grezza_firma = base64.b64decode(str(dati.get("firma", "")), validate=True)
    except (binascii.Error, ValueError):
        return EsitoFirma("non_valida", autore, chiave, data, motivo="firma scritta male")
    if not verifica_ed25519(grezza_chiave, _messaggio_progetto(dati), grezza_firma):
        return EsitoFirma("non_valida", autore, chiave, data, motivo="l'elenco dei file non corrisponde alla firma")
    attesi = dati.get("file") or {}
    presenti = _file_del_progetto(cartella)
    modificati = sorted(
        [f"{n} (cambiato)" for n in attesi if n in presenti and presenti[n] != attesi[n]]
        + [f"{n} (mancante)" for n in attesi if n not in presenti]
        + [f"{n} (aggiunto)" for n in presenti if n not in attesi])
    if modificati:
        return EsitoFirma("non_valida", autore, chiave, data, modificati=modificati,
                          motivo="file diversi da quelli firmati: " + ", ".join(modificati[:5])
                                 + ("..." if len(modificati) > 5 else ""))
    fidata, nome = _e_fidata(chiave)
    return EsitoFirma("valida", autore, chiave, data, fidata, nome)
