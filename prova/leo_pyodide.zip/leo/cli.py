"""Il comando `leo` (docs/CONTRATTI.md §12.2).

Uso::

    leo                                   REPL interattivo
    leo programma.leo [--rigoroso] [--correggi=si|no] [--tema=nero]
    leo cartella_progetto/                esegue un progetto
    leo formatta percorso... [--controlla]
    leo nuovo cartella [--testuale] [--nome NOME]
    leo studio [cartella]
    leo verifica programma.leo|cartella [--rigoroso]   esegue le verifiche incorporate
    leo controlla programma.leo|cartella [--json] [--rigoroso]   controlli prima di eseguire
    leo compila programma.leo|cartella [--uscita CARTELLA] [--nome NOME] [--icona FILE.ico]
                [--console|--finestra] [--un-file|--piu-file] [--installa]
    leo licenza [attiva CHIAVE | togli]  stato della licenza di Leo Studio
    leo aggiungi | togli | sincronizza | pacchetti   pacchetti del progetto (leo/pacchetti.py)
    leo --versione | --aiuto

Codici d'uscita: 0 tutto bene, 1 errore nel programma (o nel file da
formattare), 2 uso sbagliato del comando (opzioni, percorsi inesistenti).

Questo modulo, al caricamento, importa SOLO la libreria standard e il pacchetto
``leo`` (versione): lexer, parser, interprete, formattatore, correzioni,
messaggi e temi si importano dentro le funzioni, cosi' ``leo --versione`` e
``leo --aiuto`` funzionano sempre.

API pubblica:
    main(argv=None) -> int
    esegui_con_pila_grande(funzione, *, al_interrupt=None)   # usata anche dal REPL
    usa_colori(flusso) -> bool
    prepara_console() -> None
    e_terminale_interattivo() -> bool
    testo_rappresentabile(testo, flusso=None) -> str   # `?` al posto dei caratteri che la console non ha
    puo_scrivere(testo, flusso=None) -> bool
    FlussoTollerante(flusso)                           # uscita non riconfigurabile e non UTF-8
"""

from __future__ import annotations

import argparse
import contextlib
import os
import sys
import threading
import time
from pathlib import Path
from typing import Any, Callable, Iterator, Sequence

from . import __version__, COPYRIGHT, NOME, e_sorgente, variabile_ambiente

#: Dimensione della pila del thread che esegue i programmi (ricorsione profonda su Windows).
DIMENSIONE_PILA = 256 * 1024 * 1024
#: Su Android (telefoni con poca memoria, anche a 32 bit) basta una pila piu' piccola.
DIMENSIONE_PILA_ANDROID = 64 * 1024 * 1024

#: Codici d'uscita.
USCITA_OK = 0
USCITA_ERRORE = 1
USCITA_USO = 2

#: Argomenti dati al programma .leo (quelli dopo il suo nome): li legge `argomenti()` della libreria.
ARGOMENTI_PROGRAMMA: list[str] = []
#: Opzioni di Leo che restano a Leo anche se scritte dopo il nome del programma.
_OPZIONI_LEO_DOPO_PROGRAMMA = ("--rigoroso", "--semplice", "--consiglio", "--permetti-tutto")
_OPZIONI_LEO_CON_VALORE = ("--tema", "--correggi", "--permetti")


def separa_argomenti_programma(argv: Sequence[str]) -> tuple[list[str], list[str]]:
    """Da ``leo [opzioni] programma.leo ARGOMENTI`` a (argomenti per Leo, argomenti per il programma).

    Dopo il nome del programma restano a Leo solo ``--rigoroso``, ``--semplice``,
    ``--consiglio``, ``--tema``, ``--correggi``, ``--permetti`` e ``--permetti-tutto``; tutto
    il resto (anche ``--aiuto``) va al programma. Dopo ``--`` va tutto al programma.
    """
    leo: list[str] = []
    programma: list[str] = []
    argomenti = list(argv)
    i = 0
    trovato = False
    while i < len(argomenti):
        a = argomenti[i]
        if not trovato:
            leo.append(a)
            if a in _OPZIONI_LEO_CON_VALORE and i + 1 < len(argomenti):
                leo.append(argomenti[i + 1])
                i += 1
            elif a == "--" or not a.startswith("-") or a == "-":
                trovato = a != "--"
                if a == "--":
                    leo.pop()
                    if i + 1 < len(argomenti):      # `leo -- programma.leo ...`
                        leo.append(argomenti[i + 1])
                        i += 1
                        trovato = True
            i += 1
            continue
        if a == "--":
            programma.extend(argomenti[i + 1:])
            break
        if a in _OPZIONI_LEO_DOPO_PROGRAMMA or a.split("=", 1)[0] in _OPZIONI_LEO_CON_VALORE:
            leo.append(a)
            if a in _OPZIONI_LEO_CON_VALORE and i + 1 < len(argomenti):
                leo.append(argomenti[i + 1])
                i += 1
        else:
            programma.append(a)
        i += 1
    return leo, programma


#: Parole che nella riga di comando attivano un sottocomando.
COMANDI = ("aggiungi", "togli", "sincronizza", "pacchetti", "formatta", "nuovo", "studio", "spiega", "sfida",
           "impara", "compila", "verifica", "licenza", "firma", "permessi", "controlla",
           "lsp")

#: Cartelle ignorate da `leo formatta cartella`.
_CARTELLE_IGNORATE = {".venv", "venv", ".git", "__pycache__", "node_modules"}

_ENABLE_VIRTUAL_TERMINAL_PROCESSING = 0x0004
_ansi_windows_attivo: bool | None = None


# ---------------------------------------------------------------------------
# Console: UTF-8 e colori
# ---------------------------------------------------------------------------

def _attiva_ansi_windows() -> bool:
    """Attiva le sequenze ANSI nella console di Windows (SetConsoleMode). True se riuscito."""
    global _ansi_windows_attivo
    if _ansi_windows_attivo is not None:
        return _ansi_windows_attivo
    riuscito = False
    try:
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)  # type: ignore[attr-defined]
        kernel32.GetStdHandle.restype = wintypes.HANDLE
        for maniglia in (-11, -12):          # STD_OUTPUT_HANDLE, STD_ERROR_HANDLE
            h = kernel32.GetStdHandle(maniglia)
            modo = wintypes.DWORD()
            if not h or not kernel32.GetConsoleMode(h, ctypes.byref(modo)):
                continue
            if modo.value & _ENABLE_VIRTUAL_TERMINAL_PROCESSING:
                riuscito = True
                continue
            if kernel32.SetConsoleMode(h, modo.value | _ENABLE_VIRTUAL_TERMINAL_PROCESSING):
                riuscito = True
    except (AttributeError, ImportError, OSError, ValueError):
        riuscito = False
    _ansi_windows_attivo = riuscito
    return riuscito


def _codifica_utf8(flusso: Any) -> bool:
    try:
        import codecs

        return codecs.lookup(flusso.encoding).name == "utf-8"
    except (AttributeError, LookupError, TypeError):
        return False


def prepara_console() -> None:
    """Prepara ingresso e uscite anche quando non sono un terminale (pipe, Leo Studio).

    - Windows: uscite in UTF-8 e sequenze ANSI attive;
    - altrove, se l'uscita non e' UTF-8 (per esempio ``LANG=C``), i caratteri
      non rappresentabili diventano ``?`` invece di far fallire il programma;
    - un ingresso che non e' un terminale (dati da una pipe o da un file)
      tollera i byte non validi (diventano ``�``) invece di interrompere ``chiedi``.
    """
    for nome in ("stdout", "stderr"):
        flusso = getattr(sys, nome)
        if flusso is None or isinstance(flusso, FlussoTollerante):   # pythonw.exe: nessuna console
            continue
        try:
            if os.name == "nt":
                flusso.reconfigure(encoding="utf-8")  # type: ignore[union-attr]
            elif not _codifica_utf8(flusso):
                flusso.reconfigure(errors="replace")  # type: ignore[union-attr]
            continue
        except (AttributeError, ValueError, OSError):
            pass
        # Non si puo' riconfigurare (flusso sostituito da un altro programma):
        # se la codifica non e' UTF-8, i caratteri che non ci stanno diventano `?`.
        if isinstance(getattr(flusso, "encoding", None), str) and not _codifica_utf8(flusso):
            setattr(sys, nome, FlussoTollerante(flusso))
    ingresso = sys.stdin
    if ingresso is not None:
        try:
            if not ingresso.isatty():
                if os.name == "nt" and not os.environ.get("PYTHONIOENCODING"):
                    # Windows: una pipe o un file (Blocco note salva in UTF-8) non
                    # e' nella codifica locale cp1252; utf-8-sig toglie anche il BOM.
                    ingresso.reconfigure(encoding="utf-8-sig", errors="replace")  # type: ignore[union-attr]
                else:
                    ingresso.reconfigure(errors="replace")  # type: ignore[union-attr]
        except (AttributeError, ValueError, OSError):
            pass
    if os.name == "nt":
        _attiva_ansi_windows()


def testo_rappresentabile(testo: str, flusso: Any = None) -> str:
    """``testo`` con i caratteri che la codifica di ``flusso`` non conosce sostituiti da ``?``.

    Serve alle console che non sono UTF-8 (per esempio cp1252 su Windows):
    accenti ed emoji non devono mai far fallire Leo.
    """
    flusso = sys.stdout if flusso is None else flusso
    codifica = getattr(flusso, "encoding", None)
    if not isinstance(codifica, str) or not codifica:
        return testo
    try:
        return testo.encode(codifica, "replace").decode(codifica, "replace")
    except (LookupError, UnicodeError):
        return testo.encode("ascii", "replace").decode("ascii")


def puo_scrivere(testo: str, flusso: Any = None) -> bool:
    """True se ``flusso`` (predefinito ``sys.stdout``) sa scrivere tutti i caratteri di ``testo``."""
    flusso = sys.stdout if flusso is None else flusso
    codifica = getattr(flusso, "encoding", None)
    if not isinstance(codifica, str) or not codifica:
        return True                          # StringIO e simili: accettano tutto
    try:
        testo.encode(codifica)
    except (LookupError, UnicodeError):
        return False
    return True


class FlussoTollerante:
    """Avvolge un flusso d'uscita che non si puo' riconfigurare: se un carattere
    non esiste nella sua codifica, al suo posto si scrive ``?`` (invece di un errore)."""

    def __init__(self, flusso: Any) -> None:
        self._flusso = flusso

    def write(self, testo: str) -> int:
        try:
            return self._flusso.write(testo)
        except UnicodeEncodeError:
            return self._flusso.write(testo_rappresentabile(testo, self._flusso))

    def writelines(self, righe: Any) -> None:
        for riga in righe:
            self.write(riga)

    def __getattr__(self, nome: str) -> Any:
        return getattr(self._flusso, nome)


class _Console:
    """Uscita e ingresso dei programmi eseguiti dalla CLI (``stampa`` e ``chiedi``).

    Funziona anche quando ingresso e uscita non sono un terminale (pipe,
    reindirizzamenti, il terminale di Leo Studio che usa QProcess):

    - ogni scrittura viene inviata subito (``flush``), cosi' chi legge dalla
      pipe vede l'uscita mentre il programma gira;
    - ``chiedi`` legge una riga dall'ingresso standard; a fine dati solleva
      ``EOFError`` (l'interprete la trasforma in "Non ci sono più dati da leggere.");
    - ricorda se l'ultima riga scritta e' rimasta aperta (una domanda senza
      risposta), cosi' il messaggio d'errore comincia su una riga nuova;
    - se chi legge chiude la pipe (``leo prog.leo | more`` interrotto)
      il programma si ferma in silenzio invece di mostrare un errore.
    """

    def __init__(self) -> None:
        self.riga_aperta = False
        self.tubo_chiuso = False
        #: quante volte ``chiedi`` ha trovato l'ingresso finito
        self.fine_dati = 0
        #: True se il programma e' stato fermato perche' chiedeva ancora dati
        #: dopo la fine dell'ingresso (pipe o file): vedi :meth:`leggi`.
        self.fermato_per_fine_dati = False

    def scrivi(self, testo: str) -> None:
        if not testo:
            return
        if self.tubo_chiuso:
            self._ferma()
        try:
            try:
                sys.stdout.write(testo)
            except UnicodeEncodeError:            # console non UTF-8: `?` al posto dei caratteri mancanti
                sys.stdout.write(testo_rappresentabile(testo))
            sys.stdout.flush()
        except BrokenPipeError:
            self._chiudi_uscita()
            self._ferma()
        except (AttributeError, ValueError):
            return                               # nessuna uscita (pythonw.exe) o gia' chiusa
        self.riga_aperta = not testo.endswith("\n")

    def leggi(self, domanda: str) -> str:
        import builtins

        if domanda:
            self.riga_aperta = not domanda.endswith("\n")
        try:
            risposta = builtins.input(domanda)
        except BrokenPipeError:
            self._chiudi_uscita()
            self._ferma()
        except (EOFError, RuntimeError) as e:     # fine dei dati; RuntimeError: "lost sys.stdin"
            self._fine_dati()
            raise EOFError(str(e)) from None
        self.riga_aperta = False                  # l'Invio (o l'eco del terminale di Studio) va a capo
        return risposta.rstrip("\r")

    def _fine_dati(self) -> None:
        """L'ingresso e' finito. La prima volta ``chiedi`` da' l'errore normale
        (``ErroreValore``, che il programma puo' gestire con ``prova``). Se
        l'ingresso NON e' un terminale e il programma chiede ancora, i dati non
        arriveranno mai piu': si ferma il programma, altrimenti un ciclo come
        ``finché ... prova ... chiedi ... cattura ErroreValore`` girerebbe per
        sempre. (Da un terminale, dopo Ctrl+D si puo' scrivere ancora.)"""
        self.fine_dati += 1
        if self.fine_dati >= 2 and not _e_terminale(sys.stdin):
            self.fermato_per_fine_dati = True
            self._ferma()

    def chiudi_riga(self) -> None:
        """Va a capo se l'ultima riga scritta e' rimasta aperta (prima di un messaggio d'errore)."""
        if self.riga_aperta and not self.tubo_chiuso:
            self.riga_aperta = False
            try:
                sys.stdout.write("\n")
                sys.stdout.flush()
            except (BrokenPipeError, AttributeError, ValueError, OSError):
                pass

    def _chiudi_uscita(self) -> None:
        """Dopo una pipe chiusa: l'uscita standard punta a devnull (niente errori all'uscita di Python)."""
        self.tubo_chiuso = True
        try:
            nulla = os.open(os.devnull, os.O_WRONLY)
            os.dup2(nulla, sys.stdout.fileno())
            os.close(nulla)
        except (AttributeError, ValueError, OSError, io_UnsupportedOperation):
            pass

    @staticmethod
    def _ferma() -> None:
        from .errori import SegnaleFermaProgramma

        raise SegnaleFermaProgramma()


try:
    from io import UnsupportedOperation as io_UnsupportedOperation
except ImportError:  # pragma: no cover
    io_UnsupportedOperation = OSError  # type: ignore[misc,assignment]


def usa_colori(flusso: Any = None) -> bool:
    """True se su ``flusso`` (predefinito ``sys.stdout``) si possono usare i colori ANSI.

    Mai se la variabile d'ambiente ``NO_COLOR`` e' impostata (https://no-color.org).
    ``LEO_COLORI=1`` (o la vecchia ``DANTE_COLORI``) li forza anche su una pipe (lo imposta Leo Studio, il cui
    Terminale converte l'ANSI nei colori del tema); ``LEO_COLORI=0`` li spegne.
    Altrimenti no se ``TERM=dumb`` o se il flusso non e' un terminale. Su Windows
    servono le sequenze ANSI attivate.
    """
    if os.environ.get("NO_COLOR"):
        return False
    if os.environ.get("TERM") == "dumb":
        return False
    if variabile_ambiente("COLORI") == "1":
        # Leo Studio: l'uscita va in una pipe, ma il suo terminale interpreta le sequenze ANSI
        return True
    flusso = sys.stdout if flusso is None else flusso
    try:
        if not flusso.isatty():
            return False
    except (AttributeError, ValueError, OSError):
        return False
    if os.name == "nt":
        return _attiva_ansi_windows()
    return True


def _e_terminale(flusso: Any) -> bool:
    try:
        return bool(flusso is not None and flusso.isatty())
    except (AttributeError, ValueError, OSError):
        return False


#: Messaggio quando un programma chiede dati dopo la fine dell'ingresso (pipe o file).
MESSAGGIO_FINE_DATI = "Non ci sono più dati da leggere: il programma chiedeva ancora dati, quindi l'ho fermato."
SUGGERIMENTO_FINE_DATI = ("L'ingresso arriva da un file o da un altro programma ed è finito. "
                          "Aggiungi le risposte che mancano, oppure esegui il programma da un terminale.")


def errore_fine_dati() -> Any:
    """``ErroreValore`` da mostrare quando la CLI ferma un programma per fine dei dati."""
    from .errori import ErroreValore

    return ErroreValore(MESSAGGIO_FINE_DATI, suggerimento=SUGGERIMENTO_FINE_DATI)


def e_terminale_interattivo() -> bool:
    """True se sia l'ingresso sia l'uscita standard sono terminali (si possono fare domande)."""
    try:
        return bool(sys.stdin and sys.stdin.isatty() and sys.stdout and sys.stdout.isatty())
    except (AttributeError, ValueError, OSError):
        return False


def _carica_tema(nome: str | None) -> Any:
    """Tema per i colori (None se il modulo dei temi non e' disponibile). ErroreDante se sconosciuto."""
    try:
        from .temi import carica_tema
    except (ImportError, AttributeError):
        return None
    return carica_tema(nome or "nero")


class _TemaRimandato:
    """Il tema predefinito, caricato solo quando serve (per colorare un errore).

    Caricare ``leo.temi`` e leggere il TOML del tema costa ~10 ms a ogni avvio,
    e per un programma senza errori il tema non serve mai. Si rimanda solo il
    tema ``nero`` quando non c'e' un file dell'utente che lo sostituisce (ne' una
    cartella dati diversa): l'unico caso che poteva fallire all'avvio resta subito."""

    def __init__(self, nome: str) -> None:
        self.nome = nome
        self._tema: Any = None
        self._caricato = False

    def carica(self) -> Any:
        if not self._caricato:
            self._caricato = True
            try:
                self._tema = _carica_tema(self.nome)
            except Exception:  # noqa: BLE001 - senza tema il messaggio resta leggibile
                self._tema = None
        return self._tema

    @staticmethod
    def possibile(nome: str | None) -> bool:
        if (nome or "nero") != "nero" or variabile_ambiente("DATI") is not None:
            return False
        try:
            from .percorsi import cartella_utente

            return not (cartella_utente() / "temi" / "nero.toml").exists()
        except Exception:  # noqa: BLE001 - come temi._cartelle_temi: cartella utente ignorata
            return True


#: Opzioni dei messaggi d'errore (``--semplice``, ``--consiglio``; tema "innovazione").
OPZIONI_ERRORI: dict[str, bool] = {"semplice": False, "consiglio": False}


def _formatta(errore: Any, sorgente: str | None, *, tema: Any = None, colori: bool = False) -> str:
    """Messaggio d'errore in quattro parti (con ripiego se ``messaggi`` non e' pronto),
    piu' la riga corretta proposta e, a richiesta, livello semplice e consiglio del giorno."""
    # un errore dentro un file importato si mostra con il testo di quel file
    sorgente = getattr(errore, "sorgente_file", None) or sorgente
    if isinstance(tema, _TemaRimandato):
        tema = tema.carica()
    try:
        from .messaggi import formatta_errore

        testo = formatta_errore(errore, sorgente, tema=tema, colori=colori)
    except (ImportError, AttributeError):
        testo = None
    if testo is not None:
        try:
            from .errori_umani import arricchisci

            return arricchisci(testo, errore, sorgente, semplice=OPZIONI_ERRORI["semplice"],
                               consiglio=OPZIONI_ERRORI["consiglio"])
        except Exception:  # noqa: BLE001 - le aggiunte non devono mai far perdere il messaggio
            return testo
    try:
        return errore.formatta(sorgente)
    except Exception:  # noqa: BLE001 - il messaggio non si deve perdere
        return f"{type(errore).__name__}: {errore}"


def _stampa_errore(testo: str) -> None:
    if sys.stderr is None:                     # pythonw.exe: nessuna console
        return
    try:
        try:
            print(testo, file=sys.stderr, flush=True)
        except UnicodeEncodeError:             # console non UTF-8: il messaggio non si deve perdere
            print(testo_rappresentabile(testo, sys.stderr), file=sys.stderr, flush=True)
    except (BrokenPipeError, ValueError, OSError):
        pass


# ---------------------------------------------------------------------------
# Esecuzione in un thread con la pila grande
# ---------------------------------------------------------------------------

def esegui_con_pila_grande(funzione: Callable[[], Any], *,
                           al_interrupt: Callable[[], None] | None = None,
                           attesa_arresto: float = 2.0) -> Any:
    """Esegue ``funzione()`` in un ``threading.Thread`` con pila da 256 MB (64 MB su Android) e ne restituisce il risultato.

    Le eccezioni sollevate dentro il thread vengono risollevate qui. Se
    l'utente preme Ctrl+C mentre si aspetta, si chiama ``al_interrupt()``
    (per esempio ``interprete.ferma``), si attende al massimo
    ``attesa_arresto`` secondi e si solleva ``KeyboardInterrupt``. Se il
    sistema non permette di cambiare la pila, si esegue direttamente.
    """
    esito: dict[str, Any] = {}

    def corpo() -> None:
        try:
            esito["valore"] = funzione()
        except BaseException as e:  # noqa: BLE001 - si riporta al thread principale
            esito["errore"] = e

    from .piattaforma import e_android

    try:
        precedente = threading.stack_size(DIMENSIONE_PILA_ANDROID if e_android() else DIMENSIONE_PILA)
    except (ValueError, RuntimeError, OverflowError):
        return funzione()
    try:
        thread = threading.Thread(target=corpo, name="leo-programma", daemon=True)
        thread.start()
    except (RuntimeError, MemoryError):
        thread = None
    finally:
        try:
            threading.stack_size(precedente)
        except (ValueError, RuntimeError):
            pass
    if thread is None:
        return funzione()

    try:
        while thread.is_alive():
            thread.join(0.1)
    except KeyboardInterrupt:
        if al_interrupt is not None:
            try:
                al_interrupt()
            except Exception:  # noqa: BLE001
                pass
        limite = time.monotonic() + attesa_arresto
        try:
            while thread.is_alive() and time.monotonic() < limite:
                thread.join(0.05)
        except KeyboardInterrupt:
            pass
        raise KeyboardInterrupt from None
    if "errore" in esito:
        raise esito["errore"]
    return esito.get("valore")


# ---------------------------------------------------------------------------
# argparse in italiano
# ---------------------------------------------------------------------------

_TRADUZIONI = {
    "usage: ": "uso: ",
    "positional arguments": "argomenti",
    "optional arguments": "opzioni",
    "options": "opzioni",
    "show this help message and exit": "mostra questo aiuto ed esce",
    "show program's version number and exit": "mostra la versione ed esce",
    "the following arguments are required: %s": "mancano questi argomenti: %s",
    "unrecognized arguments: %s": "non capisco questi argomenti: %s",
    "argument %(argument_name)s: %(message)s": "argomento %(argument_name)s: %(message)s",
    "invalid choice: %(value)r (choose from %(choices)s)": "scelta non valida: %(value)r (scegli tra %(choices)s)",
    "invalid %(type)s value: %(value)r": "valore non valido: %(value)r",
    "expected one argument": "serve un valore",
    "expected at most one argument": "al massimo un valore",
    "expected at least one argument": "serve almeno un valore",
    "ignored explicit argument %r": "valore %r non previsto",
    "ambiguous option: %(option)s could match %(matches)s": "opzione ambigua: %(option)s può essere %(matches)s",
    "not allowed with argument %s": "non si può usare insieme a %s",
    "%(prog)s: error: %(message)s\n": "%(prog)s: errore: %(message)s\n",
}


def _traduci(testo: str) -> str:
    return _TRADUZIONI.get(testo, testo)


def _ngettext_italiano(singolare: str, plurale: str, n: int) -> str:
    if singolare == "expected %s argument":
        return "servono %s valori" if n != 1 else "serve %s valore"
    return singolare if n == 1 else plurale


@contextlib.contextmanager
def _argparse_in_italiano() -> Iterator[None]:
    """Traduce temporaneamente i messaggi fissi di argparse (usa ``argparse._``)."""
    vecchio = getattr(argparse, "_", None)
    vecchio_n = getattr(argparse, "ngettext", None)
    argparse._ = _traduci  # type: ignore[attr-defined]
    if vecchio_n is not None:
        argparse.ngettext = _ngettext_italiano  # type: ignore[attr-defined]
    try:
        yield
    finally:
        if vecchio is not None:
            argparse._ = vecchio  # type: ignore[attr-defined]
        if vecchio_n is not None:
            argparse.ngettext = vecchio_n  # type: ignore[attr-defined]


class _UsoSbagliato(Exception):
    """Errore di uso della riga di comando (codice d'uscita 2)."""


class _Analizzatore(argparse.ArgumentParser):
    """ArgumentParser che non chiama ``sys.exit`` e parla italiano."""

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        kwargs.setdefault("add_help", False)
        kwargs.setdefault("formatter_class", argparse.RawDescriptionHelpFormatter)
        super().__init__(*args, **kwargs)
        self.add_argument("-h", "--aiuto", "--help", action="help", default=argparse.SUPPRESS,
                          help="mostra questo aiuto ed esce")

    def error(self, message: str) -> None:  # type: ignore[override]
        raise _UsoSbagliato(message, self.prog)

    def exit(self, status: int = 0, message: str | None = None) -> None:  # type: ignore[override]
        if message:
            (sys.stderr if status else sys.stdout).write(message)
        raise SystemExit(status)


def _valore_correggi(testo: str) -> str:
    t = testo.strip().lower()
    if t in ("si", "sì", "sí", "s", "vero", "yes", "y"):
        return "si"
    if t in ("no", "n", "falso"):
        return "no"
    raise argparse.ArgumentTypeError(f"`{testo}` non va bene: scrivi `si` oppure `no`")


_DESCRIZIONE = f"""\
{NOME} {__version__}: linguaggio di programmazione con parole chiave italiane.

Comandi:
  leo                               apre il REPL (scrivi e prova il codice riga per riga)
  leo programma.leo                 esegue un programma
  leo cartella/                     esegue un progetto (grafico o testuale)
  leo formatta percorso...          sistema rientri e parole chiave dei file .leo
  leo nuovo cartella [--testuale]   crea un nuovo progetto
  leo studio [cartella]             apre Leo Studio
  leo spiega programma.leo          racconta cosa fa il programma (--semplice, --dettagli)
  leo verifica percorso             esegue le verifiche `verifica "nome" fai ... fine`
  leo controlla percorso            trova gli errori PRIMA di eseguire (nomi, argomenti, tipi, nulla...)
  leo sfida [numero]                rompicapi a livelli con verifica automatica
  leo impara [numero]               lezioni guidate, un passo alla volta
  leo compila percorso              crea un eseguibile Windows (.exe) autonomo
  leo compila percorso --apk        crea un'app Android (.apk) da installare sul telefono
  leo licenza [attiva CHIAVE|togli] prova gratuita e chiave di licenza di Leo Studio
  leo aggiungi requests             aggiunge al progetto un pacchetto Python (o leo:nome, ./cartella)
  leo togli requests                toglie un pacchetto dal progetto
  leo sincronizza                   rende l'ambiente del progetto identico a leo.lock
  leo pacchetti [--verifica]        elenca i pacchetti del progetto (vedi docs/PACCHETTI.md)
  leo permessi percorso             che cosa il programma può fare (rete, file, sistema...) e le scelte ricordate
  leo firma percorso                firma un programma o un progetto (--verifica per controllare una firma)
  leo lsp                           server del linguaggio per gli editor (VS Code, Neovim...)

Permessi: un programma usa liberamente solo la sua cartella; per rete, file altrove,
sistema, programmi, appunti e hardware Leo chiede la prima volta (vedi docs/PERMESSI.md).
  --permetti rete,file              concede queste categorie senza chiedere
  --permetti-tutto                  concede tutto (solo per programmi di cui ti fidi)
"""

_EPILOGO = """\
Esempi:
  leo saluto.leo
  leo voti.leo --rigoroso
  leo saluta.leo --nome Leo      (dopo il programma: argomenti suoi, vedi argomenti())
  leo formatta esempi/ --controlla
  leo nuovo Calcolatrice

Per l'aiuto di un comando: leo formatta --aiuto (o nuovo, studio).
Codici d'uscita: 0 tutto bene, 1 errore nel programma, 2 uso sbagliato del comando.
"""


def _parser_principale() -> _Analizzatore:
    p = _Analizzatore(prog="leo", description=_DESCRIZIONE, epilog=_EPILOGO)
    p.add_argument("percorso", nargs="?", default=None,
                   help="programma .leo o cartella di un progetto (senza: REPL)")
    p.add_argument("--rigoroso", action="store_true",
                   help="solo le parole chiave canoniche (niente sinonimi) e nessuna autocorrezione")
    p.add_argument("--correggi", type=_valore_correggi, default="si", metavar="si|no",
                   help="propone le correzioni degli errori di forma (predefinito: si; solo da terminale)")
    p.add_argument("--tema", default="nero", metavar="NOME",
                   help="tema dei colori: nero, bianco, alto_contrasto o un file .toml")
    p.add_argument("--semplice", action="store_true",
                   help="messaggi d'errore brevi e semplici, con un esempio corretto (per chi inizia)")
    p.add_argument("--consiglio", action="store_true",
                   help="aggiunge il consiglio del giorno ai messaggi d'errore")
    p.add_argument("--versione", "--version", action="version", version=f"{NOME} {__version__}\n{COPYRIGHT}",
                   help="mostra la versione ed esce")
    p.add_argument("--permetti", default="", metavar="CATEGORIE",
                   help="permessi concessi senza chiedere, separati da virgola: file, rete, sistema, processi, "
                        "appunti, hardware")
    p.add_argument("--permetti-tutto", dest="permetti_tutto", action="store_true",
                   help="concede tutti i permessi (solo per programmi di cui ti fidi)")
    return p


def _parser_permessi() -> _Analizzatore:
    p = _Analizzatore(prog="leo permessi",
                      description="Mostra che cosa un programma (o un progetto) può fare fuori dalla sua cartella: "
                                  "i permessi dichiarati, quelli che usa e le scelte che hai già fatto.")
    p.add_argument("percorso", help="programma .leo o cartella di un progetto")
    p.add_argument("--dimentica", action="store_true",
                   help="dimentica le scelte ricordate per questo programma (Leo chiederà di nuovo)")
    p.add_argument("--json", action="store_true", help="stampa il riepilogo in JSON (per Studio e strumenti)")
    return p


def _parser_firma() -> _Analizzatore:
    p = _Analizzatore(prog="leo firma",
                      description="Firma digitale (Ed25519) di programmi e progetti: chi lo riceve vede chi l'ha "
                                  "firmato e se qualcuno l'ha cambiato. Per firmare serve il pacchetto "
                                  "`cryptography`; per verificare no.")
    p.add_argument("percorso", nargs="?", default=None, help="programma .leo o cartella di un progetto")
    p.add_argument("--verifica", action="store_true", help="controlla la firma invece di firmare")
    p.add_argument("--autore", default=None, help="nome dell'autore scritto nella firma")
    p.add_argument("--crea-chiave", dest="crea_chiave", action="store_true",
                   help="crea la tua chiave di firma (una volta sola) e mostra la chiave pubblica")
    p.add_argument("--mia-chiave", dest="mia_chiave", action="store_true",
                   help="mostra la tua chiave pubblica, da dare a chi riceve i tuoi programmi")
    p.add_argument("--fidati", default=None, metavar="CHIAVE",
                   help="aggiunge una chiave pubblica a quelle di cui ti fidi")
    p.add_argument("--nome", default="", help="con --fidati: il nome di chi possiede la chiave")
    return p


def _parser_formatta() -> _Analizzatore:
    p = _Analizzatore(prog="leo formatta",
                      description="Formatta file .leo e cartelle (tutti i *.leo al loro interno).")
    p.add_argument("percorsi", nargs="+", metavar="percorso", help="file .leo o cartella")
    p.add_argument("--controlla", action="store_true",
                   help="non scrive nulla: esce con 1 se qualche file andrebbe formattato")
    p.add_argument("--rigoroso", action="store_true", help="non converte i sinonimi")
    return p


def _parser_nuovo() -> _Analizzatore:
    p = _Analizzatore(prog="leo nuovo", description="Crea un nuovo progetto Leo.")
    p.add_argument("cartella", help="cartella del progetto (viene creata)")
    p.add_argument("--testuale", action="store_true",
                   help="progetto senza finestre (solo principale.leo)")
    p.add_argument("--nome", default=None, help="nome del progetto (predefinito: nome della cartella)")
    return p


def _parser_spiega() -> _Analizzatore:
    p = _Analizzatore(prog="leo spiega",
                      description="Racconta in italiano semplice che cosa fa un programma.")
    p.add_argument("percorso", help="programma .leo da spiegare")
    livello = p.add_mutually_exclusive_group()
    livello.add_argument("--semplice", action="store_true", help="frasi brevi, per chi inizia")
    livello.add_argument("--dettagli", action="store_true",
                         help="anche il codice di ogni riga, note e un riepilogo")
    p.add_argument("--rigoroso", action="store_true", help="non converte i sinonimi")
    return p


def _parser_sfida() -> _Analizzatore:
    p = _Analizzatore(prog="leo sfida",
                      description="Piccoli rompicapi di programmazione a livelli, con verifica automatica. "
                                  "Senza numero: l'elenco delle sfide.")
    p.add_argument("numero", nargs="?", type=int, default=None, help="numero della sfida")
    p.add_argument("soluzione", nargs="?", default=None,
                   help="file .leo con la tua soluzione (senza: la scrivi qui, o arriva da una pipe)")
    p.add_argument("--azzera", action="store_true", help="cancella il progresso salvato")
    p.add_argument("--soluzione-esempio", dest="mostra_soluzione", action="store_true",
                   help="mostra una soluzione possibile (solo per le sfide già superate)")
    return p


def _parser_verifica() -> _Analizzatore:
    p = _Analizzatore(prog="leo verifica",
                      description="Esegue le verifiche incorporate (`verifica \"nome\" fai ... fine`) di un "
                                  "programma o di tutti i .leo di una cartella e stampa il rapporto. Del "
                                  "programma si preparano solo funzioni, variabili, costanti, `importa` e "
                                  "`quando`: il resto non parte.")
    p.add_argument("percorso", help="programma .leo o cartella")
    p.add_argument("--rigoroso", action="store_true", help="non converte i sinonimi")
    return p


def _parser_studio() -> _Analizzatore:
    p = _Analizzatore(prog="leo studio", description="Apre Leo Studio (serve PySide6).")
    p.add_argument("cartella", nargs="?", default=None, help="cartella del progetto da aprire")
    return p


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def main(argv: Sequence[str] | None = None) -> int:
    """Punto d'ingresso del comando `leo`. Restituisce il codice d'uscita (0, 1 o 2).

    Non lascia mai uscire un traceback: Ctrl+C da' "Interrotto." (codice 1),
    una pipe chiusa da chi legge termina in silenzio (codice 0), un errore
    interno diventa un messaggio in italiano (codice 1).
    """
    argv = list(sys.argv[1:] if argv is None else argv)
    prepara_console()
    # --rigoroso vale anche per l'interprete (niente tolleranze); si toglie alla fine,
    # cosi' chi chiama main() piu' volte nello stesso processo non se lo ritrova.
    rigoroso_prima = os.environ.get("LEO_RIGOROSO")
    try:
        return _smista(argv)
    except KeyboardInterrupt:
        _stampa_errore("\nInterrotto.")
        return USCITA_ERRORE
    except BrokenPipeError:                 # chi leggeva l'uscita ha chiuso la pipe
        _Console()._chiudi_uscita()
        return USCITA_OK
    except Exception as e:  # noqa: BLE001 - errore interno: mai un traceback nudo
        _stampa_errore_interno(e)
        return USCITA_ERRORE
    finally:
        if rigoroso_prima is None:
            os.environ.pop("LEO_RIGOROSO", None)
        else:
            os.environ["LEO_RIGOROSO"] = rigoroso_prima


def _smista(argv: list[str]) -> int:
    """Legge la riga di comando e chiama il sottocomando giusto."""
    with _argparse_in_italiano():
        try:
            if argv and argv[0] in COMANDI:
                comando, resto = argv[0], argv[1:]
                if comando in ("aggiungi", "togli", "sincronizza", "pacchetti"):   # gestore di pacchetti
                    from .pacchetti import comando_pacchetti

                    return comando_pacchetti(comando, resto)
                if comando == "formatta":
                    return _comando_formatta(_parser_formatta().parse_args(resto))
                if comando == "nuovo":
                    return _comando_nuovo(_parser_nuovo().parse_args(resto))
                if comando == "impara":             # tema bambini: lezioni guidate
                    from .lezioni import comando_impara

                    return comando_impara(resto)
                if comando == "spiega":                  # tema "innovazione"
                    return _comando_spiega(_parser_spiega().parse_args(resto))
                if comando == "sfida":                   # tema "innovazione"
                    return _comando_sfida(_parser_sfida().parse_args(resto))
                if comando == "verifica":                # test incorporati (leo/potenza.py)
                    return _comando_verifica(_parser_verifica().parse_args(resto))
                if comando == "controlla":               # controlli prima di eseguire (leo/controllo/)
                    from .controllo.cli import principale as comando_controlla

                    return comando_controlla(resto, _Analizzatore)
                if comando == "compila":                 # eseguibile Windows (leo/compila.py)
                    from .compila import comando_compila

                    return comando_compila(resto)
                if comando == "lsp":                     # server per gli editor (leo/lsp/)
                    from .lsp import comando_lsp

                    return comando_lsp(resto)
                if comando == "licenza":                 # prova e chiave (leo/licenza.py)
                    from .licenza import comando_licenza

                    return comando_licenza(resto)
                if comando == "permessi":                # leo/permessi.py
                    return _comando_permessi(_parser_permessi().parse_args(resto))
                if comando == "firma":                   # leo/firma_codice.py
                    return _comando_firma(_parser_firma().parse_args(resto))
                return _comando_studio(_parser_studio().parse_args(resto))
            argv, ARGOMENTI_PROGRAMMA[:] = separa_argomenti_programma(argv)
            args = _parser_principale().parse_args(argv)
        except _UsoSbagliato as e:
            messaggio = e.args[0] if e.args else ""
            prog = e.args[1] if len(e.args) > 1 else "leo"
            _stampa_errore(f"{prog}: {messaggio}\nScrivi `{prog} --aiuto` per vedere come si usa.")
            return USCITA_USO
        except SystemExit as e:           # --aiuto, --versione
            codice = e.code if isinstance(e.code, int) else (0 if e.code is None else USCITA_USO)
            return codice
    if getattr(args, "rigoroso", False):
        os.environ["LEO_RIGOROSO"] = "1"
    return _comando_principale(args)


def _comando_principale(args: argparse.Namespace) -> int:
    OPZIONI_ERRORI["semplice"] = bool(getattr(args, "semplice", False))
    OPZIONI_ERRORI["consiglio"] = bool(getattr(args, "consiglio", False))
    colori_err = usa_colori(sys.stderr)
    try:
        # senza un file (REPL) il tema serve subito; per un programma solo se c'e' un errore
        if args.percorso is not None and _TemaRimandato.possibile(args.tema):
            tema: Any = _TemaRimandato(args.tema or "nero")
        else:
            tema = _carica_tema(args.tema)
    except Exception as e:  # noqa: BLE001 - ErroreDante (tema sconosciuto) o file rovinato
        _stampa_errore(_formatta(e, None) if hasattr(e, "messaggio") else f"Tema non valido: {e}")
        return USCITA_USO

    if args.percorso is None:
        from .repl import Repl

        colori = usa_colori(sys.stdout)
        repl = Repl(rigoroso=args.rigoroso, colori=colori, tema=args.tema)
        repl.semplice = OPZIONI_ERRORI["semplice"]
        repl.consiglio = OPZIONI_ERRORI["consiglio"]
        return repl.esegui()

    percorso = Path(args.percorso)
    if not percorso.exists():
        _stampa_errore(f"leo: non trovo `{args.percorso}`.\n"
                       "Controlla il nome del file o della cartella (i programmi finiscono in `.leo`).")
        return USCITA_USO
    if not _attiva_permessi(percorso, args, colori_err):
        return USCITA_ERRORE
    try:
        if percorso.is_dir() or percorso.name == "progetto.toml":
            cartella = percorso if percorso.is_dir() else percorso.parent
            return _esegui_progetto(cartella, args, tema, colori_err)
        return _esegui_programma(percorso, args, tema, colori_err)
    finally:
        from . import permessi

        permessi.disattiva()


def _attiva_permessi(percorso: Path, args: argparse.Namespace, colori: bool) -> bool:
    """Prepara i permessi dell'esecuzione (leo/permessi.py); falso se il programma non deve partire."""
    from . import permessi
    from .errori import ErroreDante

    try:
        politica = permessi.attiva_per_programma(
            percorso, permetti_tutto=bool(getattr(args, "permetti_tutto", False)),
            permetti=[c for c in str(getattr(args, "permetti", "") or "").split(",") if c.strip()])
    except ErroreDante as e:
        _stampa_errore(_formatta(e, None, colori=colori))
        return False
    firma = getattr(politica, "firma", None)
    if firma is not None and not firma.valida:
        _stampa_errore(f"Attenzione: firma {firma.descrizione()}")
    return True


# ---------------------------------------------------------------------------
# Esecuzione di un file
# ---------------------------------------------------------------------------

def _opzioni_lessico(percorso: Path, rigoroso: bool) -> dict[str, Any]:
    """Stile e sinonimi del progetto che contiene il file (se c'e'), altrimenti solo ``rigoroso``.

    Senza progetto lo stile resta None: lo decide l'intestazione ``#stile:`` del file.
    """
    opzioni: dict[str, Any] = {"rigoroso": rigoroso}
    try:
        from .progetto import carica_progetto, e_progetto

        cartella = percorso.parent
        if e_progetto(cartella):
            progetto = carica_progetto(cartella)
            opzioni["stile"] = progetto.stile
            opzioni["rigoroso"] = rigoroso or progetto.rigoroso
            if progetto.sinonimi:
                opzioni["dizionari_sinonimi"] = [progetto.sinonimi]
            if progetto.file_sinonimi:
                opzioni["sinonimi_extra"] = [progetto.file_sinonimi]
    except (ImportError, AttributeError):
        pass
    return opzioni


def _leggi_sorgente(percorso: Path) -> str:
    from .errori import ErroreFile

    try:
        with open(percorso, "r", encoding="utf-8-sig") as f:
            return f.read()
    except UnicodeDecodeError as e:
        raise ErroreFile(f"`{percorso.name}` non è un file di testo UTF-8.",
                         suggerimento="Salvalo con la codifica UTF-8 (in Blocco note: Salva con nome > Codifica).") from e
    except OSError as e:
        raise ErroreFile(f"Non riesco a leggere `{percorso}`: {e.strerror or e}.") from e


def _esegui_una_volta(sorgente: str, nome_file: str, opzioni: dict[str, Any],
                      console: _Console | None = None, cartella: Path | None = None) -> None:
    """Analizza ed esegue il sorgente in un thread con pila grande (Ctrl+C ferma il programma).

    ``cartella``: cartella del programma, dove ``importa`` cerca per prima i file
    (serve quando ``leo`` viene lanciato da un'altra cartella)."""
    from .esecuzione import analizza
    from .interprete import Interprete
    from .stile import Stile

    stile = Stile.da_sorgente(sorgente, opzioni.get("stile"))
    interprete_rif: dict[str, Any] = {}
    console = console or _Console()

    def lavoro() -> None:
        programma = analizza(sorgente, nome_file, **opzioni)
        interprete = Interprete(nome_file=nome_file, sorgente=sorgente,
                                uscita=console.scrivi, ingresso=console.leggi,
                                dichiarazione_implicita=stile.dichiarazione_implicita)
        if cartella is not None:
            interprete.percorsi_moduli.append(str(cartella))
        interprete_rif["i"] = interprete
        interprete.esegui(programma)

    def ferma() -> None:
        i = interprete_rif.get("i")
        if i is not None:
            i.ferma()

    try:
        esegui_con_pila_grande(lavoro, al_interrupt=ferma)
    except KeyboardInterrupt:
        # un programma che vive di temporizzatori (`ogni ... fai`) si chiude con Ctrl+C:
        # e' la sua fine normale, non un errore
        i = interprete_rif.get("i")
        temporizzatori = getattr(i, "__dict__", {}).get("_temporizzatori") if i is not None else None
        if temporizzatori is not None and temporizzatori.in_ciclo and not temporizzatori.interrotto:
            # il filo del programma se ne accorge entro un attimo (controlla l'arresto ogni 50 ms)
            limite = time.monotonic() + 1.0
            try:
                while temporizzatori.in_ciclo and not temporizzatori.interrotto and time.monotonic() < limite:
                    time.sleep(0.01)
            except KeyboardInterrupt:
                pass
        if temporizzatori is not None and temporizzatori.interrotto:
            _svuota_stdout(console)
            console.scrivi("Temporizzatori fermati (Ctrl+C): il programma è finito.\n")
            return
        raise


def _puo_correggere(args: argparse.Namespace, opzioni: dict[str, Any]) -> bool:
    if getattr(args, "correggi", "si") == "no" or args.rigoroso or opzioni.get("rigoroso"):
        return False
    return e_terminale_interattivo()


def _esegui_programma(percorso: Path, args: argparse.Namespace, tema: Any, colori: bool,
                      *, opzioni: dict[str, Any] | None = None) -> int:
    from .errori import ErroreDante, ErroreSintassi

    if opzioni is None:
        opzioni = _opzioni_lessico(percorso, args.rigoroso)
    nome_file = percorso.name
    tentativi = 0
    avvisato = False
    while True:
        try:
            sorgente = _leggi_sorgente(percorso)
        except ErroreDante as e:
            _stampa_errore(_formatta(e, None, tema=tema, colori=colori))
            return USCITA_ERRORE
        if not avvisato:
            avvisato = True
            _stampa_avvisi(sorgente, percorso, opzioni)
        console = _Console()
        try:
            _esegui_una_volta(sorgente, nome_file, opzioni, console, percorso.resolve().parent)
            if console.fermato_per_fine_dati:
                _svuota_stdout(console)
                errore = errore_fine_dati()
                errore.nome_file = nome_file
                _stampa_errore(_formatta(errore, sorgente, tema=tema, colori=colori))
                return USCITA_ERRORE
            _concludi_tartaruga(percorso)
            return USCITA_OK
        except ErroreSintassi as e:
            if tentativi < 3 and _puo_correggere(args, opzioni) and _correggi(percorso, opzioni):
                tentativi += 1
                print("Eseguo...", flush=True)
                continue
            if opzioni.get("rigoroso"):
                aggiungi_nota_rigoroso(e, sorgente, opzioni)
            _stampa_errore(_formatta(e, sorgente, tema=tema, colori=colori))
            return USCITA_ERRORE
        except ErroreDante as e:
            _svuota_stdout(console)
            _stampa_errore(_formatta(e, sorgente, tema=tema, colori=colori))
            return USCITA_ERRORE
        except RecursionError:
            _svuota_stdout(console)
            _stampa_errore("ErroreRicorsione\n\nTroppe chiamate annidate: forse una funzione non si ferma mai.")
            return USCITA_ERRORE
        except KeyboardInterrupt:
            _svuota_stdout(console)
            _stampa_errore("\nProgramma interrotto (Ctrl+C).")
            return USCITA_ERRORE
        except BrokenPipeError:
            return USCITA_OK                      # chi leggeva l'uscita ha chiuso la pipe
        except Exception as e:  # noqa: BLE001 - errore interno: mai un traceback nudo
            _svuota_stdout(console)
            _stampa_errore_interno(e)
            return USCITA_ERRORE


def _stampa_avvisi(sorgente: str, percorso: Path, opzioni: dict[str, Any]) -> None:
    """Avvisi prima di eseguire (testo confrontato con un numero, `quando` senza finestra...)."""
    try:
        from .avvisi import testo_avvisi

        testo = testo_avvisi(sorgente, str(percorso), semplice=OPZIONI_ERRORI["semplice"], **opzioni)
    except Exception:  # noqa: BLE001 - gli avvisi non devono mai fermare il programma
        return
    if testo:
        _stampa_errore(testo + "\n")


def _concludi_tartaruga(percorso: Path) -> None:
    """Tema bambini: a fine programma mostra (o salva in SVG) il disegno della tartaruga."""
    if "leo.tartaruga" not in sys.modules:
        return      # nessuna tartaruga creata: niente da mostrare (e niente import all'uscita)
    try:
        from .tartaruga import concludi_programma
    except ImportError:
        return
    try:
        concludi_programma(str(percorso))
    except Exception as e:  # noqa: BLE001 - il disegno non deve rovinare un programma riuscito
        _stampa_errore(f"Non sono riuscito a mostrare il disegno della tartaruga: {e}")


def sinonimi_nella_riga(riga: str, opzioni: dict[str, Any] | None = None) -> list[tuple[str, str]]:
    """Sinonimi (di sistema e del progetto) scritti in ``riga``: lista di (sinonimo, parola canonica).

    Serve a spiegare gli errori di ``--rigoroso``: ``procedura saluta()`` non e'
    piu' capita perche' ``procedura`` e' solo un sinonimo di ``funzione``.
    """
    import re

    opzioni = opzioni or {}
    try:
        from .sinonimi import carica_sinonimi

        sinonimi = carica_sinonimi(opzioni.get("sinonimi_extra") or (),
                                   dizionari_extra=opzioni.get("dizionari_sinonimi") or ())
    except Exception:  # noqa: BLE001 - la nota e' solo un aiuto in piu'
        return []
    codice = riga.split("#", 1)[0]
    codice = re.sub(r'"(?:[^"\\]|\\.)*"?', " ", codice)       # niente parole dentro i testi
    parole = re.findall(r"[^\W\d]\w*'?", codice)
    trovati: list[tuple[str, str]] = []
    i = 0
    massimo = max(1, sinonimi.lunghezza_massima)
    while i < len(parole):
        for n in range(min(massimo, len(parole) - i), 0, -1):
            gruppo = parole[i:i + n]
            canonica = sinonimi.canonica_di(" ".join(gruppo))
            if canonica:
                trovati.append((" ".join(gruppo), canonica))
                i += n
                break
        else:
            i += 1
    return trovati


def aggiungi_nota_rigoroso(errore: Any, sorgente: str | None, opzioni: dict[str, Any] | None = None) -> None:
    """Con ``--rigoroso``: se la riga dell'errore usa sinonimi, lo dice nel suggerimento."""
    riga = getattr(errore, "riga", None)
    if not sorgente or not isinstance(riga, int) or riga < 1:
        return
    righe = sorgente.splitlines()
    if riga > len(righe):
        return
    trovati = sinonimi_nella_riga(righe[riga - 1], opzioni)
    if not trovati:
        return
    elenco = ", ".join(f"`{s}` al posto di `{c}`" for s, c in trovati)
    nota = (f"Con --rigoroso valgono solo le parole chiave canoniche: qui c'è {elenco}. "
            "Usa la parola canonica (anche con `leo formatta`) oppure togli --rigoroso.")
    vecchio = getattr(errore, "suggerimento", None)
    errore.suggerimento = f"{vecchio}\n{nota}" if vecchio else nota


def _svuota_stdout(console: _Console | None = None) -> None:
    """Invia l'uscita in sospeso e, se serve, va a capo (l'errore comincia su una riga nuova)."""
    if console is not None:
        console.chiudi_riga()
    try:
        sys.stdout.flush()
    except (AttributeError, ValueError, OSError):
        pass


def _stampa_errore_interno(e: BaseException) -> None:
    testo = (f"Errore interno di Leo ({type(e).__name__}: {e}).\n"
             "Non è colpa del tuo programma: se puoi, segnalalo insieme al file che stavi eseguendo.")
    if variabile_ambiente("DEBUG"):
        import traceback

        testo += "\n\n" + "".join(traceback.format_exception(type(e), e, e.__traceback__))
    _stampa_errore(testo)


def _correggi(percorso: Path, opzioni: dict[str, Any]) -> bool:
    """Propone le correzioni di forma, chiede conferma, salva la copia ``.bak``. True se corretto."""
    try:
        from .correzioni import correggi_file
    except (ImportError, AttributeError):
        return False
    lessico = {k: v for k, v in opzioni.items() if k in ("stile", "rigoroso", "sinonimi_extra", "dizionari_sinonimi")}
    try:
        return bool(correggi_file(percorso, ingresso=input, uscita=print, **lessico))
    except (EOFError, KeyboardInterrupt):
        print()
        return False


# ---------------------------------------------------------------------------
# Progetti
# ---------------------------------------------------------------------------

def _esegui_progetto(cartella: Path, args: argparse.Namespace, tema: Any, colori: bool) -> int:
    from .errori import ErroreDante
    from .progetto import carica_progetto, e_progetto

    if not e_progetto(cartella):
        _stampa_errore(f"leo: nella cartella `{cartella}` manca `progetto.toml`, quindi non è un progetto Leo.\n"
                       f"Per crearne uno: leo nuovo {cartella}")
        return USCITA_USO
    try:
        progetto = carica_progetto(cartella)
    except ErroreDante as e:
        _stampa_errore(_formatta(e, None, tema=tema, colori=colori))
        return USCITA_ERRORE
    rigoroso = bool(args.rigoroso or progetto.rigoroso)

    if progetto.e_grafico:
        return _esegui_progetto_grafico(cartella, rigoroso)

    principale = progetto.percorso_principale
    if not principale.is_file():
        _stampa_errore(f"Il progetto `{progetto.nome}` non ha finestre e manca il file `{progetto.principale}`.\n"
                       "Crea quel file oppure aggiungi una finestra con Leo Studio.")
        return USCITA_ERRORE
    opzioni: dict[str, Any] = {"stile": progetto.stile, "rigoroso": rigoroso}
    if progetto.sinonimi:
        opzioni["dizionari_sinonimi"] = [progetto.sinonimi]
    if progetto.file_sinonimi:
        opzioni["sinonimi_extra"] = [progetto.file_sinonimi]
    return _esegui_programma(principale, args, tema, colori, opzioni=opzioni)


def _pyside6_presente() -> bool:
    import importlib.util

    try:
        return importlib.util.find_spec("PySide6") is not None
    except (ImportError, ValueError):
        return False


_MESSAGGIO_PYSIDE6 = ("Questo progetto ha delle finestre: per eseguirlo installa PySide6 con:\n"
                      "    pip install PySide6\n"
                      "(su Windows puoi anche rilanciare installa.bat nella cartella di Leo).")


def _esegui_progetto_grafico(cartella: Path, rigoroso: bool) -> int:
    if not _pyside6_presente():
        _stampa_errore(_MESSAGGIO_PYSIDE6)
        return USCITA_ERRORE
    try:
        from .grafica.qt.applicazione import esegui_progetto
    except ImportError as e:
        _stampa_errore(f"{_MESSAGGIO_PYSIDE6}\n(dettaglio: {e})")
        return USCITA_ERRORE
    except AttributeError:
        esegui_progetto = None  # type: ignore[assignment]
    if esegui_progetto is None:
        _stampa_errore("Il motore grafico di Leo non è disponibile in questa installazione.")
        return USCITA_ERRORE
    try:
        codice = esegui_progetto(cartella, rigoroso=rigoroso)
    except KeyboardInterrupt:
        return USCITA_ERRORE
    except Exception as e:  # noqa: BLE001
        from .errori import ErroreDante

        if isinstance(e, ErroreDante):
            _stampa_errore(_formatta(e, None, colori=usa_colori(sys.stderr)))
            return USCITA_ERRORE
        _stampa_errore_interno(e)
        return USCITA_ERRORE
    return int(codice or 0)


# ---------------------------------------------------------------------------
# leo formatta
# ---------------------------------------------------------------------------

def _file_da_formattare(cartella: Path) -> list[Path]:
    trovati: list[Path] = []
    for radice, cartelle, file in os.walk(cartella):
        cartelle[:] = sorted(c for c in cartelle if c not in _CARTELLE_IGNORATE and not c.startswith("."))
        for nome in sorted(file):
            if e_sorgente(nome):
                trovati.append(Path(radice) / nome)
    return trovati


def _controlla_rigoroso(percorso: Path) -> None:
    """``leo formatta --rigoroso``: il file deve essere valido con le sole parole
    canoniche, altrimenti ErroreSintassi (con la nota sui sinonimi).

    Senza questo controllo un sinonimo (``finché`` al posto di ``mentre``) non
    sarebbe riconosciuto come inizio di blocco e il formattatore toglierebbe il
    rientro al corpo del ciclo."""
    from .errori import ErroreSintassi
    from .esecuzione import analizza

    sorgente = percorso.read_text(encoding="utf-8-sig")
    opzioni = _opzioni_lessico(percorso, True)
    try:
        analizza(sorgente, percorso.name, **opzioni)
    except ErroreSintassi as e:
        aggiungi_nota_rigoroso(e, sorgente, opzioni)
        raise


def _comando_formatta(args: argparse.Namespace) -> int:
    from .errori import ErroreDante

    try:
        from .formattatore import formatta_file
    except (ImportError, AttributeError):
        _stampa_errore("Il formattatore non è disponibile in questa installazione.")
        return USCITA_ERRORE

    file: list[Path] = []
    for testo in args.percorsi:
        p = Path(testo)
        if p.is_dir():
            file.extend(_file_da_formattare(p))
        elif p.is_file():
            file.append(p)
        else:
            _stampa_errore(f"leo formatta: non trovo `{testo}`.")
            return USCITA_USO
    opzioni: dict[str, Any] = {}
    if args.rigoroso:
        from .sinonimi import Sinonimi

        opzioni["sinonimi"] = Sinonimi.vuoti()

    colori = usa_colori(sys.stderr)
    cambiati: list[Path] = []
    errori = 0
    for f in file:
        try:
            if args.rigoroso:
                _controlla_rigoroso(f)
            if formatta_file(f, controlla=args.controlla, **opzioni):
                cambiati.append(f)
                print(f"Da formattare: {f}" if args.controlla else f"Formattato {f}")
        except ErroreDante as e:
            errori += 1
            try:
                sorgente = f.read_text(encoding="utf-8-sig")
            except (OSError, UnicodeDecodeError):
                sorgente = None
            nome_errore = str(getattr(e, "nome_file", "") or "")
            if not nome_errore or nome_errore.startswith("<"):      # "<sorgente>", "<formatta>"
                e.nome_file = f.name
            _stampa_errore(f"Non posso formattare {f}:\n\n" + _formatta(e, sorgente, colori=colori))
        except UnicodeDecodeError:
            errori += 1
            _stampa_errore(f"Non posso formattare {f}: non è un file di testo UTF-8.\n"
                           "Salvalo con la codifica UTF-8 (in Blocco note: Salva con nome > Codifica).")
        except OSError as e:
            errori += 1
            _stampa_errore(f"Non posso formattare {f}: {e.strerror or e}.")

    n = len(file)
    if args.controlla:
        if cambiati:
            print(f"{len(cambiati)} file su {n} andrebbero formattati: usa `leo formatta` senza --controlla.")
        else:
            print(f"Tutto in ordine: {n} file controllati.")
    else:
        print(f"Formattati {len(cambiati)} file su {n}.")
    if errori or (args.controlla and cambiati):
        return USCITA_ERRORE
    return USCITA_OK


# ---------------------------------------------------------------------------
# leo nuovo / leo studio
# ---------------------------------------------------------------------------

def _comando_nuovo(args: argparse.Namespace) -> int:
    from .errori import ErroreDante
    from .progetto import NOME_FILE_PROGETTO, crea_progetto

    cartella = Path(args.cartella)
    if (cartella / NOME_FILE_PROGETTO).exists():
        _stampa_errore(f"In `{cartella}` c'è già un progetto: scegli un'altra cartella.")
        return USCITA_ERRORE
    if cartella.exists() and not cartella.is_dir():
        _stampa_errore(f"`{cartella}` esiste già ed è un file, non una cartella.")
        return USCITA_USO
    try:
        progetto = crea_progetto(cartella, args.nome, con_finestra=not args.testuale)
    except ErroreDante as e:
        _stampa_errore(_formatta(e, None))
        return USCITA_ERRORE
    except (OSError, ImportError) as e:
        _stampa_errore(f"Non riesco a creare il progetto in `{cartella}`: {e}.")
        return USCITA_ERRORE
    tipo = "testuale" if args.testuale else "con una finestra"
    print(f"Creato il progetto {tipo} `{progetto.nome}` in {cartella}.")
    if args.testuale:
        print(f"Scrivi il codice in {progetto.percorso_principale} e poi eseguilo con:  leo {cartella}")
    else:
        print(f"Aprilo con:  leo studio {cartella}   oppure eseguilo con:  leo {cartella}")
    return USCITA_OK


def _comando_studio(args: argparse.Namespace) -> int:
    if args.cartella is not None and not Path(args.cartella).exists():
        _stampa_errore(f"leo studio: non trovo `{args.cartella}`.")
        return USCITA_USO
    try:
        from .studio.__main__ import main as studio_main
    except ImportError as e:
        _stampa_errore(f"Leo Studio non è disponibile: {e}.")
        return USCITA_ERRORE
    try:
        codice = studio_main([args.cartella] if args.cartella else [])
    except KeyboardInterrupt:
        return USCITA_ERRORE
    except Exception as e:  # noqa: BLE001 - mai un traceback nudo
        _stampa_errore_interno(e)
        return USCITA_ERRORE
    try:
        return int(codice or 0)
    except (TypeError, ValueError):
        return USCITA_ERRORE


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())


# ---------------------------------------------------------------------------
# leo spiega / leo sfida (tema "innovazione")
# ---------------------------------------------------------------------------

def _comando_spiega(args: argparse.Namespace) -> int:
    from .errori import ErroreDante
    from .spiega import spiega_sorgente

    percorso = Path(args.percorso)
    if not percorso.is_file():
        _stampa_errore(f"leo spiega: non trovo il file `{args.percorso}`.")
        return USCITA_USO
    livello = "semplice" if args.semplice else "dettagli" if args.dettagli else "normale"
    sorgente = ""
    try:
        sorgente = _leggi_sorgente(percorso)
        opzioni = _opzioni_lessico(percorso, args.rigoroso)
        testo = spiega_sorgente(sorgente, percorso.name, livello=livello, **opzioni)
    except ErroreDante as e:
        OPZIONI_ERRORI["semplice"] = livello == "semplice"
        _stampa_errore("Prima di spiegarlo, bisogna correggere un errore:\n\n"
                       + _formatta(e, sorgente or None, colori=usa_colori(sys.stderr),
                                   tema=_carica_tema_sicuro()))
        return USCITA_ERRORE
    print(testo, flush=True)
    try:
        from .permessi import riepilogo

        print("\n" + riepilogo(percorso, sorgente).testo(), flush=True)
    except ErroreDante as e:          # dichiarazione dei permessi scritta male
        print("\nPermessi: " + e.messaggio, flush=True)
    return USCITA_OK


def _comando_permessi(args: argparse.Namespace) -> int:
    """``leo permessi percorso``: riepilogo dei permessi (dichiarati, usati, ricordati)."""
    from . import permessi
    from .errori import ErroreDante

    percorso = Path(args.percorso)
    if not percorso.exists():
        _stampa_errore(f"leo permessi: non trovo `{args.percorso}`.")
        return USCITA_USO
    if args.dimentica:
        c = permessi.dimentica(permessi.chiave_programma(percorso))
        print("Scelte dimenticate: Leo chiederà di nuovo." if c else "Per questo programma non c'erano scelte ricordate.")
        return USCITA_OK
    try:
        r = permessi.riepilogo(percorso)
    except ErroreDante as e:
        _stampa_errore(_formatta(e, None, colori=usa_colori(sys.stderr)))
        return USCITA_ERRORE
    if args.json:
        import json

        print(json.dumps(r.a_dizionario(), ensure_ascii=False, indent=1))
        return USCITA_OK
    print(r.testo())
    if r.concessi:
        print("Scelte ricordate (sì, sempre): " + ", ".join(f"{c} {v}" for c, v in r.concessi))
        print("Per dimenticarle: leo permessi " + str(args.percorso) + " --dimentica")
    return USCITA_OK


def _comando_firma(args: argparse.Namespace) -> int:
    """``leo firma``: firma e verifica di programmi e progetti (leo/firma_codice.py)."""
    from . import firma_codice as fc
    from .errori import ErroreDante

    try:
        if args.crea_chiave:
            chiave = fc.crea_chiave()
            print("La tua chiave di firma è pronta. Chiave pubblica (da dare a chi riceve i tuoi programmi):")
            print(chiave)
            print(f"Impronta da confrontare a voce: {fc.impronta_chiave(chiave)}")
            return USCITA_OK
        if args.mia_chiave:
            chiave = fc.chiave_pubblica()
            if not chiave:
                _stampa_errore("Non hai ancora una chiave di firma: creala con `leo firma --crea-chiave`.")
                return USCITA_ERRORE
            print(chiave)
            print(f"Impronta: {fc.impronta_chiave(chiave)}")
            return USCITA_OK
        if args.fidati:
            impronta = fc.aggiungi_fidata(args.fidati, args.nome)
            print(f"Chiave {impronta} aggiunta a quelle di cui ti fidi"
                  + (f" ({args.nome})." if args.nome else "."))
            return USCITA_OK
        if not args.percorso:
            _stampa_errore("leo firma: indica il programma o il progetto (oppure --crea-chiave).")
            return USCITA_USO
        percorso = Path(args.percorso)
        if not percorso.exists():
            _stampa_errore(f"leo firma: non trovo `{args.percorso}`.")
            return USCITA_USO
        if args.verifica:
            esito = fc.verifica_file(percorso)
            if esito is None:
                print(f"`{percorso.name}` non è firmato.")
                return USCITA_ERRORE
            print(f"`{percorso.name}`: {esito.descrizione()}")
            for m in esito.modificati:
                print(f"  - {m}")
            return USCITA_OK if esito.valida else USCITA_ERRORE
        if not fc.chiave_pubblica():
            fc.crea_chiave()
            print("Ho creato la tua chiave di firma (la prima volta).")
        esito = fc.firma_file(percorso, args.autore)
        print(f"`{percorso.name}` firmato. {esito.descrizione()}")
        return USCITA_OK
    except ErroreDante as e:
        _stampa_errore(_formatta(e, None, colori=usa_colori(sys.stderr)))
        return USCITA_ERRORE


def _file_da_verificare(percorso: Path) -> list[Path]:
    if percorso.is_file():
        return [percorso]
    trovati = []
    for f in sorted(percorso.rglob("*.leo")):
        parti = f.relative_to(percorso).parts
        if any(p.startswith(".") or p == "__pycache__" for p in parti[:-1]):
            continue
        trovati.append(f)
    return trovati


def _comando_verifica(args: argparse.Namespace) -> int:
    """``leo verifica file.leo|cartella``: rapporto verde/rosso delle verifiche incorporate."""
    from .errori import ErroreDante
    from .potenza import esegui_verifiche, rapporto

    percorso = Path(args.percorso)
    if not percorso.exists():
        _stampa_errore(f"leo verifica: non trovo `{args.percorso}`.")
        return USCITA_USO
    if args.rigoroso:
        os.environ["LEO_RIGOROSO"] = "1"
    file = _file_da_verificare(percorso)
    if not file:
        _stampa_errore(f"leo verifica: in `{args.percorso}` non ci sono file .leo.")
        return USCITA_USO
    colori = usa_colori(sys.stdout)
    tema = _carica_tema_sicuro()
    rapporti = []
    for f in file:
        try:
            sorgente = _leggi_sorgente(f)
        except ErroreDante as e:
            from .potenza import RapportoVerifiche

            rapporti.append(RapportoVerifiche(f.name, errore=e))
            continue
        opzioni = _opzioni_lessico(f, args.rigoroso)
        nome = f.name if percorso.is_file() else str(f.relative_to(percorso))
        r = esegui_verifiche(sorgente, f.name, cartella=str(f.resolve().parent), **opzioni)
        r.nome_file = nome
        rapporti.append(r)

    def formatta_errore(errore: Any, sorgente: str) -> str:
        return _formatta(errore, sorgente or None, tema=tema, colori=colori)

    testo = rapporto(rapporti, colori=colori, formatta_errore=formatta_errore)
    print(testo_rappresentabile(testo, sys.stdout), flush=True)
    tutto_bene = all(r.errore is None and not r.fallite for r in rapporti)
    return USCITA_OK if tutto_bene else USCITA_ERRORE


def _carica_tema_sicuro() -> Any:
    try:
        return _carica_tema("nero")
    except Exception:  # noqa: BLE001
        return None


def _leggi_soluzione_sfida() -> str:
    """Il programma dello studente: da una pipe tutto l'ingresso, da terminale fino a `:fatto`."""
    if not e_terminale_interattivo():
        try:
            testo = sys.stdin.read() if sys.stdin is not None else ""
        except (OSError, ValueError):
            testo = ""
        righe = testo.replace("\r\n", "\n").split("\n")
        if ":fatto" in (r.strip() for r in righe):
            righe = righe[:[r.strip() for r in righe].index(":fatto")]
        return "\n".join(righe)
    print("Scrivi il tuo programma. Quando hai finito scrivi `:fatto` su una riga (o premi Ctrl+D).")
    righe: list[str] = []
    while True:
        try:
            riga = input("sfida> ")
        except EOFError:
            print()
            break
        if riga.strip() == ":fatto":
            break
        righe.append(riga)
    return "\n".join(righe) + "\n"


def _comando_sfida(args: argparse.Namespace) -> int:
    from . import sfide

    if args.azzera:
        sfide.salva_progresso(set())
        print("Progresso delle sfide cancellato: si riparte dalla sfida 1.")
        return USCITA_OK
    superate = sfide.carica_progresso()
    if args.numero is None:
        print(sfide.elenco(superate))
        return USCITA_OK
    try:
        s = sfide.sfida(args.numero)
    except KeyError:
        _stampa_errore(f"leo sfida: la sfida {args.numero} non esiste. "
                       f"Le sfide vanno da 1 a {len(sfide.SFIDE)}.")
        return USCITA_USO
    if not sfide.sbloccata(s.numero, superate):
        _stampa_errore(f"La sfida {s.numero} è ancora chiusa: prima supera la sfida {s.numero - 1} "
                       f"(`leo sfida {s.numero - 1}`).")
        return USCITA_USO
    if args.mostra_soluzione:
        if s.numero not in superate:
            _stampa_errore("La soluzione d'esempio si vede solo dopo aver superato la sfida.")
            return USCITA_USO
        print(s.soluzione, end="")
        return USCITA_OK
    print(sfide.presentazione(s))
    print()
    if args.soluzione is not None:
        percorso = Path(args.soluzione)
        try:
            sorgente = _leggi_sorgente(percorso)
        except Exception as e:  # noqa: BLE001 - ErroreDante (file illeggibile)
            _stampa_errore(f"leo sfida: non riesco a leggere `{args.soluzione}` ({e}).")
            return USCITA_USO
    else:
        sorgente = _leggi_soluzione_sfida()
    esito = sfide.verifica(s, sorgente)
    print(esito.testo())
    if not esito.superata:
        return USCITA_ERRORE
    superate.add(s.numero)
    sfide.salva_progresso(superate)
    prossima = next((x for x in sfide.SFIDE if x.numero not in superate), None)
    if prossima is None:
        print("Hai superato tutte le sfide.")
    else:
        print(f"Prossima sfida: `leo sfida {prossima.numero}` ({prossima.titolo}).")
    return USCITA_OK
