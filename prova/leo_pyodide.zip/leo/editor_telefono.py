"""Aiuti dell'editor dell'app Android: suggerimenti mentre scrivi e una riga di aiuto.

Logica pura (niente Android, niente Qt), provata sul PC. Il ponte dell'app
(``leo_android.completa``) la chiama in sfondo e manda il risultato alla pagina,
che lo mostra sopra la tastiera (``app.js``). I suggerimenti vengono dal motore di
Leo Studio (:func:`leo.completamento.suggerimenti`): parole chiave, blocchi pronti,
funzioni della libreria, variabili e funzioni del programma, controlli della
finestra con proprieta', metodi ed eventi (``quando Pulsante1.clic fai``).

Le posizioni che escono di qui sono gia' in unita' UTF-16 (gli indici delle
stringhe JavaScript), cosi' la pagina non deve convertire nulla.

API::

    completa(codice, riga, colonna, controlli=None, voci=True, aiuto=True, lettura=False, da=0, a=0) -> dict
    lettura_telefono(codice, riga, colonna, da, a, controlli=None) -> dict   ("Leo scrive con te")
    aiuto_contestuale(codice, riga, colonna, controlli=None) -> str
    controlli_dal_codice(codice) -> dict[str, None]
"""

from __future__ import annotations

import re
from typing import Any, Mapping

from . import completamento as c

__all__ = ["completa", "aiuto_contestuale", "controlli_dal_codice", "lettura_telefono", "LIMITE_VOCI"]

#: Quante righe visibili al massimo ricevono le pastiglie in una risposta.
LIMITE_RIGHE_PASTIGLIE = 160

#: Quante voci al massimo nella barra sopra la tastiera (scorre in orizzontale).
LIMITE_VOCI = 12

_NOME = r"[^\W\d]\w*"
_RE_QUANDO = re.compile(rf"^[ \t]*quando[ \t]+({_NOME})[ \t]*\.", re.MULTILINE | re.UNICODE)
_RE_USO = re.compile(rf"(?<![\w.])([A-Z]\w*)\.[^\W\d]\w*", re.UNICODE)
_RE_PAROLA = re.compile(r"\w+", re.UNICODE)

#: Funzioni della libreria che chi comincia usa di piu': vengono prima delle altre.
COMUNI = frozenset({
    "stampa", "chiedi", "intero", "decimale", "testo", "lunghezza", "casuale", "attendi", "arrotonda",
    "scegli_a_caso", "mescola", "somma", "massimo", "minimo", "radice", "assoluto", "media", "ora", "oggi",
    "messaggio", "domanda", "apri_finestra", "chiudi_finestra", "intervallo", "vuota", "ordina", "potenza",
    "numero", "lista", "tipo", "unisci", "dividi", "maiuscolo", "minuscolo", "contiene",
})

#: Moduli della libreria pensati per il computer (Windows, desktop, sistema): sul telefono
#: in fondo all'elenco.
_MODULI_PC = frozenset({"leo.libreria.computer", "leo.libreria.desktop", "leo.libreria.sistema"})


def _u16(testo: str) -> int:
    """Lunghezza di ``testo`` in unita' UTF-16 (come ``String.length`` in JavaScript)."""
    if testo.isascii():
        return len(testo)
    return len(testo.encode("utf-16-le")) // 2


def controlli_dal_codice(codice: str) -> dict[str, None]:
    """Nomi dei controlli ricavati dal codice (``quando Pulsante1.clic``, ``Etichetta1.testo = ...``).

    Serve quando la maschera non c'e' (il codice di un esempio): il tipo si
    ricava poi dal nome (``PulsanteSaluta`` -> ``Pulsante``).
    """
    nomi: dict[str, None] = {}
    for m in _RE_QUANDO.finditer(codice):
        nomi.setdefault(m.group(1), None)
    for riga in codice.split("\n"):
        senza = riga.split("#", 1)[0]
        if '"' in senza:
            senza = re.sub(r'"(?:[^"\\]|\\.)*"?', '""', senza)
        for m in _RE_USO.finditer(senza):
            nome = m.group(1)
            if c.tipo_da_nome(nome):
                nomi.setdefault(nome, None)
    return nomi


def _modulo_di(nome: str) -> str:
    """Modulo Python della funzione di libreria ``nome`` ("" se non e' della libreria)."""
    moduli = c._CACHE.get("telefono_moduli")
    if moduli is None:
        moduli = {}
        try:
            from . import registro

            registro.carica_libreria()
            for n, f in registro.FUNZIONI.items():
                m = getattr(getattr(f, "funzione", None), "__module__", None) or getattr(f, "_modulo_pigro", None)
                moduli[n] = str(m or "")
        except Exception:  # noqa: BLE001
            moduli = {}
        c._CACHE["telefono_moduli"] = moduli
    return moduli.get(nome, "")  # type: ignore[union-attr]


#: Le parole che si scrivono di piu', in ordine: a parita' di iniziale vengono prima delle altre
#: ("s" -> se, stampa, ...; "p" -> per ogni, prova, ...).
PRINCIPALI = (
    "stampa", "se", "variabile", "per ogni", "ripeti", "mentre", "funzione", "fine", "chiedi", "altrimenti",
    "altrimenti se", "restituisci", "allora", "fai", "lunghezza", "intero", "testo", "vero", "falso",
    "casuale", "lista", "attendi", "prova", "cattura", "quando", "in", "e", "o", "non", "decimale",
    "arrotonda", "somma", "massimo", "minimo", "media", "costante", "interrompi", "continua", "leggi_file",
    "scrivi_file", "leggi_righe",
)
_POSTO_PRINCIPALI = {p: i for i, p in enumerate(PRINCIPALI)}


def _sinonimo(testo: str) -> bool:
    """Vero per le forme alternative delle parole chiave ("sennò", "finché"): restano proponibili,
    ma dopo la forma principale."""
    try:
        from .sinonimi import carica_sinonimi

        return carica_sinonimi().canonica_di(testo) is not None
    except Exception:  # noqa: BLE001
        return False


def _gradino(s: "c.Suggerimento") -> tuple[int, int, int]:
    """Ordine sul telefono (pertinenza): prima le parole che cominciano con quello che hai scritto;
    tra queste i nomi del tuo programma e dei controlli, poi le parole che si usano di piu'
    (:data:`PRINCIPALI`, nel loro ordine), poi le altre parole chiave e le funzioni comuni, poi il
    resto della libreria; per ultime le forme alternative delle parole chiave e le funzioni pensate
    per il computer."""
    gruppo = 0 if s.corrispondenza == "prefisso" else 1
    if s.tipo in ("controllo", "proprieta", "evento") or "tuo programma" in s.descrizione:
        return gruppo, 0, 0
    if s.testo in _POSTO_PRINCIPALI:
        return gruppo, 1, _POSTO_PRINCIPALI[s.testo]
    if s.tipo == "frammento":
        return gruppo, 2, 0
    if s.tipo == "parola_chiave" and _sinonimo(s.testo):
        return gruppo, 4, 0
    if s.tipo == "parola_chiave" or s.testo in COMUNI:
        return gruppo, 2, 0
    modulo = _modulo_di(s.testo)
    if modulo in _MODULI_PC:
        return gruppo, 5, 0
    return gruppo, 3, 0


def _voce(s: "c.Suggerimento", riga: str) -> dict[str, Any]:
    ins = s.testo_da_inserire
    cur = max(0, min(len(ins), s.posizione_cursore))
    sel = max(0, min(len(ins) - cur, s.lunghezza_selezione))
    a = max(0, s.inizio - 1)
    b = max(a, s.fine - 1)
    voce: dict[str, Any] = {
        "t": s.testo, "k": s.tipo, "d": s.dettaglio, "s": s.descrizione, "i": ins,
        "c": _u16(ins[:cur]), "l": _u16(ins[cur:cur + sel]),
        "a": _u16(riga[:a]), "b": _u16(riga[:b]),
    }
    if len(s.campi) > 1 or (s.campi and s.lunghezza_selezione):
        voce["f"] = [[_u16(ins[:i]), _u16(ins[i:i + n])] for i, n in s.campi]
        voce["z"] = _u16(ins[:max(0, min(len(ins), s.cursore_finale))])
    return voce


#: Si sta scrivendo il nome di qualcosa di nuovo (``variabile punti``, ``per ogni frutto``,
#: ``funzione saluta``): niente suggerimenti, il nome lo sceglie chi scrive.
_RE_NOME_NUOVO = re.compile(rf"^[ \t]*(?:crea[ \t]+)?(?:variabile|costante|funzione|per[ \t]+ogni|cattura[ \t]+\w+[ \t]+come|"
                            rf"cattura[ \t]+come)[ \t]+(?:{_NOME}[ \t]*,[ \t]*)*\w*$", re.UNICODE)


def _da_mostrare(contesto: "c.Contesto", prima: str = "") -> bool:
    """I suggerimenti compaiono solo quando servono: mentre scrivi una parola,
    dopo il punto di un controllo o di un valore, dopo ``quando``; non mentre
    scrivi il nome di una variabile o di una funzione nuova."""
    if contesto.protetto or _RE_NOME_NUOVO.match(prima):
        return False
    return bool(contesto.prefisso) or contesto.oggetto is not None or contesto.dopo_quando


def completa(codice: str, riga: int, colonna: int, controlli: Mapping[str, str | None] | None = None,
             *, voci: bool = True, aiuto: bool = True, limite: int = LIMITE_VOCI,
             lettura: bool = False, da: int = 0, a: int = 0) -> dict[str, Any]:
    """Suggerimenti e riga di aiuto per il cursore alla ``riga`` e ``colonna`` (da 1, in caratteri).

    ``{"voci": [...], "aiuto": "..."}``; ogni voce e' ``{"t": testo mostrato, "k": tipo,
    "d": firma o dettaglio, "s": descrizione, "i": testo da inserire, "c": cursore dopo
    l'inserimento, "l": caratteri da selezionare (il primo campo), "a"/"b": colonne della
    riga da sostituire}`` e, per i blocchi con piu' campi da completare, ``"f"``
    ([inizio, lunghezza] di ogni campo) e ``"z"`` (dove finisce il cursore).
    Tutte le posizioni sono in unita' UTF-16, relative al testo da inserire o alla riga.
    """
    codice = "" if codice is None else str(codice).replace("\r\n", "\n").replace("\r", "\n")
    righe = codice.split("\n")
    indice = min(max(int(riga or 1), 1), len(righe)) - 1
    testo_riga = righe[indice]
    col = min(max(int(colonna or 1), 1), len(testo_riga) + 1) - 1
    prima = testo_riga[:col]
    if controlli is None:
        controlli = controlli_dal_codice(codice)
    risultato: dict[str, Any] = {"voci": []}
    if voci:
        contesto = c.analizza_contesto(prima)
        if _da_mostrare(contesto, prima):
            try:
                trovati = c.suggerimenti(codice, indice + 1, col + 1, maschera=dict(controlli), limite=60)
            except Exception:  # noqa: BLE001 - i suggerimenti non devono mai rompere l'editor
                trovati = []
            prefisso = contesto.prefisso
            elenco = []
            altre = 0
            for s in sorted(trovati, key=_gradino):
                # la parola e' gia' scritta tutta e non c'e' nulla da aggiungere
                if s.testo == prefisso and s.testo_da_inserire == prefisso:
                    continue
                gruppo, gradino, _posto = _gradino(s)
                # poche lettere: niente somiglianze lontane ne' funzioni da computer; delle parole che
                # non cominciano cosi' solo quelle che contengono proprio quello che hai scritto e i
                # refusi (stessa iniziale, lunghezza simile): "stmpa" -> stampa, "mesaggio" -> messaggio
                piano, scritto = c._piano(s.testo), c._piano(prefisso)
                if gruppo and (len(prefisso) < 3 or altre >= 4 or not (
                        scritto in piano or (piano[:1] == scritto[:1] and len(piano) - len(scritto) <= 3))):
                    continue
                if gradino == 5 and len(prefisso) < 4:
                    continue
                altre += gruppo
                elenco.append(_voce(s, testo_riga))
                if len(elenco) >= limite:
                    break
            risultato["voci"] = elenco
    if aiuto:
        try:
            risultato["aiuto"] = aiuto_contestuale(codice, indice + 1, col + 1, controlli)
        except Exception:  # noqa: BLE001
            risultato["aiuto"] = ""
    if lettura:
        risultato["lettura"] = lettura_telefono(codice, indice + 1, col + 1, da or indice + 1, a or indice + 1, controlli)
    return risultato


# ---------------------------------------------------------------------------
# Leo scrive con te (motore: leo.lettura_righe)
# ---------------------------------------------------------------------------

def _pastiglie_u16(testo: str, pastiglie: list) -> list[list]:
    fuori = []
    for p in pastiglie:
        a = _u16(testo[:p.colonna])
        fuori.append([a, _u16(testo[p.colonna:p.colonna + p.lunghezza]), p.genere])
    return fuori


def lettura_telefono(codice: str, riga: int, colonna: int, da: int, a: int,
                     controlli: Mapping[str, str | None] | None = None) -> dict[str, Any]:
    """Cosa Leo ha capito della riga del cursore, le pastiglie delle righe ``da``..``a`` e la firma.

    ``{"riga": {"r", "f", "g", "v"?, "t"?, "a"?, "c"?}, "pastiglie": {"testo della riga": [[inizio,
    lunghezza, genere], ...]}, "firma": {...} | None}``. Le pastiglie sono indicizzate per testo della
    riga (cosi' restano giuste anche se intanto si aggiungono righe sopra) e in unita' UTF-16.
    """
    from . import lettura_righe as L

    try:
        codice = "" if codice is None else str(codice).replace("\r\n", "\n").replace("\r", "\n")
        righe = codice.split("\n")
        da = max(1, min(int(da or riga), len(righe)))
        a = max(da, min(int(a or riga), len(righe), da + LIMITE_RIGHE_PASTIGLIE))
        firma = L.firma_al_cursore(codice, riga, colonna)
        letta = L.mentre_scrivi(L.leggi_riga(codice, riga, controlli), firma)
        pastiglie: dict[str, list] = {}
        for n in range(da, a + 1):
            testo = righe[n - 1]
            if testo.strip() and testo not in pastiglie:
                p = L.pastiglie_riga(testo)
                if p:
                    pastiglie[testo] = _pastiglie_u16(testo, p)
        dati = letta.come_dict() if letta is not None and (letta.frase or letta.avviso) else None
        if dati is not None:
            dati.pop("p", None)              # le pastiglie arrivano a parte, in unita' UTF-16
        return {"riga": dati,
                "pastiglie": pastiglie, "firma": firma.come_dict() if firma is not None else None}
    except Exception:  # noqa: BLE001 - un aiuto in meno, mai un editor rotto
        return {"riga": None, "pastiglie": {}, "firma": None}


# ---------------------------------------------------------------------------
# riga di aiuto per chi comincia
# ---------------------------------------------------------------------------

_ATTESE = {
    "allora": "Dopo la condizione scrivi `allora`, poi a capo i comandi da eseguire se è vera.",
    "fai": "Finisci la riga con `fai`: sotto vanno i comandi da ripetere.",
    "in": "Dopo il nome scrivi `in` e cosa scorrere, per esempio `1..10` o una lista.",
    "volte": "Dopo il numero scrivi `volte`: `ripeti 3 volte`.",
}


def _una_riga(testo: str) -> str:
    parti = [p.strip() for p in (testo or "").split("\n") if p.strip()]
    if not parti:
        return ""
    if len(parti) == 1:
        return parti[0]
    testa = parti[0]
    if len(testa) > 24 and "(" in testa:          # firma lunga: sul telefono basta il nome
        testa = testa[:testa.index("(")]
    return f"`{testa}`: {parti[1]}" if not testa.startswith("`") else f"{testa}: {parti[1]}"


def _parola_al_cursore(testo_riga: str, col: int) -> tuple[str, int]:
    """(parola sotto o subito prima del cursore, colonna d'inizio)."""
    for m in _RE_PAROLA.finditer(testo_riga):
        if m.start() <= col <= m.end():
            return m.group(0), m.start()
    return "", col


def aiuto_contestuale(codice: str, riga: int, colonna: int,
                      controlli: Mapping[str, str | None] | None = None) -> str:
    """Una riga di aiuto per chi comincia: cosa scrivere adesso, o cosa fa la parola sotto il cursore.

    Testo semplice con i pezzi di codice tra apici inversi (la pagina li mostra come codice);
    ``""`` quando non c'e' niente di utile da dire.
    """
    codice = codice or ""
    righe = codice.split("\n")
    indice = min(max(riga, 1), len(righe)) - 1
    testo_riga = righe[indice]
    col = min(max(colonna, 1), len(testo_riga) + 1) - 1
    prima = testo_riga[:col]
    if not codice.strip():
        return "Scrivi un comando, per esempio `stampa(\"Ciao!\")`, oppure tocca + per i comandi pronti."
    stato = c._stato_riga(prima)
    if stato == "commento":
        return "Dopo `#` c'è una nota per chi legge: Leo non la esegue."
    chiamata = c.chiamata_in_corso(prima)
    dati = c.DatiCompletamento.da_sorgente(codice, dict(controlli) if controlli else {})
    if chiamata is not None:
        nome, _argomento = chiamata
        spiegazione = _una_riga(c.descrivi_parola(nome, prima[:prima.rfind(nome)] if nome in prima else "", dati))
        if spiegazione:
            if stato == "testo":
                return spiegazione + "  Nel testo, `{nome}` mette il valore di una variabile."
            return spiegazione
    if stato == "testo":
        return "Stai scrivendo un testo: chiudilo con le virgolette. `{nome}` dentro il testo mette il valore di una variabile."
    if not testo_riga.strip():
        if c.rientro_di(testo_riga):
            return "Scrivi qui dentro i comandi del blocco; il blocco si chiude con `fine`."
        return "Riga vuota: scrivi un comando o tocca + per i comandi pronti."
    parola, inizio = _parola_al_cursore(testo_riga, col)
    contesto = c.analizza_contesto(prima)
    attesa = None
    if not contesto.inizio_istruzione and prima.strip():
        try:
            # "per ogni x" -> manca `in`; "ripeti 3 vol" -> manca ancora `volte`
            attesa = c._attesa_nella_riga(prima.rstrip() + " ", None)
        except Exception:  # noqa: BLE001
            attesa = None
    if attesa in _ATTESE and not testo_riga[col:].strip() and contesto.prefisso != attesa:
        return _ATTESE[attesa]
    try:
        if c.manca_fine(righe, indice):
            return "Questo blocco non è ancora chiuso: aggiungi `fine` sotto i suoi comandi."
    except Exception:  # noqa: BLE001
        pass
    if parola:
        doppia = f"{testo_riga[:inizio].rstrip().split()[-1]} {parola}" if testo_riga[:inizio].strip() else ""
        for chiave in (doppia, parola):
            if chiave in c.PAROLE_CHIAVE:
                return c.PAROLE_CHIAVE[chiave]
        spiegazione = _una_riga(c.descrivi_parola(parola, testo_riga[:inizio], dati))
        if spiegazione:
            return spiegazione
        variabili = dati.variabili
        if parola in variabili:
            return f"`{parola}` è una variabile del tuo programma."
    return ""
