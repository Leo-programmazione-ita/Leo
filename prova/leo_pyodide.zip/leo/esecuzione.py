"""Funzioni di alto livello che collegano lexer, parser e interprete - CONTRATTO CONDIVISO.

Usate da CLI, REPL, test di accettazione, runtime grafico e Leo Studio.
Nessuna di queste funzioni fa autocorrezione (quella e' in ``leo.cli`` con
``leo.correzioni``): gli errori si propagano come ``ErroreDante``.

API:
    prepara_lessico(sorgente, *, rigoroso=False, stile=None, sinonimi_extra=(), dizionari_sinonimi=())
        -> (Sinonimi, Stile)
    tokenizza(sorgente, nome_file="<sorgente>", **opzioni_lessico) -> list[Token]
    analizza(sorgente, nome_file="<sorgente>", *, recupero=False, **opzioni_lessico) -> Programma
    esegui_sorgente(sorgente, nome_file="<sorgente>", *, uscita=None, ingresso=None,
                    interprete=None, **opzioni_lessico) -> Interprete
    esegui_file(percorso, **opzioni) -> Interprete
    opzioni_lessico_file(percorso, *, rigoroso=False) -> dict   (opzioni_lessico per un file)
    messaggio_errore(errore, sorgente=None, *, colori=False, tema=None) -> str

``opzioni_lessico``: rigoroso: bool, stile: Stile | None (None = intestazione
``#stile:`` del sorgente o predefinito), sinonimi_extra: percorsi di
sinonimi.toml aggiuntivi, dizionari_sinonimi: sezioni [sinonimi] gia' lette.
"""

from __future__ import annotations

import os
from typing import Any, Callable, Iterable

from .errori import ErroreFile
from .sinonimi import Sinonimi, carica_sinonimi
from .stile import Stile


def prepara_lessico(sorgente: str, *, rigoroso: bool = False, stile: Stile | None = None,
                    sinonimi_extra: Iterable = (), dizionari_sinonimi: Iterable[dict] = ()
                    ) -> tuple[Sinonimi, Stile]:
    sinonimi = carica_sinonimi(sinonimi_extra, rigoroso=rigoroso, dizionari_extra=dizionari_sinonimi)
    stile_effettivo = Stile.da_sorgente(sorgente, stile)
    return sinonimi, stile_effettivo


def tokenizza(sorgente: str, nome_file: str = "<sorgente>", *, conserva_commenti: bool = False,
              tollerante: bool = False, **opzioni: Any) -> list:
    from .lexer import Lexer

    # nomi e comandi dell'utente definiti fuori dal sorgente (righe precedenti del REPL)
    nomi_noti = opzioni.pop("nomi_noti", ())
    comandi_noti = opzioni.pop("comandi_noti", ())
    sinonimi, stile = prepara_lessico(sorgente, **opzioni)
    return Lexer(sorgente, nome_file, sinonimi=sinonimi, stile=stile,
                 conserva_commenti=conserva_commenti, tollerante=tollerante,
                 nomi_noti=nomi_noti, comandi_noti=comandi_noti).tokenizza()


def analizza(sorgente: str, nome_file: str = "<sorgente>", *, recupero: bool = False, **opzioni: Any):
    from .errori import ErroreSintassi
    from .parser import Parser

    try:
        token = tokenizza(sorgente, nome_file, **opzioni)
        programma = Parser(token, nome_file, recupero=recupero).analizza()
    except ErroreSintassi as errore:
        # riga scritta alla Python (`def f(x):`, `for i in range(n):`...): la
        # correzione proposta diventa la riga intera tradotta in Leo
        from .da_python import migliora_errore

        migliora_errore(errore, sorgente)
        # forme a parole (`3 più 4`, `è uguale a`, `fai 5 volte`...): il simbolo e la riga corretta
        from .forme_parlate import migliora_errore as migliora_forme

        migliora_forme(errore, sorgente)
        raise
    programma.nome_file = nome_file
    if not recupero and "parallelo" in sorgente.lower():
        # un lavoro `in parallelo` non cambia le variabili del programma (lo si vede dal testo)
        from .parallelo_controllo import controlla_lavori

        controlla_lavori(programma)
    return programma


def esegui_sorgente(sorgente: str, nome_file: str = "<sorgente>", *,
                    uscita: Callable[[str], None] | None = None,
                    ingresso: Callable[[str], str] | None = None,
                    interprete: Any = None, **opzioni: Any):
    """Analizza ed esegue; restituisce l'interprete (per leggere ``globale``/``gestori_evento``).

    Se ``interprete`` e' dato, esegue in quello (REPL, runtime grafico).
    """
    from .interprete import Interprete

    stile = Stile.da_sorgente(sorgente, opzioni.get("stile"))
    programma = analizza(sorgente, nome_file, **opzioni)
    if interprete is None:
        interprete = Interprete(nome_file=nome_file, sorgente=sorgente, uscita=uscita, ingresso=ingresso,
                                dichiarazione_implicita=stile.dichiarazione_implicita)
    else:
        interprete.nome_file = nome_file
        interprete.sorgente = sorgente
    interprete.esegui(programma)
    return interprete


def esegui_file(percorso: str | os.PathLike, **opzioni: Any):
    try:
        with open(percorso, "r", encoding="utf-8-sig") as f:
            sorgente = f.read()
    except OSError as e:
        raise ErroreFile(f"Non riesco a leggere `{os.fspath(percorso)}`: {e.strerror or e}.") from e
    return esegui_sorgente(sorgente, os.path.basename(os.fspath(percorso)), **opzioni)


def opzioni_lessico_file(percorso: str | os.PathLike, *, rigoroso: bool = False) -> dict[str, Any]:
    """Le ``opzioni_lessico`` per eseguire un file, come la riga di comando.

    Se la cartella del file e' un progetto (``progetto.toml``) valgono il suo stile e i
    suoi sinonimi; altrimenti lo stile resta None (lo decide l'intestazione ``#stile:``).
    """
    from .progetto import carica_progetto, e_progetto

    opzioni: dict[str, Any] = {"rigoroso": rigoroso}
    cartella = os.path.dirname(os.path.abspath(os.fspath(percorso)))
    if e_progetto(cartella):
        progetto = carica_progetto(cartella)
        opzioni["stile"] = progetto.stile
        opzioni["rigoroso"] = rigoroso or progetto.rigoroso
        if progetto.sinonimi:
            opzioni["dizionari_sinonimi"] = [progetto.sinonimi]
        if progetto.file_sinonimi:
            opzioni["sinonimi_extra"] = [progetto.file_sinonimi]
    return opzioni


def messaggio_errore(errore: Any, sorgente: str | None = None, *, colori: bool = False, tema: Any = None) -> str:
    """Il testo di un errore di Leo come lo scrive la riga di comando.

    Le quattro parti del messaggio (``leo.messaggi``) piu' la "Riga corretta proposta"
    (``leo.errori_umani``). Un errore nato in un file importato si mostra con il testo
    di quel file. ``tema`` serve solo con ``colori=True``.
    """
    from .errori_umani import arricchisci
    from .messaggi import formatta_errore

    sorgente = getattr(errore, "sorgente_file", None) or sorgente
    testo = formatta_errore(errore, sorgente, tema=tema, colori=colori)
    return arricchisci(testo, errore, sorgente)
