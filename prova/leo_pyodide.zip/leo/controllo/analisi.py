"""``leo controlla``: il controllo statico di un programma Leo, PRIMA di eseguirlo.

Niente del programma viene eseguito: si analizza l'albero sintattico e si
trovano

* nomi inesistenti (con il suggerimento del nome giusto) e nomi usati prima di
  esistere;
* numero e nomi degli argomenti sbagliati (funzioni del programma, della
  libreria, strutture e metodi);
* codice irraggiungibile (dopo ``restituisci``, ``interrompi``, ``lancia``...);
* tipi sbagliati: dichiarati (``x: intero``, ``dà decimale``, campi delle
  strutture) e ricavati da soli (``"a" - 1``, ``lunghezza(x) + "!"``);
* valori che possono essere ``nulla`` (``testo?``) usati senza controllare
  prima ``se x ha valore``;
* campi e metodi inesistenti delle strutture, ``scegli`` a cui manca il caso di
  una variante;
* nomi privati dei moduli, costanti (anche il contenuto) cambiate;
* contratti: ``richiede`` violato con argomenti noti, ``può dare`` non gestito.

I messaggi sono gli stessi che il programma darebbe eseguendo (quando c'è un
corrispondente), così chi scrive impara una cosa sola.

API (vedi :mod:`leo.controllo` e docs/CONTROLLO.md)::

    controlla(sorgente, nome_file="<sorgente>", *, cartella=None, nomi_noti=(), opzioni=None) -> Rapporto
    controlla_file(percorso) -> Rapporto
    controlla_cartella(cartella) -> list[Rapporto]
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable


class _DifflibPigro:
    """Rimanda l'``import`` di ``difflib`` al primo suggerimento.

    ``difflib.get_close_matches`` serve solo a proporre il nome giusto quando
    un errore cita un nome sconosciuto: un programma corretto non lo tocca, e
    ``controllo.analisi`` viene importato a ogni avvio. Il proxy e' trasparente
    (ogni uso e' ``difflib.get_close_matches``)."""

    __slots__ = ("_modulo",)

    def __init__(self) -> None:
        self._modulo = None

    def __getattr__(self, attributo: str) -> Any:
        modulo = self._modulo
        if modulo is None:
            import difflib

            modulo = self._modulo = difflib
        return getattr(modulo, attributo)


difflib = _DifflibPigro()

from .. import nodi as N
from ..errori import ErroreDante, ErroreDivisione, ErroreSintassi, ErroreTipo, TIPI_ERRORE
from .tipi import QUALSIASI, TIPI_BASE, Tipo, leggi_tipo

__all__ = ["controlla", "controlla_file", "controlla_cartella", "Diagnostica", "Rapporto", "GRAVITA",
           "CODICI"]

#: Gravità, dalla più alta: ``errore`` (il programma si fermerebbe), ``avviso``
#: (quasi certamente uno sbaglio, ma il programma parte), ``nota`` (consiglio).
GRAVITA = ("errore", "avviso", "nota")

#: Codici delle diagnostiche (stabili: li usano editor e test).
CODICI = {
    "sintassi": "il programma non è scritto bene (non si può nemmeno avviare)",
    "nome": "nome inesistente o usato prima di esistere",
    "argomenti": "numero o nomi degli argomenti sbagliati",
    "irraggiungibile": "codice che non viene mai eseguito",
    "tipo": "valore del tipo sbagliato",
    "nulla": "valore che può essere `nulla` usato senza controllarlo",
    "campo": "campo o metodo inesistente",
    "caso": "`scegli` senza il caso di una variante",
    "privato": "nome privato di un modulo",
    "costante": "costante (o il suo contenuto) cambiata",
    "contratto": "`richiede` non rispettato o `può dare` non gestito",
    "dichiarazione": "nome dichiarato due volte",
    "modulo": "modulo da importare non trovato",
    "maiuscole": "nome scritto con le maiuscole sbagliate",
    "confronto": "confronto che dà sempre lo stesso risultato",
    "risultato": "funzione che può finire senza dare il suo risultato",
}


# ===========================================================================
# Risultati
# ===========================================================================

@dataclass
class Diagnostica:
    """Una cosa trovata dal controllo, con la posizione (righe e colonne da 1)."""

    riga: int
    colonna: int
    messaggio: str
    gravita: str = "errore"
    codice: str = ""
    suggerimento: str | None = None
    lunghezza: int = 1
    file: str = "<sorgente>"
    correzioni: list = field(default_factory=list)

    def come_dizionario(self) -> dict[str, Any]:
        """Per JSON (telefono, server del linguaggio)."""
        return {
            "riga": self.riga, "colonna": self.colonna, "lunghezza": self.lunghezza,
            "gravita": self.gravita, "codice": self.codice, "messaggio": self.messaggio,
            "suggerimento": self.suggerimento, "file": self.file,
            "correzioni": [{"riga": c.riga, "colonna": c.colonna, "prima": c.prima, "dopo": c.dopo,
                            "motivo": c.motivo} for c in self.correzioni],
        }


    def come_lsp(self) -> dict[str, Any]:
        """La stessa diagnostica nel formato del Language Server Protocol (righe e colonne da 0)."""
        messaggio = self.messaggio + (f"\nSuggerimento: {self.suggerimento}" if self.suggerimento else "")
        inizio = {"line": max(0, self.riga - 1), "character": max(0, self.colonna - 1)}
        fine = {"line": inizio["line"], "character": inizio["character"] + max(1, self.lunghezza)}
        return {"range": {"start": inizio, "end": fine}, "severity": GRAVITA.index(self.gravita) + 1,
                "code": self.codice, "source": "leo controlla", "message": messaggio}


@dataclass
class Rapporto:
    """Il risultato di :func:`controlla` per un file."""

    file: str
    diagnostiche: list[Diagnostica]
    sorgente: str = ""

    @property
    def errori(self) -> list[Diagnostica]:
        return [d for d in self.diagnostiche if d.gravita == "errore"]

    @property
    def avvisi(self) -> list[Diagnostica]:
        return [d for d in self.diagnostiche if d.gravita == "avviso"]

    @property
    def ok(self) -> bool:
        """Vero se non ci sono errori (gli avvisi non contano)."""
        return not self.errori

    def come_dizionario(self) -> dict[str, Any]:
        return {"file": self.file, "ok": self.ok, "errori": len(self.errori), "avvisi": len(self.avvisi),
                "diagnostiche": [d.come_dizionario() for d in self.diagnostiche]}

    def testo(self, *, colori: bool = False) -> str:
        """Il rapporto da mostrare nel terminale."""
        righe_sorgente = self.sorgente.splitlines()
        rosso, giallo, grigio, grassetto, fine = (
            ("\033[31m", "\033[33m", "\033[90m", "\033[1m", "\033[0m") if colori else ("",) * 5)
        uscita: list[str] = []
        for d in self.diagnostiche:
            colore = rosso if d.gravita == "errore" else (giallo if d.gravita == "avviso" else grigio)
            uscita.append(f"{grassetto}{d.file}:{d.riga}:{d.colonna}{fine}: {colore}{d.gravita}{fine}: {d.messaggio}")
            if 0 < d.riga <= len(righe_sorgente):
                testo = righe_sorgente[d.riga - 1].replace("\t", "    ")
                numero = str(d.riga)
                uscita.append(f"  {grigio}{numero} |{fine} {testo}")
                spazi = " " * (len(numero) + 3 + max(0, d.colonna - 1))
                uscita.append(f"  {spazi}{colore}{'^' * max(1, min(d.lunghezza, max(1, len(testo) - d.colonna + 1)))}{fine}")
            if d.suggerimento:
                uscita.append(f"  Suggerimento: {d.suggerimento}")
            uscita.append("")
        return "\n".join(uscita)


# ===========================================================================
# Informazioni raccolte sul programma
# ===========================================================================

@dataclass
class Firma:
    """Una funzione (del programma o di un modulo importato)."""

    nome: str
    parametri: list            # list[N.Parametro] (senza `questo` per i metodi)
    tipo_risultato: Tipo | None = None
    puo_dare: list = field(default_factory=list)
    richiede: list = field(default_factory=list)
    nodo: Any = None
    risultato_ricavato: Tipo | None = None   # dai `restituisci`, se tutti uguali

    @property
    def risultato(self) -> Tipo | None:
        return self.tipo_risultato or self.risultato_ricavato


@dataclass
class InfoStruttura:
    """Una ``struttura`` o una variante di un tipo."""

    nome: str
    campi: list                     # list[N.Campo]
    metodi: dict = field(default_factory=dict)   # nome -> Firma
    genitore: str | None = None     # per le varianti: il nome del tipo
    senza_dati: bool = False        # variante senza parentesi (`Vuota`)

    def campo(self, nome: str) -> Any:
        for c in self.campi:
            if c.nome == nome:
                return c
        return None


@dataclass
class InfoFamiglia:
    """Un ``tipo ... è uno di``: il nome e le varianti, in ordine."""

    nome: str
    varianti: list[str]
    metodi: dict = field(default_factory=dict)


@dataclass
class InfoModulo:
    nome: str
    simboli: dict                  # nome visibile -> Simbolo
    privati: set = field(default_factory=set)
    libreria: bool = False


@dataclass
class Simbolo:
    nome: str
    genere: str            # variabile costante funzione parametro struttura tipo variante modulo predefinito ciclo
    tipo: Tipo | None = None
    dichiarato: bool = False
    riga: int = 0
    colonna: int = 0
    firma: Firma | None = None
    struttura: InfoStruttura | None = None
    famiglia: InfoFamiglia | None = None
    modulo: InfoModulo | None = None
    nativo: Any = None
    bloccato: bool = False      # costante con contenuto (lista, dizionario, struttura)


class Ambito:
    def __init__(self, genitore: "Ambito | None", nome: str = "", *, funzione: Firma | None = None,
                 cattura: tuple = (), riserva: "Ambito | None" = None) -> None:
        self.genitore = genitore
        #: dove cercare quando la catena non trova il nome: per i corpi delle
        #: funzioni e dei gestori, tutto il livello esterno del file (si eseguono dopo)
        self.riserva = riserva if riserva is not None else (genitore.riserva if genitore else None)
        self.nome = nome
        self.simboli: dict[str, Simbolo] = {}
        self.ristretti: dict[str, Tipo] = {}
        self.funzione = funzione if funzione is not None else (genitore.funzione if genitore else None)
        #: tipi d'errore catturati da un `prova` intorno (per `può dare`); "*" = tutti
        self.cattura = cattura or (genitore.cattura if genitore else ())

    def cerca(self, nome: str) -> Simbolo | None:
        a: Ambito | None = self
        while a is not None:
            s = a.simboli.get(nome)
            if s is not None:
                return s
            a = a.genitore
        if self.riserva is not None:
            return self.riserva.cerca(nome)
        return None

    def tipo_ristretto(self, nome: str) -> Tipo | None:
        a: Ambito | None = self
        while a is not None:
            if nome in a.ristretti:
                return a.ristretti[nome]
            if nome in a.simboli:
                return None
            a = a.genitore
        return None

    def visibili(self) -> dict[str, int]:
        risultato: dict[str, int] = {}
        a: Ambito | None = self
        while a is not None:
            for n, s in a.simboli.items():
                risultato.setdefault(n, s.riga)
            a = a.genitore
        if self.riserva is not None:
            for n, riga in self.riserva.visibili().items():
                risultato.setdefault(n, riga)
        return risultato


# ===========================================================================
# Tabelle sulla libreria
# ===========================================================================

#: Tipo del risultato di alcune funzioni della libreria (le altre: sconosciuto).
RISULTATI_LIBRERIA = {
    "lunghezza": "intero", "testo": "testo", "intero": "intero", "decimale": "decimale", "radice": "decimale",
    "media": "decimale", "esiste": "logico", "vuota": "logico", "intervallo": "intervallo",
    "casuale": "numero", "arrotonda": "numero", "somma": "numero", "assoluto": "numero", "chiedi": "testo",
    "oggi": "testo", "ora": "testo", "tipo": "testo",
}
#: Tipo del risultato dei metodi di testi, liste e dizionari.
RISULTATI_METODI = {
    ("testo", "maiuscolo"): "testo", ("testo", "minuscolo"): "testo", ("testo", "pulisci"): "testo",
    ("testo", "sostituisci"): "testo", ("testo", "contiene"): "logico", ("testo", "inizia_con"): "logico",
    ("testo", "finisce_con"): "logico", ("testo", "dividi"): "lista di testo", ("testo", "unisci"): "testo",
    ("lista", "trova"): "intero?", ("lista", "conta"): "intero", ("lista", "aggiungi"): "nulla",
    ("lista", "inserisci"): "nulla", ("lista", "rimuovi"): "nulla", ("lista", "ordina"): "nulla",
    ("lista", "inverti"): "nulla", ("dizionario", "chiavi"): "lista", ("dizionario", "valori"): "lista",
    ("dizionario", "coppie"): "lista", ("dizionario", "ha"): "logico",
}
#: Metodi che cambiano la lista/il dizionario su cui si chiamano.
METODI_CHE_CAMBIANO = {"lista": {"aggiungi", "inserisci", "rimuovi", "estrai", "ordina", "inverti"},
                       "dizionario": {"rimuovi"}}

#: Un valore d'esempio per tipo: le operazioni si provano davvero (con i
#: messaggi d'errore veri dell'interprete) senza eseguire il programma.
_CAMPIONI: dict[str, Any] = {"intero": 7, "decimale": 2.5, "numero": 7, "testo": "a", "logico": True,
                             "nulla": None, "lista": [], "dizionario": {}, "intervallo": range(1, 3)}

_INTERO, _DECIMALE, _NUMERO, _TESTO, _LOGICO = (Tipo("intero"), Tipo("decimale"), Tipo("numero"), Tipo("testo"),
                                                Tipo("logico"))
_NULLA, _LISTA, _DIZIONARIO, _INTERVALLO, _FUNZIONE = (Tipo("nulla"), Tipo("lista"), Tipo("dizionario"),
                                                       Tipo("intervallo"), Tipo("funzione"))


def _tipo_valore(v: Any) -> Tipo | None:
    if v is None:
        return _NULLA
    if isinstance(v, bool):
        return _LOGICO
    if isinstance(v, int):
        return _INTERO
    if isinstance(v, float):
        return _DECIMALE
    if isinstance(v, str):
        return _TESTO
    if isinstance(v, list):
        return _LISTA
    if isinstance(v, dict):
        return _DIZIONARIO
    if isinstance(v, range):
        return _INTERVALLO
    return None


def _unisci(a: Tipo | None, b: Tipo | None) -> Tipo | None:
    """Il tipo che va bene per entrambi (None se non si sa)."""
    if a is None or b is None:
        return None
    if a == b:
        return a
    if a.nome == "nulla":
        return b.con_nulla
    if b.nome == "nulla":
        return a.con_nulla
    numeri = ("intero", "decimale", "numero")
    if a.nome in numeri and b.nome in numeri and a.elementi is None and b.elementi is None:
        nome = "decimale" if {a.nome, b.nome} == {"intero", "decimale"} else "numero"
        return Tipo(nome, None, a.opzionale or b.opzionale)
    if a.nome == b.nome:
        return Tipo(a.nome, _unisci(a.elementi, b.elementi) if a.elementi and b.elementi else None,
                    a.opzionale or b.opzionale)
    if a.senza_nulla == b.senza_nulla:
        return a.con_nulla
    return None


def _testo_nodo(nodo: Any) -> str:
    """Il codice di un'espressione semplice (per i messaggi)."""
    if isinstance(nodo, N.Nome):
        return nodo.nome
    if isinstance(nodo, N.Attributo):
        interno = _testo_nodo(nodo.oggetto)
        return f"{interno}.{nodo.nome}" if interno else ""
    if isinstance(nodo, N.Letterale):
        from ..valori import rappresenta

        return rappresenta(nodo.valore, dentro=True)
    return ""


def _radice(nodo: Any) -> N.Nome | None:
    """``a`` per ``a[0].b``: il nome da cui parte una catena di indici/campi."""
    while isinstance(nodo, (N.Indice, N.Attributo)):
        nodo = nodo.oggetto
    return nodo if isinstance(nodo, N.Nome) else None


def _lunghezza_nome(nodo: Any) -> int:
    if isinstance(nodo, N.Nome):
        return max(1, len(nodo.nome))
    if isinstance(nodo, N.Attributo):
        return max(1, len(nodo.nome))
    return 1


# ===========================================================================
# L'analizzatore
# ===========================================================================

class Analizzatore:
    """Analizza un :class:`~leo.nodi.Programma` e raccoglie le diagnostiche."""

    def __init__(self, nome_file: str = "<sorgente>", sorgente: str = "", *, cartella: str | None = None,
                 nomi_noti: Iterable[str] = (), dichiarazione_implicita: bool = False,
                 moduli_in_corso: tuple = (), cache_moduli: dict | None = None) -> None:
        self.nome_file = nome_file
        self.sorgente = sorgente
        self.righe = sorgente.splitlines()
        self.cartella = cartella
        self.dichiarazione_implicita = dichiarazione_implicita
        self.diagnostiche: list[Diagnostica] = []
        self._viste: set = set()
        self.strutture: dict[str, InfoStruttura] = {}
        self.famiglie: dict[str, InfoFamiglia] = {}
        self.moduli_in_corso = moduli_in_corso
        self.cache_moduli = cache_moduli if cache_moduli is not None else {}
        self.predefinito = self._ambito_predefinito(nomi_noti)
        self.dichiarati_dopo: dict[str, int] = {}   # nomi esterni dichiarati piu' avanti
        self.dentro_blocchi: dict[str, int] = {}    # nomi dichiarati dentro un blocco (riga)
        self._dentro_prova = 0
        self._amb_corrente: Ambito | None = None

    # --- diagnostiche --------------------------------------------------------------

    def segnala(self, nodo: Any, messaggio: str, *, codice: str, gravita: str = "errore",
                suggerimento: str | None = None, lunghezza: int | None = None, riga: int | None = None,
                colonna: int | None = None) -> None:
        if self._dentro_prova and gravita == "errore" and codice not in ("sintassi", "dichiarazione", "tipo-scritto"):
            # dentro `prova ... cattura`: l'errore viene catturato (spesso apposta)
            gravita = "avviso"
        r = riga if riga is not None else (getattr(nodo, "riga", 0) or 1)
        c = colonna if colonna is not None else (getattr(nodo, "colonna", 0) or 1)
        chiave = (r, c, messaggio)
        if chiave in self._viste:
            return
        self._viste.add(chiave)
        if lunghezza is None:
            lunghezza = _lunghezza_nome(nodo)
        self.diagnostiche.append(Diagnostica(r, c, messaggio, gravita, codice, suggerimento, lunghezza,
                                             self.nome_file))

    # --- ambiente predefinito ----------------------------------------------------------

    def _ambito_predefinito(self, nomi_noti: Iterable[str]) -> Ambito:
        from .. import potenza, registro  # noqa: F401  (potenza registra `aspetta`, `ferma_temporizzatori`...)

        registro.carica_libreria()
        amb = Ambito(None, "predefinito")
        for n, f in registro.FUNZIONI.items():
            amb.simboli[n] = Simbolo(n, "predefinito", _FUNZIONE, nativo=f)
        for n, v in registro.COSTANTI.items():
            amb.simboli[n] = Simbolo(n, "predefinito", _tipo_valore(v), nativo=v)
        for n in TIPI_ERRORE:
            amb.simboli[n] = Simbolo(n, "predefinito", _FUNZIONE)
        for n in nomi_noti:
            amb.simboli.setdefault(n, Simbolo(n, "predefinito"))
        return amb

    # --- tipi scritti ------------------------------------------------------------------------

    def _tipi_noti(self) -> set[str]:
        from .. import registro

        noti = set(TIPI_BASE) | set(self.strutture) | set(self.famiglie) | set(registro.METODI)
        noti |= {"data", "ora", "frazione", "soldi", "complesso", "controllo", "modulo", "errore", "oggetto",
                 "lavoro", "tipo", "struttura", "colore", "immagine", "suono", "forma"}
        return noti

    def tipo_scritto(self, testo: str | None, nodo: Any) -> Tipo | None:
        """Il :class:`Tipo` di un testo dell'albero; segnala i nomi di tipo sconosciuti."""
        if not testo:
            return None
        try:
            tipo = leggi_tipo(testo)
        except ValueError as e:
            self.segnala(nodo, str(e), codice="tipo")
            return None
        noti = self._tipi_noti()
        t: Tipo | None = tipo
        while t is not None:
            if t.nome not in noti:
                simili = difflib.get_close_matches(t.nome, sorted(noti), n=1, cutoff=0.6)
                self.segnala(nodo, f"Non conosco il tipo `{t.nome}`.", codice="tipo",
                             suggerimento=(f"Forse intendevi `{simili[0]}`?" if simili else
                                           "Tipi: `intero`, `decimale`, `numero`, `testo`, `logico`, `lista`, "
                                           "`dizionario`, `funzione`, `qualsiasi`, oppure una `struttura` o un "
                                           "`tipo` del programma."))
                return None
            t = t.elementi
        return tipo

    def compatibile(self, da: Tipo | None, verso: Tipo | None) -> bool | None:
        """Un valore di tipo ``da`` va bene dove serve ``verso``? None = non si sa."""
        if da is None or verso is None:
            return None
        if verso.nome == "qualsiasi":
            return True
        if da.nome == "qualsiasi":
            return None
        if da.nome == "nulla":
            return verso.accetta_nulla
        if da.opzionale and not verso.accetta_nulla:
            return False
        if da.nome != verso.nome:
            info = self.strutture.get(da.nome)
            if info is not None and info.genitore == verso.nome:
                return True
            if verso.nome in ("decimale", "numero") and da.nome in ("intero", "decimale", "numero"):
                return True if (da.nome != "numero" or verso.nome == "numero") else None
            if da.nome == "numero" and verso.nome == "intero":
                return None
            if da.nome in self.famiglie and self.strutture.get(verso.nome, InfoStruttura("", [])).genitore == da.nome:
                return None     # una Forma qualunque dove serve un Cerchio: forse
            return False
        if verso.elementi is None or da.elementi is None:
            return True
        return self.compatibile(da.elementi, verso.elementi)

    @staticmethod
    def descrivi(tipo: Tipo) -> str:
        from ..valori import TIPI_FEMMINILI

        if tipo.nome == "nulla":
            return "`nulla`"
        return ("una" if tipo.nome in TIPI_FEMMINILI else "un") + f" `{tipo}`"

    # =========================================================================
    # Ingresso
    # =========================================================================

    def analizza(self, programma: N.Programma) -> None:
        globale = Ambito(self.predefinito, "globale")
        self.globale = globale
        # 1. le dichiarazioni esterne (per sapere cosa esiste "piu' avanti")
        esterne = Ambito(self.predefinito, "esterne")
        self._raccogli(programma.istruzioni, esterne)
        self.esterne = esterne
        for n, s in esterne.simboli.items():
            self.dichiarati_dopo[n] = s.riga
        # 2. i corpi delle funzioni e delle strutture vedono tutto il file
        for istruzione in programma.istruzioni:
            self._prepara_corpi(istruzione, esterne)
        # 3. il programma, in ordine
        self._blocco(programma.istruzioni, globale, esterno=True)

    def _raccogli(self, istruzioni: list, amb: Ambito) -> None:
        """Le dichiarazioni del livello esterno, con firme e strutture (prima passata)."""
        for ist in istruzioni:
            if isinstance(ist, N.DefinizioneFunzione) and "." not in ist.nome:
                amb.simboli[ist.nome] = Simbolo(ist.nome, "funzione", _FUNZIONE, riga=ist.riga, colonna=ist.colonna,
                                                firma=self._firma(ist))
            elif isinstance(ist, N.DefinizioneStruttura):
                info = InfoStruttura(ist.nome, ist.campi)
                self.strutture[ist.nome] = info
                amb.simboli[ist.nome] = Simbolo(ist.nome, "struttura", _FUNZIONE, riga=ist.riga,
                                                colonna=ist.colonna, struttura=info)
            elif isinstance(ist, N.DefinizioneTipo):
                famiglia = InfoFamiglia(ist.nome, [v.nome for v in ist.varianti])
                self.famiglie[ist.nome] = famiglia
                amb.simboli[ist.nome] = Simbolo(ist.nome, "tipo", riga=ist.riga, colonna=ist.colonna,
                                                famiglia=famiglia)
                for v in ist.varianti:
                    info = InfoStruttura(v.nome, v.campi or [], genitore=ist.nome, senza_dati=v.campi is None)
                    self.strutture[v.nome] = info
                    amb.simboli[v.nome] = Simbolo(v.nome, "variante", Tipo(v.nome) if v.campi is None else _FUNZIONE,
                                                  riga=v.riga or ist.riga, colonna=v.colonna, struttura=info)
            elif isinstance(ist, N.Dichiarazione) and not isinstance(ist, N.DichiarazioneMultipla):
                amb.simboli.setdefault(ist.nome, Simbolo(ist.nome, "costante" if ist.costante else "variabile",
                                                         riga=ist.riga, colonna=ist.colonna))
            elif isinstance(ist, N.DichiarazioneMultipla):
                for n in ist.nomi:
                    amb.simboli.setdefault(n, Simbolo(n, "variabile", riga=ist.riga, colonna=ist.colonna))
            elif isinstance(ist, N.Importa):
                for n, s in self._simboli_importati(ist, segnala=False).items():
                    amb.simboli.setdefault(n, s)
            elif isinstance(ist, N.Assegnazione) and self.dichiarazione_implicita and isinstance(ist.bersaglio, N.Nome):
                amb.simboli.setdefault(ist.bersaglio.nome, Simbolo(ist.bersaglio.nome, "variabile", riga=ist.riga,
                                                                   colonna=ist.colonna))
        # metodi scritti fuori dalla struttura (`funzione Alunno.media()`)
        for ist in istruzioni:
            if isinstance(ist, N.DefinizioneStruttura):
                info = self.strutture[ist.nome]
                for m in ist.metodi:
                    info.metodi[m.nome] = self._firma(m, f"{ist.nome}.{m.nome}")
            elif isinstance(ist, N.DefinizioneFunzione) and "." in ist.nome:
                proprietario, metodo = ist.nome.split(".", 1)
                info = self.strutture.get(proprietario) or self.famiglie.get(proprietario)
                if info is not None:
                    info.metodi[metodo] = self._firma(ist)
        # tipi dei campi (ora che tutte le strutture sono note)
        for ist in istruzioni:
            if isinstance(ist, N.DefinizioneStruttura):
                for c in ist.campi:
                    self.tipo_scritto(c.tipo, c)
            elif isinstance(ist, N.DefinizioneTipo):
                for v in ist.varianti:
                    for c in v.campi or []:
                        self.tipo_scritto(c.tipo, c)

    def _firma(self, nodo: N.DefinizioneFunzione, nome: str | None = None) -> Firma:
        risultato = None
        if nodo.tipo_risultato:
            try:
                risultato = leggi_tipo(nodo.tipo_risultato)
            except ValueError:
                risultato = None
        return Firma(nome or nodo.nome, list(nodo.parametri), risultato, list(nodo.puo_dare),
                     list(nodo.richiede), nodo)

    # =========================================================================
    # Moduli
    # =========================================================================

    def _simboli_importati(self, nodo: N.Importa, *, segnala: bool) -> dict[str, Simbolo]:
        """I nomi che ``importa`` porta nell'ambito (senza ``come``) o il nome del modulo."""
        info = self._modulo(nodo, segnala=segnala)
        if info is None:
            return {}
        if nodo.alias is not None:
            return {nodo.alias: Simbolo(nodo.alias, "modulo", Tipo("modulo"), riga=nodo.riga, colonna=nodo.colonna,
                                        modulo=info)}
        if info.libreria:
            from .. import nome_modulo_implicito

            implicito = nome_modulo_implicito(info.nome)
            if implicito:
                return {implicito: Simbolo(implicito, "modulo", Tipo("modulo"), riga=nodo.riga, modulo=info)}
            return {}
        simboli = dict(info.simboli)
        from .. import nome_modulo_implicito

        implicito = nome_modulo_implicito(info.nome)
        if implicito and implicito not in simboli:
            simboli[implicito] = Simbolo(implicito, "modulo", Tipo("modulo"), riga=nodo.riga, modulo=info)
        return simboli

    def _modulo(self, nodo: N.Importa, *, segnala: bool) -> InfoModulo | None:
        from .. import e_sorgente, nomi_file_modulo

        modulo = nodo.modulo
        e_file = e_sorgente(modulo) or "/" in modulo or "\\" in modulo
        percorso = None
        cartelle = [self.cartella] if self.cartella else []
        cartelle.append(os.getcwd())
        for cartella in cartelle:
            for nome in nomi_file_modulo(modulo):
                candidato = nome if os.path.isabs(nome) else os.path.join(cartella, nome)
                if os.path.isfile(candidato):
                    percorso = os.path.abspath(candidato)
                    break
            if percorso:
                break
        if percorso is not None:
            return self._modulo_file(percorso, nodo)
        if not e_file:
            from ..interprete import Interprete

            voci = Interprete._modulo_libreria(modulo)
            if voci is not None:
                simboli = {n: Simbolo(n, "predefinito", _FUNZIONE, nativo=f) for n, f in voci.items()}
                return InfoModulo(modulo, simboli, libreria=True)
        if segnala:
            self.segnala(nodo, f"Non trovo il modulo `{modulo}`.", codice="modulo",
                         suggerimento="Metti il file `.leo` nella stessa cartella del programma, "
                                      "per esempio `importa \"geometria.leo\"`.", lunghezza=len("importa"))
        return None

    def _modulo_file(self, percorso: str, nodo: Any) -> InfoModulo | None:
        if percorso in self.cache_moduli:
            return self.cache_moduli[percorso]
        if percorso in self.moduli_in_corso:
            return None
        nome_modulo = os.path.splitext(os.path.basename(percorso))[0]
        try:
            with open(percorso, "r", encoding="utf-8-sig") as f:
                sorgente = f.read()
            from ..esecuzione import analizza, opzioni_lessico_file

            programma = analizza(sorgente, os.path.basename(percorso), **opzioni_lessico_file(percorso))
        except (OSError, ErroreDante, Exception):  # noqa: BLE001 - il modulo si controlla da solo
            self.cache_moduli[percorso] = None
            return None
        interno = Analizzatore(os.path.basename(percorso), sorgente, cartella=os.path.dirname(percorso),
                               moduli_in_corso=self.moduli_in_corso + (percorso,), cache_moduli=self.cache_moduli)
        amb = Ambito(interno.predefinito, "modulo")
        interno._raccogli(programma.istruzioni, amb)
        pubblici = programma.pubblici
        visibili = {}
        privati = set()
        for n, s in amb.simboli.items():
            if n.startswith("_") or (pubblici is not None and n not in pubblici):
                privati.add(n)
            else:
                visibili[n] = s
        # strutture e famiglie del modulo diventano note anche qui (per i tipi)
        for n, info in interno.strutture.items():
            if n in visibili or (info.genitore and info.genitore in visibili):
                self.strutture.setdefault(n, info)
        for n, info in interno.famiglie.items():
            if n in visibili:
                self.famiglie.setdefault(n, info)
        info_modulo = InfoModulo(nome_modulo, visibili, privati)
        self.cache_moduli[percorso] = info_modulo
        return info_modulo

    # =========================================================================
    # Corpi delle funzioni
    # =========================================================================

    def _prepara_corpi(self, ist: Any, esterne: Ambito) -> None:
        """Ricava il tipo del risultato delle funzioni esterne (analisi dei corpi
        senza segnalare niente: le segnalazioni vere arrivano dopo, in ordine)."""
        if isinstance(ist, N.DefinizioneFunzione) and "." not in ist.nome:
            s = esterne.simboli.get(ist.nome)
            if s is not None and s.firma is not None and s.firma.tipo_risultato is None:
                salvate, viste = self.diagnostiche, self._viste
                self.diagnostiche, self._viste = [], set()
                try:
                    s.firma.risultato_ricavato = self._corpo_funzione(ist, s.firma, esterne, ricava=True)
                finally:
                    self.diagnostiche, self._viste = salvate, viste

    def _corpo_funzione(self, nodo: Any, firma: Firma, genitore: Ambito, *, questo: str | None = None,
                        ricava: bool = False) -> Tipo | None:
        amb = Ambito(genitore, f"funzione {firma.nome}", funzione=firma, cattura=("§",),
                     riserva=self.__dict__.get("esterne"))
        amb.restituiti = []   # type: ignore[attr-defined]
        if questo is not None:
            amb.simboli["questo"] = Simbolo("questo", "parametro", Tipo(questo), riga=nodo.riga)
        for p in firma.parametri:
            tipo = self.tipo_scritto(p.tipo, p) if p.tipo else None
            if getattr(p, "variadico", False):
                tipo = Tipo("lista", tipo) if tipo else _LISTA
            amb.simboli[p.nome] = Simbolo(p.nome, "parametro", tipo, dichiarato=tipo is not None, riga=p.riga,
                                          colonna=p.colonna)
            if p.predefinito is not None:
                tp = self.espressione(p.predefinito, genitore)
                if tipo is not None and self.compatibile(tp, tipo) is False:
                    self.segnala(p.predefinito, f"Il valore predefinito di `{p.nome}` è {self.descrivi(tp)}, "
                                                f"ma il parametro è `{tipo}`.", codice="tipo")
        if firma.tipo_risultato is not None:
            self.tipo_scritto(getattr(nodo, "tipo_risultato", None), nodo)
        for c in firma.richiede:
            self.condizione(c, amb, "richiede")
        if getattr(nodo, "garantisce", None):
            g = Ambito(amb, "garantisce")
            g.simboli["risultato"] = Simbolo("risultato", "variabile", firma.tipo_risultato, riga=nodo.riga)
            for c in nodo.garantisce:
                self.condizione(c, g, "garantisce")
        for errore in firma.puo_dare:
            if errore not in TIPI_ERRORE:
                simili = difflib.get_close_matches(errore, list(TIPI_ERRORE), n=1, cutoff=0.6)
                self.segnala(nodo, f"`{errore}` non è un tipo di errore.", codice="contratto",
                             suggerimento=f"Forse intendevi `{simili[0]}`?" if simili else
                             "I tipi di errore sono: " + ", ".join(f"`{t}`" for t in TIPI_ERRORE) + ".")
        amb.cattura = tuple(firma.puo_dare) + ("§",)
        esce = self._blocco(nodo.corpo, amb)
        t = firma.tipo_risultato
        if t is not None and not t.accetta_nulla and not esce and not ricava:
            self.segnala(nodo, f"`{firma.nome}` deve dare {self.descrivi(t)}, ma può finire senza `restituisci`.",
                         codice="risultato", suggerimento="Aggiungi `restituisci ...` in fondo alla funzione "
                                                          "(o in ogni ramo di `se`/`scegli`).",
                         lunghezza=len("funzione"))
        restituiti = amb.restituiti  # type: ignore[attr-defined]
        if not restituiti:
            return _NULLA if ricava else None
        tipo: Tipo | None = restituiti[0]
        for r in restituiti[1:]:
            tipo = _unisci(tipo, r)
        if not esce and tipo is not None:
            tipo = tipo.con_nulla
        return tipo

    # =========================================================================
    # Istruzioni
    # =========================================================================

    def _blocco(self, istruzioni: list, amb: Ambito, *, esterno: bool = False) -> bool:
        """Analizza un blocco; vero se il blocco esce sempre (restituisci/lancia...)."""
        esce = False
        segnalato = False
        for ist in istruzioni:
            if esce and not segnalato and not isinstance(ist, (N.DefinizioneFunzione, N.Evento)):
                self.segnala(ist, "Questa riga non viene mai eseguita: il blocco è già finito prima.",
                             codice="irraggiungibile", gravita="avviso",
                             suggerimento="Prima c'è un `restituisci`, `interrompi`, `continua` o `lancia` che "
                                          "esce sempre: togli le righe che non servono o spostale prima.",
                             lunghezza=1)
                segnalato = True
            if self.istruzione(ist, amb, esterno=esterno):
                esce = True
        return esce

    def istruzione(self, nodo: Any, amb: Ambito, *, esterno: bool = False) -> bool:
        metodo = getattr(self, "i_" + type(nodo).__name__, None)
        if metodo is None:
            self._generico(nodo, amb)
            return False
        return bool(metodo(nodo, amb, esterno) if metodo.__code__.co_argcount > 3 else metodo(nodo, amb))

    def _generico(self, nodo: Any, amb: Ambito) -> None:
        """Nodi sconosciuti (di altri costrutti): si analizzano le espressioni e i blocchi dentro."""
        from dataclasses import fields

        for f in fields(nodo):
            valore = getattr(nodo, f.name)
            if isinstance(valore, N.Espressione):
                self.espressione(valore, amb)
            elif isinstance(valore, list) and valore and isinstance(valore[0], N.Istruzione):
                self._blocco(valore, Ambito(amb, "blocco"))

    def dichiara(self, amb: Ambito, simbolo: Simbolo, nodo: Any) -> None:
        esistente = amb.simboli.get(simbolo.nome)
        if esistente is not None and esistente.genere != "predefinito":
            dove = f" alla riga {esistente.riga}" if esistente.riga else ""
            self.segnala(nodo, f"`{simbolo.nome}` è già dichiarato{dove}.", codice="dichiarazione",
                         suggerimento=f"Per cambiarne il valore scrivi solo `{simbolo.nome} = ...`.",
                         lunghezza=len(simbolo.nome) + 10)
        amb.simboli[simbolo.nome] = simbolo
        amb.ristretti.pop(simbolo.nome, None)
        if amb.genitore is not None and amb.nome not in ("globale",) and not amb.nome.startswith("funzione"):
            self.dentro_blocchi.setdefault(simbolo.nome, simbolo.riga)

    def i_Dichiarazione(self, nodo: N.Dichiarazione, amb: Ambito) -> bool:
        tipo_valore = self.espressione(nodo.valore, amb)
        dichiarato = self.tipo_scritto(nodo.tipo, nodo) if nodo.tipo else None
        if dichiarato is not None and self.compatibile(tipo_valore, dichiarato) is False:
            self.segnala(nodo.valore, f"`{nodo.nome}` è dichiarata `{dichiarato}`, ma il valore iniziale è "
                                      f"{self.descrivi(tipo_valore)}.", codice="tipo" if tipo_valore.nome != "nulla"
                         else "nulla",
                         suggerimento=(f"Se il valore può mancare, scrivi `{dichiarato.con_nulla}`."
                                       if tipo_valore.nome == "nulla" else None),
                         lunghezza=max(1, len(_testo_nodo(nodo.valore)) or 1))
        tipo = dichiarato if dichiarato is not None else tipo_valore
        if dichiarato is None and tipo is not None and tipo.nome == "nulla":
            tipo = None     # `variabile x = nulla`: dopo diventera' qualcos'altro
        elif dichiarato is None and tipo is not None and tipo.opzionale:
            tipo = tipo.senza_nulla   # ricavato (non scritto): non si e' sicuri che possa mancare
        genere = "costante" if nodo.costante else "variabile"
        simbolo = Simbolo(nodo.nome, genere, tipo, dichiarato=dichiarato is not None, riga=nodo.riga,
                          colonna=nodo.colonna)
        if nodo.costante and (tipo is None or tipo.nome in ("lista", "dizionario") or tipo.nome in self.strutture):
            simbolo.bloccato = True
        if dichiarato is None and not nodo.costante and tipo is not None:
            simbolo.tipo = self._tipo_stabile(nodo.nome, tipo, amb)
        self.dichiara(amb, simbolo, nodo)
        if dichiarato is not None and dichiarato.opzionale and tipo_valore is not None \
                and not tipo_valore.accetta_nulla and tipo_valore.nome != "qualsiasi":
            amb.ristretti[nodo.nome] = dichiarato.senza_nulla
        return False

    def _tipo_stabile(self, nome: str, tipo: Tipo, amb: Ambito) -> Tipo | None:
        """Una variabile senza tipo scritto ha il tipo del valore iniziale solo se
        tutte le assegnazioni a quel nome danno lo stesso tipo (altrimenti: non si sa)."""
        assegnati = self._assegnazioni().get(nome)
        if assegnati is None:
            return tipo
        if any(a is None or self.compatibile(a, tipo) is not True for a in assegnati):
            return None
        return tipo

    def _assegnazioni(self) -> dict[str, list]:
        """Nome -> tipi dei letterali assegnati con ``=`` nel file (None = non letterale)."""
        cache = self.__dict__.get("_cache_assegnazioni")
        if cache is not None:
            return cache
        cache = {}
        programma = self.__dict__.get("programma")

        def visita(n: Any) -> None:
            if isinstance(n, N.Assegnazione) and isinstance(n.bersaglio, N.Nome):
                if n.operatore == "=":
                    t = _tipo_valore(n.valore.valore) if isinstance(n.valore, N.Letterale) else (
                        _TESTO if isinstance(n.valore, N.TestoInterpolato) else None)
                else:
                    t = None
                cache.setdefault(n.bersaglio.nome, []).append(t)
            if isinstance(n, list):
                for x in n:
                    visita(x)
            elif isinstance(n, N.Nodo):
                for v in vars(n).values():
                    if isinstance(v, (N.Nodo, list)):
                        visita(v)
        if programma is not None:
            visita(programma.istruzioni)
        self._cache_assegnazioni = cache
        return cache

    def i_DichiarazioneMultipla(self, nodo: Any, amb: Ambito) -> bool:
        self.espressione(nodo.valore, amb)
        for n in nodo.nomi:
            self.dichiara(amb, Simbolo(n, "costante" if nodo.costante else "variabile", riga=nodo.riga,
                                       colonna=nodo.colonna), nodo)
        return False

    def i_DefinizioneFunzione(self, nodo: N.DefinizioneFunzione, amb: Ambito, esterno: bool = False) -> bool:
        if "." in nodo.nome:
            proprietario, metodo = nodo.nome.split(".", 1)
            s = amb.cerca(proprietario)
            if s is None or s.genere not in ("struttura", "tipo"):
                if s is None:
                    self.segnala(nodo, f"Per definire il metodo `{nodo.nome}` serve prima `struttura {proprietario}`.",
                                 codice="nome", lunghezza=len("funzione"))
                else:
                    self.segnala(nodo, f"`{proprietario}` non è una struttura né un tipo: non può avere il metodo "
                                       f"`{metodo}`.", codice="nome", lunghezza=len("funzione"))
                return False
            info = s.struttura or s.famiglia
            if isinstance(info, InfoStruttura) and info.campo(metodo) is not None:
                self.segnala(nodo, f"`{proprietario}` ha già un campo `{metodo}`: un metodo deve avere un nome "
                                   "diverso.", codice="dichiarazione", lunghezza=len("funzione"))
            firma = info.metodi.get(metodo) or self._firma(nodo)
            info.metodi[metodo] = firma
            self._controlla_questo(nodo)
            self._corpo_funzione(nodo, firma, amb, questo=proprietario)
            return False
        firma = None
        if esterno:
            s = self.esterne.simboli.get(nodo.nome)
            firma = s.firma if s is not None else None
        if firma is None:
            firma = self._firma(nodo)
        self.dichiara(amb, Simbolo(nodo.nome, "funzione", _FUNZIONE, riga=nodo.riga, colonna=nodo.colonna,
                                   firma=firma), nodo)
        self._corpo_funzione(nodo, firma, amb)
        return False

    def _controlla_questo(self, nodo: N.DefinizioneFunzione) -> None:
        for p in nodo.parametri:
            if p.nome == "questo":
                self.segnala(p, "`questo` c'è già in ogni metodo (è il valore prima del punto): togli il parametro "
                                "`questo`.", codice="dichiarazione")

    def i_DefinizioneStruttura(self, nodo: N.DefinizioneStruttura, amb: Ambito) -> bool:
        info = self.strutture.get(nodo.nome)
        if info is None or info.campi is not nodo.campi:
            info = InfoStruttura(nodo.nome, nodo.campi)
            self.strutture[nodo.nome] = info
            for c in nodo.campi:
                self.tipo_scritto(c.tipo, c)
        self.dichiara(amb, Simbolo(nodo.nome, "struttura", _FUNZIONE, riga=nodo.riga, colonna=nodo.colonna,
                                   struttura=info), nodo)
        for c in nodo.campi:
            if c.predefinito is not None:
                tp = self.espressione(c.predefinito, amb)
                tc = self.tipo_scritto(c.tipo, c) if c.tipo else None
                if tc is not None and self.compatibile(tp, tc) is False:
                    self.segnala(c.predefinito, f"Il campo `{c.nome}` è `{tc}`, ma il valore predefinito è "
                                                f"{self.descrivi(tp)}.", codice="tipo")
        for m in nodo.metodi:
            firma = info.metodi.get(m.nome) or self._firma(m, f"{nodo.nome}.{m.nome}")
            info.metodi[m.nome] = firma
            self._controlla_questo(m)
            self._corpo_funzione(m, firma, amb, questo=nodo.nome)
        return False

    def i_DefinizioneTipo(self, nodo: N.DefinizioneTipo, amb: Ambito) -> bool:
        famiglia = self.famiglie.get(nodo.nome) or InfoFamiglia(nodo.nome, [v.nome for v in nodo.varianti])
        self.famiglie[nodo.nome] = famiglia
        self.dichiara(amb, Simbolo(nodo.nome, "tipo", riga=nodo.riga, colonna=nodo.colonna, famiglia=famiglia), nodo)
        for v in nodo.varianti:
            info = self.strutture.get(v.nome)
            if info is None:
                info = InfoStruttura(v.nome, v.campi or [], genitore=nodo.nome, senza_dati=v.campi is None)
                self.strutture[v.nome] = info
            self.dichiara(amb, Simbolo(v.nome, "variante", Tipo(v.nome) if v.campi is None else _FUNZIONE,
                                       riga=v.riga or nodo.riga, colonna=v.colonna, struttura=info), v)
        return False

    def i_Importa(self, nodo: N.Importa, amb: Ambito) -> bool:
        for n, s in self._simboli_importati(nodo, segnala=True).items():
            esistente = amb.simboli.get(n)
            if esistente is not None and esistente.genere not in ("predefinito",) and esistente is not s \
                    and s.genere != "modulo":
                self.segnala(nodo, f"Il modulo `{nodo.modulo}` contiene `{n}`, che nel programma esiste già.",
                             codice="dichiarazione", lunghezza=len("importa"),
                             suggerimento=f"Importalo con un nome: `importa \"{nodo.modulo}\" come ...`.")
            amb.simboli[n] = s
        return False

    def i_Assegnazione(self, nodo: N.Assegnazione, amb: Ambito) -> bool:
        bersaglio = nodo.bersaglio
        tipo_valore = self.espressione(nodo.valore, amb)
        composta = nodo.operatore != "="
        if isinstance(bersaglio, N.Nome):
            s = amb.cerca(bersaglio.nome)
            if s is None:
                if self.dichiarazione_implicita and not composta:
                    self.dichiara(amb, Simbolo(bersaglio.nome, "variabile", tipo_valore, riga=nodo.riga,
                                               colonna=nodo.colonna), nodo)
                    return False
                self._nome_sconosciuto(bersaglio, amb, per_assegnare=not composta)
                return False
            if s.genere in ("funzione",) or (s.genere == "predefinito" and s.nativo is not None
                                              and s.tipo == _FUNZIONE):
                self.segnala(bersaglio, f"`{s.nome}` è una funzione: non le puoi dare un valore con `=`.",
                             codice="costante", suggerimento="Se ti serve una variabile, usa un altro nome.")
                return False
            if s.genere in ("costante", "struttura", "tipo", "variante", "predefinito"):
                self.segnala(bersaglio, f"`{s.nome}` è una costante: non si può cambiare il suo valore.",
                             codice="costante",
                             suggerimento="Se deve cambiare, dichiarala con `variabile` invece di `costante`.")
                return False
            tipo_attuale = self._tipo_nome(s, amb)
            self._amb_corrente = amb
            if composta:
                tipo_valore = self._binaria(nodo.operatore[:-1], N.Nome(s.nome, riga=nodo.riga, colonna=nodo.colonna),
                                            tipo_attuale, nodo.valore, tipo_valore, nodo)
            if s.dichiarato and s.tipo is not None:
                if self.compatibile(tipo_valore, s.tipo) is False:
                    self.segnala(nodo.valore, f"`{s.nome}` è dichiarata `{s.tipo}`: non può ricevere "
                                              f"{self.descrivi(tipo_valore)}.",
                                 codice="nulla" if tipo_valore.nome == "nulla" else "tipo",
                                 lunghezza=max(1, len(_testo_nodo(nodo.valore))))
                if s.tipo.opzionale:
                    if tipo_valore is not None and not tipo_valore.accetta_nulla:
                        amb.ristretti[s.nome] = s.tipo.senza_nulla
                    else:
                        amb.ristretti[s.nome] = s.tipo
            return False
        radice = _radice(bersaglio)
        if radice is not None:
            s = amb.cerca(radice.nome)
            if s is not None and s.genere == "costante" and s.bloccato:
                self.segnala(bersaglio, f"`{s.nome}` è una costante: il suo contenuto non si può cambiare.",
                             codice="costante",
                             suggerimento="Se deve cambiare, dichiarala con `variabile` invece di `costante`; per "
                                          "lavorare su una copia modificabile scrivi `copia(...)`.",
                             lunghezza=len(radice.nome))
        if isinstance(bersaglio, N.Indice):
            self.espressione(bersaglio.oggetto, amb)
            self.espressione(bersaglio.indice, amb)
            return False
        if isinstance(bersaglio, N.Attributo):
            tipo_oggetto = self.espressione(bersaglio.oggetto, amb)
            if tipo_oggetto is not None:
                self._non_nulla(bersaglio.oggetto, tipo_oggetto, amb, "cambiarne un campo")
                info = self.strutture.get(tipo_oggetto.nome)
                if info is not None:
                    campo = info.campo(bersaglio.nome)
                    if campo is None:
                        self._campo_sconosciuto(bersaglio, info)
                    elif campo.tipo:
                        tc = self.tipo_scritto(campo.tipo, campo)
                        if tc is not None and self.compatibile(tipo_valore, tc) is False:
                            self.segnala(nodo.valore, f"Il campo `{campo.nome}` di `{info.nome}` è `{tc}`: non può "
                                                      f"ricevere {self.descrivi(tipo_valore)}.", codice="tipo")
                elif tipo_oggetto.nome in ("lista", "testo", "dizionario", "intero", "decimale", "logico"):
                    self.segnala(bersaglio, "Si possono cambiare solo le proprietà dei controlli grafici.",
                                 codice="campo",
                                 suggerimento="Per un dizionario scrivi `d[\"chiave\"] = valore`."
                                 if tipo_oggetto.nome == "dizionario" else None)
            return False
        self.espressione(bersaglio, amb)
        return False

    def i_AssegnazioneMultipla(self, nodo: Any, amb: Ambito) -> bool:
        self.espressione(nodo.valore, amb)
        for b in nodo.bersagli:
            if isinstance(b, N.Nome):
                s = amb.cerca(b.nome)
                if s is None and not self.dichiarazione_implicita:
                    self._nome_sconosciuto(b, amb, per_assegnare=True)
                elif s is not None and s.genere == "costante":
                    self.segnala(b, f"`{s.nome}` è una costante: non si può cambiare il suo valore.",
                                 codice="costante")
            else:
                self.espressione(b, amb)
        return False

    def i_IstruzioneEspressione(self, nodo: Any, amb: Ambito) -> bool:
        self.espressione(nodo.espressione, amb)
        return False

    # --- condizioni e restringimenti -----------------------------------------------------

    def condizione(self, espressione: Any, amb: Ambito, contesto: str) -> None:
        tipo = self.espressione(espressione, amb)
        if tipo is not None and not tipo.opzionale and tipo.nome in _CAMPIONI and tipo.nome != "logico":
            from ..valori import verifica_logico

            try:
                verifica_logico(_CAMPIONI[tipo.nome], contesto)
            except ErroreTipo as e:
                self.segnala(espressione, e.messaggio, codice="tipo", suggerimento=e.suggerimento,
                             lunghezza=max(1, len(_testo_nodo(espressione)) or 1))

    def _restringimenti(self, condizione: Any, vero: bool) -> dict[str, bool]:
        """Nomi che la condizione garantisce (``vero``: quando è vera) con valore (True) o nulla (False)."""
        risultato: dict[str, bool] = {}
        if isinstance(condizione, N.HaValore) and isinstance(condizione.valore, N.Nome):
            ha = not condizione.negato
            risultato[condizione.valore.nome] = ha if vero else not ha
        elif isinstance(condizione, N.Confronto) and len(condizione.operatori) == 1 \
                and condizione.operatori[0] in ("==", "!="):
            a, b = condizione.operandi
            nome = None
            if isinstance(a, N.Nome) and isinstance(b, N.Letterale) and b.valore is None:
                nome = a.nome
            elif isinstance(b, N.Nome) and isinstance(a, N.Letterale) and a.valore is None:
                nome = b.nome
            if nome is not None:
                ha = condizione.operatori[0] == "!="
                risultato[nome] = ha if vero else not ha
        elif isinstance(condizione, N.Logica) and condizione.operatore == "e" and vero:
            risultato.update(self._restringimenti(condizione.sinistra, True))
            risultato.update(self._restringimenti(condizione.destra, True))
        elif isinstance(condizione, N.Logica) and condizione.operatore == "o" and not vero:
            risultato.update(self._restringimenti(condizione.sinistra, False))
            risultato.update(self._restringimenti(condizione.destra, False))
        elif isinstance(condizione, N.Unaria) and condizione.operatore == "non":
            risultato.update(self._restringimenti(condizione.operando, not vero))
        return risultato

    def _applica(self, amb: Ambito, restringimenti: dict[str, bool]) -> None:
        for nome, ha in restringimenti.items():
            s = amb.cerca(nome)
            if s is not None and s.tipo is not None:
                amb.ristretti[nome] = s.tipo.senza_nulla if ha else _NULLA

    def i_Se(self, nodo: N.Se, amb: Ambito) -> bool:
        tutti_escono = True
        negati: list[dict] = []
        for ramo in nodo.rami:
            interno = Ambito(amb, "se")
            for r in negati:                      # nei rami dopo, le condizioni prima sono false
                self._applica(interno, r)
            self._condizione_ristretta(ramo.condizione, amb, interno, negati)
            self._applica(interno, self._restringimenti(ramo.condizione, True))
            if not self._blocco(ramo.corpo, interno):
                tutti_escono = False
            negati.append(self._restringimenti(ramo.condizione, False))
        if nodo.altrimenti is not None:
            interno = Ambito(amb, "altrimenti")
            for r in negati:
                self._applica(interno, r)
            if not self._blocco(nodo.altrimenti, interno):
                tutti_escono = False
        else:
            tutti_escono = False
            # `se x non ha valore allora restituisci ... fine`: dopo, x ha valore
            if len(nodo.rami) == 1 and self._esce(nodo.rami[0].corpo):
                self._applica(amb, negati[0])
        return tutti_escono

    def _condizione_ristretta(self, condizione: Any, amb: Ambito, interno: Ambito, negati: list) -> None:
        """La condizione di un ramo, con i restringimenti dei rami prima (e di `e`)."""
        valutazione = Ambito(amb, "condizione")
        for r in negati:
            self._applica(valutazione, r)
        self.condizione(condizione, valutazione, "se")

    def _esce(self, corpo: list) -> bool:
        if not corpo:
            return False
        ultima = corpo[-1]
        if isinstance(ultima, (N.Restituisci, N.Lancia, N.Interrompi, N.Continua)):
            return True
        if isinstance(ultima, N.Se) and ultima.altrimenti is not None:
            return all(self._esce(r.corpo) for r in ultima.rami) and self._esce(ultima.altrimenti)
        return False

    def i_Mentre(self, nodo: N.Mentre, amb: Ambito) -> bool:
        self.condizione(nodo.condizione, amb, "mentre")
        interno = Ambito(amb, "mentre")
        self._applica(interno, self._restringimenti(nodo.condizione, True))
        self._blocco(nodo.corpo, interno)
        # `mentre vero` senza `interrompi`: non finisce mai (conta come uscita)
        return (isinstance(nodo.condizione, N.Letterale) and nodo.condizione.valore is True
                and not self._contiene_interrompi(nodo.corpo))

    def _contiene_interrompi(self, corpo: Any) -> bool:
        if isinstance(corpo, N.Interrompi):
            return True
        if isinstance(corpo, (N.Mentre, N.PerOgni, N.Ripeti, N.FunzioneAnonima, N.DefinizioneFunzione)):
            return False
        if isinstance(corpo, list):
            return any(self._contiene_interrompi(x) for x in corpo)
        if isinstance(corpo, N.Nodo):
            return any(self._contiene_interrompi(v) for v in vars(corpo).values() if isinstance(v, (N.Nodo, list)))
        return False

    def _elemento(self, tipo: Tipo | None) -> Tipo | None:
        if tipo is None:
            return None
        if tipo.nome == "lista":
            return tipo.elementi
        if tipo.nome == "testo":
            return _TESTO
        if tipo.nome == "intervallo":
            return _INTERO
        if tipo.nome == "dizionario":
            return None
        return None

    def i_PerOgni(self, nodo: N.PerOgni, amb: Ambito) -> bool:
        tipo = self.espressione(nodo.iterabile, amb)
        if tipo is not None:
            self._non_nulla(nodo.iterabile, tipo, amb, "scorrerlo con `per ogni`")
            if tipo.nome in ("intero", "decimale", "logico") and not tipo.opzionale:
                self.segnala(nodo.iterabile, f"`per ogni` scorre liste, testi, dizionari e intervalli, non "
                                             f"{self.descrivi(tipo)}.", codice="tipo",
                             suggerimento="Per contare scrivi per esempio `per ogni i in 1..n fai`.",
                             lunghezza=max(1, len(_testo_nodo(nodo.iterabile))))
        interno = Ambito(amb, "per ogni")
        nomi = nodo.variabili or [nodo.variabile]
        elemento = self._elemento(tipo) if len(nomi) == 1 else None
        for n in nomi:
            interno.simboli[n] = Simbolo(n, "ciclo", elemento, riga=nodo.riga, colonna=nodo.colonna)
        self._blocco(nodo.corpo, interno)
        return False

    def i_Ripeti(self, nodo: N.Ripeti, amb: Ambito) -> bool:
        tipo = self.espressione(nodo.volte, amb)
        if tipo is not None and tipo.nome in ("testo", "lista", "logico", "decimale") and not tipo.opzionale:
            self.segnala(nodo.volte, f"`ripeti` vuole un numero intero di volte, non {self.descrivi(tipo)}.",
                         codice="tipo", lunghezza=max(1, len(_testo_nodo(nodo.volte))))
        self._blocco(nodo.corpo, Ambito(amb, "ripeti"))
        return False

    def i_Restituisci(self, nodo: N.Restituisci, amb: Ambito) -> bool:
        tipo = self.espressione(nodo.valore, amb) if nodo.valore is not None else _NULLA
        a: Ambito | None = amb
        while a is not None and not hasattr(a, "restituiti"):
            a = a.genitore
        if a is not None:
            a.restituiti.append(tipo)  # type: ignore[attr-defined]
            firma = a.funzione
            atteso = firma.tipo_risultato if firma is not None else None
            if atteso is not None and self.compatibile(tipo, atteso) is False:
                if nodo.valore is None:
                    self.segnala(nodo, f"`{firma.nome}` deve dare {self.descrivi(atteso)}: scrivi il valore dopo "
                                       "`restituisci`.", codice="risultato", lunghezza=len("restituisci"))
                else:
                    self.segnala(nodo.valore, f"`{firma.nome}` deve dare {self.descrivi(atteso)}, ma qui dà "
                                              f"{self.descrivi(tipo)}.", codice="nulla" if tipo.nome == "nulla"
                                 or tipo.opzionale else "tipo",
                                 lunghezza=max(1, len(_testo_nodo(nodo.valore))),
                                 suggerimento=(f"Controlla prima con `se ... ha valore`, oppure scrivi il tipo "
                                               f"`{atteso.con_nulla}`." if tipo.opzionale else None))
        return True

    def i_Interrompi(self, nodo: Any, amb: Ambito) -> bool:
        return True

    def i_Continua(self, nodo: Any, amb: Ambito) -> bool:
        return True

    def i_Lancia(self, nodo: N.Lancia, amb: Ambito) -> bool:
        self.espressione(nodo.valore, amb)
        v = nodo.valore
        if isinstance(v, N.Chiamata) and isinstance(v.funzione, N.Nome) and v.funzione.nome in TIPI_ERRORE:
            self._puo_dare(v.funzione.nome, nodo, amb, origine="lancia")
        return True

    def i_Prova(self, nodo: N.Prova, amb: Ambito) -> bool:
        catturati = tuple(c.tipo_errore or "*" for c in nodo.catture)
        self._dentro_prova += 1 if catturati else 0
        try:
            esce_corpo = self._blocco(nodo.corpo, Ambito(amb, "prova", cattura=catturati + amb.cattura))
        finally:
            self._dentro_prova -= 1 if catturati else 0
        esce_tutte = True
        for c in nodo.catture:
            if c.tipo_errore is not None and c.tipo_errore not in TIPI_ERRORE:
                simili = difflib.get_close_matches(c.tipo_errore, list(TIPI_ERRORE), n=1, cutoff=0.6)
                self.segnala(c, f"`{c.tipo_errore}` non è un tipo di errore.", codice="nome",
                             suggerimento=f"Forse intendevi `{simili[0]}`?" if simili else
                             "I tipi di errore sono: " + ", ".join(f"`{t}`" for t in TIPI_ERRORE) + ".",
                             lunghezza=len("cattura"))
            interno = Ambito(amb, "cattura")
            if c.nome_variabile:
                interno.simboli[c.nome_variabile] = Simbolo(c.nome_variabile, "variabile", Tipo("errore"),
                                                            riga=c.riga, colonna=c.colonna)
            if not self._blocco(c.corpo, interno):
                esce_tutte = False
        esce_infine = False
        if nodo.infine is not None:
            esce_infine = self._blocco(nodo.infine, Ambito(amb, "infine"))
        return esce_infine or (esce_corpo and esce_tutte and bool(nodo.catture))

    def i_Evento(self, nodo: N.Evento, amb: Ambito) -> bool:
        firma = Firma(f"{nodo.controllo}.{nodo.evento}", [])
        interno = Ambito(amb, f"funzione {firma.nome}", funzione=firma, cattura=("§",), riserva=self.esterne)
        interno.restituiti = []  # type: ignore[attr-defined]
        # nel gestore c'e' `evento`, il dizionario con i dati (vedi Interprete.chiama_gestore)
        interno.simboli["evento"] = Simbolo("evento", "variabile", _DIZIONARIO, riga=nodo.riga)
        self._blocco(nodo.corpo, interno)
        return False

    def i_Scegli(self, nodo: N.Scegli, amb: Ambito) -> bool:
        tipo = self.espressione(nodo.valore, amb)
        famiglia: InfoFamiglia | None = None
        if tipo is not None:
            famiglia = self.famiglie.get(tipo.nome)
            if famiglia is None and tipo.nome in self.strutture and self.strutture[tipo.nome].genitore:
                famiglia = self.famiglie.get(self.strutture[tipo.nome].genitore or "")
        coperte: set[str] = set()
        tutti_escono = True
        for caso in nodo.casi:
            interno = Ambito(amb, "caso")
            for schema in caso.schemi:
                variante = self._schema(schema, amb, interno, famiglia)
                if variante is not None:
                    info, completa = variante
                    if famiglia is None and info.genitore:
                        famiglia = self.famiglie.get(info.genitore)
                    if completa:
                        coperte.add(info.nome)
            if not self._blocco(caso.corpo, interno):
                tutti_escono = False
        if nodo.altrimenti is not None:
            if not self._blocco(nodo.altrimenti, Ambito(amb, "altrimenti")):
                tutti_escono = False
        elif famiglia is not None:
            mancanti = [v for v in famiglia.varianti if v not in coperte]
            if mancanti:
                elenco = ", ".join(f"`{m}`" for m in mancanti)
                self.segnala(nodo, (f"Manca il caso {elenco}" if len(mancanti) == 1 else f"Mancano i casi {elenco}")
                             + f" del tipo `{famiglia.nome}`: con quel valore `scegli` si fermerebbe con un errore.",
                             codice="caso", gravita="avviso", lunghezza=len("scegli"),
                             suggerimento=f"Aggiungi `caso {mancanti[0]} allora` (o un ramo `altrimenti`).")
                tutti_escono = False
        else:
            tutti_escono = False
        return tutti_escono and bool(nodo.casi)

    def _schema(self, schema: Any, amb: Ambito, interno: Ambito,
                famiglia: InfoFamiglia | None) -> tuple[InfoStruttura, bool] | None:
        """Analizza uno schema di ``caso``; se è una variante/struttura restituisce
        (info, completo) e mette i nomi legati in ``interno``."""
        nome = None
        if isinstance(schema, N.Nome):
            nome = schema.nome
        elif isinstance(schema, N.Chiamata) and isinstance(schema.funzione, N.Nome):
            nome = schema.funzione.nome
        info = self.strutture.get(nome) if nome else None
        s = amb.cerca(nome) if nome else None
        if info is None or s is None or s.struttura is not info:
            self.espressione(schema, amb)
            return None
        if famiglia is not None and info.genitore != famiglia.nome:
            self.segnala(schema, f"`{info.nome}` non è una variante di `{famiglia.nome}`.", codice="caso",
                         suggerimento="Varianti: " + ", ".join(f"`{v}`" for v in famiglia.varianti) + ".",
                         lunghezza=len(info.nome))
        if isinstance(schema, N.Nome):
            return info, True
        if info.senza_dati:
            self.segnala(schema, f"`{info.nome}` non ha dati: nel `caso` scrivilo senza parentesi.", codice="caso",
                         lunghezza=len(info.nome))
            return info, True
        completo = True
        posizionali = [a for a in schema.argomenti if a.nome is None]
        if len(posizionali) > len(info.campi):
            self.segnala(schema, f"`{info.nome}` ha {len(info.campi)} campi, ma nel `caso` ne hai scritti "
                                 f"{len(posizionali)}.", codice="argomenti", lunghezza=len(info.nome),
                         suggerimento="Campi: " + ", ".join(f"`{c.nome}`" for c in info.campi) + ".")
        coppie = list(zip(info.campi, posizionali))
        for a in schema.argomenti:
            if a.nome is not None:
                campo = info.campo(a.nome)
                if campo is None:
                    self._campo_sconosciuto(N.Attributo(schema, a.nome, riga=a.riga, colonna=a.colonna), info)
                    continue
                coppie.append((campo, a))
        for campo, a in coppie:
            if isinstance(a.valore, N.Nome):
                if a.valore.nome != "_":
                    tc = self.tipo_scritto(campo.tipo, campo) if campo.tipo else None
                    interno.simboli[a.valore.nome] = Simbolo(a.valore.nome, "variabile", tc, dichiarato=tc is not None,
                                                             riga=a.valore.riga, colonna=a.valore.colonna)
            else:
                completo = False
                self.espressione(a.valore, amb)
        return info, completo

    def i_Richiede(self, nodo: Any, amb: Ambito) -> bool:
        self.condizione(nodo.condizione, amb, "richiede")
        return False

    def i_Verifica(self, nodo: Any, amb: Ambito) -> bool:
        self.condizione(nodo.condizione, amb, "verifica")
        if nodo.messaggio is not None:
            self.espressione(nodo.messaggio, amb)
        return False

    def i_Temporizzatore(self, nodo: Any, amb: Ambito) -> bool:
        self.espressione(nodo.durata, amb)
        firma = Firma("ogni" if nodo.ripeti else "dopo", [])
        interno = Ambito(amb, "funzione temporizzatore", funzione=firma, riserva=self.esterne)
        interno.restituiti = []  # type: ignore[attr-defined]
        self._blocco(nodo.corpo, interno)
        return False

    def i_BloccoVerifica(self, nodo: Any, amb: Ambito) -> bool:
        self.espressione(nodo.nome, amb)
        self._blocco(nodo.corpo, Ambito(amb, "verifica"))
        return False

    def i_Aspettati(self, nodo: Any, amb: Ambito) -> bool:
        self.condizione(nodo.condizione, amb, "aspettati")
        return False

    def i_AspettatiErrore(self, nodo: Any, amb: Ambito) -> bool:
        self._blocco(nodo.corpo, Ambito(amb, "aspettati", cattura=("*",)))
        return False

    # =========================================================================
    # Espressioni
    # =========================================================================

    def espressione(self, nodo: Any, amb: Ambito) -> Tipo | None:
        if nodo is None:
            return None
        metodo = getattr(self, "e_" + type(nodo).__name__, None)
        if metodo is None:
            from dataclasses import fields

            for f in fields(nodo) if hasattr(nodo, "__dataclass_fields__") else ():
                valore = getattr(nodo, f.name)
                if isinstance(valore, N.Espressione):
                    self.espressione(valore, amb)
                elif isinstance(valore, list):
                    for x in valore:
                        if isinstance(x, N.Espressione):
                            self.espressione(x, amb)
                        elif isinstance(x, N.Istruzione):
                            self._blocco([x], Ambito(amb, "blocco"))
            return None
        return metodo(nodo, amb)

    def e_Letterale(self, nodo: Any, amb: Ambito) -> Tipo | None:
        return _tipo_valore(nodo.valore)

    def e_TestoInterpolato(self, nodo: Any, amb: Ambito) -> Tipo | None:
        for parte in nodo.parti:
            if not isinstance(parte, str):
                self.espressione(parte, amb)
        return _TESTO

    def e_ValoreFormattato(self, nodo: Any, amb: Ambito) -> Tipo | None:
        self.espressione(nodo.valore, amb)
        return _TESTO

    def e_ListaLetterale(self, nodo: Any, amb: Ambito) -> Tipo | None:
        tipi = [self.espressione(e, amb) for e in nodo.elementi]
        if not tipi:
            return _LISTA
        elemento = tipi[0]
        for t in tipi[1:]:
            elemento = _unisci(elemento, t)
        return Tipo("lista", elemento) if elemento is not None and elemento.nome != "nulla" else _LISTA

    def e_DizionarioLetterale(self, nodo: Any, amb: Ambito) -> Tipo | None:
        tipi = []
        for k, v in nodo.coppie:
            self.espressione(k, amb)
            tipi.append(self.espressione(v, amb))
        if not tipi:
            return _DIZIONARIO
        elemento = tipi[0]
        for t in tipi[1:]:
            elemento = _unisci(elemento, t)
        return Tipo("dizionario", elemento) if elemento is not None and elemento.nome != "nulla" else _DIZIONARIO

    def e_ListaCompresa(self, nodo: Any, amb: Ambito) -> Tipo | None:
        tipo = self.espressione(nodo.iterabile, amb)
        interno = Ambito(amb, "lista")
        elemento = self._elemento(tipo) if len(nodo.variabili) == 1 else None
        for n in nodo.variabili:
            interno.simboli[n] = Simbolo(n, "ciclo", elemento, riga=nodo.riga)
        if nodo.condizione is not None:
            self.condizione(nodo.condizione, interno, "se")
            self._applica(interno, self._restringimenti(nodo.condizione, True))
        t = self.espressione(nodo.elemento, interno)
        return Tipo("lista", t) if t is not None and t.nome != "nulla" else _LISTA

    def e_FunzioneAnonima(self, nodo: Any, amb: Ambito) -> Tipo | None:
        firma = Firma("<anonima>", list(nodo.parametri))
        self._corpo_funzione(nodo, firma, amb)
        return _FUNZIONE

    def e_Parallelo(self, nodo: Any, amb: Ambito) -> Tipo | None:
        firma = Firma("in parallelo", [])
        interno = Ambito(amb, "funzione in parallelo", funzione=firma)
        interno.restituiti = []  # type: ignore[attr-defined]
        self._blocco(nodo.corpo, interno)
        return Tipo("lavoro")

    def e_Intervallo(self, nodo: Any, amb: Ambito) -> Tipo | None:
        for parte in (nodo.inizio, nodo.fine):
            t = self.espressione(parte, amb)
            if t is not None and t.nome in ("testo", "lista", "logico", "decimale") and not t.opzionale:
                self.segnala(parte, f"Gli estremi di un intervallo `a..b` sono interi, non {self.descrivi(t)}.",
                             codice="tipo", lunghezza=max(1, len(_testo_nodo(parte))))
        return _INTERVALLO

    def e_HaValore(self, nodo: Any, amb: Ambito) -> Tipo | None:
        self.espressione(nodo.valore, amb)
        return _LOGICO

    # --- nomi ---------------------------------------------------------------------

    def _tipo_nome(self, s: Simbolo, amb: Ambito) -> Tipo | None:
        ristretto = amb.tipo_ristretto(s.nome)
        if ristretto is not None:
            return ristretto
        return s.tipo

    def e_Nome(self, nodo: N.Nome, amb: Ambito) -> Tipo | None:
        s = amb.cerca(nodo.nome)
        if s is None:
            self._nome_sconosciuto(nodo, amb)
            return None
        if s.genere == "struttura" or s.genere == "variante":
            return s.tipo
        return self._tipo_nome(s, amb)

    def _nome_sconosciuto(self, nodo: N.Nome, amb: Ambito, *, per_assegnare: bool = False) -> None:
        nome = nodo.nome
        # tolleranze dell'interprete: maiuscole sbagliate e colori senza virgolette
        visibili = amb.visibili()
        simili_maiuscole = [n for n in visibili if n.lower() == nome.lower() and n != nome
                            and not (nome[:1].isupper() and getattr(amb.cerca(n), "genere", "") == "predefinito")]
        if len(simili_maiuscole) == 1:
            self.segnala(nodo, f"`{nome}` si scrive `{simili_maiuscole[0]}`.", codice="maiuscole", gravita="avviso",
                         suggerimento="Leo capisce lo stesso, ma è meglio scrivere il nome sempre allo stesso modo.")
            return
        try:
            from ..grafica.colori import COLORI_NOMINATI
        except Exception:  # noqa: BLE001
            COLORI_NOMINATI = {}
        if nome.lower() in COLORI_NOMINATI and not per_assegnare:
            return
        dopo = self.dichiarati_dopo.get(nome)
        if dopo is not None and dopo > (nodo.riga or 0):
            self.segnala(nodo, f"`{nome}` qui non esiste ancora: è dichiarato più avanti, alla riga {dopo}.",
                         codice="nome", suggerimento="Il programma si esegue dall'alto in basso: sposta la "
                                                     "dichiarazione prima, oppure metti il programma principale in "
                                                     "un blocco `inizio ... fine`.")
            return
        for modulo in self.cache_moduli.values():
            if modulo is not None and nome in modulo.privati:
                self.segnala(nodo, f"`{nome}` è privato del modulo `{modulo.nome}`: si usa solo dentro quel file.",
                             codice="privato",
                             suggerimento="Nel file del modulo scrivi `pubblica` davanti alla sua dichiarazione."
                             if not nome.startswith("_") else
                             "I nomi che cominciano con `_` restano dentro il loro file.")
                return
        from ..suggerimenti import suggerisci_nome

        try:
            suggerimento = suggerisci_nome(nome, visibili)
        except Exception:  # noqa: BLE001
            suggerimento = None
        if not suggerimento and nome in self.dentro_blocchi:
            suggerimento = (f"`{nome}` è dichiarato alla riga {self.dentro_blocchi[nome]} dentro un blocco: "
                            "esiste solo lì dentro. Dichiaralo prima del blocco se ti serve anche fuori.")
        if not suggerimento and per_assegnare:
            suggerimento = f"Per creare una nuova variabile scrivi `variabile {nome} = ...`."
        elif not suggerimento and nome[:1].isupper():
            suggerimento = f'Se volevi il testo "{nome}", scrivilo tra virgolette: "{nome}".'
        self.segnala(nodo, f"`{nome}` non è definito.", codice="nome", suggerimento=suggerimento)

    # --- operatori ---------------------------------------------------------------------

    def _dichiarato(self, nodo: Any, amb: Ambito) -> bool:
        """Il tipo di ``nodo`` viene da una dichiarazione scritta (``x: testo?``,
        un campo, ``dà T?``)? Solo allora un ``nulla`` possibile è un errore: i
        tipi ricavati da soli non bastano per esserne sicuri."""
        if isinstance(nodo, N.Nome):
            s = amb.cerca(nodo.nome)
            return s is not None and s.dichiarato
        if isinstance(nodo, N.Attributo):
            return True     # campo di una struttura (con il tipo scritto)
        if isinstance(nodo, N.Chiamata):
            f = nodo.funzione
            s = amb.cerca(f.nome) if isinstance(f, N.Nome) else None
            return s is not None and s.firma is not None and s.firma.tipo_risultato is not None
        return False

    def _non_nulla(self, nodo: Any, tipo: Tipo | None, amb: Ambito, uso: str) -> None:
        """Errore se ``nodo`` ha un tipo dichiarato ``T?`` non controllato."""
        if tipo is None or not tipo.opzionale or tipo.nome in ("qualsiasi",):
            return
        if not self._dichiarato(nodo, amb):
            return
        nome = _testo_nodo(nodo) or "Questo valore"
        chi = f"`{nome}`" if nome != "Questo valore" else nome
        self.segnala(nodo, f"{chi} può essere `nulla` (è `{tipo}`): controllalo prima di {uso}.",
                     codice="nulla",
                     suggerimento=(f"Scrivi `se {nome} ha valore allora ... fine`, oppure usa un valore di riserva: "
                                   f"`{nome} oppure ...`." if nome != "Questo valore" else
                                   "Controlla con `se ... ha valore`, oppure usa `... oppure valore_di_riserva`."),
                     lunghezza=max(1, len(nome)) if nome != "Questo valore" else 1)

    def _campione(self, nodo: Any, tipo: Tipo) -> Any:
        if isinstance(nodo, N.Letterale):
            return nodo.valore
        return _CAMPIONI.get(tipo.nome, _CAMPIONI.get("intero"))

    def _binaria(self, op: str, sx: Any, ts: Tipo | None, dx: Any, td: Tipo | None, nodo: Any) -> Tipo | None:
        from .. import operazioni

        for parte, t in ((sx, ts), (dx, td)):
            if t is not None and t.opzionale and t.nome != "nulla":
                if self._dichiarato(parte, self._amb_corrente):
                    self._non_nulla(parte, t, self._amb_corrente, "usarlo in un calcolo")
                return None
        if ts is None or td is None or ts.nome not in _CAMPIONI or td.nome not in _CAMPIONI:
            if op == "/" and ts is not None and td is not None:
                return _DECIMALE if ts.nome in ("intero", "decimale", "numero") else None
            return None
        a, b = self._campione(sx, ts), self._campione(dx, td)
        try:
            risultato = operazioni.binaria(op, a, b)
        except ErroreDivisione as e:
            if isinstance(dx, N.Letterale):
                self.segnala(nodo, e.messaggio, codice="tipo", suggerimento=e.suggerimento, lunghezza=1)
            return _DECIMALE if op == "/" else None
        except ErroreTipo as e:
            messaggio, suggerimento = e.messaggio, e.suggerimento
            if suggerimento and not isinstance(dx, N.Letterale) and _testo_nodo(dx):
                from ..valori import rappresenta

                suggerimento = suggerimento.replace(f"({rappresenta(b, dentro=True)})", f"({_testo_nodo(dx)})")
            if suggerimento and not isinstance(sx, N.Letterale) and _testo_nodo(sx):
                from ..valori import rappresenta

                suggerimento = suggerimento.replace(f"({rappresenta(a, dentro=True)})", f"({_testo_nodo(sx)})")
            self.segnala(nodo, messaggio, codice="tipo", suggerimento=suggerimento, lunghezza=1)
            return None
        except Exception:  # noqa: BLE001 - qualunque altra cosa: non si sa
            return None
        if "numero" in (ts.nome, td.nome) and isinstance(risultato, (int, float)) and not isinstance(risultato, bool):
            return _NUMERO
        if op == "^" and ts.nome == "intero" and td.nome == "intero":
            return _NUMERO
        tipo = _tipo_valore(risultato)
        if tipo is not None and tipo.nome == "lista" and ts.elementi is not None and op == "+":
            return Tipo("lista", _unisci(ts.elementi, td.elementi) if td.elementi else None)
        if tipo is not None and tipo.nome == "lista" and op == "*":
            return ts if ts.nome == "lista" else td
        return tipo

    def e_Binaria(self, nodo: Any, amb: Ambito) -> Tipo | None:
        ts = self.espressione(nodo.sinistra, amb)
        td = self.espressione(nodo.destra, amb)
        self._amb_corrente = amb
        return self._binaria(nodo.operatore, nodo.sinistra, ts, nodo.destra, td, nodo)

    def e_Unaria(self, nodo: Any, amb: Ambito) -> Tipo | None:
        t = self.espressione(nodo.operando, amb)
        if nodo.operatore == "non":
            if t is not None and t.nome in _CAMPIONI and t.nome != "logico" and not t.opzionale:
                self.condizione(nodo.operando, amb, "non")
            return _LOGICO
        if t is not None and t.opzionale:
            self._non_nulla(nodo.operando, t, amb, "usarlo in un calcolo")
            return None
        if t is not None and t.nome in ("testo", "lista", "dizionario", "logico"):
            from .. import operazioni

            try:
                operazioni.unaria("-", _CAMPIONI[t.nome]) if hasattr(operazioni, "unaria") else None
            except ErroreTipo as e:
                self.segnala(nodo, e.messaggio, codice="tipo", suggerimento=e.suggerimento, lunghezza=1)
            return None
        return t

    def e_Logica(self, nodo: Any, amb: Ambito) -> Tipo | None:
        if nodo.operatore == "oppure":
            ts = self.espressione(nodo.sinistra, amb)
            td = self.espressione(nodo.destra, amb)
            if ts is not None and ts.nome == "logico" and not ts.opzionale:
                return _LOGICO
            if ts is None:
                return None
            return _unisci(ts.senza_nulla, td) if ts.nome != "nulla" else td
        self.condizione(nodo.sinistra, amb, nodo.operatore)
        destra = Ambito(amb, "condizione")
        self._applica(destra, self._restringimenti(nodo.sinistra, nodo.operatore == "e"))
        self.condizione(nodo.destra, destra, nodo.operatore)
        return _LOGICO

    def e_Confronto(self, nodo: Any, amb: Ambito) -> Tipo | None:
        from .. import operazioni

        tipi = [self.espressione(o, amb) for o in nodo.operandi]
        for i, op in enumerate(nodo.operatori):
            sx, dx = nodo.operandi[i], nodo.operandi[i + 1]
            ts, td = tipi[i], tipi[i + 1]
            if ts is None or td is None:
                continue
            numeri = ("intero", "decimale", "numero")
            if op in ("==", "!="):
                if (ts.nome == "testo" and td.nome in numeri) or (td.nome == "testo" and ts.nome in numeri):
                    sempre = "falso" if op == "==" else "vero"
                    testo_sx, testo_dx = _testo_nodo(sx) or "...", _testo_nodo(dx) or "..."
                    self.segnala(nodo, f"Confronti un testo con un numero: `{testo_sx} {op} {testo_dx}` è sempre "
                                       f"{sempre}.", codice="confronto", gravita="avviso", lunghezza=len(op),
                                 suggerimento="Trasforma prima il testo in numero con `numero(...)` (o il numero in "
                                              "testo con `testo(...)`).")
                continue
            for parte, t in ((sx, ts), (dx, td)):
                if t.opzionale and t.nome != "nulla":
                    self._non_nulla(parte, t, amb, "confrontarlo")
            if ts.opzionale or td.opzionale or ts.nome not in _CAMPIONI or td.nome not in _CAMPIONI:
                continue
            try:
                operazioni.confronta(op, self._campione(sx, ts), self._campione(dx, td))
            except ErroreTipo as e:
                self.segnala(nodo, e.messaggio, codice="tipo", suggerimento=e.suggerimento, lunghezza=len(op))
            except Exception:  # noqa: BLE001
                pass
        return _LOGICO

    # --- indici e attributi ------------------------------------------------------------

    def e_Indice(self, nodo: Any, amb: Ambito) -> Tipo | None:
        t = self.espressione(nodo.oggetto, amb)
        ti = self.espressione(nodo.indice, amb)
        if t is None:
            return None
        self._non_nulla(nodo.oggetto, t, amb, "leggerne un elemento")
        # `sequenza[da..a]`: una parte (sotto-sequenza) conserva il tipo della sequenza
        fetta = ti is not None and ti.nome == "intervallo"
        if t.nome == "lista":
            if not fetta and ti is not None and ti.nome in ("testo", "decimale", "logico") and not ti.opzionale:
                self.segnala(nodo.indice, f"Gli indici di una lista sono interi, non {self.descrivi(ti)}.",
                             codice="tipo", lunghezza=max(1, len(_testo_nodo(nodo.indice))))
            return t if fetta else t.elementi
        if t.nome == "testo":
            return _TESTO
        if t.nome == "intervallo":
            return _INTERVALLO if fetta else _INTERO
        if t.nome == "dizionario":
            return t.elementi
        if t.nome in ("intero", "decimale", "logico", "funzione"):
            self.segnala(nodo, f"Non si può usare `[...]` su {self.descrivi(t)}.", codice="tipo",
                         lunghezza=1)
        return None

    def e_Attributo(self, nodo: N.Attributo, amb: Ambito) -> Tipo | None:
        oggetto = nodo.oggetto
        if isinstance(oggetto, N.Nome):
            s = amb.cerca(oggetto.nome)
            if s is not None and s.genere == "modulo" and s.modulo is not None:
                return self._membro_modulo(nodo, s.modulo)
            if s is not None and s.genere == "tipo" and s.famiglia is not None:
                if nodo.nome in s.famiglia.varianti:
                    info = self.strutture.get(nodo.nome)
                    return Tipo(nodo.nome) if info is not None and info.senza_dati else _FUNZIONE
                if nodo.nome != "varianti":
                    self.segnala(nodo, f"Il tipo `{s.famiglia.nome}` non ha la variante `{nodo.nome}`.",
                                 codice="campo", suggerimento="Varianti: " + ", ".join(
                                     f"`{v}`" for v in s.famiglia.varianti) + ".")
                return None
        t = self.espressione(oggetto, amb)
        if t is None:
            return None
        self._non_nulla(oggetto, t, amb, "leggerne un campo")
        info = self.strutture.get(t.nome)
        if info is not None:
            campo = info.campo(nodo.nome)
            if campo is not None:
                return self.tipo_scritto(campo.tipo, campo) if campo.tipo else None
            if self._metodo_struttura(info, nodo.nome) is not None:
                return _FUNZIONE
            self._campo_sconosciuto(nodo, info)
            return None
        if t.nome in ("lista", "testo", "dizionario"):
            from .. import registro

            if registro.trova_metodo(t.nome, nodo.nome) is None:
                self._metodo_sconosciuto(nodo, t.nome)
            return _FUNZIONE
        return None

    def _metodo_struttura(self, info: InfoStruttura, nome: str) -> Firma | None:
        f = info.metodi.get(nome)
        if f is None and info.genitore:
            famiglia = self.famiglie.get(info.genitore)
            if famiglia is not None:
                f = famiglia.metodi.get(nome)
        return f

    def _campo_sconosciuto(self, nodo: N.Attributo, info: InfoStruttura) -> None:
        candidati = [c.nome for c in info.campi] + list(info.metodi)
        simili = difflib.get_close_matches(nodo.nome, candidati, n=1, cutoff=0.6)
        if simili:
            s = simili[0]
            suggerimento = f"Forse intendevi `{s}`" + ("()" if s in info.metodi else "") + "?"
        elif info.campi:
            suggerimento = f"Campi di `{info.nome}`: " + ", ".join(f"`{c.nome}`" for c in info.campi) + "."
        else:
            suggerimento = f"`{info.nome}` non ha campi."
        self.segnala(nodo, f"`{info.nome}` non ha il campo `{nodo.nome}`.", codice="campo", suggerimento=suggerimento)

    def _metodo_sconosciuto(self, nodo: N.Attributo, tipo: str) -> None:
        from ..interprete import _suggerisci_metodo

        suggerimento = _suggerisci_metodo(tipo, nodo.nome)
        if tipo == "dizionario" and suggerimento is None:
            suggerimento = f"Per leggere una chiave del dizionario scrivi `[\"{nodo.nome}\"]`."
        self.segnala(nodo, f"Un valore di tipo `{tipo}` non ha il metodo `{nodo.nome}`.", codice="campo",
                     suggerimento=suggerimento)

    def _membro_modulo(self, nodo: N.Attributo, modulo: InfoModulo) -> Tipo | None:
        s = modulo.simboli.get(nodo.nome)
        if s is not None:
            return s.tipo
        if nodo.nome in modulo.privati:
            self.segnala(nodo, f"`{nodo.nome}` è privato del modulo `{modulo.nome}`: si usa solo dentro quel file.",
                         codice="privato",
                         suggerimento="Nel file del modulo scrivi `pubblica` davanti alla sua dichiarazione."
                         if not nodo.nome.startswith("_") else
                         "I nomi che cominciano con `_` restano dentro il loro file: togli il `_` (e aggiungi "
                         "`pubblica`) se deve essere visibile.")
            return None
        if modulo.libreria:
            return None
        simili = difflib.get_close_matches(nodo.nome, list(modulo.simboli), n=1, cutoff=0.6)
        self.segnala(nodo, f"Il modulo `{modulo.nome}` non contiene `{nodo.nome}`.", codice="nome",
                     suggerimento=f"Forse intendevi `{simili[0]}`?" if simili else None)
        return None

    # --- chiamate ---------------------------------------------------------------------------

    def e_Chiamata(self, nodo: N.Chiamata, amb: Ambito) -> Tipo | None:
        tipi_argomenti = [self.espressione(a.valore, amb) for a in nodo.argomenti]
        self._amb_corrente = amb
        f = nodo.funzione
        if nodo.catena and isinstance(f, N.Nome) and amb.cerca(f.nome) is None:
            return None      # `x |> metodo`: si decide eseguendo
        if isinstance(f, N.Nome):
            s = amb.cerca(f.nome)
            if s is None:
                self._nome_sconosciuto(f, amb)
                return None
            return self._chiama_simbolo(nodo, s, tipi_argomenti, amb)
        if isinstance(f, N.Attributo):
            return self._chiama_metodo(nodo, f, tipi_argomenti, amb)
        self.espressione(f, amb)
        return None

    def _chiama_simbolo(self, nodo: N.Chiamata, s: Simbolo, tipi: list, amb: Ambito) -> Tipo | None:
        if s.firma is not None:
            self._argomenti(nodo, s.firma.nome, s.firma.parametri, tipi)
            self._richiede(nodo, s.firma)
            for errore in s.firma.puo_dare:
                self._puo_dare(errore, nodo, amb, origine=s.firma.nome)
            return s.firma.risultato
        if s.struttura is not None:
            self._costruttore(nodo, s.struttura, tipi)
            return Tipo(s.struttura.nome)
        if s.nativo is not None and s.genere == "predefinito":
            self._argomenti_libreria(nodo, s.nativo)
            nome = getattr(s.nativo, "nome", s.nome)
            risultato = RISULTATI_LIBRERIA.get(nome)
            return leggi_tipo(risultato) if risultato else None
        if s.genere == "predefinito" and s.nome in TIPI_ERRORE:
            return Tipo("errore")
        t = self._tipo_nome(s, amb)
        if t is not None and t.nome in ("intero", "decimale", "testo", "logico", "lista", "dizionario", "nulla") \
                and s.genere in ("variabile", "costante", "parametro", "ciclo"):
            self.segnala(nodo.funzione, f"`{s.nome}` non è una funzione.", codice="tipo",
                         suggerimento=f"È un valore di tipo `{t}`: non si può chiamare con `( )`.")
        return None

    def _argomenti(self, nodo: N.Chiamata, nome: str, parametri: list, tipi: list, *, metodo: bool = False) -> None:
        if any(a.espandi for a in nodo.argomenti):
            return
        variadico = parametri[-1] if parametri and getattr(parametri[-1], "variadico", False) else None
        fissi = parametri[:-1] if variadico is not None else parametri
        nomi = [p.nome for p in fissi]
        posizionali = [(a, t) for a, t in zip(nodo.argomenti, tipi) if a.nome is None]
        per_nome = [(a, t) for a, t in zip(nodo.argomenti, tipi) if a.nome is not None]
        chi = f"Il metodo `{nome}`" if metodo else f"`{nome}`"
        lunghezza = len(nome.split(".")[-1])
        if variadico is None and len(posizionali) > len(fissi):
            obbligatori = sum(1 for p in fissi if p.predefinito is None)
            if not fissi:
                messaggio = f"{chi} non vuole argomenti, ma ne ha ricevuti {len(posizionali)}."
            else:
                if obbligatori == len(fissi):
                    attesi = "1 argomento" if len(fissi) == 1 else f"{len(fissi)} argomenti"
                else:
                    attesi = f"da {obbligatori} a {len(fissi)} argomenti"
                verbo = "vuole" if metodo else "accetta"
                messaggio = f"{chi} {verbo} {attesi}, ma ne ha ricevuti {len(posizionali) + len(per_nome)}."
            self.segnala(nodo, messaggio, codice="argomenti", lunghezza=lunghezza,
                         suggerimento=(f"Parametri di `{nome}`: " + ", ".join(f"`{n}`" for n in nomi) + ".")
                         if nomi else f"`{nome}` non vuole argomenti: chiamala con `{nome}()`.")
            return
        valori: dict[str, Any] = {p.nome: t for p, (a, t) in zip(fissi, posizionali)}
        for a, t in per_nome:
            if a.nome not in nomi:
                simili = difflib.get_close_matches(a.nome, nomi, n=1, cutoff=0.6)
                self.segnala(a, f"`{nome}` non ha un parametro chiamato `{a.nome}`.", codice="argomenti",
                             lunghezza=len(a.nome),
                             suggerimento=f"Forse intendevi `{simili[0]}`?" if simili else
                             (f"Parametri di `{nome}`: " + ", ".join(f"`{n}`" for n in nomi) + ".") if nomi else None)
                continue
            if a.nome in valori:
                self.segnala(a, f"Il parametro `{a.nome}` di `{nome}` ha ricevuto due valori.", codice="argomenti",
                             lunghezza=len(a.nome))
            valori[a.nome] = t
        for p in fissi:
            if p.nome not in valori and p.predefinito is None:
                self.segnala(nodo, f"Manca l'argomento `{p.nome}` nella chiamata di `{nome}`.", codice="argomenti",
                             lunghezza=lunghezza,
                             suggerimento=f"Parametri di `{nome}`: " + ", ".join(f"`{n}`" for n in nomi) + ".")
        argomento_di = {p.nome: a for p, (a, t) in zip(fissi, posizionali)}
        argomento_di.update({a.nome: a for a, t in per_nome})
        for p in fissi:
            if p.tipo and p.nome in valori:
                atteso = self.tipo_scritto(p.tipo, p)
                t = valori[p.nome]
                if atteso is not None and self.compatibile(t, atteso) is False:
                    a = argomento_di.get(p.nome, nodo)
                    if t.opzionale and t.nome != "nulla":
                        if self._dichiarato(a.valore, self._amb_corrente):
                            self._non_nulla(a.valore, t, self._amb_corrente, f"passarlo a `{nome}`")
                        continue
                    self.segnala(a.valore if hasattr(a, "valore") else nodo,
                                 f"Il parametro `{p.nome}` di `{nome}` deve essere di tipo `{atteso}`, ma riceve "
                                 f"{self.descrivi(t)}.", codice="nulla" if t.nome == "nulla" else "tipo",
                                 lunghezza=max(1, len(_testo_nodo(getattr(a, "valore", None)))))
        if variadico is not None and variadico.tipo:
            atteso = self.tipo_scritto(variadico.tipo, variadico)
            for a, t in posizionali[len(fissi):]:
                if atteso is not None and self.compatibile(t, atteso) is False:
                    self.segnala(a.valore, f"Il parametro `{variadico.nome}` di `{nome}` vuole valori `{atteso}`, ma "
                                           f"riceve {self.descrivi(t)}.", codice="tipo",
                                 lunghezza=max(1, len(_testo_nodo(a.valore))))

    def _argomenti_libreria(self, nodo: N.Chiamata, f: Any, *, oggetto: bool = False, chi: str | None = None) -> None:
        from ..registro import _Segnaposto
        from ..valori import FunzioneNativa

        if not isinstance(f, FunzioneNativa) or type(f) is _Segnaposto or any(a.espandi for a in nodo.argomenti):
            return
        try:
            if f.firma is None:
                return
            posizionali = [None] * sum(1 for a in nodo.argomenti if a.nome is None)
            per_nome = {a.nome: None for a in nodo.argomenti if a.nome is not None}
            extra = 1 if f.vuole_interprete else 0
            if oggetto:
                f._controlla_argomenti([None] + posizionali, per_nome, extra, oggetto=True, chi=chi)
            else:
                f._controlla_argomenti(posizionali, per_nome, extra)
        except ErroreTipo as e:
            nome = nodo.funzione.nome if isinstance(nodo.funzione, (N.Nome, N.Attributo)) else ""
            self.segnala(nodo, e.messaggio, codice="argomenti", suggerimento=e.suggerimento,
                         lunghezza=max(1, len(nome)))
        except Exception:  # noqa: BLE001
            return

    def _costruttore(self, nodo: N.Chiamata, info: InfoStruttura, tipi: list) -> None:
        if info.senza_dati:
            self.segnala(nodo, f"`{info.nome}` non ha dati: si scrive senza parentesi.", codice="argomenti",
                         lunghezza=len(info.nome))
            return
        if any(a.espandi for a in nodo.argomenti):
            return
        nomi = [c.nome for c in info.campi]
        posizionali = [(a, t) for a, t in zip(nodo.argomenti, tipi) if a.nome is None]
        per_nome = [(a, t) for a, t in zip(nodo.argomenti, tipi) if a.nome is not None]
        if len(posizionali) > len(info.campi):
            attesi = "nessun valore" if not info.campi else (
                "1 valore" if len(info.campi) == 1 else f"al massimo {len(info.campi)} valori")
            self.segnala(nodo, f"`{info.nome}` vuole {attesi}, ma ne ha ricevuti {len(posizionali)}.",
                         codice="argomenti", lunghezza=len(info.nome),
                         suggerimento=(f"Campi di `{info.nome}`: " + ", ".join(f"`{n}`" for n in nomi) + ".")
                         if nomi else None)
            return
        valori = {c.nome: (a, t) for c, (a, t) in zip(info.campi, posizionali)}
        for a, t in per_nome:
            if a.nome not in nomi:
                simili = difflib.get_close_matches(a.nome, nomi, n=1, cutoff=0.6)
                self.segnala(a, f"`{info.nome}` non ha un campo chiamato `{a.nome}`.", codice="campo",
                             lunghezza=len(a.nome),
                             suggerimento=f"Forse intendevi `{simili[0]}`?" if simili else
                             (f"Campi di `{info.nome}`: " + ", ".join(f"`{n}`" for n in nomi) + ".") if nomi else None)
                continue
            if a.nome in valori:
                self.segnala(a, f"Il campo `{a.nome}` di `{info.nome}` ha ricevuto due valori.", codice="argomenti",
                             lunghezza=len(a.nome))
            valori[a.nome] = (a, t)
        for c in info.campi:
            tc = self.tipo_scritto(c.tipo, c) if c.tipo else None
            if c.nome not in valori:
                if c.predefinito is None and not (tc is not None and tc.accetta_nulla):
                    self.segnala(nodo, f"Manca il campo `{c.nome}` per creare `{info.nome}`.", codice="argomenti",
                                 lunghezza=len(info.nome),
                                 suggerimento=f"Scrivilo così: `{info.nome}({c.nome} = ...)`, oppure dagli un valore "
                                              f"predefinito nella struttura.")
                continue
            a, t = valori[c.nome]
            if tc is not None and self.compatibile(t, tc) is False:
                if t.opzionale and t.nome != "nulla":
                    if self._dichiarato(a.valore, self._amb_corrente):
                        self._non_nulla(a.valore, t, self._amb_corrente, f"darlo al campo `{c.nome}`")
                    continue
                self.segnala(a.valore, f"Il campo `{c.nome}` di `{info.nome}` deve essere `{tc}`, ma riceve "
                                       f"{self.descrivi(t)}.", codice="tipo",
                             lunghezza=max(1, len(_testo_nodo(a.valore))))

    def _chiama_metodo(self, nodo: N.Chiamata, f: N.Attributo, tipi: list, amb: Ambito) -> Tipo | None:
        oggetto = f.oggetto
        if isinstance(oggetto, N.Nome):
            s = amb.cerca(oggetto.nome)
            if s is not None and s.genere == "modulo" and s.modulo is not None:
                membro = s.modulo.simboli.get(f.nome)
                if membro is None:
                    self._membro_modulo(f, s.modulo)
                    return None
                return self._chiama_simbolo(nodo, membro, tipi, amb)
            if s is not None and s.genere == "tipo" and s.famiglia is not None:
                if f.nome in s.famiglia.varianti and f.nome in self.strutture:
                    self._costruttore(nodo, self.strutture[f.nome], tipi)
                    return Tipo(f.nome)
                self.e_Attributo(f, amb)
                return None
        t = self.espressione(oggetto, amb)
        if t is None:
            return None
        self._non_nulla(oggetto, t, amb, "chiamarne un metodo")
        radice = _radice(oggetto)
        if radice is not None and t.nome in METODI_CHE_CAMBIANO and f.nome in METODI_CHE_CAMBIANO[t.nome]:
            s = amb.cerca(radice.nome)
            if s is not None and s.genere == "costante" and s.bloccato:
                self.segnala(f, f"`{s.nome}` è una costante: il suo contenuto non si può cambiare.",
                             codice="costante",
                             suggerimento="Se deve cambiare, dichiarala con `variabile` invece di `costante`; per "
                                          "lavorare su una copia modificabile scrivi `copia(...)`.")
        info = self.strutture.get(t.nome)
        if info is not None:
            firma = self._metodo_struttura(info, f.nome)
            if firma is None:
                if info.campo(f.nome) is None:
                    self._campo_sconosciuto(f, info)
                return None
            self._argomenti(nodo, firma.nome, firma.parametri, tipi, metodo=True)
            self._richiede(nodo, firma)
            for errore in firma.puo_dare:
                self._puo_dare(errore, nodo, amb, origine=firma.nome)
            return firma.risultato
        if t.nome in ("lista", "testo", "dizionario"):
            from .. import registro

            metodo = registro.trova_metodo(t.nome, f.nome)
            if metodo is None:
                self._metodo_sconosciuto(f, t.nome)
                return None
            self._argomenti_libreria(nodo, metodo, oggetto=True)
            risultato = RISULTATI_METODI.get((t.nome, f.nome))
            if risultato == "lista" and t.nome == "dizionario" and f.nome == "valori" and t.elementi is not None:
                return Tipo("lista", t.elementi)
            return leggi_tipo(risultato) if risultato else None
        return None

    # --- contratti --------------------------------------------------------------------------

    def _puo_dare(self, errore: str, nodo: Any, amb: Ambito, *, origine: str) -> None:
        cattura = amb.cattura
        if "*" in cattura or errore in cattura:
            return
        if origine == "lancia":
            firma = amb.funzione
            if firma is None or not firma.puo_dare:
                return
            self.segnala(nodo, f"`{firma.nome}` lancia `{errore}`, ma non lo dichiara in `può dare`.",
                         codice="contratto", gravita="avviso", lunghezza=len("lancia"),
                         suggerimento=f"Aggiungi `{errore}` a `può dare` (o gestiscilo con `prova ... cattura`).")
            return
        dove = amb.funzione
        self.segnala(nodo, f"`{origine}` può dare `{errore}`, ma qui non è gestito.", codice="contratto",
                     gravita="avviso", lunghezza=len(origine.split(".")[-1]),
                     suggerimento=(f"Mettilo dentro `prova ... cattura {errore} ... fine`"
                                   + (f", oppure aggiungi `può dare {errore}` a `{dove.nome}`."
                                      if dove is not None and dove.nodo is not None else ".")))

    def _richiede(self, nodo: N.Chiamata, firma: Firma) -> None:
        """``dividi(1, 0)`` con ``richiede b != 0``: se gli argomenti sono letterali si prova la condizione."""
        if not firma.richiede or any(a.espandi for a in nodo.argomenti):
            return
        valori: dict[str, Any] = {}
        fissi = [p for p in firma.parametri if not getattr(p, "variadico", False)]
        posizionali = [a for a in nodo.argomenti if a.nome is None]
        for p, a in zip(fissi, posizionali):
            if isinstance(a.valore, N.Letterale):
                valori[p.nome] = a.valore.valore
        for a in nodo.argomenti:
            if a.nome is not None and isinstance(a.valore, N.Letterale):
                valori[a.nome] = a.valore.valore
        for p in fissi:
            if p.nome not in valori and isinstance(p.predefinito, N.Letterale) and \
                    not any(a.nome == p.nome for a in nodo.argomenti) and len(posizionali) <= fissi.index(p):
                valori[p.nome] = p.predefinito.valore
        if not valori:
            return
        for condizione in firma.richiede:
            esito = _valuta_semplice(condizione, valori)
            if esito is False:
                testo = self._testo_sorgente(condizione)
                usati = ", ".join(f"{n} = {_mostra(v)}" for n, v in valori.items() if _usa_nome(condizione, n))
                self.segnala(nodo, f"`{firma.nome}` richiede `{testo}`, ma qui non è vero" +
                             (f" ({usati})." if usati else "."), codice="contratto",
                             lunghezza=len(firma.nome.split(".")[-1]),
                             suggerimento="Con questi argomenti la chiamata si fermerebbe con un errore.")

    def _testo_sorgente(self, nodo: Any) -> str:
        riga = getattr(nodo, "riga", 0)
        if 0 < riga <= len(self.righe):
            testo = self.righe[riga - 1].strip()
            for parola in ("richiede ", "garantisce "):
                if testo.startswith(parola):
                    return testo[len(parola):].split(" # ")[0].strip()
        return _testo_nodo(nodo) or "..."


# ---------------------------------------------------------------------------
# Valutazione di condizioni semplici (solo letterali, nomi, operatori)
# ---------------------------------------------------------------------------

class _NonSo(Exception):
    pass


def _valuta_semplice(nodo: Any, valori: dict[str, Any]) -> Any:
    try:
        return _valuta(nodo, valori)
    except _NonSo:
        return None
    except Exception:  # noqa: BLE001
        return None


def _valuta(nodo: Any, valori: dict[str, Any]) -> Any:
    from .. import operazioni

    if isinstance(nodo, N.Letterale):
        return nodo.valore
    if isinstance(nodo, N.Nome):
        if nodo.nome in valori:
            return valori[nodo.nome]
        raise _NonSo
    if isinstance(nodo, N.Binaria):
        return operazioni.binaria(nodo.operatore, _valuta(nodo.sinistra, valori), _valuta(nodo.destra, valori))
    if isinstance(nodo, N.Confronto):
        operandi = [_valuta(o, valori) for o in nodo.operandi]
        return all(operazioni.confronta(op, operandi[i], operandi[i + 1]) for i, op in enumerate(nodo.operatori))
    if isinstance(nodo, N.Logica) and nodo.operatore in ("e", "o"):
        a = _valuta(nodo.sinistra, valori)
        if not isinstance(a, bool):
            raise _NonSo
        if nodo.operatore == "e" and not a:
            return False
        if nodo.operatore == "o" and a:
            return True
        b = _valuta(nodo.destra, valori)
        if not isinstance(b, bool):
            raise _NonSo
        return b
    if isinstance(nodo, N.Unaria):
        v = _valuta(nodo.operando, valori)
        if nodo.operatore == "non":
            if not isinstance(v, bool):
                raise _NonSo
            return not v
        return operazioni.binaria("-", 0, v)
    if isinstance(nodo, N.HaValore):
        v = _valuta(nodo.valore, valori)
        return (v is None) if nodo.negato else (v is not None)
    if isinstance(nodo, N.Chiamata) and isinstance(nodo.funzione, N.Nome) and nodo.funzione.nome == "lunghezza" \
            and len(nodo.argomenti) == 1:
        v = _valuta(nodo.argomenti[0].valore, valori)
        if isinstance(v, (str, list, dict)):
            return len(v)
    raise _NonSo


def _usa_nome(nodo: Any, nome: str) -> bool:
    if isinstance(nodo, N.Nome):
        return nodo.nome == nome
    if isinstance(nodo, list):
        return any(_usa_nome(x, nome) for x in nodo)
    if isinstance(nodo, N.Nodo):
        return any(_usa_nome(v, nome) for v in vars(nodo).values() if isinstance(v, (N.Nodo, list)))
    return False


def _mostra(v: Any) -> str:
    from ..valori import rappresenta

    return rappresenta(v, dentro=True)


# ===========================================================================
# API pubblica
# ===========================================================================

def _nomi_del_progetto(cartella: str | None, nome_file: str) -> set[str]:
    """Finestre e controlli delle maschere vicine, e i nomi esterni degli altri
    file del progetto (eseguiti insieme a questo)."""
    nomi: set[str] = set()
    if not cartella or not os.path.isdir(cartella):
        return nomi
    for maschera in sorted(Path(cartella).glob("*.maschera")):
        nomi.add(maschera.stem)
        try:
            testo = maschera.read_text(encoding="utf-8")
        except OSError:
            continue
        for riga in testo.splitlines():
            riga = riga.strip()
            if riga.startswith("nome") and "=" in riga:
                valore = riga.split("=", 1)[1].strip().strip('"').strip("'")
                if valore.isidentifier():
                    nomi.add(valore)
    if (Path(cartella) / "progetto.toml").is_file():
        from ..esecuzione import analizza

        for altro in sorted(Path(cartella).glob("*.leo")):
            if altro.name == os.path.basename(nome_file):
                continue
            try:
                programma = analizza(altro.read_text(encoding="utf-8-sig"), altro.name)
            except Exception:  # noqa: BLE001 - un altro file rotto: si controllera' da solo
                continue
            for ist in programma.istruzioni:
                nome = getattr(ist, "nome", None)
                if isinstance(nome, str) and "." not in nome and isinstance(
                        ist, (N.Dichiarazione, N.DefinizioneFunzione, N.DefinizioneStruttura, N.DefinizioneTipo)):
                    nomi.add(nome)
                if isinstance(ist, N.DefinizioneTipo):
                    nomi.update(v.nome for v in ist.varianti)
    return nomi


def controlla(sorgente: str, nome_file: str = "<sorgente>", *, cartella: str | os.PathLike | None = None,
              nomi_noti: Iterable[str] = (), opzioni: dict[str, Any] | None = None) -> Rapporto:
    """Controlla ``sorgente`` senza eseguirlo.

    ``cartella``: dove cercare i moduli importati, le maschere e gli altri file
    del progetto (None = solo la cartella corrente). ``nomi_noti``: nomi che
    l'ambiente in cui il programma girerà aggiunge da sé (per esempio i
    controlli di una finestra nel telefono). ``opzioni``: le opzioni del lessico
    (stile e sinonimi del progetto, come per eseguire).
    """
    from ..esecuzione import analizza
    from ..stile import Stile

    opzioni = dict(opzioni or {})
    cartella_s = os.fspath(cartella) if cartella is not None else None
    try:
        programma = analizza(sorgente, nome_file, recupero=True, **opzioni)
    except ErroreSintassi as e:
        d = Diagnostica(e.riga or 1, e.colonna or 1, e.messaggio, "errore", "sintassi", e.suggerimento,
                        max(1, getattr(e, "lunghezza", 1) or 1), nome_file, list(getattr(e, "correzioni", []) or []))
        return Rapporto(nome_file, [d], sorgente)
    stile = Stile.da_sorgente(sorgente, opzioni.get("stile"))
    nomi = set(nomi_noti) | _nomi_del_progetto(cartella_s, nome_file)
    analizzatore = Analizzatore(nome_file, sorgente, cartella=cartella_s, nomi_noti=nomi,
                                dichiarazione_implicita=bool(getattr(stile, "dichiarazione_implicita", False)))
    analizzatore.programma = programma
    try:
        analizzatore.analizza(programma)
    except RecursionError:
        pass       # programma annidatissimo: si tiene quello che si e' trovato fin qui
    except Exception:  # noqa: BLE001 - un controllo in piu' non deve mai impedire di lavorare
        if os.environ.get("LEO_CONTROLLO_RIGOROSO"):
            raise
    diagnostiche = sorted(analizzatore.diagnostiche, key=lambda d: (d.riga, d.colonna, GRAVITA.index(d.gravita)))
    return Rapporto(nome_file, diagnostiche, sorgente)


def controlla_file(percorso: str | os.PathLike, *, nomi_noti: Iterable[str] = ()) -> Rapporto:
    """Controlla un file ``.leo`` (con lo stile e i sinonimi del suo progetto)."""
    from ..esecuzione import opzioni_lessico_file

    percorso = os.fspath(percorso)
    with open(percorso, "r", encoding="utf-8-sig") as f:
        sorgente = f.read()
    try:
        opzioni = opzioni_lessico_file(percorso)
    except Exception:  # noqa: BLE001
        opzioni = {}
    return controlla(sorgente, os.path.basename(percorso), cartella=os.path.dirname(os.path.abspath(percorso)),
                     nomi_noti=nomi_noti, opzioni=opzioni)


def controlla_cartella(cartella: str | os.PathLike) -> list[Rapporto]:
    """Controlla tutti i file ``.leo`` di una cartella (e delle sottocartelle)."""
    from .. import e_sorgente

    rapporti = []
    for radice, cartelle, file in os.walk(cartella):
        cartelle[:] = sorted(c for c in cartelle if not c.startswith(".") and c not in ("__pycache__",))
        for nome in sorted(file):
            if e_sorgente(nome):
                percorso = os.path.join(radice, nome)
                rapporto = controlla_file(percorso)
                relativo = os.path.relpath(percorso, cartella)
                rapporto.file = relativo
                for d in rapporto.diagnostiche:
                    d.file = relativo
                rapporti.append(rapporto)
    return rapporti


def nomi_dei_costrutti(programma: Any) -> set[str]:
    """I nomi che i costrutti dei programmi grandi dichiarano (per chi raccoglie i
    nomi dichiarati senza conoscerli, come l'autocorrezione): strutture, tipi e
    varianti, ``questo`` nei metodi, ``risultato`` in ``garantisce``, i nomi
    presi da ``caso Cerchio(r)``."""
    from dataclasses import fields, is_dataclass

    trovati: set[str] = set()
    pila = [programma]
    while pila:
        n = pila.pop()
        if isinstance(n, (list, tuple)):
            pila.extend(n)
            continue
        if not (is_dataclass(n) and isinstance(n, N.Nodo)):
            continue
        if isinstance(n, N.DefinizioneStruttura):
            trovati.add(n.nome)
            if n.metodi:
                trovati.add("questo")
        elif isinstance(n, N.DefinizioneTipo):
            trovati.add(n.nome)
            trovati.update(v.nome for v in n.varianti)
        elif isinstance(n, N.DefinizioneFunzione):
            if "." in n.nome:
                trovati.add("questo")
            if n.garantisce:
                trovati.add("risultato")
        elif isinstance(n, N.Caso):
            for schema in n.schemi:
                if isinstance(schema, N.Chiamata):
                    trovati.update(a.valore.nome for a in schema.argomenti if isinstance(a.valore, N.Nome))
        for f in fields(n):
            valore = getattr(n, f.name)
            if isinstance(valore, (N.Nodo, list, tuple)):
                pila.append(valore)
    return trovati
