"""``leo controlla file.leo|cartella [--json] [--rigoroso]``: controlli prima di eseguire."""

from __future__ import annotations

import argparse
import json
import os
import sys

__all__ = ["principale"]

DESCRIZIONE = ("Controlla un programma PRIMA di eseguirlo: nomi inesistenti, argomenti sbagliati, tipi, valori "
               "che possono essere `nulla`, campi delle strutture, casi mancanti in `scegli`, codice "
               "irraggiungibile, costanti cambiate, nomi privati dei moduli, contratti. Il programma non viene "
               "eseguito.")


def _analizzatore(classe: type = argparse.ArgumentParser) -> argparse.ArgumentParser:
    p = classe(prog="leo controlla", description=DESCRIZIONE)
    p.add_argument("percorso", help="file .leo o cartella")
    p.add_argument("--json", action="store_true", help="risultato in JSON (per editor e strumenti)")
    p.add_argument("--rigoroso", action="store_true", help="anche gli avvisi fanno fallire il controllo")
    p.add_argument("--senza-avvisi", action="store_true", help="mostra solo gli errori")
    return p


def principale(argomenti: list[str] | None = None, classe: type = argparse.ArgumentParser) -> int:
    """Codice di uscita: 0 tutto bene, 1 errori (o avvisi con --rigoroso), 2 file non trovato.

    ``classe``: il parser degli argomenti (``leo`` passa il suo, che parla italiano)."""
    args = _analizzatore(classe).parse_args(argomenti)
    from . import controlla_cartella, controlla_file

    percorso = args.percorso
    if os.path.isdir(percorso):
        rapporti = controlla_cartella(percorso)
        if not rapporti:
            print(f"leo controlla: in `{percorso}` non ci sono file .leo.", file=sys.stderr)
            return 2
    elif os.path.isfile(percorso):
        rapporti = [controlla_file(percorso)]
    else:
        print(f"leo controlla: non trovo `{percorso}`.", file=sys.stderr)
        return 2
    if args.senza_avvisi:
        for r in rapporti:
            r.diagnostiche = [d for d in r.diagnostiche if d.gravita == "errore"]
    errori = sum(len(r.errori) for r in rapporti)
    avvisi = sum(len(r.avvisi) for r in rapporti)
    if args.json:
        print(json.dumps({"ok": errori == 0, "errori": errori, "avvisi": avvisi,
                          "file": [r.come_dizionario() for r in rapporti]}, ensure_ascii=False, indent=2))
    else:
        try:
            from ..cli import usa_colori

            colori = usa_colori(sys.stdout)
        except Exception:  # noqa: BLE001
            colori = False
        for r in rapporti:
            if r.diagnostiche:
                print(r.testo(colori=colori))
        print(_riassunto(errori, avvisi, len(rapporti)))
    if errori or (args.rigoroso and avvisi):
        return 1
    return 0


def _riassunto(errori: int, avvisi: int, file: int) -> str:
    quanti_file = "1 file" if file == 1 else f"{file} file"
    if not errori and not avvisi:
        return f"Tutto in ordine: nessun problema in {quanti_file}."
    parti = []
    if errori:
        parti.append("1 errore" if errori == 1 else f"{errori} errori")
    if avvisi:
        parti.append("1 avviso" if avvisi == 1 else f"{avvisi} avvisi")
    return " e ".join(parti) + f" in {quanti_file}."
