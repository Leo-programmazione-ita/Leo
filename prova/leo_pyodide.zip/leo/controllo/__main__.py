"""``python -m leo.controllo file.leo``: come ``leo controlla``."""

import sys

from .cli import principale

sys.exit(principale(sys.argv[1:]))
