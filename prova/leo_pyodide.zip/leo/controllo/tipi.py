"""Tipi scritti nei programmi Leo: ``intero``, ``testo?``, ``lista di decimale``...

Un tipo si scrive dopo i due punti (``variabile x: intero = 0``,
``funzione area(b: decimale)``) o dopo ``dà`` (``funzione area(...) dà decimale``).
Nell'albero sintattico resta un testo canonico; :func:`leggi_tipo` lo
trasforma in un :class:`Tipo`, usato sia dall'esecuzione (controlli mentre il
programma gira) sia da ``leo controlla`` (controlli prima di eseguire).

Grammatica::

    tipo  := base ["?"]
    base  := NOME | "lista" ["di" tipo] | "dizionario" ["di" tipo] | "(" tipo ")"

``?`` vuol dire "oppure nulla" e vale per il tipo più vicino:
``lista di intero?`` è una lista di interi o nulla; una lista che può mancare
si scrive ``(lista di intero)?``.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

__all__ = ["Tipo", "leggi_tipo", "conforme", "TIPI_BASE", "QUALSIASI", "NULLA", "descrivi_valore",
           "spiega_differenza", "compatibile"]

#: Tipi che Leo conosce da sé (oltre a quelli della libreria come ``data`` e
#: a quelli del programma: strutture e tipi a varianti).
TIPI_BASE: dict[str, str] = {
    "intero": "un numero senza virgola",
    "decimale": "un numero con la virgola (va bene anche un intero)",
    "numero": "un intero o un decimale",
    "testo": "un testo tra virgolette",
    "logico": "vero o falso",
    "lista": "una lista",
    "dizionario": "un dizionario",
    "funzione": "una funzione",
    "intervallo": "un intervallo come 1..10",
    "qualsiasi": "qualunque valore",
    "nulla": "solo il valore nulla",
}

#: Tipi che accettano un tipo degli elementi con ``di``.
CONTENITORI = ("lista", "dizionario")


@dataclass(frozen=True)
class Tipo:
    """Un tipo Leo. ``elementi`` per ``lista di T``/``dizionario di T``;
    ``opzionale`` per ``T?`` (accetta anche ``nulla``)."""

    nome: str
    elementi: "Tipo | None" = None
    opzionale: bool = False

    def __str__(self) -> str:
        base = self.nome if self.elementi is None else f"{self.nome} di {self.elementi}"
        if self.opzionale and self.nome not in ("nulla", "qualsiasi"):
            return f"({base})?" if self.elementi is not None else base + "?"
        return base

    @property
    def senza_nulla(self) -> "Tipo":
        """Lo stesso tipo senza ``?`` (dopo ``se x ha valore``)."""
        return Tipo(self.nome, self.elementi, False) if self.opzionale else self

    @property
    def con_nulla(self) -> "Tipo":
        return self if self.opzionale else Tipo(self.nome, self.elementi, True)

    @property
    def accetta_nulla(self) -> bool:
        return self.opzionale or self.nome in ("nulla", "qualsiasi")


QUALSIASI = Tipo("qualsiasi")
NULLA = Tipo("nulla")

_PEZZI = re.compile(r"\s*(\(|\)|\?|[^\s()?]+)")


def leggi_tipo(testo: str) -> Tipo:
    """``"lista di intero?"`` -> ``Tipo("lista", Tipo("intero", opzionale=True))``.

    ValueError (messaggio in italiano) se il testo non è un tipo scritto bene.
    """
    pezzi = [m.group(1) for m in _PEZZI.finditer(testo or "")]
    if not pezzi:
        raise ValueError("Manca il tipo.")
    posizione = [0]

    def guarda() -> str | None:
        return pezzi[posizione[0]] if posizione[0] < len(pezzi) else None

    def prendi() -> str:
        p = guarda()
        if p is None:
            raise ValueError(f"Il tipo `{testo}` è incompleto.")
        posizione[0] += 1
        return p

    def tipo() -> Tipo:
        p = prendi()
        if p == "(":
            interno = tipo()
            if prendi() != ")":
                raise ValueError(f"Nel tipo `{testo}` manca la `)`.")
            risultato = interno
        elif p in (")", "?"):
            raise ValueError(f"Il tipo `{testo}` non è scritto bene.")
        else:
            elementi = None
            if p in CONTENITORI and guarda() == "di":
                prendi()
                elementi = tipo()
            risultato = Tipo(p, elementi)
        if guarda() == "?":
            prendi()
            risultato = Tipo(risultato.nome, risultato.elementi, True)
        return risultato

    risultato = tipo()
    if guarda() is not None:
        raise ValueError(f"Il tipo `{testo}` non è scritto bene: non capisco `{guarda()}`.")
    return risultato


def _cache_leggi():
    memoria: dict[str, Tipo] = {}

    def leggi(testo: str | Tipo) -> Tipo:
        if isinstance(testo, Tipo):
            return testo
        t = memoria.get(testo)
        if t is None:
            t = memoria[testo] = leggi_tipo(testo)
        return t
    return leggi


tipo_da_testo = _cache_leggi()


def descrivi_valore(valore: Any) -> str:
    from ..valori import nome_tipo

    return nome_tipo(valore)


def _nomi_struttura(valore: Any) -> tuple[str, ...]:
    """Nomi di tipo di un valore di una struttura o di una variante (``Cerchio``, ``Forma``)."""
    tipo = getattr(valore, "tipo_struttura", None)
    if tipo is None:
        return ()
    nomi = [tipo.nome]
    if tipo.genitore is not None:
        nomi.append(tipo.genitore)
    return tuple(nomi)


def conforme(valore: Any, tipo: Tipo | str) -> bool:
    """Vero se ``valore`` è del tipo ``tipo`` (con gli elementi, per le liste)."""
    tipo = tipo_da_testo(tipo)
    nome = tipo.nome
    if valore is None:
        return tipo.accetta_nulla
    if nome == "qualsiasi":
        return True
    t = type(valore)
    if nome == "intero":
        return (t is int) or (isinstance(valore, int) and not isinstance(valore, bool))
    if nome == "decimale" or nome == "numero":
        return t is float or t is int or (isinstance(valore, (int, float)) and not isinstance(valore, bool))
    if nome == "testo":
        return isinstance(valore, str)
    if nome == "logico":
        return isinstance(valore, bool)
    if nome == "lista":
        if not isinstance(valore, list):
            return False
        el = tipo.elementi
        return el is None or el.nome == "qualsiasi" or all(conforme(x, el) for x in valore)
    if nome == "dizionario":
        if not isinstance(valore, dict):
            return False
        el = tipo.elementi
        return el is None or el.nome == "qualsiasi" or all(conforme(x, el) for x in valore.values())
    if nome == "nulla":
        return False
    nomi = _nomi_struttura(valore)
    if nomi:
        return nome in nomi
    from ..valori import nome_tipo

    return nome_tipo(valore) == nome


def spiega_differenza(valore: Any, tipo: Tipo | str) -> str:
    """Che cosa c'è di diverso: ``un `testo```, ``una `lista` con un elemento `testo` ("ciao")``."""
    from ..valori import rappresenta, tipo_con_articolo

    tipo = tipo_da_testo(tipo)
    if tipo.elementi is not None and isinstance(valore, (list, dict)):
        elementi = valore if isinstance(valore, list) else list(valore.values())
        for x in elementi:
            if not conforme(x, tipo.elementi):
                contenitore = "una `lista`" if isinstance(valore, list) else "un `dizionario`"
                return (f"{contenitore} con un elemento che è {tipo_con_articolo(x)} "
                        f"({rappresenta(x, dentro=True)})")
    return tipo_con_articolo(valore)


def compatibile(da: Tipo, verso: Tipo) -> bool | None:
    """Tra tipi (controllo prima di eseguire): un valore di tipo ``da`` va bene
    dove serve ``verso``? None = non si può sapere (per esempio ``qualsiasi``)."""
    if verso.nome == "qualsiasi" or da.nome == "qualsiasi":
        return None if da.nome == "qualsiasi" else True
    if da.nome == "nulla":
        return verso.accetta_nulla
    if da.opzionale and not verso.accetta_nulla:
        return False
    if da.nome == verso.nome:
        if verso.elementi is None or da.elementi is None:
            return True
        risultato = compatibile(da.elementi, verso.elementi)
        return risultato
    if verso.nome in ("decimale", "numero") and da.nome in ("intero", "decimale", "numero"):
        return True if (da.nome != "numero" or verso.nome == "numero") else None
    if da.nome == "numero" and verso.nome == "intero":
        return None
    return False
