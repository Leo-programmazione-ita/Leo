"""Riconoscimento nel parser dei costrutti per i programmi grandi.

:class:`SintassiTipi` è mescolata in :class:`leo.parser.Parser`. Tutte le
parole nuove sono *parole di contesto*: valgono solo all'inizio di
un'istruzione e nella forma giusta, altrove restano nomi qualunque (così i
programmi esistenti che usano ``tipo``, ``struttura`` o ``pubblica`` come nomi
di variabile non cambiano):

* ``struttura Alunno`` ... ``fine`` (campi ``nome: tipo = predefinito`` e funzioni);
* ``tipo Forma è uno di`` ... ``fine`` oppure ``tipo Colore è uno di Rosso, Verde``;
* ``pubblica`` davanti a ``variabile``/``costante``/``funzione``/``struttura``/``tipo``;
* in cima al corpo di una funzione: ``richiede``, ``garantisce``, ``può dare``;
* dopo i parametri: ``dà tipo`` (tipo del risultato);
* nelle espressioni: ``x ha valore``, ``x non ha valore``, ``x oppure y``;
* i tipi: ``intero``, ``testo?``, ``lista di decimale``, ``(lista di intero)?``.
"""

from __future__ import annotations

from typing import Any

from ..errori import ErroreSintassi
from ..nodi import Campo, DefinizioneFunzione, DefinizioneStruttura, DefinizioneTipo, HaValore, Istruzione, Variante
from ..tokens import TIPI_ASSEGNAZIONE, TIPI_PAROLA_CHIAVE, TipoToken

T = TipoToken

__all__ = ["SintassiTipi", "PAROLE_DI_CONTESTO_TIPI", "PAROLE_CONTRATTO", "PAROLE_RISULTATO"]

#: Parole di contesto nuove (restano NOME per il lexer).
PAROLE_DI_CONTESTO_TIPI = frozenset({"struttura", "classe", "tipo", "pubblica", "richiede", "garantisce",
                                     "può", "puo", "oppure", "ha"})
PAROLE_CONTRATTO = ("richiede", "garantisce")
#: Parole dopo i parametri che introducono il tipo del risultato.
PAROLE_RISULTATO = ("dà", "da")

_FINE = (T.FINE_RIGA, T.FINE_FILE)
#: Token dopo i quali la parola NON e' una parola di contesto (`richiede = 3`, `tipo(x)`, `tipo.x`).
_NON_CONTESTO = frozenset({T.ASSEGNA, T.PARENTESI_APERTA, T.PUNTO, T.QUADRA_APERTA, T.VIRGOLA,
                           T.FINE_RIGA, T.FINE_FILE, T.CATENA}) | frozenset(TIPI_ASSEGNAZIONE)

_ESEMPIO_STRUTTURA = ("Per esempio:\n  struttura Alunno\n      nome: testo\n      voti: lista di intero = []\n"
                      "  fine")
_ESEMPIO_CLASSE = ("Per esempio:\n  classe Persona\n      ha nome\n      ha eta = 0\n      azione saluta()\n"
                   "          scrivi \"Ciao, sono \" + questo.nome\n      fine\n  fine")
_ESEMPIO_TIPO = ("Per esempio:\n  tipo Forma è uno di\n      Cerchio(raggio: decimale)\n"
                 "      Rettangolo(base: decimale, altezza: decimale)\n  fine")


class SintassiTipi:
    """Metodi del parser per tipi, strutture, varianti, visibilità e contratti."""

    # --- istruzioni -------------------------------------------------------------------

    def _istruzione_tipi(self, t: Any) -> Istruzione | None:
        """Chiamato per un NOME all'inizio di un'istruzione: il costrutto nuovo
        che comincia qui, oppure None (la parola resta un nome)."""
        parola = t.valore
        if parola not in PAROLE_DI_CONTESTO_TIPI:
            return None
        succ = self._guarda()
        if succ.riga != t.riga or succ.tipo in _NON_CONTESTO:
            return None
        if parola == "struttura" and succ.tipo is T.NOME and self._guarda(2).tipo in _FINE:
            return self._struttura()
        if parola == "classe" and succ.tipo is T.NOME and (
                self._guarda(2).tipo in _FINE
                or (self._guarda(2).tipo is T.NOME and self._guarda(2).valore == "estende")):
            return self._classe()
        if parola == "tipo" and succ.tipo is T.NOME and self._e_tipo_varianti():
            return self._tipo_varianti()
        if parola == "pubblica" and (succ.tipo in (T.VARIABILE, T.COSTANTE, T.FUNZIONE)
                                     or (succ.tipo is T.NOME and succ.valore in ("struttura", "tipo"))):
            return self._pubblica(t)
        if parola in PAROLE_CONTRATTO or (parola in ("può", "puo") and succ.tipo is T.NOME
                                          and succ.valore == "dare"):
            forma = "può dare" if parola in ("può", "puo") else parola
            raise self._errore(
                f"`{forma}` si scrive in cima a una funzione, subito dopo la riga `funzione ...`.", t,
                "Per esempio:\n  funzione dividi(a, b)\n      richiede b != 0\n      restituisci a / b\n  fine")
        return None

    def _e_tipo_varianti(self) -> bool:
        """``tipo NOME è uno di`` (o ``è una di``)?"""
        g = self._guarda
        return (g(2).tipo is T.E_ACCENTATA and g(3).tipo is T.NOME and g(3).valore in ("uno", "una")
                and g(4).tipo is T.NOME and g(4).valore == "di")

    def _pubblica(self, t: Any) -> Istruzione:
        if self._aperti:
            raise self._errore("`pubblica` si usa solo fuori da ogni blocco, al livello più esterno del file.", t,
                               "Sposta la dichiarazione fuori dal blocco (e fuori da `inizio ... fine`).")
        self._avanza()
        istruzione = self._istruzione_semplice()
        nomi = getattr(istruzione, "nomi", None) or [getattr(istruzione, "nome", None)]
        if isinstance(istruzione, DefinizioneTipo):
            nomi = [istruzione.nome] + [v.nome for v in istruzione.varianti]
        pubblici = self.__dict__.setdefault("_pubblici", [])
        for nome in nomi:
            if nome:
                if nome.startswith("_"):
                    raise self._errore(f"`{nome}` comincia con `_`, quindi è privato: non può essere `pubblica`.",
                                       t, "Togli il `_` dal nome oppure togli `pubblica`.")
                if "." in nome:
                    raise self._errore("Un metodo è pubblico quando è pubblica la sua struttura: togli `pubblica`.", t)
                pubblici.append(nome)
        return istruzione

    # --- struttura ------------------------------------------------------------------------

    def _nome_dopo(self, parola: str, esempio: str) -> Any:
        n = self._cor
        if n.tipo is not T.NOME:
            errore = self._riservata(n, f"il nome dopo `{parola}`")
            errore.suggerimento = errore.suggerimento or esempio
            raise errore
        return self._avanza()

    def _struttura(self) -> DefinizioneStruttura:
        t = self._avanza()
        nome_tok = self._nome_dopo("struttura", _ESEMPIO_STRUTTURA)
        nome = str(nome_tok.valore)
        blocco = self._apri("struttura", t)
        campi: list[Campo] = []
        metodi: list[DefinizioneFunzione] = []
        visti: set[str] = set()
        while True:
            self._salta_righe()
            c = self._cor
            if c.tipo is T.FINE:
                break
            if c.tipo is T.FINE_FILE:
                raise self._mai_chiuso(blocco)
            if c.tipo is T.FUNZIONE and self._guarda().tipo is T.NOME:
                metodo = self._definizione_funzione()
                if "." in metodo.nome:
                    raise self._errore("Dentro `struttura` scrivi il metodo senza il nome della struttura: "
                                       f"`funzione {metodo.nome.split('.', 1)[1]}(...)`.", c)
                if metodo.nome in visti:
                    raise self._errore(f"`{metodo.nome}` è già un campo o un metodo di `{nome}`.", c)
                visti.add(metodo.nome)
                metodi.append(metodo)
                self._fine_istruzione()
                continue
            campo = self._campo(nome, obbligo_tipo_o_valore=True)
            if campo.nome in visti:
                raise self._errore(f"Il campo `{campo.nome}` compare due volte in `{nome}`.", c,
                                   "Ogni campo deve avere un nome diverso.")
            visti.add(campo.nome)
            campi.append(campo)
            self._fine_istruzione()
        self._chiudi(blocco)
        self._etichetta_parola("struttura")
        return DefinizioneStruttura(nome, campi, metodi, riga=t.riga, colonna=t.colonna)

    def _etichetta_parola(self, parola: str) -> None:
        """``fine struttura`` / ``fine tipo`` / ``fine classe`` / ``fine azione``:
        l'etichetta facoltativa dopo ``fine``."""
        e = self._cor
        prec = self._precedente()
        if e.tipo is T.NOME and e.valore == parola and prec is not None and prec.riga == e.riga:
            self._avanza()

    # --- classe (zucchero amichevole sopra `struttura`) -------------------------------
    #
    # `classe Persona` ... `fine` e' una forma piu' naturale di `struttura`: i campi si
    # scrivono con `ha nome` (anche `ha eta: intero` o `ha eta = 0`) e i metodi con
    # `azione saluta(...)` ... `fine`. Dentro un metodo il valore prima del punto e'
    # `questo` (come in ogni metodo di struttura). La creazione e' `Persona("Ada", 30)`
    # oppure, in forma discorsiva, `nuovo Persona("Ada", 30)`. Produce esattamente un
    # :class:`DefinizioneStruttura`, quindi interprete, compilatore e strumenti la
    # gestiscono gia' senza codice in piu'.

    def _classe(self) -> DefinizioneStruttura:
        t = self._avanza()
        nome_tok = self._nome_dopo("classe", _ESEMPIO_CLASSE)
        nome = str(nome_tok.valore)
        base = self._estende(nome)
        genitore_prec = getattr(self, "_classe_genitore", None)
        self._classe_genitore = base       # `genitore` nelle azioni vale solo se c'è un `estende`
        blocco = self._apri("classe", t)
        campi: list[Campo] = []
        metodi: list[DefinizioneFunzione] = []
        visti: set[str] = set()
        while True:
            self._salta_righe()
            c = self._cor
            if c.tipo is T.FINE:
                break
            if c.tipo is T.FINE_FILE:
                raise self._mai_chiuso(blocco)
            # `azione saluta()` (coi sinonimi attivi `azione` diventa il token
            # `funzione`) oppure `funzione saluta()`: un metodo della classe.
            if c.tipo is T.FUNZIONE and self._guarda().tipo is T.NOME:
                metodo = self._definizione_funzione()
                if "." in metodo.nome:
                    raise self._errore("Dentro `classe` l'azione si scrive senza il nome della classe: "
                                       f"`azione {metodo.nome.split('.', 1)[1]}(...)`.", c)
                if metodo.nome in visti:
                    raise self._errore(f"`{metodo.nome}` è già un campo o un'azione di `{nome}`.", c,
                                       "Ogni campo e ogni azione deve avere un nome diverso.")
                visti.add(metodo.nome)
                metodi.append(metodo)
                self._fine_istruzione()
                continue
            # `azione` come nome (modalità rigorosa: i sinonimi sono spenti).
            if c.tipo is T.NOME and c.valore == "azione" and self._guarda().riga == c.riga \
                    and self._guarda().tipo is T.NOME:
                metodo = self._metodo_azione(nome)
                if metodo.nome in visti:
                    raise self._errore(f"`{metodo.nome}` è già un campo o un'azione di `{nome}`.", c,
                                       "Ogni campo e ogni azione deve avere un nome diverso.")
                visti.add(metodo.nome)
                metodi.append(metodo)
                self._fine_istruzione()
                continue
            if c.tipo is T.NOME and c.valore == "ha" and self._guarda().riga == c.riga:
                campo = self._campo_ha(nome)
                if campo.nome in visti:
                    raise self._errore(f"Il campo `{campo.nome}` compare due volte in `{nome}`.", c,
                                       "Ogni campo deve avere un nome diverso.")
                visti.add(campo.nome)
                campi.append(campo)
                self._fine_istruzione()
                continue
            raise self._errore(
                f"Dentro `classe {nome}` ci vanno campi (`ha nome`) e azioni (`azione saluta()`).",
                c, _ESEMPIO_CLASSE)
        self._chiudi(blocco)
        self._classe_genitore = genitore_prec
        self._etichetta_parola("classe")
        return DefinizioneStruttura(nome, campi, metodi, base=base, riga=t.riga, colonna=t.colonna)

    def _estende(self, classe: str) -> str | None:
        """``estende Persona`` dopo il nome della classe: il nome del genitore (o None)."""
        c = self._cor
        if not (c.tipo is T.NOME and c.valore == "estende" and c.riga == self._precedente().riga):
            return None
        self._avanza()           # `estende`
        g = self._cor
        if g.tipo is not T.NOME:
            errore = self._riservata(g, f"il nome della classe genitore dopo `estende`")
            errore.suggerimento = errore.suggerimento or (
                f"Per esempio `classe {classe} estende Persona`.")
            raise errore
        self._avanza()
        if str(g.valore) == classe:
            raise self._errore(f"Una classe non può estendere se stessa: `{classe}` estende `{classe}`.", g)
        return str(g.valore)

    def _campo_ha(self, classe: str) -> Campo:
        """``ha nome`` (campo obbligatorio), ``ha eta: intero``, ``ha eta = 0``."""
        self._avanza()           # `ha`
        c = self._cor
        if c.tipo is not T.NOME:
            errore = self._riservata(c, f"il nome di un campo di `{classe}` dopo `ha`")
            errore.suggerimento = errore.suggerimento or _ESEMPIO_CLASSE
            raise errore
        self._avanza()
        nome = str(c.valore)
        tipo = None
        predefinito = None
        if self._cor.tipo is T.DUE_PUNTI:
            self._avanza()
            tipo = self._tipo_scritto(f"il tipo del campo `{nome}`")
        if self._cor.tipo is T.ASSEGNA:
            self._avanza()
            if self._cor.tipo in _FINE:
                raise self._errore(f"Manca il valore predefinito di `{nome}` dopo `=`.", self._cor)
            predefinito = self._espressione()
        return Campo(nome, tipo, predefinito, riga=c.riga, colonna=c.colonna)

    def _metodo_azione(self, classe: str) -> DefinizioneFunzione:
        """``azione saluta(parametri) [dà tipo]`` ... ``fine``: come un metodo di
        struttura (il valore prima del punto e' sempre `questo`)."""
        t = self._avanza()       # `azione`
        nome_tok = self._cor
        if nome_tok.tipo is not T.NOME:
            errore = self._riservata(nome_tok, "il nome dell'azione dopo `azione`")
            errore.suggerimento = errore.suggerimento or "Per esempio `azione saluta(nome)`."
            raise errore
        self._avanza()
        if self._cor.tipo is T.PUNTO:
            raise self._errore(f"Dentro `classe {classe}` l'azione si scrive senza il nome della classe: "
                               f"`azione {nome_tok.valore}(...)`.", self._cor)
        nome = str(nome_tok.valore)
        parametri = self._parametri()
        tipo_risultato = self._tipo_risultato(t)
        blocco = self._apri("azione", t)
        richiede, garantisce, puo_dare = self._contratti()
        corpo = self._corpo_funzione(blocco)
        self._chiudi(blocco)
        self._etichetta_parola("azione")
        return DefinizioneFunzione(nome, parametri, corpo, tipo_risultato=tipo_risultato, richiede=richiede,
                                   garantisce=garantisce, puo_dare=puo_dare, riga=t.riga, colonna=t.colonna)

    def _campo(self, struttura: str, *, obbligo_tipo_o_valore: bool) -> Campo:
        c = self._cor
        if c.tipo is not T.NOME:
            if c.tipo in (T.VARIABILE, T.COSTANTE):
                raise self._errore(
                    f"Dentro `struttura` i campi si scrivono senza `{c.tipo.value}`: `nome: testo` "
                    "oppure `nome = \"\"`.", c, _ESEMPIO_STRUTTURA)
            errore = self._riservata(c, f"il nome di un campo di `{struttura}`")
            errore.suggerimento = errore.suggerimento or _ESEMPIO_STRUTTURA
            raise errore
        self._avanza()
        nome = str(c.valore)
        tipo = None
        predefinito = None
        if self._cor.tipo is T.DUE_PUNTI:
            self._avanza()
            tipo = self._tipo_scritto(f"il tipo del campo `{nome}`")
        if self._cor.tipo is T.ASSEGNA:
            self._avanza()
            if self._cor.tipo in _FINE:
                raise self._errore(f"Manca il valore predefinito di `{nome}` dopo `=`.", self._cor)
            predefinito = self._espressione()
        if obbligo_tipo_o_valore and tipo is None and predefinito is None:
            raise self._errore(
                f"Il campo `{nome}` di `{struttura}` ha bisogno di un tipo (`{nome}: testo`) o di un valore "
                f"predefinito (`{nome} = 0`).", c, _ESEMPIO_STRUTTURA)
        return Campo(nome, tipo, predefinito, riga=c.riga, colonna=c.colonna)

    # --- tipo a varianti ---------------------------------------------------------------------

    def _tipo_varianti(self) -> DefinizioneTipo:
        t = self._avanza()
        nome_tok = self._avanza()
        for _ in range(3):           # è uno di
            self._avanza()
        varianti: list[Variante] = []
        visti: set[str] = set()

        def aggiungi(v: Variante, tok: Any) -> None:
            if v.nome in visti or v.nome == nome_tok.valore:
                raise self._errore(f"La variante `{v.nome}` compare due volte (o ha il nome del tipo).", tok)
            visti.add(v.nome)
            varianti.append(v)

        if self._cor.tipo not in _FINE:      # tutto su una riga: `tipo Colore è uno di Rosso, Verde`
            while True:
                tok = self._cor
                aggiungi(self._variante(), tok)
                if self._cor.tipo is T.VIRGOLA:
                    self._avanza()
                    continue
                break
            if len(varianti) < 2:
                raise self._errore(f"Un tipo a varianti ne ha almeno due: `{nome_tok.valore}` ne ha una.", t,
                                   _ESEMPIO_TIPO)
            return DefinizioneTipo(str(nome_tok.valore), varianti, riga=t.riga, colonna=t.colonna)
        blocco = self._apri("tipo", t)
        while True:
            self._salta_righe()
            c = self._cor
            if c.tipo is T.FINE:
                break
            if c.tipo is T.FINE_FILE:
                raise self._mai_chiuso(blocco)
            while True:
                tok = self._cor
                aggiungi(self._variante(), tok)
                if self._cor.tipo is T.VIRGOLA:
                    self._avanza()
                    continue
                break
            self._fine_istruzione()
        if len(varianti) < 2:
            raise self._errore(f"Un tipo a varianti ne ha almeno due: `{nome_tok.valore}` ne ha "
                               f"{'una' if varianti else 'nessuna'}.", t, _ESEMPIO_TIPO)
        self._chiudi(blocco)
        self._etichetta_parola("tipo")
        return DefinizioneTipo(str(nome_tok.valore), varianti, riga=t.riga, colonna=t.colonna)

    def _variante(self) -> Variante:
        v = self._cor
        if v.tipo is not T.NOME:
            errore = self._riservata(v, "il nome di una variante")
            errore.suggerimento = errore.suggerimento or _ESEMPIO_TIPO
            raise errore
        self._avanza()
        campi = None
        if self._cor.tipo is T.PARENTESI_APERTA:
            apre = self._avanza()
            campi = []
            visti: set[str] = set()
            while self._cor.tipo is not T.PARENTESI_CHIUSA:
                tok = self._cor
                campo = self._campo(str(v.valore), obbligo_tipo_o_valore=False)
                if campo.nome in visti:
                    raise self._errore(f"Il campo `{campo.nome}` compare due volte in `{v.valore}`.", tok)
                visti.add(campo.nome)
                campi.append(campo)
                if self._cor.tipo is T.VIRGOLA:
                    self._avanza()
                    continue
                if self._cor.tipo is not T.PARENTESI_CHIUSA:
                    raise self._separatore_mancante(apre, "tra i campi")
            self._avanza()
        return Variante(str(v.valore), campi, riga=v.riga, colonna=v.colonna)

    # --- tipi scritti -----------------------------------------------------------------------

    def _tipo_scritto(self, cosa: str) -> str:
        """Legge un tipo (``intero``, ``testo?``, ``lista di intero``) e ne dà il testo canonico."""
        t = self._cor
        if t.tipo is T.PARENTESI_APERTA:
            self._avanza()
            interno = self._tipo_scritto(cosa)
            if self._cor.tipo is not T.PARENTESI_CHIUSA:
                raise self._inatteso("`)` alla fine del tipo", self._cor)
            self._avanza()
            testo = f"({interno})"
            if self._cor.tipo is T.PUNTO_INTERROGATIVO:
                self._avanza()
                return testo + "?"
            return interno
        if t.tipo is T.NOME or (t.tipo in TIPI_PAROLA_CHIAVE and str(t.valore).isidentifier()):
            self._avanza()
            nome = str(t.valore)
        else:
            raise self._inatteso(cosa, t, "Per esempio `intero`, `decimale`, `testo`, `logico`, `lista di intero`, "
                                          "`testo?` (testo oppure nulla) o il nome di una struttura.")
        testo = nome
        if nome in ("lista", "dizionario") and self._cor.tipo is T.NOME and self._cor.valore == "di" \
                and self._cor.riga == t.riga:
            self._avanza()
            interno = self._tipo_scritto(f"il tipo degli elementi dopo `{nome} di`")
            testo = f"{nome} di {interno}"
            return testo     # il `?` finale e' gia' stato letto dall'elemento
        if self._cor.tipo is T.PUNTO_INTERROGATIVO:
            self._avanza()
            testo += "?"
        return testo

    # --- funzioni: metodo, `dà`, contratti --------------------------------------------------

    def _nome_metodo(self, nome: str) -> str:
        """``funzione Alunno.media()``: dopo il nome della struttura, il punto e il metodo."""
        if self._cor.tipo is T.PUNTO and self._guarda().tipo is T.NOME:
            self._avanza()
            metodo = self._avanza()
            return f"{nome}.{metodo.valore}"
        return nome

    def _tipo_risultato(self, t_funzione: Any) -> str | None:
        c = self._cor
        prec = self._precedente()
        if c.tipo is T.NOME and c.valore in PAROLE_RISULTATO and prec is not None and c.riga == prec.riga:
            self._avanza()
            return self._tipo_scritto("il tipo del risultato dopo `dà`")
        return None

    def _contratti(self) -> tuple[list, list, list]:
        """Le righe ``richiede``/``garantisce``/``può dare`` in cima al corpo."""
        richiede: list = []
        garantisce: list = []
        puo_dare: list[str] = []
        while True:
            self._salta_righe()
            c = self._cor
            if c.tipo is not T.NOME:
                break
            succ = self._guarda()
            if succ.riga != c.riga or succ.tipo in _NON_CONTESTO:
                break
            if c.valore in PAROLE_CONTRATTO:
                self._avanza()
                (richiede if c.valore == "richiede" else garantisce).append(self._espressione())
                self._fine_istruzione()
                continue
            if c.valore in ("può", "puo") and succ.tipo is T.NOME and succ.valore == "dare":
                self._avanza()
                self._avanza()
                while True:
                    e = self._cor
                    if e.tipo is not T.NOME:
                        raise self._inatteso("il tipo di errore dopo `può dare`", e,
                                             "Per esempio `può dare ErroreValore, ErroreFile`.")
                    puo_dare.append(str(self._avanza().valore))
                    if self._cor.tipo is T.VIRGOLA:
                        self._avanza()
                        continue
                    break
                self._fine_istruzione()
                continue
            break
        return richiede, garantisce, puo_dare

    # --- espressioni --------------------------------------------------------------------------

    def _ha_valore(self, espressione: Any) -> Any:
        """``x ha valore`` / ``x non ha valore`` dopo un'espressione (o None)."""
        c = self._cor
        g = self._guarda
        if c.tipo is T.NOME and c.valore == "ha" and g().tipo is T.NOME and g().valore == "valore" \
                and g().riga == c.riga:
            self._avanza()
            self._avanza()
            return HaValore(espressione, False, riga=c.riga, colonna=c.colonna)
        if c.tipo is T.NON and g().tipo is T.NOME and g().valore == "ha" and g(2).tipo is T.NOME \
                and g(2).valore == "valore" and g(2).riga == c.riga:
            for _ in range(3):
                self._avanza()
            return HaValore(espressione, True, riga=c.riga, colonna=c.colonna)
        return None

    def _e_oppure(self) -> bool:
        """Il token corrente è ``oppure`` usato come operatore (dopo un valore)?"""
        c = self._cor
        if c.tipo is T.O:
            return str(c.testo_originale or "").lower() == "oppure"
        if c.tipo is T.NOME and c.valore == "oppure":
            prec = self._precedente()
            return prec is not None and prec.riga == c.riga
        return False


def errore_punto_interrogativo(parser: Any, tok: Any) -> ErroreSintassi:
    return ErroreSintassi(
        "Il carattere `?` non fa parte di Leo.", tok.riga, tok.colonna,
        "In Leo non c'è l'operatore `?`: usa `se ... allora ... altrimenti ... fine`. "
        "Il `?` si scrive solo dopo un tipo, per dire «oppure nulla»: `variabile email: testo? = nulla`.",
        nome_file=parser.nome_file, lunghezza=1)


def apre_blocco_tipi(elenco: list, k: int) -> bool:
    """Per chi rifà i rientri (formattatore, autocorrezione): ``elenco[k]`` apre
    un blocco chiuso da ``fine``? Vale per ``struttura Nome`` e per
    ``tipo Nome è uno di`` senza varianti sulla stessa riga (anche dopo ``pubblica``).
    ``elenco``: i token della riga (senza commenti)."""
    t = elenco[k]
    if t.tipo is not T.NOME or t.valore not in ("struttura", "tipo"):
        return False
    if k > 0 and not (k == 1 and elenco[0].tipo is T.NOME and elenco[0].valore == "pubblica"):
        return False
    resto = [x for x in elenco[k + 1:] if x.tipo not in (T.FINE_RIGA, T.FINE_FILE) and x.riga == t.riga]
    if t.valore == "struttura":
        return len(resto) == 1 and resto[0].tipo is T.NOME
    return (len(resto) == 4 and resto[0].tipo is T.NOME and resto[1].tipo is T.E_ACCENTATA
            and resto[2].tipo is T.NOME and resto[2].valore in ("uno", "una")
            and resto[3].tipo is T.NOME and resto[3].valore == "di")


def parole_tipi(token: list) -> list[int]:
    """Per la colorazione: gli indici in ``token`` delle parole di contesto dei
    programmi grandi usate come tali (``struttura``, ``tipo ... è uno di``,
    ``pubblica``, ``richiede``, ``garantisce``, ``può dare``, ``dà``,
    ``ha valore``, ``oppure``). Mai eccezioni."""
    risultato: list[int] = []
    try:
        sig = [k for k, t in enumerate(token) if t.tipo not in (T.COMMENTO, T.ERRORE)]
        for pos, k in enumerate(sig):
            t = token[k]
            if t.tipo is not T.NOME:
                continue
            prec = token[sig[pos - 1]] if pos > 0 else None
            succ = token[sig[pos + 1]] if pos + 1 < len(sig) else None
            succ2 = token[sig[pos + 2]] if pos + 2 < len(sig) else None
            a_inizio = prec is None or prec.tipo is T.FINE_RIGA or (
                prec.tipo is T.NOME and prec.valore == "pubblica")
            stessa = succ is not None and succ.riga == t.riga and succ.tipo not in _NON_CONTESTO
            v = t.valore
            if v in ("struttura", "pubblica", "richiede", "garantisce") and a_inizio and stessa:
                risultato.append(k)
            elif v == "tipo" and a_inizio and stessa and succ2 is not None and succ2.tipo is T.E_ACCENTATA:
                risultato.append(k)
                for d in (2, 3, 4):
                    if pos + d < len(sig) and token[sig[pos + d]].riga == t.riga:
                        risultato.append(sig[pos + d])
            elif v in ("può", "puo") and a_inizio and succ is not None and succ.tipo is T.NOME \
                    and succ.valore == "dare":
                risultato.extend((k, sig[pos + 1]))
            elif v in PAROLE_RISULTATO and prec is not None and prec.tipo is T.PARENTESI_CHIUSA \
                    and prec.riga == t.riga:
                risultato.append(k)
            elif v == "ha" and succ is not None and succ.tipo is T.NOME and succ.valore == "valore" \
                    and prec is not None and prec.riga == t.riga and prec.tipo is not T.FINE_RIGA:
                risultato.extend((k, sig[pos + 1]))
            elif v == "oppure" and prec is not None and prec.riga == t.riga and prec.tipo is not T.FINE_RIGA:
                risultato.append(k)
    except Exception:  # noqa: BLE001
        pass
    return risultato
