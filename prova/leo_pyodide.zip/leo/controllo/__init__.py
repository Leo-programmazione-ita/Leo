"""Programmi grandi: tipi, strutture e controlli prima di eseguire.

API pubblica (documentata in docs/CONTROLLO.md), pensata per ``leo controlla``,
Leo Studio, l'app del telefono e il server del linguaggio::

    from leo.controllo import controlla, controlla_file, Diagnostica

    rapporto = controlla(sorgente, "voti.leo")      # niente viene eseguito
    for d in rapporto.diagnostiche:                 # ordinate per riga
        print(d.riga, d.colonna, d.gravita, d.messaggio)
    rapporto.come_dizionario()                      # pronto per JSON

I moduli interni:

* :mod:`leo.controllo.tipi` - i tipi scritti (``intero``, ``testo?``, ``lista di decimale``);
* :mod:`leo.controllo.strutture` - i valori di ``struttura``/varianti e le costanti bloccate;
* :mod:`leo.controllo.esecuzione` - i costrutti nuovi visti dall'interprete;
* :mod:`leo.controllo.sintassi` - il loro riconoscimento nel parser;
* :mod:`leo.controllo.analisi` - il controllo statico (``leo controlla``).
"""

from __future__ import annotations

from .analisi import GRAVITA, Diagnostica, Rapporto, controlla, controlla_cartella, controlla_file

__all__ = ["controlla", "controlla_file", "controlla_cartella", "diagnostica_editor", "Diagnostica", "Rapporto",
           "GRAVITA"]


def diagnostica_editor(sorgente: str, nome_file: str = "<editor>", **_opzioni) -> list[Diagnostica]:
    """Le diagnostiche di :func:`controlla` per gli editor (server del linguaggio, ``leo lsp``).

    Gli errori di sintassi restano al parser dell'editor (che li mostra subito, con le correzioni):
    qui arrivano solo i controlli di ``leo controlla`` (nomi, tipi, ``nulla``, argomenti...).
    Ogni voce ha ``riga``, ``colonna``, ``lunghezza``, ``gravita``, ``codice``, ``messaggio``,
    ``suggerimento`` e ``correzioni``; :meth:`Diagnostica.come_lsp` la da' nel formato LSP.
    """
    return [d for d in controlla(sorgente, nome_file).diagnostiche if d.codice != "sintassi"]
