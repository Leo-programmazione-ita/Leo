"""Esecuzione dei costrutti per i programmi grandi (mescolata nell'interprete).

:class:`EsecuzioneTipi` aggiunge all'interprete i metodi ``visita_*`` dei nodi
nuovi (``struttura``, ``tipo ... è uno di``, ``ha valore``, ``richiede``...) e
gli aiutanti usati dai metodi esistenti (dichiarazioni con tipo, costanti
bloccate, ``oppure``, ``scegli`` che scompone le varianti, funzioni con
contratti). Il compilatore passa questi nodi all'interprete ad albero (sono
rari: definizioni e controlli), quindi la semantica è una sola.
"""

from __future__ import annotations

import copy
from dataclasses import fields
from typing import Any

from ..ambiente import Voce
from ..errori import ErroreDante, ErroreNome, ErroreTipo, ErroreValore
from ..nodi import (Attributo, Chiamata, ControllaRisultato, DefinizioneFunzione, Evento, FunzioneAnonima,
                    Letterale, Nodo, Nome, Parallelo, Parametro, Restituisci, Richiede, Temporizzatore)
from ..valori import FunzioneDante, nome_tipo, rappresenta, tipo_con_articolo, uguali, verifica_logico
from .strutture import (CampoStruttura, IstanzaStruttura, SuperIstanza, TipoStruttura, TipoVarianti, blocca,
                        tipo_campo, tipo_di_variante)
from .tipi import conforme, spiega_differenza, tipo_da_testo

__all__ = ["EsecuzioneTipi", "VoceTipizzata", "corpo_con_contratti"]


class VoceTipizzata(Voce):
    """Una variabile dichiarata con un tipo (``variabile x: intero = 0``).

    Si presenta come ``costante`` cosi' ogni assegnazione passa da
    ``Ambiente.assegna`` (il percorso lento), che chiama :meth:`controlla_valore`.
    """

    def __init__(self, valore: Any, tipo: Any, riga: int = 0) -> None:
        super().__init__(valore, True, riga, False)
        self.tipo = tipo

    def controlla_valore(self, nome: str, valore: Any) -> Any:
        if not conforme(valore, self.tipo):
            raise ErroreTipo(
                f"`{nome}` è dichiarata `{self.tipo}`: non può ricevere {spiega_differenza(valore, self.tipo)}.",
                suggerimento=_suggerimento_tipo(self.tipo, valore))
        return valore


def _suggerimento_tipo(tipo: Any, valore: Any) -> str | None:
    tipo = tipo_da_testo(tipo)
    if valore is None and not tipo.accetta_nulla:
        return f"Se il valore può mancare, scrivi il tipo con il punto di domanda: `{tipo.con_nulla}`."
    if tipo.nome == "intero" and isinstance(valore, float):
        return "Per avere un intero usa `intero(x)` oppure `arrotonda(x)`; se servono i decimali dichiara `decimale`."
    if tipo.nome in ("intero", "decimale", "numero") and isinstance(valore, str):
        return "Per trasformare un testo in numero usa `numero(x)` (o `intero(x)`)."
    if tipo.nome == "testo" and not isinstance(valore, str):
        return "Per trasformare un valore in testo usa `testo(x)`."
    return None


# ---------------------------------------------------------------------------
# Funzioni con ``dà tipo`` / ``richiede`` / ``garantisce``
# ---------------------------------------------------------------------------

#: Nodi che aprono una funzione nuova: i ``restituisci`` dentro non sono nostri.
_FUNZIONI_INTERNE = (FunzioneAnonima, DefinizioneFunzione, Evento, Temporizzatore, Parallelo)


def _sostituisci_restituisci(nodo: Any, avvolgi) -> Any:
    """Copia di ``nodo`` con ogni ``restituisci`` (non di funzioni interne) avvolto."""
    if isinstance(nodo, list):
        return [_sostituisci_restituisci(x, avvolgi) for x in nodo]
    if isinstance(nodo, tuple):
        return tuple(_sostituisci_restituisci(x, avvolgi) for x in nodo)
    if not isinstance(nodo, Nodo) or isinstance(nodo, _FUNZIONI_INTERNE):
        return nodo
    if isinstance(nodo, Restituisci):
        return Restituisci(avvolgi(nodo.valore, nodo), riga=nodo.riga, colonna=nodo.colonna)
    nuovo = copy.copy(nodo)
    nuovo.__dict__.pop("_ambiti", None)
    nuovo.__dict__.pop("_ambiti_se", None)
    for f in fields(nodo):
        valore = getattr(nodo, f.name)
        if isinstance(valore, (Nodo, list, tuple)):
            setattr(nuovo, f.name, _sostituisci_restituisci(valore, avvolgi))
    return nuovo


def _finisce_sempre(corpo: list) -> bool:
    """Vero se l'ultima istruzione esce sempre (``restituisci`` o ``lancia``)."""
    from ..nodi import Lancia, Se

    if not corpo:
        return False
    ultima = corpo[-1]
    if isinstance(ultima, (Restituisci, Lancia)):
        return True
    if isinstance(ultima, Se) and ultima.altrimenti is not None:
        return all(_finisce_sempre(r.corpo) for r in ultima.rami) and _finisce_sempre(ultima.altrimenti)
    return False


def corpo_con_contratti(nodo: DefinizioneFunzione, nome: str) -> list:
    """Il corpo da eseguire per una funzione con tipo del risultato o contratti:
    i ``richiede`` in testa, ogni ``restituisci`` avvolto in un
    :class:`ControllaRisultato` (anche quello implicito alla fine)."""
    pronto = nodo.__dict__.get("_leo_corpo_contratti")
    if pronto is not None:
        return pronto
    corpo = list(nodo.corpo)
    tipo = nodo.tipo_risultato
    garanzie = list(nodo.garantisce)
    if tipo is not None or garanzie:
        def avvolgi(valore, origine):
            v = valore if valore is not None else Letterale(None, riga=origine.riga, colonna=origine.colonna)
            return ControllaRisultato(v, nome, tipo, garanzie, riga=origine.riga, colonna=origine.colonna)
        corpo = _sostituisci_restituisci(corpo, avvolgi)
        if not _finisce_sempre(corpo):
            riga = getattr(corpo[-1], "riga", nodo.riga) if corpo else nodo.riga
            corpo.append(Restituisci(ControllaRisultato(Letterale(None, riga=riga), nome, tipo, garanzie,
                                                        alla_fine=True, riga=riga), riga=riga))
    if nodo.richiede:
        corpo = [Richiede(c, nome, riga=c.riga, colonna=c.colonna) for c in nodo.richiede] + corpo
    nodo.__dict__["_leo_corpo_contratti"] = corpo
    return corpo


def _testo_condizione(espressione: Any, sorgente: str) -> str:
    """Il testo della condizione come è scritto (per i messaggi), se si trova."""
    riga = getattr(espressione, "riga", 0)
    if sorgente and riga:
        righe = sorgente.splitlines()
        if 0 < riga <= len(righe):
            testo = righe[riga - 1].strip()
            for parola in ("richiede ", "garantisce "):
                if testo.startswith(parola):
                    return testo[len(parola):].split(" # ")[0].strip()
    return ""


def _nomi_usati(espressione: Any) -> list[str]:
    visti: list[str] = []

    def visita(n: Any) -> None:
        if isinstance(n, Nome):
            if n.nome not in visti:
                visti.append(n.nome)
        elif isinstance(n, Attributo):
            visita(n.oggetto)
        elif isinstance(n, Chiamata):
            for a in n.argomenti:
                visita(a.valore)
        elif isinstance(n, Nodo):
            for f in fields(n):
                v = getattr(n, f.name)
                if isinstance(v, list):
                    for x in v:
                        visita(x)
                else:
                    visita(v)
    visita(espressione)
    return visti


class EsecuzioneTipi:
    """Mescolata in :class:`leo.interprete.Interprete`."""

    # --- dichiarazioni ----------------------------------------------------------

    def _dichiara_speciale(self, nodo: Any, ambiente: Any) -> None:
        """``variabile x: T = v`` e ``costante X = v`` (contenuto bloccato)."""
        valore = self.valuta(nodo.valore, ambiente)
        tipo = getattr(nodo, "tipo", None)
        if tipo is not None:
            t = tipo_da_testo(tipo)
            if not conforme(valore, t):
                raise self._posiziona(ErroreTipo(
                    f"`{nodo.nome}` è dichiarata `{t}`, ma il valore iniziale è {spiega_differenza(valore, t)}.",
                    suggerimento=_suggerimento_tipo(t, valore)), nodo.valore)
        if nodo.costante:
            valore = blocca(valore, nodo.nome)
            ambiente.dichiara(nodo.nome, valore, costante=True, riga=nodo.riga)
            return
        ambiente.dichiara(nodo.nome, valore, riga=nodo.riga)
        ambiente.voci[nodo.nome] = VoceTipizzata(valore, tipo_da_testo(tipo), nodo.riga)

    # --- funzioni, metodi, contratti ------------------------------------------------

    def _definisci_funzione(self, nodo: DefinizioneFunzione, ambiente: Any) -> None:
        nome = nodo.nome
        speciale = nodo.tipo_risultato is not None or nodo.richiede or nodo.garantisce
        corpo = corpo_con_contratti(nodo, nome) if speciale else nodo.corpo
        if "." not in nome:
            f = FunzioneDante(nome, nodo.parametri, corpo, ambiente, nodo.riga, nodo.colonna)
            f.nome_file = self._file_corrente
            f.tipo_risultato = nodo.tipo_risultato
            if self.repl:
                self.segna_testo(f)
            ambiente.dichiara(nome, f, costante=True, riga=nodo.riga)
            return
        nome_tipo_, nome_metodo = nome.split(".", 1)
        voce = ambiente.voce(nome_tipo_)
        proprietario = voce.valore if voce is not None else None
        if not isinstance(proprietario, (TipoStruttura, TipoVarianti)):
            if proprietario is None:
                raise ErroreNome(f"Per definire il metodo `{nome}` serve prima `struttura {nome_tipo_}`.",
                                 suggerimento=f"Scrivi la struttura `{nome_tipo_}` prima dei suoi metodi.",
                                 nome=nome_tipo_)
            raise ErroreTipo(f"`{nome_tipo_}` non è una struttura né un tipo: non può avere il metodo "
                             f"`{nome_metodo}`.")
        self._registra_metodo(proprietario, nodo, nome_metodo, corpo, ambiente)

    def _registra_metodo(self, proprietario: Any, nodo: DefinizioneFunzione, nome_metodo: str, corpo: list,
                         ambiente: Any) -> None:
        if nome_metodo in getattr(proprietario, "nomi_campi", ()):
            raise ErroreNome(f"`{proprietario.nome}` ha già un campo `{nome_metodo}`: un metodo deve avere "
                             "un nome diverso.", nome=nome_metodo)
        if nome_metodo in proprietario.metodi and not self.repl:
            raise ErroreNome(f"Il metodo `{proprietario.nome}.{nome_metodo}` è già definito.", nome=nome_metodo)
        if any(p.nome == "questo" for p in nodo.parametri):
            raise ErroreNome("`questo` c'è già in ogni metodo (è il valore prima del punto): togli il parametro "
                             "`questo`.", nome="questo")
        parametri = [Parametro("questo", riga=nodo.riga, colonna=nodo.colonna)] + list(nodo.parametri)
        f = FunzioneDante(f"{proprietario.nome}.{nome_metodo}", parametri, corpo, ambiente, nodo.riga, nodo.colonna)
        f.nome_file = self._file_corrente
        f.tipo_risultato = nodo.tipo_risultato
        if self.repl:
            self.segna_testo(f)
        proprietario.metodi[nome_metodo] = f

    def visita_Richiede(self, nodo, ambiente):
        valore = self.valuta(nodo.condizione, ambiente)
        if valore is True:
            return
        if valore is not False:
            verifica_logico(valore, "richiede")
        testo = _testo_condizione(nodo.condizione, self.sorgenti_moduli.get(self._file_corrente) or self.sorgente)
        valori = []
        for n in _nomi_usati(nodo.condizione)[:4]:
            voce = ambiente.voce(n)
            if voce is not None and not isinstance(voce.valore, (FunzioneDante,)) and voce.riga:
                valori.append(f"{n} = {rappresenta(voce.valore, dentro=True)}")
        condizione = f" `{testo}`" if testo else ""
        raise ErroreValore(
            f"`{nodo.funzione}` richiede{condizione}, ma non è vero"
            + (f" ({', '.join(valori)})." if valori else "."),
            suggerimento="L'errore è in chi chiama la funzione: controlla gli argomenti che le passi.")

    def visita_ControllaRisultato(self, nodo, ambiente):
        valore = self.valuta(nodo.valore, ambiente)
        if nodo.tipo is not None and not conforme(valore, nodo.tipo):
            t = tipo_da_testo(nodo.tipo)
            if nodo.alla_fine and valore is None:
                raise ErroreTipo(f"`{nodo.funzione}` deve dare {_articolo_tipo(t)}, ma è finita senza `restituisci`.",
                                 suggerimento="Aggiungi `restituisci ...` in fondo (o in ogni ramo) della funzione.")
            raise ErroreTipo(f"`{nodo.funzione}` deve dare {_articolo_tipo(t)}, ma ha dato "
                             f"{spiega_differenza(valore, t)}.", suggerimento=_suggerimento_tipo(t, valore))
        if nodo.garantisce:
            interno = ambiente.figlio("garantisce")
            interno.voci["risultato"] = Voce(valore, True, nodo.riga)
            for condizione in nodo.garantisce:
                esito = self.valuta(condizione, interno)
                if esito is True:
                    continue
                if esito is not False:
                    verifica_logico(esito, "garantisce")
                testo = _testo_condizione(condizione, self.sorgenti_moduli.get(self._file_corrente) or self.sorgente)
                raise self._posiziona(ErroreValore(
                    f"`{nodo.funzione}` garantisce" + (f" `{testo}`" if testo else " una condizione")
                    + f", ma con risultato = {rappresenta(valore, dentro=True)} non è vero.",
                    suggerimento="L'errore è dentro la funzione: il valore che restituisce non è quello promesso."),
                    condizione)
        return valore

    def _controlla_parametro(self, f: Any, p: Any, valore: Any) -> None:
        if not conforme(valore, p.tipo):
            t = tipo_da_testo(p.tipo)
            raise ErroreTipo(
                f"Il parametro `{p.nome}` di `{f.nome}` deve essere di tipo `{t}`, "
                f"ma ha ricevuto {_valore_ricevuto(valore, t)}.", suggerimento=_suggerimento_tipo(t, valore))

    # --- struttura e tipo a varianti ----------------------------------------------

    def _campi(self, campi: list) -> list[CampoStruttura]:
        return [CampoStruttura(c.nome, tipo_campo(c.tipo), c.predefinito) for c in campi]

    def visita_DefinizioneStruttura(self, nodo, ambiente):
        base = self._classe_base(nodo, ambiente)
        campi = self._campi(nodo.campi)
        if base is not None:
            # la sottoclasse eredita i campi del genitore; un campo con lo stesso
            # nome nella sottoclasse lo sovrascrive (resta nella posizione del genitore)
            propri = {c.nome: c for c in campi}
            uniti = [propri.get(c.nome, c) for c in base.campi]
            noti = {c.nome for c in base.campi}
            uniti += [c for c in campi if c.nome not in noti]
            campi = uniti
        tipo = TipoStruttura(nodo.nome, campi, ambiente, base=base)
        ambiente.dichiara(nodo.nome, tipo, costante=True, riga=nodo.riga)
        for metodo in nodo.metodi:
            speciale = metodo.tipo_risultato is not None or metodo.richiede or metodo.garantisce
            nome = f"{nodo.nome}.{metodo.nome}"
            corpo = corpo_con_contratti(metodo, nome) if speciale else metodo.corpo
            self._registra_metodo(tipo, metodo, metodo.nome, corpo, ambiente)

    def _classe_base(self, nodo, ambiente) -> Any:
        """Il :class:`TipoStruttura` del genitore in ``classe ... estende Base`` (o None)."""
        nome_base = getattr(nodo, "base", None)
        if not nome_base:
            return None
        voce = ambiente.voce(nome_base)
        base = voce.valore if voce is not None else None
        if isinstance(base, TipoStruttura) and base.famiglia is None:
            return base
        if base is None:
            raise ErroreNome(
                f"La classe `{nodo.nome}` estende `{nome_base}`, ma `{nome_base}` non è definita.",
                suggerimento=f"Scrivi la classe `{nome_base}` prima di `classe {nodo.nome} estende {nome_base}`.",
                nome=nome_base)
        raise ErroreTipo(
            f"La classe `{nodo.nome}` può estendere solo un'altra classe, ma `{nome_base}` non lo è.",
            suggerimento=f"`{nome_base}` deve essere una `classe`.")

    def visita_RiferimentoGenitore(self, nodo, ambiente):
        voce = ambiente.voce("questo")
        if voce is None:
            raise ErroreNome(
                "`genitore` si usa solo dentro un'azione di una classe.",
                suggerimento="Serve per richiamare l'azione del genitore, per esempio `genitore.saluta()`.",
                nome="genitore")
        base_voce = ambiente.voce(nodo.base)
        base = base_voce.valore if base_voce is not None else None
        if not isinstance(base, TipoStruttura):
            raise ErroreNome(f"La classe genitore `{nodo.base}` non è definita.", nome=nodo.base)
        return SuperIstanza(voce.valore, base)

    def visita_DefinizioneTipo(self, nodo, ambiente):
        famiglia = TipoVarianti(nodo.nome)
        ambiente.dichiara(nodo.nome, famiglia, costante=True, riga=nodo.riga)
        for variante in nodo.varianti:
            costruttore = TipoStruttura(variante.nome, self._campi(variante.campi or []), ambiente,
                                        genitore=nodo.nome, famiglia=famiglia)
            if variante.campi is None:
                valore: Any = costruttore.chiama(self, [], {})
            else:
                valore = costruttore
            famiglia.varianti[variante.nome] = valore
            ambiente.dichiara(variante.nome, valore, costante=True, riga=variante.riga or nodo.riga)

    def visita_HaValore(self, nodo, ambiente):
        valore = self.valuta(nodo.valore, ambiente)
        return (valore is None) if nodo.negato else (valore is not None)

    # --- oppure -----------------------------------------------------------------------

    def _oppure(self, nodo, ambiente):
        """``a oppure b``: se ``a`` è ``nulla`` vale ``b``; se ``a`` è logico è il
        vecchio «o» (come prima); altrimenti vale ``a``."""
        sinistra = self.valuta(nodo.sinistra, ambiente)
        if sinistra is None:
            return self.valuta(nodo.destra, ambiente)
        if sinistra is True or sinistra is False:
            if sinistra:
                return True
            return self._condizione(nodo.destra, ambiente, "o")
        return sinistra

    # --- scegli con le varianti ---------------------------------------------------------

    def _schema_struttura(self, schema: Any, ambiente: Any) -> Any:
        """Il costruttore di struttura/variante di uno schema ``Cerchio(r)``, se lo è."""
        if isinstance(schema, Chiamata) and isinstance(schema.funzione, (Nome, Attributo)):
            try:
                f = self.valuta(schema.funzione, ambiente)
            except ErroreDante:
                return None
            if isinstance(f, TipoStruttura):
                return f
        return None

    def _scomponi(self, valore: Any, schema: Any, ambiente: Any, legami: dict) -> bool:
        """``caso Cerchio(r)``: vero se ``valore`` è un ``Cerchio``; ``r`` va in ``legami``."""
        costruttore = self._schema_struttura(schema, ambiente)
        if costruttore is None:
            return self._corrisponde(valore, schema, ambiente)
        if not isinstance(valore, IstanzaStruttura) or valore._tipo is not costruttore:
            return False
        nomi = costruttore.nomi_campi
        posizionali = [a for a in schema.argomenti if a.nome is None]
        if len(posizionali) > len(nomi):
            raise ErroreTipo(f"`{costruttore.nome}` ha {len(nomi)} campi, ma nel `caso` ne hai scritti "
                             f"{len(posizionali)}.",
                             suggerimento="Campi: " + ", ".join(f"`{n}`" for n in nomi) + "." if nomi else None)
        coppie = list(zip(nomi, posizionali))
        for a in schema.argomenti:
            if a.nome is not None:
                if a.nome not in nomi:
                    raise ErroreNome(f"`{costruttore.nome}` non ha il campo `{a.nome}`.", nome=a.nome)
                coppie.append((a.nome, a))
        for campo, argomento in coppie:
            dentro = valore._valori.get(campo)
            espressione = argomento.valore
            if isinstance(espressione, Nome):
                if espressione.nome != "_":
                    legami[espressione.nome] = dentro
                continue
            if not self._scomponi(dentro, espressione, ambiente, legami):
                return False
        return True

    def _scegli(self, nodo, ambiente):
        valore = self.valuta(nodo.valore, ambiente)
        for caso in nodo.casi:
            for schema in caso.schemi:
                legami: dict = {}
                try:
                    trovato = self._scomponi(valore, schema, ambiente, legami)
                except ErroreDante as e:
                    self._posiziona(e, schema)
                    raise
                if trovato:
                    if legami:
                        interno = ambiente.figlio("caso")
                        for n, v in legami.items():
                            interno.voci[n] = Voce(v, False, caso.riga)
                    else:
                        interno = self._ambito(caso, caso.corpo, ambiente, "caso")
                    self.esegui_blocco(caso.corpo, interno)
                    return
        if nodo.altrimenti is not None:
            self.esegui_blocco(nodo.altrimenti, self._ambito(nodo, nodo.altrimenti, ambiente, "altrimenti"))
            return
        nessun_caso(valore)


def nessun_caso(valore: Any) -> None:
    """Un ``scegli`` su una variante senza il suo ``caso`` (e senza ``altrimenti``): errore."""
    famiglia = tipo_di_variante(valore)
    if famiglia is None:
        return
    nome = valore._tipo.nome
    raise ErroreValore(
        f"Nessun `caso` di `scegli` è per `{nome}` (un valore del tipo `{famiglia.nome}`).",
        suggerimento=f"Aggiungi `caso {nome} allora` (o `altrimenti`): `leo controlla` trova i casi che mancano "
                     "prima di eseguire.")


def _articolo_tipo(tipo: Any) -> str:
    nome = str(tipo)
    if tipo.nome in ("nulla",):
        return "`nulla`"
    from ..valori import TIPI_FEMMINILI

    return ("una" if tipo.nome in TIPI_FEMMINILI else "un") + f" `{nome}`"


def _valore_ricevuto(valore: Any, tipo: Any) -> str:
    descrizione = spiega_differenza(valore, tipo)
    if descrizione.startswith(("un ", "una ", "dei ")) and "elemento" not in descrizione:
        return f"un valore di tipo `{nome_tipo(valore)}`"
    return descrizione
