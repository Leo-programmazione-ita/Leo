"""Valori di ``struttura``, dei tipi a varianti e delle costanti bloccate.

* :class:`TipoStruttura` è il valore legato al nome di una struttura
  (``Alunno``): chiamarlo crea un :class:`IstanzaStruttura`
  (``Alunno("Ada", [8, 9])`` oppure ``Alunno(nome = "Ada")``). Una variante di
  ``tipo Forma è uno di`` è un ``TipoStruttura`` con ``genitore = "Forma"``;
  una variante senza dati (``Vuota``) è direttamente un'istanza unica.
* Le istanze seguono il protocollo di :class:`leo.valori.OggettoControllo`
  (``a.nome`` legge, ``a.nome = x`` scrive, ``a.media()`` chiama un metodo):
  interprete e compilatore le gestiscono già senza codice in più.
* :func:`blocca` fa una copia "di sola lettura" di liste, dizionari e strutture
  (anche annidati): la usa ``costante``, così anche il contenuto non cambia.
"""

from __future__ import annotations

import difflib
from typing import Any

from ..errori import ErroreNome, ErroreTipo, ErroreValore
from ..valori import OggettoControllo, Richiamabile, rappresenta, uguali
from .tipi import Tipo, conforme, spiega_differenza, tipo_da_testo

__all__ = ["TipoStruttura", "IstanzaStruttura", "TipoVarianti", "MetodoStruttura", "SuperIstanza", "blocca",
           "ListaBloccata", "DizionarioBloccato", "e_bloccato", "sblocca"]


def _simile(nome: str, candidati: list[str]) -> str | None:
    simili = difflib.get_close_matches(nome, candidati, n=1, cutoff=0.6)
    return simili[0] if simili else None


class CampoStruttura:
    """Un campo: nome, tipo (``Tipo`` o None), predefinito (espressione o None)."""

    __slots__ = ("nome", "tipo", "predefinito")

    def __init__(self, nome: str, tipo: Tipo | None, predefinito: Any) -> None:
        self.nome = nome
        self.tipo = tipo
        self.predefinito = predefinito


class TipoStruttura(Richiamabile):
    """Il "costruttore" di una struttura o di una variante."""

    def __init__(self, nome: str, campi: list[CampoStruttura], chiusura: Any, *,
                 genitore: str | None = None, famiglia: "TipoVarianti | None" = None,
                 base: "TipoStruttura | None" = None) -> None:
        self.nome = nome
        self.campi = campi
        self.chiusura = chiusura
        self.genitore = genitore
        self.famiglia = famiglia
        #: la classe genitore di `classe Studente estende Persona` (None senza `estende`).
        self.base = base
        self.metodi: dict[str, Any] = {}
        self.classe = type(nome, (IstanzaStruttura,), {"NOME_TIPO_DANTE": nome, "__slots__": ()})

    @property
    def nomi_campi(self) -> list[str]:
        return [c.nome for c in self.campi]

    def testo_dante(self) -> str:
        if self.genitore:
            return f"<variante {self.nome} di {self.genitore}>"
        return f"<struttura {self.nome}>"

    def trova_metodo(self, nome: str) -> Any:
        f = self.metodi.get(nome)
        if f is None and self.famiglia is not None:
            f = self.famiglia.metodi.get(nome)
        if f is None and self.base is not None:
            f = self.base.trova_metodo(nome)      # eredita le azioni della classe genitore
        return f

    def tutti_i_metodi(self) -> list[str]:
        """I nomi delle azioni della classe e di tutti i genitori (per i suggerimenti)."""
        nomi = list(self.metodi)
        if self.base is not None:
            for n in self.base.tutti_i_metodi():
                if n not in nomi:
                    nomi.append(n)
        return nomi

    def chiama(self, interprete: Any, argomenti: list, argomenti_nome: dict[str, Any]) -> "IstanzaStruttura":
        campi = self.campi
        nomi = self.nomi_campi
        if len(argomenti) > len(campi):
            attesi = "nessun valore" if not campi else (
                "1 valore" if len(campi) == 1 else f"al massimo {len(campi)} valori")
            raise ErroreTipo(
                f"`{self.nome}` vuole {attesi}, ma ne ha ricevuti {len(argomenti)}.",
                suggerimento=(f"Campi di `{self.nome}`: " + ", ".join(f"`{n}`" for n in nomi) + ".")
                if nomi else None)
        valori: dict[str, Any] = dict(zip(nomi, argomenti))
        for nome, valore in argomenti_nome.items():
            if nome not in nomi:
                simile = _simile(nome, nomi)
                raise ErroreTipo(f"`{self.nome}` non ha un campo chiamato `{nome}`.",
                                 suggerimento=f"Forse intendevi `{simile}`?" if simile else
                                 (f"Campi di `{self.nome}`: " + ", ".join(f"`{n}`" for n in nomi) + ".")
                                 if nomi else None)
            if nome in valori:
                raise ErroreTipo(f"Il campo `{nome}` di `{self.nome}` ha ricevuto due valori.")
            valori[nome] = valore
        istanza = self.classe.__new__(self.classe)
        istanza._tipo = self
        istanza._bloccata = False
        dati: dict[str, Any] = {}
        for campo in campi:
            if campo.nome in valori:
                valore = valori[campo.nome]
            elif campo.predefinito is not None:
                # il predefinito si calcola a ogni creazione: due alunni non
                # condividono mai la stessa lista `voti = []`
                valore = interprete.valuta(campo.predefinito, self.chiusura)
            elif campo.tipo is not None and campo.tipo.accetta_nulla:
                valore = None
            else:
                raise ErroreTipo(
                    f"Manca il campo `{campo.nome}` per creare `{self.nome}`.",
                    suggerimento=f"Scrivilo così: `{self.nome}({campo.nome} = ...)`, oppure dagli un valore "
                                 f"predefinito nella struttura: `{campo.nome}: ... = ...`.")
            if campo.tipo is not None and not conforme(valore, campo.tipo):
                raise ErroreTipo(
                    f"Il campo `{campo.nome}` di `{self.nome}` deve essere `{campo.tipo}`, "
                    f"ma ha ricevuto {spiega_differenza(valore, campo.tipo)}.")
            dati[campo.nome] = valore
        istanza._valori = dati
        return istanza


class IstanzaStruttura(OggettoControllo):
    """Un valore creato da una struttura (``Alunno(...)``) o da una variante."""

    __slots__ = ("_tipo", "_valori", "_bloccata")
    NOME_TIPO_DANTE = "struttura"
    E_VALORE_LIBRERIA = True     # non e' un controllo grafico
    E_STRUTTURA = True

    # --- nomi usati da OggettoControllo / MetodoLegato --------------------------
    @property
    def nome(self) -> str:  # type: ignore[override]
        return self._tipo.nome

    @property
    def tipo_controllo(self) -> str:  # type: ignore[override]
        return self._tipo.nome

    @property
    def tipo_struttura(self) -> TipoStruttura:
        return self._tipo

    @property
    def valori_campi(self) -> dict[str, Any]:
        return self._valori

    def elenco_proprieta(self) -> list[str]:
        return list(self._valori)

    def metodo(self, nome: str) -> Richiamabile | None:
        if nome in self._valori:
            return None
        f = self._tipo.trova_metodo(nome)
        return MetodoStruttura(self, f) if f is not None else None

    def leggi(self, proprieta: str) -> Any:
        try:
            return self._valori[proprieta]
        except KeyError:
            pass
        candidati = list(self._valori) + self._tipo.tutti_i_metodi()
        if self._tipo.famiglia is not None:
            candidati += list(self._tipo.famiglia.metodi)
        simile = _simile(proprieta, candidati)
        if simile:
            suggerimento = f"Forse intendevi `{simile}`" + ("()" if simile not in self._valori else "") + "?"
        elif self._valori:
            suggerimento = f"Campi di `{self._tipo.nome}`: " + ", ".join(f"`{n}`" for n in self._valori) + "."
        else:
            suggerimento = f"`{self._tipo.nome}` non ha campi."
        raise ErroreNome(f"`{self._tipo.nome}` non ha il campo `{proprieta}`.",
                         suggerimento=suggerimento, nome=proprieta)

    def scrivi(self, proprieta: str, valore: Any) -> None:
        if proprieta not in self._valori:
            self.leggi(proprieta)  # stesso messaggio, con il suggerimento
        if self._bloccata:
            raise ErroreValore(
                f"Questo `{self._tipo.nome}` è una costante: il campo `{proprieta}` non si può cambiare.",
                suggerimento="Se deve cambiare, dichiaralo con `variabile` invece di `costante`, "
                             "oppure lavora su una copia: `copia(...)`.")
        for campo in self._tipo.campi:
            if campo.nome == proprieta and campo.tipo is not None and not conforme(valore, campo.tipo):
                raise ErroreTipo(
                    f"Il campo `{proprieta}` di `{self._tipo.nome}` è `{campo.tipo}`: non può ricevere "
                    f"{spiega_differenza(valore, campo.tipo)}.")
        self._valori[proprieta] = valore

    # --- valore ---------------------------------------------------------------
    def __eq__(self, altro: Any) -> bool:
        if not isinstance(altro, IstanzaStruttura) or altro._tipo is not self._tipo:
            return False
        return all(uguali(self._valori[k], altro._valori[k]) for k in self._valori)

    __hash__ = None  # type: ignore[assignment]

    def testo_dante(self) -> str:
        if not self._valori and self._tipo.genitore is not None and not self._tipo.campi:
            return self._tipo.nome
        parti = ", ".join(f"{k} = {rappresenta(v, dentro=True)}" for k, v in self._valori.items())
        return f"{self._tipo.nome}({parti})"

    def __repr__(self) -> str:
        return self.testo_dante()


class MetodoStruttura(Richiamabile):
    """Un metodo legato a un'istanza: ``a.media`` (``questo`` = ``a``)."""

    def __init__(self, oggetto: IstanzaStruttura, funzione: Any) -> None:
        self.oggetto = oggetto
        self.funzione = funzione
        self.nome = funzione.nome

    def chiama(self, interprete: Any, argomenti: list, argomenti_nome: dict[str, Any]) -> Any:
        parametri = self.funzione.parametri[1:]     # il primo e' `questo`
        variadico = bool(parametri) and getattr(parametri[-1], "variadico", False)
        if not variadico and len(argomenti) > len(parametri):
            obbligatori = sum(1 for p in parametri if p.predefinito is None)
            if not parametri:
                attesi = "nessun argomento"
            elif obbligatori == len(parametri):
                attesi = "1 argomento" if len(parametri) == 1 else f"{len(parametri)} argomenti"
            else:
                attesi = f"da {obbligatori} a {len(parametri)} argomenti"
            raise ErroreTipo(f"Il metodo `{self.nome}` vuole {attesi}, ma ne ha ricevuti {len(argomenti)}.")
        if "questo" in argomenti_nome:
            raise ErroreTipo(f"`questo` è il valore prima del punto: non si passa a `{self.nome}`.")
        return interprete.chiama(self.funzione, [self.oggetto] + list(argomenti), argomenti_nome)

    def testo_dante(self) -> str:
        return f"<metodo {self.nome}>"


class SuperIstanza(OggettoControllo):
    """``genitore`` dentro un'azione: l'istanza corrente vista come la classe
    genitore. ``genitore.saluta()`` chiama l'azione `saluta` del genitore (anche
    se la sottoclasse la sovrascrive), con `questo` = l'istanza vera."""

    NOME_TIPO_DANTE = "genitore"
    E_VALORE_LIBRERIA = True

    def __init__(self, oggetto: IstanzaStruttura, base: TipoStruttura) -> None:
        self.oggetto = oggetto
        self.base = base
        self.nome = base.nome

    @property
    def tipo_controllo(self) -> str:  # type: ignore[override]
        return self.base.nome

    def metodo(self, nome: str) -> Richiamabile | None:
        f = self.base.trova_metodo(nome)
        return MetodoStruttura(self.oggetto, f) if f is not None else None

    def leggi(self, proprieta: str) -> Any:
        # i campi sono gli stessi dell'istanza: `genitore.nome` vale `questo.nome`
        f = self.base.trova_metodo(proprieta)
        if f is not None:
            return MetodoStruttura(self.oggetto, f)
        if proprieta in self.oggetto._valori:
            return self.oggetto._valori[proprieta]
        simile = _simile(proprieta, self.base.tutti_i_metodi() + list(self.oggetto._valori))
        raise ErroreNome(
            f"La classe genitore `{self.base.nome}` non ha l'azione `{proprieta}`.",
            suggerimento=f"Forse intendevi `{simile}`?" if simile else
            ("Azioni di `" + self.base.nome + "`: " + ", ".join(f"`{n}`" for n in self.base.tutti_i_metodi()) + "."
             if self.base.tutti_i_metodi() else f"`{self.base.nome}` non ha azioni."),
            nome=proprieta)

    def scrivi(self, proprieta: str, valore: Any) -> None:
        self.oggetto.scrivi(proprieta, valore)

    def elenco_proprieta(self) -> list[str]:
        return self.base.tutti_i_metodi()

    def testo_dante(self) -> str:
        return f"<genitore {self.base.nome}>"


class TipoVarianti(OggettoControllo):
    """Il valore di ``tipo Forma è uno di ...``: ``Forma.Cerchio`` dà la variante,
    ``Forma.varianti`` l'elenco dei nomi."""

    NOME_TIPO_DANTE = "tipo"
    E_VALORE_LIBRERIA = True

    def __init__(self, nome: str) -> None:
        self.nome = nome
        self.varianti: dict[str, Any] = {}     # nome -> TipoStruttura o istanza unica
        self.metodi: dict[str, Any] = {}

    @property
    def tipo_controllo(self) -> str:  # type: ignore[override]
        return "tipo"

    def leggi(self, proprieta: str) -> Any:
        if proprieta in self.varianti:
            return self.varianti[proprieta]
        if proprieta == "varianti":
            return list(self.varianti)
        simile = _simile(proprieta, list(self.varianti))
        raise ErroreNome(f"Il tipo `{self.nome}` non ha la variante `{proprieta}`.",
                         suggerimento=f"Forse intendevi `{simile}`?" if simile else
                         "Varianti: " + ", ".join(f"`{n}`" for n in self.varianti) + ".", nome=proprieta)

    def scrivi(self, proprieta: str, valore: Any) -> None:
        raise ErroreValore(f"Le varianti del tipo `{self.nome}` non si possono cambiare.")

    def elenco_proprieta(self) -> list[str]:
        return list(self.varianti)

    def testo_dante(self) -> str:
        return f"<tipo {self.nome}: " + ", ".join(self.varianti) + ">"


def tipo_di_variante(valore: Any) -> TipoVarianti | None:
    """La famiglia (``Forma``) di un valore di una variante, altrimenti None."""
    if isinstance(valore, IstanzaStruttura):
        return valore._tipo.famiglia
    return None


# ===========================================================================
# Costanti bloccate
# ===========================================================================

def _errore_bloccato(nome: str) -> ErroreValore:
    chi = f"`{nome}`" if nome else "Questo valore"
    return ErroreValore(
        f"{chi} è una costante: il suo contenuto non si può cambiare.",
        suggerimento="Se deve cambiare, dichiarala con `variabile` invece di `costante`; "
                     "per lavorare su una copia modificabile scrivi `copia(...)`.")


class ListaBloccata(list):
    """Una lista che non si può modificare (contenuto di una ``costante``)."""

    __slots__ = ("nome_costante",)

    def _no(self, *_a: Any, **_k: Any) -> Any:
        raise _errore_bloccato(self.nome_costante)

    append = extend = insert = remove = pop = clear = sort = reverse = _no
    __setitem__ = __delitem__ = __iadd__ = __imul__ = _no

    def __reduce_ex__(self, protocollo: Any) -> Any:  # copia/pickle: lista normale
        return (list, (list(self),))


class DizionarioBloccato(dict):
    """Un dizionario che non si può modificare (contenuto di una ``costante``)."""

    __slots__ = ("nome_costante",)

    def _no(self, *_a: Any, **_k: Any) -> Any:
        raise _errore_bloccato(self.nome_costante)

    __setitem__ = __delitem__ = __ior__ = _no
    pop = popitem = clear = update = setdefault = _no

    def __reduce_ex__(self, protocollo: Any) -> Any:
        return (dict, (dict(self),))


def e_bloccato(valore: Any) -> bool:
    return isinstance(valore, (ListaBloccata, DizionarioBloccato)) or bool(getattr(valore, "_bloccata", False))


def blocca(valore: Any, nome: str = "", _visti: dict | None = None) -> Any:
    """Copia di sola lettura di ``valore`` (liste, dizionari, strutture, anche
    annidati); gli altri valori restano come sono."""
    if _visti is None:
        _visti = {}
    if isinstance(valore, (ListaBloccata, DizionarioBloccato)):
        return valore
    if isinstance(valore, list):
        if id(valore) in _visti:
            return _visti[id(valore)]
        nuova = ListaBloccata()
        nuova.nome_costante = nome
        _visti[id(valore)] = nuova
        list.extend(nuova, (blocca(x, nome, _visti) for x in valore))
        return nuova
    if isinstance(valore, dict):
        if id(valore) in _visti:
            return _visti[id(valore)]
        nuovo = DizionarioBloccato()
        nuovo.nome_costante = nome
        _visti[id(valore)] = nuovo
        for k, x in valore.items():
            dict.__setitem__(nuovo, k, blocca(x, nome, _visti))
        return nuovo
    if isinstance(valore, IstanzaStruttura):
        if valore._bloccata:
            return valore
        if not valore._valori:      # variante senza dati: e' gia' immutabile
            return valore
        copia = valore._tipo.classe.__new__(valore._tipo.classe)
        copia._tipo = valore._tipo
        copia._bloccata = True
        _visti[id(valore)] = copia
        copia._valori = {k: blocca(x, nome, _visti) for k, x in valore._valori.items()}
        return copia
    return valore


def sblocca(valore: Any, _visti: dict | None = None) -> Any:
    """Copia profonda modificabile (la funzione ``copia`` della libreria)."""
    if _visti is None:
        _visti = {}
    if id(valore) in _visti:
        return _visti[id(valore)]
    if isinstance(valore, list):
        nuova: list = []
        _visti[id(valore)] = nuova
        nuova.extend(sblocca(x, _visti) for x in valore)
        return nuova
    if isinstance(valore, dict):
        nuovo: dict = {}
        _visti[id(valore)] = nuovo
        for k, x in valore.items():
            nuovo[k] = sblocca(x, _visti)
        return nuovo
    if isinstance(valore, IstanzaStruttura):
        if not valore._valori and not valore._tipo.campi:
            return valore
        copia = valore._tipo.classe.__new__(valore._tipo.classe)
        copia._tipo = valore._tipo
        copia._bloccata = False
        _visti[id(valore)] = copia
        copia._valori = {k: sblocca(x, _visti) for k, x in valore._valori.items()}
        return copia
    return valore


def tipo_campo(tipo: str | None) -> Tipo | None:
    return tipo_da_testo(tipo) if tipo else None
