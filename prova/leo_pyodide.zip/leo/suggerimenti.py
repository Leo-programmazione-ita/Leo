"""Suggerimenti per gli errori (docs/CONTRATTI.md §8.2).

Tre fonti, in quest'ordine (PROGETTO.md, *Messaggi di errore*):

0. il TIPO di un controllo scritto al posto del suo nome (``etichetta.testo``
   mentre nella finestra c'e' ``Etichetta1``): "`etichetta` è il tipo di
   controllo, non il suo nome: nella finestra c'è `Etichetta1`...";
1. nomi gia' definiti a distanza di Levenshtein al massimo 2
   (``"forse intendevi `totale` (definito alla riga 3)?"``; per i nomi
   predefiniti, riga 0, senza parentesi);
2. sinonimi e vocabolario delle parole chiave
   (``"Forse intendevi `ripeti`?"``), compresi i piccoli errori di battitura
   su una parola chiave (``mentr`` -> ``mentre``);
3. parole di altri linguaggi (``"In Leo si scrive `stampa`."``), da
   ``dati/altri_linguaggi.toml``;
4. un errore di battitura su una parola del vocabolario (``visualizzs`` ->
   ``stampa``), solo per le parole di almeno 6 lettere.

Il vocabolario porta anche alle funzioni della libreria (``quanti`` ->
``lunghezza``). Per i nomi comuni che potrebbero essere variabili non
dichiarate (``dimensione``) il suggerimento ricorda anche la dichiarazione.

API:
    distanza(a, b) -> int
    simili(nome, candidati, massimo=2) -> list[str]
    suggerisci_nome(nome, nomi_visibili) -> str | None
    suggerisci_metodo(nome_tipo, nome) -> str | None
    parola_chiave_simile(parola) -> str | None
    parola_altro_linguaggio(parola) -> str | None
    carica_altri_linguaggi(percorso=None) -> dict[str, dict[str, str]]
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Iterable

__all__ = [
    "distanza", "distanza_con_scambi", "simili", "suggerisci_nome", "suggerisci_metodo",
    "parola_chiave_simile", "parola_altro_linguaggio", "carica_altri_linguaggi",
    "azzera_cache", "prossima_parola", "parole_chiave_per_completamento", "completa_parola",
    "tipi_di_controllo", "tipo_del_controllo", "tipo_usato_come_nome", "frase_tipo_come_nome",
]


# ---------------------------------------------------------------------------
# Distanze
# ---------------------------------------------------------------------------

def distanza(a: str, b: str) -> int:
    """Distanza di Levenshtein: inserimenti, cancellazioni e sostituzioni."""
    if a == b:
        return 0
    if len(a) < len(b):
        a, b = b, a
    if not b:
        return len(a)
    precedente = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        corrente = [i]
        for j, cb in enumerate(b, 1):
            corrente.append(min(
                precedente[j] + 1,                 # cancellazione
                corrente[j - 1] + 1,               # inserimento
                precedente[j - 1] + (ca != cb),    # sostituzione
            ))
        precedente = corrente
    return precedente[-1]


def distanza_con_scambi(a: str, b: str) -> int:
    """Come :func:`distanza`, ma lo scambio di due lettere vicine costa 1
    (distanza di Damerau-Levenshtein ristretta): ``fien`` -> ``fine`` = 1."""
    if a == b:
        return 0
    la, lb = len(a), len(b)
    if not la or not lb:
        return la or lb
    d = [[0] * (lb + 1) for _ in range(la + 1)]
    for i in range(la + 1):
        d[i][0] = i
    for j in range(lb + 1):
        d[0][j] = j
    for i in range(1, la + 1):
        for j in range(1, lb + 1):
            costo = 0 if a[i - 1] == b[j - 1] else 1
            d[i][j] = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + costo)
            if i > 1 and j > 1 and a[i - 1] == b[j - 2] and a[i - 2] == b[j - 1]:
                d[i][j] = min(d[i][j], d[i - 2][j - 2] + 1)
    return d[la][lb]


def simili(nome: str, candidati: Iterable[str], massimo: int = 2) -> list[str]:
    """Candidati a distanza di Levenshtein da 1 a ``massimo`` da ``nome``.

    Ordinati per distanza, poi in ordine alfabetico. Il nome identico e' escluso,
    come i candidati che differiscono in ogni lettera (``a`` e ``b``: la
    distanza non e' minore della lunghezza del piu' lungo), che non sarebbero
    un suggerimento sensato.
    """
    trovati: list[tuple[int, str]] = []
    visti: set[str] = set()
    for c in candidati:
        if not isinstance(c, str) or c in visti or c == nome:
            continue
        visti.add(c)
        if abs(len(c) - len(nome)) > massimo:
            continue
        d = distanza(nome, c)
        if 1 <= d <= massimo and d < max(len(nome), len(c)):
            trovati.append((d, c))
    trovati.sort()
    return [c for _, c in trovati]


# ---------------------------------------------------------------------------
# Altri linguaggi
# ---------------------------------------------------------------------------

_CACHE_ALTRI: dict[str, dict[str, str]] | None = None


def carica_altri_linguaggi(percorso: str | os.PathLike | None = None) -> dict[str, dict[str, str]]:
    """Legge ``altri_linguaggi.toml`` -> ``{"parole_chiave": {...}, "funzioni": {...}}``.

    Senza ``percorso`` usa ``dati/altri_linguaggi.toml`` e mette in cache il
    risultato. Se il file manca o e' malformato restituisce sezioni vuote.
    """
    global _CACHE_ALTRI
    if percorso is None and _CACHE_ALTRI is not None:
        return _CACHE_ALTRI
    risultato: dict[str, dict[str, str]] = {"parole_chiave": {}, "funzioni": {}}
    try:
        from .tomlutil import carica_toml
        if percorso is None:
            from .percorsi import file_dati
            file = file_dati("altri_linguaggi.toml")
        else:
            file = Path(percorso)
        if file.is_file():
            dati = carica_toml(file)
            for sezione in risultato:
                valori = dati.get(sezione, {})
                if isinstance(valori, dict):
                    risultato[sezione] = {str(k): str(v) for k, v in valori.items()
                                          if isinstance(v, str)}
    except Exception:  # noqa: BLE001 - i suggerimenti non devono mai fallire
        pass
    if percorso is None:
        _CACHE_ALTRI = risultato
    return risultato


def azzera_cache() -> None:
    """Dimentica i dati in cache (altri linguaggi, sinonimi)."""
    global _CACHE_ALTRI, _CACHE_SINONIMI
    _CACHE_ALTRI = None
    _CACHE_SINONIMI = None


def parola_altro_linguaggio(parola: str) -> str | None:
    """Forma Leo di una parola di un altro linguaggio, o None.

    ``"print"`` -> ``"stampa"``, ``"if"`` -> ``"se"``, ``"True"`` -> ``"vero"``,
    ``"console.log"`` -> ``"stampa"``. Si cerca prima la parola esatta, poi
    senza distinguere maiuscole e minuscole.
    """
    if not parola:
        return None
    dati = carica_altri_linguaggi()
    sezioni = (dati.get("parole_chiave", {}), dati.get("funzioni", {}))
    for sezione in sezioni:
        if parola in sezione:
            return sezione[parola]
    minuscola = parola.lower()
    for sezione in sezioni:
        for k, v in sezione.items():
            if k.lower() == minuscola:
                return v
    # parole di altri linguaggi che in Leo sono parole "di contesto": stesse
    # destinazioni della tabella del parser (PAROLE_PER_CONTESTO)
    return _PAROLE_DI_CONTESTO_STRANIERE.get(minuscola)


#: import/switch/match/assert... -> parola di contesto di Leo (vedi parser.PAROLE_PER_CONTESTO).
_PAROLE_DI_CONTESTO_STRANIERE: dict[str, str] = {
    "switch": "scegli", "match": "scegli", "select": "scegli",
    "import": "importa", "include": "importa", "require": "importa", "using": "importa",
    "assert": "verifica",
}


# ---------------------------------------------------------------------------
# Parole chiave
# ---------------------------------------------------------------------------

def _canoniche() -> list[str]:
    from .tokens import COPPIE_DI_PAROLE, PAROLE_CHIAVE
    parole = set(PAROLE_CHIAVE) | {" ".join(k) for k in COPPIE_DI_PAROLE}
    return sorted(parole)


def parola_chiave_simile(parola: str) -> str | None:
    """Parola chiave canonica a un solo errore di battitura da ``parola``.

    Un errore = una lettera in piu', in meno, diversa, o due lettere vicine
    scambiate (``mentr`` -> ``mentre``, ``fien`` -> ``fine``, ``Allora`` ->
    ``allora``). Le parole piu' corte di 3 lettere non vengono confrontate
    (``i`` non deve diventare ``e``). Se ``parola`` e' gia' una parola chiave
    restituisce None.
    """
    if not parola:
        return None
    try:
        canoniche = _canoniche()
    except Exception:  # noqa: BLE001
        return None
    if parola in canoniche or parola == "e'":
        return None
    minuscola = parola.lower()
    if minuscola in canoniche:
        return minuscola
    if len(parola) < 3:
        return None
    trovate = sorted(
        (distanza_con_scambi(minuscola, c), c)
        for c in canoniche
        if len(c) >= 3 and abs(len(c) - len(minuscola)) <= 1
    )
    for d, c in trovate:
        if d == 1:
            return c
        break
    return None


_CACHE_SINONIMI = None


def _canonica_sinonimo(nome: str) -> str | None:
    """Canonica di cui ``nome`` e' un sinonimo ammesso (utile con --rigoroso)."""
    global _CACHE_SINONIMI
    try:
        if _CACHE_SINONIMI is None:
            from .sinonimi import carica_sinonimi
            _CACHE_SINONIMI = carica_sinonimi()
        canonica = _CACHE_SINONIMI.canonica_di(nome)
        if canonica is None and nome != nome.lower():
            canonica = _CACHE_SINONIMI.canonica_di(nome.lower())
        if canonica is None:
            # senza accenti o con `_` al posto degli spazi: `finche`, `nel_caso`
            from .vocabolario import normalizza
            n = normalizza(nome)
            for parole, tipo in _CACHE_SINONIMI.mappa.items():
                if normalizza(" ".join(parole)) == n:
                    return tipo.value
        return canonica
    except Exception:  # noqa: BLE001
        return None


def _altro_linguaggio_esatto(nome: str) -> bool:
    """True se ``nome`` e' scritto esattamente come una parola di altri_linguaggi.toml."""
    dati = carica_altri_linguaggi()
    leo = dati.get("parole_chiave", {}).get(nome) or dati.get("funzioni", {}).get(nome)
    return bool(leo) and leo != nome


def _parola_vocabolario(nome: str) -> str | None:
    try:
        from .vocabolario import vocabolario_predefinito
        return vocabolario_predefinito().parola_chiave_per(nome)
    except Exception:  # noqa: BLE001
        return None


def _sostantivo_vocabolario(nome: str) -> bool:
    """True se ``nome`` e' un nome comune del vocabolario (``dimensione``): puo'
    essere anche una variabile che l'utente ha dimenticato di dichiarare."""
    try:
        from .vocabolario import vocabolario_predefinito
        return vocabolario_predefinito().e_sostantivo(nome)
    except Exception:  # noqa: BLE001
        return False


def _vocabolario_simile(nome: str) -> str | None:
    """Canonica di una parola del vocabolario a un errore di battitura da ``nome``."""
    try:
        from .vocabolario import vocabolario_predefinito
        trovata = vocabolario_predefinito().simile(nome)
    except Exception:  # noqa: BLE001
        return None
    return trovata[1] if trovata else None


def _con_dichiarazione(frase: str, nome: str) -> str:
    """Aggiunge a ``frase`` come dichiarare ``nome``, se e' un nome valido."""
    if not nome.isidentifier():
        return frase
    return f"{frase} Se `{nome}` è una variabile nuova, scrivi `variabile {nome} = ...`."


# ---------------------------------------------------------------------------
# Suggerimenti completi
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Tipo del controllo scritto al posto del nome (`etichetta` per `Etichetta1`)
# ---------------------------------------------------------------------------

_TIPI_CONTROLLO: list[frozenset[str]] = []


def tipi_di_controllo() -> frozenset[str]:
    """Nomi dei tipi di controllo (``Pulsante``, ``Etichetta``...); vuoto se la
    parte grafica non si puo' caricare."""
    if not _TIPI_CONTROLLO:
        try:
            from .grafica.metadati import carica_catalogo

            tipi = frozenset(str(t) for t in carica_catalogo())
        except Exception:  # noqa: BLE001 - grafica assente o rotta: nessun tipo
            tipi = frozenset()
        _TIPI_CONTROLLO.append(tipi)
    return _TIPI_CONTROLLO[0]


def tipo_del_controllo(nome: str, tipi: Iterable[str] | None = None) -> str | None:
    """Il tipo che il nome di un controllo lascia intuire: ``Etichetta1`` ->
    ``Etichetta``, ``PulsanteVai`` -> ``Pulsante``, ``PulsanteImmagine2`` ->
    ``PulsanteImmagine`` (vince il tipo piu' lungo). Dopo il tipo ci vuole
    una cifra o una maiuscola; ``None`` se il nome non ha questa forma."""
    tipi = tipi_di_controllo() if tipi is None else tipi
    migliore = None
    minuscolo = nome.lower()
    for tipo in tipi:
        if len(nome) <= len(tipo) or not minuscolo.startswith(tipo.lower()):
            continue
        seguito = nome[len(tipo)]
        if not (seguito.isdigit() or seguito.isupper()):
            continue
        if migliore is None or len(tipo) > len(migliore):
            migliore = tipo
    return migliore


def tipo_usato_come_nome(nome: str, nomi: Iterable[str],
                         tipi: Iterable[str] | None = None) -> tuple[str, list[str]] | None:
    """Se ``nome`` e' il nome di un TIPO di controllo (``etichetta``,
    ``Pulsante``: maiuscole a parte) e tra ``nomi`` ci sono controlli di quel
    tipo (``Etichetta1``, ``EtichettaSaluto``), restituisce ``(tipo, controlli)``."""
    tipi = list(tipi_di_controllo() if tipi is None else tipi)
    tipo = next((t for t in tipi if t.lower() == (nome or "").lower()), None)
    if tipo is None:
        return None
    controlli = sorted({n for n in nomi if n != nome and tipo_del_controllo(n, tipi) == tipo},
                       key=lambda n: (len(n), n))
    return (tipo, controlli) if controlli else None


def frase_tipo_come_nome(nome: str, controlli: list[str], proprieta: str | None = None) -> str:
    """La frase per il tipo scritto al posto del nome del controllo.

    >>> frase_tipo_come_nome("etichetta", ["Etichetta1"], "testo")
    "`etichetta` è il tipo di controllo, non il suo nome: nella finestra c'è `Etichetta1`. Scrivi `Etichetta1.testo`."
    """
    inizio = f"`{nome}` è il tipo di controllo, non il suo nome: "
    if len(controlli) == 1:
        giusto = controlli[0]
        if proprieta:
            return inizio + f"nella finestra c'è `{giusto}`. Scrivi `{giusto}.{proprieta}`."
        return inizio + f"nella finestra c'è `{giusto}`. Scrivi `{giusto}` al posto di `{nome}`."
    elenco = ", ".join(f"`{c}`" for c in controlli[:-1]) + f" e `{controlli[-1]}`"
    return inizio + f"nella finestra ci sono {elenco}. Scrivi il nome di quello che vuoi usare."


#: Parole chiave che non stanno mai dove l'errore ha trovato un nome sconosciuto.
_NON_AL_POSTO_DI_UN_NOME = frozenset({"come", "in", "e", "o", "non", "è", "allora", "fai", "volte", "di", "da"})


def _somiglianza_debole(nome: str, candidato: str, visibili: dict[str, int]) -> bool:
    """Un nome predefinito che somiglia solo per 2 lettere (``mostra``/``destra``) e' un indizio debole."""
    try:
        definito_dall_utente = int(visibili.get(candidato) or 0) > 0
    except (TypeError, ValueError):
        definito_dall_utente = False
    if definito_dall_utente:
        return False
    return distanza(nome.lower(), candidato.lower()) >= 2


def suggerisci_nome(nome: str, nomi_visibili: dict[str, int]) -> str | None:
    """Suggerimento per un nome non definito, o None.

    >>> suggerisci_nome("tottale", {"totale": 3})
    'forse intendevi `totale` (definito alla riga 3)?'
    """
    if not nome:
        return None
    visibili = nomi_visibili or {}
    # 0. il tipo del controllo al posto del suo nome (`etichetta` per `Etichetta1`)
    try:
        trovato = tipo_usato_come_nome(nome, list(visibili))
    except Exception:  # noqa: BLE001 - un aiuto in piu' non deve rompere l'errore
        trovato = None
    if trovato is not None:
        return frase_tipo_come_nome(nome, trovato[1])
    # 1. nomi gia' definiti
    # nomi corti: con 2 lettere diverse su 3-4 il suggerimento e' casuale (`Red` -> `mcd`)
    candidati = simili(nome, visibili, 1 if len(nome) <= 4 else 2)
    if candidati and _somiglianza_debole(nome, candidati[0], visibili):
        # il vocabolario di Leo prima delle somiglianze deboli: `mostra` e' `stampa`, non `destra`
        dal_vocabolario = _parola_vocabolario(nome)
        if dal_vocabolario and dal_vocabolario not in (nome, candidati[0]) and not _sostantivo_vocabolario(nome):
            return f"Forse intendevi `{dal_vocabolario}`?"
    if candidati:
        scelto = candidati[0]
        try:
            riga = int(visibili.get(scelto) or 0)
        except (TypeError, ValueError):
            riga = 0
        if riga > 0:
            return f"forse intendevi `{scelto}` (definito alla riga {riga})?"
        return f"forse intendevi `{scelto}`?"
    # 2. sinonimi, vocabolario, errori di battitura sulle parole chiave
    if nome == "pass":
        # `pass` di Python: in Leo un blocco puo' restare vuoto
        return "In Leo non serve `pass`: un blocco può restare vuoto, cancella questa riga."
    canonica = _canonica_sinonimo(nome)
    if not canonica and _altro_linguaggio_esatto(nome):
        # `None`, `print`: scritti proprio cosi' sono di un altro linguaggio
        # (senza questo `None` finirebbe su `nonè` -> `non è`)
        return f"In Leo si scrive `{parola_altro_linguaggio(nome)}`."
    if not canonica:
        canonica = _parola_vocabolario(nome)
        if canonica and canonica != nome and _sostantivo_vocabolario(nome):
            # `dimensione`: forse la funzione `lunghezza`, forse una variabile nuova
            return _con_dichiarazione(f"Forse intendevi `{canonica}`?", nome)
    canonica = canonica or parola_chiave_simile(nome)
    if canonica in _NON_AL_POSTO_DI_UN_NOME:
        canonica = None          # `nome` -> `come`: una parola di collegamento non sostituisce mai un nome
    if canonica and canonica != nome:
        return f"Forse intendevi `{canonica}`?"
    # 3. altri linguaggi
    leo = parola_altro_linguaggio(nome)
    if leo and leo != nome:
        return f"In Leo si scrive `{leo}`."
    # 4. un errore di battitura su una parola del vocabolario (`visualizzs`)
    canonica = _vocabolario_simile(nome)
    if canonica and canonica != nome:
        return f"Forse intendevi `{canonica}`?"
    return None


def _metodi_del_tipo(nome_tipo: str) -> list[str]:
    try:
        from . import registro
    except Exception:  # noqa: BLE001
        return []
    if not registro.METODI.get(nome_tipo):
        try:
            registro.carica_libreria()
        except Exception:  # noqa: BLE001 - libreria incompleta
            pass
    return list(registro.METODI.get(nome_tipo, {}))


def suggerisci_metodo(nome_tipo: str, nome: str) -> str | None:
    """Suggerimento per un metodo inesistente su un valore di tipo ``nome_tipo``.

    Prima i metodi del tipo a distanza al massimo 2 (``agiungi`` ->
    ``"forse intendevi `aggiungi`?"``), poi i nomi di altri linguaggi
    (``append`` -> ``"In Leo si scrive `aggiungi`."``).
    """
    if not nome:
        return None
    metodi = _metodi_del_tipo(nome_tipo)
    candidati = simili(nome, metodi, 2)
    if candidati:
        return f"forse intendevi `{candidati[0]}`?"
    leo = parola_altro_linguaggio(nome)
    if leo and leo != nome and (not metodi or leo in metodi):
        return f"In Leo si scrive `{leo}`."
    # `x.lunghezza()` / `x.len()`: in Leo e' una funzione, non un metodo
    for candidata in (nome, leo):
        if candidata and candidata not in metodi and _e_funzione_libreria(candidata):
            return f"`{candidata}` è una funzione, non un metodo: scrivi `{candidata}(valore)`."
    return None


def _e_funzione_libreria(nome: str) -> bool:
    """True se ``nome`` e' una funzione della libreria (``lunghezza``, ``tipo``...)."""
    if not nome.isidentifier():
        return False
    try:
        from . import registro
    except Exception:  # noqa: BLE001
        return False
    if not registro.FUNZIONI:
        try:
            registro.carica_libreria()
        except Exception:  # noqa: BLE001
            pass
    return nome in registro.FUNZIONI


# ---------------------------------------------------------------------------
# Tema "innovazione": prossima parola e completamento (REPL intelligente)
# ---------------------------------------------------------------------------

import re as _re

_TESTI_E_COMMENTI = _re.compile(r'"(?:\\.|[^"\\])*"?|#.*$')


def _riga_pulita(riga: str) -> str:
    """La riga senza testi tra virgolette e commenti, con spazi normalizzati."""
    return " ".join(_TESTI_E_COMMENTI.sub(' "" ', riga).split())


def prossima_parola(riga: str) -> tuple[str, str] | None:
    """La parola che manca in fondo a ``riga`` per completare l'istruzione.

    Restituisce ``(parola, frase)`` oppure None se la riga sembra a posto::

        >>> prossima_parola("se x > 3")
        ('allora', 'dopo `se ...` manca `allora`.')
        >>> prossima_parola("mentre n > 0") [0]
        'fai'

    Serve al REPL (suggerimento dopo Invio e completamento con Tab).
    """
    testo = _riga_pulita(riga)
    if not testo:
        return None
    parole = testo.split(" ")
    prima = parole[0]
    ultima = parole[-1]
    if prima == "altrimenti" and len(parole) >= 2 and parole[1] == "se":
        if len(parole) == 2:
            return ("condizione", "dopo `altrimenti se` scrivi una condizione, poi `allora`.")
        if ultima != "allora":
            return ("allora", "dopo `altrimenti se ...` manca `allora`.")
        return None
    if prima == "se":
        if len(parole) == 1:
            return ("condizione", "dopo `se` scrivi una condizione (per esempio `x > 3`), poi `allora`.")
        if ultima != "allora":
            return ("allora", "dopo `se ...` manca `allora`.")
        return None
    if prima == "mentre":
        if len(parole) == 1:
            return ("condizione", "dopo `mentre` scrivi una condizione, poi `fai`.")
        if ultima != "fai":
            return ("fai", "dopo `mentre ...` manca `fai`.")
        return None
    if prima == "per" and len(parole) >= 2 and parole[1] == "ogni":
        if len(parole) == 2:
            return ("nome", "dopo `per ogni` scrivi il nome di una variabile, poi `in`.")
        if len(parole) == 3:
            return ("in", f"dopo `per ogni {parole[2]}` manca `in`.")
        if parole[3] != "in":
            return ("in", f"dopo `per ogni {parole[2]}` manca `in`.")
        if len(parole) == 4:
            return ("lista", "dopo `in` scrivi una lista o un intervallo (per esempio `1..10`), poi `fai`.")
        if ultima != "fai":
            return ("fai", "dopo `per ogni ... in ...` manca `fai`.")
        return None
    if prima == "ripeti":
        if len(parole) == 1:
            return ("numero", "dopo `ripeti` scrivi quante volte, poi `volte`.")
        if ultima != "volte":
            return ("volte", "dopo `ripeti ...` manca `volte`.")
        return None
    if prima == "quando":
        if len(parole) >= 2 and ultima != "fai":
            return ("fai", "dopo `quando Controllo.evento` manca `fai`.")
        return None
    if prima == "funzione" and len(parole) >= 2 and "(" not in testo:
        return ("(", f"dopo `funzione {parole[1]}` servono le parentesi: `funzione {parole[1]}()`.")
    if prima == "crea" and len(parole) == 1:
        return ("variabile", "dopo `crea` scrivi `variabile` o `costante`.")
    decl = parole[1:] if prima == "crea" else parole
    if decl and decl[0] in ("variabile", "costante"):
        if len(decl) == 1:
            return ("nome", f"dopo `{decl[0]}` scrivi il nome, poi `=` e il valore.")
        if len(decl) == 2 and "=" not in decl[1]:
            return ("=", f"dopo `{decl[0]} {decl[1]}` manca `= valore`.")
    return None


def parole_chiave_per_completamento() -> list[str]:
    """Parole chiave canoniche (anche di due parole, come ``per ogni``) per il Tab del REPL."""
    try:
        return _canoniche()
    except Exception:  # noqa: BLE001
        return ["se", "allora", "altrimenti", "fine", "mentre", "fai", "per ogni", "in",
                "ripeti", "volte", "funzione", "restituisci", "variabile", "costante"]


def completa_parola(prefisso: str, nomi: Iterable[str], *, riga: str = "") -> list[str]:
    """Completamenti per ``prefisso`` (parole chiave, ``nomi`` noti, parola suggerita dal contesto).

    La parola suggerita da :func:`prossima_parola` sulla ``riga`` (se e' una parola
    vera) viene per prima. Risultato ordinato e senza doppioni.
    """
    candidati: list[str] = []
    suggerita = prossima_parola(riga) if riga else None
    if suggerita and suggerita[0].isidentifier() and suggerita[0] not in ("condizione", "nome", "numero", "lista"):
        if suggerita[0].startswith(prefisso):
            candidati.append(suggerita[0])
    altri = set(parole_chiave_per_completamento()) | set(nomi)
    for c in sorted(altri):
        if c.startswith(prefisso) and c not in candidati:
            candidati.append(c)
    return candidati
