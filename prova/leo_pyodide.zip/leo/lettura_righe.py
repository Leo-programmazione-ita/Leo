"""Leo scrive con te: cosa Leo ha capito di ogni riga, mentre scrivi.

Motore condiviso dall'editor del telefono (``leo.editor_telefono`` -> ``app.js``) e
dall'editor di Leo Studio (``leo.studio.qt.editor_codice``). Logica pura: niente Qt,
niente Android, solo la libreria standard e i moduli di Leo.

Per ogni riga Leo dice in italiano che cosa fara'::

    stampa Ciao (nome)            Scrive: Ciao Giulia
    variabile anni = 10           Crea la variabile anni = 10 (intero)
    ripeti 5 volte                Ripete 5 volte il blocco
    se x > 3 allora               Se x > 3 esegue il blocco (ora è vero)
    quando Pulsante1.clic fai     Quando si tocca Pulsante1 esegue il blocco
    se t == segreto allora        Attenzione: t è un testo, segreto è un numero  [Sistema]

e prepara le "pastiglie": le parti calcolate (le parentesi dei comandi senza parentesi,
le graffe dentro le virgolette) e il testo libero dei comandi, che l'editor colora in
modo diverso. I valori si mostrano solo quando si conoscono senza eseguire niente: i
calcoli con numeri, testi e funzioni senza effetti (``radice``, ``lunghezza``...)
sulle variabili il cui valore e' certo in quel punto.

Veloce: ogni riga si analizza una volta sola (cache per testo, ~0,5 ms); il giro sul
programma per i valori e i tipi riusa le analisi e costa pochi microsecondi per riga.
Non solleva mai eccezioni verso l'editor: nel dubbio non dice niente.

Collegamenti con il resto di Leo: :func:`_lettura_esterna` (l'API
:func:`leo.lettura.analizza_riga` della regola "le parentesi vogliono dire CALCOLA",
cioe' il lexer vero) e :func:`_controllo_tipi_esterno` (il controllo statico di
``leo controlla``, :mod:`leo.controllo`). Le forme che il lexer non legge su una riga
sola restano alla lettura interna, costruita sulle stesse regole.

API::

    leggi(codice, righe=None, controlli=None) -> list[Lettura]
    leggi_riga(codice, riga, controlli=None) -> Lettura | None
    firma_al_cursore(codice, riga, colonna) -> Firma | None
    pastiglie_riga(testo) -> list[Pastiglia]
    Lettore(): lo stesso con la sua cache (uno per editor; ``LETTORE`` e' quello comune)
"""

from __future__ import annotations

import re
import threading
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping

from . import nodi as N
from . import operazioni as op

__all__ = [
    "Lettura", "Pastiglia", "Firma", "Correzione", "Lettore", "LETTORE",
    "leggi", "leggi_riga", "firma_al_cursore", "pastiglie_riga", "tipo_restituito", "mentre_scrivi",
    "CMD_TESTO", "CMD_VALORE", "CMD_SENZA",
]

# ---------------------------------------------------------------------------
# comandi (decisioni sul linguaggio, punto 1)
# ---------------------------------------------------------------------------

#: comandi di testo: dopo il nome tutto e' testo; le parentesi tonde calcolano.
CMD_TESTO = frozenset({"stampa", "scrivi", "messaggio", "chiedi", "domanda", "suona", "scrivi_qui"})
#: comandi di valore: valori separati da virgola (numero con unita', calcolo, parole = testo).
CMD_VALORE = frozenset({"avanti", "indietro", "destra", "sinistra", "punta_verso", "vai_a", "cerchio",
                        "colore", "sfondo", "spessore", "riempi", "velocità", "velocita", "attendi",
                        "apri_finestra", "chiudi_finestra", "suona_file", "salva_disegno"})
#: comandi senza valori.
CMD_SENZA = frozenset({"casa", "penna_su", "penna_giu", "penna_giù", "pulisci_disegno", "fine_riempi",
                       "nascondi_tartaruga", "mostra_tartaruga", "colore_casuale", "ferma_suoni",
                       "aspetta_animazioni"})
_CMD_DOPO_UGUALE = frozenset({"chiedi", "domanda"})
_UNITA = {"secondi": 1, "secondo": 1, "millisecondi": 0.001, "millisecondo": 0.001, "ms": 0.001,
          "gradi": 1, "grado": 1, "passi": 1, "passo": 1, "pixel": 1}
_FACCINE = (":", ";", "=", ":-", ";-", "=-", "8-")

#: Funzioni senza effetti che il motore puo' calcolare mentre scrivi.
FUNZIONI_PURE = frozenset({"radice", "assoluto", "arrotonda", "massimo", "minimo", "somma", "media",
                           "lunghezza", "intero", "decimale", "testo", "tipo", "logico", "mcd", "mcm",
                           "intervallo"})
#: Metodi senza effetti dei testi e delle liste.
METODI_PURI = frozenset({"maiuscolo", "minuscolo", "contiene", "inizia_con", "finisce_con", "pulisci",
                         "sostituisci", "dividi", "unisci"})

#: Tipo del valore restituito dalle funzioni piu' usate (il resto si ricava dalla descrizione).
_TIPI_RESTITUITI = {
    "chiedi": "testo", "domanda": "logico", "chiedi_numero": "numero", "casuale": "intero",
    "lunghezza": "intero", "radice": "decimale", "intero": "intero", "decimale": "decimale",
    "testo": "testo", "tipo": "testo", "logico": "logico", "arrotonda": "numero", "assoluto": "numero",
    "massimo": "numero", "minimo": "numero", "somma": "numero", "media": "decimale", "mcd": "intero",
    "mcm": "intero", "ora": "testo", "oggi": "testo", "scegli_a_caso": "valore", "intervallo": "intervallo",
    "colore": "testo", "posizione": "lista", "direzione": "decimale", "maiuscolo": "testo",
    "minuscolo": "testo", "contiene": "logico", "inizia_con": "logico", "finisce_con": "logico",
    "pulisci": "testo", "sostituisci": "testo", "dividi": "lista", "unisci": "testo", "mescola": "lista",
    "ordina": "lista", "vuota": "logico", "stampa": "nulla", "messaggio": "nulla",
}

#: Eventi dei controlli: come si dicono a parole (``{c}`` = nome del controllo).
_EVENTI = {
    "clic": "si tocca {c}", "cambio": "cambia {c}", "selezione": "si sceglie una voce di {c}",
    "invio": "si preme Invio in {c}", "tasto": "si preme un tasto su {c}", "scatto": "scatta {c}",
    "apertura": "si apre {c}", "chiusura": "si chiude {c}", "valido": "{c} diventa valido",
    "errore": "{c} segnala un errore", "fine_riproduzione": "{c} finisce di suonare",
    "risposta": "arriva la risposta di {c}", "pressione": "si preme {c}", "rilascio": "si rilascia {c}",
    "trascina": "si trascina {c}", "collisione": "{c} urta un altro oggetto", "urto": "{c} urta qualcosa",
    "uscita_bordo": "{c} esce dal bordo", "ridimensionamento": "cambia la dimensione di {c}",
    "scorrimento": "si scorre {c}", "movimento": "si muove {c}", "fotogramma": "a ogni fotogramma di {c}",
    "scadenza": "scade {c}", "ricezione": "{c} riceve un messaggio", "connessione": "{c} si collega",
    "lettura": "{c} legge un valore", "codice_letto": "{c} legge un codice",
}

_RE_NOME = re.compile(r"[^\W\d]\w*", re.UNICODE)
_RE_NUMERO = re.compile(r"(-?\d+(?:[.,]\d+)?)(?:[ \t]+([^\W\d]\w*))?", re.UNICODE)
_RE_OGGETTO_METODO = re.compile(r"([A-Z]\w*)\.([^\W\d]\w*)(?=[ \t]|$)", re.UNICODE)
_RE_PROPRIETA_TESTO = re.compile(r"([A-Z]\w*)\.(testo|titolo|suggerimento|segnaposto)[ \t]*=[ \t]*(.*)$", re.UNICODE)
_RE_CHIEDI_DESTRA = re.compile(r"((?:variabile|costante)[ \t]+)?([^\W\d]\w*)[ \t]*=[ \t]*(chiedi|domanda)[ \t]+(.*)$",
                               re.UNICODE | re.IGNORECASE)

_MASSIMO_CACHE = 6000
_MASSIMO_VALORE = 80          # caratteri di un valore mostrati nella frase
_MASSIMA_RIGA = 2000          # righe piu' lunghe: niente analisi (non servono e costano)


# ---------------------------------------------------------------------------
# risultati
# ---------------------------------------------------------------------------

@dataclass
class Pastiglia:
    """Una parte della riga da evidenziare: ``colonna`` da 0 in caratteri, ``lunghezza``.

    ``genere``: ``"calcolo"`` (parentesi che calcolano in un comando senza parentesi),
    ``"graffa"`` (``{nome}`` dentro le virgolette), ``"testo"`` (testo libero di un
    comando: si scrive cosi' com'e'), ``"errore"`` (parentesi che non si possono calcolare).
    """

    colonna: int
    lunghezza: int
    genere: str

    def come_lista(self) -> list:
        return [self.colonna, self.lunghezza, self.genere]


@dataclass
class Correzione:
    """Correzione sicura proposta (la riga nuova passa sempre l'analisi di Leo)."""

    titolo: str
    riga: int
    prima: str
    dopo: str

    def come_dict(self) -> dict:
        return {"titolo": self.titolo, "riga": self.riga, "prima": self.prima, "dopo": self.dopo}


@dataclass
class Lettura:
    """Cosa Leo ha capito della riga ``riga`` (da 1).

    ``frase``: italiano semplice, con i pezzi di codice tra apici inversi.
    ``genere``: ``"azione"``, ``"variabile"``, ``"blocco"``, ``"evento"``, ``"funzione"``,
    ``"chiusura"``, ``"commento"``, ``"avviso"`` (attenzione) o ``"incompleta"``.
    """

    riga: int
    frase: str = ""
    genere: str = ""
    pastiglie: list[Pastiglia] = field(default_factory=list)
    valore: str | None = None
    tipo: str | None = None
    avviso: str = ""
    correzione: Correzione | None = None

    def come_dict(self) -> dict:
        d: dict[str, Any] = {"r": self.riga, "f": self.frase, "g": self.genere}
        if self.pastiglie:
            d["p"] = [p.come_lista() for p in self.pastiglie]
        if self.valore is not None:
            d["v"] = self.valore
        if self.tipo:
            d["t"] = self.tipo
        if self.avviso:
            d["a"] = self.avviso
        if self.correzione is not None:
            d["c"] = self.correzione.come_dict()
        return d


@dataclass
class Firma:
    """Fumetto della funzione di cui si stanno scrivendo gli argomenti."""

    nome: str
    firma: str
    tipo: str = ""
    documentazione: str = ""
    argomento: int = 0
    parametri: list[str] = field(default_factory=list)
    senza_parentesi: bool = False

    def come_dict(self) -> dict:
        return {"nome": self.nome, "firma": self.firma, "tipo": self.tipo, "doc": self.documentazione,
                "arg": self.argomento, "par": self.parametri, "sp": self.senza_parentesi}


# ---------------------------------------------------------------------------
# PUNTO UNICO DI COLLEGAMENTO con gli altri motori (dopo l'unione dei branch)
# ---------------------------------------------------------------------------

_ESTERNI: dict[str, Any] = {}


def _modulo_esterno(nome: str) -> Any:
    if nome not in _ESTERNI:
        try:
            import importlib

            _ESTERNI[nome] = importlib.import_module(nome)
        except Exception:  # noqa: BLE001 - il modulo non c'e' ancora: si usa la lettura interna
            _ESTERNI[nome] = None
    return _ESTERNI[nome]


def _lettura_esterna(testo: str) -> Any:
    """Lettura della riga fatta dal lexer vero (:func:`leo.lettura.analizza_riga`).

    Qui, e solo qui, si collega l'API della regola "le parentesi vogliono dire CALCOLA".
    Si usa per sapere se la riga e' un comando senza parentesi e quali sono le parti
    calcolate: ``(comando, modo, parti)`` con ``modo`` ``"testo"``, ``"valore"`` o ``"senza"``
    e ``parti`` lista di ``(genere, inizio, fine)`` (posizioni da 0 nella riga) con genere
    ``"testo"`` o ``"calcolo"``. Le altre forme (metodi degli oggetti, proprieta' di testo,
    ``variabile x = chiedi ...``, funzioni dell'utente) e le righe che il lexer non legge
    restano alla lettura interna (stesse regole): si torna ``None``.
    """
    modulo = _modulo_esterno("leo.lettura")
    funzione = getattr(modulo, "analizza_riga", None) if modulo is not None else None
    if funzione is None:
        return None
    try:
        r = funzione(testo, 1)
    except Exception:  # noqa: BLE001
        return None
    if r is None:
        return None
    leggi_campo = (lambda k: r.get(k)) if isinstance(r, Mapping) else (lambda k: getattr(r, k, None))
    comando, modo, pezzi = leggi_campo("comando"), leggi_campo("genere"), leggi_campo("parti")
    if not comando or modo not in ("testo", "valore", "senza") or not isinstance(pezzi, (list, tuple)):
        return None
    if modo != "senza" and not pezzi:
        return None
    try:
        parti = []
        for p in pezzi:
            tipo = p.get("tipo") if isinstance(p, Mapping) else getattr(p, "tipo", "")
            colonna = int(p.get("colonna") if isinstance(p, Mapping) else getattr(p, "colonna", 0))
            lunghezza = int(p.get("lunghezza") if isinstance(p, Mapping) else getattr(p, "lunghezza", 0))
            genere = "testo" if tipo == "testo" else "calcolo"        # "numero" e' un calcolo gia' fatto
            parti.append((genere, colonna - 1, colonna - 1 + lunghezza))
        return str(comando), str(modo), parti
    except Exception:  # noqa: BLE001
        return None


#: Codici di ``leo controlla`` che la riga mostra come avviso ("Attento: ..."): tipi, ``nulla``,
#: argomenti, campi, varianti, costanti, contratti e confronti. I nomi sconosciuti no: mentre
#: si scrive una riga a meta' sarebbero solo rumore (li sottolinea gia' l'editor).
CODICI_AVVISO = frozenset({"tipo", "nulla", "argomenti", "campo", "caso", "costante", "contratto",
                           "confronto", "risultato"})


def _controllo_tipi_esterno(codice: str) -> list[tuple[int, str]]:
    """Avvisi del controllo statico (:func:`leo.controllo.controlla`, quello di ``leo controlla``).

    Qui, e solo qui, si collega il controllo dei tipi. Si torna ``[(riga, messaggio)]``.
    """
    modulo = _modulo_esterno("leo.controllo")
    funzione = getattr(modulo, "controlla", None) if modulo is not None else None
    if funzione is None:
        return []
    try:
        rapporto = funzione(codice, "<editor>")
        fuori = []
        for d in getattr(rapporto, "diagnostiche", None) or []:
            if getattr(d, "codice", "") not in CODICI_AVVISO:
                continue
            riga, msg = getattr(d, "riga", None), getattr(d, "messaggio", None)
            if riga and msg:
                fuori.append((int(riga), str(msg)))
        return fuori
    except Exception:  # noqa: BLE001
        return []


# ---------------------------------------------------------------------------
# libreria (caricata una volta, in modo pigro)
# ---------------------------------------------------------------------------

_LIB: dict[str, Any] = {}
_LIB_LOCK = threading.Lock()


def _libreria() -> dict[str, Any]:
    if not _LIB:
        with _LIB_LOCK:
            if not _LIB:
                funzioni: dict = {}
                metodi: dict = {}
                costanti: dict = {}
                firme: dict = {}
                try:
                    from . import registro

                    registro.carica_libreria()
                    funzioni = dict(registro.FUNZIONI)
                    metodi = {t: dict(m) for t, m in registro.METODI.items()}
                    costanti = dict(registro.COSTANTI)
                except Exception:  # noqa: BLE001
                    pass
                try:
                    from . import completamento

                    firme = dict(completamento.funzioni_libreria())
                except Exception:  # noqa: BLE001
                    pass
                _LIB.update(funzioni=funzioni, metodi=metodi, costanti=costanti, firme=firme)
    return _LIB


def tipo_restituito(nome: str, descrizione: str = "") -> str:
    """Tipo del valore che la funzione di libreria ``nome`` restituisce ("" se non si sa)."""
    if nome in _TIPI_RESTITUITI:
        return _TIPI_RESTITUITI[nome]
    d = (descrizione or "").lower()
    if not d:
        firma = _libreria()["firme"].get(nome)
        d = (firma[1] if firma else "").lower()
    if "restituisce `vero`" in d or "(sempre un decimale)" in d:
        return "logico" if "vero" in d else "decimale"
    for inizio, tipo in (("vero se", "logico"), ("`vero` se", "logico"), ("un numero intero", "intero"),
                         ("il numero intero", "intero"), ("un intero", "intero"), ("un decimale", "decimale"),
                         ("il testo", "testo"), ("un testo", "testo"), ("una lista", "lista"),
                         ("la lista", "lista"), ("un dizionario", "dizionario")):
        if d.startswith(inizio):
            return tipo
    return ""


# ---------------------------------------------------------------------------
# lettura del testo libero dei comandi senza parentesi
# ---------------------------------------------------------------------------

def _chiusa_di(testo: str, q: int, limite: int) -> int | None:
    """Indice della ``)`` che chiude la ``(`` in ``q`` (testi tra virgolette saltati)."""
    livello = 0
    k = q
    while k < limite:
        c = testo[k]
        if c == '"':
            k += 1
            while k < limite and testo[k] != '"':
                k += 2 if testo[k] == "\\" else 1
        elif c == "(":
            livello += 1
        elif c == ")":
            livello -= 1
            if livello == 0:
                return k
        k += 1
    return None


def _fine_comando(testo: str, k: int, modo: str) -> int:
    """Fine del tratto del comando: prima di un commento `` #`` e, nei blocchi su una riga,
    prima di ``fine``/``altrimenti`` staccati."""
    q, livello, n = k, 0, len(testo)
    while q < n:
        c = testo[q]
        if c == '"' and modo != "testo":
            q += 1
            while q < n and testo[q] != '"':
                q += 2 if testo[q] == "\\" else 1
        elif c == "(":
            livello += 1
        elif c == ")":
            livello = max(0, livello - 1)
        elif livello == 0:
            staccato = q == k or testo[q - 1] in " \t"
            if c == "#" and staccato and (q + 1 >= n or testo[q + 1] in " \t#["):
                break
            if staccato and c.isalpha():
                m = _RE_NOME.match(testo, q)
                if m and m.group(0) in ("fine", "altrimenti") and q > k:
                    break
        q += 1
    e = min(q, n)
    while e > k and testo[e - 1] in " \t\r":
        e -= 1
    return e


def _parti_testo_libero(testo: str, a: int, b: int) -> list[tuple[str, int, int]]:
    """Divide il testo libero ``testo[a:b]`` in parti ``(genere, inizio, fine)``:
    ``"testo"`` (si scrive cosi' com'e'), ``"calcolo"`` (``(...)`` o ``funzione(...)``),
    ``"errore"`` (parentesi non chiusa)."""
    parti: list[tuple[str, int, int]] = []
    inizio_testo = a
    q = a
    while q < b:
        c = testo[q]
        if c == "(":
            prima = testo[inizio_testo:q]
            if prima.endswith(_FACCINE) and (q + 1 >= b or testo[q + 1] in " \t"):
                q += 1
                continue                       # faccina :( resta testo
            e = _chiusa_di(testo, q, b)
            if e is None:
                if q > inizio_testo:
                    parti.append(("testo", inizio_testo, q))
                parti.append(("errore", q, b))
                return parti
            r = q
            while r > inizio_testo and (testo[r - 1].isalnum() or testo[r - 1] == "_"):
                r -= 1
            nome = testo[r:q]
            da = r if nome and not nome[0].isdigit() else q
            if da > inizio_testo:
                parti.append(("testo", inizio_testo, da))
            parti.append(("calcolo", da, e + 1))
            q = inizio_testo = e + 1
            continue
        q += 1
    if inizio_testo < b:
        parti.append(("testo", inizio_testo, b))
    return parti


def _dividi_virgole(testo: str, a: int, b: int) -> list[tuple[int, int]]:
    pezzi, livello, inizio, q = [], 0, a, a
    while q < b:
        c = testo[q]
        if c == '"':
            q += 1
            while q < b and testo[q] != '"':
                q += 2 if testo[q] == "\\" else 1
        elif c == "(":
            livello += 1
        elif c == ")":
            livello = max(0, livello - 1)
        elif c == "," and livello == 0:
            pezzi.append((inizio, q))
            inizio = q + 1
        q += 1
    pezzi.append((inizio, b))
    pulite = []
    for x, y in pezzi:
        while x < y and testo[x] in " \t":
            x += 1
        while y > x and testo[y - 1] in " \t":
            y -= 1
        pulite.append((x, y))
    return pulite


_PAROLE_LEO = frozenset({
    "se", "altrimenti", "fine", "ripeti", "mentre", "per", "variabile", "costante", "funzione", "restituisci",
    "quando", "prova", "cattura", "infine", "interrompi", "continua", "importa", "ogni", "scegli", "aumenta",
    "diminuisci", "crea", "lancia", "verifica", "tra", "anima", "fai", "mostra"})


def _minuscola_iniziale(parola: str) -> str:
    """``Stampa`` -> ``stampa`` (maiuscola iniziale accettata sulle parole di Leo, non sui nomi)."""
    if not parola[:1].isupper():
        return parola
    piccola = parola[0].lower() + parola[1:]
    if piccola in _PAROLE_LEO or piccola in CMD_TESTO or piccola in CMD_VALORE or piccola in CMD_SENZA:
        return piccola
    if piccola in _libreria()["firme"]:
        return piccola
    return parola


@dataclass
class _Comando:
    """Un comando senza parentesi: ``nome``, ``modo`` e le parti degli argomenti
    (per ogni argomento una lista di ``(genere, inizio, fine)``)."""

    nome: str
    modo: str
    argomenti: list[list[tuple[str, int, int]]]
    oggetto: str = ""
    destinazione: str = ""          # "variabile nome = chiedi ..." -> "nome"
    dichiara: str = ""              # "variabile" / "costante" / ""
    proprieta: str = ""             # "Etichetta1.testo = ..." -> "testo"


def _comando_senza_parentesi(testo: str, inizio: int) -> _Comando | None:
    """La riga (dal primo carattere non spazio ``inizio``) e' un comando senza parentesi?

    Prima la lettura interna (riga per riga, senza contesto: i valori si decidono dopo,
    nel giro sul programma); se non riconosce la riga, il lexer vero
    (:func:`_lettura_esterna`) puo' ancora riconoscere un comando a inizio riga."""
    trovato = _comando_interno(testo, inizio)
    if trovato is not None or inizio != len(testo) - len(testo.lstrip(" \t")):
        return trovato
    esterna = _lettura_esterna(testo)
    if esterna is None:
        return None
    nome, modo, parti = esterna
    if modo == "valore":            # un argomento per pezzo (vai_a 100, 200)
        return _Comando(nome, modo, [[p] for p in parti])
    return _Comando(nome, modo, [parti] if parti else [])


def _comando_interno(testo: str, inizio: int) -> _Comando | None:
    m = _RE_NOME.match(testo, inizio)
    if not m:
        return None
    parola, j = m.group(0), m.end()
    nome = _minuscola_iniziale(parola)
    n = len(testo)
    # Etichetta1.testo = Ciao (nome)  (proprieta' di testo: la regola dei comandi di testo)
    mp = _RE_PROPRIETA_TESTO.match(testo, inizio)
    if mp:
        a = mp.start(3)
        b = _fine_comando(testo, a, "testo")
        resto = testo[a:b]
        if resto and resto[0] != '"' and (_RE_PAROLE_LIBERE.match(resto) or not _sembra_espressione(resto)):
            return _Comando("=", "testo", [_parti_testo_libero(testo, a, b)], oggetto=mp.group(1),
                            proprieta=mp.group(2))
        return None
    # variabile nome = chiedi Come ti chiami?
    mc = _RE_CHIEDI_DESTRA.match(testo, inizio)
    if mc and mc.group(4) and not mc.group(4).startswith(("(", '"')):
        a = mc.start(4)
        b = _fine_comando(testo, a, "testo")
        return _Comando(mc.group(3).lower(), "testo", [_parti_testo_libero(testo, a, b)],
                        destinazione=mc.group(2), dichiara=(mc.group(1) or "").strip().lower())
    # Palla.rimbalza 3 / Finestra1.mostra
    mo = _RE_OGGETTO_METODO.match(testo, inizio)
    if mo:
        k = mo.end()
        while k < n and testo[k] in " \t":
            k += 1
        b = _fine_comando(testo, k, "valore")
        resto = testo[k:b]
        if not resto:
            return _Comando(mo.group(2), "senza", [], oggetto=mo.group(1))
        if resto[0] in "=.[,)*/<>!+%^-(" or resto[:2] == "|>":
            return None
        return _Comando(mo.group(2), "valore", [[("calcolo", x, y)] for x, y in _dividi_virgole(testo, k, b)],
                        oggetto=mo.group(1))
    if nome not in CMD_TESTO and nome not in CMD_VALORE and nome not in CMD_SENZA:
        return None
    k = j
    while k < n and testo[k] in " \t":
        k += 1
    modo = "testo" if nome in CMD_TESTO else "valore" if nome in CMD_VALORE else "senza"
    b = _fine_comando(testo, k, modo)
    resto = testo[k:b]
    if not resto:
        return _Comando(nome, "senza", []) if modo == "senza" and k == j else None
    if k == j:
        return None                              # attaccato: stampa( stampa. stampa= ...
    if resto[0] in "=.[,)*/<>!+%^" or modo == "senza":
        return None
    if resto[0] == "(" and _chiusa_di(testo, k, b) == b - 1:
        return None                              # forma classica: stampa (x), vai_a (1, 2)
    if modo == "testo":
        if resto[0] == '"' and _chiusa_virgolette(resto):
            return _Comando(nome, modo, [[("virgolette", k, b)]])   # stampa "Ciao {nome}": testo esatto
        return _Comando(nome, modo, [_parti_testo_libero(testo, k, b)])
    argomenti = []
    for x, y in _dividi_virgole(testo, k, b):
        pezzo = testo[x:y]
        if not pezzo:
            argomenti.append([])
        elif _RE_NOME.fullmatch(pezzo):
            argomenti.append([("parola", x, y)])       # un nome: valore se e' una variabile, se no testo
        elif _RE_NUMERO.fullmatch(pezzo) or pezzo[0] in '"(' or _sembra_espressione(pezzo):
            argomenti.append([("calcolo", x, y)])
        else:
            argomenti.append(_parti_testo_libero(testo, x, y))
    return _Comando(nome, modo, argomenti)


def _chiusa_virgolette(testo: str) -> bool:
    """``"..."`` occupa tutto il testo?"""
    if len(testo) < 2 or testo[0] != '"':
        return False
    k = 1
    while k < len(testo):
        if testo[k] == "\\":
            k += 2
            continue
        if testo[k] == '"':
            return k == len(testo) - 1
        k += 1
    return False


_RE_PAROLE_LIBERE = re.compile(r"[^\W\d]\w*[ \t]+(?:[^\W\d]|\()", re.UNICODE)
_RE_SOLO_PAROLE = re.compile(r"[^\W\d][\w ]*", re.UNICODE)


def _sembra_espressione(testo: str) -> bool:
    """Un'espressione valida e non un testo di piu' parole (``lato * 2`` e ``x`` si';
    ``verde chiaro`` no)."""
    t = testo.strip()
    if not t:
        return False
    if _RE_SOLO_PAROLE.fullmatch(t) and " " in t:
        return False
    return _nodo_espressione(t) is not None


# ---------------------------------------------------------------------------
# analisi della singola riga (in cache per testo)
# ---------------------------------------------------------------------------

@dataclass
class _Riga:
    testo: str
    rientro: int = 0
    genere: str = "vuota"   # vuota commento fine altrimenti altrimenti_se istruzione comando incompleta
    nodo: Any = None
    comando: _Comando | None = None
    errore: str = ""
    apre: bool = False
    pastiglie: list[Pastiglia] = field(default_factory=list)
    prima_parola: str = ""
    _assegnati: frozenset | None = None
    _mutati: frozenset | None = None
    una_riga: tuple | None = None     # ("se", condizione, allora, altrimenti) / ("ripeti", volte, corpo)

    def assegnati(self) -> frozenset:
        if self._assegnati is None:
            nomi: set = set()
            if self.genere == "istruzione" and self.nodo is not None:
                nomi = _nomi_assegnati(self.nodo)
            elif self.genere == "comando" and self.comando is not None and self.comando.destinazione:
                nomi = {self.comando.destinazione}
            self._assegnati = frozenset(nomi)
        return self._assegnati

    def mutati(self) -> frozenset:
        if self._mutati is None:
            nomi: set = set()
            if self.genere == "istruzione" and self.nodo is not None:
                _nomi_mutati(self.nodo, nomi)
            self._mutati = frozenset(nomi)
        return self._mutati


_cache_nodi: "OrderedDict[str, Any]" = OrderedDict()
_cache_lock = threading.Lock()


def _analizza_sorgente(sorgente: str) -> Any:
    """Programma di Leo per ``sorgente`` (``ErroreDante`` se non va), in cache."""
    with _cache_lock:
        if sorgente in _cache_nodi:
            _cache_nodi.move_to_end(sorgente)
            esito = _cache_nodi[sorgente]
            if isinstance(esito, BaseException):
                raise esito
            return esito
    from .esecuzione import analizza

    try:
        esito: Any = analizza(sorgente, "<riga>")
    except Exception as e:  # noqa: BLE001
        esito = e
    with _cache_lock:
        _cache_nodi[sorgente] = esito
        while len(_cache_nodi) > _MASSIMO_CACHE:
            _cache_nodi.popitem(last=False)
    if isinstance(esito, BaseException):
        raise esito
    return esito


def _nodo_espressione(testo: str) -> Any:
    """Nodo dell'espressione ``testo`` (o None se non e' un'espressione valida)."""
    try:
        programma = _analizza_sorgente("(" + testo + ")")
    except Exception:  # noqa: BLE001
        return None
    from .nodi import IstruzioneEspressione

    istr = programma.istruzioni
    if len(istr) == 1 and isinstance(istr[0], IstruzioneEspressione):
        return istr[0].espressione
    return None


def _senza_commento(testo: str) -> str:
    """La riga senza il commento finale (`` # ...``); i ``#`` nei testi restano."""
    if "#" not in testo:
        return testo
    dentro = False
    k = 0
    while k < len(testo):
        c = testo[k]
        if c == "\\" and dentro:
            k += 2
            continue
        if c == '"':
            dentro = not dentro
        elif c == "#" and not dentro:
            return testo[:k].rstrip()
        k += 1
    return testo


def _pastiglie_graffe(testo: str) -> list[Pastiglia]:
    """Le parti ``{...}`` dentro i testi tra virgolette."""
    fuori: list[Pastiglia] = []
    if '"' not in testo or "{" not in testo:
        return fuori
    dentro = False
    k, n = 0, len(testo)
    while k < n:
        c = testo[k]
        if dentro and c == "\\":
            k += 2
            continue
        if c == '"':
            dentro = not dentro
        elif c == "#" and not dentro:
            break
        elif dentro and c == "{":
            if k + 1 < n and testo[k + 1] == "{":
                k += 2
                continue
            livello, e = 0, k
            while e < n and testo[e] != '"':
                if testo[e] == "{":
                    livello += 1
                elif testo[e] == "}":
                    livello -= 1
                    if livello == 0:
                        break
                e += 1
            if e < n and testo[e] == "}":
                fuori.append(Pastiglia(k, e + 1 - k, "graffa"))
                k = e + 1
                continue
        k += 1
    return fuori


def _pastiglie_comando(cmd: _Comando, testo: str) -> list[Pastiglia]:
    fuori: list[Pastiglia] = []
    for parti in cmd.argomenti:
        for genere, a, b in parti:
            if b <= a or genere in ("parola", "virgolette"):
                continue
            if genere == "calcolo" and cmd.modo == "valore" and len(parti) == 1:
                continue                      # avanti 100: niente pastiglia per un valore semplice
            if genere == "calcolo":
                pezzo = testo[a:b]
                k = pezzo.find("(")
                interno = pezzo[k + 1:-1] if k >= 0 else pezzo
                if k > 0:
                    interno = pezzo           # funzione(...): si prova la chiamata intera
                if interno.strip() and _nodo_espressione(interno.strip()) is None:
                    genere = "errore"
            fuori.append(Pastiglia(a, b - a, genere))
    return fuori


_RE_SE_UNA_RIGA = re.compile(r"se[ \t]+(.+?)[ \t]+allora[ \t]+(.+?)(?:[ \t]+altrimenti[ \t]+(.+?))?[ \t]+fine", re.UNICODE)
_RE_RIPETI_UNA_RIGA = re.compile(r"ripeti[ \t]+(.+?)[ \t]+volte(?:[ \t]+fai)?[ \t]+(.+?)[ \t]+fine", re.UNICODE)
_RE_INTESTAZIONE = re.compile(r"(se|mentre|ripeti|per[ \t]+ogni|ogni|quando|altrimenti[ \t]+se)\b", re.UNICODE)


def _prova_blocco(corpo: str) -> tuple[Any, str]:
    """Analizza la riga come blocco (con ``fine`` aggiunto), con le tolleranze dell'editor:
    ``allora``/``fai`` facoltativi, ``=`` come confronto nelle condizioni."""
    tentativi = [corpo]
    parola = corpo.split(None, 1)[0] if corpo.split() else ""
    if parola in ("se", "altrimenti", "mentre") and not re.search(r"\b(allora|fai)$", corpo):
        tentativi.append(corpo + (" allora" if parola != "mentre" else " fai"))
    if parola in ("ripeti", "per", "ogni", "quando") and not corpo.endswith(" fai"):
        tentativi.append(corpo + " fai")
    if parola in ("se", "mentre", "altrimenti"):
        uguale = re.sub(r"(?<![=!<>])=(?!=)", "==", corpo)
        if uguale != corpo:
            tentativi.append(uguale)
            tentativi.append(uguale + (" allora" if parola != "mentre" else " fai"))
    errore = ""
    for t in tentativi:
        try:
            programma = _analizza_sorgente(t + "\nfine")
            if programma.istruzioni:
                return programma.istruzioni[0], ""
        except Exception as e:  # noqa: BLE001
            errore = errore or _prima_frase(e)
    return None, errore


def _sembra_incompleta(testo: str) -> bool:
    """La riga si sta ancora scrivendo (parentesi o virgolette aperte, operatore in fondo)?"""
    corpo = _senza_commento(testo.strip())
    return (_bilancio(corpo) > 0 or corpo.count('"') % 2 == 1
            or bool(re.search(r"(?:[,(\[{+\-*/=<>.]|\b(?:e|o|non|di|in|a))\s*$", corpo)))


_proposte: "OrderedDict[str, str]" = OrderedDict()


def _proposta_per_riga(testo: str) -> str:
    """La riga corretta che Leo propone per una riga sbagliata ("" se non c'e' o non e' sicura).

    Viene da ``leo.errori_umani`` (tramite ``leo.studio.correzione_riga``) e si propone solo
    se la riga nuova passa l'analisi di Leo (mai una correzione che non funziona)."""
    if testo in _proposte:
        return _proposte[testo]
    nuova = ""
    corpo = testo.strip()
    rientro = testo[:len(testo) - len(testo.lstrip(" \t"))]
    try:
        from .studio import correzione_riga

        for sorgente in (corpo, corpo + "\nfine"):
            try:
                _analizza_sorgente(sorgente)
                break
            except Exception as e:  # noqa: BLE001
                proposta = correzione_riga.da_errore(e, sorgente)
                if proposta is not None and proposta.riga == 1 and proposta.dopo.strip() != corpo:
                    candidata = rientro + proposta.dopo.strip()
                    if _passa_analisi(candidata):
                        nuova = candidata
                        break
    except Exception:  # noqa: BLE001
        nuova = ""
    _proposte[testo] = nuova
    while len(_proposte) > 500:
        _proposte.popitem(last=False)
    return nuova


def _bilancio(testo: str) -> int:
    """Parentesi aperte meno chiuse (fuori dai testi e dai commenti)."""
    if not any(c in testo for c in "([{"):
        return -sum(testo.count(c) for c in ")]}") if any(c in testo for c in ")]}") else 0
    n, dentro, k = 0, False, 0
    while k < len(testo):
        c = testo[k]
        if dentro:
            if c == "\\":
                k += 1
            elif c == '"':
                dentro = False
        elif c == '"':
            dentro = True
        elif c == "#":
            break
        elif c in "([{":
            n += 1
        elif c in ")]}":
            n -= 1
        k += 1
    return n


def _attenzione(messaggio: Any) -> str:
    """``Attenzione: `` + il messaggio con la minuscola (``Non posso`` -> ``non posso``)."""
    m = str(messaggio).strip()
    if len(m) > 1 and m[0].isupper() and m[1].islower():
        m = m[0].lower() + m[1:]
    return "Attenzione: " + m


def _prima_frase(e: BaseException) -> str:
    msg = str(getattr(e, "messaggio", "") or e).strip().split("\n")[0]
    # la riga si analizza da sola: i numeri di riga del messaggio non sono quelli del programma
    return re.sub(r" (?:aperta |iniziat[oa] )?alla riga \d+", "", msg)


def _analizza_riga(testo: str) -> _Riga:
    r = _Riga(testo)
    s = testo.strip()
    r.rientro = len(testo) - len(testo.lstrip(" \t"))
    if not s:
        return r
    if s.startswith("#"):
        r.genere = "commento"
        return r
    if len(testo) > _MASSIMA_RIGA:
        r.genere = "incompleta"
        return r
    r.pastiglie = _pastiglie_graffe(testo)
    corpo = _senza_commento(s)
    m = _RE_NOME.match(corpo)
    prima = _minuscola_iniziale(m.group(0)) if m else ""
    if prima != (m.group(0) if m else ""):
        corpo = prima + corpo[len(prima):]
    r.prima_parola = prima
    if corpo == "fine" or re.fullmatch(r"fine[ \t]+(se|ripeti|mentre|per[ \t]+ogni|funzione|quando|scegli|prova|inizio)", corpo):
        r.genere = "fine"
        return r
    if corpo in ("altrimenti", "altrimenti fai", "altrimenti allora"):
        r.genere = "altrimenti"
        return r
    if corpo == "inizio":
        r.genere, r.apre = "inizio", True
        return r
    if prima == "caso":
        try:
            programma = _analizza_sorgente("scegli _valore\n" + corpo + "\nfine")
            r.genere, r.nodo = "caso", programma.istruzioni[0]
        except Exception as e:  # noqa: BLE001
            r.genere, r.errore = "incompleta", _prima_frase(e)
        return r
    if corpo in ("prova", "infine") or prima == "cattura":
        r.genere = prima
        r.apre = prima == "prova"
        return r
    m1 = _RE_SE_UNA_RIGA.fullmatch(corpo)
    m2 = _RE_RIPETI_UNA_RIGA.fullmatch(corpo) if m1 is None else None
    if m1 or m2:
        r.genere = "una_riga"
        r.una_riga = ("se", m1.group(1), m1.group(2), m1.group(3)) if m1 else ("ripeti", m2.group(1), m2.group(2), None)
        # pastiglie dei comandi senza parentesi dentro il blocco
        m = (_RE_SE_UNA_RIGA if m1 else _RE_RIPETI_UNA_RIGA).search(testo, r.rientro)
        if m is not None:
            for gruppo in ((2, 3) if m1 else (2,)):
                if m.group(gruppo):
                    cmd = _comando_senza_parentesi(testo, m.start(gruppo))
                    if cmd is not None:
                        r.pastiglie += _pastiglie_comando(cmd, testo)
            r.pastiglie.sort(key=lambda p: p.colonna)
        return r
    cmd = _comando_senza_parentesi(testo, r.rientro)
    if cmd is not None:
        r.genere = "comando"
        r.comando = cmd
        r.pastiglie = sorted(r.pastiglie + _pastiglie_comando(cmd, testo), key=lambda p: p.colonna)
        return r
    if prima == "altrimenti" and corpo.startswith("altrimenti se"):
        nodo, errore = _prova_blocco(corpo[len("altrimenti "):])
        r.genere = "altrimenti_se" if nodo is not None else "incompleta"
        r.nodo, r.errore = nodo, errore
        return r
    if re.fullmatch(r"ripeti[ \t]+per[ \t]+sempre(?:[ \t]+fai)?", corpo):
        r.genere, r.apre = "per_sempre", True
        return r
    apre = False
    try:
        from . import colorazione

        apre = colorazione.rientro_dopo(corpo)
    except Exception:  # noqa: BLE001
        apre = False
    if not apre and _RE_INTESTAZIONE.match(corpo) and not re.search(r"\bfine$", corpo):
        apre = True
    if not apre and prima in ("funzione", "scegli", "classe"):
        apre = True
    if apre:
        nodo, errore = _prova_blocco(corpo)
        r.apre = True
        if nodo is not None:
            r.genere, r.nodo = "istruzione", nodo
            return r
        r.genere, r.errore = "incompleta", errore
        return r
    try:
        programma = _analizza_sorgente(corpo)
        if programma.istruzioni:
            r.genere, r.nodo = "istruzione", programma.istruzioni[0]
            return r
    except Exception as e:  # noqa: BLE001
        r.genere, r.errore = "incompleta", _prima_frase(e)
    # restituisci, interrompi, continua, aspettati...: si provano dentro una funzione, un ciclo, una verifica
    if re.search(r"(solo|si usa) dentro", r.errore):
        for involucro in ("funzione _f()\n", "ripeti 1 volte\n", 'verifica "v" fai\n'):
            try:
                programma = _analizza_sorgente(involucro + corpo + "\nfine")
                interno = programma.istruzioni[0].corpo
                if interno:
                    r.genere, r.nodo, r.errore = "istruzione", interno[0], ""
                    break
            except Exception:  # noqa: BLE001
                pass
    return r


# ---------------------------------------------------------------------------
# valori e tipi (senza eseguire niente)
# ---------------------------------------------------------------------------

class _Ignoto(Exception):
    """Il valore non si puo' conoscere senza eseguire."""


class _Problema(Exception):
    """Il calcolo darebbe sicuramente un errore (``messaggio`` in italiano)."""


@dataclass
class _Info:
    valore: Any = None
    noto: bool = False
    tipo: str = ""
    origine: str = ""       # "chiedi" -> testo scritto dall'utente


_NUMERICI = ("intero", "decimale", "numero")


def _tipo_valore(v: Any) -> str:
    from .valori import nome_tipo

    return nome_tipo(v)


def _troppo_grande(v: Any) -> bool:
    if isinstance(v, (str, list)) and len(v) > 10_000:
        return True
    if isinstance(v, int) and not isinstance(v, bool) and v.bit_length() > 20_000:
        return True
    return False


class _Valutatore:
    def __init__(self, amb: Mapping[str, _Info]) -> None:
        self.amb = amb
        self.passi = 0

    def valuta(self, nodo: Any) -> Any:
        self.passi += 1
        if self.passi > 400:
            raise _Ignoto()
        from .errori import ErroreDante

        tipo = type(nodo)
        try:
            if tipo is N.Letterale:
                return nodo.valore
            if tipo is N.Nome:
                info = self.amb.get(nodo.nome)
                if info is not None:
                    if info.noto:
                        return info.valore
                    raise _Ignoto()
                costanti = _libreria()["costanti"]
                if nodo.nome in costanti:
                    return costanti[nodo.nome]
                raise _Ignoto()
            if tipo is N.TestoInterpolato:
                from .valori import rappresenta

                return "".join(p if isinstance(p, str) else rappresenta(self.valuta(p)) for p in nodo.parti)
            if tipo is N.Binaria:
                v = op.binaria(nodo.operatore, self.valuta(nodo.sinistra), self.valuta(nodo.destra))
            elif tipo is N.Unaria:
                v = op.unaria(nodo.operatore, self.valuta(nodo.operando))
            elif tipo is N.Logica:
                sinistra = self.valuta(nodo.sinistra)
                from .valori import verifica_logico

                s = verifica_logico(sinistra, nodo.operatore)
                if nodo.operatore in ("e", "and") and not s:
                    return False
                if nodo.operatore in ("o", "or") and s:
                    return True
                return verifica_logico(self.valuta(nodo.destra), nodo.operatore)
            elif tipo is N.Confronto:
                valori = [self.valuta(x) for x in nodo.operandi]
                v = all(op.confronta(o, valori[i], valori[i + 1]) for i, o in enumerate(nodo.operatori))
            elif tipo is N.ListaLetterale:
                v = [self.valuta(x) for x in nodo.elementi]
            elif tipo is N.DizionarioLetterale:
                from .valori import verifica_chiave

                v = {verifica_chiave(self.valuta(k)): self.valuta(x) for k, x in nodo.coppie}
            elif tipo is N.Intervallo:
                from .valori import crea_intervallo

                v = crea_intervallo(self.valuta(nodo.inizio), self.valuta(nodo.fine))
            elif tipo is N.Indice:
                v = op.leggi_indice(self.valuta(nodo.oggetto), self.valuta(nodo.indice))
            elif tipo is N.Chiamata:
                v = self._chiamata(nodo)
            else:
                raise _Ignoto()
        except (_Ignoto, _Problema):
            raise
        except ErroreDante as e:
            raise _Problema(str(getattr(e, "messaggio", "") or e).split("\n")[0]) from None
        except RecursionError:
            raise _Ignoto() from None
        except Exception:  # noqa: BLE001
            raise _Ignoto() from None
        if _troppo_grande(v):
            raise _Ignoto()
        return v

    def _chiamata(self, nodo: Any) -> Any:
        if any(a.nome or a.espandi for a in nodo.argomenti):
            raise _Ignoto()
        f = nodo.funzione
        lib = _libreria()
        if type(f) is N.Nome and f.nome in FUNZIONI_PURE and f.nome not in self.amb:
            nativa = lib["funzioni"].get(f.nome)
            if nativa is None or getattr(nativa, "vuole_interprete", False):
                raise _Ignoto()
            argomenti = [self.valuta(a.valore) for a in nodo.argomenti]
            return nativa.funzione(*argomenti)
        if type(f) is N.Attributo and f.nome in METODI_PURI:
            oggetto = self.valuta(f.oggetto)
            tipo = _tipo_valore(oggetto)
            nativa = lib["metodi"].get(tipo, {}).get(f.nome)
            if nativa is None or getattr(nativa, "vuole_interprete", False):
                raise _Ignoto()
            argomenti = [self.valuta(a.valore) for a in nodo.argomenti]
            return nativa.funzione(oggetto, *argomenti)
        raise _Ignoto()

    def tipo(self, nodo: Any) -> str:
        """Tipo dell'espressione anche quando il valore non si conosce ("" se non si sa)."""
        try:
            return _tipo_valore(_Valutatore(self.amb).valuta(nodo))
        except (_Ignoto, _Problema):
            pass
        tipo = type(nodo)
        if tipo is N.Nome:
            info = self.amb.get(nodo.nome)
            return info.tipo if info else ""
        if tipo is N.TestoInterpolato:
            return "testo"
        if tipo in (N.Confronto, N.Logica):
            return "logico"
        if tipo is N.ListaLetterale or tipo is N.ListaCompresa:
            return "lista"
        if tipo is N.DizionarioLetterale:
            return "dizionario"
        if tipo is N.Unaria:
            return "logico" if nodo.operatore in ("non", "not") else self.tipo(nodo.operando)
        if tipo is N.Binaria:
            a, b = self.tipo(nodo.sinistra), self.tipo(nodo.destra)
            if nodo.operatore == "/" and a in _NUMERICI and b in _NUMERICI:
                return "decimale"
            if a in _NUMERICI and b in _NUMERICI:
                if nodo.operatore == "//":
                    return "intero"
                return "decimale" if "decimale" in (a, b) else ("intero" if a == b == "intero" else "numero")
            if nodo.operatore == "+" and a == b == "testo":
                return "testo"
            if nodo.operatore == "+" and a == b == "lista":
                return "lista"
            return ""
        if tipo is N.Chiamata:
            if type(nodo.funzione) is N.Nome:
                return tipo_restituito(nodo.funzione.nome)
            if type(nodo.funzione) is N.Attributo:
                return _TIPI_RESTITUITI.get(nodo.funzione.nome, "")
        if tipo is N.Attributo and nodo.nome in ("testo", "titolo"):
            return "testo"
        return ""


def _mostra(v: Any, *, tra_virgolette: bool = True) -> str:
    from .valori import rappresenta

    t = rappresenta(v, dentro=tra_virgolette)
    if len(t) > _MASSIMO_VALORE:
        t = t[:_MASSIMO_VALORE - 1] + "…"
    return t


def _articolo(tipo: str) -> str:
    if tipo in ("lista", "funzione", "data"):
        return "una " + tipo
    if tipo == "numero":
        return "un numero"
    if tipo == "nulla":
        return "nulla"
    return ("un " if tipo else "") + tipo


# ---------------------------------------------------------------------------
# il programma intero: blocchi, variabili, funzioni
# ---------------------------------------------------------------------------

@dataclass
class _Blocco:
    genere: str          # "se", "ripeti", "mentre", "per ogni", "funzione", "quando", "prova", ...
    riga: int
    salvato: dict | None = None
    assegnate: set = field(default_factory=set)


def _codice_di(testo: str, nodo: Any = None) -> str:
    return " ".join(testo.split())


def _nomi_assegnati(nodo: Any) -> set[str]:
    if isinstance(nodo, N.Dichiarazione):
        return set(getattr(nodo, "nomi", None) or [nodo.nome])
    if isinstance(nodo, N.Assegnazione) and type(nodo.bersaglio) is N.Nome:
        return {nodo.bersaglio.nome}
    if isinstance(nodo, N.AssegnazioneMultipla):
        return {b.nome for b in nodo.bersagli if type(b) is N.Nome}
    if isinstance(nodo, N.PerOgni):
        return set(nodo.variabili or [nodo.variabile])
    return set()


def _nomi_mutati(nodo: Any, fuori: set) -> None:
    """Nomi delle liste e dei dizionari che la riga potrebbe cambiare (metodi, indici, funzioni)."""
    if isinstance(nodo, N.Assegnazione) and type(nodo.bersaglio) is N.Indice:
        base = nodo.bersaglio.oggetto
        if type(base) is N.Nome:
            fuori.add(base.nome)
    pila = [nodo]
    visti = 0
    while pila and visti < 500:
        x = pila.pop()
        visti += 1
        if type(x) is N.Chiamata:
            f = x.funzione
            pura = (type(f) is N.Nome and f.nome in FUNZIONI_PURE) or (type(f) is N.Attributo and f.nome in METODI_PURI)
            if not pura:
                if type(f) is N.Attributo and type(f.oggetto) is N.Nome:
                    fuori.add(f.oggetto.nome)
                for arg in x.argomenti:
                    if type(arg.valore) is N.Nome:
                        fuori.add(arg.valore.nome)
        if hasattr(x, "__dataclass_fields__"):
            for nome_campo in x.__dataclass_fields__:
                valore = getattr(x, nome_campo, None)
                if isinstance(valore, list):
                    pila.extend(v for v in valore if hasattr(v, "__dataclass_fields__"))
                elif hasattr(valore, "__dataclass_fields__"):
                    pila.append(valore)


_GENERI_BLOCCO = {N.Se: "se", N.Ripeti: "ripeti", N.Mentre: "mentre", N.PerOgni: "per ogni",
                  N.DefinizioneFunzione: "funzione", N.Evento: "quando", N.Prova: "prova", N.Scegli: "scegli",
                  N.Temporizzatore: "ogni"}


def _genere_blocco(nodo: Any, riga: _Riga) -> str:
    nome = _GENERI_BLOCCO.get(type(nodo))
    if nome:
        return nome
    for classe, nome in _GENERI_BLOCCO.items():
        if isinstance(nodo, classe):
            return nome
    return riga.prima_parola or "blocco"


_RICORSIVO = ("ripeti", "mentre", "per ogni", "ogni")


class Lettore:
    """Il lettore di un editor: tiene le analisi delle righe (per testo) e dell'ultimo programma."""

    def __init__(self) -> None:
        self._assegnate: dict[int, set] = {}
        self._continua: dict[int, int] = {}
        self._importa: set = set()
        self._scelto = ""
        self._mutati: set[str] = set()
        self._righe: "OrderedDict[str, _Riga]" = OrderedDict()
        self._risultati: "OrderedDict[tuple, list]" = OrderedDict()
        self._lock = threading.Lock()

    # --- cache delle righe ---
    def riga(self, testo: str) -> _Riga:
        with self._lock:
            r = self._righe.get(testo)
            if r is not None:
                self._righe.move_to_end(testo)
                return r
        r = _analizza_riga(testo)
        with self._lock:
            self._righe[testo] = r
            while len(self._righe) > _MASSIMO_CACHE:
                self._righe.popitem(last=False)
        return r

    # --- API ---
    def leggi(self, codice: str, righe: Iterable[int] | None = None,
              controlli: Mapping[str, Any] | None = None) -> list[Lettura]:
        """Letture delle ``righe`` (da 1; tutte se None)."""
        try:
            chiave = (codice, None if righe is None else tuple(sorted(set(int(n) for n in righe))))
            with self._lock:
                fatto = self._risultati.get(chiave)
            if fatto is not None:
                return fatto
            fatto = self._leggi(codice, None if chiave[1] is None else chiave[1], controlli)
            with self._lock:
                self._risultati[chiave] = fatto
                while len(self._risultati) > 8:
                    self._risultati.popitem(last=False)
            return fatto
        except Exception:  # noqa: BLE001 - l'editor non deve mai rompersi per un aiuto
            return []

    def leggi_riga(self, codice: str, riga: int, controlli: Mapping[str, Any] | None = None) -> Lettura | None:
        letture = self.leggi(codice, [riga], controlli)
        return letture[0] if letture else None

    def _leggi(self, codice: str, richieste: Iterable[int] | None,
               controlli: Mapping[str, Any] | None) -> list[Lettura]:
        codice = "" if codice is None else str(codice).replace("\r\n", "\n").replace("\r", "\n")
        testi = codice.split("\n")
        voluto = set(range(1, len(testi) + 1)) if richieste is None else {
            int(n) for n in richieste if 1 <= int(n) <= len(testi)}
        if not voluto:
            return []
        ultima = max(voluto)
        analisi = [self.riga(t) for t in testi]
        continua: dict[int, int] = {}       # riga di continuazione -> riga dove comincia l'istruzione
        i = 0
        while i < len(analisi):
            a = analisi[i]
            if a.genere == "incompleta" and _bilancio(a.testo) > 0:
                totale, j = _bilancio(a.testo), i
                while totale > 0 and j + 1 < len(testi) and j - i < 300:
                    j += 1
                    totale += _bilancio(testi[j])
                if totale <= 0 and j > i:
                    unita = self.riga("\n".join(testi[i:j + 1]))
                    if unita.genere != "incompleta":
                        analisi[i] = unita
                        for k in range(i + 1, j + 1):
                            analisi[k] = _Riga(testi[k], genere="continua")
                            continua[k + 1] = i + 1
                        i = j
            i += 1
        self._continua = continua
        self._importa = {"*"} if any(x.prima_parola in ("importa", "usa") for x in analisi) else set()
        # prima passata: funzioni (con o senza restituisci), nomi assegnati nelle funzioni e negli eventi
        funzioni: dict[str, tuple[int, list[str]]] = {}
        con_valore: set[str] = set()
        dentro_corpi: set[str] = set()
        conta: dict[str, int] = {}
        pila_f: list[tuple[str, str]] = []
        aperti: list[tuple[int, set]] = []
        self._assegnate = assegnate_blocchi = {}
        mutati: set[str] = set()
        for i, a in enumerate(analisi):
            nodo = a.nodo
            nomi_riga = a.assegnati()
            if a.genere == "istruzione":
                mutati |= a.mutati()
            if nomi_riga:
                for _k, insieme in aperti:
                    insieme |= nomi_riga
            if a.apre and a.genere != "incompleta" or a.genere in ("per_sempre", "inizio"):
                aperti.append((i + 1, set()))
            elif a.genere == "fine" and aperti:
                k, insieme = aperti.pop()
                assegnate_blocchi[k] = insieme
            if a.genere == "istruzione" and isinstance(nodo, N.DefinizioneFunzione):
                funzioni[nodo.nome] = (i + 1, [p.nome for p in nodo.parametri])
            if a.genere == "istruzione" and isinstance(nodo, N.Restituisci) and nodo.valore is not None:
                for nome_f, _g in reversed(pila_f):
                    if nome_f:
                        con_valore.add(nome_f)
                        break
            if nomi_riga:
                in_corpo = any(g in ("funzione", "quando", "ogni") for _n, g in pila_f) and not (
                    a.genere == "istruzione" and isinstance(nodo, N.Dichiarazione))
                for nome in nomi_riga:
                    conta[nome] = conta.get(nome, 0) + 1
                    if in_corpo:
                        dentro_corpi.add(nome)
            if a.apre and a.genere not in ("incompleta", "per_sempre"):
                g = _genere_blocco(nodo, a)
                pila_f.append((nodo.nome if isinstance(nodo, N.DefinizioneFunzione) else "", g))
            elif a.genere in ("per_sempre", "inizio"):
                pila_f.append(("", "ripeti" if a.genere == "per_sempre" else "inizio"))
            elif a.genere == "fine" and pila_f:
                pila_f.pop()
        for k, insieme in aperti:
            assegnate_blocchi[k] = insieme
        self._mutati = mutati
        avvisi_tipi = dict(_controllo_tipi_esterno(codice)) if richieste is None or len(voluto) > 0 else {}

        # seconda passata: valori e tipi riga per riga
        amb: dict[str, _Info] = {}
        pila: list[_Blocco] = []
        fuori: list[Lettura] = []
        for i, a in enumerate(analisi[:ultima]):
            n = i + 1
            lettura = None
            if n in voluto:
                lettura = Lettura(n, pastiglie=list(a.pastiglie))
            try:
                self._passo(a, n, amb, pila, lettura, funzioni, con_valore, dentro_corpi, conta, controlli, testi)
            except Exception:  # noqa: BLE001
                if lettura is not None and not lettura.frase:
                    lettura.frase = ""
            if lettura is not None:
                if n in avvisi_tipi and not lettura.avviso:
                    lettura.avviso = avvisi_tipi[n]
                    lettura.genere = "avviso"
                fuori.append(lettura)
        return fuori

    # --- un passo del giro ---
    def _passo(self, a: _Riga, n: int, amb: dict, pila: list, out: Lettura | None, funzioni: dict,
               con_valore: set, dentro_corpi: set, conta: dict, controlli: Mapping[str, Any] | None,
               testi: list[str]) -> None:
        g = a.genere
        if g == "vuota":
            return
        if g == "una_riga":
            if out is not None:
                self._una_riga(a, amb, out, funzioni, con_valore, dentro_corpi, conta, controlli, testi, n)
            return
        if g == "continua":
            if out is not None:
                out.frase, out.genere = f"Continua l'istruzione della riga {self._continua.get(n, n - 1)}.", "chiusura"
            return
        if g == "inizio":
            pila.append(_Blocco("inizio", n, salvato=None))
            if out is not None:
                out.frase = "Da qui comincia il programma: Leo esegue questo blocco dopo aver letto le funzioni."
                out.genere = "blocco"
            return
        if g == "caso":
            if pila and pila[-1].salvato is not None:
                b = pila[-1]
                for nome in list(amb):
                    if nome in b.salvato:
                        amb[nome] = b.salvato[nome]
            if out is not None and a.nodo is not None and a.nodo.casi:
                schemi = [_scrivi_espressione(x) for x in a.nodo.casi[0].schemi]
                valore = f"`{self._scelto}`" if getattr(self, "_scelto", "") else "il valore"
                out.frase = f"Se {valore} è " + " o ".join(f"`{x}`" for x in schemi) + ", esegue il blocco."
                out.genere = "blocco"
            return
        if g == "commento":
            if out is not None:
                out.frase, out.genere = "Commento: Leo non lo esegue.", "commento"
            return
        if g == "fine":
            if pila:
                b = pila.pop()
                self._chiudi_blocco(b, amb)
                if out is not None:
                    out.frase = f"Chiude il blocco `{b.genere}` della riga {b.riga}."
                    out.genere = "chiusura"
            elif out is not None:
                out.frase, out.genere = "Questo `fine` non chiude nessun blocco.", "avviso"
            return
        if g in ("altrimenti", "altrimenti_se", "cattura", "infine"):
            if pila and pila[-1].salvato is not None:
                b = pila[-1]
                # ogni ramo parte dai valori di prima del blocco
                for nome in list(amb):
                    if nome in b.salvato:
                        amb[nome] = b.salvato[nome]
                for nome in b.assegnate:
                    if nome in amb:
                        amb[nome] = _Info(tipo=amb[nome].tipo)
            if out is not None:
                if g == "altrimenti":
                    out.frase, out.genere = "Altrimenti (se nessuna condizione sopra è vera) esegue il blocco.", "blocco"
                elif g == "altrimenti_se" and a.nodo is not None:
                    cond = a.nodo.rami[0].condizione
                    out.frase = "Altrimenti, se " + self._condizione(cond, a, amb, out) + ", esegue il blocco."
                    out.genere = out.genere or "blocco"
                elif g == "cattura":
                    m = re.match(r"[ \t]*cattura[ \t]+([A-Z]\w*)", a.testo)
                    quale = f"un `{m.group(1)}`" if m else "un errore"
                    out.frase, out.genere = f"Se nel blocco `prova` c'è {quale}, esegue questo blocco.", "blocco"
                else:
                    out.frase, out.genere = "Esegue questo blocco in ogni caso, alla fine di `prova`.", "blocco"
            return
        if g == "per_sempre":
            b = _Blocco("ripeti", n, salvato=dict(amb), assegnate=self._assegnate.get(n, set()))
            for nome in b.assegnate:
                if nome in amb:
                    amb[nome] = _Info(tipo=amb[nome].tipo)
            pila.append(b)
            if out is not None:
                out.frase, out.genere = "Ripete il blocco per sempre (si ferma con `interrompi` o chiudendo il programma).", "blocco"
            return
        if g == "prova":
            pila.append(_Blocco("prova", n, salvato=dict(amb), assegnate=self._assegnate.get(n, set())))
            if out is not None:
                out.frase, out.genere = "Prova il blocco; se c'è un errore passa a `cattura`.", "blocco"
            return
        if g == "incompleta":
            if a.apre:
                pila.append(_Blocco(a.prima_parola or "blocco", n, salvato=dict(amb)))
            if out is not None:
                parola = a.prima_parola
                if parola in funzioni and parola not in con_valore and parola not in amb:
                    resto = a.testo.strip()[len(parola):].strip()
                    out.frase = f"Esegue la funzione `{parola}` con: {resto}." if resto else f"Esegue la funzione `{parola}`."
                    out.genere = "azione"
                elif _sembra_incompleta(a.testo):
                    errore = a.errore[:1].lower() + a.errore[1:] if a.errore[:2] not in ("Ab", "AB") else a.errore
                    out.frase = "Non ancora completa" + (f": {errore}" if errore else ".")
                    out.genere = "incompleta"
                else:
                    out.frase = "Leo non capisce questa riga."
                    out.avviso = a.errore or "Controlla come è scritta."
                    out.genere = "avviso"
                    nuova = _proposta_per_riga(a.testo)
                    if nuova:
                        out.correzione = Correzione("Correggi", n, a.testo, nuova)
            return
        if g == "comando":
            self._comando(a, a.comando, amb, out, testi[n - 1])
            return
        nodo = a.nodo
        if nodo is None:
            return
        if a.apre:
            self._apri_blocco(a, nodo, n, amb, pila, out, funzioni, con_valore, dentro_corpi, conta, controlli)
            return
        self._istruzione(a, nodo, n, amb, out, funzioni, con_valore, dentro_corpi, conta)

    def _una_riga(self, a, amb, out, funzioni, con_valore, dentro_corpi, conta, controlli, testi, n) -> None:
        """Blocchi su una riga: ``se x > 3 allora stampa Bravo altrimenti stampa Riprova fine``."""
        genere, testa, primo, secondo = a.una_riga

        def leggi_parte(pezzo: str) -> str:
            finta = Lettura(n)
            copia = dict(amb)
            self._passo(self.riga(pezzo), n, copia, [], finta, funzioni, con_valore, dentro_corpi, conta,
                        controlli, testi[:n - 1] + [pezzo] + testi[n:])
            if finta.avviso and not out.avviso:
                out.avviso = finta.avviso
            frase = finta.frase.rstrip(".")
            return frase[:1].lower() + frase[1:] if frase[1:2].islower() else frase

        v = _Valutatore(amb)
        if genere == "se":
            nodo = _nodo_espressione(re.sub(r"(?<![=!<>])=(?!=)", "==", testa))
            cond = f"`{testa}`"
            if nodo is not None:
                cond = self._condizione(nodo, a, amb, out)
            frase = f"Se {cond}: {leggi_parte(primo)}"
            if secondo:
                frase += f"; altrimenti: {leggi_parte(secondo)}"
        else:
            nodo = _nodo_espressione(testa)
            volte = self._valore_o_codice(nodo, a.testo, v) if nodo is not None else f"`{testa}`"
            frase = f"Ripete {volte} volte: {leggi_parte(primo)}"
        out.frase = frase + "."
        out.genere = "avviso" if out.avviso else "blocco"

    def _chiudi_blocco(self, b: _Blocco, amb: dict) -> None:
        if b.salvato is None:
            return
        if b.genere in ("funzione", "quando", "ogni"):
            # le variabili create nel corpo non esistono fuori
            nuovo = dict(b.salvato)
            amb.clear()
            amb.update(nuovo)
            return
        for nome in b.assegnate:
            if nome in amb:
                prima = b.salvato.get(nome)
                tipo = amb[nome].tipo if prima is None or prima.tipo == amb[nome].tipo else ""
                amb[nome] = _Info(tipo=tipo)

    def _apri_blocco(self, a, nodo, n, amb, pila, out, funzioni, con_valore, dentro_corpi, conta, controlli) -> None:
        genere = _genere_blocco(nodo, a)
        b = _Blocco(genere, n, salvato=dict(amb))
        assegnate = set(self._assegnate.get(n, set()))
        b.assegnate = assegnate
        v = _Valutatore(amb)
        if genere in _RICORSIVO:
            # nel ciclo le variabili cambiate dal corpo non hanno un valore certo
            for nome in assegnate:
                if nome in amb:
                    amb[nome] = _Info(tipo=amb[nome].tipo)
        if isinstance(nodo, N.Se):
            cond = nodo.rami[0].condizione
            if out is not None:
                out.frase, out.genere = "Se " + self._condizione(cond, a, amb, out) + " esegue il blocco.", out.genere or "blocco"
        elif isinstance(nodo, N.Ripeti):
            if out is not None:
                volte = self._valore_o_codice(nodo.volte, a.testo, v)
                out.frase, out.genere = f"Ripete {volte} volte il blocco.", "blocco"
        elif isinstance(nodo, N.Mentre):
            if out is not None:
                if type(nodo.condizione) is N.Letterale and nodo.condizione.valore is True:
                    out.frase = "Ripete il blocco per sempre (si ferma con `interrompi`)."
                else:
                    out.frase = "Finché " + self._condizione(nodo.condizione, a, amb, out) + " ripete il blocco."
                out.genere = out.genere or "blocco"
        elif isinstance(nodo, N.PerOgni):
            nomi = nodo.variabili or [nodo.variabile]
            tipo_el = ""
            it = nodo.iterabile
            if type(it) is N.Intervallo:
                da = self._valore_o_codice(it.inizio, a.testo, v)
                fino = self._valore_o_codice(it.fine, a.testo, v)
                frase = f"Ripete il blocco con `{nomi[0]}` da {da} a {fino}."
                tipo_el = "intero"
            else:
                tipo_it = v.tipo(it)
                tipo_el = "testo" if tipo_it == "testo" else ""
                cosa = "carattere" if tipo_it == "testo" else "elemento"
                frase = f"Ripete il blocco per ogni {cosa} di `{self._codice(it, a.testo)}`, che chiama `{', '.join(nomi)}`."
            for nome in nomi:
                amb[nome] = _Info(tipo=tipo_el if len(nomi) == 1 else "")
            if out is not None:
                out.frase, out.genere = frase, "blocco"
        elif isinstance(nodo, N.DefinizioneFunzione):
            # nel corpo: i parametri non hanno valore; delle variabili di fuori resta noto solo
            # il valore di quelle assegnate una volta sola (costanti di fatto)
            for nome in list(amb):
                info = amb[nome]
                if conta.get(nome, 0) > 1 or nome in dentro_corpi:
                    amb[nome] = _Info(tipo=info.tipo)
            for p in nodo.parametri:
                amb[p.nome] = _Info(tipo=p.tipo or (v.tipo(p.predefinito) if p.predefinito is not None else ""))
            if out is not None:
                par = [p.nome for p in nodo.parametri]
                quanti = ("senza argomenti" if not par else
                          f"con l'argomento `{par[0]}`" if len(par) == 1 else
                          f"con {len(par)} argomenti: " + ", ".join(f"`{p}`" for p in par))
                if nodo.nome in con_valore:
                    coda = "restituisce un valore."
                else:
                    esempio = nodo.nome + (" " + ", ".join(par) if par else "")
                    coda = f"si usa come comando (`{esempio}`)."
                out.frase, out.genere = f"Definisce la funzione `{nodo.nome}` {quanti}: {coda}", "funzione"
        elif isinstance(nodo, N.Evento):
            for nome in list(amb):
                if conta.get(nome, 0) > 1 or nome in dentro_corpi:
                    amb[nome] = _Info(tipo=amb[nome].tipo)
            if out is not None:
                modello = _EVENTI.get(nodo.evento, "succede `{e}` su {c}")
                quando = modello.format(c=nodo.controllo, e=nodo.evento)
                out.frase, out.genere = f"Quando {quando} esegue il blocco.", "evento"
        elif isinstance(nodo, N.Temporizzatore):
            for nome in list(amb):
                if conta.get(nome, 0) > 1 or nome in dentro_corpi:
                    amb[nome] = _Info(tipo=amb[nome].tipo)
            if out is not None:
                durata = self._valore_o_codice(nodo.durata, a.testo, v)
                if nodo.ripeti:
                    out.frase = f"Ogni {durata} {nodo.unita} esegue il blocco (mentre il programma continua)."
                else:
                    out.frase = f"Tra {durata} {nodo.unita} esegue il blocco una volta."
                out.genere = "evento"
        elif isinstance(nodo, N.Scegli):
            self._scelto = _scrivi_espressione(nodo.valore)
            if out is not None:
                out.frase = f"Sceglie il blocco giusto secondo il valore di `{self._codice(nodo.valore, a.testo)}`."
                out.genere = "blocco"
        elif out is not None:
            out.frase, out.genere = "Apre un blocco: i comandi sotto, fino a `fine`.", "blocco"
        pila.append(b)

    @staticmethod
    def _corpo(nodo: Any) -> list:
        for nome in ("corpo",):
            c = getattr(nodo, nome, None)
            if isinstance(c, list):
                return c
        rami = getattr(nodo, "rami", None)
        if rami:
            return [i for r in rami for i in r.corpo]
        return []

    def _assegnate_profonde(self, istr: Any) -> set:
        nomi = _nomi_assegnati(istr)
        for sotto in self._corpo(istr):
            nomi |= self._assegnate_profonde(sotto)
        return nomi

    def _codice(self, nodo: Any, testo: str) -> str:
        """Il pezzo di codice di un'espressione, ricostruito in forma semplice."""
        return _scrivi_espressione(nodo)

    def _valore_o_codice(self, nodo: Any, testo: str, v: _Valutatore) -> str:
        try:
            return _mostra(v.valuta(nodo), tra_virgolette=False)
        except (_Ignoto, _Problema):
            return f"`{_scrivi_espressione(nodo)}`"

    def _condizione(self, cond: Any, a: _Riga, amb: dict, out: Lettura) -> str:
        """La condizione come si legge, con il valore se e' certo, e l'avviso dei tipi diversi."""
        v = _Valutatore(amb)
        codice = _scrivi_espressione(cond)
        frase = f"`{codice}`"
        try:
            valore = v.valuta(cond)
            if isinstance(valore, bool):
                frase += " (ora è " + ("vero" if valore else "falso") + ")"
        except _Problema as p:
            out.avviso = _attenzione(p)
            out.genere = "avviso"
        except _Ignoto:
            pass
        self._controlla_confronto(cond, a, amb, out)
        return frase

    def _controlla_confronto(self, cond: Any, a: _Riga, amb: dict, out: Lettura) -> None:
        """Testo confrontato con un numero: sempre diversi. Avviso e, se si puo', [Sistema]."""
        if out is None or type(cond) is not N.Confronto:
            return
        v = _Valutatore(amb)
        for i, operatore in enumerate(cond.operatori):
            sx, dx = cond.operandi[i], cond.operandi[i + 1]
            ts, td = v.tipo(sx), v.tipo(dx)
            if not ts or not td:
                continue
            testo_num = (ts == "testo" and td in _NUMERICI) or (td == "testo" and ts in _NUMERICI)
            if not testo_num:
                continue
            cs, cd = _scrivi_espressione(sx), _scrivi_espressione(dx)
            nome_t, nome_n = (cs, cd) if ts == "testo" else (cd, cs)
            nodo_t = sx if ts == "testo" else dx
            tipo_n = td if ts == "testo" else ts
            if operatore in ("==", "!="):
                esito = "sempre falso" if operatore == "==" else "sempre vero"
                out.avviso = f"Attenzione: `{nome_t}` è un testo, `{nome_n}` un numero: `{operatore}` è {esito}."
            else:
                out.avviso = f"Attenzione: `{nome_t}` è un testo, `{nome_n}` un numero: con `{operatore}` è un errore."
            out.genere = "avviso"
            # correzione sicura: trasformare il testo in numero
            conversione = "intero" if tipo_n == "intero" else "decimale"
            if type(nodo_t) is N.Nome:
                nuova = _sostituisci_nome(a.testo, nome_t, f"{conversione}({nome_t})")
                if nuova and nuova != a.testo and _passa_analisi(nuova):
                    out.correzione = Correzione("Sistema", out.riga, a.testo, nuova)
            return

    # --- istruzioni semplici ---
    def _istruzione(self, a, nodo, n, amb, out, funzioni, con_valore, dentro_corpi, conta) -> None:
        v = _Valutatore(amb)
        if isinstance(nodo, N.Dichiarazione) and not isinstance(nodo, N.DichiarazioneMultipla):
            info = self._info_da(nodo.valore, v, nodo.nome)
            amb[nodo.nome] = info
            if out is not None:
                if not info.noto:
                    info = self._info_da(nodo.valore, v)
                cosa = "la costante" if nodo.costante else "la variabile"
                out.frase = f"Crea {cosa} {nodo.nome} {self._descrivi_valore(nodo.valore, info, v, out)}"
                out.genere = out.genere or "variabile"
                self._riempi_valore(out, info)
            return
        if isinstance(nodo, N.DichiarazioneMultipla):
            for nome in nodo.nomi:
                amb[nome] = _Info()
            if out is not None:
                out.frase = "Crea le variabili " + ", ".join(f"`{x}`" for x in nodo.nomi) + "."
                out.genere = "variabile"
            return
        if isinstance(nodo, N.Assegnazione):
            self._assegnazione(a, nodo, amb, out, v)
            return
        if isinstance(nodo, N.IstruzioneEspressione):
            self._espressione(a, nodo.espressione, amb, out, v, funzioni, con_valore)
            return
        if out is None:
            return
        if isinstance(nodo, N.Restituisci):
            if nodo.valore is None:
                out.frase = "Esce dalla funzione."
            else:
                out.frase = f"Restituisce {self._descrivi_semplice(nodo.valore, v)} a chi ha chiamato la funzione."
            out.genere = "azione"
        elif isinstance(nodo, N.Interrompi):
            out.frase, out.genere = "Esce dal ciclo e continua dopo il suo `fine`.", "azione"
        elif isinstance(nodo, N.Continua):
            out.frase, out.genere = "Salta il resto del blocco e passa al giro successivo del ciclo.", "azione"
        elif isinstance(nodo, N.Importa):
            out.frase = f"Usa il modulo `{nodo.modulo}`" + (f" con il nome `{nodo.alias}`." if nodo.alias else ".")
            out.genere = "azione"
        elif isinstance(nodo, N.Lancia):
            out.frase, out.genere = f"Segnala un errore: {self._descrivi_semplice(nodo.valore, v)}.", "azione"
        elif isinstance(nodo, (N.Se, N.Mentre, N.Ripeti)):
            out.frase, out.genere = "Blocco su una riga.", "blocco"
        elif isinstance(nodo, (N.Verifica, N.Aspettati)):
            out.frase, out.genere = f"Controlla che `{_scrivi_espressione(nodo.condizione)}` sia vero.", "azione"

    def _info_da(self, espr: Any, v: _Valutatore, nome: str = "") -> _Info:
        try:
            valore = v.valuta(espr)
            if nome in self._mutati and isinstance(valore, (list, dict)):
                return _Info(tipo=_tipo_valore(valore))
            return _Info(valore, True, _tipo_valore(valore))
        except (_Ignoto, _Problema):
            pass
        origine = ""
        if type(espr) is N.Chiamata and type(espr.funzione) is N.Nome and espr.funzione.nome in ("chiedi",):
            origine = "chiedi"
        return _Info(tipo=v.tipo(espr), origine=origine)

    @staticmethod
    def _riempi_valore(out: Lettura, info: _Info) -> None:
        if info.noto:
            out.valore = _mostra(info.valore)
        if info.tipo:
            out.tipo = info.tipo

    def _descrivi_valore(self, espr: Any, info: _Info, v: _Valutatore, out: Lettura) -> str:
        tipo = f" ({info.tipo})" if info.tipo else ""
        if info.noto:
            return f"= {_mostra(info.valore)}{tipo}"
        try:
            v.valuta(espr)
        except _Problema as p:
            out.avviso = _attenzione(p)
            out.genere = "avviso"
        except _Ignoto:
            pass
        if type(espr) is N.Chiamata and type(espr.funzione) is N.Nome and espr.funzione.nome in ("chiedi", "domanda"):
            domanda = self._descrivi_semplice(espr.argomenti[0].valore, v) if espr.argomenti else ""
            return f"con la risposta a {domanda}{tipo}" if domanda else f"con la risposta dell'utente{tipo}"
        return f"= `{_scrivi_espressione(espr)}`{tipo}"

    def _descrivi_semplice(self, espr: Any, v: _Valutatore) -> str:
        try:
            return _mostra(v.valuta(espr))
        except (_Ignoto, _Problema):
            return f"`{_scrivi_espressione(espr)}`"

    def _assegnazione(self, a, nodo, amb, out, v) -> None:
        bersaglio = nodo.bersaglio
        if type(bersaglio) is N.Nome:
            nome = bersaglio.nome
            esiste = nome in amb
            if nodo.operatore == "=":
                info = self._info_da(nodo.valore, v, nome)
                if out is not None:
                    tipo_controllo = _tipo_controllo(nome)
                    if not esiste and tipo_controllo:
                        out.frase = f"Mette {self._descrivi_semplice(nodo.valore, v)} in `{nome}`."
                        out.genere = "avviso"
                        out.avviso = (f"Attenzione: `{nome}` è un oggetto della finestra ({tipo_controllo}): "
                                      f"per cambiarne il testo scrivi `{nome}.testo = ...`.")
                        nuova = re.sub(rf"^([ \t]*){re.escape(nome)}[ \t]*=", rf"\g<1>{nome}.testo =", a.testo, count=1)
                        if nuova != a.testo and _passa_analisi(nuova):
                            out.correzione = Correzione("Correggi", out.riga, a.testo, nuova)
                    elif not esiste:
                        out.frase = f"Mette {self._descrivi_semplice(nodo.valore, v)} in `{nome}`."
                        out.genere = "avviso"
                        out.avviso = f"Attenzione: `{nome}` non esiste ancora: per crearla scrivi `variabile {nome} = ...`."
                        nuova = a.testo[:a.rientro] + "variabile " + a.testo[a.rientro:].lstrip()
                        if _passa_analisi(nuova):
                            out.correzione = Correzione("Correggi", out.riga, a.testo, nuova)
                    else:
                        vecchio = amb[nome].tipo
                        out.frase = f"Cambia {nome}: ora vale " + self._descrivi_valore(nodo.valore, info, v, out)[2:]
                        out.genere = out.genere or "variabile"
                        if vecchio and info.tipo and vecchio != info.tipo and not (
                                vecchio in _NUMERICI and info.tipo in _NUMERICI):
                            out.avviso = f"Attenzione: `{nome}` era {_articolo(vecchio)}, ora diventa {_articolo(info.tipo)}."
                            out.genere = "avviso"
                    self._riempi_valore(out, info)
                amb[nome] = info
                return
            # += -= *= /=
            operatore = nodo.operatore[0]
            prima = amb.get(nome, _Info())
            nuovo = _Info(tipo=prima.tipo)
            try:
        
                if prima.noto:
                    valore = op.binaria(operatore, prima.valore, v.valuta(nodo.valore))
                    nuovo = _Info(valore, True, _tipo_valore(valore))
            except (_Ignoto, _Problema):
                pass
            except Exception as e:  # noqa: BLE001
                if out is not None:
                    out.avviso = _attenzione(_prima_frase(e))
                    out.genere = "avviso"
            if out is not None:
                verbo = {"+": "Aumenta", "-": "Diminuisce", "*": "Moltiplica", "/": "Divide"}.get(operatore, "Cambia")
                prep = {"+": "di", "-": "di", "*": "per", "/": "per"}.get(operatore, "con")
                quanto = self._descrivi_semplice(nodo.valore, v)
                out.frase = f"{verbo} {nome} {prep} {quanto}" + (f": ora vale {_mostra(nuovo.valore)}." if nuovo.noto else ".")
                out.genere = out.genere or "variabile"
                if not esiste:
                    out.avviso = f"Attenzione: `{nome}` non esiste ancora."
                    out.genere = "avviso"
                self._riempi_valore(out, nuovo)
            amb[nome] = nuovo
            return
        if out is None:
            return
        valore = self._descrivi_semplice(nodo.valore, v)
        if type(bersaglio) is N.Attributo:
            ogg = _scrivi_espressione(bersaglio.oggetto)
            m = re.match(r"[ \t]*(\w+)\.", a.testo)
            if m and m.group(1).lower() == ogg.lower():
                ogg = m.group(1)
            out.frase = f"{ogg}.{bersaglio.nome} diventa {valore}."
        elif type(bersaglio) is N.Indice:
            out.frase = (f"Mette {valore} in `{_scrivi_espressione(bersaglio.oggetto)}` alla posizione "
                         f"`{_scrivi_espressione(bersaglio.indice)}`.")
        else:
            out.frase = f"Cambia `{_scrivi_espressione(bersaglio)}`: {valore}."
        out.genere = "variabile"

    def _espressione(self, a, espr, amb, out, v, funzioni, con_valore) -> None:
        if out is None:
            return
        if type(espr) is N.Chiamata:
            f = espr.funzione
            if type(f) is N.Nome:
                nome = f.nome
                if nome in funzioni and nome not in _libreria()["firme"]:
                    argomenti = [self._descrivi_semplice(x.valore, v) for x in espr.argomenti]
                    out.frase = f"Esegue la funzione `{nome}`" + (" con " + ", ".join(argomenti) if argomenti else "") + "."
                    out.genere = "azione"
                    return
                valori = [self._testo_argomento(x.valore, v) for x in espr.argomenti if not x.nome]
                if nome in CMD_TESTO:
                    self._frase_testo(nome, " ".join(valori), out)
                    return
                frase = _frase_comando(nome, valori)
                if frase:
                    out.frase, out.genere = frase, "azione"
                    return
                firma = _libreria()["firme"].get(nome)
                if firma:
                    out.frase = f"Esegue `{nome}`: {firma[1]}"
                    out.genere = "azione"
                    try:
                        valore = v.valuta(espr)
                        out.valore = _mostra(valore)
                        out.tipo = _tipo_valore(valore)
                        out.frase = f"Calcola `{_scrivi_espressione(espr)}` = {out.valore}, ma non lo usa."
                    except (_Ignoto, _Problema):
                        pass
                    return
                out.frase = f"Esegue `{nome}`."
                out.genere = "azione"
                simile = _refuso(nome, set(funzioni) | set(_libreria()["firme"]))
                if simile and nome not in v.amb and not self._importa:
                    out.avviso = f"Attenzione: `{nome}` non è una funzione di Leo né del programma: forse `{simile}`?"
                    out.genere = "avviso"
                    nuova = _sostituisci_nome(a.testo, nome, simile)
                    if nuova and _passa_analisi(nuova):
                        out.correzione = Correzione("Correggi", out.riga, a.testo, nuova)
                return
            if type(f) is N.Attributo:
                ogg = _scrivi_espressione(f.oggetto)
                argomenti = [self._descrivi_semplice(x.valore, v) for x in espr.argomenti]
                tipo = v.tipo(f.oggetto)
                if tipo == "lista" and f.nome == "aggiungi" and argomenti:
                    out.frase = f"Aggiunge {argomenti[0]} in fondo alla lista `{ogg}`."
                elif tipo == "lista" and f.nome == "togli" and argomenti:
                    out.frase = f"Toglie {argomenti[0]} dalla lista `{ogg}`."
                else:
                    out.frase = f"Esegue `{f.nome}` su {ogg}" + (" con " + ", ".join(argomenti) if argomenti else "") + "."
                out.genere = "azione"
                return
        if type(espr) is N.Attributo:
            out.frase, out.genere = f"Esegue `{espr.nome}` su {_scrivi_espressione(espr.oggetto)}.", "azione"
            return
        # un calcolo da solo: si mostra il valore
        try:
            valore = v.valuta(espr)
            out.valore, out.tipo = _mostra(valore), _tipo_valore(valore)
            out.frase = f"Calcola `{_scrivi_espressione(espr)}` = {out.valore} ({out.tipo}), ma non lo usa."
        except _Problema as p:
            out.frase, out.avviso = f"Calcola `{_scrivi_espressione(espr)}`.", _attenzione(p)
        except _Ignoto:
            out.frase = f"Calcola `{_scrivi_espressione(espr)}`, ma non lo usa."
        out.genere = out.genere or "azione"

    def _testo_argomento(self, espr: Any, v: _Valutatore) -> str:
        """Come apparira' l'argomento sullo schermo: il valore se si sa, altrimenti ``{codice}``."""
        if type(espr) is N.Binaria and espr.operatore == "+" and "testo" in (v.tipo(espr.sinistra), v.tipo(espr.destra)):
            try:
                return _mostra(v.valuta(espr), tra_virgolette=False)
            except (_Ignoto, _Problema):
                return self._testo_argomento(espr.sinistra, v) + self._testo_argomento(espr.destra, v)
        if type(espr) is N.TestoInterpolato:
            pezzi = []
            for p in espr.parti:
                if isinstance(p, str):
                    pezzi.append(p)
                else:
                    pezzi.append(self._testo_argomento(p, v))
            return "".join(pezzi)
        try:
            return _mostra(v.valuta(espr), tra_virgolette=False)
        except (_Ignoto, _Problema):
            return "{" + _scrivi_espressione(espr) + "}"

    @staticmethod
    def _frase_testo(nome: str, testo: str, out: Lettura) -> None:
        testo = testo if len(testo) <= 2 * _MASSIMO_VALORE else testo[:2 * _MASSIMO_VALORE - 1] + "…"
        if nome in ("stampa", "scrivi"):
            out.frase = f"Scrive: {testo}" if testo else "Scrive una riga vuota."
        elif nome == "messaggio":
            out.frase = f"Mostra il messaggio: {testo}"
        elif nome == "chiedi":
            out.frase = f"Chiede: {testo} (la risposta non si salva: usa `variabile risposta = chiedi ...`)"
        elif nome == "domanda":
            out.frase = f"Chiede sì o no: {testo}"
        elif nome == "suona":
            out.frase = f"Suona: {testo}"
        elif nome == "scrivi_qui":
            out.frase = f"Scrive sul foglio: {testo}"
        out.genere = out.genere or "azione"

    # --- comandi senza parentesi ---
    def _comando(self, a: _Riga, cmd: _Comando, amb: dict, out: Lettura | None, testo: str) -> None:
        v = _Valutatore(amb)
        if cmd.destinazione:
            domanda = self._testo_libero(cmd.argomenti[0] if cmd.argomenti else [], testo, v, out)
            tipo = "logico" if cmd.nome == "domanda" else "testo"
            amb[cmd.destinazione] = _Info(tipo=tipo, origine="chiedi")
            if out is not None:
                cosa = "Crea la costante" if cmd.dichiara == "costante" else "Crea la variabile" if cmd.dichiara else "Cambia"
                quale = "sì o no" if cmd.nome == "domanda" else "la risposta"
                out.frase = f"{cosa} {cmd.destinazione} con {quale} a: {domanda} ({tipo})"
                out.genere = "variabile"
                out.tipo = tipo
            return
        if out is None:
            return
        if cmd.proprieta:
            valore = self._testo_libero(cmd.argomenti[0], testo, v, out)
            out.frase, out.genere = f"{cmd.oggetto}.{cmd.proprieta} diventa: {valore}", "azione"
            return
        if cmd.oggetto:
            argomenti = [self._testo_libero(p, testo, v, out) for p in cmd.argomenti]
            out.frase = f"Esegue `{cmd.nome}` su {cmd.oggetto}" + (" con " + ", ".join(argomenti) if argomenti else "") + "."
            out.genere = "azione"
            return
        if cmd.modo == "testo":
            self._frase_testo(cmd.nome, self._testo_libero(cmd.argomenti[0] if cmd.argomenti else [], testo, v, out), out)
            # stampa 3 + 4: e' testo; se sembra un calcolo, Leo propone le parentesi
            parti = cmd.argomenti[0] if cmd.argomenti else []
            if len(parti) == 1 and parti[0][0] == "testo":
                grezzo = testo[parti[0][1]:parti[0][2]]
                if re.search(r"\d\s*[-+*/^]\s*[\d(]", grezzo) and _nodo_espressione(grezzo) is not None:
                    nodo = _nodo_espressione(grezzo)
                    try:
                        calcolato = _mostra(_Valutatore(amb).valuta(nodo), tra_virgolette=False)
                    except (_Ignoto, _Problema):
                        calcolato = ""
                    nuova = testo[:parti[0][1]] + "(" + grezzo + ")" + testo[parti[0][2]:]
                    out.avviso = (f"Qui `{grezzo}` è testo. Per calcolarlo mettilo tra parentesi"
                                  + (f": scriverà {calcolato}." if calcolato else "."))
                    out.genere = "avviso"
                    if _passa_analisi(nuova):
                        out.correzione = Correzione("Calcola", out.riga, testo, nuova)
            return
        if cmd.modo == "senza":
            out.frase = _frase_comando(cmd.nome, []) or f"Esegue `{cmd.nome}`."
            out.genere = "azione"
            return
        valori = [self._testo_libero(p, testo, v, out, valore=True) for p in cmd.argomenti]
        out.frase = _frase_comando(cmd.nome, valori) or f"Esegue `{cmd.nome}` con " + ", ".join(valori) + "."
        out.genere = out.genere or "azione"

    def _testo_libero(self, parti: list, testo: str, v: _Valutatore, out: Lettura | None, *, valore: bool = False) -> str:
        pezzi = []
        for genere, a, b in parti:
            pezzo = testo[a:b]
            if genere == "testo":
                pezzi.append(pezzo)
                continue
            if genere == "virgolette":
                nodo = _nodo_espressione(pezzo)
                if nodo is not None:
                    pezzi.append(self._testo_argomento(nodo, v))
                else:
                    pezzi.append(pezzo)
                continue
            if genere == "parola":
                if pezzo in v.amb or pezzo in _libreria()["costanti"]:
                    genere = "calcolo"
                else:
                    pezzi.append(pezzo)
                    continue
            if genere == "errore":
                if out is not None:
                    out.avviso = ("Attenzione: la parentesi `(` non è chiusa. Dopo un comando le parentesi "
                                  "calcolano; per scriverle così come sono metti la frase tra virgolette.")
                    out.genere = "avviso"
                pezzi.append(pezzo)
                continue
            m = _RE_NUMERO.fullmatch(pezzo) if valore else None
            if m:
                numero = m.group(1).replace(",", ".")
                pezzi.append(numero + (" " + m.group(2) if m.group(2) else ""))
                continue
            nodo = _nodo_espressione(pezzo)
            if nodo is None:
                if out is not None:
                    out.avviso = (f"Attenzione: `{pezzo}` non si può calcolare. Dopo un comando le parentesi "
                                  "calcolano; per scriverle così come sono metti la frase tra virgolette.")
                    out.genere = "avviso"
                pezzi.append(pezzo)
                continue
            try:
                pezzi.append(_mostra(v.valuta(nodo), tra_virgolette=False))
            except _Problema as p:
                if out is not None:
                    out.avviso = _attenzione(p)
                    out.genere = "avviso"
                pezzi.append("{" + _scrivi_espressione(nodo) + "}")
            except _Ignoto:
                pezzi.append("{" + _scrivi_espressione(nodo) + "}")
        return "".join(pezzi).strip()


def _frase_comando(nome: str, valori: list[str]) -> str:
    """Frase per i comandi della tartaruga, dei suoni e delle finestre."""
    def arg(i: int, predefinito: str = "") -> str:
        return valori[i] if i < len(valori) and valori[i] else predefinito

    def con_unita(x: str, unita: str) -> str:
        return x if re.search(r"[^\W\d]", x.split()[-1] if x.split() else "") and not x.startswith("`") else f"{x} {unita}"

    nome = "velocità" if nome == "velocita" else "penna_giù" if nome == "penna_giu" else nome
    tabella = {
        "avanti": lambda: f"La tartaruga va avanti di {con_unita(arg(0, '100'), 'passi')}.",
        "indietro": lambda: f"La tartaruga va indietro di {con_unita(arg(0, '100'), 'passi')}.",
        "destra": lambda: f"La tartaruga gira a destra di {con_unita(arg(0, '90'), 'gradi')}.",
        "sinistra": lambda: f"La tartaruga gira a sinistra di {con_unita(arg(0, '90'), 'gradi')}.",
        "vai_a": lambda: f"La tartaruga va al punto ({arg(0, 'x')}, {arg(1, 'y')}).",
        "punta_verso": lambda: f"La tartaruga guarda verso {con_unita(arg(0), 'gradi')}.",
        "cerchio": lambda: f"Disegna un cerchio di raggio {arg(0, '50')}" + (f" ({arg(1)} gradi)." if arg(1) else "."),
        "colore": lambda: f"Colore della penna: {arg(0)}.",
        "sfondo": lambda: f"Colore dello sfondo: {arg(0)}.",
        "spessore": lambda: f"Spessore della penna: {arg(0)}.",
        "riempi": lambda: f"Da qui riempie le figure con il colore {arg(0)}.",
        "velocità": lambda: f"Velocità della tartaruga: {arg(0)}.",
        "attendi": lambda: f"Aspetta {con_unita(arg(0, '1'), 'secondi')}.",
        "apri_finestra": lambda: f"Apre la finestra {arg(0)}.",
        "chiudi_finestra": lambda: f"Chiude la finestra {arg(0)}." if arg(0) else "Chiude la finestra.",
        "suona_file": lambda: f"Suona il file {arg(0)}.",
        "salva_disegno": lambda: f"Salva il disegno nel file {arg(0, 'disegno.svg')}.",
        "casa": lambda: "La tartaruga torna al centro, senza disegnare.",
        "penna_su": lambda: "Alza la penna: la tartaruga si muove senza disegnare.",
        "penna_giù": lambda: "Abbassa la penna: la tartaruga disegna mentre cammina.",
        "pulisci_disegno": lambda: "Cancella il disegno.",
        "fine_riempi": lambda: "Finisce di riempire la figura.",
        "nascondi_tartaruga": lambda: "Nasconde la tartaruga.",
        "mostra_tartaruga": lambda: "Mostra la tartaruga.",
        "colore_casuale": lambda: "Sceglie un colore a caso per la penna.",
        "ferma_suoni": lambda: "Ferma tutti i suoni.",
        "aspetta_animazioni": lambda: "Aspetta che finiscano le animazioni.",
    }
    f = tabella.get(nome)
    return f() if f else ""


# ---------------------------------------------------------------------------
# espressioni riscritte in forma semplice (per le frasi)
# ---------------------------------------------------------------------------

_PRIORITA = {"o": 1, "or": 1, "e": 2, "and": 2, "cmp": 4, "..": 5, "+": 6, "-": 6, "*": 7, "/": 7, "//": 7,
             "%": 7, "^": 9}


def _scrivi_espressione(nodo: Any, livello: int = 0) -> str:
    t = type(nodo)
    try:
        if t is N.Letterale:
            from .valori import rappresenta

            return rappresenta(nodo.valore, dentro=True)
        if t is N.Nome:
            return nodo.nome
        if t is N.TestoInterpolato:
            pezzi = []
            for p in nodo.parti:
                pezzi.append(p.replace('"', '\\"') if isinstance(p, str) else "{" + _scrivi_espressione(p) + "}")
            return '"' + "".join(pezzi) + '"'
        if t is N.Binaria:
            p = _PRIORITA.get(nodo.operatore, 6)
            s = f"{_scrivi_espressione(nodo.sinistra, p)} {nodo.operatore} {_scrivi_espressione(nodo.destra, p + 1)}"
            return f"({s})" if p < livello else s
        if t is N.Unaria:
            op = nodo.operatore
            return (op + " " if op.isalpha() else op) + _scrivi_espressione(nodo.operando, 8)
        if t is N.Logica:
            p = _PRIORITA.get(nodo.operatore, 1)
            s = f"{_scrivi_espressione(nodo.sinistra, p)} {nodo.operatore} {_scrivi_espressione(nodo.destra, p + 1)}"
            return f"({s})" if p < livello else s
        if t is N.Confronto:
            pezzi = [_scrivi_espressione(nodo.operandi[0], 5)]
            for o, x in zip(nodo.operatori, nodo.operandi[1:]):
                pezzi.append(f"{o} {_scrivi_espressione(x, 5)}")
            s = " ".join(pezzi)
            return f"({s})" if 4 < livello else s
        if t is N.Chiamata:
            argomenti = []
            for a in nodo.argomenti:
                x = _scrivi_espressione(a.valore)
                argomenti.append(f"{a.nome} = {x}" if a.nome else x + ("..." if a.espandi else ""))
            return f"{_scrivi_espressione(nodo.funzione, 10)}({', '.join(argomenti)})"
        if t is N.Attributo:
            return f"{_scrivi_espressione(nodo.oggetto, 10)}.{nodo.nome}"
        if t is N.Indice:
            return f"{_scrivi_espressione(nodo.oggetto, 10)}[{_scrivi_espressione(nodo.indice)}]"
        if t is N.ListaLetterale:
            return "[" + ", ".join(_scrivi_espressione(x) for x in nodo.elementi) + "]"
        if t is N.Intervallo:
            return f"{_scrivi_espressione(nodo.inizio, 6)}..{_scrivi_espressione(nodo.fine, 6)}"
        if t is N.DizionarioLetterale:
            return "{" + ", ".join(f"{_scrivi_espressione(k)}: {_scrivi_espressione(x)}" for k, x in nodo.coppie) + "}"
    except Exception:  # noqa: BLE001
        pass
    return "…"


def _tipo_controllo(nome: str) -> str:
    """Tipo di oggetto della finestra dal nome (``Etichetta1`` -> ``Etichetta``), solo per i nomi
    con la maiuscola che finiscono con un numero o hanno un nome di tipo davanti."""
    if not nome[:1].isupper():
        return ""
    try:
        from . import completamento

        return completamento.tipo_da_nome(nome) or ""
    except Exception:  # noqa: BLE001
        return ""


def _refuso(nome: str, noti: set) -> str:
    """Il nome noto che ``nome`` sembra voler dire (un refuso: ``stmpa`` -> ``stampa``), o ""."""
    import difflib

    if len(nome) < 3 or nome in noti:
        return ""
    vicini = difflib.get_close_matches(nome, list(noti), n=2, cutoff=0.8)
    if not vicini or (len(vicini) > 1 and difflib.SequenceMatcher(None, nome, vicini[1]).ratio() >= 0.8
                      and vicini[1][:1] == vicini[0][:1]):
        return vicini[0] if len(vicini) == 1 else ""
    return vicini[0]


def _sostituisci_nome(testo: str, nome: str, nuovo: str) -> str:
    """Sostituisce il nome (parola intera, fuori dai testi) con ``nuovo`` una volta."""
    dentro = False
    k = 0
    while k < len(testo):
        c = testo[k]
        if c == '"':
            dentro = not dentro
        elif not dentro and testo.startswith(nome, k):
            prima = testo[k - 1] if k else " "
            dopo = testo[k + len(nome)] if k + len(nome) < len(testo) else " "
            if not (prima.isalnum() or prima in "_.") and not (dopo.isalnum() or dopo == "_"):
                return testo[:k] + nuovo + testo[k + len(nome):]
        k += 1
    return ""


def _passa_analisi(riga: str) -> bool:
    """La riga passa l'analisi di Leo? (validazione centrale: leo.correttore_sicuro).

    Prova la riga da sola e dentro le incorniciature minime (blocco da chiudere
    con ``fine``, ramo ``altrimenti``/``caso``, ``restituisci`` in una funzione),
    così accetta anche le righe lecite solo dentro un blocco."""
    try:
        from .correttore_sicuro import riga_valida

        return riga_valida(riga)
    except Exception:  # noqa: BLE001
        corpo = riga.strip()
        if corpo.startswith("altrimenti se "):
            corpo = corpo[len("altrimenti "):]
        for prova in (corpo, corpo + "\nfine"):
            try:
                _analizza_sorgente(prova)
                return True
            except Exception:  # noqa: BLE001
                pass
        return False


# ---------------------------------------------------------------------------
# pastiglie e firma
# ---------------------------------------------------------------------------

def pastiglie_riga(testo: str) -> list[Pastiglia]:
    """Le pastiglie della riga (senza contesto): graffe nei testi, testo libero e calcoli dei comandi."""
    return list(LETTORE.riga(testo).pastiglie)


def _parametri(firma: str) -> list[str]:
    a, b = firma.find("("), firma.rfind(")")
    if a < 0 or b <= a:
        return []
    interno = firma[a + 1:b]
    pezzi, livello, inizio = [], 0, 0
    for i, c in enumerate(interno):
        if c in "([{":
            livello += 1
        elif c in ")]}":
            livello -= 1
        elif c == '"':
            pass
        elif c == "," and livello == 0:
            pezzi.append(interno[inizio:i].strip())
            inizio = i + 1
    if interno.strip():
        pezzi.append(interno[inizio:].strip())
    return pezzi


def firma_al_cursore(codice: str, riga: int, colonna: int, *, funzioni_utente: Mapping[str, str] | None = None) -> Firma | None:
    """Firma, tipo e documentazione della funzione di cui si scrivono gli argomenti.

    ``colonna`` da 1 in caratteri. Vale per le chiamate con le parentesi
    (``casuale(1, |``) e per i comandi senza parentesi (``avanti |``).
    """
    try:
        righe = (codice or "").replace("\r\n", "\n").split("\n")
        if not 1 <= riga <= len(righe):
            return None
        testo = righe[riga - 1]
        prima = testo[:max(0, colonna - 1)]
        from . import completamento as c

        lib = _libreria()
        utente = dict(funzioni_utente or {})
        if not utente:
            for t in righe:
                m = re.match(r"[ \t]*funzione[ \t]+([^\W\d]\w*)[ \t]*(\([^)]*\))?", t)
                if m:
                    utente[m.group(1)] = m.group(1) + (m.group(2) or "()")
        chiamata = c.chiamata_in_corso(prima)
        senza = False
        if chiamata is None:
            m = re.match(r"[ \t]*([^\W\d]\w*)[ \t]+(.*)$", prima)
            if not m:
                return None
            nome = _minuscola_iniziale(m.group(1))
            if nome not in CMD_TESTO and nome not in CMD_VALORE:
                return None
            resto = m.group(2)
            if nome in CMD_TESTO and resto.strip():
                return None                      # si sta scrivendo il testo: il fumetto darebbe fastidio
            if resto.startswith("(") and _chiusa_di(resto, 0, len(resto)) is None and nome in CMD_VALORE:
                pass
            argomento = resto.count(",") if nome in CMD_VALORE else 0
            chiamata = (nome, argomento)
            senza = True
        nome, argomento = chiamata
        firma, doc = "", ""
        if nome in utente:
            firma, doc = utente[nome], "Funzione del tuo programma."
        elif nome in lib["firme"]:
            firma, doc = lib["firme"][nome]
        else:
            try:
                metodi = c.metodi_valori()
                if nome in metodi:
                    firma, doc = metodi[nome][0], metodi[nome][1]
            except Exception:  # noqa: BLE001
                pass
        if not firma:
            return None
        doc = (doc[:1].upper() + doc[1:]) if doc else ""
        return Firma(nome, firma, tipo_restituito(nome, doc) if nome not in utente else "", doc,
                     max(0, int(argomento or 0)), _parametri(firma), senza)
    except Exception:  # noqa: BLE001
        return None


def mentre_scrivi(lettura: Lettura | None, firma: Firma | None) -> Lettura | None:
    """Mentre si scrivono gli argomenti di una chiamata la riga e' incompleta per forza:
    al posto di "Non ancora completa" Leo dice che cosa si sta scrivendo."""
    if lettura is None or firma is None or lettura.genere != "incompleta" or firma.senza_parentesi:
        return lettura
    par = firma.parametri[firma.argomento] if firma.argomento < len(firma.parametri) else ""
    from dataclasses import replace

    frase = (f"Stai scrivendo gli argomenti di `{firma.nome}`"
             + (f" (ora `{par.split('=')[0].strip()}`)" if par else "") + "; poi chiudi con `)`.")
    return replace(lettura, frase=frase, genere="azione")       # copia: le letture in cache restano com'erano


#: Il lettore comune (telefono, prove); Leo Studio ne crea uno per editor.
LETTORE = Lettore()


def leggi(codice: str, righe: Iterable[int] | None = None, controlli: Mapping[str, Any] | None = None) -> list[Lettura]:
    """Letture delle righe ``righe`` (da 1; tutte se None) con il lettore comune."""
    return LETTORE.leggi(codice, righe, controlli)


def leggi_riga(codice: str, riga: int, controlli: Mapping[str, Any] | None = None) -> Lettura | None:
    return LETTORE.leggi_riga(codice, riga, controlli)
