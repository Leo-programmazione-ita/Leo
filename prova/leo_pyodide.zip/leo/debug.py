"""Debugger passo-passo di Leo (gancio additivo, SPENTO di default).

Questo modulo offre un oggetto di debug di alto livello, pensato per il
"debugger vero" dell'editor web/Android (``window.LeoDebug``), costruito
SOPRA il gancio ufficiale e a costo zero dell'interprete
(:meth:`leo.interprete.Interprete.imposta_traccia`).

Principio: quando il debug e' spento l'interprete NON paga nulla. Senza
gancio di traccia l'interprete usa il suo percorso compilato veloce; il
gancio (e quindi il percorso ad albero) viene installato solo quando si
chiama :meth:`Debug.avvia` e viene tolto da :meth:`Debug.ferma`. Non c'e'
nessun ``if`` in piu' per istruzione nel caso normale: l'esecuzione resta
identica, bit per bit, a quella senza questo modulo.

Uso tipico (lato runtime, p.es. Pyodide o Chaquopy)::

    from leo.debug import Debug
    debug = Debug()
    debug.collega(interprete)            # collega il gancio di traccia
    debug.su_riga = lambda riga: ...     # avvisa la UI: evidenzia la riga
    debug.pausa  = lambda riga: ...      # sospende e attende Continua/Passo
    debug.avvia({3, 10}, modo="continua")  # breakpoint sulle righe 3 e 10
    interprete.esegui(programma)

Un'unica istanza condivisa e' disponibile come ``leo.debug.corrente`` per
chi preferisce uno stato globale.

Collegamento con la UI (lato runtime/JS, NON fatto qui):
    - ``su_riga(riga)`` va collegato a ``window.LeoDebug`` per evidenziare la
      riga in esecuzione (p.es. chiamando una funzione JS esposta che fa
      l'highlight); ``debug.variabili`` contiene nome->testo delle variabili
      visibili su quella riga, da mostrare nel pannello.
    - ``pausa(riga)`` deve SOSPENDERE l'esecuzione e attendere che l'utente
      prema Continua o Passo: tipicamente richiama
      ``window.LeoDebug.fermaARiga(n)`` e poi aspetta. In Pyodide la sospensione
      si ottiene con l'esecuzione asincrona (``runPythonAsync`` + una Promise
      JS risolta da Continua/Passo); in Chaquopy con un blocco su un evento del
      thread di lavoro. Continua/Passo lato runtime chiamano
      :meth:`Debug.continua` / :meth:`Debug.passo` e poi rilasciano l'attesa.
    - se ``pausa`` (o ``su_riga``) restituisce ``False``, l'esecuzione si ferma
      subito e senza errore catturabile (come il pulsante Ferma).
"""

from __future__ import annotations

from typing import Any, Callable, Iterable, Optional

#: Modalita' di avanzamento.
CONTINUA = "continua"   # avanza fino al prossimo breakpoint
PASSO = "passo"         # si ferma su ogni istruzione


class Debug:
    """Stato e API del debugger passo-passo, settabili dall'esterno.

    Attributi pubblici:
        ``attivo``       -- ``bool`` (default ``False``): debug acceso o spento.
        ``breakpoints``  -- ``set[int]`` di righe su cui fermarsi.
        ``su_riga``      -- callback ``(riga) -> Any`` chiamato PRIMA di ogni
                            istruzione (``None`` = niente). ``False`` ferma.
        ``pausa``        -- callback ``(riga) -> Any`` chiamato quando si deve
                            sospendere (breakpoint o modo Passo). ``False`` ferma.
        ``variabili``    -- ``dict[str, str]`` nome->testo delle variabili
                            visibili sull'ultima riga tracciata (per la UI).
        ``riga_corrente``-- ultima riga passata al gancio (``0`` se mai).
    """

    __slots__ = ("attivo", "breakpoints", "su_riga", "pausa", "variabili",
                 "riga_corrente", "_modo", "_interprete", "_gancio_bound")

    def __init__(self) -> None:
        self.attivo: bool = False
        self.breakpoints: set[int] = set()
        self.su_riga: Optional[Callable[[int], Any]] = None
        self.pausa: Optional[Callable[[int], Any]] = None
        self.variabili: dict[str, str] = {}
        self.riga_corrente: int = 0
        self._modo: str = CONTINUA
        self._interprete: Any = None
        # Un unico oggetto metodo legato: leggere ``self._gancio`` ne creerebbe
        # uno nuovo ogni volta, e il confronto ``is`` in _disinstalla fallirebbe.
        self._gancio_bound: Callable[[int, int, dict], Any] = self._gancio

    # ------------------------------------------------------------------
    # Collegamento all'interprete
    # ------------------------------------------------------------------
    def collega(self, interprete: Any) -> None:
        """Ricorda l'interprete da tracciare. Non accende ancora il debug:
        serve :meth:`avvia`. Se il debug era gia' attivo, reinstalla il gancio
        sul nuovo interprete."""
        self._interprete = interprete
        if self.attivo:
            self._installa()

    def scollega(self) -> None:
        """Toglie il gancio dall'interprete (se collegato) e dimentica l'interprete."""
        self._disinstalla()
        self._interprete = None

    # ------------------------------------------------------------------
    # API di controllo (quella minima per la UI)
    # ------------------------------------------------------------------
    def avvia(self, breakpoints: Optional[Iterable[int]] = None, *,
              modo: str = CONTINUA) -> None:
        """Accende il debug e installa il gancio di traccia sull'interprete.

        ``breakpoints``: righe su cui fermarsi (``None`` = lascia quelli attuali).
        ``modo``: :data:`CONTINUA` (ferma solo sui breakpoint) o :data:`PASSO`
        (ferma su ogni istruzione).
        """
        if breakpoints is not None:
            self.breakpoints = {int(r) for r in breakpoints}
        self._modo = PASSO if modo == PASSO else CONTINUA
        self.attivo = True
        self._installa()

    def ferma(self) -> None:
        """Spegne il debug e toglie il gancio: l'interprete torna al percorso
        veloce, a costo zero. L'esecuzione eventualmente in corso prosegue
        senza fermarsi piu' (il gancio sparisce)."""
        self.attivo = False
        self._modo = CONTINUA
        self._disinstalla()

    def passo(self) -> None:
        """Modalita' Passo: ferma sulla prossima istruzione."""
        self._modo = PASSO

    def continua(self) -> None:
        """Modalita' Continua: avanza fino al prossimo breakpoint."""
        self._modo = CONTINUA

    @property
    def modo(self) -> str:
        """Modalita' corrente (:data:`CONTINUA` o :data:`PASSO`)."""
        return self._modo

    def imposta_breakpoints(self, righe: Iterable[int]) -> None:
        """Rimpiazza l'insieme dei breakpoint."""
        self.breakpoints = {int(r) for r in righe}

    def aggiungi_breakpoint(self, riga: int) -> None:
        self.breakpoints.add(int(riga))

    def togli_breakpoint(self, riga: int) -> None:
        self.breakpoints.discard(int(riga))

    def alterna_breakpoint(self, riga: int) -> bool:
        """Mette/toglie un breakpoint sulla riga; restituisce ``True`` se ora c'e'."""
        riga = int(riga)
        if riga in self.breakpoints:
            self.breakpoints.discard(riga)
            return False
        self.breakpoints.add(riga)
        return True

    # ------------------------------------------------------------------
    # Interno: il gancio di traccia vero e proprio
    # ------------------------------------------------------------------
    def _installa(self) -> None:
        interprete = self._interprete
        if interprete is not None and hasattr(interprete, "imposta_traccia"):
            interprete.imposta_traccia(self._gancio_bound)

    def _disinstalla(self) -> None:
        interprete = self._interprete
        if interprete is not None and hasattr(interprete, "imposta_traccia"):
            # Toglie solo se il gancio e' il nostro (non pestare i piedi ad altri).
            if getattr(interprete, "traccia", None) is self._gancio_bound:
                interprete.imposta_traccia(None)

    def _gancio(self, riga: int, colonna: int, variabili: dict) -> Any:
        """Chiamato dall'interprete PRIMA di ogni istruzione.

        Firma richiesta da ``imposta_traccia``: ``(riga, colonna, variabili)``.
        Restituire ``False`` ferma l'esecuzione (senza errore catturabile).
        """
        if not self.attivo:          # debug spento a meta' esecuzione: non fermare piu'
            return True
        self.riga_corrente = riga
        self.variabili = variabili
        su_riga = self.su_riga
        if su_riga is not None:
            if su_riga(riga) is False:
                return False
        if self._modo == PASSO or riga in self.breakpoints:
            pausa = self.pausa
            if pausa is not None:
                if pausa(riga) is False:
                    return False
        return True


#: Istanza condivisa, comoda per chi vuole uno stato globale (``leo.debug.corrente``).
corrente = Debug()


def collega(interprete: Any, breakpoints: Optional[Iterable[int]] = None, *,
            modo: str = CONTINUA, debug: Optional[Debug] = None) -> Debug:
    """Scorciatoia: collega ``debug`` (o :data:`corrente`) all'interprete e,
    se ``breakpoints`` e' dato, lo avvia subito. Restituisce il :class:`Debug`."""
    d = debug if debug is not None else corrente
    d.collega(interprete)
    if breakpoints is not None:
        d.avvia(breakpoints, modo=modo)
    return d
