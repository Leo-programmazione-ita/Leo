"""Nodi dell'albero sintattico (AST) di Leo (CONTRATTO CONDIVISO).

Il parser (``leo.parser``) produce un :class:`Programma`; l'interprete, il
formattatore e gli strumenti lo visitano. Tutti i nodi sono ``dataclass`` con
``riga`` e ``colonna`` (1-based, posizione del primo token del costrutto) come
campi solo-parola-chiave con valore predefinito 0.

Convenzioni:
- un "blocco" e' semplicemente ``list[Istruzione]``;
- gli operatori sono memorizzati come testo canonico: ``"+"``, ``"-"``, ``"*"``,
  ``"/"``, ``"//"``, ``"%"``, ``"^"``, ``"=="``, ``"!="``, ``"<"``, ``"<="``,
  ``">"``, ``">="``, ``"in"``, ``"è"``, ``"non è"``, ``"e"``, ``"o"``, ``"non"``;
- le espressioni sono istanze di :class:`Espressione`, le istruzioni di
  :class:`Istruzione`; un'espressione usata come istruzione e' avvolta in
  :class:`IstruzioneEspressione`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Union


@dataclass
class Nodo:
    """Base di tutti i nodi."""

    riga: int = field(default=0, kw_only=True)
    colonna: int = field(default=0, kw_only=True)


@dataclass
class Espressione(Nodo):
    """Base delle espressioni."""


@dataclass
class Istruzione(Nodo):
    """Base delle istruzioni."""


Blocco = list  # list[Istruzione]


# ===========================================================================
# Espressioni
# ===========================================================================

@dataclass
class Letterale(Espressione):
    """Numero intero, decimale, testo semplice, ``vero``, ``falso`` o ``nulla``.

    ``valore`` e' gia' il valore Python corrispondente (int, float, str, bool,
    None) secondo il modello di ``leo.valori``.
    """

    valore: Any


@dataclass
class TestoInterpolato(Espressione):
    """``"Ciao {nome}!"`` -> ``parti = ["Ciao ", Nome("nome"), "!"]``."""

    parti: list[Union[str, Espressione]]


@dataclass
class Nome(Espressione):
    """Riferimento a una variabile, costante, funzione o controllo grafico."""

    nome: str


@dataclass
class ListaLetterale(Espressione):
    """``[a, b, c]``."""

    elementi: list[Espressione]


@dataclass
class DizionarioLetterale(Espressione):
    """``{chiave: valore, ...}``; ``coppie`` e' una lista di tuple (chiave, valore)."""

    coppie: list[tuple[Espressione, Espressione]]


@dataclass
class Binaria(Espressione):
    """Operazione aritmetica: ``+ - * / // % ^``."""

    operatore: str
    sinistra: Espressione
    destra: Espressione


@dataclass
class Unaria(Espressione):
    """``-x`` oppure ``non x`` (operatore ``"-"`` o ``"non"``)."""

    operatore: str
    operando: Espressione


@dataclass
class Logica(Espressione):
    """``a e b`` / ``a o b`` con cortocircuito (operatore ``"e"`` o ``"o"``)."""

    operatore: str
    sinistra: Espressione
    destra: Espressione


@dataclass
class Confronto(Espressione):
    """Confronto eventualmente concatenato: ``0 < x <= 10``.

    ``operandi`` ha un elemento in piu' di ``operatori``:
    ``Confronto([0, x, 10], ["<", "<="])`` significa ``0 < x e x <= 10``
    (``x`` valutato una sola volta).
    """

    operandi: list[Espressione]
    operatori: list[str]


@dataclass
class Intervallo(Espressione):
    """``inizio..fine`` (entrambi inclusi)."""

    inizio: Espressione
    fine: Espressione


@dataclass
class Argomento(Nodo):
    """Argomento di chiamata: posizionale (``nome is None``) o per nome."""

    valore: Espressione
    nome: str | None = None
    espandi: bool = False   # ``f(lista...)``: gli elementi diventano argomenti


@dataclass
class Chiamata(Espressione):
    """``funzione(argomenti)``. ``funzione`` e' un'espressione qualsiasi
    (``Nome``, ``Attributo`` per i metodi, ...). Gli argomenti per nome devono
    seguire quelli posizionali (lo controlla il parser)."""

    funzione: Espressione
    argomenti: list[Argomento]
    #: Nata da ``valore |> funzione``: se ``funzione`` non e' un nome definito si
    #: prova il metodo del valore (``"ciao" |> maiuscolo``).
    catena: bool = False


@dataclass
class Indice(Espressione):
    """``oggetto[indice]``."""

    oggetto: Espressione
    indice: Espressione


@dataclass
class Attributo(Espressione):
    """``oggetto.nome`` (proprieta' di un controllo, campo di un errore,
    metodo di testo/lista/dizionario)."""

    oggetto: Espressione
    nome: str


@dataclass
class Parametro(Nodo):
    """Parametro di funzione: ``nome``, ``nome = predefinito``, ``nome: tipo``."""

    nome: str
    predefinito: Espressione | None = None
    tipo: str | None = None   # nome di tipo Leo facoltativo ("intero", ...)
    variadico: bool = False   # ``numeri...``: raccoglie gli argomenti in piu' in una lista


@dataclass
class FunzioneAnonima(Espressione):
    """``funzione (x) restituisci x * 2 fine``."""

    parametri: list[Parametro]
    corpo: list[Istruzione]


# ===========================================================================
# Istruzioni
# ===========================================================================

@dataclass
class Dichiarazione(Istruzione):
    """``[crea] variabile nome = valore`` o ``[crea] costante NOME = valore``.

    ``tipo``: il tipo dichiarato, facoltativo (``variabile x: intero = 0``,
    ``variabile e: testo?`` che vale ``nulla``), come testo canonico.
    """

    nome: str
    valore: Espressione
    costante: bool = False
    tipo: str | None = field(default=None, kw_only=True)


@dataclass
class Assegnazione(Istruzione):
    """``bersaglio op valore`` con op in ``= += -= *= /=``.

    ``bersaglio`` e' un :class:`Nome`, :class:`Indice` o :class:`Attributo`.
    """

    bersaglio: Espressione
    operatore: str
    valore: Espressione


@dataclass
class RamoSe(Nodo):
    """Un ramo ``se``/``altrimenti se``: condizione e corpo."""

    condizione: Espressione
    corpo: list[Istruzione]


@dataclass
class Se(Istruzione):
    """Catena ``se``/``altrimenti se``/``altrimenti``; ``altrimenti`` e' None se assente."""

    rami: list[RamoSe]
    altrimenti: list[Istruzione] | None = None


@dataclass
class Mentre(Istruzione):
    condizione: Espressione
    corpo: list[Istruzione]


@dataclass
class PerOgni(Istruzione):
    """``per ogni variabile in iterabile fai ... fine``."""

    variabile: str
    iterabile: Espressione
    corpo: list[Istruzione]
    #: ``per ogni chiave, valore in d fai``: tutti i nomi (``variabile`` e' il primo).
    variabili: list[str] | None = None


@dataclass
class Ripeti(Istruzione):
    """``ripeti volte volte ... fine``."""

    volte: Espressione
    corpo: list[Istruzione]


@dataclass
class DefinizioneFunzione(Istruzione):
    """``funzione nome(parametri) ... fine``.

    Facoltativi (programmi grandi, vedi docs/CONTROLLO.md): ``tipo_risultato``
    (``funzione area(b: decimale) dà decimale``), i contratti scritti in cima al
    corpo (``richiede``, ``garantisce``, ``può dare``). Un ``nome`` con il punto
    (``Alunno.media``) definisce un metodo di una ``struttura``.
    """

    nome: str
    parametri: list[Parametro]
    corpo: list[Istruzione]
    tipo_risultato: str | None = field(default=None, kw_only=True)
    richiede: list = field(default_factory=list, kw_only=True)      # list[Espressione]
    garantisce: list = field(default_factory=list, kw_only=True)    # list[Espressione]
    puo_dare: list = field(default_factory=list, kw_only=True)      # list[str] (tipi d'errore)


@dataclass
class Restituisci(Istruzione):
    valore: Espressione | None = None


@dataclass
class Interrompi(Istruzione):
    pass


@dataclass
class Continua(Istruzione):
    pass


@dataclass
class Cattura(Nodo):
    """Clausola ``cattura [TipoErrore] [come nome]``.

    ``tipo_errore`` None = cattura qualunque errore (tranne ErroreSintassi).
    """

    tipo_errore: str | None
    nome_variabile: str | None
    corpo: list[Istruzione]


@dataclass
class Prova(Istruzione):
    corpo: list[Istruzione]
    catture: list[Cattura] = field(default_factory=list)
    infine: list[Istruzione] | None = None


@dataclass
class Lancia(Istruzione):
    valore: Espressione


@dataclass
class Evento(Istruzione):
    """``quando Controllo.evento fai ... fine`` (o ``quando Giocatore.tocca Moneta fai``: solo con ``Moneta``)."""

    controllo: str
    evento: str
    corpo: list[Istruzione]
    oggetto: str = ""


@dataclass
class IstruzioneEspressione(Istruzione):
    """Espressione usata come istruzione (tipicamente una chiamata)."""

    espressione: Espressione


@dataclass
class Programma(Nodo):
    istruzioni: list[Istruzione]
    nome_file: str = "<sorgente>"
    #: Nomi dichiarati con ``pubblica``; None se il file non usa ``pubblica``
    #: (allora sono visibili a chi lo importa tutti i nomi che non cominciano con ``_``).
    pubblici: list[str] | None = field(default=None, kw_only=True)


# ===========================================================================
# Novita' del tema "linguaggio"
# ===========================================================================

@dataclass
class ListaCompresa(Espressione):
    """``[x * 2 per ogni x in lista se x > 3]``.

    ``variabili``: uno o piu' nomi (``per ogni k, v in d``); ``condizione``
    facoltativa (``se ...``).
    """

    elemento: Espressione
    variabili: list[str]
    iterabile: Espressione
    condizione: Espressione | None = None


@dataclass
class DichiarazioneMultipla(Dichiarazione):
    """``variabile a, b = [1, 2]`` (destrutturazione).

    ``nome`` e' il primo nome (per chi conosce solo :class:`Dichiarazione`),
    ``nomi`` tutti i nomi; ``valore`` deve dare una sequenza della stessa
    lunghezza. Con piu' valori (``variabile a, b = 1, 2``) ``valore`` e' una
    :class:`ListaLetterale`.
    """

    nomi: list[str] = field(default_factory=list)


@dataclass
class AssegnazioneMultipla(Istruzione):
    """``a, b = b, a``: i valori si calcolano tutti prima di assegnare.

    ``valore`` e' un'espressione che da' una sequenza (una
    :class:`ListaLetterale` se a destra ci sono piu' espressioni).
    """

    bersagli: list[Espressione]
    valore: Espressione


@dataclass
class Caso(Nodo):
    """``caso schema1, schema2 allora`` dentro ``scegli``.

    Uno schema e' un valore (uguaglianza), un intervallo ``a..b`` (il valore
    sta tra ``a`` e ``b``) o una lista (il valore e' uno degli elementi).
    """

    schemi: list[Espressione]
    corpo: list[Istruzione]


@dataclass
class Scegli(Istruzione):
    """``scegli valore`` / ``caso ... allora`` / ``altrimenti`` / ``fine``."""

    valore: Espressione
    casi: list[Caso]
    altrimenti: list[Istruzione] | None = None


@dataclass
class Importa(Istruzione):
    """``importa "file.leo"``, ``importa geometria``, ``importa matematica come m``.

    ``modulo``: il testo scritto (percorso o nome); ``alias``: il nome dopo
    ``come`` (None = i nomi del modulo entrano direttamente nel programma).
    """

    modulo: str
    alias: str | None = None


@dataclass
class Verifica(Istruzione):
    """``verifica condizione, "messaggio"``: se la condizione e' falsa si ferma
    con un ``ErroreValore`` che mostra i valori confrontati."""

    condizione: Espressione
    messaggio: Espressione | None = None


# ===========================================================================
# Costrutti "potenti": temporizzatori, verifiche incorporate, parallelo, formati
# ===========================================================================

@dataclass
class Temporizzatore(Istruzione):
    """``ogni 2 secondi fai ... fine`` (``ripeti=True``) o ``dopo 3 secondi fai
    ... fine`` (``ripeti=False``). ``durata`` in ``unita`` (``"secondi"``,
    ``"millisecondi"``, ``"minuti"``...); il corpo e' come quello di una funzione
    senza parametri (``restituisci`` esce solo da questo scatto)."""

    durata: Espressione
    unita: str
    corpo: list[Istruzione]
    ripeti: bool = True


@dataclass
class BloccoVerifica(Istruzione):
    """``verifica "nome del test" fai ... fine``: un test incorporato. Nella
    normale esecuzione non parte; lo esegue ``leo verifica``."""

    nome: Espressione
    corpo: list[Istruzione]


@dataclass
class Aspettati(Istruzione):
    """``aspettati condizione`` dentro una verifica: se e' falsa la verifica non
    riesce e il rapporto mostra il valore atteso e quello ottenuto."""

    condizione: Espressione


@dataclass
class AspettatiErrore(Istruzione):
    """``aspettati errore [TipoErrore] fai ... fine``: il corpo deve finire con
    quell'errore (con qualunque errore se ``tipo_errore`` e' None)."""

    tipo_errore: str | None
    corpo: list[Istruzione]


@dataclass
class Parallelo(Espressione):
    """``in parallelo fai ... fine``: il corpo parte in un altro filo di
    esecuzione; il valore e' un *lavoro* (``aspetta(lavoro)`` ne da' il
    risultato, cioe' il valore di ``restituisci``)."""

    corpo: list[Istruzione]


@dataclass
class ValoreFormattato(Espressione):
    """``{prezzo:2}`` / ``{n:migliaia}`` dentro un testo: ``valore`` scritto con
    il ``formato`` (gia' controllato dal parser)."""

    valore: Espressione
    formato: str


# ===========================================================================
# Programmi grandi: tipi, strutture, contratti (docs/CONTROLLO.md)
# ===========================================================================

@dataclass
class Campo(Nodo):
    """Un campo di ``struttura`` o di una variante: ``nome: tipo = predefinito``
    (tipo e predefinito facoltativi, almeno uno dei due nelle strutture)."""

    nome: str
    tipo: str | None = None
    predefinito: Espressione | None = None


@dataclass
class DefinizioneStruttura(Istruzione):
    """``struttura Alunno`` / campi / [funzioni] / ``fine``.

    ``metodi``: le funzioni scritte dentro il blocco (nome senza il punto);
    i metodi scritti fuori (``funzione Alunno.media()``) sono
    :class:`DefinizioneFunzione` con il punto nel nome.

    ``base``: il nome della classe genitore in ``classe Studente estende Persona``
    (None quando la classe non eredita da nessuno).
    """

    nome: str
    campi: list[Campo]
    metodi: list[DefinizioneFunzione] = field(default_factory=list)
    base: str | None = None


@dataclass
class RiferimentoGenitore(Espressione):
    """``genitore`` dentro un'azione di una classe che ``estende`` un'altra:
    l'oggetto corrente visto come la classe genitore ``base``, per richiamarne le
    azioni (``genitore.saluta()``). Compare sempre prima di un ``.``."""

    base: str


@dataclass
class Variante(Nodo):
    """Una variante di ``tipo ... è uno di``: ``Cerchio(raggio: decimale)``;
    ``campi`` None per una variante senza dati (``Vuota``)."""

    nome: str
    campi: list[Campo] | None = None


@dataclass
class DefinizioneTipo(Istruzione):
    """``tipo Forma è uno di`` / varianti / ``fine`` (o su una riga:
    ``tipo Colore è uno di Rosso, Verde, Blu``)."""

    nome: str
    varianti: list[Variante]


@dataclass
class HaValore(Espressione):
    """``e ha valore`` (vero se ``e`` non e' ``nulla``); ``negato``: ``e non ha valore``."""

    valore: Espressione
    negato: bool = False


@dataclass
class Richiede(Istruzione):
    """``richiede condizione`` in cima a una funzione (precondizione):
    se e' falsa la chiamata si ferma con un errore che indica chi ha sbagliato."""

    condizione: Espressione
    funzione: str = ""


@dataclass
class ControllaRisultato(Espressione):
    """Nodo interno (non lo produce il parser): avvolge il valore di
    ``restituisci`` nelle funzioni con ``dà tipo`` o ``garantisce``; controlla
    il tipo e le garanzie (con ``risultato`` uguale al valore)."""

    valore: Espressione
    funzione: str
    tipo: str | None = None
    garantisce: list = field(default_factory=list)
    alla_fine: bool = False   # la funzione e' finita senza ``restituisci``


# ===========================================================================
# Visitatore
# ===========================================================================

class Visitatore:
    """Smistamento per nome: ``visita(nodo)`` chiama ``visita_<NomeClasse>(nodo, *arg)``.

    Esempio: per un nodo :class:`PerOgni` viene chiamato ``visita_PerOgni``.
    Se il metodo manca viene chiamato ``visita_generica``.
    """

    def visita(self, nodo: Nodo, *argomenti: Any) -> Any:
        metodo = getattr(self, "visita_" + type(nodo).__name__, None)
        if metodo is None:
            return self.visita_generica(nodo, *argomenti)
        return metodo(nodo, *argomenti)

    def visita_generica(self, nodo: Nodo, *argomenti: Any) -> Any:
        raise NotImplementedError(
            f"{type(self).__name__} non sa visitare il nodo {type(nodo).__name__}"
        )


#: Elenco di tutte le classi di nodo concrete (utile ai test di completezza).
TUTTI_I_NODI: tuple[type, ...] = (
    Letterale, TestoInterpolato, Nome, ListaLetterale, DizionarioLetterale,
    Binaria, Unaria, Logica, Confronto, Intervallo, Argomento, Chiamata, Indice,
    Attributo, Parametro, FunzioneAnonima, Dichiarazione, Assegnazione, RamoSe,
    Se, Mentre, PerOgni, Ripeti, DefinizioneFunzione, Restituisci, Interrompi,
    Continua, Cattura, Prova, Lancia, Evento, IstruzioneEspressione, Programma,
    ListaCompresa, DichiarazioneMultipla, AssegnazioneMultipla, Caso, Scegli, Importa,
    Verifica, Temporizzatore, BloccoVerifica, Aspettati, AspettatiErrore, Parallelo, ValoreFormattato,
    Campo, DefinizioneStruttura, RiferimentoGenitore, Variante, DefinizioneTipo, HaValore, Richiede, ControllaRisultato,
)
