"""Flussi di automazione del computer per Leo Sistema.

Verbi di alto livello sui file e le cartelle: `organizza_cartella`, `trova_file_grandi`,
`trova_duplicati`, `rinomina_in_serie`. Ognuno ha una modalità **prova** (`prova = vero`) che mostra
cosa farebbe senza toccare niente: così si guarda prima, e solo poi si agisce.
"""

from __future__ import annotations

import hashlib
import os
import shutil
from typing import Any

from ..errori import ErroreFile, ErroreValore
from .generali import funzione_libreria, richiedi_intero, richiedi_logico, richiedi_testo

#: estensione (senza punto) -> categoria, per organizza_cartella
CATEGORIE_FILE: dict[str, set[str]] = {
    "Immagini": {"jpg", "jpeg", "png", "gif", "bmp", "webp", "svg", "heic", "tiff", "ico"},
    "Documenti": {"pdf", "doc", "docx", "txt", "odt", "rtf", "md", "tex"},
    "Fogli": {"xls", "xlsx", "csv", "ods", "tsv"},
    "Presentazioni": {"ppt", "pptx", "odp"},
    "Audio": {"mp3", "wav", "flac", "aac", "ogg", "m4a", "wma"},
    "Video": {"mp4", "avi", "mkv", "mov", "wmv", "webm", "flv"},
    "Archivi": {"zip", "rar", "7z", "tar", "gz", "bz2", "xz"},
    "Programmi": {"exe", "msi", "apk", "dmg", "deb", "appimage"},
    "Codice": {"py", "js", "ts", "html", "css", "leo", "java", "c", "cpp", "cs", "go", "rs", "json", "xml"},
}


def _categoria(nome: str) -> str:
    est = nome.rsplit(".", 1)[-1].lower() if "." in nome else ""
    for categoria, estensioni in CATEGORIE_FILE.items():
        if est in estensioni:
            return categoria
    return "Altri"


def _cartella_valida(cartella: Any, funzione: str) -> str:
    cartella = richiedi_testo(cartella, funzione, "cartella")
    if not os.path.isdir(cartella):
        raise ErroreFile(f"La cartella `{cartella}` non esiste.")
    return cartella


@funzione_libreria("organizza_cartella")
def organizza_cartella(cartella, prova=False):
    """organizza_cartella(cartella, prova = falso): mette in ordine una cartella spostando i file in
    sottocartelle per tipo (Immagini, Documenti, Video...). Con `prova = vero` mostra solo il piano,
    senza spostare niente. Restituisce la lista di {"file", "destinazione"}.
    Esempio: `organizza_cartella(cartella_download(), prova = vero)`.
    """
    cartella = _cartella_valida(cartella, "organizza_cartella")
    prova = richiedi_logico(prova, "organizza_cartella", "prova") if prova is not False else False
    piano: list[dict] = []
    for nome in sorted(os.listdir(cartella)):
        origine = os.path.join(cartella, nome)
        if not os.path.isfile(origine) or nome.startswith("."):
            continue
        categoria = _categoria(nome)
        destinazione = os.path.join(cartella, categoria, nome)
        piano.append({"file": nome, "categoria": categoria,
                      "destinazione": os.path.join(categoria, nome)})
        if not prova:
            os.makedirs(os.path.join(cartella, categoria), exist_ok=True)
            if os.path.abspath(origine) != os.path.abspath(destinazione):
                try:
                    shutil.move(origine, destinazione)
                except OSError as e:
                    raise ErroreFile(f"Non riesco a spostare `{nome}`: {e.strerror or e}.") from e
    return piano


@funzione_libreria("trova_file_grandi")
def trova_file_grandi(cartella, minimo_mb=100):
    """trova_file_grandi(cartella, minimo_mb = 100): cerca (anche nelle sottocartelle) i file più grandi
    di `minimo_mb` megabyte, dal più grande. Restituisce {"file", "mb", "percorso"}.
    Esempio: `trova_file_grandi(cartella_casa(), 500)`.
    """
    cartella = _cartella_valida(cartella, "trova_file_grandi")
    if isinstance(minimo_mb, bool) or not isinstance(minimo_mb, (int, float)) or minimo_mb < 0:
        raise ErroreValore("`minimo_mb` deve essere un numero di megabyte (per esempio 100).")
    soglia = float(minimo_mb) * 1024 * 1024
    trovati: list[dict] = []
    for base, _c, file in os.walk(cartella):
        for nome in file:
            percorso = os.path.join(base, nome)
            try:
                dim = os.path.getsize(percorso)
            except OSError:
                continue
            if dim >= soglia:
                trovati.append({"file": nome, "mb": round(dim / 1024 / 1024, 1), "percorso": percorso})
    trovati.sort(key=lambda x: x["mb"], reverse=True)
    return trovati


@funzione_libreria("trova_duplicati")
def trova_duplicati(cartella):
    """trova_duplicati(cartella): trova i file uguali (stesso contenuto) in una cartella e nelle sue
    sottocartelle. Restituisce una lista di gruppi, ogni gruppo è la lista dei percorsi uguali.
    Esempio: `per ogni gruppo in trova_duplicati(cartella_immagini()) fai ... fine`.
    """
    cartella = _cartella_valida(cartella, "trova_duplicati")
    per_dimensione: dict[int, list[str]] = {}
    for base, _c, file in os.walk(cartella):
        for nome in file:
            percorso = os.path.join(base, nome)
            try:
                per_dimensione.setdefault(os.path.getsize(percorso), []).append(percorso)
            except OSError:
                continue
    gruppi: list[list[str]] = []
    for percorsi in per_dimensione.values():
        if len(percorsi) < 2:
            continue
        per_impronta: dict[str, list[str]] = {}
        for percorso in percorsi:
            try:
                with open(percorso, "rb") as f:
                    h = hashlib.sha256(f.read()).hexdigest()
            except OSError:
                continue
            per_impronta.setdefault(h, []).append(percorso)
        for uguali in per_impronta.values():
            if len(uguali) >= 2:
                gruppi.append(sorted(uguali))
    return gruppi


@funzione_libreria("rinomina_in_serie")
def rinomina_in_serie(cartella, cerca, sostituisci, prova=False):
    """rinomina_in_serie(cartella, cerca, sostituisci, prova = falso): nei nomi dei file di una cartella
    sostituisce `cerca` con `sostituisci`. Con `prova = vero` mostra solo cosa cambierebbe.
    Restituisce {"vecchio", "nuovo"}. Esempio: `rinomina_in_serie(cartella, "IMG", "Foto")`.
    """
    cartella = _cartella_valida(cartella, "rinomina_in_serie")
    cerca = richiedi_testo(cerca, "rinomina_in_serie", "cerca")
    sostituisci = richiedi_testo(sostituisci, "rinomina_in_serie", "sostituisci")
    prova = richiedi_logico(prova, "rinomina_in_serie", "prova") if prova is not False else False
    if not cerca:
        raise ErroreValore("`cerca` non può essere vuoto.")
    cambi: list[dict] = []
    for nome in sorted(os.listdir(cartella)):
        if cerca not in nome:
            continue
        nuovo = nome.replace(cerca, sostituisci)
        if nuovo == nome or not nuovo.strip():
            continue
        cambi.append({"vecchio": nome, "nuovo": nuovo})
        if not prova:
            origine = os.path.join(cartella, nome)
            destinazione = os.path.join(cartella, nuovo)
            if os.path.exists(destinazione):
                raise ErroreFile(f"Esiste già `{nuovo}`: rinomina fermata per non sovrascrivere.")
            try:
                os.rename(origine, destinazione)
            except OSError as e:
                raise ErroreFile(f"Non riesco a rinominare `{nome}`: {e.strerror or e}.") from e
    return cambi


__all__ = ["organizza_cartella", "trova_file_grandi", "trova_duplicati", "rinomina_in_serie",
           "CATEGORIE_FILE"]
