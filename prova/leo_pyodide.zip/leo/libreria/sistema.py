"""Libreria "sistema" (S1): il programma Leo parla con Windows.

Gruppi di funzioni (la parte che chiama davvero Windows è in
``leo/sistema/programmi.py``; qui ci sono controlli, conferme e messaggi):

* **informazioni**: ``nome_computer``, ``nome_utente``, ``versione_windows``,
  ``info_windows``, ``architettura``, ``tempo_accensione``, ``tempo_accensione_testo``;
* **cartelle speciali**: ``cartella_speciale``, ``cartella_immagini``, ``cartella_musica``,
  ``cartella_video``, ``cartella_appdata``, ``cartella_appdata_locale``,
  ``cartella_temp_sistema``, ``cartella_programmi``, ``cartella_menu_start``
  (Desktop, Documenti e Download sono già in ``cartelle.py``);
* **variabili d'ambiente** (solo per questo programma): ``leggi_variabile_ambiente``,
  ``imposta_variabile_ambiente``, ``togli_variabile_ambiente``, ``variabili_ambiente``,
  ``espandi_variabili_ambiente``;
* **processi**: ``elenca_processi``, ``trova_processi``, ``processo_esiste``,
  ``termina_processo`` (con conferma), ``pid_corrente``;
* **programmi**: ``avvia_programma``, ``apri_con_programma_predefinito``,
  ``apri_in_esplora_file``, ``seleziona_in_esplora_file``, ``apri_indirizzo_web``,
  ``apri_impostazioni_windows``, ``sezioni_impostazioni``;
* **comandi**: ``esegui_comando``, ``esegui_powershell`` (il comando si mostra
  all'utente e si chiede conferma);
* **appunti**: ``leggi_appunti``, ``scrivi_appunti``, ``svuota_appunti``,
  ``appunti_contiene_testo``, ``appunti_contiene_immagine``, ``salva_immagine_appunti``,
  ``copia_file_negli_appunti``;
* **cestino**: ``sposta_nel_cestino``, ``elementi_nel_cestino``, ``dimensione_cestino``,
  ``svuota_cestino`` (con conferma);
* **collegamenti**: ``crea_collegamento``, ``destinazione_collegamento``, ``info_collegamento``;
  **file recenti**: ``file_recenti``;
* **avvio automatico** (solo per l'utente, ``HKCU\\...\\Run``): ``programmi_all_avvio``,
  ``e_all_avvio``, ``aggiungi_all_avvio`` e ``togli_dall_avvio`` (con conferma);
* **associazioni**: ``programma_predefinito``, ``nome_programma_predefinito``.

Sicurezza: le azioni pericolose chiedono conferma all'utente del programma
(finestra se c'è la grafica, domanda nel terminale altrimenti) salvo
``senza_conferma = vero``; il registro si scrive solo in HKCU; i processi
vitali di Windows non si chiudono.
"""

from __future__ import annotations

import difflib
import os
import re
import subprocess
import tempfile
from typing import Any

from ..errori import ErroreFile, ErroreTipo, ErroreValore
from ..sistema import _win, programmi
from ..sistema._win import ErroreSistema, chiedi_conferma, solo_windows
from ..valori import rappresenta
from .date import DataDante
from .generali import articolo, funzione_libreria, mostra, richiedi_intero, richiedi_logico, richiedi_testo


def _n() -> programmi.Nativo:
    """L'implementazione nativa in uso (i test la sostituiscono)."""
    return programmi.nativo


def _testo_pieno(valore: Any, funzione: str, parametro: str, esempio: str) -> str:
    richiedi_testo(valore, funzione, parametro)
    if not valore.strip():
        raise ErroreValore(f"Il parametro `{parametro}` di `{funzione}` è vuoto.",
                           suggerimento=f"Scrivi per esempio `{esempio}`.")
    if "\0" in valore:
        raise ErroreValore(f"Il parametro `{parametro}` di `{funzione}` contiene un carattere non valido.")
    return valore


def _tempo(valore: Any, funzione: str) -> float | None:
    if valore is None:
        return None
    if isinstance(valore, bool) or not isinstance(valore, (int, float)):
        raise ErroreTipo(f"`tempo_massimo` di `{funzione}` deve essere un numero di secondi, non {articolo(valore)}.",
                         suggerimento="Scrivi per esempio `tempo_massimo = 30`, oppure `nulla` per aspettare senza limite.")
    if valore <= 0:
        raise ErroreValore(f"`tempo_massimo` di `{funzione}` deve essere maggiore di zero.")
    if valore > 10_000_000 or valore != valore:  # oltre 115 giorni (o NaN): e' un errore di scrittura
        raise ErroreValore(f"`tempo_massimo` di `{funzione}` è troppo grande.",
                           suggerimento="Usa `nulla` per aspettare senza limite.")
    return float(valore)


def _cartella_esistente(valore: Any, funzione: str) -> str | None:
    if valore is None:
        return None
    _testo_pieno(valore, funzione, "cartella", f'{funzione}(..., cartella = "C:/Lavoro")')
    if not os.path.isdir(valore):
        raise ErroreFile(f"La cartella `{valore}` non esiste.",
                         suggerimento="Controlla il percorso, oppure togli `cartella` per usare quella corrente.")
    return os.path.abspath(valore)


def _esistente(percorso: Any, funzione: str) -> str:
    _testo_pieno(percorso, funzione, "percorso", f'{funzione}("C:/Documenti/nota.txt")')
    if not os.path.exists(percorso):
        raise ErroreFile(f"`{percorso}` non esiste.",
                         suggerimento=f"Controlla il nome e la cartella: ora sei in `{os.getcwd()}`.")
    return os.path.abspath(percorso)


def _chiedi(interprete: Any, senza_conferma: Any, funzione: str, testo: str) -> bool:
    richiedi_logico(senza_conferma, funzione, "senza_conferma")
    if senza_conferma:
        return True
    return chiedi_conferma(interprete, testo)


# ===========================================================================
# Informazioni sul sistema
# ===========================================================================

@funzione_libreria("nome_computer")
def nome_computer():
    """nome_computer(): il nome di questo computer in rete (per esempio "PC-UFFICIO").

    Esempio: `stampa("Sono su", nome_computer())`.
    """
    return _n().nome_computer()


@funzione_libreria("nome_utente")
def nome_utente():
    """nome_utente(): il nome dell'utente che ha acceso la sessione (per esempio "ada").

    Esempio: `stampa("Ciao,", nome_utente())`.
    """
    return _n().nome_utente()


def _info_versione() -> dict:
    return programmi.componi_versione(_n().dati_versione())


@funzione_libreria("versione_windows")
def versione_windows():
    """versione_windows(): la versione di Windows in una frase, per esempio "Windows 11 Pro 23H2 (build 22631.3447)".

    Solo su Windows. Esempio: `stampa(versione_windows())`.
    """
    solo_windows("versione_windows")
    return programmi.descrivi_versione(_info_versione())


@funzione_libreria("info_windows")
def info_windows():
    """info_windows(): un dizionario con le informazioni su Windows e sul computer.

    Chiavi: "nome" ("Windows 11 Pro"), "versione" ("23H2"), "build", "edizione", "numero" (10 o 11),
    "architettura", "nome_computer", "utente", "acceso_da" (secondi).
    Solo su Windows. Esempio: `se info_windows()["numero"] >= 11 allora stampa("Windows 11!") fine`.
    """
    solo_windows("info_windows")
    info = _info_versione()
    info.update({
        "architettura": architettura(),
        "nome_computer": nome_computer(),
        "utente": nome_utente(),
        "acceso_da": tempo_accensione(),
    })
    return info


@funzione_libreria("architettura")
def architettura():
    """architettura(): il tipo di processore per cui è fatto il sistema: "x64", "x86" o "ARM64".

    Esempio: `se architettura() == "ARM64" allora stampa("Computer con processore ARM") fine`.
    """
    return programmi.normalizza_architettura(_n().macchina())


@funzione_libreria("tempo_accensione")
def tempo_accensione():
    """tempo_accensione(): da quanti secondi è acceso il computer (un intero).

    Esempio: `stampa("Acceso da", tempo_accensione() // 3600, "ore")`.
    """
    return int(_n().secondi_accensione())


@funzione_libreria("tempo_accensione_testo")
def tempo_accensione_testo():
    """tempo_accensione_testo(): da quanto è acceso il computer, in parole ("2 giorni, 3 ore e 5 minuti").

    Esempio: `stampa("Il computer è acceso da", tempo_accensione_testo())`.
    """
    return programmi.durata_leggibile(_n().secondi_accensione())


# ===========================================================================
# Cartelle speciali
# ===========================================================================

def _cartella(chiave: str) -> str:
    percorso = None
    if _win.e_windows() and chiave in programmi.CARTELLE_NOTE:
        percorso = _n().cartella_nota(chiave)
    if not percorso:
        percorso = programmi.ripiego_cartella(chiave)
    if not percorso:
        raise ErroreSistema(f"Su questo computer non trovo la cartella `{chiave}`.")
    return percorso


@funzione_libreria("cartella_speciale")
def cartella_speciale(nome):
    """cartella_speciale(nome): il percorso di una cartella speciale di Windows, dal suo nome italiano.

    Nomi: "desktop", "documenti", "download", "immagini", "musica", "video", "appdata",
    "appdata_locale", "temporanea", "programmi", "programmi_x86", "menu_start",
    "programmi_menu_start", "esecuzione_automatica", "recenti", "preferiti", "modelli", "casa".
    Esempio: `stampa(cartella_speciale("immagini"))`.
    """
    _testo_pieno(nome, "cartella_speciale", "nome", 'cartella_speciale("immagini")')
    chiave = programmi.normalizza_nome_cartella(nome)
    if chiave is None:
        nomi = programmi.nomi_cartelle_speciali()
        simili = difflib.get_close_matches(nome.strip().lower(), nomi, n=1)
        suggerimento = (f"Forse intendevi \"{simili[0]}\"? " if simili else "") + \
            "I nomi sono: " + ", ".join(f'"{n}"' for n in nomi) + "."
        raise ErroreValore(f"Non conosco la cartella speciale {mostra(nome)}.", suggerimento=suggerimento)
    return _cartella(chiave)


@funzione_libreria("cartella_immagini")
def cartella_immagini():
    """cartella_immagini(): la cartella Immagini dell'utente.

    Esempio: `copia_file("foto.png", cartella_immagini())`.
    """
    return _cartella("immagini")


@funzione_libreria("cartella_musica")
def cartella_musica():
    """cartella_musica(): la cartella Musica dell'utente.

    Esempio: `stampa(elenca_file(cartella_musica(), "*.mp3"))`.
    """
    return _cartella("musica")


@funzione_libreria("cartella_video")
def cartella_video():
    """cartella_video(): la cartella Video dell'utente.

    Esempio: `stampa(cartella_video())`.
    """
    return _cartella("video")


@funzione_libreria("cartella_appdata")
def cartella_appdata():
    """cartella_appdata(): la cartella dei dati dei programmi dell'utente (%APPDATA%, "AppData\\Roaming").

    È il posto giusto per le impostazioni del tuo programma.
    Esempio: `variabile mie = unisci_percorso(cartella_appdata(), "MioProgramma")`.
    """
    return _cartella("appdata")


@funzione_libreria("cartella_appdata_locale")
def cartella_appdata_locale():
    """cartella_appdata_locale(): la cartella dei dati locali dei programmi (%LOCALAPPDATA%, "AppData\\Local").

    Esempio: `stampa(cartella_appdata_locale())`.
    """
    return _cartella("appdata_locale")


@funzione_libreria("cartella_temp_sistema")
def cartella_temp_sistema():
    """cartella_temp_sistema(): la cartella dei file temporanei di Windows (%TEMP%).

    Diversa da `cartella_temporanea()`, che crea una cartella nuova che sparisce a fine programma.
    Esempio: `stampa(cartella_temp_sistema())`.
    """
    return tempfile.gettempdir()


@funzione_libreria("cartella_programmi")
def cartella_programmi():
    """cartella_programmi(): la cartella in cui sono installati i programmi ("C:\\Program Files").

    Solo su Windows. Esempio: `stampa(cartella_programmi())`.
    """
    solo_windows("cartella_programmi")
    return _cartella("programmi")


@funzione_libreria("cartella_menu_start")
def cartella_menu_start():
    """cartella_menu_start(): la cartella dei programmi del menu Start dell'utente.

    Solo su Windows. Esempio: `stampa(elenca_file(cartella_menu_start()))`.
    """
    solo_windows("cartella_menu_start")
    return _cartella("programmi_menu_start")


# ===========================================================================
# Variabili d'ambiente (solo per questo programma e per quelli che avvia)
# ===========================================================================

def _nome_variabile(nome: Any, funzione: str) -> str:
    _testo_pieno(nome, funzione, "nome", f'{funzione}("PATH")')
    if "=" in nome:
        raise ErroreValore(f"Il nome della variabile d'ambiente {mostra(nome)} non può contenere `=`.")
    return nome


@funzione_libreria("leggi_variabile_ambiente")
def leggi_variabile_ambiente(nome, predefinito=None):
    """leggi_variabile_ambiente(nome, predefinito = nulla): il valore di una variabile d'ambiente (un testo).

    Se la variabile non c'è restituisce `predefinito`. Su Windows maiuscole e minuscole non contano.
    Esempio: `stampa(leggi_variabile_ambiente("USERPROFILE"))`.
    """
    _nome_variabile(nome, "leggi_variabile_ambiente")
    return os.environ.get(nome, predefinito)


@funzione_libreria("imposta_variabile_ambiente")
def imposta_variabile_ambiente(nome, valore):
    """imposta_variabile_ambiente(nome, valore): imposta una variabile d'ambiente per questo programma.

    La vedono anche i programmi avviati dopo con `avvia_programma` o `esegui_comando`;
    non cambia le impostazioni di Windows. Con `valore = nulla` la toglie.
    Esempio: `imposta_variabile_ambiente("LINGUA", "it")`.
    """
    _nome_variabile(nome, "imposta_variabile_ambiente")
    if valore is None:
        os.environ.pop(nome, None)
        return None
    if isinstance(valore, bool) or not isinstance(valore, (str, int, float)):
        raise ErroreTipo(f"Il valore di una variabile d'ambiente deve essere un testo, non {articolo(valore)}.",
                         suggerimento=f"Trasformalo in testo: `testo({mostra(valore)})`.")
    testo = valore if isinstance(valore, str) else rappresenta(valore)
    if "\0" in testo:
        raise ErroreValore("Il valore della variabile d'ambiente contiene un carattere non valido.")
    os.environ[nome] = testo
    return None


@funzione_libreria("togli_variabile_ambiente")
def togli_variabile_ambiente(nome):
    """togli_variabile_ambiente(nome): toglie una variabile d'ambiente da questo programma.

    Restituisce `vero` se c'era. Esempio: `togli_variabile_ambiente("LINGUA")`.
    """
    _nome_variabile(nome, "togli_variabile_ambiente")
    if nome in os.environ:
        del os.environ[nome]
        return True
    return False


@funzione_libreria("variabili_ambiente")
def variabili_ambiente():
    """variabili_ambiente(): un dizionario con tutte le variabili d'ambiente (nome -> valore), in ordine.

    Esempio: `per ogni nome in variabili_ambiente().chiavi() fai stampa(nome) fine`.
    """
    return {k: os.environ[k] for k in sorted(os.environ, key=str.lower)}


@funzione_libreria("espandi_variabili_ambiente")
def espandi_variabili_ambiente(testo):
    """espandi_variabili_ambiente(testo): sostituisce le parti come `%USERPROFILE%` con il loro valore.

    Le variabili sconosciute restano come sono.
    Esempio: `espandi_variabili_ambiente("%APPDATA%\\\\MioProgramma")`.
    """
    richiedi_testo(testo, "espandi_variabili_ambiente", "testo")
    return programmi.espandi_variabili(testo)


# ===========================================================================
# Processi
# ===========================================================================

def _voce_processo(p: dict) -> dict:
    memoria = p.get("memoria")
    return {
        "nome": p["nome"],
        "pid": int(p["pid"]),
        "pid_padre": int(p.get("pid_padre") or 0),
        "memoria": memoria,
        "memoria_mb": round(memoria / (1024 * 1024), 1) if isinstance(memoria, int) else None,
    }


def _processi() -> list[dict]:
    voci = [_voce_processo(p) for p in _n().elenca_processi()]
    voci.sort(key=lambda v: (v["nome"].lower(), v["pid"]))
    return voci


@funzione_libreria("elenca_processi")
def elenca_processi(filtro=""):
    """elenca_processi(filtro = ""): la lista dei programmi in esecuzione (processi).

    Ogni elemento è un dizionario con "nome", "pid", "pid_padre", "memoria" (byte, `nulla` se
    Windows non la dice) e "memoria_mb". Con `filtro` tiene solo i nomi che lo contengono.
    Solo su Windows. Esempio: `per ogni p in elenca_processi("chrome") fai stampa(p["pid"], p["memoria_mb"]) fine`.
    """
    richiedi_testo(filtro, "elenca_processi", "filtro")
    voci = _processi()
    f = filtro.strip().lower()
    return [v for v in voci if f in v["nome"].lower()] if f else voci


@funzione_libreria("trova_processi")
def trova_processi(nome):
    """trova_processi(nome): i processi con esattamente quel nome ("notepad" trova anche "notepad.exe").

    Restituisce una lista di dizionari come `elenca_processi`. Solo su Windows.
    Esempio: `stampa(lunghezza(trova_processi("notepad")), "Blocco note aperti")`.
    """
    _testo_pieno(nome, "trova_processi", "nome", 'trova_processi("notepad")')
    return [v for v in _processi() if programmi.stesso_nome_processo(v["nome"], nome)]


def _bersagli(nome_o_pid: Any, funzione: str) -> list[dict]:
    if isinstance(nome_o_pid, bool) or not isinstance(nome_o_pid, (str, int)):
        raise ErroreTipo(f"`{funzione}` vuole il nome del programma (testo) o il suo pid (intero), "
                         f"non {articolo(nome_o_pid)}.",
                         suggerimento=f'Scrivi per esempio `{funzione}("notepad")`.')
    if isinstance(nome_o_pid, int):
        return [v for v in _processi() if v["pid"] == nome_o_pid]
    _testo_pieno(nome_o_pid, funzione, "nome_o_pid", f'{funzione}("notepad")')
    return [v for v in _processi() if programmi.stesso_nome_processo(v["nome"], nome_o_pid)]


@funzione_libreria("processo_esiste")
def processo_esiste(nome_o_pid):
    """processo_esiste(nome_o_pid): `vero` se un programma con quel nome (o quel pid) è in esecuzione.

    Solo su Windows. Esempio: `se processo_esiste("excel") allora stampa("Excel è aperto") fine`.
    """
    return bool(_bersagli(nome_o_pid, "processo_esiste"))


@funzione_libreria("pid_corrente")
def pid_corrente():
    """pid_corrente(): il numero (pid) del processo di questo programma.

    Esempio: `stampa("Il mio pid è", pid_corrente())`.
    """
    return os.getpid()


@funzione_libreria("termina_processo", interprete=True)
def termina_processo(interprete, nome_o_pid, senza_conferma=False):
    """termina_processo(nome_o_pid, senza_conferma = falso): chiude a forza un programma; restituisce quanti ne ha chiusi.

    Con un nome chiude tutti i processi con quel nome. Prima chiede conferma all'utente (i dati non
    salvati di quel programma vanno persi); se l'utente dice No restituisce 0. I processi vitali di
    Windows e questo stesso programma non si chiudono. Solo su Windows.
    Esempio: `termina_processo("notepad")`.
    """
    richiedi_logico(senza_conferma, "termina_processo", "senza_conferma")
    bersagli = _bersagli(nome_o_pid, "termina_processo")
    if not bersagli:
        return 0
    mio = os.getpid()
    for b in bersagli:
        if b["pid"] == mio:
            raise ErroreValore("`termina_processo` non può chiudere questo stesso programma.",
                               suggerimento="Per finire il programma lascialo arrivare in fondo o chiudi la sua finestra.")
        if b["nome"].lower() in programmi.PROCESSI_PROTETTI or b["pid"] in (0, 4):
            raise ErroreSistema(f"Non chiudo `{b['nome']}`: è una parte vitale di Windows.",
                                suggerimento="Chiuderla bloccherebbe il computer.")
    nome = bersagli[0]["nome"]
    pid = ", ".join(str(b["pid"]) for b in bersagli)
    quanti = "1 processo" if len(bersagli) == 1 else f"{len(bersagli)} processi"
    domanda = (f"Il programma vuole chiudere a forza «{nome}» ({quanti}, pid {pid}).\n"
               "I dati non salvati di quel programma andranno persi.\n\nVuoi permetterlo?")
    if not _chiedi(interprete, senza_conferma, "termina_processo", domanda):
        return 0
    chiusi, primo_errore = 0, None
    for b in bersagli:
        try:
            _n().termina(b["pid"])
            chiusi += 1
        except ErroreSistema as e:
            primo_errore = primo_errore or e
    if chiusi == 0 and primo_errore is not None:
        raise primo_errore
    return chiusi


# ===========================================================================
# Programmi, file, cartelle, siti, impostazioni
# ===========================================================================

def _argomenti(argomenti: Any, funzione: str) -> list[str]:
    if argomenti is None:
        return []
    if isinstance(argomenti, str):
        if "\0" in argomenti:
            raise ErroreValore(f"Un argomento di `{funzione}` contiene un carattere non valido.")
        return [argomenti] if argomenti != "" else []
    if isinstance(argomenti, list):
        risultato = []
        for a in argomenti:
            if isinstance(a, bool) or not isinstance(a, (str, int, float)):
                raise ErroreTipo(f"Gli argomenti di `{funzione}` devono essere testi o numeri, non {articolo(a)}.")
            risultato.append(a if isinstance(a, str) else rappresenta(a))
        if any("\0" in a for a in risultato):
            raise ErroreValore(f"Un argomento di `{funzione}` contiene un carattere non valido.")
        return risultato
    raise ErroreTipo(f"`argomenti` di `{funzione}` deve essere una lista di testi (o un testo), "
                     f"non {articolo(argomenti)}.",
                     suggerimento=f'Scrivi per esempio `{funzione}("notepad.exe", ["nota.txt"])`.')


@funzione_libreria("avvia_programma")
def avvia_programma(programma, argomenti=None, attendi=False, cartella=None, tempo_massimo=None):
    """avvia_programma(programma, argomenti = [], attendi = falso, cartella = nulla, tempo_massimo = nulla): avvia un programma.

    Senza `attendi` restituisce subito il pid del nuovo processo; con `attendi = vero` aspetta che
    finisca e restituisce il suo codice di uscita (0 = tutto bene), oppure `nulla` se supera
    `tempo_massimo` secondi (il programma resta aperto).
    Esempi: `avvia_programma("notepad.exe", ["nota.txt"])`,
    `variabile codice = avvia_programma("C:/Strumenti/converti.exe", ["a.csv"], attendi = vero)`.
    """
    _testo_pieno(programma, "avvia_programma", "programma", 'avvia_programma("notepad.exe")')
    lista = _argomenti(argomenti, "avvia_programma")
    richiedi_logico(attendi, "avvia_programma", "attendi")
    dove = _cartella_esistente(cartella, "avvia_programma")
    limite = _tempo(tempo_massimo, "avvia_programma")
    try:
        processo = _n().avvia([programma, *lista], dove)
    except FileNotFoundError:
        raise ErroreFile(f"Non trovo il programma `{programma}`.",
                         suggerimento="Scrivi il percorso completo, per esempio "
                                      "\"C:/Program Files/Programma/programma.exe\".") from None
    except PermissionError:
        raise ErroreFile(f"Non ho il permesso di avviare `{programma}`.") from None
    except OSError as e:
        raise ErroreSistema(f"Non sono riuscito ad avviare `{programma}`: {e.strerror or e}.") from None
    if not attendi:
        return int(processo.pid)
    try:
        return int(processo.wait(timeout=limite))
    except subprocess.TimeoutExpired:
        return None


@funzione_libreria("apri_con_programma_predefinito")
def apri_con_programma_predefinito(percorso):
    """apri_con_programma_predefinito(percorso): apre un file con il suo programma (come il doppio clic).

    Un ".pdf" si apre con il lettore PDF, un ".docx" con Word e così via. Solo su Windows.
    Esempio: `apri_con_programma_predefinito("resoconto.pdf")`.
    """
    completo = _esistente(percorso, "apri_con_programma_predefinito")
    solo_windows("apri_con_programma_predefinito")
    _n().apri_predefinito(completo)
    return None


@funzione_libreria("apri_in_esplora_file")
def apri_in_esplora_file(cartella=None):
    """apri_in_esplora_file(cartella = cartella corrente): mostra una cartella in Esplora file.

    Solo su Windows. Esempio: `apri_in_esplora_file(cartella_documenti())`.
    """
    if cartella is None:
        cartella = os.getcwd()
    completo = _esistente(cartella, "apri_in_esplora_file")
    if not os.path.isdir(completo):
        raise ErroreFile(f"`{cartella}` è un file, non una cartella.",
                         suggerimento=f'Per mostrare il file in Esplora usa `seleziona_in_esplora_file("{cartella}")`.')
    solo_windows("apri_in_esplora_file")
    _n().apri_esplora([f'"{completo}"'])
    return None


@funzione_libreria("seleziona_in_esplora_file")
def seleziona_in_esplora_file(percorso):
    """seleziona_in_esplora_file(percorso): apre Esplora file sulla cartella del file, con il file selezionato.

    Solo su Windows. Esempio: `seleziona_in_esplora_file("C:/Documenti/fattura.pdf")`.
    """
    completo = _esistente(percorso, "seleziona_in_esplora_file")
    solo_windows("seleziona_in_esplora_file")
    _n().apri_esplora([f'/select,"{completo}"'])
    return None


_SCHEMI_WEB = ("http://", "https://", "mailto:")


def indirizzo_web_valido(indirizzo: str) -> str | None:
    """L'indirizzo pronto per il browser ("www.x.it" -> "https://www.x.it"), o None se non va bene."""
    s = indirizzo.strip()
    if any(c.isspace() for c in s) or not s:
        return None
    if s.lower().startswith(_SCHEMI_WEB):
        return s
    if re.match(r"^[a-z][a-z0-9+.\-]*:", s, re.IGNORECASE) and not re.match(r"^[^/]+:\d+", s):
        return None  # javascript:, file:, ms-...: non sono indirizzi web
    if re.match(r"^[\w\-]+(\.[\w\-]+)+(:\d+)?(/.*)?$", s) or s.lower().startswith("localhost"):
        return "https://" + s if not s.lower().startswith("localhost") else "http://" + s
    return None


@funzione_libreria("apri_indirizzo_web")
def apri_indirizzo_web(indirizzo):
    """apri_indirizzo_web(indirizzo): apre un sito nel browser predefinito.

    Senza "https://" lo aggiunge Leo. Si accettano anche gli indirizzi "mailto:".
    Esempio: `apri_indirizzo_web("www.wikipedia.it")`.
    """
    _testo_pieno(indirizzo, "apri_indirizzo_web", "indirizzo", 'apri_indirizzo_web("https://www.wikipedia.it")')
    pronto = indirizzo_web_valido(indirizzo)
    if pronto is None:
        raise ErroreValore(f"{mostra(indirizzo)} non è un indirizzo web.",
                           suggerimento="Scrivi per esempio \"https://www.esempio.it\".")
    from ..piattaforma import non_su_android

    non_su_android("apri_indirizzo_web")
    if not _n().apri_web(pronto):
        raise ErroreSistema("Non sono riuscito ad aprire il browser.")
    return None


@funzione_libreria("apri_impostazioni_windows")
def apri_impostazioni_windows(sezione="home"):
    """apri_impostazioni_windows(sezione = "home"): apre le Impostazioni di Windows alla pagina giusta.

    Sezioni: "schermo", "suoni", "wifi", "bluetooth", "rete", "stampanti", "sfondo", "temi",
    "app_predefinite", "app_avvio", "aggiornamenti", "privacy", "data_ora", "lingua"... (tutte con
    `sezioni_impostazioni()`), oppure una pagina "ms-settings:...". Solo su Windows.
    Esempio: `apri_impostazioni_windows("bluetooth")`.
    """
    richiedi_testo(sezione, "apri_impostazioni_windows", "sezione")
    uri = programmi.uri_impostazioni(sezione or "home")
    if uri is None:
        simili = difflib.get_close_matches(sezione.strip().lower(), list(programmi.SEZIONI_IMPOSTAZIONI), n=2)
        suggerimento = (("Forse intendevi " + " o ".join(f'"{s}"' for s in simili) + "? ") if simili else "") + \
            "L'elenco completo è in `sezioni_impostazioni()`."
        raise ErroreValore(f"Non conosco la sezione delle impostazioni {mostra(sezione)}.", suggerimento=suggerimento)
    solo_windows("apri_impostazioni_windows")
    _n().apri_predefinito(uri)
    return None


@funzione_libreria("sezioni_impostazioni")
def sezioni_impostazioni():
    """sezioni_impostazioni(): i nomi delle sezioni che `apri_impostazioni_windows` conosce.

    Esempio: `stampa(sezioni_impostazioni())`.
    """
    return sorted(programmi.SEZIONI_IMPOSTAZIONI)


# ===========================================================================
# Comandi e PowerShell (con conferma)
# ===========================================================================

def _risultato_comando(uscita: Any, errore: Any, codice: int | None, scaduto: bool) -> dict:
    return {
        "uscita": _win.decodifica_uscita(uscita),
        "errore": _win.decodifica_uscita(errore),
        "codice": codice,
        "riuscito": codice == 0 and not scaduto,
        "scaduto": scaduto,
        "annullato": False,
    }


def _annullato() -> dict:
    return {"uscita": "", "errore": "Annullato: l'utente non ha dato il permesso.", "codice": None,
            "riuscito": False, "scaduto": False, "annullato": True}


def _esegui(comando: Any, shell: bool, tempo: float | None, dove: str | None, nome: str) -> dict:
    try:
        uscita, errore, codice, scaduto = _n().esegui(comando, shell, tempo, dove)
    except FileNotFoundError:
        raise ErroreFile(f"`{nome}`: non trovo il programma da eseguire.",
                         suggerimento="Controlla il nome del comando o scrivi il percorso completo.") from None
    except OSError as e:
        raise ErroreSistema(f"`{nome}` non è riuscito a partire: {e.strerror or e}.") from None
    return _risultato_comando(uscita, errore, codice, scaduto)


@funzione_libreria("esegui_comando", interprete=True)
def esegui_comando(interprete, comando, tempo_massimo=60, cartella=None, senza_conferma=False):
    """esegui_comando(comando, tempo_massimo = 60, cartella = nulla, senza_conferma = falso): esegue un comando del Prompt.

    Il comando viene mostrato all'utente, che deve dare il permesso (salvo `senza_conferma = vero`).
    `comando` è un testo (come nel Prompt dei comandi) oppure una lista [programma, argomenti...].
    Restituisce un dizionario: "uscita", "errore" (testi), "codice" (0 = riuscito), "riuscito",
    "scaduto" (superato `tempo_massimo` secondi), "annullato" (l'utente ha detto No).
    Esempio: `variabile r = esegui_comando("ipconfig")` poi `stampa(r["uscita"])`.
    """
    if isinstance(comando, list):
        lista = _argomenti(comando, "esegui_comando")
        if not lista or not lista[0].strip():
            raise ErroreValore("La lista del comando di `esegui_comando` è vuota.",
                               suggerimento='Scrivi per esempio `esegui_comando(["ping", "-n", "1", "localhost"])`.')
        mostrato, shell, da_eseguire = programmi.riga_di_comando(lista[0], lista[1:]), False, lista
    else:
        _testo_pieno(comando, "esegui_comando", "comando", 'esegui_comando("ipconfig")')
        mostrato, shell, da_eseguire = comando, True, comando
    tempo = _tempo(tempo_massimo, "esegui_comando")
    dove = _cartella_esistente(cartella, "esegui_comando")
    domanda = f"Il programma vuole eseguire questo comando:\n\n{mostrato}\n\nVuoi permetterlo?"
    if not _chiedi(interprete, senza_conferma, "esegui_comando", domanda):
        return _annullato()
    return _esegui(da_eseguire, shell, tempo, dove, "esegui_comando")


@funzione_libreria("esegui_powershell", interprete=True)
def esegui_powershell(interprete, script, tempo_massimo=60, cartella=None, senza_conferma=False):
    """esegui_powershell(script, tempo_massimo = 60, cartella = nulla, senza_conferma = falso): esegue comandi PowerShell.

    Lo script viene mostrato all'utente, che deve dare il permesso (salvo `senza_conferma = vero`).
    Restituisce lo stesso dizionario di `esegui_comando` ("uscita", "errore", "codice", "riuscito",
    "scaduto", "annullato"). Solo su Windows.
    Esempio: `stampa(esegui_powershell("Get-Date -Format dd/MM/yyyy")["uscita"])`.
    """
    _testo_pieno(script, "esegui_powershell", "script", 'esegui_powershell("Get-Date")')
    tempo = _tempo(tempo_massimo, "esegui_powershell")
    dove = _cartella_esistente(cartella, "esegui_powershell")
    solo_windows("esegui_powershell")
    domanda = f"Il programma vuole eseguire questi comandi PowerShell:\n\n{script}\n\nVuoi permetterlo?"
    if not _chiedi(interprete, senza_conferma, "esegui_powershell", domanda):
        return _annullato()
    return _esegui(_win.comando_powershell(script), False, tempo, dove, "esegui_powershell")


# ===========================================================================
# Appunti
# ===========================================================================

_CF_UNICODETEXT, _CF_BITMAP, _CF_DIB, _CF_DIBV5, _CF_HDROP = 13, 2, 8, 17, 15


@funzione_libreria("leggi_appunti")
def leggi_appunti():
    """leggi_appunti(): il testo copiato negli appunti ("" se negli appunti non c'è testo).

    Solo su Windows. Esempio: `stampa("Hai copiato:", leggi_appunti())`.
    """
    solo_windows("leggi_appunti")
    testo = _n().leggi_appunti()
    return (testo or "").replace("\r\n", "\n")


@funzione_libreria("scrivi_appunti")
def scrivi_appunti(testo):
    """scrivi_appunti(testo): copia un testo negli appunti (poi si incolla con Ctrl+V).

    Numeri e liste si copiano come si vedono con `stampa`. Solo su Windows.
    Esempio: `scrivi_appunti("Ciao da Leo!")`.
    """
    valore = testo if isinstance(testo, str) else rappresenta(testo)
    if "\0" in valore:
        raise ErroreValore("Il testo per gli appunti contiene un carattere non valido.")
    solo_windows("scrivi_appunti")
    _n().scrivi_appunti(valore.replace("\r\n", "\n").replace("\n", "\r\n"))
    return None


@funzione_libreria("svuota_appunti")
def svuota_appunti():
    """svuota_appunti(): cancella il contenuto degli appunti.

    Solo su Windows. Esempio: `svuota_appunti()`.
    """
    solo_windows("svuota_appunti")
    _n().svuota_appunti()
    return None


@funzione_libreria("appunti_contiene_testo")
def appunti_contiene_testo():
    """appunti_contiene_testo(): `vero` se negli appunti c'è un testo.

    Solo su Windows. Esempio: `se appunti_contiene_testo() allora stampa(leggi_appunti()) fine`.
    """
    solo_windows("appunti_contiene_testo")
    return _n().formato_appunti_presente(_CF_UNICODETEXT)


@funzione_libreria("appunti_contiene_immagine")
def appunti_contiene_immagine():
    """appunti_contiene_immagine(): `vero` se negli appunti c'è un'immagine (per esempio uno screenshot).

    Solo su Windows. Esempio: `se appunti_contiene_immagine() allora salva_immagine_appunti("cattura.png") fine`.
    """
    solo_windows("appunti_contiene_immagine")
    n = _n()
    return any(n.formato_appunti_presente(f) for f in (_CF_DIB, _CF_BITMAP, _CF_DIBV5))


@funzione_libreria("salva_immagine_appunti")
def salva_immagine_appunti(percorso):
    """salva_immagine_appunti(percorso): salva l'immagine degli appunti in un file PNG.

    Restituisce `vero` se l'ha salvata, `falso` se negli appunti non c'è un'immagine.
    Solo su Windows. Esempio: `salva_immagine_appunti(unisci_percorso(cartella_immagini(), "cattura.png"))`.
    """
    _testo_pieno(percorso, "salva_immagine_appunti", "percorso", 'salva_immagine_appunti("cattura.png")')
    radice, est = os.path.splitext(percorso)
    if not est:
        percorso = percorso + ".png"
    elif est.lower() != ".png":
        raise ErroreValore(f"`salva_immagine_appunti` salva solo immagini PNG, non `{est}`.",
                           suggerimento=f'Usa un nome che finisce con ".png", per esempio "{os.path.basename(radice)}.png".')
    completo = os.path.abspath(percorso)
    cartella = os.path.dirname(completo)
    if not os.path.isdir(cartella):
        raise ErroreFile(f"La cartella `{cartella}` non esiste.",
                         suggerimento="Creala prima con `crea_cartella(...)`.")
    solo_windows("salva_immagine_appunti")
    return bool(_n().salva_immagine_appunti(completo))


@funzione_libreria("copia_file_negli_appunti")
def copia_file_negli_appunti(percorsi):
    """copia_file_negli_appunti(percorsi): copia uno o più file negli appunti, come Ctrl+C in Esplora file.

    `percorsi` è un testo o una lista di testi; poi si incollano con Ctrl+V in una cartella.
    Solo su Windows. Esempio: `copia_file_negli_appunti(["foto1.jpg", "foto2.jpg"])`.
    """
    elenco = [percorsi] if isinstance(percorsi, str) else percorsi
    if not isinstance(elenco, list) or not elenco:
        raise ErroreTipo(f"`copia_file_negli_appunti` vuole un percorso o una lista di percorsi, "
                         f"non {articolo(percorsi)}.",
                         suggerimento='Scrivi per esempio `copia_file_negli_appunti(["a.txt", "b.txt"])`.')
    completi = [_esistente(p, "copia_file_negli_appunti") for p in elenco]
    solo_windows("copia_file_negli_appunti")
    _n().copia_file_appunti(completi)
    return None


# ===========================================================================
# Cestino
# ===========================================================================

@funzione_libreria("sposta_nel_cestino")
def sposta_nel_cestino(percorso):
    """sposta_nel_cestino(percorso): mette un file o una cartella nel cestino (si può ripristinare).

    Le cartelle importanti (Documenti, Desktop, la cartella personale...) sono protette.
    Esempio: `sposta_nel_cestino("vecchia_bozza.txt")`.
    """
    from . import cartelle

    _testo_pieno(percorso, "sposta_nel_cestino", "percorso", 'sposta_nel_cestino("bozza.txt")')
    cartelle._richiedi_esistente(percorso)
    cartelle._guardia(percorso, "spostare nel cestino")
    try:
        _n().al_cestino(percorso)
    except cartelle._CestinoNonDisponibile as e:
        raise ErroreFile(f"Non posso mettere `{percorso}` nel cestino: {e}.") from None
    except OSError as e:
        raise cartelle._errore_os(e, percorso, "spostare nel cestino") from None
    return None


@funzione_libreria("elementi_nel_cestino")
def elementi_nel_cestino():
    """elementi_nel_cestino(): quanti file e cartelle ci sono nel cestino.

    Solo su Windows. Esempio: `stampa("Nel cestino:", elementi_nel_cestino())`.
    """
    solo_windows("elementi_nel_cestino")
    return _n().info_cestino()[0]


@funzione_libreria("dimensione_cestino")
def dimensione_cestino():
    """dimensione_cestino(): quanti byte occupa il cestino.

    Solo su Windows. Esempio: `stampa(dimensione_leggibile(dimensione_cestino()))`.
    """
    solo_windows("dimensione_cestino")
    return _n().info_cestino()[1]


@funzione_libreria("svuota_cestino", interprete=True)
def svuota_cestino(interprete, senza_conferma=False):
    """svuota_cestino(senza_conferma = falso): elimina per sempre tutto quello che c'è nel cestino.

    Prima chiede conferma all'utente. Restituisce `vero` se il cestino ora è vuoto, `falso` se
    l'utente ha detto No. Solo su Windows. Esempio: `svuota_cestino()`.
    """
    richiedi_logico(senza_conferma, "svuota_cestino", "senza_conferma")
    solo_windows("svuota_cestino")
    elementi, byte = _n().info_cestino()
    if elementi == 0:
        return True
    from .cartelle import dimensione_leggibile

    cosa = "1 elemento" if elementi == 1 else f"{elementi} elementi"
    domanda = (f"Il programma vuole svuotare il cestino ({cosa}, {dimensione_leggibile(byte)}).\n"
               "I file verranno eliminati per sempre.\n\nVuoi permetterlo?")
    if not _chiedi(interprete, senza_conferma, "svuota_cestino", domanda):
        return False
    _n().svuota_cestino()
    return True


# ===========================================================================
# Collegamenti (.lnk) e file recenti
# ===========================================================================

_VIETATI_NOME = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def _cartella_collegamento(dove: str) -> str:
    chiave = dove.strip().lower().replace(" ", "_")
    if chiave in ("desktop", "scrivania"):
        return _cartella("desktop")
    if chiave in ("menu_start", "start"):
        return _cartella("programmi_menu_start")
    if not os.path.isdir(dove):
        raise ErroreFile(f"La cartella `{dove}` non esiste.",
                         suggerimento='Usa "desktop", "menu_start" oppure il percorso di una cartella che esiste.')
    return os.path.abspath(dove)


@funzione_libreria("crea_collegamento")
def crea_collegamento(destinazione, nome=None, dove="desktop", argomenti="", icona="", descrizione="",
                      cartella_lavoro="", sovrascrivi=False):
    """crea_collegamento(destinazione, nome, dove = "desktop", argomenti, icona, descrizione, cartella_lavoro, sovrascrivi = falso): crea un collegamento (.lnk).

    `dove` è "desktop", "menu_start" oppure una cartella. `icona` è un file .ico/.exe (anche
    "file.exe,2" per la terza icona). Restituisce il percorso del collegamento. Solo su Windows.
    Esempio: `crea_collegamento("C:/Giochi/gioco.exe", "Il mio gioco", icona = "C:/Giochi/gioco.ico")`.
    """
    completo = _esistente(destinazione, "crea_collegamento")
    for valore, parametro in ((argomenti, "argomenti"), (icona, "icona"), (descrizione, "descrizione"),
                              (cartella_lavoro, "cartella_lavoro"), (dove, "dove")):
        richiedi_testo(valore, "crea_collegamento", parametro)
    richiedi_logico(sovrascrivi, "crea_collegamento", "sovrascrivi")
    if nome is None:
        nome = os.path.splitext(os.path.basename(completo.rstrip("\\/")))[0] or "Collegamento"
    _testo_pieno(nome, "crea_collegamento", "nome", 'crea_collegamento("gioco.exe", "Il mio gioco")')
    if nome.lower().endswith(".lnk"):
        nome = nome[:-4]
    if _VIETATI_NOME.search(nome) or nome.strip() in (".", ".."):
        raise ErroreValore(f"Il nome del collegamento {mostra(nome)} contiene caratteri che Windows non accetta.",
                           suggerimento='Non usare < > : " / \\ | ? *.')
    if icona:
        parte_file = icona.rsplit(",", 1)[0] if re.search(r",\s*-?\d+$", icona) else icona
        if not os.path.exists(parte_file):
            raise ErroreFile(f"Il file dell'icona `{parte_file}` non esiste.")
        if parte_file == icona:
            icona = os.path.abspath(icona) + ",0"
        else:
            icona = os.path.abspath(parte_file) + "," + icona.rsplit(",", 1)[1].strip()
    if cartella_lavoro:
        cartella_lavoro = _cartella_esistente(cartella_lavoro, "crea_collegamento") or ""
    solo_windows("crea_collegamento")
    percorso_lnk = os.path.join(_cartella_collegamento(dove), nome.strip() + ".lnk")
    if os.path.exists(percorso_lnk) and not sovrascrivi:
        raise ErroreFile(f"Il collegamento `{percorso_lnk}` esiste già.",
                         suggerimento="Scegli un altro nome oppure aggiungi `sovrascrivi = vero`.")
    _n().crea_collegamento(percorso_lnk, completo, argomenti, cartella_lavoro, icona, descrizione)
    return percorso_lnk


def _leggi_lnk(percorso: Any, funzione: str) -> dict:
    completo = _esistente(percorso, funzione)
    if not completo.lower().endswith(".lnk"):
        raise ErroreValore(f"`{percorso}` non è un collegamento (.lnk).",
                           suggerimento="I collegamenti di Windows hanno l'estensione \".lnk\".")
    solo_windows(funzione)
    dati = _n().leggi_collegamenti([completo])
    d = dati[0] if dati else {}
    return {
        "destinazione": str(d.get("d") or ""),
        "argomenti": str(d.get("a") or ""),
        "cartella_lavoro": str(d.get("w") or ""),
        "icona": str(d.get("i") or ""),
        "descrizione": str(d.get("s") or ""),
    }


@funzione_libreria("destinazione_collegamento")
def destinazione_collegamento(percorso):
    """destinazione_collegamento(percorso): il file o la cartella a cui porta un collegamento .lnk.

    Solo su Windows. Esempio: `stampa(destinazione_collegamento("C:/Users/ada/Desktop/Gioco.lnk"))`.
    """
    return _leggi_lnk(percorso, "destinazione_collegamento")["destinazione"]


@funzione_libreria("info_collegamento")
def info_collegamento(percorso):
    """info_collegamento(percorso): un dizionario con "destinazione", "argomenti", "cartella_lavoro", "icona", "descrizione".

    Solo su Windows. Esempio: `stampa(info_collegamento("Gioco.lnk")["argomenti"])`.
    """
    return _leggi_lnk(percorso, "info_collegamento")


@funzione_libreria("file_recenti")
def file_recenti(quanti=20):
    """file_recenti(quanti = 20): i file aperti di recente in Windows, dal più nuovo.

    Ogni elemento è un dizionario con "nome", "percorso", "data" (quando è stato aperto),
    "esiste" e "cartella" (vero se è una cartella). Solo su Windows.
    Esempio: `per ogni f in file_recenti(5) fai stampa(f["nome"], f["data"]) fine`.
    """
    richiedi_intero(quanti, "file_recenti", "quanti")
    if quanti <= 0:
        raise ErroreValore("`quanti` di `file_recenti` deve essere maggiore di zero.")
    solo_windows("file_recenti")
    cartella = _n().cartella_recenti()
    if not cartella or not os.path.isdir(cartella):
        return []
    voci = []
    for voce in os.scandir(cartella):
        if voce.name.lower().endswith(".lnk") and voce.is_file():
            try:
                voci.append((voce.stat().st_mtime, voce.path))
            except OSError:
                continue
    voci.sort(reverse=True)
    voci = voci[: quanti * 2]  # qualche collegamento non porta a un file: se ne leggono di piu'
    date = {p: m for m, p in voci}
    risultato = []
    for d in _n().leggi_collegamenti([p for _, p in voci]):
        bersaglio = str(d.get("d") or "")
        if not bersaglio:
            continue
        risultato.append({
            "nome": re.split(r"[\\/]", bersaglio.rstrip("\\/"))[-1] or bersaglio,
            "percorso": bersaglio,
            "data": DataDante(programmi.data_da_timestamp(date.get(d.get("p"), 0))),
            "esiste": os.path.exists(bersaglio),
            "cartella": os.path.isdir(bersaglio),
        })
        if len(risultato) >= quanti:
            break
    return risultato


# ===========================================================================
# Avvio automatico dell'utente (HKCU\Software\Microsoft\Windows\CurrentVersion\Run)
# ===========================================================================

def _nome_avvio(nome: Any, funzione: str) -> str:
    _testo_pieno(nome, funzione, "nome", f'{funzione}("MioProgramma")')
    if "\\" in nome or len(nome) > 200:
        raise ErroreValore(f"Il nome {mostra(nome)} non va bene per l'avvio automatico.",
                           suggerimento="Usa un nome breve senza `\\`, per esempio \"MioProgramma\".")
    return nome.strip()


@funzione_libreria("programmi_all_avvio")
def programmi_all_avvio():
    """programmi_all_avvio(): i programmi che partono quando accedi a Windows (nome -> comando).

    Sono quelli del tuo utente (non quelli di tutto il computer). Solo su Windows.
    Esempio: `stampa(programmi_all_avvio())`.
    """
    solo_windows("programmi_all_avvio")
    voci = _n().leggi_avvio()
    return {k: voci[k] for k in sorted(voci, key=str.lower)}


def _trova_avvio(nome: str) -> str | None:
    for k in _n().leggi_avvio():
        if k.lower() == nome.lower():
            return k
    return None


@funzione_libreria("e_all_avvio")
def e_all_avvio(nome):
    """e_all_avvio(nome): `vero` se nell'avvio automatico c'è un programma con questo nome.

    Solo su Windows. Esempio: `se non e_all_avvio("MioProgramma") allora stampa("Non parte da solo") fine`.
    """
    nome = _nome_avvio(nome, "e_all_avvio")
    solo_windows("e_all_avvio")
    return _trova_avvio(nome) is not None


@funzione_libreria("aggiungi_all_avvio", interprete=True)
def aggiungi_all_avvio(interprete, programma, nome=None, argomenti="", senza_conferma=False):
    """aggiungi_all_avvio(programma, nome, argomenti = "", senza_conferma = falso): fa partire un programma quando accedi a Windows.

    Scrive solo nelle impostazioni del tuo utente, dopo aver chiesto conferma. Restituisce `vero` se
    l'ha aggiunto, `falso` se l'utente ha detto No. Solo su Windows.
    Esempio: `aggiungi_all_avvio("C:/Programmi/Promemoria/promemoria.exe", "Promemoria")`.
    """
    completo = _esistente(programma, "aggiungi_all_avvio")
    if not os.path.isfile(completo):
        raise ErroreFile(f"`{programma}` è una cartella, non un programma.")
    richiedi_testo(argomenti, "aggiungi_all_avvio", "argomenti")
    if nome is None:
        nome = os.path.splitext(os.path.basename(completo))[0]
    nome = _nome_avvio(nome, "aggiungi_all_avvio")
    solo_windows("aggiungi_all_avvio")
    valore = programmi.valore_avvio(completo, argomenti)
    domanda = (f"Il programma vuole far partire «{nome}» ogni volta che accedi a Windows:\n\n{valore}\n\n"
               "Vuoi permetterlo?")
    if not _chiedi(interprete, senza_conferma, "aggiungi_all_avvio", domanda):
        return False
    _n().scrivi_avvio(_trova_avvio(nome) or nome, valore)
    return True


@funzione_libreria("togli_dall_avvio", interprete=True)
def togli_dall_avvio(interprete, nome, senza_conferma=False):
    """togli_dall_avvio(nome, senza_conferma = falso): toglie un programma dall'avvio automatico.

    Chiede conferma. Restituisce `vero` se l'ha tolto, `falso` se non c'era o se l'utente ha detto No.
    Solo su Windows. Esempio: `togli_dall_avvio("Promemoria")`.
    """
    nome = _nome_avvio(nome, "togli_dall_avvio")
    richiedi_logico(senza_conferma, "togli_dall_avvio", "senza_conferma")
    solo_windows("togli_dall_avvio")
    trovato = _trova_avvio(nome)
    if trovato is None:
        return False
    domanda = f"Il programma vuole togliere «{trovato}» dai programmi che partono con Windows.\n\nVuoi permetterlo?"
    if not _chiedi(interprete, senza_conferma, "togli_dall_avvio", domanda):
        return False
    return bool(_n().togli_avvio(trovato))


# ===========================================================================
# Associazioni dei file
# ===========================================================================

def _estensione(estensione: Any, funzione: str) -> str:
    _testo_pieno(estensione, funzione, "estensione", f'{funzione}(".pdf")')
    e = estensione.strip().lower()
    if not e.startswith("."):
        e = "." + e
    if not re.fullmatch(r"\.[\w\-]{1,30}", e):
        raise ErroreValore(f"{mostra(estensione)} non è un'estensione di file.",
                           suggerimento=f'Scrivi per esempio `{funzione}(".pdf")`.')
    return e


@funzione_libreria("programma_predefinito")
def programma_predefinito(estensione):
    """programma_predefinito(estensione): il percorso del programma che apre quel tipo di file (o `nulla`).

    Solo su Windows. Esempio: `stampa(programma_predefinito(".pdf"))`.
    """
    e = _estensione(estensione, "programma_predefinito")
    solo_windows("programma_predefinito")
    return _n().associazione(e, 2)  # ASSOCSTR_EXECUTABLE


@funzione_libreria("nome_programma_predefinito")
def nome_programma_predefinito(estensione):
    """nome_programma_predefinito(estensione): il nome del programma che apre quel tipo di file, per esempio "Blocco note".

    Restituisce `nulla` se nessun programma è associato. Solo su Windows.
    Esempio: `stampa("I .txt si aprono con", nome_programma_predefinito("txt"))`.
    """
    e = _estensione(estensione, "nome_programma_predefinito")
    solo_windows("nome_programma_predefinito")
    return _n().associazione(e, 4)  # ASSOCSTR_FRIENDLYAPPNAME


#: Tutte le funzioni registrate da questo modulo (per i test e la documentazione).
NOMI_S1 = (
    "nome_computer", "nome_utente", "versione_windows", "info_windows", "architettura", "tempo_accensione",
    "tempo_accensione_testo", "cartella_speciale", "cartella_immagini", "cartella_musica", "cartella_video",
    "cartella_appdata", "cartella_appdata_locale", "cartella_temp_sistema", "cartella_programmi",
    "cartella_menu_start", "leggi_variabile_ambiente", "imposta_variabile_ambiente", "togli_variabile_ambiente",
    "variabili_ambiente", "espandi_variabili_ambiente", "elenca_processi", "trova_processi", "processo_esiste",
    "pid_corrente", "termina_processo", "avvia_programma", "apri_con_programma_predefinito",
    "apri_in_esplora_file", "seleziona_in_esplora_file", "apri_indirizzo_web", "apri_impostazioni_windows",
    "sezioni_impostazioni", "esegui_comando", "esegui_powershell", "leggi_appunti", "scrivi_appunti",
    "svuota_appunti", "appunti_contiene_testo", "appunti_contiene_immagine", "salva_immagine_appunti",
    "copia_file_negli_appunti", "sposta_nel_cestino", "elementi_nel_cestino", "dimensione_cestino",
    "svuota_cestino", "crea_collegamento", "destinazione_collegamento", "info_collegamento", "file_recenti",
    "programmi_all_avvio", "e_all_avvio", "aggiungi_all_avvio", "togli_dall_avvio", "programma_predefinito",
    "nome_programma_predefinito",
)
