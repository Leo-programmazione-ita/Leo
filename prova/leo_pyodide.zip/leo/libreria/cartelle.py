"""Libreria: file e cartelle (copia, sposta, elimina nel cestino), percorsi e cartelle speciali.

Comandi sui file e sulle cartelle:
``e_file``, ``e_cartella``, ``copia_file``, ``copia_cartella``, ``sposta_file``,
``rinomina_file``, ``elimina_file``, ``elimina_cartella``, ``svuota_cartella``,
``cerca_file``, ``dimensione_file``, ``dimensione_cartella``,
``dimensione_leggibile``, ``data_modifica``, ``info_file``,
``cartella_corrente``, ``cambia_cartella``.

Percorsi: ``unisci_percorso``, ``nome_file``, ``nome_senza_estensione``,
``estensione_file``, ``cambia_estensione``, ``cartella_di``,
``percorso_completo``, ``percorso_relativo``.

Cartelle speciali: ``cartella_casa``, ``cartella_documenti``,
``cartella_desktop``, ``cartella_download``, ``cartella_programma``;
temporanei: ``file_temporaneo``, ``cartella_temporanea`` (spariscono alla
fine del programma).

Sicurezza:

* ``elimina_file``/``elimina_cartella`` mettono nel **cestino** del sistema
  (Windows, macOS, Linux con lo standard freedesktop); se il cestino non si
  può usare si fermano con un ``ErroreFile`` che spiega come eliminare per
  sempre (``definitivo = vero``). Nella cartella temporanea del sistema si
  elimina subito.
* la **guardia ai percorsi pericolosi** (:func:`motivo_pericolo`) rifiuta di
  eliminare, spostare o sovrascrivere la radice del disco, le cartelle di
  sistema, la cartella personale (e quelle che la contengono), le cartelle
  Documenti/Desktop/Download stesse, la cartella in cui si sta lavorando (e
  quelle che la contengono) e la cartella di Leo.
"""

from __future__ import annotations

import atexit
import datetime
import os
import shutil
import stat
import sys
import tempfile
from typing import Any

from ..errori import ErroreFile, ErroreTipo, ErroreValore
from ..valori import rappresenta
from .date import DataDante
from .generali import articolo, funzione_libreria, mostra, richiedi_logico, richiedi_testo
from .ingresso_uscita import _controlla_percorso, _errore_file

# ===========================================================================
# Strumenti interni
# ===========================================================================


def _esiste(percorso: str) -> bool:
    try:
        return os.path.lexists(percorso)
    except (OSError, ValueError):  # pragma: no cover - percorso strano
        return False


def _richiedi_esistente(percorso: str) -> None:
    if not _esiste(percorso):
        raise ErroreFile(f"`{percorso}` non esiste.",
                         suggerimento=f"Controlla il nome e la cartella: ora sei in `{os.getcwd()}`. "
                                      f"Puoi verificare prima con `esiste(\"{percorso}\")`.")


def _assoluto(percorso: str) -> str:
    return os.path.normcase(os.path.abspath(percorso))


def _dentro(percorso: str, cartella: str) -> bool:
    """`vero` se ``percorso`` (assoluto, normcase) è ``cartella`` o sta dentro di essa."""
    if percorso == cartella:
        return True
    base = cartella if cartella.endswith(os.sep) else cartella + os.sep
    return percorso.startswith(base)


def _cartella_leo() -> str:
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # .../leo


def _cartelle_di_sistema() -> list[str]:
    if os.name == "nt":
        radice = os.environ.get("SystemDrive", "C:") + "\\"
        cartelle = [os.environ.get("SystemRoot") or os.path.join(radice, "Windows"),
                    os.environ.get("ProgramFiles") or os.path.join(radice, "Program Files"),
                    os.environ.get("ProgramFiles(x86)") or os.path.join(radice, "Program Files (x86)"),
                    os.environ.get("ProgramData") or os.path.join(radice, "ProgramData")]
    else:
        cartelle = ["/bin", "/boot", "/dev", "/etc", "/lib", "/lib32", "/lib64", "/libx32", "/proc",
                    "/sbin", "/sys", "/usr", "/var", "/snap"]
        if sys.platform == "darwin":
            cartelle += ["/System", "/Library", "/Applications", "/private", "/cores"]
    return [_assoluto(c) for c in cartelle]


def _nella_temporanea(assoluto: str) -> bool:
    """`vero` se il percorso sta dentro la cartella temporanea del sistema (non è la cartella stessa)."""
    try:
        temporanee = {_assoluto(tempfile.gettempdir())}
    except (OSError, ValueError):  # pragma: no cover
        temporanee = set()
    if os.name != "nt":
        temporanee |= {_assoluto("/tmp"), _assoluto("/var/tmp")}
    return any(assoluto != t and _dentro(assoluto, t) for t in temporanee)


def motivo_pericolo(percorso: str) -> str | None:
    """Perché è pericoloso eliminare/spostare/sovrascrivere ``percorso`` (in italiano), o ``None``."""
    a = _assoluto(percorso)
    if os.path.dirname(a) == a:
        return "è la radice del disco"
    casa = _assoluto(os.path.expanduser("~"))
    if _dentro(casa, a):
        return "è la tua cartella personale" if a == casa else "contiene la tua cartella personale"
    for nome, trova in (("Documenti", cartella_documenti), ("Desktop", cartella_desktop),
                        ("Download", cartella_download)):
        try:
            if a == _assoluto(trova()):
                return f"è la cartella {nome}"
        except Exception:  # noqa: BLE001 - una cartella speciale introvabile non e' un pericolo
            pass
    try:
        corrente = _assoluto(os.getcwd())
    except OSError:  # pragma: no cover - cartella corrente sparita
        corrente = ""
    if corrente and _dentro(corrente, a):
        return ("è la cartella in cui stai lavorando" if a == corrente
                else "contiene la cartella in cui stai lavorando")
    leo = _assoluto(_cartella_leo())
    if _dentro(a, leo) or _dentro(leo, a):
        return "contiene i file di Leo stesso"
    if not _nella_temporanea(a):
        for c in _cartelle_di_sistema():
            if _dentro(a, c):
                return "è una cartella di sistema" if a == c else "è dentro una cartella di sistema"
    return None


def _guardia(percorso: str, azione: str) -> None:
    motivo = motivo_pericolo(percorso)
    if motivo:
        raise ErroreFile(f"Non posso {azione} `{percorso}`: {motivo}.",
                         suggerimento="Per sicurezza Leo non tocca queste cartelle. "
                                      "Lavora su file e cartelle creati dal tuo programma.")


def _errore_os(e: OSError, percorso: str, azione: str) -> ErroreFile:
    return _errore_file(e, percorso, azione)


def _rimuovi_solo_lettura(funzione, percorso, _info) -> None:
    """Per ``shutil.rmtree`` su Windows: i file di sola lettura si sbloccano e si riprovano."""
    os.chmod(percorso, stat.S_IWRITE)
    funzione(percorso)


def _elimina_per_sempre(percorso: str, e_cartella: bool) -> None:
    try:
        if e_cartella:
            if sys.version_info >= (3, 12):
                shutil.rmtree(percorso, onexc=_rimuovi_solo_lettura)
            else:  # pragma: no cover - Python 3.10/3.11
                shutil.rmtree(percorso, onerror=_rimuovi_solo_lettura)
        else:
            try:
                os.remove(percorso)
            except PermissionError:
                if os.name != "nt":
                    raise
                os.chmod(percorso, stat.S_IWRITE)
                os.remove(percorso)
    except OSError as e:
        raise _errore_os(e, percorso, "eliminare") from None


# ---------------------------------------------------------------------------
# Cestino
# ---------------------------------------------------------------------------

class _CestinoNonDisponibile(Exception):
    """Il cestino non si può usare (il messaggio spiega perché)."""


def _cestino_windows(assoluto: str) -> None:  # pragma: no cover - solo su Windows
    import ctypes
    from ctypes import wintypes

    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [("hwnd", wintypes.HWND), ("wFunc", wintypes.UINT),
                    ("pFrom", wintypes.LPCWSTR), ("pTo", wintypes.LPCWSTR),
                    ("fFlags", ctypes.c_uint16), ("fAnyOperationsAborted", wintypes.BOOL),
                    ("hNameMappings", ctypes.c_void_p), ("lpszProgressTitle", wintypes.LPCWSTR)]

    FO_DELETE = 3
    FOF_SILENT, FOF_NOCONFIRMATION, FOF_ALLOWUNDO, FOF_NOERRORUI = 0x4, 0x10, 0x40, 0x400
    op = SHFILEOPSTRUCTW()
    op.wFunc = FO_DELETE
    op.pFrom = os.path.abspath(assoluto) + "\0"  # doppio terminatore: ctypes aggiunge il secondo
    op.fFlags = FOF_SILENT | FOF_NOCONFIRMATION | FOF_ALLOWUNDO | FOF_NOERRORUI
    esito = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))
    if esito != 0 or op.fAnyOperationsAborted:
        raise _CestinoNonDisponibile(f"Windows ha rifiutato l'operazione (codice {esito})")
    if os.path.lexists(assoluto):
        raise _CestinoNonDisponibile("il file è ancora al suo posto (forse è su un disco di rete)")


def _nome_libero(cartella: str, nome: str) -> str:
    base, est = os.path.splitext(nome)
    candidato, n = nome, 1
    while os.path.lexists(os.path.join(cartella, candidato)):
        n += 1
        candidato = f"{base} {n}{est}"
    return candidato


def _cestino_mac(assoluto: str) -> None:  # pragma: no cover - solo su macOS
    cestino = os.path.join(os.path.expanduser("~"), ".Trash")
    if not os.path.isdir(cestino):
        raise _CestinoNonDisponibile("la cartella del cestino non c'è")
    shutil.move(assoluto, os.path.join(cestino, _nome_libero(cestino, os.path.basename(assoluto))))


def _cestino_freedesktop(assoluto: str) -> None:
    """Cestino dello standard freedesktop.org (GNOME, KDE, XFCE...)."""
    from urllib.parse import quote

    base = os.environ.get("XDG_DATA_HOME") or os.path.join(os.path.expanduser("~"), ".local", "share")
    cestino = os.path.join(base, "Trash")
    file_dir, info_dir = os.path.join(cestino, "files"), os.path.join(cestino, "info")
    try:
        os.makedirs(file_dir, exist_ok=True)
        os.makedirs(info_dir, exist_ok=True)
    except OSError as e:
        raise _CestinoNonDisponibile(f"non posso creare la cartella del cestino ({e.strerror})") from None
    nome = os.path.basename(assoluto.rstrip(os.sep)) or "senza_nome"
    base_nome, est = os.path.splitext(nome)
    n = 1
    while True:
        candidato = nome if n == 1 else f"{base_nome}.{n}{est}"
        info = os.path.join(info_dir, candidato + ".trashinfo")
        try:
            fd = os.open(info, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        except FileExistsError:
            n += 1
            continue
        except OSError as e:
            raise _CestinoNonDisponibile(f"non posso scrivere nel cestino ({e.strerror})") from None
        break
    data = datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(f"[Trash Info]\nPath={quote(os.path.abspath(assoluto))}\nDeletionDate={data}\n")
    try:
        shutil.move(assoluto, os.path.join(file_dir, candidato))
    except OSError as e:
        try:
            os.remove(info)
        except OSError:
            pass
        raise _CestinoNonDisponibile(f"lo spostamento nel cestino non è riuscito ({e.strerror})") from None


def _al_cestino(percorso: str) -> None:
    assoluto = os.path.abspath(percorso)
    if os.name == "nt":
        _cestino_windows(assoluto)
    elif sys.platform == "darwin":
        _cestino_mac(assoluto)
    else:
        _cestino_freedesktop(assoluto)


def _elimina(percorso: Any, definitivo: Any, nome: str, vuoi_cartella: bool) -> None:
    _controlla_percorso(percorso, nome)
    richiedi_logico(definitivo, nome, "definitivo")
    _richiedi_esistente(percorso)
    e_cart = os.path.isdir(percorso) and not os.path.islink(percorso)
    if e_cart and not vuoi_cartella:
        raise ErroreFile(f"`{percorso}` è una cartella, non un file.",
                         suggerimento=f"Per eliminare una cartella usa `elimina_cartella(\"{percorso}\")`.")
    if not e_cart and vuoi_cartella:
        raise ErroreFile(f"`{percorso}` è un file, non una cartella.",
                         suggerimento=f"Per eliminare un file usa `elimina_file(\"{percorso}\")`.")
    _guardia(percorso, "eliminare")
    if definitivo or _nella_temporanea(_assoluto(percorso)):
        _elimina_per_sempre(percorso, e_cart)
        return
    try:
        _al_cestino(percorso)
    except _CestinoNonDisponibile as e:
        raise ErroreFile(f"Non posso mettere `{percorso}` nel cestino: {e}.",
                         suggerimento=f"Se sei sicuro, eliminalo per sempre con "
                                      f"`{nome}(\"{percorso}\", definitivo = vero)`.") from None
    except OSError as e:
        raise _errore_os(e, percorso, "eliminare") from None


# ===========================================================================
# File e cartelle
# ===========================================================================


@funzione_libreria("e_file")
def e_file(percorso):
    """e_file(percorso): `vero` se il percorso esiste ed è un file (non una cartella).

    Esempio: `se e_file("voti.csv") allora stampa("trovato") fine`.
    """
    _controlla_percorso(percorso, "e_file")
    return os.path.isfile(percorso)


@funzione_libreria("e_cartella")
def e_cartella(percorso):
    """e_cartella(percorso): `vero` se il percorso esiste ed è una cartella.

    Esempio: `se non e_cartella("foto") allora crea_cartella("foto") fine`.
    """
    _controlla_percorso(percorso, "e_cartella")
    return os.path.isdir(percorso)


def _destinazione(origine: str, destinazione: str) -> str:
    """Se ``destinazione`` è una cartella esistente, il file va dentro con lo stesso nome."""
    if os.path.isdir(destinazione) and not os.path.isdir(origine):
        return os.path.join(destinazione, os.path.basename(origine.rstrip("/\\")))
    return destinazione


def _prepara_destinazione(origine: str, destinazione: str, sovrascrivi: bool, nome: str) -> None:
    if _assoluto(origine) == _assoluto(destinazione):
        raise ErroreFile(f"`{origine}` e `{destinazione}` sono lo stesso file.",
                         suggerimento="Scegli un'altra destinazione.")
    if _esiste(destinazione):
        if not sovrascrivi:
            raise ErroreFile(f"`{destinazione}` esiste già.",
                             suggerimento=f"Per sostituirlo scrivi `{nome}(..., sovrascrivi = vero)`.")
        _guardia(destinazione, "sovrascrivere")
    cartella = os.path.dirname(destinazione)
    if cartella and not os.path.isdir(cartella):
        try:
            os.makedirs(cartella, exist_ok=True)
        except OSError as e:
            raise _errore_os(e, cartella, "creare") from None


@funzione_libreria("copia_file")
def copia_file(origine, destinazione, sovrascrivi=False):
    """copia_file(origine, destinazione, sovrascrivi = falso): copia un file e restituisce il percorso della copia.

    Se `destinazione` è una cartella, la copia va dentro con lo stesso nome; le cartelle
    mancanti si creano. Se la copia esiste già serve `sovrascrivi = vero`.
    Esempio: `copia_file("voti.csv", "salvataggi/voti_copia.csv")`.
    """
    _controlla_percorso(origine, "copia_file")
    _controlla_percorso(destinazione, "copia_file")
    richiedi_logico(sovrascrivi, "copia_file", "sovrascrivi")
    _richiedi_esistente(origine)
    if os.path.isdir(origine):
        raise ErroreFile(f"`{origine}` è una cartella, non un file.",
                         suggerimento=f"Per copiare una cartella intera usa `copia_cartella(\"{origine}\", ...)`.")
    destinazione = _destinazione(origine, destinazione)
    _prepara_destinazione(origine, destinazione, sovrascrivi, "copia_file")
    if os.path.isdir(destinazione):
        raise ErroreFile(f"`{destinazione}` è una cartella: non posso sostituirla con un file.")
    try:
        shutil.copy2(origine, destinazione)
    except OSError as e:
        raise _errore_os(e, destinazione, "scrivere") from None
    return destinazione


@funzione_libreria("copia_cartella")
def copia_cartella(origine, destinazione, sovrascrivi=False):
    """copia_cartella(origine, destinazione, sovrascrivi = falso): copia una cartella con tutto il contenuto.

    Restituisce il percorso della copia. Se la destinazione esiste già serve `sovrascrivi = vero`
    (i file con lo stesso nome vengono sostituiti, gli altri restano).
    Esempio: `copia_cartella("progetto", "backup/progetto")`.
    """
    _controlla_percorso(origine, "copia_cartella")
    _controlla_percorso(destinazione, "copia_cartella")
    richiedi_logico(sovrascrivi, "copia_cartella", "sovrascrivi")
    _richiedi_esistente(origine)
    if not os.path.isdir(origine):
        raise ErroreFile(f"`{origine}` è un file, non una cartella.",
                         suggerimento=f"Per copiare un file usa `copia_file(\"{origine}\", ...)`.")
    a_or, a_de = _assoluto(origine), _assoluto(destinazione)
    if _dentro(a_de, a_or):
        raise ErroreFile(f"Non posso copiare `{origine}` dentro se stessa (`{destinazione}`).",
                         suggerimento="Scegli una destinazione fuori dalla cartella da copiare.")
    if _esiste(destinazione):
        if not sovrascrivi:
            raise ErroreFile(f"`{destinazione}` esiste già.",
                             suggerimento="Per unire le due cartelle scrivi "
                                          "`copia_cartella(..., sovrascrivi = vero)`.")
        if not os.path.isdir(destinazione):
            raise ErroreFile(f"`{destinazione}` è un file: non posso copiarci dentro una cartella.")
        _guardia(destinazione, "sovrascrivere")
    try:
        shutil.copytree(origine, destinazione, symlinks=True, dirs_exist_ok=True)
    except shutil.Error as e:
        dettagli = e.args[0] if e.args and isinstance(e.args[0], list) else []
        primo = dettagli[0][0] if dettagli and len(dettagli[0]) > 0 else origine
        raise ErroreFile(f"Non sono riuscito a copiare tutto: {len(dettagli) or 'alcuni'} file "
                         f"non copiati (il primo è `{primo}`).",
                         suggerimento="Forse qualche file è aperto in un altro programma o è protetto.") from None
    except OSError as e:
        raise _errore_os(e, destinazione, "scrivere") from None
    return destinazione


@funzione_libreria("sposta_file")
def sposta_file(origine, destinazione, sovrascrivi=False):
    """sposta_file(origine, destinazione, sovrascrivi = falso): sposta un file (o una cartella) e restituisce il nuovo percorso.

    Se `destinazione` è una cartella esistente, ci finisce dentro con lo stesso nome.
    Esempio: `sposta_file("foto.png", "album")` restituisce "album/foto.png".
    """
    _controlla_percorso(origine, "sposta_file")
    _controlla_percorso(destinazione, "sposta_file")
    richiedi_logico(sovrascrivi, "sposta_file", "sovrascrivi")
    _richiedi_esistente(origine)
    _guardia(origine, "spostare")
    if os.path.isdir(destinazione) and _assoluto(origine) != _assoluto(destinazione):
        destinazione = os.path.join(destinazione, os.path.basename(origine.rstrip("/\\")))
    if os.path.isdir(origine) and _dentro(_assoluto(destinazione), _assoluto(origine)):
        raise ErroreFile(f"Non posso spostare `{origine}` dentro se stessa.")
    _prepara_destinazione(origine, destinazione, sovrascrivi, "sposta_file")
    if _esiste(destinazione):  # sovrascrivi = vero
        if os.path.isdir(destinazione) != os.path.isdir(origine):
            raise ErroreFile(f"Non posso sostituire `{destinazione}`: uno è un file e l'altro una cartella.")
        _elimina_per_sempre(destinazione, os.path.isdir(destinazione) and not os.path.islink(destinazione))
    try:
        shutil.move(origine, destinazione)
    except OSError as e:
        raise _errore_os(e, origine, "spostare") from None
    return destinazione


@funzione_libreria("rinomina_file")
def rinomina_file(percorso, nuovo_nome):
    """rinomina_file(percorso, nuovo_nome): cambia il nome a un file (o a una cartella), che resta dov'è.

    `nuovo_nome` è solo il nome, senza cartelle. Restituisce il nuovo percorso.
    Esempio: `rinomina_file("foto/IMG_001.jpg", "mare.jpg")` restituisce "foto/mare.jpg".
    """
    _controlla_percorso(percorso, "rinomina_file")
    _controlla_percorso(nuovo_nome, "rinomina_file")
    if "/" in nuovo_nome or "\\" in nuovo_nome or nuovo_nome in (".", ".."):
        raise ErroreValore(f"Il nuovo nome {mostra(nuovo_nome)} deve essere solo un nome, senza cartelle.",
                           suggerimento="Per spostare il file in un'altra cartella usa `sposta_file(...)`.")
    _richiedi_esistente(percorso)
    _guardia(percorso, "rinominare")
    cartella = os.path.dirname(percorso.rstrip("/\\"))
    nuovo = os.path.join(cartella, nuovo_nome) if cartella else nuovo_nome
    if _esiste(nuovo) and _assoluto(nuovo) != _assoluto(percorso):
        # stesso nome con maiuscole diverse su Windows/macOS: e' lo stesso file, si rinomina
        try:
            stesso = os.path.samefile(nuovo, percorso)
        except OSError:
            stesso = False
        if not stesso:
            raise ErroreFile(f"`{nuovo}` esiste già.", suggerimento="Scegli un altro nome oppure elimina prima quel file.")
    try:
        os.rename(percorso, nuovo)
    except OSError as e:
        raise _errore_os(e, percorso, "rinominare") from None
    return nuovo


@funzione_libreria("elimina_file")
def elimina_file(percorso, definitivo=False):
    """elimina_file(percorso, definitivo = falso): mette un file nel cestino.

    Con `definitivo = vero` lo elimina per sempre. Se il cestino non si può usare, Leo si ferma
    con un errore invece di eliminare di nascosto. I file di sistema e le cartelle importanti
    sono protetti. Esempio: `elimina_file("vecchio.txt")`.
    """
    _elimina(percorso, definitivo, "elimina_file", False)
    return None


@funzione_libreria("elimina_cartella")
def elimina_cartella(percorso, definitivo=False):
    """elimina_cartella(percorso, definitivo = falso): mette nel cestino una cartella con tutto il contenuto.

    Con `definitivo = vero` la elimina per sempre. La cartella personale, Documenti, Desktop,
    le cartelle di sistema e quella in cui stai lavorando sono protette.
    Esempio: `elimina_cartella("prove")`.
    """
    _elimina(percorso, definitivo, "elimina_cartella", True)
    return None


@funzione_libreria("svuota_cartella")
def svuota_cartella(percorso, definitivo=False):
    """svuota_cartella(percorso, definitivo = falso): mette nel cestino tutto il contenuto della cartella, che resta vuota.

    Restituisce quanti elementi ha tolto. Esempio: `svuota_cartella("temporanei")`.
    """
    _controlla_percorso(percorso, "svuota_cartella")
    richiedi_logico(definitivo, "svuota_cartella", "definitivo")
    _richiedi_esistente(percorso)
    if not os.path.isdir(percorso):
        raise ErroreFile(f"`{percorso}` è un file, non una cartella.")
    _guardia(percorso, "svuotare")
    try:
        nomi = sorted(os.listdir(percorso))
    except OSError as e:
        raise _errore_os(e, percorso, "leggere") from None
    for n in nomi:
        voce = os.path.join(percorso, n)
        cartella = os.path.isdir(voce) and not os.path.islink(voce)
        _elimina(voce, definitivo, "elimina_cartella" if cartella else "elimina_file", cartella)
    return len(nomi)


def _filtri(filtro: Any, nome: str) -> list[str] | None:
    """Filtro "*.txt", "*.jpg;*.png" o lista di filtri -> lista di modelli minuscoli (None = tutto)."""
    if filtro is None:
        return None
    if isinstance(filtro, list):
        modelli = []
        for f in filtro:
            modelli.extend(_filtri(richiedi_testo(f, nome, "filtro"), nome) or [])
        return modelli or None
    richiedi_testo(filtro, nome, "filtro")
    modelli = [p.strip().lower() for p in filtro.replace(",", ";").split(";") if p.strip()]
    return modelli or None


def corrisponde_filtro(nome_file: str, modelli: list[str] | None) -> bool:
    """`vero` se ``nome_file`` corrisponde a uno dei modelli (senza distinguere maiuscole)."""
    if not modelli:
        return True
    from fnmatch import fnmatchcase

    basso = nome_file.lower()
    return any(fnmatchcase(basso, m) for m in modelli)


@funzione_libreria("cerca_file")
def cerca_file(cartella=".", filtro="*", nascosti=False, massimo=None):
    """cerca_file(cartella = ".", filtro = "*", nascosti = falso, massimo = nulla): cerca i file anche nelle sottocartelle.

    Restituisce i percorsi in ordine alfabetico. Il filtro usa `*` (qualunque testo) e `?` (un
    carattere); più filtri si separano con `;`. I file e le cartelle nascosti (che iniziano con
    un punto) si saltano, salvo `nascosti = vero`. Esempio: `cerca_file("documenti", "*.txt;*.md")`.
    """
    _controlla_percorso(cartella, "cerca_file")
    modelli = _filtri(filtro, "cerca_file")
    richiedi_logico(nascosti, "cerca_file", "nascosti")
    if massimo is not None and not (type(massimo) is int and massimo >= 0):
        raise ErroreTipo(f"`massimo` di `cerca_file` deve essere un intero positivo, non {articolo(massimo)}.")
    if not os.path.isdir(cartella):
        if os.path.exists(cartella):
            raise ErroreFile(f"`{cartella}` è un file, non una cartella.")
        raise ErroreFile(f"La cartella `{cartella}` non esiste.",
                         suggerimento=f"Controlla il nome: ora sei in `{os.getcwd()}`.")
    trovati: list[str] = []
    for radice, cartelle, file in os.walk(cartella, followlinks=False):
        if not nascosti:
            cartelle[:] = [c for c in cartelle if not c.startswith(".")]
        cartelle.sort(key=str.casefold)
        for n in file:
            if not nascosti and n.startswith("."):
                continue
            if corrisponde_filtro(n, modelli):
                p = os.path.join(radice, n)
                if cartella in (".", "./") and p.startswith("." + os.sep):
                    p = p[2:]
                trovati.append(p)
    trovati.sort(key=lambda s: (s.casefold(), s))
    if massimo is not None:
        trovati = trovati[:massimo]
    return trovati


def _stat(percorso: str, nome: str) -> os.stat_result:
    _controlla_percorso(percorso, nome)
    try:
        return os.stat(percorso)
    except OSError as e:
        raise _errore_os(e, percorso, "leggere") from None
    except ValueError:
        raise ErroreFile(f"Il percorso `{percorso}` non è valido.") from None


@funzione_libreria("dimensione_file")
def dimensione_file(percorso):
    """dimensione_file(percorso): quanti byte occupa un file.

    Esempio: `dimensione_leggibile(dimensione_file("foto.jpg"))` è per esempio "2,4 MB".
    """
    info = _stat(percorso, "dimensione_file")
    if stat.S_ISDIR(info.st_mode):
        raise ErroreFile(f"`{percorso}` è una cartella.",
                         suggerimento=f"Per una cartella usa `dimensione_cartella(\"{percorso}\")`.")
    return info.st_size


@funzione_libreria("dimensione_cartella")
def dimensione_cartella(percorso):
    """dimensione_cartella(percorso): quanti byte occupano tutti i file della cartella e delle sottocartelle.

    Esempio: `stampa(dimensione_leggibile(dimensione_cartella("foto")))`.
    """
    info = _stat(percorso, "dimensione_cartella")
    if not stat.S_ISDIR(info.st_mode):
        return info.st_size
    totale = 0
    for radice, _cartelle, file in os.walk(percorso, followlinks=False):
        for n in file:
            try:
                totale += os.lstat(os.path.join(radice, n)).st_size
            except OSError:  # file sparito nel frattempo
                continue
    return totale


_UNITA = ("KB", "MB", "GB", "TB", "PB", "EB")


@funzione_libreria("dimensione_leggibile")
def dimensione_leggibile(byte):
    """dimensione_leggibile(byte): una quantità di byte scritta per le persone, con la virgola.

    Esempi: `dimensione_leggibile(512)` è "512 byte", `dimensione_leggibile(1536)` è "1,5 KB",
    `dimensione_leggibile(3000000)` è "2,9 MB".
    """
    if type(byte) not in (int, float):
        raise ErroreTipo(f"`dimensione_leggibile` vuole un numero di byte, non {articolo(byte)}.")
    if byte != byte or byte < 0 or byte == float("inf"):
        raise ErroreValore(f"Una dimensione non può essere {rappresenta(byte)}.")
    if byte < 1024:
        return f"{int(byte)} byte"
    valore = float(min(byte, 1024 ** 7))
    for unita in _UNITA:
        valore /= 1024
        if valore < 1024 or unita == _UNITA[-1]:
            testo = f"{valore:.1f}".replace(".", ",")
            if testo.endswith(",0"):
                testo = testo[:-2]
            return f"{testo} {unita}"
    return f"{int(byte)} byte"  # pragma: no cover


@funzione_libreria("data_modifica")
def data_modifica(percorso):
    """data_modifica(percorso): la data (con l'ora) dell'ultima modifica di un file o di una cartella.

    Esempio: `stampa("Salvato il", data_modifica("voti.csv"))`.
    """
    info = _stat(percorso, "data_modifica")
    try:
        momento = datetime.datetime.fromtimestamp(info.st_mtime)
    except (OverflowError, OSError, ValueError):
        raise ErroreFile(f"La data di modifica di `{percorso}` non è valida.") from None
    return DataDante(momento.replace(microsecond=0))


@funzione_libreria("info_file")
def info_file(percorso):
    """info_file(percorso): un dizionario con le informazioni su un file o una cartella.

    Chiavi: "nome", "estensione", "cartella", "percorso" (completo), "tipo" ("file" o "cartella"),
    "dimensione" (byte), "data_modifica". Esempio: `info_file("voti.csv")["dimensione"]`.
    """
    info = _stat(percorso, "info_file")
    cartella = stat.S_ISDIR(info.st_mode)
    return {
        "nome": nome_file(percorso),
        "estensione": "" if cartella else estensione_file(percorso),
        "cartella": cartella_di(percorso),
        "percorso": os.path.abspath(percorso),
        "tipo": "cartella" if cartella else "file",
        "dimensione": dimensione_cartella(percorso) if cartella else info.st_size,
        "data_modifica": data_modifica(percorso),
    }


@funzione_libreria("cartella_corrente")
def cartella_corrente():
    """cartella_corrente(): il percorso completo della cartella in cui sta lavorando il programma.

    I percorsi relativi (come "voti.csv") partono da qui. Esempio: `stampa(cartella_corrente())`.
    """
    try:
        return os.getcwd()
    except OSError:
        raise ErroreFile("La cartella corrente non esiste più.",
                         suggerimento="Spostati in un'altra cartella con `cambia_cartella(...)`.") from None


@funzione_libreria("cambia_cartella")
def cambia_cartella(percorso):
    """cambia_cartella(percorso): cambia la cartella di lavoro; restituisce il suo percorso completo.

    Da quel momento i percorsi relativi partono dalla nuova cartella.
    Esempio: `cambia_cartella(cartella_documenti())`.
    """
    _controlla_percorso(percorso, "cambia_cartella")
    if not os.path.isdir(percorso):
        if os.path.exists(percorso):
            raise ErroreFile(f"`{percorso}` è un file, non una cartella.")
        raise ErroreFile(f"La cartella `{percorso}` non esiste.",
                         suggerimento="Creala prima con `crea_cartella(...)`.")
    try:
        os.chdir(percorso)
    except OSError as e:
        raise _errore_os(e, percorso, "aprire") from None
    return os.getcwd()


# ===========================================================================
# Percorsi
# ===========================================================================


@funzione_libreria("unisci_percorso")
def unisci_percorso(*parti):
    """unisci_percorso(parti...): unisce cartelle e nome del file con il separatore giusto per il sistema.

    Esempio: `unisci_percorso(cartella_documenti(), "leo", "voti.csv")`. Accetta anche una lista.
    """
    if len(parti) == 1 and isinstance(parti[0], list):
        parti = tuple(parti[0])
    if not parti:
        raise ErroreTipo("`unisci_percorso` vuole almeno un pezzo di percorso.",
                         suggerimento="Esempio: `unisci_percorso(\"dati\", \"voti.csv\")`.")
    for i, p in enumerate(parti):
        if not isinstance(p, str):
            raise ErroreTipo(f"I pezzi di `unisci_percorso` devono essere testi, ma il numero {i + 1} "
                             f"è {articolo(p)}.")
        if "\0" in p:
            raise ErroreValore(f"Il pezzo {mostra(p)} contiene un carattere non valido.")
    return os.path.join(*parti)


def _percorso_testo(percorso: Any, nome: str) -> str:
    richiedi_testo(percorso, nome, "percorso")
    if "\0" in percorso:
        raise ErroreValore(f"Il percorso {mostra(percorso)} contiene un carattere non valido.")
    return percorso


def _base(percorso: str) -> str:
    pulito = percorso.rstrip("/\\") or percorso
    return os.path.basename(pulito) or pulito


@funzione_libreria("nome_file")
def nome_file(percorso):
    """nome_file(percorso): solo il nome finale del percorso, senza le cartelle.

    Esempio: `nome_file("foto/estate/mare.jpg")` è "mare.jpg".
    """
    return _base(_percorso_testo(percorso, "nome_file"))


@funzione_libreria("nome_senza_estensione")
def nome_senza_estensione(percorso):
    """nome_senza_estensione(percorso): il nome del file senza cartelle e senza estensione.

    Esempio: `nome_senza_estensione("foto/mare.jpg")` è "mare".
    """
    return os.path.splitext(_base(_percorso_testo(percorso, "nome_senza_estensione")))[0]


@funzione_libreria("estensione_file")
def estensione_file(percorso):
    """estensione_file(percorso): l'estensione del file in minuscolo, senza il punto ("" se non c'è).

    Esempi: `estensione_file("mare.JPG")` è "jpg", `estensione_file("leggimi")` è "".
    """
    return os.path.splitext(_base(_percorso_testo(percorso, "estensione_file")))[1][1:].lower()


@funzione_libreria("cambia_estensione")
def cambia_estensione(percorso, estensione):
    """cambia_estensione(percorso, estensione): il percorso con un'altra estensione (il file non cambia).

    Esempi: `cambia_estensione("voti.csv", "json")` è "voti.json"; con "" l'estensione si toglie.
    """
    _percorso_testo(percorso, "cambia_estensione")
    richiedi_testo(estensione, "cambia_estensione", "estensione")
    estensione = estensione.strip()
    if estensione.startswith("."):
        estensione = estensione[1:]
    if any(c in estensione for c in "/\\\0"):
        raise ErroreValore(f"L'estensione {mostra(estensione)} non è valida.")
    radice, _vecchia = os.path.splitext(percorso)
    return radice + ("." + estensione if estensione else "")


@funzione_libreria("cartella_di")
def cartella_di(percorso):
    """cartella_di(percorso): la cartella che contiene il file ("." se il percorso è solo un nome).

    Esempio: `cartella_di("foto/estate/mare.jpg")` è "foto/estate".
    """
    _percorso_testo(percorso, "cartella_di")
    pulito = percorso.rstrip("/\\") or percorso
    return os.path.dirname(pulito) or "."


@funzione_libreria("percorso_completo")
def percorso_completo(percorso):
    """percorso_completo(percorso): il percorso assoluto, a partire dalla radice del disco.

    Esempio: `percorso_completo("voti.csv")` è per esempio "C:\\Users\\ada\\leo\\voti.csv".
    """
    _percorso_testo(percorso, "percorso_completo")
    try:
        return os.path.abspath(os.path.expanduser(percorso))
    except (OSError, ValueError):
        raise ErroreValore(f"Il percorso {mostra(percorso)} non è valido.") from None


@funzione_libreria("percorso_relativo")
def percorso_relativo(percorso, base="."):
    """percorso_relativo(percorso, base = "."): il percorso visto dalla cartella `base`.

    Esempio: `percorso_relativo("/casa/ada/foto/mare.jpg", "/casa/ada")` è "foto/mare.jpg".
    """
    _percorso_testo(percorso, "percorso_relativo")
    richiedi_testo(base, "percorso_relativo", "base")
    try:
        return os.path.relpath(percorso, base or ".")
    except ValueError:
        raise ErroreValore(f"{mostra(percorso)} e {mostra(base)} sono su dischi diversi: "
                           f"non c'è un percorso relativo.") from None


# ===========================================================================
# Cartelle speciali
# ===========================================================================

_GUID = {  # Known Folder di Windows
    "documenti": "{FDD39AD0-238F-46AF-ADB4-6C85480369C7}",
    "desktop": "{B4BFCC3A-DB2C-424C-B029-7FE99A87C641}",
    "download": "{374DE290-123F-4565-9164-39C4925E467B}",
}
_XDG = {"documenti": "XDG_DOCUMENTS_DIR", "desktop": "XDG_DESKTOP_DIR", "download": "XDG_DOWNLOAD_DIR"}
_NOMI = {"documenti": ("Documenti", "Documents"), "desktop": ("Scrivania", "Desktop"),
         "download": ("Scaricati", "Download", "Downloads")}


def _cartella_windows(guid: str) -> str | None:  # pragma: no cover - solo su Windows
    try:
        import ctypes
        import uuid
        from ctypes import wintypes

        class GUID(ctypes.Structure):
            _fields_ = [("Data1", wintypes.DWORD), ("Data2", wintypes.WORD), ("Data3", wintypes.WORD),
                        ("Data4", ctypes.c_ubyte * 8)]

        u = uuid.UUID(guid)
        g = GUID(u.fields[0], u.fields[1], u.fields[2], (ctypes.c_ubyte * 8)(*u.bytes[8:]))
        puntatore = ctypes.c_wchar_p()
        if ctypes.windll.shell32.SHGetKnownFolderPath(ctypes.byref(g), 0, None, ctypes.byref(puntatore)) != 0:
            return None
        valore = puntatore.value
        ctypes.windll.ole32.CoTaskMemFree(puntatore)
        return valore
    except Exception:  # noqa: BLE001
        return None


def _cartella_xdg(variabile: str, casa: str) -> str | None:
    config = os.environ.get("XDG_CONFIG_HOME") or os.path.join(casa, ".config")
    try:
        with open(os.path.join(config, "user-dirs.dirs"), encoding="utf-8") as f:
            righe = f.read().splitlines()
    except (OSError, UnicodeDecodeError):
        return None
    for riga in righe:
        riga = riga.strip()
        if riga.startswith(variabile + "="):
            valore = riga.split("=", 1)[1].strip().strip('"')
            valore = valore.replace("$HOME", casa)
            valore = os.path.normpath(valore)
            if valore != casa:  # "$HOME/" vuol dire "cartella disattivata"
                return valore
    return None


def _speciale(chiave: str) -> str:
    casa = os.path.expanduser("~")
    if os.name == "nt":  # pragma: no cover - solo su Windows
        trovata = _cartella_windows(_GUID[chiave])
        if trovata:
            return trovata
    elif sys.platform != "darwin":
        trovata = _cartella_xdg(_XDG[chiave], casa)
        if trovata:
            return trovata
    for nome in _NOMI[chiave]:
        candidata = os.path.join(casa, nome)
        if os.path.isdir(candidata):
            return candidata
    return os.path.join(casa, _NOMI[chiave][-1] if chiave != "documenti" else "Documents")


@funzione_libreria("cartella_casa")
def cartella_casa():
    """cartella_casa(): la tua cartella personale (per esempio "C:\\Users\\ada" o "/home/ada").

    Esempio: `unisci_percorso(cartella_casa(), "appunti.txt")`.
    """
    return os.path.expanduser("~")


@funzione_libreria("cartella_documenti")
def cartella_documenti():
    """cartella_documenti(): la cartella Documenti dell'utente (anche se è spostata su OneDrive).

    Esempio: `scrivi_file(unisci_percorso(cartella_documenti(), "nota.txt"), "Ciao")`.
    """
    return _speciale("documenti")


@funzione_libreria("cartella_desktop")
def cartella_desktop():
    """cartella_desktop(): la cartella del Desktop (la Scrivania).

    Esempio: `copia_file("resoconto.pdf", cartella_desktop())`.
    """
    return _speciale("desktop")


@funzione_libreria("cartella_download")
def cartella_download():
    """cartella_download(): la cartella dei file scaricati (Download).

    Esempio: `elenca_file(cartella_download(), "*.pdf")`.
    """
    return _speciale("download")


@funzione_libreria("cartella_programma", interprete=True)
def cartella_programma(interprete):
    """cartella_programma(): la cartella in cui si trova il programma `.leo` che è in esecuzione.

    Serve per trovare i file che stanno accanto al programma, da qualunque cartella lo si avvii.
    Esempio: `leggi_file(unisci_percorso(cartella_programma(), "dati.txt"))`.
    """
    nome = getattr(interprete, "nome_file", None)
    if isinstance(nome, str) and nome and not nome.startswith("<"):
        completo = os.path.abspath(nome)
        if os.path.isfile(completo):
            return os.path.dirname(completo)
    return cartella_corrente()


# ===========================================================================
# Temporanei
# ===========================================================================

_TEMPORANEI: list[str] = []


def _pulisci_temporanei() -> None:
    for p in reversed(_TEMPORANEI):
        try:
            if os.path.isdir(p) and not os.path.islink(p):
                shutil.rmtree(p, ignore_errors=True)
            elif os.path.lexists(p):
                os.remove(p)
        except OSError:
            pass
    _TEMPORANEI.clear()


atexit.register(_pulisci_temporanei)


@funzione_libreria("file_temporaneo")
def file_temporaneo(estensione=""):
    """file_temporaneo(estensione = ""): crea un file vuoto nella cartella temporanea e ne restituisce il percorso.

    Il file viene eliminato quando il programma finisce.
    Esempio: `variabile t = file_temporaneo("txt")` poi `scrivi_file(t, "prova")`.
    """
    richiedi_testo(estensione, "file_temporaneo", "estensione")
    estensione = estensione.strip().lstrip(".")
    if any(c in estensione for c in '/\\\0:*?"<>|') or len(estensione) > 20:
        raise ErroreValore(f"L'estensione {mostra(estensione)} non è valida.",
                           suggerimento="Scrivi solo l'estensione, per esempio \"txt\" o \"csv\".")
    try:
        fd, percorso = tempfile.mkstemp(prefix="leo_", suffix="." + estensione if estensione else "")
        os.close(fd)
    except OSError as e:
        raise _errore_os(e, tempfile.gettempdir(), "creare") from None
    _TEMPORANEI.append(percorso)
    return percorso


@funzione_libreria("cartella_temporanea")
def cartella_temporanea():
    """cartella_temporanea(): crea una cartella vuota nuova per i file di passaggio e ne restituisce il percorso.

    La cartella (con tutto il contenuto) viene eliminata quando il programma finisce.
    Esempio: `variabile lavoro = cartella_temporanea()`.
    """
    try:
        percorso = tempfile.mkdtemp(prefix="leo_")
    except OSError as e:
        raise _errore_os(e, tempfile.gettempdir(), "creare") from None
    _TEMPORANEI.append(percorso)
    return percorso


# ===========================================================================
# Sinonimi
# ===========================================================================


def registra_sinonimo(nuovo: str, originale: str) -> None:
    """Registra ``nuovo`` come un'altra forma della funzione di libreria ``originale``.

    La documentazione del sinonimo ripete la firma dell'originale con il nuovo nome.
    """
    import functools

    from ..registro import FUNZIONI

    nativa = FUNZIONI[originale]
    f = nativa.funzione

    @functools.wraps(f)
    def sinonimo(*argomenti, **per_nome):
        return f(*argomenti, **per_nome)

    prima = (f.__doc__ or "").strip().splitlines()[0]
    firma = prima.split(":", 1)[0]
    firma = nuovo + firma[len(originale):] if firma.startswith(originale + "(") else nuovo + "(...)"
    sinonimo.__doc__ = f"{firma}: sinonimo di `{originale}`.\n\n" + (f.__doc__ or "")
    sinonimo.__name__ = nuovo
    funzione_libreria(nuovo, interprete=nativa.vuole_interprete)(sinonimo)


for _nuovo, _originale in (("cancella_file", "elimina_file"), ("cancella_cartella", "elimina_cartella"),
                           ("muovi_file", "sposta_file"), ("duplica_file", "copia_file"),
                           ("unisci_percorsi", "unisci_percorso"), ("cartella_scrivania", "cartella_desktop")):
    registra_sinonimo(_nuovo, _originale)
