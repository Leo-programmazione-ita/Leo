"""Libreria: file, cartelle, tabelle (CSV) e JSON.

``elenca_file``, ``elenca_cartelle``, ``esiste``, ``crea_cartella``,
``leggi_righe``, ``aggiungi_a_file``, ``leggi_tabella``, ``scrivi_tabella``,
``da_json``, ``a_json``, ``leggi_json``, ``scrivi_json``, ``da_csv``, ``a_csv``,
``aggiungi_a_tabella``.

``elenca_file``/``elenca_cartelle`` accettano filtri con ``*`` e ``?``
(``"*.txt"``, ``"foto_*.jpg;*.png"``); ``scrivi_tabella(..., excel = vero)``
scrive un CSV che l'Excel italiano apre direttamente (``;``, virgola decimale,
UTF-8 con BOM). Copia, spostamento, cestino e percorsi sono in
``cartelle.py``; righe, binari, codifiche, INI, TOML e ZIP in ``formati.py``.

I file si leggono e si scrivono in UTF-8; i percorsi relativi partono dalla
cartella corrente. Gli errori del sistema operativo diventano ``ErroreFile``
in italiano (vedi ``ingresso_uscita._errore_file``).
"""

from __future__ import annotations

import csv
import io
import json
import math
import os
import re
from typing import Any

from ..errori import ErroreFile, ErroreTipo, ErroreValore
from ..valori import e_numero, rappresenta
from .generali import (articolo, funzione_libreria, intero_a_testo, lunghezza_intervallo, mostra,
                       richiedi_logico, richiedi_testo, testo_a_intero)
from .ingresso_uscita import _controlla_percorso, _errore_file, leggi_file

# ---------------------------------------------------------------------------
# File e cartelle
# ---------------------------------------------------------------------------


def _elenca(cartella: Any, nome: str, vuoi_file: bool, estensione: Any, filtro: Any = None) -> list:
    from .cartelle import _filtri, corrisponde_filtro

    _controlla_percorso(cartella, nome)
    if estensione is not None:
        richiedi_testo(estensione, nome, "estensione")
        if any(c in estensione for c in "*?[;"):  # `elenca_file(".", "*.txt")`: e' un filtro
            if filtro is None:
                filtro = estensione
            estensione = None
        else:
            estensione = estensione.lower()
            if estensione and not estensione.startswith("."):
                estensione = "." + estensione
    modelli = _filtri(filtro, nome)
    try:
        # scandir (non listdir + isdir): su Windows sa già se ogni voce è una cartella,
        # senza interrogare il disco una volta per file
        with os.scandir(cartella) as voci:
            risultato = []
            for voce in voci:
                try:
                    e_cartella = voce.is_dir()
                except OSError:  # voce sparita o illeggibile nel frattempo
                    continue
                if e_cartella == vuoi_file:
                    continue
                if estensione and not voce.name.lower().endswith(estensione):
                    continue
                if modelli and not corrisponde_filtro(voce.name, modelli):
                    continue
                risultato.append(voce.name)
    except FileNotFoundError:
        raise ErroreFile(f"La cartella `{cartella}` non esiste.",
                         suggerimento=f"Controlla il nome: ora sei in `{os.getcwd()}`.") from None
    except NotADirectoryError:
        raise ErroreFile(f"`{cartella}` è un file, non una cartella.") from None
    except OSError as e:
        raise _errore_file(e, cartella, "leggere") from None
    risultato.sort(key=lambda s: (s.casefold(), s))
    return risultato


@funzione_libreria("elenca_file")
def elenca_file(cartella=".", estensione=None, filtro=None):
    """elenca_file(cartella = ".", estensione = nulla, filtro = nulla): i nomi dei file di una cartella, in ordine alfabetico.

    Il filtro usa `*` (qualunque testo) e `?` (un carattere), senza distinguere maiuscole; più
    filtri si separano con `;`. Esempi: `elenca_file()` (la cartella corrente),
    `elenca_file("foto", estensione = "png")`, `elenca_file("foto", "*.jpg;*.png")`.
    Per cercare anche nelle sottocartelle usa `cerca_file`.
    """
    return _elenca(cartella, "elenca_file", True, estensione, filtro)


@funzione_libreria("elenca_cartelle")
def elenca_cartelle(cartella=".", filtro=None):
    """elenca_cartelle(cartella = ".", filtro = nulla): i nomi delle sottocartelle di una cartella, in ordine alfabetico.

    Esempi: `per ogni c in elenca_cartelle() fai stampa(c) fine`, `elenca_cartelle(".", "livello_*")`.
    """
    return _elenca(cartella, "elenca_cartelle", False, None, filtro)


@funzione_libreria("esiste")
def esiste(percorso):
    """esiste(percorso): `vero` se il file o la cartella esiste.

    Esempio: `se non esiste("punteggi.txt") allora scrivi_file("punteggi.txt", "") fine`.
    """
    _controlla_percorso(percorso, "esiste")
    return os.path.exists(percorso)


@funzione_libreria("crea_cartella")
def crea_cartella(percorso):
    """crea_cartella(percorso): crea la cartella (e quelle che la contengono, se mancano).

    Se esiste già non succede niente. Esempio: `crea_cartella("salvataggi/livello1")`.
    """
    _controlla_percorso(percorso, "crea_cartella")
    if os.path.isfile(percorso):
        raise ErroreFile(f"Non posso creare la cartella `{percorso}`: esiste già un file con quel nome.")
    try:
        os.makedirs(percorso, exist_ok=True)
    except OSError as e:
        raise _errore_file(e, percorso, "creare") from None
    return None


@funzione_libreria("leggi_righe")
def leggi_righe(percorso):
    """leggi_righe(percorso): le righe di un file di testo, come lista di testi (senza "a capo").

    Esempio: `per ogni riga in leggi_righe("spesa.txt") fai stampa("- " + riga) fine`.
    """
    testo = leggi_file(percorso)
    if not testo:
        return []
    # solo "a capo" veri: splitlines taglierebbe anche a caratteri come \x0c o \u2028
    righe = testo.split("\n")
    if righe[-1] == "":
        righe.pop()
    return righe


@funzione_libreria("aggiungi_a_file")
def aggiungi_a_file(percorso, testo, a_capo=True):
    """aggiungi_a_file(percorso, testo, a_capo = vero): aggiunge il testo in fondo al file (lo crea se manca).

    Con `a_capo = vero` (il normale) il testo diventa una riga a sé (anche se il file non finiva a capo). Esempio: `aggiungi_a_file("diario.txt", "Oggi ho imparato Leo")`.
    """
    _controlla_percorso(percorso, "aggiungi_a_file")
    if not isinstance(testo, str):
        testo = rappresenta(testo)
    richiedi_logico(a_capo, "aggiungi_a_file", "a_capo")
    try:
        prima = ""
        if a_capo and os.path.isfile(percorso) and os.path.getsize(percorso) > 0:
            # il file non finisce con "a capo" (es. scritto con scrivi_file): la nuova riga
            # non deve incollarsi all'ultima
            with open(percorso, "rb") as f:
                f.seek(-1, os.SEEK_END)
                if f.read(1) not in (b"\n", b"\r"):
                    prima = "\n"
        with open(percorso, "a", encoding="utf-8") as f:
            f.write(prima + testo + ("\n" if a_capo else ""))
    except OSError as e:
        raise _errore_file(e, percorso, "scrivere") from None
    except ValueError:
        raise ErroreFile(f"Il percorso `{percorso}` non è valido.") from None
    return None


# ---------------------------------------------------------------------------
# Tabelle (CSV)
# ---------------------------------------------------------------------------

#: Un numero in una cella: intero (gruppo 1) oppure decimale col punto o con la virgola.
_NUMERO = re.compile(r"[+-]?(?:(\d+)|(?:\d+[.,]\d*|[.,]\d+)(?:[eE][+-]?\d+)?)")
_INIZIO_NUMERO = frozenset("+-.,0123456789")


def _converti_cella(cella: str, separatore: str) -> Any:
    s = cella.strip()
    # via veloce: la maggior parte delle celle di testo non comincia come un numero
    if not s or (s[0] not in _INIZIO_NUMERO and not s[0].isdecimal()):
        return cella
    m = _NUMERO.fullmatch(s)
    if m is None:
        return cella
    if m.group(1) is not None:
        cifre = m.group(1)
        if len(cifre) > 1 and cifre[0] == "0":
            return cella  # "007", "0123": codici, non numeri
        try:
            return testo_a_intero(s)
        except ValueError:  # troppe cifre: resta un testo
            return cella
    if "," in s:
        if separatore == ",":
            return cella
        s = s.replace(",", ".")
    valore = float(s)
    return cella if math.isinf(valore) else valore


def _indovina_separatore(prima_riga: str) -> str:
    conteggi = {sep: prima_riga.count(sep) for sep in (";", ",", "\t")}
    migliore = max(conteggi, key=conteggi.__getitem__)
    return migliore if conteggi[migliore] else ","


def _controlla_separatore(separatore: Any, nome: str) -> str:
    richiedi_testo(separatore, nome, "separatore")
    if len(separatore) != 1 or separatore in "\x00\r\n\"":
        raise ErroreValore(f"Il separatore deve essere un solo carattere visibile (per esempio \",\" o \";\"), "
                           f"non {mostra(separatore)}.")
    return separatore


def _analizza_csv(testo: str, separatore: Any, intestazione: Any, converti_numeri: Any, nome: str,
                  origine: str) -> list:
    """Il testo CSV come lista di dizionari (con intestazione) o di liste."""
    if separatore is None:
        separatore = _indovina_separatore(testo.split("\n", 1)[0])
    _controlla_separatore(separatore, nome)
    richiedi_logico(intestazione, nome, "intestazione")
    richiedi_logico(converti_numeri, nome, "converti_numeri")
    if testo.startswith("\ufeff"):
        testo = testo[1:]
    try:
        # le righe vuote (anche quelle fatte solo di separatori, come ";;;" che Excel lascia
        # in fondo) non sono dati
        righe = [r for r in csv.reader(io.StringIO(testo, newline=""), delimiter=separatore)
                 if r and any(c.strip() for c in r)]
    except csv.Error as e:
        raise ErroreFile(f"{origine} non è una tabella CSV valida: {_spiega_csv(e)}.") from None
    if converti_numeri:
        conv = _converti_cella
        dati = [[conv(c, separatore) for c in r] for r in (righe[1:] if intestazione else righe)]
    else:
        dati = righe[1:] if intestazione else righe
    if not intestazione:
        return dati
    if not righe:
        return []
    chiavi = [n.strip() or f"colonna{i + 1}" for i, n in enumerate(righe[0])]
    colonne = len(chiavi)
    risultato = []
    for r in dati:
        if len(r) < colonne:  # celle mancanti in fondo alla riga: `nulla`
            r = r + [None] * (colonne - len(r))
        risultato.append(dict(zip(chiavi, r)))
    return risultato


@funzione_libreria("leggi_tabella")
def leggi_tabella(percorso, separatore=None, intestazione=True, converti_numeri=True):
    """leggi_tabella(percorso, separatore = nulla, intestazione = vero, converti_numeri = vero): legge un file CSV.

    Con l'intestazione (la prima riga con i nomi delle colonne) ogni riga diventa un dizionario,
    altrimenti una lista. Il separatore (`,` `;` o tabulazione) si indovina da solo; i numeri
    diventano numeri (anche "3,5" con il separatore `;`).
    Esempio: `per ogni r in leggi_tabella("voti.csv") fai stampa(r["nome"], r["voto"]) fine`.
    """
    testo = leggi_file(percorso)
    return _analizza_csv(testo, separatore, intestazione, converti_numeri, "leggi_tabella",
                         f"Il file `{percorso}`")


@funzione_libreria("da_csv")
def da_csv(testo, separatore=None, intestazione=True, converti_numeri=True):
    """da_csv(testo, separatore = nulla, intestazione = vero, converti_numeri = vero): come `leggi_tabella`, ma da un testo.

    Esempio: `da_csv("nome;voto\\nAda;30")` è `[{"nome": "Ada", "voto": 30}]`.
    """
    richiedi_testo(testo, "da_csv", "testo")
    if "\r" in testo:
        testo = testo.replace("\r\n", "\n").replace("\r", "\n")
    return _analizza_csv(testo, separatore, intestazione, converti_numeri, "da_csv", "Il testo")


def _spiega_csv(errore: csv.Error) -> str:
    testo = str(errore)
    if "field larger than field limit" in testo:
        return "una cella è troppo lunga (forse manca una virgoletta di chiusura)"
    if "new-line character seen in unquoted field" in testo:
        return "c'è un \"a capo\" dentro una cella senza virgolette"
    if "NUL" in testo:
        return "contiene caratteri nulli (forse non è un file di testo)"
    return testo


def _cella(v: Any) -> str:
    if v is None:
        return ""
    return rappresenta(v)


def _valore_colonna(riga: dict, chiave: Any) -> Any:
    """``riga[chiave]`` distinguendo `vero` da 1 (in Python sono la stessa chiave)."""
    if type(chiave) is bool or (type(chiave) is int and chiave in (0, 1)):
        for k in riga:
            if k == chiave and type(k) is type(chiave):
                return riga[k]
        return None
    return riga.get(chiave)


def _cella_excel(v: Any) -> str:
    """Come :func:`_cella`, ma con la virgola decimale dell'Excel italiano."""
    if type(v) is float:
        return rappresenta(v).replace(".", ",")
    return _cella(v)


def _tabella_testo(righe: Any, separatore: Any, excel: Any, nome: str) -> str:
    """Le righe (lista di dizionari o di liste) come testo CSV."""
    if not isinstance(righe, list):
        raise ErroreTipo(f"`righe` di `{nome}` deve essere una lista, non {articolo(righe)}.")
    richiedi_logico(excel, nome, "excel")
    if separatore is None:
        separatore = ";" if excel else ","
    _controlla_separatore(separatore, nome)
    cella = _cella_excel if excel and separatore != "," else _cella
    tabella: list[list[str]] = []
    if righe and all(isinstance(r, dict) for r in righe):
        nomi: list = []
        visti: set = set()
        for r in righe:
            for k in r:
                segno = (type(k) is bool, k)  # `vero` e 1 sono colonne diverse
                if segno not in visti:
                    visti.add(segno)
                    nomi.append(k)
        tabella.append([_cella(k) for k in nomi])
        tabella.extend([cella(_valore_colonna(r, k)) for k in nomi] for r in righe)
    elif all(isinstance(r, list) for r in righe):
        tabella.extend([cella(c) for c in r] for r in righe)
    else:
        raise ErroreTipo(f"`{nome}` vuole una lista di dizionari oppure una lista di liste, "
                         "non un miscuglio.",
                         suggerimento="Esempio: `[[\"nome\", \"voto\"], [\"Ada\", 30]]`.")
    uscita = io.StringIO()
    csv.writer(uscita, delimiter=separatore, lineterminator="\r\n" if excel else "\n").writerows(tabella)
    return uscita.getvalue()


@funzione_libreria("scrivi_tabella")
def scrivi_tabella(percorso, righe, separatore=None, excel=False):
    """scrivi_tabella(percorso, righe, separatore = ",", excel = falso): scrive una tabella in un file CSV.

    `righe` è una lista di dizionari (le chiavi diventano l'intestazione) o una lista di liste.
    Con `excel = vero` il file è pronto per l'Excel italiano: separatore `;`, decimali con la
    virgola, UTF-8 con BOM (le lettere accentate si vedono giuste).
    Esempio: `scrivi_tabella("voti.csv", [{"nome": "Ada", "voto": 30}, {"nome": "Bruno", "voto": 28}])`.
    """
    _controlla_percorso(percorso, "scrivi_tabella")
    testo = _tabella_testo(righe, separatore, excel, "scrivi_tabella")
    try:
        with open(percorso, "w", encoding="utf-8-sig" if excel else "utf-8", newline="") as f:
            f.write(testo)
    except OSError as e:
        raise _errore_file(e, percorso, "scrivere") from None
    except ValueError:
        raise ErroreFile(f"Il percorso `{percorso}` non è valido.") from None
    return None


@funzione_libreria("a_csv")
def a_csv(righe, separatore=",", excel=False):
    """a_csv(righe, separatore = ",", excel = falso): come `scrivi_tabella`, ma restituisce il testo CSV invece di scriverlo.

    Esempio: `a_csv([{"nome": "Ada", "voto": 30}])` è "nome,voto\\nAda,30\\n".
    """
    return _tabella_testo(righe, None if excel and separatore == "," else separatore, excel, "a_csv")


@funzione_libreria("aggiungi_a_tabella")
def aggiungi_a_tabella(percorso, riga):
    """aggiungi_a_tabella(percorso, riga): aggiunge una riga in fondo a un file CSV (lo crea se manca).

    `riga` è un dizionario (le chiavi sono i nomi delle colonne) o una lista. Si usano il separatore
    e l'intestazione del file esistente. Esempio: `aggiungi_a_tabella("voti.csv", {"nome": "Carla", "voto": 27})`.
    """
    from .ingresso_uscita import decodifica_testo

    _controlla_percorso(percorso, "aggiungi_a_tabella")
    if not isinstance(riga, (dict, list)):
        raise ErroreTipo(f"`riga` di `aggiungi_a_tabella` deve essere un dizionario o una lista, "
                         f"non {articolo(riga)}.")
    try:
        with open(percorso, "rb") as f:
            dati = f.read()
    except FileNotFoundError:
        dati = None
    except OSError as e:
        raise _errore_file(e, percorso, "leggere") from None
    except ValueError:
        raise ErroreFile(f"Il percorso `{percorso}` non è valido.") from None
    if not dati or not dati.strip():
        testo = _tabella_testo([riga], ",", False, "aggiungi_a_tabella")
        try:
            with open(percorso, "w", encoding="utf-8", newline="") as f:
                f.write(testo)
        except OSError as e:
            raise _errore_file(e, percorso, "scrivere") from None
        return None
    contenuto = decodifica_testo(dati)
    if contenuto is None:
        raise ErroreFile(f"Il file `{percorso}` non è una tabella CSV (non è un file di testo).")
    if contenuto.startswith("\ufeff"):
        contenuto = contenuto[1:]
    prima = contenuto.split("\n", 1)[0]
    separatore = _indovina_separatore(prima)
    windows = b"\r\n" in dati[:4096]
    excel = separatore == ";"
    if isinstance(riga, dict):
        try:
            intestazione = next(csv.reader([prima], delimiter=separatore))
        except (csv.Error, StopIteration):
            intestazione = []
        nomi = [n.strip() for n in intestazione]
        mancanti = [rappresenta(k) for k in riga if rappresenta(k) not in nomi]
        if mancanti:
            raise ErroreValore(f"La tabella `{percorso}` non ha la colonna `{mancanti[0]}`.",
                               suggerimento="Colonne esistenti: " + ", ".join(f"`{n}`" for n in nomi) + ".")
        chiavi = {rappresenta(k): v for k, v in riga.items()}
        valori = [chiavi.get(n) for n in nomi]
    else:
        valori = riga
    testo = _tabella_testo([valori], separatore, excel, "aggiungi_a_tabella")
    if not windows:
        testo = testo.replace("\r\n", "\n")
    elif not testo.endswith("\r\n"):
        testo = testo.replace("\n", "\r\n")
    codifica = "utf-8"
    if not dati.startswith((b"\xef\xbb\xbf", b"\xff\xfe", b"\xfe\xff")):
        try:
            dati.decode("utf-8")
        except UnicodeDecodeError:
            codifica = "cp1252"  # il file e' "ANSI": si continua nella stessa codifica
    elif dati.startswith((b"\xff\xfe", b"\xfe\xff")):
        raise ErroreFile(f"Il file `{percorso}` è in UTF-16: non posso aggiungere righe senza rovinarlo.",
                         suggerimento="Leggilo con `leggi_tabella` e riscrivilo con `scrivi_tabella`.")
    try:
        nuovo = testo.encode(codifica)
    except UnicodeEncodeError:
        raise ErroreValore(f"La riga contiene caratteri che la codifica del file `{percorso}` (ANSI) "
                           f"non sa scrivere.") from None
    a_capo = b"\r\n" if windows else b"\n"
    _scrivi_in_fondo(percorso, nuovo, not dati.endswith((b"\n", b"\r")), a_capo)
    return None


def _scrivi_in_fondo(percorso: str, dati: bytes, serve_a_capo: bool, a_capo: bytes = b"\n") -> None:
    try:
        with open(percorso, "ab") as f:
            if serve_a_capo:
                f.write(a_capo)
            f.write(dati)
    except OSError as e:
        raise _errore_file(e, percorso, "scrivere") from None


# ---------------------------------------------------------------------------
# JSON
# ---------------------------------------------------------------------------

def _rifiuta_costante(nome: str) -> Any:
    raise ValueError(f"`{nome}` non è ammesso in JSON")


@funzione_libreria("da_json")
def da_json(testo):
    """da_json(testo): trasforma un testo JSON in valori Leo (dizionari, liste, numeri, testi...).

    `null` diventa `nulla`, `true`/`false` diventano `vero`/`falso`.
    Esempio: `da_json("\\{\\"nome\\": \\"Ada\\", \\"voti\\": [30, 28]\\}")["nome"]` è "Ada".
    """
    richiedi_testo(testo, "da_json", "testo")
    try:
        return json.loads(testo, parse_constant=_rifiuta_costante, parse_int=testo_a_intero)
    except json.JSONDecodeError as e:
        raise ErroreValore(f"Il testo non è JSON valido (riga {e.lineno}, colonna {e.colno}): "
                           f"{_spiega_json(e.msg)}.",
                           suggerimento="In JSON i testi vanno tra virgolette doppie \"...\" e "
                                        "non si mette la virgola dopo l'ultimo elemento.") from None
    except ValueError as e:
        raise ErroreValore(f"Il testo non è JSON valido: {e}.") from None
    except RecursionError:
        raise ErroreValore("Il testo JSON è annidato troppo in profondità.") from None


_SPIEGAZIONI = {
    "Expecting value": "manca un valore",
    "Expecting property name enclosed in double quotes": "i nomi delle chiavi vanno tra virgolette doppie",
    "Expecting ',' delimiter": "manca una virgola",
    "Expecting ':' delimiter": "mancano i due punti `:` dopo la chiave",
    "Extra data": "c'è del testo in più dopo la fine",
    "Unterminated string starting at": "un testo non è chiuso dalle virgolette",
    "Invalid control character at": "c'è un carattere non valido dentro un testo",
    "Illegal trailing comma before end of object": "c'è una virgola di troppo prima di `}`",
    "Illegal trailing comma before end of array": "c'è una virgola di troppo prima di `]`",
}


def _spiega_json(messaggio: str) -> str:
    return _SPIEGAZIONI.get(messaggio, messaggio)


#: Parte casuale dei segnaposti: un testo dell'utente non può coincidere per caso.
_SEGRETO = os.urandom(8).hex()


def _segnaposto(i: int) -> str:
    return f"\x00{_SEGRETO}-{i}\x00"


def _a_python(v: Any, profondita: int = 0, grandi: list | None = None) -> Any:
    """Il valore Leo come valore per ``json.dumps``.

    Gli interi con troppe cifre per ``json.dumps`` (limite di Python di 4300 cifre)
    diventano segnaposti in ``grandi``, sostituiti dopo con le loro cifre.
    """
    if profondita > 500:
        raise ErroreValore("Il valore è annidato troppo in profondità per diventare JSON.")
    if v is None or isinstance(v, (bool, str)):
        return v
    if e_numero(v):
        if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
            raise ErroreValore(f"{rappresenta(v)} non si può scrivere in JSON.")
        if grandi is not None and isinstance(v, int) and v.bit_length() > 14_000:  # oltre ~4200 cifre
            try:
                grandi.append(intero_a_testo(v))
            except ValueError as e:
                raise ErroreValore(f"Non posso scrivere in JSON questo numero: {e}.") from None
            return _segnaposto(len(grandi) - 1)
        return v
    if isinstance(v, range) and lunghezza_intervallo(v) > 1_000_000:
        raise ErroreValore("L'intervallo è troppo grande per diventare JSON.")
    if isinstance(v, (list, range)):
        return [_a_python(x, profondita + 1, grandi) for x in v]
    if isinstance(v, dict):
        return {(k if isinstance(k, str) else rappresenta(k)): _a_python(x, profondita + 1, grandi)
                for k, x in v.items()}
    if getattr(type(v), "NOME_TIPO_DANTE", None) == "data":
        return rappresenta(v)
    raise ErroreTipo(f"Non posso trasformare in JSON {articolo(v)}.",
                     suggerimento="In JSON vanno solo testi, numeri, logici, `nulla`, liste e dizionari.")


@funzione_libreria("a_json")
def a_json(valore, rientro=None):
    """a_json(valore, rientro = nulla): trasforma un valore Leo in testo JSON.

    Con `rientro` (un numero di spazi) il testo va a capo ed è più facile da leggere.
    Esempio: `a_json({"nome": "Ada", "voti": [30, 28]})` è "{\\"nome\\": \\"Ada\\", \\"voti\\": [30, 28]}".
    """
    if rientro is not None and not (isinstance(rientro, int) and not isinstance(rientro, bool) and 0 <= rientro <= 16):
        raise ErroreTipo("Il `rientro` di `a_json` deve essere un intero da 0 a 16 (gli spazi di rientro).")
    grandi: list = []
    testo = json.dumps(_a_python(valore, 0, grandi), ensure_ascii=False, indent=rientro)
    for i, cifre in enumerate(grandi):
        testo = testo.replace(json.dumps(_segnaposto(i)), cifre, 1)
    return testo


#: Valore predefinito di ``predefinito``: "non dato" (``nulla`` e' un predefinito valido).
_NON_DATO = object()


@funzione_libreria("leggi_json")
def leggi_json(percorso, predefinito=_NON_DATO):
    """leggi_json(percorso, predefinito): legge un file JSON e lo trasforma in valori Leo.

    Se il file non c'è ancora e hai dato `predefinito`, restituisce quello invece di un errore.
    Esempi: `variabile impostazioni = leggi_json("impostazioni.json")`,
    `variabile punti = leggi_json("punti.json", predefinito = {})`.
    """
    if predefinito is not _NON_DATO and isinstance(percorso, str) and percorso.strip() \
            and "\0" not in percorso and not os.path.exists(percorso):
        return predefinito
    testo = leggi_file(percorso)
    try:
        return da_json(testo)
    except ErroreValore as e:
        raise ErroreFile(f"Il file `{percorso}` non contiene JSON valido: {e.messaggio}",
                         suggerimento=e.suggerimento) from None


@funzione_libreria("scrivi_json")
def scrivi_json(percorso, valore, rientro=2):
    """scrivi_json(percorso, valore, rientro = 2): salva un valore Leo in un file JSON.

    Esempio: `scrivi_json("punteggi.json", {"Ada": 120, "Bruno": 95})`.
    """
    _controlla_percorso(percorso, "scrivi_json")
    testo = a_json(valore, rientro)
    try:
        with open(percorso, "w", encoding="utf-8") as f:
            f.write(testo + "\n")
    except OSError as e:
        raise _errore_file(e, percorso, "scrivere") from None
    return None
