"""Libreria: testo avanzato (``testo_pro``) — schemi in italiano e strumenti di testo.

Questo modulo **non ripete** le operazioni di base (già in ``testi.py``,
``testo_e_lingua.py``, ``modelli.py`` e ``modelli_testo.py``): aggiunge un
livello avanzato.

Il cuore è un **costruttore di schemi**: invece di scrivere a memoria le
espressioni regolari (``\\d+``, ``[^\\W\\d_]+``...) si compongono con funzioni
dai nomi chiari — ``schema_cifre()``, ``schema_parole()``, ``schema_email()``,
``schema_tra("<", ">")`` — e si combinano con i metodi ``.poi(...)``,
``.oppure(...)``, ``.ripetuto(...)``, ``.opzionale()`` e ``.gruppo(...)``.
Ogni schema sa anche **spiegarsi in italiano** (``.spiegazione``).

Gli schemi (o un testo normale, cercato *così com'è*, senza sintassi speciale)
si usano con ``trova_schema``, ``trova_tutti_schema``, ``gruppi_schema``,
``corrisponde_schema``, ``dividi_per_schema`` e ``sostituisci_schema``.

In più: ``parole_di``, ``frasi_di``, ``righe_di``, ``solo_lettere_numeri``,
``a_titolo``, ``accorcia`` e la lettura/scrittura di INI da **testo**
(``da_ini``/``a_ini``, mentre ``leggi_ini``/``scrivi_ini`` di ``formati``
lavorano sui file).

Tutto solo con la libreria standard (``re``, ``configparser``); nessuna
funzione tocca file, rete o sistema, quindi non servono permessi.
"""

from __future__ import annotations

import re
from typing import Any

from ..errori import ErroreTipo, ErroreValore
from ..valori import Richiamabile
from .funzionali import chiama_funzione
from .generali import (articolo, funzione_libreria, mostra, richiedi_intero, richiedi_lista,
                       richiedi_logico, richiedi_testo)
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta


# ===========================================================================
# L'oggetto "schema"
# ===========================================================================

class Schema(OggettoLibreria):
    """Valore Leo di tipo ``schema``: una forma di testo da cercare.

    Si costruisce con le funzioni ``schema_...`` e si combina con i metodi
    ``poi``, ``oppure``, ``ripetuto``, ``opzionale`` e ``gruppo``.
    """

    NOME_TIPO_DANTE = "schema"
    SUGGERIMENTO_MODIFICA = ("Uno schema si costruisce con le funzioni `schema_...` e si combina con "
                             "`.poi(...)`, `.oppure(...)`, `.ripetuto(...)`.")

    def __init__(self, regex: str, spiegazione: str) -> None:
        self.regex = regex
        self.spiegazione = spiegazione

    def testo_dante(self) -> str:
        return f"schema ({self.spiegazione})"

    def __repr__(self) -> str:
        return f"Schema({self.regex!r})"


proprieta(Schema, "regex")(lambda s: s.regex)
proprieta(Schema, "spiegazione")(lambda s: s.spiegazione)


def _gruppo_muto(regex: str) -> str:
    """Racchiude ``regex`` in un gruppo muto ``(?:...)`` quando serve per combinarlo senza rischi."""
    # già un singolo atomo (un carattere, una classe `[...]`, un gruppo `(...)`) o un gruppo muto intero
    if re.fullmatch(r"\\?.", regex) or re.fullmatch(r"\[[^]]*\]", regex):
        return regex
    return f"(?:{regex})"


def _schema_o_errore(valore: Any, funzione: str, parametro: str = "schema") -> Schema:
    if not isinstance(valore, Schema):
        raise ErroreTipo(f"Il `{parametro}` di `{funzione}` deve essere uno schema, non {articolo(valore)}.",
                         suggerimento="Costruiscilo con `schema_cifre`, `schema_parole`, `schema_esatto`...")
    return valore


@metodo_oggetto(Schema, "poi")
def schema_poi_metodo(schema, altro):
    """schema.poi(altro): uno schema che cerca prima questo e **subito dopo** l'altro.

    `altro` può essere un altro schema o un testo (cercato così com'è).
    Esempio: `schema_cifre().poi(schema_esatto("€"))` trova "12€".
    """
    a = _gruppo_muto(schema.regex)
    if isinstance(altro, Schema):
        b, desc = _gruppo_muto(altro.regex), altro.spiegazione
    else:
        richiedi_testo(altro, "poi", "altro")
        b, desc = re.escape(altro), f"il testo {mostra(altro)}"
    return Schema(a + b, f"{schema.spiegazione}, poi {desc}")


@metodo_oggetto(Schema, "oppure")
def schema_oppure_metodo(schema, altro):
    """schema.oppure(altro): uno schema che cerca **questo oppure** l'altro.

    Esempio: `schema_esatto("sì").oppure(schema_esatto("no"))` trova "sì" o "no".
    """
    a = _gruppo_muto(schema.regex)
    if isinstance(altro, Schema):
        b, desc = _gruppo_muto(altro.regex), altro.spiegazione
    else:
        richiedi_testo(altro, "oppure", "altro")
        b, desc = re.escape(altro), f"il testo {mostra(altro)}"
    return Schema(f"(?:{a}|{b})", f"{schema.spiegazione} oppure {desc}")


def _quantita(minimo: Any, massimo: Any, funzione: str) -> str:
    richiedi_intero(minimo, funzione, "minimo")
    if minimo < 0:
        raise ErroreValore(f"Il `minimo` di `{funzione}` non può essere negativo (è {minimo}).")
    if massimo is None:
        if minimo == 0:
            return "*"
        if minimo == 1:
            return "+"
        return f"{{{minimo},}}"
    richiedi_intero(massimo, funzione, "massimo")
    if massimo < minimo:
        raise ErroreValore(f"In `{funzione}` il `massimo` ({massimo}) è più piccolo del `minimo` ({minimo}).",
                           suggerimento="Il massimo deve essere maggiore o uguale al minimo.")
    if minimo == 0 and massimo == 1:
        return "?"
    if minimo == massimo:
        return f"{{{minimo}}}"
    return f"{{{minimo},{massimo}}}"


def _descrizione_quantita(minimo: Any, massimo: Any, singolare: str, plurale: str) -> str:
    if massimo is None:
        if minimo <= 1:
            return f"{'una o più' if minimo else 'zero o più'} {plurale}"
        return f"almeno {minimo} {plurale}"
    if minimo == massimo:
        return f"{minimo} {singolare if minimo == 1 else plurale}"
    return f"da {minimo} a {massimo} {plurale}"


@metodo_oggetto(Schema, "ripetuto")
def schema_ripetuto_metodo(schema, minimo=1, massimo=None):
    """schema.ripetuto(minimo = 1, massimo = nulla): lo stesso schema (attaccato) ripetuto più volte.

    Con `massimo = nulla` significa "senza limite". I pezzi sono attaccati, senza niente in mezzo:
    `schema_cifre(1, 1).poi(schema_esatto("-")).ripetuto(3)` trova "1-2-3-".
    """
    quant = _quantita(minimo, massimo, "ripetuto")
    volte = _descrizione_quantita(minimo, massimo, "volta", "volte")
    return Schema(_gruppo_muto(schema.regex) + quant, f"({schema.spiegazione}) ripetuto {volte}")


@metodo_oggetto(Schema, "opzionale")
def schema_opzionale_metodo(schema):
    """schema.opzionale(): lo schema diventa facoltativo (può esserci oppure no).

    Esempio: `schema_esatto("+").opzionale().poi(schema_cifre())` trova "39" e "+39".
    """
    return Schema(_gruppo_muto(schema.regex) + "?", f"{schema.spiegazione} (facoltativo)")


@metodo_oggetto(Schema, "gruppo")
def schema_gruppo_metodo(schema, nome=None):
    """schema.gruppo(nome = nulla): segna questa parte come **gruppo** da estrarre con `gruppi_schema`.

    Con un `nome` il gruppo è richiamabile per nome. Esempio:
    `schema_cifre().gruppo("anno")` dentro uno schema più grande.
    """
    if nome is None:
        return Schema(f"({schema.regex})", f"{schema.spiegazione} (gruppo)")
    richiedi_testo(nome, "gruppo", "nome")
    if not re.fullmatch(r"[^\W\d]\w*", nome):
        raise ErroreValore(f"Il nome di gruppo {mostra(nome)} non va bene: usa lettere, cifre e `_`, "
                           "iniziando con una lettera.")
    return Schema(f"(?P<{nome}>{schema.regex})", f"{schema.spiegazione} (gruppo «{nome}»)")


# ===========================================================================
# Costruttori di schemi
# ===========================================================================

@funzione_libreria("schema_cifre")
def schema_cifre(minimo=1, massimo=None):
    """schema_cifre(minimo = 1, massimo = nulla): uno schema che trova una sequenza di cifre (0-9).

    Esempi: `trova_tutti_schema("ho 3 gatti e 12 pesci", schema_cifre())` è ["3", "12"];
    `schema_cifre(5, 5)` trova esattamente cinque cifre (come un CAP).
    """
    quant = _quantita(minimo, massimo, "schema_cifre")
    return Schema(r"\d" + quant, _descrizione_quantita(minimo, massimo, "cifra", "cifre"))


@funzione_libreria("schema_lettere")
def schema_lettere(minimo=1, massimo=None):
    """schema_lettere(minimo = 1, massimo = nulla): uno schema che trova una sequenza di lettere (anche accentate).

    Non prende cifre né spazi. Esempio: `trova_tutti_schema("abc123def", schema_lettere())` è ["abc", "def"].
    """
    quant = _quantita(minimo, massimo, "schema_lettere")
    return Schema(r"[^\W\d_]" + quant, _descrizione_quantita(minimo, massimo, "lettera", "lettere"))


@funzione_libreria("schema_parole")
def schema_parole():
    """schema_parole(): uno schema che trova una parola (lettere, con l'apostrofo come in "dell'arte").

    Per prendere tutte le parole di un testo: `trova_tutti_schema(testo, schema_parole())`.
    """
    return Schema(r"[^\W\d_]+(?:'[^\W\d_]+)*", "una parola")


@funzione_libreria("schema_spazi")
def schema_spazi(minimo=1, massimo=None):
    """schema_spazi(minimo = 1, massimo = nulla): uno schema che trova spazi (anche tabulazioni e a-capo).

    Utile per dividere o normalizzare: `sostituisci_schema("a  b\\tc", schema_spazi(), " ")` è "a b c".
    """
    quant = _quantita(minimo, massimo, "schema_spazi")
    return Schema(r"\s" + quant, _descrizione_quantita(minimo, massimo, "spazio", "spazi"))


@funzione_libreria("schema_qualsiasi")
def schema_qualsiasi(minimo=1, massimo=None):
    """schema_qualsiasi(minimo = 1, massimo = nulla): uno schema che trova un carattere qualunque (tranne l'a-capo).

    Esempio: `schema_esatto("(").poi(schema_qualsiasi()).poi(schema_esatto(")"))` trova "(ciao)".
    """
    quant = _quantita(minimo, massimo, "schema_qualsiasi")
    return Schema(r"." + quant, _descrizione_quantita(minimo, massimo, "carattere", "caratteri"))


@funzione_libreria("schema_esatto")
def schema_esatto(testo):
    """schema_esatto(testo): uno schema che trova esattamente quel testo, senza sintassi speciale.

    Comodo per cercare simboli come `.` `(` `+` senza doverli "proteggere".
    Esempio: `corrisponde_schema("3.14", schema_cifre().poi(schema_esatto(".")).poi(schema_cifre()))` è `vero`.
    """
    richiedi_testo(testo, "schema_esatto", "testo")
    if testo == "":
        raise ErroreValore("`schema_esatto` vuole del testo da cercare, non un testo vuoto.")
    return Schema(re.escape(testo), f"il testo {mostra(testo)}")


@funzione_libreria("schema_uno_di")
def schema_uno_di(elenco):
    """schema_uno_di(elenco): uno schema che trova uno qualunque dei testi dell'elenco.

    Esempio: `trova_tutti_schema("mela, pera, mela", schema_uno_di(["mela", "pera"]))` è ["mela", "pera", "mela"].
    """
    richiedi_lista(elenco, "schema_uno_di", "elenco")
    if not elenco:
        raise ErroreValore("`schema_uno_di` vuole un elenco con almeno un testo dentro.")
    pezzi = []
    for v in elenco:
        if not isinstance(v, str):
            raise ErroreTipo(f"`schema_uno_di` vuole un elenco di testi, ma c'è {articolo(v)}.")
        if v == "":
            raise ErroreValore("`schema_uno_di` non accetta testi vuoti nell'elenco.")
        pezzi.append(re.escape(v))
    # i più lunghi prima, così "mela" vince su "me" se entrambi presenti
    pezzi.sort(key=len, reverse=True)
    uniti = ", ".join(mostra(v) for v in elenco)
    return Schema("(?:" + "|".join(pezzi) + ")", f"uno tra {uniti}")


@funzione_libreria("schema_email")
def schema_email():
    """schema_email(): uno schema che trova un indirizzo email (nome@dominio).

    Esempio: `trova_tutti_schema("scrivi a ada@esempio.it", schema_email())` è ["ada@esempio.it"].
    """
    return Schema(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+", "un indirizzo email")


@funzione_libreria("schema_tra")
def schema_tra(prima, dopo):
    """schema_tra(prima, dopo): uno schema che trova il testo **tra** due segni, e lo mette in un gruppo.

    Prende la quantità più corta possibile. Con `gruppi_schema` ottieni il contenuto in mezzo.
    Esempio: `gruppi_schema("<b>ciao</b>", schema_tra("<b>", "</b>"))` è ["ciao"].
    """
    richiedi_testo(prima, "schema_tra", "prima")
    richiedi_testo(dopo, "schema_tra", "dopo")
    if prima == "" or dopo == "":
        raise ErroreValore("`schema_tra` vuole due segni non vuoti (per esempio \"<\" e \">\").")
    return Schema(re.escape(prima) + r"(.*?)" + re.escape(dopo),
                  f"il testo tra {mostra(prima)} e {mostra(dopo)}")


@funzione_libreria("spiega_schema")
def spiega_schema(schema):
    """spiega_schema(schema): la spiegazione in italiano di che cosa cerca lo schema.

    Esempio: `spiega_schema(schema_cifre(5, 5))` è "5 cifre". Equivale a `schema.spiegazione`.
    """
    return _schema_o_errore(schema, "spiega_schema").spiegazione


# ===========================================================================
# Operazioni con gli schemi (accettano uno schema o un testo cercato "così com'è")
# ===========================================================================

def _regola(schema: Any, funzione: str, ignora_maiuscole: Any) -> "re.Pattern[str]":
    richiedi_logico(ignora_maiuscole, funzione, "ignora_maiuscole")
    if isinstance(schema, Schema):
        pattern = schema.regex
    elif isinstance(schema, str):
        if schema == "":
            raise ErroreValore(f"Lo schema dato a `{funzione}` è un testo vuoto.",
                               suggerimento="Dai un testo da cercare o uno schema costruito con `schema_...`.")
        pattern = re.escape(schema)  # un testo normale si cerca così com'è (nessuna sintassi speciale)
    else:
        raise ErroreTipo(f"Lo `schema` di `{funzione}` deve essere uno schema o un testo da cercare, "
                         f"non {articolo(schema)}.",
                         suggerimento="Costruisci uno schema con `schema_cifre`, `schema_parole`, `schema_email`...")
    return re.compile(pattern, re.IGNORECASE if ignora_maiuscole else 0)


@funzione_libreria("trova_schema")
def trova_schema(testo, schema, ignora_maiuscole=False):
    """trova_schema(testo, schema, ignora_maiuscole = falso): il primo pezzo che segue lo schema, o `nulla`.

    Esempio: `trova_schema("Totale: 42 euro", schema_cifre())` è "42".
    """
    richiedi_testo(testo, "trova_schema", "testo")
    m = _regola(schema, "trova_schema", ignora_maiuscole).search(testo)
    return m.group(0) if m else None


@funzione_libreria("trova_tutti_schema")
def trova_tutti_schema(testo, schema, ignora_maiuscole=False):
    """trova_tutti_schema(testo, schema, ignora_maiuscole = falso): la lista di tutti i pezzi che seguono lo schema.

    Esempio: `trova_tutti_schema("tel 333 e 051", schema_cifre())` è ["333", "051"].
    """
    richiedi_testo(testo, "trova_tutti_schema", "testo")
    return [m.group(0) for m in _regola(schema, "trova_tutti_schema", ignora_maiuscole).finditer(testo)]


@funzione_libreria("gruppi_schema")
def gruppi_schema(testo, schema, ignora_maiuscole=False):
    """gruppi_schema(testo, schema, ignora_maiuscole = falso): i gruppi del primo pezzo trovato, o `nulla`.

    Con gruppi dal nome (`.gruppo("nome")`) restituisce un dizionario, altrimenti la lista dei gruppi.
    Esempi: `gruppi_schema("<b>ciao</b>", schema_tra("<b>", "</b>"))` è ["ciao"];
    nessun gruppo nello schema dà una lista vuota, nessun pezzo trovato dà `nulla`.
    """
    richiedi_testo(testo, "gruppi_schema", "testo")
    m = _regola(schema, "gruppi_schema", ignora_maiuscole).search(testo)
    if m is None:
        return None
    if m.re.groupindex:
        return dict(m.groupdict())
    return list(m.groups())


@funzione_libreria("corrisponde_schema")
def corrisponde_schema(testo, schema, ignora_maiuscole=False):
    """corrisponde_schema(testo, schema, ignora_maiuscole = falso): `vero` se TUTTO il testo segue lo schema.

    Serve a controllare quello che scrive l'utente. Esempio:
    `corrisponde_schema("12345", schema_cifre(5, 5))` è `vero`, `corrisponde_schema("12a45", schema_cifre())` è `falso`.
    """
    richiedi_testo(testo, "corrisponde_schema", "testo")
    return _regola(schema, "corrisponde_schema", ignora_maiuscole).fullmatch(testo) is not None


@funzione_libreria("dividi_per_schema")
def dividi_per_schema(testo, schema, ignora_maiuscole=False):
    """dividi_per_schema(testo, schema, ignora_maiuscole = falso): divide il testo dove compare lo schema.

    Esempio: `dividi_per_schema("uno, due;tre", schema_uno_di([", ", ";"]))` è ["uno", "due", "tre"].
    """
    richiedi_testo(testo, "dividi_per_schema", "testo")
    regola = _regola(schema, "dividi_per_schema", ignora_maiuscole)
    pezzi, inizio = [], 0
    for m in regola.finditer(testo):
        if m.end() == m.start():
            continue  # uno schema che trova "niente" non taglia
        pezzi.append(testo[inizio:m.start()])
        inizio = m.end()
    pezzi.append(testo[inizio:])
    return pezzi


@funzione_libreria("sostituisci_schema", interprete=True)
def sostituisci_schema(interprete, testo, schema, con, ignora_maiuscole=False):
    """sostituisci_schema(testo, schema, con, ignora_maiuscole = falso): sostituisce ogni pezzo che segue lo schema.

    `con` è un testo (messo così com'è, senza sorprese) oppure una funzione che riceve il pezzo
    trovato e restituisce il testo da mettere al suo posto.
    Esempi: `sostituisci_schema("a  b   c", schema_spazi(), " ")` è "a b c";
    `sostituisci_schema("3 mele", schema_cifre(), funzione (n) restituisci testo(intero(n) * 2) fine)` è "6 mele".
    """
    richiedi_testo(testo, "sostituisci_schema", "testo")
    regola = _regola(schema, "sostituisci_schema", ignora_maiuscole)
    if isinstance(con, str):
        return regola.sub(lambda _m: con, testo)
    if isinstance(con, Richiamabile):
        def con_funzione(m: "re.Match[str]") -> str:
            r = chiama_funzione(interprete, con, [m.group(0)])
            if not isinstance(r, str):
                raise ErroreTipo(f"La funzione data a `sostituisci_schema` deve restituire un testo, "
                                 f"non {articolo(r)}.",
                                 suggerimento="Trasforma il risultato con `testo(...)`.")
            return r
        return regola.sub(con_funzione, testo)
    raise ErroreTipo(f"Il `con` di `sostituisci_schema` deve essere un testo o una funzione, "
                     f"non {articolo(con)}.")


# ===========================================================================
# Strumenti di testo avanzati
# ===========================================================================

_PAROLA = re.compile(r"[^\W\d_]+(?:'[^\W\d_]+)*")
_FINE_FRASE = re.compile(r"[.!?…]+(?:\s|$)")


@funzione_libreria("parole_di")
def parole_di(testo):
    """parole_di(testo): la lista delle parole del testo (lettere, con l'apostrofo; senza numeri né segni).

    Esempio: `parole_di("Ciao, mondo! L'alba")` è ["Ciao", "mondo", "L'alba"].
    Per i numeri usa `trova_tutti_schema(testo, schema_cifre())`.
    """
    richiedi_testo(testo, "parole_di", "testo")
    return _PAROLA.findall(testo)


@funzione_libreria("frasi_di")
def frasi_di(testo):
    """frasi_di(testo): la lista delle frasi, divise sui segni `.` `!` `?` `…` (senza spazi inutili).

    Esempio: `frasi_di("Ciao. Come va? Bene!")` è ["Ciao.", "Come va?", "Bene!"].
    """
    richiedi_testo(testo, "frasi_di", "testo")
    frasi, inizio = [], 0
    for m in _FINE_FRASE.finditer(testo):
        pezzo = testo[inizio:m.end()].strip()
        if pezzo:
            frasi.append(pezzo)
        inizio = m.end()
    coda = testo[inizio:].strip()
    if coda:
        frasi.append(coda)
    return frasi


@funzione_libreria("righe_di")
def righe_di(testo):
    """righe_di(testo): la lista delle righe del testo (divise agli a-capo, senza l'a-capo).

    Vanno bene gli a-capo di Windows, Mac e Unix. Esempio: `righe_di("a\\nb\\nc")` è ["a", "b", "c"].
    """
    richiedi_testo(testo, "righe_di", "testo")
    return testo.splitlines()


@funzione_libreria("solo_lettere_numeri")
def solo_lettere_numeri(testo, tieni_spazi=False):
    """solo_lettere_numeri(testo, tieni_spazi = falso): toglie dal testo tutto tranne lettere e cifre.

    Con `tieni_spazi = vero` lascia anche gli spazi. Esempio:
    `solo_lettere_numeri("C-3PO, va bene!")` è "C3POvabene".
    """
    richiedi_testo(testo, "solo_lettere_numeri", "testo")
    richiedi_logico(tieni_spazi, "solo_lettere_numeri", "tieni_spazi")
    if tieni_spazi:
        return "".join(c for c in testo if c.isalnum() or c.isspace())
    return "".join(c for c in testo if c.isalnum())


@funzione_libreria("a_titolo")
def a_titolo(testo):
    """a_titolo(testo): mette in maiuscolo la prima lettera di ogni parola e in minuscolo il resto.

    A differenza di altri modi gestisce bene l'apostrofo e gli accenti.
    Esempio: `a_titolo("l'ISOLA del TESORO")` è "L'isola Del Tesoro".
    """
    richiedi_testo(testo, "a_titolo", "testo")

    def alza(m: "re.Match[str]") -> str:
        parola = m.group(0)
        return parola[0].upper() + parola[1:].lower()

    return re.sub(r"[^\W\d_]+", alza, testo)


@funzione_libreria("accorcia")
def accorcia(testo, n, finale="…"):
    """accorcia(testo, n, finale = "…"): accorcia il testo a `n` caratteri al massimo, aggiungendo `finale`.

    Se il testo è già corto resta com'è. Il risultato (segno finale compreso) non supera `n` caratteri.
    Esempio: `accorcia("Buongiorno a tutti", 10)` è "Buongiorn…".
    """
    richiedi_testo(testo, "accorcia", "testo")
    richiedi_intero(n, "accorcia", "n")
    richiedi_testo(finale, "accorcia", "finale")
    if n < 0:
        raise ErroreValore(f"Il `n` di `accorcia` non può essere negativo (è {n}).")
    if len(testo) <= n:
        return testo
    if n <= len(finale):
        return testo[:n]
    return testo[:n - len(finale)] + finale


# ===========================================================================
# INI da testo (i file li fanno `leggi_ini`/`scrivi_ini` di `formati`)
# ===========================================================================

def _valore_ini(testo: str) -> Any:
    basso = testo.strip().lower()
    if basso in ("vero", "true", "sì", "si"):
        return True
    if basso in ("falso", "false", "no"):
        return False
    try:
        return int(testo)
    except ValueError:
        pass
    try:
        return float(testo.replace(",", ".")) if re.fullmatch(r"[+-]?\d+[.,]\d+", testo.strip()) else testo
    except ValueError:
        return testo


@funzione_libreria("da_ini")
def da_ini(testo, converti=True):
    """da_ini(testo, converti = vero): legge un testo in formato INI e lo trasforma in un dizionario di sezioni.

    Ogni sezione `[nome]` diventa un dizionario di coppie chiave-valore. Con `converti = vero`
    numeri e vero/falso diventano valori veri (non testo).
    Esempio: `da_ini("[gioco]\\nvite = 3\\naudio = sì")` è {"gioco": {"vite": 3, "audio": vero}}.
    """
    richiedi_testo(testo, "da_ini", "testo")
    richiedi_logico(converti, "da_ini", "converti")
    import configparser
    lettore = configparser.ConfigParser(interpolation=None)
    lettore.optionxform = str  # non abbassare le maiuscole delle chiavi
    try:
        lettore.read_string(testo)
    except configparser.Error as e:
        riga = getattr(e, "lineno", None)
        dove = f" (riga {riga})" if riga else ""
        if isinstance(e, configparser.MissingSectionHeaderError):
            motivo = "prima delle righe `chiave = valore` serve l'intestazione di una sezione fra parentesi quadre"
        elif isinstance(e, configparser.DuplicateOptionError):
            motivo = (f"la chiave `{e.option}` compare due volte nella sezione `{e.section}`"
                      if getattr(e, "option", None) else "una chiave è ripetuta nella stessa sezione")
        elif isinstance(e, configparser.DuplicateSectionError):
            motivo = (f"la sezione `{e.section}` compare due volte"
                      if getattr(e, "section", None) else "una sezione è ripetuta")
        else:
            motivo = "una riga non è né una sezione `[nome]` né una coppia `chiave = valore`"
        raise ErroreValore(f"Il testo dato a `da_ini` non è un INI valido{dove}: {motivo}.",
                           suggerimento="Ogni sezione va tra parentesi quadre, es. `[impostazioni]`, "
                                        "e le righe sono `chiave = valore`.") from None
    risultato: dict[str, dict[str, Any]] = {}
    if lettore.defaults():
        risultato[""] = {k: (_valore_ini(v) if converti else v) for k, v in lettore.defaults().items()}
    for sezione in lettore.sections():
        risultato[sezione] = {k: (_valore_ini(v) if converti else v)
                              for k, v in lettore.items(sezione)}
    return risultato


@funzione_libreria("a_ini")
def a_ini(dati):
    """a_ini(dati): trasforma un dizionario di sezioni in un testo in formato INI.

    `dati` è un dizionario dove ogni valore è a sua volta un dizionario (una sezione).
    Esempio: `a_ini({"gioco": {"vite": 3, "audio": vero}})` è "[gioco]\\nvite = 3\\naudio = vero\\n".
    """
    if not isinstance(dati, dict):
        raise ErroreTipo(f"`a_ini` vuole un dizionario di sezioni, non {articolo(dati)}.",
                         suggerimento="Esempio: {\"gioco\": {\"vite\": 3}}.")
    righe: list[str] = []
    for sezione, coppie in dati.items():
        if not isinstance(sezione, str):
            raise ErroreTipo(f"In `a_ini` i nomi delle sezioni devono essere testi, non {articolo(sezione)}.")
        if not isinstance(coppie, dict):
            raise ErroreTipo(f"In `a_ini` ogni sezione deve essere un dizionario, ma {mostra(sezione)} "
                             f"ha {articolo(coppie)}.",
                             suggerimento="Esempio: {\"gioco\": {\"vite\": 3}}.")
        righe.append(f"[{sezione}]")
        for chiave, valore in coppie.items():
            if not isinstance(chiave, str):
                raise ErroreTipo(f"In `a_ini` le chiavi devono essere testi, non {articolo(chiave)}.")
            if valore is True:
                testo_valore = "vero"
            elif valore is False:
                testo_valore = "falso"
            elif valore is None:
                testo_valore = ""
            elif isinstance(valore, str):
                testo_valore = valore
            elif isinstance(valore, (int, float)):
                testo_valore = repr(valore) if isinstance(valore, float) else str(valore)
            else:
                raise ErroreTipo(f"In `a_ini` il valore di {mostra(chiave)} deve essere testo, numero o vero/falso, "
                                 f"non {articolo(valore)}.")
            if "\n" in testo_valore:
                raise ErroreValore(f"In `a_ini` il valore di {mostra(chiave)} non può andare a capo.")
            righe.append(f"{chiave} = {testo_valore}")
        righe.append("")
    return "\n".join(righe)
