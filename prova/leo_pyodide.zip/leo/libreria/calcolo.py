"""Libreria: calcolo e dati (categoria ``calcolo_dati``).

Funzioni comode per numeri, vettori e matrici che completano quelle già presenti
in Leo (``matematica``, ``matematica_avanzata``, ``statistica``, ``scienza``,
``funzionali`` e le tabelle di ``tabelle``). Qui NON si ripete ciò che esiste già
(``somma_vettori``, ``trasposta``, ``determinante``, ``media``, ``quartili``,
``normalizza``, le tabelle...): si aggiunge quello che mancava per rendere il
lavoro con i numeri più diretto che in Python.

Un vettore è una lista di numeri ``[1, 2, 3]``; una matrice è una lista di righe
``[[1, 2], [3, 4]]``, come nel resto di Leo.

Tutto funziona in Python puro su qualunque dispositivo (anche il telefono). Dove
è presente ``numpy`` viene usato in modo trasparente per costruire grandi vettori
e matrici più in fretta, con lo stesso identico risultato; se manca, Leo usa
l'implementazione pura senza che tu debba installare nulla.
"""

from __future__ import annotations

import math
from collections import Counter
from decimal import Decimal, localcontext
from typing import Any

from ..errori import ErroreTipo, ErroreValore
from ..valori import e_numero
from .generali import (articolo, funzione_libreria, lunghezza_intervallo, mostra,
                       richiedi_intero, richiedi_lista, richiedi_numero)

# numpy è opzionale: se c'è si usa per allocare in fretta grandi strutture,
# altrimenti si fa tutto in Python puro. Il risultato è identico.
try:                                 # pragma: no cover - dipende dall'ambiente
    import numpy as _np
except ImportError:                  # pragma: no cover
    _np = None

#: Oltre questa lunghezza fermiamo la creazione, per non riempire la memoria.
_MASSIMO = 10_000_000


# ===========================================================================
# Aiutanti interni
# ===========================================================================

def _vettore(v: Any, nome: str, parametro: str = "vettore") -> list:
    """La lista ``v`` controllata: deve esistere, non essere vuota, soli numeri."""
    richiedi_lista(v, nome, parametro)
    if not v:
        raise ErroreValore(f"Il vettore `{parametro}` di `{nome}` è vuoto.",
                           suggerimento="Serve almeno un numero, per esempio [1, 2, 3].")
    for x in v:
        if not e_numero(x) or isinstance(x, bool):
            raise ErroreTipo(f"`{nome}` lavora solo con numeri, ma nel vettore c'è {articolo(x)}.",
                             suggerimento="Trasforma prima i testi in numeri: `mappa(lista, decimale)`.")
    return v


def _due_vettori(v: Any, w: Any, nome: str) -> tuple[list, list]:
    a = _vettore(v, nome, "v")
    b = _vettore(w, nome, "w")
    if len(a) != len(b):
        raise ErroreValore(f"I due vettori di `{nome}` hanno lunghezze diverse ({len(a)} e {len(b)}).",
                           suggerimento="Devono avere lo stesso numero di elementi.")
    return a, b


def _numeri(lista: Any, nome: str, *, minimo: int = 1) -> list:
    """I numeri di una lista o di un intervallo, controllati (minimo quanti)."""
    if isinstance(lista, range):
        if lunghezza_intervallo(lista) > _MASSIMO:
            raise ErroreValore(f"L'intervallo di `{nome}` è troppo grande (più di {_MASSIMO} numeri).",
                               suggerimento="Lavora con una lista di numeri o con un intervallo più piccolo.")
        dati = list(lista)
    else:
        richiedi_lista(lista, nome, "lista")
        dati = lista
        for x in dati:
            if not e_numero(x) or isinstance(x, bool):
                raise ErroreTipo(f"`{nome}` lavora solo con numeri, ma nella lista c'è {articolo(x)}.",
                                 suggerimento="Trasforma prima i testi in numeri: `mappa(lista, decimale)`.")
    if len(dati) < minimo:
        if not dati:
            raise ErroreValore(f"Non posso calcolare `{nome}` di una lista vuota.",
                               suggerimento="Controlla prima con `se non vuota(lista) allora`.")
        raise ErroreValore(f"Per calcolare `{nome}` servono almeno {minimo} numeri.")
    return dati


def _media(dati: list) -> float:
    return math.fsum(dati) / len(dati)


def _pulisci(x: float) -> float | int:
    """Numero in virgola mobile senza i soliti errori di coda (0.30000000000004 -> 0.3)."""
    if isinstance(x, int):
        return x
    if math.isinf(x) or math.isnan(x):
        return x
    corto = float(repr(x))
    return corto


# ===========================================================================
# Creazione di vettori e matrici
# ===========================================================================

@funzione_libreria("crea_vettore")
def crea_vettore(lunghezza, valore=0):
    """crea_vettore(lunghezza, valore = 0): un vettore di `lunghezza` elementi tutti uguali a `valore`.

    Esempio: `crea_vettore(3)` è [0, 0, 0]; `crea_vettore(4, 1)` è [1, 1, 1, 1].
    """
    richiedi_intero(lunghezza, "crea_vettore", "lunghezza")
    richiedi_numero(valore, "crea_vettore", "valore")
    if lunghezza < 0:
        raise ErroreValore(f"La `lunghezza` di `crea_vettore` non può essere negativa (hai scritto {lunghezza}).")
    if lunghezza > _MASSIMO:
        raise ErroreValore(f"`crea_vettore` può fare al massimo {_MASSIMO} elementi.")
    if _np is not None and lunghezza > 1000:
        return _np.full(lunghezza, valore).tolist()
    return [valore] * lunghezza


@funzione_libreria("crea_matrice")
def crea_matrice(righe, colonne, valore=0):
    """crea_matrice(righe, colonne, valore = 0): una matrice `righe`x`colonne` piena di `valore`.

    Esempio: `crea_matrice(2, 3)` è [[0, 0, 0], [0, 0, 0]]; `crea_matrice(2, 2, 1)` è [[1, 1], [1, 1]].
    """
    richiedi_intero(righe, "crea_matrice", "righe")
    richiedi_intero(colonne, "crea_matrice", "colonne")
    richiedi_numero(valore, "crea_matrice", "valore")
    if righe < 0 or colonne < 0:
        raise ErroreValore("Le dimensioni di `crea_matrice` non possono essere negative.")
    if righe > _MASSIMO or colonne > _MASSIMO or righe * colonne > _MASSIMO:
        raise ErroreValore(f"`crea_matrice` può fare al massimo {_MASSIMO} celle.")
    if _np is not None and righe * colonne > 1000:
        return _np.full((righe, colonne), valore).tolist()
    return [[valore] * colonne for _ in range(righe)]


@funzione_libreria("matrice_diagonale")
def matrice_diagonale(vettore):
    """matrice_diagonale(vettore): la matrice quadrata con `vettore` sulla diagonale e 0 altrove.

    Esempio: `matrice_diagonale([1, 2, 3])` è [[1, 0, 0], [0, 2, 0], [0, 0, 3]].
    """
    v = _vettore(vettore, "matrice_diagonale", "vettore")
    n = len(v)
    if n > 3162:                      # 3162^2 ~ 10 milioni di celle
        raise ErroreValore("`matrice_diagonale` è troppo grande.")
    return [[v[i] if i == j else 0 for j in range(n)] for i in range(n)]


# ===========================================================================
# Operazioni sui vettori
# ===========================================================================

@funzione_libreria("sottrai_vettori")
def sottrai_vettori(v, w):
    """sottrai_vettori(v, w): la differenza elemento per elemento di due vettori (v meno w).

    Esempio: `sottrai_vettori([10, 20, 30], [1, 2, 3])` è [9, 18, 27].
    """
    a, b = _due_vettori(v, w, "sottrai_vettori")
    return [x - y for x, y in zip(a, b)]


@funzione_libreria("scala_vettore")
def scala_vettore(vettore, numero):
    """scala_vettore(vettore, numero): il vettore con ogni elemento moltiplicato per `numero`.

    Esempio: `scala_vettore([1, 2, 3], 10)` è [10, 20, 30].
    """
    v = _vettore(vettore, "scala_vettore", "vettore")
    k = richiedi_numero(numero, "scala_vettore", "numero")
    return [x * k for x in v]


@funzione_libreria("distanza_vettori")
def distanza_vettori(v, w):
    """distanza_vettori(v, w): la distanza euclidea tra due vettori (la lunghezza della loro differenza).

    Esempio: `distanza_vettori([0, 0], [3, 4])` è 5.0.
    """
    a, b = _due_vettori(v, w, "distanza_vettori")
    return _pulisci(math.sqrt(math.fsum((x - y) ** 2 for x, y in zip(a, b))))


@funzione_libreria("vettore_unitario")
def vettore_unitario(vettore):
    """vettore_unitario(vettore): il vettore con la stessa direzione ma lunghezza 1.

    Esempio: `vettore_unitario([3, 4])` è [0.6, 0.8].
    """
    v = _vettore(vettore, "vettore_unitario", "vettore")
    norma = math.sqrt(math.fsum(x ** 2 for x in v))
    if norma == 0:
        raise ErroreValore("Il vettore ha lunghezza 0: non ha una direzione.",
                           suggerimento="Serve un vettore con almeno un numero diverso da zero.")
    return [_pulisci(x / norma) for x in v]


# ===========================================================================
# Operazioni sulle matrici (diagonale e traccia completano trasposta/determinante/inversa già presenti)
# ===========================================================================

def _matrice(m: Any, nome: str) -> list:
    richiedi_lista(m, nome, "matrice")
    if not m:
        raise ErroreValore(f"La matrice di `{nome}` è vuota.",
                           suggerimento="Scrivila come lista di righe, per esempio [[1, 2], [3, 4]].")
    colonne = None
    for i, riga in enumerate(m):
        if not isinstance(riga, list) or not riga:
            raise ErroreTipo(f"In `{nome}` ogni riga deve essere una lista di numeri: la riga {i + 1} è {articolo(riga)}.",
                             suggerimento="Esempio: [[1, 2], [3, 4]].")
        if colonne is None:
            colonne = len(riga)
        elif len(riga) != colonne:
            raise ErroreValore(f"In `{nome}` le righe hanno lunghezze diverse "
                               f"(la riga 1 ne ha {colonne}, la riga {i + 1} ne ha {len(riga)}).")
        for x in riga:
            if not e_numero(x) or isinstance(x, bool):
                raise ErroreTipo(f"`{nome}` lavora solo con numeri, ma nella matrice c'è {articolo(x)}.")
    return m


@funzione_libreria("diagonale")
def diagonale(matrice):
    """diagonale(matrice): i numeri sulla diagonale principale, dall'angolo in alto a sinistra.

    Esempio: `diagonale([[1, 2], [3, 4]])` è [1, 4].
    """
    m = _matrice(matrice, "diagonale")
    n = min(len(m), len(m[0]))
    return [m[i][i] for i in range(n)]


@funzione_libreria("traccia_matrice")
def traccia_matrice(matrice):
    """traccia_matrice(matrice): la somma dei numeri sulla diagonale di una matrice quadrata.

    Esempio: `traccia_matrice([[1, 2], [3, 4]])` è 5.
    """
    m = _matrice(matrice, "traccia_matrice")
    if len(m) != len(m[0]):
        raise ErroreValore(f"`traccia_matrice` vuole una matrice quadrata, non {len(m)}x{len(m[0])}.")
    totale = sum(m[i][i] for i in range(len(m)))
    return _pulisci(totale) if isinstance(totale, float) else totale


# ===========================================================================
# Numeri e serie
# ===========================================================================

@funzione_libreria("serie")
def serie(da, a, passo=1):
    """serie(da, a, passo = 1): i numeri da `da` fino ad `a` compreso, andando di `passo` (anche decimale).

    A differenza di `intervallo`, qui il passo può essere decimale.
    Esempi: `serie(0, 1, 0.1)` è 0, 0.1, 0.2, ... 1.0; `serie(5, 1, -2)` è 5, 3, 1.
    """
    richiedi_numero(da, "serie", "da")
    richiedi_numero(a, "serie", "a")
    richiedi_numero(passo, "serie", "passo")
    for valore, nome in ((da, "da"), (a, "a"), (passo, "passo")):
        if isinstance(valore, float) and (math.isinf(valore) or math.isnan(valore)):
            raise ErroreValore(f"Il `{nome}` di `serie` deve essere un numero normale, non {mostra(valore)}.",
                               suggerimento="Usa numeri finiti, per esempio serie(0, 10, 0.5).")
    if passo == 0:
        raise ErroreValore("Il `passo` di `serie` non può essere 0: la serie non finirebbe mai.")
    # Tutti i conti con Decimal: `serie(0, 1, 0.1)` dà 0.1, 0.2 ... senza code di errori,
    # e numeri enormi non fanno traboccare la virgola mobile.
    d_da, d_a, d_passo = Decimal(repr(da)), Decimal(repr(a)), Decimal(repr(passo))
    if d_a != d_da and (d_a > d_da) != (d_passo > 0):
        raise ErroreValore(f"Con passo {mostra(passo)} non si va da {mostra(da)} a {mostra(a)}.",
                           suggerimento="Il passo deve essere positivo per salire, negativo per scendere.")
    with localcontext() as ctx:
        ctx.prec = 50
        quanti = int((d_a - d_da) / d_passo) + 1
    if quanti > _MASSIMO:
        raise ErroreValore(f"`serie` produrrebbe troppi numeri (più di {_MASSIMO}).",
                           suggerimento="Usa un intervallo più piccolo o un passo più grande.")
    interi = all(isinstance(x, int) for x in (da, a, passo))
    risultato = []
    for i in range(quanti):
        v = d_da + d_passo * i
        risultato.append(int(v) if interi else float(v))
    return risultato


@funzione_libreria("prodotto")
def prodotto(lista):
    """prodotto(lista): il prodotto di tutti i numeri di una lista o di un intervallo (1 se è vuota).

    È il compagno di `somma`. Esempio: `prodotto([1, 2, 3, 4])` è 24.
    """
    dati = _numeri(lista, "prodotto", minimo=0)
    risultato: Any = 1
    for x in dati:
        risultato *= x
        if isinstance(risultato, float) and math.isinf(risultato):
            raise ErroreValore("Il prodotto è troppo grande per essere calcolato.",
                               suggerimento="I numeri sono enormi: prova a lavorare con meno numeri.")
    return _pulisci(risultato) if isinstance(risultato, float) else risultato


@funzione_libreria("somma_cumulata")
def somma_cumulata(lista):
    """somma_cumulata(lista): le somme parziali, passo dopo passo (l'ultima è la somma totale).

    Esempio: `somma_cumulata([1, 2, 3, 4])` è [1, 3, 6, 10].
    """
    dati = _numeri(lista, "somma_cumulata", minimo=0)
    risultato = []
    totale: Any = 0
    for x in dati:
        totale += x
        risultato.append(_pulisci(totale) if isinstance(totale, float) else totale)
    return risultato


@funzione_libreria("rimappa")
def rimappa(valore, da_minimo, da_massimo, a_minimo, a_massimo):
    """rimappa(valore, da_minimo, da_massimo, a_minimo, a_massimo): porta un numero da un intervallo a un altro.

    Utile per barre, percentuali e colori. Esempio: `rimappa(5, 0, 10, 0, 100)` è 50.0.
    """
    v = richiedi_numero(valore, "rimappa", "valore")
    dm = richiedi_numero(da_minimo, "rimappa", "da_minimo")
    dM = richiedi_numero(da_massimo, "rimappa", "da_massimo")
    am = richiedi_numero(a_minimo, "rimappa", "a_minimo")
    aM = richiedi_numero(a_massimo, "rimappa", "a_massimo")
    if dm == dM:
        raise ErroreValore("L'intervallo di partenza di `rimappa` è vuoto (minimo e massimo uguali).",
                           suggerimento="`da_minimo` e `da_massimo` devono essere diversi.")
    return _pulisci(am + (v - dm) * (aM - am) / (dM - dm))


@funzione_libreria("limita")
def limita(valore, minimo, massimo):
    """limita(valore, minimo, massimo): il numero riportato dentro l'intervallo [minimo, massimo].

    Esempi: `limita(15, 0, 10)` è 10; `limita(-3, 0, 10)` è 0; `limita(7, 0, 10)` è 7.
    """
    v = richiedi_numero(valore, "limita", "valore")
    mn = richiedi_numero(minimo, "limita", "minimo")
    mx = richiedi_numero(massimo, "limita", "massimo")
    if mn > mx:
        raise ErroreValore(f"`limita` ha il minimo ({mostra(mn)}) più grande del massimo ({mostra(mx)}).",
                           suggerimento="Scrivi prima il minimo e poi il massimo.")
    return mn if v < mn else mx if v > mx else v


# ===========================================================================
# Statistica (completa media/mediana/moda/varianza/percentile/correlazione già presenti)
# ===========================================================================

@funzione_libreria("covarianza")
def covarianza(x, y):
    """covarianza(x, y): quanto due serie di numeri crescono o calano insieme (positiva: insieme).

    Serve per capire se due misure sono legate. Esempio: `covarianza([1, 2, 3], [1, 2, 3])` è circa 0.667.
    """
    a = _numeri(x, "covarianza", minimo=1)
    b = _numeri(y, "covarianza", minimo=1)
    if len(a) != len(b):
        raise ErroreValore(f"Le due liste di `covarianza` hanno lunghezze diverse ({len(a)} e {len(b)}).")
    ma, mb = _media(a), _media(b)
    return _pulisci(math.fsum((p - ma) * (q - mb) for p, q in zip(a, b)) / len(a))


@funzione_libreria("standardizza")
def standardizza(lista):
    """standardizza(lista): trasforma i numeri in punteggi z (media 0, deviazione 1).

    Utile per confrontare misure di scale diverse. Esempio: `standardizza([10, 20, 30])` è [-1.224..., 0.0, 1.224...].
    """
    dati = _numeri(lista, "standardizza", minimo=2)
    m = _media(dati)
    dev = math.sqrt(math.fsum((x - m) ** 2 for x in dati) / len(dati))
    if dev == 0:
        raise ErroreValore("Non posso standardizzare: tutti i numeri sono uguali (deviazione 0).",
                           suggerimento="Servono numeri con qualche differenza tra loro.")
    return [_pulisci((x - m) / dev) for x in dati]


@funzione_libreria("scarto_assoluto_medio")
def scarto_assoluto_medio(lista):
    """scarto_assoluto_medio(lista): di quanto, in media, i numeri si allontanano dalla loro media.

    Più robusto della deviazione standard. Esempio: `scarto_assoluto_medio([2, 4, 6, 8])` è 2.0.
    """
    dati = _numeri(lista, "scarto_assoluto_medio", minimo=1)
    m = _media(dati)
    return _pulisci(math.fsum(abs(x - m) for x in dati) / len(dati))


@funzione_libreria("conteggi")
def conteggi(lista):
    """conteggi(lista): un dizionario che dice quante volte compare ogni valore, nell'ordine di prima comparsa.

    Vale anche per testi. Esempio: `conteggi(["a", "b", "a", "c", "a"])` è {"a": 3, "b": 1, "c": 1}.
    """
    richiedi_lista(lista, "conteggi", "lista")
    conta: dict = {}
    for v in lista:
        try:
            conta[v] = conta.get(v, 0) + 1
        except TypeError:
            raise ErroreTipo(f"`conteggi` non sa contare {articolo(v)} (non è un valore semplice).",
                             suggerimento="Funziona con numeri, testi e valori logici.") from None
    return conta


@funzione_libreria("riepilogo_numeri")
def riepilogo_numeri(lista):
    """riepilogo_numeri(lista): un dizionario con conteggio, media, minimo, primo_quartile, mediana, terzo_quartile, massimo e deviazione.

    Come il `describe` di pandas, ma già in Leo. Esempio: `riepilogo_numeri([1, 2, 3, 4])["media"]` è 2.5.
    """
    dati = sorted(_numeri(lista, "riepilogo_numeri", minimo=1))
    n = len(dati)
    m = _media(dati)
    dev = math.sqrt(math.fsum((x - m) ** 2 for x in dati) / n) if n >= 1 else 0.0

    def _percentile(frazione: float) -> float:
        if n == 1:
            return float(dati[0])
        posizione = frazione * (n - 1)
        basso = math.floor(posizione)
        alto = math.ceil(posizione)
        if basso == alto:
            return float(dati[basso])
        peso = posizione - basso
        return dati[basso] * (1 - peso) + dati[alto] * peso

    return {
        "conteggio": n,
        "media": _pulisci(m),
        "minimo": dati[0],
        "primo_quartile": _pulisci(_percentile(0.25)),
        "mediana": _pulisci(_percentile(0.5)),
        "terzo_quartile": _pulisci(_percentile(0.75)),
        "massimo": dati[-1],
        "deviazione": _pulisci(dev),
    }
