"""Libreria: analisi dei file, forense di base e analisi dei log (DIFENSIVA e didattica).

Strumenti per CAPIRE e PROTEGGERE i propri file e i propri registri (log), con la
sola libreria standard di Python. Si appoggia a ``binario`` (tipo vero di un file,
entropia, EXIF, impronte) e a ``sicurezza_dati`` (impronte, HMAC): qui non si
ripete niente, si completa.

Gruppi di funzioni:

* **Identificazione e integrità**: ``tipo_dai_byte`` e ``elenca_firme`` (il vero
  tipo da decine di "numeri magici"), ``estensione_coerente`` (l'estensione mente?),
  ``impronta_albero``/``confronta_alberi`` (fotografia di una cartella e che cosa è
  cambiato, con data e dimensione), ``verifica_integrita`` (rispetto a impronte note);
* **Riconoscimento di schemi** (stile YARA, in italiano): ``condizione_testo``,
  ``condizione_byte``, ``condizione_regex``, ``regola_schema``, ``descrivi_regola``,
  ``cerca_schema``/``cerca_schema_cartella``, ``applica_regole``/``applica_regole_cartella``,
  ``regole_pronte`` (regole già fatte per schemi NOTI e LEGITTIMI: eseguibili, archivi,
  chiavi private lasciate in chiaro, token/segreti dimenticati, email/IP/carte);
* **Metadati** (oltre all'EXIF di ``binario``): ``metadati_pdf``, ``metadati_zip``,
  ``metadati_office``, ``metadati_audio``, ``togli_metadati`` (privacy), ``date_file`` e
  ``date_incoerenti`` (le date di un file e le loro stranezze);
* **Analisi dei log**: ``leggi_log`` e ``analizza_log_web``/``analizza_syslog``/
  ``analizza_log_csv``/``analizza_log_firewall``, ``raggruppa_eventi``, ``conta_valori``,
  ``riepilogo_log``, ``accessi_falliti``, ``ip_sospetti``, ``orari_insoliti``,
  ``trova_anomalie_log`` e ``segui_log`` (segue un file dal vivo e avvisa su uno schema);
* **File sospetto** (triage difensivo): ``stringhe_leggibili`` (come *strings*),
  ``estrai_url``/``estrai_ip``/``estrai_email``/``estrai_carte``, ``cerca_segreti`` e
  ``indizi_file`` (un riassunto in una chiamata).

LINEA ETICA (obbligatoria). Questi sono mattoni difensivi: servono a trovare e
PROTEGGERE, non a creare minacce. NIENTE esecuzione di file sospetti, niente
creazione di malware, niente scansione di reti altrui. I segreti e le carte
trovati vengono sempre MASCHERATI: non compaiono mai in chiaro nei risultati né
nei messaggi d'errore.
"""

from __future__ import annotations

import csv as _csv
import io
import os
import re
import struct
import time
import zipfile
from collections import Counter
from datetime import datetime, timezone
from typing import Any

from ..errori import ErroreFile, ErroreTipo, ErroreValore
from .generali import articolo, funzione_libreria, mostra, richiedi_intero, richiedi_logico, richiedi_testo
from .ingresso_uscita import _controlla_percorso, _errore_file

#: Un file più grande di così non si legge tutto in memoria.
MASSIMO_FILE = 256 * 1024 * 1024
#: Quanti byte leggere per riconoscere il tipo.
TESTA = 4096


# ===========================================================================
# Strumenti comuni
# ===========================================================================

def _in_byte(dati: Any, nome_funzione: str, parametro: str = "dati") -> bytes:
    """Un testo (UTF-8), una lista di numeri 0-255 o dei ``dati_binari`` come ``bytes``."""
    from .binario import DatiBinari

    if isinstance(dati, DatiBinari):
        return dati.valore
    if isinstance(dati, (bytes, bytearray)):
        return bytes(dati)
    if isinstance(dati, str):
        return dati.encode("utf-8", "surrogatepass")
    if isinstance(dati, list):
        for i, b in enumerate(dati):
            if type(b) is not int or not 0 <= b <= 255:
                raise ErroreValore(f"Nella lista di byte di `{nome_funzione}` l'elemento in posizione {i} "
                                   f"({mostra(b)}) non è un numero da 0 a 255.")
        return bytes(dati)
    raise ErroreTipo(f"L'argomento `{parametro}` di `{nome_funzione}` deve essere un testo, una lista di byte "
                     f"o dei `dati_binari`, non {articolo(dati)}.")


def _testo_per_ricerca(dati: Any, nome_funzione: str, parametro: str = "dati") -> str:
    """Il contenuto come testo per cercarci dentro (i byte diventano caratteri 1:1 con latin-1)."""
    if isinstance(dati, str):
        return dati
    return _in_byte(dati, nome_funzione, parametro).decode("latin-1")


def _leggi(percorso: Any, nome_funzione: str, massimo: int = MASSIMO_FILE) -> bytes:
    _controlla_percorso(percorso, nome_funzione)
    try:
        with open(percorso, "rb") as f:
            contenuto = f.read(massimo + 1)
    except OSError as e:
        raise _errore_file(e, percorso, "leggere") from None
    if len(contenuto) > massimo:
        raise ErroreValore(f"Il file `{percorso}` è troppo grande per `{nome_funzione}` "
                           f"(massimo {massimo // (1024 * 1024)} MB).")
    return contenuto


def _leggi_testo(percorso: Any, nome_funzione: str, massimo: int = MASSIMO_FILE) -> str:
    return _leggi(percorso, nome_funzione, massimo).decode("utf-8", "replace")


def _cartella(cartella: Any, nome_funzione: str) -> str:
    _controlla_percorso(cartella, nome_funzione)
    if not os.path.isdir(cartella):
        if os.path.exists(cartella):
            raise ErroreFile(f"`{cartella}` è un file, non una cartella.",
                             suggerimento="Dai a questa funzione il nome di una cartella.")
        raise ErroreFile(f"La cartella `{cartella}` non esiste.",
                         suggerimento=f"Controlla il nome: ora sei in `{os.getcwd()}`.")
    return cartella


def _ogni_file(cartella: str):
    """Percorre i file di una cartella (anche nelle sottocartelle), senza seguire i collegamenti."""
    for radice, cartelle, file in os.walk(cartella, followlinks=False):
        cartelle.sort()
        for nome in sorted(file):
            completo = os.path.join(radice, nome)
            if os.path.islink(completo):
                continue
            relativo = os.path.relpath(completo, cartella).replace(os.sep, "/")
            yield completo, relativo


def _iso(secondi: float) -> str:
    return datetime.fromtimestamp(secondi).isoformat(timespec="seconds")


# ===========================================================================
# Identificazione e integrità
# ===========================================================================

#: Catalogo dei "numeri magici": (offset, firma, tipo, descrizione, estensioni, categoria, eseguibile).
_CATALOGO: tuple[tuple[int, bytes, str, str, tuple[str, ...], str, bool], ...] = (
    # immagini
    (0, b"\x89PNG\r\n\x1a\n", "PNG", "immagine PNG", ("png",), "immagine", False),
    (0, b"\xff\xd8\xff", "JPEG", "foto JPEG", ("jpg", "jpeg", "jfif"), "immagine", False),
    (0, b"GIF87a", "GIF", "immagine GIF", ("gif",), "immagine", False),
    (0, b"GIF89a", "GIF", "immagine GIF animata", ("gif",), "immagine", False),
    (0, b"BM", "BMP", "immagine BMP", ("bmp", "dib"), "immagine", False),
    (0, b"II*\x00", "TIFF", "immagine TIFF (o RAW di fotocamera)", ("tif", "tiff", "dng", "nef", "cr2", "arw"),
     "immagine", False),
    (0, b"MM\x00*", "TIFF", "immagine TIFF (o RAW di fotocamera)", ("tif", "tiff", "dng", "nef"), "immagine", False),
    (0, b"\x00\x00\x01\x00", "ICO", "icona di Windows", ("ico",), "immagine", False),
    (0, b"\x00\x00\x02\x00", "CUR", "cursore di Windows", ("cur",), "immagine", False),
    (0, b"8BPS", "PSD", "immagine di Photoshop", ("psd",), "immagine", False),
    (0, b"\xff\x0a", "JXL", "immagine JPEG XL", ("jxl",), "immagine", False),
    (0, b"\x00\x00\x00\x0cJXL ", "JXL", "immagine JPEG XL", ("jxl",), "immagine", False),
    # documenti
    (0, b"%PDF-", "PDF", "documento PDF", ("pdf",), "documento", False),
    (0, b"{\\rtf", "RTF", "documento RTF", ("rtf",), "documento", False),
    (0, b"%!PS", "PS", "documento PostScript", ("ps", "eps"), "documento", False),
    (0, b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1", "OLE", "documento Office vecchio o installatore (doc, xls, msi)",
     ("doc", "xls", "ppt", "msi", "msg"), "documento", False),
    # archivi e compressi
    (0, b"PK\x03\x04", "ZIP", "archivio ZIP (anche documenti Office, OpenDocument, APK, JAR, EPUB)",
     ("zip", "docx", "xlsx", "pptx", "odt", "ods", "odp", "jar", "apk", "epub"), "archivio", False),
    (0, b"PK\x05\x06", "ZIP", "archivio ZIP vuoto", ("zip",), "archivio", False),
    (0, b"Rar!\x1a\x07\x00", "RAR", "archivio RAR (versione 4)", ("rar",), "archivio", False),
    (0, b"Rar!\x1a\x07\x01\x00", "RAR", "archivio RAR (versione 5)", ("rar",), "archivio", False),
    (0, b"7z\xbc\xaf\x27\x1c", "7Z", "archivio 7-Zip", ("7z",), "archivio", False),
    (0, b"\x1f\x8b", "GZIP", "file compresso gzip", ("gz", "tgz"), "archivio", False),
    (0, b"BZh", "BZIP2", "file compresso bzip2", ("bz2", "tbz2"), "archivio", False),
    (0, b"\xfd7zXZ\x00", "XZ", "file compresso xz", ("xz", "txz"), "archivio", False),
    (0, b"\x28\xb5\x2f\xfd", "ZSTD", "file compresso Zstandard", ("zst",), "archivio", False),
    (0, b"\x04\x22\x4d\x18", "LZ4", "file compresso LZ4", ("lz4",), "archivio", False),
    (0, b"MSCF", "CAB", "archivio CAB di Windows", ("cab",), "archivio", False),
    (0, b"!<arch>", "AR", "archivio ar (anche pacchetti .deb)", ("a", "deb"), "archivio", False),
    (257, b"ustar", "TAR", "archivio TAR", ("tar",), "archivio", False),
    (0, b"\x75\x73\x74\x61\x72", "TAR", "archivio TAR", ("tar",), "archivio", False),
    # eseguibili e codice
    (0, b"MZ", "EXE", "programma di Windows (exe o dll)", ("exe", "dll", "sys", "scr", "com", "cpl"),
     "eseguibile", True),
    (0, b"\x7fELF", "ELF", "programma di Linux o Android", ("so", "elf", "bin", "o"), "eseguibile", True),
    (0, b"\xcf\xfa\xed\xfe", "MACHO", "programma del Mac a 64 bit", ("dylib",), "eseguibile", True),
    (0, b"\xce\xfa\xed\xfe", "MACHO", "programma del Mac a 32 bit", (), "eseguibile", True),
    (0, b"\xca\xfe\xba\xbe", "MACHO", "programma del Mac universale (o classe Java)", ("class",),
     "eseguibile", True),
    (0, b"dex\n", "DEX", "codice di un'app Android", ("dex",), "eseguibile", True),
    (0, b"\x00asm", "WASM", "programma WebAssembly", ("wasm",), "eseguibile", True),
    (0, b"#!", "SCRIPT", "script da eseguire (shell, Python...)", ("sh", "py", "pl", "rb"), "eseguibile", True),
    # audio
    (0, b"ID3", "MP3", "audio MP3 (con tag ID3)", ("mp3",), "audio", False),
    (0, b"\xff\xfb", "MP3", "audio MP3", ("mp3",), "audio", False),
    (0, b"\xff\xf3", "MP3", "audio MP3", ("mp3",), "audio", False),
    (0, b"\xff\xf2", "MP3", "audio MP3", ("mp3",), "audio", False),
    (0, b"OggS", "OGG", "audio o video Ogg", ("ogg", "oga", "ogv", "opus"), "audio", False),
    (0, b"fLaC", "FLAC", "audio FLAC", ("flac",), "audio", False),
    (0, b"MThd", "MIDI", "musica MIDI", ("mid", "midi"), "audio", False),
    (0, b"#!AMR", "AMR", "audio AMR", ("amr",), "audio", False),
    # video
    (0, b"\x1aE\xdf\xa3", "MKV", "video Matroska o WebM", ("mkv", "webm", "mka"), "video", False),
    (0, b"FLV", "FLV", "video Flash", ("flv",), "video", False),
    (0, b"\x30\x26\xb2\x75", "ASF", "video o audio ASF/WMV/WMA di Windows", ("wmv", "wma", "asf"), "video", False),
    (0, b"\x00\x00\x01\xba", "MPEG", "video MPEG", ("mpg", "mpeg", "vob"), "video", False),
    (0, b"\x00\x00\x01\xb3", "MPEG", "video MPEG", ("mpg", "mpeg"), "video", False),
    # database
    (0, b"SQLite format 3\x00", "SQLITE", "database SQLite", ("db", "sqlite", "sqlite3"), "database", False),
    # caratteri (font)
    (0, b"\x00\x01\x00\x00", "TTF", "carattere TrueType", ("ttf",), "font", False),
    (0, b"OTTO", "OTF", "carattere OpenType", ("otf",), "font", False),
    (0, b"wOFF", "WOFF", "carattere per il web", ("woff",), "font", False),
    (0, b"wOF2", "WOFF2", "carattere per il web", ("woff2",), "font", False),
    # catture di rete (lettura, non invio)
    (0, b"\xd4\xc3\xb2\xa1", "PCAP", "cattura di rete pcap", ("pcap",), "cattura", False),
    (0, b"\xa1\xb2\xc3\xd4", "PCAP", "cattura di rete pcap", ("pcap",), "cattura", False),
    (0, b"\x0a\x0d\x0d\x0a", "PCAPNG", "cattura di rete pcapng", ("pcapng",), "cattura", False),
)
_RIFF = {b"WEBP": ("WEBP", "immagine WebP", ("webp",), "immagine"),
         b"WAVE": ("WAV", "audio WAV", ("wav",), "audio"),
         b"AVI ": ("AVI", "video AVI", ("avi",), "video")}
#: Marchi dentro i contenitori "ftyp" (MP4 e parenti).
_FTYP = {
    b"heic": ("HEIC", "foto HEIC", ("heic",), "immagine"), b"heif": ("HEIC", "foto HEIF", ("heif",), "immagine"),
    b"mif1": ("HEIC", "foto HEIF", ("heif",), "immagine"), b"avif": ("AVIF", "immagine AVIF", ("avif",), "immagine"),
    b"mp41": ("MP4", "video MP4", ("mp4",), "video"), b"mp42": ("MP4", "video MP4", ("mp4",), "video"),
    b"isom": ("MP4", "video MP4", ("mp4",), "video"), b"M4A ": ("M4A", "audio M4A", ("m4a",), "audio"),
    b"M4V ": ("MP4", "video M4V", ("m4v",), "video"), b"qt  ": ("MOV", "video QuickTime", ("mov",), "video"),
    b"3gp": ("3GP", "video 3GP", ("3gp",), "video"),
}
#: estensioni che un utente apre pensando che siano innocue.
_ESTENSIONI_INNOCUE = frozenset({"pdf", "jpg", "jpeg", "png", "gif", "txt", "doc", "docx", "xls", "xlsx", "mp3",
                                 "mp4", "zip", "csv", "odt", "bmp", "webp", "mov", "avi", "wav", "html", "rtf"})


def _identifica(testa: bytes) -> dict:
    """Riconosce il tipo dai primi byte. Restituisce tipo, descrizione, estensioni, categoria, eseguibile."""
    if testa[:4] == b"RIFF" and testa[8:12] in _RIFF:
        tipo, descrizione, estensioni, categoria = _RIFF[testa[8:12]]
        return _tipo(tipo, descrizione, estensioni, categoria, False)
    if testa[4:8] == b"ftyp":
        marchio = testa[8:12]
        voce = _FTYP.get(marchio) or _FTYP.get(marchio[:3] + b" ") or _FTYP.get(bytes(marchio[:3]))
        if voce is None and marchio[:3] == b"3gp":
            voce = _FTYP[b"3gp"]
        if voce is not None:
            return _tipo(voce[0], voce[1], voce[2], voce[3], False)
        return _tipo("MP4", "contenitore MP4/MOV", ("mp4", "mov", "m4a"), "video", False)
    for inizio, firma, tipo, descrizione, estensioni, categoria, eseguibile in _CATALOGO:
        if testa[inizio:inizio + len(firma)] == firma:
            return _tipo(tipo, descrizione, estensioni, categoria, eseguibile)
    if not testa:
        return _tipo("VUOTO", "file vuoto", (), "vuoto", False)
    if b"-----BEGIN" in testa[:64]:
        return _tipo("PEM", "chiave o certificato PEM (testo)", ("pem", "key", "crt"), "certificato", False)
    if b"\x00" not in testa:
        try:
            testo = testa.decode("utf-8")
        except UnicodeDecodeError as e:
            testo = testa[:e.start].decode("utf-8") if e.start >= len(testa) - 3 else None
        if testo is not None:
            inizio = testo.lstrip("﻿ \t\r\n")[:200].lower()
            if inizio.startswith(("<!doctype html", "<html")):
                return _tipo("HTML", "pagina web HTML", ("html", "htm"), "testo", False)
            if inizio.startswith("<?xml") or inizio.startswith("<svg"):
                return _tipo("XML", "documento XML o SVG", ("xml", "svg"), "testo", False)
            if inizio.startswith(("{", "[")):
                return _tipo("JSON", "dati JSON (probabile)", ("json",), "testo", False)
            return _tipo("TESTO", "file di testo", ("txt", "csv", "log", "md", "ini"), "testo", False)
    return _tipo("SCONOSCIUTO", "tipo non riconosciuto", (), "sconosciuto", False)


def _tipo(tipo: str, descrizione: str, estensioni: tuple, categoria: str, eseguibile: bool) -> dict:
    return {"tipo": tipo, "descrizione": descrizione, "estensioni": list(estensioni),
            "categoria": categoria, "eseguibile": eseguibile}


@funzione_libreria("tipo_dai_byte")
def tipo_dai_byte(dati):
    """tipo_dai_byte(dati): il vero tipo di dati in memoria (testo, lista di byte o `dati_binari`).

    Come `riconosci_tipo_file` ma su dati che hai già, senza file. Riconosce decine di formati dai
    "numeri magici". Restituisce un dizionario con "tipo", "descrizione", "estensioni", "categoria"
    (immagine, documento, archivio, eseguibile, audio, video...) ed "eseguibile" (vero o falso).
    Esempio: `tipo_dai_byte(dati_binari("89504E470D0A1A0A", "esadecimale"))["tipo"]` è "PNG".
    """
    testa = _in_byte(dati, "tipo_dai_byte")[:TESTA]
    return _identifica(testa)


@funzione_libreria("elenca_firme")
def elenca_firme():
    """elenca_firme(): l'elenco di tutti i formati che Leo riconosce dai "numeri magici".

    Restituisce una lista di dizionari con "tipo", "descrizione", "categoria", "estensioni" ed
    "eseguibile". Utile per sapere che cosa `tipo_dai_byte` e `riconosci_tipo_file` sanno distinguere.
    Esempio: `lunghezza(elenca_firme())` è il numero di formati conosciuti.
    """
    visti: dict[str, dict] = {}
    for _, _, tipo, descrizione, estensioni, categoria, eseguibile in _CATALOGO:
        if tipo not in visti:
            visti[tipo] = _tipo(tipo, descrizione, estensioni, categoria, eseguibile)
    for tipo, descrizione, estensioni, categoria in _RIFF.values():
        visti.setdefault(tipo, _tipo(tipo, descrizione, estensioni, categoria, False))
    for tipo, descrizione, estensioni, categoria in _FTYP.values():
        visti.setdefault(tipo, _tipo(tipo, descrizione, estensioni, categoria, False))
    return sorted(visti.values(), key=lambda v: (v["categoria"], v["tipo"]))


@funzione_libreria("estensione_coerente")
def estensione_coerente(percorso):
    """estensione_coerente(percorso): l'estensione del file corrisponde al suo vero contenuto?

    Restituisce un dizionario con "coerente" (vero, falso o nulla se non si sa), "estensione" (quella
    scritta nel nome), "tipo_vero", "estensioni_attese" e "avviso" (un testo di allerta o nulla).
    Un file "foto.jpg" che in realtà è un EXE è un classico travestimento di un programma dannoso.
    Esempio: `estensione_coerente("compiti.pdf")["coerente"]`.
    """
    from .binario import riconosci_tipo_file

    ris = riconosci_tipo_file(percorso)
    estensione = os.path.splitext(os.path.basename(percorso))[1].lower().lstrip(".")
    return {"coerente": ris["estensione_giusta"], "estensione": estensione, "tipo_vero": ris["tipo"],
            "estensioni_attese": ris["estensioni"], "avviso": ris["avviso"]}


@funzione_libreria("impronta_albero")
def impronta_albero(cartella):
    """impronta_albero(cartella): una "fotografia" di una cartella: ogni file con impronta, dimensione e data.

    Restituisce un dizionario percorso -> {"impronta" (SHA-256), "dimensione", "modifica"}. Salvalo con
    `scrivi_json` e più avanti usalo con `confronta_alberi` per accorgerti di modifiche non volute.
    A differenza di `impronta_cartella`, tiene anche dimensione e data di ogni file.
    Esempio: `scrivi_json("stato.json", impronta_albero("documenti"))`.
    """
    import hashlib

    _cartella(cartella, "impronta_albero")
    risultato: dict[str, dict] = {}
    for completo, relativo in _ogni_file(cartella):
        calcolo = hashlib.sha256()
        try:
            dimensione = os.path.getsize(completo)
            modifica = os.path.getmtime(completo)
            with open(completo, "rb") as f:
                while True:
                    pezzo = f.read(1024 * 1024)
                    if not pezzo:
                        break
                    calcolo.update(pezzo)
        except OSError as e:
            raise _errore_file(e, completo, "leggere") from None
        risultato[relativo] = {"impronta": calcolo.hexdigest(), "dimensione": dimensione,
                               "modifica": _iso(modifica)}
    return risultato


def _albero(valore: Any, parametro: str, nome_funzione: str) -> dict:
    if isinstance(valore, str):
        return impronta_albero(valore)
    if not isinstance(valore, dict):
        raise ErroreTipo(f"L'argomento `{parametro}` di `{nome_funzione}` deve essere un risultato di "
                         f"`impronta_albero` o il nome di una cartella, non {articolo(valore)}.")
    pulito: dict[str, dict] = {}
    for k, v in valore.items():
        if not isinstance(k, str):
            raise ErroreValore(f"`{parametro}` non sembra un risultato di `impronta_albero`.")
        if isinstance(v, dict):
            pulito[k] = v
        elif isinstance(v, str):                 # anche un impronta_cartella (percorso -> impronta)
            pulito[k] = {"impronta": v, "dimensione": None, "modifica": None}
        else:
            raise ErroreValore(f"`{parametro}` non sembra un risultato di `impronta_albero`: la voce "
                               f"{mostra(k)} non va bene.")
    return pulito


@funzione_libreria("confronta_alberi")
def confronta_alberi(prima, dopo):
    """confronta_alberi(prima, dopo): che cosa è cambiato tra due "fotografie" di una cartella (con dettagli).

    `prima` e `dopo` sono risultati di `impronta_albero` (o `dopo` è direttamente il nome della cartella).
    Restituisce "aggiunti", "tolti" e "cambiati" (ognuno con prima/dopo di dimensione, data e impronta),
    il numero "uguali" e "intatta". Serve per accorgersi di modifiche non volute.
    Esempio: `confronta_alberi(leggi_json("stato.json"), "documenti")["cambiati"]`.
    """
    a = _albero(prima, "prima", "confronta_alberi")
    b = _albero(dopo, "dopo", "confronta_alberi")
    aggiunti, tolti, cambiati, uguali = [], [], [], 0
    for k in sorted(b):
        if k not in a:
            aggiunti.append({"percorso": k, **b[k]})
    for k in sorted(a):
        if k not in b:
            tolti.append({"percorso": k, **a[k]})
    for k in sorted(a):
        if k not in b:
            continue
        va, vb = a[k], b[k]
        if (va.get("impronta") or "").lower() == (vb.get("impronta") or "").lower():
            uguali += 1
            continue
        cambi = []
        if va.get("dimensione") is not None and vb.get("dimensione") is not None \
                and va["dimensione"] != vb["dimensione"]:
            cambi.append("dimensione")
        if va.get("modifica") and vb.get("modifica") and va["modifica"] != vb["modifica"]:
            cambi.append("data")
        cambi.append("contenuto")
        cambiati.append({"percorso": k, "cambi": cambi, "prima": va, "dopo": vb})
    return {"aggiunti": aggiunti, "tolti": tolti, "cambiati": cambiati, "uguali": uguali,
            "intatta": not (aggiunti or tolti or cambiati)}


@funzione_libreria("verifica_integrita")
def verifica_integrita(cartella, impronte_note):
    """verifica_integrita(cartella, impronte_note): controlla una cartella rispetto a un elenco di impronte noto.

    `impronte_note` è un risultato di `impronta_albero` o di `impronta_cartella` (percorso -> impronta).
    Restituisce "integra" (vero/falso), "intatti" (quanti combaciano), "modificati", "mancanti"
    (nell'elenco ma non più sul disco) ed "estranei" (sul disco ma non nell'elenco).
    Esempio: `verifica_integrita("sito", leggi_json("impronte_ufficiali.json"))["integra"]`.
    """
    import hmac

    _cartella(cartella, "verifica_integrita")
    noti = _albero(impronte_note, "impronte_note", "verifica_integrita")
    attuale = impronta_albero(cartella)
    intatti, modificati, mancanti, estranei = 0, [], [], []
    for percorso, voce in noti.items():
        atteso = (voce.get("impronta") or "").lower()
        if percorso not in attuale:
            mancanti.append(percorso)
        elif atteso and hmac.compare_digest(atteso, attuale[percorso]["impronta"]):
            intatti += 1
        else:
            modificati.append(percorso)
    for percorso in attuale:
        if percorso not in noti:
            estranei.append(percorso)
    return {"integra": not (modificati or mancanti or estranei), "intatti": intatti,
            "modificati": sorted(modificati), "mancanti": sorted(mancanti), "estranei": sorted(estranei)}


# ===========================================================================
# Riconoscimento di schemi (stile YARA, in italiano)
# ===========================================================================

def _offset(offset: Any, nome_funzione: str) -> int | None:
    if offset is None:
        return None
    richiedi_intero(offset, nome_funzione, "offset")
    if offset < 0:
        raise ErroreValore(f"L'offset di `{nome_funzione}` non può essere negativo.")
    return offset


@funzione_libreria("condizione_testo")
def condizione_testo(testo, offset=None, ignora_maiuscole=False):
    """condizione_testo(testo, offset = nulla, ignora_maiuscole = falso): cerca un testo dentro un file.

    Un pezzetto di una regola per `regola_schema`. Se dai `offset`, il testo deve stare esattamente lì;
    con `ignora_maiuscole = vero` "ERRORE" trova anche "errore". Esempio:
    `condizione_testo("-----BEGIN", offset = 0)`.
    """
    richiedi_testo(testo, "condizione_testo", "testo")
    richiedi_logico(ignora_maiuscole, "condizione_testo", "ignora_maiuscole")
    return {"tipo": "testo", "valore": testo, "offset": _offset(offset, "condizione_testo"),
            "ignora_maiuscole": ignora_maiuscole}


@funzione_libreria("condizione_byte")
def condizione_byte(byte, offset=None):
    """condizione_byte(byte, offset = nulla): cerca una sequenza di byte (numeri magici) dentro un file.

    `byte` è un testo esadecimale ("4D5A"), una lista di numeri 0-255 o dei `dati_binari`. Un pezzetto
    di regola per `regola_schema`; con `offset = 0` la firma deve stare all'inizio. Esempio:
    `condizione_byte("4D5A", offset = 0)` (l'inizio di un programma di Windows).
    """
    if isinstance(byte, str):
        from .binario import dati_binari

        sequenza = dati_binari(byte, "esadecimale").valore
    else:
        sequenza = _in_byte(byte, "condizione_byte", "byte")
    if not sequenza:
        raise ErroreValore("`condizione_byte` ha bisogno di almeno un byte.")
    return {"tipo": "byte", "valore_hex": sequenza.hex(), "offset": _offset(offset, "condizione_byte")}


@funzione_libreria("condizione_regex")
def condizione_regex(espressione, ignora_maiuscole=False):
    """condizione_regex(espressione, ignora_maiuscole = falso): cerca un'espressione regolare dentro un file.

    Un pezzetto di regola per `regola_schema`, per schemi flessibili (per esempio un indirizzo email).
    Esempio: `condizione_regex("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\\\.[A-Za-z]\\{2,\\}")`.
    """
    richiedi_testo(espressione, "condizione_regex", "espressione")
    richiedi_logico(ignora_maiuscole, "condizione_regex", "ignora_maiuscole")
    try:
        re.compile(espressione)
    except re.error as e:
        raise ErroreValore(f"L'espressione regolare di `condizione_regex` non è valida: {e}.",
                           suggerimento="Controlla le parentesi e le barre. Le barre si scrivono doppie.") from None
    return {"tipo": "regex", "valore": espressione, "ignora_maiuscole": ignora_maiuscole}


def _condizione(valore: Any, nome_funzione: str) -> dict:
    if not isinstance(valore, dict) or valore.get("tipo") not in ("testo", "byte", "regex"):
        raise ErroreTipo(f"`{nome_funzione}` vuole condizioni fatte con `condizione_testo`, `condizione_byte` "
                         f"o `condizione_regex`, non {articolo(valore)}.")
    return valore


@funzione_libreria("regola_schema")
def regola_schema(nome, condizioni, operatore="o", descrizione=""):
    """regola_schema(nome, condizioni, operatore = "o", descrizione = ""): costruisce una regola in stile YARA.

    `condizioni` è una condizione (`condizione_testo`/`condizione_byte`/`condizione_regex`) o una lista.
    `operatore` è "o" (basta una condizione) oppure "e" (devono esserci tutte). Usa la regola con
    `cerca_schema`, `cerca_schema_cartella` o `applica_regole`. Esempio:
    `regola_schema("chiave privata", condizione_testo("PRIVATE KEY"))`.
    """
    richiedi_testo(nome, "regola_schema", "nome")
    richiedi_testo(descrizione, "regola_schema", "descrizione")
    op = str(operatore).strip().lower()
    if op in ("and", "tutte", "tutti"):
        op = "e"
    if op in ("or", "almeno_una", "una"):
        op = "o"
    if op not in ("e", "o"):
        raise ErroreValore(f"L'operatore di `regola_schema` deve essere \"e\" oppure \"o\", non {mostra(operatore)}.")
    elenco = condizioni if isinstance(condizioni, list) else [condizioni]
    if not elenco:
        raise ErroreValore("`regola_schema` ha bisogno di almeno una condizione.")
    return {"nome": nome, "descrizione": descrizione, "operatore": op,
            "condizioni": [_condizione(c, "regola_schema") for c in elenco]}


def _regola(valore: Any, nome_funzione: str) -> dict:
    if isinstance(valore, dict) and valore.get("tipo") in ("testo", "byte", "regex"):
        return {"nome": "schema", "descrizione": "", "operatore": "o", "condizioni": [valore]}
    if isinstance(valore, str):
        return {"nome": "testo", "descrizione": "", "operatore": "o",
                "condizioni": [{"tipo": "testo", "valore": valore, "offset": None, "ignora_maiuscole": False}]}
    if not isinstance(valore, dict) or "condizioni" not in valore:
        raise ErroreTipo(f"`{nome_funzione}` vuole una regola fatta con `regola_schema` (o un testo/condizione), "
                         f"non {articolo(valore)}.")
    return valore


@funzione_libreria("descrivi_regola")
def descrivi_regola(regola):
    """descrivi_regola(regola): spiega a parole una regola fatta con `regola_schema`.

    Restituisce un testo leggibile, utile per controllare una regola prima di usarla.
    Esempio: `stampa(descrivi_regola(regola_schema("eseguibile", condizione_byte("4D5A", offset = 0))))`.
    """
    r = _regola(regola, "descrivi_regola")
    pezzi = []
    for c in r["condizioni"]:
        if c["tipo"] == "testo":
            dove = f" all'offset {c['offset']}" if c.get("offset") is not None else ""
            come = " (senza distinguere maiuscole)" if c.get("ignora_maiuscole") else ""
            pezzi.append(f"contiene il testo {mostra(c['valore'])}{dove}{come}")
        elif c["tipo"] == "byte":
            dove = f" all'offset {c['offset']}" if c.get("offset") is not None else ""
            pezzi.append(f"contiene i byte {c['valore_hex'].upper()}{dove}")
        else:
            pezzi.append(f"corrisponde all'espressione {mostra(c['valore'])}")
    legame = " E " if r["operatore"] == "e" else " OPPURE "
    testa = f"Regola «{r['nome']}»"
    if r.get("descrizione"):
        testa += f" ({r['descrizione']})"
    return testa + ": un file va bene se " + legame.join(pezzi) + "."


def _valuta_condizione(cond: dict, dati: bytes, testo: str) -> list[dict]:
    riscontri = []
    if cond["tipo"] == "byte":
        sequenza = bytes.fromhex(cond["valore_hex"])
        if cond.get("offset") is not None:
            o = cond["offset"]
            if dati[o:o + len(sequenza)] == sequenza:
                riscontri.append({"offset": o, "anteprima": sequenza.hex().upper()})
        else:
            inizio = dati.find(sequenza)
            while inizio != -1:
                riscontri.append({"offset": inizio, "anteprima": sequenza.hex().upper()})
                if len(riscontri) >= 50:
                    break
                inizio = dati.find(sequenza, inizio + 1)
    elif cond["tipo"] == "testo":
        ago = cond["valore"]
        pagliaio = testo
        if cond.get("ignora_maiuscole"):
            ago, pagliaio = ago.lower(), testo.lower()
        if cond.get("offset") is not None:
            o = cond["offset"]
            if pagliaio[o:o + len(ago)] == ago:
                riscontri.append({"offset": o, "anteprima": cond["valore"]})
        else:
            inizio = pagliaio.find(ago)
            while inizio != -1:
                riscontri.append({"offset": inizio, "anteprima": testo[inizio:inizio + len(ago)]})
                if len(riscontri) >= 50:
                    break
                inizio = pagliaio.find(ago, inizio + 1)
    else:
        bandiere = re.IGNORECASE if cond.get("ignora_maiuscole") else 0
        for m in re.finditer(cond["valore"], testo, bandiere):
            riscontri.append({"offset": m.start(), "anteprima": m.group(0)[:80]})
            if len(riscontri) >= 50:
                break
    return riscontri


def _applica(regola: dict, dati: bytes) -> dict:
    testo = dati.decode("latin-1")
    per_condizione = []
    tutte = True
    almeno_una = False
    for i, cond in enumerate(regola["condizioni"]):
        riscontri = _valuta_condizione(cond, dati, testo)
        if riscontri:
            almeno_una = True
            for r in riscontri:
                per_condizione.append({"condizione": i, "tipo": cond["tipo"], **r})
        else:
            tutte = False
    trovata = tutte if regola["operatore"] == "e" else almeno_una
    return {"nome": regola.get("nome", "schema"), "trovata": trovata, "operatore": regola["operatore"],
            "riscontri": per_condizione}


@funzione_libreria("cerca_schema")
def cerca_schema(regola, dati):
    """cerca_schema(regola, dati): cerca una regola (`regola_schema`) dentro dati in memoria.

    `dati` è un testo, una lista di byte o dei `dati_binari`. `regola` può essere anche solo un testo o
    una condizione. Restituisce "trovata" (vero/falso) e "riscontri" (dove e che cosa ha trovato).
    Esempio: `cerca_schema("password", "config: password = 1234")["trovata"]` è vero.
    """
    r = _regola(regola, "cerca_schema")
    return _applica(r, _in_byte(dati, "cerca_schema"))


@funzione_libreria("cerca_schema_cartella")
def cerca_schema_cartella(regola, cartella):
    """cerca_schema_cartella(regola, cartella): cerca una regola in tutti i file di una cartella.

    Restituisce una lista con, per ogni file in cui la regola è stata trovata, "percorso" e "riscontri".
    Esempio: `cerca_schema_cartella(condizione_testo("TODO"), "progetto")`.
    """
    r = _regola(regola, "cerca_schema_cartella")
    _cartella(cartella, "cerca_schema_cartella")
    trovati = []
    for completo, relativo in _ogni_file(cartella):
        try:
            with open(completo, "rb") as f:
                dati = f.read(MASSIMO_FILE)
        except OSError:
            continue
        esito = _applica(r, dati)
        if esito["trovata"]:
            trovati.append({"percorso": relativo, "riscontri": esito["riscontri"]})
    return trovati


def _regole(valore: Any, nome_funzione: str) -> list[dict]:
    elenco = valore if isinstance(valore, list) else [valore]
    return [_regola(r, nome_funzione) for r in elenco]


@funzione_libreria("applica_regole")
def applica_regole(regole, percorso):
    """applica_regole(regole, percorso): prova un insieme di regole su un file e dice quali scattano.

    `regole` è una regola o una lista di regole (`regola_schema`, o `regole_pronte()`). Restituisce la
    lista delle regole trovate, ognuna con "nome" e "riscontri". Esempio:
    `applica_regole(regole_pronte(), "sorgente.py")`.
    """
    insieme = _regole(regole, "applica_regole")
    dati = _leggi(percorso, "applica_regole")
    trovate = []
    for r in insieme:
        esito = _applica(r, dati)
        if esito["trovata"]:
            trovate.append(esito)
    return trovate


@funzione_libreria("applica_regole_cartella")
def applica_regole_cartella(regole, cartella):
    """applica_regole_cartella(regole, cartella): prova un insieme di regole su tutti i file di una cartella.

    Restituisce una lista con, per ogni file che fa scattare almeno una regola, "percorso" e "regole"
    (i nomi delle regole trovate). Esempio: `applica_regole_cartella(regole_pronte(), "progetto")`.
    """
    insieme = _regole(regole, "applica_regole_cartella")
    _cartella(cartella, "applica_regole_cartella")
    trovati = []
    for completo, relativo in _ogni_file(cartella):
        try:
            with open(completo, "rb") as f:
                dati = f.read(MASSIMO_FILE)
        except OSError:
            continue
        nomi = [r.get("nome", "schema") for r in insieme if _applica(r, dati)["trovata"]]
        if nomi:
            trovati.append({"percorso": relativo, "regole": nomi})
    return trovati


#: Regole già fatte per schemi NOTI e LEGITTIMI (scopo difensivo: trovare e proteggere).
_REGOLE_SEGRETI = (
    ("chiave privata in chiaro", "una chiave privata (RSA/EC/OpenSSH/PGP) lasciata nel testo",
     r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY-----"),
    ("token AWS", "una chiave di accesso AWS (AKIA...)", r"\bAKIA[0-9A-Z]{16}\b"),
    ("token GitHub", "un token personale di GitHub (ghp_...)", r"\bghp_[0-9A-Za-z]{36}\b"),
    ("token Slack", "un token di Slack (xox...)", r"\bxox[baprs]-[0-9A-Za-z-]{10,}"),
    ("segreto generico", "un segreto scritto nel codice (api_key, password, token = ...)",
     r"(?i)(?:api[_-]?key|secret|token|password|passwd|pwd)\s*[:=]\s*[\"']?[A-Za-z0-9/+_.\-]{8,}"),
    ("JWT", "un token JWT (eyJ...)", r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}"),
)


@funzione_libreria("regole_pronte")
def regole_pronte():
    """regole_pronte(): un insieme di regole già fatte per schemi noti e legittimi, a scopo difensivo.

    Trova (per PROTEGGERE, non per attaccare): eseguibili, archivi, chiavi private lasciate in chiaro,
    token/segreti dimenticati nel codice, indirizzi email, IP e numeri di carta in un testo. Dalle a
    `applica_regole` o `applica_regole_cartella`. Esempio: `applica_regole(regole_pronte(), "config.txt")`.
    """
    regole = [
        regola_schema("eseguibile", [condizione_byte("4D5A", 0), condizione_byte("7F454C46", 0),
                                     condizione_byte("CFFAEDFE", 0), condizione_byte("FEEDFACF", 0)],
                      "o", "un programma (Windows, Linux, Mac)"),
        regola_schema("archivio", [condizione_byte("504B0304", 0), condizione_byte("526172211A07", 0),
                                   condizione_byte("377ABCAF271C", 0), condizione_byte("1F8B", 0)],
                      "o", "un archivio o un file compresso"),
        regola_schema("indirizzo email", condizione_regex(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"),
                      "o", "un indirizzo email (protezione dei dati personali)"),
        regola_schema("indirizzo IP", condizione_regex(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"),
                      "o", "un indirizzo IP"),
        regola_schema("numero di carta", condizione_regex(r"\b(?:\d[ -]?){13,19}\b"),
                      "o", "una possibile carta di credito (controlla con `estrai_carte`)"),
    ]
    for nome, descrizione, espressione in _REGOLE_SEGRETI:
        regole.append(regola_schema(nome, condizione_regex(espressione), "o", descrizione))
    return regole


# ===========================================================================
# Metadati (oltre all'EXIF, che è in `binario`)
# ===========================================================================

def _data_pdf(valore: str) -> str:
    """D:20230115120000+01'00' -> ISO."""
    m = re.match(r"D?:?(\d{4})(\d{2})?(\d{2})?(\d{2})?(\d{2})?(\d{2})?", valore)
    if not m:
        return valore
    anno, mese, giorno, ora, minuto, sec = (int(x) if x else d for x, d in
                                            zip(m.groups(), (0, 1, 1, 0, 0, 0)))
    try:
        return datetime(anno, mese, giorno, ora, minuto, sec).isoformat(timespec="seconds")
    except ValueError:
        return valore


@funzione_libreria("metadati_pdf")
def metadati_pdf(percorso):
    """metadati_pdf(percorso): i metadati di un documento PDF (autore, titolo, programma, date).

    Restituisce un dizionario con "titolo", "autore", "oggetto", "parole_chiave", "creatore",
    "programma" (il software che l'ha prodotto), "creato", "modificato" e "pagine" (circa). Utile per
    sapere chi e con che cosa ha fatto un PDF. Esempio: `metadati_pdf("relazione.pdf")["programma"]`.
    """
    dati = _leggi(percorso, "metadati_pdf")
    if not dati.startswith(b"%PDF-"):
        raise ErroreValore(f"`{percorso}` non è un PDF.",
                           suggerimento="Controlla il tipo con `riconosci_tipo_file(percorso)`.")
    testo = dati.decode("latin-1")
    chiavi = {"Title": "titolo", "Author": "autore", "Subject": "oggetto", "Keywords": "parole_chiave",
              "Creator": "creatore", "Producer": "programma", "CreationDate": "creato", "ModDate": "modificato"}
    ris: dict[str, Any] = {v: None for v in chiavi.values()}
    for chiave, nome in chiavi.items():
        m = re.search(r"/" + chiave + r"\s*\((.*?)(?<!\\)\)", testo, re.DOTALL)
        if not m:
            m = re.search(r"/" + chiave + r"\s*<([0-9A-Fa-f]+)>", testo)
            valore = bytes.fromhex(m.group(1)).decode("utf-16-be", "replace") if m else None
        else:
            valore = m.group(1).replace("\\(", "(").replace("\\)", ")").replace("\\\\", "\\")
        if valore is not None:
            ris[nome] = _data_pdf(valore) if nome in ("creato", "modificato") else valore
    m = re.search(r"/Count\s+(\d+)", testo)
    ris["pagine"] = int(m.group(1)) if m else testo.count("/Type /Page") or testo.count("/Type/Page") or None
    ris["versione"] = dati[5:8].decode("latin-1").strip()
    return ris


@funzione_libreria("metadati_zip")
def metadati_zip(percorso):
    """metadati_zip(percorso): che cosa c'è dentro un archivio ZIP (anche docx, xlsx, apk, epub...).

    Restituisce "numero" (quanti file), "commento", "compresso" e "disteso" (byte totali) e "voci":
    per ogni file nome, dimensione, compressa, data e se è cifrato. Non estrae niente.
    Esempio: `metadati_zip("documento.docx")["numero"]`.
    """
    _controlla_percorso(percorso, "metadati_zip")
    try:
        with zipfile.ZipFile(percorso) as z:
            voci = []
            compresso = disteso = 0
            for info in z.infolist():
                compresso += info.compress_size
                disteso += info.file_size
                voci.append({"nome": info.filename, "dimensione": info.file_size,
                             "compressa": info.compress_size,
                             "data": "%04d-%02d-%02dT%02d:%02d:%02d" % info.date_time,
                             "cifrato": bool(info.flag_bits & 0x1)})
            commento = z.comment.decode("utf-8", "replace")
    except zipfile.BadZipFile:
        raise ErroreValore(f"`{percorso}` non è un archivio ZIP valido.",
                           suggerimento="Controlla il tipo con `riconosci_tipo_file(percorso)`.") from None
    except OSError as e:
        raise _errore_file(e, percorso, "leggere") from None
    return {"numero": len(voci), "commento": commento, "compresso": compresso, "disteso": disteso, "voci": voci}


_NS = re.compile(r"\{[^}]*\}")


def _xml_valori(xml: bytes) -> dict:
    """Legge le coppie tag -> testo di un piccolo XML di metadati (senza librerie esterne pesanti)."""
    import xml.etree.ElementTree as ET

    ris: dict[str, str] = {}
    try:
        radice = ET.fromstring(xml)
    except ET.ParseError:
        return ris
    for elemento in radice.iter():
        tag = _NS.sub("", elemento.tag)
        if elemento.text and elemento.text.strip():
            ris[tag] = elemento.text.strip()
    return ris


@funzione_libreria("metadati_office")
def metadati_office(percorso):
    """metadati_office(percorso): i metadati di un documento Office o OpenDocument (autore, date, programma).

    Vale per docx, xlsx, pptx (dentro docProps) e odt, ods, odp (dentro meta.xml). Restituisce "autore",
    "ultimo_autore", "titolo", "oggetto", "creato", "modificato", "programma" e "azienda" (quelli che ci sono).
    Esempio: `metadati_office("lettera.docx")["autore"]`.
    """
    _controlla_percorso(percorso, "metadati_office")
    ris: dict[str, Any] = {v: None for v in ("autore", "ultimo_autore", "titolo", "oggetto",
                                             "creato", "modificato", "programma", "azienda")}
    try:
        with zipfile.ZipFile(percorso) as z:
            nomi = set(z.namelist())
            core = {}
            if "docProps/core.xml" in nomi:
                core = _xml_valori(z.read("docProps/core.xml"))
                app = _xml_valori(z.read("docProps/app.xml")) if "docProps/app.xml" in nomi else {}
                ris.update({"autore": core.get("creator"), "ultimo_autore": core.get("lastModifiedBy"),
                            "titolo": core.get("title"), "oggetto": core.get("subject"),
                            "creato": core.get("created"), "modificato": core.get("modified"),
                            "programma": app.get("Application"), "azienda": app.get("Company")})
            elif "meta.xml" in nomi:
                meta = _xml_valori(z.read("meta.xml"))
                ris.update({"autore": meta.get("initial-creator"), "ultimo_autore": meta.get("creator"),
                            "titolo": meta.get("title"), "oggetto": meta.get("subject"),
                            "creato": meta.get("creation-date"), "modificato": meta.get("date"),
                            "programma": meta.get("generator")})
            elif not any(n.startswith(("word/", "xl/", "ppt/", "content.xml", "[Content_Types]")) for n in nomi):
                raise ErroreValore(f"`{percorso}` non sembra un documento Office o OpenDocument.",
                                   suggerimento="Funziona con docx, xlsx, pptx, odt, ods, odp.")
            # un documento valido senza proprietà (per esempio dopo `togli_metadati`): tutto nulla
    except zipfile.BadZipFile:
        raise ErroreValore(f"`{percorso}` non è un documento Office valido (non è uno ZIP).",
                           suggerimento="Controlla il tipo con `riconosci_tipo_file(percorso)`.") from None
    except OSError as e:
        raise _errore_file(e, percorso, "leggere") from None
    return ris


def _id3v2(dati: bytes) -> dict:
    """Legge i tag ID3v2 di un MP3 (titolo, artista, album, anno)."""
    campi: dict[str, str] = {}
    if dati[:3] != b"ID3" or len(dati) < 10:
        return campi
    dimensione = ((dati[6] & 0x7f) << 21) | ((dati[7] & 0x7f) << 14) | ((dati[8] & 0x7f) << 7) | (dati[9] & 0x7f)
    corpo = dati[10:10 + dimensione]
    i = 0
    nomi = {"TIT2": "titolo", "TPE1": "artista", "TALB": "album", "TYER": "anno", "TDRC": "anno",
            "TCON": "genere", "COMM": "commento"}
    while i + 10 <= len(corpo):
        frame = corpo[i:i + 4].decode("latin-1")
        lung = struct.unpack(">I", corpo[i + 4:i + 8])[0]
        if not frame.strip("\x00") or lung <= 0 or i + 10 + lung > len(corpo):
            break
        valore = corpo[i + 10:i + 10 + lung]
        if frame in nomi and valore:
            codifica = valore[0]
            testo = valore[1:]
            try:
                if codifica == 1:
                    deco = testo.decode("utf-16", "replace")
                elif codifica == 3:
                    deco = testo.decode("utf-8", "replace")
                else:
                    deco = testo.decode("latin-1", "replace")
            except Exception:  # noqa: BLE001
                deco = testo.decode("latin-1", "replace")
            campi[nomi[frame]] = deco.strip("\x00").strip()
        i += 10 + lung
    return campi


def _flac_commenti(dati: bytes) -> dict:
    campi: dict[str, str] = {}
    if dati[:4] != b"fLaC":
        return campi
    i = 4
    while i + 4 <= len(dati):
        intestazione = dati[i]
        ultimo = intestazione & 0x80
        tipo = intestazione & 0x7f
        lung = int.from_bytes(dati[i + 1:i + 4], "big")
        blocco = dati[i + 4:i + 4 + lung]
        if tipo == 4 and len(blocco) >= 4:          # VORBIS_COMMENT
            p = 0
            nl = int.from_bytes(blocco[p:p + 4], "little"); p += 4 + nl
            if p + 4 <= len(blocco):
                conteggio = int.from_bytes(blocco[p:p + 4], "little"); p += 4
                for _ in range(conteggio):
                    if p + 4 > len(blocco):
                        break
                    vl = int.from_bytes(blocco[p:p + 4], "little"); p += 4
                    coppia = blocco[p:p + vl].decode("utf-8", "replace"); p += vl
                    if "=" in coppia:
                        chiave, valore = coppia.split("=", 1)
                        campi[chiave.lower()] = valore
        i += 4 + lung
        if ultimo:
            break
    return campi


@funzione_libreria("metadati_audio")
def metadati_audio(percorso):
    """metadati_audio(percorso): i metadati di un file audio (MP3 con ID3, FLAC, WAV).

    Restituisce "formato" e, quando ci sono, "titolo", "artista", "album", "anno" e un dizionario "campi"
    con tutto il resto. Per il WAV dà anche la "durata" in secondi. Esempio:
    `metadati_audio("canzone.mp3")["artista"]`.
    """
    dati = _leggi(percorso, "metadati_audio", 128 * 1024 * 1024)
    ris: dict[str, Any] = {"formato": None, "titolo": None, "artista": None, "album": None,
                           "anno": None, "durata": None, "campi": {}}
    if dati[:3] == b"ID3" or dati[:2] in (b"\xff\xfb", b"\xff\xf3", b"\xff\xf2"):
        ris["formato"] = "MP3"
        campi = _id3v2(dati)
        ris["campi"] = campi
        ris.update({k: campi.get(k) for k in ("titolo", "artista", "album", "anno")})
    elif dati[:4] == b"fLaC":
        ris["formato"] = "FLAC"
        campi = _flac_commenti(dati)
        ris["campi"] = campi
        ris.update({"titolo": campi.get("title"), "artista": campi.get("artist"),
                    "album": campi.get("album"), "anno": campi.get("date")})
    elif dati[:4] == b"RIFF" and dati[8:12] == b"WAVE":
        ris["formato"] = "WAV"
        campi = {}
        i = 12
        canali = frequenza = bit = blocco_dati = 0
        while i + 8 <= len(dati):
            pezzo = dati[i:i + 4]
            lung = struct.unpack("<I", dati[i + 4:i + 8])[0]
            corpo = dati[i + 8:i + 8 + lung]
            if pezzo == b"fmt " and len(corpo) >= 16:
                canali, frequenza = struct.unpack("<HI", corpo[2:8])
                bit = struct.unpack("<H", corpo[14:16])[0]
            elif pezzo == b"data":
                blocco_dati = lung
            elif pezzo == b"LIST" and corpo[:4] == b"INFO":
                campi = _riff_info(corpo[4:])
            i += 8 + lung + (lung & 1)
        if frequenza and canali and bit:
            ris["durata"] = round(blocco_dati / (frequenza * canali * (bit // 8)), 3)
        ris["campi"] = campi
        ris.update({"titolo": campi.get("INAM"), "artista": campi.get("IART"), "album": campi.get("IPRD")})
    else:
        raise ErroreValore(f"`{percorso}` non è un audio MP3, FLAC o WAV.",
                           suggerimento="Controlla il tipo con `riconosci_tipo_file(percorso)`.")
    return ris


def _riff_info(dati: bytes) -> dict:
    campi: dict[str, str] = {}
    i = 0
    while i + 8 <= len(dati):
        pezzo = dati[i:i + 4].decode("latin-1")
        lung = struct.unpack("<I", dati[i + 4:i + 8])[0]
        valore = dati[i + 8:i + 8 + lung].split(b"\x00", 1)[0].decode("utf-8", "replace")
        campi[pezzo] = valore
        i += 8 + lung + (lung & 1)
    return campi


@funzione_libreria("togli_metadati")
def togli_metadati(percorso, destinazione=None):
    """togli_metadati(percorso, destinazione = nulla): toglie i metadati da un file (privacy).

    Per le foto (JPEG, PNG, WebP) usa `togli_exif`; per i documenti Office/OpenDocument e gli archivi ZIP
    toglie le proprietà (autore, date, programma). Se non dai `destinazione` aggiunge "_pulito" al nome.
    Restituisce un dizionario con "destinazione" e "tolti". Esempio: `togli_metadati("lettera.docx")`.
    """
    from .binario import togli_exif

    _controlla_percorso(percorso, "togli_metadati")
    if destinazione is None:
        radice, est = os.path.splitext(percorso)
        destinazione = f"{radice}_pulito{est}"
    _controlla_percorso(destinazione, "togli_metadati")
    testa = _leggi(percorso, "togli_metadati", TESTA)
    tipo = _identifica(testa)["tipo"]
    if tipo in ("JPEG", "PNG", "WEBP"):
        togli_exif(percorso, destinazione)
        return {"destinazione": destinazione, "tolti": ["EXIF", "GPS", "commenti"]}
    if tipo == "ZIP":
        return _togli_zip(percorso, destinazione)
    raise ErroreValore(f"`togli_metadati` non sa pulire un file di tipo {tipo}.",
                       suggerimento="Funziona con foto (JPEG, PNG, WebP) e documenti Office/OpenDocument e ZIP.")


def _togli_zip(percorso: str, destinazione: str) -> dict:
    if os.path.exists(destinazione):
        raise ErroreFile(f"Il file `{destinazione}` esiste già.", suggerimento="Scegli un altro nome.")
    da_togliere = tuple("docProps/") + ("meta.xml",)
    tolti = []
    try:
        with zipfile.ZipFile(percorso) as sorgente, \
                zipfile.ZipFile(destinazione, "w", zipfile.ZIP_DEFLATED) as uscita:
            for info in sorgente.infolist():
                if info.filename.startswith("docProps/") or info.filename == "meta.xml":
                    tolti.append(info.filename)
                    continue
                uscita.writestr(info, sorgente.read(info.filename))
    except zipfile.BadZipFile:
        raise ErroreValore(f"`{percorso}` non è uno ZIP valido.") from None
    except OSError as e:
        raise _errore_file(e, destinazione, "scrivere") from None
    return {"destinazione": destinazione, "tolti": tolti or ["(niente da togliere)"]}


@funzione_libreria("date_file")
def date_file(percorso):
    """date_file(percorso): le date di un file (modifica, accesso, creazione dove il sistema la dà) e la dimensione.

    Restituisce un dizionario con "modifica", "accesso", "creazione" (o nulla) in formato ISO e "dimensione".
    Le date aiutano a ricostruire che cosa è successo a un file. Esempio: `date_file("prova.txt")["modifica"]`.
    """
    _controlla_percorso(percorso, "date_file")
    try:
        st = os.stat(percorso)
    except OSError as e:
        raise _errore_file(e, percorso, "leggere") from None
    creazione = getattr(st, "st_birthtime", None)
    if creazione is None and os.name == "nt":
        creazione = st.st_ctime
    return {"modifica": _iso(st.st_mtime), "accesso": _iso(st.st_atime),
            "creazione": _iso(creazione) if creazione else None, "dimensione": st.st_size}


@funzione_libreria("date_incoerenti")
def date_incoerenti(percorso):
    """date_incoerenti(percorso): cerca stranezze nelle date di un file (segnali di manomissione).

    Restituisce un dizionario con "avvisi" (una lista di messaggi) e le date stesse. Segnala per esempio
    una modifica avvenuta prima della creazione o una data nel futuro. Esempio:
    `date_incoerenti("sospetto.doc")["avvisi"]`.
    """
    date = date_file(percorso)
    avvisi = []
    ora = datetime.now()
    def _dt(v):
        return datetime.fromisoformat(v) if v else None
    mod, acc, cre = _dt(date["modifica"]), _dt(date["accesso"]), _dt(date["creazione"])
    if cre and mod and mod < cre:
        avvisi.append("Il file risulta modificato PRIMA di essere stato creato: data sospetta.")
    for nome, v in (("modifica", mod), ("accesso", acc), ("creazione", cre)):
        if v and v > ora:
            avvisi.append(f"La data di {nome} è nel futuro: l'orologio era sbagliato o la data è stata cambiata.")
    return {"avvisi": avvisi, "modifica": date["modifica"], "accesso": date["accesso"],
            "creazione": date["creazione"]}


# ===========================================================================
# Analisi dei log
# ===========================================================================

_MESI = {"Jan": 1, "Feb": 2, "Mar": 3, "Apr": 4, "May": 5, "Jun": 6, "Jul": 7, "Aug": 8,
         "Sep": 9, "Oct": 10, "Nov": 11, "Dec": 12}
_RE_WEB = re.compile(
    r'^(\S+) \S+ (\S+) \[([^\]]+)\] "([^"]*)" (\d{3}|-) (\d+|-)(?: "([^"]*)" "([^"]*)")?')
_RE_SYSLOG = re.compile(
    r'^([A-Z][a-z]{2}\s+\d+ \d{2}:\d{2}:\d{2}) (\S+) ([^:\[]+?)(?:\[(\d+)\])?: (.*)$')
_RE_IP = re.compile(r'\b(?:\d{1,3}\.){3}\d{1,3}\b')
_LIVELLI = ("emergenza", "allerta", "critico", "errore", "error", "err", "avviso", "warning", "warn",
            "notice", "info", "debug")


def _ora_da(iso: str) -> int | None:
    try:
        return datetime.fromisoformat(iso).hour
    except (ValueError, TypeError):
        return None


def _data_web(testo: str) -> str | None:
    m = re.match(r"(\d{2})/([A-Za-z]{3})/(\d{4}):(\d{2}):(\d{2}):(\d{2})", testo)
    if not m:
        return None
    g, mese, a, h, mi, s = m.groups()
    if mese not in _MESI:
        return None
    try:
        return datetime(int(a), _MESI[mese], int(g), int(h), int(mi), int(s)).isoformat(timespec="seconds")
    except ValueError:
        return None


def _riga_web(riga: str) -> dict | None:
    m = _RE_WEB.match(riga)
    if not m:
        return None
    ip, utente, data, richiesta, stato, dimensione, referer, agente = m.groups()
    parti = richiesta.split(" ")
    metodo = parti[0] if parti and parti[0] else None
    risorsa = parti[1] if len(parti) > 1 else None
    iso = _data_web(data)
    return {"_tipo": "web", "ip": ip, "utente": None if utente == "-" else utente, "data": iso,
            "ora": _ora_da(iso) if iso else None, "metodo": metodo, "risorsa": risorsa,
            "stato": int(stato) if stato.isdigit() else None,
            "dimensione": int(dimensione) if dimensione.isdigit() else 0,
            "referer": referer, "agente": agente, "riga": riga}


def _riga_syslog(riga: str) -> dict | None:
    m = _RE_SYSLOG.match(riga)
    if not m:
        return None
    data, host, programma, pid, messaggio = m.groups()
    mm = re.match(r"([A-Z][a-z]{2})\s+(\d+) (\d{2}):(\d{2}):(\d{2})", data)
    iso = None
    ora = None
    if mm and mm.group(1) in _MESI:
        mese, g, h, mi, s = mm.group(1), *map(int, mm.groups()[1:])
        try:
            iso = datetime(datetime.now().year, _MESI[mese], g, h, mi, s).isoformat(timespec="seconds")
            ora = h
        except ValueError:
            pass
    livello = next((l for l in _LIVELLI if re.search(r"\b" + l + r"\b", messaggio, re.IGNORECASE)), None)
    ip = (_RE_IP.search(messaggio) or [None])
    ip = ip.group(0) if hasattr(ip, "group") else None
    return {"_tipo": "syslog", "data": iso, "ora": ora, "host": host, "programma": programma.strip(),
            "pid": int(pid) if pid else None, "livello": livello, "ip": ip, "messaggio": messaggio, "riga": riga}


def _riga_firewall(riga: str) -> dict | None:
    if "SRC=" not in riga and "src=" not in riga:
        return None
    coppie = dict(re.findall(r"(\w+)=([^\s]+)", riga))
    coppie = {k.upper(): v for k, v in coppie.items()}
    azione = None
    for parola in ("BLOCK", "DROP", "DENY", "REJECT", "ACCEPT", "ALLOW", "PASS"):
        if re.search(r"\b" + parola + r"\b", riga, re.IGNORECASE):
            azione = parola.upper()
            break
    return {"_tipo": "firewall", "ip": coppie.get("SRC"), "destinazione": coppie.get("DST"),
            "protocollo": coppie.get("PROTO"), "porta_origine": coppie.get("SPT"),
            "porta_destinazione": coppie.get("DPT"), "azione": azione, "interfaccia": coppie.get("IN"),
            "riga": riga}


def _righe(percorso: str, nome_funzione: str) -> list[str]:
    testo = _leggi_testo(percorso, nome_funzione)
    return [r for r in testo.splitlines() if r.strip()]


@funzione_libreria("analizza_log_web")
def analizza_log_web(percorso):
    """analizza_log_web(percorso): legge un log di accessi web (Apache/Nginx) e lo trasforma in eventi.

    Capisce sia il formato "combined" sia "common". Ogni evento ha "ip", "data", "ora", "metodo",
    "risorsa", "stato", "dimensione", "referer" e "agente". Esempio:
    `lunghezza(analizza_log_web("access.log"))`.
    """
    return [e for e in (_riga_web(r) for r in _righe(percorso, "analizza_log_web")) if e]


@funzione_libreria("analizza_syslog")
def analizza_syslog(percorso):
    """analizza_syslog(percorso): legge un log di sistema (syslog) e lo trasforma in eventi.

    Ogni evento ha "data", "ora", "host", "programma", "pid", "livello" (se c'è), "ip" (se compare) e
    "messaggio". Esempio: `analizza_syslog("/var/log/syslog")`.
    """
    return [e for e in (_riga_syslog(r) for r in _righe(percorso, "analizza_syslog")) if e]


@funzione_libreria("analizza_log_firewall")
def analizza_log_firewall(percorso):
    """analizza_log_firewall(percorso): legge un log di firewall (iptables/UFW) e lo trasforma in eventi.

    Legge le coppie SRC/DST/PROTO/SPT/DPT e l'azione (BLOCK, DROP, ACCEPT...). Ogni evento ha "ip",
    "destinazione", "protocollo", "porta_destinazione" e "azione". Esempio:
    `analizza_log_firewall("ufw.log")`.
    """
    return [e for e in (_riga_firewall(r) for r in _righe(percorso, "analizza_log_firewall")) if e]


@funzione_libreria("analizza_log_csv")
def analizza_log_csv(percorso):
    """analizza_log_csv(percorso): legge un CSV di eventi (con intestazione) e lo trasforma in eventi.

    La prima riga sono i nomi delle colonne. Riconosce colonne come "ip", "data"/"ora"/"timestamp",
    "livello"/"level" e "messaggio" e le normalizza, tenendo anche tutte le altre. Esempio:
    `analizza_log_csv("eventi.csv")`.
    """
    testo = _leggi_testo(percorso, "analizza_log_csv")
    lettore = _csv.DictReader(io.StringIO(testo))
    sinonimi = {"ip": "ip", "indirizzo": "ip", "src": "ip", "source": "ip",
                "data": "data", "ora": "data", "time": "data", "timestamp": "data", "datetime": "data",
                "livello": "livello", "level": "livello", "severity": "livello",
                "messaggio": "messaggio", "message": "messaggio", "msg": "messaggio"}
    eventi = []
    for riga in lettore:
        evento: dict[str, Any] = {"_tipo": "csv"}
        for chiave, valore in riga.items():
            if chiave is None:
                continue
            norm = sinonimi.get(chiave.strip().lower())
            if norm and norm not in evento:
                evento[norm] = valore
            evento[chiave] = valore
        iso = evento.get("data")
        if iso:
            evento["ora"] = _ora_da(iso)
        eventi.append(evento)
    return eventi


@funzione_libreria("leggi_log")
def leggi_log(percorso, formato="auto"):
    """leggi_log(percorso, formato = "auto"): legge un file di log riconoscendo da solo il formato.

    `formato` può essere "auto", "web", "syslog", "firewall" o "csv". Restituisce la lista degli eventi
    (vedi le funzioni `analizza_...`). Con "auto" prova a indovinare dal contenuto. Esempio:
    `leggi_log("access.log")` oppure `leggi_log("eventi.csv", "csv")`.
    """
    richiedi_testo(formato, "leggi_log", "formato")
    f = formato.strip().lower()
    alias = {"apache": "web", "nginx": "web", "accessi": "web", "sistema": "syslog", "system": "syslog"}
    f = alias.get(f, f)
    if f == "web":
        return analizza_log_web(percorso)
    if f == "syslog":
        return analizza_syslog(percorso)
    if f == "firewall":
        return analizza_log_firewall(percorso)
    if f == "csv":
        return analizza_log_csv(percorso)
    if f != "auto":
        raise ErroreValore(f"Non conosco il formato di log {mostra(formato)}.",
                           suggerimento='Usa "auto", "web", "syslog", "firewall" o "csv".')
    righe = _righe(percorso, "leggi_log")
    campione = righe[:20]
    if any(_riga_web(r) for r in campione):
        return [e for e in (_riga_web(r) for r in righe) if e]
    if any("SRC=" in r or "src=" in r for r in campione):
        return [e for e in (_riga_firewall(r) for r in righe) if e]
    if any(_riga_syslog(r) for r in campione):
        return [e for e in (_riga_syslog(r) for r in righe) if e]
    if campione and ("," in campione[0] or ";" in campione[0]):
        return analizza_log_csv(percorso)
    raise ErroreValore(f"Non riesco a riconoscere il formato del log `{percorso}`.",
                       suggerimento='Indica il formato, per esempio `leggi_log(percorso, "web")`.')


def _eventi(valore: Any, nome_funzione: str) -> list[dict]:
    if not isinstance(valore, list) or any(not isinstance(e, dict) for e in valore):
        raise ErroreTipo(f"`{nome_funzione}` vuole una lista di eventi (il risultato di `leggi_log` o "
                         f"`analizza_...`), non {articolo(valore)}.")
    return valore


@funzione_libreria("raggruppa_eventi")
def raggruppa_eventi(eventi, campo):
    """raggruppa_eventi(eventi, campo): raggruppa gli eventi di un log per un campo (ip, ora, stato, livello...).

    Restituisce un dizionario valore_del_campo -> lista di eventi. Esempio:
    `raggruppa_eventi(leggi_log("access.log"), "ip")`.
    """
    _eventi(eventi, "raggruppa_eventi")
    richiedi_testo(campo, "raggruppa_eventi", "campo")
    gruppi: dict[Any, list] = {}
    for e in eventi:
        gruppi.setdefault(e.get(campo), []).append(e)
    return gruppi


@funzione_libreria("conta_valori")
def conta_valori(eventi, campo, quanti=10):
    """conta_valori(eventi, campo, quanti = 10): la classifica dei valori più frequenti di un campo.

    Restituisce una lista di dizionari {"valore", "conteggio"}, dal più frequente, lunga al massimo `quanti`.
    Esempio: `conta_valori(leggi_log("access.log"), "ip", 5)` (i 5 IP più attivi).
    """
    _eventi(eventi, "conta_valori")
    richiedi_testo(campo, "conta_valori", "campo")
    richiedi_intero(quanti, "conta_valori", "quanti")
    conteggio = Counter(e.get(campo) for e in eventi if e.get(campo) is not None)
    return [{"valore": v, "conteggio": c} for v, c in conteggio.most_common(max(quanti, 0))]


@funzione_libreria("riepilogo_log")
def riepilogo_log(eventi):
    """riepilogo_log(eventi): un riassunto di un log: quanti eventi, periodo, IP, stati o livelli più frequenti.

    Restituisce un dizionario con "totale", "dalla"/"alla" (prima e ultima data), "ip_distinti",
    "top_ip" e, se ci sono, "per_stato" (web) o "per_livello" (syslog). Esempio:
    `riepilogo_log(leggi_log("access.log"))`.
    """
    _eventi(eventi, "riepilogo_log")
    date = sorted(e["data"] for e in eventi if e.get("data"))
    ip = [e.get("ip") for e in eventi if e.get("ip")]
    ris: dict[str, Any] = {"totale": len(eventi), "dalla": date[0] if date else None,
                           "alla": date[-1] if date else None, "ip_distinti": len(set(ip)),
                           "top_ip": conta_valori(eventi, "ip", 5)}
    if any(e.get("stato") is not None for e in eventi):
        ris["per_stato"] = conta_valori(eventi, "stato", 10)
        ris["errori"] = sum(1 for e in eventi if isinstance(e.get("stato"), int) and e["stato"] >= 400)
        ris["top_risorse"] = conta_valori(eventi, "risorsa", 5)
    if any(e.get("livello") for e in eventi):
        ris["per_livello"] = conta_valori(eventi, "livello", 10)
    if any(e.get("azione") for e in eventi):
        ris["per_azione"] = conta_valori(eventi, "azione", 10)
    return ris


def _ip_di(e: dict) -> str | None:
    return e.get("ip")


@funzione_libreria("accessi_falliti")
def accessi_falliti(eventi):
    """accessi_falliti(eventi): raggruppa per IP i tentativi di accesso falliti di un log.

    Riconosce gli errori di autenticazione del web (stato 401/403) e del syslog ("Failed password",
    "authentication failure", "invalid user"). Restituisce una lista {"ip", "tentativi"} dal più attivo.
    Esempio: `accessi_falliti(leggi_log("auth.log", "syslog"))`.
    """
    _eventi(eventi, "accessi_falliti")
    falliti: Counter = Counter()
    for e in eventi:
        fallito = False
        if isinstance(e.get("stato"), int) and e["stato"] in (401, 403):
            fallito = True
        msg = e.get("messaggio") or ""
        if re.search(r"failed password|authentication failure|invalid user|failed login|login failed",
                     msg, re.IGNORECASE):
            fallito = True
        if fallito and e.get("ip"):
            falliti[e["ip"]] += 1
    return [{"ip": ip, "tentativi": n} for ip, n in falliti.most_common()]


@funzione_libreria("ip_sospetti")
def ip_sospetti(eventi, soglia=10):
    """ip_sospetti(eventi, soglia = 10): gli IP con troppi accessi falliti (possibile forza bruta altrui).

    Restituisce la lista degli IP con almeno `soglia` tentativi falliti, con "ip", "tentativi" e un
    "motivo". Strumento DIFENSIVO: serve a vedere chi bussa troppo ai propri servizi. Esempio:
    `ip_sospetti(leggi_log("auth.log", "syslog"), 5)`.
    """
    richiedi_intero(soglia, "ip_sospetti", "soglia")
    return [{"ip": v["ip"], "tentativi": v["tentativi"],
             "motivo": f"{v['tentativi']} accessi falliti (soglia {soglia})"}
            for v in accessi_falliti(eventi) if v["tentativi"] >= soglia]


@funzione_libreria("orari_insoliti")
def orari_insoliti(eventi, da_ora=0, a_ora=6):
    """orari_insoliti(eventi, da_ora = 0, a_ora = 6): gli eventi capitati in orari insoliti (di notte).

    Tiene gli eventi la cui ora è compresa tra `da_ora` (incluso) e `a_ora` (escluso). Di notte un
    accesso può meritare un'occhiata. Restituisce la lista di quegli eventi. Esempio:
    `orari_insoliti(leggi_log("access.log"))`.
    """
    _eventi(eventi, "orari_insoliti")
    richiedi_intero(da_ora, "orari_insoliti", "da_ora")
    richiedi_intero(a_ora, "orari_insoliti", "a_ora")
    return [e for e in eventi if isinstance(e.get("ora"), int) and da_ora <= e["ora"] < a_ora]


@funzione_libreria("trova_anomalie_log")
def trova_anomalie_log(eventi, ip_noti=None, soglia_falliti=5):
    """trova_anomalie_log(eventi, ip_noti = nulla, soglia_falliti = 5): cerca stranezze in un log.

    Trova: IP con molti accessi falliti, eventi notturni, IP mai visti (se dai `ip_noti`, una lista di
    IP fidati) e picchi (minuti con molti più eventi della media). Restituisce un dizionario con questi
    risultati e una lista "avvisi" in italiano. Esempio: `trova_anomalie_log(leggi_log("access.log"))`.
    """
    _eventi(eventi, "trova_anomalie_log")
    avvisi = []
    sospetti = ip_sospetti(eventi, soglia_falliti)
    for s in sospetti:
        avvisi.append(f"L'IP {s['ip']} ha {s['tentativi']} accessi falliti: possibile tentativo a forza bruta.")
    notturni = orari_insoliti(eventi)
    if notturni:
        avvisi.append(f"Ci sono {len(notturni)} eventi in orario notturno (00:00-06:00).")
    nuovi = []
    if ip_noti is not None:
        if not isinstance(ip_noti, list):
            raise ErroreTipo("`ip_noti` di `trova_anomalie_log` deve essere una lista di IP.")
        fidati = {str(x) for x in ip_noti}
        nuovi = sorted({e["ip"] for e in eventi if e.get("ip") and e["ip"] not in fidati})
        for ip in nuovi:
            avvisi.append(f"L'IP {ip} non è nella lista di quelli conosciuti.")
    minuti = Counter((e["data"] or "")[:16] for e in eventi if e.get("data"))
    picchi = []
    if len(minuti) >= 3:
        valori = list(minuti.values())
        media = sum(valori) / len(valori)
        limite = max(media * 3, media + 5)
        picchi = [{"minuto": m, "eventi": n} for m, n in sorted(minuti.items()) if n > limite]
        for p in picchi:
            avvisi.append(f"Picco di traffico alle {p['minuto']}: {p['eventi']} eventi in un minuto.")
    return {"accessi_falliti_sospetti": sospetti, "orari_notturni": len(notturni),
            "ip_mai_visti": nuovi, "picchi": picchi, "avvisi": avvisi}


@funzione_libreria("segui_log", interprete=True)
def segui_log(interprete, percorso, schema, quando_trova=None, secondi=10, da_inizio=False):
    """segui_log(percorso, schema, quando_trova = nulla, secondi = 10, da_inizio = falso): segue un log dal vivo.

    Guarda il file mentre cresce (come `tail -f`) e, per ogni nuova riga che corrisponde a `schema` (un
    testo, un'espressione o una `regola_schema`), chiama la funzione `quando_trova` passandole la riga.
    Si ferma dopo `secondi` secondi. Con `da_inizio = vero` guarda anche le righe già presenti (utile per
    provare). Restituisce la lista delle righe che hanno fatto scattare lo schema. SOLO difensivo: serve
    a sorvegliare i propri registri. Esempio:
    `segui_log("auth.log", "Failed password", stampa_riga, secondi = 30)`.
    """
    from .funzionali import chiama_funzione, richiedi_funzione

    _controlla_percorso(percorso, "segui_log")
    richiedi_intero(secondi, "segui_log", "secondi")
    richiedi_logico(da_inizio, "segui_log", "da_inizio")
    regola = _regola(schema, "segui_log")
    funzione = richiedi_funzione(quando_trova, "segui_log", "quando_trova") if quando_trova is not None else None
    trovate = []
    scadenza = time.monotonic() + max(secondi, 0)
    try:
        f = open(percorso, "r", encoding="utf-8", errors="replace")
    except OSError as e:
        raise _errore_file(e, percorso, "leggere") from None
    try:
        if not da_inizio:
            f.seek(0, os.SEEK_END)
        while True:
            riga = f.readline()
            if riga:
                testo = riga.rstrip("\n")
                if _applica(regola, testo.encode("latin-1", "replace"))["trovata"]:
                    trovate.append(testo)
                    if funzione is not None:
                        chiama_funzione(interprete, funzione, [testo])
                continue
            if getattr(interprete, "fermato", False) or time.monotonic() >= scadenza:
                break
            time.sleep(0.2)
    finally:
        f.close()
    return trovate


# ===========================================================================
# Caratteristiche di un file sospetto (triage difensivo)
# ===========================================================================

_STAMPABILI = frozenset(bytes(range(32, 127)) + b"\t")


@funzione_libreria("stringhe_leggibili")
def stringhe_leggibili(percorso, minimo=4):
    """stringhe_leggibili(percorso, minimo = 4): estrae le parti di testo leggibili da un file (come "strings").

    Trova le sequenze di caratteri stampabili lunghe almeno `minimo`, sia ASCII sia UTF-16. Dentro un
    programma o un file binario rivelano URL, messaggi, percorsi: utile per il triage, senza eseguire
    niente. Restituisce una lista di testi. Esempio: `stringhe_leggibili("programma.exe", 6)`.
    """
    richiedi_intero(minimo, "stringhe_leggibili", "minimo")
    if minimo < 1:
        raise ErroreValore("`minimo` di `stringhe_leggibili` deve essere almeno 1.")
    dati = _leggi(percorso, "stringhe_leggibili")
    risultato: list[str] = []
    corrente = bytearray()
    for b in dati:
        if b in _STAMPABILI:
            corrente.append(b)
        else:
            if len(corrente) >= minimo:
                risultato.append(corrente.decode("latin-1"))
            corrente.clear()
        if len(risultato) >= 200000:
            break
    if len(corrente) >= minimo:
        risultato.append(corrente.decode("latin-1"))
    # UTF-16LE: carattere ASCII (0x20-0x7e) seguito da uno zero, in sequenza
    corrente16 = bytearray()
    i = 0
    while i + 1 < len(dati) and len(risultato) < 200000:
        if 0x20 <= dati[i] <= 0x7e and dati[i + 1] == 0:
            corrente16.append(dati[i])
            i += 2
        else:
            if len(corrente16) >= minimo:
                risultato.append(corrente16.decode("latin-1"))
            corrente16.clear()
            i += 1
    if len(corrente16) >= minimo:
        risultato.append(corrente16.decode("latin-1"))
    return risultato


def _unici_ordinati(valori) -> list[str]:
    visti: dict[str, None] = {}
    for v in valori:
        visti.setdefault(v, None)
    return list(visti)


@funzione_libreria("estrai_url")
def estrai_url(dati):
    """estrai_url(dati): tutti gli indirizzi web (URL) dentro un testo o dei dati binari.

    Restituisce la lista degli URL trovati (http, https, ftp), senza ripetizioni. Utile per capire con
    chi "parla" un file sospetto, senza aprirlo. Esempio:
    `estrai_url("vai su https://esempio.it e http://altro.org")`.
    """
    testo = _testo_per_ricerca(dati, "estrai_url")
    trovati = re.findall(r"\b(?:https?|ftp)://[^\s\"'<>)\]]+", testo)
    return _unici_ordinati(t.rstrip(".,;)") for t in trovati)


@funzione_libreria("estrai_ip")
def estrai_ip(dati):
    """estrai_ip(dati): tutti gli indirizzi IP (versione 4) dentro un testo o dei dati binari.

    Restituisce la lista degli IP validi trovati, senza ripetizioni. Esempio:
    `estrai_ip("connessioni da 10.0.0.1 e 8.8.8.8")`.
    """
    testo = _testo_per_ricerca(dati, "estrai_ip")
    trovati = []
    for m in re.findall(r"\b(?:\d{1,3}\.){3}\d{1,3}\b", testo):
        if all(0 <= int(p) <= 255 for p in m.split(".")):
            trovati.append(m)
    return _unici_ordinati(trovati)


@funzione_libreria("estrai_email")
def estrai_email(dati):
    """estrai_email(dati): tutti gli indirizzi email dentro un testo o dei dati binari.

    Restituisce la lista degli indirizzi trovati, senza ripetizioni (utile anche per la protezione dei
    dati personali). Esempio: `estrai_email("scrivi a mario@esempio.it")`.
    """
    testo = _testo_per_ricerca(dati, "estrai_email")
    trovati = re.findall(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", testo)
    return _unici_ordinati(t.lower() for t in trovati)


def _luhn(numero: str) -> bool:
    cifre = [int(c) for c in numero]
    totale = 0
    for i, c in enumerate(reversed(cifre)):
        if i % 2 == 1:
            c *= 2
            if c > 9:
                c -= 9
        totale += c
    return totale % 10 == 0


def _circuito(numero: str) -> str:
    if numero.startswith("4"):
        return "Visa"
    if numero[:2] in ("34", "37"):
        return "American Express"
    if numero[:2] in [str(n) for n in range(51, 56)] or (2221 <= int(numero[:4]) <= 2720):
        return "Mastercard"
    if numero[:2] in ("36", "38") or numero[:3] in [str(n) for n in range(300, 306)]:
        return "Diners"
    return "sconosciuto"


@funzione_libreria("estrai_carte")
def estrai_carte(dati):
    """estrai_carte(dati): possibili numeri di carta di credito in un testo (per la protezione dei dati).

    Trova le sequenze di 13-19 cifre che passano il controllo di Luhn. I numeri sono sempre MASCHERATI
    (si vedono solo le ultime 4 cifre): servono a scoprire dati sensibili lasciati in giro, non a
    copiarli. Restituisce {"mascherato", "circuito"}. Esempio: `estrai_carte(leggi_testo("note.txt"))`.
    """
    testo = _testo_per_ricerca(dati, "estrai_carte")
    trovati = []
    visti = set()
    for grezzo in re.findall(r"\b(?:\d[ -]?){13,19}\b", testo):
        numero = re.sub(r"[ -]", "", grezzo)
        if 13 <= len(numero) <= 19 and _luhn(numero) and numero not in visti:
            visti.add(numero)
            trovati.append({"mascherato": "*" * (len(numero) - 4) + numero[-4:], "circuito": _circuito(numero)})
    return trovati


@funzione_libreria("cerca_segreti")
def cerca_segreti(percorso):
    """cerca_segreti(percorso): cerca in un file segreti dimenticati (chiavi private, token, password).

    Strumento DIFENSIVO: trova chiavi private lasciate in chiaro e token/segreti scritti nel codice, per
    toglierli. I valori trovati sono sempre MASCHERATI. Restituisce una lista {"tipo", "riga", "anteprima"}.
    Esempio: `cerca_segreti("config.py")`.
    """
    testo = _leggi_testo(percorso, "cerca_segreti")
    trovati = []
    for nome, descrizione, espressione in _REGOLE_SEGRETI:
        for m in re.finditer(espressione, testo):
            pezzo = m.group(0)
            numero_riga = testo.count("\n", 0, m.start()) + 1
            trovati.append({"tipo": nome, "descrizione": descrizione, "riga": numero_riga,
                            "anteprima": _maschera(pezzo)})
    return trovati


def _maschera(testo: str) -> str:
    """Mostra solo l'inizio di un segreto (mai il valore in chiaro)."""
    testo = testo.replace("\n", " ").strip()
    if len(testo) <= 12:
        return testo[:4] + "…"
    return testo[:8] + "…" + f" ({len(testo)} caratteri)"


@funzione_libreria("indizi_file")
def indizi_file(percorso):
    """indizi_file(percorso): un triage difensivo di un file in una sola chiamata.

    Mette insieme tipo vero, coerenza dell'estensione, dimensione, entropia (vicina a 8 = compresso o
    cifrato), impronta SHA-256, quante stringhe leggibili contiene e se dentro ci sono URL, IP o email.
    NON esegue niente. Restituisce un dizionario con questi indizi e una lista "avvisi". Esempio:
    `indizi_file("allegato_sospetto.bin")["avvisi"]`.
    """
    from .binario import entropia_file
    from .sicurezza_dati import impronta_file

    _controlla_percorso(percorso, "indizi_file")
    dati = _leggi(percorso, "indizi_file")
    coer = estensione_coerente(percorso)
    entropia = entropia_file(percorso)
    stringhe = stringhe_leggibili(percorso)
    testo = dati.decode("latin-1")
    url = _unici_ordinati(t.rstrip(".,;)") for t in re.findall(r"\b(?:https?|ftp)://[^\s\"'<>)\]]+", testo))
    ip = estrai_ip(testo)
    email = estrai_email(testo)
    avvisi = []
    if coer["avviso"]:
        avvisi.append(coer["avviso"])
    if entropia >= 7.9 and coer["tipo_vero"] in ("SCONOSCIUTO", "TESTO"):
        avvisi.append(f"Entropia molto alta ({entropia}): il file sembra compresso o cifrato, pur non "
                      f"sembrando un archivio. Potrebbe nascondere qualcosa.")
    if coer["tipo_vero"] == "SCONOSCIUTO":
        avvisi.append("Il tipo del file non è riconosciuto: tratta il file con prudenza.")
    return {"tipo": coer["tipo_vero"], "estensione_coerente": coer["coerente"], "dimensione": len(dati),
            "entropia": entropia, "impronta_sha256": impronta_file(percorso),
            "numero_stringhe": len(stringhe), "url": url, "ip": ip, "email": email, "avvisi": avvisi}
