"""Libreria: righe, file binari, codifiche, INI, TOML, ZIP, XML, YAML e JSON.

``scrivi_righe``, ``leggi_binario``, ``scrivi_binario``,
``riconosci_codifica``, ``leggi_con_codifica``, ``scrivi_con_codifica``,
``leggi_ini``, ``scrivi_ini``, ``leggi_toml``, ``scrivi_toml``,
``comprimi_zip``, ``estrai_zip``, ``elenca_zip``,
``leggi_xml``, ``trova_nodi``, ``trova_nodo``, ``trova_attributo``, ``scrivi_xml``,
``leggi_yaml``, ``scrivi_yaml``,
``converti_csv_in_json``, ``converti_json_in_csv``, ``abbellisci_json``, ``valida_json``.

L'XML diventa un *albero di nodi* (dizionari ``{"tag", "attributi", "testo", "figli"}``)
che si naviga con ``trova_nodi``/``trova_nodo`` e si riscrive con ``scrivi_xml``;
``leggi_xml`` rifiuta ``<!DOCTYPE>`` ed ``<!ENTITY>`` per sicurezza.

I file di testo si scrivono in UTF-8 (senza BOM) salvo richiesta diversa;
in lettura si riconoscono il BOM (UTF-8, UTF-16, UTF-32) e la codifica
"ANSI" di Windows. Le scritture dei formati di dati (INI, TOML) sono
*atomiche*: si scrive un file temporaneo accanto e poi lo si sostituisce,
così un'interruzione non lascia mai un file a metà.

Gli archivi ZIP si estraggono con prudenza: nomi con ``..`` o assoluti
(che uscirebbero dalla cartella di destinazione) e archivi enormi
("bombe ZIP") vengono rifiutati prima di scrivere qualunque file.
"""

from __future__ import annotations

import configparser
import os
import re
import tempfile
import zipfile
from typing import Any

from ..errori import ErroreFile, ErroreTipo, ErroreValore
from ..valori import rappresenta
from .generali import (articolo, funzione_libreria, lunghezza_intervallo, mostra, richiedi_logico,
                       richiedi_testo, tipi)
from .ingresso_uscita import _controlla_percorso, _errore_file, decodifica_testo

# ===========================================================================
# Strumenti comuni
# ===========================================================================


def scrivi_atomico(percorso: str, dati: bytes) -> None:
    """Scrive ``dati`` in ``percorso`` passando da un file temporaneo nella stessa cartella."""
    cartella = os.path.dirname(os.path.abspath(percorso))
    try:
        fd, temporaneo = tempfile.mkstemp(prefix=".leo_", suffix=".tmp", dir=cartella)
    except FileNotFoundError:
        raise ErroreFile(f"Non posso scrivere `{percorso}`: la cartella `{os.path.dirname(percorso) or '.'}` "
                         f"non esiste.", suggerimento="Creala prima con `crea_cartella(...)`.") from None
    except OSError as e:
        raise _errore_file(e, percorso, "scrivere") from None
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(dati)
        if os.path.isdir(percorso):
            raise IsADirectoryError(percorso)
        os.replace(temporaneo, percorso)
    except OSError as e:
        try:
            os.remove(temporaneo)
        except OSError:
            pass
        raise _errore_file(e, percorso, "scrivere") from None


def _leggi_byte(percorso: str) -> bytes:
    try:
        with open(percorso, "rb") as f:
            return f.read()
    except OSError as e:
        raise _errore_file(e, percorso, "leggere") from None
    except ValueError:
        raise ErroreFile(f"Il percorso `{percorso}` non è valido.") from None


# ===========================================================================
# Righe e file binari
# ===========================================================================


@funzione_libreria("scrivi_righe")
def scrivi_righe(percorso, righe):
    """scrivi_righe(percorso, righe): scrive una lista di righe in un file di testo, una per riga.

    I valori che non sono testi si scrivono come li mostra `stampa`. Il contrario è `leggi_righe`.
    Esempio: `scrivi_righe("spesa.txt", ["pane", "latte", "uova"])`.
    """
    _controlla_percorso(percorso, "scrivi_righe")
    if not isinstance(righe, list):
        raise ErroreTipo(f"`righe` di `scrivi_righe` deve essere una lista, non {articolo(righe)}.",
                         suggerimento="Per scrivere un solo testo usa `scrivi_file(percorso, testo)`.")
    testo = "".join((r if isinstance(r, str) else rappresenta(r)) + "\n" for r in righe)
    try:
        with open(percorso, "w", encoding="utf-8", newline="") as f:
            f.write(testo)
    except OSError as e:
        raise _errore_file(e, percorso, "scrivere") from None
    except ValueError:
        raise ErroreFile(f"Il percorso `{percorso}` non è valido.") from None
    return None


#: Oltre questa dimensione un file binario come lista di numeri occuperebbe troppa memoria.
MASSIMO_BINARIO = 32 * 1024 * 1024


@funzione_libreria("leggi_binario")
def leggi_binario(percorso):
    """leggi_binario(percorso): i byte di un file qualunque (immagine, suono...) come lista di numeri da 0 a 255.

    Esempio: `variabile b = leggi_binario("logo.png")` e poi `stampa(b[0..3])`.
    """
    _controlla_percorso(percorso, "leggi_binario")
    try:
        dimensione = os.path.getsize(percorso)
    except OSError as e:
        raise _errore_file(e, percorso, "leggere") from None
    if dimensione > MASSIMO_BINARIO:
        raise ErroreFile(f"Il file `{percorso}` è troppo grande per leggerlo come lista di byte "
                         f"(al massimo {MASSIMO_BINARIO // (1024 * 1024)} MB).",
                         suggerimento="Per copiarlo usa `copia_file(...)`, che non ha limiti.")
    return list(_leggi_byte(percorso))


@funzione_libreria("scrivi_binario")
def scrivi_binario(percorso, dati):
    """scrivi_binario(percorso, dati): scrive in un file una lista di byte (numeri interi da 0 a 255).

    Il contrario di `leggi_binario`. Esempio: `scrivi_binario("copia.png", leggi_binario("logo.png"))`.
    """
    _controlla_percorso(percorso, "scrivi_binario")
    if not isinstance(dati, list):
        raise ErroreTipo(f"`dati` di `scrivi_binario` deve essere una lista di numeri da 0 a 255, "
                         f"non {articolo(dati)}.",
                         suggerimento="Per scrivere un testo usa `scrivi_file(percorso, testo)`.")
    if not tipi(dati) <= {int}:
        for i, v in enumerate(dati):
            if type(v) is not int:
                raise ErroreTipo(f"L'elemento {i} dei `dati` è {articolo(v)} ({mostra(v)}): "
                                 f"servono numeri interi da 0 a 255.")
    try:
        contenuto = bytes(dati)
    except ValueError:
        sbagliato = next(v for v in dati if not 0 <= v <= 255)
        raise ErroreValore(f"Un byte va da 0 a 255, ma nei `dati` c'è {mostra(sbagliato)}.") from None
    try:
        with open(percorso, "wb") as f:
            f.write(contenuto)
    except OSError as e:
        raise _errore_file(e, percorso, "scrivere") from None
    except ValueError:
        raise ErroreFile(f"Il percorso `{percorso}` non è valido.") from None
    return None


# ===========================================================================
# Codifiche
# ===========================================================================

#: nome dato dall'utente (normalizzato) -> codifica Python
_CODIFICHE = {
    "utf8": "utf-8", "utf-8": "utf-8",
    "utf-8-bom": "utf-8-sig", "utf8-bom": "utf-8-sig", "utf-8 con bom": "utf-8-sig", "utf-8-sig": "utf-8-sig",
    "utf-16": "utf-16", "utf16": "utf-16", "unicode": "utf-16",
    "utf-32": "utf-32", "utf32": "utf-32",
    "ansi": "cp1252", "windows": "cp1252", "cp1252": "cp1252", "windows-1252": "cp1252",
    "latin1": "latin-1", "latin-1": "latin-1", "iso-8859-1": "latin-1",
    "latin9": "iso-8859-15", "iso-8859-15": "iso-8859-15",
    "ascii": "ascii", "oem": "cp850", "cp850": "cp850", "dos": "cp850", "mac": "mac-roman",
}
_NOMI_CODIFICHE = '"utf-8", "utf-8-bom", "utf-16", "utf-32", "ansi", "latin1", "latin9", "ascii", "dos"'


def _codifica(nome: Any, funzione: str) -> str:
    richiedi_testo(nome, funzione, "codifica")
    chiave = " ".join(nome.strip().lower().replace("_", "-").split())
    if chiave not in _CODIFICHE:
        raise ErroreValore(f"Non conosco la codifica {mostra(nome)}.",
                           suggerimento=f"Codifiche disponibili: {_NOMI_CODIFICHE}.")
    return _CODIFICHE[chiave]


@funzione_libreria("riconosci_codifica")
def riconosci_codifica(percorso):
    """riconosci_codifica(percorso): la codifica di un file di testo: "utf-8", "utf-8-bom", "utf-16", "utf-32", "ansi" o "binario".

    "ansi" è la codifica classica di Windows (per esempio i CSV del vecchio Excel); "binario" vuol
    dire che non è un file di testo. Esempio: `stampa(riconosci_codifica("voti.csv"))`.
    """
    _controlla_percorso(percorso, "riconosci_codifica")
    dati = _leggi_byte(percorso)
    if dati.startswith(b"\xef\xbb\xbf"):
        return "utf-8-bom"
    if dati.startswith((b"\xff\xfe\x00\x00", b"\x00\x00\xfe\xff")):
        return "utf-32"
    if dati.startswith((b"\xff\xfe", b"\xfe\xff")):
        return "utf-16"
    if b"\x00" in dati:
        return "binario"
    try:
        dati.decode("utf-8")
        return "utf-8"
    except UnicodeDecodeError:
        pass
    return "ansi" if decodifica_testo(dati) is not None else "binario"


@funzione_libreria("leggi_con_codifica")
def leggi_con_codifica(percorso, codifica):
    """leggi_con_codifica(percorso, codifica): legge un file di testo in una codifica precisa.

    Di solito basta `leggi_file`, che la riconosce da solo; questa serve per i casi speciali.
    Codifiche: "utf-8", "utf-8-bom", "utf-16", "utf-32", "ansi", "latin1", "latin9", "ascii", "dos".
    Esempio: `leggi_con_codifica("vecchio.txt", "dos")`.
    """
    _controlla_percorso(percorso, "leggi_con_codifica")
    nome = _codifica(codifica, "leggi_con_codifica")
    dati = _leggi_byte(percorso)
    if nome == "utf-8" and dati.startswith(b"\xef\xbb\xbf"):
        nome = "utf-8-sig"
    try:
        testo = dati.decode(nome)
    except UnicodeDecodeError as e:
        raise ErroreFile(f"Il file `{percorso}` non è scritto in {codifica} (byte non valido alla "
                         f"posizione {e.start}).",
                         suggerimento=f"Scopri la codifica giusta con `riconosci_codifica(\"{percorso}\")`.") from None
    return testo.replace("\r\n", "\n").replace("\r", "\n") if "\r" in testo else testo


@funzione_libreria("scrivi_con_codifica")
def scrivi_con_codifica(percorso, testo, codifica="utf-8", a_capo_windows=False):
    """scrivi_con_codifica(percorso, testo, codifica = "utf-8", a_capo_windows = falso): scrive un testo in una codifica precisa.

    Con `a_capo_windows = vero` le righe finiscono con "\\r\\n" come nel Blocco note.
    Esempio: `scrivi_con_codifica("per_excel.csv", testo, "utf-8-bom")`.
    """
    _controlla_percorso(percorso, "scrivi_con_codifica")
    if not isinstance(testo, str):
        raise ErroreTipo(f"Il `testo` di `scrivi_con_codifica` deve essere un testo, non {articolo(testo)}.")
    nome = _codifica(codifica, "scrivi_con_codifica")
    richiedi_logico(a_capo_windows, "scrivi_con_codifica", "a_capo_windows")
    if a_capo_windows:
        testo = testo.replace("\r\n", "\n").replace("\n", "\r\n")
    try:
        dati = testo.encode(nome)
    except UnicodeEncodeError as e:
        carattere = testo[e.start]
        raise ErroreValore(f"Il carattere {mostra(carattere)} non si può scrivere nella codifica {codifica}.",
                           suggerimento="Usa \"utf-8\", che sa scrivere tutti i caratteri.") from None
    try:
        with open(percorso, "wb") as f:
            f.write(dati)
    except OSError as e:
        raise _errore_file(e, percorso, "scrivere") from None
    except ValueError:
        raise ErroreFile(f"Il percorso `{percorso}` non è valido.") from None
    return None


# ===========================================================================
# INI
# ===========================================================================

#: sezione usata per le chiavi scritte prima di ogni ``[sezione]``
SEZIONE_GENERALE = "generale"


def _valore_ini(testo: str) -> Any:
    from .archivi import _converti_cella

    pulito = testo.strip()
    basso = pulito.lower()
    if basso in ("vero", "true", "si", "sì", "yes", "on"):
        return True
    if basso in ("falso", "false", "no", "off"):
        return False
    if len(pulito) >= 2 and pulito[0] == pulito[-1] and pulito[0] in "\"'":
        return pulito[1:-1]
    return _converti_cella(pulito, ";") if pulito else ""


@funzione_libreria("leggi_ini")
def leggi_ini(percorso, converti=True):
    """leggi_ini(percorso, converti = vero): legge un file di impostazioni INI come dizionario di sezioni.

    Ogni `[sezione]` diventa un dizionario `chiave: valore`; le chiavi fuori da ogni sezione vanno in
    "generale". Con `converti = vero` numeri e vero/falso (anche true/false, sì/no) diventano valori Leo.
    Esempio: `leggi_ini("gioco.ini")["grafica"]["larghezza"]`.
    """
    from .ingresso_uscita import leggi_testo

    _controlla_percorso(percorso, "leggi_ini")
    richiedi_logico(converti, "leggi_ini", "converti")
    testo = leggi_testo(percorso)
    lettore = configparser.RawConfigParser(strict=False, interpolation=None,
                                           comment_prefixes=("#", ";"), inline_comment_prefixes=None,
                                           default_section="\x00nessuna")
    lettore.optionxform = str  # type: ignore[assignment,method-assign]  # maiuscole rispettate
    try:
        try:
            lettore.read_string(testo)
        except configparser.MissingSectionHeaderError:
            lettore = configparser.RawConfigParser(strict=False, interpolation=None,
                                                   default_section="\x00nessuna")
            lettore.optionxform = str  # type: ignore[assignment,method-assign]
            lettore.read_string(f"[{SEZIONE_GENERALE}]\n" + testo)
    except configparser.Error as e:
        riga = getattr(e, "lineno", None)
        dove = f" (riga {riga})" if riga else ""
        raise ErroreFile(f"Il file `{percorso}` non è un file INI valido{dove}.",
                         suggerimento="Ogni riga deve essere `[sezione]`, `chiave = valore` o un commento "
                                      "che inizia con `#` o `;`.") from None
    risultato: dict = {}
    for sezione in lettore.sections():
        voci = {}
        for chiave, valore in lettore.items(sezione, raw=True):
            valore = "" if valore is None else valore
            voci[chiave] = _valore_ini(valore) if converti else valore
        risultato[sezione] = voci
    return risultato


def _testo_ini(v: Any, dove: str) -> str:
    if isinstance(v, (dict, list, range)):
        raise ErroreTipo(f"In un file INI i valori devono essere semplici (testi, numeri, logici), "
                         f"ma {dove} è {articolo(v)}.",
                         suggerimento="Per dati annidati usa `scrivi_json` o `scrivi_toml`.")
    testo = "" if v is None else rappresenta(v)
    if "\n" in testo or "\r" in testo:
        raise ErroreValore(f"In un file INI un valore non può andare a capo ({dove}).")
    return testo


@funzione_libreria("scrivi_ini")
def scrivi_ini(percorso, dati):
    """scrivi_ini(percorso, dati): salva un dizionario di sezioni in un file INI.

    `dati` è `{"sezione": {"chiave": valore}}`; i valori semplici fuori da una sezione vanno in
    `[generale]`. Esempio: `scrivi_ini("gioco.ini", {"grafica": {"larghezza": 800, "schermo_intero": falso}})`.
    """
    _controlla_percorso(percorso, "scrivi_ini")
    if not isinstance(dati, dict):
        raise ErroreTipo(f"`dati` di `scrivi_ini` deve essere un dizionario di sezioni, non {articolo(dati)}.",
                         suggerimento="Esempio: `{\"grafica\": {\"larghezza\": 800}}`.")
    generali = {k: v for k, v in dati.items() if not isinstance(v, dict)}
    sezioni = [(SEZIONE_GENERALE, generali)] if generali else []
    sezioni += [(k, v) for k, v in dati.items() if isinstance(v, dict)]
    righe: list[str] = []
    for nome, voci in sezioni:
        nome_t = rappresenta(nome)
        if any(c in nome_t for c in "[]\n\r") or not nome_t.strip():
            raise ErroreValore(f"Il nome di sezione {mostra(nome_t)} non va bene in un file INI.")
        if righe:
            righe.append("")
        righe.append(f"[{nome_t}]")
        for chiave, valore in voci.items():
            chiave_t = rappresenta(chiave)
            if not chiave_t.strip() or any(c in chiave_t for c in "=:\n\r[") or chiave_t.lstrip()[0] in "#;":
                raise ErroreValore(f"La chiave {mostra(chiave_t)} non va bene in un file INI.",
                                   suggerimento="Usa nomi semplici, senza `=`, `:` e senza andare a capo.")
            righe.append(f"{chiave_t} = {_testo_ini(valore, f'il valore di `{chiave_t}`')}")
    scrivi_atomico(percorso, ("\n".join(righe) + "\n").encode("utf-8"))
    return None


# ===========================================================================
# TOML
# ===========================================================================


@funzione_libreria("leggi_toml")
def leggi_toml(percorso):
    """leggi_toml(percorso): legge un file TOML (come `progetto.toml`) e lo trasforma in un dizionario Leo.

    Esempio: `variabile config = leggi_toml("config.toml")` poi `config["finestra"]["titolo"]`.
    """
    from ..tomlutil import ErroreToml
    from ..tomlutil import leggi_toml as _leggi
    from .ingresso_uscita import leggi_testo

    _controlla_percorso(percorso, "leggi_toml")
    testo = leggi_testo(percorso)
    try:
        return _leggi(testo)
    except ErroreToml as e:
        riga = getattr(e, "riga", 0)
        dove = f" (riga {riga})" if riga else ""
        raise ErroreFile(f"Il file `{percorso}` non è TOML valido{dove}: {getattr(e, 'messaggio', e)}",
                         suggerimento="In TOML i testi vanno tra virgolette e ogni riga è `chiave = valore`.") from None
    except (ValueError, RecursionError):
        raise ErroreFile(f"Il file `{percorso}` non è TOML valido.") from None


def _per_toml(v: Any, profondita: int = 0) -> Any:
    if profondita > 100:
        raise ErroreValore("Il valore è annidato troppo in profondità per diventare TOML.")
    if isinstance(v, (bool, str)) or v is None:
        return v
    if isinstance(v, int):
        if not -(2 ** 63) <= v < 2 ** 63:
            raise ErroreValore("In TOML gli interi devono stare tra -9223372036854775808 e 9223372036854775807.")
        return v
    if isinstance(v, float):
        return v
    if isinstance(v, range):
        if lunghezza_intervallo(v) > 100_000:
            raise ErroreValore("L'intervallo è troppo grande per diventare TOML.")
        return list(v)
    if isinstance(v, list):
        return [_per_toml(x, profondita + 1) for x in v if x is not None]
    if isinstance(v, dict):
        return {rappresenta(k): _per_toml(x, profondita + 1) for k, x in v.items()}
    if getattr(type(v), "NOME_TIPO_DANTE", None) == "data":
        return rappresenta(v)
    raise ErroreTipo(f"Non posso scrivere in TOML {articolo(v)}.",
                     suggerimento="In TOML vanno testi, numeri, logici, liste e dizionari.")


@funzione_libreria("scrivi_toml")
def scrivi_toml(percorso, dati):
    """scrivi_toml(percorso, dati): salva un dizionario Leo in un file TOML.

    I valori `nulla` si saltano (TOML non li conosce). Esempio:
    `scrivi_toml("config.toml", {"titolo": "Gioco", "finestra": {"larghezza": 800}})`.
    """
    from ..tomlutil import scrivi_toml as _scrivi

    _controlla_percorso(percorso, "scrivi_toml")
    if not isinstance(dati, dict):
        raise ErroreTipo(f"`dati` di `scrivi_toml` deve essere un dizionario, non {articolo(dati)}.")
    try:
        testo = _scrivi(_per_toml(dati))
    except (TypeError, ValueError, RecursionError) as e:
        raise ErroreValore(f"Non posso scrivere questi dati in TOML: {e}.") from None
    scrivi_atomico(percorso, testo.encode("utf-8"))
    return None


# ===========================================================================
# ZIP
# ===========================================================================

#: Limiti di sicurezza per l'estrazione (contro le "bombe ZIP").
MASSIMO_ESTRATTO = 4 * 1024 ** 3
MASSIMO_VOCI = 200_000


def _sorgenti(sorgente: Any) -> list[str]:
    if isinstance(sorgente, str):
        elenco = [sorgente]
    elif isinstance(sorgente, list):
        elenco = sorgente
    else:
        raise ErroreTipo(f"Cosa comprimere (`sorgente`) deve essere un percorso o una lista di percorsi, "
                         f"non {articolo(sorgente)}.")
    if not elenco:
        raise ErroreValore("La lista dei file da comprimere è vuota.")
    for p in elenco:
        _controlla_percorso(p, "comprimi_zip")
        if not os.path.exists(p):
            raise ErroreFile(f"`{p}` non esiste: non posso comprimerlo.",
                             suggerimento=f"Controlla il nome: ora sei in `{os.getcwd()}`.")
    return elenco


@funzione_libreria("comprimi_zip")
def comprimi_zip(sorgente, archivio):
    """comprimi_zip(sorgente, archivio): comprime un file, una cartella o una lista di percorsi in un archivio ZIP.

    Le cartelle entrano con tutto il contenuto. Se l'archivio esiste già viene sostituito.
    Restituisce quanti file ha compresso. Esempio: `comprimi_zip(["voti.csv", "foto"], "backup.zip")`.
    """
    elenco = _sorgenti(sorgente)
    _controlla_percorso(archivio, "comprimi_zip")
    if os.path.isdir(archivio):
        raise ErroreFile(f"`{archivio}` è una cartella: l'archivio deve essere un file, per esempio \"backup.zip\".")
    archivio_ass = os.path.normcase(os.path.abspath(archivio))
    voci: list[tuple[str, str]] = []  # (percorso sul disco, nome nell'archivio)
    for p in elenco:
        pulito = p.rstrip("/\\") or p
        if os.path.isdir(pulito):
            base = os.path.basename(os.path.abspath(pulito))
            for radice, cartelle, file in os.walk(pulito, followlinks=False):
                cartelle.sort()
                relativa = os.path.relpath(radice, pulito)
                interna = base if relativa == "." else base + "/" + relativa.replace(os.sep, "/")
                if not file and not cartelle:
                    voci.append((radice, interna + "/"))
                for n in sorted(file):
                    completo = os.path.join(radice, n)
                    if os.path.normcase(os.path.abspath(completo)) == archivio_ass:
                        continue  # l'archivio non contiene se stesso
                    voci.append((completo, interna + "/" + n))
        else:
            voci.append((pulito, os.path.basename(pulito)))
    scritti = 0
    temporaneo = archivio + ".leo_parziale"
    try:
        with zipfile.ZipFile(temporaneo, "w", compression=zipfile.ZIP_DEFLATED) as z:
            visti: set[str] = set()
            for disco, nome in voci:
                if nome in visti:
                    raise ErroreValore(f"Due file diversi avrebbero lo stesso nome `{nome}` nell'archivio.",
                                       suggerimento="Rinomina uno dei due o mettili in cartelle diverse.")
                visti.add(nome)
                if nome.endswith("/"):
                    z.writestr(nome, b"")
                    continue
                if os.path.islink(disco) and not os.path.exists(disco):
                    continue  # collegamento rotto
                z.write(disco, nome)
                scritti += 1
        os.replace(temporaneo, archivio)
    except OSError as e:
        _togli(temporaneo)
        raise _errore_file(e, archivio, "scrivere") from None
    except BaseException:
        _togli(temporaneo)
        raise
    return scritti


def _togli(percorso: str) -> None:
    try:
        os.remove(percorso)
    except OSError:
        pass


def _apri_zip(archivio: Any, nome: str) -> zipfile.ZipFile:
    _controlla_percorso(archivio, nome)
    try:
        return zipfile.ZipFile(archivio, "r")
    except zipfile.BadZipFile:
        raise ErroreFile(f"Il file `{archivio}` non è un archivio ZIP valido (forse è rovinato o di un "
                         f"altro formato, come RAR o 7z).") from None
    except OSError as e:
        raise _errore_file(e, archivio, "leggere") from None
    except (ValueError, NotImplementedError, RuntimeError):
        raise ErroreFile(f"Non riesco ad aprire l'archivio `{archivio}`.") from None


@funzione_libreria("elenca_zip")
def elenca_zip(archivio):
    """elenca_zip(archivio): i nomi dei file contenuti in un archivio ZIP, senza estrarli.

    Esempio: `per ogni n in elenca_zip("backup.zip") fai stampa(n) fine`.
    """
    with _apri_zip(archivio, "elenca_zip") as z:
        return [i.filename for i in z.infolist() if not i.is_dir()]


def _nome_sicuro(nome: str) -> str | None:
    """Il nome interno come percorso relativo sicuro, oppure None se uscirebbe dalla destinazione."""
    n = nome.replace("\\", "/")
    if n.startswith("/") or (len(n) > 1 and n[1] == ":") or "\0" in n:
        return None
    parti = [p for p in n.split("/") if p not in ("", ".")]
    if any(p == ".." for p in parti) or not parti:
        return None
    return os.path.join(*parti)


@funzione_libreria("estrai_zip")
def estrai_zip(archivio, cartella=".", sovrascrivi=False):
    """estrai_zip(archivio, cartella = ".", sovrascrivi = falso): estrae un archivio ZIP nella cartella e restituisce i file estratti.

    Se un file esiste già serve `sovrascrivi = vero` (prima di scrivere si controlla tutto).
    Gli archivi pericolosi (percorsi che escono dalla cartella, dimensioni esagerate) vengono rifiutati.
    Esempio: `estrai_zip("backup.zip", "ripristino")`.
    """
    _controlla_percorso(cartella, "estrai_zip")
    richiedi_logico(sovrascrivi, "estrai_zip", "sovrascrivi")
    if os.path.exists(cartella) and not os.path.isdir(cartella):
        raise ErroreFile(f"`{cartella}` è un file, non una cartella.")
    with _apri_zip(archivio, "estrai_zip") as z:
        voci = z.infolist()
        if len(voci) > MASSIMO_VOCI:
            raise ErroreFile(f"L'archivio `{archivio}` contiene troppi file ({len(voci)}): per sicurezza "
                             f"non lo estraggo.")
        totale = sum(i.file_size for i in voci)
        if totale > MASSIMO_ESTRATTO:
            raise ErroreFile(f"L'archivio `{archivio}` una volta estratto occuperebbe troppo spazio: "
                             f"per sicurezza non lo estraggo.")
        piano: list[tuple[zipfile.ZipInfo, str]] = []
        for info in voci:
            relativo = _nome_sicuro(info.filename)
            if relativo is None:
                raise ErroreFile(f"L'archivio `{archivio}` contiene un percorso pericoloso "
                                 f"({mostra(info.filename)}) che uscirebbe dalla cartella: non lo estraggo.",
                                 suggerimento="Gli archivi con `..` o percorsi assoluti possono sovrascrivere "
                                              "file di sistema. Non fidarti della fonte.")
            destinazione = os.path.join(cartella, relativo)
            if not info.is_dir() and os.path.exists(destinazione):
                if os.path.isdir(destinazione):
                    raise ErroreFile(f"Non posso estrarre `{info.filename}`: `{destinazione}` è una cartella.")
                if not sovrascrivi:
                    raise ErroreFile(f"`{destinazione}` esiste già: non estraggo niente.",
                                     suggerimento="Per sostituire i file scrivi "
                                                  "`estrai_zip(..., sovrascrivi = vero)`, oppure estrai "
                                                  "in una cartella nuova.")
            piano.append((info, destinazione))
        estratti: list[str] = []
        for info, destinazione in piano:
            try:
                if info.is_dir():
                    os.makedirs(destinazione, exist_ok=True)
                    continue
                os.makedirs(os.path.dirname(destinazione) or ".", exist_ok=True)
                with z.open(info) as sorgente, open(destinazione, "wb") as uscita:
                    scritti = 0
                    while True:
                        blocco = sorgente.read(1024 * 1024)
                        if not blocco:
                            break
                        scritti += len(blocco)
                        if scritti > info.file_size + 1024:  # dimensione dichiarata falsa
                            raise ErroreFile(f"L'archivio `{archivio}` mente sulla dimensione di "
                                             f"`{info.filename}`: estrazione interrotta.")
                        uscita.write(blocco)
            except RuntimeError:
                raise ErroreFile(f"`{info.filename}` nell'archivio è protetto da password: "
                                 f"Leo non sa ancora aprirlo.") from None
            except (zipfile.BadZipFile, EOFError, ValueError, NotImplementedError):
                raise ErroreFile(f"L'archivio `{archivio}` è rovinato: non riesco a leggere "
                                 f"`{info.filename}`.") from None
            except OSError as e:
                raise _errore_file(e, destinazione, "scrivere") from None
            estratti.append(destinazione)
    return estratti


# ===========================================================================
# XML (albero di nodi)
# ===========================================================================
#
# ``da_xml`` (in "testo_e_lingua") trasforma l'XML in un dizionario comodo ma
# che perde l'ordine e fonde gli elementi ripetuti. Qui invece l'XML diventa un
# *albero di nodi*: ogni nodo è un dizionario ``{"tag", "attributi", "testo",
# "figli"}`` che conserva ordine, ripetizioni e attributi, così puoi navigarlo
# con ``trova_nodi``/``trova_nodo`` e riscriverlo con ``scrivi_xml``.


def _nodo_da_elemento(el: Any) -> dict:
    """Un elemento di ``ElementTree`` come nodo Leo (dizionario)."""
    return {
        "tag": el.tag,
        "attributi": dict(el.attrib),
        "testo": el.text.strip() if (el.text and el.text.strip()) else "",
        "figli": [_nodo_da_elemento(f) for f in el],
    }


def _e_nodo_xml(x: Any) -> bool:
    return isinstance(x, dict) and "tag" in x and "figli" in x


def _richiedi_nodo(x: Any, nome: str, parametro: str) -> dict:
    if not _e_nodo_xml(x):
        raise ErroreTipo(f"`{parametro}` di `{nome}` deve essere un nodo XML, non {articolo(x)}.",
                         suggerimento="Prima leggi l'XML con `leggi_xml(testo)`: ti dà l'albero dei nodi.")
    return x


@funzione_libreria("leggi_xml")
def leggi_xml(testo):
    """leggi_xml(testo): legge un testo XML e restituisce l'albero dei nodi.

    Ogni nodo è un dizionario con `tag` (il nome), `attributi` (un dizionario), `testo`
    (il testo diretto) e `figli` (la lista dei nodi dentro). Per un file: `leggi_xml(leggi_file("dati.xml"))`.
    Esempio: `leggi_xml("<libro id=\\"7\\"><titolo>Pinocchio</titolo></libro>")["figli"][0]["testo"]` è "Pinocchio".
    """
    import xml.etree.ElementTree as ET

    richiedi_testo(testo, "leggi_xml", "testo")
    if re.search(r"<!(?:DOCTYPE|ENTITY)\b", testo, re.IGNORECASE):
        raise ErroreValore("Per sicurezza `leggi_xml` non apre XML con `<!DOCTYPE>` o `<!ENTITY>`.",
                           suggerimento="Togli le righe `<!DOCTYPE ...>` e `<!ENTITY ...>` dal testo XML.")
    try:
        radice = ET.fromstring(testo)
    except ET.ParseError as e:
        riga, colonna = getattr(e, "position", (0, 0)) or (0, 0)
        dove = f" (riga {riga}, colonna {colonna})" if riga else ""
        raise ErroreValore(f"Il testo non è XML valido{dove}.",
                           suggerimento="Ogni tag `<nome>` va chiuso con `</nome>` e gli attributi "
                                        "vanno tra virgolette, come `id=\"7\"`.") from None
    return _nodo_da_elemento(radice)


@funzione_libreria("trova_nodi")
def trova_nodi(nodo, tag):
    """trova_nodi(nodo, tag): la lista di tutti i nodi con quel nome dentro l'albero (anche il nodo stesso).

    Esempio: `trova_nodi(albero, "titolo")` sono tutti i nodi `<titolo>`.
    """
    _richiedi_nodo(nodo, "trova_nodi", "nodo")
    richiedi_testo(tag, "trova_nodi", "tag")
    trovati: list = []

    def cerca(n: dict) -> None:
        if n["tag"] == tag:
            trovati.append(n)
        for f in n["figli"]:
            cerca(f)

    cerca(nodo)
    return trovati


@funzione_libreria("trova_nodo")
def trova_nodo(nodo, tag, predefinito=None):
    """trova_nodo(nodo, tag, predefinito = nulla): il primo nodo con quel nome, o `predefinito` se non c'è.

    Esempio: `trova_nodo(albero, "titolo")["testo"]`.
    """
    _richiedi_nodo(nodo, "trova_nodo", "nodo")
    richiedi_testo(tag, "trova_nodo", "tag")
    trovati = trova_nodi(nodo, tag)
    return trovati[0] if trovati else predefinito


@funzione_libreria("trova_attributo")
def trova_attributo(nodo, nome, predefinito=None):
    """trova_attributo(nodo, nome, predefinito = nulla): il valore di un attributo del nodo, o `predefinito`.

    Esempio: `trova_attributo(nodo, "id")`.
    """
    _richiedi_nodo(nodo, "trova_attributo", "nodo")
    richiedi_testo(nome, "trova_attributo", "nome")
    return nodo["attributi"].get(nome, predefinito)


_RE_TAG_XML = re.compile(r"^[^\s<>&\"'/=]+$")


def _elemento_da_nodo(nodo: Any, profondita: int = 0):
    import xml.etree.ElementTree as ET

    if profondita > 200:
        raise ErroreValore("L'albero XML è annidato troppo in profondità per `scrivi_xml`.")
    _richiedi_nodo(nodo, "scrivi_xml", "nodo")
    tag = nodo.get("tag")
    if not isinstance(tag, str) or not _RE_TAG_XML.match(tag.strip() or " "):
        raise ErroreValore(f"Ogni nodo XML deve avere un `tag` (nome) valido, ma c'è {mostra(tag)}.",
                           suggerimento="Il nome di un tag è un testo senza spazi, come \"libro\" o \"titolo\".")
    el = ET.Element(tag)
    attributi = nodo.get("attributi")
    if attributi is None:
        attributi = {}
    elif not isinstance(attributi, dict):
        raise ErroreTipo(f"Gli `attributi` di un nodo XML devono essere un dizionario, non {articolo(attributi)}.")
    for chiave, valore in attributi.items():
        el.set(chiave if isinstance(chiave, str) else rappresenta(chiave),
               valore if isinstance(valore, str) else rappresenta(valore))
    testo = nodo.get("testo")
    if testo is not None and testo != "":
        el.text = testo if isinstance(testo, str) else rappresenta(testo)
    figli = nodo.get("figli")
    if figli is None:
        figli = []
    elif not isinstance(figli, (list, tuple, range)):
        raise ErroreTipo(f"I `figli` di un nodo XML devono essere una lista, non {articolo(figli)}.")
    for figlio in figli:
        el.append(_elemento_da_nodo(figlio, profondita + 1))
    return el


@funzione_libreria("scrivi_xml")
def scrivi_xml(nodo, rientro=True):
    """scrivi_xml(nodo, rientro = vero): trasforma un albero di nodi in un testo XML (l'inverso di `leggi_xml`).

    Con `rientro = vero` il testo va a capo con i rientri. Per salvarlo: `scrivi_file("dati.xml", scrivi_xml(albero))`.
    Esempio: `scrivi_xml({"tag": "libro", "attributi": {"id": "7"}, "testo": "", "figli": []}, rientro = falso)`
    è "<libro id=\\"7\\" />".
    """
    import xml.etree.ElementTree as ET

    richiedi_logico(rientro, "scrivi_xml", "rientro")
    elemento = _elemento_da_nodo(nodo)
    if rientro:
        ET.indent(elemento, space="  ")
    testo = ET.tostring(elemento, encoding="unicode")
    if rientro and not testo.endswith("\n"):
        testo += "\n"
    return testo


# ===========================================================================
# YAML da/su file (il testo lo leggono/scrivono ``da_yaml``/``a_yaml``)
# ===========================================================================


@funzione_libreria("leggi_yaml")
def leggi_yaml(percorso):
    """leggi_yaml(percorso): legge un file YAML (come `impostazioni.yaml`) e restituisce dizionari e liste.

    Capisce lo YAML di tutti i giorni (vedi `da_yaml`). Esempio: `variabile config = leggi_yaml("config.yaml")`.
    """
    from .ingresso_uscita import leggi_testo
    from .testo_e_lingua import da_yaml

    _controlla_percorso(percorso, "leggi_yaml")
    testo = leggi_testo(percorso)
    try:
        return da_yaml(testo)
    except ErroreValore as e:
        raise ErroreFile(f"Il file `{percorso}` non è un YAML che so leggere: {e}",
                         suggerimento="Ogni riga è `chiave: valore`; gli elementi di una lista iniziano "
                                      "con `- ` e i livelli si segnano con i rientri (spazi).") from None


@funzione_libreria("scrivi_yaml")
def scrivi_yaml(percorso, dati):
    """scrivi_yaml(percorso, dati): salva dizionari e liste in un file YAML (l'inverso di `leggi_yaml`).

    Esempio: `scrivi_yaml("config.yaml", {"nome": "Ada", "linguaggi": ["Leo", "Python"]})`.
    """
    from .testo_e_lingua import a_yaml

    _controlla_percorso(percorso, "scrivi_yaml")
    testo = a_yaml(dati)
    scrivi_atomico(percorso, testo.encode("utf-8"))
    return None


# ===========================================================================
# Tabelle e JSON (conversioni veloci fra testi)
# ===========================================================================


@funzione_libreria("converti_csv_in_json")
def converti_csv_in_json(testo, separatore=None, rientro=2):
    """converti_csv_in_json(testo, separatore = nulla, rientro = 2): trasforma un testo CSV in un testo JSON.

    La prima riga del CSV sono i nomi delle colonne; ogni riga dopo diventa un dizionario.
    Esempio: `converti_csv_in_json("nome,voto\\nAda,30")` è `[\\n  {\\n    "nome": "Ada",\\n    "voto": 30\\n  }\\n]`.
    """
    from .archivi import a_json, da_csv

    richiedi_testo(testo, "converti_csv_in_json", "testo")
    righe = da_csv(testo, separatore)
    return a_json(righe, rientro)


@funzione_libreria("converti_json_in_csv")
def converti_json_in_csv(testo, separatore=","):
    """converti_json_in_csv(testo, separatore = ","): trasforma un testo JSON (lista di dizionari) in un testo CSV.

    Esempio: `converti_json_in_csv("[\\{\\"nome\\": \\"Ada\\", \\"voto\\": 30\\}]")` è "nome,voto\\nAda,30\\n".
    """
    from .archivi import a_csv, da_json

    richiedi_testo(testo, "converti_json_in_csv", "testo")
    dati = da_json(testo)
    if not isinstance(dati, list):
        raise ErroreTipo(f"`converti_json_in_csv` vuole un JSON con una lista di righe, "
                         f"ma ho trovato {articolo(dati)}.",
                         suggerimento='Il JSON deve essere come `[{"nome": "Ada"}, {"nome": "Bruno"}]`.')
    return a_csv(dati, separatore)


@funzione_libreria("abbellisci_json")
def abbellisci_json(testo, rientro=2):
    """abbellisci_json(testo, rientro = 2): rimette in ordine un testo JSON con i rientri, per leggerlo meglio.

    Esempio: `abbellisci_json("\\{\\"nome\\": \\"Ada\\", \\"voti\\": [30, 28]\\}")` va a capo e aggiunge gli spazi.
    """
    from .archivi import a_json, da_json

    richiedi_testo(testo, "abbellisci_json", "testo")
    return a_json(da_json(testo), rientro)


@funzione_libreria("valida_json")
def valida_json(testo):
    """valida_json(testo): controlla se un testo è JSON valido.

    Restituisce un dizionario `{"valido": vero/falso, "messaggio": "..."}`: se non è valido, il
    messaggio spiega dov'è l'errore. Esempio: `valida_json("\\{\\"a\\": 1\\}")["valido"]` è vero.
    """
    from .archivi import da_json

    richiedi_testo(testo, "valida_json", "testo")
    try:
        da_json(testo)
    except ErroreValore as e:
        return {"valido": False, "messaggio": str(e)}
    return {"valido": True, "messaggio": "Il testo è JSON valido."}


# ===========================================================================
# Sinonimi
# ===========================================================================

from .cartelle import registra_sinonimo  # noqa: E402

for _nuovo, _originale in (("comprimi", "comprimi_zip"), ("decomprimi", "estrai_zip"),
                           ("leggi_byte", "leggi_binario"), ("scrivi_byte", "scrivi_binario")):
    registra_sinonimo(_nuovo, _originale)
