"""Genera ``leo/libreria/_indice.py``: le funzioni e i metodi dei moduli pigri.

Uso::

    python -m leo.libreria._genera_indice            # riscrive _indice.py
    python -m leo.libreria._genera_indice --controlla # esce con 1 se _indice.py non è aggiornato

Il calcolo avviene in un processo nuovo con ``LEO_LIBRERIA_PIGRA=indice`` (il
pacchetto non importa niente da solo): si importano i moduli uno alla volta,
nell'ordine di :data:`leo.libreria.MODULI`, e si guarda che cosa aggiunge
ciascuno ai registri. Per un modulo pigro è un errore:

* registrare di nuovo un nome già registrato da un altro modulo;
* registrare costanti (l'ambiente predefinito le vuole tutte subito);
* importare (in cima) un altro modulo della libreria che viene dopo di lui.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

FILE_INDICE = Path(__file__).with_name("_indice.py")

_CALCOLO = r'''
import importlib, json, sys
import leo.libreria as lib
from leo import registro

def istantanea():
    f = {k: id(v) for k, v in registro.FUNZIONI.items()}
    m = {(t, k): id(v) for t, d in registro.METODI.items() for k, v in d.items()}
    return f, m, dict(registro.COSTANTI)

nomi = [n for n, _ in lib.MODULI]
risultato, errori = {}, []
for nome, pigro in lib.MODULI:
    completo = f"leo.libreria.{nome}"
    prima_f, prima_m, prima_c = istantanea()
    gia = {n for n in nomi if f"leo.libreria.{n}" in sys.modules}
    importlib.import_module(completo)
    nuovi = {n for n in nomi if f"leo.libreria.{n}" in sys.modules} - gia - {nome}
    if not pigro:
        continue
    if nuovi:
        errori.append(f"{nome}: importa anche {sorted(nuovi)} (mettili prima in MODULI)")
    voci = []
    for k, v in registro.FUNZIONI.items():
        if k in prima_f:
            if prima_f[k] != id(v):
                errori.append(f"{nome}: registra di nuovo la funzione `{k}`")
            continue
        voci.append((None, k, v))
    for t, d in registro.METODI.items():
        for k, v in d.items():
            if (t, k) in prima_m:
                if prima_m[(t, k)] != id(v):
                    errori.append(f"{nome}: registra di nuovo il metodo `{t}.{k}`")
                continue
            voci.append((t, k, v))
    if set(registro.COSTANTI) != set(prima_c):
        errori.append(f"{nome}: registra costanti")
    elenco = []
    for t, k, v in voci:
        modulo_python = getattr(v.funzione, "__module__", "") or ""
        elenco.append([t, k, bool(v.vuole_interprete), bool(v.e_metodo),
                       None if modulo_python == completo else modulo_python])
    risultato[nome] = elenco
print(json.dumps({"indice": risultato, "errori": errori}))
'''


def calcola_indice() -> dict[str, list[tuple]]:
    """L'indice dei moduli pigri com'è oggi (in un processo separato)."""
    ambiente = dict(os.environ, LEO_LIBRERIA_PIGRA="indice")
    radice = str(Path(__file__).resolve().parents[2])
    ambiente["PYTHONPATH"] = radice + os.pathsep + ambiente.get("PYTHONPATH", "")
    uscita = subprocess.run([sys.executable, "-c", _CALCOLO], capture_output=True, text=True,
                            env=ambiente, cwd=radice, check=False)
    if uscita.returncode != 0:
        raise RuntimeError(f"calcolo dell'indice fallito:\n{uscita.stderr}")
    dati = json.loads(uscita.stdout.strip().splitlines()[-1])
    if dati["errori"]:
        raise RuntimeError("moduli pigri non validi:\n" + "\n".join(dati["errori"]))
    return {nome: [tuple(v) for v in voci] for nome, voci in dati["indice"].items()}


def testo_indice(indice: dict[str, list[tuple]]) -> str:
    righe = [
        '"""Funzioni e metodi dei moduli pigri della libreria (vedi ``leo/libreria/__init__.py``).',
        "",
        "GENERATO da ``python -m leo.libreria._genera_indice``: non modificarlo a mano.",
        "Ogni voce: (tipo del metodo o None per le funzioni, nome, vuole_interprete, e_metodo,",
        "modulo Python della funzione se diverso da quello che la registra).",
        '"""',
        "",
        "PIGRI: dict[str, tuple[tuple, ...]] = {",
    ]
    for nome, voci in indice.items():
        righe.append(f"    {nome!r}: (")
        for voce in voci:
            righe.append(f"        {tuple(voce)!r},")
        righe.append("    ),")
    righe.append("}")
    return "\n".join(righe) + "\n"


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    testo = testo_indice(calcola_indice())
    attuale = FILE_INDICE.read_text(encoding="utf-8") if FILE_INDICE.exists() else ""
    if "--controlla" in argv:
        if testo != attuale:
            print("leo/libreria/_indice.py non è aggiornato: python -m leo.libreria._genera_indice")
            return 1
        print("indice aggiornato")
        return 0
    if testo != attuale:
        FILE_INDICE.write_text(testo, encoding="utf-8")
        print(f"scritto {FILE_INDICE}")
    else:
        print("indice già aggiornato")
    return 0


if __name__ == "__main__":
    sys.exit(main())
