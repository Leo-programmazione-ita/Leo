"""Libreria: tempo avanzato (date in parole, giorni lavorativi e festività italiane, età, durate, conto alla rovescia).

Completa ``leo.libreria.date`` (tipo ``data``, ``giorni_tra``, ``in_lettere``,
``formato``) e ``caso_e_tempo`` (``cronometro``) senza ripeterne le funzioni:

* ``formatta_data``: una data in vari stili italiani ("lunedì 5 ottobre 2026", "5 ott 2026"...);
* ``tempo_relativo``: la distanza da adesso in parole ("3 giorni fa", "tra 2 ore");
* ``pasqua``, ``festivita_italiane``, ``nome_festivita``, ``e_festivo``,
  ``e_giorno_lavorativo``, ``giorni_lavorativi``, ``aggiungi_giorni_lavorativi``:
  il calendario delle festività nazionali italiane (Pasqua e Pasquetta calcolate);
* ``calcola_eta``: gli anni compiuti (o anni, mesi e giorni) da una data di nascita;
* ``durata_in_parole`` e ``formatta_durata``: secondi scritti per esteso o come "01:02:03";
* ``conto_alla_rovescia``: un valore che dice quanto manca a una scadenza;
* al ``cronometro`` si aggiungono ``segna_giro()`` e la proprietà ``tempi_giro``.
"""

from __future__ import annotations

import datetime
import math
import time
from typing import Any

from ..errori import ErroreTipo, ErroreValore
from ..valori import rappresenta
from .caso_e_tempo import Cronometro
from .date import GIORNI, MESI, DataDante, richiedi_data
from .generali import (articolo, funzione_libreria, mostra, richiedi_intero, richiedi_logico, richiedi_numero,
                       richiedi_testo)
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta

MESI_BREVI = ["gen", "feb", "mar", "apr", "mag", "giu", "lug", "ago", "set", "ott", "nov", "dic"]

#: Durata massima trattata (in secondi): 10000 anni.
MASSIMA_DURATA = 10_000 * 366 * 86_400


def _data(valore: Any, nome_funzione: str, parametro: str) -> DataDante:
    return richiedi_data(valore, nome_funzione, parametro)


def _data_o_oggi(valore: Any, nome_funzione: str, parametro: str) -> DataDante:
    if valore is None:
        oggi = datetime.date.today()
        return DataDante(datetime.datetime(oggi.year, oggi.month, oggi.day))
    return _data(valore, nome_funzione, parametro)


def _nuova(giorno: datetime.date) -> DataDante:
    return DataDante(datetime.datetime(giorno.year, giorno.month, giorno.day))


# ===========================================================================
# Date in parole
# ===========================================================================

STILI_DATA = ("lungo", "completo", "medio", "breve", "numerico", "iso", "mese_anno", "giorno_mese")


@funzione_libreria("formatta_data")
def formatta_data(d, stile="lungo"):
    """formatta_data(d, stile = "lungo"): la data scritta in italiano nello stile scelto.

    Stili: "lungo" ("lunedì 5 ottobre 2026"), "completo" (con l'ora: "lunedì 5 ottobre 2026, ore 14:30"),
    "medio" ("5 ott 2026"), "breve" ("05/10/26"), "numerico" ("05/10/2026"), "iso" ("2026-10-05"),
    "mese_anno" ("ottobre 2026"), "giorno_mese" ("5 ottobre").
    Esempio: `formatta_data(data(2026, 10, 5))` è "lunedì 5 ottobre 2026".
    """
    v = _data(d, "formatta_data", "d").valore
    richiedi_testo(stile, "formatta_data", "stile")
    s = stile.strip().lower()
    giorno, mese = GIORNI[v.weekday()], MESI[v.month - 1]
    if s == "lungo":
        return f"{giorno} {v.day} {mese} {v.year}"
    if s == "completo":
        return f"{giorno} {v.day} {mese} {v.year}, ore {v.hour:02d}:{v.minute:02d}"
    if s == "medio":
        return f"{v.day} {MESI_BREVI[v.month - 1]} {v.year}"
    if s == "breve":
        return f"{v.day:02d}/{v.month:02d}/{v.year % 100:02d}"
    if s == "numerico":
        return f"{v.day:02d}/{v.month:02d}/{v.year:04d}"
    if s == "iso":
        return f"{v.year:04d}-{v.month:02d}-{v.day:02d}"
    if s == "mese_anno":
        return f"{mese} {v.year}"
    if s == "giorno_mese":
        return f"{v.day} {mese}"
    raise ErroreValore(f"Non conosco lo stile di data {mostra(stile)}.",
                       suggerimento="Stili disponibili: " + ", ".join(f"\"{x}\"" for x in STILI_DATA) + ".")


def _quanti(n: int, singolare: str, plurale: str, articolo_uno: str) -> str:
    return f"{articolo_uno}{singolare}" if n == 1 else f"{n} {plurale}"


@funzione_libreria("tempo_relativo")
def tempo_relativo(d, riferimento=None):
    """tempo_relativo(d, riferimento = nulla): quanto tempo è passato (o manca) in parole, rispetto ad adesso.

    Esempi di risultato: "adesso", "5 minuti fa", "tra 2 ore", "ieri", "domani", "3 giorni fa",
    "una settimana fa", "tra 4 mesi", "2 anni fa". Con le date senza orario conta i giorni del calendario.
    Esempio: `tempo_relativo(data(2026, 9, 24), riferimento = data(2026, 9, 27))` è "3 giorni fa".
    """
    a = _data(d, "tempo_relativo", "d")
    if riferimento is None:
        rif = DataDante(datetime.datetime.now().replace(microsecond=0))
        solo_giorni = not a.ha_orario
        if solo_giorni:
            rif = _nuova(rif.valore.date())
    else:
        rif = _data(riferimento, "tempo_relativo", "riferimento")
        solo_giorni = not a.ha_orario and not rif.ha_orario
    secondi = (a.valore - rif.valore).total_seconds()
    futuro = secondi > 0
    s = abs(secondi)

    def frase(parole: str) -> str:
        return f"tra {parole}" if futuro else f"{parole} fa"

    if not solo_giorni:
        if s < 60:
            return "adesso"
        if s < 3600:
            return frase(_quanti(int(s // 60), "minuto", "minuti", "un "))
        if s < 86_400:
            return frase(_quanti(int(s // 3600), "ora", "ore", "un'"))
    giorni = int(s // 86_400)
    if giorni == 0:
        return "oggi"
    if giorni == 1:
        return "domani" if futuro else "ieri"
    if giorni == 2:
        return "dopodomani" if futuro else "l'altro ieri"
    if giorni < 7:
        return frase(f"{giorni} giorni")
    if giorni < 30:
        return frase(_quanti(giorni // 7, "settimana", "settimane", "una "))
    if giorni < 365:
        return frase(_quanti(max(1, giorni // 30), "mese", "mesi", "un "))
    return frase(_quanti(giorni // 365, "anno", "anni", "un "))


# ===========================================================================
# Pasqua e festività italiane
# ===========================================================================

def _pasqua(anno: int) -> datetime.date:
    """Domenica di Pasqua (calendario gregoriano, algoritmo di Meeus/Jones/Butcher)."""
    a = anno % 19
    b, c = divmod(anno, 100)
    d, e = divmod(b, 4)
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = divmod(c, 4)
    l_ = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l_) // 451
    mese = (h + l_ - 7 * m + 114) // 31
    giorno = (h + l_ - 7 * m + 114) % 31 + 1
    return datetime.date(anno, mese, giorno)


def _anno(anno: Any, nome_funzione: str) -> int:
    if isinstance(anno, (DataDante, str)):
        return _data(anno, nome_funzione, "anno").valore.year
    richiedi_intero(anno, nome_funzione, "anno")
    if not 1583 <= anno <= 9998:
        raise ErroreValore(f"L'anno deve essere tra 1583 (calendario gregoriano) e 9998, non {mostra(anno)}.")
    return anno


@funzione_libreria("pasqua")
def pasqua(anno):
    """pasqua(anno): la data della domenica di Pasqua in quell'anno (calcolata, calendario gregoriano).

    Esempi: `pasqua(2026)` è 05/04/2026; Pasquetta è `pasqua(2026).aggiungi_giorni(1)`.
    """
    return _nuova(_pasqua(_anno(anno, "pasqua")))


def _festivita(anno: int) -> dict[datetime.date, str]:
    p = _pasqua(anno)
    elenco = {
        datetime.date(anno, 1, 1): "Capodanno",
        datetime.date(anno, 1, 6): "Epifania",
        p: "Pasqua",
        p + datetime.timedelta(days=1): "Lunedì dell'Angelo (Pasquetta)",
        datetime.date(anno, 4, 25): "Festa della Liberazione",
        datetime.date(anno, 5, 1): "Festa del Lavoro",
        datetime.date(anno, 6, 2): "Festa della Repubblica",
        datetime.date(anno, 8, 15): "Ferragosto (Assunzione)",
        datetime.date(anno, 11, 1): "Ognissanti",
        datetime.date(anno, 12, 8): "Immacolata Concezione",
        datetime.date(anno, 12, 25): "Natale",
        datetime.date(anno, 12, 26): "Santo Stefano",
    }
    if anno >= 2026:  # festa nazionale di nuovo dal 2026 (legge 151/2025)
        elenco.setdefault(datetime.date(anno, 10, 4), "San Francesco d'Assisi, patrono d'Italia")
    return dict(sorted(elenco.items()))


def _extra(extra: Any, nome_funzione: str) -> set[tuple[int, int]]:
    """Giorni festivi in più (patrono...): testi "GG/MM" o date, ripetuti ogni anno."""
    if extra is None:
        return set()
    elenco = extra if isinstance(extra, list) else [extra]
    risultato = set()
    for v in elenco:
        if isinstance(v, DataDante):
            risultato.add((v.valore.month, v.valore.day))
            continue
        if not isinstance(v, str):
            raise ErroreTipo(f"Le festività in più di `{nome_funzione}` devono essere testi come \"07/12\" o date, "
                             f"non {articolo(v)}.")
        parti = v.strip().replace("-", "/").replace(".", "/").split("/")
        try:
            giorno, mese = int(parti[0]), int(parti[1])
            datetime.date(2000, mese, giorno)
        except (ValueError, IndexError):
            raise ErroreValore(f"Non capisco la festività {mostra(v)}.",
                               suggerimento="Scrivila come \"GG/MM\", per esempio \"07/12\" per Sant'Ambrogio.") from None
        risultato.add((mese, giorno))
    return risultato


@funzione_libreria("festivita_italiane")
def festivita_italiane(anno):
    """festivita_italiane(anno): le festività nazionali italiane dell'anno, come lista di dizionari {"data", "nome"}.

    Pasqua e Pasquetta sono calcolate; dal 2026 c'è anche San Francesco (4 ottobre).
    Esempio: `per ogni f in festivita_italiane(2026) fai stampa(f["data"], f["nome"]) fine`.
    """
    return [{"data": _nuova(g), "nome": n} for g, n in _festivita(_anno(anno, "festivita_italiane")).items()]


def _nome_festa(giorno: datetime.date, extra: set[tuple[int, int]]) -> str | None:
    nome = _festivita(giorno.year).get(giorno) if 1583 <= giorno.year <= 9998 else None
    if nome is None and (giorno.month, giorno.day) in extra:
        return "festività locale"
    return nome


@funzione_libreria("nome_festivita")
def nome_festivita(d):
    """nome_festivita(d): il nome della festività nazionale di quel giorno, o `nulla` se è un giorno normale.

    Esempio: `nome_festivita("25/04/2026")` è "Festa della Liberazione".
    """
    return _nome_festa(_data(d, "nome_festivita", "d").valore.date(), set())


@funzione_libreria("e_festivo")
def e_festivo(d, extra=None):
    """e_festivo(d, extra = nulla): `vero` se il giorno è domenica o una festività nazionale italiana.

    `extra` aggiunge feste locali ripetute ogni anno, per esempio il patrono: `extra = ["07/12"]`.
    Esempi: `e_festivo("06/04/2026")` è `vero` (Pasquetta); `e_festivo("07/04/2026")` è `falso`.
    """
    giorno = _data(d, "e_festivo", "d").valore.date()
    return giorno.weekday() == 6 or _nome_festa(giorno, _extra(extra, "e_festivo")) is not None


def _lavorativo(giorno: datetime.date, sabato: bool, extra: set[tuple[int, int]]) -> bool:
    if giorno.weekday() == 6 or (giorno.weekday() == 5 and not sabato):
        return False
    return _nome_festa(giorno, extra) is None


@funzione_libreria("e_giorno_lavorativo")
def e_giorno_lavorativo(d, sabato_lavorativo=False, extra=None):
    """e_giorno_lavorativo(d, sabato_lavorativo = falso, extra = nulla): `vero` se non è sabato, domenica o festa.

    Esempio: `e_giorno_lavorativo(data(2026, 12, 24))` è `vero`; `e_giorno_lavorativo(data(2026, 12, 25))` è `falso`.
    """
    giorno = _data(d, "e_giorno_lavorativo", "d").valore.date()
    richiedi_logico(sabato_lavorativo, "e_giorno_lavorativo", "sabato_lavorativo")
    return _lavorativo(giorno, sabato_lavorativo, _extra(extra, "e_giorno_lavorativo"))


MASSIMI_GIORNI_CONTATI = 200 * 366


@funzione_libreria("giorni_lavorativi")
def giorni_lavorativi(da, a, sabato_lavorativo=False, extra=None):
    """giorni_lavorativi(da, a, sabato_lavorativo = falso, extra = nulla): quanti giorni lavorativi ci sono da una data all'altra (comprese).

    Salta sabati (se non lavorativi), domeniche e festività nazionali italiane (e quelle in `extra`).
    Se `a` viene prima di `da` il risultato è negativo.
    Esempio: `giorni_lavorativi("01/12/2026", "31/12/2026")` è 21.
    """
    inizio = _data(da, "giorni_lavorativi", "da").valore.date()
    fine = _data(a, "giorni_lavorativi", "a").valore.date()
    richiedi_logico(sabato_lavorativo, "giorni_lavorativi", "sabato_lavorativo")
    feste = _extra(extra, "giorni_lavorativi")
    segno = 1
    if fine < inizio:
        inizio, fine, segno = fine, inizio, -1
    if (fine - inizio).days > MASSIMI_GIORNI_CONTATI:
        raise ErroreValore("L'intervallo è troppo lungo per `giorni_lavorativi` (al massimo 200 anni).")
    conteggio, giorno, uno = 0, inizio, datetime.timedelta(days=1)
    while giorno <= fine:
        if _lavorativo(giorno, sabato_lavorativo, feste):
            conteggio += 1
        if giorno == datetime.date.max:
            break
        giorno += uno
    return segno * conteggio


@funzione_libreria("aggiungi_giorni_lavorativi")
def aggiungi_giorni_lavorativi(d, giorni, sabato_lavorativo=False, extra=None):
    """aggiungi_giorni_lavorativi(d, giorni, sabato_lavorativo = falso, extra = nulla): la data dopo tanti giorni lavorativi.

    Con un numero negativo va indietro. Serve per scadenze come "entro 10 giorni lavorativi".
    Esempio: `aggiungi_giorni_lavorativi("24/12/2026", 1)` è 28/12/2026 (salta Natale, S. Stefano e la domenica).
    """
    partenza = _data(d, "aggiungi_giorni_lavorativi", "d")
    richiedi_intero(giorni, "aggiungi_giorni_lavorativi", "giorni")
    richiedi_logico(sabato_lavorativo, "aggiungi_giorni_lavorativi", "sabato_lavorativo")
    feste = _extra(extra, "aggiungi_giorni_lavorativi")
    if abs(giorni) > 50_000:
        raise ErroreValore("Troppi giorni lavorativi da aggiungere (al massimo 50000).")
    passo = datetime.timedelta(days=1 if giorni >= 0 else -1)
    giorno, mancano = partenza.valore.date(), abs(giorni)
    try:
        while mancano:
            giorno += passo
            if _lavorativo(giorno, sabato_lavorativo, feste):
                mancano -= 1
    except OverflowError:
        raise ErroreValore("La data risultante è fuori dal calendario (anni da 1 a 9999).") from None
    orario = partenza.valore.time()
    return DataDante(datetime.datetime.combine(giorno, orario))


# ===========================================================================
# Età
# ===========================================================================

@funzione_libreria("calcola_eta")
def calcola_eta(nascita, alla_data=None, completa=False):
    """calcola_eta(nascita, alla_data = nulla, completa = falso): gli anni compiuti da chi è nato in quella data (a oggi).

    Con `completa = vero` restituisce un dizionario con "anni", "mesi" e "giorni".
    Chi è nato il 29 febbraio compie gli anni il 1° marzo negli anni non bisestili.
    Esempi: `calcola_eta("15/03/2000", alla_data = "14/03/2026")` è 25;
    `calcola_eta("15/03/2000", "20/05/2026", completa = vero)` è {"anni": 26, "mesi": 2, "giorni": 5}.
    """
    n = _data(nascita, "calcola_eta", "nascita").valore.date()
    oggi = _data_o_oggi(alla_data, "calcola_eta", "alla_data").valore.date()
    richiedi_logico(completa, "calcola_eta", "completa")
    if oggi < n:
        raise ErroreValore(f"La data di nascita ({n.day:02d}/{n.month:02d}/{n.year}) viene dopo "
                           f"la data del calcolo ({oggi.day:02d}/{oggi.month:02d}/{oggi.year}).")
    mesi = (oggi.year - n.year) * 12 + oggi.month - n.month
    if oggi.day < n.day:
        mesi -= 1
    anni = mesi // 12
    if not completa:
        return anni
    # giorni dall'ultimo "mesiversario"
    anno_m, mese_m = divmod(n.year * 12 + n.month - 1 + mesi, 12)
    import calendar
    ultimo = calendar.monthrange(anno_m, mese_m + 1)[1]
    riferimento = datetime.date(anno_m, mese_m + 1, min(n.day, ultimo))
    return {"anni": anni, "mesi": mesi % 12, "giorni": (oggi - riferimento).days}


# ===========================================================================
# Durate
# ===========================================================================

def _secondi(valore: Any, nome_funzione: str) -> float:
    richiedi_numero(valore, nome_funzione, "secondi")
    if isinstance(valore, float) and math.isnan(valore):
        raise ErroreValore(f"`{nome_funzione}` non può usare `non_numero`.")
    if abs(valore) > MASSIMA_DURATA:
        raise ErroreValore(f"La durata data a `{nome_funzione}` è troppo lunga (al massimo 10000 anni).")
    return valore


@funzione_libreria("durata_in_parole")
def durata_in_parole(secondi, con_secondi=True):
    """durata_in_parole(secondi, con_secondi = vero): una durata scritta per esteso in italiano.

    Esempi: `durata_in_parole(3725)` è "1 ora, 2 minuti e 5 secondi"; `durata_in_parole(90061)` è
    "1 giorno, 1 ora, 1 minuto e 1 secondo"; `durata_in_parole(0)` è "0 secondi".
    """
    s = _secondi(secondi, "durata_in_parole")
    richiedi_logico(con_secondi, "durata_in_parole", "con_secondi")
    totale = int(round(abs(s))) if con_secondi else int(round(abs(s) / 60)) * 60
    giorni, resto = divmod(totale, 86_400)
    ore, resto = divmod(resto, 3600)
    minuti, sec = divmod(resto, 60)
    parti = []
    for n, uno, tanti in ((giorni, "giorno", "giorni"), (ore, "ora", "ore"), (minuti, "minuto", "minuti"),
                          (sec if con_secondi else 0, "secondo", "secondi")):
        if n:
            parti.append(f"{n} {uno if n == 1 else tanti}")
    if not parti:
        return "0 secondi" if con_secondi else "0 minuti"
    testo = parti[0] if len(parti) == 1 else ", ".join(parti[:-1]) + " e " + parti[-1]
    return ("meno " + testo) if s < 0 and totale else testo


@funzione_libreria("formatta_durata")
def formatta_durata(secondi, decimi=False):
    """formatta_durata(secondi, decimi = falso): una durata come "hh:mm:ss" (le ore possono superare 24).

    Esempi: `formatta_durata(3725)` è "01:02:05"; `formatta_durata(65.4, decimi = vero)` è "00:01:05.4".
    """
    s = _secondi(secondi, "formatta_durata")
    richiedi_logico(decimi, "formatta_durata", "decimi")
    segno = "-" if s < 0 else ""
    decimi_tot = int(round(abs(s) * 10)) if decimi else int(round(abs(s))) * 10
    interi, frazione = divmod(decimi_tot, 10)
    ore, resto = divmod(interi, 3600)
    minuti, sec = divmod(resto, 60)
    testo = f"{segno}{ore:02d}:{minuti:02d}:{sec:02d}"
    return testo + f".{frazione}" if decimi else testo


# ===========================================================================
# Conto alla rovescia
# ===========================================================================

class ContoAllaRovescia(OggettoLibreria):
    """Valore Leo di tipo ``conto_alla_rovescia``: quanto manca a una scadenza."""

    NOME_TIPO_DANTE = "conto_alla_rovescia"
    SUGGERIMENTO_MODIFICA = "Per cambiarlo usa `c.aggiungi(secondi)` o `c.azzera()`."

    def __init__(self, durata: float) -> None:
        self.durata = float(durata)
        self.scadenza = time.monotonic() + self.durata
        self.fermo_a: float | None = None  # secondi rimasti al momento della pausa

    def rimasti(self) -> float:
        if self.fermo_a is not None:
            return max(0.0, self.fermo_a)
        return max(0.0, self.scadenza - time.monotonic())

    def testo_dante(self) -> str:
        stato = ", fermo" if self.fermo_a is not None else ""
        return f"<conto alla rovescia {formatta_durata(math.ceil(self.rimasti()))}{stato}>"


@funzione_libreria("conto_alla_rovescia")
def conto_alla_rovescia(durata):
    """conto_alla_rovescia(durata): parte un conto alla rovescia di tanti secondi, oppure fino a una data.

    Non blocca il programma: si legge quando serve. Proprietà: `secondi_rimasti` (con 3 decimali),
    `secondi_interi`, `scaduto`, `testo` ("00:04:59"), `in_parole`. Metodi: `ferma()`, `riprendi()`,
    `azzera()`, `aggiungi(secondi)`.
    Esempi: `variabile c = conto_alla_rovescia(300)` e poi `se c.scaduto allora stampa("Tempo!") fine`;
    `conto_alla_rovescia(data(2026, 12, 25)).in_parole`.
    """
    if isinstance(durata, (DataDante, str)):
        obiettivo = _data(durata, "conto_alla_rovescia", "durata").valore
        secondi = (obiettivo - datetime.datetime.now()).total_seconds()
        return ContoAllaRovescia(max(0.0, secondi))
    s = _secondi(durata, "conto_alla_rovescia")
    if s < 0 or (isinstance(s, float) and math.isinf(s)):
        raise ErroreValore(f"La durata del conto alla rovescia non può essere {rappresenta(s)}.",
                           suggerimento="Scrivi quanti secondi deve durare, per esempio `conto_alla_rovescia(60)`.")
    return ContoAllaRovescia(s)


proprieta(ContoAllaRovescia, "secondi_rimasti")(lambda c: round(c.rimasti(), 3))
proprieta(ContoAllaRovescia, "secondi_interi")(lambda c: math.ceil(c.rimasti()))
proprieta(ContoAllaRovescia, "scaduto")(lambda c: c.rimasti() <= 0)
proprieta(ContoAllaRovescia, "in_corsa")(lambda c: c.fermo_a is None and c.rimasti() > 0)
proprieta(ContoAllaRovescia, "testo")(lambda c: formatta_durata(math.ceil(c.rimasti())))
proprieta(ContoAllaRovescia, "in_parole")(lambda c: durata_in_parole(math.ceil(c.rimasti())))


@metodo_oggetto(ContoAllaRovescia, "ferma")
def conto_ferma(c):
    """conto_alla_rovescia.ferma(): mette in pausa il conto (il tempo rimasto non scende più)."""
    if c.fermo_a is None:
        c.fermo_a = c.rimasti()
    return None


@metodo_oggetto(ContoAllaRovescia, "riprendi")
def conto_riprendi(c):
    """conto_alla_rovescia.riprendi(): fa ripartire un conto messo in pausa con `ferma()`."""
    if c.fermo_a is not None:
        c.scadenza = time.monotonic() + c.fermo_a
        c.fermo_a = None
    return None


@metodo_oggetto(ContoAllaRovescia, "azzera")
def conto_azzera(c):
    """conto_alla_rovescia.azzera(): ricomincia da capo con la durata iniziale."""
    c.scadenza = time.monotonic() + c.durata
    c.fermo_a = None
    return None


@metodo_oggetto(ContoAllaRovescia, "aggiungi")
def conto_aggiungi(c, secondi):
    """conto_alla_rovescia.aggiungi(secondi): aggiunge (o toglie, se negativi) secondi al tempo rimasto."""
    s = _secondi(secondi, "aggiungi")
    if isinstance(s, float) and math.isinf(s):
        raise ErroreValore("Non posso aggiungere un tempo infinito.")
    if c.fermo_a is not None:
        c.fermo_a = max(0.0, c.fermo_a + s)
    else:
        c.scadenza = max(time.monotonic(), c.scadenza) + s
    return None


# ===========================================================================
# Giri del cronometro (aggiunte al tipo `cronometro` di caso_e_tempo)
# ===========================================================================

def _giri(c: Cronometro) -> list[float]:
    giri = getattr(c, "_tempi_giro", None)
    if giri is None:
        giri = []
        c._tempi_giro = giri  # type: ignore[attr-defined]
    return giri


@metodo_oggetto(Cronometro, "segna_giro")
def cronometro_segna_giro(c):
    """cronometro.segna_giro(): registra un giro e restituisce quanto è durato (in secondi, 3 decimali).

    I tempi di tutti i giri si leggono con `c.tempi_giro`. Esempio: `stampa("Giro:", c.segna_giro())`.
    """
    giri = _giri(c)
    adesso = c.trascorso()
    ultimo = getattr(c, "_fine_ultimo_giro", 0.0)
    if adesso < ultimo:  # il cronometro è stato azzerato
        giri.clear()
        ultimo = 0.0
    durata = round(adesso - ultimo, 3)
    giri.append(durata)
    c._fine_ultimo_giro = adesso  # type: ignore[attr-defined]
    return durata


proprieta(Cronometro, "tempi_giro")(lambda c: list(_giri(c)))
