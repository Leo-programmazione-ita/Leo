"""Libreria "piattaforma": primitivi di sistema uguali su ogni computer.

Qui stanno le poche informazioni di sistema che mancavano e che funzionano
senza cambiare niente su Windows, Linux, macOS e Android:

* **processori e carico**: ``numero_cpu``, ``carico_sistema``;
* **programmi e processi**: ``cerca_eseguibile``, ``percorsi_eseguibili``,
  ``pid_genitore``;
* **percorsi portabili**: ``separatore_cartelle``, ``separatore_percorsi``,
  ``a_capo_sistema``.

Sono tutti primitivi neutri che *leggono* la configurazione del computer: non
cambiano niente e non eseguono niente, quindi non chiedono permessi. Per il
resto del "sistema" guarda le altre librerie già presenti: ``sistema_operativo``,
``memoria_sistema``, ``spazio_disco`` e i processi (``rete_sistema``), le
informazioni e l'amministratore (``computer``), i file e le cartelle
(``cartelle``), i comandi e le variabili d'ambiente (``sistema``).
"""

from __future__ import annotations

import os
import shutil

from ..errori import ErroreValore
from .generali import funzione_libreria, richiedi_testo


@funzione_libreria("numero_cpu")
def numero_cpu():
    """numero_cpu(): quanti processori (core logici) ha il computer, come numero intero.

    Funziona su Windows, Linux, macOS e Android. È almeno 1.
    Esempio: `stampa("Ho {numero_cpu()} processori")`.
    """
    return os.cpu_count() or 1


@funzione_libreria("carico_sistema")
def carico_sistema():
    """carico_sistema(): quanto è carico il computer in media negli ultimi 1, 5 e 15 minuti.

    Restituisce un dizionario con "minuto_1", "minuti_5", "minuti_15" (numeri:
    quanti processi in media chiedevano la CPU) e "testo". Su Windows questa
    media non esiste e la funzione restituisce `nulla`.
    Esempio: `se carico_sistema() != nulla e carico_sistema()["minuto_1"] > numero_cpu() allora stampa("Computer sotto sforzo") fine`.
    """
    try:
        uno, cinque, quindici = os.getloadavg()
    except (OSError, AttributeError):
        # os.getloadavg non c'è su Windows (e in casi rari altrove): nessun errore, solo `nulla`.
        return None
    uno, cinque, quindici = round(uno, 2), round(cinque, 2), round(quindici, 2)
    testo = f"{uno} (1 min), {cinque} (5 min), {quindici} (15 min)".replace(".", ",")
    return {"minuto_1": uno, "minuti_5": cinque, "minuti_15": quindici, "testo": testo}


@funzione_libreria("cerca_eseguibile")
def cerca_eseguibile(nome):
    """cerca_eseguibile(nome): dove si trova il programma `nome`, cercandolo come farebbe il sistema; `nulla` se non c'è.

    Cerca nelle cartelle del PERCORSO (variabile PATH) e, su Windows, prova anche
    le estensioni giuste (.exe, .bat...). Utile prima di `esegui_comando` per
    sapere se un programma è installato.
    Funziona su Windows, Linux, macOS e Android.
    Esempio: `se cerca_eseguibile("git") != nulla allora stampa("Git è installato") fine`.
    """
    richiedi_testo(nome, "cerca_eseguibile", "nome")
    pulito = nome.strip()
    if not pulito:
        raise ErroreValore("Il `nome` del programma da cercare è vuoto.",
                           suggerimento='Scrivi il nome di un programma, per esempio `cerca_eseguibile("python")`.')
    return shutil.which(pulito)


@funzione_libreria("percorsi_eseguibili")
def percorsi_eseguibili():
    """percorsi_eseguibili(): la lista delle cartelle dove il sistema cerca i programmi (la variabile PATH).

    Sono le stesse cartelle in cui guarda `cerca_eseguibile`. L'ordine conta: il
    sistema usa la prima dove trova il programma.
    Funziona su Windows, Linux, macOS e Android.
    Esempio: `per ogni cartella in percorsi_eseguibili() fai stampa(cartella) fine`.
    """
    grezzo = os.environ.get("PATH", "")
    visti: set[str] = set()
    elenco = []
    for parte in grezzo.split(os.pathsep):
        parte = parte.strip()
        if parte and parte not in visti:
            visti.add(parte)
            elenco.append(parte)
    return elenco


@funzione_libreria("pid_genitore")
def pid_genitore():
    """pid_genitore(): il numero (PID) del processo che ha avviato questo programma.

    Fa coppia con `pid_corrente()`, che dà il numero di questo programma.
    Funziona su Windows, Linux, macOS e Android.
    Esempio: `stampa("Mi ha avviato il processo {pid_genitore()}")`.
    """
    return os.getppid()


@funzione_libreria("separatore_cartelle")
def separatore_cartelle():
    """separatore_cartelle(): il segno che separa le cartelle nei percorsi di questo sistema ("/" o "\\\\").

    Su Windows è "\\\\", su Linux, macOS e Android è "/". Per unire i pezzi di un
    percorso è di solito meglio `unisci_percorso`, che lo fa già da sé.
    Esempio: `stampa(separatore_cartelle())`.
    """
    return os.sep


@funzione_libreria("separatore_percorsi")
def separatore_percorsi():
    """separatore_percorsi(): il segno che separa più percorsi in un elenco come PATH (";" o ":").

    Su Windows è ";", su Linux, macOS e Android è ":". È lo stesso segno che
    separa le cartelle restituite da `percorsi_eseguibili`.
    Esempio: `stampa(separatore_percorsi())`.
    """
    return os.pathsep


@funzione_libreria("a_capo_sistema")
def a_capo_sistema():
    """a_capo_sistema(): il segno di "a capo" preferito da questo sistema ("\\r\\n" su Windows, "\\n" altrove).

    Serve quando devi scrivere un file di testo rispettando le abitudini del
    sistema. Di solito scrivendo i file con Leo non ti serve pensarci.
    Esempio: `stampa(rappresenta(a_capo_sistema()))`.
    """
    return os.linesep
