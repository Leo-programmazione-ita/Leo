"""Libreria: il database SQLite "senza SQL", seconda parte.

Aggiunge al tipo ``database`` (vedi :mod:`leo.libreria.database`) i metodi per:

* leggere: ``esiste``, ``riga``, ``ultimo``, ``valori``, ``distinti``, ``pagina``,
  ``riga_a_caso``, ``cerca_testo``;
* calcolare: ``somma``, ``media``, ``minimo``, ``massimo``, ``conta_per``, ``raggruppa``;
* collegare le tabelle: ``unisci``;
* scrivere: ``inserisci_o_aggiorna``, ``importa_righe``, ``elimina_duplicati``;
* cambiare la struttura: ``aggiungi_colonna``, ``rinomina_tabella``, ``rinomina_colonna``,
  ``copia_tabella``, ``crea_indice``, ``esiste_tabella``, ``struttura``;
* file e manutenzione: ``esporta_json``, ``importa_json``, ``copia_di_sicurezza``,
  ``compatta``; SQL per chi lo conosce: ``valore_sql``;
* mostrare: ``stampa_tabella``;

e le funzioni ``database_di_esempio()`` ed ``e_database(percorso)``.

Il modulo si importa da solo quando si apre il primo database (vedi
``Database.__init__``), così i metodi ci sono sempre.

Sicurezza: come in ``database.py`` i valori passano SEMPRE come parametri ``?``;
i nomi di tabelle e colonne sono controllati (solo lettere, cifre e ``_``) e
verificati sulla tabella vera. L'unica eccezione è il valore ``predefinito`` di
``aggiungi_colonna`` con ``obbligatorio`` (SQLite non accetta parametri in
``DEFAULT``): lì il valore è controllato (solo numeri, testi, logici o date) e
scritto con le regole di SQLite per i testi (apici raddoppiati).
"""

from __future__ import annotations

import json
import os
import re
import sqlite3
import unicodedata
from typing import Any

from ..errori import ErroreFile, ErroreTipo, ErroreValore
from ..grafica.servizi.bancadati import (_COLLEGAMENTO, _SINONIMI_TIPO, TIPI_COLONNA, _identificatore, _q,
                                         _testo_data, _traduci, _valore_in, data_da_testo)
from ..valori import rappresenta
from .database import Database, _apri, _condizioni, _in_blocco, _limite, db_esegui
from .date import DataDante
from .generali import articolo, funzione_libreria, mostra, richiedi_logico, richiedi_testo
from .ingresso_uscita import _controlla_percorso
from .oggetti import metodo_oggetto

__all__ = ["database_di_esempio", "e_database"]


# ---------------------------------------------------------------------------
# Utilità interne
# ---------------------------------------------------------------------------

def _tab(db: Database, tabella: Any) -> str:
    return db.motore._richiedi_tabella(tabella)


def _col(db: Database, tabella: str, colonna: Any) -> str:
    return db.motore._colonna(tabella, colonna)


def _info(db: Database, tabella: str) -> dict[str, str]:
    return db.motore._info(tabella)


def _esegui(db: Database, sql: str, parametri: Any = (), contesto: str = "") -> sqlite3.Cursor:
    return db.motore._esegui(sql, parametri, contesto)


def _leggi(db: Database, cursore: sqlite3.Cursor, logiche: set | None = None,
           date: set | None = None) -> list[dict]:
    return db.motore._righe(cursore, logiche, date)


def _tipi_speciali(db: Database, tabella: str) -> tuple[set, set]:
    return db.motore._colonne_logiche(tabella), db.motore._colonne_data(tabella)


def _dove(db: Database, tabella: str, condizioni: Any, filtri: dict, metodo: str) -> tuple[str, list]:
    return db.motore._dove(tabella, _condizioni(condizioni, metodo, filtri))


def _converti_uscita(db: Database, tabella: str, colonna: str, valore: Any) -> Any:
    """Un valore letto con SQL "a mano" come lo restituirebbe `cerca`."""
    tipo = _info(db, tabella).get(colonna)
    if valore is None:
        return None
    if tipo == "LOGICO":
        return bool(valore)
    if tipo == "DATA" and isinstance(valore, str):
        d = data_da_testo(valore)
        return DataDante(d) if d is not None else valore
    if isinstance(valore, bytes):
        return valore.decode("utf-8", errors="replace")
    return valore


def _chiave_primaria(db: Database, tabella: str) -> str:
    """Il nome della colonna chiave (``id`` di solito) o ``rowid`` se non ce n'è una sola."""
    righe = _esegui(db, f"PRAGMA table_info({_q(tabella)})").fetchall()
    chiavi = [r[1] for r in righe if r[5]]
    return chiavi[0] if len(chiavi) == 1 else "rowid"


def _nome_uscita(nome: Any, cosa: str) -> str:
    return _identificatore(nome, cosa)


def _elenco_colonne(db: Database, tabella: str, colonne: Any, metodo: str) -> list[str]:
    if isinstance(colonne, str):
        colonne = [c for c in colonne.split(",") if c.strip()]
    if not isinstance(colonne, list) or not colonne:
        raise ErroreTipo(f"`{metodo}` vuole il nome di una colonna o una lista di nomi, non {articolo(colonne)}.",
                         suggerimento="Esempi: \"classe\", [\"cognome\", \"nome\"].")
    return [_col(db, tabella, c.strip() if isinstance(c, str) else c) for c in colonne]


def _numerica(db: Database, tabella: str, colonna: str, metodo: str) -> None:
    tipo = _info(db, tabella).get(colonna, "")
    if tipo in ("TEXT", "DATA", "LOGICO"):
        spiegazione = {"TEXT": "testi", "DATA": "date", "LOGICO": "valori sì/no"}[tipo]
        raise ErroreTipo(f"La colonna `{colonna}` contiene {spiegazione}: `{metodo}` vuole una colonna di numeri.",
                         suggerimento="Per contare quante righe ci sono per ogni valore usa `conta_per`.")


# ---------------------------------------------------------------------------
# Leggere
# ---------------------------------------------------------------------------

@metodo_oggetto(Database, "esiste")
def db_esiste(db, tabella, /, condizioni=None, **filtri):
    """db.esiste(tabella, condizioni = nulla): `vero` se c'è almeno una riga che rispetta le condizioni.

    Esempio: `se db.esiste("alunni", nome = "Ada") allora stampa("trovata") fine`.
    """
    with db.motore._blocco:
        nome = _tab(db, tabella)
        dove, parametri = _dove(db, nome, condizioni, filtri, "esiste")
        return _esegui(db, f"SELECT 1 FROM {_q(nome)}{dove} LIMIT 1", parametri,
                       f"Ricerca in `{nome}`").fetchone() is not None


@metodo_oggetto(Database, "riga")
def db_riga(db, tabella, id):
    """db.riga(tabella, id): la riga con quell'`id` (la chiave della tabella), o `nulla` se non c'è.

    Esempio: `variabile ada = db.riga("alunni", 1)`, poi `stampa(ada["nome"])`.
    """
    with db.motore._blocco:
        nome = _tab(db, tabella)
        chiave = _chiave_primaria(db, nome)
        cursore = _esegui(db, f"SELECT * FROM {_q(nome)} WHERE {_q(chiave) if chiave != 'rowid' else 'rowid'} = ?",
                          [_valore_in(id, "id")], f"Ricerca in `{nome}`")
        righe = _leggi(db, cursore, *_tipi_speciali(db, nome))
        return righe[0] if righe else None


_VERSO = re.compile(r'" (ASC|DESC)(?=,|$)')


@metodo_oggetto(Database, "ultimo")
def db_ultimo(db, tabella, /, condizioni=None, ordina="", **filtri):
    """db.ultimo(tabella, condizioni = nulla, ordina = ""): l'ultima riga (l'ultima inserita, o l'ultima nell'ordine dato).

    Restituisce `nulla` se non ci sono righe. Esempi: `db.ultimo("messaggi")`,
    `db.ultimo("voti", ordina = "voto")` (il voto più alto).
    """
    with db.motore._blocco:
        nome = _tab(db, tabella)
        dove, parametri = _dove(db, nome, condizioni, filtri, "ultimo")
        ordine = db.motore._ordine(nome, ordina)
        if ordine:
            ordine = _VERSO.sub(lambda m: '" ' + ("DESC" if m.group(1) == "ASC" else "ASC"), ordine)
        else:
            ordine = " ORDER BY rowid DESC"
        cursore = _esegui(db, f"SELECT * FROM {_q(nome)}{dove}{ordine} LIMIT 1", parametri, f"Ricerca in `{nome}`")
        righe = _leggi(db, cursore, *_tipi_speciali(db, nome))
        return righe[0] if righe else None


@metodo_oggetto(Database, "valori")
def db_valori(db, tabella, colonna, /, condizioni=None, ordina="", **filtri):
    """db.valori(tabella, colonna, condizioni = nulla, ordina = ""): la lista dei valori di una sola colonna.

    Esempio: `db.valori("alunni", "nome", classe = "5A", ordina = "nome")` dà ["Ada", "Bruno", ...].
    """
    with db.motore._blocco:
        nome = _tab(db, tabella)
        c = _col(db, nome, colonna)
        dove, parametri = _dove(db, nome, condizioni, filtri, "valori")
        ordine = db.motore._ordine(nome, ordina) or " ORDER BY rowid"
        cursore = _esegui(db, f"SELECT {_q(c)} FROM {_q(nome)}{dove}{ordine}", parametri, f"Ricerca in `{nome}`")
        return [_converti_uscita(db, nome, c, r[0]) for r in cursore.fetchall()]


@metodo_oggetto(Database, "distinti")
def db_distinti(db, tabella, colonna, /, condizioni=None, **filtri):
    """db.distinti(tabella, colonna, condizioni = nulla): i valori diversi di una colonna, in ordine, senza ripetizioni.

    I valori vuoti (`nulla`) non ci sono. Esempio: `db.distinti("alunni", "classe")` dà ["5A", "5B"].
    """
    with db.motore._blocco:
        nome = _tab(db, tabella)
        c = _col(db, nome, colonna)
        dove, parametri = _dove(db, nome, condizioni, filtri, "distinti")
        dove = f"{dove} AND {_q(c)} IS NOT NULL" if dove else f" WHERE {_q(c)} IS NOT NULL"
        cursore = _esegui(db, f"SELECT DISTINCT {_q(c)} FROM {_q(nome)}{dove} ORDER BY {_q(c)}", parametri,
                          f"Ricerca in `{nome}`")
        return [_converti_uscita(db, nome, c, r[0]) for r in cursore.fetchall()]


@metodo_oggetto(Database, "pagina")
def db_pagina(db, tabella, numero, /, per_pagina=10, condizioni=None, ordina="", **filtri):
    """db.pagina(tabella, numero, per_pagina = 10, condizioni = nulla, ordina = ""): le righe della pagina `numero` (da 1).

    Serve per mostrare tante righe un po' alla volta. Esempio:
    `db.pagina("libri", 2, per_pagina = 20, ordina = "titolo")` dà i libri dal 21° al 40°.
    """
    for valore, parametro in ((numero, "numero"), (per_pagina, "per_pagina")):
        if isinstance(valore, bool) or not isinstance(valore, int):
            raise ErroreTipo(f"`{parametro}` di `pagina` deve essere un intero, non {articolo(valore)}.")
        if valore < 1:
            raise ErroreValore(f"`{parametro}` di `pagina` deve essere almeno 1 (la prima pagina è la 1).")
    with db.motore._blocco:
        nome = _tab(db, tabella)
        dove, parametri = _dove(db, nome, condizioni, filtri, "pagina")
        ordine = db.motore._ordine(nome, ordina) or " ORDER BY rowid"
        cursore = _esegui(db, f"SELECT * FROM {_q(nome)}{dove}{ordine} LIMIT ? OFFSET ?",
                          parametri + [per_pagina, (numero - 1) * per_pagina], f"Ricerca in `{nome}`")
        return _leggi(db, cursore, *_tipi_speciali(db, nome))


@metodo_oggetto(Database, "riga_a_caso")
def db_riga_a_caso(db, tabella, /, condizioni=None, **filtri):
    """db.riga_a_caso(tabella, condizioni = nulla): una riga scelta a caso (o `nulla` se non ce ne sono).

    Ottima per i quiz. Esempio: `variabile domanda = db.riga_a_caso("domande", livello = 1)`.
    """
    from .matematica import GENERATORE

    with db.motore._blocco:
        nome = _tab(db, tabella)
        dove, parametri = _dove(db, nome, condizioni, filtri, "riga_a_caso")
        quante = _esegui(db, f"SELECT COUNT(*) FROM {_q(nome)}{dove}", parametri).fetchone()[0]
        if not quante:
            return None
        cursore = _esegui(db, f"SELECT * FROM {_q(nome)}{dove} ORDER BY rowid LIMIT 1 OFFSET ?",
                          parametri + [GENERATORE.randrange(quante)], f"Ricerca in `{nome}`")
        righe = _leggi(db, cursore, *_tipi_speciali(db, nome))
        return righe[0] if righe else None


def _normale(testo: Any) -> Any:
    """Minuscole e senza accenti: "Città" -> "citta" (per la ricerca nel testo)."""
    if not isinstance(testo, str):
        return None if testo is None else _normale(str(testo))
    scomposto = unicodedata.normalize("NFD", testo.casefold())
    return "".join(c for c in scomposto if not unicodedata.combining(c))


@metodo_oggetto(Database, "cerca_testo")
def db_cerca_testo(db, tabella, testo, /, colonne=None, ordina="", limite=0):
    """db.cerca_testo(tabella, testo, colonne = nulla, ordina = "", limite = 0): le righe che contengono le parole cercate.

    Ogni parola deve comparire in almeno una colonna; maiuscole e accenti non contano
    ("citta" trova "Città"). Senza `colonne` cerca in tutte le colonne di testo.
    Esempio: `db.cerca_testo("libri", "principe piccolo", colonne = ["titolo", "autore"])`.
    """
    richiedi_testo(testo, "cerca_testo", "testo")
    parole = [_normale(p) for p in testo.split()]
    if not parole:
        raise ErroreValore("`cerca_testo` vuole almeno una parola da cercare.",
                           suggerimento="Esempio: `db.cerca_testo(\"libri\", \"pinocchio\")`.")
    with db.motore._blocco:
        nome = _tab(db, tabella)
        if colonne is None:
            scelte = [c for c, t in _info(db, nome).items() if t in ("TEXT", "")]
            if not scelte:
                raise ErroreValore(f"La tabella `{nome}` non ha colonne di testo in cui cercare.",
                                   suggerimento="Indica le colonne con `colonne = [...]`.")
        else:
            scelte = _elenco_colonne(db, nome, colonne, "cerca_testo")
        conn = db.motore._conn()
        conn.create_function("leo_normale", 1, _normale, deterministic=True)
        pezzi, parametri = [], []
        for parola in parole:
            pezzi.append("(" + " OR ".join(f"instr(leo_normale({_q(c)}), ?) > 0" for c in scelte) + ")")
            parametri.extend([parola] * len(scelte))
        sql = f"SELECT * FROM {_q(nome)} WHERE {' AND '.join(pezzi)}{db.motore._ordine(nome, ordina)}"
        limite = _limite(limite, "cerca_testo")
        if limite:
            sql += " LIMIT ?"
            parametri.append(limite)
        return _leggi(db, _esegui(db, sql, parametri, f"Ricerca in `{nome}`"), *_tipi_speciali(db, nome))


# ---------------------------------------------------------------------------
# Calcolare
# ---------------------------------------------------------------------------

def _aggregato(db, tabella, colonna, condizioni, filtri, funzione: str, metodo: str, numerica: bool) -> Any:
    with db.motore._blocco:
        nome = _tab(db, tabella)
        c = _col(db, nome, colonna)
        if numerica:
            _numerica(db, nome, c, metodo)
        dove, parametri = _dove(db, nome, condizioni, filtri, metodo)
        valore = _esegui(db, f"SELECT {funzione}({_q(c)}) FROM {_q(nome)}{dove}", parametri,
                         f"Calcolo su `{nome}`").fetchone()[0]
        if funzione == "SUM":
            return 0 if valore is None else valore
        return _converti_uscita(db, nome, c, valore) if funzione in ("MIN", "MAX") else valore


@metodo_oggetto(Database, "somma")
def db_somma(db, tabella, colonna, /, condizioni=None, **filtri):
    """db.somma(tabella, colonna, condizioni = nulla): la somma dei numeri di una colonna (0 se non ci sono righe).

    Esempio: `db.somma("spese", "euro", mese = "marzo")`.
    """
    return _aggregato(db, tabella, colonna, condizioni, filtri, "SUM", "somma", True)


@metodo_oggetto(Database, "media")
def db_media(db, tabella, colonna, /, condizioni=None, **filtri):
    """db.media(tabella, colonna, condizioni = nulla): la media dei numeri di una colonna (`nulla` se non ci sono righe).

    I valori vuoti non contano. Esempio: `db.media("voti", "voto", materia = "storia")`.
    """
    return _aggregato(db, tabella, colonna, condizioni, filtri, "AVG", "media", True)


@metodo_oggetto(Database, "minimo")
def db_minimo(db, tabella, colonna, /, condizioni=None, **filtri):
    """db.minimo(tabella, colonna, condizioni = nulla): il valore più piccolo della colonna (`nulla` se non ci sono righe).

    Funziona con numeri, testi (ordine alfabetico) e date. Esempio: `db.minimo("alunni", "nato")`.
    """
    return _aggregato(db, tabella, colonna, condizioni, filtri, "MIN", "minimo", False)


@metodo_oggetto(Database, "massimo")
def db_massimo(db, tabella, colonna, /, condizioni=None, **filtri):
    """db.massimo(tabella, colonna, condizioni = nulla): il valore più grande della colonna (`nulla` se non ci sono righe).

    Esempio: `db.massimo("voti", "voto", materia = "matematica")`.
    """
    return _aggregato(db, tabella, colonna, condizioni, filtri, "MAX", "massimo", False)


@metodo_oggetto(Database, "conta_per")
def db_conta_per(db, tabella, colonna, /, condizioni=None, **filtri):
    """db.conta_per(tabella, colonna, condizioni = nulla): dizionario valore -> quante righe hanno quel valore.

    Esempio: `db.conta_per("alunni", "classe")` dà {"5A": 12, "5B": 10}.
    """
    with db.motore._blocco:
        nome = _tab(db, tabella)
        c = _col(db, nome, colonna)
        dove, parametri = _dove(db, nome, condizioni, filtri, "conta_per")
        cursore = _esegui(db, f"SELECT {_q(c)}, COUNT(*) FROM {_q(nome)}{dove} GROUP BY {_q(c)} ORDER BY {_q(c)}",
                          parametri, f"Conteggio in `{nome}`")
        return {_converti_uscita(db, nome, c, v): n for v, n in cursore.fetchall()}


_CALCOLI = {"conta": "COUNT", "quanti": "COUNT", "somma": "SUM", "totale": "SUM", "media": "AVG",
            "minimo": "MIN", "massimo": "MAX", "distinti": "COUNT DISTINCT"}


@metodo_oggetto(Database, "raggruppa")
def db_raggruppa(db, tabella, per, /, calcola=None, condizioni=None, ordina="", **filtri):
    """db.raggruppa(tabella, per, calcola = {"quanti": "conta"}, condizioni = nulla, ordina = ""): un riassunto per gruppi.

    `per` è la colonna (o la lista di colonne) che forma i gruppi; `calcola` dice cosa calcolare
    per ogni gruppo: nome del risultato -> "conta", "somma COLONNA", "media COLONNA",
    "minimo COLONNA", "massimo COLONNA" o "distinti COLONNA". Il risultato è una lista di dizionari.
    Esempio: `db.raggruppa("voti", "materia", calcola = {"media": "media voto", "quanti": "conta"})`
    dà [{"materia": "italiano", "media": 7.5, "quanti": 4}, ...].
    """
    if calcola is None:
        calcola = {"quanti": "conta"}
    if not isinstance(calcola, dict) or not calcola:
        raise ErroreTipo(f"`calcola` di `raggruppa` deve essere un dizionario, non {articolo(calcola)}.",
                         suggerimento="Esempio: {\"media\": \"media voto\", \"quanti\": \"conta\"}.")
    with db.motore._blocco:
        nome = _tab(db, tabella)
        gruppi = _elenco_colonne(db, nome, per, "raggruppa")
        scelte = [f"{_q(c)}" for c in gruppi]
        date_uscita = {c for c in gruppi if _info(db, nome).get(c) == "DATA"}
        logiche_uscita = {c for c in gruppi if _info(db, nome).get(c) == "LOGICO"}
        nomi_uscita = list(gruppi)
        for risultato, spiegazione in calcola.items():
            chiave = _nome_uscita(risultato, "colonna del risultato")
            if chiave in nomi_uscita:
                raise ErroreValore(f"Il nome `{chiave}` in `calcola` è già usato.",
                                   suggerimento="Dai a ogni risultato un nome diverso dalle colonne dei gruppi.")
            if isinstance(spiegazione, list):
                parole = [str(p) for p in spiegazione]
            elif isinstance(spiegazione, str):
                parole = spiegazione.split()
            else:
                parole = []
            if not parole or parole[0].lower() not in _CALCOLI or len(parole) > 2:
                raise ErroreValore(f"Non capisco il calcolo {mostra(spiegazione)} per `{chiave}`.",
                                   suggerimento="Scrivi \"conta\", \"somma COLONNA\", \"media COLONNA\", "
                                                "\"minimo COLONNA\", \"massimo COLONNA\" o \"distinti COLONNA\".")
            funzione = _CALCOLI[parole[0].lower()]
            if len(parole) == 1:
                if funzione != "COUNT":
                    raise ErroreValore(f"Per `{parole[0]}` in `{chiave}` serve anche la colonna, per esempio "
                                       f"\"{parole[0]} voto\".")
                scelte.append(f"COUNT(*) AS {_q(chiave)}")
            else:
                c = _col(db, nome, parole[1])
                if funzione in ("SUM", "AVG"):
                    _numerica(db, nome, c, parole[0])
                if funzione == "COUNT DISTINCT":
                    scelte.append(f"COUNT(DISTINCT {_q(c)}) AS {_q(chiave)}")
                elif funzione == "SUM":
                    scelte.append(f"COALESCE(SUM({_q(c)}), 0) AS {_q(chiave)}")
                else:
                    scelte.append(f"{funzione}({_q(c)}) AS {_q(chiave)}")
                if funzione in ("MIN", "MAX"):
                    tipo = _info(db, nome).get(c)
                    if tipo == "DATA":
                        date_uscita.add(chiave)
                    elif tipo == "LOGICO":
                        logiche_uscita.add(chiave)
            nomi_uscita.append(chiave)
        dove, parametri = _dove(db, nome, condizioni, filtri, "raggruppa")

        def valida(colonna: Any) -> str:
            n = _identificatore(colonna, "colonna")
            if n not in nomi_uscita:
                raise ErroreValore(f"Non posso ordinare per `{n}`: non è nel risultato.",
                                   suggerimento="Puoi ordinare per: " + ", ".join(f"`{x}`" for x in nomi_uscita) + ".")
            return n

        ordine = db.motore._ordine(nome, ordina, valida) or " ORDER BY " + ", ".join(_q(c) for c in gruppi)
        sql = (f"SELECT {', '.join(scelte)} FROM {_q(nome)}{dove} GROUP BY "
               f"{', '.join(_q(c) for c in gruppi)}{ordine}")
        return _leggi(db, _esegui(db, sql, parametri, f"Raggruppamento di `{nome}`"), logiche_uscita, date_uscita)


# ---------------------------------------------------------------------------
# Collegare le tabelle
# ---------------------------------------------------------------------------

def _singolari(nome: str) -> list[str]:
    """Possibili singolari italiani: "classi" -> classe, classo, classa; "voti" -> voto..."""
    if len(nome) < 3 or nome[-1] not in "ieah":
        return []
    radice = nome[:-1]
    if nome.endswith("chi") or nome.endswith("ghi"):
        radice = nome[:-2]
    return [radice + finale for finale in ("o", "a", "e")]


def _collegamento(db: Database, prima: str, seconda: str) -> tuple[str, str] | None:
    """(colonna di `prima`, colonna di `seconda`) che le collegano, indovinati."""
    for tabella, altra, inverti in ((prima, seconda, False), (seconda, prima, True)):
        for r in _esegui(db, f"PRAGMA foreign_key_list({_q(tabella)})").fetchall():
            if r[2] == altra:
                verso = r[4] or _chiave_primaria(db, altra)
                if verso == "rowid":
                    verso = "id"
                coppia = (r[3], verso)
                return (coppia[1], coppia[0]) if inverti else coppia
    for tabella, altra, inverti in ((prima, seconda, False), (seconda, prima, True)):
        colonne = _info(db, tabella)
        chiave = _chiave_primaria(db, altra)
        if chiave == "rowid":
            continue
        for base in [altra] + _singolari(altra):
            for candidata in (f"{base}_id", f"id_{base}", f"{base}_{chiave}"):
                if candidata in colonne and candidata != chiave:
                    return (chiave, candidata) if inverti else (candidata, chiave)
    return None


@metodo_oggetto(Database, "unisci")
def db_unisci(db, tabella, altra, /, collega=None, condizioni=None, ordina="", limite=0, anche_senza=False):
    """db.unisci(tabella, altra, collega = nulla, condizioni = nulla, ordina = "", limite = 0, anche_senza = falso): unisce le righe collegate di due tabelle.

    Ogni riga di `tabella` si unisce alla riga di `altra` a cui è collegata. Leo trova da solo
    il collegamento se una colonna è `collegato ALTRA` oppure si chiama come `classe_id` (per la
    tabella `classi`); altrimenti scrivi `collega = {"colonna_di_tabella": "colonna_di_altra"}`.
    Le colonne di `altra` con lo stesso nome di una di `tabella` diventano `altra_colonna`
    (per esempio `classi_nome`). Con `anche_senza = vero` restano anche le righe senza collegamento.
    Esempio: `db.unisci("alunni", "classi", ordina = "classi_nome, cognome")`.
    """
    richiedi_logico(anche_senza, "unisci", "anche_senza")
    with db.motore._blocco:
        prima = _tab(db, tabella)
        seconda = _tab(db, altra)
        if prima == seconda:
            raise ErroreValore("`unisci` vuole due tabelle diverse.")
        if collega is None:
            coppie = [_collegamento(db, prima, seconda)]
            if coppie[0] is None:
                raise ErroreValore(
                    f"Non trovo il collegamento tra `{prima}` e `{seconda}`.",
                    suggerimento=f"Scrivi quali colonne si corrispondono, per esempio "
                                 f"`collega = {{\"{_singolari(seconda)[0] if _singolari(seconda) else seconda}_id\": "
                                 f"\"id\"}}`, oppure crea la colonna come \"intero collegato {seconda}\".")
        elif isinstance(collega, str):
            chiave = _chiave_primaria(db, seconda)
            coppie = [(collega, "id" if chiave == "rowid" else chiave)]
        elif isinstance(collega, dict) and collega:
            coppie = list(collega.items())
        else:
            raise ErroreTipo(f"`collega` di `unisci` deve essere un dizionario, non {articolo(collega)}.",
                             suggerimento="Esempio: {\"classe_id\": \"id\"}.")
        condizioni_on = [f"a.{_q(_col(db, prima, x))} = b.{_q(_col(db, seconda, y))}" for x, y in coppie]
        colonne_prima = list(_info(db, prima))
        scelte, uscita = [], {}
        logiche, date = set(), set()
        for c in colonne_prima:
            scelte.append(f"a.{_q(c)} AS {_q(c)}")
            uscita[c] = (prima, c)
        for c in _info(db, seconda):
            alias = c
            if alias in uscita:
                alias = f"{seconda}_{c}"
                while alias in uscita:
                    alias += "_"
            scelte.append(f"b.{_q(c)} AS {_q(alias)}")
            uscita[alias] = (seconda, c)
        for alias, (t, c) in uscita.items():
            tipo = _info(db, t).get(c)
            if tipo == "LOGICO":
                logiche.add(alias)
            elif tipo == "DATA":
                date.add(alias)

        def valida(colonna: Any) -> str:
            n = _identificatore(colonna, "colonna")
            if n not in uscita:
                raise ErroreValore(f"La colonna `{n}` non c'è nell'unione di `{prima}` e `{seconda}`.",
                                   suggerimento="Colonne presenti: " + ", ".join(f"`{x}`" for x in uscita) + ".")
            return n

        dove, parametri = db.motore._dove("", _condizioni(condizioni, "unisci"), valida)
        ordine = db.motore._ordine("", ordina, valida)
        join = "LEFT JOIN" if anche_senza else "JOIN"
        sql = (f"SELECT * FROM (SELECT {', '.join(scelte)} FROM {_q(prima)} AS a {join} {_q(seconda)} AS b "
               f"ON {' AND '.join(condizioni_on)}){dove}{ordine}")
        limite = _limite(limite, "unisci")
        if limite:
            sql += " LIMIT ?"
            parametri = parametri + [limite]
        return _leggi(db, _esegui(db, sql, parametri, f"Unione di `{prima}` e `{seconda}`"), logiche, date)


# ---------------------------------------------------------------------------
# Scrivere
# ---------------------------------------------------------------------------

@metodo_oggetto(Database, "inserisci_o_aggiorna")
def db_inserisci_o_aggiorna(db, tabella, riga, /, chiave="id"):
    """db.inserisci_o_aggiorna(tabella, riga, chiave = "id"): aggiorna la riga con la stessa chiave, oppure la aggiunge.

    `chiave` è la colonna (o la lista di colonne) che riconosce la riga. Restituisce l'`id` della riga.
    Esempio: `db.inserisci_o_aggiorna("punteggi", {"giocatore": "Ada", "punti": 120}, chiave = "giocatore")`.
    """
    if not isinstance(riga, dict) or not riga:
        raise ErroreTipo(f"La riga di `inserisci_o_aggiorna` deve essere un dizionario, non {articolo(riga)}.",
                         suggerimento="Esempio: {\"giocatore\": \"Ada\", \"punti\": 120}.")
    with db.motore._blocco:
        nome = _tab(db, tabella)
        chiavi = _elenco_colonne(db, nome, chiave, "inserisci_o_aggiorna")
        mancanti = [c for c in chiavi if c not in riga]
        primaria = _chiave_primaria(db, nome)

        def azione():
            if not mancanti:
                trovate = db.motore.cerca(nome, {c: riga[c] for c in chiavi}, "", 2)
                if len(trovate) > 1:
                    raise ErroreValore(f"Ci sono più righe con la stessa chiave ({', '.join(chiavi)}).",
                                       suggerimento="Usa come chiave una colonna `unico`, per esempio `id`.")
                if trovate:
                    altri = {c: v for c, v in riga.items() if c not in chiavi}
                    if altri:
                        db.motore.aggiorna(nome, {c: riga[c] for c in chiavi}, altri)
                    if primaria != "rowid" and primaria in trovate[0]:
                        return trovate[0][primaria]
                    return _esegui(db, f"SELECT rowid FROM {_q(nome)} WHERE "
                                       + " AND ".join(f"{_q(c)} IS ?" for c in chiavi),
                                   [db.motore._valore_per(nome, c, riga[c]) for c in chiavi]).fetchone()[0]
            return db.motore.inserisci(nome, riga)

        return _in_blocco(db, azione)


def _righe_da(righe: Any, metodo: str) -> list[dict]:
    """Lista di dizionari, lista di liste con l'intestazione, o un oggetto `tabella` -> lista di dizionari."""
    if not isinstance(righe, list) and hasattr(righe, "metodo"):
        for nome_metodo in ("in_lista", "righe", "a_dizionari", "in_dizionari"):
            m = righe.metodo(nome_metodo)
            if m is not None:
                righe = m.chiama(None, [], {})
                break
    if not isinstance(righe, list):
        raise ErroreTipo(f"`{metodo}` vuole una lista di dizionari, non {articolo(righe)}.",
                         suggerimento="Esempio: [{\"nome\": \"Ada\", \"età\": 10}, {\"nome\": \"Bruno\", \"età\": 11}].")
    if righe and all(isinstance(r, list) for r in righe):
        intestazione = righe[0]
        if not all(isinstance(h, str) for h in intestazione):
            raise ErroreValore(f"Per `{metodo}` la prima riga della lista deve avere i nomi delle colonne.")
        convertite = []
        for i, r in enumerate(righe[1:], start=2):
            if len(r) != len(intestazione):
                raise ErroreValore(f"La riga {i} ha {len(r)} valori ma le colonne sono {len(intestazione)}.")
            convertite.append(dict(zip(intestazione, r)))
        return convertite
    for i, r in enumerate(righe, start=1):
        if not isinstance(r, dict):
            raise ErroreTipo(f"L'elemento {i} della lista non è un dizionario ma {articolo(r)}.",
                             suggerimento="Ogni riga è un dizionario colonna -> valore.")
    return righe


def _tipo_di(valori: list) -> str:
    pieni = [v for v in valori if v is not None]
    if not pieni:
        return "testo"
    if all(isinstance(v, bool) for v in pieni):
        return "logico"
    if all(isinstance(v, int) and not isinstance(v, bool) for v in pieni):
        return "intero"
    if all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in pieni):
        return "decimale"
    if all(isinstance(v, DataDante) or (isinstance(v, str) and data_da_testo(v) is not None) for v in pieni):
        return "data"
    return "testo"


def _importa(db: Database, tabella: Any, righe: list[dict], metodo: str) -> int:
    richiedi_testo(tabella, metodo, "tabella")
    nome = _identificatore(tabella)
    if nome in db.motore.tabelle():
        colonne = _info(db, nome)
        mancanti = [c for r in righe for c in r if c not in colonne]
        if mancanti:
            raise ErroreValore(
                f"La tabella `{nome}` non ha la colonna `{mancanti[0]}`.",
                suggerimento=f"Aggiungila con `db.aggiungi_colonna(\"{nome}\", \"{mancanti[0]}\", \"testo\")`.")
    else:
        if not righe:
            return 0
        ordine: list[str] = []
        for r in righe:
            for c in r:
                if c not in ordine:
                    ordine.append(c)
        definizione = {}
        for c in ordine:
            _identificatore(c, "colonna")
            definizione[c] = _tipo_di([r.get(c) for r in righe])
        if definizione.get("id") == "intero":
            definizione["id"] = "intero chiave"
        db.motore.crea_tabella(nome, definizione)
    _in_blocco(db, lambda: [db.motore.inserisci(nome, r) for r in righe])
    return len(righe)


@metodo_oggetto(Database, "importa_righe")
def db_importa_righe(db, tabella, righe):
    """db.importa_righe(tabella, righe): aggiunge alla tabella una lista di dizionari (la crea se non c'è).

    Se la tabella non esiste Leo la crea indovinando i tipi (intero, decimale, logico, data, testo).
    Va anche una lista di liste con i nomi delle colonne nella prima. Tutto o niente.
    Restituisce quante righe ha aggiunto. Esempio:
    `db.importa_righe("pianeti", [{"nome": "Marte", "lune": 2}, {"nome": "Terra", "lune": 1}])`.
    """
    return _importa(db, tabella, _righe_da(righe, "importa_righe"), "importa_righe")


@metodo_oggetto(Database, "elimina_duplicati")
def db_elimina_duplicati(db, tabella, /, colonne=None):
    """db.elimina_duplicati(tabella, colonne = nulla): toglie le righe ripetute (tiene la prima) e dice quante ha tolto.

    Due righe sono ripetute se hanno uguali tutte le colonne (tranne l'`id`), oppure le `colonne` indicate.
    Esempio: `db.elimina_duplicati("iscritti", colonne = ["email"])`.
    """
    with db.motore._blocco:
        nome = _tab(db, tabella)
        if colonne is None:
            primaria = _chiave_primaria(db, nome)
            scelte = [c for c in _info(db, nome) if c != primaria]
        else:
            scelte = _elenco_colonne(db, nome, colonne, "elimina_duplicati")
        if not scelte:
            return 0
        sql = (f"DELETE FROM {_q(nome)} WHERE rowid NOT IN (SELECT MIN(rowid) FROM {_q(nome)} "
               f"GROUP BY {', '.join(_q(c) for c in scelte)})")
        return max(0, _esegui(db, sql, (), f"Eliminazione dei doppioni in `{nome}`").rowcount)


# ---------------------------------------------------------------------------
# Struttura
# ---------------------------------------------------------------------------

@metodo_oggetto(Database, "esiste_tabella")
def db_esiste_tabella(db, nome):
    """db.esiste_tabella(nome): `vero` se nel database c'è la tabella `nome`.

    Esempio: `se non db.esiste_tabella("alunni") allora db.crea_tabella("alunni", {"nome": "testo"}) fine`.
    """
    return _identificatore(nome) in db.motore.tabelle()


def _tipo_sql(db: Database, colonna: str, tipo: Any) -> tuple[str, bool]:
    """Tipo in italiano -> (pezzo SQL, obbligatorio) per `aggiungi_colonna`."""
    if not isinstance(tipo, str) or not tipo.split():
        raise ErroreTipo(f"Il tipo della colonna `{colonna}` deve essere un testo, per esempio \"intero\".")
    parole = tipo.lower().split()
    base = _SINONIMI_TIPO.get(parole[0], parole[0])
    if base not in TIPI_COLONNA:
        raise ErroreValore(f"Tipo `{parole[0]}` sconosciuto per la colonna `{colonna}`.",
                           suggerimento="I tipi possibili sono: intero, decimale, testo, logico (sì/no), data.")
    pezzo = TIPI_COLONNA[base]
    obbligatorio = False
    altre = iter(parole[1:])
    for parola in altre:
        if parola in ("obbligatorio", "obbligatoria"):
            obbligatorio = True
            pezzo += " NOT NULL"
        elif parola in _COLLEGAMENTO:
            collegata = next(altre, None)
            if collegata in ("a", "alla", "con"):
                collegata = next(altre, None)
            if collegata is None:
                raise ErroreValore("Dopo `collegato` scrivi il nome della tabella.")
            pezzo += f" REFERENCES {_q(_identificatore(collegata))}"
        elif parola in ("unico", "unica"):
            raise ErroreValore("Una colonna aggiunta dopo non può essere `unico`.",
                               suggerimento=f"Aggiungila senza `unico` e poi usa "
                                            f"`db.crea_indice(tabella, \"{colonna}\", unico = vero)`.")
        elif parola == "chiave":
            raise ErroreValore("La chiave di una tabella si sceglie solo quando la crei.",
                               suggerimento="Crea una tabella nuova con `copia_tabella` o `crea_tabella`.")
        else:
            raise ErroreValore(f"Parola `{parola}` sconosciuta nel tipo della colonna `{colonna}`.",
                               suggerimento="Dopo il tipo puoi scrivere: obbligatorio, collegato TABELLA.")
    return pezzo, obbligatorio


def _letterale(valore: Any) -> str:
    """Un valore semplice scritto come costante SQL (solo per DEFAULT, che non accetta parametri)."""
    valore = _valore_in(valore)
    if valore is None:
        return "NULL"
    if isinstance(valore, int):
        return str(int(valore))
    if isinstance(valore, float):
        if valore != valore or valore in (float("inf"), float("-inf")):
            raise ErroreValore("Il valore predefinito deve essere un numero vero.")
        return repr(float(valore))
    return "'" + str(valore).replace("'", "''").replace("\0", "") + "'"


@metodo_oggetto(Database, "aggiungi_colonna")
def db_aggiungi_colonna(db, tabella, nome, tipo="testo", predefinito=None):
    """db.aggiungi_colonna(tabella, nome, tipo = "testo", predefinito = nulla): aggiunge una colonna a una tabella che esiste già.

    Le righe che ci sono già ricevono il valore `predefinito` (o `nulla`). Una colonna
    `obbligatorio` ha bisogno di un `predefinito`.
    Esempio: `db.aggiungi_colonna("alunni", "promosso", "sì/no", predefinito = falso)`.
    """
    with db.motore._blocco:
        t = _tab(db, tabella)
        colonna = _identificatore(nome, "colonna")
        if colonna in _info(db, t):
            raise ErroreValore(f"La tabella `{t}` ha già la colonna `{colonna}`.")
        pezzo, obbligatorio = _tipo_sql(db, colonna, tipo)
        if obbligatorio and predefinito is None:
            raise ErroreValore(f"La colonna obbligatoria `{colonna}` ha bisogno di un valore predefinito "
                               "per le righe che ci sono già.",
                               suggerimento=f"Esempio: `db.aggiungi_colonna(\"{t}\", \"{colonna}\", \"{tipo}\", "
                                            "predefinito = 0)`.")
        if predefinito is not None:
            if pezzo.startswith("DATA") and isinstance(predefinito, str) and data_da_testo(predefinito):
                predefinito = _testo_data(data_da_testo(predefinito))
            pezzo += f" DEFAULT {_letterale(predefinito)}"
        _esegui(db, f"ALTER TABLE {_q(t)} ADD COLUMN {_q(colonna)} {pezzo}", (),
                f"Aggiunta della colonna `{colonna}`")
        db.motore._cache_colonne.pop(t, None)
        return None


@metodo_oggetto(Database, "rinomina_tabella")
def db_rinomina_tabella(db, vecchio, nuovo):
    """db.rinomina_tabella(vecchio, nuovo): cambia il nome di una tabella (le righe restano).

    Esempio: `db.rinomina_tabella("studenti", "alunni")`.
    """
    with db.motore._blocco:
        t = _tab(db, vecchio)
        n = _identificatore(nuovo)
        if n in db.motore.tabelle():
            raise ErroreValore(f"Esiste già una tabella `{n}`.", suggerimento="Scegli un altro nome.")
        _esegui(db, f"ALTER TABLE {_q(t)} RENAME TO {_q(n)}", (), f"Cambio del nome di `{t}`")
        db.motore._cache_colonne.clear()
        return None


@metodo_oggetto(Database, "rinomina_colonna")
def db_rinomina_colonna(db, tabella, vecchio, nuovo):
    """db.rinomina_colonna(tabella, vecchio, nuovo): cambia il nome di una colonna (i valori restano).

    Esempio: `db.rinomina_colonna("alunni", "eta", "età")`.
    """
    with db.motore._blocco:
        t = _tab(db, tabella)
        v = _col(db, t, vecchio)
        n = _identificatore(nuovo, "colonna")
        if n in _info(db, t):
            raise ErroreValore(f"La tabella `{t}` ha già una colonna `{n}`.")
        _esegui(db, f"ALTER TABLE {_q(t)} RENAME COLUMN {_q(v)} TO {_q(n)}", (), f"Cambio del nome di `{v}`")
        db.motore._cache_colonne.clear()
        return None


_CREA = re.compile(r'^\s*CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?(?:"(?:[^"]|"")+"|\[[^\]]+\]|`[^`]+`|[\w]+)',
                   re.IGNORECASE)


@metodo_oggetto(Database, "copia_tabella")
def db_copia_tabella(db, origine, nuova, /, condizioni=None, **filtri):
    """db.copia_tabella(origine, nuova, condizioni = nulla): crea `nuova` con le stesse colonne e ci copia le righe.

    Restituisce quante righe ha copiato; con le condizioni copia solo quelle righe.
    Esempio: `db.copia_tabella("alunni", "alunni_5A", classe = "5A")`.
    """
    with db.motore._blocco:
        t = _tab(db, origine)
        n = _identificatore(nuova)
        if n in db.motore.tabelle():
            raise ErroreValore(f"Esiste già una tabella `{n}`.",
                               suggerimento="Scegli un altro nome o elimina prima quella tabella.")
        riga = _esegui(db, "SELECT sql FROM sqlite_master WHERE type = 'table' AND name = ?", [t]).fetchone()
        if not riga or not riga[0] or not _CREA.match(riga[0]):
            raise ErroreValore(f"Non riesco a copiare la struttura di `{t}`.")
        dove, parametri = _dove(db, t, condizioni, filtri, "copia_tabella")

        def azione():
            _esegui(db, _CREA.sub(f"CREATE TABLE {_q(n)}", riga[0], count=1), (), f"Copia di `{t}`")
            db.motore._cache_colonne.pop(n, None)
            return _esegui(db, f"INSERT INTO {_q(n)} SELECT * FROM {_q(t)}{dove}", parametri,
                           f"Copia di `{t}`").rowcount

        return max(0, _in_blocco(db, azione))


@metodo_oggetto(Database, "crea_indice")
def db_crea_indice(db, tabella, colonne, /, unico=False):
    """db.crea_indice(tabella, colonne, unico = falso): rende più veloci le ricerche su quelle colonne.

    Con `unico = vero` impedisce anche i valori ripetuti. Restituisce il nome dell'indice.
    Serve con tabelle grandi (migliaia di righe). Esempio: `db.crea_indice("alunni", ["cognome", "nome"])`.
    """
    richiedi_logico(unico, "crea_indice", "unico")
    with db.motore._blocco:
        t = _tab(db, tabella)
        scelte = _elenco_colonne(db, t, colonne, "crea_indice")
        nome = ("unico_" if unico else "indice_") + t + "_" + "_".join(scelte)
        try:
            _esegui(db, f"CREATE {'UNIQUE ' if unico else ''}INDEX IF NOT EXISTS {_q(nome)} ON {_q(t)} "
                        f"({', '.join(_q(c) for c in scelte)})", (), f"Creazione dell'indice su `{t}`")
        except ErroreValore as e:
            if unico and "stesso valore" in e.messaggio:
                raise ErroreValore(f"Non posso rendere unica la colonna: in `{t}` ci sono già valori ripetuti.",
                                   suggerimento=f"Toglili prima con `db.elimina_duplicati(\"{t}\", "
                                                f"colonne = {mostra(scelte)})`.") from None
            raise
        return nome


@metodo_oggetto(Database, "struttura")
def db_struttura(db, tabella):
    """db.struttura(tabella): com'è fatta la tabella, colonna per colonna (lista di dizionari).

    Ogni dizionario ha `nome`, `tipo`, `obbligatorio`, `unico`, `chiave`, `collegata` (la tabella
    collegata o `nulla`) e `predefinito`. Esempio: `per ogni c in db.struttura("alunni") fai stampa(c) fine`.
    """
    with db.motore._blocco:
        t = _tab(db, tabella)
        tipi = db.motore.colonne(t)
        uniche = set()
        for indice in _esegui(db, f"PRAGMA index_list({_q(t)})").fetchall():
            if indice[2]:
                colonne = _esegui(db, f"PRAGMA index_info({_q(indice[1])})").fetchall()
                if len(colonne) == 1:
                    uniche.add(colonne[0][2])
        collegate = {r[3]: r[2] for r in _esegui(db, f"PRAGMA foreign_key_list({_q(t)})").fetchall()}
        risultato = []
        for r in _esegui(db, f"PRAGMA table_info({_q(t)})").fetchall():
            predefinito = r[4]
            if isinstance(predefinito, str) and len(predefinito) >= 2 and predefinito[0] == predefinito[-1] == "'":
                predefinito = predefinito[1:-1].replace("''", "'")
            elif isinstance(predefinito, str):
                try:
                    predefinito = int(predefinito)
                except ValueError:
                    try:
                        predefinito = float(predefinito)
                    except ValueError:
                        predefinito = None if predefinito.upper() == "NULL" else predefinito
            chiave = bool(r[5])
            tipo = tipi.get(r[1], "testo")
            if tipo == "logico" and isinstance(predefinito, int):
                predefinito = bool(predefinito)
            elif tipo == "data" and isinstance(predefinito, str) and data_da_testo(predefinito):
                predefinito = DataDante(data_da_testo(predefinito))
            risultato.append({"nome": r[1], "tipo": tipo, "obbligatorio": bool(r[3]) or chiave,
                              "unico": r[1] in uniche or chiave, "chiave": chiave,
                              "collegata": collegate.get(r[1]), "predefinito": predefinito})
        return risultato


# ---------------------------------------------------------------------------
# Mostrare
# ---------------------------------------------------------------------------

def _cella(valore: Any, larghezza: int = 30) -> str:
    if valore is None:
        testo = ""
    elif valore is True:
        testo = "sì"
    elif valore is False:
        testo = "no"
    else:
        testo = rappresenta(valore).replace("\n", " ")
    return testo if len(testo) <= larghezza else testo[:larghezza - 1] + "…"


def testo_tabella(righe: list[dict]) -> str:
    """Le righe come tabella di testo con i bordi."""
    colonne: list[str] = []
    for r in righe:
        for c in r:
            if c not in colonne:
                colonne.append(str(c))
    if not colonne:
        return "(nessuna riga)"
    celle = [[_cella(r.get(c)) for c in colonne] for r in righe]
    larghezze = [max([len(c)] + [len(riga[i]) for riga in celle]) for i, c in enumerate(colonne)]
    numeriche = [all(isinstance(r.get(c), (int, float)) and not isinstance(r.get(c), bool)
                     for r in righe if r.get(c) is not None) for c in colonne]

    def linea(sinistra: str, mezzo: str, destra: str) -> str:
        return sinistra + mezzo.join("─" * (w + 2) for w in larghezze) + destra

    def riga(valori: list[str], intestazione: bool = False) -> str:
        pezzi = []
        for v, w, num in zip(valori, larghezze, numeriche):
            pezzi.append(" " + (v.rjust(w) if num and not intestazione else v.ljust(w)) + " ")
        return "│" + "│".join(pezzi) + "│"

    uscita = [linea("┌", "┬", "┐"), riga(colonne, True), linea("├", "┼", "┤")]
    uscita += [riga(r) for r in celle]
    uscita.append(linea("└", "┴", "┘"))
    return "\n".join(uscita)


@metodo_oggetto(Database, "stampa_tabella", interprete=True)
def db_stampa_tabella(interprete, db, tabella, /, condizioni=None, ordina="", limite=20, **filtri):
    """db.stampa_tabella(tabella, condizioni = nulla, ordina = "", limite = 20): stampa le righe come una tabella con i bordi.

    Al posto del nome della tabella puoi dare una lista di righe (per esempio il risultato di `unisci`).
    Esempio: `db.stampa_tabella("alunni", classe = "5A", ordina = "cognome")`.
    """
    limite = _limite(limite, "stampa_tabella")
    if isinstance(tabella, list):
        righe = _righe_da(tabella, "stampa_tabella")
        totale = len(righe)
    else:
        condizioni_tutte = _condizioni(condizioni, "stampa_tabella", filtri)
        righe = db.motore.cerca(tabella, condizioni_tutte, ordina or "", limite)
        totale = db.motore.conta(tabella, condizioni_tutte)
    if limite:
        righe = righe[:limite]
    testo = testo_tabella(righe)
    if totale > len(righe):
        testo += f"\n({len(righe)} righe di {totale}: per vederne di più usa `limite`)"
    interprete.scrivi(testo + "\n")
    return None


# ---------------------------------------------------------------------------
# File e manutenzione
# ---------------------------------------------------------------------------

@metodo_oggetto(Database, "esporta_json")
def db_esporta_json(db, tabella, percorso, /, condizioni=None, ordina="", **filtri):
    """db.esporta_json(tabella, percorso, condizioni = nulla, ordina = ""): salva le righe in un file JSON (lista di dizionari).

    Restituisce quante righe ha scritto; le date diventano testi come "25/09/2026".
    Esempio: `db.esporta_json("alunni", "alunni.json", ordina = "cognome")`.
    """
    from .archivi import scrivi_json

    _controlla_percorso(percorso, "esporta_json")
    righe = db.motore.cerca(tabella, _condizioni(condizioni, "esporta_json", filtri), ordina or "")
    scrivi_json(percorso, righe)
    return len(righe)


@metodo_oggetto(Database, "importa_json")
def db_importa_json(db, percorso, tabella):
    """db.importa_json(percorso, tabella): aggiunge alla tabella le righe di un file JSON (la crea se non c'è).

    Il file deve contenere una lista di dizionari (come quelli scritti da `esporta_json`).
    Tutto o niente. Restituisce quante righe ha aggiunto. Esempio: `db.importa_json("alunni.json", "alunni")`.
    """
    from .archivi import leggi_json

    dati = leggi_json(percorso)
    if isinstance(dati, dict) and len(dati) == 1 and isinstance(next(iter(dati.values())), list):
        dati = next(iter(dati.values()))
    if not isinstance(dati, list):
        raise ErroreValore(f"Il file `{percorso}` non contiene una lista di righe.",
                           suggerimento="Il JSON deve essere come [{\"nome\": \"Ada\"}, {\"nome\": \"Bruno\"}].")
    righe = _righe_da(dati, "importa_json")
    for r in righe:
        for c, v in r.items():
            if isinstance(v, (list, dict)):
                raise ErroreValore(f"Nel file `{percorso}` la colonna `{c}` contiene {articolo(v)}: "
                                   "nel database vanno solo numeri, testi, sì/no, date e nulla.",
                                   suggerimento="Trasforma quei valori in testo prima di importare.")
    return _importa(db, tabella, righe, "importa_json")


@metodo_oggetto(Database, "copia_di_sicurezza")
def db_copia_di_sicurezza(db, percorso):
    """db.copia_di_sicurezza(percorso): salva una copia completa del database in un altro file.

    Funziona anche mentre il database è in uso; le modifiche di una transazione non ancora
    confermata non entrano nella copia. Restituisce il percorso. Esempio:
    `db.copia_di_sicurezza("copie/scuola_" + testo(oggi()) + ".db")`.
    """
    _controlla_percorso(percorso, "copia_di_sicurezza")
    if db.percorso != ":memory:" and os.path.abspath(percorso) == os.path.abspath(db.percorso):
        raise ErroreValore("La copia di sicurezza deve andare in un file diverso dal database.",
                           suggerimento="Per esempio aggiungi `_copia` al nome del file.")
    cartella = os.path.dirname(os.path.abspath(percorso))
    if not os.path.isdir(cartella):
        raise ErroreFile(f"La cartella `{cartella}` non esiste.",
                         suggerimento="Creala prima con `crea_cartella(...)`.")
    with db.motore._blocco:
        sorgente = db.motore._conn()
        try:
            destinazione = sqlite3.connect(percorso)
        except sqlite3.Error as e:
            raise _traduci(e, "Copia di sicurezza") from None
        try:
            sorgente.backup(destinazione)
        except sqlite3.Error as e:
            raise _traduci(e, "Copia di sicurezza") from None
        finally:
            destinazione.close()
    return percorso


@metodo_oggetto(Database, "compatta")
def db_compatta(db):
    """db.compatta(): riordina il file del database e lo rende più piccolo dopo tante cancellazioni.

    Restituisce quanti byte ha risparmiato (0 per un database in memoria). Esempio: `stampa(db.compatta())`.
    """
    if db.motore.in_transazione:
        raise ErroreValore("Non posso compattare il database durante una transazione.",
                           suggerimento="Prima chiama `conferma()` o `annulla()`.")
    with db.motore._blocco:
        prima = os.path.getsize(db.percorso) if db.percorso != ":memory:" and os.path.exists(db.percorso) else 0
        _esegui(db, "VACUUM", (), "Compattazione")
        _esegui(db, "ANALYZE", (), "Compattazione")
        dopo = os.path.getsize(db.percorso) if prima else 0
        return max(0, prima - dopo)


@metodo_oggetto(Database, "valore_sql")
def db_valore_sql(db, sql, parametri=None):
    """db.valore_sql(sql, parametri = nulla): esegue un comando SQL e restituisce un solo valore (la prima colonna della prima riga).

    Restituisce `nulla` se non ci sono righe. Come in `esegui`, i valori vanno nei parametri `?`.
    Esempio: `db.valore_sql("SELECT MAX(voto) FROM voti WHERE materia = ?", ["storia"])`.
    """
    righe = db_esegui(db, sql, parametri)
    if not righe:
        return None
    return next(iter(righe[0].values()), None)


# ---------------------------------------------------------------------------
# Funzioni
# ---------------------------------------------------------------------------

_CLASSI = [{"id": 1, "nome": "5A", "aula": "Aula verde"}, {"id": 2, "nome": "5B", "aula": "Aula blu"}]

_ALUNNI = [
    ("Ada", "Rossi", 1, "2015-03-14"), ("Bruno", "Bianchi", 1, "2015-07-02"),
    ("Chiara", "Verdi", 1, "2015-11-23"), ("Dario", "Esposito", 1, "2016-01-09"),
    ("Elena", "Romano", 2, "2015-05-30"), ("Filippo", "Colombo", 2, "2015-09-12"),
    ("Giulia", "Ricci", 2, "2015-12-01"), ("Hamid", "Marino", 2, "2015-02-18"),
]

_VOTI = [
    (1, "italiano", 9), (1, "matematica", 10), (2, "italiano", 7), (2, "matematica", 6),
    (3, "italiano", 8), (3, "matematica", 9), (4, "italiano", 6), (4, "matematica", 7),
    (5, "italiano", 10), (5, "matematica", 8), (6, "italiano", 7), (6, "matematica", 9),
    (7, "italiano", 8), (7, "matematica", 6), (8, "italiano", 9), (8, "matematica", 8),
]


@funzione_libreria("database_di_esempio")
def database_di_esempio():
    """database_di_esempio(): un database in memoria già pieno, per fare prove senza rompere niente.

    Ha le tabelle `classi` (nome, aula), `alunni` (nome, cognome, classe_id, nato) e `voti`
    (alunno_id, materia, voto); sparisce alla fine del programma.
    Esempio: `variabile db = database_di_esempio()`, poi `db.stampa_tabella("alunni")`.
    """
    db = _apri(":memory:", "database_di_esempio")
    m = db.motore
    m.crea_tabella("classi", {"id": "intero chiave", "nome": "testo obbligatorio unico", "aula": "testo"})
    m.crea_tabella("alunni", {"nome": "testo obbligatorio", "cognome": "testo obbligatorio",
                              "classe_id": "intero collegato classi", "nato": "data"})
    m.crea_tabella("voti", {"alunno_id": "intero collegato alunni", "materia": "testo obbligatorio",
                            "voto": "intero obbligatorio"})

    def riempi():
        for c in _CLASSI:
            m.inserisci("classi", c)
        for nome, cognome, classe, nato in _ALUNNI:
            m.inserisci("alunni", {"nome": nome, "cognome": cognome, "classe_id": classe, "nato": nato})
        for alunno, materia, voto in _VOTI:
            m.inserisci("voti", {"alunno_id": alunno, "materia": materia, "voto": voto})

    _in_blocco(db, riempi)
    return db


@funzione_libreria("e_database")
def e_database(percorso):
    """e_database(percorso): `vero` se il file esiste ed è un database SQLite.

    Esempio: `se e_database("scuola.db") allora variabile db = apri_database("scuola.db") fine`.
    """
    _controlla_percorso(percorso, "e_database")
    try:
        with open(percorso, "rb") as f:
            return f.read(16) == b"SQLite format 3\x00"
    except OSError:
        return False
