"""Libreria: date e tempo pratici (il livello più comodo).

Completa ``leo.libreria.date`` (tipo ``data``, ``data``, ``adesso``, ``giorni_tra``,
``nome_giorno``, ``nome_mese``) e ``tempo_avanzato`` (festività, età, durate) con un
livello di *funzioni* che hanno sempre la data come primo argomento, così non serve
ricordare quali parti del tipo ``data`` sono proprietà e quali metodi:

* lettura dei pezzi: ``anno_di``, ``mese_di``, ``giorno_di``, ``ora_di``, ``minuto_di``,
  ``secondo_di``, ``e_bisestile``;
* creazione e testo: ``crea_ora``, ``da_testo_data`` (con formato italiano), ``a_testo_data``;
* aritmetica: ``aggiungi_giorni``, ``aggiungi_mesi``, ``aggiungi_anni``, ``aggiungi_ore``,
  ``aggiungi_minuti``, ``aggiungi_secondi``, ``inizio_mese``, ``fine_mese``,
  ``prossimo_giorno_della_settimana``, ``differenza_tra`` (durata leggibile);
* calendario: ``giorni_nel_mese``, ``settimana_del``, ``calendario_mese`` (testo);
* fusi orari: ``converti_fuso`` (usa ``zoneinfo`` se c'è, con ripiego a UTC/ora locale);
* cronometro: ``leggi_cronometro`` (legge un ``cronometro`` come funzione).
"""

from __future__ import annotations

import calendar
import datetime
from typing import Any

from ..errori import ErroreTipo, ErroreValore
from .caso_e_tempo import Cronometro
from .date import GIORNI, MESI, DataDante, _costruisci, richiedi_data
from .generali import articolo, funzione_libreria, mostra, richiedi_intero, richiedi_testo
from .tempo_avanzato import durata_in_parole

# ---------------------------------------------------------------------------
# Aiutanti interni
# ---------------------------------------------------------------------------

def _d(valore: Any, nome_funzione: str, parametro: str = "data") -> datetime.datetime:
    """La ``datetime`` interna di una data (accetta anche un testo come "25/09/2026")."""
    return richiedi_data(valore, nome_funzione, parametro).valore


def _anno_mese(primo: Any, mese: Any, nome_funzione: str) -> tuple[int, int]:
    """Legge (anno, mese) da ``f(data)`` oppure da ``f(anno, mese)``."""
    if isinstance(primo, (DataDante, str)) and mese is None:
        v = _d(primo, nome_funzione)
        return v.year, v.month
    if mese is None:
        raise ErroreTipo(
            f"`{nome_funzione}` vuole una data, oppure l'anno e il mese: "
            f"per esempio `{nome_funzione}(2026, 10)` o `{nome_funzione}(oggi())`.")
    anno = richiedi_intero(primo, nome_funzione, "anno")
    m = richiedi_intero(mese, nome_funzione, "mese")
    if not 1 <= m <= 12:
        raise ErroreValore(f"Il mese deve essere un numero da 1 a 12, non {m}.")
    if not 1 <= anno <= 9999:
        raise ErroreValore(f"L'anno deve essere tra 1 e 9999, non {anno}.")
    return anno, m


def _numero_giorno(giorno: Any, nome_funzione: str) -> int:
    """Un giorno della settimana come 0..6 (lunedì..domenica) da un numero 1-7 o un nome."""
    if isinstance(giorno, str):
        testo = giorno.strip().lower()
        for i, nome in enumerate(GIORNI):
            if testo == nome or testo == nome.replace("ì", "i"):
                return i
        raise ErroreValore(
            f"Non conosco il giorno {mostra(giorno)}.",
            suggerimento="Usa un nome come \"lunedì\" o un numero da 1 (lunedì) a 7 (domenica).")
    richiedi_intero(giorno, nome_funzione, "giorno")
    if not 1 <= giorno <= 7:
        raise ErroreValore(f"I giorni della settimana vanno da 1 (lunedì) a 7 (domenica), non {giorno}.")
    return giorno - 1


# ---------------------------------------------------------------------------
# Lettura dei pezzi (funzioni con la data come primo argomento)
# ---------------------------------------------------------------------------

@funzione_libreria("anno_di")
def anno_di(data):
    """anno_di(data): l'anno di una data. Esempio: `anno_di(data(2026, 10, 4))` è 2026."""
    return _d(data, "anno_di").year


@funzione_libreria("mese_di")
def mese_di(data):
    """mese_di(data): il numero del mese (1-12). Esempio: `mese_di(data(2026, 10, 4))` è 10.

    Per il nome usa `nome_mese(data)`.
    """
    return _d(data, "mese_di").month


@funzione_libreria("giorno_di")
def giorno_di(data):
    """giorno_di(data): il numero del giorno nel mese (1-31). Esempio: `giorno_di("04/10/2026")` è 4."""
    return _d(data, "giorno_di").day


@funzione_libreria("ora_di")
def ora_di(data):
    """ora_di(data): l'ora (0-23) di una data con orario. Esempio: `ora_di(data(2026,10,4, ore=14))` è 14."""
    return _d(data, "ora_di").hour


@funzione_libreria("minuto_di")
def minuto_di(data):
    """minuto_di(data): i minuti (0-59) di una data con orario."""
    return _d(data, "minuto_di").minute


@funzione_libreria("secondo_di")
def secondo_di(data):
    """secondo_di(data): i secondi (0-59) di una data con orario."""
    return _d(data, "secondo_di").second


@funzione_libreria("e_bisestile")
def e_bisestile(anno):
    """e_bisestile(anno): `vero` se l'anno è bisestile (ha il 29 febbraio).

    Accetta un numero o una data: `e_bisestile(2024)` è `vero`, `e_bisestile(oggi())` dipende da oggi.
    """
    if isinstance(anno, (DataDante, str)):
        anno = _d(anno, "e_bisestile").year
    else:
        richiedi_intero(anno, "e_bisestile", "anno")
        if not 1 <= anno <= 9999:
            raise ErroreValore(f"L'anno deve essere tra 1 e 9999, non {anno}.")
    return calendar.isleap(anno)


# ---------------------------------------------------------------------------
# Creazione e testo
# ---------------------------------------------------------------------------

@funzione_libreria("crea_ora")
def crea_ora(ore, minuti=0, secondi=0):
    """crea_ora(ore, minuti = 0, secondi = 0): un orario di oggi (una data con quell'ora).

    Esempio: `crea_ora(14, 30)` è oggi alle 14:30. Per una data intera usa `data(anno, mese, giorno)`.
    """
    for nome, v in (("ore", ore), ("minuti", minuti), ("secondi", secondi)):
        richiedi_intero(v, "crea_ora", nome)
    if not 0 <= ore <= 23:
        raise ErroreValore(f"Le ore devono andare da 0 a 23, non {ore}.")
    if not 0 <= minuti <= 59 or not 0 <= secondi <= 59:
        raise ErroreValore("Minuti e secondi devono andare da 0 a 59.")
    oggi = datetime.date.today()
    return DataDante(datetime.datetime(oggi.year, oggi.month, oggi.day, ore, minuti, secondi))


_SEGNAPOSTI_LETTURA = [
    ("AAAA", r"(?P<anno>\d{4})"),
    ("AA", r"(?P<anno2>\d{2})"),
    ("MM", r"(?P<mese>\d{1,2})"),
    ("GG", r"(?P<giorno>\d{1,2})"),
    ("hh", r"(?P<ore>\d{1,2})"),
    ("mm", r"(?P<minuti>\d{1,2})"),
    ("ss", r"(?P<secondi>\d{1,2})"),
]


@funzione_libreria("da_testo_data")
def da_testo_data(testo, formato=None):
    """da_testo_data(testo, formato = niente): legge una data da un testo.

    Senza `formato` riconosce "25/09/2026", "25/09/2026 14:30" e "2026-09-25".
    Con un `formato` all'italiana (`GG` giorno, `MM` mese, `AAAA` anno, `AA` due cifre,
    `hh` ore, `mm` minuti, `ss` secondi) legge testi su misura:
    `da_testo_data("2026-10-04", "AAAA-MM-GG")`, `da_testo_data("4 ott", "GG MESE")` no—usa i numeri.
    """
    richiedi_testo(testo, "da_testo_data", "testo")
    if formato is None:
        return richiedi_data(testo, "da_testo_data", "testo")
    richiedi_testo(formato, "da_testo_data", "formato")
    import re
    pezzi = []
    i = 0
    trovati = sorted(_SEGNAPOSTI_LETTURA, key=lambda p: -len(p[0]))
    while i < len(formato):
        for seg, regex in trovati:
            if formato.startswith(seg, i):
                pezzi.append(regex)
                i += len(seg)
                break
        else:
            pezzi.append(re.escape(formato[i]))
            i += 1
    regola = re.compile(r"^\s*" + "".join(pezzi) + r"\s*$")
    m = regola.match(testo)
    if not m:
        raise ErroreValore(
            f"Il testo {mostra(testo)} non combacia con il formato {mostra(formato)}.",
            suggerimento="Controlla che separatori e cifre siano come nel formato "
                         "(per esempio \"04/10/2026\" con \"GG/MM/AAAA\").")
    d = m.groupdict()
    anno = int(d["anno"]) if d.get("anno") else (2000 + int(d["anno2"]) if d.get("anno2") else 1)
    mese = int(d.get("mese") or 1)
    giorno = int(d.get("giorno") or 1)
    ore = int(d.get("ore") or 0)
    minuti = int(d.get("minuti") or 0)
    secondi = int(d.get("secondi") or 0)
    return _costruisci(anno, mese, giorno, ore, minuti, secondi)


@funzione_libreria("a_testo_data")
def a_testo_data(data, formato):
    """a_testo_data(data, formato): scrive una data secondo un formato italiano (come `data.formato`).

    Segnaposti: `GG` giorno, `MM` mese, `AAAA`/`AA` anno, `hh` ore, `mm` minuti, `ss` secondi,
    `GIORNO` nome del giorno, `MESE` nome del mese.
    Esempio: `a_testo_data(data(2026, 10, 4), "GIORNO GG MESE AAAA")` è "domenica 04 ottobre 2026".
    """
    d = richiedi_data(data, "a_testo_data", "data")
    richiedi_testo(formato, "a_testo_data", "formato")
    return _formato(d, formato)


def _formato(d: DataDante, modello: str) -> str:
    import re
    v = d.valore
    valori = {"AAAA": f"{v.year:04d}", "AA": f"{v.year % 100:02d}", "MM": f"{v.month:02d}",
              "GG": f"{v.day:02d}", "hh": f"{v.hour:02d}", "mm": f"{v.minute:02d}",
              "ss": f"{v.second:02d}", "GIORNO": GIORNI[v.weekday()], "MESE": MESI[v.month - 1]}
    return re.sub(r"AAAA|AA|MESE|MM|GIORNO|GG|hh|mm|ss", lambda m: valori[m.group(0)], modello)


# ---------------------------------------------------------------------------
# Aritmetica
# ---------------------------------------------------------------------------

def _sposta(d: datetime.datetime, nome_funzione: str, **delta) -> DataDante:
    try:
        return DataDante(d + datetime.timedelta(**delta))
    except (OverflowError, ValueError):
        raise ErroreValore("La data risultante è fuori dal calendario (anni da 1 a 9999).") from None


@funzione_libreria("aggiungi_giorni")
def aggiungi_giorni(data, giorni):
    """aggiungi_giorni(data, giorni): una nuova data spostata di tanti giorni (negativi = indietro).

    Esempio: `aggiungi_giorni(data(2026, 12, 31), 1)` è 01/01/2027.
    """
    richiedi_intero(giorni, "aggiungi_giorni", "giorni")
    if abs(giorni) > 4_000_000:
        raise ErroreValore("La data risultante è fuori dal calendario (anni da 1 a 9999).")
    return _sposta(_d(data, "aggiungi_giorni"), "aggiungi_giorni", days=giorni)


def _aggiungi_mesi(v: datetime.datetime, mesi: int) -> DataDante:
    totale = (v.year * 12 + (v.month - 1)) + mesi
    anno, mese0 = divmod(totale, 12)
    mese = mese0 + 1
    if not 1 <= anno <= 9999:
        raise ErroreValore("La data risultante è fuori dal calendario (anni da 1 a 9999).")
    ultimo = calendar.monthrange(anno, mese)[1]
    giorno = min(v.day, ultimo)  # il 31 gennaio + 1 mese = 28/29 febbraio
    return DataDante(v.replace(year=anno, month=mese, day=giorno))


@funzione_libreria("aggiungi_mesi")
def aggiungi_mesi(data, mesi):
    """aggiungi_mesi(data, mesi): una nuova data avanti (o indietro) di tanti mesi.

    Se il giorno non esiste nel mese d'arrivo scende all'ultimo: `aggiungi_mesi(data(2026, 1, 31), 1)`
    è 28/02/2026. Esempio: `aggiungi_mesi(data(2026, 10, 4), 3)` è 04/01/2027.
    """
    richiedi_intero(mesi, "aggiungi_mesi", "mesi")
    if abs(mesi) > 120_000:
        raise ErroreValore("Lo spostamento è troppo grande (anni da 1 a 9999).")
    return _aggiungi_mesi(_d(data, "aggiungi_mesi"), mesi)


@funzione_libreria("aggiungi_anni")
def aggiungi_anni(data, anni):
    """aggiungi_anni(data, anni): una nuova data avanti (o indietro) di tanti anni.

    Il 29 febbraio di un anno non bisestile diventa 28 febbraio. Esempio:
    `aggiungi_anni(data(2024, 2, 29), 1)` è 28/02/2025.
    """
    richiedi_intero(anni, "aggiungi_anni", "anni")
    if abs(anni) > 10_000:
        raise ErroreValore("Lo spostamento è troppo grande (anni da 1 a 9999).")
    return _aggiungi_mesi(_d(data, "aggiungi_anni"), anni * 12)


@funzione_libreria("aggiungi_ore")
def aggiungi_ore(data, ore):
    """aggiungi_ore(data, ore): una nuova data spostata di tante ore (negative = indietro)."""
    richiedi_intero(ore, "aggiungi_ore", "ore")
    if abs(ore) > 100_000_000:
        raise ErroreValore("Lo spostamento è troppo grande.")
    return _sposta(_d(data, "aggiungi_ore"), "aggiungi_ore", hours=ore)


@funzione_libreria("aggiungi_minuti")
def aggiungi_minuti(data, minuti):
    """aggiungi_minuti(data, minuti): una nuova data spostata di tanti minuti (negativi = indietro)."""
    richiedi_intero(minuti, "aggiungi_minuti", "minuti")
    if abs(minuti) > 6_000_000_000:
        raise ErroreValore("Lo spostamento è troppo grande.")
    return _sposta(_d(data, "aggiungi_minuti"), "aggiungi_minuti", minutes=minuti)


@funzione_libreria("aggiungi_secondi")
def aggiungi_secondi(data, secondi):
    """aggiungi_secondi(data, secondi): una nuova data spostata di tanti secondi (negativi = indietro)."""
    richiedi_intero(secondi, "aggiungi_secondi", "secondi")
    if abs(secondi) > 360_000_000_000:
        raise ErroreValore("Lo spostamento è troppo grande.")
    return _sposta(_d(data, "aggiungi_secondi"), "aggiungi_secondi", seconds=secondi)


@funzione_libreria("inizio_mese")
def inizio_mese(data):
    """inizio_mese(data): il primo giorno del mese della data (a mezzanotte).

    Esempio: `inizio_mese(data(2026, 10, 4))` è 01/10/2026.
    """
    v = _d(data, "inizio_mese")
    return DataDante(datetime.datetime(v.year, v.month, 1))


@funzione_libreria("fine_mese")
def fine_mese(data):
    """fine_mese(data): l'ultimo giorno del mese della data (a mezzanotte).

    Esempio: `fine_mese(data(2026, 2, 10))` è 28/02/2026.
    """
    v = _d(data, "fine_mese")
    ultimo = calendar.monthrange(v.year, v.month)[1]
    return DataDante(datetime.datetime(v.year, v.month, ultimo))


@funzione_libreria("prossimo_giorno_della_settimana")
def prossimo_giorno_della_settimana(data, giorno):
    """prossimo_giorno_della_settimana(data, giorno): la prima data *dopo* quella data che cade in quel giorno.

    `giorno` è un nome ("venerdì") o un numero da 1 (lunedì) a 7 (domenica).
    Esempio: `prossimo_giorno_della_settimana(data(2026, 10, 4), "venerdì")` è 09/10/2026.
    """
    v = _d(data, "prossimo_giorno_della_settimana")
    voluto = _numero_giorno(giorno, "prossimo_giorno_della_settimana")
    avanti = (voluto - v.weekday()) % 7
    avanti = avanti or 7  # sempre una data successiva, mai la stessa
    return _sposta(v, "prossimo_giorno_della_settimana", days=avanti)


@funzione_libreria("differenza_tra")
def differenza_tra(prima, dopo):
    """differenza_tra(prima, dopo): la distanza fra due date scritta in parole ("2 giorni e 3 ore").

    È sempre positiva (è una durata). Esempio:
    `differenza_tra(data(2026, 10, 4), data(2026, 10, 6, ore=3))` è "2 giorni e 3 ore".
    Per il solo numero di giorni usa `giorni_tra`.
    """
    a = _d(prima, "differenza_tra", "prima")
    b = _d(dopo, "differenza_tra", "dopo")
    secondi = abs((b - a).total_seconds())
    con_secondi = (a.second or b.second or secondi < 60)
    return durata_in_parole(secondi, con_secondi)


# ---------------------------------------------------------------------------
# Calendario
# ---------------------------------------------------------------------------

@funzione_libreria("giorni_nel_mese")
def giorni_nel_mese(anno, mese=None):
    """giorni_nel_mese(anno, mese) oppure giorni_nel_mese(data): quanti giorni ha quel mese.

    Esempi: `giorni_nel_mese(2026, 2)` è 28; `giorni_nel_mese(2024, 2)` è 29; `giorni_nel_mese(oggi())`.
    """
    a, m = _anno_mese(anno, mese, "giorni_nel_mese")
    return calendar.monthrange(a, m)[1]


@funzione_libreria("settimana_del")
def settimana_del(data):
    """settimana_del(data): il numero della settimana nell'anno (standard ISO, da 1 a 53).

    Esempio: `settimana_del(data(2026, 1, 1))` è 1.
    """
    return _d(data, "settimana_del").isocalendar()[1]


@funzione_libreria("calendario_mese")
def calendario_mese(anno, mese=None):
    """calendario_mese(anno, mese) oppure calendario_mese(data): il calendario del mese come testo.

    La prima colonna è lunedì. Esempio: `stampa(calendario_mese(2026, 10))`.
    """
    a, m = _anno_mese(anno, mese, "calendario_mese")
    titolo = f"{MESI[m - 1].capitalize()} {a}"
    intestazione = "lu ma me gi ve sa do"
    righe = [titolo.center(len(intestazione)), intestazione]
    for settimana in calendar.Calendar(firstweekday=0).monthdayscalendar(a, m):
        righe.append(" ".join(f"{g:2d}" if g else "  " for g in settimana))
    return "\n".join(righe)


# ---------------------------------------------------------------------------
# Fusi orari
# ---------------------------------------------------------------------------

def _zona(nome: str):
    """Un fuso orario da un nome IANA, con ripiego quando ``zoneinfo`` manca."""
    testo = nome.strip()
    basso = testo.lower()
    if basso in ("utc", "gmt", "z"):
        return datetime.timezone.utc
    if basso in ("locale", "local", "ora locale"):
        locale = datetime.datetime.now().astimezone().tzinfo
        return locale or datetime.timezone.utc
    try:
        from zoneinfo import ZoneInfo
    except ImportError:
        raise ErroreValore(
            f"Qui non posso usare il fuso {mostra(nome)}: manca il database dei fusi orari.",
            suggerimento="Su questo sistema uso solo \"UTC\" e \"locale\".") from None
    try:
        return ZoneInfo(testo)
    except Exception:
        raise ErroreValore(
            f"Non conosco il fuso orario {mostra(nome)}.",
            suggerimento="Usa un nome come \"Europe/Rome\", \"UTC\" o \"America/New_York\".") from None


@funzione_libreria("converti_fuso")
def converti_fuso(data, da_fuso, a_fuso):
    """converti_fuso(data, da_fuso, a_fuso): la stessa ora letta in un altro fuso orario.

    I fusi sono nomi come "Europe/Rome", "UTC", "America/New_York" (o "locale").
    Esempio: `converti_fuso(data(2026, 10, 4, ore=12), "Europe/Rome", "UTC")` è le 10:00 (ora solare).
    Dove manca il database dei fusi restano "UTC" e "locale".
    """
    v = richiedi_data(data, "converti_fuso", "data").valore
    richiedi_testo(da_fuso, "converti_fuso", "da_fuso")
    richiedi_testo(a_fuso, "converti_fuso", "a_fuso")
    sorgente = _zona(da_fuso)
    destinazione = _zona(a_fuso)
    with_tz = v.replace(tzinfo=sorgente)
    convertita = with_tz.astimezone(destinazione)
    return DataDante(convertita.replace(tzinfo=None))


# ---------------------------------------------------------------------------
# Cronometro (livello comodo)
# ---------------------------------------------------------------------------

@funzione_libreria("leggi_cronometro")
def leggi_cronometro(cronometro, decimali=3):
    """leggi_cronometro(cronometro, decimali = 3): i secondi passati su un `cronometro()`.

    Comodo per chi preferisce una funzione: `leggi_cronometro(c)` è come `c.secondi`.
    Esempio: `variabile c = cronometro()` ... `stampa(leggi_cronometro(c))`.
    """
    if not isinstance(cronometro, Cronometro):
        raise ErroreTipo(
            f"L'argomento `cronometro` di `leggi_cronometro` deve essere un cronometro, non {articolo(cronometro)}.",
            suggerimento="Crea un cronometro con `variabile c = cronometro()`.")
    richiedi_intero(decimali, "leggi_cronometro", "decimali")
    return round(cronometro.trascorso(), max(0, min(decimali, 9)))
