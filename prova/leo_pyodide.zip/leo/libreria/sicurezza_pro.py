"""Flussi di sicurezza per Leo Sicurezza: ricognizione, audit e analisi (blue e red team).

Verbi di alto livello che compongono i mattoni già presenti (porte, DNS, certificati, HTTP) in
compiti che un professionista lancia davvero: `scansiona_porte`, `intestazioni_sicurezza`,
`audita_sito`. Ognuno restituisce un risultato strutturato, pronto per un report.

Usa questi strumenti SOLO su sistemi tuoi o per cui hai un'autorizzazione esplicita.
"""

from __future__ import annotations

from typing import Any, Callable

from ..errori import ErroreValore
from .generali import funzione_libreria, richiedi_intero, richiedi_testo

#: porte comuni -> nome del servizio (per etichettare i risultati della scansione)
PORTE_NOTE: dict[int, str] = {
    21: "ftp", 22: "ssh", 23: "telnet", 25: "smtp", 53: "dns", 80: "http", 110: "pop3",
    123: "ntp", 135: "msrpc", 139: "netbios", 143: "imap", 161: "snmp", 389: "ldap",
    443: "https", 445: "smb", 465: "smtps", 587: "smtp", 631: "ipp", 993: "imaps",
    995: "pop3s", 1433: "mssql", 1521: "oracle", 2049: "nfs", 3306: "mysql", 3389: "rdp",
    5060: "sip", 5432: "postgres", 5900: "vnc", 6379: "redis", 8000: "http-alt",
    8080: "http-proxy", 8443: "https-alt", 9200: "elasticsearch", 27017: "mongodb",
}
#: intestazioni di sicurezza che un sito dovrebbe avere, con una spiegazione
INTESTAZIONI_SICUREZZA: dict[str, str] = {
    "strict-transport-security": "obbliga il browser a usare HTTPS (HSTS)",
    "content-security-policy": "limita da dove si caricano script e risorse (anti-XSS)",
    "x-content-type-options": "impedisce al browser di 'indovinare' il tipo dei file",
    "x-frame-options": "impedisce di incorniciare il sito in un altro (clickjacking)",
    "referrer-policy": "controlla quante informazioni escono nei link in uscita",
    "permissions-policy": "spegne funzioni del browser che il sito non usa (fotocamera, GPS...)",
}


@funzione_libreria("scansiona_porte", interprete=True)
def scansiona_porte(interprete, indirizzo, da=1, a=1024, tempo_massimo=1, _controlla=None):
    """scansiona_porte(indirizzo, da = 1, a = 1024): guarda quali porte sono aperte su un indirizzo
    (ricognizione). Restituisce una lista di {"porta", "servizio"}. Usala SOLO su sistemi tuoi o
    autorizzati. Esempio: `scansiona_porte("192.168.1.1", 1, 100)`.
    """
    indirizzo = richiedi_testo(indirizzo, "scansiona_porte", "indirizzo").strip()
    da = richiedi_intero(da, "scansiona_porte", "da") if da != 1 else 1
    a = richiedi_intero(a, "scansiona_porte", "a") if a != 1024 else 1024
    if not indirizzo:
        raise ErroreValore("Devi dire quale indirizzo scansionare.")
    if not (1 <= da <= 65535 and 1 <= a <= 65535) or da > a:
        raise ErroreValore("L'intervallo delle porte deve stare tra 1 e 65535, con `da` <= `a`.")
    if a - da > 5000:
        raise ErroreValore("Intervallo troppo grande (oltre 5000 porte): scansionane un pezzo per volta.",
                           suggerimento="Per esempio `scansiona_porte(indirizzo, 1, 1024)`.")
    controlla: Callable[..., bool] = _controlla if callable(_controlla) else _porta_aperta
    if _controlla is None or not callable(_controlla):
        import socket
        try:
            socket.getaddrinfo(indirizzo, None)   # risolve una volta: se l'host non esiste, fermati subito
        except OSError:
            raise ErroreValore(f"Non trovo l'indirizzo `{indirizzo}`.",
                               suggerimento="Controlla il nome o scrivi l'indirizzo IP.") from None
    aperte = []
    for porta in range(da, a + 1):
        try:
            if controlla(indirizzo, porta, tempo_massimo):
                aperte.append({"porta": porta, "servizio": PORTE_NOTE.get(porta, "?")})
        except Exception:
            continue
    return aperte


def _porta_aperta(indirizzo, porta, tempo):
    from .rete_sistema import porta_aperta
    return bool(porta_aperta(indirizzo, porta, tempo))


@funzione_libreria("intestazioni_sicurezza")
def intestazioni_sicurezza(indirizzo, _ottieni=None):
    """intestazioni_sicurezza(indirizzo): controlla le intestazioni di sicurezza HTTP di un sito e dice
    quali ci sono e quali mancano, con un voto. Esempio: `intestazioni_sicurezza("https://miosito.it")`.
    """
    indirizzo = richiedi_testo(indirizzo, "intestazioni_sicurezza", "indirizzo").strip()
    if not indirizzo:
        raise ErroreValore("Devi dire quale sito controllare.")
    ottieni: Callable[[str], dict] = _ottieni if callable(_ottieni) else _intestazioni_http
    testate = {str(k).lower(): v for k, v in ottieni(indirizzo).items()}
    presenti, mancanti = {}, []
    for nome, perche in INTESTAZIONI_SICUREZZA.items():
        if nome in testate:
            presenti[nome] = testate[nome]
        else:
            mancanti.append({"intestazione": nome, "perche": perche})
    totale = len(INTESTAZIONI_SICUREZZA)
    punti = len(presenti)
    voto = "ottimo" if punti == totale else "buono" if punti >= totale - 1 else \
           "da migliorare" if punti >= totale // 2 else "debole"
    return {"presenti": presenti, "mancanti": mancanti, "voto": voto,
            "punteggio": f"{punti}/{totale}"}


def _intestazioni_http(indirizzo):
    from .internet import richiesta_get
    return richiesta_get(indirizzo).get("intestazioni", {})


@funzione_libreria("audita_sito")
def audita_sito(indirizzo, _dns=None, _cert=None, _header=None):
    """audita_sito(indirizzo): un audit di sicurezza di un sito in un colpo solo — DNS, certificato TLS
    e intestazioni di sicurezza — e restituisce un report con i problemi trovati. Esempio:
    `variabile report = audita_sito("miosito.it")`.
    """
    indirizzo = richiedi_testo(indirizzo, "audita_sito", "indirizzo").strip()
    if not indirizzo:
        raise ErroreValore("Devi dire quale sito auditare.")
    dominio = indirizzo.replace("https://", "").replace("http://", "").split("/")[0].split(":")[0]

    dns = _dns if callable(_dns) else (lambda d: _dns_a(d))
    cert = _cert if callable(_cert) else (lambda d: _avvisi_cert(d))
    header = _header if callable(_header) else (lambda u: intestazioni_sicurezza(u))

    report: dict[str, Any] = {"sito": dominio, "problemi": []}
    try:
        report["indirizzi_ip"] = list(dns(dominio))
    except Exception as e:  # noqa: BLE001
        report["indirizzi_ip"] = []
        report["problemi"].append(f"DNS: non risolve ({e}).")
    if not report["indirizzi_ip"]:
        # l'host non esiste: inutile (e lento) provare certificato e intestazioni
        report["problemi"].append("Il sito non risolve: niente da auditare in HTTPS.")
        report["tutto_a_posto"] = False
        return report
    try:
        avvisi = list(cert(dominio))
        report["certificato"] = {"avvisi": avvisi, "ok": not avvisi}
        for a in avvisi:
            report["problemi"].append(f"Certificato: {a}")
    except Exception as e:  # noqa: BLE001
        report["certificato"] = {"avvisi": [], "ok": False, "errore": str(e)}
        report["problemi"].append("Certificato: non raggiungibile in HTTPS.")
    try:
        h = header("https://" + dominio)
        report["intestazioni"] = h
        for m in h.get("mancanti", []):
            report["problemi"].append(f"Intestazione mancante: {m['intestazione']} ({m['perche']}).")
    except Exception as e:  # noqa: BLE001
        report["intestazioni"] = {"errore": str(e)}
    report["tutto_a_posto"] = not report["problemi"]
    return report


def _dns_a(dominio):
    from .rete_bassa import dns_a
    return dns_a(dominio)


def _avvisi_cert(dominio):
    from .rete_bassa import avvisi_certificato
    return avvisi_certificato(dominio)


@funzione_libreria("tria_log")
def tria_log(percorso, formato="auto"):
    """tria_log(percorso): fa il triage di un file di log in un colpo solo (blue team) — lo legge,
    lo riassume e ne tira fuori IP sospetti, accessi falliti, orari insoliti e anomalie. Restituisce
    un report. Esempio: `variabile r = tria_log("access.log")`.
    """
    from .forense import (accessi_falliti, ip_sospetti, leggi_log, orari_insoliti,
                          riepilogo_log, trova_anomalie_log)
    percorso = richiedi_testo(percorso, "tria_log", "percorso")
    formato = richiedi_testo(formato, "tria_log", "formato") if formato != "auto" else "auto"
    eventi = leggi_log(percorso, formato)
    return {
        "eventi_totali": len(eventi),
        "riepilogo": riepilogo_log(eventi),
        "ip_sospetti": ip_sospetti(eventi),
        "accessi_falliti": accessi_falliti(eventi),
        "orari_insoliti": len(orari_insoliti(eventi)),
        "anomalie": trova_anomalie_log(eventi),
    }


__all__ = ["scansiona_porte", "intestazioni_sicurezza", "audita_sito", "tria_log",
           "PORTE_NOTE", "INTESTAZIONI_SICUREZZA"]
