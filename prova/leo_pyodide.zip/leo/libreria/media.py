"""Libreria **media**: un livello comodo e unico per immagini e audio.

Leo ha già i valori ``immagine`` (modulo ``immagini``) e ``suono`` (modulo
``suoni``), ricchi di metodi come ``foto.ridimensiona(200)`` o
``nota("la").con_volume(0.3)``. Questo modulo aggiunge **funzioni di comando**
in stile ``verbo_oggetto`` con l'immagine o il suono come **primo argomento**::

    foto = apri_immagine("gatto.jpg")        # da `immagini`
    ridimensiona(foto, 400)                  # invece di foto.ridimensiona(400)
    scrivi_testo = disegna_testo             # (esempio)
    salva_immagine(foto, "piccola.png")

È lo stile procedurale, comodo per chi preferisce i comandi ai metodi e per
insegnare passo passo. Le funzioni sulle immagini **modificano l'immagine data
e la restituiscono** (come i metodi: efficiente anche dentro i cicli); se vuoi
lasciare intatto l'originale fai prima ``copia_immagine(foto)``. Le funzioni sui
suoni, invece, restituiscono sempre un **suono nuovo** (un suono non cambia).

Niente da installare: se c'è Pillow lo usa, altrimenti Leo disegna e salva da
solo in PNG/BMP (immagini) e usa il modulo ``wave`` della libreria standard per
i file WAV (audio). Le funzioni che leggono o scrivono file passano dai permessi
come tutte le altre. Le costruttrici ``apri_immagine``, ``nuova_immagine``,
``dimensioni_immagine`` stanno già nel modulo ``immagini`` e si usano insieme a
queste senza doppioni.
"""

from __future__ import annotations

from typing import Any

from .generali import funzione_libreria
from .immagini import (
    Immagine,
    _immagine,
    immagine_bianco_e_nero,
    immagine_colore_pixel,
    immagine_disegna_cerchio,
    immagine_disegna_linea,
    immagine_disegna_rettangolo,
    immagine_imposta_pixel,
    immagine_incolla,
    immagine_capovolgi,
    immagine_ridimensiona,
    immagine_ritaglia,
    immagine_ruota,
    immagine_salva,
    immagine_scrivi_testo,
)
from .suoni import (
    Suono,
    _suono,
    carica_suono,
    salva_suono,
    suono_con_volume,
    suono_insieme,
    suono_poi,
    tono,
)

__all__ = [
    "copia_immagine", "salva_immagine", "ridimensiona", "ritaglia", "ruota",
    "specchia", "converti_in_grigio", "incolla_immagine", "disegna_rettangolo",
    "disegna_cerchio", "disegna_linea", "disegna_testo", "metti_pixel",
    "leggi_pixel", "genera_tono", "unisci_suoni", "salva_audio_wav",
    "carica_audio_wav", "durata_audio", "volume",
]


# ===========================================================================
# Immagini: comandi `verbo_oggetto` (modificano l'immagine data e la restituiscono)
# ===========================================================================

def _img(v: Any, funzione: str) -> Immagine:
    """L'immagine data, con un errore italiano chiaro se non lo è."""
    return _immagine(v, funzione, "immagine")


@funzione_libreria("copia_immagine")
def copia_immagine(immagine):
    """copia_immagine(immagine): una copia indipendente, da cambiare senza toccare l'originale.

    Utile prima di un comando che modifica l'immagine, per tenere intatto l'originale.
    Esempio: `piccola = ridimensiona(copia_immagine(foto), 200)`.
    """
    return _img(immagine, "copia_immagine").copia_interna()


@funzione_libreria("salva_immagine")
def salva_immagine(immagine, percorso, qualita=90):
    """salva_immagine(immagine, percorso, qualita = 90): scrive l'immagine in un file.

    Il formato viene dall'estensione (.png, .jpg, .webp, .gif, .bmp, .tiff, .ico);
    senza Pillow Leo salva in PNG o BMP. `qualita` (1-100) conta per JPEG e WebP.
    Esempio: `salva_immagine(foto, "ritratto.png")`.
    """
    return immagine_salva(_img(immagine, "salva_immagine"), percorso, qualita)


@funzione_libreria("ridimensiona")
def ridimensiona(immagine, larghezza, altezza=None, liscio=True):
    """ridimensiona(immagine, larghezza, altezza = nulla, liscio = vero): cambia le misure.

    Senza `altezza` mantiene le proporzioni; `liscio = falso` tiene i quadretti netti (pixel art).
    Modifica l'immagine data e la restituisce. Esempio: `ridimensiona(foto, 800)`.
    """
    return immagine_ridimensiona(_img(immagine, "ridimensiona"), larghezza, altezza, liscio)


@funzione_libreria("ritaglia")
def ritaglia(immagine, x, y, larghezza, altezza):
    """ritaglia(immagine, x, y, larghezza, altezza): tiene solo il rettangolo che parte da (x, y).

    (x, y) è l'angolo in alto a sinistra, con (0, 0) in cima all'immagine.
    Esempio: `ritaglia(foto, 100, 50, 300, 300)` tiene un quadrato di 300 pixel.
    """
    return immagine_ritaglia(_img(immagine, "ritaglia"), x, y, larghezza, altezza)


@funzione_libreria("ruota")
def ruota(immagine, gradi, sfondo="trasparente"):
    """ruota(immagine, gradi, sfondo = "trasparente"): gira l'immagine in senso orario.

    Con angoli non multipli di 90 l'immagine si allarga e gli angoli si riempiono di `sfondo`
    (senza Pillow si può ruotare solo di 90, 180, 270). Esempio: `ruota(foto, 90)`.
    """
    return immagine_ruota(_img(immagine, "ruota"), gradi, sfondo)


@funzione_libreria("specchia")
def specchia(immagine, direzione="orizzontale"):
    """specchia(immagine, direzione = "orizzontale"): riflette l'immagine come allo specchio.

    "orizzontale" scambia destra e sinistra, "verticale" alto e basso.
    Esempio: `specchia(foto)`, `specchia(foto, "verticale")`.
    """
    return immagine_capovolgi(_img(immagine, "specchia"), direzione)


@funzione_libreria("converti_in_grigio")
def converti_in_grigio(immagine):
    """converti_in_grigio(immagine): toglie i colori e lascia solo i grigi.

    Esempio: `salva_immagine(converti_in_grigio(apri_immagine("foto.jpg")), "bn.png")`.
    """
    return immagine_bianco_e_nero(_img(immagine, "converti_in_grigio"))


@funzione_libreria("incolla_immagine")
def incolla_immagine(immagine, altra, x=0, y=0, opacita=1):
    """incolla_immagine(immagine, altra, x = 0, y = 0, opacita = 1): mette `altra` sopra `immagine` in (x, y).

    Le parti trasparenti di `altra` lasciano vedere sotto; `opacita` da 0 (invisibile) a 1 (piena).
    Esempio: `incolla_immagine(foto, logo, 10, 10, 0.7)`.
    """
    return immagine_incolla(_img(immagine, "incolla_immagine"), altra, x, y, opacita)


@funzione_libreria("disegna_rettangolo")
def disegna_rettangolo(immagine, x, y, larghezza, altezza, colore="nero", pieno=True, spessore=3):
    """disegna_rettangolo(immagine, x, y, larghezza, altezza, colore = "nero", pieno = vero, spessore = 3).

    Disegna un rettangolo con l'angolo in alto a sinistra in (x, y); `pieno = falso` fa solo il bordo.
    Esempio: `disegna_rettangolo(foglio, 20, 20, 100, 60, "rosso")`.
    """
    return immagine_disegna_rettangolo(_img(immagine, "disegna_rettangolo"), x, y, larghezza, altezza,
                                       colore, pieno, spessore)


@funzione_libreria("disegna_cerchio")
def disegna_cerchio(immagine, x, y, raggio, colore="nero", pieno=True, spessore=3):
    """disegna_cerchio(immagine, x, y, raggio, colore = "nero", pieno = vero, spessore = 3): un cerchio con centro (x, y).

    `pieno = falso` fa solo il contorno. Esempio: `disegna_cerchio(foglio, 200, 150, 50, "giallo")`.
    """
    return immagine_disegna_cerchio(_img(immagine, "disegna_cerchio"), x, y, raggio, colore, pieno, spessore)


@funzione_libreria("disegna_linea")
def disegna_linea(immagine, x1, y1, x2, y2, colore="nero", spessore=3):
    """disegna_linea(immagine, x1, y1, x2, y2, colore = "nero", spessore = 3): una linea da (x1, y1) a (x2, y2).

    Esempio: `disegna_linea(foglio, 0, 0, 400, 300, "blu", 5)`.
    """
    return immagine_disegna_linea(_img(immagine, "disegna_linea"), x1, y1, x2, y2, colore, spessore)


@funzione_libreria("disegna_testo")
def disegna_testo(immagine, testo, x=10, y=10, colore="nero", dimensione=24, carattere=None, bordo=None):
    """disegna_testo(immagine, testo, x = 10, y = 10, colore = "nero", dimensione = 24, carattere = nulla, bordo = nulla).

    Scrive un testo con l'angolo in alto a sinistra in (x, y). `carattere` è il nome di un font
    (per esempio "arial"); `bordo` è il colore del contorno delle lettere. Richiede Pillow.
    Esempio: `disegna_testo(foto, "Ciao!", 30, 30, "giallo", 60, bordo = "nero")`.
    """
    return immagine_scrivi_testo(_img(immagine, "disegna_testo"), testo, x, y, colore, dimensione,
                                 carattere, bordo)


@funzione_libreria("metti_pixel")
def metti_pixel(immagine, x, y, colore):
    """metti_pixel(immagine, x, y, colore): colora un solo punto dell'immagine.

    Esempio: `per ogni x in 0..99 fai metti_pixel(foglio, x, 50, "rosso") fine`.
    """
    return immagine_imposta_pixel(_img(immagine, "metti_pixel"), x, y, colore)


@funzione_libreria("leggi_pixel")
def leggi_pixel(immagine, x, y):
    """leggi_pixel(immagine, x, y): il colore del punto (x, y) come testo "#RRGGBB".

    Esempio: `stampa(leggi_pixel(foto, 0, 0))` dice il colore dell'angolo in alto a sinistra.
    """
    return immagine_colore_pixel(_img(immagine, "leggi_pixel"), x, y)


# ===========================================================================
# Audio di base: toni e suoni WAV (restituiscono sempre un suono nuovo)
# ===========================================================================

@funzione_libreria("genera_tono")
def genera_tono(frequenza, durata=1, forma="sinusoide", volume=0.8):
    """genera_tono(frequenza, durata = 1, forma = "sinusoide", volume = 0.8): un suono puro di quella frequenza (in hertz).

    `durata` è in secondi; le forme sono "sinusoide", "quadra", "triangolo", "dente_di_sega".
    Esempio: `suona(genera_tono(440, 0.5))` fa un la per mezzo secondo.
    """
    return tono(frequenza, durata, forma, volume)


@funzione_libreria("unisci_suoni")
def unisci_suoni(*suoni, insieme=False):
    """unisci_suoni(suono1, suono2, ...) oppure unisci_suoni(lista, insieme = falso): unisce più suoni in uno solo.

    Senza `insieme` i suoni vanno **uno dopo l'altro**; con `insieme = vero` suonano **sovrapposti**.
    Accetta anche una lista di suoni. Esempio: `unisci_suoni(nota("do"), nota("mi"), nota("sol"))`.
    """
    elenco = list(suoni[0]) if len(suoni) == 1 and isinstance(suoni[0], list) else list(suoni)
    if not elenco:
        from ..errori import ErroreValore

        raise ErroreValore("`unisci_suoni` vuole almeno un suono.",
                           suggerimento="Per esempio `unisci_suoni(nota(\"do\"), nota(\"mi\"))`.")
    risultato = _suono(elenco[0], "unisci_suoni", "suono1")
    for i, altro in enumerate(elenco[1:], start=2):
        altro = _suono(altro, "unisci_suoni", f"suono{i}")
        risultato = suono_insieme(risultato, altro) if insieme else suono_poi(risultato, altro)
    return risultato


@funzione_libreria("salva_audio_wav")
def salva_audio_wav(suono, percorso):
    """salva_audio_wav(suono, percorso): scrive il suono in un file WAV; restituisce il nome del file.

    Esempio: `salva_audio_wav(genera_tono(440, 1), "la.wav")`.
    """
    return salva_suono(_suono(suono, "salva_audio_wav"), percorso)


@funzione_libreria("carica_audio_wav")
def carica_audio_wav(percorso):
    """carica_audio_wav(percorso): legge un file WAV e lo restituisce come suono da unire o modificare.

    Legge i WAV non compressi (PCM); converti prima gli MP3. Esempio: `voce = carica_audio_wav("voce.wav")`.
    """
    return carica_suono(percorso)


@funzione_libreria("durata_audio")
def durata_audio(suono):
    """durata_audio(suono): quanti secondi dura il suono (un numero).

    Esempio: `stampa(durata_audio(carica_audio_wav("canzone.wav")))`.
    """
    return round(_suono(suono, "durata_audio").durata, 3)


@funzione_libreria("volume")
def volume(suono, livello):
    """volume(suono, livello): un suono nuovo più forte o più piano (0 = muto, 1 = pieno, oppure 0-100).

    Esempio: `piano = volume(carica_audio_wav("voce.wav"), 0.3)`.
    """
    return suono_con_volume(_suono(suono, "volume"), livello)
