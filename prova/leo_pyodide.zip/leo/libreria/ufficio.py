"""Libreria: ufficio (Excel, Word, PDF) con la sola libreria standard di Python.

Tutto è scritto a mano con ``zipfile``, ``xml.etree`` e ``zlib``: funziona anche
sul telefono (Chaquopy) e dentro gli .exe, senza pacchetti da installare.

* **Excel** (.xlsx, e anche OpenDocument .ods): ``leggi_excel``, ``scrivi_excel``,
  ``scrivi_fogli_excel``, ``elenca_fogli_excel``, ``leggi_cella_excel``,
  ``leggi_intervallo_excel``, ``nome_colonna_excel``, ``numero_colonna_excel``.
  Numeri, date (valori ``data``), importi ``soldi``, logici e formule
  (anche con i nomi italiani: ``"=SOMMA(B2:B9)"``).
* **Word** (.docx, e anche .odt): ``leggi_word``, ``paragrafi_word``,
  ``tabelle_word``, ``scrivi_word``, ``sostituisci_in_word``, ``stampa_unione``.
* **Documenti** con titoli, paragrafi (``**grassetto**``, ``*corsivo*``), elenchi,
  tabelle e immagini: ``nuovo_documento`` restituisce un ``documento`` con i
  metodi ``aggiungi_titolo``, ``aggiungi_paragrafo``, ``aggiungi_elenco``,
  ``aggiungi_tabella``, ``aggiungi_immagine``, ``aggiungi_interruzione_pagina``
  e ``salva`` (in .docx, .odt, .pdf, .html, .md o .txt, secondo l'estensione).
* **PDF**: ``scrivi_pdf``, ``leggi_pdf``, ``conta_pagine_pdf``, ``info_pdf``,
  ``unisci_pdf``, ``estrai_pagine_pdf``, ``ruota_pagine_pdf``, ``immagini_in_pdf``.
  I PDF si creano con i caratteri standard (Helvetica) e le immagini JPEG e PNG;
  si leggono con un piccolo lettore interno. Se è installato il pacchetto
  facoltativo ``pypdf``, ``leggi_pdf`` lo usa quando il lettore interno non
  trova il testo.

Sicurezza: i file letti possono venire da chiunque, quindi ci sono limiti alle
dimensioni (niente "bombe zip"), l'XML non risolve entità esterne e i PDF protetti
da password vengono rifiutati con un messaggio chiaro.
"""

from __future__ import annotations

import base64
import copy
import datetime
import io
import math
import os
import posixpath
import re
import struct
import tempfile
import unicodedata
import zipfile
import zlib
import xml.etree.ElementTree as ET
from decimal import Decimal
from typing import Any

from ..errori import ErroreFile, ErroreTipo, ErroreValore
from ..valori import rappresenta
from .date import DataDante
from .generali import articolo, funzione_libreria, mostra, richiedi_intero, richiedi_logico, richiedi_testo
from .ingresso_uscita import _controlla_percorso, _errore_file
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta

#: Un file più grande di così (in byte) non si apre.
MASSIMO_FILE = 200 * 1024 * 1024
#: Una parte di un file Office (dentro lo zip) più grande di così, una volta estratta, è rifiutata.
MASSIMA_PARTE = 300 * 1024 * 1024
#: Massimo numero di celle di una griglia letta o scritta.
MASSIME_CELLE = 5_000_000
#: Righe massime per la stampa unione.
MASSIME_LETTERE = 10_000
#: Righe e colonne massime di un foglio Excel.
MASSIME_RIGHE_EXCEL = 1_048_576
MASSIME_COLONNE_EXCEL = 16_384

_OLE = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"
_XML_VIETATI = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff\ufffe\uffff]")


# ---------------------------------------------------------------------------
# Aiuti comuni
# ---------------------------------------------------------------------------

def _x(testo: str) -> str:
    """Il testo pronto per stare dentro l'XML (caratteri speciali e vietati)."""
    testo = _XML_VIETATI.sub("", testo)
    return testo.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def _nome_xml(tag: Any) -> str:
    """Il nome di un elemento XML senza lo spazio dei nomi (``{...}p`` -> ``p``)."""
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


def _in_testo(valore: Any) -> str:
    """Il testo con cui un valore compare in un documento o in una lettera."""
    if valore is None:
        return ""
    if isinstance(valore, str):
        return valore
    return rappresenta(valore)


def _estensione(percorso: str) -> str:
    return os.path.splitext(percorso)[1].lower()


def _elenco_estensioni(estensioni: tuple[str, ...]) -> str:
    voci = [f"`{e}`" for e in estensioni]
    return voci[0] if len(voci) == 1 else ", ".join(voci[:-1]) + " o " + voci[-1]


def _percorso_da_leggere(percorso: Any, nome: str, estensioni: tuple[str, ...]) -> str:
    """Controlla il percorso di un file da leggere; senza estensione prova quelle ammesse."""
    _controlla_percorso(percorso, nome)
    if not _estensione(percorso) and not os.path.exists(percorso):
        for e in estensioni:
            if os.path.isfile(percorso + e):
                return percorso + e
    return percorso


def _percorso_da_scrivere(percorso: Any, nome: str, estensioni: tuple[str, ...]) -> str:
    """Controlla il percorso di un file da scrivere; senza estensione aggiunge la prima ammessa."""
    _controlla_percorso(percorso, nome)
    estensione = _estensione(percorso)
    if not estensione:
        return percorso + estensioni[0]
    if estensione not in estensioni:
        raise ErroreValore(f"`{nome}` non sa scrivere file `{estensione}`.",
                           suggerimento=f"Usa un nome che finisce con {_elenco_estensioni(estensioni)}.")
    if os.path.isdir(percorso):
        raise ErroreFile(f"`{percorso}` è una cartella, non un file.")
    return percorso


def _leggi_byte(percorso: str, nome: str) -> bytes:
    try:
        with open(percorso, "rb") as f:
            f.seek(0, os.SEEK_END)
            if f.tell() > MASSIMO_FILE:
                raise ErroreValore(f"Il file `{percorso}` è troppo grande per `{nome}` "
                                   f"(più di {MASSIMO_FILE // (1024 * 1024)} MB).")
            f.seek(0)
            return f.read()
    except OSError as e:
        raise _errore_file(e, percorso, "leggere") from None


def _scrivi_byte(percorso: str, dati: bytes) -> None:
    """Scrive il file tutto insieme: se qualcosa va storto il vecchio file resta com'era."""
    cartella = os.path.dirname(os.path.abspath(percorso))
    temporaneo = None
    try:
        descrittore, temporaneo = tempfile.mkstemp(prefix=".leo_", suffix=".tmp", dir=cartella)
        with os.fdopen(descrittore, "wb") as f:
            f.write(dati)
        os.replace(temporaneo, percorso)
        temporaneo = None
    except OSError as e:
        if isinstance(e, FileNotFoundError) and not os.path.isdir(cartella):
            raise ErroreFile(f"Non posso scrivere `{percorso}`: la cartella `{os.path.dirname(percorso)}` "
                             "non esiste.") from None
        raise _errore_file(e, percorso, "scrivere") from None
    finally:
        if temporaneo is not None:
            try:
                os.remove(temporaneo)
            except OSError:
                pass


def _crea_cartella_di(percorso: str) -> None:
    cartella = os.path.dirname(percorso)
    if cartella and not os.path.isdir(cartella):
        try:
            os.makedirs(cartella, exist_ok=True)
        except OSError as e:
            raise _errore_file(e, cartella, "creare la cartella per") from None


def _nuova_voce(info: zipfile.ZipInfo) -> zipfile.ZipInfo:
    """Una copia della voce di un archivio da scrivere in un altro (quella originale non va toccata)."""
    nuova = zipfile.ZipInfo(info.filename, info.date_time)
    nuova.compress_type = zipfile.ZIP_STORED if info.filename == "mimetype" else zipfile.ZIP_DEFLATED
    nuova.external_attr = info.external_attr
    return nuova


def _zip(parti: list[tuple[str, bytes | str]], mimetype: str | None = None) -> bytes:
    """Un archivio zip in memoria (i file Office e OpenDocument sono archivi zip di XML)."""
    uscita = io.BytesIO()
    with zipfile.ZipFile(uscita, "w", compression=zipfile.ZIP_DEFLATED) as z:
        if mimetype is not None:  # OpenDocument: `mimetype` per primo e non compresso
            z.writestr(zipfile.ZipInfo("mimetype", (1980, 1, 1, 0, 0, 0)), mimetype.encode("ascii"),
                       compress_type=zipfile.ZIP_STORED)
        for nome, contenuto in parti:
            z.writestr(nome, contenuto.encode("utf-8") if isinstance(contenuto, str) else contenuto)
    return uscita.getvalue()


class _Pacchetto:
    """Un file Office o OpenDocument aperto (un archivio zip di parti XML)."""

    def __init__(self, percorso: str, nome: str, tipo: str) -> None:
        self.percorso = percorso
        self.nome = nome
        dati = _leggi_byte(percorso, nome)
        if dati[:8] == _OLE:
            raise ErroreValore(f"Il file `{percorso}` è nel vecchio formato di Office (.xls o .doc) "
                               "oppure è protetto da una password.",
                               suggerimento=f"Aprilo con Office o LibreOffice e salvalo come {tipo}.")
        if dati[:5] == b"%PDF-":
            raise ErroreValore(f"Il file `{percorso}` è un PDF, non un {tipo}.",
                               suggerimento="Per i PDF usa `leggi_pdf`.")
        try:
            self.zip = zipfile.ZipFile(io.BytesIO(dati))
        except (zipfile.BadZipFile, zipfile.LargeZipFile, NotImplementedError, ValueError, OSError, EOFError,
                UnicodeDecodeError):
            raise self.rotto() from None
        self.nomi = set(self.zip.namelist())

    def rotto(self, dettaglio: str = "") -> ErroreValore:
        return ErroreValore(f"Il file `{self.percorso}` non è un file valido per `{self.nome}` "
                            f"oppure è danneggiato{dettaglio}.",
                            suggerimento="Prova ad aprirlo e salvarlo di nuovo con Office o LibreOffice.")

    def c_e(self, parte: str) -> bool:
        return parte in self.nomi

    def leggi(self, parte: str) -> bytes:
        try:
            info = self.zip.getinfo(parte)
        except KeyError:
            raise self.rotto(f" (manca la parte `{parte}`)") from None
        if info.file_size > MASSIMA_PARTE:
            raise ErroreValore(f"Il file `{self.percorso}` è troppo grande da aprire.")
        try:
            with self.zip.open(info) as f:
                dati = f.read(MASSIMA_PARTE + 1)
        except (zipfile.BadZipFile, zlib.error, NotImplementedError, RuntimeError, ValueError, OSError, EOFError):
            raise self.rotto() from None
        if len(dati) > MASSIMA_PARTE:
            raise ErroreValore(f"Il file `{self.percorso}` è troppo grande da aprire.")
        return dati

    def xml(self, parte: str) -> ET.Element:
        return self.analizza(self.leggi(parte))

    def analizza(self, dati: bytes) -> ET.Element:
        if b"<!ENTITY" in dati:
            raise self.rotto(" (contiene definizioni XML non ammesse)")
        try:
            return ET.fromstring(dati)
        except (ET.ParseError, ValueError, RecursionError):
            raise self.rotto() from None

    def relazioni(self, parte: str) -> dict[str, tuple[str, str]]:
        """Le relazioni di una parte: identificativo -> (tipo, parte di destinazione)."""
        cartella, nome = posixpath.split(parte)
        rels = posixpath.join(cartella, "_rels", nome + ".rels")
        if not self.c_e(rels):
            return {}
        risultato = {}
        for r in self.xml(rels):
            if _nome_xml(r.tag) != "Relationship" or r.get("TargetMode") == "External":
                continue
            destinazione = r.get("Target", "")
            if destinazione.startswith("/"):
                destinazione = destinazione[1:]
            else:
                destinazione = posixpath.normpath(posixpath.join(cartella, destinazione))
            risultato[r.get("Id", "")] = (r.get("Type", "").rsplit("/", 1)[-1], destinazione)
        return risultato

    def parte_principale(self, predefinita: str) -> str:
        for tipo, destinazione in self.relazioni("").values():
            if tipo == "officeDocument" and self.c_e(destinazione):
                return destinazione
        if self.c_e(predefinita):
            return predefinita
        raise self.rotto()


def _richiedi_righe(righe: Any, nome: str, parametro: str = "righe") -> list:
    if isinstance(righe, list):
        return righe
    if isinstance(righe, tuple):
        return list(righe)
    raise ErroreTipo(f"L'argomento `{parametro}` di `{nome}` deve essere una lista di righe "
                     f"(dizionari o liste), non {articolo(righe)}.",
                     suggerimento=f"Per esempio `{nome}(..., [{{\"nome\": \"Ada\", \"voto\": 9}}])`.")


def _tabella_da_righe(righe: Any, nome: str) -> tuple[list[list[Any]], bool]:
    """Una lista di dizionari o di liste come griglia; vero se la prima riga è l'intestazione."""
    righe = _richiedi_righe(righe, nome)
    if len(righe) > MASSIME_RIGHE_EXCEL:
        raise ErroreValore(f"Troppe righe per `{nome}`: al massimo {MASSIME_RIGHE_EXCEL}.")
    if not righe:
        return [], False
    if all(isinstance(r, dict) for r in righe):
        chiavi: dict[Any, None] = {}
        for r in righe:
            for k in r:
                chiavi.setdefault(k, None)
        colonne = list(chiavi)
        griglia = [[_in_testo(k) for k in colonne]]
        griglia += [[r.get(k) for k in colonne] for r in righe]
        return griglia, True
    if any(isinstance(r, dict) for r in righe):
        raise ErroreValore(f"Le righe di `{nome}` devono essere tutte dizionari o tutte liste.")
    griglia = [list(r) if isinstance(r, (list, tuple)) else [r] for r in righe]
    intestazione = len(griglia) > 1 and bool(griglia[0]) and all(isinstance(v, str) for v in griglia[0])
    return griglia, intestazione


def _controlla_celle(griglia: list[list[Any]], nome: str) -> None:
    larghezza = max((len(r) for r in griglia), default=0)
    if larghezza > MASSIME_COLONNE_EXCEL:
        raise ErroreValore(f"Troppe colonne per `{nome}`: al massimo {MASSIME_COLONNE_EXCEL}.")
    if larghezza * len(griglia) > MASSIME_CELLE:
        raise ErroreValore(f"La tabella di `{nome}` è troppo grande (più di {MASSIME_CELLE} celle).")


# ---------------------------------------------------------------------------
# Immagini (JPEG, PNG, GIF): dimensioni e dati per i documenti
# ---------------------------------------------------------------------------

class _Immagine:
    def __init__(self, percorso: str, dati: bytes, formato: str, larghezza: int, altezza: int) -> None:
        self.percorso = percorso
        self.dati = dati
        self.formato = formato          # "jpeg", "png" o "gif"
        self.larghezza = larghezza      # pixel
        self.altezza = altezza
        self.componenti = 3             # JPEG: 1 grigio, 3 colori, 4 CMYK
        self.adobe = False              # JPEG CMYK di Adobe (colori invertiti)
        self.orientamento = 1           # JPEG: orientamento EXIF (1 normale, 3, 6, 8 ruotate)

    @property
    def estensione(self) -> str:
        return {"jpeg": "jpg"}.get(self.formato, self.formato)

    @property
    def larghezza_vista(self) -> int:
        return self.altezza if self.orientamento in (5, 6, 7, 8) else self.larghezza

    @property
    def altezza_vista(self) -> int:
        return self.larghezza if self.orientamento in (5, 6, 7, 8) else self.altezza


def _orientamento_exif(segmento: bytes) -> int:
    if not segmento.startswith(b"Exif\x00\x00") or len(segmento) < 14:
        return 1
    tiff = segmento[6:]
    ordine = {b"II": "<", b"MM": ">"}.get(tiff[:2])
    if ordine is None:
        return 1
    try:
        inizio = struct.unpack(ordine + "I", tiff[4:8])[0]
        quante = struct.unpack(ordine + "H", tiff[inizio:inizio + 2])[0]
        for i in range(min(quante, 200)):
            voce = tiff[inizio + 2 + 12 * i: inizio + 14 + 12 * i]
            if len(voce) < 12:
                break
            if struct.unpack(ordine + "H", voce[:2])[0] == 0x0112:
                valore = struct.unpack(ordine + "H", voce[8:10])[0]
                return valore if 1 <= valore <= 8 else 1
    except struct.error:
        return 1
    return 1


def _leggi_immagine(percorso: Any, nome: str) -> _Immagine:
    _controlla_percorso(percorso, nome)
    dati = _leggi_byte(percorso, nome)
    if dati[:2] == b"\xff\xd8":
        return _info_jpeg(percorso, dati)
    if dati[:8] == b"\x89PNG\r\n\x1a\n" and len(dati) >= 24 and dati[12:16] == b"IHDR":
        larghezza, altezza = struct.unpack(">II", dati[16:24])
        if larghezza and altezza:
            return _Immagine(percorso, dati, "png", larghezza, altezza)
    if dati[:6] in (b"GIF87a", b"GIF89a") and len(dati) >= 10:
        larghezza, altezza = struct.unpack("<HH", dati[6:10])
        if larghezza and altezza:
            return _Immagine(percorso, dati, "gif", larghezza, altezza)
    raise ErroreValore(f"Il file `{percorso}` non è un'immagine JPEG, PNG o GIF.",
                       suggerimento="Salva l'immagine come .jpg o .png.")


def _info_jpeg(percorso: str, dati: bytes) -> _Immagine:
    pos = 2
    orientamento, adobe = 1, False
    while pos + 4 <= len(dati):
        if dati[pos] != 0xFF:
            pos += 1
            continue
        marcatore = dati[pos + 1]
        if marcatore in (0xFF,):
            pos += 1
            continue
        if marcatore in (0xD8, 0x01) or 0xD0 <= marcatore <= 0xD7:
            pos += 2
            continue
        lunghezza = struct.unpack(">H", dati[pos + 2:pos + 4])[0]
        segmento = dati[pos + 4:pos + 2 + lunghezza]
        if marcatore == 0xE1:
            orientamento = _orientamento_exif(segmento)
        elif marcatore == 0xEE and segmento.startswith(b"Adobe"):
            adobe = True
        elif marcatore in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
            if len(segmento) >= 6:
                altezza, larghezza = struct.unpack(">HH", segmento[1:5])
                if larghezza and altezza:
                    immagine = _Immagine(percorso, dati, "jpeg", larghezza, altezza)
                    immagine.componenti = segmento[5]
                    immagine.orientamento = orientamento
                    immagine.adobe = adobe
                    return immagine
            break
        elif marcatore == 0xDA:
            break
        pos += 2 + lunghezza
    raise ErroreValore(f"Il file `{percorso}` sembra un JPEG ma è danneggiato.")


# ---------------------------------------------------------------------------
# Excel: colonne e riferimenti
# ---------------------------------------------------------------------------

_ESTENSIONI_EXCEL = (".xlsx", ".xlsm", ".ods")
_RE_CELLA = re.compile(r"^\$?([A-Za-z]{1,3})\$?(\d{1,7})$")


def _lettere_colonna(numero: int) -> str:
    lettere = ""
    while numero > 0:
        numero, resto = divmod(numero - 1, 26)
        lettere = chr(65 + resto) + lettere
    return lettere


def _numero_colonna(lettere: str) -> int:
    numero = 0
    for c in lettere.upper():
        numero = numero * 26 + ord(c) - 64
    return numero


def _cella(riferimento: str, nome: str) -> tuple[int, int]:
    """``"B3"`` -> (riga 3, colonna 2)."""
    m = _RE_CELLA.match(riferimento.strip())
    if m:
        colonna, riga = _numero_colonna(m.group(1)), int(m.group(2))
        if 1 <= colonna <= MASSIME_COLONNE_EXCEL and 1 <= riga <= MASSIME_RIGHE_EXCEL:
            return riga, colonna
    raise ErroreValore(f"{mostra(riferimento)} non è una cella valida per `{nome}`.",
                       suggerimento="Una cella si scrive con la colonna e la riga, per esempio \"B3\".")


def _dividi_foglio(riferimento: str) -> tuple[str | None, str]:
    """``"Foglio2!A1:B3"`` -> ("Foglio2", "A1:B3")."""
    if "!" in riferimento:
        foglio, _, resto = riferimento.rpartition("!")
        foglio = foglio.strip()
        if len(foglio) >= 2 and foglio[0] == foglio[-1] == "'":
            foglio = foglio[1:-1].replace("''", "'")
        return foglio, resto
    return None, riferimento


# ---------------------------------------------------------------------------
# Excel: lettura (.xlsx e .ods)
# ---------------------------------------------------------------------------

_BASE_1900 = datetime.datetime(1899, 12, 30)
_BASE_1904 = datetime.datetime(1904, 1, 1)
_FORMATI_DATA = set(range(14, 23)) | {45, 46, 47}


def _formato_e_data(codice: str) -> bool:
    pulito = re.sub(r'"[^"]*"|\[[^\]]*\]|\\.|_.|\*.', "", codice).lower()
    return bool(re.search(r"[dmyhs]", pulito)) and "general" not in pulito


def _da_numero_data(numero: float, sistema_1904: bool) -> Any:
    if not math.isfinite(numero) or not -1 < numero < 2958466:
        return numero
    if numero < 1 and not sistema_1904:
        secondi = round(numero * 86400)
        return f"{secondi // 3600:02d}:{secondi // 60 % 60:02d}" + (f":{secondi % 60:02d}" if secondi % 60 else "")
    base = _BASE_1904 if sistema_1904 else (_BASE_1900 if numero >= 61 else datetime.datetime(1899, 12, 31))
    try:
        momento = base + datetime.timedelta(seconds=round(numero * 86400))
    except OverflowError:
        return numero
    if momento.year < 1:
        return numero
    return DataDante(momento)


def _numero_excel(testo: str) -> Any:
    try:
        valore = float(testo)
    except ValueError:
        return testo
    if valore.is_integer() and abs(valore) < 2 ** 53:
        return int(valore)
    return valore


class _Cartella:
    """Una cartella di lavoro aperta: i nomi dei fogli e, a richiesta, le celle di uno."""

    def __init__(self, percorso: Any, nome: str) -> None:
        percorso = _percorso_da_leggere(percorso, nome, _ESTENSIONI_EXCEL)
        if _estensione(percorso) in (".csv", ".tsv", ".txt"):
            raise ErroreValore(f"`{percorso}` è un file di testo (CSV), non un file Excel.",
                               suggerimento=f"Per i file CSV usa `leggi_tabella({mostra(percorso)})`.")
        self.nome = nome
        self.percorso = percorso
        self.ods = _estensione(percorso) in (".ods", ".ots")
        self.pacchetto = _Pacchetto(percorso, nome, "file .ods" if self.ods else "file Excel .xlsx")
        if self.ods:
            self._fogli_ods = self._leggi_ods()
            self.nomi = [n for n, _ in self._fogli_ods]
        else:
            self._prepara_xlsx()

    # -- scelta del foglio --------------------------------------------------
    def indice(self, foglio: Any) -> int:
        if not self.nomi:
            raise ErroreValore(f"Il file `{self.percorso}` non ha fogli con dati.")
        if foglio is None:
            return 0
        if isinstance(foglio, bool) or not isinstance(foglio, (int, str)):
            raise ErroreTipo(f"L'argomento `foglio` di `{self.nome}` deve essere il nome del foglio o il suo "
                             f"numero (da 1), non {articolo(foglio)}.")
        if isinstance(foglio, int):
            if 1 <= foglio <= len(self.nomi):
                return foglio - 1
            raise ErroreValore(f"Il file `{self.percorso}` ha {len(self.nomi)} fogli: il numero {mostra(foglio)} "
                               "non va bene.", suggerimento=f"Usa un numero da 1 a {len(self.nomi)}.")
        if foglio in self.nomi:
            return self.nomi.index(foglio)
        for i, n in enumerate(self.nomi):
            if n.strip().casefold() == foglio.strip().casefold():
                return i
        raise ErroreValore(f"Nel file `{self.percorso}` non c'è il foglio {mostra(foglio)}.",
                           suggerimento="I fogli sono: " + ", ".join(mostra(n) for n in self.nomi) + ".")

    def celle(self, foglio: Any) -> dict[tuple[int, int], Any]:
        i = self.indice(foglio)
        if self.ods:
            return self._fogli_ods[i][1]
        return self._leggi_foglio_xlsx(self._parti[i])

    # -- xlsx ---------------------------------------------------------------
    def _prepara_xlsx(self) -> None:
        p = self.pacchetto
        principale = p.parte_principale("xl/workbook.xml")
        libro = p.xml(principale)
        relazioni = p.relazioni(principale)
        self.sistema_1904 = False
        self.nomi, self._parti = [], []
        condivisi = stili = None
        for tipo, destinazione in relazioni.values():
            if tipo == "sharedStrings":
                condivisi = destinazione
            elif tipo == "styles":
                stili = destinazione
        for elemento in libro.iter():
            nome = _nome_xml(elemento.tag)
            if nome == "workbookPr" and elemento.get("date1904", "").lower() in ("1", "true"):
                self.sistema_1904 = True
            elif nome == "sheet":
                rid = next((v for k, v in elemento.attrib.items() if _nome_xml(k) == "id"), "")
                tipo, destinazione = relazioni.get(rid, ("", ""))
                if tipo == "worksheet" and p.c_e(destinazione):
                    self.nomi.append(elemento.get("name", f"Foglio{len(self.nomi) + 1}"))
                    self._parti.append(destinazione)
        self.testi = self._testi_condivisi(condivisi) if condivisi and p.c_e(condivisi) else []
        self.date = self._stili_data(stili) if stili and p.c_e(stili) else []

    def _testi_condivisi(self, parte: str) -> list[str]:
        testi = []
        for si in self.pacchetto.xml(parte):
            if _nome_xml(si.tag) != "si":
                continue
            pezzi = []
            for figlio in si:
                n = _nome_xml(figlio.tag)
                if n == "t":
                    pezzi.append(figlio.text or "")
                elif n == "r":
                    pezzi.extend(t.text or "" for t in figlio if _nome_xml(t.tag) == "t")
            testi.append("".join(pezzi))
        return testi

    def _stili_data(self, parte: str) -> list[bool]:
        radice = self.pacchetto.xml(parte)
        personali: dict[int, str] = {}
        risultato: list[bool] = []
        for elemento in radice:
            n = _nome_xml(elemento.tag)
            if n == "numFmts":
                for f in elemento:
                    try:
                        personali[int(f.get("numFmtId", "-1"))] = f.get("formatCode", "")
                    except ValueError:
                        pass
            elif n == "cellXfs":
                for xf in elemento:
                    try:
                        codice = int(xf.get("numFmtId", "0"))
                    except ValueError:
                        codice = 0
                    risultato.append(codice in _FORMATI_DATA if codice not in personali
                                     else _formato_e_data(personali[codice]))
        return risultato

    def _leggi_foglio_xlsx(self, parte: str) -> dict[tuple[int, int], Any]:
        radice = self.pacchetto.xml(parte)
        celle: dict[tuple[int, int], Any] = {}
        dati_foglio = next((e for e in radice if _nome_xml(e.tag) == "sheetData"), None)
        if dati_foglio is None:
            return celle
        numero_riga = 0
        for riga in dati_foglio:
            if _nome_xml(riga.tag) != "row":
                continue
            try:
                numero_riga = int(riga.get("r", numero_riga + 1))
            except ValueError:
                numero_riga += 1
            colonna = 0
            for c in riga:
                if _nome_xml(c.tag) != "c":
                    continue
                riferimento = c.get("r")
                m = _RE_CELLA.match(riferimento) if riferimento else None
                colonna = _numero_colonna(m.group(1)) if m else colonna + 1
                valore = self._valore_xlsx(c)
                if valore is not None and valore != "":
                    celle[(numero_riga, colonna)] = valore
                if len(celle) > MASSIME_CELLE:
                    raise ErroreValore(f"Il foglio di `{self.percorso}` ha troppe celle (più di {MASSIME_CELLE}).")
        return celle

    def _valore_xlsx(self, c: ET.Element) -> Any:
        tipo = c.get("t", "n")
        v = None
        testo_in_linea = None
        for figlio in c:
            n = _nome_xml(figlio.tag)
            if n == "v":
                v = figlio.text or ""
            elif n == "is":
                pezzi = []
                for parte in figlio:
                    if _nome_xml(parte.tag) == "t":
                        pezzi.append(parte.text or "")
                    elif _nome_xml(parte.tag) == "r":
                        pezzi.extend(t.text or "" for t in parte if _nome_xml(t.tag) == "t")
                testo_in_linea = "".join(pezzi)
        if tipo == "inlineStr":
            return testo_in_linea
        if v is None:
            return None
        if tipo == "s":
            try:
                return self.testi[int(v)]
            except (ValueError, IndexError):
                return ""
        if tipo == "b":
            return v.strip() in ("1", "true")
        if tipo in ("str", "e"):
            return v
        if tipo == "d":
            try:
                return DataDante(datetime.datetime.fromisoformat(v.strip()[:19]))
            except ValueError:
                return v
        numero = _numero_excel(v)
        try:
            stile = int(c.get("s", "0"))
        except ValueError:
            stile = 0
        if isinstance(numero, (int, float)) and 0 <= stile < len(self.date) and self.date[stile]:
            return _da_numero_data(float(numero), self.sistema_1904)
        return numero

    # -- ods ----------------------------------------------------------------
    def _leggi_ods(self) -> list[tuple[str, dict[tuple[int, int], Any]]]:
        radice = self.pacchetto.xml("content.xml")
        fogli = []
        for tabella in radice.iter(_T + "table"):
            fogli.append((tabella.get(_T + "name", f"Foglio{len(fogli) + 1}"), self._tabella_ods(tabella)))
        return fogli

    def _tabella_ods(self, tabella: ET.Element) -> dict[tuple[int, int], Any]:
        celle: dict[tuple[int, int], Any] = {}
        numero_riga = 0

        def righe(elemento):
            for figlio in elemento:
                n = _nome_xml(figlio.tag)
                if n == "table-row":
                    yield figlio
                elif n in ("table-header-rows", "table-rows", "table-row-group"):
                    yield from righe(figlio)

        for riga in righe(tabella):
            ripeti_riga = _ripetizioni(riga.get(_T + "number-rows-repeated"))
            valori: dict[int, Any] = {}
            colonna = 0
            for c in riga:
                if _nome_xml(c.tag) not in ("table-cell", "covered-table-cell"):
                    continue
                ripeti = _ripetizioni(c.get(_T + "number-columns-repeated"))
                valore = _valore_ods(c)
                if valore is not None and valore != "":
                    for k in range(min(ripeti, 1024)):
                        valori[colonna + 1 + k] = valore
                colonna += ripeti
            if valori:
                for k in range(min(ripeti_riga, 1024)):
                    for col, valore in valori.items():
                        celle[(numero_riga + 1 + k, col)] = valore
                if len(celle) > MASSIME_CELLE:
                    raise ErroreValore(f"Il foglio di `{self.percorso}` ha troppe celle.")
            numero_riga += ripeti_riga
        return celle


def _ripetizioni(testo: str | None) -> int:
    try:
        return max(1, min(int(testo), MASSIME_RIGHE_EXCEL)) if testo else 1
    except ValueError:
        return 1


# spazi dei nomi di OpenDocument
_NS_ODF = {
    "office": "urn:oasis:names:tc:opendocument:xmlns:office:1.0",
    "table": "urn:oasis:names:tc:opendocument:xmlns:table:1.0",
    "text": "urn:oasis:names:tc:opendocument:xmlns:text:1.0",
}
_O = "{%s}" % _NS_ODF["office"]
_T = "{%s}" % _NS_ODF["table"]
_TX = "{%s}" % _NS_ODF["text"]


def _testo_odf(elemento: ET.Element) -> str:
    """Il testo di un paragrafo OpenDocument (con spazi, tabulazioni e a capo)."""
    pezzi = [elemento.text or ""]
    for figlio in elemento:
        n = _nome_xml(figlio.tag)
        if n == "s":
            pezzi.append(" " * _ripetizioni(figlio.get(_TX + "c")))
        elif n == "tab":
            pezzi.append("\t")
        elif n == "line-break":
            pezzi.append("\n")
        elif n in ("note", "annotation", "bookmark", "bookmark-start", "bookmark-end"):
            pass
        else:
            pezzi.append(_testo_odf(figlio))
        pezzi.append(figlio.tail or "")
    return "".join(pezzi)


def _valore_ods(c: ET.Element) -> Any:
    tipo = c.get(_O + "value-type")
    if tipo in ("float", "percentage", "currency"):
        return _numero_excel(c.get(_O + "value", ""))
    if tipo == "boolean":
        return c.get(_O + "boolean-value", "").lower() == "true"
    if tipo == "date":
        testo = c.get(_O + "date-value", "")
        try:
            return DataDante(datetime.datetime.fromisoformat(testo[:19]))
        except ValueError:
            return testo
    if tipo == "time":
        m = re.match(r"PT(\d+)H(\d+)M(\d+)", c.get(_O + "time-value", ""))
        if m:
            ore, minuti, secondi = (int(g) for g in m.groups())
            return f"{ore:02d}:{minuti:02d}" + (f":{secondi:02d}" if secondi else "")
    paragrafi = [_testo_odf(p) for p in c if _nome_xml(p.tag) in ("p", "h")]
    return "\n".join(paragrafi) if paragrafi else None


def _riquadro(celle: dict[tuple[int, int], Any]) -> tuple[int, int, int, int] | None:
    if not celle:
        return None
    righe = [r for r, _ in celle]
    colonne = [c for _, c in celle]
    return min(righe), min(colonne), max(righe), max(colonne)


def _griglia(celle: dict[tuple[int, int], Any], r1: int, c1: int, r2: int, c2: int, nome: str) -> list[list[Any]]:
    if (r2 - r1 + 1) * (c2 - c1 + 1) > MASSIME_CELLE:
        raise ErroreValore(f"L'intervallo di `{nome}` è troppo grande (più di {MASSIME_CELLE} celle).",
                           suggerimento="Leggi un pezzo alla volta con `leggi_intervallo_excel`.")
    return [[celle.get((r, c)) for c in range(c1, c2 + 1)] for r in range(r1, r2 + 1)]


def _nomi_intestazione(riga: list[Any]) -> list[str]:
    nomi: list[str] = []
    for i, v in enumerate(riga, 1):
        nome = _in_testo(v).strip() or f"colonna_{i}"
        base, n = nome, 2
        while nome in nomi:
            nome = f"{base}_{n}"
            n += 1
        nomi.append(nome)
    return nomi


# ---------------------------------------------------------------------------
# Excel: scrittura (.xlsx e .ods)
# ---------------------------------------------------------------------------

#: Nomi italiani delle funzioni di Excel più comuni -> nomi nel file (inglesi).
_FUNZIONI_EXCEL = {
    "SOMMA": "SUM", "MEDIA": "AVERAGE", "MIN": "MIN", "MAX": "MAX", "CONTA.NUMERI": "COUNT",
    "CONTA.VALORI": "COUNTA", "CONTA.VUOTE": "COUNTBLANK", "CONTA.SE": "COUNTIF", "SOMMA.SE": "SUMIF",
    "MEDIA.SE": "AVERAGEIF", "SE": "IF", "E": "AND", "O": "OR", "NON": "NOT", "ARROTONDA": "ROUND",
    "ARROTONDA.PER.ECC": "ROUNDUP", "ARROTONDA.PER.DIF": "ROUNDDOWN", "INT": "INT", "ASS": "ABS",
    "RADQ": "SQRT", "POTENZA": "POWER", "RESTO": "MOD", "PRODOTTO": "PRODUCT", "OGGI": "TODAY",
    "ADESSO": "NOW", "ANNO": "YEAR", "MESE": "MONTH", "GIORNO": "DAY", "CONCATENA": "CONCATENATE",
    "MAIUSC": "UPPER", "MINUSC": "LOWER", "LUNGHEZZA": "LEN", "SINISTRA": "LEFT", "DESTRA": "RIGHT",
    "STRINGA.ESTRAI": "MID", "ANNULLA.SPAZI": "TRIM", "CERCA.VERT": "VLOOKUP", "CERCA.ORIZZ": "HLOOKUP",
    "INDICE": "INDEX", "CONFRONTA": "MATCH", "SE.ERRORE": "IFERROR", "MEDIANA": "MEDIAN",
    "DEV.ST": "STDEV", "TESTO": "TEXT", "VALORE": "VALUE", "CASUALE": "RAND", "CASUALE.TRA": "RANDBETWEEN",
    "PI.GRECO": "PI", "RANGO": "RANK", "GRANDE": "LARGE", "PICCOLO": "SMALL", "SOMMA.PIÙ.SE": "SUMIFS",
    "SOMMA.PIU.SE": "SUMIFS", "CONTA.PIÙ.SE": "COUNTIFS", "CONTA.PIU.SE": "COUNTIFS",
}
_RE_FORMULA = re.compile(r'"(?:[^"]|"")*"|([A-Za-zÀ-ÿ_][A-Za-zÀ-ÿ0-9_.]*)(?=\s*\()|;|,')


def _formula_excel(testo: str) -> str:
    """``"=SOMMA(A1:A3; 2,5)"`` -> ``"SUM(A1:A3, 2.5)"`` (come Excel la salva nel file)."""
    corpo = testo[1:]
    punto_e_virgola = any(m.group(0) == ";" for m in _RE_FORMULA.finditer(corpo))

    def cambia(m: re.Match) -> str:
        pezzo = m.group(0)
        if m.group(1):
            return _FUNZIONI_EXCEL.get(pezzo.upper(), pezzo.upper())
        if pezzo == ";":
            return ","
        if pezzo == "," and punto_e_virgola:
            return "."
        return pezzo

    return _RE_FORMULA.sub(cambia, corpo)


_RE_RIF_ODS = re.compile(r'"(?:[^"]|"")*"|(?:(\'[^\']+\'|[A-Za-z_][\w.]*)!)?(\$?[A-Z]{1,3}\$?\d+)'
                         r'(?::(\$?[A-Z]{1,3}\$?\d+))?(?![\w(])|,')


def _formula_ods(formula: str) -> str:
    """Da formula di Excel (già in inglese) a formula OpenDocument (``of:=SUM([.A1:.A3])``)."""

    def cambia(m: re.Match) -> str:
        pezzo = m.group(0)
        if pezzo.startswith('"'):
            return pezzo
        if pezzo == ",":
            return ";"
        foglio = m.group(1)
        prefisso = "$" + foglio.replace("'", "") + "." if foglio else "."
        if m.group(3):
            return f"[{prefisso}{m.group(2)}:.{m.group(3)}]"
        return f"[{prefisso}{m.group(2)}]"

    return "of:=" + _RE_RIF_ODS.sub(cambia, formula)


def _giorni_excel(d: DataDante) -> float | None:
    v = d.valore
    if v.year < 1900 or (v.year == 1900 and v.month < 3):
        return None
    giorni = (v - _BASE_1900).total_seconds() / 86400
    return round(giorni, 10)


class _Cella:
    """Una cella da scrivere: tipo ("n" numero, "s" testo, "b" logico, "f" formula, "d" data), valore, stile."""

    __slots__ = ("tipo", "valore", "stile", "testo", "risultato")

    def __init__(self, tipo: str, valore: Any, testo: str, stile: str = "") -> None:
        self.tipo, self.valore, self.testo, self.stile = tipo, valore, testo, stile
        self.risultato: Any = None      # formule: il risultato calcolato da Leo (se è una formula semplice)


def _cella_da_valore(v: Any, nome: str) -> _Cella | None:
    if v is None:
        return None
    if isinstance(v, bool):
        return _Cella("b", v, "VERO" if v else "FALSO")
    if isinstance(v, int):
        if abs(v) < 10 ** 15:
            return _Cella("n", v, str(v))
        return _Cella("s", str(v), str(v))
    if isinstance(v, float):
        if math.isfinite(v):
            return _Cella("n", v, rappresenta(v))
        return _Cella("s", rappresenta(v), rappresenta(v))
    if isinstance(v, str):
        if len(v) > 32767:
            raise ErroreValore(f"Un testo di `{nome}` è troppo lungo per una cella (al massimo 32767 caratteri).")
        if v.startswith("=") and len(v) > 1:
            return _Cella("f", v, v)
        if v.startswith("'="):
            v = v[1:]
        return _Cella("s", v, v)
    if isinstance(v, DataDante):
        testo = v.testo_dante()
        return _Cella("d", v, testo, "dataora" if v.ha_orario else "data")
    tipo = getattr(v, "NOME_TIPO_DANTE", "")
    if tipo == "soldi" and isinstance(getattr(v, "valore", None), Decimal):
        return _Cella("n", float(v.valore), v.testo_dante(), "soldi:" + str(getattr(v, "valuta", "€")))
    if tipo == "frazione":
        try:
            return _Cella("n", float(v.valore), v.testo_dante())
        except (OverflowError, ValueError, TypeError, AttributeError):
            pass
    testo = _in_testo(v)
    return _Cella("s", testo, testo)


class _Righe(list):
    """Le celle di un foglio da scrivere, con le larghezze delle colonne scelte (se ci sono)."""

    larghezze: dict[int, float] = {}


def _prepara_foglio(righe: Any, nome: str, larghezze: Any = None) -> tuple[list[list[_Cella | None]], bool]:
    griglia, intestazione = _tabella_da_righe(righe, nome)
    _controlla_celle(griglia, nome)
    celle = _Righe([_cella_da_valore(v, nome) for v in riga] for riga in griglia)
    celle.larghezze = _larghezze_scelte(larghezze, griglia[0] if intestazione else [], nome)
    _calcola_formule(celle)
    return celle, intestazione


def _larghezze_scelte(larghezze: Any, intestazione: list[Any], nome: str) -> dict[int, float]:
    """Le larghezze date da chi scrive: una lista (una per colonna) o un dizionario colonna -> larghezza.

    Le colonne del dizionario si scrivono con le lettere ("A") o con il nome dell'intestazione ("nome").
    La larghezza si misura in caratteri, come in Excel.
    """
    if larghezze is None:
        return {}
    if isinstance(larghezze, list):
        coppie = list(enumerate(larghezze, 1))
    elif isinstance(larghezze, dict):
        coppie = []
        for chiave, valore in larghezze.items():
            if isinstance(chiave, str) and chiave in intestazione:
                coppie.append((intestazione.index(chiave) + 1, valore))
            elif isinstance(chiave, str) and re.fullmatch(r"[A-Za-z]{1,3}", chiave):
                coppie.append((_numero_colonna(chiave), valore))
            elif isinstance(chiave, int) and not isinstance(chiave, bool) and chiave >= 1:
                coppie.append((chiave, valore))
            else:
                raise ErroreValore(f"Non trovo la colonna {mostra(chiave)} per le larghezze di `{nome}`.",
                                   suggerimento="Scrivi le lettere della colonna (\"A\") o il nome "
                                                "dell'intestazione (\"nome\").")
    else:
        raise ErroreTipo(f"L'argomento `larghezze` di `{nome}` deve essere una lista di numeri o un dizionario, "
                         f"non {articolo(larghezze)}.",
                         suggerimento="Per esempio `[20, 10, 12]` oppure `{\"nome\": 25}`.")
    risultato: dict[int, float] = {}
    for colonna, valore in coppie:
        if valore is None:
            continue
        if isinstance(valore, bool) or not isinstance(valore, (int, float)) or not 0 < valore <= 255:
            raise ErroreValore(f"La larghezza di una colonna di `{nome}` deve essere un numero da 1 a 255 "
                               f"(in caratteri), non {mostra(valore)}.")
        risultato[colonna] = float(valore)
    return risultato


# -- Formule semplici: Leo ne calcola il risultato, così si legge subito ------------

_RE_GETTONE_FORMULA = re.compile(
    r"\s*(?:(?P<num>\d+(?:\.\d*)?(?:[eE][+-]?\d+)?|\.\d+)"
    r"|(?P<rif>\$?[A-Z]{1,3}\$?\d+(?::\$?[A-Z]{1,3}\$?\d+)?)(?![\w(!])"
    r"|(?P<fun>[A-Z][A-Z0-9.]*)\s*\("
    r"|(?P<op><>|<=|>=|[-+*/^(),=<>&%]))")

_FUNZIONI_CALCOLABILI = {
    "SUM": sum,
    "AVERAGE": lambda v: sum(v) / len(v) if v else None,
    "MIN": lambda v: min(v) if v else 0,
    "MAX": lambda v: max(v) if v else 0,
    "COUNT": len,
    "PRODUCT": lambda v: math.prod(v),
}


class _NonCalcolabile(Exception):
    """La formula è troppo complicata per il piccolo calcolatore: ci penserà Excel."""


class _Calcolatore:
    """Calcola le formule semplici: numeri, celle, + - * / ^, SOMMA, MEDIA, MIN, MAX, CONTA, ARROTONDA, ASS."""

    def __init__(self, celle: list[list[_Cella | None]]) -> None:
        self.celle = celle
        self.in_corso: set[tuple[int, int]] = set()

    def valore_cella(self, riga: int, colonna: int, in_intervallo: bool = False) -> Any:
        if riga > len(self.celle) or colonna > len(self.celle[riga - 1]):
            return None
        c = self.celle[riga - 1][colonna - 1]
        if c is None:
            return None
        if c.tipo == "n":
            return c.valore
        if c.tipo == "b":
            return None if in_intervallo else int(c.valore)
        if c.tipo == "f":
            return self.risultato(c, (riga, colonna))
        if in_intervallo:
            return None
        raise _NonCalcolabile

    def risultato(self, c: _Cella, posto: tuple[int, int]) -> Any:
        if c.risultato is not None:
            return c.risultato
        if posto in self.in_corso:
            raise _NonCalcolabile
        self.in_corso.add(posto)
        try:
            gettoni = self.gettoni(_formula_excel(c.valore))
            self.pos = 0
            self.lista = gettoni
            valore = self.espressione()
            if self.pos != len(gettoni):
                raise _NonCalcolabile
        finally:
            self.in_corso.discard(posto)
        c.risultato = valore
        return valore

    @staticmethod
    def gettoni(testo: str) -> list[tuple[str, str]]:
        gettoni = []
        pos = 0
        testo = testo.rstrip()
        while pos < len(testo):
            m = _RE_GETTONE_FORMULA.match(testo, pos)
            if not m or m.end() == pos:
                raise _NonCalcolabile
            tipo = m.lastgroup or ""
            gettoni.append((tipo, m.group(tipo)))
            pos = m.end()
        return gettoni

    def guarda(self) -> tuple[str, str]:
        return self.lista[self.pos] if self.pos < len(self.lista) else ("", "")

    def prendi(self, atteso: str | None = None) -> tuple[str, str]:
        g = self.guarda()
        if not g[0] or (atteso is not None and g[1] != atteso):
            raise _NonCalcolabile
        self.pos += 1
        return g

    def espressione(self) -> float:
        valore = self.termine()
        while self.guarda() in (("op", "+"), ("op", "-")):
            segno = self.prendi()[1]
            destra = self.termine()
            valore = valore + destra if segno == "+" else valore - destra
        return valore

    def termine(self) -> float:
        valore = self.fattore()
        while self.guarda() in (("op", "*"), ("op", "/")):
            segno = self.prendi()[1]
            destra = self.fattore()
            if segno == "*":
                valore = valore * destra
            elif destra == 0:
                raise _NonCalcolabile
            else:
                valore = valore / destra
        return valore

    def fattore(self) -> float:
        if self.guarda() in (("op", "-"), ("op", "+")):
            segno = self.prendi()[1]
            valore = self.fattore()
            return -valore if segno == "-" else valore
        base = self.atomo()
        if self.guarda() == ("op", "%"):
            self.prendi()
            base = base / 100
        if self.guarda() == ("op", "^"):
            self.prendi()
            esponente = self.fattore()
            if abs(esponente) > 1000:
                raise _NonCalcolabile
            try:
                return float(base) ** esponente
            except (OverflowError, ZeroDivisionError, ValueError):
                raise _NonCalcolabile from None
        return base

    def atomo(self) -> float:
        tipo, testo = self.prendi()
        if tipo == "num":
            numero = float(testo)
            return int(numero) if numero.is_integer() and "." not in testo and "e" not in testo.lower() else numero
        if tipo == "rif":
            if ":" in testo:
                raise _NonCalcolabile
            riga, colonna = _cella(testo.replace("$", ""), "formula")
            valore = self.valore_cella(riga, colonna)
            return 0 if valore is None else valore
        if tipo == "op" and testo == "(":
            valore = self.espressione()
            self.prendi(")")
            return valore
        if tipo == "fun":
            return self.funzione(testo)
        raise _NonCalcolabile

    def argomenti(self) -> list[Any]:
        """Gli argomenti di una funzione: numeri singoli o liste (dagli intervalli)."""
        argomenti: list[Any] = []
        if self.guarda() == ("op", ")"):
            self.prendi()
            return argomenti
        while True:
            tipo, testo = self.guarda()
            dopo = self.lista[self.pos + 1] if self.pos + 1 < len(self.lista) else ("", "")
            if tipo == "rif" and ":" in testo and dopo[1] in (",", ")"):
                self.prendi()
                inizio, _, fine = testo.replace("$", "").partition(":")
                r1, c1 = _cella(inizio, "formula")
                r2, c2 = _cella(fine, "formula")
                if (abs(r2 - r1) + 1) * (abs(c2 - c1) + 1) > 1_000_000:
                    raise _NonCalcolabile
                valori = []
                for r in range(min(r1, r2), max(r1, r2) + 1):
                    for col in range(min(c1, c2), max(c1, c2) + 1):
                        v = self.valore_cella(r, col, in_intervallo=True)
                        if v is not None:
                            valori.append(v)
                argomenti.append(valori)
            else:
                argomenti.append(self.espressione())
            separatore = self.prendi()[1]
            if separatore == ")":
                return argomenti
            if separatore != ",":
                raise _NonCalcolabile

    def funzione(self, nome: str) -> float:
        argomenti = self.argomenti()
        if nome in _FUNZIONI_CALCOLABILI:
            valori: list[Any] = []
            for a in argomenti:
                valori.extend(a if isinstance(a, list) else [a])
            risultato = _FUNZIONI_CALCOLABILI[nome](valori)
            if risultato is None:
                raise _NonCalcolabile
            return risultato
        if any(isinstance(a, list) for a in argomenti):
            raise _NonCalcolabile
        if nome == "ROUND" and len(argomenti) in (1, 2):
            cifre = int(argomenti[1]) if len(argomenti) == 2 else 0
            d = Decimal(repr(float(argomenti[0]))).quantize(Decimal(1).scaleb(-cifre), rounding="ROUND_HALF_UP")
            return int(d) if cifre <= 0 else float(d)
        if nome == "ABS" and len(argomenti) == 1:
            return abs(argomenti[0])
        if nome == "SQRT" and len(argomenti) == 1 and argomenti[0] >= 0:
            return math.sqrt(argomenti[0])
        if nome == "PI" and not argomenti:
            return math.pi
        raise _NonCalcolabile


def _calcola_formule(celle: list[list[_Cella | None]]) -> None:
    """Mette in ogni formula semplice il suo risultato (le altre le calcola Excel all'apertura)."""
    calcolatore = _Calcolatore(celle)
    for r, riga in enumerate(celle, 1):
        for col, c in enumerate(riga, 1):
            if c is None or c.tipo != "f" or c.risultato is not None:
                continue
            try:
                valore = calcolatore.risultato(c, (r, col))
            except (_NonCalcolabile, ErroreValore, ArithmeticError, ValueError, TypeError, RecursionError):
                calcolatore.in_corso.clear()
                continue
            if isinstance(valore, float) and math.isfinite(valore):
                valore = float(f"{valore:.15g}")    # come Excel: 15 cifre (0.1 * 3 -> 0.3)
            if isinstance(valore, float) and not math.isfinite(valore):
                c.risultato = None
            elif isinstance(valore, float) and valore.is_integer() and abs(valore) < 10 ** 15:
                c.risultato = int(valore)
            else:
                c.risultato = valore


def _larghezze(celle: list[list[_Cella | None]]) -> list[float]:
    colonne = max((len(r) for r in celle), default=0)
    scelte = getattr(celle, "larghezze", {}) or {}
    if scelte:
        colonne = max(colonne, max(scelte))
    larghezze = [8.0] * colonne
    for riga in celle[:2000]:
        for i, c in enumerate(riga):
            if c is None:
                continue
            testo = c.testo if c.tipo != "f" else "0000000000"
            lunghezza = max((len(p) for p in testo.split("\n")), default=0)
            larghezze[i] = max(larghezze[i], min(lunghezza + 2.0, 60.0))
    for colonna, larghezza in scelte.items():
        larghezze[colonna - 1] = larghezza
    return larghezze


_VIETATI_FOGLIO = re.compile(r"[\[\]:*?/\\]")


def _nomi_fogli(nomi: list[Any], nome: str) -> list[str]:
    risultato: list[str] = []
    for n in nomi:
        if not isinstance(n, str):
            raise ErroreTipo(f"Il nome di un foglio di `{nome}` deve essere un testo, non {articolo(n)}.")
        pulito = n.strip()
        if not pulito:
            raise ErroreValore(f"Il nome di un foglio di `{nome}` è vuoto.")
        if len(pulito) > 31 or _VIETATI_FOGLIO.search(pulito) or _XML_VIETATI.search(pulito) \
                or pulito.startswith("'") or pulito.endswith("'"):
            raise ErroreValore(f"Il nome di foglio {mostra(n)} non va bene per Excel.",
                               suggerimento="Al massimo 31 caratteri, senza [ ] : * ? / \\ e senza apostrofi "
                                            "all'inizio o alla fine.")
        if pulito.casefold() in (r.casefold() for r in risultato):
            raise ErroreValore(f"Ci sono due fogli con lo stesso nome {mostra(pulito)}.")
        risultato.append(pulito)
    return risultato


_NS_MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
_NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
_NS_PKG_REL = "http://schemas.openxmlformats.org/package/2006/relationships"
_TIPO_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/"
_XML_TESTA = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'


def _core_xml(titolo: str = "") -> str:
    adesso = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return (_XML_TESTA + '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/'
            'core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            + (f"<dc:title>{_x(titolo)}</dc:title>" if titolo else "")
            + f'<dc:creator>Leo</dc:creator><dcterms:created xsi:type="dcterms:W3CDTF">{adesso}</dcterms:created>'
            f'<dcterms:modified xsi:type="dcterms:W3CDTF">{adesso}</dcterms:modified></cp:coreProperties>')


def _xlsx(fogli: list[tuple[str, list[list[_Cella | None]], bool]]) -> bytes:
    testi: dict[str, int] = {}
    valute: dict[str, int] = {}
    parti: list[tuple[str, str]] = []
    for numero, (_, celle, intestazione) in enumerate(fogli, 1):
        parti.append((f"xl/worksheets/sheet{numero}.xml", _foglio_xlsx(celle, intestazione, testi, valute)))
    formati = ['<numFmt numFmtId="164" formatCode="dd/mm/yyyy"/>',
               '<numFmt numFmtId="165" formatCode="dd/mm/yyyy hh:mm"/>']
    stili = ['<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>',
             '<xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>',
             '<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>',
             '<xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>',
             '<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0" applyAlignment="1">'
             '<alignment wrapText="1" vertical="top"/></xf>']
    for valuta, indice in sorted(valute.items(), key=lambda v: v[1]):
        codice = 166 + indice
        formati.append(f'<numFmt numFmtId="{codice}" formatCode="{_x("#,##0.00 " + chr(34) + valuta + chr(34))}"/>')
        stili.append(f'<xf numFmtId="{codice}" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>')
    stili_xml = (_XML_TESTA + f'<styleSheet xmlns="{_NS_MAIN}"><numFmts count="{len(formati)}">{"".join(formati)}'
                 '</numFmts><fonts count="2"><font><sz val="11"/><name val="Calibri"/><family val="2"/></font>'
                 '<font><b/><sz val="11"/><name val="Calibri"/><family val="2"/></font></fonts>'
                 '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill '
                 'patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFDDEBF7"/>'
                 '<bgColor indexed="64"/></patternFill></fill></fills>'
                 '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
                 '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
                 f'<cellXfs count="{len(stili)}">{"".join(stili)}</cellXfs>'
                 '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>')
    elenco_testi = sorted(testi, key=testi.__getitem__)
    condivisi = (_XML_TESTA + f'<sst xmlns="{_NS_MAIN}" count="{len(elenco_testi)}" uniqueCount="{len(elenco_testi)}">'
                 + "".join(f'<si><t xml:space="preserve">{_x(t)}</t></si>' for t in elenco_testi) + "</sst>")
    fogli_xml = "".join(f'<sheet name="{_x(n)}" sheetId="{i}" r:id="rId{i}"/>' for i, (n, _, _) in enumerate(fogli, 1))
    libro = (_XML_TESTA + f'<workbook xmlns="{_NS_MAIN}" xmlns:r="{_NS_REL}"><workbookPr/><bookViews>'
             f'<workbookView activeTab="0"/></bookViews><sheets>{fogli_xml}</sheets>'
             '<calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>')
    n = len(fogli)
    rel_libro = (_XML_TESTA + f'<Relationships xmlns="{_NS_PKG_REL}">'
                 + "".join(f'<Relationship Id="rId{i}" Type="{_TIPO_REL}worksheet" Target="worksheets/sheet{i}.xml"/>'
                           for i in range(1, n + 1))
                 + f'<Relationship Id="rId{n + 1}" Type="{_TIPO_REL}styles" Target="styles.xml"/>'
                 f'<Relationship Id="rId{n + 2}" Type="{_TIPO_REL}sharedStrings" Target="sharedStrings.xml"/>'
                 "</Relationships>")
    tipi = (_XML_TESTA + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.'
            'spreadsheetml.sheet.main+xml"/>'
            + "".join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-'
                      'officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1, n + 1))
            + '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.'
            'spreadsheetml.styles+xml"/><Override PartName="/xl/sharedStrings.xml" ContentType="application/'
            'vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>'
            '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.'
            'core-properties+xml"/></Types>')
    rel = (_XML_TESTA + f'<Relationships xmlns="{_NS_PKG_REL}"><Relationship Id="rId1" Type="{_TIPO_REL}'
           'officeDocument" Target="xl/workbook.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/'
           'package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>')
    return _zip([("[Content_Types].xml", tipi), ("_rels/.rels", rel), ("docProps/core.xml", _core_xml()),
                 ("xl/workbook.xml", libro), ("xl/_rels/workbook.xml.rels", rel_libro), ("xl/styles.xml", stili_xml),
                 ("xl/sharedStrings.xml", condivisi)] + parti)


def _foglio_xlsx(celle: list[list[_Cella | None]], intestazione: bool, testi: dict[str, int],
                 valute: dict[str, int]) -> str:
    pezzi = [_XML_TESTA, f'<worksheet xmlns="{_NS_MAIN}" xmlns:r="{_NS_REL}">']
    if intestazione:
        pezzi.append('<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" '
                     'activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>')
    larghezze = _larghezze(celle)
    if larghezze:
        pezzi.append("<cols>" + "".join(f'<col min="{i}" max="{i}" width="{w:.1f}" customWidth="1"/>'
                                        for i, w in enumerate(larghezze, 1)) + "</cols>")
    pezzi.append("<sheetData>")
    for r, riga in enumerate(celle, 1):
        pezzi.append(f'<row r="{r}">')
        for col, c in enumerate(riga, 1):
            if c is None:
                continue
            rif = _lettere_colonna(col) + str(r)
            stile = 1 if intestazione and r == 1 else 0
            if c.stile == "data":
                stile = 2
            elif c.stile == "dataora":
                stile = 3
            elif c.stile.startswith("soldi:"):
                stile = 5 + valute.setdefault(c.stile[6:], len(valute))
            elif c.tipo == "s" and "\n" in c.valore and stile == 0:
                stile = 4
            s = f' s="{stile}"' if stile else ""
            if c.tipo == "n":
                pezzi.append(f'<c r="{rif}"{s}><v>{c.valore!r}</v></c>')
            elif c.tipo == "b":
                pezzi.append(f'<c r="{rif}" t="b"{s}><v>{int(c.valore)}</v></c>')
            elif c.tipo == "f":
                valore = f"<v>{c.risultato!r}</v>" if c.risultato is not None else ""
                pezzi.append(f'<c r="{rif}"{s}><f>{_x(_formula_excel(c.valore))}</f>{valore}</c>')
            elif c.tipo == "d":
                giorni = _giorni_excel(c.valore)
                if giorni is None:
                    indice = testi.setdefault(c.testo, len(testi))
                    pezzi.append(f'<c r="{rif}" t="s"><v>{indice}</v></c>')
                else:
                    pezzi.append(f'<c r="{rif}"{s}><v>{giorni!r}</v></c>')
            else:
                indice = testi.setdefault(c.valore, len(testi))
                pezzi.append(f'<c r="{rif}" t="s"{s}><v>{indice}</v></c>')
        pezzi.append("</row>")
    pezzi.append("</sheetData>")
    if intestazione and len(celle) > 1 and larghezze:
        pezzi.append(f'<autoFilter ref="A1:{_lettere_colonna(len(larghezze))}{len(celle)}"/>')
    pezzi.append('<pageMargins left="0.7" right="0.7" top="0.75" bottom="0.75" header="0.3" footer="0.3"/>'
                 "</worksheet>")
    return "".join(pezzi)


_NS_ODF_TUTTI = (
    'xmlns:office="urn:oasis:names:tc:opendocument:xmlns:office:1.0" '
    'xmlns:style="urn:oasis:names:tc:opendocument:xmlns:style:1.0" '
    'xmlns:text="urn:oasis:names:tc:opendocument:xmlns:text:1.0" '
    'xmlns:table="urn:oasis:names:tc:opendocument:xmlns:table:1.0" '
    'xmlns:draw="urn:oasis:names:tc:opendocument:xmlns:drawing:1.0" '
    'xmlns:fo="urn:oasis:names:tc:opendocument:xmlns:xsl-fo-compatible:1.0" '
    'xmlns:xlink="http://www.w3.org/1999/xlink" '
    'xmlns:dc="http://purl.org/dc/elements/1.1/" '
    'xmlns:meta="urn:oasis:names:tc:opendocument:xmlns:meta:1.0" '
    'xmlns:number="urn:oasis:names:tc:opendocument:xmlns:datastyle:1.0" '
    'xmlns:svg="urn:oasis:names:tc:opendocument:xmlns:svg-compatible:1.0" '
    'xmlns:of="urn:oasis:names:tc:opendocument:xmlns:of:1.2" office:version="1.2"'
)


def _manifest(tipo: str, altri: list[tuple[str, str]] = ()) -> str:
    return (_XML_TESTA.replace(' standalone="yes"', "")
            + '<manifest:manifest xmlns:manifest="urn:oasis:names:tc:opendocument:xmlns:manifest:1.0" '
            'manifest:version="1.2">'
            f'<manifest:file-entry manifest:full-path="/" manifest:version="1.2" manifest:media-type="{tipo}"/>'
            '<manifest:file-entry manifest:full-path="content.xml" manifest:media-type="text/xml"/>'
            '<manifest:file-entry manifest:full-path="styles.xml" manifest:media-type="text/xml"/>'
            '<manifest:file-entry manifest:full-path="meta.xml" manifest:media-type="text/xml"/>'
            + "".join(f'<manifest:file-entry manifest:full-path="{p}" manifest:media-type="{t}"/>' for p, t in altri)
            + "</manifest:manifest>")


def _meta_odf(titolo: str = "") -> str:
    adesso = datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    return (_XML_TESTA.replace(' standalone="yes"', "") + f"<office:document-meta {_NS_ODF_TUTTI}><office:meta>"
            f"<meta:generator>Leo</meta:generator><meta:creation-date>{adesso}</meta:creation-date>"
            + (f"<dc:title>{_x(titolo)}</dc:title>" if titolo else "")
            + "</office:meta></office:document-meta>")


def _testo_in_odf(testo: str) -> str:
    """Testo per un paragrafo OpenDocument: spazi multipli, tabulazioni e a capo diventano elementi."""
    pezzi = []
    for i, riga in enumerate(testo.split("\n")):
        if i:
            pezzi.append("<text:line-break/>")
        for j, parte in enumerate(riga.split("\t")):
            if j:
                pezzi.append("<text:tab/>")
            parte = _x(parte)
            parte = re.sub(r"(?<= ) +|^ +", lambda m: f'<text:s text:c="{len(m.group(0))}"/>', parte)
            pezzi.append(parte)
    return "".join(pezzi)


def _ods(fogli: list[tuple[str, list[list[_Cella | None]], bool]]) -> bytes:
    colonne_stili: dict[str, str] = {}
    corpo = []
    for nome, celle, intestazione in fogli:
        corpo.append(f'<table:table table:name="{_x(nome)}">')
        for w in _larghezze(celle) or [8.0]:
            stile = colonne_stili.setdefault(f"{w * 0.19:.2f}cm", f"co{len(colonne_stili) + 1}")
            corpo.append(f'<table:table-column table:style-name="{stile}"/>')
        for r, riga in enumerate(celle, 1):
            corpo.append("<table:table-row>")
            if not riga:
                corpo.append("<table:table-cell/>")
            for c in riga:
                grassetto = ' table:style-name="ce_gr"' if intestazione and r == 1 else ""
                if c is None:
                    corpo.append(f"<table:table-cell{grassetto}/>")
                elif c.tipo == "n":
                    corpo.append(f'<table:table-cell{grassetto} office:value-type="float" office:value="{c.valore!r}">'
                                 f"<text:p>{_x(c.testo)}</text:p></table:table-cell>")
                elif c.tipo == "b":
                    corpo.append(f'<table:table-cell{grassetto} office:value-type="boolean" '
                                 f'office:boolean-value="{"true" if c.valore else "false"}"><text:p>{c.testo}</text:p>'
                                 "</table:table-cell>")
                elif c.tipo == "d":
                    v = c.valore.valore
                    stile = "ce_dataora" if c.stile == "dataora" else "ce_data"
                    corpo.append(f'<table:table-cell table:style-name="{stile}" office:value-type="date" '
                                 f'office:date-value="{v.year:04d}-{v.month:02d}-{v.day:02d}T{v.hour:02d}:{v.minute:02d}'
                                 f':{v.second:02d}"><text:p>{_x(c.testo)}</text:p></table:table-cell>')
                elif c.tipo == "f":
                    formula = _x(_formula_ods(_formula_excel(c.valore)))
                    if c.risultato is None:
                        corpo.append(f'<table:table-cell{grassetto} table:formula="{formula}"/>')
                    else:
                        corpo.append(f'<table:table-cell{grassetto} table:formula="{formula}" '
                                     f'office:value-type="float" office:value="{c.risultato!r}">'
                                     f"<text:p>{_x(rappresenta(c.risultato))}</text:p></table:table-cell>")
                else:
                    paragrafi = "".join(f"<text:p>{_testo_in_odf(p)}</text:p>" for p in c.valore.split("\n"))
                    corpo.append(f'<table:table-cell{grassetto} office:value-type="string">{paragrafi}'
                                 "</table:table-cell>")
            corpo.append("</table:table-row>")
        corpo.append("</table:table>")
    stili_colonne = "".join(f'<style:style style:name="{n}" style:family="table-column"><style:table-column-properties '
                            f'style:column-width="{w}"/></style:style>' for w, n in colonne_stili.items())
    contenuto = (_XML_TESTA.replace(' standalone="yes"', "") + f"<office:document-content {_NS_ODF_TUTTI}>"
                 "<office:automatic-styles>"
                 '<number:date-style style:name="N_data"><number:day number:style="long"/><number:text>/</number:text>'
                 '<number:month number:style="long"/><number:text>/</number:text><number:year number:style="long"/>'
                 '</number:date-style><number:date-style style:name="N_dataora"><number:day number:style="long"/>'
                 '<number:text>/</number:text><number:month number:style="long"/><number:text>/</number:text>'
                 '<number:year number:style="long"/><number:text> </number:text><number:hours number:style="long"/>'
                 '<number:text>:</number:text><number:minutes number:style="long"/></number:date-style>'
                 f"{stili_colonne}"
                 '<style:style style:name="ce_gr" style:family="table-cell"><style:table-cell-properties '
                 'fo:background-color="#ddebf7"/><style:text-properties fo:font-weight="bold"/></style:style>'
                 '<style:style style:name="ce_data" style:family="table-cell" style:data-style-name="N_data"/>'
                 '<style:style style:name="ce_dataora" style:family="table-cell" style:data-style-name="N_dataora"/>'
                 "</office:automatic-styles><office:body><office:spreadsheet>"
                 + "".join(corpo) + "</office:spreadsheet></office:body></office:document-content>")
    stili = (_XML_TESTA.replace(' standalone="yes"', "") + f"<office:document-styles {_NS_ODF_TUTTI}>"
             "<office:styles/></office:document-styles>")
    tipo = "application/vnd.oasis.opendocument.spreadsheet"
    return _zip([("META-INF/manifest.xml", _manifest(tipo)), ("content.xml", contenuto), ("styles.xml", stili),
                 ("meta.xml", _meta_odf())], mimetype=tipo)


def _scrivi_cartella(percorso: str, fogli: list[tuple[str, Any]], nome: str, larghezze: Any = None) -> str:
    nomi = _nomi_fogli([n for n, _ in fogli], nome)
    preparati = []
    for n, righe in zip(nomi, (r for _, r in fogli)):
        celle, intestazione = _prepara_foglio(righe, nome, larghezze)
        preparati.append((n, celle, intestazione))
    dati = _ods(preparati) if _estensione(percorso) == ".ods" else _xlsx(preparati)
    _scrivi_byte(percorso, dati)
    return percorso


# ---------------------------------------------------------------------------
# Il documento (titoli, paragrafi, elenchi, tabelle, immagini)
# ---------------------------------------------------------------------------

_ALLINEAMENTI = {"sinistra": "left", "centro": "center", "destra": "right", "giustificato": "both"}
_RE_GRASSETTO = re.compile(r"(?<![\w*])\*\*(?=[^\s*])(.+?)(?<=[^\s*])\*\*(?![\w*])", re.S)
_RE_CORSIVO = re.compile(r"(?<![\w*])\*(?=[^\s*])(.+?)(?<=[^\s*])\*(?![\w*])", re.S)
MASSIMI_ELEMENTI = 200_000


def _frammenti(testo: str) -> list[tuple[str, bool, bool]]:
    """``"Ciao **Ada**, *brava*"`` -> pezzi (testo, grassetto, corsivo)."""
    risultato: list[tuple[str, bool, bool]] = []

    def corsivi(pezzo: str, grassetto: bool) -> None:
        pos = 0
        for m in _RE_CORSIVO.finditer(pezzo):
            risultato.append((pezzo[pos:m.start()], grassetto, False))
            risultato.append((m.group(1), grassetto, True))
            pos = m.end()
        risultato.append((pezzo[pos:], grassetto, False))

    pos = 0
    for m in _RE_GRASSETTO.finditer(testo):
        corsivi(testo[pos:m.start()], False)
        corsivi(m.group(1), True)
        pos = m.end()
    corsivi(testo[pos:], False)
    return [f for f in risultato if f[0]]


def _senza_segni(testo: str) -> str:
    return "".join(t for t, _, _ in _frammenti(testo))


class Documento(OggettoLibreria):
    """Un documento da riempire e poi salvare in .docx, .odt, .pdf, .html, .md o .txt."""

    NOME_TIPO_DANTE = "documento"
    SUGGERIMENTO_MODIFICA = "Per aggiungere contenuto usa i metodi `aggiungi_titolo`, `aggiungi_paragrafo`..."

    def __init__(self, titolo: str = "") -> None:
        self.titolo = titolo
        self.elementi: list[tuple] = []
        if titolo:
            self.elementi.append(("titolo", titolo, 0))

    def aggiungi(self, elemento: tuple) -> "Documento":
        if len(self.elementi) >= MASSIMI_ELEMENTI:
            raise ErroreValore(f"Il documento è troppo lungo (più di {MASSIMI_ELEMENTI} parti).")
        self.elementi.append(elemento)
        return self

    def testo_dante(self) -> str:
        n = len(self.elementi)
        return f"<documento{' ' + mostra(self.titolo) if self.titolo else ''} con {n} {'parte' if n == 1 else 'parti'}>"

    def __repr__(self) -> str:
        return f"Documento({self.titolo!r}, {len(self.elementi)})"


_RE_TITOLO_MD = re.compile(r"^(#{1,3})\s+(.*?)\s*#*\s*$")
_RE_PUNTO = re.compile(r"^\s*[-*•]\s+(.*)$")
_RE_NUMERO = re.compile(r"^\s*\d{1,4}[.)]\s+(.*)$")
_RE_SEPARATORE_TABELLA = re.compile(r"^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$")
_RE_IMMAGINE_MD = re.compile(r"^\s*!\[([^\]]*)\]\(([^)]+)\)\s*$")


def _celle_riga_md(riga: str) -> list[str]:
    riga = riga.strip()
    if riga.startswith("|"):
        riga = riga[1:]
    if riga.endswith("|"):
        riga = riga[:-1]
    return [c.strip() for c in riga.split("|")]


def _documento_da_testo(testo: str, nome: str, titolo: str = "") -> Documento:
    """Il testo semplice di `scrivi_word`/`scrivi_pdf` diventa un documento.

    ``# titolo``, ``## titolo``, ``- punto``, ``1. punto``, righe ``| a | b |`` (tabella),
    ``![](foto.jpg)`` (immagine), ``---`` (nuova pagina); una riga vuota separa i paragrafi.
    """
    doc = Documento(titolo)
    paragrafo: list[str] = []
    elenco: list[str] = []
    numerato = False
    tabella: list[list[str]] = []

    def chiudi() -> None:
        nonlocal elenco, paragrafo, tabella
        if paragrafo:
            doc.aggiungi(("paragrafo", "\n".join(paragrafo), "sinistra"))
            paragrafo = []
        if elenco:
            doc.aggiungi(("elenco", elenco, numerato))
            elenco = []
        if tabella:
            larghezza = max(len(r) for r in tabella)
            doc.aggiungi(("tabella", [r + [""] * (larghezza - len(r)) for r in tabella], len(tabella) > 1))
            tabella = []

    for riga in testo.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        pulita = riga.strip()
        m_titolo = _RE_TITOLO_MD.match(pulita)
        m_punto = _RE_PUNTO.match(riga)
        m_numero = _RE_NUMERO.match(riga)
        m_immagine = _RE_IMMAGINE_MD.match(riga)
        if pulita.startswith("|"):
            if not tabella:
                chiudi()
            if not _RE_SEPARATORE_TABELLA.match(pulita):
                tabella.append(_celle_riga_md(pulita))
            continue
        if tabella:
            chiudi()
        if not pulita:
            chiudi()
        elif re.fullmatch(r"-{3,}|={3,}", pulita):
            chiudi()
            doc.aggiungi(("pagina",))
        elif m_titolo:
            chiudi()
            doc.aggiungi(("titolo", m_titolo.group(2), len(m_titolo.group(1))))
        elif m_immagine:
            chiudi()
            doc.aggiungi(("immagine", _leggi_immagine(m_immagine.group(2).strip(), nome), None))
        elif m_punto or m_numero:
            nuovo_numerato = m_punto is None
            if paragrafo or (elenco and nuovo_numerato != numerato):
                chiudi()
            numerato = nuovo_numerato
            elenco.append((m_punto or m_numero).group(1))
        elif elenco and riga[:1] in (" ", "\t"):
            elenco[-1] += " " + pulita
        else:
            if elenco:
                chiudi()
            paragrafo.append(riga.rstrip())
    chiudi()
    return doc


# -- Word (.docx) -----------------------------------------------------------

_NS_W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
_W = "{%s}" % _NS_W
_CM_TWIP = 566.93
_LARGHEZZA_TESTO_TWIP = 9638   # A4 con margini di 2 cm


def _run_docx(testo: str, grassetto: bool = False, corsivo: bool = False) -> str:
    proprieta_run = ""
    if grassetto or corsivo:
        proprieta_run = "<w:rPr>" + ("<w:b/>" if grassetto else "") + ("<w:i/>" if corsivo else "") + "</w:rPr>"
    pezzi = []
    for i, riga in enumerate(testo.split("\n")):
        if i:
            pezzi.append("<w:br/>")
        for j, parte in enumerate(riga.split("\t")):
            if j:
                pezzi.append("<w:tab/>")
            if parte:
                pezzi.append(f'<w:t xml:space="preserve">{_x(parte)}</w:t>')
    return f"<w:r>{proprieta_run}{''.join(pezzi)}</w:r>"


def _paragrafo_docx(testo: str, stile: str = "", allinea: str = "", numero: int = 0,
                    grassetto: bool = False) -> str:
    proprieta_par = ""
    if stile:
        proprieta_par += f'<w:pStyle w:val="{stile}"/>'
    if numero:
        proprieta_par += f'<w:numPr><w:ilvl w:val="0"/><w:numId w:val="{numero}"/></w:numPr>'
    if allinea and allinea != "left":
        proprieta_par += f'<w:jc w:val="{allinea}"/>'
    runs = "".join(_run_docx(t, g or grassetto, c) for t, g, c in _frammenti(testo))
    return f"<w:p>{'<w:pPr>' + proprieta_par + '</w:pPr>' if proprieta_par else ''}{runs}</w:p>"


def _larghezze_colonne(griglia: list[list[str]], totale: float) -> list[float]:
    colonne = max((len(r) for r in griglia), default=1) or 1
    misure = [3.0] * colonne
    for riga in griglia[:500]:
        for i, cella in enumerate(riga):
            lunghezza = max((len(p) for p in _senza_segni(cella).split("\n")), default=0)
            misure[i] = max(misure[i], min(float(lunghezza), 40.0))
    somma = sum(misure)
    return [totale * m / somma for m in misure]


def _tabella_docx(griglia: list[list[str]], intestazione: bool) -> str:
    larghezze = [int(w) for w in _larghezze_colonne(griglia, _LARGHEZZA_TESTO_TWIP)]
    pezzi = ['<w:tbl><w:tblPr><w:tblStyle w:val="Tabella"/><w:tblW w:w="5000" w:type="pct"/>'
             '<w:tblLook w:val="04A0" w:firstRow="1" w:lastRow="0" w:firstColumn="0" w:lastColumn="0" '
             'w:noHBand="0" w:noVBand="1"/></w:tblPr><w:tblGrid>']
    pezzi += [f'<w:gridCol w:w="{w}"/>' for w in larghezze]
    pezzi.append("</w:tblGrid>")
    for r, riga in enumerate(griglia):
        testa = intestazione and r == 0
        pezzi.append("<w:tr>" + ("<w:trPr><w:tblHeader/></w:trPr>" if testa else ""))
        for i, w in enumerate(larghezze):
            cella = riga[i] if i < len(riga) else ""
            sfondo = '<w:shd w:val="clear" w:color="auto" w:fill="DDEBF7"/>' if testa else ""
            pezzi.append(f'<w:tc><w:tcPr><w:tcW w:w="{w}" w:type="dxa"/>{sfondo}</w:tcPr>'
                         f'{_paragrafo_docx(cella, "Cella", grassetto=testa)}</w:tc>')
        pezzi.append("</w:tr>")
    pezzi.append("</w:tbl>")
    return "".join(pezzi)


def _misura_immagine_cm(immagine: _Immagine, larghezza_cm: float | None, massima_cm: float,
                        massima_altezza_cm: float, vista: bool = False) -> tuple[float, float]:
    larghezza_px = immagine.larghezza_vista if vista else immagine.larghezza
    altezza_px = immagine.altezza_vista if vista else immagine.altezza
    larghezza = larghezza_cm if larghezza_cm else min(larghezza_px / 96 * 2.54, massima_cm)
    larghezza = min(larghezza, massima_cm)
    altezza = larghezza * altezza_px / larghezza_px
    if altezza > massima_altezza_cm:
        larghezza, altezza = larghezza * massima_altezza_cm / altezza, massima_altezza_cm
    return larghezza, altezza


def _immagine_docx(numero: int, rid: str, larghezza_cm: float, altezza_cm: float) -> str:
    cx, cy = int(larghezza_cm * 360000), int(altezza_cm * 360000)
    return ('<w:p><w:pPr><w:jc w:val="center"/></w:pPr><w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" '
            f'distR="0"><wp:extent cx="{cx}" cy="{cy}"/><wp:docPr id="{numero}" name="Immagine {numero}"/>'
            '<wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/></wp:cNvGraphicFramePr>'
            '<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic>'
            f'<pic:nvPicPr><pic:cNvPr id="{numero}" name="immagine{numero}"/><pic:cNvPicPr/></pic:nvPicPr>'
            f'<pic:blipFill><a:blip r:embed="{rid}"/><a:stretch><a:fillRect/></a:stretch></pic:blipFill>'
            f'<pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm>'
            '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic>'
            "</wp:inline></w:drawing></w:r></w:p>")


_STILI_DOCX = (
    _XML_TESTA + f'<w:styles xmlns:w="{_NS_W}"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" '
    'w:hAnsi="Calibri" w:eastAsia="Calibri" w:cs="Calibri"/><w:sz w:val="22"/><w:szCs w:val="22"/><w:lang w:val="it-IT"/>'
    '</w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="276" w:lineRule="auto"/></w:pPr>'
    '</w:pPrDefault></w:docDefaults>'
    '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style>'
    '<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/>'
    '<w:next w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:after="240"/></w:pPr><w:rPr><w:b/>'
    '<w:color w:val="1F3864"/><w:sz w:val="48"/><w:szCs w:val="48"/></w:rPr></w:style>'
    + "".join(f'<w:style w:type="paragraph" w:styleId="Heading{n}"><w:name w:val="heading {n}"/>'
              '<w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:qFormat/><w:pPr><w:keepNext/>'
              f'<w:spacing w:before="{360 - 60 * n}" w:after="120"/><w:outlineLvl w:val="{n - 1}"/></w:pPr>'
              f'<w:rPr><w:b/><w:color w:val="2F5496"/><w:sz w:val="{s}"/><w:szCs w:val="{s}"/></w:rPr></w:style>'
              for n, s in ((1, 32), (2, 28), (3, 24)))
    + '<w:style w:type="paragraph" w:styleId="ListParagraph"><w:name w:val="List Paragraph"/>'
    '<w:basedOn w:val="Normal"/><w:qFormat/><w:pPr><w:spacing w:after="60"/><w:ind w:left="720"/></w:pPr></w:style>'
    '<w:style w:type="paragraph" w:styleId="Cella"><w:name w:val="Cella"/><w:basedOn w:val="Normal"/>'
    '<w:pPr><w:spacing w:after="0" w:line="240" w:lineRule="auto"/></w:pPr></w:style>'
    '<w:style w:type="table" w:default="1" w:styleId="TableNormal"><w:name w:val="Normal Table"/><w:tblPr>'
    '<w:tblInd w:w="0" w:type="dxa"/><w:tblCellMar><w:top w:w="0" w:type="dxa"/><w:left w:w="108" w:type="dxa"/>'
    '<w:bottom w:w="0" w:type="dxa"/><w:right w:w="108" w:type="dxa"/></w:tblCellMar></w:tblPr></w:style>'
    '<w:style w:type="table" w:styleId="Tabella"><w:name w:val="Tabella"/><w:basedOn w:val="TableNormal"/>'
    '<w:tblPr><w:tblBorders>'
    + "".join(f'<w:{b} w:val="single" w:sz="4" w:space="0" w:color="808080"/>'
              for b in ("top", "left", "bottom", "right", "insideH", "insideV"))
    + '</w:tblBorders><w:tblCellMar><w:top w:w="40" w:type="dxa"/><w:bottom w:w="40" w:type="dxa"/></w:tblCellMar>'
    "</w:tblPr></w:style></w:styles>"
)


def _numerazione_docx(elenchi: list[bool]) -> str:
    astratti = (
        '<w:abstractNum w:abstractNumId="0"><w:multiLevelType w:val="singleLevel"/><w:lvl w:ilvl="0">'
        '<w:start w:val="1"/><w:numFmt w:val="bullet"/><w:lvlText w:val="\u2022"/><w:lvlJc w:val="left"/>'
        '<w:pPr><w:ind w:left="720" w:hanging="360"/></w:pPr></w:lvl></w:abstractNum>'
        '<w:abstractNum w:abstractNumId="1"><w:multiLevelType w:val="singleLevel"/><w:lvl w:ilvl="0">'
        '<w:start w:val="1"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%1."/><w:lvlJc w:val="left"/>'
        '<w:pPr><w:ind w:left="720" w:hanging="360"/></w:pPr></w:lvl></w:abstractNum>'
    )
    numeri = "".join(f'<w:num w:numId="{i}"><w:abstractNumId w:val="{int(numerato)}"/>'
                     + ('<w:lvlOverride w:ilvl="0"><w:startOverride w:val="1"/></w:lvlOverride>' if numerato else "")
                     + "</w:num>" for i, numerato in enumerate(elenchi, 1))
    return _XML_TESTA + f'<w:numbering xmlns:w="{_NS_W}">{astratti}{numeri}</w:numbering>'


def _docx(doc: Documento) -> bytes:
    corpo: list[str] = []
    elenchi: list[bool] = []
    immagini: list[tuple[str, _Immagine]] = []
    for elemento in doc.elementi:
        tipo = elemento[0]
        if tipo == "titolo":
            corpo.append(_paragrafo_docx(elemento[1], "Title" if elemento[2] == 0 else f"Heading{elemento[2]}"))
        elif tipo == "paragrafo":
            corpo.append(_paragrafo_docx(elemento[1], allinea=_ALLINEAMENTI.get(elemento[2], "left")))
        elif tipo == "elenco":
            elenchi.append(elemento[2])
            corpo.extend(_paragrafo_docx(v, "ListParagraph", numero=len(elenchi)) for v in elemento[1])
        elif tipo == "tabella":
            corpo.append(_tabella_docx(elemento[1], elemento[2]))
            corpo.append('<w:p><w:pPr><w:spacing w:after="0"/></w:pPr></w:p>')
        elif tipo == "immagine":
            immagine = elemento[1]
            immagini.append((f"rIdImg{len(immagini) + 1}", immagine))
            larghezza, altezza = _misura_immagine_cm(immagine, elemento[2], 17.0, 24.0)
            corpo.append(_immagine_docx(len(immagini), immagini[-1][0], larghezza, altezza))
        elif tipo == "pagina":
            corpo.append('<w:p><w:r><w:br w:type="page"/></w:r></w:p>')
    documento = (_XML_TESTA + f'<w:document xmlns:w="{_NS_W}" xmlns:r="{_NS_REL}" '
                 'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
                 'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
                 'xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"><w:body>'
                 + "".join(corpo)
                 + '<w:sectPr><w:pgSz w:w="11906" w:h="16838"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" '
                 'w:left="1134" w:header="709" w:footer="709" w:gutter="0"/></w:sectPr></w:body></w:document>')
    rel_doc = (_XML_TESTA + f'<Relationships xmlns="{_NS_PKG_REL}">'
               f'<Relationship Id="rIdStili" Type="{_TIPO_REL}styles" Target="styles.xml"/>'
               f'<Relationship Id="rIdNumeri" Type="{_TIPO_REL}numbering" Target="numbering.xml"/>'
               + "".join(f'<Relationship Id="{rid}" Type="{_TIPO_REL}image" Target="media/immagine{i}.{im.estensione}"/>'
                         for i, (rid, im) in enumerate(immagini, 1))
               + "</Relationships>")
    tipi = (_XML_TESTA + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/><Default Extension="jpg" ContentType="image/jpeg"/>'
            '<Default Extension="png" ContentType="image/png"/><Default Extension="gif" ContentType="image/gif"/>'
            '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.'
            'wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/'
            'vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/numbering.xml" '
            'ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/>'
            '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.'
            'core-properties+xml"/></Types>')
    rel = (_XML_TESTA + f'<Relationships xmlns="{_NS_PKG_REL}"><Relationship Id="rId1" Type="{_TIPO_REL}'
           'officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/'
           'package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>')
    parti: list[tuple[str, bytes | str]] = [
        ("[Content_Types].xml", tipi), ("_rels/.rels", rel), ("docProps/core.xml", _core_xml(doc.titolo)),
        ("word/document.xml", documento), ("word/_rels/document.xml.rels", rel_doc),
        ("word/styles.xml", _STILI_DOCX), ("word/numbering.xml", _numerazione_docx(elenchi))]
    parti += [(f"word/media/immagine{i}.{im.estensione}", im.dati) for i, (_, im) in enumerate(immagini, 1)]
    return _zip(parti)


# -- OpenDocument (.odt) ------------------------------------------------------

def _span_odt(testo: str) -> str:
    pezzi = []
    for t, g, c in _frammenti(testo):
        contenuto = _testo_in_odf(t)
        stile = "T_gc" if g and c else "T_g" if g else "T_c" if c else ""
        pezzi.append(f'<text:span text:style-name="{stile}">{contenuto}</text:span>' if stile else contenuto)
    return "".join(pezzi)


def _odt(doc: Documento) -> bytes:
    corpo: list[str] = []
    immagini: list[tuple[str, _Immagine]] = []
    stili_tabelle: list[str] = []
    nuova_pagina = False

    def stile_par(base: str) -> str:
        nonlocal nuova_pagina
        if nuova_pagina:
            nuova_pagina = False
            return base + "_pag"
        return base

    for elemento in doc.elementi:
        tipo = elemento[0]
        if tipo == "titolo":
            livello = elemento[2]
            if livello == 0:
                corpo.append(f'<text:p text:style-name="{stile_par("P_titolo")}">{_span_odt(elemento[1])}</text:p>')
            else:
                corpo.append(f'<text:h text:style-name="{stile_par(f"H{livello}")}" text:outline-level="{livello}">'
                             f"{_span_odt(elemento[1])}</text:h>")
        elif tipo == "paragrafo":
            base = {"centro": "P_centro", "destra": "P_destra", "giustificato": "P_giust"}.get(elemento[2], "P")
            corpo.append(f'<text:p text:style-name="{stile_par(base)}">{_span_odt(elemento[1])}</text:p>')
        elif tipo == "elenco":
            stile = "L_numeri" if elemento[2] else "L_punti"
            voci = "".join(f'<text:list-item><text:p text:style-name="{stile_par("P_voce")}">{_span_odt(v)}</text:p>'
                           "</text:list-item>" for v in elemento[1])
            corpo.append(f'<text:list text:style-name="{stile}">{voci}</text:list>')
        elif tipo == "tabella":
            griglia, intestazione = elemento[1], elemento[2]
            nome = f"Tab{len(stili_tabelle) + 1}"
            larghezze = _larghezze_colonne(griglia, 17.0)
            stili_tabelle.append(f'<style:style style:name="{nome}" style:family="table"><style:table-properties '
                                 f'style:width="17cm" table:align="margins"{" fo:break-before=" + chr(34) + "page" + chr(34) if nuova_pagina else ""}/>'
                                 "</style:style>"
                                 + "".join(f'<style:style style:name="{nome}.C{i}" style:family="table-column">'
                                           f'<style:table-column-properties style:column-width="{w:.2f}cm"/></style:style>'
                                           for i, w in enumerate(larghezze, 1)))
            nuova_pagina = False
            righe = []
            for r, riga in enumerate(griglia):
                testa = intestazione and r == 0
                celle = "".join(f'<table:table-cell table:style-name="{"C_testa" if testa else "C"}" '
                                f'office:value-type="string"><text:p text:style-name="{"P_cella_g" if testa else "P_cella"}">'
                                f'{_span_odt(riga[i] if i < len(riga) else "")}</text:p></table:table-cell>'
                                for i in range(len(larghezze)))
                riga_xml = f"<table:table-row>{celle}</table:table-row>"
                righe.append(f"<table:table-header-rows>{riga_xml}</table:table-header-rows>" if testa else riga_xml)
            colonne = "".join(f'<table:table-column table:style-name="{nome}.C{i}"/>'
                              for i in range(1, len(larghezze) + 1))
            corpo.append(f'<table:table table:name="{nome}" table:style-name="{nome}">{colonne}{"".join(righe)}'
                         "</table:table>")
        elif tipo == "immagine":
            immagine = elemento[1]
            immagini.append((f"Pictures/immagine{len(immagini) + 1}.{immagine.estensione}", immagine))
            larghezza, altezza = _misura_immagine_cm(immagine, elemento[2], 17.0, 24.0)
            corpo.append(f'<text:p text:style-name="{stile_par("P_centro")}"><draw:frame draw:name="Immagine'
                         f'{len(immagini)}" text:anchor-type="as-char" svg:width="{larghezza:.3f}cm" '
                         f'svg:height="{altezza:.3f}cm" draw:z-index="0"><draw:image xlink:href="{immagini[-1][0]}" '
                         'xlink:type="simple" xlink:show="embed" xlink:actuate="onLoad"/></draw:frame></text:p>')
        elif tipo == "pagina":
            nuova_pagina = True
    if nuova_pagina:
        corpo.append('<text:p text:style-name="P_pag"/>')

    def par(nome: str, proprieta_par: str = "", proprieta_testo: str = "", classe: str = "") -> str:
        testo = f"<style:text-properties {proprieta_testo}/>" if proprieta_testo else ""
        risultato = ""
        for suffisso, extra in (("", ""), ("_pag", ' fo:break-before="page"')):
            risultato += (f'<style:style style:name="{nome}{suffisso}" style:family="paragraph"'
                          f'{" style:class=" + chr(34) + classe + chr(34) if classe else ""}>'
                          f'<style:paragraph-properties {proprieta_par}{extra}/>{testo}</style:style>')
        return risultato

    grassetto = 'fo:font-weight="bold" style:font-weight-asian="bold" style:font-weight-complex="bold"'
    automatici = (
        par("P", 'fo:margin-bottom="0.21cm"')
        + par("P_centro", 'fo:margin-bottom="0.21cm" fo:text-align="center"')
        + par("P_destra", 'fo:margin-bottom="0.21cm" fo:text-align="end"')
        + par("P_giust", 'fo:margin-bottom="0.21cm" fo:text-align="justify"')
        + par("P_voce", 'fo:margin-bottom="0.1cm"')
        + par("P_titolo", 'fo:margin-bottom="0.42cm"', f'fo:font-size="24pt" fo:color="#1f3864" {grassetto}', "chapter")
        + par("H1", 'fo:margin-top="0.5cm" fo:margin-bottom="0.21cm" fo:keep-with-next="always"',
              f'fo:font-size="16pt" fo:color="#2f5496" {grassetto}')
        + par("H2", 'fo:margin-top="0.4cm" fo:margin-bottom="0.21cm" fo:keep-with-next="always"',
              f'fo:font-size="14pt" fo:color="#2f5496" {grassetto}')
        + par("H3", 'fo:margin-top="0.3cm" fo:margin-bottom="0.21cm" fo:keep-with-next="always"',
              f'fo:font-size="12pt" fo:color="#2f5496" {grassetto}')
        + par("P_cella", 'fo:margin-bottom="0cm"') + par("P_cella_g", 'fo:margin-bottom="0cm"', grassetto)
        + f'<style:style style:name="T_g" style:family="text"><style:text-properties {grassetto}/></style:style>'
        '<style:style style:name="T_c" style:family="text"><style:text-properties fo:font-style="italic"/></style:style>'
        f'<style:style style:name="T_gc" style:family="text"><style:text-properties {grassetto} '
        'fo:font-style="italic"/></style:style>'
        '<style:style style:name="C" style:family="table-cell"><style:table-cell-properties fo:padding="0.1cm" '
        'fo:border="0.5pt solid #808080"/></style:style>'
        '<style:style style:name="C_testa" style:family="table-cell"><style:table-cell-properties fo:padding="0.1cm" '
        'fo:border="0.5pt solid #808080" fo:background-color="#ddebf7"/></style:style>'
        + "".join(stili_tabelle)
        + '<text:list-style style:name="L_punti"><text:list-level-style-bullet text:level="1" text:bullet-char="\u2022">'
        '<style:list-level-properties text:list-level-position-and-space-mode="label-alignment">'
        '<style:list-level-label-alignment text:label-followed-by="listtab" text:list-tab-stop-position="1.27cm" '
        'fo:text-indent="-0.635cm" fo:margin-left="1.27cm"/></style:list-level-properties>'
        '</text:list-level-style-bullet></text:list-style>'
        '<text:list-style style:name="L_numeri"><text:list-level-style-number text:level="1" style:num-suffix="." '
        'style:num-format="1"><style:list-level-properties text:list-level-position-and-space-mode="label-alignment">'
        '<style:list-level-label-alignment text:label-followed-by="listtab" text:list-tab-stop-position="1.27cm" '
        'fo:text-indent="-0.635cm" fo:margin-left="1.27cm"/></style:list-level-properties>'
        '</text:list-level-style-number></text:list-style>'
    )
    intestazione_xml = _XML_TESTA.replace(' standalone="yes"', "")
    contenuto = (intestazione_xml + f"<office:document-content {_NS_ODF_TUTTI}><office:automatic-styles>{automatici}"
                 "</office:automatic-styles><office:body><office:text>" + "".join(corpo)
                 + "</office:text></office:body></office:document-content>")
    stili = (intestazione_xml + f"<office:document-styles {_NS_ODF_TUTTI}><office:styles>"
             '<style:default-style style:family="paragraph"><style:text-properties style:font-name="Liberation Sans" '
             'fo:font-family="Liberation Sans, Arial, Helvetica" fo:font-size="11pt" fo:language="it" '
             'fo:country="IT"/></style:default-style></office:styles><office:automatic-styles>'
             '<style:page-layout style:name="pm1"><style:page-layout-properties fo:page-width="21cm" '
             'fo:page-height="29.7cm" fo:margin-top="2cm" fo:margin-bottom="2cm" fo:margin-left="2cm" '
             'fo:margin-right="2cm"/></style:page-layout></office:automatic-styles><office:master-styles>'
             '<style:master-page style:name="Standard" style:page-layout-name="pm1"/></office:master-styles>'
             "</office:document-styles>")
    tipo = "application/vnd.oasis.opendocument.text"
    altri = [(p, "image/" + im.formato) for p, im in immagini]
    return _zip([("META-INF/manifest.xml", _manifest(tipo, altri)), ("content.xml", contenuto), ("styles.xml", stili),
                 ("meta.xml", _meta_odf(doc.titolo))] + [(p, im.dati) for p, im in immagini], mimetype=tipo)


# -- HTML, Markdown e testo semplice -------------------------------------------

def _html_in_linea(testo: str) -> str:
    pezzi = []
    for t, g, c in _frammenti(testo):
        t = _x(t).replace("\n", "<br>")
        if c:
            t = f"<em>{t}</em>"
        if g:
            t = f"<strong>{t}</strong>"
        pezzi.append(t)
    return "".join(pezzi)


def _html(doc: Documento) -> str:
    corpo = []
    for elemento in doc.elementi:
        tipo = elemento[0]
        if tipo == "titolo":
            livello = elemento[2] + 1
            corpo.append(f"<h{livello}>{_html_in_linea(elemento[1])}</h{livello}>")
        elif tipo == "paragrafo":
            allinea = {"centro": "center", "destra": "right", "giustificato": "justify"}.get(elemento[2])
            stile = f' style="text-align:{allinea}"' if allinea else ""
            corpo.append(f"<p{stile}>{_html_in_linea(elemento[1])}</p>")
        elif tipo == "elenco":
            etichetta = "ol" if elemento[2] else "ul"
            corpo.append(f"<{etichetta}>" + "".join(f"<li>{_html_in_linea(v)}</li>" for v in elemento[1])
                         + f"</{etichetta}>")
        elif tipo == "tabella":
            righe = []
            for r, riga in enumerate(elemento[1]):
                cella = "th" if elemento[2] and r == 0 else "td"
                righe.append("<tr>" + "".join(f"<{cella}>{_html_in_linea(v)}</{cella}>" for v in riga) + "</tr>")
            corpo.append("<table>" + "".join(righe) + "</table>")
        elif tipo == "immagine":
            immagine = elemento[1]
            larghezza, _ = _misura_immagine_cm(immagine, elemento[2], 17.0, 1e9, vista=True)
            dati = base64.b64encode(immagine.dati).decode("ascii")
            corpo.append(f'<p class="immagine"><img src="data:image/{immagine.formato};base64,{dati}" '
                         f'style="width:{larghezza:.2f}cm;max-width:100%" alt=""></p>')
        elif tipo == "pagina":
            corpo.append('<div style="page-break-after:always"></div>')
    titolo = _x(doc.titolo or "Documento")
    return ('<!DOCTYPE html>\n<html lang="it">\n<head>\n<meta charset="utf-8">\n'
            '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
            f"<title>{titolo}</title>\n<style>\n"
            "body{font-family:Calibri,Arial,Helvetica,sans-serif;max-width:48em;margin:2em auto;padding:0 1em;"
            "line-height:1.45;color:#222}\nh1{color:#1f3864}h2,h3,h4{color:#2f5496}\n"
            "table{border-collapse:collapse;margin:1em 0}th,td{border:1px solid #808080;padding:.3em .6em;"
            "vertical-align:top;text-align:left}th{background:#ddebf7}\n.immagine{text-align:center}\n"
            "</style>\n</head>\n<body>\n" + "\n".join(corpo) + "\n</body>\n</html>\n")


def _markdown(doc: Documento) -> str:
    blocchi = []
    for elemento in doc.elementi:
        tipo = elemento[0]
        if tipo == "titolo":
            blocchi.append("#" * max(1, elemento[2]) + " " + elemento[1].replace("\n", " "))
        elif tipo == "paragrafo":
            blocchi.append(elemento[1].replace("\n", "  \n"))
        elif tipo == "elenco":
            blocchi.append("\n".join((f"{i}. " if elemento[2] else "- ") + v for i, v in enumerate(elemento[1], 1)))
        elif tipo == "tabella":
            griglia = [[v.replace("|", "\\|").replace("\n", " ") for v in r] for r in elemento[1]]
            if not griglia:
                continue
            if not elemento[2]:
                griglia = [[""] * len(griglia[0])] + griglia
            righe = ["| " + " | ".join(griglia[0]) + " |", "|" + "|".join("---" for _ in griglia[0]) + "|"]
            righe += ["| " + " | ".join(r) + " |" for r in griglia[1:]]
            blocchi.append("\n".join(righe))
        elif tipo == "immagine":
            blocchi.append(f"![]({elemento[1].percorso})")
        elif tipo == "pagina":
            blocchi.append("---")
    return "\n\n".join(blocchi) + "\n"


def _testo_semplice(doc: Documento) -> str:
    blocchi = []
    for elemento in doc.elementi:
        tipo = elemento[0]
        if tipo == "titolo":
            testo = _senza_segni(elemento[1])
            blocchi.append(testo + ("\n" + ("=" if elemento[2] <= 1 else "-") * len(testo) if elemento[2] <= 2 else ""))
        elif tipo == "paragrafo":
            blocchi.append(_senza_segni(elemento[1]))
        elif tipo == "elenco":
            blocchi.append("\n".join((f"{i}. " if elemento[2] else "- ") + _senza_segni(v)
                                     for i, v in enumerate(elemento[1], 1)))
        elif tipo == "tabella":
            griglia = [[_senza_segni(v).replace("\n", " ") for v in r] for r in elemento[1]]
            larghezze = [max(len(r[i]) for r in griglia if i < len(r)) for i in range(max(len(r) for r in griglia))] \
                if griglia else []
            blocchi.append("\n".join("  ".join(v.ljust(larghezze[i]) for i, v in enumerate(r)).rstrip()
                                     for r in griglia))
        elif tipo == "immagine":
            blocchi.append(f"[immagine: {os.path.basename(elemento[1].percorso)}]")
        elif tipo == "pagina":
            blocchi.append("\f")
    return "\n\n".join(blocchi).replace("\n\n\f\n\n", "\n\f\n") + "\n"


_ESTENSIONI_DOCUMENTO = (".docx", ".odt", ".pdf", ".html", ".htm", ".md", ".txt")


def _salva_documento(doc: Documento, percorso: str) -> str:
    estensione = _estensione(percorso)
    if estensione == ".docx":
        dati = _docx(doc)
    elif estensione == ".odt":
        dati = _odt(doc)
    elif estensione == ".pdf":
        dati = _pdf_documento(doc)
    elif estensione in (".html", ".htm"):
        dati = _html(doc).encode("utf-8")
    elif estensione == ".md":
        dati = _markdown(doc).encode("utf-8")
    else:
        dati = _testo_semplice(doc).encode("utf-8")
    _scrivi_byte(percorso, dati)
    return percorso


# ---------------------------------------------------------------------------
# Word: lettura (.docx e .odt)
# ---------------------------------------------------------------------------

_ESTENSIONI_WORD = (".docx", ".docm", ".dotx", ".odt")


def _testo_w(elemento: ET.Element) -> str:
    """Il testo di un paragrafo di Word (o di un pezzo): run, tabulazioni, a capo; niente testo cancellato."""
    pezzi: list[str] = []

    def visita(e: ET.Element) -> None:
        for figlio in e:
            n = _nome_xml(figlio.tag)
            if n == "t":
                pezzi.append(figlio.text or "")
            elif n == "tab" and e.tag == _W + "r":
                pezzi.append("\t")
            elif n in ("br", "cr"):
                if figlio.get(_W + "type") != "page":
                    pezzi.append("\n")
            elif n == "noBreakHyphen":
                pezzi.append("-")
            elif n in ("Fallback", "del", "instrText", "delText", "rPr", "pPr", "footnoteReference"):
                continue
            elif n == "p":
                if pezzi and not pezzi[-1].endswith("\n"):
                    pezzi.append("\n")
                visita(figlio)
            else:
                visita(figlio)

    visita(elemento)
    return "".join(pezzi)


def _blocchi_docx(corpo: ET.Element) -> list[tuple]:
    """I blocchi del corpo: ("p", testo, stile) e ("t", righe)."""
    blocchi: list[tuple] = []
    for e in corpo:
        n = _nome_xml(e.tag)
        if n == "p":
            stile = ""
            ppr = e.find(_W + "pPr")
            if ppr is not None:
                s = ppr.find(_W + "pStyle")
                if s is not None:
                    stile = s.get(_W + "val", "")
                if ppr.find(_W + "numPr") is not None and not stile:
                    stile = "ListParagraph"
            testo = _testo_w(e)
            salto = (ppr is not None and ppr.find(_W + "pageBreakBefore") is not None) or any(
                b.get(_W + "type") == "page" for b in e.iter(_W + "br"))
            if salto and blocchi:
                blocchi.append(("pagina",))
            if testo or not salto:
                blocchi.append(("p", testo, stile))
        elif n == "tbl":
            righe = []
            for tr in e:
                if _nome_xml(tr.tag) != "tr":
                    continue
                celle = []
                for tc in tr:
                    if _nome_xml(tc.tag) == "tc":
                        celle.append("\n".join(_testo_w(p) for p in tc if _nome_xml(p.tag) in ("p", "tbl", "sdt")))
                    elif _nome_xml(tc.tag) == "sdt":
                        celle.append(_testo_w(tc))
                righe.append(celle)
            blocchi.append(("t", righe))
        elif n in ("sdt", "customXml", "ins", "smartTag"):
            contenuto = e.find(_W + "sdtContent") if n == "sdt" else e
            if contenuto is not None:
                blocchi.extend(_blocchi_docx(contenuto))
    return blocchi


def _blocchi_odt(elemento: ET.Element) -> list[tuple]:
    blocchi: list[tuple] = []
    for e in elemento:
        n = _nome_xml(e.tag)
        if n == "h":
            blocchi.append(("p", _testo_odf(e), f"Heading{e.get(_TX + 'outline-level', '1')}"))
        elif n == "p":
            blocchi.append(("p", _testo_odf(e), ""))
        elif n in ("list", "list-item", "list-header"):
            for b in _blocchi_odt(e):
                blocchi.append(b if b[0] != "p" or b[2] else ("p", b[1], "ListParagraph"))
        elif n in ("section", "text", "body", "index-body", "table-of-content"):
            blocchi.extend(_blocchi_odt(e))
        elif n == "table":
            righe = []
            for riga in e.iter(_T + "table-row"):
                righe.append(["\n".join(b[1] for b in _blocchi_odt(c) if b[0] == "p")
                              for c in riga if _nome_xml(c.tag) in ("table-cell", "covered-table-cell")])
            blocchi.append(("t", righe))
    return blocchi


def _leggi_blocchi_word(percorso: Any, nome: str) -> list[tuple]:
    percorso = _percorso_da_leggere(percorso, nome, _ESTENSIONI_WORD)
    if _estensione(percorso) in (".odt", ".ott"):
        p = _Pacchetto(percorso, nome, "file .odt")
        radice = p.xml("content.xml")
        testo = radice.find(f"{_O}body/{_O}text")
        return _blocchi_odt(testo) if testo is not None else []
    p = _Pacchetto(percorso, nome, "file Word .docx")
    radice = p.xml(p.parte_principale("word/document.xml"))
    corpo = radice.find(_W + "body")
    return _blocchi_docx(corpo) if corpo is not None else []


def _documento_da_blocchi(blocchi: list[tuple], titolo: str = "") -> Documento:
    doc = Documento(titolo)
    elenco: list[str] = []
    for b in blocchi:
        if b[0] == "p" and b[2] in ("ListParagraph", "Elencoparagrafo", "Paragrafoelenco"):
            elenco.append(b[1])
            continue
        if elenco:
            doc.aggiungi(("elenco", elenco, False))
            elenco = []
        if b[0] == "pagina":
            doc.aggiungi(("pagina",))
            continue
        if b[0] == "t":
            if b[1]:
                larghezza = max(len(r) for r in b[1])
                doc.aggiungi(("tabella", [r + [""] * (larghezza - len(r)) for r in b[1]], True))
            continue
        stile = b[2].lower()
        m = re.match(r"(?:heading|titolo)\s*(\d)", stile)
        if stile in ("title", "titolo"):
            doc.aggiungi(("titolo", b[1], 0))
        elif m:
            doc.aggiungi(("titolo", b[1], min(3, max(1, int(m.group(1))))))
        else:
            doc.aggiungi(("paragrafo", b[1], "sinistra"))
    if elenco:
        doc.aggiungi(("elenco", elenco, False))
    return doc


# ---------------------------------------------------------------------------
# Word: sostituire testi dentro un .docx (anche spezzati tra più "run")
# ---------------------------------------------------------------------------

_RE_DICHIARAZIONI = re.compile(rb'xmlns:([A-Za-z_][\w.-]*)="([^"]*)"')


def _registra_prefissi(dati: bytes) -> list[tuple[str, str]]:
    inizio = dati[:4096]
    prefissi = []
    for prefisso, uri in _RE_DICHIARAZIONI.findall(inizio):
        p, u = prefisso.decode("ascii", "replace"), uri.decode("utf-8", "replace")
        prefissi.append((p, u))
        if not re.fullmatch(r"ns\d+", p):
            try:
                ET.register_namespace(p, u)
            except ValueError:
                pass
    return prefissi


def _serializza_word(radice: ET.Element, prefissi: list[tuple[str, str]]) -> bytes:
    testo = ET.tostring(radice, encoding="unicode")
    # ElementTree toglie le dichiarazioni dei prefissi che non usa: Word le vuole (mc:Ignorable)
    fine = testo.find(">")
    apertura = testo[:fine]
    aggiunte = "".join(f' xmlns:{p}="{_x(u)}"' for p, u in prefissi if f"xmlns:{p}=" not in apertura)
    if apertura.endswith("/"):
        apertura, chiusura = apertura[:-1], "/>"
    else:
        chiusura = ">"
    return (_XML_TESTA + apertura + aggiunte + chiusura + testo[fine + 1:]).encode("utf-8")


def _pezzi_di_testo(p: ET.Element) -> list[ET.Element]:
    """Gli elementi <w:t> di un paragrafo (non quelli dei paragrafi annidati)."""
    risultato: list[ET.Element] = []

    def visita(e: ET.Element) -> None:
        for figlio in e:
            n = _nome_xml(figlio.tag)
            if n == "t":
                risultato.append(figlio)
            elif n not in ("p", "Fallback", "del", "delText", "instrText"):
                visita(figlio)

    visita(p)
    return risultato


def _sostituisci_in_paragrafi(radice: ET.Element, regola: re.Pattern, sostituto) -> int:
    conta = 0
    for p in radice.iter(_W + "p"):
        pezzi = _pezzi_di_testo(p)
        if not pezzi:
            continue
        testi = [t.text or "" for t in pezzi]
        tutto = "".join(testi)
        trovati = list(regola.finditer(tutto))
        if not trovati:
            continue
        inizi, lunghezze = [], [len(t) for t in testi]
        pos = 0
        for t in testi:
            inizi.append(pos)
            pos += len(t)
        for m in reversed(trovati):
            a, b = m.start(), m.end()
            if a == b:
                continue
            nuovo = sostituto(m)
            primo = next(i for i in range(len(testi)) if inizi[i] <= a < inizi[i] + lunghezze[i])
            ultimo = next(i for i in range(len(testi)) if inizi[i] < b <= inizi[i] + lunghezze[i])
            if primo == ultimo:
                t = testi[primo]
                testi[primo] = t[:a - inizi[primo]] + nuovo + t[b - inizi[primo]:]
            else:
                testi[primo] = testi[primo][:a - inizi[primo]] + nuovo
                for k in range(primo + 1, ultimo):
                    testi[k] = ""
                testi[ultimo] = testi[ultimo][b - inizi[ultimo]:]
            conta += 1
        for t, testo in zip(pezzi, testi):
            if t.text != testo:
                t.text = testo
                t.set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
    return conta


_RE_PARTI_TESTO_WORD = re.compile(r"^word/(document|header\d*|footer\d*|footnotes|endnotes)\.xml$")


def _sostituisci_docx(p: _Pacchetto, regola: re.Pattern, sostituto) -> tuple[bytes, int]:
    """Il .docx con le sostituzioni fatte in documento, intestazioni, piè di pagina e note."""
    uscita = io.BytesIO()
    totale = 0
    with zipfile.ZipFile(uscita, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for info in p.zip.infolist():
            dati = p.leggi(info.filename)
            if _RE_PARTI_TESTO_WORD.match(info.filename):
                prefissi = _registra_prefissi(dati)
                radice = p.analizza(dati)
                conta = _sostituisci_in_paragrafi(radice, regola, sostituto)
                if conta:
                    dati = _serializza_word(radice, prefissi)
                    totale += conta
            z.writestr(_nuova_voce(info), dati)
    return uscita.getvalue(), totale


# ---------------------------------------------------------------------------
# PDF: scrittura (caratteri standard Helvetica, codifica WinAnsi)
# ---------------------------------------------------------------------------

# larghezze dei caratteri (millesimi del corpo) per i codici da 32 a 255 della codifica WinAnsi (cp1252)
_LARGHEZZE_NORMALE = tuple(int(x) for x in """
278 278 355 556 556 889 667 191 333 333 389 584 278 333 278 278 556 556 556 556 556 556 556 556 556
556 278 278 584 584 584 556 1015 667 667 722 722 667 611 778 722 278 500 667 556 833 722 778 667 778
722 667 611 722 667 944 667 667 611 278 278 278 469 556 333 556 556 500 556 556 278 556 556 222 222
500 222 833 556 556 556 556 333 500 278 556 500 722 500 500 500 334 260 334 584 0 556 0 222 556 333
1000 556 556 333 1000 667 333 1000 0 611 0 0 222 222 333 333 350 556 1000 333 1000 500 333 944 0 500
667 278 333 556 556 556 556 260 556 333 737 370 556 584 333 737 333 400 584 333 333 333 556 537 278
333 333 365 556 834 834 834 611 667 667 667 667 667 667 1000 722 667 667 667 667 278 278 278 278 722
722 778 778 778 778 778 584 778 722 722 722 722 667 667 611 556 556 556 556 556 556 889 500 556 556
556 556 278 278 278 278 556 556 556 556 556 556 556 584 611 556 556 556 556 500 556 500
""".split())
_LARGHEZZE_GRASSETTO = tuple(int(x) for x in """
278 333 474 556 556 889 722 238 333 333 389 584 278 333 278 278 556 556 556 556 556 556 556 556 556
556 333 333 584 584 584 611 975 722 722 722 722 667 611 778 722 278 556 722 611 833 722 778 667 778
722 667 611 722 667 944 667 667 611 333 278 333 584 556 333 556 611 556 611 556 333 611 611 278 278
556 278 889 611 611 611 611 389 556 333 611 556 778 556 556 500 389 280 389 584 0 556 0 278 556 500
1000 556 556 333 1000 667 333 1000 0 611 0 0 278 278 500 500 350 556 1000 333 1000 556 333 944 0 500
667 278 333 556 556 556 556 280 556 333 737 370 556 584 333 737 333 400 584 333 333 333 611 556 278
333 333 365 556 834 834 834 611 722 722 722 722 722 722 1000 722 667 667 667 667 278 278 278 278 722
722 778 778 778 778 778 584 778 722 722 722 722 667 667 611 556 556 556 556 556 556 889 556 556 556
556 556 278 278 278 278 611 611 611 611 611 611 611 584 611 611 611 611 611 556 611 556
""".split())
_CARATTERI_PDF = ("Helvetica", "Helvetica-Bold", "Helvetica-Oblique", "Helvetica-BoldOblique")
_PT_CM = 72 / 2.54
_A4 = (595.276, 841.89)
_MARGINE = 2 * _PT_CM
_BLU_SCURO = "0.122 0.220 0.392 rg"
_BLU = "0.184 0.329 0.588 rg"


def _cp1252(testo: str) -> bytes:
    """Il testo nella codifica dei caratteri standard del PDF; quello che non c'è diventa "?"."""
    testo = unicodedata.normalize("NFC", testo.replace("\t", "    "))
    try:
        return testo.encode("cp1252")
    except UnicodeEncodeError:
        pass
    pezzi = []
    for c in testo:
        try:
            pezzi.append(c.encode("cp1252"))
        except UnicodeEncodeError:
            base = "".join(x for x in unicodedata.normalize("NFKD", c) if not unicodedata.combining(x))
            pezzi.append(base.encode("cp1252", "replace") if base and base != c else b"?")
    return b"".join(pezzi)


def _larghezza_pdf(dati: bytes, grassetto: bool, corpo: float) -> float:
    tabella = _LARGHEZZE_GRASSETTO if grassetto else _LARGHEZZE_NORMALE
    return sum(tabella[b - 32] if b >= 32 else 0 for b in dati) * corpo / 1000


def _stringa_pdf(dati: bytes) -> bytes:
    return b"(" + dati.replace(b"\\", b"\\\\").replace(b"(", b"\\(").replace(b")", b"\\)").replace(b"\r", b"\\r") + b")"


def _testo_info_pdf(testo: str) -> bytes:
    """Un testo per il dizionario delle informazioni del PDF (UTF-16 se serve)."""
    try:
        dati = testo.encode("ascii")
        return _stringa_pdf(dati)
    except UnicodeEncodeError:
        return b"<FEFF" + testo.encode("utf-16-be", "replace").hex().upper().encode("ascii") + b">"


def _numero_pdf(n: float) -> str:
    if isinstance(n, int):
        return str(n)
    testo = f"{n:.3f}".rstrip("0").rstrip(".")
    return testo if testo not in ("-0", "") else "0"


class _Pezzo:
    """Un pezzo di parola con il suo carattere (grassetto, corsivo)."""

    __slots__ = ("dati", "grassetto", "corsivo", "larghezza")

    def __init__(self, dati: bytes, grassetto: bool, corsivo: bool, corpo: float) -> None:
        self.dati, self.grassetto, self.corsivo = dati, grassetto, corsivo
        self.larghezza = _larghezza_pdf(dati, grassetto, corpo)

    @property
    def carattere(self) -> int:
        return 1 + int(self.grassetto) + 2 * int(self.corsivo)


def _gruppi_di_parole(frammenti: list[tuple[str, bool, bool]], corpo: float) -> list[Any]:
    """Le parole (liste di pezzi attaccati) separate da spazi; "\n" è un a capo obbligato."""
    gruppi: list[Any] = []
    attuale: list[_Pezzo] = []
    for testo, grassetto, corsivo in frammenti:
        for m in re.finditer(r"\n|[ \u00a0\u2009]+|[^ \n\u00a0\u2009]+", testo):
            t = m.group(0)
            if t == "\n":
                if attuale:
                    gruppi.append(attuale)
                    attuale = []
                gruppi.append("\n")
            elif t[0] in " \u00a0\u2009":
                if attuale:
                    gruppi.append(attuale)
                    attuale = []
            else:
                attuale.append(_Pezzo(_cp1252(t), grassetto, corsivo, corpo))
    if attuale:
        gruppi.append(attuale)
    return gruppi


def _spezza_pezzo(pezzo: _Pezzo, larghezza: float, corpo: float) -> list[_Pezzo]:
    """Una parola troppo lunga per la riga, tagliata in pezzi che ci stanno."""
    risultato, attuale = [], b""
    for b in pezzo.dati:
        prova = attuale + bytes([b])
        if attuale and _larghezza_pdf(prova, pezzo.grassetto, corpo) > larghezza:
            risultato.append(_Pezzo(attuale, pezzo.grassetto, pezzo.corsivo, corpo))
            attuale = bytes([b])
        else:
            attuale = prova
    if attuale:
        risultato.append(_Pezzo(attuale, pezzo.grassetto, pezzo.corsivo, corpo))
    return risultato


def _righe_pdf(frammenti: list[tuple[str, bool, bool]], corpo: float, larghezza: float) -> list[list[list[_Pezzo]]]:
    """Le righe di un paragrafo: ogni riga è una lista di parole, ogni parola una lista di pezzi."""
    spazio = _larghezza_pdf(b" ", False, corpo)
    larghezza += 0.01   # tolleranza per gli arrotondamenti
    righe: list[list[list[_Pezzo]]] = []
    riga: list[list[_Pezzo]] = []
    occupata = 0.0
    for gruppo in _gruppi_di_parole(frammenti, corpo):
        if gruppo == "\n":
            righe.append(riga)
            riga, occupata = [], 0.0
            continue
        misura = sum(p.larghezza for p in gruppo)
        if misura > larghezza:
            if riga:
                righe.append(riga)
                riga, occupata = [], 0.0
            pezzi = [q for p in gruppo for q in (_spezza_pezzo(p, larghezza, corpo) if p.larghezza > larghezza else [p])]
            for p in pezzi:
                if riga and occupata + p.larghezza > larghezza:
                    righe.append(riga)
                    riga, occupata = [], 0.0
                if riga:
                    riga[-1].append(p)
                else:
                    riga.append([p])
                occupata += p.larghezza
            continue
        aggiunta = misura + (spazio if riga else 0)
        if riga and occupata + aggiunta > larghezza:
            righe.append(riga)
            riga, occupata = [], 0.0
            aggiunta = misura
        riga.append(gruppo)
        occupata += aggiunta
    if riga or not righe:
        righe.append(riga)
    return righe


class _ImmaginePdf:
    """Un'immagine pronta per il PDF: dizionario, dati ed eventuale maschera di trasparenza."""

    def __init__(self, dizionario: str, dati: bytes, maschera: tuple[str, bytes] | None = None) -> None:
        self.dizionario, self.dati, self.maschera = dizionario, dati, maschera


def _immagine_pdf(immagine: _Immagine) -> _ImmaginePdf:
    if immagine.formato == "jpeg":
        spazio = {1: "/DeviceGray", 3: "/DeviceRGB", 4: "/DeviceCMYK"}.get(immagine.componenti)
        if spazio is None:
            raise ErroreValore(f"L'immagine `{immagine.percorso}` usa colori che il PDF non conosce.",
                               suggerimento="Salvala di nuovo come JPEG normale (RGB).")
        inverti = " /Decode [1 0 1 0 1 0 1 0]" if immagine.componenti == 4 and immagine.adobe else ""
        return _ImmaginePdf(f"/Type /XObject /Subtype /Image /Width {immagine.larghezza} /Height {immagine.altezza} "
                            f"/ColorSpace {spazio} /BitsPerComponent 8 /Filter /DCTDecode{inverti}", immagine.dati)
    if immagine.formato == "png":
        return _png_pdf(immagine)
    raise ErroreValore(f"Le immagini GIF come `{immagine.percorso}` non si possono mettere in un PDF.",
                       suggerimento="Salvala come .png o .jpg.")


def _png_pdf(immagine: _Immagine) -> _ImmaginePdf:
    dati = immagine.dati
    pos = 8
    idat: list[bytes] = []
    tavolozza = b""
    intestazione = b""
    while pos + 8 <= len(dati):
        lunghezza, tipo = struct.unpack(">I4s", dati[pos:pos + 8])
        corpo = dati[pos + 8:pos + 8 + lunghezza]
        if tipo == b"IHDR":
            intestazione = corpo
        elif tipo == b"PLTE":
            tavolozza = corpo
        elif tipo == b"IDAT":
            idat.append(corpo)
        elif tipo == b"IEND":
            break
        pos += 12 + lunghezza
    if len(intestazione) < 13 or not idat:
        raise ErroreValore(f"L'immagine PNG `{immagine.percorso}` è danneggiata.")
    larghezza, altezza, bit, colore, _, _, interlacciata = struct.unpack(">IIBBBBB", intestazione[:13])
    if interlacciata:
        raise ErroreValore(f"L'immagine PNG `{immagine.percorso}` è \"interlacciata\" e non va nei PDF.",
                           suggerimento="Salvala di nuovo senza interlacciamento, o come JPEG.")
    compressi = b"".join(idat)
    if colore in (0, 2, 3):
        spazio = {0: "/DeviceGray", 2: "/DeviceRGB"}.get(colore)
        if colore == 3:
            if not tavolozza:
                raise ErroreValore(f"L'immagine PNG `{immagine.percorso}` è danneggiata (manca la tavolozza).")
            spazio = f"[/Indexed /DeviceRGB {len(tavolozza) // 3 - 1} <{tavolozza[:len(tavolozza) // 3 * 3].hex()}>]"
        colori = 3 if colore == 2 else 1
        return _ImmaginePdf(f"/Type /XObject /Subtype /Image /Width {larghezza} /Height {altezza} /ColorSpace {spazio} "
                            f"/BitsPerComponent {bit} /Filter /FlateDecode /DecodeParms << /Predictor 15 /Colors {colori} "
                            f"/BitsPerComponent {bit} /Columns {larghezza} >>", compressi)
    if colore not in (4, 6) or bit not in (8, 16):
        raise ErroreValore(f"L'immagine PNG `{immagine.percorso}` ha un formato che non conosco.",
                           suggerimento="Salvala di nuovo come PNG a colori normale, o come JPEG.")
    if larghezza * altezza > 6_000_000:
        raise ErroreValore(f"L'immagine PNG `{immagine.percorso}` con trasparenza è troppo grande per il PDF.",
                           suggerimento="Rimpiccioliscila o salvala come JPEG.")
    canali = 4 if colore == 6 else 2
    campione = bit // 8
    passo = canali * campione
    riga_byte = larghezza * passo
    try:
        grezzi = zlib.decompressobj().decompress(compressi, (riga_byte + 1) * altezza + 1)
    except zlib.error:
        raise ErroreValore(f"L'immagine PNG `{immagine.percorso}` è danneggiata.") from None
    pixel = _togli_filtri_png(grezzi, riga_byte, altezza, passo)
    if pixel is None:
        raise ErroreValore(f"L'immagine PNG `{immagine.percorso}` è danneggiata.")
    if campione == 2:
        pixel = pixel[0::2]          # 16 bit -> 8 bit (il byte più importante)
    n = larghezza * altezza
    alfa = bytes(pixel[canali - 1::canali])
    colori = canali - 1
    colore_dati = bytearray(n * colori)
    for k in range(colori):
        colore_dati[k::colori] = pixel[k::canali]
    spazio = "/DeviceRGB" if colori == 3 else "/DeviceGray"
    maschera = (f"/Type /XObject /Subtype /Image /Width {larghezza} /Height {altezza} /ColorSpace /DeviceGray "
                "/BitsPerComponent 8 /Filter /FlateDecode", zlib.compress(alfa))
    return _ImmaginePdf(f"/Type /XObject /Subtype /Image /Width {larghezza} /Height {altezza} /ColorSpace {spazio} "
                        "/BitsPerComponent 8 /Filter /FlateDecode", zlib.compress(bytes(colore_dati)), maschera)


def _togli_filtri_png(dati: bytes, riga_byte: int, altezza: int, passo: int) -> bytearray | None:
    """Toglie i "filtri" delle righe PNG (li usano anche i PDF compressi con /Predictor)."""
    risultato = bytearray(riga_byte * altezza)
    precedente = bytearray(riga_byte)
    pos = 0
    for r in range(altezza):
        if pos + 1 + riga_byte > len(dati):
            return None
        filtro = dati[pos]
        riga = bytearray(dati[pos + 1:pos + 1 + riga_byte])
        pos += 1 + riga_byte
        if filtro == 1:
            for i in range(passo, riga_byte):
                riga[i] = (riga[i] + riga[i - passo]) & 0xFF
        elif filtro == 2:
            for i in range(riga_byte):
                riga[i] = (riga[i] + precedente[i]) & 0xFF
        elif filtro == 3:
            for i in range(riga_byte):
                sinistra = riga[i - passo] if i >= passo else 0
                riga[i] = (riga[i] + ((sinistra + precedente[i]) >> 1)) & 0xFF
        elif filtro == 4:
            for i in range(riga_byte):
                a = riga[i - passo] if i >= passo else 0
                b = precedente[i]
                c = precedente[i - passo] if i >= passo else 0
                p = a + b - c
                pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                riga[i] = (riga[i] + (a if pa <= pb and pa <= pc else b if pb <= pc else c)) & 0xFF
        elif filtro != 0:
            return None
        risultato[r * riga_byte:(r + 1) * riga_byte] = riga
        precedente = riga
    return risultato


def _matrice_orientamento(orientamento: int, x: float, y: float, larghezza: float, altezza: float) -> str:
    """La matrice `cm` che disegna un'immagine JPEG girata come dice il suo EXIF."""
    if orientamento in (5, 6):
        m = (0, -altezza, larghezza, 0, x, y + altezza)
    elif orientamento in (7, 8):
        m = (0, altezza, -larghezza, 0, x + larghezza, y)
    elif orientamento in (3, 4):
        m = (-larghezza, 0, 0, -altezza, x + larghezza, y + altezza)
    else:
        m = (larghezza, 0, 0, altezza, x, y)
    return " ".join(_numero_pdf(float(v)) for v in m) + " cm"


class _Impaginatore:
    """Mette titoli, paragrafi, elenchi, tabelle e immagini nelle pagine A4 di un PDF."""

    def __init__(self, numeri_pagina: bool = True) -> None:
        self.larghezza_pagina, self.altezza_pagina = _A4
        self.sinistra = _MARGINE
        self.larghezza = self.larghezza_pagina - 2 * _MARGINE
        self.alto = self.altezza_pagina - _MARGINE
        self.basso = _MARGINE
        self.numeri_pagina = numeri_pagina
        self.pagine: list[list[str]] = []
        self.formati: list[tuple[float, float]] = []
        self.immagini: list[_ImmaginePdf] = []
        self.immagini_pagina: list[set[int]] = []
        self.y = 0.0
        self.nuova_pagina()

    def nuova_pagina(self, formato: tuple[float, float] | None = None) -> None:
        self.pagine.append([])
        self.immagini_pagina.append(set())
        self.formati.append(formato or _A4)
        self.y = self.alto

    @property
    def vuota(self) -> bool:
        return not self.pagine[-1]

    def disegna(self, comando: str) -> None:
        self.pagine[-1].append(comando)

    def serve_spazio(self, altezza: float) -> None:
        if self.y - altezza < self.basso and not self.vuota:
            self.nuova_pagina()

    def scrivi_riga(self, riga: list[list[_Pezzo]], x: float, baseline: float, corpo: float, larghezza: float,
                    allinea: str, ultima: bool, colore: str = "") -> None:
        spazio = _larghezza_pdf(b" ", False, corpo)
        misura = sum(sum(p.larghezza for p in g) for g in riga) + spazio * max(0, len(riga) - 1)
        extra = 0.0
        if allinea == "centro":
            x += max(0.0, (larghezza - misura) / 2)
        elif allinea == "destra":
            x += max(0.0, larghezza - misura)
        elif allinea == "giustificato" and not ultima and len(riga) > 1:
            extra = max(0.0, (larghezza - misura) / (len(riga) - 1))
        comandi = ["BT", colore or "0 g"]
        carattere_attuale = 0
        for n, gruppo in enumerate(riga, 1):
            comandi.append(f"1 0 0 1 {_numero_pdf(x)} {_numero_pdf(baseline)} Tm")
            for i, p in enumerate(gruppo, 1):
                if p.carattere != carattere_attuale:
                    comandi.append(f"/F{p.carattere} {_numero_pdf(corpo)} Tf")
                    carattere_attuale = p.carattere
                # lo spazio dopo la parola non sposta niente (la parola dopo ha la sua posizione),
                # ma serve a chi copia o cerca il testo nel PDF
                dati = p.dati + b" " if i == len(gruppo) and n < len(riga) else p.dati
                comandi.append(_stringa_pdf(dati).decode("latin-1") + " Tj")
                x += p.larghezza
            x += spazio + extra
        comandi.append("ET")
        self.disegna("\n".join(comandi))

    def paragrafo(self, testo: str, corpo: float = 11, allinea: str = "sinistra", rientro: float = 0,
                  prima: float = 0, dopo: float = 6, grassetto: bool = False, colore: str = "",
                  etichetta: bytes = b"", tieni_con_il_seguente: bool = False) -> None:
        frammenti = [(t, g or grassetto, c) for t, g, c in _frammenti(testo)] or [("", grassetto, False)]
        larghezza = self.larghezza - rientro
        righe = _righe_pdf(frammenti, corpo, larghezza)
        interlinea = corpo * 1.3
        if not self.vuota:
            self.y -= prima
        riserva = interlinea * (len(righe) + 3 if tieni_con_il_seguente else min(2, len(righe)))
        self.serve_spazio(riserva)
        for i, riga in enumerate(righe):
            self.serve_spazio(interlinea)
            baseline = self.y - corpo
            if i == 0 and etichetta:
                misura = _larghezza_pdf(etichetta, False, corpo)
                self.disegna(f"BT 0 g /F1 {_numero_pdf(corpo)} Tf 1 0 0 1 "
                             f"{_numero_pdf(self.sinistra + rientro - misura - 5)} {_numero_pdf(baseline)} Tm "
                             f"{_stringa_pdf(etichetta).decode('latin-1')} Tj ET")
            if riga:
                self.scrivi_riga(riga, self.sinistra + rientro, baseline, corpo, larghezza, allinea,
                                 i == len(righe) - 1, colore)
            self.y -= interlinea
        self.y -= dopo

    def titolo(self, testo: str, livello: int) -> None:
        corpo = {0: 22.0, 1: 16.0, 2: 13.5}.get(livello, 12.0)
        self.paragrafo(testo, corpo, grassetto=True, prima=corpo * 0.8 if livello else 0,
                       dopo=corpo * (0.6 if livello == 0 else 0.35),
                       colore=_BLU_SCURO if livello == 0 else _BLU, tieni_con_il_seguente=True)

    def elenco(self, voci: list[str], numerato: bool) -> None:
        for i, voce in enumerate(voci, 1):
            etichetta = f"{i}.".encode("ascii") if numerato else b"\x95"
            self.paragrafo(voce, rientro=22, dopo=3, etichetta=etichetta)
        self.y -= 4

    def tabella(self, griglia: list[list[str]], intestazione: bool) -> None:
        if not griglia:
            return
        corpo, margine = 10.0, 4.0
        colonne = max(len(r) for r in griglia)
        celle = [[[(t, g or (intestazione and r == 0), c) for t, g, c in _frammenti(riga[i] if i < len(riga) else "")]
                  for i in range(colonne)] for r, riga in enumerate(griglia)]
        naturali, minime = [2 * margine + 10] * colonne, [2 * margine + 10] * colonne
        for riga in celle[:1000]:
            for i, frammenti in enumerate(riga):
                for linea in _gruppi_linee(frammenti):
                    gruppi = [g for g in _gruppi_di_parole(linea, corpo) if g != "\n"]
                    spazio = _larghezza_pdf(b" ", False, corpo)
                    misure = [sum(p.larghezza for p in g) for g in gruppi]
                    naturali[i] = max(naturali[i], sum(misure) + spazio * max(0, len(misure) - 1) + 2 * margine)
                    minime[i] = max(minime[i], max(misure, default=0) + 2 * margine)
        totale = self.larghezza
        if sum(naturali) <= totale:
            larghezze = [n * totale / sum(naturali) for n in naturali]
        elif sum(minime) >= totale:
            larghezze = [m * totale / sum(minime) for m in minime]
        else:
            resto = totale - sum(minime)
            differenze = [n - m for n, m in zip(naturali, minime)]
            larghezze = [m + resto * d / (sum(differenze) or 1) for m, d in zip(minime, differenze)]
        interlinea = corpo * 1.25
        disposte = [[_righe_pdf(fr or [("", False, False)], corpo, max(1.0, w - 2 * margine))
                     for fr, w in zip(riga, larghezze)] for riga in celle]
        altezze = [max(len(c) for c in riga) * interlinea + 2 * margine for riga in disposte]

        def disegna_riga(r: int) -> None:
            x = self.sinistra
            h = altezze[r]
            testa = intestazione and r == 0
            for c, w in enumerate(larghezze):
                if testa:
                    self.disegna(f"0.867 0.922 0.969 rg {_numero_pdf(x)} {_numero_pdf(self.y - h)} {_numero_pdf(w)} "
                                 f"{_numero_pdf(h)} re f")
                self.disegna(f"0.5 G 0.5 w {_numero_pdf(x)} {_numero_pdf(self.y - h)} {_numero_pdf(w)} "
                             f"{_numero_pdf(h)} re S")
                for k, linea in enumerate(disposte[r][c]):
                    if linea:
                        self.scrivi_riga(linea, x + margine, self.y - margine - corpo - k * interlinea + 2, corpo,
                                         w - 2 * margine, "sinistra", True)
                x += w
            self.y -= h

        self.y -= 4
        for r in range(len(disposte)):
            if self.y - altezze[r] < self.basso and not self.vuota:
                self.nuova_pagina()
                if intestazione and r > 0:
                    disegna_riga(0)
            disegna_riga(r)
        self.y -= 10

    def immagine(self, immagine: _Immagine, larghezza_cm: float | None) -> None:
        larghezza_cm_, altezza_cm_ = _misura_immagine_cm(immagine, larghezza_cm, self.larghezza / _PT_CM,
                                                         (self.alto - self.basso) / _PT_CM, vista=True)
        larghezza, altezza = larghezza_cm_ * _PT_CM, altezza_cm_ * _PT_CM
        self.serve_spazio(altezza + 6)
        x = self.sinistra + (self.larghezza - larghezza) / 2
        self.disegna_immagine(immagine, x, self.y - altezza, larghezza, altezza)
        self.y -= altezza + 10

    def disegna_immagine(self, immagine: _Immagine, x: float, y: float, larghezza: float, altezza: float) -> None:
        indice = len(self.immagini)
        self.immagini.append(_immagine_pdf(immagine))
        self.immagini_pagina[-1].add(indice)
        orientamento = immagine.orientamento if immagine.formato == "jpeg" else 1
        self.disegna(f"q {_matrice_orientamento(orientamento, x, y, larghezza, altezza)} /Im{indice + 1} Do Q")

    def componi(self, titolo: str = "") -> bytes:
        oggetti: list[bytes] = []

        def aggiungi(contenuto: bytes) -> int:
            oggetti.append(contenuto)
            return len(oggetti)

        aggiungi(b"")  # 1: catalogo (dopo)
        aggiungi(b"")  # 2: albero delle pagine (dopo)
        caratteri = [aggiungi(f"<< /Type /Font /Subtype /Type1 /BaseFont /{n} /Encoding /WinAnsiEncoding >>"
                              .encode("ascii")) for n in _CARATTERI_PDF]
        numeri_immagini = []
        for im in self.immagini:
            maschera = ""
            if im.maschera:
                n = aggiungi(_flusso_pdf(im.maschera[0], im.maschera[1]))
                maschera = f" /SMask {n} 0 R"
            numeri_immagini.append(aggiungi(_flusso_pdf(im.dizionario + maschera, im.dati)))
        risorse_caratteri = " ".join(f"/F{i} {n} 0 R" for i, n in enumerate(caratteri, 1))
        figli = []
        totale = len(self.pagine)
        for numero, (comandi, formato, usate) in enumerate(zip(self.pagine, self.formati, self.immagini_pagina), 1):
            if self.numeri_pagina and totale > 1:
                piede = _cp1252(f"Pagina {numero} di {totale}")
                x = (formato[0] - _larghezza_pdf(piede, False, 9)) / 2
                comandi = comandi + [f"BT 0.4 g /F1 9 Tf 1 0 0 1 {_numero_pdf(x)} 28 Tm "
                                     f"{_stringa_pdf(piede).decode('latin-1')} Tj ET"]
            contenuto = zlib.compress("\n".join(comandi).encode("latin-1"))
            n_contenuto = aggiungi(_flusso_pdf("/Filter /FlateDecode", contenuto))
            xobject = ""
            if usate:
                xobject = " /XObject << " + " ".join(f"/Im{i + 1} {numeri_immagini[i]} 0 R" for i in sorted(usate)) + " >>"
            figli.append(aggiungi(
                f"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 {_numero_pdf(formato[0])} {_numero_pdf(formato[1])}] "
                f"/Resources << /Font << {risorse_caratteri} >>{xobject} >> /Contents {n_contenuto} 0 R >>"
                .encode("ascii")))
        oggetti[0] = b"<< /Type /Catalog /Pages 2 0 R >>"
        oggetti[1] = (f"<< /Type /Pages /Kids [{' '.join(f'{n} 0 R' for n in figli)}] /Count {len(figli)} >>"
                      .encode("ascii"))
        adesso = datetime.datetime.now().strftime("D:%Y%m%d%H%M%S")
        info = aggiungi(b"<< /Producer (Leo) /Creator (Leo) /CreationDate (" + adesso.encode("ascii") + b")"
                        + (b" /Title " + _testo_info_pdf(titolo) if titolo else b"") + b" >>")
        return _file_pdf(oggetti, info)


def _gruppi_linee(frammenti: list[tuple[str, bool, bool]]) -> list[list[tuple[str, bool, bool]]]:
    linee: list[list[tuple[str, bool, bool]]] = [[]]
    for t, g, c in frammenti:
        for i, pezzo in enumerate(t.split("\n")):
            if i:
                linee.append([])
            if pezzo:
                linee[-1].append((pezzo, g, c))
    return linee


def _flusso_pdf(dizionario: str | bytes, dati: bytes) -> bytes:
    if isinstance(dizionario, str):
        dizionario = dizionario.encode("latin-1")
    return b"<< " + dizionario + b" /Length " + str(len(dati)).encode("ascii") + b" >>\nstream\n" + dati + b"\nendstream"


def _file_pdf(oggetti: list[bytes], info: int | None = None, radice: int = 1) -> bytes:
    uscita = io.BytesIO()
    uscita.write(b"%PDF-1.7\n%\xe2\xe3\xcf\xd3\n")
    posizioni = []
    for numero, contenuto in enumerate(oggetti, 1):
        posizioni.append(uscita.tell())
        uscita.write(f"{numero} 0 obj\n".encode("ascii") + contenuto + b"\nendobj\n")
    inizio_xref = uscita.tell()
    uscita.write(f"xref\n0 {len(oggetti) + 1}\n0000000000 65535 f \n".encode("ascii"))
    for p in posizioni:
        uscita.write(f"{p:010d} 00000 n \n".encode("ascii"))
    uscita.write(f"trailer\n<< /Size {len(oggetti) + 1} /Root {radice} 0 R".encode("ascii")
                 + (f" /Info {info} 0 R".encode("ascii") if info else b"")
                 + f" >>\nstartxref\n{inizio_xref}\n%%EOF\n".encode("ascii"))
    return uscita.getvalue()


def _pdf_documento(doc: Documento) -> bytes:
    impaginatore = _Impaginatore()
    for elemento in doc.elementi:
        tipo = elemento[0]
        if tipo == "titolo":
            impaginatore.titolo(elemento[1], elemento[2])
        elif tipo == "paragrafo":
            impaginatore.paragrafo(elemento[1], allinea=elemento[2])
        elif tipo == "elenco":
            impaginatore.elenco(elemento[1], elemento[2])
        elif tipo == "tabella":
            impaginatore.tabella(elemento[1], elemento[2])
        elif tipo == "immagine":
            impaginatore.immagine(elemento[1], elemento[2])
        elif tipo == "pagina":
            impaginatore.nuova_pagina()
    return impaginatore.componi(doc.titolo)


# ---------------------------------------------------------------------------
# PDF: lettura (un piccolo lettore di oggetti PDF)
# ---------------------------------------------------------------------------

class _PdfRotto(Exception):
    """Un pezzo del PDF che non si riesce a leggere."""


class _Nome(str):
    """Un nome PDF (``/Type``) senza la barra."""


class _Rif(tuple):
    """Un riferimento a un oggetto (``12 0 R``)."""

    @property
    def numero(self) -> int:
        return self[0]


class _Flusso:
    """Un oggetto con dati (``stream``): dizionario e byte ancora codificati."""

    __slots__ = ("diz", "grezzi")

    def __init__(self, diz: dict, grezzi: bytes) -> None:
        self.diz, self.grezzi = diz, grezzi


_RE_SPAZI_PDF = re.compile(rb"(?:[\x00\t\n\x0c\r ]+|%[^\r\n]*)*")
_RE_NUMERO_PDF = re.compile(rb"[+-]?(?:\d+\.?\d*|\.\d+)")
_RE_RIF_PDF = re.compile(rb"[\x00\t\n\x0c\r ]+(\d+)[\x00\t\n\x0c\r ]+R(?![A-Za-z0-9])")
_RE_REGOLARI_PDF = re.compile(rb"[^\x00\t\n\x0c\r ()<>\[\]{}/%]*")
_RE_OPERATORE_PDF = re.compile(rb"[A-Za-z'\"*][A-Za-z0-9'\"*]*")
_RE_OGGETTO_PDF = re.compile(rb"(?<![0-9])(\d{1,10})[\x00\t\n\x0c\r ]+(\d{1,5})[\x00\t\n\x0c\r ]+obj(?![A-Za-z0-9])")
_ESCAPE_PDF = {ord("n"): b"\n", ord("r"): b"\r", ord("t"): b"\t", ord("b"): b"\b", ord("f"): b"\f",
               ord("("): b"(", ord(")"): b")", ord("\\"): b"\\"}
_PROFONDITA_PDF = 60


class _Lettore:
    """Legge gli oggetti PDF uno dopo l'altro da una sequenza di byte."""

    def __init__(self, dati: bytes, pos: int = 0, operatori: bool = False) -> None:
        self.dati, self.pos, self.operatori = dati, pos, operatori

    def spazi(self) -> None:
        self.pos = _RE_SPAZI_PDF.match(self.dati, self.pos).end()

    def fine(self) -> bool:
        self.spazi()
        return self.pos >= len(self.dati)

    def oggetto(self, profondita: int = 0) -> Any:
        if profondita > _PROFONDITA_PDF:
            raise _PdfRotto("troppo annidato")
        self.spazi()
        dati, pos = self.dati, self.pos
        if pos >= len(dati):
            raise _PdfRotto("fine inattesa")
        c = dati[pos]
        if c == 0x2F:  # /
            m = _RE_REGOLARI_PDF.match(dati, pos + 1)
            self.pos = m.end()
            grezzo = m.group(0)
            if b"#" in grezzo:
                grezzo = re.sub(rb"#([0-9A-Fa-f]{2})", lambda x: bytes([int(x.group(1), 16)]), grezzo)
            return _Nome(grezzo.decode("latin-1"))
        if c == 0x28:  # (
            return self._stringa()
        if c == 0x3C:  # <
            if dati[pos + 1:pos + 2] == b"<":
                self.pos += 2
                diz: dict = {}
                while True:
                    self.spazi()
                    if self.dati[self.pos:self.pos + 2] == b">>":
                        self.pos += 2
                        return diz
                    if self.pos >= len(self.dati):
                        raise _PdfRotto("dizionario non chiuso")
                    chiave = self.oggetto(profondita + 1)
                    if not isinstance(chiave, _Nome):
                        if self.operatori:
                            continue
                        raise _PdfRotto("chiave non valida")
                    self.spazi()
                    if self.dati[self.pos:self.pos + 2] == b">>":
                        diz[str(chiave)] = None
                        continue
                    diz[str(chiave)] = self.oggetto(profondita + 1)
            fine = dati.find(b">", pos + 1)
            if fine < 0:
                raise _PdfRotto("stringa esadecimale non chiusa")
            cifre = re.sub(rb"[^0-9A-Fa-f]", b"", dati[pos + 1:fine])
            if len(cifre) % 2:
                cifre += b"0"
            self.pos = fine + 1
            return bytes.fromhex(cifre.decode("ascii"))
        if c == 0x5B:  # [
            self.pos += 1
            lista = []
            while True:
                self.spazi()
                if self.pos >= len(self.dati):
                    raise _PdfRotto("lista non chiusa")
                if self.dati[self.pos] == 0x5D:
                    self.pos += 1
                    return lista
                lista.append(self.oggetto(profondita + 1))
        m = _RE_NUMERO_PDF.match(dati, pos)
        if m:
            testo = m.group(0)
            self.pos = m.end()
            if b"." in testo:
                try:
                    return float(testo)
                except ValueError:
                    return 0.0
            numero = int(testo)
            if not self.operatori:
                r = _RE_RIF_PDF.match(dati, self.pos)
                if r:
                    self.pos = r.end()
                    return _Rif((numero, int(r.group(1))))
            return numero
        m = _RE_OPERATORE_PDF.match(dati, pos)
        if m:
            parola = m.group(0)
            self.pos = m.end()
            if parola == b"true":
                return True
            if parola == b"false":
                return False
            if parola == b"null":
                return None
            if self.operatori:
                return _Operatore(parola.decode("latin-1"))
            raise _PdfRotto("parola inattesa")
        if self.operatori:
            self.pos += 1
            return _Operatore("")
        raise _PdfRotto("carattere inatteso")

    def _stringa(self) -> bytes:
        dati = self.dati
        pos = self.pos + 1
        livello = 1
        pezzi = bytearray()
        lunghezza = len(dati)
        while pos < lunghezza:
            c = dati[pos]
            if c == 0x5C:  # \
                pos += 1
                if pos >= lunghezza:
                    break
                d = dati[pos]
                if d in _ESCAPE_PDF:
                    pezzi += _ESCAPE_PDF[d]
                    pos += 1
                elif 0x30 <= d <= 0x37:
                    m = re.match(rb"[0-7]{1,3}", dati[pos:pos + 3])
                    pezzi.append(int(m.group(0), 8) & 0xFF)
                    pos += len(m.group(0))
                elif d == 0x0D:
                    pos += 2 if dati[pos + 1:pos + 2] == b"\n" else 1
                elif d == 0x0A:
                    pos += 1
                else:
                    pezzi.append(d)
                    pos += 1
                continue
            if c == 0x28:
                livello += 1
            elif c == 0x29:
                livello -= 1
                if livello == 0:
                    self.pos = pos + 1
                    return bytes(pezzi)
            pezzi.append(c)
            pos += 1
        raise _PdfRotto("stringa non chiusa")


class _Operatore(str):
    """Un operatore di un flusso di contenuto (``Tj``, ``BT``...)."""


_RE_GETTONE_PDF = re.compile(
    rb"(?:[\x00\t\n\x0c\r ]+|%[^\r\n]*)*"
    rb"(?:(?P<n>[+-]?(?:\d+\.?\d*|\.\d+))|/(?P<nome>[^\x00\t\n\x0c\r ()<>\[\]{}/%]*)"
    rb"|(?P<op>[A-Za-z'\"*][A-Za-z0-9'\"*]*)|(?P<altro>[(<\[])|(?P<resto>.))", re.S)


_RE_FUORI_TESTO = re.compile(rb"(?<![A-Za-z0-9*'\"/])(BT|Do|cm|q|Q|BI)(?![A-Za-z0-9*'\"])")
_RE_CM = re.compile(rb"((?:[+-]?(?:\d+\.?\d*|\.\d+)[\x00\t\n\x0c\r ]+){6})cm$")
_RE_DO = re.compile(rb"/([^\x00\t\n\x0c\r ()<>\[\]{}/%]*)[\x00\t\n\x0c\r ]*Do$")
_RE_FINE_IMMAGINE = re.compile(rb"[\x00\t\n\x0c\r ]EI(?=[\x00\t\n\x0c\r ]|$)")


def _gettoni_contenuto(dati: bytes):
    """I pezzi (numeri, nomi, testi, liste, operatori) di un flusso di contenuto, uno dopo l'altro."""
    pos, fine = 0, len(dati)
    lettore = _Lettore(dati, 0, operatori=True)
    corrispondi = _RE_GETTONE_PDF.match
    in_testo = False
    while pos < fine:
        if not in_testo:
            # fuori da BT ... ET contano solo q, Q, cm, Do (e BT): il resto (disegni) si salta in fretta
            m = _RE_FUORI_TESTO.search(dati, pos)
            if m is None:
                return
            op, pos = m.group(1), m.end()
            if op == b"BT":
                in_testo = True
                yield _Operatore("BT")
            elif op in (b"q", b"Q"):
                yield _Operatore(op.decode("ascii"))
            elif op == b"cm":
                w = _RE_CM.search(dati, max(0, m.start() - 160), m.end())
                if w:
                    yield from (float(n) for n in w.group(1).split())
                    yield _Operatore("cm")
            elif op == b"Do":
                w = _RE_DO.search(dati, max(0, m.start() - 160), m.end())
                if w:
                    yield _Nome(w.group(1).decode("latin-1"))
                    yield _Operatore("Do")
            else:  # BI: immagine dentro il flusso
                fine_immagine = _RE_FINE_IMMAGINE.search(dati, pos)
                pos = fine_immagine.end() if fine_immagine else fine
            continue
        m = corrispondi(dati, pos)
        if m is None:
            return
        pos = m.end()
        n = m.group("n")
        if n is not None:
            if b"." in n:
                try:
                    yield float(n)
                except ValueError:
                    yield 0.0
            else:
                yield int(n)
            continue
        op = m.group("op")
        if op is not None:
            if op == b"true":
                yield True
            elif op == b"false":
                yield False
            elif op == b"null":
                yield None
            elif op == b"BI":   # immagine dentro il flusso: si salta fino a EI
                fine_immagine = _RE_FINE_IMMAGINE.search(dati, pos)
                pos = fine_immagine.end() if fine_immagine else fine
            elif op == b"ET":
                in_testo = False
                yield _Operatore("ET")
            else:
                yield _Operatore(op.decode("latin-1"))
            continue
        nome = m.group("nome")
        if nome is not None:
            if b"#" in nome:
                nome = re.sub(rb"#([0-9A-Fa-f]{2})", lambda x: bytes([int(x.group(1), 16)]), nome)
            yield _Nome(nome.decode("latin-1"))
            continue
        if m.group("altro") is not None:
            lettore.pos = m.start("altro")
            try:
                yield lettore.oggetto()
            except (_PdfRotto, ValueError, OverflowError, RecursionError):
                lettore.pos = m.end()
                yield _Operatore("")
            pos = lettore.pos
            continue
        if m.group("resto") is None:
            return


def _decomprimi(dati: bytes) -> bytes:
    oggetto = zlib.decompressobj()
    try:
        risultato = oggetto.decompress(dati, MASSIMA_PARTE)
    except zlib.error:
        # alcuni PDF hanno la coda del flusso rovinata: si tiene quello che si è letto
        risultato = b""
        oggetto = zlib.decompressobj()
        for i in range(0, len(dati), 4096):
            try:
                risultato += oggetto.decompress(dati[i:i + 4096], MASSIMA_PARTE)
            except zlib.error:
                break
            if len(risultato) > MASSIMA_PARTE:
                break
        if not risultato:
            raise _PdfRotto("dati compressi rovinati") from None
    if oggetto.unconsumed_tail or len(risultato) > MASSIMA_PARTE:
        raise _PdfRotto("dati troppo grandi")
    return risultato


def _lzw(dati: bytes, anticipo: int = 1) -> bytes:
    uscita = bytearray()
    tabella = [bytes([i]) for i in range(256)] + [b"", b""]
    bit = 9
    precedente = b""
    riserva, quanti = 0, 0
    for byte in dati:
        riserva = (riserva << 8) | byte
        quanti += 8
        while quanti >= bit:
            quanti -= bit
            codice = (riserva >> quanti) & ((1 << bit) - 1)
            if codice == 256:
                tabella = tabella[:258]
                bit = 9
                precedente = b""
                continue
            if codice == 257:
                return bytes(uscita)
            if codice < len(tabella):
                voce = tabella[codice]
                if precedente:
                    tabella.append(precedente + voce[:1])
            elif precedente:
                voce = precedente + precedente[:1]
                tabella.append(voce)
            else:
                raise _PdfRotto("LZW rovinato")
            uscita += voce
            if len(uscita) > MASSIMA_PARTE:
                raise _PdfRotto("dati troppo grandi")
            precedente = voce
            if len(tabella) + anticipo >= (1 << bit) and bit < 12:
                bit += 1
    return bytes(uscita)


def _predittore(dati: bytes, parametri: Any) -> bytes:
    if not isinstance(parametri, dict):
        return dati
    predittore = parametri.get("Predictor", 1)
    if not isinstance(predittore, int) or predittore < 10:
        return dati
    colonne = parametri.get("Columns", 1)
    colori = parametri.get("Colors", 1)
    bit = parametri.get("BitsPerComponent", 8)
    if not all(isinstance(v, int) and 0 < v < 100000 for v in (colonne, colori, bit)):
        raise _PdfRotto("parametri non validi")
    passo = max(1, colori * bit // 8)
    riga = (colonne * colori * bit + 7) // 8
    altezza = len(dati) // (riga + 1)
    risultato = _togli_filtri_png(dati, riga, altezza, passo)
    if risultato is None:
        raise _PdfRotto("predittore rovinato")
    return bytes(risultato)


class _Pdf:
    """Un PDF aperto: gli oggetti, il trailer, le pagine."""

    def __init__(self, percorso: Any, nome: str) -> None:
        _controlla_percorso(percorso, nome)
        percorso = _percorso_da_leggere(percorso, nome, (".pdf",))
        self.percorso, self.nome = percorso, nome
        dati = _leggi_byte(percorso, nome)
        inizio = dati.find(b"%PDF-", 0, 1024)
        if inizio < 0:
            raise ErroreValore(f"Il file `{percorso}` non è un PDF.",
                               suggerimento="Controlla il nome: i PDF finiscono con .pdf e iniziano con %PDF.")
        self.dati = dati
        self.oggetti: dict[int, tuple[int, Any]] = {}
        self.trailer: dict = {}
        self._decodificati: dict[int, bytes] = {}
        self._carica()
        self.protetto = "Encrypt" in self.trailer

    # -- caricamento ----------------------------------------------------------
    def _carica(self) -> None:
        dati = self.dati
        pos = 0
        trailer_trovati: list[tuple[int, dict]] = []
        while True:
            m = _RE_OGGETTO_PDF.search(dati, pos)
            if not m:
                break
            numero = int(m.group(1))
            try:
                valore, fine = self._oggetto_indiretto(m.end())
            except (_PdfRotto, ValueError, OverflowError, RecursionError):
                pos = m.end()
                continue
            self.oggetti[numero] = (m.start(), valore)
            if isinstance(valore, _Flusso) and valore.diz.get("Type") == "XRef":
                trailer_trovati.append((m.start(), valore.diz))
            pos = max(fine, m.end())
        for m in re.finditer(rb"trailer[\x00\t\n\x0c\r ]*<<", dati):
            try:
                diz = _Lettore(dati, m.end() - 2).oggetto()
            except (_PdfRotto, ValueError, OverflowError, RecursionError):
                continue
            if isinstance(diz, dict):
                trailer_trovati.append((m.start(), diz))
        for posizione, flusso in [(p, v) for p, v in list(self.oggetti.values())
                                  if isinstance(v, _Flusso) and v.diz.get("Type") == "ObjStm"]:
            self._carica_flusso_oggetti(posizione, flusso)
        trailer_trovati.sort(key=lambda t: t[0])
        for _, diz in trailer_trovati:
            for chiave in ("Root", "Info", "Encrypt", "ID"):
                if chiave in diz and diz[chiave] is not None:
                    self.trailer[chiave] = diz[chiave]
        if "Root" not in self.trailer:
            for numero, (_, v) in self.oggetti.items():
                if isinstance(v, dict) and v.get("Type") == "Catalog":
                    self.trailer["Root"] = _Rif((numero, 0))

    def _oggetto_indiretto(self, pos: int) -> tuple[Any, int]:
        lettore = _Lettore(self.dati, pos)
        valore = lettore.oggetto()
        lettore.spazi()
        dati = self.dati
        if isinstance(valore, dict) and dati.startswith(b"stream", lettore.pos):
            inizio = lettore.pos + 6
            if dati[inizio:inizio + 2] == b"\r\n":
                inizio += 2
            elif dati[inizio:inizio + 1] in (b"\n", b"\r"):
                inizio += 1
            lunghezza = valore.get("Length")
            fine = -1
            if isinstance(lunghezza, int) and 0 <= lunghezza <= len(dati) - inizio:
                dopo = _RE_SPAZI_PDF.match(dati, inizio + lunghezza).end()
                if dati.startswith(b"endstream", dopo):
                    fine = inizio + lunghezza
                    termine = dopo + 9
            if fine < 0:
                trovato = dati.find(b"endstream", inizio)
                if trovato < 0:
                    raise _PdfRotto("flusso non chiuso")
                fine = trovato
                if dati[fine - 2:fine] == b"\r\n":
                    fine -= 2
                elif dati[fine - 1:fine] in (b"\n", b"\r"):
                    fine -= 1
                termine = trovato + 9
            return _Flusso(valore, dati[inizio:fine]), termine
        return valore, lettore.pos

    def _carica_flusso_oggetti(self, posizione: int, flusso: _Flusso) -> None:
        try:
            dati = self.decodifica(flusso)
            quanti, primo = flusso.diz.get("N"), flusso.diz.get("First")
            if not isinstance(quanti, int) or not isinstance(primo, int) or quanti > 1_000_000:
                return
            lettore = _Lettore(dati[:primo], 0, operatori=True)
            coppie = []
            for _ in range(quanti):
                numero, scarto = lettore.oggetto(), lettore.oggetto()
                if not isinstance(numero, int) or not isinstance(scarto, int):
                    break
                coppie.append((numero, scarto))
        except (_PdfRotto, ValueError, OverflowError, RecursionError):
            return
        for numero, scarto in coppie:
            vecchio = self.oggetti.get(numero)
            if vecchio is not None and vecchio[0] > posizione:
                continue
            try:
                valore = _Lettore(dati, primo + scarto).oggetto()
            except (_PdfRotto, ValueError, OverflowError, RecursionError):
                continue
            self.oggetti[numero] = (posizione, valore)

    # -- accesso agli oggetti ---------------------------------------------------
    def risolvi(self, valore: Any) -> Any:
        for _ in range(32):
            if not isinstance(valore, _Rif):
                return valore
            voce = self.oggetti.get(valore.numero)
            valore = voce[1] if voce else None
        return None

    def decodifica(self, flusso: Any) -> bytes:
        if not isinstance(flusso, _Flusso):
            raise _PdfRotto("non è un flusso")
        chiave = id(flusso)
        if chiave in self._decodificati:
            return self._decodificati[chiave]
        filtri = self.risolvi(flusso.diz.get("Filter"))
        parametri = self.risolvi(flusso.diz.get("DecodeParms"))
        if not isinstance(filtri, list):
            filtri = [filtri] if filtri else []
            parametri = [parametri]
        elif not isinstance(parametri, list):
            parametri = [parametri] * len(filtri)
        dati = flusso.grezzi
        for i, filtro in enumerate(self.risolvi(f) for f in filtri):
            p = self.risolvi(parametri[i]) if i < len(parametri) else None
            if filtro in ("FlateDecode", "Fl"):
                dati = _predittore(_decomprimi(dati), p)
            elif filtro in ("LZWDecode", "LZW"):
                anticipo = p.get("EarlyChange", 1) if isinstance(p, dict) else 1
                dati = _predittore(_lzw(dati, 1 if anticipo != 0 else 0), p)
            elif filtro in ("ASCIIHexDecode", "AHx"):
                cifre = re.sub(rb"[^0-9A-Fa-f]", b"", dati.split(b">")[0])
                dati = bytes.fromhex((cifre + b"0" * (len(cifre) % 2)).decode("ascii"))
            elif filtro in ("ASCII85Decode", "A85"):
                pulito = re.sub(rb"\s", b"", dati)
                pulito = pulito[2:] if pulito.startswith(b"<~") else pulito
                pulito = pulito.split(b"~>")[0]
                try:
                    dati = base64.a85decode(pulito)
                except ValueError:
                    raise _PdfRotto("ASCII85 rovinato") from None
            elif filtro in ("RunLengthDecode", "RL"):
                uscita, k = bytearray(), 0
                while k < len(dati) and dati[k] != 128:
                    n = dati[k]
                    if n < 128:
                        uscita += dati[k + 1:k + 2 + n]
                        k += n + 2
                    else:
                        uscita += dati[k + 1:k + 2] * (257 - n)
                        k += 2
                dati = bytes(uscita)
            elif filtro is None:
                continue
            else:
                raise _PdfRotto(f"filtro {filtro} non gestito")
        self._decodificati[chiave] = dati
        return dati

    # -- pagine -----------------------------------------------------------------
    def pagine(self) -> list[tuple[int | None, dict, dict]]:
        """Le pagine in ordine: (numero dell'oggetto, dizionario, valori ereditati)."""
        if hasattr(self, "_pagine"):
            return self._pagine
        risultato: list[tuple[int | None, dict, dict]] = []
        visti: set[int] = set()

        def visita(rif: Any, ereditati: dict, profondita: int) -> None:
            if profondita > 64 or len(risultato) > 200_000:
                return
            numero = rif.numero if isinstance(rif, _Rif) else None
            if numero is not None:
                if numero in visti:
                    return
                visti.add(numero)
            nodo = self.risolvi(rif)
            if not isinstance(nodo, dict):
                return
            ereditati = dict(ereditati)
            for chiave in ("Resources", "MediaBox", "CropBox", "Rotate"):
                if chiave in nodo:
                    ereditati[chiave] = nodo[chiave]
            figli = self.risolvi(nodo.get("Kids"))
            if nodo.get("Type") == "Pages" or (isinstance(figli, list) and nodo.get("Type") != "Page"):
                for figlio in figli if isinstance(figli, list) else []:
                    visita(figlio, ereditati, profondita + 1)
            else:
                risultato.append((numero, nodo, ereditati))

        radice = self.risolvi(self.trailer.get("Root"))
        if isinstance(radice, dict):
            visita(radice.get("Pages"), {}, 0)
        if not risultato:
            for numero, (_, v) in sorted(self.oggetti.items(), key=lambda o: o[1][0]):
                if isinstance(v, dict) and v.get("Type") == "Page":
                    risultato.append((numero, v, {}))
        self._pagine = risultato
        return risultato

    def controlla_non_protetto(self) -> None:
        if self.protetto:
            raise ErroreValore(f"Il PDF `{self.percorso}` è protetto (cifrato): non posso leggerlo né modificarlo.",
                               suggerimento="Aprilo con un lettore di PDF e salvane una copia senza protezione.")

    def testo_info(self, valore: Any) -> str | None:
        valore = self.risolvi(valore)
        if not isinstance(valore, bytes):
            return None if valore is None else str(valore)
        return _testo_pdf(valore)


def _testo_pdf(valore: bytes) -> str:
    if valore[:2] == b"\xfe\xff":
        return valore[2:].decode("utf-16-be", "replace")
    if valore[:3] == b"\xef\xbb\xbf":
        return valore[3:].decode("utf-8", "replace")
    return valore.decode("latin-1")


def _data_pdf(testo: str | None) -> Any:
    m = re.match(r"(?:D:)?(\d{4})(\d{2})?(\d{2})?(\d{2})?(\d{2})?(\d{2})?", testo or "")
    if not m:
        return testo
    parti = [int(g) if g else d for g, d in zip(m.groups(), (1, 1, 1, 0, 0, 0))]
    try:
        return DataDante(datetime.datetime(*parti))
    except ValueError:
        return testo


def _apri_pdf(percorso: Any, nome: str) -> _Pdf:
    try:
        return _Pdf(percorso, nome)
    except RecursionError:
        raise ErroreValore(f"Il PDF `{percorso}` è danneggiato o troppo complicato da leggere.") from None


# -- estrazione del testo -------------------------------------------------------

_NOMI_GLIFI = {
    "space": " ", "exclam": "!", "quotedbl": '"', "numbersign": "#", "dollar": "$", "percent": "%",
    "ampersand": "&", "quotesingle": "'", "quoteright": "’", "quoteleft": "‘", "parenleft": "(",
    "parenright": ")", "asterisk": "*", "plus": "+", "comma": ",", "hyphen": "-", "minus": "-", "period": ".",
    "slash": "/", "colon": ":", "semicolon": ";", "less": "<", "equal": "=", "greater": ">", "question": "?",
    "at": "@", "bracketleft": "[", "backslash": "\\", "bracketright": "]", "asciicircum": "^",
    "underscore": "_", "grave": "`", "braceleft": "{", "bar": "|", "braceright": "}", "asciitilde": "~",
    "quotedblleft": "“", "quotedblright": "”", "quotesinglbase": "‚", "quotedblbase": "„",
    "endash": "–", "emdash": "—", "bullet": "•", "ellipsis": "…", "Euro": "€",
    "fi": "fi", "fl": "fl", "ff": "ff", "ffi": "ffi", "ffl": "ffl", "germandbls": "ß", "ae": "æ",
    "AE": "Æ", "oe": "œ", "OE": "Œ", "oslash": "ø", "Oslash": "Ø", "degree": "°",
    "copyright": "©", "registered": "®", "trademark": "™", "guillemotleft": "«",
    "guillemotright": "»", "periodcentered": "·", "multiply": "×", "divide": "÷",
    "section": "§", "paragraph": "¶", "dagger": "†", "sterling": "£", "yen": "¥",
    "cent": "¢", "exclamdown": "¡", "questiondown": "¿", "nbspace": " ", "dotlessi": "ı",
    "zero": "0", "one": "1", "two": "2", "three": "3", "four": "4", "five": "5", "six": "6", "seven": "7",
    "eight": "8", "nine": "9", "onehalf": "½", "onequarter": "¼", "threequarters": "¾",
    "mu": "µ", "plusminus": "±", "ordfeminine": "ª", "ordmasculine": "º",
}
_ACCENTI = {"acute": "ACUTE", "grave": "GRAVE", "circumflex": "CIRCUMFLEX", "dieresis": "DIAERESIS",
            "tilde": "TILDE", "cedilla": "CEDILLA", "ring": "RING ABOVE", "caron": "CARON"}


def _glifo(nome: str) -> str:
    if nome in _NOMI_GLIFI:
        return _NOMI_GLIFI[nome]
    if len(nome) == 1:
        return nome
    m = re.fullmatch(r"uni([0-9A-Fa-f]{4})+|u([0-9A-Fa-f]{4,6})", nome)
    if m:
        cifre = nome[3:] if nome.startswith("uni") else nome[1:]
        passo = 4 if nome.startswith("uni") else len(cifre)
        try:
            return "".join(chr(int(cifre[i:i + passo], 16)) for i in range(0, len(cifre), passo))
        except ValueError:
            return ""
    base = nome.split(".")[0].split("_")[0]
    if base != nome:
        return _glifo(base)
    for suffisso, accento in _ACCENTI.items():
        if nome.endswith(suffisso) and len(nome) == len(suffisso) + 1:
            lettera = nome[0]
            caso = "CAPITAL" if lettera.isupper() else "SMALL"
            try:
                return unicodedata.lookup(f"LATIN {caso} LETTER {lettera.upper()} WITH {accento}")
            except KeyError:
                return lettera
    return ""


class _Carattere:
    """Come trasformare i codici di un carattere del PDF in testo, e quanto è larga ogni lettera."""

    def __init__(self, pdf: _Pdf, diz: Any) -> None:
        diz = pdf.risolvi(diz)
        self.diz = diz if isinstance(diz, dict) else {}
        self.due_byte = self.diz.get("Subtype") == "Type0"
        self.mappa: dict[int, str] = {}
        self.lunghezze: set[int] = set()
        self.larghezze: dict[int, float] = {}
        self.predefinita = 500.0
        self.codifica: dict[int, str] = {}
        base = "cp1252"
        codifica = pdf.risolvi(self.diz.get("Encoding"))
        if isinstance(codifica, dict):
            base = {"MacRomanEncoding": "mac_roman"}.get(pdf.risolvi(codifica.get("BaseEncoding")), "cp1252")
            differenze = pdf.risolvi(codifica.get("Differences"))
            codice = 0
            for voce in differenze if isinstance(differenze, list) else []:
                if isinstance(voce, int):
                    codice = voce
                elif isinstance(voce, _Nome):
                    self.codifica[codice] = _glifo(str(voce))
                    codice += 1
        elif codifica == "MacRomanEncoding":
            base = "mac_roman"
        self.base = base
        try:
            self._leggi_mappa(pdf, pdf.risolvi(self.diz.get("ToUnicode")))
        except (_PdfRotto, ValueError, OverflowError, RecursionError):
            pass
        try:
            self._leggi_larghezze(pdf)
        except (ValueError, TypeError, OverflowError):
            pass

    def _leggi_mappa(self, pdf: _Pdf, flusso: Any) -> None:
        if not isinstance(flusso, _Flusso):
            return
        testo = pdf.decodifica(flusso)
        for blocco in re.findall(rb"begincodespacerange(.*?)endcodespacerange", testo, re.S):
            for a in re.findall(rb"<([0-9A-Fa-f]+)>\s*<[0-9A-Fa-f]+>", blocco):
                self.lunghezze.add(len(a) // 2)

        def unicode(esadecimale: bytes) -> str:
            dati = bytes.fromhex(esadecimale.decode("ascii") + ("0" if len(esadecimale) % 2 else ""))
            return dati.decode("utf-16-be", "replace")

        for blocco in re.findall(rb"beginbfchar(.*?)endbfchar", testo, re.S):
            for sorgente, destinazione in re.findall(rb"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]*)>", blocco):
                self.mappa[int(sorgente, 16)] = unicode(destinazione)
                self.lunghezze.add(len(sorgente) // 2)
        for blocco in re.findall(rb"beginbfrange(.*?)endbfrange", testo, re.S):
            for a, b, resto in re.findall(rb"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*(<[0-9A-Fa-f]*>|\[[^\]]*\])", blocco):
                inizio, fine = int(a, 16), int(b, 16)
                self.lunghezze.add(len(a) // 2)
                if fine - inizio > 65536 or fine < inizio:
                    continue
                if resto.startswith(b"["):
                    for k, voce in enumerate(re.findall(rb"<([0-9A-Fa-f]*)>", resto)):
                        self.mappa[inizio + k] = unicode(voce)
                else:
                    primo = unicode(resto[1:-1])
                    if not primo:
                        continue
                    for k in range(fine - inizio + 1):
                        self.mappa[inizio + k] = primo[:-1] + chr(min(0x10FFFF, ord(primo[-1]) + k))
        if self.lunghezze == {2}:
            self.due_byte = True

    def _leggi_larghezze(self, pdf: _Pdf) -> None:
        if self.due_byte:
            discendenti = pdf.risolvi(self.diz.get("DescendantFonts"))
            figlio = pdf.risolvi(discendenti[0]) if isinstance(discendenti, list) and discendenti else None
            if not isinstance(figlio, dict):
                return
            dw = pdf.risolvi(figlio.get("DW"))
            self.predefinita = float(dw) if isinstance(dw, (int, float)) else 1000.0
            w = pdf.risolvi(figlio.get("W"))
            k = 0
            while isinstance(w, list) and k < len(w) and len(self.larghezze) < 200_000:
                primo = pdf.risolvi(w[k])
                seguente = pdf.risolvi(w[k + 1]) if k + 1 < len(w) else None
                if isinstance(seguente, list):
                    for j, v in enumerate(seguente):
                        v = pdf.risolvi(v)
                        if isinstance(v, (int, float)):
                            self.larghezze[primo + j] = float(v)
                    k += 2
                elif k + 2 < len(w):
                    ultimo, v = pdf.risolvi(w[k + 1]), pdf.risolvi(w[k + 2])
                    if isinstance(primo, int) and isinstance(ultimo, int) and isinstance(v, (int, float)) \
                            and 0 <= ultimo - primo < 65536:
                        for c in range(primo, ultimo + 1):
                            self.larghezze[c] = float(v)
                    k += 3
                else:
                    break
            return
        primo = pdf.risolvi(self.diz.get("FirstChar"))
        larghezze = pdf.risolvi(self.diz.get("Widths"))
        if isinstance(primo, int) and isinstance(larghezze, list):
            for j, v in enumerate(larghezze[:65536]):
                v = pdf.risolvi(v)
                if isinstance(v, (int, float)):
                    self.larghezze[primo + j] = float(v)
        elif str(self.diz.get("BaseFont", "")).startswith("Helvetica"):
            tabella = _LARGHEZZE_GRASSETTO if "Bold" in str(self.diz.get("BaseFont")) else _LARGHEZZE_NORMALE
            self.larghezze = {32 + i: float(v) for i, v in enumerate(tabella)}

    def codici(self, dati: bytes) -> list[tuple[str, float, bool]]:
        """(testo, larghezza in millesimi, è uno spazio) per ogni codice della stringa."""
        risultato = []
        passo = 2 if self.due_byte else 1
        if self.lunghezze and self.lunghezze != {1, 2} and len(self.lunghezze) == 1:
            passo = next(iter(self.lunghezze))
        for i in range(0, len(dati) - passo + 1, passo):
            codice = int.from_bytes(dati[i:i + passo], "big")
            if codice in self.mappa:
                testo = self.mappa[codice]
            elif codice in self.codifica:
                testo = self.codifica[codice]
            elif passo == 1:
                testo = bytes([codice]).decode(self.base, "replace").replace("\ufffd", "")
            else:
                testo = ""
            larghezza = self.larghezze.get(codice, self.predefinita)
            risultato.append((testo, larghezza, passo == 1 and codice == 32))
        return risultato


class _Estrattore:
    """Legge i comandi di disegno di una pagina e ricostruisce il testo, riga per riga."""

    def __init__(self, pdf: _Pdf) -> None:
        self.pdf = pdf
        self.caratteri: dict[int, _Carattere] = {}
        self.pezzi: list[str] = []
        self.ultimo: tuple[float, float, float] | None = None   # x di fine, y, corpo

    def carattere(self, diz: Any) -> _Carattere:
        chiave = diz.numero if isinstance(diz, _Rif) else id(diz)
        if chiave not in self.caratteri:
            self.caratteri[chiave] = _Carattere(self.pdf, diz)
        return self.caratteri[chiave]

    def pagina(self, diz: dict, ereditati: dict) -> str:
        self.pezzi, self.ultimo = [], None
        risorse = self.pdf.risolvi(diz.get("Resources", ereditati.get("Resources")))
        contenuti = self.pdf.risolvi(diz.get("Contents"))
        flussi = contenuti if isinstance(contenuti, list) else [contenuti]
        dati = []
        for f in flussi:
            f = self.pdf.risolvi(f)
            if isinstance(f, _Flusso):
                try:
                    dati.append(self.pdf.decodifica(f))
                except _PdfRotto:
                    continue
        self.esegui(b"\n".join(dati), risorse, (1, 0, 0, 1, 0, 0), 0)
        return "".join(self.pezzi)

    def esegui(self, dati: bytes, risorse: Any, ctm: tuple, profondita: int) -> None:
        if profondita > 6:
            return
        risorse = self.pdf.risolvi(risorse)
        risorse = risorse if isinstance(risorse, dict) else {}
        font_risorse = self.pdf.risolvi(risorse.get("Font"))
        font_risorse = font_risorse if isinstance(font_risorse, dict) else {}
        xobject = self.pdf.risolvi(risorse.get("XObject"))
        xobject = xobject if isinstance(xobject, dict) else {}
        operandi: list[Any] = []
        pila: list[tuple] = []
        carattere = None
        corpo, spaziatura_c, spaziatura_p, scala, interlinea = 1.0, 0.0, 0.0, 1.0, 0.0
        tm = tlm = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
        gettoni = _gettoni_contenuto(dati)
        for v in gettoni:
            if type(v) is not _Operatore:
                operandi.append(v)
                if len(operandi) > 1000:
                    operandi = operandi[-100:]
                continue
            op = str(v)
            if op not in _OPERATORI_TESTO:
                operandi = []
                continue
            numeri = [float(x) for x in operandi if isinstance(x, (int, float)) and not isinstance(x, bool)]
            try:
                if op == "BT":
                    tm = tlm = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
                elif op == "q":
                    if len(pila) < 64:
                        pila.append(ctm)
                elif op == "Q":
                    if pila:
                        ctm = pila.pop()
                elif op == "cm" and len(numeri) >= 6:
                    ctm = _moltiplica(tuple(numeri[-6:]), ctm)
                elif op == "Tf" and operandi:
                    nome = operandi[0]
                    carattere = self.carattere(font_risorse.get(str(nome))) if isinstance(nome, _Nome) else None
                    if numeri:
                        corpo = numeri[-1]
                elif op == "Tc" and numeri:
                    spaziatura_c = numeri[-1]
                elif op == "Tw" and numeri:
                    spaziatura_p = numeri[-1]
                elif op == "Tz" and numeri:
                    scala = numeri[-1] / 100
                elif op == "TL" and numeri:
                    interlinea = numeri[-1]
                elif op in ("Td", "TD") and len(numeri) >= 2:
                    tx, ty = numeri[-2], numeri[-1]
                    if op == "TD":
                        interlinea = -ty
                    tlm = _moltiplica((1, 0, 0, 1, tx, ty), tlm)
                    tm = tlm
                elif op == "Tm" and len(numeri) >= 6:
                    tm = tlm = tuple(numeri[-6:])
                elif op == "T*":
                    tlm = _moltiplica((1, 0, 0, 1, 0, -interlinea), tlm)
                    tm = tlm
                elif op in ("Tj", "'", '"', "TJ"):
                    if op in ("'", '"'):
                        if op == '"' and len(numeri) >= 2:
                            spaziatura_p, spaziatura_c = numeri[0], numeri[1]
                        tlm = _moltiplica((1, 0, 0, 1, 0, -interlinea), tlm)
                        tm = tlm
                    elementi = operandi[-1] if op == "TJ" and operandi and isinstance(operandi[-1], list) \
                        else [x for x in operandi[-1:] if isinstance(x, bytes)]
                    for elemento in elementi:
                        if isinstance(elemento, bytes) and carattere is not None:
                            tm = self.mostra(elemento, carattere, corpo, spaziatura_c, spaziatura_p, scala, tm, ctm)
                        elif isinstance(elemento, (int, float)) and not isinstance(elemento, bool):
                            tm = _moltiplica((1, 0, 0, 1, -elemento / 1000 * corpo * scala, 0), tm)
                elif op == "Do" and operandi and isinstance(operandi[-1], _Nome):
                    forma = self.pdf.risolvi(xobject.get(str(operandi[-1])))
                    if isinstance(forma, _Flusso) and forma.diz.get("Subtype") == "Form":
                        matrice = self.pdf.risolvi(forma.diz.get("Matrix"))
                        m = tuple(float(x) for x in matrice) if isinstance(matrice, list) and len(matrice) == 6 \
                            and all(isinstance(x, (int, float)) for x in matrice) else (1, 0, 0, 1, 0, 0)
                        try:
                            contenuto = self.pdf.decodifica(forma)
                        except _PdfRotto:
                            contenuto = b""
                        self.esegui(contenuto, forma.diz.get("Resources", risorse), _moltiplica(m, ctm),
                                    profondita + 1)
            except (TypeError, ValueError, OverflowError, ZeroDivisionError, IndexError):
                pass
            operandi = []

    def mostra(self, dati: bytes, carattere: _Carattere, corpo: float, spaziatura_c: float, spaziatura_p: float,
               scala: float, tm: tuple, ctm: tuple) -> tuple:
        m = _moltiplica(tm, ctm)
        dimensione = abs(corpo * math.hypot(m[2], m[3])) or abs(corpo) or 1.0
        ax, ay, x0, y0 = m[0], m[1], m[4], m[5]
        avanzato = 0.0
        pezzi = self.pezzi
        for testo, larghezza, spazio in carattere.codici(dati):
            x, y = x0 + avanzato * ax, y0 + avanzato * ay
            if self.ultimo is not None:
                ux, uy, ucorpo = self.ultimo
                soglia = max(dimensione, ucorpo)
                if abs(y - uy) > soglia * 0.5:
                    pezzi.append("\n\n" if abs(y - uy) > soglia * 2.2 and uy > y else "\n")
                elif x - ux > soglia * 0.15 and pezzi and not pezzi[-1].endswith((" ", "\n")) \
                        and not testo.startswith(" "):
                    pezzi.append(" ")
                elif x < ux - soglia * 4 and pezzi and not pezzi[-1].endswith("\n"):
                    pezzi.append("\n")
            if testo:
                pezzi.append(testo)
            avanzato += (larghezza / 1000 * corpo + spaziatura_c + (spaziatura_p if spazio else 0)) * scala
            self.ultimo = (x0 + avanzato * ax, y, dimensione)
        return (tm[0], tm[1], tm[2], tm[3], tm[4] + avanzato * tm[0], tm[5] + avanzato * tm[1])


_OPERATORI_TESTO = frozenset(("BT", "q", "Q", "cm", "Tf", "Tc", "Tw", "Tz", "TL", "Td", "TD", "Tm", "T*",
                              "Tj", "'", '"', "TJ", "Do"))


def _moltiplica(a: tuple, b: tuple) -> tuple:
    return (a[0] * b[0] + a[1] * b[2], a[0] * b[1] + a[1] * b[3],
            a[2] * b[0] + a[3] * b[2], a[2] * b[1] + a[3] * b[3],
            a[4] * b[0] + a[5] * b[2] + b[4], a[4] * b[1] + a[5] * b[3] + b[5])


def _punto(m: tuple) -> tuple[float, float]:
    return m[4], m[5]


def _pulisci_testo_estratto(testo: str) -> str:
    testo = testo.replace(" ", " ").replace("\x00", "")
    righe = [re.sub(r"[ \t]+", " ", r).strip() for r in testo.split("\n")]
    return re.sub(r"\n{3,}", "\n\n", "\n".join(righe)).strip()


def _testo_con_pypdf(percorso: str, indici: list[int]) -> str | None:
    import logging
    import warnings
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            import pypdf  # facoltativo
    except Exception:  # noqa: BLE001 - pacchetto assente o rotto: si fa senza
        return None
    registro_pypdf = logging.getLogger("pypdf")
    livello = registro_pypdf.level
    registro_pypdf.setLevel(logging.CRITICAL + 1)      # niente avvisi di pypdf sullo schermo
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            lettore = pypdf.PdfReader(percorso)
            return "\n\n".join(_pulisci_testo_estratto(lettore.pages[i].extract_text() or "") for i in indici)
    except Exception:  # noqa: BLE001 - qualunque problema di pypdf: si tiene il risultato interno
        return None
    finally:
        registro_pypdf.setLevel(livello)


# -- scrittura di pagine copiate da altri PDF ---------------------------------------

def _serializza_pdf(v: Any) -> bytes:
    if v is None:
        return b"null"
    if v is True:
        return b"true"
    if v is False:
        return b"false"
    if isinstance(v, _Rif):
        return f"{v[0]} 0 R".encode("ascii")
    if isinstance(v, _Nome):
        return b"/" + re.sub(rb"[^!-~]|[()<>\[\]{}/%#]", lambda m: b"#%02X" % m.group(0)[0],
                             str(v).encode("latin-1", "replace"))
    if isinstance(v, int):
        return str(v).encode("ascii")
    if isinstance(v, float):
        return (_numero_pdf(v) if math.isfinite(v) else "0").encode("ascii")
    if isinstance(v, bytes):
        return b"<" + v.hex().encode("ascii") + b">"
    if isinstance(v, str):
        return _stringa_pdf(v.encode("latin-1", "replace"))
    if isinstance(v, list):
        return b"[" + b" ".join(_serializza_pdf(x) for x in v) + b"]"
    if isinstance(v, dict):
        return b"<<" + b"".join(_serializza_pdf(_Nome(k)) + b" " + _serializza_pdf(x) + b"\n" for k, x in v.items()) \
            + b">>"
    if isinstance(v, _Flusso):
        diz = {k: x for k, x in v.diz.items() if k != "Length"}
        return _flusso_pdf(_serializza_pdf(diz)[2:-2], v.grezzi)
    return b"null"


def _componi_pagine(scelte: list[tuple[_Pdf, int | None, dict, dict, int]]) -> bytes:
    """Un PDF nuovo con le pagine scelte: (pdf, numero, dizionario, ereditati, rotazione da aggiungere)."""
    oggetti: list[Any] = [None, None]          # 1 catalogo, 2 albero delle pagine
    nuovi: dict[tuple[int, int], int] = {}
    pagine_nuove: dict[tuple[int, int], int] = {}
    da_copiare: list[tuple[_Pdf, int, int]] = []
    tutte_le_pagine: dict[int, set[int]] = {}

    for pdf, numero, _, _, _ in scelte:
        tutte_le_pagine.setdefault(id(pdf), {n for n, _, _ in pdf.pagine() if n is not None})
    numeri_pagine = []
    for pdf, numero, _, _, _ in scelte:
        oggetti.append(None)
        numeri_pagine.append(len(oggetti))
        if numero is not None:
            pagine_nuove.setdefault((id(pdf), numero), len(oggetti))

    def copia(v: Any, pdf: _Pdf, profondita: int = 0) -> Any:
        if profondita > _PROFONDITA_PDF:
            return None
        if isinstance(v, _Rif):
            chiave = (id(pdf), v.numero)
            if v.numero in tutte_le_pagine[id(pdf)]:
                return _Rif((pagine_nuove[chiave], 0)) if chiave in pagine_nuove else None
            if chiave not in nuovi:
                if v.numero not in pdf.oggetti:
                    return None
                bersaglio = pdf.oggetti[v.numero][1]
                if isinstance(bersaglio, dict) and bersaglio.get("Type") in ("Pages", "Page"):
                    return None
                oggetti.append(None)
                nuovi[chiave] = len(oggetti)
                da_copiare.append((pdf, v.numero, len(oggetti)))
            return _Rif((nuovi[chiave], 0))
        if isinstance(v, dict):
            togli = "Parent" if v.get("Type") in ("Page", "Pages") else None
            return {k: copia(x, pdf, profondita + 1) for k, x in v.items() if k != togli}
        if isinstance(v, list):
            return [copia(x, pdf, profondita + 1) for x in v]
        if isinstance(v, _Flusso):
            return _Flusso({k: copia(x, pdf, profondita + 1) for k, x in v.diz.items() if k != "Length"}, v.grezzi)
        return v

    for posto, (pdf, numero, diz, ereditati, rotazione) in zip(numeri_pagine, scelte):
        pagina = {k: v for k, v in diz.items() if k not in ("Parent", "B", "StructParents")}
        for chiave in ("Resources", "MediaBox", "CropBox", "Rotate"):
            if chiave not in pagina and chiave in ereditati:
                pagina[chiave] = ereditati[chiave]
        if "MediaBox" not in pagina:
            pagina["MediaBox"] = [0, 0, 595.276, 841.89]
        if "Resources" not in pagina:
            pagina["Resources"] = {}
        vecchia = pdf.risolvi(pagina.get("Rotate"))
        vecchia = vecchia if isinstance(vecchia, int) else 0
        if rotazione or vecchia:
            pagina["Rotate"] = (vecchia + rotazione) % 360
        pagina = copia(pagina, pdf)
        pagina["Type"] = _Nome("Page")
        pagina["Parent"] = _Rif((2, 0))
        oggetti[posto - 1] = pagina
        while da_copiare:
            sorgente, vecchio, nuovo = da_copiare.pop()
            oggetti[nuovo - 1] = copia(sorgente.oggetti[vecchio][1], sorgente)
    oggetti[0] = {"Type": _Nome("Catalog"), "Pages": _Rif((2, 0))}
    oggetti[1] = {"Type": _Nome("Pages"), "Kids": [_Rif((n, 0)) for n in numeri_pagine], "Count": len(numeri_pagine)}
    oggetti.append({"Producer": b"Leo"})
    return _file_pdf([_serializza_pdf(o) for o in oggetti], len(oggetti))


def _indici_pagine(pagine: Any, totale: int, nome: str, parametro: str = "pagine") -> list[int]:
    """Le pagine chieste (numerate da 1) come indici da 0: un numero, una lista o un testo "1-3, 5"."""
    if pagine is None:
        return list(range(totale))
    if isinstance(pagine, bool):
        raise ErroreTipo(f"L'argomento `{parametro}` di `{nome}` deve essere un numero, una lista di numeri "
                         f"o un testo come \"1-3, 5\", non {articolo(pagine)}.")
    if isinstance(pagine, int):
        voci: list[Any] = [pagine]
    elif isinstance(pagine, list):
        voci = pagine
    elif isinstance(pagine, str):
        voci = []
        for pezzo in pagine.replace(";", ",").split(","):
            pezzo = pezzo.strip()
            if not pezzo:
                continue
            m = re.fullmatch(r"(\d+)?\s*-\s*(\d+)?", pezzo)
            if m and (m.group(1) or m.group(2)):
                da = int(m.group(1)) if m.group(1) else 1
                a = int(m.group(2)) if m.group(2) else totale
                if a - da > 100_000:
                    raise ErroreValore(f"L'intervallo di pagine {mostra(pezzo)} è troppo grande.")
                voci.extend(range(da, a + 1) if da <= a else range(da, a - 1, -1))
            elif pezzo.isdigit():
                voci.append(int(pezzo))
            elif pezzo.lower() == "ultima":
                voci.append(totale)
            else:
                raise ErroreValore(f"Non capisco le pagine {mostra(pagine)}.",
                                   suggerimento="Scrivile come \"1-3, 5, 8\" (da 1).")
    else:
        raise ErroreTipo(f"L'argomento `{parametro}` di `{nome}` deve essere un numero, una lista di numeri "
                         f"o un testo come \"1-3, 5\", non {articolo(pagine)}.")
    indici = []
    for v in voci:
        if isinstance(v, bool) or not isinstance(v, int):
            raise ErroreTipo(f"Le pagine di `{nome}` devono essere numeri interi, non {articolo(v)}.")
        indice = v - 1 if v > 0 else totale + v
        if not 0 <= indice < totale:
            raise ErroreValore(f"La pagina {mostra(v)} non esiste: il PDF ha {totale} "
                               f"{'pagina' if totale == 1 else 'pagine'}.",
                               suggerimento="Le pagine si contano da 1; con i numeri negativi si parte dalla fine "
                                            "(-1 è l'ultima).")
        indici.append(indice)
    if not indici:
        raise ErroreValore(f"Non hai scelto nessuna pagina per `{nome}`.")
    return indici


# ===========================================================================
# Funzioni della libreria: Excel
# ===========================================================================

@funzione_libreria("leggi_excel")
def leggi_excel(percorso, foglio=None, intestazione=True):
    """leggi_excel(percorso, foglio = nulla, intestazione = vero): legge un foglio di un file Excel (.xlsx) o LibreOffice (.ods).

    Con l'intestazione ogni riga diventa un dizionario: le chiavi sono i nomi scritti nella prima riga.
    Con `intestazione = falso` ogni riga è una lista. Senza `foglio` legge il primo; si può dare il nome
    ("Voti") o il numero (da 1). Numeri, date e valori logici restano tali; le righe vuote si saltano.
    Esempio: `per ogni r in leggi_excel("voti.xlsx") fai stampa(r["nome"], r["voto"]) fine`.
    """
    richiedi_logico(intestazione, "leggi_excel", "intestazione")
    cartella = _Cartella(percorso, "leggi_excel")
    celle = cartella.celle(foglio)
    riquadro = _riquadro(celle)
    if riquadro is None:
        return []
    griglia = _griglia(celle, *riquadro, "leggi_excel")
    if not intestazione:
        return griglia
    nomi = _nomi_intestazione(griglia[0])
    return [dict(zip(nomi, riga)) for riga in griglia[1:] if any(v is not None for v in riga)]


@funzione_libreria("scrivi_excel")
def scrivi_excel(percorso, righe, foglio="Foglio1", larghezze=None):
    """scrivi_excel(percorso, righe, foglio = "Foglio1", larghezze = nulla): scrive una tabella in un file Excel (.xlsx) o LibreOffice (.ods).

    `righe` è una lista di dizionari (le chiavi diventano l'intestazione, in grassetto e bloccata in alto)
    o una lista di liste. Numeri, date (`data(...)`), `soldi` e `vero`/`falso` restano tali; un testo che
    inizia con "=" è una formula, anche con i nomi italiani: "=SOMMA(B2:B4)"; delle formule semplici
    (+ - * /, SOMMA, MEDIA, MIN, MAX, CONTA, ARROTONDA) Leo salva già il risultato.
    Le colonne si allargano da sole; con `larghezze` le scegli tu, in caratteri: una lista (`[20, 8]`)
    o un dizionario (`{"nome": 25, "C": 12}`).
    Senza estensione aggiunge ".xlsx". Restituisce il percorso del file scritto.
    Esempio: `scrivi_excel("voti.xlsx", [{"nome": "Ada", "voto": 9}, {"nome": "Bruno", "voto": 7}])`.
    """
    percorso = _percorso_da_scrivere(percorso, "scrivi_excel", (".xlsx", ".ods"))
    richiedi_testo(foglio, "scrivi_excel", "foglio")
    return _scrivi_cartella(percorso, [(foglio, righe)], "scrivi_excel", larghezze)


@funzione_libreria("scrivi_fogli_excel")
def scrivi_fogli_excel(percorso, fogli):
    """scrivi_fogli_excel(percorso, fogli): scrive un file Excel (.xlsx o .ods) con più fogli.

    `fogli` è un dizionario: nome del foglio -> righe (come in `scrivi_excel`). I fogli restano nell'ordine dato.
    Esempio: `scrivi_fogli_excel("scuola.xlsx", {"3A": voti_3a, "3B": voti_3b})`.
    """
    percorso = _percorso_da_scrivere(percorso, "scrivi_fogli_excel", (".xlsx", ".ods"))
    if not isinstance(fogli, dict):
        raise ErroreTipo(f"L'argomento `fogli` di `scrivi_fogli_excel` deve essere un dizionario "
                         f"(nome del foglio -> righe), non {articolo(fogli)}.",
                         suggerimento="Per esempio `{\"Voti\": righe, \"Assenze\": altre_righe}`.")
    if not fogli:
        raise ErroreValore("Il dizionario dei fogli di `scrivi_fogli_excel` è vuoto: serve almeno un foglio.")
    if len(fogli) > 255:
        raise ErroreValore("Troppi fogli per `scrivi_fogli_excel`: al massimo 255.")
    return _scrivi_cartella(percorso, list(fogli.items()), "scrivi_fogli_excel")


@funzione_libreria("elenca_fogli_excel")
def elenca_fogli_excel(percorso):
    """elenca_fogli_excel(percorso): i nomi dei fogli di un file Excel (.xlsx) o .ods, in ordine.

    Esempio: `per ogni f in elenca_fogli_excel("scuola.xlsx") fai stampa(f) fine`.
    """
    return list(_Cartella(percorso, "elenca_fogli_excel").nomi)


@funzione_libreria("leggi_cella_excel")
def leggi_cella_excel(percorso, cella, foglio=None):
    """leggi_cella_excel(percorso, cella, foglio = nulla): il valore di una cella ("B3"), o `nulla` se è vuota.

    Il foglio si può scrivere anche nella cella: "Voti!B3". Delle formule si legge l'ultimo risultato
    salvato da Excel.
    Esempio: `stampa(leggi_cella_excel("conti.xlsx", "B10"))`.
    """
    richiedi_testo(cella, "leggi_cella_excel", "cella")
    nome_foglio, riferimento = _dividi_foglio(cella)
    riga, colonna = _cella(riferimento, "leggi_cella_excel")
    cartella = _Cartella(percorso, "leggi_cella_excel")
    return cartella.celle(nome_foglio if nome_foglio is not None else foglio).get((riga, colonna))


@funzione_libreria("leggi_intervallo_excel")
def leggi_intervallo_excel(percorso, intervallo, foglio=None):
    """leggi_intervallo_excel(percorso, intervallo, foglio = nulla): le celle di un rettangolo ("A1:C5") come lista di righe.

    Le celle vuote sono `nulla`. Il foglio si può scrivere anche nell'intervallo: "Voti!A1:C5".
    Esempio: `variabile tabella = leggi_intervallo_excel("voti.xlsx", "A2:B30")`.
    """
    richiedi_testo(intervallo, "leggi_intervallo_excel", "intervallo")
    nome_foglio, riferimento = _dividi_foglio(intervallo)
    inizio, _, fine = riferimento.partition(":")
    r1, c1 = _cella(inizio, "leggi_intervallo_excel")
    r2, c2 = _cella(fine, "leggi_intervallo_excel") if fine else (r1, c1)
    r1, r2 = min(r1, r2), max(r1, r2)
    c1, c2 = min(c1, c2), max(c1, c2)
    if (r2 - r1 + 1) * (c2 - c1 + 1) > MASSIME_CELLE:
        raise ErroreValore(f"L'intervallo {mostra(intervallo)} è troppo grande (più di {MASSIME_CELLE} celle).")
    cartella = _Cartella(percorso, "leggi_intervallo_excel")
    celle = cartella.celle(nome_foglio if nome_foglio is not None else foglio)
    return _griglia(celle, r1, c1, r2, c2, "leggi_intervallo_excel")


@funzione_libreria("nome_colonna_excel")
def nome_colonna_excel(numero):
    """nome_colonna_excel(numero): le lettere di una colonna di Excel dal suo numero (1 -> "A", 28 -> "AB").

    Esempio: `stampa(nome_colonna_excel(3) + "5")` scrive "C5".
    """
    richiedi_intero(numero, "nome_colonna_excel", "numero")
    if not 1 <= numero <= MASSIME_COLONNE_EXCEL:
        raise ErroreValore(f"Le colonne di Excel vanno da 1 a {MASSIME_COLONNE_EXCEL}, non {mostra(numero)}.")
    return _lettere_colonna(numero)


@funzione_libreria("numero_colonna_excel")
def numero_colonna_excel(lettere):
    """numero_colonna_excel(lettere): il numero di una colonna di Excel dalle sue lettere ("A" -> 1, "AB" -> 28).

    Esempio: `stampa(numero_colonna_excel("D"))` scrive 4.
    """
    richiedi_testo(lettere, "numero_colonna_excel", "lettere")
    pulite = lettere.strip().lstrip("$")
    if not re.fullmatch(r"[A-Za-z]{1,3}", pulite) or _numero_colonna(pulite) > MASSIME_COLONNE_EXCEL:
        raise ErroreValore(f"{mostra(lettere)} non è una colonna di Excel.",
                           suggerimento="Le colonne si scrivono con le lettere, da \"A\" a \"XFD\".")
    return _numero_colonna(pulite)


# ===========================================================================
# Funzioni della libreria: Word
# ===========================================================================

@funzione_libreria("leggi_word")
def leggi_word(percorso):
    """leggi_word(percorso): tutto il testo di un documento Word (.docx) o LibreOffice (.odt).

    I paragrafi vanno a capo; le celle delle tabelle sono separate da una tabulazione.
    Esempio: `stampa(leggi_word("relazione.docx"))`.
    """
    righe = []
    for b in _leggi_blocchi_word(percorso, "leggi_word"):
        if b[0] == "p":
            righe.append(b[1])
        elif b[0] == "t":
            righe.extend("\t".join(c.replace("\n", " ") for c in r) for r in b[1])
    return "\n".join(righe)


@funzione_libreria("paragrafi_word")
def paragrafi_word(percorso):
    """paragrafi_word(percorso): la lista dei paragrafi (non vuoti) di un documento .docx o .odt, fuori dalle tabelle.

    Esempio: `variabile p = paragrafi_word("tema.docx")` e poi `stampa(lunghezza(p), "paragrafi")`.
    """
    return [b[1] for b in _leggi_blocchi_word(percorso, "paragrafi_word") if b[0] == "p" and b[1].strip()]


@funzione_libreria("tabelle_word")
def tabelle_word(percorso):
    """tabelle_word(percorso): le tabelle di un documento .docx o .odt; ogni tabella è una lista di righe di testi.

    Esempio: `per ogni riga in tabelle_word("orario.docx")[0] fai stampa(riga) fine`.
    """
    return [b[1] for b in _leggi_blocchi_word(percorso, "tabelle_word") if b[0] == "t"]


def _testo_da_scrivere(testo: Any, nome: str) -> str:
    if isinstance(testo, list):
        return "\n\n".join(_in_testo(t) for t in testo)
    return richiedi_testo(testo, nome, "testo")


def _titolo_opzionale(titolo: Any, nome: str) -> str:
    if titolo is None:
        return ""
    return richiedi_testo(titolo, nome, "titolo").strip()


@funzione_libreria("scrivi_word")
def scrivi_word(percorso, testo, titolo=None):
    """scrivi_word(percorso, testo, titolo = nulla): crea un documento Word (.docx) o LibreOffice (.odt) da un testo semplice.

    Nel testo: una riga vuota separa i paragrafi; `# Titolo`, `## Sottotitolo`; righe che iniziano con
    `- ` (punti) o `1. ` (numeri) formano un elenco; righe come `| Nome | Voto |` una tabella;
    `![](foto.jpg)` un'immagine; `---` una nuova pagina; `**grassetto**` e `*corsivo*`.
    Senza estensione aggiunge ".docx". Restituisce il percorso del file.
    Esempio: `scrivi_word("invito.docx", "# Festa!\\n\\nSabato alle **16**, porta un amico.")`.
    """
    percorso = _percorso_da_scrivere(percorso, "scrivi_word", (".docx", ".odt"))
    doc = _documento_da_testo(_testo_da_scrivere(testo, "scrivi_word"), "scrivi_word",
                              _titolo_opzionale(titolo, "scrivi_word"))
    return _salva_documento(doc, percorso)


def _sostituzioni(valore: Any, nome: str) -> dict[str, str]:
    if not isinstance(valore, dict):
        raise ErroreTipo(f"L'argomento `sostituzioni` di `{nome}` deve essere un dizionario "
                         f"(testo da cercare -> testo nuovo), non {articolo(valore)}.",
                         suggerimento="Per esempio `{\"<<nome>>\": \"Ada\", \"<<data>>\": \"5 ottobre\"}`.")
    risultato = {}
    for k, v in valore.items():
        if not isinstance(k, str) or not k:
            raise ErroreValore(f"In `{nome}` ogni testo da cercare deve essere un testo non vuoto, non {mostra(k)}.")
        risultato[k] = _in_testo(v)
    return risultato


@funzione_libreria("sostituisci_in_word")
def sostituisci_in_word(percorso, sostituzioni, uscita=None):
    """sostituisci_in_word(percorso, sostituzioni, uscita = nulla): sostituisce dei testi in un .docx, lasciando intatta la grafica.

    `sostituzioni` è un dizionario: testo da cercare -> testo nuovo. Cerca anche nelle intestazioni e nei
    piè di pagina. Scrive il risultato in `uscita` (senza `uscita` cambia il file stesso) e restituisce
    quante sostituzioni ha fatto.
    Esempio: `sostituisci_in_word("modello.docx", {"<<nome>>": "Ada"}, "lettera_ada.docx")`.
    """
    percorso = _percorso_da_leggere(percorso, "sostituisci_in_word", (".docx", ".docm"))
    cambi = _sostituzioni(sostituzioni, "sostituisci_in_word")
    destinazione = percorso if uscita is None else _percorso_da_scrivere(uscita, "sostituisci_in_word",
                                                                          (".docx", ".docm"))
    if _estensione(percorso) not in (".docx", ".docm"):
        raise ErroreValore(f"`sostituisci_in_word` lavora solo sui file .docx, non su `{percorso}`.")
    pacchetto = _Pacchetto(percorso, "sostituisci_in_word", "file Word .docx")
    if not cambi:
        dati, conta = _dati_pacchetto(pacchetto), 0
    else:
        regola = re.compile("|".join(re.escape(k) for k in sorted(cambi, key=len, reverse=True)))
        dati, conta = _sostituisci_docx(pacchetto, regola, lambda m: cambi[m.group(0)])
    _scrivi_byte(destinazione, dati)
    return conta


def _dati_pacchetto(pacchetto: _Pacchetto) -> bytes:
    return _leggi_byte(pacchetto.percorso, pacchetto.nome)


_RE_CAMPO = re.compile(r"<<\s*([^<>\n]+?)\s*>>|«\s*([^«»\n]+?)\s*»|\{\s*([^{}\n]+?)\s*\}")


def _normalizza_campo(nome: Any) -> str:
    """Il nome di un campo senza differenze di maiuscole, accenti, spazi e `_` ("Città" = "citta")."""
    testo = "".join(c for c in unicodedata.normalize("NFKD", _in_testo(nome)) if not unicodedata.combining(c))
    return re.sub(r"[\s_]+", " ", testo).strip().casefold()


def _valore_campo(riga: dict, campo: str, numero: int) -> Any:
    if campo in riga:
        return riga[campo]
    cercato = _normalizza_campo(campo)
    for k, v in riga.items():
        if _normalizza_campo(k) == cercato:
            return v
    raise ErroreValore(f"Nella riga {numero} della stampa unione manca il campo {mostra(campo)}.",
                       suggerimento="I campi disponibili sono: " + ", ".join(mostra(k) for k in riga) + ".")


def _riempi(testo: str, riga: dict, numero: int) -> str:
    return _RE_CAMPO.sub(lambda m: _in_testo(_valore_campo(riga, next(g for g in m.groups() if g), numero)), testo)


def _righe_unione(righe: Any) -> list[dict]:
    if isinstance(righe, dict):
        righe = [righe]
    elif isinstance(righe, str):
        estensione = _estensione(righe)
        if estensione in _ESTENSIONI_EXCEL:
            righe = leggi_excel(righe)
        elif estensione in (".csv", ".tsv", ".txt"):
            from .archivi import leggi_tabella
            righe = leggi_tabella(righe)
        else:
            raise ErroreValore(f"Non so leggere le righe della stampa unione da {mostra(righe)}.",
                               suggerimento="Dai una lista di dizionari, oppure un file .xlsx, .ods o .csv.")
    if not isinstance(righe, list):
        raise ErroreTipo(f"L'argomento `righe` di `stampa_unione` deve essere una lista di dizionari, "
                         f"non {articolo(righe)}.",
                         suggerimento="Per esempio `leggi_excel(\"indirizzi.xlsx\")`.")
    if len(righe) > MASSIME_LETTERE:
        raise ErroreValore(f"Troppe righe per `stampa_unione`: al massimo {MASSIME_LETTERE}.")
    for i, r in enumerate(righe, 1):
        if not isinstance(r, dict):
            raise ErroreTipo(f"La riga {i} di `stampa_unione` deve essere un dizionario, non {articolo(r)}.")
    if not righe:
        raise ErroreValore("La stampa unione non ha righe: non c'è niente da scrivere.")
    return righe


def _nome_file_sicuro(testo: str) -> str:
    pulito = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', "_", testo).strip(" .")
    return pulito[:120] or "vuoto"


def _rinumera_disegni(radice: ET.Element) -> None:
    numero = 0
    for e in radice.iter():
        if _nome_xml(e.tag) in ("docPr", "cNvPr") and "id" in e.attrib:
            numero += 1
            e.set("id", str(numero))


@funzione_libreria("stampa_unione")
def stampa_unione(modello, righe, uscita):
    """stampa_unione(modello, righe, uscita): crea una lettera (o un attestato...) per ogni riga di una tabella.

    `modello` è un file .docx, .txt, .md o .html, oppure direttamente un testo, con i campi scritti come
    `<<nome>>` (o «nome»). `righe` è una lista di dizionari o un file .xlsx, .ods, .csv.
    Se `uscita` contiene un campo ("lettere/lettera_<<nome>>.pdf") crea un file per riga, altrimenti
    un solo file con una pagina per riga. Il formato viene dall'estensione (.docx, .odt, .pdf, .html, .md, .txt).
    Restituisce la lista dei file creati.
    Esempio: `stampa_unione("Cara <<nome>>, sei invitata!", leggi_excel("amici.xlsx"), "inviti.pdf")`.
    """
    richiedi_testo(modello, "stampa_unione", "modello")
    richiedi_testo(uscita, "stampa_unione", "uscita")
    elenco = _righe_unione(righe)
    _controlla_percorso(uscita, "stampa_unione")
    estensione_uscita = _estensione(uscita) or ".docx"
    if not _estensione(uscita):
        uscita += ".docx"
    if estensione_uscita not in _ESTENSIONI_DOCUMENTO:
        raise ErroreValore(f"`stampa_unione` non sa scrivere file `{estensione_uscita}`.",
                           suggerimento=f"Usa un nome che finisce con {_elenco_estensioni(_ESTENSIONI_DOCUMENTO)}.")
    estensione_modello = _estensione(modello) if "\n" not in modello else ""
    e_file = bool(estensione_modello) and (os.path.isfile(modello) or len(modello) < 260) \
        and not _RE_CAMPO.search(modello) and estensione_modello in (".docx", ".docm", ".txt", ".md", ".html", ".htm")
    pacchetto = None
    testo_modello = modello
    if e_file:
        _controlla_percorso(modello, "stampa_unione")
        if estensione_modello in (".docx", ".docm"):
            pacchetto = _Pacchetto(modello, "stampa_unione", "file Word .docx")
        else:
            dati = _leggi_byte(modello, "stampa_unione")
            try:
                testo_modello = dati.decode("utf-8-sig")
            except UnicodeDecodeError:
                testo_modello = dati.decode("cp1252", "replace")
    per_riga = bool(_RE_CAMPO.search(uscita))
    creati: list[str] = []

    def nome_uscita(riga: dict, numero: int) -> str:
        nome = _RE_CAMPO.sub(lambda m: _nome_file_sicuro(_in_testo(_valore_campo(riga, next(g for g in m.groups() if g),
                                                                                   numero))), uscita)
        base, estensione = os.path.splitext(nome)
        k = 2
        while nome in creati:
            nome = f"{base}_{k}{estensione}"
            k += 1
        return nome

    def scrivi(percorso: str, dati: bytes) -> None:
        _crea_cartella_di(percorso)
        _scrivi_byte(percorso, dati)
        creati.append(percorso)

    if pacchetto is not None:
        if per_riga:
            for numero, riga in enumerate(elenco, 1):
                dati, _ = _sostituisci_docx(pacchetto, _RE_CAMPO, lambda m, r=riga, n=numero: _in_testo(
                    _valore_campo(r, next(g for g in m.groups() if g), n)))
                destinazione = nome_uscita(riga, numero)
                if estensione_uscita in (".docx", ".docm"):
                    scrivi(destinazione, dati)
                else:
                    doc = _documento_da_blocchi(_blocchi_docx_da_byte(dati, pacchetto))
                    scrivi(destinazione, _documento_in_byte(doc, estensione_uscita))
            return creati
        parte = pacchetto.parte_principale("word/document.xml")
        grezzo = pacchetto.leggi(parte)
        prefissi = _registra_prefissi(grezzo)
        radice = pacchetto.analizza(grezzo)
        corpo = radice.find(_W + "body")
        if corpo is None:
            raise pacchetto.rotto()
        figli = list(corpo)
        blocchi = [f for f in figli if f.tag != _W + "sectPr"]
        for f in figli:
            corpo.remove(f)
        for numero, riga in enumerate(elenco, 1):
            if numero > 1:
                corpo.append(ET.fromstring(f'<w:p xmlns:w="{_NS_W}"><w:r><w:br w:type="page"/></w:r></w:p>'))
            for b in blocchi:
                copia_blocco = copy.deepcopy(b)
                contenitore = ET.Element("contenitore")
                contenitore.append(copia_blocco)
                _sostituisci_in_paragrafi(contenitore, _RE_CAMPO, lambda m, r=riga, n=numero: _in_testo(
                    _valore_campo(r, next(g for g in m.groups() if g), n)))
                corpo.append(copia_blocco)
        for f in figli:
            if f.tag == _W + "sectPr":
                corpo.append(f)
        _rinumera_disegni(radice)
        nuovo_documento_xml = _serializza_word(radice, prefissi)
        if estensione_uscita in (".docx", ".docm"):
            uscita_zip = io.BytesIO()
            with zipfile.ZipFile(uscita_zip, "w", compression=zipfile.ZIP_DEFLATED) as z:
                for info in pacchetto.zip.infolist():
                    z.writestr(_nuova_voce(info), nuovo_documento_xml if info.filename == parte else pacchetto.leggi(info.filename))
            scrivi(uscita, uscita_zip.getvalue())
        else:
            doc = _documento_da_blocchi(_blocchi_docx(radice.find(_W + "body")))
            scrivi(uscita, _documento_in_byte(doc, estensione_uscita))
        return creati

    grezzo_html = estensione_modello in (".html", ".htm") and estensione_uscita in (".html", ".htm")
    testi = [(riga, numero, _riempi(testo_modello, riga, numero)) for numero, riga in enumerate(elenco, 1)]
    if per_riga:
        for riga, numero, testo in testi:
            destinazione = nome_uscita(riga, numero)
            if estensione_uscita in (".txt", ".md") or grezzo_html:
                scrivi(destinazione, testo.encode("utf-8"))
            else:
                scrivi(destinazione, _documento_in_byte(_documento_da_testo(testo, "stampa_unione"), estensione_uscita))
        return creati
    if estensione_uscita == ".txt":
        scrivi(uscita, "\n\f\n".join(t for _, _, t in testi).encode("utf-8"))
    elif estensione_uscita == ".md":
        scrivi(uscita, "\n\n---\n\n".join(t for _, _, t in testi).encode("utf-8"))
    else:
        doc = Documento()
        for k, (_, _, testo) in enumerate(testi):
            if k:
                doc.aggiungi(("pagina",))
            for elemento in _documento_da_testo(testo, "stampa_unione").elementi:
                doc.aggiungi(elemento)
        scrivi(uscita, _documento_in_byte(doc, estensione_uscita))
    return creati


def _blocchi_docx_da_byte(dati: bytes, modello: _Pacchetto) -> list[tuple]:
    z = zipfile.ZipFile(io.BytesIO(dati))
    parte = modello.parte_principale("word/document.xml")
    radice = modello.analizza(z.read(parte))
    corpo = radice.find(_W + "body")
    return _blocchi_docx(corpo) if corpo is not None else []


def _documento_in_byte(doc: Documento, estensione: str) -> bytes:
    if estensione == ".docx":
        return _docx(doc)
    if estensione == ".odt":
        return _odt(doc)
    if estensione == ".pdf":
        return _pdf_documento(doc)
    if estensione in (".html", ".htm"):
        return _html(doc).encode("utf-8")
    if estensione == ".md":
        return _markdown(doc).encode("utf-8")
    return _testo_semplice(doc).encode("utf-8")


# ===========================================================================
# Funzioni della libreria: documenti
# ===========================================================================

@funzione_libreria("nuovo_documento")
def nuovo_documento(titolo=None):
    """nuovo_documento(titolo = nulla): un documento vuoto da riempire e poi salvare in Word, PDF, LibreOffice o HTML.

    Metodi: `aggiungi_titolo(testo, livello)`, `aggiungi_paragrafo(testo, allinea)`, `aggiungi_elenco(voci, numerato)`,
    `aggiungi_tabella(righe)`, `aggiungi_immagine(percorso, larghezza)`, `aggiungi_interruzione_pagina()` e
    `salva(percorso)`: il formato viene dall'estensione (.docx, .odt, .pdf, .html, .md, .txt).
    Esempio: `variabile d = nuovo_documento("Gita")`, poi `d.aggiungi_paragrafo("Si parte alle **8**.")` e `d.salva("gita.pdf")`.
    """
    return Documento(_titolo_opzionale(titolo, "nuovo_documento"))


@proprieta(Documento, "titolo")
def _doc_titolo(doc):
    return doc.titolo


@proprieta(Documento, "elementi")
def _doc_elementi(doc):
    return len(doc.elementi)


@proprieta(Documento, "testo")
def _doc_testo(doc):
    return _testo_semplice(doc).rstrip("\n")


@metodo_oggetto(Documento, "aggiungi_titolo")
def doc_aggiungi_titolo(doc, testo, livello=1):
    """d.aggiungi_titolo(testo, livello = 1): aggiunge un titolo (livello 1, 2 o 3; 0 è il titolo del documento).

    Esempio: `d.aggiungi_titolo("Capitolo 1")`, `d.aggiungi_titolo("Parte A", 2)`.
    """
    richiedi_testo(testo, "aggiungi_titolo", "testo")
    richiedi_intero(livello, "aggiungi_titolo", "livello")
    if not 0 <= livello <= 3:
        raise ErroreValore(f"Il livello di un titolo va da 0 a 3, non {mostra(livello)}.",
                           suggerimento="1 per i capitoli, 2 e 3 per le parti più piccole.")
    return doc.aggiungi(("titolo", testo, livello))


@metodo_oggetto(Documento, "aggiungi_paragrafo")
def doc_aggiungi_paragrafo(doc, testo, allinea="sinistra"):
    """d.aggiungi_paragrafo(testo, allinea = "sinistra"): aggiunge un paragrafo; `**grassetto**` e `*corsivo*` funzionano.

    `allinea` può essere "sinistra", "centro", "destra" o "giustificato". "\\n" va a capo nello stesso paragrafo.
    Esempio: `d.aggiungi_paragrafo("Ciao **Ada**, ci vediamo *domani*.")`.
    """
    richiedi_testo(testo, "aggiungi_paragrafo", "testo")
    richiedi_testo(allinea, "aggiungi_paragrafo", "allinea")
    chiave = allinea.strip().lower()
    chiave = {"centrato": "centro", "centrale": "centro", "al centro": "centro", "a sinistra": "sinistra",
              "a destra": "destra", "giustifica": "giustificato"}.get(chiave, chiave)
    if chiave not in _ALLINEAMENTI:
        raise ErroreValore(f"Non conosco l'allineamento {mostra(allinea)}.",
                           suggerimento="Usa \"sinistra\", \"centro\", \"destra\" o \"giustificato\".")
    return doc.aggiungi(("paragrafo", testo, chiave))


@metodo_oggetto(Documento, "aggiungi_elenco")
def doc_aggiungi_elenco(doc, voci, numerato=False):
    """d.aggiungi_elenco(voci, numerato = falso): aggiunge un elenco puntato (o numerato con `numerato = vero`).

    Esempio: `d.aggiungi_elenco(["pane", "latte", "uova"])`.
    """
    if not isinstance(voci, list):
        raise ErroreTipo(f"L'argomento `voci` di `aggiungi_elenco` deve essere una lista, non {articolo(voci)}.",
                         suggerimento="Per esempio `d.aggiungi_elenco([\"pane\", \"latte\"])`.")
    richiedi_logico(numerato, "aggiungi_elenco", "numerato")
    if not voci:
        raise ErroreValore("L'elenco di `aggiungi_elenco` è vuoto.")
    return doc.aggiungi(("elenco", [_in_testo(v) for v in voci], numerato))


@metodo_oggetto(Documento, "aggiungi_tabella")
def doc_aggiungi_tabella(doc, righe, intestazione=None):
    """d.aggiungi_tabella(righe, intestazione = nulla): aggiunge una tabella da una lista di dizionari o di liste.

    Con i dizionari le chiavi diventano la riga d'intestazione (in grassetto); con le liste la prima riga
    è l'intestazione se contiene solo testi (oppure scegli tu con `intestazione = vero` o `falso`).
    Esempio: `d.aggiungi_tabella([{"nome": "Ada", "voto": 9}, {"nome": "Bruno", "voto": 7}])`.
    """
    griglia, trovata = _tabella_da_righe(righe, "aggiungi_tabella")
    if intestazione is not None:
        richiedi_logico(intestazione, "aggiungi_tabella", "intestazione")
        trovata = intestazione
    if not griglia:
        raise ErroreValore("La tabella di `aggiungi_tabella` è vuota.")
    _controlla_celle(griglia, "aggiungi_tabella")
    larghezza = max(len(r) for r in griglia)
    if larghezza == 0:
        raise ErroreValore("La tabella di `aggiungi_tabella` non ha colonne.")
    testi = [[_in_testo(v) for v in r] + [""] * (larghezza - len(r)) for r in griglia]
    return doc.aggiungi(("tabella", testi, trovata))


@metodo_oggetto(Documento, "aggiungi_immagine")
def doc_aggiungi_immagine(doc, percorso, larghezza=None):
    """d.aggiungi_immagine(percorso, larghezza = nulla): aggiunge un'immagine JPEG o PNG (GIF solo per Word e .odt).

    `larghezza` è in centimetri (al massimo 17, la larghezza della pagina); senza, l'immagine tiene la
    sua misura, ridotta se non ci sta.
    Esempio: `d.aggiungi_immagine("foto.jpg", 8)`.
    """
    if larghezza is not None:
        if isinstance(larghezza, bool) or not isinstance(larghezza, (int, float)):
            raise ErroreTipo(f"L'argomento `larghezza` di `aggiungi_immagine` deve essere un numero (centimetri), "
                             f"non {articolo(larghezza)}.")
        if not 0.1 <= larghezza <= 17:   # vale anche per nan e per gli interi enormi
            raise ErroreValore(f"La larghezza di un'immagine va da 0.1 a 17 centimetri, non {mostra(larghezza)}.")
        larghezza = float(larghezza)
    return doc.aggiungi(("immagine", _leggi_immagine(percorso, "aggiungi_immagine"), larghezza))


@metodo_oggetto(Documento, "aggiungi_interruzione_pagina")
def doc_aggiungi_interruzione_pagina(doc):
    """d.aggiungi_interruzione_pagina(): quello che viene dopo comincia su una pagina nuova.

    Esempio: `d.aggiungi_interruzione_pagina()` e poi `d.aggiungi_titolo("Capitolo 2")`.
    """
    return doc.aggiungi(("pagina",))


@metodo_oggetto(Documento, "salva")
def doc_salva(doc, percorso):
    """d.salva(percorso): salva il documento; il formato viene dall'estensione (.docx, .odt, .pdf, .html, .md, .txt).

    Senza estensione salva in Word (.docx). Restituisce il percorso del file.
    Esempio: `d.salva("relazione.docx")` e anche `d.salva("relazione.pdf")`.
    """
    percorso = _percorso_da_scrivere(percorso, "salva", _ESTENSIONI_DOCUMENTO)
    return _salva_documento(doc, percorso)


# ===========================================================================
# Funzioni della libreria: PDF
# ===========================================================================

@funzione_libreria("scrivi_pdf")
def scrivi_pdf(percorso, testo, titolo=None):
    """scrivi_pdf(percorso, testo, titolo = nulla): crea un PDF (A4) da un testo semplice, con titoli, elenchi e tabelle.

    Il testo si scrive come in `scrivi_word`: `# Titolo`, `- punto`, `| a | b |`, `**grassetto**`, `---` per una
    pagina nuova, `![](foto.jpg)` per un'immagine. Le pagine sono numerate in basso.
    Esempio: `scrivi_pdf("ricetta.pdf", "# Pancake\\n\\n- 2 uova\\n- 200 g di farina")`.
    """
    percorso = _percorso_da_scrivere(percorso, "scrivi_pdf", (".pdf",))
    doc = _documento_da_testo(_testo_da_scrivere(testo, "scrivi_pdf"), "scrivi_pdf",
                              _titolo_opzionale(titolo, "scrivi_pdf"))
    return _salva_documento(doc, percorso)


@funzione_libreria("leggi_pdf")
def leggi_pdf(percorso, pagine=None):
    """leggi_pdf(percorso, pagine = nulla): il testo di un PDF (di tutte le pagine o solo di quelle scelte).

    `pagine` può essere un numero (da 1), una lista o un testo come "1-3, 5". Le pagine sono separate da
    una riga vuota. I PDF fatti da foto o da scanner non hanno testo (serve un programma OCR).
    Esempio: `stampa(leggi_pdf("contratto.pdf", 1))`.
    """
    pdf = _apri_pdf(percorso, "leggi_pdf")
    pdf.controlla_non_protetto()
    elenco = pdf.pagine()
    if not elenco:
        raise ErroreValore(f"Nel PDF `{pdf.percorso}` non trovo nessuna pagina: forse è danneggiato.")
    indici = _indici_pagine(pagine, len(elenco), "leggi_pdf")
    estrattore = _Estrattore(pdf)
    testi = []
    for i in indici:
        try:
            testi.append(_pulisci_testo_estratto(estrattore.pagina(elenco[i][1], elenco[i][2])))
        except (_PdfRotto, RecursionError, ValueError, TypeError, OverflowError):
            testi.append("")
    testo = "\n\n".join(testi).strip("\n")
    if not testo.strip():
        alternativo = _testo_con_pypdf(pdf.percorso, indici)
        if alternativo and alternativo.strip():
            return alternativo.strip("\n")
    return testo


@funzione_libreria("conta_pagine_pdf")
def conta_pagine_pdf(percorso):
    """conta_pagine_pdf(percorso): quante pagine ha un PDF.

    Esempio: `stampa(conta_pagine_pdf("libro.pdf"), "pagine")`.
    """
    pdf = _apri_pdf(percorso, "conta_pagine_pdf")
    quante = len(pdf.pagine())
    if not quante:
        quante = len(re.findall(rb"/Type[\x00\t\n\x0c\r ]*/Page(?![A-Za-z])", pdf.dati))
    if not quante:
        raise ErroreValore(f"Nel PDF `{pdf.percorso}` non trovo le pagine: forse è danneggiato.")
    return quante


@funzione_libreria("info_pdf")
def info_pdf(percorso):
    """info_pdf(percorso): un dizionario con le informazioni di un PDF.

    Chiavi: "pagine", "titolo", "autore", "oggetto", "parole_chiave", "programma", "creato", "modificato"
    (date o `nulla`), "larghezza_mm" e "altezza_mm" (della prima pagina), "protetto" (`vero` se cifrato), "versione".
    Esempio: `variabile i = info_pdf("tesi.pdf")` e poi `stampa(i["pagine"], i["titolo"])`.
    """
    pdf = _apri_pdf(percorso, "info_pdf")
    elenco = pdf.pagine()
    info = pdf.risolvi(pdf.trailer.get("Info"))
    info = info if isinstance(info, dict) and not pdf.protetto else {}
    larghezza = altezza = None
    if elenco:
        _, diz, ereditati = elenco[0]
        scatola = pdf.risolvi(diz.get("MediaBox", ereditati.get("MediaBox")))
        if isinstance(scatola, list) and len(scatola) == 4:
            numeri = [pdf.risolvi(v) for v in scatola]
            if all(isinstance(v, (int, float)) and not isinstance(v, bool) for v in numeri):
                larghezza = round(abs(numeri[2] - numeri[0]) * 25.4 / 72, 1)
                altezza = round(abs(numeri[3] - numeri[1]) * 25.4 / 72, 1)
                rotazione = pdf.risolvi(diz.get("Rotate", ereditati.get("Rotate")))
                if isinstance(rotazione, int) and rotazione % 180 == 90:
                    larghezza, altezza = altezza, larghezza
    versione = re.match(rb"%PDF-(\d\.\d)", pdf.dati[pdf.dati.find(b"%PDF-"):])
    programma = pdf.testo_info(info.get("Creator")) or pdf.testo_info(info.get("Producer"))
    return {
        "pagine": len(elenco) or conta_pagine_pdf(pdf.percorso),
        "titolo": pdf.testo_info(info.get("Title")),
        "autore": pdf.testo_info(info.get("Author")),
        "oggetto": pdf.testo_info(info.get("Subject")),
        "parole_chiave": pdf.testo_info(info.get("Keywords")),
        "programma": programma,
        "creato": _data_pdf(pdf.testo_info(info.get("CreationDate"))) if info.get("CreationDate") else None,
        "modificato": _data_pdf(pdf.testo_info(info.get("ModDate"))) if info.get("ModDate") else None,
        "larghezza_mm": larghezza,
        "altezza_mm": altezza,
        "protetto": pdf.protetto,
        "versione": versione.group(1).decode("ascii") if versione else None,
    }


def _elenco_percorsi(valore: Any, nome: str, parametro: str) -> list[str]:
    if isinstance(valore, str):
        return [valore]
    if not isinstance(valore, list):
        raise ErroreTipo(f"L'argomento `{parametro}` di `{nome}` deve essere una lista di file, non {articolo(valore)}.",
                         suggerimento=f"Per esempio `{nome}([\"a.pdf\", \"b.pdf\"], ...)`.")
    if not valore:
        raise ErroreValore(f"La lista dei file di `{nome}` è vuota.")
    if len(valore) > 1000:
        raise ErroreValore(f"Troppi file per `{nome}`: al massimo 1000.")
    for v in valore:
        richiedi_testo(v, nome, parametro)
    return list(valore)


def _pdf_modificabile(percorso: Any, nome: str) -> _Pdf:
    pdf = _apri_pdf(percorso, nome)
    pdf.controlla_non_protetto()
    if not pdf.pagine():
        raise ErroreValore(f"Nel PDF `{pdf.percorso}` non trovo nessuna pagina: forse è danneggiato.")
    return pdf


@funzione_libreria("unisci_pdf")
def unisci_pdf(sorgenti, uscita):
    """unisci_pdf(sorgenti, uscita): unisce più PDF, uno dopo l'altro, in un PDF nuovo; restituisce quante pagine ha.

    Esempio: `unisci_pdf(["copertina.pdf", "compiti.pdf"], "consegna.pdf")`.
    """
    elenco = _elenco_percorsi(sorgenti, "unisci_pdf", "sorgenti")
    uscita = _percorso_da_scrivere(uscita, "unisci_pdf", (".pdf",))
    scelte = []
    for p in elenco:
        pdf = _pdf_modificabile(p, "unisci_pdf")
        scelte += [(pdf, n, d, e, 0) for n, d, e in pdf.pagine()]
    _scrivi_byte(uscita, _componi_pagine(scelte))
    return len(scelte)


@funzione_libreria("estrai_pagine_pdf")
def estrai_pagine_pdf(percorso, pagine, uscita):
    """estrai_pagine_pdf(percorso, pagine, uscita): copia alcune pagine di un PDF in un PDF nuovo, nell'ordine chiesto.

    `pagine` è un numero (da 1; -1 è l'ultima), una lista di numeri o un testo come "1-3, 5".
    Restituisce quante pagine ha il PDF nuovo.
    Esempio: `estrai_pagine_pdf("libro.pdf", "10-12", "capitolo2.pdf")`.
    """
    pdf = _pdf_modificabile(percorso, "estrai_pagine_pdf")
    elenco = pdf.pagine()
    indici = _indici_pagine(pagine, len(elenco), "estrai_pagine_pdf")
    uscita = _percorso_da_scrivere(uscita, "estrai_pagine_pdf", (".pdf",))
    _scrivi_byte(uscita, _componi_pagine([(pdf, *elenco[i], 0) for i in indici]))
    return len(indici)


@funzione_libreria("ruota_pagine_pdf")
def ruota_pagine_pdf(percorso, gradi=90, uscita=None, pagine=None):
    """ruota_pagine_pdf(percorso, gradi = 90, uscita = nulla, pagine = nulla): gira le pagine di un PDF (90, 180, 270 gradi).

    I gradi positivi girano in senso orario, quelli negativi al contrario. Senza `pagine` gira tutte le pagine;
    senza `uscita` cambia il file stesso. Restituisce il percorso del file scritto.
    Esempio: `ruota_pagine_pdf("scansione.pdf", 90, "dritta.pdf")`.
    """
    richiedi_intero(gradi, "ruota_pagine_pdf", "gradi")
    if gradi % 90:
        raise ErroreValore(f"Le pagine si possono girare solo di 90, 180 o 270 gradi, non di {mostra(gradi)}.")
    pdf = _pdf_modificabile(percorso, "ruota_pagine_pdf")
    elenco = pdf.pagine()
    scelte = set(_indici_pagine(pagine, len(elenco), "ruota_pagine_pdf"))
    destinazione = pdf.percorso if uscita is None else _percorso_da_scrivere(uscita, "ruota_pagine_pdf", (".pdf",))
    _scrivi_byte(destinazione, _componi_pagine([(pdf, *p, gradi % 360 if i in scelte else 0)
                                                for i, p in enumerate(elenco)]))
    return destinazione


@funzione_libreria("immagini_in_pdf")
def immagini_in_pdf(immagini, uscita):
    """immagini_in_pdf(immagini, uscita): mette delle foto JPEG o PNG in un PDF, una per pagina; restituisce quante pagine.

    Ogni foto riempie una pagina A4 (verticale o orizzontale, come la foto). Utile per le pagine fotografate.
    Esempio: `immagini_in_pdf(["pagina1.jpg", "pagina2.jpg"], "compito.pdf")`.
    """
    elenco = _elenco_percorsi(immagini, "immagini_in_pdf", "immagini")
    uscita = _percorso_da_scrivere(uscita, "immagini_in_pdf", (".pdf",))
    impaginatore = _Impaginatore(numeri_pagina=False)
    impaginatore.pagine, impaginatore.formati, impaginatore.immagini_pagina = [], [], []
    margine = _PT_CM
    for p in elenco:
        immagine = _leggi_immagine(p, "immagini_in_pdf")
        orizzontale = immagine.larghezza_vista > immagine.altezza_vista
        formato = (_A4[1], _A4[0]) if orizzontale else _A4
        impaginatore.nuova_pagina(formato)
        spazio_l, spazio_a = formato[0] - 2 * margine, formato[1] - 2 * margine
        scala = min(spazio_l / immagine.larghezza_vista, spazio_a / immagine.altezza_vista)
        larghezza, altezza = immagine.larghezza_vista * scala, immagine.altezza_vista * scala
        impaginatore.disegna_immagine(immagine, (formato[0] - larghezza) / 2, (formato[1] - altezza) / 2,
                                      larghezza, altezza)
    _scrivi_byte(uscita, impaginatore.componi())
    return len(elenco)


@funzione_libreria("cerca_in_pdf")
def cerca_in_pdf(percorso, testo):
    """cerca_in_pdf(percorso, testo): dove compare un testo in un PDF; restituisce una lista di dizionari.

    Ogni risultato ha "pagina" (da 1) e "riga" (la riga intera che contiene il testo). Non guarda
    maiuscole e minuscole. Se il testo non c'è restituisce una lista vuota.
    Esempio: `per ogni t in cerca_in_pdf("contratto.pdf", "scadenza") fai stampa(t["pagina"], t["riga"]) fine`.
    """
    richiedi_testo(testo, "cerca_in_pdf", "testo")
    cercato = " ".join(testo.split()).casefold()
    if not cercato:
        raise ErroreValore("Il testo da cercare di `cerca_in_pdf` è vuoto.")
    pdf = _apri_pdf(percorso, "cerca_in_pdf")
    pdf.controlla_non_protetto()
    elenco = pdf.pagine()
    estrattore = _Estrattore(pdf)
    trovati = []
    for numero, pagina in enumerate(elenco, 1):
        try:
            contenuto = _pulisci_testo_estratto(estrattore.pagina(pagina[1], pagina[2]))
        except (_PdfRotto, RecursionError, ValueError, TypeError, OverflowError):
            contenuto = ""
        if not contenuto.strip():
            contenuto = _testo_con_pypdf(pdf.percorso, [numero - 1]) or ""
        for riga in contenuto.split("\n"):
            if cercato in " ".join(riga.split()).casefold():
                trovati.append({"pagina": numero, "riga": riga.strip()})
    return trovati


@funzione_libreria("dividi_pdf")
def dividi_pdf(percorso, cartella):
    """dividi_pdf(percorso, cartella): fa un PDF per ogni pagina, dentro una cartella (la crea se manca).

    I file si chiamano come l'originale con il numero della pagina: "libro_001.pdf", "libro_002.pdf"...
    Restituisce la lista dei file creati.
    Esempio: `dividi_pdf("scansioni.pdf", "pagine")`.
    """
    richiedi_testo(cartella, "dividi_pdf", "cartella")
    _controlla_percorso(cartella, "dividi_pdf")
    pdf = _pdf_modificabile(percorso, "dividi_pdf")
    elenco = pdf.pagine()
    if os.path.exists(cartella) and not os.path.isdir(cartella):
        raise ErroreFile(f"`{cartella}` è un file, non una cartella.")
    try:
        os.makedirs(cartella, exist_ok=True)
    except OSError as e:
        raise _errore_file(e, cartella) from None
    base = os.path.splitext(os.path.basename(pdf.percorso))[0] or "pagina"
    cifre = max(3, len(str(len(elenco))))
    creati = []
    for numero, pagina in enumerate(elenco, 1):
        uscita = os.path.join(cartella, f"{base}_{numero:0{cifre}d}.pdf")
        _scrivi_byte(uscita, _componi_pagine([(pdf, *pagina, 0)]))
        creati.append(uscita)
    return creati


# ===========================================================================
# Funzioni della libreria: tabelle e documenti da un formato all'altro
# ===========================================================================

@funzione_libreria("leggi_fogli_excel")
def leggi_fogli_excel(percorso, intestazione=True):
    """leggi_fogli_excel(percorso, intestazione = vero): tutti i fogli di un file .xlsx o .ods in un dizionario.

    Le chiavi sono i nomi dei fogli, i valori le righe (come in `leggi_excel`).
    Esempio: `per ogni nome, righe in leggi_fogli_excel("scuola.xlsx") fai stampa(nome, lunghezza(righe)) fine`.
    """
    richiedi_logico(intestazione, "leggi_fogli_excel", "intestazione")
    cartella = _Cartella(percorso, "leggi_fogli_excel")
    risultato = {}
    for numero, nome in enumerate(cartella.nomi, 1):
        celle = cartella.celle(numero)
        riquadro = _riquadro(celle)
        if riquadro is None:
            risultato[nome] = []
            continue
        griglia = _griglia(celle, *riquadro, "leggi_fogli_excel")
        if intestazione:
            nomi = _nomi_intestazione(griglia[0])
            risultato[nome] = [dict(zip(nomi, r)) for r in griglia[1:] if any(v is not None for v in r)]
        else:
            risultato[nome] = griglia
    return risultato


def _valore_html(v: Any) -> str:
    if isinstance(v, DataDante):
        return _x(v.testo_dante())
    return _x(_in_testo(v)).replace("\n", "<br>")


@funzione_libreria("tabella_in_html")
def tabella_in_html(righe, titolo=None, intestazione=None, classe=None):
    """tabella_in_html(righe, titolo = nulla, intestazione = nulla, classe = nulla): il codice HTML (`<table>...`) di una tabella.

    `righe` è una lista di dizionari (le chiavi diventano le colonne) o di liste, come in `scrivi_excel`.
    I testi sono protetti e i numeri allineati a destra; con `titolo` la tabella ha una didascalia.
    `intestazione` (vero o falso) dice se la prima riga di una lista di liste è l'intestazione: se manca,
    Leo lo capisce da solo (prima riga tutta di testi). `classe` aggiunge `class="..."` per lo stile CSS.
    Per un file .html completo usa `converti_tabella`.
    Esempio: `scrivi_file("voti.html", tabella_in_html(leggi_excel("voti.xlsx"), "Voti", classe = "voti"))`.
    """
    if isinstance(titolo, bool) and intestazione is None:
        # forma breve della libreria web: tabella_in_html(righe, falso)
        titolo, intestazione = None, titolo
    if isinstance(righe, list) and any(isinstance(r, dict) for r in righe) \
            and not all(isinstance(r, dict) for r in righe):
        altro = next(r for r in righe if not isinstance(r, dict))
        raise ErroreTipo(f"Le righe di `tabella_in_html` devono essere tutte dizionari o tutte liste: "
                         f"c'è {articolo(altro)}.")
    if intestazione is not None and not isinstance(intestazione, bool):
        raise ErroreTipo("`intestazione` di `tabella_in_html` deve essere `vero` o `falso`.")
    griglia, automatica = _tabella_da_righe(righe, "tabella_in_html")
    _controlla_celle(griglia, "tabella_in_html")
    titolo = _titolo_opzionale(titolo, "tabella_in_html")
    if intestazione is None or (righe and all(isinstance(r, dict) for r in righe)):
        intestazione = automatica
    larghezza = max((len(r) for r in griglia), default=0)
    if classe is not None:
        if not isinstance(classe, str):
            raise ErroreTipo("`classe` di `tabella_in_html` deve essere un testo, per esempio \"voti\".")
        pezzi = [f'<table class="{_x(classe)}">']
    else:
        pezzi = ["<table>"]
    if titolo:
        pezzi.append(f"<caption>{_x(titolo)}</caption>")
    corpo = griglia
    if intestazione and griglia:
        pezzi.append("<thead><tr>" + "".join(f"<th>{_valore_html(v)}</th>" for v in griglia[0]) + "</tr></thead>")
        corpo = griglia[1:]
    pezzi.append("<tbody>")
    for riga in corpo:
        celle = []
        for v in list(riga) + [None] * (larghezza - len(riga)):
            numero = isinstance(v, (int, float, Decimal)) and not isinstance(v, bool) \
                or getattr(v, "NOME_TIPO_DANTE", "") in ("soldi", "frazione")
            stile = ' style="text-align:right"' if numero else ""
            celle.append(f"<td{stile}>{_valore_html(v)}</td>")
        pezzi.append("<tr>" + "".join(celle) + "</tr>")
    pezzi.append("</tbody></table>")
    return "\n".join(pezzi)


def _numero_da_testo(testo: str) -> Any:
    """Le celle di una tabella di Word sono testi: "8" e "7,5" tornano numeri, "" torna `nulla`."""
    pulito = testo.strip()
    if not pulito:
        return None
    if re.fullmatch(r"-?\d{1,15}", pulito):
        return int(pulito)
    if re.fullmatch(r"-?\d{1,15}[.,]\d{1,10}", pulito):
        return float(pulito.replace(",", "."))
    return testo


_ESTENSIONI_TABELLA_LETTURA = (".xlsx", ".xlsm", ".ods", ".csv", ".tsv", ".txt", ".json", ".docx", ".odt")
_ESTENSIONI_TABELLA_SCRITTURA = (".xlsx", ".ods", ".csv", ".tsv", ".json", ".html", ".htm", ".md", ".txt",
                                 ".docx", ".odt", ".pdf")


def _leggi_tabella_da_file(percorso: str, nome: str) -> list:
    estensione = _estensione(percorso)
    if estensione in _ESTENSIONI_EXCEL:
        return leggi_excel(percorso)
    if estensione in (".csv", ".tsv", ".txt"):
        from .archivi import leggi_tabella
        return leggi_tabella(percorso, "\t" if estensione == ".tsv" else None)
    if estensione == ".json":
        from .archivi import leggi_json
        valore = leggi_json(percorso)
        if isinstance(valore, dict):
            valore = [valore]
        return _richiedi_righe(valore, nome)
    if estensione in (".docx", ".odt"):
        tabelle = tabelle_word(percorso)
        if not tabelle:
            raise ErroreValore(f"Nel documento `{percorso}` non c'è nessuna tabella.")
        return [[_numero_da_testo(v) for v in r] for r in tabelle[0]]
    raise ErroreValore(f"`{nome}` non sa leggere una tabella da file `{estensione or percorso}`.",
                       suggerimento=f"Usa un file {_elenco_estensioni(_ESTENSIONI_TABELLA_LETTURA)}.")


@funzione_libreria("converti_tabella")
def converti_tabella(sorgente, destinazione, titolo=None):
    """converti_tabella(sorgente, destinazione, titolo = nulla): porta una tabella da un formato a un altro.

    `sorgente` è un file (.xlsx, .ods, .csv, .tsv, .json, oppure la prima tabella di un .docx/.odt) o
    direttamente una lista di righe. `destinazione` decide il formato: .xlsx, .ods, .csv, .tsv, .json,
    .html, .md, .txt, .docx, .odt o .pdf. Con `titolo` i documenti hanno un titolo sopra la tabella.
    Restituisce il percorso del file scritto.
    Esempio: `converti_tabella("voti.xlsx", "voti.pdf", "Voti della 3A")`.
    """
    richiedi_testo(destinazione, "converti_tabella", "destinazione")
    titolo = _titolo_opzionale(titolo, "converti_tabella")
    if isinstance(sorgente, str):
        _controlla_percorso(sorgente, "converti_tabella")
        righe = _leggi_tabella_da_file(sorgente, "converti_tabella")
    else:
        righe = _richiedi_righe(sorgente, "converti_tabella", "sorgente")
    destinazione = _percorso_da_scrivere(destinazione, "converti_tabella", _ESTENSIONI_TABELLA_SCRITTURA)
    estensione = _estensione(destinazione)
    if estensione in (".xlsx", ".ods"):
        return scrivi_excel(destinazione, righe, (titolo or "Foglio1")[:31])
    if estensione in (".csv", ".tsv"):
        from .archivi import scrivi_tabella
        scrivi_tabella(destinazione, righe, "\t" if estensione == ".tsv" else None)
        return destinazione
    if estensione == ".json":
        from .archivi import scrivi_json
        scrivi_json(destinazione, righe)
        return destinazione
    doc = Documento(titolo)
    if righe:
        doc_aggiungi_tabella(doc, righe)
    return _salva_documento(doc, destinazione)


_ESTENSIONI_DOCUMENTO_LETTURA = (".docx", ".docm", ".dotx", ".odt", ".md", ".txt", ".pdf")


def _documento_da_file(percorso: Any, nome: str) -> Documento:
    percorso = _percorso_da_leggere(percorso, nome, _ESTENSIONI_DOCUMENTO_LETTURA)
    estensione = _estensione(percorso)
    if estensione in _ESTENSIONI_WORD:
        doc = _documento_da_blocchi(_leggi_blocchi_word(percorso, nome))
        if doc.elementi and doc.elementi[0][0] == "titolo" and doc.elementi[0][2] == 0:
            doc.titolo = doc.elementi[0][1]
        return doc
    if estensione == ".pdf":
        doc = Documento()
        for numero in range(1, conta_pagine_pdf(percorso) + 1):
            if numero > 1:
                doc.aggiungi(("pagina",))
            testo = re.sub(r"\n?\s*Pagina \d+ di \d+\s*$", "", leggi_pdf(percorso, numero))  # il piè di pagina
            for blocco in re.split(r"\n\s*\n", testo):
                if blocco.strip():
                    doc.aggiungi(("paragrafo", blocco.strip(), "sinistra"))
        return doc
    if estensione in (".md", ".txt"):
        dati = _leggi_byte(percorso, nome)
        try:
            testo = dati.decode("utf-8-sig")
        except UnicodeDecodeError:
            testo = dati.decode("cp1252", "replace")
        cartella = os.path.dirname(os.path.abspath(percorso))

        def vicino(m: re.Match) -> str:     # le immagini ![](foto.jpg) sono accanto al file
            posto = m.group(2).strip()
            if not os.path.isabs(posto):
                posto = os.path.join(cartella, posto)
            return f"![{m.group(1)}]({posto})"

        testo = "\n".join(_RE_IMMAGINE_MD.sub(vicino, r) for r in testo.split("\n"))
        return _documento_da_testo(testo, nome)
    raise ErroreValore(f"`{nome}` non sa aprire file `{estensione or percorso}`.",
                       suggerimento=f"Usa un file {_elenco_estensioni(_ESTENSIONI_DOCUMENTO_LETTURA)}.")


@funzione_libreria("apri_documento")
def apri_documento(percorso):
    """apri_documento(percorso): apre un documento (.docx, .odt, .md, .txt o .pdf) come `documento`, per aggiungere e risalvare.

    Si tengono titoli, paragrafi, elenchi e tabelle (non la grafica). Poi si usano i metodi di
    `nuovo_documento` (`aggiungi_paragrafo`, `salva`...).
    Esempio: `variabile d = apri_documento("verbale.docx")`, `d.aggiungi_paragrafo("Firmato: Ada")`,
    `d.salva("verbale_firmato.pdf")`.
    """
    return _documento_da_file(percorso, "apri_documento")


@funzione_libreria("converti_documento")
def converti_documento(sorgente, destinazione):
    """converti_documento(sorgente, destinazione): trasforma un documento in un altro formato; restituisce il percorso scritto.

    Legge .docx, .odt, .md, .txt e .pdf (solo il testo); scrive .docx, .odt, .pdf, .html, .md o .txt,
    secondo l'estensione di `destinazione`. Si tengono titoli, paragrafi, elenchi e tabelle.
    Esempio: `converti_documento("tema.docx", "tema.pdf")`.
    """
    doc = _documento_da_file(sorgente, "converti_documento")
    destinazione = _percorso_da_scrivere(destinazione, "converti_documento", _ESTENSIONI_DOCUMENTO)
    return _salva_documento(doc, destinazione)
