"""Libreria: strumenti per programmi "seri" (riga di comando, registro, parallelismo, orari, terminale).

Gruppi di funzioni (vedi docs/LIBRERIA_PROGRAMMI.md):

* **riga di comando**: ``argomenti``, ``leggi_opzioni``, ``aiuto_opzioni``;
* **registro degli eventi** su file che ruota: ``apri_registro`` (valore ``registro``
  con ``informazione``, ``avviso``, ``errore``, ``dettaglio``, ``ultime_righe``, ``chiudi``);
* **lavorare in parallelo e con calma**: ``mappa_in_parallelo`` (su più processi per
  davvero), ``con_limite_di_tempo``, ``riprova``, ``ricorda_risultati``,
  ``confronta_tempi``, ``crea_coda`` (valore ``coda`` con ``metti``, ``prendi``, ``chiudi``);
* **orari**: ``ogni_giorno_alle``, ``ogni_settimana`` (finché il programma è aperto);
* **configurazione e stato**: ``leggi_configurazione``, ``salva_configurazione``,
  ``salva_stato``, ``carica_stato``;
* **terminale**: ``barra_avanzamento``, ``testo_colorato``, ``togli_colori``,
  ``tabella_con_bordi``, ``menu``, ``chiedi_numero``, ``scegli_da_elenco``,
  ``chiedi_si_no``, ``premi_invio``, ``pulisci_terminale``;
* **vita del programma**: ``programma_unico``, ``esci_dal_programma``,
  ``prima_di_uscire``, ``memoria_programma``.

Le funzioni Leo ricevute come argomento si chiamano con ``interprete.chiama``.
I limiti di tempo (``con_limite_di_tempo``, ``tempo_massimo``) non usano altri
fili per il codice Leo: un filo sorvegliante accende, alla scadenza, la stessa
richiesta di arresto del pulsante "Ferma" (``_ferma_richiesta``), che il codice
Leo controlla a ogni ciclo e chiamata; chi ha messo il limite la cattura e la spegne.

``mappa_in_parallelo`` usa i processi lavoratori dei lavori ``in parallelo``
(:mod:`leo.parallelo_processi`: avviati una volta e riusati, uno per processore):
la funzione riceve una copia isolata del programma, i dati si dividono in
``quanti`` pezzi. Dove i processi non si possono usare (Android, eseguibile che
non sa fare da lavoratore, valori che non si possono copiare,
``LEO_PARALLELO=fili``) il codice Leo gira uno alla volta nell'interprete del
programma (con Python i fili non lo renderebbero più veloce), mentre le
funzioni della libreria (per esempio ``scarica_testo``) usano più fili.
``crea_coda`` è un canale (:class:`leo.parallelo.Canale`) con i nomi della coda.
"""

from __future__ import annotations

import atexit
import datetime
import difflib
import itertools
import json
import math
import os
import pickle
import re
import sys
import tempfile
import threading
import time
from typing import Any, Callable

from ..errori import TIPI_ERRORE, ErroreDante, ErroreFile, ErroreTipo, ErroreValore
from ..valori import FunzioneDante, FunzioneNativa, Richiamabile, rappresenta
from .funzionali import chiama_funzione, elementi, richiedi_funzione
from .generali import (articolo, funzione_libreria, mostra, richiedi_intero, richiedi_logico, richiedi_numero,
                       richiedi_testo)
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta
from ..parallelo import Canale, CanaleChiuso, TempoScaduto, copia_messaggio
from ..parallelo_processi import CLASSI_CON_METODI, TIPI_REMOTI, CanaleRemoto

_NON_DATO = object()


# ===========================================================================
# Strumenti interni
# ===========================================================================

def _scrivi(interprete: Any, testo: str) -> None:
    scrivi = getattr(interprete, "scrivi", None)
    if callable(scrivi):
        scrivi(testo)
    else:  # pragma: no cover - senza interprete
        sys.stdout.write(testo)
        sys.stdout.flush()


def _leggi(interprete: Any, domanda: str) -> str:
    risposta = interprete.leggi(domanda)
    if risposta is None:
        raise ErroreValore("Non ci sono più dati da leggere.")
    return risposta if isinstance(risposta, str) else str(risposta)


def _nome_funzione(f: Any, riserva: str = "la funzione") -> str:
    nome = getattr(f, "nome", "") or ""
    if not nome or nome.startswith("<"):
        return riserva
    return nome


def _numero_it(x: float, decimali: int = 3) -> str:
    """Un decimale scritto all'italiana (virgola)."""
    return f"{x:.{decimali}f}".replace(".", ",")


def _fermato(interprete: Any) -> bool:
    return bool(getattr(interprete, "fermato", False))


def _pausa(interprete: Any, secondi: float) -> None:
    """Aspetta ``secondi`` restando interrompibile (e con le finestre vive)."""
    if secondi <= 0:
        return
    from .tempo import attendi

    attendi(interprete, float(min(secondi, 86_400)))


def _interattivo() -> bool:
    """Vero se l'uscita è un terminale vero (o il Terminale di Leo Studio)."""
    if os.environ.get("LEO_COLORI") == "1" or os.environ.get("DANTE_COLORI") == "1":
        return True
    try:
        return bool(sys.stdout.isatty())
    except (AttributeError, ValueError, OSError):
        return False


def _usa_colori() -> bool:
    try:
        from ..cli import usa_colori
    except Exception:  # noqa: BLE001 - senza la riga di comando: niente colori
        return False
    try:
        return bool(usa_colori())
    except Exception:  # noqa: BLE001
        return False


def _nome_programma(interprete: Any) -> str:
    nome = getattr(interprete, "nome_file", "") or ""
    if not nome or nome.startswith("<"):
        return "programma"
    return os.path.basename(nome)


def _e_lavoro_parallelo(interprete: Any) -> bool:
    return type(interprete).__name__ == "InterpreteParallelo"


# ===========================================================================
# Riga di comando
# ===========================================================================

def _argomenti_programma() -> list[str]:
    cli = sys.modules.get("leo.cli")
    lista = getattr(cli, "ARGOMENTI_PROGRAMMA", None)
    return [str(a) for a in lista] if lista else []


@funzione_libreria("argomenti")
def argomenti():
    """argomenti(): la lista dei testi scritti dopo il nome del programma nella riga di comando.

    Esempio: con `leo saluta.leo Anna Luca`, `argomenti()` è ["Anna", "Luca"].
    Senza argomenti (o in Leo Studio) è una lista vuota. Per le opzioni con nome
    (`--volte 3`) usa `leggi_opzioni`.
    """
    return _argomenti_programma()


class _Opzione:
    def __init__(self, nome: str, specifica: Any) -> None:
        self.nome = nome
        self.aiuto = ""
        self.breve: str | None = None
        self.obbligatoria = False
        if isinstance(specifica, dict) and ("predefinito" in specifica or "aiuto" in specifica
                                            or "breve" in specifica or "obbligatoria" in specifica):
            sconosciute = [k for k in specifica if k not in ("predefinito", "aiuto", "breve", "obbligatoria")]
            if sconosciute:
                raise ErroreValore(
                    f"L'opzione `{nome}` di `leggi_opzioni` ha una voce sconosciuta: `{sconosciute[0]}`.",
                    suggerimento="Le voci possibili sono `predefinito`, `aiuto`, `breve` e `obbligatoria`.")
            self.predefinito = specifica.get("predefinito")
            aiuto = specifica.get("aiuto", "")
            self.aiuto = aiuto if isinstance(aiuto, str) else rappresenta(aiuto)
            breve = specifica.get("breve")
            if breve is not None:
                if not isinstance(breve, str) or len(breve.strip("-")) != 1:
                    raise ErroreValore(f"La voce `breve` dell'opzione `{nome}` deve essere una lettera sola, "
                                       f"non {mostra(breve)}.", suggerimento='Per esempio `"breve": "n"`.')
                self.breve = breve.strip("-")
            obbligatoria = specifica.get("obbligatoria", False)
            self.obbligatoria = richiedi_logico(obbligatoria, "leggi_opzioni", "obbligatoria")
        else:
            self.predefinito = specifica
        p = self.predefinito
        if isinstance(p, bool):
            self.tipo = "logico"
        elif isinstance(p, int):
            self.tipo = "intero"
        elif isinstance(p, float):
            self.tipo = "decimale"
        elif isinstance(p, list):
            self.tipo = "lista"
        elif p is None or isinstance(p, str):
            self.tipo = "testo"
        else:
            raise ErroreTipo(f"Il valore predefinito dell'opzione `{nome}` deve essere un testo, un numero, "
                             f"`vero`/`falso` o una lista, non {articolo(p)}.")

    @property
    def lunga(self) -> str:
        return "--" + self.nome.replace("_", "-")

    def segnaposto(self) -> str:
        return {"intero": "NUMERO", "decimale": "NUMERO", "lista": "VALORE", "testo": "TESTO"}.get(self.tipo, "")

    def converti(self, testo: str) -> Any:
        if self.tipo == "intero":
            try:
                return int(testo.strip().replace("_", ""))
            except ValueError:
                raise ValueError(f"l'opzione `{self.lunga}` vuole un numero intero, non `{testo}`") from None
        if self.tipo == "decimale":
            try:
                return float(testo.strip().replace(",", "."))
            except ValueError:
                raise ValueError(f"l'opzione `{self.lunga}` vuole un numero, non `{testo}`") from None
        if self.tipo == "logico":
            t = testo.strip().lower()
            if t in ("si", "sì", "s", "vero", "1", "yes", "y"):
                return True
            if t in ("no", "n", "falso", "0"):
                return False
            raise ValueError(f"l'opzione `{self.lunga}` vuole `si` oppure `no`, non `{testo}`")
        return testo


def _opzioni_da(opzioni: Any, chi: str) -> list[_Opzione]:
    if not isinstance(opzioni, dict):
        raise ErroreTipo(f"Il primo argomento di `{chi}` deve essere un dizionario delle opzioni, "
                         f"non {articolo(opzioni)}.",
                         suggerimento=f'Per esempio `{chi}({{"nome": "Mondo", "volte": 1, "forte": falso}})`.')
    risultato = []
    brevi: dict[str, str] = {}
    for nome, specifica in opzioni.items():
        if not isinstance(nome, str) or not re.fullmatch(r"[A-Za-z_À-ÿ][\wÀ-ÿ-]*", nome):
            raise ErroreValore(f"{mostra(nome)} non va bene come nome di un'opzione.",
                               suggerimento="Usa lettere, numeri e `_`, per esempio `\"nome_file\"`.")
        if nome == "altri":
            raise ErroreValore("`altri` è riservato: contiene gli argomenti senza nome.",
                               suggerimento="Scegli un altro nome per l'opzione.")
        o = _Opzione(nome.replace("-", "_"), specifica)
        if o.breve is not None:
            if o.breve == "h":
                raise ErroreValore("La lettera `-h` è riservata all'aiuto.",
                                   suggerimento="Scegli un'altra lettera per `breve`.")
            if o.breve in brevi:
                raise ErroreValore(f"La lettera `-{o.breve}` è usata sia da `{brevi[o.breve]}` sia da `{o.nome}`.",
                                   suggerimento="Ogni opzione deve avere una lettera diversa.")
            brevi[o.breve] = o.nome
        risultato.append(o)
    return risultato


def _testo_aiuto(opzioni: list[_Opzione], descrizione: str, programma: str) -> str:
    righe = [f"Uso: leo {programma} [opzioni] [altri argomenti]", ""]
    if descrizione:
        righe += [descrizione, ""]
    voci = []
    for o in opzioni:
        nomi = (f"-{o.breve}, " if o.breve else "    ") + o.lunga
        if o.segnaposto():
            nomi += " " + o.segnaposto()
        dettagli = o.aiuto
        if o.obbligatoria:
            extra = "obbligatoria"
        elif o.tipo == "logico":
            extra = "si/no, predefinito: " + ("si" if o.predefinito else "no")
        elif o.tipo == "lista":
            extra = "si può ripetere"
        elif o.predefinito is None:
            extra = ""
        else:
            extra = "predefinito: " + rappresenta(o.predefinito, dentro=True)
        if extra:
            dettagli = f"{dettagli} ({extra})" if dettagli else f"({extra})"
        voci.append((nomi, dettagli))
    voci.append(("-h, --aiuto", "mostra questo aiuto ed esce"))
    larghezza = max(len(n) for n, _ in voci) + 2
    righe.append("Opzioni:")
    for nomi, dettagli in voci:
        righe.append(f"  {nomi.ljust(larghezza)}{dettagli}".rstrip())
    if any(o.tipo == "logico" for o in opzioni):
        righe += ["", "Le opzioni si/no si accendono scrivendole (--forte) e si spengono con --no-forte."]
    return "\n".join(righe) + "\n"


def _analizza_opzioni(opzioni: list[_Opzione], parole: list[str]) -> tuple[dict, list[str], bool]:
    """(valori, altri argomenti, aiuto chiesto); ``ValueError`` con il motivo in italiano."""
    per_nome = {o.lunga: o for o in opzioni}
    per_nome.update({"--" + o.nome: o for o in opzioni})
    per_breve = {"-" + o.breve: o for o in opzioni if o.breve}
    valori: dict[str, Any] = {}
    for o in opzioni:
        valori[o.nome] = list(o.predefinito) if o.tipo == "lista" else o.predefinito
    viste: set[str] = set()
    iniziate: set[str] = set()
    altri: list[str] = []
    i = 0
    while i < len(parole):
        parola = parole[i]
        i += 1
        if parola == "--":
            altri.extend(parole[i:])
            break
        if parola in ("-h", "--aiuto", "--help", "-?", "/?"):
            return valori, altri, True
        if not parola.startswith("-") or parola == "-" or re.fullmatch(r"-\d[\d.,]*", parola):
            altri.append(parola)
            continue
        nome, uguale, valore = parola.partition("=")
        negata = False
        opzione = per_nome.get(nome) or per_breve.get(nome)
        if opzione is None and nome.startswith("--no-"):
            candidata = per_nome.get("--" + nome[5:])
            if candidata is not None and candidata.tipo == "logico" and not uguale:
                opzione, negata = candidata, True
        if opzione is None:
            tutti = sorted(per_nome) + sorted(per_breve)
            simili = difflib.get_close_matches(nome, tutti, n=1, cutoff=0.6)
            forse = f" Forse intendevi `{simili[0]}`?" if simili else ""
            raise ValueError(f"non conosco l'opzione `{nome}`.{forse}")
        viste.add(opzione.nome)
        if opzione.tipo == "logico":
            valori[opzione.nome] = opzione.converti(valore) if uguale else not negata
            continue
        if not uguale:
            if i >= len(parole):
                raise ValueError(f"dopo `{nome}` manca il valore (per esempio `{opzione.lunga} "
                                 f"{opzione.segnaposto().lower() or 'valore'}`)")
            valore = parole[i]
            i += 1
        if opzione.tipo == "lista":
            elemento = valore
            if opzione.predefinito and all(isinstance(x, int) and not isinstance(x, bool)
                                           for x in opzione.predefinito):
                elemento = _Opzione(opzione.nome, 0).converti(valore)
            if opzione.nome not in iniziate:       # la prima volta si sostituisce il predefinito
                valori[opzione.nome] = []
                iniziate.add(opzione.nome)
            valori[opzione.nome].append(elemento)
        else:
            valori[opzione.nome] = opzione.converti(valore)
    for o in opzioni:
        if o.obbligatoria and o.nome not in viste:
            raise ValueError(f"manca l'opzione obbligatoria `{o.lunga}`")
    return valori, altri, False


@funzione_libreria("aiuto_opzioni", interprete=True)
def aiuto_opzioni(interprete, opzioni, descrizione=""):
    """aiuto_opzioni(opzioni, descrizione = ""): il testo d'aiuto (in italiano) delle opzioni di `leggi_opzioni`.

    Esempio: `stampa(aiuto_opzioni({"nome": "Mondo", "volte": 1}, "Saluta qualcuno."))`.
    È lo stesso testo che `leggi_opzioni` mostra con `--aiuto`.
    """
    richiedi_testo(descrizione, "aiuto_opzioni", "descrizione")
    return _testo_aiuto(_opzioni_da(opzioni, "aiuto_opzioni"), descrizione, _nome_programma(interprete))


@funzione_libreria("leggi_opzioni", interprete=True)
def leggi_opzioni(interprete, opzioni, descrizione="", argomenti=None, esci_se_sbagliato=True):
    """leggi_opzioni(opzioni, descrizione = "", argomenti = nulla, esci_se_sbagliato = vero): legge le opzioni della riga di comando.

    `opzioni` è un dizionario nome -> valore predefinito; il tipo del predefinito decide
    il tipo dell'opzione (testo, intero, decimale, `vero`/`falso`, lista). Al posto del
    predefinito puoi dare un dizionario con `predefinito`, `aiuto`, `breve` (una lettera)
    e `obbligatoria`. Restituisce un dizionario con i valori, più `altri` (gli argomenti
    senza nome). Con `--aiuto` mostra l'aiuto in italiano e chiude il programma.
    Esempio: `variabile opz = leggi_opzioni({"nome": "Mondo", "volte": 1, "forte": falso})`
    e poi `leo saluta.leo --nome Anna --volte 3 --forte`.
    """
    lista = _opzioni_da(opzioni, "leggi_opzioni")
    richiedi_testo(descrizione, "leggi_opzioni", "descrizione")
    richiedi_logico(esci_se_sbagliato, "leggi_opzioni", "esci_se_sbagliato")
    if argomenti is None:
        parole = _argomenti_programma()
    else:
        if not isinstance(argomenti, list) or not all(isinstance(a, str) for a in argomenti):
            raise ErroreTipo("L'argomento `argomenti` di `leggi_opzioni` deve essere una lista di testi.",
                             suggerimento='Per esempio `argomenti = ["--nome", "Anna"]`.')
        parole = list(argomenti)
    programma = _nome_programma(interprete)
    try:
        valori, altri, aiuto = _analizza_opzioni(lista, parole)
    except ValueError as e:
        motivo = str(e)
        if esci_se_sbagliato:
            try:
                sys.stdout.flush()
            except Exception:  # noqa: BLE001
                pass
            sys.stderr.write(f"{programma}: {motivo}\nScrivi `leo {programma} --aiuto` per vedere le opzioni.\n")
            sys.stderr.flush()
            raise SystemExit(2) from None
        raise ErroreValore(f"Riga di comando sbagliata: {motivo}",
                           suggerimento="Con `--aiuto` si vedono le opzioni possibili.") from None
    if aiuto:
        _scrivi(interprete, _testo_aiuto(lista, descrizione, programma))
        if esci_se_sbagliato:
            raise SystemExit(0)
        valori["aiuto"] = True
    valori["altri"] = altri
    return valori


# ===========================================================================
# Registro degli eventi
# ===========================================================================

#: livello Leo -> (numero di logging, nome scritto nel file)
_LIVELLI = {
    "dettaglio": (10, "DETTAGLIO"),
    "informazione": (20, "INFO"),
    "avviso": (30, "AVVISO"),
    "errore": (40, "ERRORE"),
}
_SINONIMI_LIVELLI = {"debug": "dettaglio", "info": "informazione", "informazioni": "informazione",
                     "warning": "avviso", "avvisi": "avviso", "error": "errore", "errori": "errore",
                     "dettagli": "dettaglio"}
_REGISTRI: dict[str, "Registro"] = {}
_NUMERI_REGISTRI = itertools.count(1)
_BLOCCO_REGISTRI = threading.Lock()


def _livello(valore: Any, chi: str) -> str:
    richiedi_testo(valore, chi, "livello")
    t = valore.strip().lower()
    t = _SINONIMI_LIVELLI.get(t, t)
    if t not in _LIVELLI:
        raise ErroreValore(f"Il livello {mostra(valore)} non esiste.",
                           suggerimento="I livelli sono: \"dettaglio\", \"informazione\", \"avviso\", \"errore\".")
    return t


class Registro(OggettoLibreria):
    """Valore Leo di tipo ``registro``: scrive gli eventi del programma in un file."""

    NOME_TIPO_DANTE = "registro"
    SUGGERIMENTO_MODIFICA = "Per cambiare livello apri il registro con `apri_registro(percorso, livello = ...)`."

    def __init__(self, percorso: str, livello: str, dimensione: int, copie: int, schermo: bool,
                 interprete: Any) -> None:
        import logging
        from logging.handlers import RotatingFileHandler

        self.percorso = os.path.abspath(percorso)
        self.livello = livello
        self.schermo = schermo
        self.interprete = interprete
        self._logger = logging.getLogger(f"leo.registro.{next(_NUMERI_REGISTRI)}")
        self._logger.propagate = False
        self._logger.setLevel(_LIVELLI[livello][0])
        for vecchio in list(self._logger.handlers):
            self._logger.removeHandler(vecchio)
        cartella = os.path.dirname(self.percorso)
        try:
            if cartella:
                os.makedirs(cartella, exist_ok=True)
            self._gestore = RotatingFileHandler(self.percorso, maxBytes=dimensione, backupCount=copie,
                                                encoding="utf-8", delay=True)
        except OSError as e:
            raise ErroreFile(f"Non posso aprire il registro `{percorso}`: {e.strerror or e}.",
                             suggerimento="Controlla la cartella e i permessi.") from None
        self._gestore.setFormatter(logging.Formatter("%(asctime)s [%(nome_livello)s] %(message)s",
                                                     datefmt="%Y-%m-%d %H:%M:%S"))
        self._logger.addHandler(self._gestore)
        self.chiuso = False

    def scrivi_evento(self, livello: str, valori: tuple) -> None:
        if self.chiuso:
            raise ErroreValore(f"Il registro `{os.path.basename(self.percorso)}` è stato chiuso.",
                               suggerimento="Aprilo di nuovo con `apri_registro(...)`.")
        testo = " ".join(v if isinstance(v, str) else rappresenta(v) for v in valori)
        numero, nome = _LIVELLI[livello]
        try:
            self._logger.log(numero, testo, extra={"nome_livello": nome})
        except Exception as e:  # noqa: BLE001 - disco pieno, file bloccato...
            raise ErroreFile(f"Non riesco a scrivere nel registro `{self.percorso}`: {e}") from None
        if self.schermo and numero >= self._logger.level:
            _scrivi(self.interprete, f"[{nome}] {testo}\n")

    def testo_dante(self) -> str:
        return f"<registro {os.path.basename(self.percorso)}, livello {self.livello}>"


@funzione_libreria("apri_registro", interprete=True)
def apri_registro(interprete, percorso="programma.log", livello="informazione", dimensione_massima=1_000_000,
                  copie=3, schermo=False):
    """apri_registro(percorso = "programma.log", livello = "informazione", dimensione_massima = 1000000, copie = 3, schermo = falso): un registro degli eventi su file.

    Ogni riga ha data, ora e livello: `2026-10-05 14:30:00 [AVVISO] disco quasi pieno`.
    Metodi: `informazione(...)`, `avviso(...)`, `errore(...)`, `dettaglio(...)`,
    `ultime_righe(quante = 10)`, `chiudi()`. Le righe sotto `livello` non si scrivono.
    Quando il file supera `dimensione_massima` byte diventa `programma.log.1` e si
    ricomincia (si tengono `copie` file vecchi). Con `schermo = vero` le righe si stampano anche.
    Esempio: `variabile reg = apri_registro("gioco.log")` e poi `reg.avviso("vite finite:", vite)`.
    """
    richiedi_testo(percorso, "apri_registro", "percorso")
    if not percorso.strip():
        raise ErroreValore("Il percorso del registro è vuoto.", suggerimento='Per esempio `apri_registro("gioco.log")`.')
    livello = _livello(livello, "apri_registro")
    richiedi_intero(dimensione_massima, "apri_registro", "dimensione_massima")
    richiedi_intero(copie, "apri_registro", "copie")
    richiedi_logico(schermo, "apri_registro", "schermo")
    if dimensione_massima < 0 or copie < 0:
        raise ErroreValore("`dimensione_massima` e `copie` non possono essere negativi.",
                           suggerimento="Con `dimensione_massima = 0` il file non ruota mai.")
    chiave = os.path.normcase(os.path.abspath(percorso))
    with _BLOCCO_REGISTRI:
        vecchio = _REGISTRI.get(chiave)
        if vecchio is not None and not vecchio.chiuso:
            vecchio._chiudi()
        registro = Registro(percorso, livello, dimensione_massima, copie, schermo, interprete)
        _REGISTRI[chiave] = registro
    return registro


def _registro_chiudi(r: Registro) -> None:
    if not r.chiuso:
        r.chiuso = True
        r._logger.removeHandler(r._gestore)
        r._gestore.close()


Registro._chiudi = _registro_chiudi  # type: ignore[attr-defined]

proprieta(Registro, "percorso")(lambda r: r.percorso)
proprieta(Registro, "livello")(lambda r: r.livello)


def _metodo_livello(livello: str) -> Callable:
    def scrivi(registro, *valori):
        registro.scrivi_evento(livello, valori)
        return None

    scrivi.__doc__ = (f"registro.{livello}(valori...): scrive una riga di livello \"{livello}\" nel registro.\n\n"
                      f"Esempio: `reg.{livello}(\"punteggio:\", punti)`.")
    return scrivi


for _nome in ("informazione", "avviso", "errore", "dettaglio"):
    metodo_oggetto(Registro, _nome)(_metodo_livello(_nome))


@metodo_oggetto(Registro, "ultime_righe")
def _registro_ultime_righe(r, quante=10):
    """registro.ultime_righe(quante = 10): le ultime righe scritte nel file del registro (lista di testi)."""
    richiedi_intero(quante, "ultime_righe", "quante")
    try:
        r._gestore.flush()
        with open(r.percorso, "r", encoding="utf-8", errors="replace") as f:
            righe = f.read().splitlines()
    except FileNotFoundError:
        return []
    except OSError as e:
        raise ErroreFile(f"Non riesco a leggere il registro `{r.percorso}`: {e.strerror or e}.") from None
    return righe[-quante:] if quante > 0 else []


@metodo_oggetto(Registro, "chiudi")
def _registro_chiudi_metodo(r):
    """registro.chiudi(): chiude il file del registro (dopo non si può più scrivere)."""
    _registro_chiudi(r)
    return None


# ===========================================================================
# Parallelismo: processi veri, fili, limiti di tempo
# ===========================================================================

#: Quanti processi al massimo (Windows non ne aspetta piu' di 61 insieme).
MASSIMO_PROCESSI = 32
_VARIABILE_LAVORATORE = "LEO_PROCESSO_LAVORATORE"


def _dato_copiabile(valore: Any) -> bool:
    try:
        pickle.dumps(valore, protocol=pickle.HIGHEST_PROTOCOL)
    except Exception:  # noqa: BLE001 - qualunque cosa non copiabile
        return False
    return True


def _descrivi_funzione(f: Any) -> tuple | None:
    """La funzione come dati da spedire a un altro processo (None se non si può)."""
    if isinstance(f, FunzioneDante):
        descrizione = ("dante", f.nome, f.parametri, f.corpo, f.riga, f.colonna)
        return descrizione if _dato_copiabile(descrizione) else None
    if isinstance(f, FunzioneNativa):
        from .. import registro

        if registro.FUNZIONI.get(f.nome) is f:
            return ("libreria", f.nome)
    return None


def _istantanea(f: Any, interprete: Any) -> dict[str, tuple]:
    """Le variabili viste da ``f`` che si possono copiare in un altro processo."""
    visti: dict[str, tuple] = {}
    ambiente = getattr(f, "chiusura", None)
    predefinito = getattr(interprete, "predefinito", None)
    while ambiente is not None and ambiente is not predefinito:
        for nome, voce in list(ambiente.voci.items()):
            if nome in visti:
                continue
            valore = voce.valore
            if isinstance(valore, FunzioneDante):
                descrizione = _descrivi_funzione(valore)
                if descrizione is not None:
                    visti[nome] = ("funzione", descrizione)
            elif isinstance(valore, Richiamabile):
                continue
            elif getattr(valore, "E_VALORE_LIBRERIA", True) is False:
                continue            # controlli grafici
            elif _dato_copiabile(valore):
                visti[nome] = ("dato", valore)
        ambiente = ambiente.genitore
    return visti


def _comando_lavoratore() -> list[str] | None:
    """Come avviare un processo lavoratore (None = processi non disponibili): vedi
    :func:`leo.parallelo_processi.comando_lavoratore`, l'unico posto che lo decide."""
    from ..parallelo_processi import comando_lavoratore

    return comando_lavoratore()


def lavoratore_processo(argomenti: list[str]) -> int:
    """Corpo di un processo lavoratore: con ``--servizio`` quello dei lavori ``in parallelo`` e di
    ``mappa_in_parallelo`` (:func:`leo.parallelo_processi.servizio_lavoratore`); con
    ``[ingresso, uscita]`` la forma "a file" (un solo pacchetto letto da un file)."""
    if argomenti[:1] == ["--servizio"]:
        from ..parallelo_processi import servizio_lavoratore

        return servizio_lavoratore(argomenti[1:])
    os.environ[_VARIABILE_LAVORATORE] = "1"
    ingresso, uscita = argomenti[0], argomenti[1]
    # eseguibile senza console (Leo Studio.exe, programma compilato "a finestra"): sys.stdout
    # e' None anche se il padre ha passato un file; si scrive accanto al file dei risultati
    if sys.stdout is None:
        sys.stdout = open(uscita + ".stampa", "w", encoding="utf-8")  # noqa: SIM115
    if sys.stderr is None:
        sys.stderr = open(uscita + ".errori", "w", encoding="utf-8")  # noqa: SIM115
    with open(ingresso, "rb") as f:
        pacchetto = pickle.load(f)
    try:
        os.chdir(pacchetto["cartella"])
    except (OSError, KeyError, TypeError):
        pass
    from ..interprete import Interprete

    it = Interprete(nome_file=pacchetto.get("nome_file") or "<sorgente>",
                    ingresso=lambda domanda: None)

    def crea(descrizione: tuple) -> Any:
        if descrizione[0] == "libreria":
            from .. import registro

            registro.carica_libreria()
            return registro.FUNZIONI[descrizione[1]]
        _, nome, parametri, corpo, riga, colonna = descrizione
        funzione = FunzioneDante(nome, parametri, corpo, it.globale, riga, colonna)
        funzione.nome_file = pacchetto.get("nome_file")
        return funzione

    for nome, (tipo, valore) in pacchetto["globali"].items():
        try:
            it.globale.dichiara(nome, crea(valore) if tipo == "funzione" else valore)
        except ErroreDante:
            continue
    f = crea(pacchetto["funzione"])
    risultati = []
    for indice, elemento in pacchetto["elementi"]:
        try:
            risultato = it.chiama(f, [elemento])
            if not _dato_copiabile(risultato):
                raise ErroreTipo(f"`mappa_in_parallelo`: la funzione ha restituito {articolo(risultato)}, "
                                 "che non si può riportare al programma principale.",
                                 suggerimento="Restituisci numeri, testi, liste o dizionari.")
            risultati.append((indice, True, risultato))
        except ErroreDante as e:
            risultati.append((indice, False, (e.tipo, e.messaggio, e.suggerimento, e.riga, e.colonna)))
            break
        except RecursionError:
            risultati.append((indice, False, ("ErroreRicorsione", "Troppe chiamate annidate.", None, 0, 0)))
            break
    try:
        sys.stdout.flush()
    except Exception:  # noqa: BLE001
        pass
    temporaneo = uscita + ".tmp"
    with open(temporaneo, "wb") as f_uscita:
        pickle.dump(risultati, f_uscita, protocol=pickle.HIGHEST_PROTOCOL)
    os.replace(temporaneo, uscita)
    return 0


def _errore_da(dati: tuple) -> ErroreDante:
    """L'errore di un processo lavoratore, ricreato qui (stesso tipo, messaggio e riga)."""
    tipo, messaggio, suggerimento, riga, colonna = dati
    classe = TIPI_ERRORE.get(tipo, ErroreValore)
    return classe(messaggio, riga=riga or 0, colonna=colonna or 0, suggerimento=suggerimento)


class _Limite:
    """Limite di tempo per il codice eseguito dall'interprete ``it`` in QUESTO filo.

    Un filo sorvegliante, alla scadenza, accende la richiesta di arresto
    dell'interprete (``_ferma_richiesta``, la stessa del pulsante "Ferma" di Leo
    Studio): il codice Leo si ferma al prossimo ciclo o chiamata con
    ``SegnaleFermaProgramma``. Chi usa il limite lo cattura, controlla con
    :meth:`scaduto` che sia il suo e spegne di nuovo la richiesta. Finché il
    limite è attivo la richiesta si riaccende (così un limite più esterno
    scaduto nel frattempo non si perde)."""

    def __init__(self, interprete: Any, secondi: float) -> None:
        self.it = interprete
        self.fine = time.monotonic() + secondi
        self._fatto = threading.Event()
        self._acceso = False
        self._filo: threading.Thread | None = None

    def scaduto(self) -> bool:
        return time.monotonic() >= self.fine

    def _sorveglia(self) -> None:
        while not self._fatto.wait(min(0.01, max(0.0, self.fine - time.monotonic()))):
            if self.scaduto() and not getattr(self.it, "_ferma_richiesta", True):
                self._acceso = True
                self.it._ferma_richiesta = True

    def __enter__(self) -> "_Limite":
        self._filo = threading.Thread(target=self._sorveglia, name="leo-limite-di-tempo", daemon=True)
        self._filo.start()
        return self

    def __exit__(self, tipo: Any, errore: Any, traccia: Any) -> None:
        self._fatto.set()
        if self._filo is not None:
            self._filo.join()
        if self._acceso and (tipo is None or self.scaduto()):
            self.it._ferma_richiesta = False        # la richiesta era nostra: si spegne


def _con_limite(interprete: Any, secondi: float | None, azione: Callable[[], Any]) -> tuple[bool, Any]:
    """(finito in tempo, risultato) di ``azione()`` con al massimo ``secondi``."""
    if secondi is None or not hasattr(interprete, "_ferma_richiesta"):
        return True, azione()
    from ..errori import SegnaleFermaProgramma

    limite = _Limite(interprete, secondi)
    try:
        with limite:
            return True, azione()
    except SegnaleFermaProgramma:
        if not limite.scaduto():
            raise                                    # arresto vero (Ctrl+C, pulsante Ferma)
        return False, None


def _mappa_fili(interprete: Any, f: Any, dati: list, quanti: int, tempo_massimo: float | None) -> list:
    """Funzioni della libreria (che spesso aspettano la rete o il disco) su più fili."""
    from concurrent.futures import ThreadPoolExecutor, wait

    esecutore = ThreadPoolExecutor(max_workers=quanti, thread_name_prefix="leo-mappa")
    try:
        futuri = [esecutore.submit(f.chiama, interprete, [x], {}) for x in dati]
        limite = None if tempo_massimo is None else time.monotonic() + tempo_massimo
        while True:
            fatti, in_corso = wait(futuri, timeout=0.02)
            if not in_corso:
                break
            if _fermato(interprete):
                from ..errori import SegnaleFermaProgramma

                raise SegnaleFermaProgramma()
            if limite is not None and time.monotonic() >= limite:
                raise ErroreValore(
                    f"`mappa_in_parallelo` non ha finito entro {rappresenta(tempo_massimo)} secondi.",
                    suggerimento="Dai più tempo con `tempo_massimo`, oppure dividi il lavoro in parti più piccole.")
        return [futuro.result() for futuro in futuri]
    finally:
        esecutore.shutdown(wait=False, cancel_futures=True)


def _mappa_qui(interprete: Any, f: Any, dati: list, tempo_massimo: float | None) -> list:
    """Uno dopo l'altro nell'interprete del programma (veloce come `mappa`), con il limite di tempo."""
    finito, risultato = _con_limite(interprete, tempo_massimo,
                                    lambda: [chiama_funzione(interprete, f, [x]) for x in dati])
    if not finito:
        raise ErroreValore(f"`mappa_in_parallelo` non ha finito entro {rappresenta(tempo_massimo)} secondi.",
                           suggerimento="Dai più tempo con `tempo_massimo`, oppure dividi il lavoro in parti "
                                        "più piccole.")
    return risultato


#: Come ha lavorato l'ultima `mappa_in_parallelo` ("processi", "fili" o "uno_alla_volta"): per i test.
ULTIMO_MODO = [""]


@funzione_libreria("mappa_in_parallelo", interprete=True)
def mappa_in_parallelo(interprete, lista, funzione, quanti=None, tempo_massimo=None):
    """mappa_in_parallelo(lista, funzione, quanti = nulla, tempo_massimo = nulla): come `mappa`, ma usando tutti i processori.

    Divide la lista fra `quanti` processi (predefinito: uno per processore) che lavorano
    davvero insieme; il risultato ha lo stesso ordine della lista. Conviene per calcoli
    lunghi (ogni processo impiega un attimo a partire). La funzione vede una COPIA delle
    variabili del programma (numeri, testi, liste, dizionari e le tue funzioni): quello
    che cambia lì non torna indietro; `stampa` funziona, `chiedi` e le finestre no.
    Con `tempo_massimo` (secondi) si ferma tutto e c'è un errore se non ha finito.
    Esempio: `variabile primi = mappa_in_parallelo(1..40, funzione (n) restituisci conta_primi(n * 100000) fine)`.
    """
    dati = list(elementi(lista, "mappa_in_parallelo"))
    f = richiedi_funzione(funzione, "mappa_in_parallelo")
    if tempo_massimo is not None:
        richiedi_numero(tempo_massimo, "mappa_in_parallelo", "tempo_massimo")
        if not tempo_massimo > 0:
            raise ErroreValore("Il `tempo_massimo` di `mappa_in_parallelo` deve essere maggiore di zero.")
        tempo_massimo = float(min(tempo_massimo, 10 ** 9))
    if quanti is None:
        quanti = os.cpu_count() or 1
    else:
        richiedi_intero(quanti, "mappa_in_parallelo", "quanti")
        if quanti < 1:
            raise ErroreValore("`quanti` deve essere almeno 1.", suggerimento="Per esempio `quanti = 4`.")
    quanti = max(1, min(quanti, MASSIMO_PROCESSI, len(dati) or 1))
    if not dati:
        return []
    if quanti > 1 and not _e_lavoro_parallelo(interprete) and _comando_lavoratore() is not None:
        from ..parallelo_processi import MappaNonPossibile, mappa_nei_processi

        try:
            risultato = mappa_nei_processi(interprete, f, dati, quanti, tempo_massimo)
        except MappaNonPossibile:
            pass
        else:
            ULTIMO_MODO[0] = "processi"
            return risultato
    if quanti > 1 and isinstance(f, FunzioneNativa) and not f.vuole_interprete:
        ULTIMO_MODO[0] = "fili"
        return _mappa_fili(interprete, f, dati, quanti, tempo_massimo)
    # senza processi i fili non aiutano il codice Leo (Python ne esegue uno alla volta)
    ULTIMO_MODO[0] = "uno_alla_volta"
    return _mappa_qui(interprete, f, dati, tempo_massimo)


@funzione_libreria("con_limite_di_tempo", interprete=True)
def con_limite_di_tempo(interprete, funzione, secondi, argomenti=None, predefinito=_NON_DATO):
    """con_limite_di_tempo(funzione, secondi, argomenti = [], predefinito): chiama la funzione, ma la ferma se ci mette più di `secondi`.

    Se la funzione finisce in tempo dà il suo risultato; altrimenti la interrompe e dà un
    `ErroreValore` (che puoi catturare con `prova`), oppure il valore `predefinito` se l'hai dato.
    Esempio: `variabile r = con_limite_di_tempo(cerca_soluzione, 5, predefinito = nulla)`.
    """
    f = richiedi_funzione(funzione, "con_limite_di_tempo")
    richiedi_numero(secondi, "con_limite_di_tempo", "secondi")
    if not secondi > 0 or secondi == math.inf:
        raise ErroreValore("I `secondi` di `con_limite_di_tempo` devono essere un numero maggiore di zero.",
                           suggerimento="Per esempio `con_limite_di_tempo(f, 2.5)`.")
    valori = [] if argomenti is None else argomenti
    if not isinstance(valori, list):
        raise ErroreTipo(f"`argomenti` di `con_limite_di_tempo` deve essere una lista, non {articolo(valori)}.",
                         suggerimento="Per esempio `argomenti = [10, 20]`.")
    finito, risultato = _con_limite(interprete, float(min(secondi, 10 ** 9)),
                                    lambda: chiama_funzione(interprete, f, list(valori)))
    if finito:
        return risultato
    if predefinito is not _NON_DATO:
        return predefinito
    raise ErroreValore(f"`{_nome_funzione(f)}` non ha finito entro {rappresenta(secondi)} secondi.",
                       suggerimento="Dai più tempo, oppure usa `predefinito = ...` per avere un valore quando "
                                    "il tempo scade.")

@funzione_libreria("riprova", interprete=True)
def riprova(interprete, funzione, tentativi=3, attesa=1, moltiplica=2):
    """riprova(funzione, tentativi = 3, attesa = 1, moltiplica = 2): chiama la funzione e, se dà un errore, riprova.

    Tra un tentativo e l'altro aspetta `attesa` secondi, poi ogni volta `moltiplica` volte
    di più (1, 2, 4 secondi...). Restituisce il risultato del primo tentativo riuscito;
    se falliscono tutti, ripete l'ultimo errore. Utile per Internet e file condivisi.
    Esempio: `variabile pagina = riprova(funzione () restituisci scarica_testo(indirizzo) fine, tentativi = 5)`.
    """
    f = richiedi_funzione(funzione, "riprova")
    richiedi_intero(tentativi, "riprova", "tentativi")
    richiedi_numero(attesa, "riprova", "attesa")
    richiedi_numero(moltiplica, "riprova", "moltiplica")
    if tentativi < 1:
        raise ErroreValore("`tentativi` deve essere almeno 1.")
    if tentativi > 1000:
        raise ErroreValore("`tentativi` può essere al massimo 1000.",
                           suggerimento="Per riprovare per sempre usa un ciclo `mentre` con `prova`.")
    if attesa < 0 or moltiplica < 1 or attesa != attesa:
        raise ErroreValore("`attesa` non può essere negativa e `moltiplica` deve essere almeno 1.")
    pausa = float(min(attesa, 10 ** 9))
    for numero in range(1, tentativi + 1):
        try:
            return chiama_funzione(interprete, f, [])
        except ErroreDante as e:
            if not e.catturabile or numero == tentativi:
                raise
        _pausa(interprete, min(pausa, 3600.0))
        pausa = min(pausa * float(min(moltiplica, 10 ** 6)), 10.0 ** 9)
    return None  # pragma: no cover - non si arriva qui


def _chiave(valore: Any) -> Any:
    """Una chiave confrontabile per ``ricorda_risultati`` (anche per liste e dizionari)."""
    if isinstance(valore, list):
        return ("lista", tuple(_chiave(v) for v in valore))
    if isinstance(valore, dict):
        return ("dizionario", tuple((_chiave(k), _chiave(v)) for k, v in valore.items()))
    try:
        hash(valore)
    except TypeError:
        return ("altro", type(valore).__name__, rappresenta(valore, dentro=True))
    return (type(valore).__name__, valore)


def _copia(valore: Any) -> Any:
    if isinstance(valore, list):
        return [_copia(v) for v in valore]
    if isinstance(valore, dict):
        return {k: _copia(v) for k, v in valore.items()}
    return valore


@funzione_libreria("ricorda_risultati")
def ricorda_risultati(funzione, massimo=1000):
    """ricorda_risultati(funzione, massimo = 1000): una nuova funzione che ricorda i risultati già calcolati.

    La seconda volta che la chiami con gli stessi argomenti risponde subito, senza
    rifare il calcolo (utile per funzioni lente o ricorsive). Ricorda al massimo
    `massimo` risultati (i più vecchi si dimenticano). Gli errori non si ricordano.
    Se le dai una funzione con nome, anche quel nome (e le chiamate ricorsive) da lì in
    poi ricordano i risultati.
    Esempio: dopo aver scritto
    `funzione fib(n)
    se n < 2 allora restituisci n fine
    restituisci fib(n - 1) + fib(n - 2)
fine`
    chiama `ricorda_risultati(fib)`.
    """
    f = richiedi_funzione(funzione, "ricorda_risultati")
    richiedi_intero(massimo, "ricorda_risultati", "massimo")
    if massimo < 1:
        raise ErroreValore("`massimo` deve essere almeno 1.")
    from collections import OrderedDict

    memoria: "OrderedDict[Any, Any]" = OrderedDict()
    blocco = threading.Lock()

    def ricordata(interprete, *argomenti, **per_nome):
        chiave = (_chiave(list(argomenti)), _chiave(dict(sorted(per_nome.items()))))
        with blocco:
            if chiave in memoria:
                memoria.move_to_end(chiave)
                return _copia(memoria[chiave])
        chiama = getattr(interprete, "chiama", None)
        if chiama is not None:
            risultato = chiama(f, list(argomenti), per_nome)
        else:  # pragma: no cover - interpreti finti
            risultato = f.chiama(interprete, list(argomenti), per_nome)
        with blocco:
            memoria[chiave] = _copia(risultato)
            while len(memoria) > massimo:
                memoria.popitem(last=False)
        return risultato

    nome = _nome_funzione(f, "funzione_ricordata")
    ricordata.__doc__ = f"{nome}(...): `{nome}` che ricorda i risultati (creata con `ricorda_risultati`)."
    nuova = FunzioneNativa(nome, ricordata, vuole_interprete=True)
    # `funzione fib(n) ... fine` e poi `ricorda_risultati(fib)`: da qui in poi il nome `fib`
    # (anche nelle chiamate ricorsive dentro fib) usa la versione che ricorda
    ambiente = getattr(f, "chiusura", None) if isinstance(f, FunzioneDante) else None
    while ambiente is not None:
        voce = ambiente.voci.get(f.nome)
        if voce is not None:
            if voce.valore is f:
                voce.valore = nuova
            break
        ambiente = ambiente.genitore
    return nuova


@funzione_libreria("confronta_tempi", interprete=True)
def confronta_tempi(interprete, funzioni, ripetizioni=5, mostra_risultato=True):
    """confronta_tempi(funzioni, ripetizioni = 5, mostra_risultato = vero): misura quale versione è più veloce.

    `funzioni` è un dizionario nome -> funzione (senza argomenti), oppure una lista di
    funzioni. Ognuna si esegue `ripetizioni` volte; il risultato è un dizionario nome -> secondi
    (il tempo medio). Con `mostra_risultato` stampa anche la classifica.
    Esempio: `confronta_tempi({"ciclo": versione1, "somma": versione2})`.
    """
    if isinstance(funzioni, list):
        coppie = []
        for i, f in enumerate(funzioni, 1):
            nome = _nome_funzione(f, f"funzione {i}")
            if any(nome == n for n, _ in coppie):
                nome = f"{nome} ({i})"
            coppie.append((nome, f))
    elif isinstance(funzioni, dict):
        coppie = [(k if isinstance(k, str) else rappresenta(k), f) for k, f in funzioni.items()]
    else:
        raise ErroreTipo(f"`confronta_tempi` vuole un dizionario nome -> funzione (o una lista di funzioni), "
                         f"non {articolo(funzioni)}.",
                         suggerimento='Per esempio `confronta_tempi({"prima": f1, "seconda": f2})`.')
    if not coppie:
        raise ErroreValore("`confronta_tempi` ha bisogno di almeno una funzione.")
    richiedi_intero(ripetizioni, "confronta_tempi", "ripetizioni")
    richiedi_logico(mostra_risultato, "confronta_tempi", "mostra_risultato")
    if not 1 <= ripetizioni <= 1_000_000:
        raise ErroreValore("`ripetizioni` deve essere fra 1 e 1000000.")
    tempi: dict[str, float] = {}
    for nome, f in coppie:
        richiedi_funzione(f, "confronta_tempi", "funzioni")
        totale = 0.0
        for _ in range(ripetizioni):
            inizio = time.perf_counter()
            chiama_funzione(interprete, f, [])
            totale += time.perf_counter() - inizio
        tempi[nome] = round(totale / ripetizioni, 6)
    if mostra_risultato:
        ordinati = sorted(tempi.items(), key=lambda c: c[1])
        migliore = ordinati[0][1]
        larghezza = max(len(n) for n in tempi)
        for posto, (nome, t) in enumerate(ordinati):
            if posto == 0:
                nota = "la più veloce" if len(ordinati) > 1 else ""
            elif migliore > 0:
                nota = f"{_numero_it(t / migliore, 1)} volte più lenta"
            else:
                nota = "più lenta"
            _scrivi(interprete, f"  {nome.ljust(larghezza)}  {_numero_it(t, 6)} s  {nota}".rstrip() + "\n")
    return tempi


# ===========================================================================
# Coda di lavori
# ===========================================================================

class Coda(Canale):
    """Valore Leo di tipo ``coda``: passa valori fra parti del programma (anche in parallelo).

    È un canale (:class:`leo.parallelo.Canale`) con i nomi della coda: ``metti`` per
    ``invia``, ``prendi`` (che dà ``nulla`` invece di un errore) per ``ricevi``. Come
    ogni canale passa copie dei valori e funziona anche fra processi."""

    NOME_TIPO_DANTE = "coda"
    nome = "coda"
    tipo_controllo = "coda"
    TIPO_REMOTO = "coda"
    _METODI: dict[str, FunzioneNativa] = {}
    _PROPRIETA_CODA: dict[str, Callable[[Any], Any]] = {}

    def leggi(self, proprieta_nome: str) -> Any:
        lettore = self._PROPRIETA_CODA.get(proprieta_nome)
        if lettore is not None:
            return lettore(self)
        from ..errori import ErroreNome

        raise ErroreNome(f"Un valore di tipo `coda` non ha `{proprieta_nome}`.",
                         suggerimento="Puoi usare: `lunghezza`, `vuota`, `chiusa`, `metti()`, `prendi()`, "
                                      "`chiudi()`.", nome=proprieta_nome)

    def elenco_proprieta(self) -> list[str]:
        return sorted(self._PROPRIETA_CODA)

    def testo_dante(self) -> str:
        return f"<coda con {self.lunghezza()} valori{', chiusa' if self.chiuso() else ''}>"


class CodaRemota(CanaleRemoto):
    """Una coda del programma principale vista da un processo lavoratore."""

    NOME_TIPO_DANTE = "coda"
    nome = "coda"
    tipo_controllo = "coda"
    TIPO_REMOTO = "coda"
    _METODI = Coda._METODI
    _PROPRIETA_CODA = Coda._PROPRIETA_CODA
    leggi = Coda.leggi
    elenco_proprieta = Coda.elenco_proprieta


TIPI_REMOTI["coda"] = CodaRemota
CLASSI_CON_METODI["Coda"] = Coda


@funzione_libreria("crea_coda")
def crea_coda(massimo=0):
    """crea_coda(massimo = 0): una coda per passare valori fra le parti del programma, anche fra lavori `in parallelo`.

    Metodi: `metti(valore)`, `prendi(secondi = nulla)` (aspetta un valore; dà `nulla` se il
    tempo scade o se la coda è chiusa e vuota), `chiudi()`. Proprietà: `lunghezza`,
    `vuota`, `chiusa`. Con `massimo` > 0 `metti` aspetta quando la coda è piena.
    È un `canale()` con altri nomi: passa copie dei valori, anche fra processi.
    Esempio: `variabile lavori = crea_coda()` poi `lavori.metti("foto1.png")` e in un
    lavoro in parallelo `variabile x = lavori.prendi()`.
    """
    richiedi_intero(massimo, "crea_coda", "massimo")
    if massimo < 0:
        raise ErroreValore("`massimo` non può essere negativo (0 vuol dire senza limite).")
    return Coda(massimo)


Coda._PROPRIETA_CODA["lunghezza"] = lambda c: c.lunghezza()
Coda._PROPRIETA_CODA["vuota"] = lambda c: c.lunghezza() == 0
Coda._PROPRIETA_CODA["chiusa"] = lambda c: c.chiuso()


def _metodo_coda(nome: str, *, interprete: bool = False) -> Callable:
    def decora(f: Callable) -> Callable:
        Coda._METODI[nome] = FunzioneNativa(nome, f, vuole_interprete=interprete, e_metodo=True)
        return f

    return decora


@_metodo_coda("metti", interprete=True)
def _coda_metti(interprete, c, valore):
    """coda.metti(valore): aggiunge un valore in fondo alla coda."""
    if not isinstance(c, CanaleRemoto):
        valore = copia_messaggio(valore)
    try:
        c.invia_dato(valore, lambda: _fermato(interprete))
    except CanaleChiuso:
        raise ErroreValore("La coda è chiusa: non si possono mettere altri valori.",
                           suggerimento="Chiudi la coda solo quando hai finito di mettere valori.") from None
    return None


@_metodo_coda("prendi", interprete=True)
def _coda_prendi(interprete, c, secondi=None):
    """coda.prendi(secondi = nulla): toglie e restituisce il primo valore, aspettando se la coda è vuota.

    Con `secondi` aspetta al massimo quel tempo; se scade (o se la coda è chiusa e vuota) dà `nulla`.
    """
    if secondi is not None:
        richiedi_numero(secondi, "prendi", "secondi")
        if secondi < 0 or secondi != secondi:
            raise ErroreValore("I `secondi` di `prendi` non possono essere negativi.")
    limite = None if secondi is None else time.monotonic() + float(min(secondi, 10 ** 9))
    try:
        return c.prendi_dato(lambda: _fermato(interprete), limite)
    except (CanaleChiuso, TempoScaduto):
        return None


@_metodo_coda("chiudi")
def _coda_chiudi(c):
    """coda.chiudi(): niente più valori nuovi; chi aspetta con `prendi()` riceve `nulla` quando la coda è vuota."""
    c.chiudi()
    return None


# ===========================================================================
# Orari: ogni giorno, ogni settimana
# ===========================================================================

_GIORNI = ["lunedi", "martedi", "mercoledi", "giovedi", "venerdi", "sabato", "domenica"]
#: Controllo dell'orologio al massimo ogni minuto (sospensione del computer, ora legale).
_PASSO_OROLOGIO = 60.0


def _senza_accenti(testo: str) -> str:
    import unicodedata

    return "".join(c for c in unicodedata.normalize("NFD", testo) if unicodedata.category(c) != "Mn")


def _orario(valore: Any, chi: str) -> tuple[int, int, int]:
    richiedi_testo(valore, chi, "orario")
    m = re.fullmatch(r"\s*(\d{1,2})(?:[:.](\d{2}))?(?:[:.](\d{2}))?\s*", valore)
    if m:
        ore, minuti, secondi = int(m.group(1)), int(m.group(2) or 0), int(m.group(3) or 0)
        if ore < 24 and minuti < 60 and secondi < 60:
            return ore, minuti, secondi
    raise ErroreValore(f"L'orario {mostra(valore)} non è valido.",
                       suggerimento='Scrivilo come ore e minuti, per esempio "08:30" o "21:00".')


def _giorni(valore: Any, chi: str) -> list[int]:
    valori = valore if isinstance(valore, list) else [valore]
    if not valori:
        raise ErroreValore(f"La lista dei giorni di `{chi}` è vuota.")
    risultato = []
    for v in valori:
        richiedi_testo(v, chi, "giorno")
        t = _senza_accenti(v.strip().lower())
        trovati = [i for i, g in enumerate(_GIORNI) if g == t or (len(t) >= 3 and g.startswith(t))]
        if len(trovati) != 1:
            simili = difflib.get_close_matches(t, _GIORNI, n=1, cutoff=0.5)
            raise ErroreValore(f"{mostra(v)} non è un giorno della settimana.",
                               suggerimento=f"Forse intendevi \"{simili[0]}\"?" if simili else
                               "Scrivi per esempio \"lunedì\" o \"sabato\".")
        risultato.append(trovati[0])
    return sorted(set(risultato))


def _prossima(orario: tuple[int, int, int], giorni: list[int] | None,
              dopo: datetime.datetime) -> datetime.datetime:
    ore, minuti, secondi = orario
    base = dopo.replace(hour=ore, minute=minuti, second=secondi, microsecond=0)
    for spostamento in range(0, 8):
        candidata = base + datetime.timedelta(days=spostamento)
        if candidata <= dopo:
            continue
        if giorni is None or candidata.weekday() in giorni:
            return candidata
    return base + datetime.timedelta(days=7)  # pragma: no cover


def _pianifica_orario(interprete: Any, f: Any, orario: tuple[int, int, int], giorni: list[int] | None,
                      chi: str) -> Any:
    if _e_lavoro_parallelo(interprete):
        raise ErroreValore(f"Dentro un lavoro `in parallelo` non si usa `{chi}`.",
                           suggerimento="Scrivilo nel programma principale.")
    temporizzatori = getattr(interprete, "temporizzatori", None)
    if temporizzatori is None:
        raise ErroreValore(f"`{chi}` qui non è disponibile.")
    stato = {"quando": _prossima(orario, giorni, datetime.datetime.now())}

    def controlla(it):
        adesso = datetime.datetime.now()
        if adesso >= stato["quando"]:
            stato["quando"] = _prossima(orario, giorni, adesso)
            programma(it)                  # prima si ripianifica: un errore non ferma i prossimi giri
            chiama_funzione(it, f, [])
        else:
            programma(it)
        return None

    nativa = FunzioneNativa(f"<{chi}>", controlla, vuole_interprete=True)

    def programma(it):
        rimasto = (stato["quando"] - datetime.datetime.now()).total_seconds()
        it.temporizzatori.pianifica(max(0.0, min(rimasto, _PASSO_OROLOGIO)), nativa, False)

    programma(interprete)
    from .date import DataDante

    return DataDante(stato["quando"])


@funzione_libreria("ogni_giorno_alle", interprete=True)
def ogni_giorno_alle(interprete, orario, funzione):
    """ogni_giorno_alle(orario, funzione): chiama la funzione (senza argomenti) ogni giorno all'orario dato, finché il programma è aperto.

    Restituisce la data e l'ora della prima volta. Il programma resta aperto ad
    aspettare (come con `ogni`); `ferma_temporizzatori()` lo ferma.
    Esempio: `ogni_giorno_alle("08:30", funzione () stampa("Buongiorno!") fine)`.
    """
    f = richiedi_funzione(funzione, "ogni_giorno_alle")
    return _pianifica_orario(interprete, f, _orario(orario, "ogni_giorno_alle"), None, "ogni_giorno_alle")


@funzione_libreria("ogni_settimana", interprete=True)
def ogni_settimana(interprete, giorno, orario, funzione):
    """ogni_settimana(giorno, orario, funzione): chiama la funzione ogni settimana nel giorno (o nei giorni) e all'orario dati.

    `giorno` è un testo ("lunedì", "sab"...) o una lista di giorni. Restituisce la data della
    prima volta; il programma resta aperto ad aspettare, finché non chiami `ferma_temporizzatori()`.
    Esempio: `ogni_settimana("lunedì", "09:00", manda_riepilogo)` oppure
    `ogni_settimana(["sabato", "domenica"], "10:00", sveglia)`.
    """
    giorni = _giorni(giorno, "ogni_settimana")
    f = richiedi_funzione(funzione, "ogni_settimana")
    return _pianifica_orario(interprete, f, _orario(orario, "ogni_settimana"), giorni, "ogni_settimana")


# ===========================================================================
# Configurazione e stato
# ===========================================================================

def _formato_file(percorso: str) -> str:
    estensione = os.path.splitext(percorso)[1].lower()
    if estensione in (".ini", ".cfg", ".conf"):
        return "ini"
    if estensione == ".toml":
        return "toml"
    return "json"


def _controlla_percorso(percorso: Any, chi: str) -> str:
    richiedi_testo(percorso, chi, "percorso")
    if not percorso.strip() or "\0" in percorso:
        raise ErroreValore(f"Il percorso di `{chi}` non è valido.",
                           suggerimento=f'Per esempio `{chi}("impostazioni.json", ...)`.')
    return percorso


def _scrivi_sicuro(percorso: str, testo: str, chi: str) -> None:
    """Scrive in un file temporaneo e poi lo sostituisce: il file non resta mai a metà."""
    cartella = os.path.dirname(os.path.abspath(percorso))
    try:
        os.makedirs(cartella, exist_ok=True)
        descrittore, temporaneo = tempfile.mkstemp(prefix=".leo_", suffix=".tmp", dir=cartella)
        with os.fdopen(descrittore, "w", encoding="utf-8", newline="\n") as f:
            f.write(testo)
            f.flush()
            try:
                os.fsync(f.fileno())
            except OSError:
                pass
        for tentativo in range(10):
            try:
                os.replace(temporaneo, percorso)
                break
            except PermissionError:          # Windows: antivirus o indicizzazione tengono il file
                if tentativo == 9:
                    raise
                time.sleep(0.05 * (tentativo + 1))
    except OSError as e:
        try:
            os.remove(temporaneo)  # type: ignore[possibly-undefined]
        except Exception:  # noqa: BLE001
            pass
        raise ErroreFile(f"`{chi}` non riesce a scrivere `{percorso}`: {e.strerror or e}.",
                         suggerimento="Controlla che la cartella esista e che il file non sia aperto altrove.") from None


def _leggi_config_file(percorso: str) -> dict:
    formato = _formato_file(percorso)
    if formato == "ini":
        from .formati import leggi_ini

        sezioni = leggi_ini(percorso)
        risultato = dict(sezioni.pop("generale", {}) or {})
        risultato.update(sezioni)
        return risultato
    if formato == "toml":
        from .formati import leggi_toml

        return leggi_toml(percorso)
    try:
        with open(percorso, "r", encoding="utf-8-sig") as f:
            dati = json.load(f)
    except json.JSONDecodeError as e:
        raise ErroreFile(f"Il file `{percorso}` è rovinato: errore alla riga {e.lineno}, colonna {e.colno}.",
                         suggerimento="Controlla virgole e virgolette, oppure cancellalo: si ricrea con i "
                                      "valori predefiniti.") from None
    except (UnicodeDecodeError, ValueError):
        raise ErroreFile(f"Il file `{percorso}` non è un file di configurazione valido (sembra binario).",
                         suggerimento="Controlla che sia un file .json, .ini o .toml di testo.") from None
    except OSError as e:
        raise ErroreFile(f"Non riesco a leggere `{percorso}`: {e.strerror or e}.") from None
    if not isinstance(dati, dict):
        raise ErroreFile(f"Il file `{percorso}` deve contenere un dizionario (fra graffe {{ }}).")
    return dati


def _come_predefinito(valore: Any, predefinito: Any, chiave: str, percorso: str) -> Any:
    """Porta ``valore`` (letto dal file) al tipo del ``predefinito``."""
    if predefinito is None or valore is None:
        return valore
    if isinstance(predefinito, dict):
        if not isinstance(valore, dict):
            raise ErroreValore(f"In `{percorso}` la voce `{chiave}` deve essere un gruppo di impostazioni.",
                               suggerimento="Correggi il file o cancellalo per ricrearlo.")
        return _unisci_config(predefinito, valore, percorso, chiave + ".")
    if isinstance(predefinito, bool):
        if isinstance(valore, bool):
            return valore
        if isinstance(valore, str) and valore.strip().lower() in ("si", "sì", "vero", "true", "1", "yes", "on"):
            return True
        if isinstance(valore, str) and valore.strip().lower() in ("no", "falso", "false", "0", "off"):
            return False
    elif isinstance(predefinito, int):
        if isinstance(valore, int) and not isinstance(valore, bool):
            return valore
        if isinstance(valore, float) and valore.is_integer():
            return int(valore)
        if isinstance(valore, str):
            try:
                return int(valore.strip())
            except ValueError:
                pass
    elif isinstance(predefinito, float):
        if isinstance(valore, (int, float)) and not isinstance(valore, bool):
            return float(valore)
        if isinstance(valore, str):
            try:
                return float(valore.strip().replace(",", "."))
            except ValueError:
                pass
    elif isinstance(predefinito, str):
        return valore if isinstance(valore, str) else rappresenta(valore)
    elif isinstance(predefinito, list):
        if isinstance(valore, list):
            return valore
    else:
        return valore
    raise ErroreValore(f"In `{percorso}` la voce `{chiave}` vale {mostra(valore)}, ma dovrebbe essere "
                       f"{articolo(predefinito)} (come {mostra(predefinito)}).",
                       suggerimento="Correggi il file, oppure cancella la riga per usare il valore predefinito.")


def _unisci_config(predefiniti: dict, dal_file: dict, percorso: str, prefisso: str = "") -> dict:
    risultato = {}
    for chiave, predefinito in predefiniti.items():
        if chiave in dal_file:
            risultato[chiave] = _come_predefinito(dal_file[chiave], predefinito, prefisso + str(chiave), percorso)
        else:
            risultato[chiave] = _copia(predefinito)
    for chiave, valore in dal_file.items():
        if chiave not in risultato:
            risultato[chiave] = valore
    return risultato


def _scrivi_config(percorso: str, dati: dict, chi: str) -> None:
    formato = _formato_file(percorso)
    if formato == "json":
        try:
            testo = json.dumps(dati, ensure_ascii=False, indent=2) + "\n"
        except (TypeError, ValueError):
            raise ErroreTipo(f"`{chi}`: la configurazione può contenere solo testi, numeri, `vero`/`falso`, "
                             "`nulla`, liste e dizionari.") from None
        _scrivi_sicuro(percorso, testo, chi)
        return
    if formato == "ini":
        from .formati import scrivi_ini

        sezioni: dict = {}
        generale = {k: v for k, v in dati.items() if not isinstance(v, dict)}
        if generale:
            sezioni["generale"] = generale
        sezioni.update({k: v for k, v in dati.items() if isinstance(v, dict)})
        scrivi_ini(percorso, sezioni)
        return
    from .formati import scrivi_toml

    scrivi_toml(percorso, dati)


@funzione_libreria("leggi_configurazione")
def leggi_configurazione(percorso, predefiniti=None, crea=True):
    """leggi_configurazione(percorso, predefiniti = {}, crea = vero): le impostazioni del programma lette da un file, con i valori predefiniti.

    Il formato dipende dall'estensione: .json, .ini (o .cfg) oppure .toml. Le voci che
    mancano nel file prendono il valore predefinito, e i valori si portano al tipo del
    predefinito ("3" diventa 3, "sì" diventa `vero`). Se il file non c'è e `crea` è
    vero, lo scrive con i predefiniti (così l'utente sa cosa può cambiare).
    Esempio: `variabile conf = leggi_configurazione("gioco.json", {"volume": 80, "nome": "Leo"})`.
    """
    _controlla_percorso(percorso, "leggi_configurazione")
    predefiniti = {} if predefiniti is None else predefiniti
    if not isinstance(predefiniti, dict):
        raise ErroreTipo(f"`predefiniti` di `leggi_configurazione` deve essere un dizionario, "
                         f"non {articolo(predefiniti)}.", suggerimento='Per esempio `{"volume": 80}`.')
    richiedi_logico(crea, "leggi_configurazione", "crea")
    if not os.path.exists(percorso):
        if crea and predefiniti:
            _scrivi_config(percorso, predefiniti, "leggi_configurazione")
        return _copia(predefiniti)
    return _unisci_config(predefiniti, _leggi_config_file(percorso), percorso)


@funzione_libreria("salva_configurazione")
def salva_configurazione(percorso, impostazioni):
    """salva_configurazione(percorso, impostazioni): salva il dizionario delle impostazioni nel file (.json, .ini o .toml).

    Il file si scrive in modo sicuro: se il computer si spegne a metà resta quello vecchio.
    Esempio: `conf["volume"] = 50` e poi `salva_configurazione("gioco.json", conf)`.
    """
    _controlla_percorso(percorso, "salva_configurazione")
    if not isinstance(impostazioni, dict):
        raise ErroreTipo(f"Le `impostazioni` di `salva_configurazione` devono essere un dizionario, "
                         f"non {articolo(impostazioni)}.")
    _scrivi_config(percorso, impostazioni, "salva_configurazione")
    return None


def _in_json(valore: Any, chi: str) -> Any:
    from .date import DataDante

    if valore is None or isinstance(valore, (bool, str)):
        return valore
    if isinstance(valore, int):
        return valore
    if isinstance(valore, float):
        if valore != valore or valore in (math.inf, -math.inf):
            return {"__leo__": "decimale", "valore": repr(valore)}
        return valore
    if isinstance(valore, list):
        return [_in_json(v, chi) for v in valore]
    if isinstance(valore, dict):
        if all(isinstance(k, str) and k != "__leo__" for k in valore):
            return {k: _in_json(v, chi) for k, v in valore.items()}
        return {"__leo__": "dizionario", "coppie": [[_in_json(k, chi), _in_json(v, chi)] for k, v in valore.items()]}
    if isinstance(valore, range):
        return {"__leo__": "intervallo", "da": valore.start, "a": valore.stop, "passo": valore.step}
    if isinstance(valore, DataDante):
        return {"__leo__": "data", "valore": valore.valore.isoformat()}
    raise ErroreTipo(f"`{chi}` non sa salvare {articolo(valore)}.",
                     suggerimento="Si salvano numeri, testi, `vero`/`falso`, `nulla`, liste, dizionari, "
                                  "intervalli e date.")


def _da_json(valore: Any) -> Any:
    if isinstance(valore, list):
        return [_da_json(v) for v in valore]
    if isinstance(valore, dict):
        tipo = valore.get("__leo__")
        if tipo == "decimale":
            return float(valore["valore"])
        if tipo == "dizionario":
            return {_chiave_json(_da_json(k)): _da_json(v) for k, v in valore["coppie"]}
        if tipo == "intervallo":
            return range(valore["da"], valore["a"], valore["passo"])
        if tipo == "data":
            from .date import DataDante

            return DataDante(datetime.datetime.fromisoformat(valore["valore"]))
        return {k: _da_json(v) for k, v in valore.items()}
    return valore


def _chiave_json(k: Any) -> Any:
    return tuple(k) if isinstance(k, list) else k


def _file_stato(nome: Any, chi: str) -> str:
    richiedi_testo(nome, chi, "nome")
    if not nome.strip() or "\0" in nome:
        raise ErroreValore(f"Il nome dello stato per `{chi}` è vuoto.", suggerimento='Per esempio "partita".')
    if os.path.splitext(nome)[1] or "/" in nome or "\\" in nome:
        return nome
    return nome + ".json"


@funzione_libreria("salva_stato")
def salva_stato(valore, nome="stato"):
    """salva_stato(valore, nome = "stato"): salva un valore (liste, dizionari, date...) nel file `nome.json` per ritrovarlo alla prossima apertura.

    La scrittura è sicura (mai un file a metà) e si tiene una copia di riserva
    (`nome.json.bak`) della versione precedente. Si legge con `carica_stato`.
    Esempio: `salva_stato({"livello": 3, "punti": 1200}, "partita")`.
    """
    percorso = _file_stato(nome, "salva_stato")
    testo = json.dumps({"leo_stato": 1, "valore": _in_json(valore, "salva_stato")}, ensure_ascii=False, indent=1)
    if os.path.isfile(percorso):
        try:
            import shutil

            shutil.copyfile(percorso, percorso + ".bak")
        except OSError:
            pass
    _scrivi_sicuro(percorso, testo + "\n", "salva_stato")
    return None


@funzione_libreria("carica_stato")
def carica_stato(nome="stato", predefinito=None):
    """carica_stato(nome = "stato", predefinito = nulla): il valore salvato con `salva_stato`, oppure `predefinito` se non c'è ancora.

    Se il file è rovinato si usa la copia di riserva `.bak`.
    Esempio: `variabile partita = carica_stato("partita", {"livello": 1, "punti": 0})`.
    """
    percorso = _file_stato(nome, "carica_stato")
    for candidato in (percorso, percorso + ".bak"):
        if not os.path.isfile(candidato):
            continue
        try:
            with open(candidato, "r", encoding="utf-8-sig") as f:
                dati = json.load(f)
            if isinstance(dati, dict) and "leo_stato" in dati:
                return _da_json(dati.get("valore"))
            return _da_json(dati)
        except (OSError, ValueError, KeyError, TypeError):
            continue
    if os.path.isfile(percorso):
        raise ErroreFile(f"Il file dello stato `{percorso}` è rovinato e non c'è una copia di riserva.",
                         suggerimento="Cancellalo per ricominciare da capo.")
    return _copia(predefinito)


# ===========================================================================
# Terminale
# ===========================================================================

_COLORI_ANSI = {
    "nero": 0, "rosso": 1, "verde": 2, "giallo": 3, "blu": 4, "viola": 5, "magenta": 5, "azzurro": 6,
    "ciano": 6, "bianco": 7, "grigio": 60, "rosso_chiaro": 61, "verde_chiaro": 62, "giallo_chiaro": 63,
    "blu_chiaro": 64, "viola_chiaro": 65, "azzurro_chiaro": 66, "arancione": None,
}
_ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")


def _codice_colore(colore: Any, sfondo: bool, chi: str) -> str:
    richiedi_testo(colore, chi, "sfondo" if sfondo else "colore")
    t = _senza_accenti(colore.strip().lower()).replace(" ", "_")
    m = re.fullmatch(r"#?([0-9a-f]{6})", t)
    if m:
        r, g, b = (int(m.group(1)[i:i + 2], 16) for i in (0, 2, 4))
        return f"{48 if sfondo else 38};2;{r};{g};{b}"
    if t == "arancione":
        return f"{48 if sfondo else 38};2;255;140;0"
    if t in _COLORI_ANSI:
        n = _COLORI_ANSI[t]
        return str((40 if sfondo else 30) + n) if n < 60 else str((100 if sfondo else 90) + n - 60)
    simili = difflib.get_close_matches(t, list(_COLORI_ANSI), n=1, cutoff=0.6)
    raise ErroreValore(f"Non conosco il colore {mostra(colore)}.",
                       suggerimento=(f"Forse intendevi \"{simili[0]}\"? " if simili else "") +
                       "Colori: " + ", ".join(k for k in _COLORI_ANSI) + ", oppure \"#RRGGBB\".")


@funzione_libreria("testo_colorato")
def testo_colorato(testo, colore=None, sfondo=None, grassetto=False, corsivo=False, sottolineato=False,
                   sempre=False):
    """testo_colorato(testo, colore = nulla, sfondo = nulla, grassetto = falso, corsivo = falso, sottolineato = falso, sempre = falso): il testo con colori e stile per il terminale.

    Colori: "rosso", "verde", "giallo", "blu", "viola", "azzurro", "bianco", "nero", "grigio",
    "arancione", le versioni "..._chiaro" oppure "#RRGGBB". Se l'uscita non è un terminale
    (un file, una pipe) il testo resta semplice, a meno di `sempre = vero`.
    Esempio: `stampa(testo_colorato("Attenzione!", "rosso", grassetto = vero))`.
    """
    if not isinstance(testo, str):
        testo = rappresenta(testo)
    codici = []
    for valore, nome in ((grassetto, "grassetto"), (corsivo, "corsivo"), (sottolineato, "sottolineato"),
                         (sempre, "sempre")):
        richiedi_logico(valore, "testo_colorato", nome)
    if grassetto:
        codici.append("1")
    if corsivo:
        codici.append("3")
    if sottolineato:
        codici.append("4")
    if colore is not None:
        codici.append(_codice_colore(colore, False, "testo_colorato"))
    if sfondo is not None:
        codici.append(_codice_colore(sfondo, True, "testo_colorato"))
    if not codici or not (sempre or _usa_colori()):
        return testo
    return f"\x1b[{';'.join(codici)}m{testo}\x1b[0m"


@funzione_libreria("togli_colori")
def togli_colori(testo):
    """togli_colori(testo): il testo senza i codici dei colori del terminale (per salvarlo in un file o misurarlo).

    Esempio: `lunghezza(togli_colori(testo_colorato("ciao", "rosso", sempre = vero)))` è 4.
    """
    richiedi_testo(testo, "togli_colori", "testo")
    return _ANSI.sub("", testo)


def _larghezza(testo: str) -> int:
    import unicodedata

    visibile = _ANSI.sub("", testo)
    return sum(0 if unicodedata.combining(c) else (2 if unicodedata.east_asian_width(c) in "WF" else 1)
               for c in visibile)


_BORDI = {
    "semplice": "┌─┬┐│├┼┤└┴┘",
    "doppio": "╔═╦╗║╠╬╣╚╩╝",
    "arrotondato": "╭─┬╮│├┼┤╰┴╯",
    "ascii": "+-++|++++++",
}


@funzione_libreria("tabella_con_bordi")
def tabella_con_bordi(righe, intestazioni=None, stile="semplice"):
    """tabella_con_bordi(righe, intestazioni = nulla, stile = "semplice"): una tabella con i bordi, pronta da stampare.

    `righe` è una lista di liste, oppure una lista di dizionari (le chiavi diventano le
    intestazioni). I numeri si allineano a destra. Stili: "semplice", "doppio",
    "arrotondato", "ascii" (per i terminali che non mostrano le linee).
    Esempio: `stampa(tabella_con_bordi([["Anna", 9], ["Luca", 7]], ["Nome", "Voto"]))`.
    """
    if not isinstance(righe, list):
        raise ErroreTipo(f"`righe` di `tabella_con_bordi` deve essere una lista, non {articolo(righe)}.",
                         suggerimento='Per esempio `[["Anna", 9], ["Luca", 7]]`.')
    richiedi_testo(stile, "tabella_con_bordi", "stile")
    bordi = _BORDI.get(stile.strip().lower())
    if bordi is None:
        raise ErroreValore(f"Lo stile {mostra(stile)} non esiste.",
                           suggerimento="Stili: " + ", ".join(f'"{s}"' for s in _BORDI) + ".")
    if righe and all(isinstance(r, dict) for r in righe):
        chiavi: list = []
        for r in righe:
            for k in r:
                if k not in chiavi:
                    chiavi.append(k)
        if intestazioni is None:
            intestazioni = [k if isinstance(k, str) else rappresenta(k) for k in chiavi]
        tabella = [[r.get(k, "") for k in chiavi] for r in righe]
    else:
        tabella = []
        for i, r in enumerate(righe):
            if not isinstance(r, list):
                raise ErroreTipo(f"La riga {i} di `tabella_con_bordi` deve essere una lista, non {articolo(r)}.")
            tabella.append(r)
    if intestazioni is not None and not isinstance(intestazioni, list):
        raise ErroreTipo("`intestazioni` di `tabella_con_bordi` deve essere una lista di testi.")
    colonne = max([len(r) for r in tabella] + [len(intestazioni or [])] + [0])
    if colonne == 0:
        return ""

    def cella(v: Any) -> str:
        return v if isinstance(v, str) else ("" if v is None else rappresenta(v))

    testi = [[cella(r[j]) if j < len(r) else "" for j in range(colonne)] for r in tabella]
    numeri = [[isinstance(r[j], (int, float)) and not isinstance(r[j], bool) if j < len(r) else False
               for j in range(colonne)] for r in tabella]
    testata = [cella(intestazioni[j]) if j < len(intestazioni) else "" for j in range(colonne)] \
        if intestazioni is not None else None
    larghezze = [max([_larghezza(r[j]) for r in testi] + ([_larghezza(testata[j])] if testata else []) + [1])
                 for j in range(colonne)]
    a_s, oriz, a_m, a_d, vert, m_s, m_m, m_d, b_s, b_m, b_d = bordi

    def linea(sinistra: str, mezzo: str, destra: str) -> str:
        return sinistra + mezzo.join(oriz * (w + 2) for w in larghezze) + destra

    def riga(celle: list[str], destra: list[bool]) -> str:
        parti = []
        for j, testo in enumerate(celle):
            spazio = " " * (larghezze[j] - _larghezza(testo))
            parti.append(" " + (spazio + testo if destra[j] else testo + spazio) + " ")
        return vert + vert.join(parti) + vert

    uscita = [linea(a_s, a_m, a_d)]
    if testata is not None:
        uscita.append(riga(testata, [False] * colonne))
        uscita.append(linea(m_s, m_m, m_d))
    for celle, destra in zip(testi, numeri):
        uscita.append(riga(celle, destra))
    uscita.append(linea(b_s, b_m, b_d))
    return "\n".join(uscita)


class BarraAvanzamento(OggettoLibreria):
    """Valore Leo di tipo ``barra``: una barra di avanzamento nel terminale."""

    NOME_TIPO_DANTE = "barra"

    def __init__(self, interprete: Any, totale: int | float, testo: str, larghezza: int) -> None:
        self.interprete = interprete
        self.totale = totale
        self.testo = testo
        self.larghezza = larghezza
        self.valore: int | float = 0
        self.inizio = time.monotonic()
        self.finita = False
        self.interattiva = _interattivo()
        self._ultimo_disegno = -1.0
        self._ultima_decina = -1
        self._blocco = threading.Lock()

    def frazione(self) -> float:
        if self.totale <= 0:
            return 1.0
        return max(0.0, min(1.0, self.valore / self.totale))

    def riga(self) -> str:
        frazione = self.frazione()
        piene = int(round(frazione * self.larghezza))
        barra = "█" * piene + "░" * (self.larghezza - piene)
        conteggio = f"{rappresenta(self.valore)}/{rappresenta(self.totale)}"
        parti = [self.testo] if self.testo else []
        parti.append(f"{barra} {int(frazione * 100):3d}% ({conteggio})")
        trascorso = time.monotonic() - self.inizio
        if not self.finita and 0 < frazione < 1 and trascorso >= 1:
            mancano = trascorso * (1 - frazione) / frazione
            parti.append(f"mancano {_durata_breve(mancano)}")
        elif self.finita:
            parti.append(f"in {_durata_breve(trascorso)}")
        return " ".join(parti)

    def disegna(self, forza: bool = False) -> None:
        adesso = time.monotonic()
        if self.interattiva:
            if not forza and adesso - self._ultimo_disegno < 0.05:
                return
            self._ultimo_disegno = adesso
            _scrivi(self.interprete, "\r" + self.riga() + "\x1b[K" + ("\n" if self.finita else ""))
            return
        decina = int(self.frazione() * 10)
        if decina != self._ultima_decina or (forza and self.finita):
            self._ultima_decina = decina
            _scrivi(self.interprete, self.riga() + "\n")

    def testo_dante(self) -> str:
        return f"<barra {int(self.frazione() * 100)}%>"


def _durata_breve(secondi: float) -> str:
    secondi = int(round(secondi))
    if secondi < 60:
        return f"{secondi} s"
    minuti, secondi = divmod(secondi, 60)
    if minuti < 60:
        return f"{minuti} min {secondi:02d} s"
    ore, minuti = divmod(minuti, 60)
    return f"{ore} h {minuti:02d} min"


@funzione_libreria("barra_avanzamento", interprete=True)
def barra_avanzamento(interprete, totale, testo="", larghezza=30):
    """barra_avanzamento(totale, testo = "", larghezza = 30): una barra che mostra nel terminale a che punto è un lavoro lungo.

    Metodi: `avanza(quanto = 1)`, `imposta(valore)`, `finisci()`. Proprietà: `valore`,
    `percentuale`. Mostra anche quanto manca. Se l'uscita non è un terminale scrive una
    riga ogni 10%.
    Esempio: `variabile b = barra_avanzamento(lunghezza(file), "Copio")` e nel ciclo `b.avanza()`.
    """
    richiedi_numero(totale, "barra_avanzamento", "totale")
    if totale < 0 or totale != totale:
        raise ErroreValore("Il `totale` di `barra_avanzamento` non può essere negativo.")
    richiedi_testo(testo, "barra_avanzamento", "testo")
    richiedi_intero(larghezza, "barra_avanzamento", "larghezza")
    if not 5 <= larghezza <= 200:
        raise ErroreValore("La `larghezza` della barra deve essere fra 5 e 200 caratteri.")
    barra = BarraAvanzamento(interprete, totale, testo, larghezza)
    barra.disegna(forza=True)
    return barra


proprieta(BarraAvanzamento, "valore")(lambda b: b.valore)
proprieta(BarraAvanzamento, "percentuale")(lambda b: round(b.frazione() * 100, 1))
proprieta(BarraAvanzamento, "totale")(lambda b: b.totale)


@metodo_oggetto(BarraAvanzamento, "avanza")
def _barra_avanza(b, quanto=1):
    """barra.avanza(quanto = 1): fa avanzare la barra (di 1 se non dici niente)."""
    richiedi_numero(quanto, "avanza", "quanto")
    with b._blocco:
        b.valore = min(b.valore + quanto, b.totale) if b.totale > 0 else b.valore + quanto
        if b.valore >= b.totale and not b.finita:
            b.finita = True
            b.disegna(forza=True)
        elif not b.finita:
            b.disegna()
    return None


@metodo_oggetto(BarraAvanzamento, "imposta")
def _barra_imposta(b, valore):
    """barra.imposta(valore): porta la barra al valore dato (fra 0 e il totale)."""
    richiedi_numero(valore, "imposta", "valore")
    with b._blocco:
        b.valore = max(0, min(valore, b.totale))
        if b.valore >= b.totale and not b.finita:
            b.finita = True
            b.disegna(forza=True)
        elif not b.finita:
            b.disegna()
    return None


@metodo_oggetto(BarraAvanzamento, "finisci")
def _barra_finisci(b):
    """barra.finisci(): porta la barra al 100% e va a capo."""
    with b._blocco:
        if not b.finita:
            b.valore = b.totale
            b.finita = True
            b.disegna(forza=True)
    return None


def _analizza_numero(testo: str, decimali: bool) -> int | float | None:
    t = testo.strip().replace(" ", "")
    if not t:
        return None
    if re.fullmatch(r"[+-]?\d+", t):
        return int(t)
    if decimali and re.fullmatch(r"[+-]?(\d+([.,]\d*)?|[.,]\d+)", t):
        return float(t.replace(",", "."))
    return None


def _chiedi_numero(interprete: Any, domanda: str, da: Any, a: Any, decimali: bool) -> int | float:
    while True:
        risposta = _leggi(interprete, domanda)
        numero = _analizza_numero(risposta, decimali)
        if numero is None:
            if not decimali and _analizza_numero(risposta, True) is not None:
                _scrivi(interprete, "Scrivi un numero intero, senza virgola.\n")
            else:
                _scrivi(interprete, "Non è un numero: scrivi solo cifre, per esempio 7.\n")
            continue
        if (da is not None and numero < da) or (a is not None and numero > a):
            if da is not None and a is not None:
                _scrivi(interprete, f"Scrivi un numero da {rappresenta(da)} a {rappresenta(a)}.\n")
            elif da is not None:
                _scrivi(interprete, f"Scrivi un numero uguale o maggiore di {rappresenta(da)}.\n")
            else:
                _scrivi(interprete, f"Scrivi un numero uguale o minore di {rappresenta(a)}.\n")
            continue
        return numero


@funzione_libreria("chiedi_numero", interprete=True)
def chiedi_numero(interprete, domanda="Scrivi un numero: ", da=None, a=None, decimali=False):
    """chiedi_numero(domanda = "Scrivi un numero: ", da = nulla, a = nulla, decimali = falso): chiede un numero e richiede finché la risposta è giusta.

    Con `da` e `a` il numero deve stare in quell'intervallo; con `decimali = vero`
    accetta anche 2,5 (virgola o punto). Restituisce un intero (o un decimale).
    Esempio: `variabile eta = chiedi_numero("Quanti anni hai? ", da = 1, a = 120)`.
    """
    if not isinstance(domanda, str):
        domanda = rappresenta(domanda)
    richiedi_logico(decimali, "chiedi_numero", "decimali")
    if da is not None:
        richiedi_numero(da, "chiedi_numero", "da")
    if a is not None:
        richiedi_numero(a, "chiedi_numero", "a")
    if da is not None and a is not None and da > a:
        raise ErroreValore(f"In `chiedi_numero` `da` ({rappresenta(da)}) è più grande di `a` ({rappresenta(a)}).",
                           suggerimento="Scambiali: `da` è il più piccolo.")
    return _chiedi_numero(interprete, domanda, da, a, decimali)


def _mostra_voci(interprete: Any, titolo: str, voci: list[str], zero: str | None) -> None:
    if titolo:
        _scrivi(interprete, titolo + "\n")
    larghezza = len(str(len(voci)))
    for i, voce in enumerate(voci, 1):
        _scrivi(interprete, f"  {str(i).rjust(larghezza)}. {voce}\n")
    if zero is not None:
        _scrivi(interprete, f"  {'0'.rjust(larghezza)}. {zero}\n")


@funzione_libreria("scegli_da_elenco", interprete=True)
def scegli_da_elenco(interprete, lista, domanda="Scegli un numero: ", titolo=""):
    """scegli_da_elenco(lista, domanda = "Scegli un numero: ", titolo = ""): mostra la lista numerata e restituisce l'elemento scelto.

    Richiede finché il numero non è valido.
    Esempio: `variabile gusto = scegli_da_elenco(["fragola", "cioccolato", "limone"], titolo = "Gelato:")`.
    """
    dati = list(elementi(lista, "scegli_da_elenco"))
    if not dati:
        raise ErroreValore("`scegli_da_elenco` ha ricevuto una lista vuota: non c'è niente da scegliere.")
    richiedi_testo(domanda, "scegli_da_elenco", "domanda")
    richiedi_testo(titolo, "scegli_da_elenco", "titolo")
    _mostra_voci(interprete, titolo, [v if isinstance(v, str) else rappresenta(v) for v in dati], None)
    return dati[_chiedi_numero(interprete, domanda, 1, len(dati), False) - 1]


@funzione_libreria("menu", interprete=True)
def menu(interprete, voci, titolo="Menu", uscita="Esci"):
    """menu(voci, titolo = "Menu", uscita = "Esci"): un menu numerato nel terminale che si ripete finché non scegli 0.

    `voci` è un dizionario testo -> funzione (senza argomenti): scegliendo un numero si
    chiama la sua funzione, poi il menu ricompare. 0 esce dal menu.
    Esempio: `menu({"Nuova partita": gioca, "Classifica": mostra_classifica}, "Gioco")`.
    """
    if not isinstance(voci, dict) or not voci:
        raise ErroreTipo("`menu` vuole un dizionario non vuoto testo -> funzione.",
                         suggerimento='Per esempio `menu({"Gioca": gioca, "Regole": regole})`. '
                                      'Per scegliere solo un elemento da una lista usa `scegli_da_elenco`.')
    richiedi_testo(titolo, "menu", "titolo")
    richiedi_testo(uscita, "menu", "uscita")
    nomi = []
    funzioni = []
    for nome, f in voci.items():
        richiedi_funzione(f, "menu", "voci")
        nomi.append(nome if isinstance(nome, str) else rappresenta(nome))
        funzioni.append(f)
    while True:
        _scrivi(interprete, "\n")
        _mostra_voci(interprete, titolo, nomi, uscita)
        scelta = _chiedi_numero(interprete, "Scelta: ", 0, len(nomi), False)
        if scelta == 0:
            return None
        chiama_funzione(interprete, funzioni[scelta - 1], [])


@funzione_libreria("chiedi_si_no", interprete=True)
def chiedi_si_no(interprete, domanda, predefinito=None):
    """chiedi_si_no(domanda, predefinito = nulla): chiede sì o no nel terminale; restituisce `vero` per sì.

    Accetta "s", "si", "sì", "n", "no" (maiuscole o minuscole). Con `predefinito` basta
    premere Invio. Per una finestrella con i pulsanti usa `domanda`.
    Esempio: `se chiedi_si_no("Vuoi salvare?", predefinito = vero) allora salva() fine`.
    """
    if not isinstance(domanda, str):
        domanda = rappresenta(domanda)
    if predefinito is not None:
        richiedi_logico(predefinito, "chiedi_si_no", "predefinito")
    suffisso = " [S/n] " if predefinito is True else (" [s/N] " if predefinito is False else " (s/n) ")
    while True:
        risposta = _senza_accenti(_leggi(interprete, domanda.rstrip() + suffisso).strip().lower())
        if risposta in ("s", "si", "y", "yes", "vero", "certo", "ok"):
            return True
        if risposta in ("n", "no", "falso"):
            return False
        if not risposta and predefinito is not None:
            return predefinito
        _scrivi(interprete, "Rispondi s (sì) oppure n (no).\n")


@funzione_libreria("premi_invio", interprete=True)
def premi_invio(interprete, testo="Premi Invio per continuare..."):
    """premi_invio(testo = "Premi Invio per continuare..."): ferma il programma finché non si preme Invio.

    Esempio: `premi_invio()` alla fine del programma, così la finestra non si chiude subito.
    """
    if not isinstance(testo, str):
        testo = rappresenta(testo)
    try:
        interprete.leggi(testo)
    except ErroreValore:
        pass                    # nessun ingresso (programma in una pipe): si continua
    return None


@funzione_libreria("pulisci_terminale", interprete=True)
def pulisci_terminale(interprete):
    """pulisci_terminale(): cancella tutto quello che è scritto nel terminale e riparte dall'alto.

    Esempio: `pulisci_terminale()` prima di ridisegnare il menu di un gioco. Se l'uscita non
    è un terminale (un file) non fa niente.
    """
    if not _interattivo():
        return None
    try:
        sys.stdout.flush()
    except Exception:  # noqa: BLE001
        pass
    if os.name == "nt" and sys.stdout.isatty() and not _usa_colori():
        os.system("cls")  # noqa: S605,S607 - console di Windows senza ANSI
    else:
        _scrivi(interprete, "\x1b[2J\x1b[H")
    return None


# ===========================================================================
# Vita del programma
# ===========================================================================

_BLOCCHI_ISTANZA: dict[str, Any] = {}


def _blocca_file(percorso: str) -> Any:
    """Apre e blocca ``percorso`` (None se un altro processo lo tiene)."""
    f = open(percorso, "a+b")
    try:
        if os.name == "nt":
            import msvcrt

            f.seek(0)
            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl

            fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        f.close()
        return None
    try:
        f.seek(0)
        f.truncate()
        f.write(str(os.getpid()).encode("ascii"))
        f.flush()
    except OSError:
        pass
    return f


@funzione_libreria("programma_unico", interprete=True)
def programma_unico(interprete, nome=None):
    """programma_unico(nome = nulla): `vero` se questo è l'unico programma aperto con quel nome, `falso` se un altro è già aperto.

    Il primo che la chiama "prenota" il nome finché resta aperto (anche se si chiude
    male, la prenotazione si libera). Senza nome si usa il nome del file del programma.
    Esempio:
    `se non programma_unico() allora
    stampa("Il programma è già aperto!")
    esci_dal_programma(1)
fine`.
    """
    if nome is None:
        nome = os.path.splitext(_nome_programma(interprete))[0]
    richiedi_testo(nome, "programma_unico", "nome")
    pulito = re.sub(r"[^\w-]+", "_", nome.strip())[:80] or "programma"
    if pulito in _BLOCCHI_ISTANZA:
        return True
    cartella = os.path.join(tempfile.gettempdir(), "leo_programmi_unici")
    try:
        os.makedirs(cartella, exist_ok=True)
        f = _blocca_file(os.path.join(cartella, pulito + ".blocco"))
    except OSError as e:
        raise ErroreFile(f"`programma_unico` non riesce a creare il suo file: {e.strerror or e}.") from None
    if f is None:
        return False
    _BLOCCHI_ISTANZA[pulito] = f
    return True


@funzione_libreria("esci_dal_programma", interprete=True)
def esci_dal_programma(interprete, codice=0, messaggio=None):
    """esci_dal_programma(codice = 0, messaggio = nulla): chiude subito il programma con un codice d'uscita.

    Il codice 0 vuol dire "tutto bene"; un altro numero (di solito 1) dice a chi ha
    avviato il programma che qualcosa è andato storto. Il `messaggio`, se c'è, si stampa prima.
    Le funzioni di `prima_di_uscire` vengono chiamate.
    Esempio: `se non esiste("dati.csv") allora esci_dal_programma(1, "Manca il file dati.csv") fine`.
    """
    richiedi_intero(codice, "esci_dal_programma", "codice")
    if not 0 <= codice <= 255:
        raise ErroreValore("Il codice d'uscita deve essere fra 0 e 255.",
                           suggerimento="Usa 0 se è andato tutto bene, 1 se c'è stato un problema.")
    if _e_lavoro_parallelo(interprete):
        raise ErroreValore("Da un lavoro `in parallelo` non si può chiudere il programma.",
                           suggerimento="Fai restituire un valore al lavoro e chiudi dal programma principale.")
    if not hasattr(interprete, "globale"):
        raise ErroreValore("`esci_dal_programma` chiude un programma Leo: qui non ce n'è uno da chiudere.")
    if messaggio is not None:
        _scrivi(interprete, (messaggio if isinstance(messaggio, str) else rappresenta(messaggio)) + "\n")
    temporizzatori = getattr(interprete, "__dict__", {}).get("_temporizzatori")
    if temporizzatori is not None:
        temporizzatori.ferma_tutti()
    raise SystemExit(codice)


_ALLA_FINE: list[tuple[Any, Any]] = []
_BLOCCO_FINE = threading.Lock()
_REGISTRATO = [False]


def esegui_funzioni_finali() -> None:
    """Chiama (una volta sola, nell'ordine) le funzioni registrate con ``prima_di_uscire``."""
    with _BLOCCO_FINE:
        voci = list(_ALLA_FINE)
        _ALLA_FINE.clear()
    for interprete, f in voci:
        try:
            if getattr(interprete, "_ferma_richiesta", False):
                interprete._ferma_richiesta = False       # Ctrl+C: le ultime funzioni girano comunque
            chiama_funzione(interprete, f, [])
        except SystemExit:
            continue
        except BaseException as e:  # noqa: BLE001 - un errore non deve bloccare le altre
            try:
                breve = e.breve() if isinstance(e, ErroreDante) else str(e)
                sys.stderr.write(f"Errore in una funzione di `prima_di_uscire`: {breve}\n")
            except Exception:  # noqa: BLE001
                pass


@funzione_libreria("prima_di_uscire", interprete=True)
def prima_di_uscire(interprete, funzione):
    """prima_di_uscire(funzione): chiama la funzione (senza argomenti) quando il programma finisce, in qualunque modo.

    Anche con Ctrl+C, con un errore o con `esci_dal_programma`. Utile per salvare lo stato
    o chiudere i file. Se la registri più volte, le funzioni si chiamano nell'ordine.
    Esempio: `prima_di_uscire(funzione () salva_stato(punti, "partita") fine)`.
    """
    f = richiedi_funzione(funzione, "prima_di_uscire")
    with _BLOCCO_FINE:
        _ALLA_FINE.append((interprete, f))
        if not _REGISTRATO[0]:
            atexit.register(esegui_funzioni_finali)
            _REGISTRATO[0] = True
    return None


def _memoria_windows() -> int | None:
    import ctypes
    from ctypes import wintypes

    class Contatori(ctypes.Structure):
        _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                    ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t), ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                    ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]

    contatori = Contatori()
    contatori.cb = ctypes.sizeof(Contatori)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    processo = kernel32.GetCurrentProcess
    processo.restype = wintypes.HANDLE
    leggi = kernel32.K32GetProcessMemoryInfo
    leggi.argtypes = [wintypes.HANDLE, ctypes.POINTER(Contatori), wintypes.DWORD]
    leggi.restype = wintypes.BOOL
    if leggi(processo(), ctypes.byref(contatori), contatori.cb):
        return int(contatori.WorkingSetSize)
    return None


@funzione_libreria("memoria_programma")
def memoria_programma():
    """memoria_programma(): quanti byte di memoria RAM sta usando questo programma adesso.

    Esempio: `stampa("Uso", dimensione_leggibile(memoria_programma()))` scrive per esempio "Uso 42,5 MB".
    Per la memoria di tutto il computer usa `info_memoria()`.
    """
    try:
        if os.name == "nt":
            valore = _memoria_windows()
            if valore is not None:
                return valore
        else:
            with open("/proc/self/statm", "r") as f:
                pagine = int(f.read().split()[1])
            return pagine * os.sysconf("SC_PAGE_SIZE")
    except Exception:  # noqa: BLE001 - si prova l'altra strada
        pass
    try:
        import resource

        massimo = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        return int(massimo if sys.platform == "darwin" else massimo * 1024)
    except Exception:  # noqa: BLE001
        raise ErroreValore("Su questo sistema non riesco a misurare la memoria del programma.") from None
