"""Libreria: lavorare in parallelo in modo sicuro (canali, attese su più lavori, annullamento).

Il motore è in :mod:`leo.parallelo` (lavori isolati, canali, attese) e in
:mod:`leo.parallelo_processi` (processi lavoratori su più processori). Qui ci
sono le funzioni Leo:

* ``canale(capacità = 0)``: un canale per mandare messaggi fra lavori
  (metodi ``invia``, ``ricevi``, ``chiudi``; ``per ogni messaggio in canale``);
* ``aspetta_tutti(lavori, secondi)``: tutti i risultati (al primo errore annulla
  gli altri); ``aspetta_il_primo(lavori, secondi)``: il primo lavoro che finisce;
* ``ricevi_dal_primo(canali, secondi)``: il primo messaggio da più canali;
* ``annulla(lavori)``: ferma uno o più lavori;
* ``processori()``, ``informazioni_parallelismo()``, ``prepara_processi(quanti)``.

``aspetta`` e la sintassi ``in parallelo fai ... fine`` sono del linguaggio
(:mod:`leo.potenza`); ``mappa_in_parallelo`` è in :mod:`leo.libreria.programmi`.
"""

from __future__ import annotations

from typing import Any

from .. import parallelo as P
from ..errori import ErroreTipo, ErroreValore
from ..valori import rappresenta
from .generali import articolo, funzione_libreria, richiedi_intero, richiedi_logico


@funzione_libreria("canale", interprete=True)
def canale(interprete, capacità=0):
    """canale(capacità = 0): un canale per mandare messaggi da un lavoro `in parallelo` all'altro.

    `c.invia(messaggio)` mette in fondo una copia del messaggio, `c.ricevi()` toglie il
    primo (aspettando se non ce n'è), `c.chiudi()` dice che non ne arriveranno altri;
    `per ogni m in c fai` riceve finché il canale è chiuso e vuoto. Con `capacità` > 0
    `invia` aspetta quando il canale è pieno (chi produce non corre più di chi consuma).
    Funziona anche fra lavori che girano in processi diversi.
    Esempio: `variabile risultati = canale()`.
    """
    richiedi_intero(capacità, "canale", "capacità")
    if capacità < 0:
        raise ErroreValore("La `capacità` di un canale non può essere negativa.",
                           suggerimento="Usa 0 per un canale senza limiti, oppure un numero come 10.")
    c = P.Canale(capacità)
    c.interprete = interprete
    return c


def _lista_di_lavori(valore: Any, chi: str) -> list:
    return P.richiedi_lavori(valore, chi)


@funzione_libreria("aspetta_tutti", interprete=True)
def aspetta_tutti(interprete, lavori, secondi=None):
    """aspetta_tutti(lavori, secondi = nulla): aspetta che finiscano tutti i lavori e dà la lista dei risultati.

    I risultati sono nell'ordine della lista. Se un lavoro finisce con un errore, gli
    altri vengono annullati e l'errore si ripete qui; se dai `secondi` e il tempo
    scade, i lavori non finiti vengono annullati e c'è un errore.
    Esempio: `variabile parti = aspetta_tutti([l1, l2, l3], 10)`.
    """
    return P.aspetta_tutti(interprete, lavori, secondi)


@funzione_libreria("aspetta_il_primo", interprete=True)
def aspetta_il_primo(interprete, lavori, secondi=None, annulla_gli_altri=False):
    """aspetta_il_primo(lavori, secondi = nulla, annulla_gli_altri = falso): il primo lavoro della lista che finisce.

    Dà il lavoro (il suo risultato si legge con `aspetta(lavoro)`). Con
    `annulla_gli_altri = vero` ferma tutti gli altri: utile per chiedere la stessa cosa
    a più fonti e tenere la risposta più veloce.
    Esempio: `variabile vincitore = aspetta_il_primo([a, b], annulla_gli_altri = vero)`.
    """
    richiedi_logico(annulla_gli_altri, "aspetta_il_primo", "annulla_gli_altri")
    return P.aspetta_il_primo(interprete, lavori, secondi, annulla_gli_altri)


@funzione_libreria("ricevi_dal_primo", interprete=True)
def ricevi_dal_primo(interprete, canali, secondi=None):
    """ricevi_dal_primo(canali, secondi = nulla): il primo messaggio che arriva da uno dei canali: `[canale, messaggio]`.

    Aspetta finché uno dei canali ha un messaggio (al massimo `secondi`); se sono tutti
    chiusi e vuoti c'è un errore.
    Esempio: `variabile da, messaggio = ricevi_dal_primo([ordini, annulli])`.
    """
    if isinstance(canali, P.Canale):
        canali = [canali]
    if not isinstance(canali, list) or not canali:
        raise ErroreTipo(f"`ricevi_dal_primo` vuole una lista di canali, non {articolo(canali)}.",
                         suggerimento="Per esempio `ricevi_dal_primo([c1, c2])`.")
    for i, c in enumerate(canali):
        if not isinstance(c, P.Canale):
            raise ErroreTipo(f"`ricevi_dal_primo` vuole solo canali, ma l'elemento {i} della lista è "
                             f"{articolo(c)} ({rappresenta(c, dentro=True)}).",
                             suggerimento="I canali si creano con `canale()`.")
    return P.ricevi_dal_primo(interprete, canali, secondi)


@funzione_libreria("annulla")
def annulla(lavori):
    """annulla(lavori): ferma un lavoro `in parallelo` (o una lista di lavori).

    Con un lavoro dà `vero` se era ancora in corso; con una lista dà quanti ne ha fermati.
    Un lavoro annullato non ha un risultato: `aspetta` dà un errore.
    Esempio: `annulla(ricerca)`.
    """
    return P.annulla(lavori)


@funzione_libreria("processori")
def processori():
    """processori(): quanti processori può usare il programma (per dividere un calcolo in parti).

    Esempio: `variabile parti = dividi_in_parti(numeri, processori())`.
    """
    return P.processori()


@funzione_libreria("informazioni_parallelismo")
def informazioni_parallelismo():
    """informazioni_parallelismo(): come lavorano qui i lavori `in parallelo`.

    Dà un dizionario con `modo` ("processi": più processori per davvero; "fili": un
    processore, per esempio su Android), `processori`, `processi` (vero se si possono
    usare), `motivo` (perché no), `lavoratori` (processi pronti) e `gil`.
    """
    return P.informazioni()


@funzione_libreria("prepara_processi")
def prepara_processi(quanti=None):
    """prepara_processi(quanti = nulla): avvia subito i processi che faranno i lavori (predefinito: uno per processore).

    Di solito non serve: i processi partono da soli al primo lavoro. Prepararli prima
    toglie quella breve attesa (utile prima di misurare i tempi o in un gioco). Dà quanti
    processi sono pronti (0 dove i processi non si possono usare, per esempio su Android).
    """
    if quanti is None:
        quanti = P.processori()
    richiedi_intero(quanti, "prepara_processi", "quanti")
    if quanti < 1:
        raise ErroreValore("`quanti` deve essere almeno 1.")
    from ..parallelo_processi import massimo_lavoratori, prepara_lavoratori

    return prepara_lavoratori(min(quanti, massimo_lavoratori()))
