"""Libreria: animazioni ed effetti dei controlli nei programmi con finestre.

Funzioni (registrate con :mod:`leo.registro`)::

    anima(oggetto, proprieta, valore, durata = 0.3, curva = "morbida", poi = nulla)
    lampeggia(oggetto, volte = 3, durata = 0.3, poi = nulla)
    scuoti(oggetto, intensita = 10, durata = 0.45, poi = nulla)
    dissolvi(oggetto, durata = 0.4, poi = nulla)
    compari(oggetto, durata = 0.4, poi = nulla)
    pulsa(oggetto, volte = 1, durata = 0.45, poi = nulla)
    aspetta_animazioni()
    ferma_animazioni(oggetto = nulla)

Le stesse (tranne le ultime due) sono anche metodi di ogni controllo visibile:
``Pulsante1.scuoti()``, ``Pulsante1.anima("alto", 50, 0.3)``... (li aggiunge
:func:`leo.grafica.metadati.registra`, che chiama le funzioni ``*_controllo``
di questo modulo). Solo come metodi ci sono anche gli effetti per chi comincia:
``rimbalza``, ``ruota``, ``capovolgi``, ``brilla``, ``dondola``, ``trema`` (effetti grafici
che non cambiano le proprietà: :func:`piano_colpo`), ``mostra_con`` e
``nascondi_con`` (:func:`piano_entrata`), ``vola_a``, ``ingrandisci``,
``cambia_colore`` e ``cambia_sfondo`` (animazioni di proprietà). Il catalogo
degli effetti grafici è in :mod:`leo.grafica.effetti`.

Il sintattico ``anima Pulsante1.alto a 50 in 0.3 secondi con curva "rimbalzo"``
diventa la chiamata ``anima(Pulsante1, "alto", 50, 0.3, "rimbalzo")``.

Come funziona
-------------
Qui c'è la parte **pura** (senza Qt), verificabile da sola:

* le **curve** (:data:`CURVE`, :func:`applica_curva`): ``lineare``,
  ``morbida`` (parte e arriva piano), ``rimbalzo``, ``elastica``, ``veloce``
  (parte veloce e frena), ``lenta`` (parte piano e accelera);
* l'**interpolazione** di numeri e colori (:func:`interpola`);
* il **piano** di un'animazione (:class:`Animazione`, fatta di
  :class:`Traccia`: una proprietà di un controllo con i suoi fotogrammi
  chiave) per ``anima`` (:func:`piano_anima`) e per gli effetti
  (:func:`piano_effetto`);
* il :class:`GestoreAnimazioni`, che sa quale animazione "possiede" ogni
  proprietà di ogni controllo: un'animazione nuova sulla stessa proprietà
  **sostituisce** la vecchia (che smette di muovere quella proprietà; se
  non le resta niente si ferma e il suo ``poi`` non viene chiamato).

Il tempo lo scandisce il motore Qt (``leo.grafica.qt.animazioni_programma_qt``):
a ogni fotogramma il gestore **scrive il valore nel controllo** con
``ControlloVivo.scrivi``, così il widget vero si aggiorna (tramite gli
osservatori) e leggere ``Pulsante1.alto`` durante o dopo l'animazione dà il
valore giusto. Alla fine si scrive il valore finale esatto e ``poi`` viene
chiamato dal ciclo degli eventi, nello stesso thread degli altri gestori
``quando``.

Nei programmi testuali (senza finestre) queste funzioni danno un errore chiaro.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Any, Callable

from ..errori import ErroreTipo, ErroreValore
from ..registro import funzione
from ..valori import OggettoControllo, Richiamabile, e_numero, nome_tipo

# ===========================================================================
# Curve
# ===========================================================================

#: Curve ammesse (nome canonico).
CURVE = ("lineare", "morbida", "rimbalzo", "elastica", "veloce", "lenta")
CURVA_PREDEFINITA = "morbida"

_SINONIMI_CURVE = {
    "lineare": "lineare", "costante": "lineare", "uniforme": "lineare", "dritta": "lineare",
    "morbida": "morbida", "morbido": "morbida", "dolce": "morbida", "fluida": "morbida", "naturale": "morbida",
    "rimbalzo": "rimbalzo", "rimbalza": "rimbalzo", "rimbalzante": "rimbalzo", "palla": "rimbalzo",
    "elastica": "elastica", "elastico": "elastica", "molla": "elastica",
    "veloce": "veloce", "rapida": "veloce", "frenata": "veloce", "uscita": "veloce",
    "lenta": "lenta", "lento": "lenta", "accelerata": "lenta", "entrata": "lenta",
}

#: Durata predefinita di ``anima`` (secondi) e limite di sicurezza.
DURATA_PREDEFINITA = 0.3
DURATA_MASSIMA = 60.0

#: Tipi di proprieta' (vedi ``leo.grafica.metadati``) che si possono animare.
TIPI_ANIMABILI = ("intero", "decimale", "numero", "colore")

#: Nomi degli effetti (funzioni e metodi dei controlli).
EFFETTI = ("lampeggia", "scuoti", "dissolvi", "compari", "pulsa")


def _chiave(testo: str) -> str:
    from ..grafica.metadati import semplifica_nome

    return semplifica_nome(testo).replace(" ", "_").replace("-", "_")


def normalizza_curva(nome: Any) -> str:
    """Nome canonico di una curva (``"Rimbalzo"`` -> ``"rimbalzo"``); errore chiaro se sconosciuta."""
    if nome is None:
        return CURVA_PREDEFINITA
    if not isinstance(nome, str):
        raise ErroreTipo(f"La curva di un'animazione si scrive come testo, non come `{nome_tipo(nome)}`.",
                         suggerimento="Curve: " + ", ".join(f'"{c}"' for c in CURVE) + ".")
    chiave = _chiave(nome)
    if chiave == "":
        return CURVA_PREDEFINITA
    if chiave in _SINONIMI_CURVE:
        return _SINONIMI_CURVE[chiave]
    import difflib

    vicine = difflib.get_close_matches(chiave, list(_SINONIMI_CURVE), n=1, cutoff=0.6)
    suggerimento = (f"Forse intendevi \"{_SINONIMI_CURVE[vicine[0]]}\"? " if vicine else "") + \
        "Curve: " + ", ".join(f'"{c}"' for c in CURVE) + "."
    raise ErroreValore(f"Non conosco la curva `{nome}`.", suggerimento=suggerimento)


def _rimbalzo(t: float) -> float:
    n, d = 7.5625, 2.75
    if t < 1 / d:
        return n * t * t
    if t < 2 / d:
        t -= 1.5 / d
        return n * t * t + 0.75
    if t < 2.5 / d:
        t -= 2.25 / d
        return n * t * t + 0.9375
    t -= 2.625 / d
    return n * t * t + 0.984375


def applica_curva(curva: str, t: float) -> float:
    """Avanzamento "curvato" per l'avanzamento ``t`` nel tempo (0..1).

    Il risultato vale 0 all'inizio e 1 alla fine; ``elastica`` supera
    brevemente 1 (va oltre e torna indietro).
    """
    t = 0.0 if t <= 0 else 1.0 if t >= 1 else float(t)
    if t in (0.0, 1.0):
        return t
    if curva == "lineare":
        return t
    if curva == "veloce":  # parte veloce e frena (uscita cubica)
        return 1 - (1 - t) ** 3
    if curva == "lenta":   # parte piano e accelera (entrata cubica)
        return t ** 3
    if curva == "rimbalzo":
        return _rimbalzo(t)
    if curva == "elastica":
        return 2 ** (-10 * t) * math.sin((t * 10 - 0.75) * (2 * math.pi / 3)) + 1
    # morbida: entrata e uscita cubica
    return 4 * t ** 3 if t < 0.5 else 1 - (-2 * t + 2) ** 3 / 2


# ===========================================================================
# Interpolazione
# ===========================================================================

_ESADECIMALE = re.compile(r"^#[0-9A-Fa-f]{6}(?:[0-9A-Fa-f]{2})?$")


def colore_rgba(colore: Any) -> tuple[int, int, int, int] | None:
    """``"#RRGGBB"``/``"#RRGGBBAA"`` -> (r, g, b, a); None se non è un colore semplice."""
    if not isinstance(colore, str) or not _ESADECIMALE.match(colore.strip()):
        return None
    c = colore.strip()
    r, g, b = (int(c[i:i + 2], 16) for i in (1, 3, 5))
    a = int(c[7:9], 16) if len(c) == 9 else 255
    return r, g, b, a


def colore_da_rgba(r: float, g: float, b: float, a: float = 255) -> str:
    """(r, g, b, a) -> ``"#RRGGBB"`` (``"#RRGGBBAA"`` se trasparente)."""
    v = [max(0, min(255, int(round(x)))) for x in (r, g, b, a)]
    testo = "#" + "".join(f"{x:02X}" for x in v[:3])
    return testo if v[3] == 255 else testo + f"{v[3]:02X}"


def interpola_colore(inizio: Any, fine: Any, t: float) -> Any:
    """Colore intermedio (canale per canale, trasparenza compresa).

    Se uno dei due non è un colore semplice (``""``, una sfumatura...) il
    valore resta quello iniziale e diventa quello finale solo alla fine.
    """
    a = colore_rgba(inizio)
    b = colore_rgba(fine)
    if a is None or b is None:
        return fine if t >= 1 else inizio
    t = max(0.0, min(1.0, t))  # i colori non "vanno oltre"
    return colore_da_rgba(*(x + (y - x) * t for x, y in zip(a, b)))


def interpola(inizio: Any, fine: Any, t: float, tipo: str = "decimale") -> Any:
    """Valore tra ``inizio`` e ``fine`` (``t`` = 0 -> inizio, 1 -> fine; può uscire da 0..1).

    ``tipo``: ``"intero"`` arrotonda, ``"colore"`` interpola i canali,
    ``"numero"`` resta intero se lo sono entrambi gli estremi.
    """
    if tipo == "colore":
        return interpola_colore(inizio, fine, t)
    if not (e_numero(inizio) and e_numero(fine)):
        return fine if t >= 1 else inizio
    valore = inizio + (fine - inizio) * t
    if tipo == "intero" or (tipo == "numero" and isinstance(inizio, int) and isinstance(fine, int)
                            and not isinstance(inizio, bool) and not isinstance(fine, bool)):
        return int(round(valore))
    return float(valore)


# ===========================================================================
# Tracce e animazioni
# ===========================================================================

@dataclass
class Traccia:
    """Una proprietà di un controllo con i suoi fotogrammi chiave ``(posizione 0..1, valore)``.

    ``base``: valore "a riposo" a cui l'effetto torna alla fine (``scuoti``,
    ``pulsa``, ``lampeggia``); None per ``anima``. Serve quando un effetto ne
    sostituisce un altro a metà: il nuovo riparte dal valore a riposo.
    """

    controllo: Any
    proprieta: str
    tipo: str
    fotogrammi: list[tuple[float, Any]]
    base: Any = None

    @property
    def chiave(self) -> tuple[int, str]:
        return (id(self.controllo), self.proprieta)

    @property
    def finale(self) -> Any:
        return self.fotogrammi[-1][1]

    def valore(self, p: float) -> Any:
        """Valore all'avanzamento (già curvato) ``p``."""
        f = self.fotogrammi
        if len(f) == 1:
            return f[0][1]
        if len(f) == 2:  # anima: si puo' andare oltre (curva elastica)
            (p0, v0), (p1, v1) = f
            locale = (p - p0) / (p1 - p0) if p1 > p0 else 1.0
            return interpola(v0, v1, locale, self.tipo)
        p = max(0.0, min(1.0, p))
        for (p0, v0), (p1, v1) in zip(f, f[1:]):
            if p <= p1:
                locale = (p - p0) / (p1 - p0) if p1 > p0 else 1.0
                return interpola(v0, v1, locale, self.tipo)
        return f[-1][1]


@dataclass
class Animazione:
    """Un'animazione in corso: tracce, durata (secondi), curva, ``poi`` e azioni.

    ``prima``: azioni all'avvio (es. ``compari`` rende visibile il controllo);
    ``alla_fine``: azioni dopo l'ultimo fotogramma (es. ``dissolvi`` lo nasconde
    e rimette l'opacità). Non vengono eseguite se l'animazione è sostituita.
    """

    tracce: list[Traccia]
    durata: float
    curva: str = CURVA_PREDEFINITA
    poi: Any = None
    nome: str = "anima"
    prima: list[Callable[[], None]] = field(default_factory=list)
    alla_fine: list[Callable[[], None]] = field(default_factory=list)
    finita: bool = False
    sostituita: bool = False
    #: dati del motore (es. l'oggetto QVariantAnimation)
    motore: Any = None
    #: effetto grafico da far vedere (``rimbalza``, ``ruota``, ``mostra_con``...): dizionario di
    #: ``leo.grafica.effetti.dati_effetto``, per il controllo ``controllo_effetto``. Non cambia proprietà.
    effetto: dict | None = None
    controllo_effetto: Any = None

    @property
    def millisecondi(self) -> int:
        return max(0, int(round(self.durata * 1000)))

    def controlli(self) -> list[Any]:
        visti: list[Any] = []
        for t in self.tracce:
            if all(t.controllo is not c for c in visti):
                visti.append(t.controllo)
        return visti


def _riguarda(animazione: Animazione, controllo: Any) -> bool:
    """Vero se l'animazione muove ``controllo`` (una sua proprietà o un suo effetto grafico)."""
    return animazione.controllo_effetto is controllo or any(t.controllo is controllo for t in animazione.tracce)


def _meta(controllo: Any, proprieta: str):
    tipo = getattr(controllo, "tipo", None)
    return getattr(tipo, "proprieta", {}).get(proprieta) if tipo is not None else None


def _limita(controllo: Any, proprieta: str, valore: Any) -> Any:
    """Riporta un numero nei limiti della proprietà (la curva elastica può uscirne)."""
    meta = _meta(controllo, proprieta)
    if meta is None or not e_numero(valore) or isinstance(valore, bool):
        return valore
    if meta.minimo is not None and valore < meta.minimo:
        valore = type(valore)(meta.minimo)
    if meta.massimo is not None and valore > meta.massimo:
        valore = type(valore)(meta.massimo)
    return valore


def scrivi_valore(controllo: Any, proprieta: str, valore: Any) -> None:
    """Scrive un valore nel controllo (e quindi nel widget) rispettando i limiti."""
    valore = _limita(controllo, proprieta, valore)
    try:
        controllo.scrivi(proprieta, valore)
    except (ErroreValore, ErroreTipo):
        pass  # un fotogramma non valido non ferma il programma


class GestoreAnimazioni:
    """Parte pura del motore: chi anima cosa, un passo, la fine, la sostituzione.

    Il motore Qt chiama :meth:`avvia` (restituisce le animazioni rimaste senza
    tracce, da fermare), :meth:`passo` con l'avanzamento nel tempo (0..1) e
    :meth:`completa` alla fine (restituisce ``poi`` da chiamare).
    """

    def __init__(self) -> None:
        self._possessori: dict[tuple[int, str], Animazione] = {}
        self.attive: list[Animazione] = []

    # --- stato ------------------------------------------------------------
    def in_corso(self, controllo: Any = None) -> bool:
        if controllo is None:
            return bool(self.attive)
        return any(_riguarda(a, controllo) for a in self.attive)

    def possessore(self, controllo: Any, proprieta: str) -> Animazione | None:
        return self._possessori.get((id(controllo), proprieta))

    def valore_base(self, controllo: Any, proprieta: str) -> Any:
        """Valore "a riposo" della proprietà se un effetto la sta muovendo, altrimenti quello attuale."""
        a = self.possessore(controllo, proprieta)
        if a is not None:
            for t in a.tracce:
                if t.controllo is controllo and t.proprieta == proprieta and t.base is not None:
                    return t.base
        return controllo.modello.proprieta.get(proprieta)

    # --- ciclo di vita -------------------------------------------------------
    def avvia(self, animazione: Animazione) -> list[Animazione]:
        """Registra l'animazione (le sue proprietà passano a lei) ed esegue le azioni ``prima``.

        Restituisce le animazioni che sono rimaste senza tracce (da fermare).
        """
        vuote: list[Animazione] = []
        if animazione.effetto and animazione.effetto.get("tipo") in ("entrata", "uscita"):
            # `mostra_con` e `nascondi_con` sullo stesso controllo: vale l'ultima (niente `visibile`
            # rimesso a falso dalla vecchia uscita dopo che la nuova entrata l'ha mostrato)
            for vecchia in list(self.attive):
                if vecchia is not animazione and not vecchia.tracce \
                        and vecchia.controllo_effetto is animazione.controllo_effetto \
                        and (vecchia.effetto or {}).get("tipo") in ("entrata", "uscita"):
                    vecchia.sostituita = True
                    vuote.append(vecchia)
        for traccia in animazione.tracce:
            vecchia = self._possessori.get(traccia.chiave)
            if vecchia is not None and vecchia is not animazione:
                vecchia.tracce = [t for t in vecchia.tracce if t.chiave != traccia.chiave]
                if not vecchia.tracce and vecchia not in vuote:
                    vecchia.sostituita = True
                    vuote.append(vecchia)
            self._possessori[traccia.chiave] = animazione
        for v in vuote:
            self._togli(v)
        self.attive.append(animazione)
        for azione in animazione.prima:
            azione()
        return vuote

    def passo(self, animazione: Animazione, avanzamento: float) -> None:
        """Scrive nei controlli i valori all'avanzamento nel tempo ``avanzamento`` (0..1)."""
        if animazione.finita or animazione.sostituita:
            return
        p = applica_curva(animazione.curva, avanzamento)
        for traccia in list(animazione.tracce):
            scrivi_valore(traccia.controllo, traccia.proprieta, traccia.valore(p))

    def completa(self, animazione: Animazione) -> Any:
        """Ultimo fotogramma esatto, azioni finali; restituisce ``poi`` (o None)."""
        if animazione.finita or animazione.sostituita:
            return None
        for traccia in list(animazione.tracce):
            scrivi_valore(traccia.controllo, traccia.proprieta, traccia.finale)
        animazione.finita = True
        self._togli(animazione)
        for azione in animazione.alla_fine:
            azione()
        return animazione.poi

    def ferma(self, animazione: Animazione) -> None:
        """Ferma dove si trova (niente valore finale, niente ``poi``)."""
        animazione.sostituita = True
        self._togli(animazione)

    def ferma_controllo(self, controllo: Any = None) -> list[Animazione]:
        """Ferma le animazioni di un controllo (tutte con None); restituisce quelle fermate."""
        fermate = [a for a in list(self.attive) if controllo is None or _riguarda(a, controllo)]
        for a in fermate:
            self.ferma(a)
        return fermate

    def _togli(self, animazione: Animazione) -> None:
        for chiave, a in list(self._possessori.items()):
            if a is animazione:
                del self._possessori[chiave]
        if animazione in self.attive:
            self.attive.remove(animazione)


# ===========================================================================
# Piani: anima ed effetti
# ===========================================================================

def _nome_proprieta(controllo: Any, proprieta: Any, chi: str) -> str:
    if not isinstance(proprieta, str):
        raise ErroreTipo(f"`{chi}` vuole il nome della proprietà come testo, non `{nome_tipo(proprieta)}`.",
                         suggerimento="Per esempio `anima(Pulsante1, \"alto\", 50)`.")
    nome = proprieta.strip()
    tipo = controllo.tipo
    vero = tipo.risolvi_nome(nome)
    if vero not in tipo.proprieta:
        alternativo = tipo.risolvi_nome(nome.replace(" ", "_"))  # "dimensione carattere"
        if alternativo in tipo.proprieta:
            vero = alternativo
    tipo.proprieta_o_errore(vero)
    return vero


def _controllare_durata(durata: Any, chi: str) -> float:
    if isinstance(durata, bool) or not e_numero(durata):
        raise ErroreTipo(f"La durata di `{chi}` è un numero di secondi, non `{nome_tipo(durata)}`.",
                         suggerimento="Per esempio 0.3 (tre decimi di secondo).")
    durata = float(durata)
    if not math.isfinite(durata) or durata < 0:
        raise ErroreValore(f"La durata di `{chi}` non può essere negativa.",
                           suggerimento="Usa 0 per un cambio immediato, 0.3 per un'animazione rapida.")
    if durata > DURATA_MASSIMA:
        raise ErroreValore(f"La durata di `{chi}` è troppo lunga ({durata:g} secondi).",
                           suggerimento=f"Il massimo è {DURATA_MASSIMA:g} secondi.")
    return durata


def _controllare_poi(poi: Any, chi: str) -> Any:
    if poi is None or isinstance(poi, Richiamabile):
        return poi
    raise ErroreTipo(f"`poi` di `{chi}` deve essere una funzione, non `{nome_tipo(poi)}`.",
                     suggerimento="Scrivi il nome di una funzione senza parentesi: `poi = finito`.")


def _controllare_intero(valore: Any, nome: str, chi: str, minimo: int, massimo: int) -> int:
    if isinstance(valore, bool) or not e_numero(valore) or (isinstance(valore, float) and not valore.is_integer()):
        raise ErroreTipo(f"`{nome}` di `{chi}` è un numero intero, non `{nome_tipo(valore)}`.")
    valore = int(valore)
    if not minimo <= valore <= massimo:
        raise ErroreValore(f"`{nome}` di `{chi}` deve essere tra {minimo} e {massimo}.")
    return valore


def _elenco_animabili(controllo: Any) -> str:
    nomi = sorted(n for n, p in controllo.tipo.proprieta.items()
                  if p.tipo in TIPI_ANIMABILI and not p.sola_lettura and not p.solo_progettazione)
    return ", ".join(f"`{n}`" for n in nomi[:12]) + (", ..." if len(nomi) > 12 else "")


def piano_anima(controllo: Any, proprieta: Any, valore: Any, durata: Any = DURATA_PREDEFINITA,
                curva: Any = CURVA_PREDEFINITA, poi: Any = None, *, predefiniti: dict | None = None) -> Animazione:
    """Piano di ``anima``: controlla gli argomenti e prepara l'unica traccia.

    ``predefiniti``: colori da cui partire quando il colore attuale è ``""``
    (il colore del tema), per esempio ``{"colore_testo": "#111114"}``.
    """
    nome = _nome_proprieta(controllo, proprieta, "anima")
    meta = controllo.tipo.proprieta[nome]
    if meta.sola_lettura or meta.solo_progettazione:
        raise ErroreValore(f"La proprietà `{nome}` di `{controllo.nome}` non si può cambiare dal codice.")
    if meta.tipo not in TIPI_ANIMABILI:
        raise ErroreValore(
            f"La proprietà `{nome}` non si può animare: si animano i numeri e i colori.",
            suggerimento=f"Proprietà animabili di `{controllo.nome}`: {_elenco_animabili(controllo)}. "
                         f"Per cambiare `{nome}` subito scrivi `{controllo.nome}.{nome} = ...`.")
    fine = meta.converti(valore)  # stessi controlli di un'assegnazione (tipo, limiti, nomi dei colori)
    durata = _controllare_durata(durata, "anima")
    curva = normalizza_curva(curva)
    poi = _controllare_poi(poi, "anima")
    inizio = controllo.modello.proprieta.get(nome)
    if meta.tipo == "colore":
        if colore_rgba(inizio) is None and inizio in ("", None):
            partenza = (predefiniti or {}).get(nome, "")
            if colore_rgba(partenza) is None:
                rgba = colore_rgba(fine)
                # sfondo "predefinito": si parte dallo stesso colore trasparente
                partenza = colore_da_rgba(*rgba[:3], 0) if rgba is not None and "sfondo" in nome else fine
            inizio = partenza
    elif not e_numero(inizio) or isinstance(inizio, bool):
        inizio = meta.predefinito if e_numero(meta.predefinito) else fine
    traccia = Traccia(controllo, nome, meta.tipo, [(0.0, inizio), (1.0, fine)])
    return Animazione([traccia], durata, curva, poi, "anima")


def _base(gestore: GestoreAnimazioni | None, controllo: Any, proprieta: str, predefinito: Any) -> Any:
    valore = gestore.valore_base(controllo, proprieta) if gestore is not None \
        else controllo.modello.proprieta.get(proprieta)
    return valore if e_numero(valore) and not isinstance(valore, bool) else predefinito


def _serve_proprieta(controllo: Any, nomi: tuple[str, ...], chi: str) -> None:
    for n in nomi:
        if n not in controllo.tipo.proprieta:
            raise ErroreValore(f"`{chi}` non funziona su `{controllo.nome}`: il controllo non ha `{n}`.")


def piano_effetto(nome: str, controllo: Any, *, gestore: GestoreAnimazioni | None = None, poi: Any = None,
                  durata: Any = None, volte: Any = None, intensita: Any = None) -> Animazione:
    """Piano di un effetto (``lampeggia``, ``scuoti``, ``dissolvi``, ``compari``, ``pulsa``)."""
    poi = _controllare_poi(poi, nome)
    if nome == "scuoti":
        _serve_proprieta(controllo, ("sinistra",), nome)
        d = _controllare_durata(0.45 if durata is None else durata, nome)
        forza = 10 if intensita is None else intensita
        if isinstance(forza, bool) or not e_numero(forza):
            raise ErroreTipo(f"`intensita` di `scuoti` è un numero di pixel, non `{nome_tipo(forza)}`.")
        forza = max(0.0, min(200.0, float(forza)))
        x = _base(gestore, controllo, "sinistra", 0)
        scosse = (0, -1, 1, -0.8, 0.8, -0.5, 0.5, -0.2, 0)
        fotogrammi = [(i / (len(scosse) - 1), int(round(x + s * forza))) for i, s in enumerate(scosse)]
        return Animazione([Traccia(controllo, "sinistra", "intero", fotogrammi, base=x)], d, "lineare", poi, nome)

    if nome == "pulsa":
        _serve_proprieta(controllo, ("sinistra", "alto", "larghezza", "altezza"), nome)
        n = _controllare_intero(1 if volte is None else volte, "volte", nome, 1, 50)
        d = _controllare_durata(0.45 if durata is None else durata, nome)
        x, y = _base(gestore, controllo, "sinistra", 0), _base(gestore, controllo, "alto", 0)
        w, h = _base(gestore, controllo, "larghezza", 0), _base(gestore, controllo, "altezza", 0)
        scala = 1.08 if intensita is None else 1 + max(0.0, min(1.0, float(intensita) / 100))
        dw, dh = int(round(w * (scala - 1))), int(round(h * (scala - 1)))
        dw += dw % 2
        dh += dh % 2

        def ciclo(riposo: int, gonfio: int) -> list[tuple[float, int]]:
            f: list[tuple[float, int]] = [(0.0, riposo)]
            for i in range(n):
                f.append(((i + 0.5) / n, gonfio))
                f.append(((i + 1) / n, riposo))
            return f

        tracce = [Traccia(controllo, "larghezza", "intero", ciclo(w, w + dw), base=w),
                  Traccia(controllo, "altezza", "intero", ciclo(h, h + dh), base=h),
                  Traccia(controllo, "sinistra", "intero", ciclo(x, x - dw // 2), base=x),
                  Traccia(controllo, "alto", "intero", ciclo(y, y - dh // 2), base=y)]
        return Animazione(tracce, d * n, "morbida", poi, nome)

    # effetti sull'opacita'
    _serve_proprieta(controllo, ("opacità", "visibile"), nome)
    piena = _base(gestore, controllo, "opacità", 100)
    if nome == "lampeggia":
        n = _controllare_intero(3 if volte is None else volte, "volte", nome, 1, 100)
        d = _controllare_durata(0.3 if durata is None else durata, nome)
        fotogrammi: list[tuple[float, Any]] = [(0.0, piena)]
        for i in range(n):
            fotogrammi.append(((i + 0.5) / n, 0))
            fotogrammi.append(((i + 1) / n, piena))
        a = Animazione([Traccia(controllo, "opacità", "intero", fotogrammi, base=piena)], d * n, "lineare", poi,
                       nome)
        a.prima.append(lambda: scrivi_valore(controllo, "visibile", True))
        return a
    if nome == "dissolvi":
        d = _controllare_durata(0.4 if durata is None else durata, nome)
        attuale = controllo.modello.proprieta.get("opacità", piena)
        attuale = attuale if e_numero(attuale) else piena
        a = Animazione([Traccia(controllo, "opacità", "intero", [(0.0, attuale), (1.0, 0)], base=piena)], d,
                       "morbida", poi, nome)
        # alla fine: nascosto, con l'opacita' di prima (cosi' `visibile = vero` lo fa ricomparire)
        a.alla_fine.append(lambda: scrivi_valore(controllo, "visibile", False))
        a.alla_fine.append(lambda: scrivi_valore(controllo, "opacità", piena if piena > 0 else 100))
        return a
    if nome == "compari":
        d = _controllare_durata(0.4 if durata is None else durata, nome)
        visibile = bool(controllo.modello.proprieta.get("visibile", True))
        finale = piena if piena > 0 else 100
        partenza = 0
        if visibile:  # gia' visibile (o in dissolvenza): riparte dall'opacita' attuale, senza sparire prima
            attuale = controllo.modello.proprieta.get("opacità", 0)
            partenza = attuale if e_numero(attuale) else 0
        a = Animazione([Traccia(controllo, "opacità", "intero", [(0.0, partenza), (1.0, finale)], base=finale)],
                       d, "morbida", poi, nome)
        a.prima.append(lambda: scrivi_valore(controllo, "opacità", partenza))
        a.prima.append(lambda: scrivi_valore(controllo, "visibile", True))
        return a
    raise ErroreValore(f"L'effetto `{nome}` non esiste.",
                       suggerimento="Effetti: " + ", ".join(f"`{e}`" for e in EFFETTI) + ".")


# ===========================================================================
# Piani degli effetti per chi comincia (rimbalza, ruota, vola_a, mostra_con...)
# ===========================================================================

def _controllare_numero(valore: Any, nome: str, chi: str, minimo: float, massimo: float) -> float:
    if isinstance(valore, bool) or not e_numero(valore):
        raise ErroreTipo(f"`{nome}` di `{chi}` è un numero, non `{nome_tipo(valore)}`.")
    valore = float(valore)
    if not math.isfinite(valore) or not minimo <= valore <= massimo:
        raise ErroreValore(f"`{nome}` di `{chi}` deve essere tra {minimo:g} e {massimo:g}.")
    return valore


def piano_colpo(nome: str, controllo: Any, *, volte: Any = None, giri: Any = None, durata: Any = None,
                poi: Any = None) -> Animazione:
    """Piano di un effetto grafico breve (``rimbalza``, ``ruota``, ``capovolgi``, ``brilla``, ``dondola``, ``trema``).

    Non muove nessuna proprietà: lo disegna chi mostra il controllo (``leo.grafica.effetti``);
    il motore aspetta la durata e poi chiama ``poi``.
    """
    from ..grafica import effetti as ef

    poi = _controllare_poi(poi, nome)
    n = _controllare_intero(1 if volte is None else volte, "volte", nome, 1, 50)
    g = 1.0
    if nome == "ruota":
        g = _controllare_numero(1 if giri is None else giri, "giri", nome, -20, 20)
        if g == 0:
            raise ErroreValore("`giri` di `ruota` non può essere 0.",
                               suggerimento="Per esempio `ruota(1)` fa un giro, `ruota(-1)` un giro al contrario.")
    predefinita = ef.DURATE_COLPI.get(nome, 0.5)
    if nome == "ruota":
        predefinita *= max(1.0, abs(g) ** 0.5)
    d = _controllare_durata(predefinita if durata is None else durata, nome)
    totale = d * n
    a = Animazione([], totale, "lineare", poi, nome)
    altro: dict[str, Any] = {"volte": n} if n > 1 else {}
    if nome == "ruota":
        altro["giri"] = g
    a.effetto = ef.dati_effetto("colpo", nome, int(round(totale * 1000)), **altro)
    a.controllo_effetto = controllo
    return a


def piano_entrata(controllo: Any, effetto: Any = "dissolvenza", durata: Any = 0.5, poi: Any = None, *,
                  mostra: bool = True) -> Animazione:
    """Piano di ``mostra_con`` (``mostra`` vero) e ``nascondi_con``: entrata o uscita con un effetto."""
    from ..grafica import effetti as ef

    chi = "mostra_con" if mostra else "nascondi_con"
    poi = _controllare_poi(poi, chi)
    nome = ef.normalizza(effetto if effetto is not None else "dissolvenza", ef.ENTRATE, ef.SINONIMI_ENTRATE)
    if nome is None:
        if not isinstance(effetto, str):
            raise ErroreTipo(f"L'effetto di `{chi}` si scrive come testo, non `{nome_tipo(effetto)}`.")
        raise ErroreValore(f"Non conosco l'effetto `{effetto}`.",
                           suggerimento="Effetti: " + ", ".join(f'"{e}"' for e in ef.ENTRATE if e != "nessuna") + ".")
    _serve_proprieta(controllo, ("visibile",), chi)
    d = _controllare_durata(durata, chi)
    visibile = bool(controllo.modello.proprieta.get("visibile", True))
    if nome == "nessuna" or (not mostra and not visibile):
        d = 0.0  # niente da animare: cambio immediato (e `poi` lo stesso)
    a = Animazione([], d, "lineare", poi, chi)
    if mostra:
        a.prima.append(lambda: scrivi_valore(controllo, "visibile", True))
    else:
        a.alla_fine.append(lambda: scrivi_valore(controllo, "visibile", False))
    if d > 0:
        a.effetto = ef.dati_effetto("entrata" if mostra else "uscita", nome, int(round(d * 1000)))
        a.controllo_effetto = controllo
    return a


def piano_vola(controllo: Any, x: Any, y: Any, durata: Any = 0.6, curva: Any = CURVA_PREDEFINITA,
               poi: Any = None) -> Animazione:
    """Piano di ``vola_a``: ``sinistra`` e ``alto`` insieme, con la stessa curva."""
    a = piano_anima(controllo, "sinistra", x, durata, curva, poi)
    b = piano_anima(controllo, "alto", y, durata, curva, None)
    a.tracce += b.tracce
    a.nome = "vola_a"
    return a


def piano_ingrandisci(controllo: Any, fattore: Any = 1.2, durata: Any = 0.3, curva: Any = CURVA_PREDEFINITA,
                      poi: Any = None) -> Animazione:
    """Piano di ``ingrandisci``: larghezza e altezza per ``fattore``, restando centrato (anche il carattere)."""
    f = _controllare_numero(fattore, "fattore", "ingrandisci", 0.05, 20)
    _serve_proprieta(controllo, ("sinistra", "alto", "larghezza", "altezza"), "ingrandisci")
    p = controllo.modello.proprieta
    x, y = int(p.get("sinistra", 0) or 0), int(p.get("alto", 0) or 0)
    w, h = int(p.get("larghezza", 0) or 0), int(p.get("altezza", 0) or 0)
    nw, nh = max(1, int(round(w * f))), max(1, int(round(h * f)))
    nx, ny = x - (nw - w) // 2, y - (nh - h) // 2
    a = piano_anima(controllo, "larghezza", nw, durata, curva, poi)
    for nome, valore in (("altezza", nh), ("sinistra", nx), ("alto", ny)):
        a.tracce += piano_anima(controllo, nome, valore, durata, curva, None).tracce
    carattere = p.get("dimensione_carattere", 0)
    if "dimensione_carattere" in controllo.tipo.proprieta and e_numero(carattere) and not isinstance(carattere, bool) \
            and carattere > 0:
        nuovo = max(1, int(round(carattere * f)))
        a.tracce += piano_anima(controllo, "dimensione_carattere", nuovo, durata, curva, None).tracce
    a.nome = "ingrandisci"
    return a


def avvisa_effetto(animazione: Animazione) -> None:
    """Fa vedere l'effetto grafico dell'animazione (se ne ha uno) a chi disegna il controllo."""
    if animazione.effetto and animazione.controllo_effetto is not None:
        from ..grafica.effetti import notifica

        notifica(animazione.controllo_effetto, animazione.effetto)


def ferma_effetti(animazioni: list[Animazione]) -> None:
    """Le animazioni fermate smettono anche di farsi vedere."""
    from ..grafica.effetti import notifica

    for a in animazioni:
        if a.effetto and a.controllo_effetto is not None:
            notifica(a.controllo_effetto, {"tipo": "ferma", "effetto": a.effetto.get("effetto", ""), "durata": 0})


# ===========================================================================
# Motore attivo e funzioni di libreria
# ===========================================================================

_MOTORE: dict[str, Any] = {"attivo": None}


class MotoreImmediato:
    """Motore senza tempo: lo stato finale subito (e ``poi`` subito, se c'è l'interprete).

    Serve ai programmi con finestre eseguiti senza Qt (prove automatiche, strumenti
    che caricano un progetto senza mostrarlo): le animazioni non si vedono, ma il
    programma fa le stesse cose.
    """

    def __init__(self, interprete: Any = None) -> None:
        self.interprete = interprete
        self.gestore = GestoreAnimazioni()

    def colori_predefiniti(self, controllo: Any) -> dict:
        return {}

    def avvia(self, animazione: Animazione) -> None:
        self.gestore.avvia(animazione)
        poi = self.gestore.completa(animazione)
        if poi is not None and self.interprete is not None:
            self.interprete.chiama(poi, [])

    def aspetta(self) -> None:
        return None

    def ferma(self, controllo: Any = None) -> None:
        self.gestore.ferma_controllo(controllo)


def _ponte_con_finestre(ponte: Any) -> bool:
    try:
        from ..grafica.ponte import PonteConsole, PonteGrafico
    except ImportError:  # pragma: no cover
        return False
    return isinstance(ponte, PonteGrafico) and not isinstance(ponte, PonteConsole)


def imposta_motore(motore: Any) -> None:
    """Il runtime grafico registra qui il suo motore (None quando il programma finisce)."""
    _MOTORE["attivo"] = motore


def motore_attivo() -> Any:
    return _MOTORE["attivo"]


def _motore(interprete: Any, chi: str) -> Any:
    if interprete is not None:
        ponte = getattr(interprete, "ponte_grafico", None)
        motore = getattr(ponte, "animatore", None)
        if motore is None and _ponte_con_finestre(ponte):
            motore = MotoreImmediato(interprete)  # finestre senza Qt: stato finale subito
    else:
        # metodi dei controlli (`Pulsante1.scuoti()`): i controlli esistono solo nei programmi
        # con finestre; senza il motore Qt lo stato finale arriva subito
        motore = _MOTORE["attivo"] or MotoreImmediato()
    if motore is None:
        raise ErroreValore(
            f"`{chi}` funziona solo nei programmi con finestre.",
            suggerimento="Le animazioni muovono i controlli di una finestra: crea un progetto con una finestra "
                         f"in Leo Studio e usa `{chi}` dentro un `quando`, per esempio in `quando Pulsante1.clic`.")
    return motore


def _controllo(oggetto: Any, chi: str) -> Any:
    if isinstance(oggetto, OggettoControllo) and hasattr(oggetto, "modello") and hasattr(oggetto, "tipo"):
        if getattr(oggetto.tipo, "invisibile", False):
            raise ErroreValore(f"`{oggetto.nome}` non si vede nella finestra: non si può animare con `{chi}`.")
        return oggetto
    suggerimento = "Per esempio `" + chi + "(Pulsante1)`."
    if isinstance(oggetto, str):
        suggerimento = f"Scrivi il nome del controllo senza virgolette: `{chi}({oggetto})`."
    raise ErroreTipo(f"`{chi}` vuole un controllo della finestra, non `{nome_tipo(oggetto)}`.",
                     suggerimento=suggerimento)


def anima_controllo(controllo: Any, proprieta: Any, valore: Any, durata: Any = DURATA_PREDEFINITA,
                    curva: Any = CURVA_PREDEFINITA, poi: Any = None, *, interprete: Any = None) -> None:
    motore = _motore(interprete, "anima")
    controllo = _controllo(controllo, "anima")
    piano = piano_anima(controllo, proprieta, valore, durata, curva, poi,
                        predefiniti=motore.colori_predefiniti(controllo))
    motore.avvia(piano)


def effetto_controllo(nome: str, controllo: Any, *, interprete: Any = None, **opzioni: Any) -> None:
    motore = _motore(interprete, nome)
    controllo = _controllo(controllo, nome)
    motore.avvia(piano_effetto(nome, controllo, gestore=motore.gestore, **opzioni))


def colpo_controllo(nome: str, controllo: Any, *, interprete: Any = None, **opzioni: Any) -> None:
    motore = _motore(interprete, nome)
    controllo = _controllo(controllo, nome)
    motore.avvia(piano_colpo(nome, controllo, **opzioni))


def entrata_controllo(controllo: Any, effetto: Any, durata: Any, poi: Any, *, mostra: bool,
                      interprete: Any = None) -> None:
    chi = "mostra_con" if mostra else "nascondi_con"
    motore = _motore(interprete, chi)
    controllo = _controllo(controllo, chi)
    motore.avvia(piano_entrata(controllo, effetto, durata, poi, mostra=mostra))


def vola_controllo(controllo: Any, x: Any, y: Any, durata: Any = 0.6, curva: Any = CURVA_PREDEFINITA,
                   poi: Any = None, *, interprete: Any = None) -> None:
    motore = _motore(interprete, "vola_a")
    controllo = _controllo(controllo, "vola_a")
    motore.avvia(piano_vola(controllo, x, y, durata, curva, poi))


def ingrandisci_controllo(controllo: Any, fattore: Any = 1.2, durata: Any = 0.3, curva: Any = CURVA_PREDEFINITA,
                          poi: Any = None, *, interprete: Any = None) -> None:
    motore = _motore(interprete, "ingrandisci")
    controllo = _controllo(controllo, "ingrandisci")
    motore.avvia(piano_ingrandisci(controllo, fattore, durata, curva, poi))


@funzione("anima", interprete=True)
def anima(interprete, oggetto, proprieta, valore, durata=DURATA_PREDEFINITA, curva=CURVA_PREDEFINITA, poi=None):
    """anima(oggetto, proprieta, valore, durata = 0.3, curva = "morbida", poi = nulla): porta pian piano
    una proprietà di un controllo a un nuovo valore, senza fermare il programma.

    Esempio: `anima(Pulsante1, "alto", 50, 0.3, "rimbalzo")`, oppure
    `anima Pulsante1.alto a 50 in 0.3 secondi con curva "rimbalzo"`. Si animano numeri
    (sinistra, alto, larghezza, altezza, opacità, dimensione_carattere...) e colori
    (colore_sfondo, colore_testo). Curve: "lineare", "morbida", "rimbalzo", "elastica",
    "veloce", "lenta". `poi` è una funzione chiamata alla fine. Solo nei programmi con finestre.
    """
    anima_controllo(oggetto, proprieta, valore, durata, curva, poi, interprete=interprete)


@funzione("lampeggia", interprete=True)
def lampeggia(interprete, oggetto, volte=3, durata=0.3, poi=None):
    """lampeggia(oggetto, volte = 3, durata = 0.3, poi = nulla): fa lampeggiare un controllo
    (`volte` lampi di `durata` secondi l'uno). Esempio: `lampeggia(Etichetta1, 2)`."""
    effetto_controllo("lampeggia", oggetto, interprete=interprete, volte=volte, durata=durata, poi=poi)


@funzione("scuoti", interprete=True)
def scuoti(interprete, oggetto, intensita=10, durata=0.45, poi=None):
    """scuoti(oggetto, intensita = 10, durata = 0.45, poi = nulla): scuote un controllo a destra e a
    sinistra (per esempio dopo una password sbagliata) e lo rimette al suo posto."""
    effetto_controllo("scuoti", oggetto, interprete=interprete, intensita=intensita, durata=durata, poi=poi)


@funzione("dissolvi", interprete=True)
def dissolvi(interprete, oggetto, durata=0.4, poi=None):
    """dissolvi(oggetto, durata = 0.4, poi = nulla): fa sparire un controllo sfumandolo;
    alla fine `visibile` diventa falso."""
    effetto_controllo("dissolvi", oggetto, interprete=interprete, durata=durata, poi=poi)


@funzione("compari", interprete=True)
def compari(interprete, oggetto, durata=0.4, poi=None):
    """compari(oggetto, durata = 0.4, poi = nulla): fa comparire un controllo sfumandolo
    (lo rende anche visibile)."""
    effetto_controllo("compari", oggetto, interprete=interprete, durata=durata, poi=poi)


@funzione("pulsa", interprete=True)
def pulsa(interprete, oggetto, volte=1, durata=0.45, poi=None):
    """pulsa(oggetto, volte = 1, durata = 0.45, poi = nulla): fa "battere" un controllo:
    si ingrandisce un poco dal centro e torna com'era."""
    effetto_controllo("pulsa", oggetto, interprete=interprete, volte=volte, durata=durata, poi=poi)


@funzione("aspetta_animazioni", interprete=True)
def aspetta_animazioni(interprete):
    """aspetta_animazioni(): aspetta che finiscano tutte le animazioni in corso
    (l'interfaccia resta viva, come con `attendi`)."""
    _motore(interprete, "aspetta_animazioni").aspetta()


@funzione("ferma_animazioni", interprete=True)
def ferma_animazioni(interprete, oggetto=None):
    """ferma_animazioni(oggetto = nulla): ferma le animazioni di un controllo (senza argomento:
    tutte), lasciandolo dov'è in quel momento; il loro `poi` non viene chiamato."""
    motore = _motore(interprete, "ferma_animazioni")
    motore.ferma(None if oggetto is None else _controllo(oggetto, "ferma_animazioni"))


__all__ = ["CURVE", "EFFETTI", "TIPI_ANIMABILI", "Traccia", "Animazione", "GestoreAnimazioni", "applica_curva",
           "normalizza_curva", "interpola", "interpola_colore", "piano_anima", "piano_effetto", "imposta_motore",
           "motore_attivo", "anima_controllo", "effetto_controllo", "piano_colpo", "piano_entrata", "piano_vola",
           "piano_ingrandisci", "avvisa_effetto", "ferma_effetti", "colpo_controllo", "entrata_controllo",
           "vola_controllo", "ingrandisci_controllo"]
