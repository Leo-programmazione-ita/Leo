"""Libreria: modelli di testo avanzati (gruppi, modelli pronti, controlli dei codici italiani).

Completa ``leo.libreria.modelli`` (``trova_tutti``, ``trova_primo``,
``corrisponde``, ``contiene_modello``, ``sostituisci_modello``,
``dividi_modello``) senza ripeterne le funzioni:

* ``trova_corrispondenza`` e ``trova_corrispondenze``: i pezzi trovati come
  valori di tipo ``corrispondenza``, con posizione e **gruppi** (anche con nome);
* ``gruppi_modello``: i gruppi del primo pezzo trovato, pronti da usare;
* ``sostituisci_con_gruppi``: sostituzioni che riusano i gruppi (``$1``,
  ``$nome``, ``\\1``) o una funzione che riceve la corrispondenza;
* ``modello(nome)`` e ``modelli_pronti()``: modelli già scritti per i casi
  più comuni (email, telefono italiano, codice fiscale, CAP, partita IVA...);
* ``e_email``, ``e_codice_fiscale``, ``e_partita_iva``, ``e_iban``, ``e_cap``:
  controlli pronti, con il calcolo dei caratteri di controllo dove esiste.

I gruppi con nome si scrivono ``(?P<nome>...)`` oppure, più corto,
``(?<nome>...)``.
"""

from __future__ import annotations

import difflib
import re
from typing import Any

from ..errori import ErroreTipo, ErroreValore
from ..valori import Richiamabile
from .funzionali import chiama_funzione
from .generali import articolo, funzione_libreria, mostra, richiedi_intero, richiedi_testo
from .modelli import _compila
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta

#: Testi più lunghi di così non si controllano con i modelli pronti (sono sicuramente sbagliati).
_LUNGHEZZA_MASSIMA_CODICE = 100

# ---------------------------------------------------------------------------
# Modelli pronti
# ---------------------------------------------------------------------------

#: nome -> (modello, descrizione). Modelli "aperti" (senza ^ e $): vanno bene sia con
#: ``trova_tutti`` sia con ``corrisponde`` (che controlla tutto il testo).
MODELLI_PRONTI: dict[str, tuple[str, str]] = {
    "email": (r"[A-Za-z0-9._%+-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}",
              "un indirizzo email, come ada@esempio.it"),
    "telefono italiano": (r"(?:(?:\+|00)39[ .-]?)?(?:3\d{2}[ .-]?\d{3}[ .-]?\d{3,4}|0\d{1,4}[ .-]?\d{4,8})",
                          "un numero di telefono italiano, fisso o cellulare, anche con +39"),
    "cellulare": (r"(?:(?:\+|00)39[ .-]?)?3\d{2}[ .-]?\d{3}[ .-]?\d{3,4}",
                  "un numero di cellulare italiano (inizia con 3)"),
    "codice fiscale": (r"[A-Za-z]{6}[0-9LMNPQRSTUVlmnpqrstuv]{2}[ABCDEHLMPRSTabcdehlmprst]"
                       r"[0-9LMNPQRSTUVlmnpqrstuv]{2}[A-Za-z][0-9LMNPQRSTUVlmnpqrstuv]{3}[A-Za-z]",
                       "un codice fiscale italiano di 16 caratteri"),
    "cap": (r"(?<!\d)\d{5}(?!\d)", "un codice di avviamento postale (5 cifre)"),
    "partita iva": (r"(?<![0-9A-Za-z])(?:IT)?\d{11}(?!\d)", "una partita IVA italiana (11 cifre, anche con IT davanti)"),
    "iban": (r"[A-Z]{2}\d{2}(?: ?[A-Z0-9]){11,30}", "un codice IBAN, come IT60X0542811101000000123456"),
    "url": (r"(?:https?|ftp)://[^\s<>\"']+", "un indirizzo web che inizia con http:// o https://"),
    "numero": (r"[+-]?\d+(?:[.,]\d+)?", "un numero intero o con la virgola (anche col segno)"),
    "intero": (r"[+-]?\d+", "un numero intero"),
    "data": (r"(?<!\d)\d{1,2}[/.-]\d{1,2}[/.-]\d{4}(?!\d)", "una data come 25/12/2026"),
    "ora": (r"(?<!\d)\d{1,2}:\d{2}(?::\d{2})?(?!\d)", "un orario come 14:30 o 14:30:15"),
    "targa": (r"[A-Za-z]{2} ?\d{3} ?[A-Za-z]{2}", "una targa automobilistica italiana, come AB 123 CD"),
    "parola": (r"[^\W\d_]+(?:'[^\W\d_]+)*", "una parola (solo lettere)"),
}


def _chiave_modello(nome: str) -> str:
    return " ".join(nome.strip().lower().replace("_", " ").replace("-", " ").split())


@funzione_libreria("modello")
def modello(nome):
    """modello(nome): un modello di testo già pronto, da usare con `trova_tutti`, `corrisponde`...

    Nomi disponibili: "email", "telefono italiano", "cellulare", "codice fiscale", "cap",
    "partita iva", "iban", "url", "numero", "intero", "data", "ora", "targa", "parola".
    Esempi: `trova_tutti("scrivi a ada@esempio.it", modello("email"))` è ["ada@esempio.it"];
    `corrisponde("20121", modello("cap"))` è `vero`.
    """
    richiedi_testo(nome, "modello", "nome")
    chiave = _chiave_modello(nome)
    if chiave in MODELLI_PRONTI:
        return MODELLI_PRONTI[chiave][0]
    simili = difflib.get_close_matches(chiave, list(MODELLI_PRONTI), n=1, cutoff=0.6)
    suggerimento = (f"Forse intendevi `modello(\"{simili[0]}\")`?" if simili
                    else "Per vedere tutti i modelli pronti usa `modelli_pronti()`.")
    raise ErroreValore(f"Non conosco un modello pronto chiamato {mostra(nome)}.", suggerimento=suggerimento)


@funzione_libreria("modelli_pronti")
def modelli_pronti():
    """modelli_pronti(): un dizionario con i nomi dei modelli pronti e cosa riconoscono.

    Esempio: `per ogni nome in modelli_pronti() fai stampa(nome) fine`.
    """
    return {nome: descrizione for nome, (_m, descrizione) in MODELLI_PRONTI.items()}


# ---------------------------------------------------------------------------
# Corrispondenze e gruppi
# ---------------------------------------------------------------------------

# (?<nome>...) come in JavaScript/.NET -> (?P<nome>...) di Python (ma non (?<= e (?<!)
_GRUPPO_CORTO = re.compile(r"\(\?<(?![=!])")


def _regola(modello_: Any, nome_funzione: str, ignora_maiuscole: Any) -> "re.Pattern[str]":
    if isinstance(modello_, str):
        modello_ = _GRUPPO_CORTO.sub("(?P<", modello_)
    return _compila(modello_, nome_funzione, ignora_maiuscole)


class Corrispondenza(OggettoLibreria):
    """Valore Leo di tipo ``corrispondenza``: un pezzo di testo trovato da un modello."""

    NOME_TIPO_DANTE = "corrispondenza"
    SUGGERIMENTO_MODIFICA = "Una corrispondenza si può solo leggere: copia i valori in variabili tue."

    def __init__(self, m: "re.Match[str]") -> None:
        self.testo = m.group(0)
        self.inizio = m.start()
        self.fine = m.end()
        self.gruppi = list(m.groups())
        self.nomi = dict(m.groupdict())
        self.indice_nomi = dict(m.re.groupindex)

    def testo_dante(self) -> str:
        return self.testo

    def __repr__(self) -> str:
        return f"Corrispondenza({self.testo!r})"


proprieta(Corrispondenza, "testo")(lambda c: c.testo)
proprieta(Corrispondenza, "inizio")(lambda c: c.inizio)
proprieta(Corrispondenza, "fine")(lambda c: c.fine)
proprieta(Corrispondenza, "lunghezza")(lambda c: c.fine - c.inizio)
proprieta(Corrispondenza, "gruppi")(lambda c: list(c.gruppi))
proprieta(Corrispondenza, "gruppi_con_nome")(lambda c: dict(c.nomi))


@metodo_oggetto(Corrispondenza, "gruppo")
def corrispondenza_gruppo(c, quale=0):
    """corrispondenza.gruppo(quale = 0): il testo di un gruppo, dal numero (1, 2...) o dal nome.

    `gruppo(0)` è tutto il pezzo trovato; un gruppo che non ha trovato niente è `nulla`.
    Esempio: `trova_corrispondenza("ore 14:30", "(\\\\d+):(\\\\d+)").gruppo(2)` è "30".
    """
    if isinstance(quale, str):
        if quale not in c.nomi:
            nomi = ", ".join(f"`{n}`" for n in c.nomi) or "nessuno"
            raise ErroreValore(f"Il modello non ha un gruppo chiamato {mostra(quale)} (gruppi con nome: {nomi}).",
                               suggerimento="Un gruppo con nome si scrive `(?<nome>...)`.")
        return c.nomi[quale]
    richiedi_intero(quale, "gruppo", "quale")
    if quale == 0:
        return c.testo
    if not 1 <= quale <= len(c.gruppi):
        raise ErroreValore(f"Il modello ha {len(c.gruppi)} gruppi: non esiste il gruppo {quale}.",
                           suggerimento="I gruppi sono le parti tra parentesi tonde e si contano da 1.")
    return c.gruppi[quale - 1]


@funzione_libreria("trova_corrispondenza")
def trova_corrispondenza(testo, modello, ignora_maiuscole=False):
    """trova_corrispondenza(testo, modello, ignora_maiuscole = falso): il primo pezzo trovato con i suoi gruppi, o `nulla`.

    Il risultato ha `testo`, `inizio`, `fine`, `gruppi`, `gruppi_con_nome` e il metodo `gruppo(n)`.
    Esempio: `variabile c = trova_corrispondenza("nata il 5/10/2026", "(?<g>\\\\d+)/(?<m>\\\\d+)/(?<a>\\\\d+)")`
    e poi `c.gruppo("a")` è "2026" e `c.inizio` è 8.
    """
    richiedi_testo(testo, "trova_corrispondenza", "testo")
    m = _regola(modello, "trova_corrispondenza", ignora_maiuscole).search(testo)
    return Corrispondenza(m) if m else None


@funzione_libreria("trova_corrispondenze")
def trova_corrispondenze(testo, modello, ignora_maiuscole=False):
    """trova_corrispondenze(testo, modello, ignora_maiuscole = falso): la lista di tutti i pezzi trovati, con i loro gruppi.

    Esempio: `per ogni c in trova_corrispondenze("a=1, b=2", "(\\\\w)=(\\\\d)") fai stampa(c.gruppo(1), c.gruppo(2)) fine`.
    """
    richiedi_testo(testo, "trova_corrispondenze", "testo")
    return [Corrispondenza(m) for m in _regola(modello, "trova_corrispondenze", ignora_maiuscole).finditer(testo)]


@funzione_libreria("gruppi_modello")
def gruppi_modello(testo, modello, ignora_maiuscole=False):
    """gruppi_modello(testo, modello, ignora_maiuscole = falso): i gruppi del primo pezzo trovato, o `nulla`.

    Con gruppi con nome restituisce un dizionario, altrimenti la lista dei gruppi.
    Esempi: `gruppi_modello("Rossi, Mario", "(?<cognome>\\\\w+), (?<nome>\\\\w+)")` è
    {"cognome": "Rossi", "nome": "Mario"}; `gruppi_modello("14:30", "(\\\\d+):(\\\\d+)")` è ["14", "30"].
    """
    richiedi_testo(testo, "gruppi_modello", "testo")
    m = _regola(modello, "gruppi_modello", ignora_maiuscole).search(testo)
    if m is None:
        return None
    if m.re.groupindex:
        return dict(m.groupdict())
    return list(m.groups())


_RIFERIMENTO = re.compile(r"\$(\$|\d{1,2}|[^\W\d]\w*)|\\(\d{1,2})|\\g<(\w+)>")


def _espandi(sostituto: str, m: "re.Match[str]") -> str:
    def uno(r: "re.Match[str]") -> str:
        dollaro, barra, nome_g = r.groups()
        chiave: Any = dollaro if dollaro is not None else (barra if barra is not None else nome_g)
        if chiave == "$":
            return "$"
        if chiave.isdigit():
            n = int(chiave)
            if n > (m.re.groups or 0):
                raise ErroreValore(f"Nel sostituto c'è il gruppo {n}, ma il modello ha solo {m.re.groups} gruppi.",
                                   suggerimento="Per scrivere il simbolo del dollaro usa `$$`.")
            return m.group(n) or ""
        if chiave not in m.re.groupindex:
            raise ErroreValore(f"Nel sostituto c'è il gruppo `{chiave}`, ma il modello non ha un gruppo con quel nome.",
                               suggerimento="Un gruppo con nome si scrive `(?<nome>...)`; per il dollaro usa `$$`.")
        return m.group(chiave) or ""

    return _RIFERIMENTO.sub(uno, sostituto)


@funzione_libreria("sostituisci_con_gruppi", interprete=True)
def sostituisci_con_gruppi(interprete, testo, modello, sostituto, quante=0, ignora_maiuscole=False):
    """sostituisci_con_gruppi(testo, modello, sostituto, quante = 0, ignora_maiuscole = falso): sostituisce riusando i gruppi.

    Nel `sostituto` `$1`, `$2`... (o `\\\\1`) sono i gruppi per numero, `$nome` i gruppi con nome,
    `$$` il simbolo del dollaro. Il `sostituto` può anche essere una funzione che riceve la
    `corrispondenza` e restituisce il testo. `quante` = quante sostituzioni fare (0 = tutte).
    Esempi: `sostituisci_con_gruppi("Rossi Mario", "(\\\\w+) (\\\\w+)", "$2 $1")` è "Mario Rossi";
    `sostituisci_con_gruppi("25/12/2026", "(?<g>\\\\d+)/(?<m>\\\\d+)/(?<a>\\\\d+)", "$a-$m-$g")` è "2026-12-25".
    """
    richiedi_testo(testo, "sostituisci_con_gruppi", "testo")
    regola = _regola(modello, "sostituisci_con_gruppi", ignora_maiuscole)
    richiedi_intero(quante, "sostituisci_con_gruppi", "quante")
    if quante < 0:
        raise ErroreValore(f"`quante` non può essere negativo (hai scritto {quante}).",
                           suggerimento="Scrivi 0 per sostituire tutto, 1 per il primo pezzo e così via.")
    if isinstance(sostituto, str):
        return regola.sub(lambda m: _espandi(sostituto, m), testo, count=quante)
    if isinstance(sostituto, Richiamabile):
        def con_funzione(m: "re.Match[str]") -> str:
            r = chiama_funzione(interprete, sostituto, [Corrispondenza(m)])
            if not isinstance(r, str):
                raise ErroreTipo(f"La funzione data a `sostituisci_con_gruppi` deve restituire un testo, "
                                 f"non {articolo(r)}.", suggerimento="Trasforma il risultato con `testo(...)`.")
            return r
        return regola.sub(con_funzione, testo, count=quante)
    raise ErroreTipo(f"Il `sostituto` di `sostituisci_con_gruppi` deve essere un testo o una funzione, "
                     f"non {articolo(sostituto)}.")


# ---------------------------------------------------------------------------
# Controlli pronti
# ---------------------------------------------------------------------------

def _compatto(valore: Any, nome_funzione: str) -> str | None:
    """Il testo senza spazi e in maiuscolo, o ``None`` se è troppo lungo per essere un codice."""
    richiedi_testo(valore, nome_funzione, "testo")
    if len(valore) > _LUNGHEZZA_MASSIMA_CODICE:
        return None
    return "".join(valore.split()).upper()


_RE_EMAIL = re.compile(MODELLI_PRONTI["email"][0])


@funzione_libreria("e_email")
def e_email(testo):
    """e_email(testo): `vero` se il testo è scritto come un indirizzo email.

    Controlla la forma (non se la casella esiste davvero). Esempi: `e_email("ada@esempio.it")` è `vero`;
    `e_email("ada@esempio")` è `falso`.
    """
    richiedi_testo(testo, "e_email", "testo")
    t = testo.strip()
    if not 3 <= len(t) <= 254 or ".." in t:
        return False
    if _RE_EMAIL.fullmatch(t) is None:
        return False
    locale = t.split("@", 1)[0]
    return len(locale) <= 64 and not locale.startswith(".") and not locale.endswith(".")


# valori dei caratteri in posizione dispari (1a, 3a, ...) per il carattere di controllo
_DISPARI = dict(zip("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ",
                    [1, 0, 5, 7, 9, 13, 15, 17, 19, 21, 1, 0, 5, 7, 9, 13, 15, 17, 19, 21,
                     2, 4, 18, 20, 11, 3, 6, 8, 12, 14, 16, 10, 22, 25, 24, 23]))
_RE_CODICE_FISCALE = re.compile(r"[A-Z]{6}[0-9LMNPQRSTUV]{2}[ABCDEHLMPRST][0-9LMNPQRSTUV]{2}[A-Z][0-9LMNPQRSTUV]{3}[A-Z]")


def carattere_controllo_cf(primi15: str) -> str:
    """La lettera di controllo (16o carattere) di un codice fiscale dai primi 15 caratteri."""
    totale = 0
    for i, c in enumerate(primi15):
        if i % 2 == 0:
            totale += _DISPARI[c]
        else:
            totale += int(c) if c.isdigit() else ord(c) - ord("A")
    return chr(ord("A") + totale % 26)


@funzione_libreria("e_codice_fiscale")
def e_codice_fiscale(testo):
    """e_codice_fiscale(testo): `vero` se il codice fiscale è scritto bene e il carattere di controllo torna.

    Accetta maiuscole, minuscole, spazi e i codici "omocodici". Esempi:
    `e_codice_fiscale("RSSMRA85T10A562S")` è `vero`; `e_codice_fiscale("RSSMRA85T10A562A")` è `falso`.
    """
    cf = _compatto(testo, "e_codice_fiscale")
    if cf is None or _RE_CODICE_FISCALE.fullmatch(cf) is None:
        return False
    return carattere_controllo_cf(cf[:15]) == cf[15]


@funzione_libreria("e_partita_iva")
def e_partita_iva(testo):
    """e_partita_iva(testo): `vero` se la partita IVA italiana ha 11 cifre e la cifra di controllo torna.

    Accetta anche "IT" davanti e gli spazi. Esempi: `e_partita_iva("12345678903")` è `vero`;
    `e_partita_iva("12345678901")` è `falso`.
    """
    piva = _compatto(testo, "e_partita_iva")
    if piva is None:
        return False
    if piva.startswith("IT"):
        piva = piva[2:]
    if len(piva) != 11 or not piva.isascii() or not piva.isdigit() or piva == "0" * 11:
        return False
    totale = 0
    for i, c in enumerate(piva[:10]):
        n = int(c)
        if i % 2 == 1:
            n *= 2
            if n > 9:
                n -= 9
        totale += n
    return (10 - totale % 10) % 10 == int(piva[10])


#: Lunghezza dell'IBAN nei paesi più comuni (gli altri: da 15 a 34 caratteri).
LUNGHEZZE_IBAN = {
    "IT": 27, "SM": 27, "VA": 22, "DE": 22, "FR": 27, "ES": 24, "GB": 22, "CH": 21, "AT": 20,
    "BE": 16, "NL": 18, "PT": 25, "IE": 22, "LU": 20, "MT": 31, "GR": 27, "SI": 19, "HR": 21,
    "PL": 28, "RO": 24, "SE": 24, "DK": 18, "NO": 15, "FI": 18, "CZ": 24, "SK": 24, "HU": 28,
}


@funzione_libreria("e_iban")
def e_iban(testo):
    """e_iban(testo): `vero` se il codice IBAN ha la lunghezza giusta e supera il controllo "modulo 97".

    Gli spazi non contano. Esempi: `e_iban("IT60 X054 2811 1010 0000 0123 456")` è `vero`;
    `e_iban("IT61X0542811101000000123456")` è `falso`.
    """
    iban = _compatto(testo, "e_iban")
    if iban is None or not iban.isascii() or not iban.isalnum() or len(iban) < 15:
        return False
    paese = iban[:2]
    if not paese.isalpha() or not iban[2:4].isdigit():
        return False
    atteso = LUNGHEZZE_IBAN.get(paese)
    if (atteso is not None and len(iban) != atteso) or len(iban) > 34:
        return False
    riordinato = iban[4:] + iban[:4]
    numero = "".join(str(int(c, 36)) for c in riordinato)
    return int(numero) % 97 == 1


@funzione_libreria("e_cap")
def e_cap(testo):
    """e_cap(testo): `vero` se il testo è un codice di avviamento postale italiano (5 cifre).

    Esempi: `e_cap("00184")` è `vero`; `e_cap("1234")` è `falso`.
    """
    cap = _compatto(testo, "e_cap")
    return cap is not None and len(cap) == 5 and cap.isascii() and cap.isdigit()
