"""Libreria: suoni e musica (note, melodie, accordi, forme d'onda, rumore, file WAV).

Un suono è un valore Leo di tipo ``suono``: una sequenza di campioni (numeri
tra -1 e 1, :data:`FREQUENZA_CAMPIONAMENTO` al secondo, un solo canale) creata
in Python puro, senza librerie esterne. Si può suonare, salvare in WAV,
unire ad altri suoni e modificare (volume, dissolvenza, ripetizione...).

Esempio::

    suona(melodia("do4 re4 mi4 fa4 sol2", tempo = 100))
    variabile s = accordo("do maggiore", battiti = 2).dissolvenza(uscita = 0.5)
    s.salva("accordo.wav")

Le **note** si scrivono in italiano: ``do re mi fa sol la si``, con ``#`` (diesis)
o ``b`` (bemolle) attaccati (``fa#``, ``sib``) e ``+``/``-`` per l'ottava sopra
o sotto (``do+``). L'ottava 4 è quella centrale (``la`` = 440 Hz).

Nelle **melodie** (``melodia("do4 re4 mi2")``) il numero dopo la nota è la sua
durata come nel solfeggio: 1 = intero (4 battiti), 2 = metà (2 battiti),
4 = quarto (1 battito), 8 = ottavo, 16 = sedicesimo; un punto la allunga di metà
(``do4.``). Se il numero manca vale la durata precedente. ``p`` è la pausa,
``(do mi sol)2`` un accordo, ``o5`` cambia l'ottava di partenza.

**Riproduzione** non bloccante (``aspetta = falso``), un suono alla volta:

1. su Windows con ``winsound`` (file WAV temporaneo, ``SND_ASYNC``);
2. altrimenti con QtMultimedia (``QSoundEffect``) se c'è PySide6, dentro un
   programma con finestre; oppure con il lettore del sistema (``afplay`` su
   macOS, ``paplay``/``aplay`` su Linux);
3. se niente di questo è disponibile il suono viene salvato in un file WAV e
   Leo lo dice. Con ``LEO_SUONI=muto`` non si sente e non si salva nulla.

La parte pura (analisi delle note, sintesi, WAV) non dipende dal sistema ed è
testata da sola; la scelta del lettore è in :func:`scegli_lettore`.
"""

from __future__ import annotations

import atexit
import io
import math
import os
import random
import re
import shutil
import subprocess
import sys
import tempfile
import time
import wave
from array import array
from typing import Any, Callable, Sequence

from .. import variabile_ambiente
from ..errori import ErroreDante, ErroreFile, ErroreTipo, ErroreValore
from ..valori import e_numero, rappresenta
from .generali import articolo, funzione_libreria, mostra
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta

# ===========================================================================
# 1. Logica pura: note, durate, melodie
# ===========================================================================

#: Campioni al secondo dei suoni creati da Leo.
FREQUENZA_CAMPIONAMENTO = 22050
#: Frequenza del la centrale (la4).
LA_CENTRALE = 440.0
OTTAVA_PREDEFINITA = 4
TEMPO_PREDEFINITO = 120
VOLUME_PREDEFINITO = 0.8
#: Durata massima di un suono (protegge da melodie o ripetizioni infinite).
DURATA_MASSIMA = 600.0

#: Semitoni dal do di ogni nota.
NOTE = {"do": 0, "re": 2, "mi": 4, "fa": 5, "sol": 7, "la": 9, "si": 11}
#: Forme d'onda: nome canonico e altri nomi accettati.
FORME_ONDA = ("sinusoide", "quadra", "triangolo", "dente_di_sega")
_ALIAS_FORME = {"sinusoide": "sinusoide", "sinusoidale": "sinusoide", "seno": "sinusoide",
                "quadra": "quadra", "quadrata": "quadra", "quadro": "quadra",
                "triangolo": "triangolo", "triangolare": "triangolo",
                "dente_di_sega": "dente_di_sega", "sega": "dente_di_sega", "dente di sega": "dente_di_sega"}
#: Tipi di rumore.
RUMORI = ("bianco", "rosa", "marrone")
#: Accordi per nome: semitoni sopra la nota di base.
ACCORDI = {"maggiore": (0, 4, 7), "minore": (0, 3, 7), "settima": (0, 4, 7, 10),
           "maggiore_settima": (0, 4, 7, 11), "minore_settima": (0, 3, 7, 10),
           "diminuito": (0, 3, 6), "aumentato": (0, 4, 8), "sospeso": (0, 5, 7)}
#: Nomi inglesi delle note: servono solo per i suggerimenti.
_NOTE_INGLESI = {"c": "do", "d": "re", "e": "mi", "f": "fa", "g": "sol", "a": "la", "b": "si", "h": "si"}

_NOTA = re.compile(r"^(do|re|mi|fa|sol|la|si)(#|b|diesis|bemolle)?([+-]*)$")
_TOKEN = re.compile(r"\([^)]*\)[\d.]*|[^\s,;|]+")


class ErroreSuono(ValueError):
    """Errore della logica pura: la libreria lo trasforma in ``ErroreValore``/``ErroreTipo``."""

    def __init__(self, messaggio: str, suggerimento: str | None = None, *, di_tipo: bool = False) -> None:
        super().__init__(messaggio)
        self.messaggio = messaggio
        self.suggerimento = suggerimento
        self.di_tipo = di_tipo


def _suggerimento_nota(testo: str) -> str:
    base = testo.strip().lower()[:1]
    if base in _NOTE_INGLESI and not base.startswith(("d", "r", "m", "s", "l")):
        return (f"In Leo le note si scrivono in italiano: `{_NOTE_INGLESI[base]}` invece di `{testo.strip()}`. "
                "Le note sono do re mi fa sol la si.")
    return "Le note sono do re mi fa sol la si, con # o b attaccati (fa#, sib) e + o - per cambiare ottava."


def semitono_nota(nome: str, ottava: int = OTTAVA_PREDEFINITA) -> int:
    """Numero MIDI della nota (``"la"`` in ottava 4 -> 69; ``"do#+"`` -> 73)."""
    if not isinstance(nome, str):
        raise ErroreSuono(f"Il nome della nota deve essere un testo, non {articolo(nome)}.",
                          "Per esempio \"do\", \"fa#\" o \"sib\".", di_tipo=True)
    m = _NOTA.match(nome.strip().lower().replace(" ", ""))
    if not m:
        raise ErroreSuono(f"Non conosco la nota `{nome}`.", _suggerimento_nota(nome))
    base, alterazione, segni = m.groups()
    n = NOTE[base] + (ottava + 1) * 12
    if alterazione in ("#", "diesis"):
        n += 1
    elif alterazione in ("b", "bemolle"):
        n -= 1
    n += 12 * segni.count("+") - 12 * segni.count("-")
    if not 0 <= n <= 127:
        raise ErroreSuono(f"La nota `{nome}` in ottava {ottava} è fuori dall'udibile.",
                          "Usa un'ottava tra 0 e 8.")
    return n


def frequenza_midi(n: float) -> float:
    """Frequenza in Hz del numero MIDI ``n`` (69 = la4 = 440 Hz)."""
    return LA_CENTRALE * 2 ** ((n - 69) / 12)


def frequenza(nome: str, ottava: int = OTTAVA_PREDEFINITA) -> float:
    """Frequenza in Hz di una nota (``frequenza("la")`` -> 440.0)."""
    return frequenza_midi(semitono_nota(nome, ottava))


def secondi_per_battito(tempo: float) -> float:
    return 60.0 / tempo


def battiti_da_valore(testo: str) -> float:
    """Durata in battiti di un valore di nota: ``"4"`` -> 1, ``"2"`` -> 2, ``"8."`` -> 0.75."""
    punti = len(testo) - len(testo.rstrip("."))
    cifre = testo.rstrip(".")
    if not cifre.isdigit() or int(cifre) not in (1, 2, 4, 8, 16, 32):
        raise ErroreSuono(f"La durata `{testo}` non va bene.",
                          "Le durate sono 1 (intero), 2 (metà), 4 (quarto), 8 (ottavo), 16 e 32; "
                          "con un punto la nota dura metà di più (4.).")
    battiti = 4.0 / int(cifre)
    aggiunta = battiti
    for _ in range(punti):
        aggiunta /= 2
        battiti += aggiunta
    return battiti


def analizza_melodia(testo: str, ottava: int = OTTAVA_PREDEFINITA) -> list[tuple[list[int], float]]:
    """Melodia in testo -> ``[(numeri_midi, battiti), ...]`` (lista vuota = pausa).

    ``"do4 re4 mi2"`` -> ``[([60], 1.0), ([62], 1.0), ([64], 2.0)]``.
    """
    if not isinstance(testo, str):
        raise ErroreSuono(f"La melodia deve essere un testo, non {articolo(testo)}.",
                          "Per esempio melodia(\"do4 re4 mi2\").", di_tipo=True)
    risultato: list[tuple[list[int], float]] = []
    battiti = 1.0
    for token in _TOKEN.findall(testo.lower()):
        if re.fullmatch(r"o\d", token):
            ottava = int(token[1])
            continue
        if token.startswith("("):
            chiusa = token.index(")")
            dentro, durata = token[1:chiusa], token[chiusa + 1:]
            nomi = dentro.replace(",", " ").split()
            if not nomi:
                raise ErroreSuono("Nella melodia c'è un accordo vuoto `()`.", "Scrivi per esempio (do mi sol)2.")
            note = [semitono_nota(n, ottava) for n in nomi]
        else:
            m = re.fullmatch(r"([a-z#]+[+-]*)(\d*\.*)", token)
            if not m:
                raise ErroreSuono(f"Nella melodia non capisco `{token}`.",
                                  "Scrivi le note con la durata attaccata, per esempio \"do4 re4 mi2\"; "
                                  "p = pausa.")
            nome, durata = m.groups()
            if nome in ("p", "pausa"):
                note = []
            else:
                try:
                    note = [semitono_nota(nome, ottava)]
                except ErroreSuono as e:
                    raise ErroreSuono(f"Nella melodia non capisco `{token}`: {e.messaggio[0].lower()}"
                                      f"{e.messaggio[1:]}", e.suggerimento) from None
        if durata:
            battiti = battiti_da_valore(durata)
        risultato.append((note, battiti))
    return risultato


def note_accordo(testo: Any, ottava: int = OTTAVA_PREDEFINITA) -> list[int]:
    """Note di un accordo: ``"do maggiore"``, ``"la minore"``, ``"do mi sol"`` o una lista di nomi."""
    if isinstance(testo, list):
        if not testo:
            raise ErroreSuono("L'accordo non ha note.", "Per esempio accordo([\"do\", \"mi\", \"sol\"]).")
        return [semitono_nota(n, ottava) for n in testo]
    if not isinstance(testo, str):
        raise ErroreSuono(f"L'accordo vuole un testo o una lista di note, non {articolo(testo)}.",
                          "Per esempio accordo(\"do maggiore\") o accordo(\"do mi sol\").", di_tipo=True)
    parole = testo.strip().lower().replace(",", " ").split()
    if len(parole) >= 2 and "_".join(parole[1:]) in ACCORDI:
        base = semitono_nota(parole[0], ottava)
        return [base + s for s in ACCORDI["_".join(parole[1:])]]
    if len(parole) == 1 and _NOTA.match(parole[0]):
        base = semitono_nota(parole[0], ottava)
        return [base + s for s in ACCORDI["maggiore"]]
    if not parole:
        raise ErroreSuono("L'accordo non ha note.", "Per esempio accordo(\"do maggiore\").")
    try:
        return [semitono_nota(p, ottava) for p in parole]
    except ErroreSuono as e:
        tipi = ", ".join(ACCORDI)
        raise ErroreSuono(e.messaggio, f"Scrivi le note (\"do mi sol\") oppure nota e tipo: {tipi}.") from None


def forma_onda(nome: Any) -> str:
    if not isinstance(nome, str):
        raise ErroreSuono(f"La forma d'onda è un testo, non {articolo(nome)}.", _suggerimento_forme(), di_tipo=True)
    chiave = nome.strip().lower()
    if chiave in _ALIAS_FORME:
        return _ALIAS_FORME[chiave]
    raise ErroreSuono(f"Non conosco la forma d'onda `{nome}`.", _suggerimento_forme())


def _suggerimento_forme() -> str:
    return "Le forme sono: " + ", ".join(f"\"{f}\"" for f in FORME_ONDA) + "."


# ===========================================================================
# 2. Logica pura: sintesi e WAV
# ===========================================================================

def _campione_onda(forma: str, fase: float) -> float:
    """Valore dell'onda (tra -1 e 1) alla ``fase`` (in giri: 0..1)."""
    f = fase - math.floor(fase)
    if forma == "sinusoide":
        return math.sin(2 * math.pi * f)
    if forma == "quadra":
        return 1.0 if f < 0.5 else -1.0
    if forma == "triangolo":
        return 4 * f - 1 if f < 0.5 else 3 - 4 * f
    return 2 * f - 1  # dente di sega


def genera_onda(frequenze: Sequence[float], secondi: float, forma: str = "sinusoide",
                volume: float = VOLUME_PREDEFINITO, fc: int = FREQUENZA_CAMPIONAMENTO,
                attacco: float = 0.005, rilascio: float = 0.03) -> array:
    """Campioni di una o più frequenze insieme, con attacco e rilascio brevi (niente "clic")."""
    n = max(0, int(round(secondi * fc)))
    campioni = array("f", bytes(4 * n))
    if not frequenze or n == 0 or volume <= 0:
        return campioni
    forme = FORME_ONDA
    if forma not in forme:
        forma = "sinusoide"
    ampiezza = volume / len(frequenze)
    if forma in ("quadra", "dente_di_sega"):
        ampiezza *= 0.6  # a parità di volume suonano molto più forti
    n_attacco = max(1, int(attacco * fc))
    n_rilascio = max(1, min(int(rilascio * fc), n // 2))
    for f in frequenze:
        passo = f / fc
        if forma == "sinusoide":
            w = 2 * math.pi * passo
            seno = math.sin
            for i in range(n):
                campioni[i] += ampiezza * seno(w * i)
        else:
            calcola = _campione_onda
            for i in range(n):
                campioni[i] += ampiezza * calcola(forma, passo * i)
    for i in range(min(n_attacco, n)):
        campioni[i] *= i / n_attacco
    for i in range(n_rilascio):
        campioni[n - 1 - i] *= i / n_rilascio
    return campioni


def genera_rumore(secondi: float, tipo: str = "bianco", volume: float = 0.5,
                  fc: int = FREQUENZA_CAMPIONAMENTO, seme: int | None = None) -> array:
    """Rumore bianco (tutte le frequenze), rosa (più morbido) o marrone (cupo, come il mare)."""
    n = max(0, int(round(secondi * fc)))
    caso = random.Random(seme)
    uniforme = caso.uniform
    campioni = array("f", bytes(4 * n))
    if tipo == "bianco":
        for i in range(n):
            campioni[i] = uniforme(-1.0, 1.0)
    elif tipo == "rosa":  # filtro di Paul Kellet (versione economica)
        b0 = b1 = b2 = 0.0
        for i in range(n):
            bianco = uniforme(-1.0, 1.0)
            b0 = 0.99765 * b0 + bianco * 0.0990460
            b1 = 0.96300 * b1 + bianco * 0.2965164
            b2 = 0.57000 * b2 + bianco * 1.0526913
            campioni[i] = (b0 + b1 + b2 + bianco * 0.1848) * 0.25
    else:  # marrone: somma dei passi casuali, con una piccola perdita per restare al centro
        ultimo = 0.0
        for i in range(n):
            ultimo = (ultimo + 0.02 * uniforme(-1.0, 1.0)) * 0.998
            campioni[i] = ultimo * 3.5
    return normalizza(campioni, volume)


def picco(campioni: Sequence[float]) -> float:
    return max((abs(c) for c in campioni), default=0.0)


def normalizza(campioni: array, volume: float) -> array:
    """Porta il picco al ``volume`` (0..1)."""
    massimo = picco(campioni)
    if massimo <= 0:
        return campioni
    k = volume / massimo
    return array("f", (c * k for c in campioni))


def mescola(a: Sequence[float], b: Sequence[float]) -> array:
    """Due suoni insieme; se la somma supera 1 si abbassa tutto (niente distorsione)."""
    n = max(len(a), len(b))
    risultato = array("f", bytes(4 * n))
    for i, c in enumerate(a):
        risultato[i] = c
    for i, c in enumerate(b):
        risultato[i] += c
    return normalizza(risultato, 1.0) if picco(risultato) > 1.0 else risultato


def dissolvenza(campioni: Sequence[float], entrata: float, uscita: float,
                fc: int = FREQUENZA_CAMPIONAMENTO) -> array:
    """Volume che sale per ``entrata`` secondi all'inizio e scende per ``uscita`` alla fine."""
    risultato = array("f", campioni)
    n = len(risultato)
    ne = min(n, int(entrata * fc))
    nu = min(n, int(uscita * fc))
    for i in range(ne):
        risultato[i] *= i / ne
    for i in range(nu):
        risultato[n - 1 - i] *= i / nu
    return risultato


def campioni_melodia(eventi: list[tuple[list[int], float]], tempo: float, forma: str, volume: float,
                     fc: int = FREQUENZA_CAMPIONAMENTO, legato: float = 0.92) -> array:
    """Campioni di una melodia analizzata (ogni nota suona ``legato`` della sua durata)."""
    risultato = array("f")
    spb = secondi_per_battito(tempo)
    for note, battiti in eventi:
        durata = battiti * spb
        n_totale = int(round(durata * fc))
        suono = genera_onda([frequenza_midi(n) for n in note], durata * legato, forma, volume, fc)
        risultato.extend(suono)
        risultato.extend(array("f", bytes(4 * max(0, n_totale - len(suono)))))
    return risultato


def wav_in_byte(campioni: Sequence[float], fc: int = FREQUENZA_CAMPIONAMENTO) -> bytes:
    """Il suono come file WAV (PCM 16 bit, mono), in memoria."""
    dati = array("h", (int(max(-1.0, min(1.0, c)) * 32767) for c in campioni))
    if sys.byteorder == "big":
        dati.byteswap()
    uscita = io.BytesIO()
    with wave.open(uscita, "wb") as f:
        f.setnchannels(1)
        f.setsampwidth(2)
        f.setframerate(fc)
        f.writeframes(dati.tobytes())
    return uscita.getvalue()


def leggi_wav(sorgente: Any) -> tuple[array, int]:
    """Legge un WAV PCM (8, 16, 24 o 32 bit, mono o stereo) -> (campioni mono, frequenza).

    Solleva ``wave.Error``/``EOFError`` se il file non è un WAV valido.
    """
    with wave.open(sorgente, "rb") as f:
        canali, larghezza, fc, n = f.getnchannels(), f.getsampwidth(), f.getframerate(), f.getnframes()
        grezzi = f.readframes(n)
    if larghezza == 1:
        valori = [(b - 128) / 128.0 for b in grezzi]
    elif larghezza == 2:
        a = array("h")
        a.frombytes(grezzi[: len(grezzi) // 2 * 2])
        if sys.byteorder == "big":
            a.byteswap()
        valori = [v / 32768.0 for v in a]
    elif larghezza == 3:
        valori = [int.from_bytes(grezzi[i:i + 3], "little", signed=True) / 8388608.0
                  for i in range(0, len(grezzi) - 2, 3)]
    elif larghezza == 4:
        a = array("i")
        a.frombytes(grezzi[: len(grezzi) // 4 * 4])
        if sys.byteorder == "big":
            a.byteswap()
        valori = [v / 2147483648.0 for v in a]
    else:
        raise wave.Error(f"campioni da {larghezza} byte")
    if canali > 1:
        valori = [sum(valori[i:i + canali]) / canali for i in range(0, len(valori) - canali + 1, canali)]
    return array("f", valori), fc


def ricampiona(campioni: Sequence[float], da: int, a: int = FREQUENZA_CAMPIONAMENTO) -> array:
    """Cambia la frequenza di campionamento (interpolazione lineare)."""
    if da == a or not campioni:
        return array("f", campioni)
    n = int(len(campioni) * a / da)
    rapporto = da / a
    ultimo = len(campioni) - 1
    risultato = array("f", bytes(4 * n))
    for i in range(n):
        pos = i * rapporto
        j = int(pos)
        if j >= ultimo:
            risultato[i] = campioni[ultimo]
        else:
            t = pos - j
            risultato[i] = campioni[j] * (1 - t) + campioni[j + 1] * t
    return risultato


# ===========================================================================
# 3. Riproduzione (scelta del lettore; il suono vero dipende dal sistema)
# ===========================================================================

LETTORI_ESTERNI = (("afplay",), ("paplay",), ("aplay", "-q"), ("ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet"))


def scegli_lettore(sistema: str, *, winsound: bool, qt: bool, qt_attiva: bool,
                   comando: Sequence[str] | None, muto: bool = False) -> str:
    """Chi suona: ``"winsound"``, ``"qt"``, ``"comando"``, ``"muto"`` o ``"nessuno"``.

    Ordine: Windows -> winsound; un'applicazione Qt già attiva (programma con
    finestre) -> QSoundEffect; il lettore del sistema; Qt anche senza finestre
    (in quel caso la riproduzione aspetta la fine); altrimenti nessuno.
    """
    if muto:
        return "muto"
    if sistema == "win32" and winsound:
        return "winsound"
    if qt and qt_attiva:
        return "qt"
    if comando:
        return "comando"
    if qt:
        return "qt"
    return "nessuno"


def trova_comando() -> list[str] | None:
    """Il primo lettore di file WAV del sistema che c'è (``afplay``, ``paplay``, ``aplay``...)."""
    for voce in LETTORI_ESTERNI:
        percorso = shutil.which(voce[0])
        if percorso:
            return [percorso, *voce[1:]]
    return None


def _ha_modulo(nome: str) -> bool:
    import importlib.util

    try:
        return importlib.util.find_spec(nome) is not None
    except (ImportError, ValueError):
        return False


class Riproduzione:
    """Stato della riproduzione (un suono alla volta). Si può sostituire nei test."""

    def __init__(self) -> None:
        self.metodo: str | None = None
        self.processo: subprocess.Popen | None = None
        self.file_temporanei: list[str] = []
        self.fine_prevista = 0.0
        self._atexit = False

    def _scegli(self) -> str:
        if self.metodo is None:
            muto = (variabile_ambiente("SUONI") or "").strip().lower() in ("muto", "no", "0", "spento")
            qt = _ha_modulo("PySide6") and _ha_modulo("PySide6.QtMultimedia")
            qt_attiva = False
            if qt and "PySide6.QtWidgets" in sys.modules:
                try:
                    from PySide6.QtWidgets import QApplication

                    qt_attiva = QApplication.instance() is not None
                except Exception:  # noqa: BLE001
                    qt_attiva = False
            self.metodo = scegli_lettore(sys.platform, winsound=_ha_modulo("winsound"), qt=qt,
                                         qt_attiva=qt_attiva, comando=trova_comando(), muto=muto)
        return self.metodo

    def _file_temporaneo(self, dati: bytes) -> str:
        descrittore, percorso = tempfile.mkstemp(prefix="leo_suono_", suffix=".wav")
        with os.fdopen(descrittore, "wb") as f:
            f.write(dati)
        self.file_temporanei.append(percorso)
        if not self._atexit:
            atexit.register(self._alla_fine)
            self._atexit = True
        return percorso

    def suona_wav(self, percorso: str | None, dati: bytes | None, durata: float, aspetta: bool,
                  avvisa: Callable[[str], None], volume: float = 1.0) -> str:
        """Suona un WAV (file o byte). Restituisce il metodo usato."""
        metodo = self._scegli()
        if metodo == "muto":
            return metodo
        if metodo == "nessuno":
            if percorso is None:
                percorso = "suono_leo.wav"
                with open(percorso, "wb") as f:
                    f.write(dati or b"")
                avvisa(f"Su questo computer Leo non riesce a suonare: ho salvato il suono in \"{percorso}\".")
            else:
                avvisa(f"Su questo computer Leo non riesce a suonare \"{percorso}\": aprilo con un lettore audio.")
            return metodo
        self.ferma()
        if percorso is None:
            percorso = self._file_temporaneo(dati or b"")
        if metodo == "winsound":
            import winsound

            winsound.PlaySound(percorso, winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT)
            self.fine_prevista = time.monotonic() + durata
            if aspetta:
                time.sleep(max(0.0, durata))
        elif metodo == "comando":
            self.processo = subprocess.Popen([*trova_comando(), percorso], stdin=subprocess.DEVNULL,  # type: ignore[misc]
                                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            self.fine_prevista = time.monotonic() + durata
            if aspetta:
                self.processo.wait()
        else:  # qt
            from ..grafica.qt import suoni_qt

            suoni_qt.suona_file(percorso, aspetta=aspetta, volume=volume)
            self.fine_prevista = time.monotonic() + durata
        return metodo

    def ferma(self) -> None:
        metodo = self.metodo
        if metodo == "winsound":
            try:
                import winsound

                winsound.PlaySound(None, winsound.SND_PURGE)
            except (ImportError, RuntimeError):
                pass
        elif metodo == "comando" and self.processo is not None:
            if self.processo.poll() is None:
                self.processo.terminate()
                try:
                    self.processo.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    self.processo.kill()
            self.processo = None
        elif metodo == "qt":
            try:
                from ..grafica.qt import suoni_qt

                suoni_qt.ferma()
            except ImportError:
                pass
        self.fine_prevista = 0.0

    def _alla_fine(self) -> None:
        """A fine programma lascia finire l'ultimo suono (al massimo un minuto) e pulisce."""
        resta = self.fine_prevista - time.monotonic()
        if resta > 0 and self.metodo in ("winsound", "comando"):
            try:
                time.sleep(min(resta, 60.0))
            except KeyboardInterrupt:
                pass
        self.ferma()
        for percorso in self.file_temporanei:
            try:
                os.remove(percorso)
            except OSError:
                pass
        self.file_temporanei.clear()


#: La riproduzione del programma (i test la sostituiscono con una finta).
RIPRODUZIONE = Riproduzione()


# ===========================================================================
# 4. Il valore `suono` e le funzioni Leo
# ===========================================================================

class Suono(OggettoLibreria):
    """Valore Leo di tipo ``suono``: campioni mono tra -1 e 1."""

    NOME_TIPO_DANTE = "suono"
    SUGGERIMENTO_MODIFICA = ("Un suono non cambia: metodi come `con_volume(0.5)` o `dissolvenza()` "
                             "ne creano uno nuovo.")

    def __init__(self, campioni: array | None = None, fc: int = FREQUENZA_CAMPIONAMENTO, nome: str = "") -> None:
        self.campioni = campioni if campioni is not None else array("f")
        self.fc = fc
        self.nome_suono = nome

    @property
    def durata(self) -> float:
        return len(self.campioni) / self.fc

    def testo_dante(self) -> str:
        nome = f" {self.nome_suono}" if self.nome_suono else ""
        return f"<suono{nome} {rappresenta(round(self.durata, 3))} s>"


def _leo(e: ErroreSuono) -> ErroreDante:
    return (ErroreTipo if e.di_tipo else ErroreValore)(e.messaggio, suggerimento=e.suggerimento)


def _esegui(azione, *argomenti):
    try:
        return azione(*argomenti)
    except ErroreSuono as e:
        raise _leo(e) from None


def _numero(v: Any, funzione: str, parametro: str, minimo: float | None = None, massimo: float | None = None,
            esempio: str = "") -> float:
    if not e_numero(v):
        raise ErroreTipo(f"`{parametro}` di `{funzione}` deve essere un numero, non {articolo(v)}.",
                         suggerimento=esempio or None)
    try:
        x = float(v)
    except OverflowError:
        x = math.inf if v > 0 else -math.inf
    if math.isnan(x) or (minimo is not None and x < minimo) or (massimo is not None and x > massimo):
        limiti = (f"tra {rappresenta(minimo)} e {rappresenta(massimo)}" if minimo is not None and massimo is not None
                  else f"almeno {rappresenta(minimo)}" if minimo is not None else f"al massimo {rappresenta(massimo)}")
        raise ErroreValore(f"`{parametro}` di `{funzione}` deve essere {limiti}, non {mostra(v)}.",
                           suggerimento=esempio or None)
    return x


def _volume(v: Any, funzione: str) -> float:
    """Volume da 0 a 1 (oppure, sopra 1, in percentuale da 0 a 100)."""
    x = _numero(v, funzione, "volume", 0, 100, "Il volume va da 0 (muto) a 1 (pieno), oppure da 0 a 100.")
    return x / 100.0 if x > 1 else x


def _durata(secondi: float, funzione: str) -> float:
    if secondi > DURATA_MASSIMA:
        quanto = f"{rappresenta(round(secondi))} secondi" if math.isfinite(secondi) else "per sempre"
        raise ErroreValore(f"Il suono di `{funzione}` durerebbe {quanto}: il massimo è {int(DURATA_MASSIMA)} secondi.",
                           suggerimento="Accorcia la melodia o usa meno ripetizioni.")
    return secondi


def _tempo(v: Any, funzione: str) -> float:
    return _numero(v, funzione, "tempo", 20, 400, "Il tempo è in battiti al minuto: per esempio 120.")


def _ottava(v: Any, funzione: str) -> int:
    if isinstance(v, bool) or not isinstance(v, int) or not 0 <= v <= 8:
        raise ErroreValore(f"`ottava` di `{funzione}` deve essere un intero da 0 a 8, non {mostra(v)}.",
                           suggerimento="L'ottava 4 è quella centrale (la = 440 Hz).")
    return v


def _suono(v: Any, funzione: str, parametro: str = "suono") -> Suono:
    if isinstance(v, Suono):
        return v
    raise ErroreTipo(f"`{parametro}` di `{funzione}` deve essere un suono, non {articolo(v)}.",
                     suggerimento="Crea un suono con `nota(\"la\")`, `melodia(\"do4 re4 mi2\")` o `carica_suono(file)`.")


def _avvisa(interprete: Any) -> Callable[[str], None]:
    def avvisa(testo: str) -> None:
        scrivi = getattr(interprete, "scrivi", None)
        if callable(scrivi):
            scrivi(testo + "\n")
        else:
            print(testo, flush=True)
    return avvisa


def _percorso(v: Any, funzione: str) -> str:
    if not isinstance(v, str):
        raise ErroreTipo(f"Il percorso di `{funzione}` deve essere un testo, non {articolo(v)}.",
                         suggerimento="Per esempio \"musica.wav\".")
    if not v.strip():
        raise ErroreValore(f"Il nome del file di `{funzione}` è vuoto.", suggerimento="Per esempio \"musica.wav\".")
    if "\0" in v:
        raise ErroreValore(f"Il nome del file di `{funzione}` contiene un carattere non valido.")
    if v.strip().lower().startswith("galleria:"):
        from ..galleria import risolvi                # un suono della galleria: il suo file vero

        return str(risolvi(v.strip()))
    return v.strip()


# --- creare suoni ---------------------------------------------------------------

@funzione_libreria("nota")
def nota(nome, battiti=1, tempo=TEMPO_PREDEFINITO, ottava=OTTAVA_PREDEFINITA, forma="sinusoide",
         volume=VOLUME_PREDEFINITO):
    """nota(nome, battiti = 1, tempo = 120, ottava = 4, forma = "sinusoide", volume = 0.8): una nota.

    Le note sono do re mi fa sol la si, con # o b (fa#, sib) e + o - per l'ottava sopra o sotto.
    Esempio: `suona(nota("la"))` (440 Hz, un battito), `nota("do+", battiti = 2, forma = "quadra")`.
    """
    n = _esegui(semitono_nota, nome, _ottava(ottava, "nota"))
    b = _numero(battiti, "nota", "battiti", 0, None, "Per esempio `battiti = 2`.")
    secondi = _durata(b * secondi_per_battito(_tempo(tempo, "nota")), "nota")
    campioni = genera_onda([frequenza_midi(n)], secondi, _esegui(forma_onda, forma), _volume(volume, "nota"))
    return Suono(campioni, nome=nome.strip())


@funzione_libreria("frequenza_nota")
def frequenza_nota(nome, ottava=OTTAVA_PREDEFINITA):
    """frequenza_nota(nome, ottava = 4): la frequenza della nota in hertz.

    Esempio: `frequenza_nota("la")` è 440.0; `frequenza_nota("do", 5)` è circa 523.25.
    """
    return round(_esegui(frequenza, nome, _ottava(ottava, "frequenza_nota")), 3)


@funzione_libreria("tono")
def tono(frequenza, secondi=1, forma="sinusoide", volume=VOLUME_PREDEFINITO):
    """tono(frequenza, secondi = 1, forma = "sinusoide", volume = 0.8): un suono di quella frequenza in hertz.

    Esempio: `suona(tono(1000, 0.2))` fa un bip; le forme sono "sinusoide", "quadra", "triangolo", "dente_di_sega".
    """
    f = _numero(frequenza, "tono", "frequenza", 1, FREQUENZA_CAMPIONAMENTO / 2,
                "Le frequenze udibili vanno da circa 20 a 20000 hertz.")
    s = _durata(_numero(secondi, "tono", "secondi", 0), "tono")
    return Suono(genera_onda([f], s, _esegui(forma_onda, forma), _volume(volume, "tono")))


@funzione_libreria("melodia")
def melodia(note, tempo=TEMPO_PREDEFINITO, forma="sinusoide", volume=VOLUME_PREDEFINITO, ottava=OTTAVA_PREDEFINITA):
    """melodia(note, tempo = 120, forma = "sinusoide", volume = 0.8, ottava = 4): una melodia da un testo.

    Ogni nota ha la durata attaccata: 1 intero, 2 metà, 4 quarto (un battito), 8 ottavo; "p" è la pausa,
    "(do mi sol)2" un accordo, "do+" l'ottava sopra. Esempio: `suona(melodia("do4 re4 mi4 do4 mi2"))`.
    """
    eventi = _esegui(analizza_melodia, note, _ottava(ottava, "melodia"))
    t = _tempo(tempo, "melodia")
    _durata(sum(b for _n, b in eventi) * secondi_per_battito(t), "melodia")
    return Suono(campioni_melodia(eventi, t, _esegui(forma_onda, forma), _volume(volume, "melodia")))


@funzione_libreria("accordo")
def accordo(note, battiti=1, tempo=TEMPO_PREDEFINITO, forma="sinusoide", volume=VOLUME_PREDEFINITO,
            ottava=OTTAVA_PREDEFINITA):
    """accordo(note, battiti = 1, tempo = 120, forma = "sinusoide", volume = 0.8, ottava = 4): più note insieme.

    `note` è "do maggiore", "la minore", "sol settima", "do mi sol" o una lista ["do", "mi", "sol"].
    Esempio: `suona(accordo("do maggiore", battiti = 2))`.
    """
    semitoni = _esegui(note_accordo, note, _ottava(ottava, "accordo"))
    b = _numero(battiti, "accordo", "battiti", 0)
    secondi = _durata(b * secondi_per_battito(_tempo(tempo, "accordo")), "accordo")
    campioni = genera_onda([frequenza_midi(n) for n in semitoni], secondi, _esegui(forma_onda, forma),
                           _volume(volume, "accordo"))
    return Suono(campioni)


@funzione_libreria("rumore")
def rumore(secondi=1, tipo="bianco", volume=0.5):
    """rumore(secondi = 1, tipo = "bianco", volume = 0.5): un fruscio; tipi "bianco", "rosa" o "marrone".

    Esempio: `suona(rumore(2, "marrone").dissolvenza(0.5, 0.5))` somiglia al mare.
    """
    s = _durata(_numero(secondi, "rumore", "secondi", 0), "rumore")
    if not isinstance(tipo, str) or tipo.strip().lower() not in RUMORI:
        raise ErroreValore(f"Non conosco il rumore {mostra(tipo)}.",
                           suggerimento="I tipi sono: " + ", ".join(f"\"{r}\"" for r in RUMORI) + ".")
    return Suono(genera_rumore(s, tipo.strip().lower(), _volume(volume, "rumore")))


@funzione_libreria("silenzio")
def silenzio(secondi=1):
    """silenzio(secondi = 1): un suono muto, utile per fare pause tra altri suoni.

    Esempio: `nota("do").poi(silenzio(0.5)).poi(nota("sol"))`.
    """
    s = _durata(_numero(secondi, "silenzio", "secondi", 0), "silenzio")
    return Suono(array("f", bytes(4 * int(round(s * FREQUENZA_CAMPIONAMENTO)))))


@funzione_libreria("carica_suono")
def carica_suono(percorso):
    """carica_suono(percorso): legge un file WAV e lo restituisce come suono da modificare o unire.

    Esempio: `variabile applauso = carica_suono("applauso.wav")`.
    """
    p = _percorso(percorso, "carica_suono")
    try:
        with open(p, "rb") as f:
            campioni, fc = leggi_wav(f)
    except FileNotFoundError:
        raise ErroreFile(f"Il file `{p}` non esiste.", suggerimento="Controlla il nome e la cartella.") from None
    except (wave.Error, EOFError):
        raise ErroreFile(f"`{p}` non è un file WAV che Leo sa leggere.",
                         suggerimento="Leo legge i file WAV non compressi (PCM); converti prima gli MP3.") from None
    except OSError as e:
        raise ErroreFile(f"Non riesco a leggere `{p}`: {e.strerror or e}.") from None
    _durata(len(campioni) / fc, "carica_suono")
    return Suono(ricampiona(campioni, fc), nome=os.path.basename(p))


# --- suonare e salvare ------------------------------------------------------------

def _suoni_muti() -> bool:
    return (variabile_ambiente("SUONI") or "").strip().lower() in ("muto", "no", "0", "spento")


def _non_su_android(funzione: str) -> None:
    """Su Android non c'è un lettore audio per Leo: errore chiaro (salvo con LEO_SUONI=muto)."""
    from ..piattaforma import non_su_android

    if not _suoni_muti():
        non_su_android(funzione)

def _suona(interprete: Any, s: Suono, aspetta: Any, funzione: str) -> None:
    if not isinstance(aspetta, bool):
        raise ErroreTipo(f"`aspetta` di `{funzione}` vuole `vero` o `falso`, non {articolo(aspetta)}.")
    if not s.campioni:
        return None  # niente da sentire
    _non_su_android(funzione)
    try:
        RIPRODUZIONE.suona_wav(None, wav_in_byte(s.campioni, s.fc), s.durata, aspetta, _avvisa(interprete))
    except ErroreDante:
        raise
    except Exception as e:  # noqa: BLE001 - nessun errore Python deve arrivare all'utente
        raise ErroreValore(f"Non sono riuscito a suonare: {e}.",
                           suggerimento="Controlla che l'audio del computer funzioni.") from None
    return None


@funzione_libreria("suona", interprete=True)
def suona(interprete, suono, aspetta=False):
    """suona(suono, aspetta = falso): fa sentire un suono, una melodia scritta come testo o un file ".wav".

    Il programma va avanti subito; con `aspetta = vero` aspetta la fine. Un nuovo suono ferma il precedente.
    Esempi: `suona(nota("la"))`, `suona("do4 mi4 sol2")`, `suona("campanello.wav")`.
    """
    if isinstance(suono, str):
        if suono.strip().lower().endswith((".wav", ".mp3", ".ogg", ".flac", ".m4a", ".aac")) \
                or suono.strip().lower().startswith("galleria:"):
            return suona_file(interprete, suono, aspetta)
        suono = melodia(suono)
    return _suona(interprete, _suono(suono, "suona"), aspetta, "suona")


@funzione_libreria("suona_file", interprete=True)
def suona_file(interprete, percorso, aspetta=False):
    """suona_file(percorso, aspetta = falso): fa sentire un file WAV.

    Esempio: `suona_file("vittoria.wav")`. Per gli MP3 usa il controllo Suono di una finestra.
    """
    p = _percorso(percorso, "suona_file")
    if not isinstance(aspetta, bool):
        raise ErroreTipo(f"`aspetta` di `suona_file` vuole `vero` o `falso`, non {articolo(aspetta)}.")
    if not os.path.isfile(p):
        raise ErroreFile(f"Il file `{p}` non esiste.", suggerimento="Controlla il nome e la cartella.")
    if not p.lower().endswith(".wav"):
        raise ErroreValore(f"`suona_file` suona solo file WAV, non `{os.path.basename(p)}`.",
                           suggerimento="Per MP3 e altri formati usa il controllo Suono in una finestra.")
    _non_su_android("suona_file")
    try:
        with open(p, "rb") as f:
            campioni, fc = leggi_wav(f)
    except (wave.Error, EOFError):
        raise ErroreFile(f"`{p}` non è un file WAV che Leo sa leggere.") from None
    except OSError as e:
        raise ErroreFile(f"Non riesco a leggere `{p}`: {e.strerror or e}.") from None
    try:
        RIPRODUZIONE.suona_wav(os.path.abspath(p), None, len(campioni) / fc, aspetta, _avvisa(interprete))
    except ErroreDante:
        raise
    except Exception as e:  # noqa: BLE001
        raise ErroreValore(f"Non sono riuscito a suonare `{p}`: {e}.") from None
    return None


@funzione_libreria("ferma_suoni")
def ferma_suoni():
    """ferma_suoni(): ferma subito il suono che si sta sentendo.

    Esempio: `suona(melodia("do1 re1 mi1"))` ... `ferma_suoni()`.
    """
    try:
        RIPRODUZIONE.ferma()
    except Exception:  # noqa: BLE001 - fermare non deve mai fallire
        pass
    return None


@funzione_libreria("salva_suono")
def salva_suono(suono, percorso):
    """salva_suono(suono, percorso): scrive il suono in un file WAV; restituisce il nome del file.

    Esempio: `salva_suono(melodia("do4 re4 mi2"), "canzone.wav")`.
    """
    s = _suono(suono, "salva_suono")
    p = _percorso(percorso, "salva_suono")
    if not os.path.splitext(p)[1]:
        p += ".wav"
    elif not p.lower().endswith(".wav"):
        raise ErroreValore(f"Leo salva i suoni solo in formato WAV, non `{os.path.splitext(p)[1]}`.",
                           suggerimento="Usa un nome che finisce con \".wav\".")
    try:
        with open(p, "wb") as f:
            f.write(wav_in_byte(s.campioni, s.fc))
    except OSError as e:
        raise ErroreFile(f"Non riesco a salvare il suono in `{p}`: {e.strerror or e}.",
                         suggerimento="Controlla che la cartella esista.") from None
    return p


# --- proprietà e metodi del valore `suono` --------------------------------------------

proprieta(Suono, "durata")(lambda s: round(s.durata, 3))
proprieta(Suono, "campioni_al_secondo")(lambda s: s.fc)
proprieta(Suono, "volume_massimo")(lambda s: round(picco(s.campioni), 3))


@metodo_oggetto(Suono, "suona", interprete=True)
def suono_suona(interprete, s, aspetta=False):
    """suono.suona(aspetta = falso): fa sentire il suono (vedi `suona`)."""
    return _suona(interprete, s, aspetta, "suona")


@metodo_oggetto(Suono, "salva")
def suono_salva(s, percorso):
    """suono.salva(percorso): scrive il suono in un file WAV (vedi `salva_suono`)."""
    return salva_suono(s, percorso)


@metodo_oggetto(Suono, "poi")
def suono_poi(s, altro):
    """suono.poi(altro): un suono nuovo: prima questo, poi l'altro.

    Esempio: `nota("do").poi(nota("mi")).poi(nota("sol"))`.
    """
    b = _suono(altro, "poi", "altro")
    _durata(s.durata + b.durata, "poi")
    return Suono(s.campioni + b.campioni, s.fc)


@metodo_oggetto(Suono, "insieme")
def suono_insieme(s, altro):
    """suono.insieme(altro): un suono nuovo con i due suoni sovrapposti.

    Esempio: `melodia("do4 mi4 sol2").insieme(rumore(2, "rosa", 0.1))`.
    """
    b = _suono(altro, "insieme", "altro")
    return Suono(mescola(s.campioni, b.campioni), s.fc)


@metodo_oggetto(Suono, "ripeti")
def suono_ripeti(s, volte=2):
    """suono.ripeti(volte = 2): un suono nuovo che ripete questo tante volte.

    Esempio: `nota("la", 0.25).poi(silenzio(0.1)).ripeti(3)`.
    """
    if isinstance(volte, bool) or not isinstance(volte, int) or volte < 0:
        raise ErroreValore(f"`volte` di `ripeti` deve essere un intero da 0 in su, non {mostra(volte)}.")
    _durata(s.durata * volte, "ripeti")
    return Suono(s.campioni * volte, s.fc)


@metodo_oggetto(Suono, "con_volume")
def suono_con_volume(s, volume):
    """suono.con_volume(volume): un suono nuovo più forte o più piano (0 = muto, 1 = pieno).

    Esempio: `nota("la").con_volume(0.3)`.
    """
    v = _volume(volume, "con_volume")
    return Suono(normalizza(array("f", s.campioni), v), s.fc)


@metodo_oggetto(Suono, "dissolvenza")
def suono_dissolvenza(s, entrata=0, uscita=0.5):
    """suono.dissolvenza(entrata = 0, uscita = 0.5): un suono nuovo che sale e sfuma (secondi).

    Esempio: `accordo("la minore", 4).dissolvenza(entrata = 0.2, uscita = 1)`.
    """
    e = _numero(entrata, "dissolvenza", "entrata", 0)
    u = _numero(uscita, "dissolvenza", "uscita", 0)
    return Suono(dissolvenza(s.campioni, e, u, s.fc), s.fc)


@metodo_oggetto(Suono, "taglia")
def suono_taglia(s, inizio=0, fine=None):
    """suono.taglia(inizio = 0, fine = nulla): il pezzo di suono tra i due istanti (in secondi).

    Esempio: `carica_suono("canzone.wav").taglia(10, 20)`.
    """
    a = _numero(inizio, "taglia", "inizio", 0)
    b = s.durata if fine is None else _numero(fine, "taglia", "fine", 0)
    if b < a:
        raise ErroreValore("In `taglia` la `fine` viene prima dell'`inizio`.")
    return Suono(s.campioni[int(a * s.fc):int(b * s.fc)], s.fc)


@metodo_oggetto(Suono, "al_contrario")
def suono_al_contrario(s):
    """suono.al_contrario(): un suono nuovo che va dalla fine all'inizio."""
    campioni = array("f", s.campioni)
    campioni.reverse()
    return Suono(campioni, s.fc)


__all__ = ["FREQUENZA_CAMPIONAMENTO", "NOTE", "FORME_ONDA", "RUMORI", "ACCORDI", "ErroreSuono", "Suono",
           "semitono_nota", "frequenza", "frequenza_midi", "battiti_da_valore", "analizza_melodia", "note_accordo",
           "forma_onda", "genera_onda", "genera_rumore", "mescola", "dissolvenza", "normalizza", "picco",
           "campioni_melodia", "wav_in_byte", "leggi_wav", "ricampiona", "scegli_lettore", "trova_comando",
           "Riproduzione", "RIPRODUZIONE"]
