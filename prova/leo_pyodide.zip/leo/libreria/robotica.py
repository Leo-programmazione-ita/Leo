"""Robotica: comanda una scheda (Raspberry Pi Pico) dal codice Leo.

Questa è l'anima di **Leo Robotica**. Con `collega_scheda` ottieni una scheda e la comandi con
parole italiane: accendi e spegni i pin, regoli l'intensità (PWM), leggi i pin e i sensori
(temperatura, luce, distanza), sorvegli i pulsanti e scambi testi. Funziona con una Pico vera
(USB o Wi-Fi) e con una **scheda simulata** (`simulata = vero`), utile per provare senza hardware.

Sulla Pico deve girare `dati/pico/leo_pico.py` (copiato come `main.py`). Il protocollo (righe JSON)
e i trasporti stanno in :mod:`leo.grafica.servizi.pico`; qui c'è l'involucro per il linguaggio.

Esempio::

    variabile scheda = collega_scheda(simulata = vero)
    scheda.accendi(25)                 # il LED di bordo
    stampa(scheda.temperatura())       # gradi
    scheda.scollega()
"""

from __future__ import annotations

from typing import Any

from ..errori import ErroreNome, ErroreTipo, ErroreValore
from ..valori import Richiamabile
from .generali import funzione_libreria, richiedi_logico, richiedi_testo


def _scheda_pico():
    from ..grafica.servizi.pico import SchedaPico
    return SchedaPico


@funzione_libreria("collega_scheda")
def collega_scheda(porta: Any = "auto", indirizzo: Any = "", simulata: Any = False, tipo: Any = "auto"):
    """collega_scheda(porta = "auto", indirizzo = "", simulata = falso, tipo = "auto"): collega una
    scheda MicroPython e la restituisce già pronta. ``porta`` "auto" prende la prima trovata (USB);
    con ``indirizzo`` usa il Wi-Fi; con ``simulata = vero`` non serve hardware. ``tipo`` sceglie la
    scheda: "pico" o "rp2040" (Raspberry/RP2040), "esp32", "arduino_nano_esp32" (ESP32-S3); "auto"
    la riconosce dal collegamento. Nota: gli Arduino classici (AVR, come Uno o Nano AVR) non hanno
    MicroPython e qui danno un errore chiaro (servirebbe un ponte Firmata, non ancora supportato).
    Esempio: `variabile s = collega_scheda(simulata = vero, tipo = "arduino_nano_esp32")`.
    """
    porta = richiedi_testo(porta, "collega_scheda", "porta") if porta != "auto" else "auto"
    indirizzo = richiedi_testo(indirizzo, "collega_scheda", "indirizzo") if indirizzo else ""
    simulata = richiedi_logico(simulata, "collega_scheda", "simulata") if simulata is not False else False
    tipo = richiedi_testo(tipo, "collega_scheda", "tipo") if tipo != "auto" else "auto"
    scheda = _scheda_pico()(porta=porta or "auto", indirizzo=indirizzo or "",
                            simulata=bool(simulata), tipo=tipo or "auto")
    scheda.connetti()
    return Scheda(scheda)


@funzione_libreria("scheda_simulata")
def scheda_simulata():
    """scheda_simulata(): una scheda finta già collegata, per provare la robotica senza hardware.

    Esempio: `variabile s = scheda_simulata()` poi `s.accendi(25)`.
    """
    scheda = _scheda_pico()(simulata=True)
    scheda.connetti()
    return Scheda(scheda)


@funzione_libreria("schede_disponibili")
def schede_disponibili():
    """schede_disponibili(): la lista delle porte USB dove si vede una scheda (vuota = nessuna).

    Esempio: `per ogni porta in schede_disponibili() fai stampa(porta) fine`.
    """
    from ..grafica.servizi.pico import porte_disponibili
    return porte_disponibili()


class Scheda(Richiamabile):
    """Una scheda collegata, vista dal codice Leo: `scheda.accendi(25)`, `scheda.temperatura()`..."""

    NOME_TIPO_DANTE = "scheda"
    ATTRIBUTI_DANTE = True
    _METODI = (
        "accendi", "spegni", "imposta_pin", "intensita", "leggi_pin",
        "servo", "motore", "suona",
        "temperatura", "luce", "distanza", "umidita", "movimento",
        "potenziometro", "suono", "analogico", "leggi_sensore",
        "sorveglia_pulsante", "invia_testo", "eventi", "scollega",
        "passo_passo", "i2c_cerca", "i2c_leggi", "i2c_scrivi", "spi_trasferisci",
        "schermo", "scrivi_schermo", "pulisci_schermo", "mostra_schermo",
    )

    def __init__(self, scheda: Any) -> None:
        self._s = scheda

    def attributo_dante(self, nome: str):
        if nome == "collegata":
            return bool(self._s.connessa)
        if nome == "descrizione":
            return str(self._s.descrizione)
        if nome == "simulata":
            return bool(self._s.simulata)
        if nome not in self._METODI:
            raise ErroreNome(f"Una scheda non ha `{nome}`.",
                             suggerimento="Metodi: " + ", ".join(f"`{m}`" for m in self._METODI)
                             + "; proprietà: `collegata`, `descrizione`, `simulata`.", nome=nome)
        return _MetodoScheda(self._s, nome)

    leggi = attributo_dante

    def testo_dante(self) -> str:
        stato = "collegata" if self._s.connessa else "scollegata"
        return f"scheda {self._s.descrizione} ({stato})"

    def valore_python(self) -> Any:
        return self._s


class _MetodoScheda(Richiamabile):
    """Un metodo della scheda (`accendi`, `leggi_sensore`...), pronto da chiamare."""

    def __init__(self, scheda: Any, nome: str) -> None:
        self._s = scheda
        self._nome = nome

    def _arg(self, argomenti, argomenti_nome, pos, chiave, predefinito="__OBBLIGATORIO__"):
        if len(argomenti) > pos:
            return argomenti[pos]
        if chiave in argomenti_nome:
            return argomenti_nome[chiave]
        if predefinito == "__OBBLIGATORIO__":
            raise ErroreTipo(f"Al metodo `{self._nome}` serve `{chiave}`.")
        return predefinito

    def chiama(self, interprete: Any, argomenti: list, argomenti_nome: dict) -> Any:
        s, nome = self._s, self._nome

        def A(pos, chiave, pre="__OBBLIGATORIO__"):
            return self._arg(argomenti, argomenti_nome, pos, chiave, pre)

        if nome == "accendi":
            s.scrivi_pin(A(0, "pin"), 1); return None
        if nome == "spegni":
            s.scrivi_pin(A(0, "pin"), 0); return None
        if nome == "imposta_pin":
            s.scrivi_pin(A(0, "pin"), A(1, "valore")); return None
        if nome == "intensita":
            s.pwm(A(0, "pin"), A(1, "percentuale"), int(A(2, "frequenza", 1000))); return None
        if nome == "leggi_pin":
            return s.leggi_pin(A(0, "pin"), str(A(1, "pull", "")))
        if nome == "servo":
            try:
                ang = max(0.0, min(180.0, float(A(1, "angolo"))))
            except (TypeError, ValueError):
                raise ErroreTipo("`servo` vuole un angolo da 0 a 180 gradi.")
            s.pwm(A(0, "pin"), 2.5 + ang / 180.0 * 10.0, 50); return None
        if nome == "motore":
            try:
                vel = max(-100.0, min(100.0, float(A(2, "velocita"))))
            except (TypeError, ValueError):
                raise ErroreTipo("`motore` vuole una velocita' da -100 a 100.")
            avanti, indietro = A(0, "pin_avanti"), A(1, "pin_indietro")
            if vel >= 0:
                s.scrivi_pin(indietro, 0); s.pwm(avanti, vel)
            else:
                s.scrivi_pin(avanti, 0); s.pwm(indietro, -vel)
            return None
        if nome == "suona":
            try:
                f = int(A(1, "frequenza"))
            except (TypeError, ValueError):
                raise ErroreTipo("`suona` vuole una frequenza in hertz (un numero).")
            if f <= 0:
                raise ErroreValore("La frequenza di `suona` deve essere maggiore di zero.")
            pin = A(0, "pin"); s.pwm(pin, 50, f)
            try:
                d = float(A(2, "durata", 0))
            except (TypeError, ValueError):
                d = 0.0
            if d > 0:
                import time as _time
                _time.sleep(min(d, 10.0)); s.scrivi_pin(pin, 0)
            return None
        if nome == "umidita":
            return s.leggi_sensore("umidita", A(0, "pin", 26))
        if nome == "movimento":
            return s.leggi_sensore("movimento", A(0, "pin", 16))
        if nome == "potenziometro":
            return s.leggi_sensore("potenziometro", A(0, "pin", 26))
        if nome == "suono":
            return s.leggi_sensore("suono", A(0, "pin", 26))
        if nome == "analogico":
            return s.leggi_sensore("analogico", A(0, "pin", 26))
        if nome == "temperatura":
            return s.leggi_sensore("temperatura", A(0, "pin", -1))
        if nome == "luce":
            return s.leggi_sensore("luce", A(0, "pin", 26))
        if nome == "distanza":
            return s.leggi_sensore("distanza", A(0, "pin", 26), A(1, "eco", None))
        if nome == "leggi_sensore":
            return s.leggi_sensore(str(A(0, "tipo")), A(1, "pin", 26), A(2, "eco", None))
        if nome == "sorveglia_pulsante":
            s.sorveglia_pulsante(A(0, "pin")); return None
        if nome == "invia_testo":
            s.invia_testo(A(0, "testo")); return None
        if nome == "passo_passo":
            return s.stepper(A(0, "pin"), A(1, "passi"), A(2, "direzione", 1),
                             int(A(3, "ritardo_us", 2000)), bool(A(4, "mezzo_passo", False)))
        if nome == "i2c_cerca":
            return list(s.i2c_cerca(A(0, "sda", 0), A(1, "scl", 1)))
        if nome == "i2c_leggi":
            return list(s.i2c_leggi(A(0, "indirizzo"), A(1, "quanti", 1), A(2, "sda", 0), A(3, "scl", 1)))
        if nome == "i2c_scrivi":
            s.i2c_scrivi(A(0, "indirizzo"), A(1, "dati"), A(2, "sda", 0), A(3, "scl", 1)); return None
        if nome == "spi_trasferisci":
            return list(s.spi_trasferisci(A(0, "dati"), A(1, "sck", 2), A(2, "mosi", 3), A(3, "miso", 4)))
        if nome in ("schermo", "scrivi_schermo"):
            s.oled_testo(A(0, "testo"), A(1, "riga", 0)); return None
        if nome == "pulisci_schermo":
            s.oled_pulisci(); return None
        if nome == "mostra_schermo":
            return list(s.oled_mostra())
        if nome == "eventi":
            return list(s.ricevi())
        if nome == "scollega":
            s.disconnetti(); return None
        raise ErroreNome(f"Una scheda non ha `{nome}`.", nome=nome)


# ============================================================================
# Rilevamento e preparazione (flash) delle schede
# ============================================================================

def _conferma(interprete, senza_conferma, funzione, testo):
    richiedi_logico(senza_conferma, funzione, "senza_conferma")
    if senza_conferma:
        return True
    from ..sistema._win import chiedi_conferma
    return chiedi_conferma(interprete, testo)


@funzione_libreria("rileva_dispositivi")
def rileva_dispositivi():
    """rileva_dispositivi(): la lista delle schede collegate, ognuna un dizionario con
    `tipo`, `nome`, `modo` ("pronta" o "flash"), `porta`, `unita`.

    Esempio: `per ogni d in rileva_dispositivi() fai stampa(d["nome"]) fine`.
    """
    from ..grafica.servizi.dispositivi import rileva_dispositivi as _rileva
    return [d.a_dizionario() for d in _rileva()]


@funzione_libreria("flasha_scheda", interprete=True)
def flasha_scheda(interprete, unita, firmware, senza_conferma=False):
    """flasha_scheda(unita, firmware): scrive il firmware MicroPython (.uf2) su una scheda in
    modalità flash (il disco BOOTSEL). Prende `unita` da `rileva_dispositivi()` (le schede in `modo`
    "flash"). Dopo, la scheda si riavvia col nuovo firmware. Esempio:
    `flasha_scheda("E:\\", "micropython.uf2")`. Chiede conferma (`senza_conferma = vero` la salta).
    """
    from ..grafica.servizi.dispositivi import flasha_firmware
    unita = richiedi_testo(unita, "flasha_scheda", "unita")
    firmware = richiedi_testo(firmware, "flasha_scheda", "firmware")
    if not _conferma(interprete, senza_conferma, "flasha_scheda",
                     f"Scrivo il firmware su `{unita}`?\n\nLa scheda verrà riprogrammata."):
        return False
    flasha_firmware(unita, firmware)
    return True


@funzione_libreria("carica_programma", interprete=True)
def carica_programma(interprete, porta, file, nome_remoto="main.py", senza_conferma=False):
    """carica_programma(porta, file): carica un file Python sulla scheda come `main.py` (via REPL
    MicroPython), così parte da solo all'accensione. La scheda deve già avere MicroPython.
    Chiede conferma. Esempio: `carica_programma("COM5", "robot.py")`.
    """
    from ..grafica.servizi.dispositivi import carica_programma as _carica
    porta = richiedi_testo(porta, "carica_programma", "porta")
    file = richiedi_testo(file, "carica_programma", "file")
    nome_remoto = richiedi_testo(nome_remoto, "carica_programma", "nome_remoto") if nome_remoto != "main.py" else "main.py"
    if not _conferma(interprete, senza_conferma, "carica_programma",
                     f"Carico `{file}` sulla scheda `{porta}` come `{nome_remoto}`?"):
        return False
    _carica(porta, file, nome_remoto)
    return True


@funzione_libreria("rendi_pronta", interprete=True)
def rendi_pronta(interprete, porta, senza_conferma=False):
    """rendi_pronta(porta): mette il programma di Leo (`leo_pico.py`) sulla scheda come `main.py`,
    così `collega_scheda` funziona. La scheda deve già avere MicroPython. Chiede conferma.
    Esempio: `rendi_pronta("COM5")`.
    """
    from ..grafica.servizi.dispositivi import carica_programma as _carica
    from ..percorsi import file_dati
    porta = richiedi_testo(porta, "rendi_pronta", "porta")
    sorgente = str(file_dati("pico", "leo_pico.py"))
    if not _conferma(interprete, senza_conferma, "rendi_pronta",
                     f"Preparo la scheda `{porta}` per Leo?\n\nCarico il programma di Leo come `main.py`."):
        return False
    _carica(porta, sorgente, "main.py")
    return True


__all__ = ["collega_scheda", "scheda_simulata", "schede_disponibili", "Scheda",
           "rileva_dispositivi", "flasha_scheda", "carica_programma", "rendi_pronta"]
