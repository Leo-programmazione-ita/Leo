"""Libreria: sicurezza dei dati (impronte, codifiche, casualità sicura, HMAC, password).

Tutto con la sola libreria standard di Python (``hashlib``, ``hmac``,
``secrets``, ``base64``, ``uuid``):

* ``impronta``, ``impronta_file``: l'impronta (hash) di un testo, di una lista
  di byte o di un file con md5, sha1, sha256, sha512...;
* ``codifica_base64``/``decodifica_base64``, ``codifica_esadecimale``/``decodifica_esadecimale``;
* ``nuovo_uuid``, ``password_casuale``, ``numero_casuale_sicuro``,
  ``testo_casuale_sicuro`` (generatore crittografico ``secrets``, non ``casuale``);
* ``firma_hmac``/``verifica_hmac`` e ``confronto_sicuro`` (a tempo costante);
* ``impronta_password``/``verifica_password``: salvare le password nel modo
  giusto (scrypt con sale casuale), senza mai conservarle in chiaro.

La **cifratura** (rendere un testo illeggibile e poi di nuovo leggibile con
una password) è AES-256-GCM, un cifrario vero fatto da una libreria
riconosciuta (``cryptography`` sul PC, quella di Android sul telefono): le
funzioni ``cifra_testo``/``decifra_testo``/``cifra_file`` (modulo ``binario``)
e il controllo ``Cifratura`` usano lo stesso formato (:mod:`leo.cifratura`).
Qui non c'è nessun cifrario fatto a mano.

``md5`` e ``sha1`` NON sono sicuri (si possono costruire due dati diversi con
la stessa impronta): restano solo per confrontare impronte già esistenti.
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import os
import secrets
import string
import uuid
from typing import Any

from ..errori import ErroreTipo, ErroreValore
from .generali import articolo, funzione_libreria, mostra, richiedi_intero, richiedi_logico, richiedi_testo
from .ingresso_uscita import _controlla_percorso, _errore_file

#: Algoritmi NON sicuri (collisioni note): solo per confrontare impronte già esistenti.
ALGORITMI_NON_SICURI = frozenset({"md5", "sha1"})

#: Algoritmi di impronta ammessi (nome Leo -> nome hashlib).
ALGORITMI = {
    "md5": "md5", "sha1": "sha1", "sha224": "sha224", "sha256": "sha256", "sha384": "sha384",
    "sha512": "sha512", "sha3_256": "sha3_256", "sha3_512": "sha3_512", "blake2b": "blake2b",
    "blake2s": "blake2s",
}
#: Dati più grandi di così (in byte) non si trattano in memoria come testo o lista.
MASSIMO_DATI = 64 * 1024 * 1024
#: Lunghezza massima di password e testi casuali.
MASSIMA_LUNGHEZZA_CASUALE = 4096
SIMBOLI_PASSWORD = "!#$%&*+-=?@^_~.,:;"
_AMBIGUI = set("Il1O0o")

# parametri di scrypt per impronta_password (consigliati per l'uso interattivo)
_SCRYPT_N, _SCRYPT_R, _SCRYPT_P = 2 ** 14, 8, 1


def _in_byte(dati: Any, nome_funzione: str, parametro: str = "dati") -> bytes:
    """Un testo (in UTF-8) o una lista di numeri 0-255 come ``bytes``."""
    if isinstance(dati, str):
        if len(dati) > MASSIMO_DATI:
            raise ErroreValore(f"Il testo dato a `{nome_funzione}` è troppo lungo.")
        try:
            return dati.encode("utf-8")
        except UnicodeEncodeError:
            return dati.encode("utf-8", "surrogatepass")
    if isinstance(dati, list):
        if len(dati) > MASSIMO_DATI:
            raise ErroreValore(f"La lista di byte data a `{nome_funzione}` è troppo lunga.")
        for i, b in enumerate(dati):
            if type(b) is not int or not 0 <= b <= 255:
                raise ErroreValore(f"Nella lista di byte di `{nome_funzione}` l'elemento in posizione {i} "
                                   f"({mostra(b)}) non è un numero da 0 a 255.")
        return bytes(dati)
    raise ErroreTipo(f"L'argomento `{parametro}` di `{nome_funzione}` deve essere un testo o una lista di byte, "
                     f"non {articolo(dati)}.")


def _algoritmo(nome: Any, nome_funzione: str) -> str:
    richiedi_testo(nome, nome_funzione, "algoritmo")
    chiave = nome.strip().lower().replace("-", "").replace(" ", "")
    chiave = {"sha3256": "sha3_256", "sha3512": "sha3_512"}.get(chiave, chiave)
    if chiave not in ALGORITMI:
        raise ErroreValore(f"Non conosco l'algoritmo di impronta {mostra(nome)}.",
                           suggerimento="Usa \"sha256\" (consigliato), \"sha512\", \"sha1\" o \"md5\" "
                                        "(questi due non sono sicuri).")
    return ALGORITMI[chiave]


def _nuovo_calcolo(algoritmo: str):
    try:
        return hashlib.new(algoritmo)
    except ValueError:  # pragma: no cover - md5 disattivato nei sistemi FIPS
        try:
            return hashlib.new(algoritmo, usedforsecurity=False)
        except (TypeError, ValueError):
            raise ErroreValore(f"L'algoritmo {algoritmo} non è disponibile su questo computer.",
                               suggerimento="Usa \"sha256\".") from None


@funzione_libreria("impronta")
def impronta(dati, algoritmo="sha256"):
    """impronta(dati, algoritmo = "sha256"): l'impronta (hash) di un testo o di una lista di byte, in esadecimale.

    La stessa entrata dà sempre la stessa impronta; basta cambiare una lettera perché cambi tutta.
    Algoritmi: "sha256" (consigliato), "sha512", "sha1", "md5" (questi due NON sono sicuri: solo per confronti).
    Esempio: `impronta("ciao", "md5")` è "6e6bc4e49dd477ebc98ef4046c067b5f".
    """
    contenuto = _in_byte(dati, "impronta")
    calcolo = _nuovo_calcolo(_algoritmo(algoritmo, "impronta"))
    calcolo.update(contenuto)
    return calcolo.hexdigest()


@funzione_libreria("impronta_file")
def impronta_file(percorso, algoritmo="sha256"):
    """impronta_file(percorso, algoritmo = "sha256"): l'impronta di un file, per controllare che non sia cambiato.

    Legge il file a pezzi: funziona anche con file molto grandi.
    Esempio: `stampa(impronta_file("installatore.zip"))` e confronta con l'impronta pubblicata dal sito.
    """
    _controlla_percorso(percorso, "impronta_file")
    calcolo = _nuovo_calcolo(_algoritmo(algoritmo, "impronta_file"))
    try:
        with open(percorso, "rb") as f:
            while True:
                pezzo = f.read(1024 * 1024)
                if not pezzo:
                    break
                calcolo.update(pezzo)
    except OSError as e:
        raise _errore_file(e, percorso, "leggere") from None
    return calcolo.hexdigest()


def _testo_o_byte(contenuto: bytes, come_byte: bool, nome_funzione: str) -> Any:
    if come_byte:
        return list(contenuto)
    try:
        return contenuto.decode("utf-8")
    except UnicodeDecodeError:
        raise ErroreValore(f"Il risultato di `{nome_funzione}` non è un testo leggibile (sono dati binari).",
                           suggerimento=f"Per avere la lista dei byte scrivi `{nome_funzione}(..., come_byte = vero)`.") \
            from None


@funzione_libreria("codifica_base64")
def codifica_base64(dati, per_url=False):
    """codifica_base64(dati, per_url = falso): il testo o la lista di byte in Base64 (solo lettere, cifre, + / =).

    Con `per_url = vero` usa `-` e `_` al posto di `+` e `/`, così si può mettere in un indirizzo web.
    Esempio: `codifica_base64("ciao")` è "Y2lhbw==".
    """
    contenuto = _in_byte(dati, "codifica_base64")
    richiedi_logico(per_url, "codifica_base64", "per_url")
    codifica = base64.urlsafe_b64encode if per_url else base64.b64encode
    return codifica(contenuto).decode("ascii")


@funzione_libreria("decodifica_base64")
def decodifica_base64(testo, come_byte=False):
    """decodifica_base64(testo, come_byte = falso): il contrario di `codifica_base64`.

    Accetta anche la variante per URL e il testo senza gli `=` finali.
    Esempio: `decodifica_base64("Y2lhbw==")` è "ciao". Con `come_byte = vero` dà la lista dei byte.
    """
    richiedi_testo(testo, "decodifica_base64", "testo")
    richiedi_logico(come_byte, "decodifica_base64", "come_byte")
    pulito = "".join(testo.split())
    if len(pulito) > MASSIMO_DATI:
        raise ErroreValore("Il testo dato a `decodifica_base64` è troppo lungo.")
    pulito = pulito.replace("-", "+").replace("_", "/")
    pulito += "=" * (-len(pulito) % 4)
    try:
        contenuto = base64.b64decode(pulito.encode("ascii"), validate=True)
    except (binascii.Error, ValueError, UnicodeEncodeError):
        raise ErroreValore(f"Il testo {mostra(testo)} non è Base64 valido.",
                           suggerimento="Il Base64 contiene solo lettere, cifre, `+`, `/` e `=` alla fine.") from None
    return _testo_o_byte(contenuto, come_byte, "decodifica_base64")


@funzione_libreria("codifica_esadecimale")
def codifica_esadecimale(dati, separatore=""):
    """codifica_esadecimale(dati, separatore = ""): il testo o la lista di byte scritti in esadecimale (due cifre per byte).

    Esempi: `codifica_esadecimale("Leo")` è "4c656f"; `codifica_esadecimale([255, 1], " ")` è "ff 01".
    """
    contenuto = _in_byte(dati, "codifica_esadecimale")
    richiedi_testo(separatore, "codifica_esadecimale", "separatore")
    return separatore.join(f"{b:02x}" for b in contenuto) if separatore else contenuto.hex()


@funzione_libreria("decodifica_esadecimale")
def decodifica_esadecimale(testo, come_byte=False):
    """decodifica_esadecimale(testo, come_byte = falso): il contrario di `codifica_esadecimale` (spazi e `:` ignorati).

    Esempi: `decodifica_esadecimale("4c656f")` è "Leo"; `decodifica_esadecimale("ff 01", come_byte = vero)` è [255, 1].
    """
    richiedi_testo(testo, "decodifica_esadecimale", "testo")
    richiedi_logico(come_byte, "decodifica_esadecimale", "come_byte")
    pulito = "".join(testo.replace(":", " ").replace("-", " ").split())
    if len(pulito) > MASSIMO_DATI:
        raise ErroreValore("Il testo dato a `decodifica_esadecimale` è troppo lungo.")
    if pulito[:2].lower() == "0x":
        pulito = pulito[2:]
    if len(pulito) % 2:
        raise ErroreValore(f"Il testo esadecimale {mostra(testo)} ha un numero dispari di cifre.",
                           suggerimento="Ogni byte si scrive con due cifre: \"0a\", non \"a\".")
    try:
        contenuto = bytes.fromhex(pulito)
    except ValueError:
        raise ErroreValore(f"Il testo {mostra(testo)} non è esadecimale valido.",
                           suggerimento="Le cifre esadecimali sono 0-9 e a-f.") from None
    return _testo_o_byte(contenuto, come_byte, "decodifica_esadecimale")


@funzione_libreria("nuovo_uuid")
def nuovo_uuid():
    """nuovo_uuid(): un identificativo unico universale (UUID versione 4), casuale.

    Esempio: `nuovo_uuid()` è per esempio "3f2b8c1e-9a4d-4e57-b6f0-2d8c9e1a7b35".
    """
    return str(uuid.uuid4())


def _lunghezza(valore: Any, nome_funzione: str, parametro: str, minimo: int) -> int:
    richiedi_intero(valore, nome_funzione, parametro)
    if not minimo <= valore <= MASSIMA_LUNGHEZZA_CASUALE:
        raise ErroreValore(f"`{parametro}` di `{nome_funzione}` deve essere tra {minimo} e "
                           f"{MASSIMA_LUNGHEZZA_CASUALE} (hai scritto {mostra(valore)}).")
    return valore


@funzione_libreria("password_casuale")
def password_casuale(lunghezza=16, simboli=True, cifre=True, maiuscole=True, senza_ambigui=False):
    """password_casuale(lunghezza = 16, simboli = vero, cifre = vero, maiuscole = vero, senza_ambigui = falso): una password robusta.

    Usa il generatore crittografico del sistema e contiene almeno un carattere di ogni gruppo scelto.
    Con `senza_ambigui = vero` evita i caratteri che si confondono (I, l, 1, O, 0, o).
    Esempi: `password_casuale()`; `password_casuale(24, simboli = falso)`.
    """
    _lunghezza(lunghezza, "password_casuale", "lunghezza", 4)
    for nome, v in (("simboli", simboli), ("cifre", cifre), ("maiuscole", maiuscole),
                    ("senza_ambigui", senza_ambigui)):
        richiedi_logico(v, "password_casuale", nome)
    gruppi = [string.ascii_lowercase]
    if maiuscole:
        gruppi.append(string.ascii_uppercase)
    if cifre:
        gruppi.append(string.digits)
    if simboli:
        gruppi.append(SIMBOLI_PASSWORD)
    if senza_ambigui:
        gruppi = ["".join(c for c in g if c not in _AMBIGUI) for g in gruppi]
    tutti = "".join(gruppi)
    caratteri = [secrets.choice(g) for g in gruppi]  # almeno uno per gruppo
    caratteri += [secrets.choice(tutti) for _ in range(lunghezza - len(caratteri))]
    # mescolamento crittografico (Fisher-Yates con secrets)
    for i in range(len(caratteri) - 1, 0, -1):
        j = secrets.randbelow(i + 1)
        caratteri[i], caratteri[j] = caratteri[j], caratteri[i]
    return "".join(caratteri)


@funzione_libreria("numero_casuale_sicuro")
def numero_casuale_sicuro(da, a):
    """numero_casuale_sicuro(da, a): un intero a caso tra `da` e `a` (compresi), imprevedibile.

    A differenza di `casuale` non si può ripetere né indovinare: va bene per codici di verifica,
    estrazioni e giochi con premi. Esempio: `numero_casuale_sicuro(100000, 999999)`.
    """
    richiedi_intero(da, "numero_casuale_sicuro", "da")
    richiedi_intero(a, "numero_casuale_sicuro", "a")
    if da > a:
        raise ErroreValore(f"In `numero_casuale_sicuro(da, a)` il primo numero non può essere più grande del secondo "
                           f"(hai scritto {mostra(da)} e {mostra(a)}).")
    return da + secrets.randbelow(a - da + 1)


@funzione_libreria("testo_casuale_sicuro")
def testo_casuale_sicuro(lunghezza=32, solo_cifre=False):
    """testo_casuale_sicuro(lunghezza = 32, solo_cifre = falso): un testo casuale imprevedibile (lettere, cifre, `-`, `_`).

    Serve per chiavi, codici di invito, gettoni di accesso. Esempi: `testo_casuale_sicuro(20)`;
    `testo_casuale_sicuro(6, solo_cifre = vero)` è per esempio "048213".
    """
    _lunghezza(lunghezza, "testo_casuale_sicuro", "lunghezza", 1)
    richiedi_logico(solo_cifre, "testo_casuale_sicuro", "solo_cifre")
    alfabeto = string.digits if solo_cifre else string.ascii_letters + string.digits + "-_"
    return "".join(secrets.choice(alfabeto) for _ in range(lunghezza))


@funzione_libreria("firma_hmac")
def firma_hmac(messaggio, chiave, algoritmo="sha256"):
    """firma_hmac(messaggio, chiave, algoritmo = "sha256"): la firma HMAC del messaggio con una chiave segreta, in esadecimale.

    Chi conosce la chiave può controllare che il messaggio non sia stato cambiato.
    Esempio: `variabile f = firma_hmac("importo=100", "chiave segreta")`.
    """
    dati = _in_byte(messaggio, "firma_hmac", "messaggio")
    segreto = _in_byte(chiave, "firma_hmac", "chiave")
    nome = _algoritmo(algoritmo, "firma_hmac")
    return hmac.new(segreto, dati, nome).hexdigest()


@funzione_libreria("verifica_hmac")
def verifica_hmac(messaggio, chiave, firma, algoritmo="sha256"):
    """verifica_hmac(messaggio, chiave, firma, algoritmo = "sha256"): `vero` se la firma HMAC corrisponde al messaggio.

    Il confronto è a tempo costante. Esempio: `se verifica_hmac(messaggio, chiave, f) allora stampa("Integro") fine`.
    """
    richiedi_testo(firma, "verifica_hmac", "firma")
    attesa = firma_hmac(messaggio, chiave, algoritmo)
    return hmac.compare_digest(attesa.encode("ascii"), firma.strip().lower().encode("utf-8", "replace"))


@funzione_libreria("confronto_sicuro")
def confronto_sicuro(a, b):
    """confronto_sicuro(a, b): `vero` se i due testi (o liste di byte) sono uguali, in un tempo che non svela dove differiscono.

    Da usare per confrontare codici segreti, gettoni e firme. Esempio: `confronto_sicuro(codice, "048213")`.
    """
    return hmac.compare_digest(_in_byte(a, "confronto_sicuro", "a"), _in_byte(b, "confronto_sicuro", "b"))


def _b64(dati: bytes) -> str:
    return base64.b64encode(dati).decode("ascii").rstrip("=")


def _da_b64(testo: str) -> bytes:
    return base64.b64decode(testo + "=" * (-len(testo) % 4), validate=True)


def _scrypt(password: bytes, sale: bytes, n: int, r: int, p: int) -> bytes:
    try:
        return hashlib.scrypt(password, salt=sale, n=n, r=r, p=p, maxmem=256 * 1024 * 1024, dklen=32)
    except (ValueError, MemoryError):
        raise ErroreValore("Non riesco a calcolare l'impronta della password con questi parametri.") from None


@funzione_libreria("impronta_password")
def impronta_password(password):
    """impronta_password(password): l'impronta da salvare al posto della password (scrypt con sale casuale).

    Due chiamate con la stessa password danno impronte diverse (per il sale), ma `verifica_password`
    le riconosce entrambe. Non si può risalire alla password.
    Esempio: `variabile salvata = impronta_password("Cavallo-Batteria-42")`.
    """
    richiedi_testo(password, "impronta_password", "password")
    if not password:
        raise ErroreValore("La password è vuota.", suggerimento="Chiedi all'utente di scrivere una password.")
    dati = _in_byte(password, "impronta_password", "password")
    sale = os.urandom(16)
    calcolata = _scrypt(dati, sale, _SCRYPT_N, _SCRYPT_R, _SCRYPT_P)
    return f"scrypt${_SCRYPT_N}${_SCRYPT_R}${_SCRYPT_P}${_b64(sale)}${_b64(calcolata)}"


@funzione_libreria("verifica_password")
def verifica_password(password, impronta_salvata):
    """verifica_password(password, impronta_salvata): `vero` se la password corrisponde all'impronta di `impronta_password`.

    Esempio: `se verifica_password(chiedi("Password: "), salvata) allora stampa("Benvenuto") fine`.
    """
    richiedi_testo(password, "verifica_password", "password")
    richiedi_testo(impronta_salvata, "verifica_password", "impronta_salvata")
    parti = impronta_salvata.strip().split("$")
    errore = ErroreValore(f"{mostra(impronta_salvata)} non è un'impronta creata da `impronta_password`.",
                          suggerimento="Salva e rileggi il testo restituito da `impronta_password(...)` senza cambiarlo.")
    if len(parti) != 6 or parti[0] != "scrypt":
        raise errore
    try:
        n, r, p = int(parti[1]), int(parti[2]), int(parti[3])
        sale, attesa = _da_b64(parti[4]), _da_b64(parti[5])
    except (ValueError, binascii.Error):
        raise errore from None
    if not (2 <= n <= 2 ** 20 and n & (n - 1) == 0 and 1 <= r <= 32 and 1 <= p <= 16 and sale and len(attesa) == 32):
        raise errore
    calcolata = _scrypt(_in_byte(password, "verifica_password", "password"), sale, n, r, p)
    return hmac.compare_digest(calcolata, attesa)
