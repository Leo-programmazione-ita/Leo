"""Libreria "desktop" (S2): il programma Leo organizza il desktop di Windows.

Gruppi di funzioni (la parte che chiama davvero Windows è in
``leo/sistema/desktop.py``; qui ci sono controlli, conferme e messaggi):

* **finestre delle applicazioni**: ``elenca_finestre``, ``trova_finestra``,
  ``trova_finestre``, ``finestra_esiste``, ``finestra_attiva``, ``info_finestra``,
  ``porta_in_primo_piano``, ``minimizza_finestra``, ``massimizza_finestra``,
  ``ripristina_finestra``, ``sposta_finestra``, ``ridimensiona_finestra``,
  ``sempre_in_primo_piano``, ``chiudi_finestra_programma`` (con conferma),
  ``affianca_finestre``;
* **schermi**: ``numero_schermi``, ``elenca_schermi``, ``schermo_principale``,
  ``risoluzione_schermo``, ``scala_schermo``, ``area_di_lavoro``, ``frequenza_schermo``;
* **cattura**: ``cattura_schermo``, ``cattura_zona``, ``cattura_finestra`` (PNG),
  ``colore_punto``;
* **notifiche**: ``mostra_notifica``;
* **finestre di dialogo**: ``messaggio_windows``, ``domanda_windows``,
  ``scegli_file_da_aprire``, ``scegli_piu_file``, ``scegli_file_da_salvare``,
  ``scegli_cartella``, ``chiedi_colore`` (con Qt se il programma ha finestre,
  altrimenti quelle native di Windows);
* **aspetto**: ``sfondo_desktop``, ``imposta_sfondo_desktop``, ``tema_windows``,
  ``tema_scuro_attivo``, ``colore_accento``, ``suono_di_sistema``, ``suoni_di_sistema``.

Una "finestra" si indica con il suo titolo (anche solo una parte, o il nome del
programma: "notepad"), con il dizionario restituito da ``elenca_finestre`` /
``trova_finestra`` o con il suo numero ``id``. Niente simulazione di tastiera o
mouse: le finestre si comandano solo con le normali richieste di Windows.
"""

from __future__ import annotations

import os
from typing import Any

from ..errori import ErroreFile, ErroreTipo, ErroreValore
from ..sistema import _win
from ..sistema import desktop as dk
from ..sistema._win import ErroreSistema, chiedi_conferma, solo_windows
from .generali import articolo, funzione_libreria, richiedi_intero, richiedi_logico, richiedi_numero, richiedi_testo

#: limite di sicurezza per le coordinate (pixel)
COORDINATA_MASSIMA = 100_000
#: lato massimo di una cattura e numero massimo di pixel
LATO_MASSIMO = 32_767
PIXEL_MASSIMI = 200_000_000

ESTENSIONI_SFONDO = (".jpg", ".jpeg", ".jfif", ".png", ".bmp", ".gif", ".tif", ".tiff", ".heic", ".webp")
ESTENSIONI_ICONA = (".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico")


def _n() -> Any:
    """Il backend nativo in uso (i test lo sostituiscono)."""
    return dk.nativo


# ===========================================================================
# Controlli degli argomenti
# ===========================================================================

def _testo_pieno(valore: Any, funzione: str, parametro: str, esempio: str) -> str:
    richiedi_testo(valore, funzione, parametro)
    if not valore.strip():
        raise ErroreValore(f"Il parametro `{parametro}` di `{funzione}` è vuoto.",
                           suggerimento=f"Scrivi per esempio `{esempio}`.")
    if "\0" in valore:
        raise ErroreValore(f"Il parametro `{parametro}` di `{funzione}` contiene un carattere non valido.")
    return valore


def _testo_breve(valore: Any, funzione: str, parametro: str, massimo: int) -> str:
    richiedi_testo(valore, funzione, parametro)
    if "\0" in valore:
        raise ErroreValore(f"Il parametro `{parametro}` di `{funzione}` contiene un carattere non valido.")
    if len(valore) > massimo:
        raise ErroreValore(f"Il parametro `{parametro}` di `{funzione}` è troppo lungo ({len(valore)} caratteri, "
                           f"al massimo {massimo}).")
    return valore


def _coordinata(valore: Any, funzione: str, parametro: str) -> int:
    n = richiedi_intero(valore, funzione, parametro)
    if abs(n) > COORDINATA_MASSIMA:
        raise ErroreValore(f"`{parametro}` di `{funzione}` è fuori dagli schermi ({n}).",
                           suggerimento="Le coordinate sono in pixel: guarda `elenca_schermi()` per le misure.")
    return n


def _misura(valore: Any, funzione: str, parametro: str, massimo: int = COORDINATA_MASSIMA) -> int:
    n = richiedi_intero(valore, funzione, parametro)
    if n <= 0:
        raise ErroreValore(f"`{parametro}` di `{funzione}` deve essere maggiore di zero, non {n}.")
    if n > massimo:
        raise ErroreValore(f"`{parametro}` di `{funzione}` è troppo grande ({n}, al massimo {massimo}).")
    return n


def _cartella_iniziale(valore: Any, funzione: str) -> str | None:
    if valore is None:
        return None
    _testo_pieno(valore, funzione, "cartella", f'{funzione}(cartella = "C:/Documenti")')
    if not os.path.isdir(valore):
        raise ErroreFile(f"La cartella `{valore}` non esiste.",
                         suggerimento="Controlla il percorso, oppure togli `cartella`.")
    return os.path.abspath(valore)


def _percorso_png(percorso: Any, funzione: str) -> str:
    if percorso is None:
        percorso = dk.nome_cattura()
    _testo_pieno(percorso, funzione, "percorso", f'{funzione}("schermo.png")')
    base, estensione = os.path.splitext(percorso)
    if not estensione:
        percorso += ".png"
    elif estensione.lower() != ".png":
        raise ErroreValore(f"`{funzione}` salva solo immagini PNG, non `{estensione}`.",
                           suggerimento=f'Usa un nome che finisce con ".png", per esempio "{os.path.basename(base)}.png".')
    assoluto = os.path.abspath(percorso)
    cartella = os.path.dirname(assoluto)
    if not os.path.isdir(cartella):
        raise ErroreFile(f"La cartella `{cartella}` non esiste.",
                         suggerimento="Crea prima la cartella con `crea_cartella(...)` o scegli un altro percorso.")
    if os.path.isdir(assoluto):
        raise ErroreFile(f"`{percorso}` è una cartella, non un file.")
    return assoluto


def _salva(percorso: str, larghezza: int, altezza: int, rgb: bytes) -> str:
    try:
        return dk.salva_png(percorso, larghezza, altezza, rgb)
    except OSError as e:
        raise ErroreFile(f"Non riesco a salvare l'immagine `{percorso}`.", suggerimento=str(e)) from None


# ===========================================================================
# Finestre delle applicazioni
# ===========================================================================

def _grezze() -> list[dict]:
    return [g for g in _n().finestre() if dk.da_elencare(g)]


def _componi(grezza: dict) -> dict:
    return dk.componi_finestra(grezza, _n().id_finestra_attiva())


def _elenco_titoli(grezze: list[dict], quanti: int = 5) -> str:
    titoli = [f"`{g['titolo']}`" for g in grezze[:quanti]]
    return ", ".join(titoli) if titoli else "nessuna"


class _NonTrovata(ErroreValore):
    """La finestra indicata non è aperta (per ``finestra_esiste``)."""

    @property
    def tipo(self) -> str:  # visto da Leo come ErroreValore
        return "ErroreValore"


def _risolvi(finestra: Any, funzione: str) -> dict:
    """I dati grezzi (freschi) della finestra indicata da titolo, dizionario o id."""
    if isinstance(finestra, str):
        _testo_pieno(finestra, funzione, "finestra", f'{funzione}("Blocco note")')
        grezze = _grezze()
        trovate = dk.filtra_per_titolo(grezze, finestra)
        if not trovate:
            raise _NonTrovata(f"Non trovo nessuna finestra aperta con `{finestra}` nel titolo.",
                               suggerimento=f"Finestre aperte ora: {_elenco_titoli(grezze)}. "
                                            "Usa `elenca_finestre()` per vederle tutte.")
        return trovate[0]
    if isinstance(finestra, dict):
        ident = finestra.get("id")
        if isinstance(ident, bool) or not isinstance(ident, int):
            raise ErroreValore(f"Il dizionario dato a `{funzione}` non è una finestra (manca `id`).",
                               suggerimento="Usa un elemento di `elenca_finestre()` o il risultato di `trova_finestra(...)`.")
        descrizione = f"`{finestra.get('titolo', ident)}`"
    elif isinstance(finestra, int) and not isinstance(finestra, bool):
        ident = finestra
        descrizione = f"numero {ident}"
    else:
        raise ErroreTipo(f"`{funzione}` vuole una finestra: il titolo (testo), un elemento di "
                         f"`elenca_finestre()` o il suo `id`, non {articolo(finestra)}.",
                         suggerimento=f'Scrivi per esempio `{funzione}("Blocco note")`.')
    if not 0 < ident < 2 ** 63:
        raise ErroreValore(f"`{ident}` non è l'id di una finestra.")
    grezza = _n().finestra(ident)
    if grezza is None:
        raise _NonTrovata(f"La finestra {descrizione} non c'è più: probabilmente è stata chiusa.",
                           suggerimento="Cercala di nuovo con `trova_finestra(...)`.")
    return grezza


def _risolvi_comandabile(finestra: Any, funzione: str) -> dict:
    grezza = _risolvi(finestra, funzione)
    if grezza.get("classe") in dk.CLASSI_DEL_DESKTOP:
        raise ErroreValore(f"`{funzione}` non si usa sul desktop o sulla barra delle applicazioni di Windows.")
    return grezza


def _aggiornata(grezza: dict) -> dict:
    fresca = _n().finestra(grezza["id"])
    return _componi(fresca if fresca is not None else grezza)


@funzione_libreria("elenca_finestre")
def elenca_finestre(filtro=""):
    """elenca_finestre(filtro = ""): le finestre delle applicazioni aperte, dalla più in alto.

    Ogni elemento è un dizionario con "id", "titolo", "programma" (per esempio "notepad.exe"), "pid",
    "classe", "x", "y", "larghezza", "altezza", "stato" ("normale", "minimizzata" o "massimizzata"),
    "sempre_in_primo_piano" e "attiva". Con `filtro` tiene solo le finestre che lo hanno nel titolo o
    nel nome del programma. Solo su Windows.
    Esempio: `per ogni f in elenca_finestre() fai stampa(f["titolo"], "-", f["programma"]) fine`.
    """
    richiedi_testo(filtro, "elenca_finestre", "filtro")
    solo_windows("elenca_finestre")
    grezze = _grezze()
    if filtro.strip():
        f = filtro.strip().casefold()
        grezze = [g for g in grezze if f in g["titolo"].casefold() or f in str(g.get("programma", "")).casefold()]
    attiva = _n().id_finestra_attiva()
    return [dk.componi_finestra(g, attiva) for g in grezze]


@funzione_libreria("trova_finestra")
def trova_finestra(titolo):
    """trova_finestra(titolo): la finestra con quel titolo (o che lo contiene), oppure `nulla`.

    Non conta maiuscole e minuscole; va bene anche il nome del programma ("notepad").
    Se ce ne sono più di una, prima quella con il titolo uguale, poi la più in alto.
    Solo su Windows. Esempio: `f = trova_finestra("Blocco note")` poi `se f != nulla allora stampa(f["id"]) fine`.
    """
    _testo_pieno(titolo, "trova_finestra", "titolo", 'trova_finestra("Blocco note")')
    solo_windows("trova_finestra")
    trovate = dk.filtra_per_titolo(_grezze(), titolo)
    return _componi(trovate[0]) if trovate else None


@funzione_libreria("trova_finestre")
def trova_finestre(titolo):
    """trova_finestre(titolo): tutte le finestre che hanno quel testo nel titolo (o nel nome del programma).

    Restituisce una lista di dizionari come `elenca_finestre` (vuota se non ce n'è nessuna).
    Solo su Windows. Esempio: `stampa(lunghezza(trova_finestre("Chrome")), "finestre di Chrome")`.
    """
    _testo_pieno(titolo, "trova_finestre", "titolo", 'trova_finestre("Chrome")')
    solo_windows("trova_finestre")
    attiva = _n().id_finestra_attiva()
    return [dk.componi_finestra(g, attiva) for g in dk.filtra_per_titolo(_grezze(), titolo)]


@funzione_libreria("finestra_esiste")
def finestra_esiste(finestra):
    """finestra_esiste(finestra): `vero` se la finestra (titolo, dizionario o id) è ancora aperta.

    Solo su Windows. Esempio: `mentre finestra_esiste("Calcolatrice") fai attendi(1) fine`.
    """
    if isinstance(finestra, str):
        _testo_pieno(finestra, "finestra_esiste", "finestra", 'finestra_esiste("Calcolatrice")')
    solo_windows("finestra_esiste")
    try:
        _risolvi(finestra, "finestra_esiste")
    except _NonTrovata:
        return False
    return True


@funzione_libreria("finestra_attiva")
def finestra_attiva():
    """finestra_attiva(): la finestra in primo piano (quella che riceve i tasti), oppure `nulla`.

    Restituisce un dizionario come `elenca_finestre`. Solo su Windows.
    Esempio: `stampa("Stai usando:", finestra_attiva()["titolo"])`.
    """
    solo_windows("finestra_attiva")
    ident = _n().id_finestra_attiva()
    if not ident:
        return None
    grezza = _n().finestra(ident)
    return dk.componi_finestra(grezza, ident) if grezza is not None else None


@funzione_libreria("info_finestra")
def info_finestra(finestra):
    """info_finestra(finestra): i dati aggiornati della finestra (posizione, dimensioni, stato...).

    Restituisce un dizionario come `elenca_finestre`; errore se la finestra non c'è.
    Solo su Windows. Esempio: `f = info_finestra("Blocco note")` e poi `stampa(f["larghezza"], "x", f["altezza"])`.
    """
    if isinstance(finestra, str):
        _testo_pieno(finestra, "info_finestra", "finestra", 'info_finestra("Blocco note")')
    solo_windows("info_finestra")
    return _componi(_risolvi(finestra, "info_finestra"))


@funzione_libreria("porta_in_primo_piano")
def porta_in_primo_piano(finestra):
    """porta_in_primo_piano(finestra): mostra la finestra davanti alle altre e la rende attiva.

    Se era minimizzata la ripristina. Restituisce `vero` se Windows l'ha messa in primo piano
    (a volte Windows lo impedisce e fa solo lampeggiare il pulsante nella barra).
    Solo su Windows. Esempio: `porta_in_primo_piano("Blocco note")`.
    """
    solo_windows("porta_in_primo_piano")
    grezza = _risolvi_comandabile(finestra, "porta_in_primo_piano")
    return bool(_n().porta_davanti(grezza["id"]))


def _mostra(finestra: Any, funzione: str, comando: int) -> dict:
    solo_windows(funzione)
    grezza = _risolvi_comandabile(finestra, funzione)
    _n().mostra(grezza["id"], comando)
    return _aggiornata(grezza)


@funzione_libreria("minimizza_finestra")
def minimizza_finestra(finestra):
    """minimizza_finestra(finestra): riduce la finestra a icona nella barra delle applicazioni.

    Restituisce i dati aggiornati della finestra. Solo su Windows.
    Esempio: `minimizza_finestra("Blocco note")`.
    """
    return _mostra(finestra, "minimizza_finestra", dk.SW_MINIMIZZA)


@funzione_libreria("massimizza_finestra")
def massimizza_finestra(finestra):
    """massimizza_finestra(finestra): ingrandisce la finestra a tutto schermo (con la barra visibile).

    Restituisce i dati aggiornati della finestra. Solo su Windows.
    Esempio: `massimizza_finestra("Blocco note")`.
    """
    return _mostra(finestra, "massimizza_finestra", dk.SW_MASSIMIZZA)


@funzione_libreria("ripristina_finestra")
def ripristina_finestra(finestra):
    """ripristina_finestra(finestra): riporta la finestra minimizzata o massimizzata alla sua misura normale.

    Restituisce i dati aggiornati della finestra. Solo su Windows.
    Esempio: `ripristina_finestra("Blocco note")`.
    """
    return _mostra(finestra, "ripristina_finestra", dk.SW_RIPRISTINA)


@funzione_libreria("sposta_finestra")
def sposta_finestra(finestra, x, y):
    """sposta_finestra(finestra, x, y): mette l'angolo in alto a sinistra della finestra nel punto (x, y).

    Le coordinate sono in pixel del desktop (0, 0 = angolo dello schermo principale; gli altri
    schermi possono avere coordinate negative). Una finestra massimizzata viene prima ripristinata.
    Restituisce i dati aggiornati. Solo su Windows. Esempio: `sposta_finestra("Blocco note", 100, 50)`.
    """
    nx = _coordinata(x, "sposta_finestra", "x")
    ny = _coordinata(y, "sposta_finestra", "y")
    solo_windows("sposta_finestra")
    grezza = _risolvi_comandabile(finestra, "sposta_finestra")
    _n().imposta_rettangolo(grezza["id"], nx, ny, None, None)
    return _aggiornata(grezza)


@funzione_libreria("ridimensiona_finestra")
def ridimensiona_finestra(finestra, larghezza, altezza):
    """ridimensiona_finestra(finestra, larghezza, altezza): cambia le dimensioni della finestra (in pixel).

    L'angolo in alto a sinistra resta dov'è; una finestra massimizzata viene prima ripristinata.
    Restituisce i dati aggiornati. Solo su Windows. Esempio: `ridimensiona_finestra("Blocco note", 800, 600)`.
    """
    nl = _misura(larghezza, "ridimensiona_finestra", "larghezza")
    na = _misura(altezza, "ridimensiona_finestra", "altezza")
    solo_windows("ridimensiona_finestra")
    grezza = _risolvi_comandabile(finestra, "ridimensiona_finestra")
    _n().imposta_rettangolo(grezza["id"], None, None, nl, na)
    return _aggiornata(grezza)


@funzione_libreria("sempre_in_primo_piano")
def sempre_in_primo_piano(finestra, attivo=True):
    """sempre_in_primo_piano(finestra, attivo = vero): tiene la finestra sopra tutte le altre (o smette con `falso`).

    Restituisce i dati aggiornati (chiave "sempre_in_primo_piano"). Solo su Windows.
    Esempio: `sempre_in_primo_piano("Calcolatrice")` e poi `sempre_in_primo_piano("Calcolatrice", falso)`.
    """
    richiedi_logico(attivo, "sempre_in_primo_piano", "attivo")
    solo_windows("sempre_in_primo_piano")
    grezza = _risolvi_comandabile(finestra, "sempre_in_primo_piano")
    _n().imposta_sempre_davanti(grezza["id"], attivo)
    return _aggiornata(grezza)


@funzione_libreria("chiudi_finestra_programma", interprete=True)
def chiudi_finestra_programma(interprete, finestra, senza_conferma=False):
    """chiudi_finestra_programma(finestra, senza_conferma = falso): chiede a un'altra applicazione di chiudere la finestra.

    È come premere la X: il programma può chiedere di salvare il lavoro o rifiutare. Prima chiede
    conferma all'utente del programma Leo (salvo `senza_conferma = vero`). Restituisce `vero` se la
    richiesta è partita, `falso` se l'utente risponde No. Per le finestre del proprio programma Leo
    si usa `chiudi_finestra`. Solo su Windows.
    Esempio: `se chiudi_finestra_programma("Blocco note") allora stampa("Richiesta inviata") fine`.
    """
    richiedi_logico(senza_conferma, "chiudi_finestra_programma", "senza_conferma")
    solo_windows("chiudi_finestra_programma")
    grezza = _risolvi_comandabile(finestra, "chiudi_finestra_programma")
    if not senza_conferma:
        programma = f" ({grezza['programma']})" if grezza.get("programma") else ""
        testo = (f"Il programma vuole chiudere la finestra `{grezza['titolo']}`{programma}.\n"
                 "Se ci sono modifiche non salvate, l'applicazione chiederà cosa fare. Continuare?")
        if not chiedi_conferma(interprete, testo, "Leo - chiudi una finestra"):
            return False
    if not _n().invia_chiusura(grezza["id"]):
        raise _win.errore_windows(f"chiedere la chiusura della finestra `{grezza['titolo']}`")
    return True


@funzione_libreria("affianca_finestre")
def affianca_finestre(sinistra, destra, divisione=50):
    """affianca_finestre(sinistra, destra, divisione = 50): mette due finestre una accanto all'altra.

    Usano tutta l'area di lavoro dello schermo dove si trova la prima; `divisione` è la percentuale
    di larghezza della finestra di sinistra (da 10 a 90). Restituisce la lista dei due dizionari
    aggiornati. Solo su Windows. Esempio: `affianca_finestre("Blocco note", "Calcolatrice", 60)`.
    """
    d = richiedi_numero(divisione, "affianca_finestre", "divisione")
    if isinstance(d, bool) or d != d or not 10 <= d <= 90:
        raise ErroreValore(f"`divisione` di `affianca_finestre` deve essere tra 10 e 90, non {d}.",
                           suggerimento="È la percentuale di larghezza della finestra di sinistra: 50 = metà e metà.")
    solo_windows("affianca_finestre")
    a = _risolvi_comandabile(sinistra, "affianca_finestre")
    b = _risolvi_comandabile(destra, "affianca_finestre")
    if a["id"] == b["id"]:
        raise ErroreValore("`affianca_finestre` vuole due finestre diverse, ma le due indicate sono la stessa.",
                           suggerimento="Usa titoli più precisi, oppure gli `id` di `elenca_finestre()`.")
    schermi = _schermi_grezzi()
    centro_x = a["x"] + a["larghezza"] // 2
    centro_y = a["y"] + a["altezza"] // 2
    schermo = dk.schermo_del_punto(schermi, centro_x, centro_y)
    if schermo is None:
        raise ErroreSistema("Windows non ha indicato nessuno schermo.")
    area = schermo.get("lavoro", (schermo["x"], schermo["y"], schermo["larghezza"], schermo["altezza"]))
    ra, rb = dk.rettangoli_affiancati(area, d / 100)
    for grezza, rett in ((a, ra), (b, rb)):
        _n().imposta_rettangolo(grezza["id"], *rett)
    return [_aggiornata(a), _aggiornata(b)]


# ===========================================================================
# Schermi
# ===========================================================================

def _schermi_grezzi() -> list[dict]:
    schermi = dk.ordina_schermi(_n().schermi())
    if not schermi:
        raise ErroreSistema("Windows non ha indicato nessuno schermo.")
    return schermi


def _schermo(schermo: Any, funzione: str) -> dict:
    schermi = _schermi_grezzi()
    if schermo is None:
        return schermi[0]
    n = richiedi_intero(schermo, funzione, "schermo")
    if not 1 <= n <= len(schermi):
        quanti = "c'è 1 schermo" if len(schermi) == 1 else f"ci sono {len(schermi)} schermi"
        raise ErroreValore(f"Lo schermo {n} non c'è: {quanti}.",
                           suggerimento="Gli schermi si contano da 1 (1 = principale): vedi `elenca_schermi()`.")
    return schermi[n - 1]


def _schermo_controllato(schermo: Any, funzione: str) -> None:
    if schermo is not None:
        richiedi_intero(schermo, funzione, "schermo")


@funzione_libreria("numero_schermi")
def numero_schermi():
    """numero_schermi(): quanti schermi (monitor) sono collegati e accesi.

    Solo su Windows. Esempio: `se numero_schermi() > 1 allora stampa("Hai più schermi") fine`.
    """
    solo_windows("numero_schermi")
    return len(_schermi_grezzi())


@funzione_libreria("elenca_schermi")
def elenca_schermi():
    """elenca_schermi(): gli schermi collegati, il principale per primo.

    Ogni elemento è un dizionario con "numero" (da 1), "nome", "dispositivo", "principale", "x", "y",
    "larghezza", "altezza" (in pixel), "area_di_lavoro" (senza la barra delle applicazioni), "dpi",
    "scala" (percentuale, per esempio 125) e "frequenza" (Hz). Solo su Windows.
    Esempio: `per ogni s in elenca_schermi() fai stampa(s["numero"], s["larghezza"], "x", s["altezza"]) fine`.
    """
    solo_windows("elenca_schermi")
    return [dk.componi_schermo(s) for s in _schermi_grezzi()]


@funzione_libreria("schermo_principale")
def schermo_principale():
    """schermo_principale(): il dizionario dello schermo principale (quello con la barra e l'orologio).

    Ha le stesse chiavi degli elementi di `elenca_schermi`. Solo su Windows.
    Esempio: `stampa(schermo_principale()["nome"])`.
    """
    solo_windows("schermo_principale")
    return dk.componi_schermo(_schermi_grezzi()[0])


@funzione_libreria("risoluzione_schermo")
def risoluzione_schermo(schermo=None):
    """risoluzione_schermo(schermo = nulla): larghezza e altezza in pixel dello schermo (predefinito: il principale).

    Restituisce un dizionario con "larghezza" e "altezza". Solo su Windows.
    Esempio: `r = risoluzione_schermo()` e poi `stampa(r["larghezza"], "x", r["altezza"])`.
    """
    _schermo_controllato(schermo, "risoluzione_schermo")
    solo_windows("risoluzione_schermo")
    s = _schermo(schermo, "risoluzione_schermo")
    return {"larghezza": int(s["larghezza"]), "altezza": int(s["altezza"])}


@funzione_libreria("scala_schermo")
def scala_schermo(schermo=None):
    """scala_schermo(schermo = nulla): la scala di Windows in percentuale (100, 125, 150...) dello schermo.

    È l'impostazione "Ridimensiona" di Impostazioni > Schermo. Solo su Windows.
    Esempio: `stampa("Scala:", scala_schermo(), "%")`.
    """
    _schermo_controllato(schermo, "scala_schermo")
    solo_windows("scala_schermo")
    return dk.scala_da_dpi(_schermo(schermo, "scala_schermo").get("dpi"))


@funzione_libreria("area_di_lavoro")
def area_di_lavoro(schermo=None):
    """area_di_lavoro(schermo = nulla): la parte dello schermo libera dalla barra delle applicazioni.

    Restituisce un dizionario con "x", "y", "larghezza" e "altezza". Solo su Windows.
    Esempio: `a = area_di_lavoro()` e poi `sposta_finestra("Blocco note", a["x"], a["y"])`.
    """
    _schermo_controllato(schermo, "area_di_lavoro")
    solo_windows("area_di_lavoro")
    return dk.componi_schermo(_schermo(schermo, "area_di_lavoro"))["area_di_lavoro"]


@funzione_libreria("frequenza_schermo")
def frequenza_schermo(schermo=None):
    """frequenza_schermo(schermo = nulla): quante volte al secondo si aggiorna lo schermo (Hz, per esempio 60 o 144).

    0 se Windows non lo sa. Solo su Windows. Esempio: `stampa(frequenza_schermo(), "Hz")`.
    """
    _schermo_controllato(schermo, "frequenza_schermo")
    solo_windows("frequenza_schermo")
    return int(_schermo(schermo, "frequenza_schermo").get("frequenza") or 0)


# ===========================================================================
# Cattura dello schermo
# ===========================================================================

def _controlla_zona(larghezza: int, altezza: int, funzione: str) -> None:
    if larghezza > LATO_MASSIMO or altezza > LATO_MASSIMO or larghezza * altezza > PIXEL_MASSIMI:
        raise ErroreValore(f"La zona di `{funzione}` è troppo grande ({larghezza} x {altezza} pixel).")


@funzione_libreria("cattura_schermo")
def cattura_schermo(percorso=None, schermo=None):
    """cattura_schermo(percorso = nulla, schermo = nulla): salva un'immagine PNG di quello che si vede.

    Senza `schermo` cattura tutti gli schermi insieme; con `schermo = 1` solo il principale, ecc.
    Senza `percorso` il nome è "cattura_AAAAMMGG_HHMMSS.png" nella cartella corrente.
    Restituisce il percorso completo del file. Solo su Windows.
    Esempio: `stampa("Salvata in", cattura_schermo("desktop.png"))`.
    """
    file = _percorso_png(percorso, "cattura_schermo")
    _schermo_controllato(schermo, "cattura_schermo")
    solo_windows("cattura_schermo")
    if schermo is None:
        x, y, larghezza, altezza = dk.area_totale(_schermi_grezzi())
    else:
        s = _schermo(schermo, "cattura_schermo")
        x, y, larghezza, altezza = s["x"], s["y"], s["larghezza"], s["altezza"]
    if larghezza <= 0 or altezza <= 0:
        raise ErroreSistema("Windows non ha indicato le misure dello schermo.")
    _controlla_zona(larghezza, altezza, "cattura_schermo")
    return _salva(file, larghezza, altezza, _n().cattura(x, y, larghezza, altezza))


@funzione_libreria("cattura_zona")
def cattura_zona(x, y, larghezza, altezza, percorso=None):
    """cattura_zona(x, y, larghezza, altezza, percorso = nulla): salva in PNG un rettangolo dello schermo.

    Le coordinate sono in pixel del desktop. Restituisce il percorso completo del file. Solo su Windows.
    Esempio: `cattura_zona(0, 0, 400, 300, "angolo.png")`.
    """
    nx = _coordinata(x, "cattura_zona", "x")
    ny = _coordinata(y, "cattura_zona", "y")
    nl = _misura(larghezza, "cattura_zona", "larghezza", LATO_MASSIMO)
    na = _misura(altezza, "cattura_zona", "altezza", LATO_MASSIMO)
    _controlla_zona(nl, na, "cattura_zona")
    file = _percorso_png(percorso, "cattura_zona")
    solo_windows("cattura_zona")
    return _salva(file, nl, na, _n().cattura(nx, ny, nl, na))


@funzione_libreria("cattura_finestra")
def cattura_finestra(finestra, percorso=None):
    """cattura_finestra(finestra, percorso = nulla): salva in PNG l'immagine di una finestra.

    Funziona anche se la finestra è coperta da altre (non se è minimizzata: prima la si ripristina).
    Restituisce il percorso completo del file. Solo su Windows.
    Esempio: `cattura_finestra("Calcolatrice", "calcolatrice.png")`.
    """
    file = _percorso_png(percorso, "cattura_finestra")
    solo_windows("cattura_finestra")
    grezza = _risolvi(finestra, "cattura_finestra")
    if grezza.get("minimizzata"):
        raise ErroreValore(f"La finestra `{grezza['titolo']}` è minimizzata: non c'è niente da catturare.",
                           suggerimento="Prima usa `ripristina_finestra(...)`.")
    immagine = _n().cattura_finestra(grezza["id"])
    if immagine is None:  # ripiego: la zona dello schermo dove si trova
        larghezza, altezza = int(grezza["larghezza"]), int(grezza["altezza"])
        if larghezza <= 0 or altezza <= 0:
            raise ErroreValore(f"La finestra `{grezza['titolo']}` non ha una parte visibile da catturare.")
        _controlla_zona(larghezza, altezza, "cattura_finestra")
        immagine = (larghezza, altezza, _n().cattura(grezza["x"], grezza["y"], larghezza, altezza))
    return _salva(file, *immagine)


@funzione_libreria("colore_punto")
def colore_punto(x, y):
    """colore_punto(x, y): il colore del punto (x, y) dello schermo, come "#RRGGBB" (lo stesso formato di `rgb`).

    Solo su Windows. Esempio: `stampa("In alto a sinistra c'è", colore_punto(0, 0))`.
    """
    nx = _coordinata(x, "colore_punto", "x")
    ny = _coordinata(y, "colore_punto", "y")
    solo_windows("colore_punto")
    colore = _n().colore_pixel(nx, ny)
    if colore is None:
        raise ErroreValore(f"Il punto ({nx}, {ny}) è fuori dagli schermi.",
                           suggerimento="Guarda `elenca_schermi()` per le coordinate valide.")
    return dk.esadecimale(*colore)


# ===========================================================================
# Notifiche
# ===========================================================================

def _icona(icona: Any, funzione: str, tipi: tuple[str, ...], file_ammessi: bool) -> tuple[str, str | None]:
    """(tipo, percorso immagine o None) dall'argomento `icona`."""
    if icona is None:
        return "nessuna", None
    richiedi_testo(icona, funzione, "icona")
    chiave = icona.strip().lower()
    if chiave in tipi:
        return chiave, None
    if file_ammessi and os.path.splitext(chiave)[1] in ESTENSIONI_ICONA:
        if "\0" in icona or not os.path.isfile(icona):
            raise ErroreFile(f"L'immagine dell'icona `{icona}` non esiste.")
        return "info", os.path.abspath(icona)
    altro = " oppure il percorso di un'immagine PNG/JPG/ICO" if file_ammessi else ""
    raise ErroreValore(f"`{icona}` non è un'icona valida per `{funzione}`.",
                       suggerimento="Icone: " + ", ".join(f'"{t}"' for t in tipi) + altro + ".")


@funzione_libreria("mostra_notifica")
def mostra_notifica(titolo, testo="", icona="info"):
    """mostra_notifica(titolo, testo = "", icona = "info"): mostra una notifica di Windows in basso a destra.

    `icona` può essere "info", "avviso", "errore", "nessuna" o il percorso di un'immagine.
    Usa le notifiche di Windows 10/11; se non vanno, il fumetto dell'area di notifica.
    Restituisce "notifica" o "fumetto" (quale è stato usato). Solo su Windows.
    Esempio: `mostra_notifica("Backup finito", "Copiati 120 file")`.
    """
    _testo_pieno(titolo, "mostra_notifica", "titolo", 'mostra_notifica("Fatto!")')
    _testo_breve(titolo, "mostra_notifica", "titolo", 200)
    _testo_breve(testo, "mostra_notifica", "testo", 2000)
    tipo, immagine = _icona(icona, "mostra_notifica", ("info", "avviso", "errore", "nessuna"), True)
    solo_windows("mostra_notifica")
    try:
        _uscita, _errori, codice = _n().powershell(dk.script_notifica(titolo, testo, immagine))
    except ErroreSistema:
        codice = 1
    if codice == 0:
        return "notifica"
    _n().avvia_powershell(dk.script_fumetto(titolo, testo, tipo))
    return "fumetto"


# ===========================================================================
# Finestre di dialogo
# ===========================================================================

class _DialoghiQt:  # pragma: no cover - richiede Qt vero
    """Le stesse finestre di dialogo con Qt, per i programmi Leo che hanno finestre."""

    def __init__(self, ponte: Any) -> None:
        self.ponte = ponte

    @staticmethod
    def _genitore():
        from PySide6.QtWidgets import QApplication

        return QApplication.activeWindow()

    def _fine(self) -> None:
        controlla = getattr(self.ponte, "_controlla_arresto", None)
        if callable(controlla):
            controlla()

    def messaggio(self, testo: str, titolo: str, icona: str) -> None:
        from PySide6.QtWidgets import QMessageBox

        icone = {"info": QMessageBox.Icon.Information, "avviso": QMessageBox.Icon.Warning,
                 "errore": QMessageBox.Icon.Critical, "domanda": QMessageBox.Icon.Question,
                 "nessuna": QMessageBox.Icon.NoIcon}
        box = QMessageBox(self._genitore())
        box.setIcon(icone.get(icona, QMessageBox.Icon.Information))
        box.setWindowTitle(titolo)
        box.setText(testo)
        box.addButton("OK", QMessageBox.ButtonRole.AcceptRole)
        box.exec()
        self._fine()

    def domanda(self, testo: str, titolo: str) -> bool:
        risposta = bool(self.ponte.domanda(testo, titolo))
        return risposta

    def apri(self, titolo: str, filtro: str, cartella: str | None, multipli: bool) -> list[str] | None:
        from PySide6.QtWidgets import QFileDialog

        if multipli:
            percorsi, _f = QFileDialog.getOpenFileNames(self._genitore(), titolo, cartella or "", filtro)
            self._fine()
            return list(percorsi) or None
        percorso, _f = QFileDialog.getOpenFileName(self._genitore(), titolo, cartella or "", filtro)
        self._fine()
        return [percorso] if percorso else None

    def salva(self, titolo: str, filtro: str, iniziale: str) -> str | None:
        from PySide6.QtWidgets import QFileDialog

        percorso, _f = QFileDialog.getSaveFileName(self._genitore(), titolo, iniziale, filtro)
        self._fine()
        return percorso or None

    def cartella(self, titolo: str, cartella: str | None) -> str | None:
        from PySide6.QtWidgets import QFileDialog

        percorso = QFileDialog.getExistingDirectory(self._genitore(), titolo, cartella or "")
        self._fine()
        return percorso or None

    def colore(self, iniziale: str) -> str | None:
        from PySide6.QtGui import QColor
        from PySide6.QtWidgets import QColorDialog

        scelto = QColorDialog.getColor(QColor(iniziale), self._genitore(), "Scegli un colore")
        self._fine()
        return scelto.name().upper() if scelto.isValid() else None


def _dialoghi_qt(interprete: Any) -> Any:
    """Le finestre di dialogo Qt se il programma Leo ha finestre, altrimenti None (si usano quelle native)."""
    ponte = getattr(interprete, "ponte_grafico", None)
    if ponte is None or not hasattr(ponte, "scegli_file"):
        return None
    try:  # pragma: no cover - richiede Qt vero
        from PySide6.QtWidgets import QApplication

        if QApplication.instance() is None:
            return None
    except (ImportError, AttributeError):
        return None
    return _DialoghiQt(ponte)  # pragma: no cover


ICONE_DIALOGO = ("info", "avviso", "errore", "domanda", "nessuna")


@funzione_libreria("messaggio_windows", interprete=True)
def messaggio_windows(interprete, testo, titolo="Leo", icona="info"):
    """messaggio_windows(testo, titolo = "Leo", icona = "info"): una vera finestra di messaggio di Windows con OK.

    A differenza di `messaggio`, appare come finestra anche nei programmi testuali.
    `icona`: "info", "avviso", "errore", "domanda" o "nessuna". Il programma aspetta che si prema OK.
    Solo su Windows (nei programmi con finestre usa Qt). Esempio: `messaggio_windows("Copia finita", icona = "info")`.
    """
    richiedi_testo(testo, "messaggio_windows", "testo")
    _testo_breve(testo, "messaggio_windows", "testo", 10_000)
    _testo_breve(titolo, "messaggio_windows", "titolo", 200)
    tipo, _ = _icona(icona, "messaggio_windows", ICONE_DIALOGO, False)
    qt = _dialoghi_qt(interprete)
    if qt is not None:
        qt.messaggio(testo, titolo, tipo)
        return None
    solo_windows("messaggio_windows")
    _n().messaggio(testo, titolo, dk.ICONE_MESSAGGIO[tipo])
    return None


@funzione_libreria("domanda_windows", interprete=True)
def domanda_windows(interprete, testo, titolo="Leo"):
    """domanda_windows(testo, titolo = "Leo"): una finestra di Windows con Sì e No; `vero` se si preme Sì.

    A differenza di `domanda`, appare come finestra anche nei programmi testuali.
    Solo su Windows (nei programmi con finestre usa Qt).
    Esempio: `se domanda_windows("Vuoi continuare?") allora stampa("Avanti!") fine`.
    """
    _testo_pieno(testo, "domanda_windows", "testo", 'domanda_windows("Vuoi continuare?")')
    _testo_breve(testo, "domanda_windows", "testo", 10_000)
    _testo_breve(titolo, "domanda_windows", "titolo", 200)
    qt = _dialoghi_qt(interprete)
    if qt is not None:
        return bool(qt.domanda(testo, titolo))
    solo_windows("domanda_windows")
    return _n().messaggio(testo, titolo, dk.MB_SINO | dk.ICONE_MESSAGGIO["domanda"]) == dk.IDSI


def _filtri(filtri: Any, funzione: str) -> list[tuple[str, list[str]]]:
    voci = dk.normalizza_filtri(filtri)
    if voci is None:
        raise ErroreValore(f"Non capisco i `filtri` di `{funzione}`.",
                           suggerimento='Esempi: `["png", "jpg"]`, `{"Immagini": ["png", "jpg"], "Testi": "txt"}` '
                                        'oppure `"Immagini (*.png *.jpg);;Tutti i file (*.*)"`.')
    return voci


def _titolo_dialogo(titolo: Any, funzione: str) -> str:
    _testo_breve(titolo, funzione, "titolo", 200)
    return titolo


def _scegli_da_aprire(interprete: Any, funzione: str, titolo: Any, filtri: Any, cartella: Any,
                      multipli: bool) -> list[str] | None:
    _titolo_dialogo(titolo, funzione)
    voci = _filtri(filtri, funzione)
    iniziale = _cartella_iniziale(cartella, funzione)
    qt = _dialoghi_qt(interprete)
    if qt is not None:
        return qt.apri(titolo, dk.filtri_qt(voci, _win.e_windows()), iniziale, multipli)
    solo_windows(funzione)
    return _n().apri_file(titolo, dk.filtri_windows(voci), iniziale, multipli)


@funzione_libreria("scegli_file_da_aprire", interprete=True)
def scegli_file_da_aprire(interprete, titolo="Apri un file", filtri=None, cartella=None):
    """scegli_file_da_aprire(titolo = "Apri un file", filtri = nulla, cartella = nulla): la finestra "Apri" di Windows.

    Restituisce il percorso del file scelto, oppure `nulla` se l'utente annulla. `filtri` limita i tipi
    di file: `["png", "jpg"]`, `{"Immagini": ["png", "jpg"], "Testi": "txt"}` o `"Testi (*.txt)"`.
    Solo su Windows (nei programmi con finestre usa Qt).
    Esempio: `f = scegli_file_da_aprire("Scegli una foto", ["jpg", "png"])`.
    """
    scelti = _scegli_da_aprire(interprete, "scegli_file_da_aprire", titolo, filtri, cartella, False)
    return scelti[0] if scelti else None


@funzione_libreria("scegli_piu_file", interprete=True)
def scegli_piu_file(interprete, titolo="Scegli i file", filtri=None, cartella=None):
    """scegli_piu_file(titolo = "Scegli i file", filtri = nulla, cartella = nulla): la finestra "Apri" con più file.

    Si selezionano più file con Ctrl o Maiusc. Restituisce la lista dei percorsi (vuota se l'utente
    annulla). `filtri` come in `scegli_file_da_aprire`. Solo su Windows (nei programmi con finestre usa Qt).
    Esempio: `per ogni f in scegli_piu_file(filtri = ["txt"]) fai stampa(f) fine`.
    """
    return list(_scegli_da_aprire(interprete, "scegli_piu_file", titolo, filtri, cartella, True) or [])


@funzione_libreria("scegli_file_da_salvare", interprete=True)
def scegli_file_da_salvare(interprete, titolo="Salva con nome", filtri=None, cartella=None, nome=""):
    """scegli_file_da_salvare(titolo = "Salva con nome", filtri = nulla, cartella = nulla, nome = ""): la finestra "Salva con nome".

    `nome` è il nome proposto; se l'utente non scrive l'estensione si aggiunge quella del primo filtro.
    Se il file esiste Windows chiede se sostituirlo. Restituisce il percorso scelto (il file NON viene
    creato) oppure `nulla` se l'utente annulla. Solo su Windows (nei programmi con finestre usa Qt).
    Esempio: `p = scegli_file_da_salvare(filtri = ["txt"], nome = "note.txt")`.
    """
    funzione = "scegli_file_da_salvare"
    _titolo_dialogo(titolo, funzione)
    voci = _filtri(filtri, funzione)
    iniziale = _cartella_iniziale(cartella, funzione)
    _testo_breve(nome, funzione, "nome", 250)
    if any(c in nome for c in '<>:"/\\|?*'):
        raise ErroreValore(f"Il nome proposto `{nome}` contiene caratteri che Windows non accetta nei nomi dei file.",
                           suggerimento='Togli i caratteri < > : " / \\ | ? * (la cartella va in `cartella`).')
    qt = _dialoghi_qt(interprete)
    if qt is not None:
        percorso_iniziale = os.path.join(iniziale, nome) if iniziale and nome else (nome or iniziale or "")
        return qt.salva(titolo, dk.filtri_qt(voci, _win.e_windows()), percorso_iniziale)
    solo_windows(funzione)
    return _n().salva_file(titolo, dk.filtri_windows(voci), iniziale, nome, dk.estensione_predefinita(voci))


@funzione_libreria("scegli_cartella", interprete=True)
def scegli_cartella(interprete, titolo="Scegli una cartella", cartella=None):
    """scegli_cartella(titolo = "Scegli una cartella", cartella = nulla): la finestra di Windows per scegliere una cartella.

    Restituisce il percorso della cartella, oppure `nulla` se l'utente annulla. `cartella` è quella
    proposta all'inizio. Solo su Windows (nei programmi con finestre usa Qt).
    Esempio: `c = scegli_cartella("Dove salvo le foto?")`.
    """
    _titolo_dialogo(titolo, "scegli_cartella")
    iniziale = _cartella_iniziale(cartella, "scegli_cartella")
    qt = _dialoghi_qt(interprete)
    if qt is not None:
        return qt.cartella(titolo, iniziale)
    solo_windows("scegli_cartella")
    return _n().scegli_cartella(titolo, iniziale)


@funzione_libreria("chiedi_colore", interprete=True)
def chiedi_colore(interprete, iniziale="#FFFFFF"):
    """chiedi_colore(iniziale = "#FFFFFF"): la finestra dei colori di Windows; restituisce il colore scelto come "#RRGGBB".

    Restituisce `nulla` se l'utente annulla. Il risultato si usa dovunque serva un colore (come `rgb`).
    Solo su Windows (nei programmi con finestre usa Qt).
    Esempio: `c = chiedi_colore("#FF8800")` e poi `se c != nulla allora Finestra1.sfondo = c fine`.
    """
    richiedi_testo(iniziale, "chiedi_colore", "iniziale")
    rgb = dk.leggi_colore(iniziale)
    if rgb is None:
        raise ErroreValore(f"`{iniziale}` non è un colore.",
                           suggerimento='Scrivi il colore come "#RRGGBB", per esempio "#FF8800", oppure usa `rgb(...)`.')
    qt = _dialoghi_qt(interprete)
    if qt is not None:
        return qt.colore(dk.esadecimale(*rgb))
    solo_windows("chiedi_colore")
    scelto = _n().scegli_colore(rgb)
    return dk.esadecimale(*scelto) if scelto is not None else None


# ===========================================================================
# Sfondo, tema, colore d'accento, suoni
# ===========================================================================

@funzione_libreria("sfondo_desktop")
def sfondo_desktop():
    """sfondo_desktop(): il percorso dell'immagine di sfondo del desktop ("" se lo sfondo è un colore).

    Solo su Windows. Esempio: `stampa("Sfondo attuale:", sfondo_desktop())`.
    """
    solo_windows("sfondo_desktop")
    return str(_n().leggi_sfondo() or "")


@funzione_libreria("imposta_sfondo_desktop")
def imposta_sfondo_desktop(percorso, stile=None):
    """imposta_sfondo_desktop(percorso, stile = nulla): mette un'immagine come sfondo del desktop.

    `stile`: "riempi", "adatta", "estendi", "affianca", "centra" o "estendi_su_schermi"
    (`nulla` = lascia quello attuale). Restituisce il percorso dello sfondo di prima, così si può
    rimettere. Solo su Windows.
    Esempio: `vecchio = imposta_sfondo_desktop("C:/Immagini/mare.jpg", "riempi")`.
    """
    _testo_pieno(percorso, "imposta_sfondo_desktop", "percorso", 'imposta_sfondo_desktop("C:/Immagini/mare.jpg")')
    if stile is not None:
        richiedi_testo(stile, "imposta_sfondo_desktop", "stile")
        if stile.strip().lower() not in dk.STILI_SFONDO:
            raise ErroreValore(f"`{stile}` non è uno stile dello sfondo.",
                               suggerimento="Stili: " + ", ".join(f'"{s}"' for s in dk.STILI_SFONDO) + ".")
    if not os.path.isfile(percorso):
        raise ErroreFile(f"L'immagine `{percorso}` non esiste.",
                         suggerimento=f"Controlla il nome e la cartella: ora sei in `{os.getcwd()}`.")
    if os.path.splitext(percorso)[1].lower() not in ESTENSIONI_SFONDO:
        raise ErroreValore(f"`{os.path.basename(percorso)}` non sembra un'immagine adatta allo sfondo.",
                           suggerimento="Usa un file JPG, PNG o BMP.")
    solo_windows("imposta_sfondo_desktop")
    precedente = str(_n().leggi_sfondo() or "")
    _n().imposta_sfondo(os.path.abspath(percorso), dk.STILI_SFONDO[stile.strip().lower()] if stile else None)
    return precedente


@funzione_libreria("tema_windows")
def tema_windows(parte="app"):
    """tema_windows(parte = "app"): "chiaro" o "scuro", il tema scelto in Impostazioni > Personalizzazione > Colori.

    `parte = "app"` è il tema delle applicazioni, `parte = "sistema"` quello della barra e del menu Start.
    Solo su Windows. Esempio: `se tema_windows() == "scuro" allora Finestra1.sfondo = "#202020" fine`.
    """
    richiedi_testo(parte, "tema_windows", "parte")
    nomi = {"app": "AppsUseLightTheme", "applicazioni": "AppsUseLightTheme", "sistema": "SystemUsesLightTheme"}
    chiave = parte.strip().lower()
    if chiave not in nomi:
        raise ErroreValore(f"`{parte}` non è una parte del tema.", suggerimento='Usa "app" oppure "sistema".')
    solo_windows("tema_windows")
    valore = _n().valore_utente(dk.CHIAVE_TEMA, nomi[chiave])
    return "scuro" if valore == 0 else "chiaro"


@funzione_libreria("tema_scuro_attivo")
def tema_scuro_attivo():
    """tema_scuro_attivo(): `vero` se le applicazioni di Windows usano il tema scuro.

    Solo su Windows. Esempio: `se tema_scuro_attivo() allora stampa("Modalità scura") fine`.
    """
    solo_windows("tema_scuro_attivo")
    return tema_windows("app") == "scuro"


@funzione_libreria("colore_accento")
def colore_accento():
    """colore_accento(): il colore d'accento di Windows come "#RRGGBB", oppure `nulla` se Windows non lo dice.

    Solo su Windows. Esempio: `Pulsante1.sfondo = colore_accento()` (per un programma intonato a Windows).
    """
    solo_windows("colore_accento")

    def dword(v: Any) -> int | None:
        return v & 0xFFFFFFFF if isinstance(v, int) and not isinstance(v, bool) else None

    rgb = dk.colore_accento_da_dwm(dword(_n().valore_utente(dk.CHIAVE_DWM, "AccentColor")),
                                   dword(_n().valore_utente(dk.CHIAVE_DWM, "ColorizationColor")))
    return dk.esadecimale(*rgb) if rgb is not None else None


@funzione_libreria("suono_di_sistema")
def suono_di_sistema(tipo="predefinito"):
    """suono_di_sistema(tipo = "predefinito"): fa sentire un suono di avviso di Windows.

    Tipi: "predefinito", "informazione", "avviso", "errore", "domanda", "bip", "notifica", "posta",
    "promemoria" (vedi `suoni_di_sistema()`). I suoni sono quelli scelti nel Pannello di controllo;
    il programma non aspetta la fine. Solo su Windows. Esempio: `suono_di_sistema("errore")`.
    """
    richiedi_testo(tipo, "suono_di_sistema", "tipo")
    chiave = tipo.strip().lower()
    if chiave not in dk.SUONI_DI_SISTEMA:
        raise ErroreValore(f"`{tipo}` non è un suono di sistema.",
                           suggerimento="Suoni: " + ", ".join(f'"{s}"' for s in dk.SUONI_DI_SISTEMA) + ".")
    solo_windows("suono_di_sistema")
    _n().suono(dk.SUONI_DI_SISTEMA[chiave])
    return None


@funzione_libreria("suoni_di_sistema")
def suoni_di_sistema():
    """suoni_di_sistema(): i nomi dei suoni di avviso che si possono usare con `suono_di_sistema`.

    Funziona su ogni sistema. Esempio: `per ogni s in suoni_di_sistema() fai stampa(s) fine`.
    """
    return list(dk.SUONI_DI_SISTEMA)
