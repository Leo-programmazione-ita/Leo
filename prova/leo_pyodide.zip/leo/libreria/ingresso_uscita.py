"""Libreria: stampa, chiedi, leggi_file, scrivi_file.

``stampa`` e ``chiedi`` passano dall'interprete (``interprete.scrivi`` e
``interprete.leggi``), così il REPL, i test e Leo Studio possono
catturare l'uscita e simulare l'ingresso. I file si scrivono in UTF-8 e si
leggono in UTF-8 (con o senza BOM), UTF-16 con BOM (Blocco note "Unicode",
PowerShell 5) oppure, se non sono UTF-8, nella codifica classica di Windows
(cp1252, "ANSI": per esempio i CSV salvati da Excel). I percorsi relativi
partono dalla cartella corrente; spazi e lettere accentate vanno bene.
"""

from __future__ import annotations

import errno
import os
import re
from typing import Any

from ..errori import ErroreFile, ErroreTipo, ErroreValore
from ..valori import rappresenta
from .generali import articolo, funzione_libreria, mostra, richiedi_testo


@funzione_libreria("stampa", interprete=True)
def stampa(interprete, *valori, separatore=" "):
    """stampa(valori..., separatore = " "): scrive i valori sullo schermo e va a capo.

    I valori sono separati da uno spazio, oppure dal testo `separatore`.
    Esempi: `stampa("Ciao", nome)`, `stampa(1, 2, 3, separatore = ", ")`.
    """
    if not isinstance(separatore, str):
        raise ErroreTipo(f"Il `separatore` di `stampa` deve essere un testo, non {articolo(separatore)}.",
                         suggerimento="Scrivi per esempio `separatore = \", \"`.")
    interprete.scrivi(separatore.join(rappresenta(v) for v in valori) + "\n")
    return None


@funzione_libreria("chiedi", interprete=True)
def chiedi(interprete, domanda=""):
    """chiedi(domanda): mostra la domanda e restituisce come testo quello che l'utente scrive.

    Per avere un numero trasforma la risposta: `intero(chiedi("Quanti anni hai? "))`.
    """
    testo = domanda if isinstance(domanda, str) else rappresenta(domanda)
    risposta = interprete.leggi(testo)
    if risposta is None:
        raise ErroreValore("Non ci sono più dati da leggere.")
    return risposta if isinstance(risposta, str) else str(risposta)


#: Caratteri che Windows non accetta nei nomi di file e cartelle.
_VIETATI_WINDOWS = '<>:"|?*'
#: Nomi riservati di Windows (anche con un'estensione: "con.txt" non è un file ma la console).
_RISERVATI_WINDOWS = re.compile(r"^(con|prn|aux|nul|com[0-9¹²³]|lpt[0-9¹²³])(\..*)?$", re.IGNORECASE)


def problema_nome_windows(percorso: str) -> str | None:
    """Perché ``percorso`` non va bene su Windows (in italiano), oppure ``None``.

    Controlla i caratteri vietati (``: * ? " < > |``, esclusa la lettera del disco
    ``C:``), i nomi riservati (``con``, ``nul``, ``com1``...) e i nomi che finiscono
    con un punto o uno spazio (Windows li toglierebbe in silenzio). Su Windows un
    ``:`` nel nome non dà errore ma scrive i dati in un "flusso nascosto": meglio
    fermarsi prima.
    """
    if percorso.startswith(("\\\\?\\", "\\\\.\\")):
        return None  # percorsi speciali di Windows: chi li usa sa cosa fa
    resto = percorso
    if len(resto) >= 2 and resto[1] == ":" and resto[0].isascii() and resto[0].isalpha():
        resto = resto[2:]
    for parte in re.split(r"[\\/]", resto):
        if parte in ("", ".", ".."):
            continue
        for c in parte:
            if c in _VIETATI_WINDOWS or ord(c) < 32:
                visibile = repr(c)[1:-1] if ord(c) < 32 else c
                return f"il nome `{parte}` contiene il carattere `{visibile}`, che Windows non accetta"
        if _RISERVATI_WINDOWS.match(parte):
            return f"`{parte.split('.')[0]}` è un nome riservato di Windows"
        if parte[-1] in ". ":
            return f"il nome `{parte}` finisce con un punto o uno spazio, che Windows toglie"
    return None


def _controlla_percorso(percorso: Any, nome_funzione: str) -> str:
    richiedi_testo(percorso, nome_funzione, "percorso")
    if not percorso.strip():
        raise ErroreValore(f"Il percorso del file per `{nome_funzione}` è vuoto.",
                           suggerimento=f"Scrivi il nome del file, per esempio `{nome_funzione}(\"dati.txt\")`.")
    if "\0" in percorso:
        raise ErroreValore(f"Il percorso {mostra(percorso)} contiene un carattere non valido.")
    if os.name == "nt":
        problema = problema_nome_windows(percorso)
        if problema:
            raise ErroreValore(f"Il percorso {mostra(percorso)} non è valido: {problema}.",
                               suggerimento="Usa lettere, numeri, spazi, `-` e `_`; "
                                            "le cartelle si separano con `/`.")
    return percorso


#: Spiegazioni in italiano degli errori del sistema operativo più comuni.
_MOTIVI = {
    errno.ENOSPC: "il disco è pieno",
    errno.EROFS: "il disco è di sola lettura",
    errno.ENAMETOOLONG: "il nome è troppo lungo",
    errno.EINVAL: "il nome contiene caratteri non ammessi",
    errno.ELOOP: "il percorso gira in tondo (collegamenti che puntano a se stessi)",
    errno.EMFILE: "ci sono troppi file aperti",
    errno.EBUSY: "il file è in uso da un altro programma",
    errno.EEXIST: "esiste già",
}


def _errore_file(errore: OSError, percorso: str, azione: str) -> ErroreFile:
    """Trasforma un errore del sistema operativo in un ``ErroreFile`` in italiano."""
    if isinstance(errore, FileNotFoundError):
        if azione == "leggere":
            return ErroreFile(f"Il file `{percorso}` non esiste.",
                              suggerimento=f"Controlla il nome e la cartella: ora sei in `{os.getcwd()}`.")
        cartella = os.path.dirname(percorso) or "."
        return ErroreFile(f"Non posso {azione} `{percorso}`: la cartella `{cartella}` non esiste.")
    if isinstance(errore, IsADirectoryError) or (isinstance(errore, PermissionError) and _e_cartella(percorso)):
        # su Windows aprire una cartella come file dà "permesso negato", non "è una cartella"
        return ErroreFile(f"`{percorso}` è una cartella, non un file.")
    if isinstance(errore, NotADirectoryError):
        return ErroreFile(f"Il percorso `{percorso}` non è valido: una delle cartelle è in realtà un file.")
    if isinstance(errore, PermissionError):
        return ErroreFile(f"Non hai il permesso di {azione} il file `{percorso}`.",
                          suggerimento="Forse il file è aperto in un altro programma o è protetto.")
    motivo = _MOTIVI.get(errore.errno or 0)
    if motivo is None and getattr(errore, "winerror", None) == 123:  # ERROR_INVALID_NAME
        motivo = _MOTIVI[errno.EINVAL]
    if motivo is None:
        return ErroreFile(f"Non posso {azione} il file `{percorso}`.",
                          suggerimento=f"Dettaglio tecnico: {errore.strerror or errore}")
    return ErroreFile(f"Non posso {azione} il file `{percorso}`: {motivo}.")


def _e_cartella(percorso: str) -> bool:
    try:
        return os.path.isdir(percorso)
    except (OSError, ValueError):  # pragma: no cover - percorso strano
        return False


def decodifica_testo(dati: bytes) -> str | None:
    """Il testo contenuto nei byte di un file, oppure ``None`` se non è un file di testo.

    Ordine: BOM UTF-8 / UTF-16 / UTF-32, poi UTF-8, poi cp1252 (l'"ANSI" di Windows
    in italiano) se non ci sono byte nulli (che indicano un file binario).
    Gli "a capo" di Windows (``\\r\\n``) e dei vecchi Mac (``\\r``) diventano ``\\n``.
    """
    if dati.startswith(b"\xef\xbb\xbf"):
        codifiche: tuple[str, ...] = ("utf-8-sig",)
    elif dati.startswith((b"\xff\xfe\x00\x00", b"\x00\x00\xfe\xff")):
        codifiche = ("utf-32",)
    elif dati.startswith((b"\xff\xfe", b"\xfe\xff")):
        codifiche = ("utf-16",)
    elif b"\x00" in dati:
        return None
    else:
        codifiche = ("utf-8", "cp1252")
    for codifica in codifiche:
        try:
            testo = dati.decode(codifica)
        except UnicodeDecodeError:
            continue
        if "\r" in testo:
            testo = testo.replace("\r\n", "\n").replace("\r", "\n")
        return testo
    return None


def leggi_testo(percorso: str) -> str:
    """Contenuto di un file di testo (percorso già controllato), con errori in italiano."""
    try:
        with open(percorso, "rb") as f:
            dati = f.read()
    except OSError as e:
        raise _errore_file(e, percorso, "leggere") from None
    except ValueError:
        raise ErroreFile(f"Il percorso `{percorso}` non è valido.") from None
    testo = decodifica_testo(dati)
    if testo is None:
        raise ErroreFile(f"Il file `{percorso}` non è un file di testo (né UTF-8 né ANSI): "
                         f"forse è un'immagine, un PDF o un documento di Word.",
                         suggerimento="Aprilo con il suo programma e salvalo come testo, scegliendo la codifica UTF-8.")
    return testo


@funzione_libreria("leggi_file")
def leggi_file(percorso):
    """leggi_file(percorso): restituisce tutto il contenuto di un file di testo.

    Legge i file UTF-8 e anche quelli salvati con la codifica classica di Windows. Esempio: `variabile righe = leggi_file("voti.txt").dividi("\\n")`.
    """
    _controlla_percorso(percorso, "leggi_file")
    return leggi_testo(percorso)


@funzione_libreria("scrivi_file")
def scrivi_file(percorso, testo):
    """scrivi_file(percorso, testo): scrive il testo nel file (UTF-8), sostituendo il contenuto precedente.

    Esempio: `scrivi_file("saluto.txt", "Ciao!")`.
    """
    _controlla_percorso(percorso, "scrivi_file")
    if not isinstance(testo, str):
        raise ErroreTipo(f"Il `testo` di `scrivi_file` deve essere un testo, non {articolo(testo)}.",
                         suggerimento=f"Trasformalo prima: `scrivi_file(percorso, testo({mostra(testo)}))`.")
    try:
        with open(percorso, "w", encoding="utf-8") as f:
            f.write(testo)
    except OSError as e:
        raise _errore_file(e, percorso, "scrivere") from None
    except ValueError:
        raise ErroreFile(f"Il percorso `{percorso}` non è valido.") from None
    return None
