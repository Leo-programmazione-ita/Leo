"""Libreria: gli stili degli oggetti delle finestre (la proprietà ``stile`` di ogni controllo).

Funzioni::

    stili_oggetti()              # ["Moderno", "Pillola", "3D", "Neon", "Vetro", ...]
    descrizione_stile(nome)      # "Contorni che brillano come le insegne di notte"

Uno stile si sceglie con una riga: ``Pulsante1.stile = "Neon"`` (maiuscole, accenti e spazi non
contano: vanno bene anche ``"neon"``, ``"8 bit"``, ``"scuro elegante"``); ``Finestra1.stile = "Gioco"``
lo dà a tutti gli oggetti della finestra che non ne hanno uno loro; ``"normale"`` torna come la
finestra. Il catalogo è :mod:`leo.grafica.stili_oggetti`, lo stesso per il PC e il telefono.
"""

from __future__ import annotations

from ..errori import ErroreTipo
from ..grafica import stili_oggetti as so
from .generali import funzione_libreria


@funzione_libreria("stili_oggetti")
def stili_oggetti():
    """stili_oggetti(): la lista dei nomi degli stili degli oggetti.

    Esempio: `per ogni s in stili_oggetti() fai stampa(s) fine`; poi `Pulsante1.stile = "Neon"`.
    """
    return so.elenco_stili()


@funzione_libreria("descrizione_stile")
def descrizione_stile(nome):
    """descrizione_stile(nome): com'è fatto uno stile, in una riga.

    Esempio: `stampa(descrizione_stile("Cartone"))`.
    """
    if not isinstance(nome, str):
        raise ErroreTipo("`descrizione_stile` vuole il nome di uno stile, come \"Neon\".",
                         suggerimento="Gli stili sono in `stili_oggetti()`.")
    return so.stile_oggetto(nome).descrizione
