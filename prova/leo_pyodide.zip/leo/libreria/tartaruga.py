"""Libreria: la tartaruga che disegna (avanti, destra, colore, cerchio, ...).

Ogni programma ha la sua tartaruga (creata al primo comando, vedi
``leo.tartaruga.tartaruga_di``). Il disegno si vede a fine programma: in
una finestra animata se c'è PySide6, altrimenti viene salvato in un file SVG
(``casa.leo`` -> ``casa.svg``) da aprire con il browser. La riga di
comando chiama ``leo.tartaruga.concludi_programma`` quando il programma
finisce.

Esempio::

    colore("rosso")
    ripeti 4 volte
        avanti(100)
        destra(90)
    fine
"""

from __future__ import annotations

import os
import threading
from typing import Any

from ..errori import ErroreFile, ErroreValore
from .. import tartaruga as logica
from .generali import funzione_libreria, richiedi_testo


def _t(interprete: Any) -> logica.Tartaruga:
    return logica.tartaruga_di(interprete)


def _esegui(azione, *argomenti):
    """Chiama la logica pura trasformando i suoi errori in ``ErroreValore`` gentili."""
    try:
        return azione(*argomenti)
    except logica.ErroreTartaruga as e:
        raise ErroreValore(e.messaggio, suggerimento=e.suggerimento) from None


# ---------------------------------------------------------------------------
# Movimento
# ---------------------------------------------------------------------------

@funzione_libreria("avanti", interprete=True)
def avanti(interprete, passi=100):
    """avanti(passi = 100): la tartaruga cammina in avanti; con la penna giù lascia una riga.

    Esempio: `avanti(100)`.
    """
    _esegui(_t(interprete).avanti, passi)


@funzione_libreria("indietro", interprete=True)
def indietro(interprete, passi=100):
    """indietro(passi = 100): la tartaruga cammina all'indietro, senza girarsi.

    Esempio: `indietro(50)`.
    """
    _esegui(_t(interprete).indietro, passi)


@funzione_libreria("destra", interprete=True)
def destra(interprete, gradi=90):
    """destra(gradi = 90): la tartaruga gira verso destra (90 = un angolo retto).

    Esempio: `destra(90)`; un giro completo è `destra(360)`.
    """
    _esegui(_t(interprete).destra, gradi)


@funzione_libreria("sinistra", interprete=True)
def sinistra(interprete, gradi=90):
    """sinistra(gradi = 90): la tartaruga gira verso sinistra.

    Esempio: `sinistra(45)`.
    """
    _esegui(_t(interprete).sinistra, gradi)


@funzione_libreria("punta_verso", interprete=True)
def punta_verso(interprete, gradi):
    """punta_verso(gradi): fa guardare la tartaruga in una direzione (0 = destra, 90 = su).

    Esempio: `punta_verso(0)`.
    """
    _esegui(_t(interprete).punta_verso, gradi)


@funzione_libreria("vai_a", interprete=True)
def vai_a(interprete, x, y):
    """vai_a(x, y): la tartaruga va dritta al punto (x, y); il centro è (0, 0).

    Con la penna giù disegna la riga. Esempio: `vai_a(-100, 50)`.
    """
    _esegui(_t(interprete).vai_a, x, y)


@funzione_libreria("casa", interprete=True)
def casa(interprete):
    """casa(): la tartaruga torna al centro guardando in alto, senza disegnare.

    Esempio: `casa()`.
    """
    _esegui(_t(interprete).casa)


@funzione_libreria("cerchio", interprete=True)
def cerchio(interprete, raggio=50, gradi=360):
    """cerchio(raggio = 50, gradi = 360): disegna un cerchio (il centro è alla sinistra della tartaruga).

    Con `gradi` minore di 360 disegna solo un arco. Esempi: `cerchio(80)`, `cerchio(50, 180)`.
    """
    _esegui(_t(interprete).cerchio, raggio, gradi)


@funzione_libreria("posizione", interprete=True)
def posizione(interprete):
    """posizione(): dove si trova la tartaruga, come lista [x, y].

    Esempio: `stampa(posizione())`.
    """
    t = _t(interprete)
    return [_numero(t.x), _numero(t.y)]


@funzione_libreria("direzione", interprete=True)
def direzione(interprete):
    """direzione(): verso dove guarda la tartaruga, in gradi (0 = destra, 90 = su).

    Esempio: `stampa(direzione())`.
    """
    return _numero(_t(interprete).direzione)


def _numero(v: float) -> int | float:
    return int(v) if float(v).is_integer() else round(v, 6)


# ---------------------------------------------------------------------------
# Penna e colori
# ---------------------------------------------------------------------------

@funzione_libreria("penna_su", interprete=True)
def penna_su(interprete):
    """penna_su(): alza la penna; la tartaruga cammina senza disegnare.

    Esempio: `penna_su()` poi `avanti(50)` poi `penna_giu()`.
    """
    _t(interprete).penna_su()


@funzione_libreria("penna_giu", interprete=True)
def penna_giu(interprete):
    """penna_giu(): abbassa la penna; da ora la tartaruga disegna mentre cammina.

    Si può scrivere anche `penna_giù()`.
    """
    _t(interprete).penna_giu_()


@funzione_libreria("penna_giù", interprete=True)
def penna_giu_accentata(interprete):
    """penna_giù(): come `penna_giu()`: abbassa la penna per disegnare."""
    _t(interprete).penna_giu_()


@funzione_libreria("colore", interprete=True)
def colore(interprete, nome):
    """colore(nome): cambia il colore della penna; restituisce il colore come "#RRGGBB".

    Nomi italiani ("rosso", "verde chiaro"...), "#FF8800", [255, 128, 0], "casuale",
    oppure un numero: 0, 1, 2... sono i colori dell'arcobaleno. Esempio: `colore("blu")`.
    """
    return _esegui(_t(interprete).imposta_colore, nome)


@funzione_libreria("colore_casuale", interprete=True)
def colore_casuale(interprete):
    """colore_casuale(): sceglie per la penna un colore a caso dell'arcobaleno.

    Esempio: `colore_casuale()`.
    """
    return _esegui(_t(interprete).imposta_colore, "casuale")


@funzione_libreria("spessore", interprete=True)
def spessore(interprete, quanto):
    """spessore(quanto): quanto è grossa la riga (1 = sottile, 10 = grossa).

    Esempio: `spessore(5)`.
    """
    _esegui(_t(interprete).imposta_spessore, quanto)


@funzione_libreria("sfondo", interprete=True)
def sfondo(interprete, colore):
    """sfondo(colore): cambia il colore del foglio.

    Esempio: `sfondo("azzurro")`.
    """
    _esegui(_t(interprete).imposta_sfondo, colore)


@funzione_libreria("riempi", interprete=True)
def riempi(interprete, colore=None):
    """riempi(colore): da qui la tartaruga colora l'interno della figura che disegna.

    La figura si chiude e si colora con `fine_riempi()`. Esempio:
    `riempi("giallo")`, poi
    `ripeti 4 volte
    avanti(80)
    destra(90)
fine`, poi `fine_riempi()`.
    """
    _esegui(_t(interprete).inizia_riempimento, colore)


@funzione_libreria("fine_riempi", interprete=True)
def fine_riempi(interprete):
    """fine_riempi(): chiude e colora la figura cominciata con `riempi`.

    Restituisce `vero` se ha colorato qualcosa.
    """
    return _esegui(_t(interprete).finisci_riempimento)


@funzione_libreria("velocità", interprete=True)
def velocita(interprete, quanto):
    """velocità(quanto): quanto corre la tartaruga nella finestra: 1 lenta, 10 velocissima, 0 subito.

    Esempio: `velocità(8)`. Si può scrivere anche `velocita(8)`.
    """
    _esegui(_t(interprete).imposta_velocita, quanto)


@funzione_libreria("velocita", interprete=True)
def velocita_senza_accento(interprete, quanto):
    """velocita(quanto): come `velocità(quanto)`."""
    _esegui(_t(interprete).imposta_velocita, quanto)


# ---------------------------------------------------------------------------
# Scritte, tartaruga, disegno
# ---------------------------------------------------------------------------

@funzione_libreria("scrivi_qui", interprete=True)
def scrivi_qui(interprete, testo, dimensione=16):
    """scrivi_qui(testo, dimensione = 16): scrive un testo sul foglio, dove si trova la tartaruga.

    Esempio: `scrivi_qui("Ciao!", 24)`.
    """
    from ..valori import rappresenta

    parole = testo if isinstance(testo, str) else rappresenta(testo)
    _esegui(_t(interprete).scrivi_qui, parole, dimensione)


@funzione_libreria("nascondi_tartaruga", interprete=True)
def nascondi_tartaruga(interprete):
    """nascondi_tartaruga(): la tartaruga diventa invisibile (il disegno resta).

    Esempio: `nascondi_tartaruga()` alla fine, per un disegno pulito.
    """
    _t(interprete).visibile = False


@funzione_libreria("mostra_tartaruga", interprete=True)
def mostra_tartaruga(interprete):
    """mostra_tartaruga(): fa vedere di nuovo la tartaruga."""
    _t(interprete).visibile = True


@funzione_libreria("pulisci_disegno", interprete=True)
def pulisci_disegno(interprete):
    """pulisci_disegno(): cancella tutto il disegno (la tartaruga resta dov'è)."""
    _t(interprete).pulisci()


@funzione_libreria("salva_disegno", interprete=True)
def salva_disegno(interprete, percorso="disegno.svg"):
    """salva_disegno(percorso = "disegno.svg"): salva il disegno in un'immagine SVG da aprire nel browser.

    Esempio: `salva_disegno("casa.svg")`.
    """
    richiedi_testo(percorso, "salva_disegno", "percorso")
    nome = percorso.strip()
    if not nome or "\0" in nome:
        raise ErroreValore("Il nome del file per `salva_disegno` non è valido.",
                           suggerimento="Scrivi per esempio `salva_disegno(\"casa.svg\")`.")
    if not nome.lower().endswith(".svg"):
        nome += ".svg"
    t = _t(interprete)
    if t.colore_riempimento is not None:
        _esegui(t.finisci_riempimento)
    try:
        t.salva_svg(nome)
    except (OSError, ValueError) as e:
        motivo = getattr(e, "strerror", None) or str(e)
        raise ErroreFile(f"Non riesco a salvare il disegno in `{nome}`: {motivo}.",
                         suggerimento="Controlla il nome del file e che la cartella esista.") from None
    interprete.scrivi(f"Disegno salvato in \"{nome}\" (si apre con il browser).\n")
    return nome


@funzione_libreria("mostra_disegno", interprete=True)
def mostra_disegno(interprete):
    """mostra_disegno(): fa vedere il disegno (finestra animata se c'è PySide6, altrimenti file SVG).

    Di solito non serve: a fine programma il disegno si vede da solo.
    """
    t = _t(interprete)
    if t.colore_riempimento is not None:
        _esegui(t.finisci_riempimento)
    if logica.modalita_finestra():
        # le finestre Qt si aprono solo nel thread principale: nel REPL subito,
        # in un programma alla fine (la riga di comando chiama concludi_programma)
        if getattr(interprete, "repl", False) and threading.current_thread() is threading.main_thread():
            if logica.mostra_finestra(t):
                return None
        t.mostra_richiesto = True
        return None
    nome = logica.nome_svg(getattr(interprete, "nome_file", None))
    if not isinstance(nome, str) or not os.path.basename(nome):
        nome = "disegno.svg"
    return salva_disegno(interprete, nome)
