"""Libreria: lunghezza, vuota, intervallo.

Questo modulo contiene anche gli **strumenti comuni della libreria** usati
dagli altri moduli di ``leo/libreria/``:

* :class:`NativaLibreria`, una ``FunzioneNativa`` con messaggi più chiari
  quando il numero o i nomi degli argomenti sono sbagliati (per i metodi non
  conta l'oggetto a sinistra del punto);
* i decoratori :func:`funzione_libreria` e :func:`metodo_libreria`, che
  registrano con ``@funzione``/``@metodo`` di ``leo.registro`` e poi
  sostituiscono la voce con una :class:`NativaLibreria`;
* le funzioni ``richiedi_*`` che controllano il tipo di un argomento e
  sollevano ``ErroreTipo`` in italiano.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any, Callable

from ..errori import ErroreTipo
from ..registro import FUNZIONI, METODI, funzione, inserisci, metodo
from ..valori import (FunzioneNativa, crea_intervallo, e_intero, e_numero, nome_tipo, rappresenta,
                      tipo_con_articolo)

# ===========================================================================
# Strumenti comuni
# ===========================================================================

def articolo(v: Any) -> str:
    """Tipo di ``v`` con l'articolo: ``un `intero```, ``una `lista```, ``dei `soldi```, ```nulla```."""
    return tipo_con_articolo(v)


def mostra(v: Any) -> str:
    """Valore come appare nei messaggi (testi tra virgolette), al massimo 40 caratteri.

    Di liste, dizionari e testi lunghi si rappresenta solo l'inizio: un messaggio
    d'errore su una lista di un milione di elementi resta immediato.
    """
    tagliato = False
    if isinstance(v, str) and len(v) > 60:
        v, tagliato = v[:60], True
    elif isinstance(v, list) and len(v) > 10:
        v, tagliato = v[:10], True
    elif isinstance(v, dict) and len(v) > 10:
        v, tagliato = dict(list(v.items())[:10]), True
    try:
        testo = rappresenta(v, dentro=True)
    except ValueError:  # intero con troppe cifre per diventare testo
        return "un numero enorme" if e_intero(v) else f"{articolo(v)} con un numero enorme"
    if len(testo) > 40 or tagliato:
        testo = testo[:37] + "..."
    return testo


_TIPI_NUMERO = frozenset((int, float))


def tipi(valori: Any) -> set:
    """L'insieme dei tipi Python degli elementi (calcolato in C: molto veloce)."""
    return set(map(type, valori))


def tutti_numeri(valori: Any) -> bool:
    """`vero` se tutti gli elementi sono interi o decimali (non logici)."""
    if tipi(valori) <= _TIPI_NUMERO:
        return True
    return all(e_numero(v) for v in valori)  # sottoclassi di int/float: rarissime


#: Oltre queste cifre la conversione testo <-> intero diventa lentissima (è quadratica).
MASSIME_CIFRE = 100_000


def intero_a_testo(n: int) -> str:
    """Le cifre di un intero, anche oltre il limite di Python (4300 cifre).

    ``ValueError`` (in italiano) oltre :data:`MASSIME_CIFRE` cifre.
    """
    try:
        return str(n)
    except ValueError:
        if n.bit_length() > MASSIME_CIFRE * 3.33:
            raise ValueError(f"il numero ha più di {MASSIME_CIFRE} cifre") from None
        return str(Decimal(n))


def testo_a_intero(cifre: str) -> int:
    """``int(cifre)`` anche oltre il limite di Python (4300 cifre).

    ``ValueError`` se il testo non è un intero o se ha più di :data:`MASSIME_CIFRE` cifre.
    """
    try:
        return int(cifre)
    except ValueError:
        if len(cifre) < 4000:
            raise
    if len(cifre) > MASSIME_CIFRE + 10:
        raise ValueError(f"il numero ha più di {MASSIME_CIFRE} cifre")
    from decimal import InvalidOperation
    try:
        valore = Decimal(cifre.strip())
    except InvalidOperation:
        raise ValueError("non è un numero intero") from None
    if not valore.is_finite() or valore != valore.to_integral_value():
        raise ValueError("non è un numero intero")
    return int(valore)


class NativaLibreria(FunzioneNativa):
    """Funzione (o metodo) della libreria standard.

    Resta per compatibilità: i messaggi precisi sugli argomenti (parametri
    esistenti, oggetto del metodo non contato) ora sono in
    :class:`leo.valori.FunzioneNativa` stessa (integrazione del nucleo).
    """

    def __init__(self, nome: str, funzione: Callable[..., Any], *,
                 vuole_interprete: bool = False, e_metodo: bool = False) -> None:
        super().__init__(nome, funzione, vuole_interprete=vuole_interprete, e_metodo=e_metodo)


def funzione_libreria(nome: str, *, interprete: bool = False) -> Callable:
    """Come ``registro.funzione``, ma registra una :class:`NativaLibreria`."""

    def decora(f: Callable) -> Callable:
        funzione(nome, interprete=interprete)(f)
        inserisci(FUNZIONI, None, nome, NativaLibreria(nome, f, vuole_interprete=interprete))
        return f

    return decora


def metodo_libreria(tipo: str, nome: str, *, interprete: bool = False) -> Callable:
    """Come ``registro.metodo``, ma registra una :class:`NativaLibreria` di tipo metodo."""

    def decora(f: Callable) -> Callable:
        metodo(tipo, nome, interprete=interprete)(f)
        inserisci(METODI.setdefault(tipo, {}), tipo, nome,
                  NativaLibreria(nome, f, vuole_interprete=interprete, e_metodo=True))
        return f

    return decora


def _errore_argomento(funzione_nome: str, parametro: str, atteso: str, valore: Any,
                      suggerimento: str | None = None) -> ErroreTipo:
    return ErroreTipo(
        f"L'argomento `{parametro}` di `{funzione_nome}` deve essere {atteso}, non {articolo(valore)}.",
        suggerimento=suggerimento,
    )


def richiedi_testo(valore: Any, funzione_nome: str, parametro: str) -> str:
    """Restituisce ``valore`` se è un testo, altrimenti ``ErroreTipo``."""
    if isinstance(valore, str):
        return valore
    suggerimento = None
    if e_numero(valore) or isinstance(valore, bool):
        suggerimento = f"Per trasformarlo in testo usa `testo({mostra(valore)})`."
    raise _errore_argomento(funzione_nome, parametro, "un testo", valore, suggerimento)


def richiedi_intero(valore: Any, funzione_nome: str, parametro: str) -> int:
    """Restituisce ``valore`` se è un intero (non logico), altrimenti ``ErroreTipo``."""
    if e_intero(valore):
        return valore
    suggerimento = None
    if isinstance(valore, float):
        suggerimento = "Per trasformare un decimale in intero usa `arrotonda(...)` o `intero(...)`."
    elif isinstance(valore, str):
        suggerimento = "Per trasformare un testo in numero usa `intero(...)`."
    elif isinstance(valore, bool):
        suggerimento = "`vero` e `falso` non sono numeri."
    raise _errore_argomento(funzione_nome, parametro, "un intero", valore, suggerimento)


def richiedi_numero(valore: Any, funzione_nome: str, parametro: str) -> int | float:
    """Restituisce ``valore`` se è un intero o un decimale, altrimenti ``ErroreTipo``."""
    if e_numero(valore):
        return valore
    suggerimento = None
    if isinstance(valore, str):
        suggerimento = "Per trasformare un testo in numero usa `intero(...)` o `decimale(...)`."
    elif isinstance(valore, bool):
        suggerimento = "`vero` e `falso` non sono numeri."
    raise _errore_argomento(funzione_nome, parametro, "un numero", valore, suggerimento)


def richiedi_logico(valore: Any, funzione_nome: str, parametro: str) -> bool:
    """Restituisce ``valore`` se è ``vero``/``falso``, altrimenti ``ErroreTipo``."""
    if isinstance(valore, bool):
        return valore
    raise _errore_argomento(funzione_nome, parametro, "`vero` o `falso`", valore)


def richiedi_lista(valore: Any, funzione_nome: str, parametro: str) -> list:
    """Restituisce ``valore`` se è una lista, altrimenti ``ErroreTipo``."""
    if isinstance(valore, list):
        return valore
    raise _errore_argomento(funzione_nome, parametro, "una lista", valore)


def lunghezza_intervallo(r: range) -> int:
    """Numero di elementi di un intervallo anche enorme (``len`` avrebbe un limite)."""
    passo = r.step
    segno = 1 if passo > 0 else -1
    return max(0, (r.stop - r.start + passo - segno) // passo)


# ===========================================================================
# Funzioni generali
# ===========================================================================

_CON_LUNGHEZZA = "testi, liste, dizionari e intervalli"


def _misura(x: Any, nome: str) -> int:
    if isinstance(x, (str, list, dict)):
        return len(x)
    if isinstance(x, range):
        return lunghezza_intervallo(x)
    misura = getattr(type(x), "lunghezza_dante", None)  # valori della libreria (tabelle) e oggetti del ponte Python
    if misura is not None:
        return misura(x)
    suggerimento = None
    if e_numero(x):
        suggerimento = f"Per contare le cifre di un numero usa `{nome}(testo({mostra(x)}))`."
    raise ErroreTipo(f"`{nome}` funziona con {_CON_LUNGHEZZA}, non con {articolo(x)}.",
                     suggerimento=suggerimento)


@funzione_libreria("lunghezza")
def lunghezza(x):
    """lunghezza(x): quanti elementi ha una lista, un dizionario o un intervallo, o quanti caratteri ha un testo.

    Esempi: `lunghezza("città")` è 5, `lunghezza([1, 2, 3])` è 3, `lunghezza(1..10)` è 10.
    """
    t = type(x)
    if t is str or t is list or t is dict:  # via veloce
        return len(x)
    return _misura(x, "lunghezza")


@funzione_libreria("vuota")
def vuota(x):
    """vuota(x): `vero` se il testo, la lista, il dizionario o l'intervallo non ha elementi.

    Esempio: `se non vuota(voti) allora stampa(voti) fine`.
    """
    t = type(x)
    if t is str or t is list or t is dict:  # via veloce
        return len(x) == 0
    return _misura(x, "vuota") == 0


@funzione_libreria("intervallo")
def intervallo(da, a, passo=None):
    """intervallo(da, a, passo): i numeri interi da `da` fino ad `a` compreso, andando avanti di `passo`.

    Senza passo conta di 1 in 1 (all'indietro se `da` è più grande di `a`).
    Esempi: `intervallo(1, 10, 2)` è 1, 3, 5, 7, 9; `intervallo(5, 1)` è 5, 4, 3, 2, 1.
    """
    richiedi_intero(da, "intervallo", "da")
    richiedi_intero(a, "intervallo", "a")
    if passo is not None:
        richiedi_intero(passo, "intervallo", "passo")
    return crea_intervallo(da, a, passo)
