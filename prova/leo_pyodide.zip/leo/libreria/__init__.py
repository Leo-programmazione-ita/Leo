"""Libreria standard di Leo.

Importare questo pacchetto registra tutte le funzioni e i metodi in
``leo.registro`` (ogni modulo usa i decoratori ``@funzione``/``@metodo``).

I moduli leggeri si importano subito. Quelli pesanti (pigri in :data:`MODULI`:
internet, Windows, suoni, grafici...) si importano alla prima chiamata di una
loro funzione: intanto nei registri c'è un segnaposto con lo stesso nome (vedi
``registro.registra_pigre``), così chi elenca le funzioni (suggerimenti,
colorazione, documentazione, completamento) le vede tutte, nello stesso ordine.
I nomi vengono dall'indice generato ``_indice.py``.

Per aggiungere un gruppo di funzioni: crea il modulo, aggiungilo a
:data:`MODULI` e, se è pigro, rigenera l'indice con
``python -m leo.libreria._genera_indice`` (un test verifica che sia aggiornato).
Un modulo pigro non deve cambiare niente fuori da sé quando si importa (per
esempio aggiungere metodi a classi di altri moduli): quelli resterebbero
assenti finché non si chiama una sua funzione.

``LEO_LIBRERIA_PIGRA=0`` nell'ambiente importa tutto subito (come una volta).
"""

from __future__ import annotations

import importlib
import os
import sys

from .. import registro

#: (modulo, pigro) nell'ordine di registrazione (l'ordine dei nomi nei registri).
MODULI: tuple[tuple[str, bool], ...] = (
    ("ingresso_uscita", False),
    ("conversioni", False),
    ("generali", False),
    ("matematica", False),
    ("testi", False),
    ("liste", False),
    ("dizionari", False),
    ("tempo", False),
    ("grafica", False),
    ("tartaruga", True),             # tema bambini: la tartaruga che disegna
    # tema "libreria": funzioni di ordine superiore, statistica, date, file/CSV/JSON, modelli, caso e tempo
    ("funzionali", False),
    ("statistica", False),
    ("date", False),
    ("archivi", True),
    ("modelli", False),
    ("caso_e_tempo", False),
    # file e cartelle (copia, sposta, cestino, percorsi) e formati di dati (binari, codifiche, INI, TOML, ZIP)
    ("cartelle", True),
    ("formati", True),
    # Internet (pagine, richieste, email, server web) e database SQLite
    ("internet", True),
    ("web", True),                   # web: pagine HTML, selettori, sessioni e API, feed, siti con percorsi
    ("web_pro", True),               # web PRO: risposta-oggetto comoda e server web con rotte (routing)
    ("database", True),
    ("database_avanzato", True),     # database senza SQL: unisci, somma, raggruppa, JSON, copie...
    # grafici di dati (barre, linee, torta...) e suoni (note, melodie, WAV)
    ("diagrammi", True),
    ("suoni", True),
    # animazioni ed effetti dei controlli nei programmi con finestre (anima, scuoti, lampeggia...)
    ("animazioni", True),
    ("stili_oggetti", True),         # stili degli oggetti delle finestre (stili_oggetti, descrizione_stile)
    # Windows (S1): informazioni di sistema, processi, programmi, comandi, appunti, cestino, collegamenti, avvio
    ("sistema", True),
    # Windows (S2): finestre delle applicazioni, schermi, cattura, notifiche, dialoghi nativi, sfondo e tema
    ("desktop", True),
    # Windows (S3): batteria, alimentazione, audio, prestazioni, dischi, rete, stampanti, registro, hardware
    ("computer", True),
    # libreria "potenza": modelli di testo con gruppi e controlli dei codici italiani, sicurezza dei dati,
    # matematica avanzata (frazioni, soldi, complessi, matrici, primi, basi) e tempo avanzato (festività, età).
    # tempo_avanzato si importa subito: aggiunge metodi e proprieta' al `cronometro` di caso_e_tempo.
    ("modelli_testo", True),
    ("testo_pro", True),             # testo avanzato: costruttore di schemi in italiano, frasi/parole/righe, INI da testo
    ("sicurezza_dati", True),
    ("matematica_avanzata", True),
    ("tempo_avanzato", False),
    ("tempo_pratico", False),        # livello comodo di date e tempo: componenti, aritmetica mesi/anni, calendario, fusi
    ("binario", True),               # dati binari, file (tipo vero, EXIF, entropia), compressione, cifratura, firme
    ("forense", True),               # analisi file, forense di base, log: tipo vero, schemi (YARA), metadati, anomalie
    ("difesa", True),                # robustezza account (forza password, OTP), chiave pubblica, firme di file, sfide
    ("immagini", True),               # immagini e foto: apri, ridimensiona, filtri, disegni, EXIF, GIF, ASCII
    ("media", True),                  # media: comandi comodi verbo_oggetto per immagini e audio di base (WAV)
    # rete e sistema su ogni piattaforma: TCP/UDP, DNS, IP, certificati, IMAP, FTP, processi, disco, ping
    ("rete_sistema", True),
    # primitivi di sistema uguali ovunque: numero_cpu, carico, cerca_eseguibile, PATH, separatori dei percorsi
    ("piattaforma", True),
    # rete di basso livello e analisi del proprio traffico: DNS completo, certificati/TLS, lettura di
    # catture .pcap/.pcapng, informazioni di rete del proprio sistema (interfacce, connessioni, routing)
    ("rete_bassa", True),
    # scienza: trigonometria, statistica, probabilità, geometria, GPS, unità di misura, mutui, chimica,
    # equazioni, derivate e integrali, intelligenza artificiale semplice (k-medie, k vicini, percettrone)
    ("scienza", True),
    # giochi e geometria 2D: punti e vettori, collisioni (rettangoli, cerchi), interpolazione e movimento,
    # angoli (gradi/radianti, direzione_verso, muovi_verso) e punti a caso. Solo calcolo (niente finestre)
    ("geometria", True),
    # testo e lingua italiana: numeri in lettere, sillabe, plurali, articoli, confronti, Markdown, XML, YAML
    ("testo_e_lingua", True),
    # tabelle di dati (righe e colonne con un nome): filtra, ordina, raggruppa, unisci, salva, grafico
    ("tabelle", True),
    # calcolo e dati: crea vettori/matrici, diagonale/traccia, serie a passo decimale, prodotto, somma
    # cumulata, rimappa/limita, covarianza, standardizza, conteggi, riepilogo numeri (completa gli esistenti)
    ("calcolo", True),
    # ufficio: Excel (.xlsx/.ods), Word (.docx/.odt), PDF e documenti con titoli, tabelle e immagini
    ("ufficio", True),
    ("programmi", True),             # programmi seri: riga di comando, registro, parallelo, orari, terminale
    ("parallelismo", True),          # lavori in parallelo: canali, aspetta_tutti/il_primo, annulla, processori
    ("sequenze_pigre", True),        # sequenze pigre: flussi senza fine, mappa/filtra/prendi/finche (uno alla volta)
    ("tipi_dati", False),            # copia, ha_tipo, campi (tipi e strutture: leo/controllo/)
    # la galleria di Leo (personaggi, oggetti, sfondi, suoni...): il valore `galleria` con i suoi metodi
    ("galleria", False),
)

_PIGRI = frozenset(nome for nome, pigro in MODULI if pigro)


def _carica() -> None:
    modo = os.environ.get("LEO_LIBRERIA_PIGRA", "1").strip()
    if modo == "indice":            # solo per _genera_indice: importa lui un modulo alla volta
        return
    indice: dict = {}
    if modo != "0":
        try:
            from ._indice import PIGRI as indice
        except ImportError:         # indice mancante: si importa tutto
            indice = {}
    for nome, pigro in MODULI:
        completo = f"{__name__}.{nome}"
        if pigro and nome in indice and completo not in sys.modules:
            registro.registra_pigre(completo, indice[nome])
        else:
            importlib.import_module(completo)


def __getattr__(nome: str):
    # `leo.libreria.internet` funziona anche se il modulo non e' ancora stato importato
    if nome in _PIGRI:
        return importlib.import_module(f"{__name__}.{nome}")
    raise AttributeError(f"module {__name__!r} has no attribute {nome!r}")


_carica()
