"""Libreria: modelli di testo (espressioni regolari) con nomi semplici.

``trova_tutti``, ``trova_primo``, ``corrisponde``, ``contiene_modello``,
``sostituisci_modello``, ``dividi_modello``.

Un *modello* è un testo che descrive una forma di testo, per esempio
``"[0-9]+"`` (una o più cifre). Per i principianti ci sono anche delle
**scorciatoie** tra parentesi angolari, che si possono mescolare con le
regole normali: ``<cifra>``, ``<cifre>``, ``<numero>``, ``<lettera>``,
``<parola>``, ``<maiuscola>``, ``<minuscola>``, ``<spazio>``, ``<spazi>``,
``<qualsiasi>``, ``<punto>``, ``<inizio>``, ``<fine>``, ``<email>``,
``<data>``, ``<ora>``. Sono comode perché nei testi di Leo la barra ``\\``
e le graffe ``{ }`` sono speciali (andrebbero scritte ``\\\\`` e ``\\{``).
"""

from __future__ import annotations

import functools
import re
import warnings
from typing import Any

from ..errori import ErroreTipo, ErroreValore
from ..valori import Richiamabile
from .funzionali import chiama_funzione
from .generali import articolo, funzione_libreria, mostra, richiedi_logico, richiedi_testo

#: Scorciatoie leggibili per i modelli più comuni: ``<cifra>``, ``<parola>``...
SCORCIATOIE = {
    "cifra": r"\d",
    "cifre": r"\d+",
    "numero": r"[+-]?\d+(?:[.,]\d+)?",
    "lettera": r"[^\W\d_]",
    "parola": r"[^\W\d_]+(?:'[^\W\d_]+)*",
    "maiuscola": r"[A-ZÀ-ÖØ-Þ]",
    "minuscola": r"[a-zß-öø-ÿ]",
    "spazio": r"\s",
    "spazi": r"\s+",
    "qualsiasi": r".",
    "punto": r"\.",
    "inizio": r"^",
    "fine": r"$",
    "email": r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+",
    "data": r"\d{1,2}/\d{1,2}/\d{4}",
    "ora": r"\d{1,2}:\d{2}(?::\d{2})?",
}
# <nome> (ma non il gruppo con nome di Python `(?P<nome>`): i nomi sconosciuti restano come sono
_SCORCIATOIA = re.compile(r"(?<!\(\?P)<(\w+)>")

_MESSAGGI_RE = {
    "missing ), unterminated subpattern": "una parentesi `(` non è chiusa",
    "unbalanced parenthesis": "c'è una parentesi `)` di troppo",
    "unterminated character set": "una parentesi quadra `[` non è chiusa",
    "nothing to repeat": "un simbolo di ripetizione (`*`, `+`, `?`) non ha niente prima da ripetere",
    "multiple repeat": "due simboli di ripetizione sono attaccati",
    "bad escape (end of pattern)": "il modello finisce con una barra `\\`",
}

#: Inizi dei messaggi di ``re`` che contengono dettagli variabili (``bad escape \\q``...).
_INIZI_RE = (
    ("bad escape", "la barra `\\` è seguita da una lettera che non ha significato speciale"),
    ("bad character range", "un intervallo tra parentesi quadre va al contrario (scrivi per esempio `[a-z]`, non `[z-a]`)"),
    ("look-behind requires fixed-width pattern", "il controllo all'indietro `(?<=...)` deve avere una lunghezza fissa"),
    ("unknown extension", "dopo `(?` c'è un simbolo sconosciuto"),
    ("unknown group name", "il gruppo con quel nome non esiste"),
    ("invalid group reference", "il riferimento a un gruppo non è valido"),
    ("missing group name", "manca il nome del gruppo"),
    ("bad character in group name", "il nome del gruppo contiene caratteri non ammessi"),
    ("redefinition of group name", "due gruppi hanno lo stesso nome"),
    ("min repeat greater than max repeat", "in `{min,max}` il primo numero è più grande del secondo"),
    ("the repetition number is too large", "il numero di ripetizioni è troppo grande"),
    ("missing ), unterminated comment", "un commento `(?#` non è chiuso da `)`"),
    ("missing ), unterminated subpattern", "una parentesi `(` non è chiusa"),
    ("missing :, unterminated name", "manca il nome del gruppo"),
    ("unterminated name", "il nome del gruppo non è chiuso da `>`"),
    ("global flags not at the start", "le opzioni `(?i)` vanno messe all'inizio del modello"),
    ("cannot refer to an open group", "un gruppo si riferisce a se stesso"),
)


def _spiega_errore_re(messaggio: str) -> str:
    """Il motivo di un ``re.error`` in italiano (se non è noto resta com'è)."""
    if messaggio in _MESSAGGI_RE:
        return _MESSAGGI_RE[messaggio]
    for inizio, spiegazione in _INIZI_RE:
        if messaggio.startswith(inizio):
            return spiegazione
    return f"errore nel modello ({messaggio})"


def _compila_re(modello: str, opzioni: int) -> "re.Pattern[str]":
    """``re.compile`` uguale su Python 3.10 e 3.11+.

    Con Python 3.10 ``a(?i)b`` (opzioni non all'inizio) è solo un
    DeprecationWarning; da 3.11 è un ``re.error``: qui diventa sempre errore."""
    with warnings.catch_warnings():
        warnings.simplefilter("error", DeprecationWarning)
        try:
            return re.compile(modello, opzioni)
        except DeprecationWarning as avviso:
            if "not at the start" in str(avviso):
                raise re.error("global flags not at the start of the expression", modello) from None
    return re.compile(modello, opzioni)          # altri avvisi di Python: il modello resta valido


@functools.lru_cache(maxsize=256)
def _compila_cache(modello: str, ignora: bool) -> "re.Pattern[str]":
    def espandi(m: "re.Match[str]") -> str:
        nome = m.group(1)
        if nome not in SCORCIATOIE:
            return m.group(0)
        return "(?:" + SCORCIATOIE[nome] + ")"

    espanso = _SCORCIATOIA.sub(espandi, modello)
    try:
        return _compila_re(espanso, re.IGNORECASE if ignora else 0)
    except re.error as e:
        motivo = _spiega_errore_re(e.msg)
        dove = f" (vicino al carattere {e.pos + 1})" if e.pos is not None and espanso == modello else ""
        raise ErroreValore(f"Il modello {mostra(modello)} non è valido{dove}: {motivo}.",
                           suggerimento="Per cercare un punto vero usa `<punto>`; per altri simboli speciali come `(` "
                                        "scrivi `\\\\(` nel testo Leo.") \
            from None


def _compila(modello: Any, nome_funzione: str, ignora_maiuscole: Any) -> "re.Pattern[str]":
    richiedi_testo(modello, nome_funzione, "modello")
    richiedi_logico(ignora_maiuscole, nome_funzione, "ignora_maiuscole")
    return _compila_cache(modello, ignora_maiuscole)


@funzione_libreria("trova_tutti")
def trova_tutti(testo, modello, ignora_maiuscole=False):
    """trova_tutti(testo, modello, ignora_maiuscole = falso): la lista di tutti i pezzi del testo che seguono il modello.

    Esempi: `trova_tutti("ho 3 gatti e 12 pesci", "[0-9]+")` è ["3", "12"];
    `trova_tutti("scrivi a ada@esempio.it", "<email>")` è ["ada@esempio.it"].
    """
    richiedi_testo(testo, "trova_tutti", "testo")
    regola = _compila(modello, "trova_tutti", ignora_maiuscole)
    return [m.group(0) for m in regola.finditer(testo)]


@funzione_libreria("trova_primo")
def trova_primo(testo, modello, ignora_maiuscole=False):
    """trova_primo(testo, modello, ignora_maiuscole = falso): il primo pezzo che segue il modello, o `nulla`.

    Esempio: `trova_primo("Totale: 42 euro", "<numero>")` è "42".
    """
    richiedi_testo(testo, "trova_primo", "testo")
    m = _compila(modello, "trova_primo", ignora_maiuscole).search(testo)
    return m.group(0) if m else None


@funzione_libreria("corrisponde")
def corrisponde(testo, modello, ignora_maiuscole=False):
    """corrisponde(testo, modello, ignora_maiuscole = falso): `vero` se TUTTO il testo segue il modello.

    Serve per controllare cosa scrive l'utente. Esempi: `corrisponde("12345", "<cifra>+")` è `vero`;
    `corrisponde("12a45", "<cifra>+")` è `falso`.
    """
    richiedi_testo(testo, "corrisponde", "testo")
    return _compila(modello, "corrisponde", ignora_maiuscole).fullmatch(testo) is not None


@funzione_libreria("contiene_modello")
def contiene_modello(testo, modello, ignora_maiuscole=False):
    """contiene_modello(testo, modello, ignora_maiuscole = falso): `vero` se almeno un pezzo del testo segue il modello.

    Esempio: `contiene_modello("chiamami al 333 1234567", "<cifre>")` è `vero`.
    """
    richiedi_testo(testo, "contiene_modello", "testo")
    return _compila(modello, "contiene_modello", ignora_maiuscole).search(testo) is not None


@funzione_libreria("sostituisci_modello", interprete=True)
def sostituisci_modello(interprete, testo, modello, sostituto, ignora_maiuscole=False):
    """sostituisci_modello(testo, modello, sostituto): sostituisce ogni pezzo che segue il modello.

    `sostituto` può essere un testo (messo così com'è) oppure una funzione che riceve il pezzo
    trovato e restituisce il testo da mettere al suo posto.
    Esempi: `sostituisci_modello("a  b   c", " +", " ")` è "a b c";
    `sostituisci_modello("3 mele", "<numero>", funzione (n) restituisci testo(intero(n) * 2) fine)` è "6 mele".
    """
    richiedi_testo(testo, "sostituisci_modello", "testo")
    regola = _compila(modello, "sostituisci_modello", ignora_maiuscole)
    if isinstance(sostituto, str):
        return regola.sub(lambda _m: sostituto, testo)
    if isinstance(sostituto, Richiamabile):
        def con_funzione(m: "re.Match[str]") -> str:
            r = chiama_funzione(interprete, sostituto, [m.group(0)])
            if not isinstance(r, str):
                raise ErroreTipo(f"La funzione data a `sostituisci_modello` deve restituire un testo, "
                                 f"non {articolo(r)}.",
                                 suggerimento="Trasforma il risultato con `testo(...)`.")
            return r
        return regola.sub(con_funzione, testo)
    raise ErroreTipo(f"Il `sostituto` di `sostituisci_modello` deve essere un testo o una funzione, "
                     f"non {articolo(sostituto)}.")


@funzione_libreria("dividi_modello")
def dividi_modello(testo, modello, ignora_maiuscole=False):
    """dividi_modello(testo, modello): divide il testo in pezzi, tagliando dove c'è il modello.

    Esempio: `dividi_modello("uno, due;tre", "[,;] *")` è ["uno", "due", "tre"].
    """
    richiedi_testo(testo, "dividi_modello", "testo")
    regola = _compila(modello, "dividi_modello", ignora_maiuscole)
    pezzi, inizio = [], 0
    for m in regola.finditer(testo):
        if m.end() == m.start():
            continue  # un modello che trova "niente" non taglia
        pezzi.append(testo[inizio:m.start()])
        inizio = m.end()
    pezzi.append(testo[inizio:])
    return pezzi
