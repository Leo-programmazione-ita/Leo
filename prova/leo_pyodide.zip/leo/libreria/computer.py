"""Libreria: il computer (batteria, alimentazione, audio, prestazioni, dischi, rete, registro...).

Funzioni di Windows per i programmi Leo (parte S3 della libreria "sistema");
il lavoro vero lo fa :mod:`leo.sistema.hardware`.

* **Batteria**: ``info_batteria``, ``ha_batteria``, ``percentuale_batteria``,
  ``batteria_in_carica``, ``tempo_batteria_rimasto``.
* **Alimentazione** (con conferma e ritardo facoltativo): ``blocca_computer``,
  ``sospendi_computer``, ``iberna_computer``, ``spegni_computer``,
  ``riavvia_computer``, ``disconnetti_utente``, ``annulla_spegnimento``;
  ``impedisci_standby``/``consenti_standby`` mentre il programma lavora.
* **Audio**: ``volume_principale``, ``imposta_volume``, ``alza_volume``,
  ``abbassa_volume``, ``e_muto``, ``imposta_muto``, ``dispositivi_audio``.
* **Schermo**: ``luminosita_schermo``, ``imposta_luminosita``.
* **Prestazioni**: ``uso_cpu``, ``numero_core``, ``info_memoria``,
  ``memoria_totale``, ``memoria_libera``, ``uso_memoria``, ``processi_piu_pesanti``.
* **Dischi**: ``elenca_unita``, ``info_unita``, ``spazio_libero``, ``spazio_totale``.
* **Rete**: ``indirizzi_ip_locali``, ``indirizzo_ip_locale``, ``ip_pubblico``,
  ``wifi_connesso``, ``potenza_wifi``, ``schede_di_rete``, ``invia_ping``.
* **Stampanti**: ``elenca_stampanti``, ``nome_stampante_predefinita``, ``stampa_documento``.
* **Registro di Windows**: ``leggi_registro``, ``elenca_chiavi_registro``,
  ``elenca_valori_registro``, ``esiste_chiave_registro`` (ovunque);
  ``scrivi_registro``, ``elimina_valore_registro``, ``elimina_chiave_registro``
  (solo HKCU, con conferma).
* **Servizi** (solo lettura): ``elenca_servizi``, ``stato_servizio``, ``servizio_attivo``.
* **Utente e orologio**: ``e_amministratore``, ``info_sessione``,
  ``fuso_orario``, ``ora_utc``, ``sincronizzazione_ora``.
* **Caratteri, hardware, USB**: ``elenca_caratteri``, ``carattere_installato``,
  ``info_processore``, ``info_scheda_madre``, ``info_schede_video``,
  ``info_computer``, ``dispositivi_usb``.

Le azioni pericolose chiedono conferma all'utente del programma (finestra se
c'è la grafica, altrimenti domanda nel terminale) salvo ``senza_conferma =
vero``, e restituiscono ``vero`` se l'azione è stata fatta, ``falso`` se
l'utente ha risposto No.
"""

from __future__ import annotations

import math
import os
import time
from typing import Any

from ..errori import ErroreFile, ErroreValore
from ..sistema import hardware as hw
from ..sistema._win import chiedi_conferma
from .date import DataDante
from .generali import funzione_libreria, richiedi_logico, richiedi_numero, richiedi_testo

# ===========================================================================
# Aiuti
# ===========================================================================


def _chiedi(interprete: Any, senza_conferma: bool, testo: str) -> bool:
    if senza_conferma:
        return True
    return chiedi_conferma(interprete, testo)


def _tra_quanto(secondi: int) -> str:
    if secondi <= 0:
        return "adesso"
    if secondi < 60:
        return f"tra {secondi} second{'o' if secondi == 1 else 'i'}"
    minuti, resto = divmod(secondi, 60)
    if minuti < 60:
        testo = f"tra {minuti} minut{'o' if minuti == 1 else 'i'}"
        return testo + (f" e {resto} secondi" if resto else "")
    ore, minuti = divmod(minuti, 60)
    return f"tra {ore} or{'a' if ore == 1 else 'e'}" + (f" e {minuti} minuti" if minuti else "")


def _ritardo(valore: Any, funzione: str) -> int:
    n = richiedi_numero(valore, funzione, "ritardo")
    if isinstance(n, float) and not math.isfinite(n) or n < 0 or n > hw.RITARDO_MASSIMO:
        raise ErroreValore(f"Il `ritardo` di `{funzione}` va da 0 a {hw.RITARDO_MASSIMO} secondi (31 giorni).",
                           suggerimento=f"Per esempio `{funzione}(ritardo = 60)` aspetta un minuto.")
    return int(math.ceil(n))


def _percentuale(valore: Any, funzione: str, parametro: str) -> float:
    n = richiedi_numero(valore, funzione, parametro)
    if isinstance(n, float) and not math.isfinite(n) or not 0 <= n <= 100:
        raise ErroreValore(f"`{parametro}` di `{funzione}` va da 0 a 100.",
                           suggerimento=f"Per esempio `{funzione}(50)` per la metà.")
    return float(n)


def _numero_tra(valore: Any, funzione: str, parametro: str, minimo: float, massimo: float) -> float:
    n = richiedi_numero(valore, funzione, parametro)
    if isinstance(n, float) and not math.isfinite(n) or not minimo <= n <= massimo:
        raise ErroreValore(f"`{parametro}` di `{funzione}` va da {minimo:g} a {massimo:g}.")
    return n


def _testo_non_vuoto(valore: Any, funzione: str, parametro: str) -> str:
    t = richiedi_testo(valore, funzione, parametro)
    if not t.strip() or "\0" in t:
        raise ErroreValore(f"`{parametro}` di `{funzione}` è vuoto o non valido.")
    return t


# ===========================================================================
# Batteria
# ===========================================================================


@funzione_libreria("info_batteria")
def info_batteria():
    """info_batteria(): tutto sulla batteria in un dizionario.

    Chiavi: `presente`, `percentuale` (0-100 o `nulla`), `in_carica`, `alla_corrente`,
    `minuti_rimasti` (`nulla` se non si sa o se è alla corrente), `risparmio_energetico`.
    Esempio: `variabile b = info_batteria()` e poi `stampa(b["percentuale"])`.
    """
    return hw.info_batteria()


@funzione_libreria("ha_batteria")
def ha_batteria():
    """ha_batteria(): `vero` se il computer ha una batteria (un portatile).

    Esempio: `se ha_batteria() allora stampa("Portatile") fine`.
    """
    hw.richiedi_windows("ha_batteria")
    return hw.info_batteria()["presente"]


@funzione_libreria("percentuale_batteria")
def percentuale_batteria():
    """percentuale_batteria(): carica della batteria da 0 a 100 (`nulla` se non c'è batteria).

    Esempio: `se percentuale_batteria() < 20 allora messaggio("Batteria quasi scarica") fine`.
    """
    hw.richiedi_windows("percentuale_batteria")
    return hw.info_batteria()["percentuale"]


@funzione_libreria("batteria_in_carica")
def batteria_in_carica():
    """batteria_in_carica(): `vero` se la batteria si sta caricando.

    Esempio: `stampa("In carica: {batteria_in_carica()}")`.
    """
    hw.richiedi_windows("batteria_in_carica")
    return hw.info_batteria()["in_carica"]


@funzione_libreria("tempo_batteria_rimasto")
def tempo_batteria_rimasto():
    """tempo_batteria_rimasto(): minuti di autonomia stimati (`nulla` se alla corrente o non si sa).

    Esempio: `variabile m = tempo_batteria_rimasto()` e `se m != nulla allora stampa("{m} minuti") fine`.
    """
    hw.richiedi_windows("tempo_batteria_rimasto")
    return hw.info_batteria()["minuti_rimasti"]


# ===========================================================================
# Alimentazione
# ===========================================================================

_DOMANDE = {
    "blocca": "Vuoi bloccare il computer {quando}?",
    "sospendi": "Vuoi mettere in sospensione il computer {quando}?",
    "iberna": "Vuoi ibernare il computer {quando}?",
    "spegni": "Vuoi spegnere il computer {quando}? Salva prima il lavoro: i programmi aperti verranno chiusi.",
    "riavvia": "Vuoi riavviare il computer {quando}? Salva prima il lavoro: i programmi aperti verranno chiusi.",
    "disconnetti": "Vuoi disconnettere l'utente {quando}? Salva prima il lavoro: i programmi aperti verranno chiusi.",
}


def _alimentazione(interprete, azione: str, funzione: str, ritardo: Any, senza_conferma: Any) -> bool:
    secondi = _ritardo(ritardo, funzione)
    richiedi_logico(senza_conferma, funzione, "senza_conferma")
    hw.richiedi_windows(funzione)
    if not _chiedi(interprete, senza_conferma, _DOMANDE[azione].format(quando=_tra_quanto(secondi))):
        return False
    hw.alimentazione(azione, secondi)
    return True


@funzione_libreria("blocca_computer", interprete=True)
def blocca_computer(interprete, ritardo=0, senza_conferma=False):
    """blocca_computer(ritardo = 0, senza_conferma = falso): blocca lo schermo (come Windows+L).

    `ritardo` in secondi; restituisce `vero` se fatto (o programmato), `falso` se l'utente dice No.
    Esempio: `blocca_computer(ritardo = 30)`.
    """
    return _alimentazione(interprete, "blocca", "blocca_computer", ritardo, senza_conferma)


@funzione_libreria("sospendi_computer", interprete=True)
def sospendi_computer(interprete, ritardo=0, senza_conferma=False):
    """sospendi_computer(ritardo = 0, senza_conferma = falso): mette il computer in sospensione (standby).

    Chiede conferma; `ritardo` in secondi. Esempio: `sospendi_computer(ritardo = 600)` fra dieci minuti.
    """
    return _alimentazione(interprete, "sospendi", "sospendi_computer", ritardo, senza_conferma)


@funzione_libreria("iberna_computer", interprete=True)
def iberna_computer(interprete, ritardo=0, senza_conferma=False):
    """iberna_computer(ritardo = 0, senza_conferma = falso): iberna il computer (se l'ibernazione è attiva).

    Chiede conferma; `ritardo` in secondi. Esempio: `iberna_computer()`.
    """
    return _alimentazione(interprete, "iberna", "iberna_computer", ritardo, senza_conferma)


@funzione_libreria("spegni_computer", interprete=True)
def spegni_computer(interprete, ritardo=0, senza_conferma=False):
    """spegni_computer(ritardo = 0, senza_conferma = falso): spegne il computer, dopo una conferma.

    Con `ritardo` (secondi) lo spegnimento è programmato e si può annullare con
    `annulla_spegnimento()`. Esempio: `spegni_computer(ritardo = 3600)` fra un'ora.
    """
    return _alimentazione(interprete, "spegni", "spegni_computer", ritardo, senza_conferma)


@funzione_libreria("riavvia_computer", interprete=True)
def riavvia_computer(interprete, ritardo=0, senza_conferma=False):
    """riavvia_computer(ritardo = 0, senza_conferma = falso): riavvia il computer, dopo una conferma.

    Esempio: `se riavvia_computer(ritardo = 60) allora stampa("Riavvio tra un minuto") fine`.
    """
    return _alimentazione(interprete, "riavvia", "riavvia_computer", ritardo, senza_conferma)


@funzione_libreria("disconnetti_utente", interprete=True)
def disconnetti_utente(interprete, ritardo=0, senza_conferma=False):
    """disconnetti_utente(ritardo = 0, senza_conferma = falso): esce dall'account di Windows (logout).

    Chiede conferma. Esempio: `disconnetti_utente()`.
    """
    return _alimentazione(interprete, "disconnetti", "disconnetti_utente", ritardo, senza_conferma)


@funzione_libreria("annulla_spegnimento")
def annulla_spegnimento():
    """annulla_spegnimento(): annulla spegnimenti, riavvii e sospensioni programmati; dice cosa ha annullato.

    Restituisce la lista delle azioni annullate (vuota se non c'era niente).
    Esempio: `stampa(annulla_spegnimento())`.
    """
    hw.richiedi_windows("annulla_spegnimento")
    return hw.annulla_programmate()


@funzione_libreria("impedisci_standby")
def impedisci_standby(schermo=True):
    """impedisci_standby(schermo = vero): finché il programma lavora il PC non va in standby.

    Con `schermo = vero` anche lo schermo resta acceso. Vale fino a `consenti_standby()`
    o alla fine del programma. Esempio: `impedisci_standby()` prima di un lungo calcolo.
    """
    richiedi_logico(schermo, "impedisci_standby", "schermo")
    hw.richiedi_windows("impedisci_standby")
    hw.nativo.stato_esecuzione(True, schermo)
    return None


@funzione_libreria("consenti_standby")
def consenti_standby():
    """consenti_standby(): il computer torna ad andare in standby e a spegnere lo schermo come sempre.

    Esempio: `consenti_standby()` alla fine del lavoro.
    """
    hw.richiedi_windows("consenti_standby")
    hw.nativo.stato_esecuzione(False, False)
    return None


# ===========================================================================
# Audio e schermo
# ===========================================================================


@funzione_libreria("volume_principale")
def volume_principale():
    """volume_principale(): volume delle casse o cuffie predefinite, da 0 a 100.

    Esempio: `stampa("Volume: {volume_principale()}")`.
    """
    return hw.volume_percentuale()


@funzione_libreria("imposta_volume")
def imposta_volume(livello):
    """imposta_volume(livello): imposta il volume principale (da 0 a 100).

    Esempio: `imposta_volume(30)`.
    """
    valore = _percentuale(livello, "imposta_volume", "livello")
    hw.imposta_volume_percentuale(valore)
    return None


@funzione_libreria("alza_volume")
def alza_volume(passo=10):
    """alza_volume(passo = 10): alza il volume di `passo` punti (fino a 100); restituisce il nuovo volume.

    Esempio: `alza_volume(5)`.
    """
    p = _percentuale(passo, "alza_volume", "passo")
    hw.richiedi_windows("alza_volume")
    return hw.imposta_volume_percentuale(min(100.0, hw.volume_percentuale() + p))


@funzione_libreria("abbassa_volume")
def abbassa_volume(passo=10):
    """abbassa_volume(passo = 10): abbassa il volume di `passo` punti (fino a 0); restituisce il nuovo volume.

    Esempio: `abbassa_volume()`.
    """
    p = _percentuale(passo, "abbassa_volume", "passo")
    hw.richiedi_windows("abbassa_volume")
    return hw.imposta_volume_percentuale(max(0.0, hw.volume_percentuale() - p))


@funzione_libreria("e_muto")
def e_muto():
    """e_muto(): `vero` se l'audio è disattivato (muto).

    Esempio: `se e_muto() allora imposta_muto(falso) fine`.
    """
    hw.richiedi_windows("e_muto")
    return hw.nativo.muto()


@funzione_libreria("imposta_muto")
def imposta_muto(muto=True):
    """imposta_muto(muto = vero): toglie (`vero`) o rimette (`falso`) l'audio.

    Esempio: `imposta_muto()` per silenziare, `imposta_muto(falso)` per riattivare.
    """
    richiedi_logico(muto, "imposta_muto", "muto")
    hw.richiedi_windows("imposta_muto")
    hw.nativo.imposta_muto(muto)
    return None


@funzione_libreria("dispositivi_audio")
def dispositivi_audio():
    """dispositivi_audio(): le uscite audio attive (casse, cuffie...): lista di dizionari.

    Ogni elemento ha `nome`, `predefinito` (vero/falso) e `id`.
    Esempio: `per ogni d in dispositivi_audio() fai stampa(d["nome"]) fine`.
    """
    hw.richiedi_windows("dispositivi_audio")
    return hw.nativo.dispositivi_audio()


@funzione_libreria("luminosita_schermo")
def luminosita_schermo():
    """luminosita_schermo(): luminosità dello schermo da 0 a 100 (`nulla` se lo schermo non lo permette).

    Di solito funziona sugli schermi dei portatili, non sui monitor esterni.
    Esempio: `stampa(luminosita_schermo())`.
    """
    hw.richiedi_windows("luminosita_schermo")
    return hw.nativo.luminosita()


@funzione_libreria("imposta_luminosita")
def imposta_luminosita(livello):
    """imposta_luminosita(livello): cambia la luminosità dello schermo (0-100); `falso` se non si può.

    Esempio: `imposta_luminosita(70)`.
    """
    valore = _percentuale(livello, "imposta_luminosita", "livello")
    hw.richiedi_windows("imposta_luminosita")
    return hw.nativo.imposta_luminosita(int(round(valore)))


# ===========================================================================
# Prestazioni
# ===========================================================================


@funzione_libreria("uso_cpu")
def uso_cpu(intervallo=0.5):
    """uso_cpu(intervallo = 0.5): quanto lavora il processore, in percentuale (0-100).

    Misura per `intervallo` secondi (da 0.1 a 10). Esempio: `stampa("CPU al {uso_cpu()}%")`.
    """
    secondi = _numero_tra(intervallo, "uso_cpu", "intervallo", 0.1, 10)
    hw.richiedi_windows("uso_cpu")
    prima = hw.nativo.tempi_sistema()
    time.sleep(secondi)
    return hw.percentuale_cpu(prima, hw.nativo.tempi_sistema())


@funzione_libreria("numero_core")
def numero_core(fisici=False):
    """numero_core(fisici = falso): quanti processori logici ha il computer (con `fisici = vero` i core veri).

    Esempio: `stampa("Core: {numero_core()}")`.
    """
    richiedi_logico(fisici, "numero_core", "fisici")
    if fisici:
        return hw.info_processore()["core"]
    return os.cpu_count() or 1


def _memoria() -> dict:
    return hw.stato_memoria(*hw.nativo.memoria())


@funzione_libreria("info_memoria")
def info_memoria():
    """info_memoria(): la memoria RAM: dizionario con `totale`, `libera`, `usata` (byte) e `percentuale_usata`.

    Per un testo leggibile usa `dimensione_leggibile(...)`.
    Esempio: `stampa(dimensione_leggibile(info_memoria()["libera"]))`.
    """
    hw.richiedi_windows("info_memoria")
    return _memoria()


@funzione_libreria("memoria_totale")
def memoria_totale():
    """memoria_totale(): memoria RAM installata, in byte.

    Esempio: `stampa(dimensione_leggibile(memoria_totale()))`.
    """
    hw.richiedi_windows("memoria_totale")
    return _memoria()["totale"]


@funzione_libreria("memoria_libera")
def memoria_libera():
    """memoria_libera(): memoria RAM ancora disponibile, in byte.

    Esempio: `stampa(dimensione_leggibile(memoria_libera()))`.
    """
    hw.richiedi_windows("memoria_libera")
    return _memoria()["libera"]


@funzione_libreria("uso_memoria")
def uso_memoria():
    """uso_memoria(): percentuale di memoria RAM usata (0-100).

    Esempio: `se uso_memoria() > 90 allora stampa("Memoria quasi piena") fine`.
    """
    hw.richiedi_windows("uso_memoria")
    return _memoria()["percentuale_usata"]


@funzione_libreria("processi_piu_pesanti")
def processi_piu_pesanti(quanti=5):
    """processi_piu_pesanti(quanti = 5): i programmi che usano più memoria.

    Lista di dizionari con `nome`, `pid`, `memoria` (byte) e `cpu_secondi`.
    Esempio: `per ogni p in processi_piu_pesanti(3) fai stampa(p["nome"]) fine`.
    """
    n = int(_numero_tra(quanti, "processi_piu_pesanti", "quanti", 1, 200))
    hw.richiedi_windows("processi_piu_pesanti")
    risultato = []
    for d in hw.nativo.processi_pesanti(n):
        cpu = d.get("c")
        risultato.append({
            "nome": str(d.get("n") or ""),
            "pid": int(d.get("p") or 0),
            "memoria": int(d.get("m") or 0),
            "cpu_secondi": round(float(cpu), 1) if isinstance(cpu, (int, float)) else None,
        })
    return risultato


# ===========================================================================
# Dischi
# ===========================================================================


@funzione_libreria("elenca_unita")
def elenca_unita():
    """elenca_unita(): i dischi e le unità del computer (C:, D:, chiavette...).

    Ogni elemento ha `unita`, `tipo` ("disco fisso", "rimovibile", "rete", "CD/DVD"...),
    `etichetta`, `file_system`, `pronta`, `totale`, `libero`, `usato` (byte).
    Esempio: `per ogni u in elenca_unita() fai stampa(u["unita"], u["tipo"]) fine`.
    """
    return hw.elenca_unita()


@funzione_libreria("info_unita")
def info_unita(unita="C:"):
    """info_unita(unita = "C:"): le informazioni su un'unità (come un elemento di `elenca_unita`).

    Esempio: `stampa(info_unita("D:")["etichetta"])`.
    """
    richiedi_testo(unita, "info_unita", "unita")
    return hw.info_unita(unita)


@funzione_libreria("spazio_libero")
def spazio_libero(unita="C:"):
    """spazio_libero(unita = "C:"): byte liberi sull'unità.

    Esempio: `stampa(dimensione_leggibile(spazio_libero("C:")))`.
    """
    richiedi_testo(unita, "spazio_libero", "unita")
    hw.richiedi_windows("spazio_libero")
    return hw.info_unita(unita)["libero"]


@funzione_libreria("spazio_totale")
def spazio_totale(unita="C:"):
    """spazio_totale(unita = "C:"): capacità dell'unità in byte.

    Per lo spazio occupato da una cartella usa `dimensione_cartella(...)`.
    Esempio: `stampa(dimensione_leggibile(spazio_totale()))`.
    """
    richiedi_testo(unita, "spazio_totale", "unita")
    hw.richiedi_windows("spazio_totale")
    return hw.info_unita(unita)["totale"]


# ===========================================================================
# Rete
# ===========================================================================


@funzione_libreria("indirizzi_ip_locali")
def indirizzi_ip_locali():
    """indirizzi_ip_locali(): gli indirizzi IPv4 del computer nella rete locale (lista di testi).

    Esempio: `stampa(indirizzi_ip_locali())`.
    """
    hw.richiedi_windows("indirizzi_ip_locali")
    visti: list[str] = []
    for d in hw.nativo.indirizzi_ip():
        ip = str(d.get("i") or "")
        if ip and ip not in visti:
            visti.append(ip)
    return visti


@funzione_libreria("indirizzo_ip_locale")
def indirizzo_ip_locale():
    """indirizzo_ip_locale(): l'indirizzo IP locale principale (quello usato per uscire in rete), o `nulla`.

    Esempio: `stampa("Il mio IP: {indirizzo_ip_locale()}")`.
    """
    hw.richiedi_windows("indirizzo_ip_locale")
    return hw.nativo.ip_uscita()


@funzione_libreria("ip_pubblico")
def ip_pubblico(tempo_massimo=5):
    """ip_pubblico(tempo_massimo = 5): l'indirizzo IP con cui il computer si vede su Internet.

    Chiede a un servizio pubblico (api.ipify.org); aspetta al massimo `tempo_massimo` secondi.
    Esempio: `stampa(ip_pubblico())`.
    """
    secondi = _numero_tra(tempo_massimo, "ip_pubblico", "tempo_massimo", 0.5, 60)
    hw.richiedi_windows("ip_pubblico")
    return hw.nativo.ip_pubblico(secondi)


@funzione_libreria("wifi_connesso")
def wifi_connesso():
    """wifi_connesso(): la rete Wi-Fi a cui si è collegati, o `nulla`.

    Dizionario con `nome`, `segnale` (0-100), `bssid`, `canale`, `autenticazione`, `scheda`.
    Esempio: `variabile w = wifi_connesso()` e `se w != nulla allora stampa(w["nome"]) fine`.
    """
    hw.richiedi_windows("wifi_connesso")
    return hw.analizza_wifi(hw.nativo.wifi())


@funzione_libreria("potenza_wifi")
def potenza_wifi():
    """potenza_wifi(): potenza del segnale Wi-Fi da 0 a 100 (`nulla` se non connesso).

    Esempio: `stampa("Segnale: {potenza_wifi()}%")`.
    """
    hw.richiedi_windows("potenza_wifi")
    w = hw.analizza_wifi(hw.nativo.wifi())
    return w["segnale"] if w else None


@funzione_libreria("schede_di_rete")
def schede_di_rete():
    """schede_di_rete(): le schede di rete (Ethernet, Wi-Fi...): lista di dizionari.

    Ogni elemento ha `nome`, `descrizione`, `stato`, `connessa`, `mac`, `velocita`.
    Esempio: `per ogni s in schede_di_rete() fai stampa(s["nome"], s["stato"]) fine`.
    """
    return hw.schede_di_rete()


@funzione_libreria("invia_ping")
def invia_ping(indirizzo, volte=4, tempo_massimo=2):
    """invia_ping(indirizzo, volte = 4, tempo_massimo = 2): controlla se un computer in rete risponde.

    Restituisce un dizionario con `raggiungibile`, `inviati`, `ricevuti`, `persi`,
    `percentuale_persi`, `tempi` (millisecondi), `minimo`, `massimo`, `medio`, `ip`.
    Esempio: `se invia_ping("192.168.1.1")["raggiungibile"] allora stampa("Il router risponde") fine`.
    """
    testo = _testo_non_vuoto(indirizzo, "invia_ping", "indirizzo").strip()
    n = int(_numero_tra(volte, "invia_ping", "volte", 1, 100))
    secondi = _numero_tra(tempo_massimo, "invia_ping", "tempo_massimo", 0.1, 30)
    if any(c.isspace() for c in testo) or len(testo) > 253:
        raise ErroreValore(f"`{testo}` non è un indirizzo valido.",
                           suggerimento="Scrivi un nome come \"www.google.it\" o un IP come \"192.168.1.1\".")
    return hw.ping(testo, n, secondi)


# ===========================================================================
# Stampanti
# ===========================================================================


@funzione_libreria("elenca_stampanti")
def elenca_stampanti():
    """elenca_stampanti(): le stampanti installate: lista di dizionari.

    Ogni elemento ha `nome`, `predefinita`, `in_linea`, `porta`, `driver`, `condivisa`.
    Esempio: `per ogni s in elenca_stampanti() fai stampa(s["nome"]) fine`.
    """
    return hw.elenca_stampanti()


@funzione_libreria("nome_stampante_predefinita")
def nome_stampante_predefinita():
    """nome_stampante_predefinita(): il nome della stampante predefinita (`nulla` se non ce n'è).

    Esempio: `stampa(nome_stampante_predefinita())`.
    """
    hw.richiedi_windows("nome_stampante_predefinita")
    return hw.nativo.stampante_predefinita()


@funzione_libreria("stampa_documento", interprete=True)
def stampa_documento(interprete, percorso, senza_conferma=False):
    """stampa_documento(percorso, senza_conferma = falso): stampa un file (testo, PDF...) con il programma predefinito.

    Chiede conferma; restituisce `vero` se la stampa è partita.
    Esempio: `stampa_documento("relazione.pdf")`.
    """
    p = _testo_non_vuoto(percorso, "stampa_documento", "percorso")
    richiedi_logico(senza_conferma, "stampa_documento", "senza_conferma")
    hw.richiedi_windows("stampa_documento")
    completo = os.path.abspath(p)
    if not os.path.isfile(completo):
        raise ErroreFile(f"Il file `{p}` non esiste.",
                         suggerimento=f"Controlla il nome e la cartella: ora sei in `{os.getcwd()}`.")
    stampante = hw.nativo.stampante_predefinita()
    dove = f" sulla stampante `{stampante}`" if stampante else ""
    if not _chiedi(interprete, senza_conferma, f"Vuoi stampare `{os.path.basename(completo)}`{dove}?"):
        return False
    hw.nativo.stampa_file(completo)
    return True


# ===========================================================================
# Registro di Windows
# ===========================================================================


@funzione_libreria("leggi_registro")
def leggi_registro(chiave, nome=""):
    """leggi_registro(chiave, nome = ""): legge un valore del registro di Windows (`nulla` se non c'è).

    La chiave comincia con HKCU, HKLM, HKCR, HKU o HKCC; separa le parti con `/`.
    `nome = ""` legge il valore predefinito della chiave.
    Esempio: `leggi_registro("HKLM/SOFTWARE/Microsoft/Windows NT/CurrentVersion", "ProductName")`.
    """
    k = _testo_non_vuoto(chiave, "leggi_registro", "chiave")
    n = richiedi_testo(nome, "leggi_registro", "nome")
    return hw.leggi_registro(k, n)


@funzione_libreria("elenca_chiavi_registro")
def elenca_chiavi_registro(chiave):
    """elenca_chiavi_registro(chiave): i nomi delle sottochiavi di una chiave del registro.

    Esempio: `stampa(elenca_chiavi_registro("HKCU/Software"))`.
    """
    k = _testo_non_vuoto(chiave, "elenca_chiavi_registro", "chiave")
    hw.richiedi_windows("elenca_chiavi_registro")
    radice, sotto = hw.dividi_chiave(k)
    return hw.nativo.reg_chiavi(radice, sotto)


@funzione_libreria("elenca_valori_registro")
def elenca_valori_registro(chiave):
    """elenca_valori_registro(chiave): i valori di una chiave del registro, in un dizionario nome -> valore.

    Esempio: `stampa(elenca_valori_registro("HKCU/Control Panel/Desktop"))`.
    """
    k = _testo_non_vuoto(chiave, "elenca_valori_registro", "chiave")
    return hw.elenca_valori_registro(k)


@funzione_libreria("esiste_chiave_registro")
def esiste_chiave_registro(chiave):
    """esiste_chiave_registro(chiave): `vero` se la chiave del registro esiste.

    Esempio: `se esiste_chiave_registro("HKCU/Software/MioProgramma") allora stampa("esiste") fine`.
    """
    k = _testo_non_vuoto(chiave, "esiste_chiave_registro", "chiave")
    hw.richiedi_windows("esiste_chiave_registro")
    radice, sotto = hw.dividi_chiave(k)
    return hw.nativo.reg_esiste(radice, sotto)


@funzione_libreria("scrivi_registro", interprete=True)
def scrivi_registro(interprete, chiave, nome, valore, senza_conferma=False):
    """scrivi_registro(chiave, nome, valore, senza_conferma = falso): scrive un valore nel registro (solo HKCU).

    Crea la chiave se manca. Testi, interi, `vero`/`falso` e liste di testi. Chiede conferma;
    restituisce `vero` se scritto. Esempio: `scrivi_registro("HKCU/Software/MioProgramma", "tema", "scuro")`.
    """
    k = _testo_non_vuoto(chiave, "scrivi_registro", "chiave")
    n = richiedi_testo(nome, "scrivi_registro", "nome")
    richiedi_logico(senza_conferma, "scrivi_registro", "senza_conferma")
    radice, sotto = hw.controlla_scrittura(k)
    hw.valore_per_registro(valore)  # controlla il valore prima di chiedere
    hw.richiedi_windows("scrivi_registro")
    etichetta = f"`{n}`" if n else "il valore predefinito"
    if not _chiedi(interprete, senza_conferma, f"Vuoi scrivere {etichetta} nel registro di Windows, "
                                               f"nella chiave `HKCU\\{sotto}`?"):
        return False
    hw.scrivi_registro(k, n, valore)
    return True


@funzione_libreria("elimina_valore_registro", interprete=True)
def elimina_valore_registro(interprete, chiave, nome, senza_conferma=False):
    """elimina_valore_registro(chiave, nome, senza_conferma = falso): cancella un valore del registro (solo HKCU).

    Chiede conferma; `vero` se cancellato, `falso` se non c'era o l'utente ha detto No.
    Esempio: `elimina_valore_registro("HKCU/Software/MioProgramma", "tema")`.
    """
    k = _testo_non_vuoto(chiave, "elimina_valore_registro", "chiave")
    n = richiedi_testo(nome, "elimina_valore_registro", "nome")
    richiedi_logico(senza_conferma, "elimina_valore_registro", "senza_conferma")
    radice, sotto = hw.controlla_scrittura(k)
    hw.richiedi_windows("elimina_valore_registro")
    if hw.nativo.reg_leggi(radice, sotto, n) is None:
        return False
    if not _chiedi(interprete, senza_conferma, f"Vuoi cancellare il valore `{n}` dal registro di Windows "
                                               f"(chiave `HKCU\\{sotto}`)?"):
        return False
    return hw.nativo.reg_elimina_valore(radice, sotto, n)


@funzione_libreria("elimina_chiave_registro", interprete=True)
def elimina_chiave_registro(interprete, chiave, senza_conferma=False):
    """elimina_chiave_registro(chiave, senza_conferma = falso): cancella una chiave vuota di sottochiavi (solo HKCU).

    Per sicurezza non cancella chiavi che ne contengono altre. Chiede conferma.
    Esempio: `elimina_chiave_registro("HKCU/Software/MioProgramma")`.
    """
    k = _testo_non_vuoto(chiave, "elimina_chiave_registro", "chiave")
    richiedi_logico(senza_conferma, "elimina_chiave_registro", "senza_conferma")
    radice, sotto = hw.controlla_scrittura(k)
    if "\\" not in sotto:
        raise ErroreValore(f"Non elimino la chiave principale `HKCU\\{sotto}`.",
                           suggerimento="Elimina solo le chiavi del tuo programma, per esempio "
                                        "\"HKCU/Software/MioProgramma\".")
    hw.richiedi_windows("elimina_chiave_registro")
    if not hw.nativo.reg_esiste(radice, sotto):
        return False
    if not _chiedi(interprete, senza_conferma, f"Vuoi eliminare la chiave `HKCU\\{sotto}` dal registro di Windows?"):
        return False
    return hw.nativo.reg_elimina_chiave(radice, sotto)


# ===========================================================================
# Servizi (solo lettura)
# ===========================================================================


@funzione_libreria("elenca_servizi")
def elenca_servizi(solo_attivi=False):
    """elenca_servizi(solo_attivi = falso): i servizi di Windows con `nome`, `nome_visualizzato`, `stato`, `avvio`.

    `stato` è per esempio "in esecuzione" o "fermo"; `avvio` "automatico", "manuale", "disattivato".
    Esempio: `stampa(lunghezza(elenca_servizi(solo_attivi = vero)))`.
    """
    richiedi_logico(solo_attivi, "elenca_servizi", "solo_attivi")
    servizi = hw.elenca_servizi()
    if solo_attivi:
        servizi = [s for s in servizi if s["stato"] == "in esecuzione"]
    return servizi


@funzione_libreria("stato_servizio")
def stato_servizio(nome):
    """stato_servizio(nome): lo stato di un servizio ("in esecuzione", "fermo", "in pausa"...).

    Esempio: `stampa(stato_servizio("Spooler"))`.
    """
    n = _testo_non_vuoto(nome, "stato_servizio", "nome")
    return hw.trova_servizio(n)["stato"]


@funzione_libreria("servizio_attivo")
def servizio_attivo(nome):
    """servizio_attivo(nome): `vero` se il servizio è in esecuzione.

    Esempio: `se non servizio_attivo("Spooler") allora stampa("Stampa non disponibile") fine`.
    """
    n = _testo_non_vuoto(nome, "servizio_attivo", "nome")
    hw.richiedi_windows("servizio_attivo")
    return hw.trova_servizio(n)["stato"] == "in esecuzione"


# ===========================================================================
# Utente, orologio
# ===========================================================================


@funzione_libreria("e_amministratore")
def e_amministratore():
    """e_amministratore(): `vero` se il programma gira con i permessi di amministratore.

    Esempio: `se non e_amministratore() allora stampa("Servono i permessi di amministratore") fine`.
    """
    hw.richiedi_windows("e_amministratore")
    return hw.nativo.e_amministratore()


@funzione_libreria("info_sessione")
def info_sessione():
    """info_sessione(): l'utente collegato: `utente`, `dominio`, `computer`, `amministratore`, `sessione_remota`, `cartella_profilo`.

    Esempio: `stampa(info_sessione()["dominio"])`.
    """
    return hw.info_sessione()


@funzione_libreria("fuso_orario")
def fuso_orario():
    """fuso_orario(): il fuso orario: `nome`, `scarto_ore` rispetto a UTC, `ora_legale`, `id` di Windows.

    Esempio: `stampa("UTC + {fuso_orario()["scarto_ore"]}")`.
    """
    return hw.fuso_orario()


@funzione_libreria("ora_utc")
def ora_utc():
    """ora_utc(): data e ora attuali in UTC (tempo universale), come `data`.

    Esempio: `stampa(ora_utc())`.
    """
    return DataDante(hw.ora_utc())


@funzione_libreria("sincronizzazione_ora")
def sincronizzazione_ora():
    """sincronizzazione_ora(): come Windows tiene giusto l'orologio: `attiva`, `tipo`, `server`, `servizio`.

    Solo lettura. Esempio: `stampa(sincronizzazione_ora()["server"])`.
    """
    return hw.sincronizzazione_ora()


# ===========================================================================
# Caratteri, hardware, USB
# ===========================================================================


@funzione_libreria("elenca_caratteri")
def elenca_caratteri():
    """elenca_caratteri(): i nomi dei caratteri (font) installati, in ordine alfabetico.

    Esempio: `stampa(lunghezza(elenca_caratteri()), "caratteri installati")`.
    """
    return hw.elenca_caratteri()


@funzione_libreria("carattere_installato")
def carattere_installato(nome):
    """carattere_installato(nome): `vero` se un carattere (font) con quel nome è installato.

    Basta la famiglia: "Arial" trova anche "Arial Bold". Esempio: `carattere_installato("Consolas")`.
    """
    n = _testo_non_vuoto(nome, "carattere_installato", "nome").strip().lower()
    hw.richiedi_windows("carattere_installato")
    for c in hw.elenca_caratteri():
        c = c.lower()
        if c == n or c.startswith(n + " "):
            return True
    return False


@funzione_libreria("info_processore")
def info_processore():
    """info_processore(): il processore: `nome`, `produttore`, `core`, `processori_logici`, `frequenza_mhz`, `bit`.

    Esempio: `stampa(info_processore()["nome"])`.
    """
    return hw.info_processore()


@funzione_libreria("info_scheda_madre")
def info_scheda_madre():
    """info_scheda_madre(): la scheda madre e il BIOS: `produttore`, `modello`, `versione`, `bios_produttore`, `bios_versione`.

    Esempio: `stampa(info_scheda_madre()["modello"])`.
    """
    return hw.info_scheda_madre()


@funzione_libreria("info_schede_video")
def info_schede_video():
    """info_schede_video(): le schede video (GPU): lista con `nome`, `produttore`, `memoria`, `driver`, `risoluzione`.

    Esempio: `per ogni g in info_schede_video() fai stampa(g["nome"]) fine`.
    """
    return hw.info_schede_video()


@funzione_libreria("info_computer")
def info_computer():
    """info_computer(): il computer: `nome`, `produttore`, `modello`, `memoria`, `sistema_operativo`, `versione`...

    Esempio: `variabile c = info_computer()` e `stampa(c["produttore"], c["modello"])`.
    """
    return hw.info_computer()


@funzione_libreria("dispositivi_usb")
def dispositivi_usb():
    """dispositivi_usb(): i dispositivi USB collegati: lista con `nome`, `classe`, `stato`, `id`.

    Esempio: `per ogni d in dispositivi_usb() fai stampa(d["nome"]) fine`.
    """
    return hw.dispositivi_usb()
