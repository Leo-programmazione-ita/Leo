"""Libreria: funzioni "superpotere" che lavorano su intere liste.

``mappa``, ``filtra``, ``riduci``, ``ordina_per``, ``raggruppa_per``,
``conta_se``, ``tutti``, ``almeno_uno``, ``accoppia``, ``enumera``.

Ricevono una lista (oppure un intervallo, un testo o un dizionario, che si
percorrono come con ``per ogni``) e, dove serve, una funzione da applicare a
ogni elemento: una funzione scritta dall'utente, una funzione anonima
(``funzione (x) restituisci x * 2 fine``) o una funzione della libreria
(``mappa(numeri, testo)``). Nessuna di queste funzioni modifica la lista
ricevuta: restituiscono sempre un valore nuovo.
"""

from __future__ import annotations

from typing import Any

from ..errori import ErroreTipo, ErroreValore
from ..valori import Richiamabile, e_numero, rappresenta, verifica_chiave
from .generali import (articolo, funzione_libreria, lunghezza_intervallo, mostra, richiedi_intero,
                       richiedi_logico, tipi)

_PERCORRIBILI = "una lista, un intervallo, un testo o un dizionario"
#: Oltre questo numero di elementi un intervallo non si trasforma in lista (memoria).
MASSIMO_INTERVALLO = 10_000_000


def chiama_funzione(interprete: Any, f: Richiamabile, argomenti: list) -> Any:
    """Chiama la funzione Leo ``f`` passando dall'interprete (o direttamente se è un finto)."""
    chiama = getattr(interprete, "chiama", None)
    if chiama is not None:
        return chiama(f, argomenti)
    return f.chiama(interprete, list(argomenti), {})


def _chiamante(interprete: Any, f: Richiamabile):
    chiamante = getattr(interprete, "chiamante", None)
    if chiamante is not None:  # l'interprete vero: via veloce per le funzioni Leo pure
        return chiamante(f)
    chiama = getattr(interprete, "chiama", None)
    if chiama is not None:
        return lambda argomenti: chiama(f, argomenti)
    return lambda argomenti: f.chiama(interprete, list(argomenti), {})


def elementi(valore: Any, nome_funzione: str, parametro: str = "lista") -> list:
    """Gli elementi di ``valore`` come lista Python (come li percorre ``per ogni``)."""
    if isinstance(valore, list):
        return valore
    if isinstance(valore, range):
        if lunghezza_intervallo(valore) > MASSIMO_INTERVALLO:
            raise ErroreValore(f"L'intervallo è troppo grande per `{nome_funzione}` "
                               f"(al massimo {MASSIMO_INTERVALLO} elementi).")
        return list(valore)
    if isinstance(valore, str):
        return list(valore)
    if isinstance(valore, dict):
        return list(valore.keys())
    raise ErroreTipo(f"L'argomento `{parametro}` di `{nome_funzione}` deve essere {_PERCORRIBILI}, "
                     f"non {articolo(valore)}.")


def richiedi_funzione(valore: Any, nome_funzione: str, parametro: str = "funzione") -> Richiamabile:
    """Controlla che ``valore`` sia una funzione Leo."""
    if isinstance(valore, Richiamabile):
        return valore
    raise ErroreTipo(
        f"L'argomento `{parametro}` di `{nome_funzione}` deve essere una funzione, non {articolo(valore)}.",
        suggerimento=f"Per esempio: `{nome_funzione}(lista, funzione (x) restituisci x * 2 fine)`, "
                     "oppure il nome di una funzione che hai creato tu.")


def _logico(risultato: Any, nome_funzione: str, elemento: Any) -> bool:
    if isinstance(risultato, bool):
        return risultato
    raise ErroreTipo(
        f"La funzione data a `{nome_funzione}` deve restituire `vero` o `falso`, "
        f"ma per l'elemento {mostra(elemento)} ha restituito {articolo(risultato)} ({mostra(risultato)}).",
        suggerimento="Scrivi una condizione, per esempio `restituisci x > 10`.")


@funzione_libreria("mappa", interprete=True)
def mappa(interprete, lista, funzione):
    """mappa(lista, funzione): una nuova lista con la funzione applicata a ogni elemento.

    Esempio: `mappa([1, 2, 3], funzione (x) restituisci x * 10 fine)` è [10, 20, 30].
    """
    dati = elementi(lista, "mappa")
    f = richiedi_funzione(funzione, "mappa")
    chiama = _chiamante(interprete, f)
    return [chiama([x]) for x in list(dati)]


@funzione_libreria("filtra", interprete=True)
def filtra(interprete, lista, funzione):
    """filtra(lista, funzione): una nuova lista con solo gli elementi per cui la funzione dà `vero`.

    Esempio: `filtra([5, 12, 8, 20], funzione (x) restituisci x > 10 fine)` è [12, 20].
    """
    dati = elementi(lista, "filtra")
    f = richiedi_funzione(funzione, "filtra")
    chiama = _chiamante(interprete, f)
    return [x for x in list(dati) if _logico(chiama([x]), "filtra", x)]


_NESSUNO = object()


@funzione_libreria("riduci", interprete=True)
def riduci(interprete, lista, funzione, iniziale=_NESSUNO):
    """riduci(lista, funzione, iniziale): combina tutti gli elementi in un solo valore.

    La funzione riceve il risultato "fin qui" e l'elemento successivo.
    Esempio: `riduci([1, 2, 3, 4], funzione (tot, x) restituisci tot + x fine)` è 10.
    Con `iniziale` si sceglie da dove partire: `riduci(parole, f, iniziale = "")`.
    """
    dati = list(elementi(lista, "riduci"))
    f = richiedi_funzione(funzione, "riduci")
    if iniziale is _NESSUNO:
        if not dati:
            raise ErroreValore("Non posso `riduci`re una lista vuota senza un valore `iniziale`.",
                               suggerimento="Aggiungi il punto di partenza: `riduci(lista, f, iniziale = 0)`.")
        risultato, resto = dati[0], dati[1:]
    else:
        risultato, resto = iniziale, dati
    chiama = _chiamante(interprete, f)
    for x in resto:
        risultato = chiama([risultato, x])
    return risultato


def _chiave_ordinabile(valori: list, nome_funzione: str) -> None:
    presenti = tipi(valori)
    if presenti == {str} or presenti == {bool} or not valori:
        return
    if presenti <= {int, float} or all(e_numero(v) for v in valori):
        if float in presenti and any(v != v for v in valori):
            raise ErroreValore(f"`{nome_funzione}` non può ordinare usando `non_numero`.")
        return
    if all(isinstance(v, str) for v in valori) or all(isinstance(v, bool) for v in valori):
        return
    for v in valori:
        if not (e_numero(v) or isinstance(v, (str, bool))):
            raise ErroreTipo(f"La funzione data a `{nome_funzione}` deve restituire numeri o testi, "
                             f"ma ha restituito {articolo(v)}.")
    raise ErroreTipo(f"La funzione data a `{nome_funzione}` ha restituito numeri e testi mescolati: "
                     "non so come metterli in ordine.",
                     suggerimento="Fai restituire sempre numeri oppure sempre testi.")


@funzione_libreria("ordina_per", interprete=True)
def ordina_per(interprete, lista, funzione, decrescente=False):
    """ordina_per(lista, funzione, decrescente = falso): una nuova lista ordinata secondo la funzione.

    La funzione dice "quanto vale" ogni elemento. A parità di valore l'ordine resta quello di prima.
    Esempio: `ordina_per(["banana", "fico", "kiwi"], lunghezza)` è ["fico", "kiwi", "banana"]
    (ordinati per numero di lettere).
    """
    dati = list(elementi(lista, "ordina_per"))
    f = richiedi_funzione(funzione, "ordina_per")
    richiedi_logico(decrescente, "ordina_per", "decrescente")
    chiama = _chiamante(interprete, f)
    chiavi = [chiama([x]) for x in dati]
    _chiave_ordinabile(chiavi, "ordina_per")
    posizioni = sorted(range(len(dati)), key=chiavi.__getitem__, reverse=decrescente)
    return [dati[i] for i in posizioni]


@funzione_libreria("raggruppa_per", interprete=True)
def raggruppa_per(interprete, lista, funzione):
    """raggruppa_per(lista, funzione): un dizionario che mette insieme gli elementi con lo stesso valore.

    Esempio: `raggruppa_per([1, 2, 3, 4], funzione (x) restituisci x % 2 == 0 fine)`
    è {falso: [1, 3], vero: [2, 4]}.
    """
    dati = elementi(lista, "raggruppa_per")
    f = richiedi_funzione(funzione, "raggruppa_per")
    chiama = _chiamante(interprete, f)
    gruppi: dict = {}
    for x in list(dati):
        chiave = chiama([x])
        try:
            verifica_chiave(chiave)
        except ErroreTipo:
            raise ErroreTipo(f"La funzione data a `raggruppa_per` deve restituire un testo, un intero o un logico "
                             f"(diventa il nome del gruppo), non {articolo(chiave)}.") from None
        gruppo = gruppi.get(chiave)
        if gruppo is not None:
            gemella = next(k for k in gruppi if k == chiave)
            if isinstance(gemella, bool) != isinstance(chiave, bool):
                # per Python vero == 1 e falso == 0: in Leo sono gruppi diversi, che
                # pero' un dizionario non puo' tenere insieme (come `d[vero] = ...`)
                raise ErroreValore(
                    f"La funzione data a `raggruppa_per` ha dato sia {rappresenta(gemella, dentro=True)} "
                    f"sia {rappresenta(chiave, dentro=True)}: un dizionario non può avere insieme "
                    "queste due chiavi.",
                    suggerimento="Fai restituire alla funzione valori dello stesso tipo, per esempio solo "
                                 "logici o solo testi.")
            gruppo.append(x)
        else:
            gruppi[chiave] = [x]
    return gruppi


@funzione_libreria("conta_se", interprete=True)
def conta_se(interprete, lista, funzione):
    """conta_se(lista, funzione): quanti elementi fanno dare `vero` alla funzione.

    Esempio: `conta_se([18, 30, 24, 30], funzione (v) restituisci v == 30 fine)` è 2.
    """
    dati = elementi(lista, "conta_se")
    f = richiedi_funzione(funzione, "conta_se")
    chiama = _chiamante(interprete, f)
    return sum(1 for x in list(dati) if _logico(chiama([x]), "conta_se", x))


def _ogni_logico(interprete, lista, funzione, nome: str, cerco: bool) -> bool:
    dati = elementi(lista, nome)
    if funzione is None:
        for x in dati:
            if not isinstance(x, bool):
                raise ErroreTipo(f"Senza funzione, `{nome}` vuole una lista di `vero`/`falso`, "
                                 f"ma c'è {articolo(x)}.",
                                 suggerimento=f"Aggiungi una condizione: `{nome}(lista, funzione (x) "
                                              "restituisci x > 0 fine)`.")
            if x is cerco:
                return cerco
        return not cerco
    f = richiedi_funzione(funzione, nome)
    chiama = _chiamante(interprete, f)
    for x in list(dati):  # si ferma al primo elemento che decide la risposta
        if _logico(chiama([x]), nome, x) is cerco:
            return cerco
    return not cerco


@funzione_libreria("tutti", interprete=True)
def tutti(interprete, lista, funzione=None):
    """tutti(lista, funzione): `vero` se la funzione dà `vero` per tutti gli elementi.

    Esempio: `tutti(voti, funzione (v) restituisci v >= 18 fine)`. Senza funzione controlla
    una lista di `vero`/`falso`. Una lista vuota dà `vero`.
    """
    return _ogni_logico(interprete, lista, funzione, "tutti", False)


@funzione_libreria("almeno_uno", interprete=True)
def almeno_uno(interprete, lista, funzione=None):
    """almeno_uno(lista, funzione): `vero` se la funzione dà `vero` per almeno un elemento.

    Esempio: `almeno_uno(voti, funzione (v) restituisci v == 30 fine)`. Una lista vuota dà `falso`.
    """
    return _ogni_logico(interprete, lista, funzione, "almeno_uno", True)


@funzione_libreria("accoppia")
def accoppia(*liste):
    """accoppia(lista1, lista2, ...): mette insieme gli elementi nella stessa posizione.

    Esempio: `accoppia(["Ada", "Bruno"], [30, 28])` è [["Ada", 30], ["Bruno", 28]].
    Se le liste sono lunghe diverse si ferma alla più corta.
    """
    if len(liste) < 2:
        raise ErroreTipo(f"`accoppia` vuole almeno due liste, ma ne ha ricevute {len(liste)}.",
                         suggerimento="Esempio: `accoppia(nomi, voti)`.")
    dati = [elementi(l, "accoppia", f"lista{i + 1}") for i, l in enumerate(liste)]
    return [list(t) for t in zip(*dati)]


@funzione_libreria("enumera")
def enumera(lista, inizio=0):
    """enumera(lista, inizio = 0): coppie [posizione, elemento] per ogni elemento.

    Esempio: `enumera(["a", "b"])` è [[0, "a"], [1, "b"]]; con `inizio = 1` si conta da 1.
    """
    richiedi_intero(inizio, "enumera", "inizio")
    return [[i, x] for i, x in enumerate(elementi(lista, "enumera"), inizio)]
