"""Libreria: la galleria di Leo (personaggi, nemici, oggetti, piastrelle, sfondi, suoni, musiche...).

Nei programmi c'è il valore ``galleria`` con i suoi metodi::

    stampa(galleria.cerca("drago"))              # ["galleria:nemici/drago"]
    galleria.suona("moneta")                     # un suono della galleria
    Immagine1.immagine = galleria.trova("cavaliere")
    stampa(galleria.licenza("galleria:personaggi/cavaliere"))

Un elemento si indica ovunque (proprietà delle finestre, ``suona``, ``carica_suono``...) con
``"galleria:categoria/nome"``; i metodi accettano anche il solo nome (``"cavaliere"``) o il titolo
italiano (``"Moneta d'oro"``). Tutto il lavoro vero è in ``leo/galleria.py``.
"""

from __future__ import annotations

from typing import Any

from ..errori import ErroreTipo
from ..registro import costante
from .generali import articolo
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta


class GalleriaLeo(OggettoLibreria):
    """Il valore ``galleria`` dei programmi."""

    NOME_TIPO_DANTE = "galleria"
    SUGGERIMENTO_MODIFICA = "La galleria non si modifica dai programmi: usa i suoi metodi, come `galleria.cerca(\"drago\")`."

    def __repr__(self) -> str:
        return "<galleria di Leo>"


GALLERIA = GalleriaLeo()
costante("galleria", GALLERIA)


def _g():
    from .. import galleria as G

    return G


def _testo(v: Any, metodo: str, parametro: str = "elemento") -> str:
    if not isinstance(v, str):
        raise ErroreTipo(f"`{parametro}` di `galleria.{metodo}` deve essere un testo, non {articolo(v)}.",
                         suggerimento=f"Per esempio `galleria.{metodo}(\"cavaliere\")`.")
    return v.strip()


def _elemento(v: Any, metodo: str, categoria: str = ""):
    """L'elemento indicato da ``v`` (percorso, nome o titolo); con ``categoria`` si prova prima lì."""
    G = _g()
    testo = _testo(v, metodo)
    g = G.galleria()
    if categoria and not G.e_percorso_galleria(testo) and "/" not in testo:
        try:
            return g.trova(f"{categoria}/{testo}")[0]
        except Exception:  # noqa: BLE001 - si prova nelle altre categorie
            pass
    try:
        return g.trova(testo)[0]
    except Exception:
        risultati = g.elenca(categoria, "", testo) or g.elenca("", "", testo)
        if risultati:
            return risultati[0]
        raise


def _percorso(v: Any, metodo: str) -> str:
    """Il percorso ``galleria:...`` di ``v`` (con l'eventuale animazione)."""
    G = _g()
    testo = _testo(v, metodo)
    if G.e_percorso_galleria(testo):
        G.galleria().trova(testo)            # errore chiaro se non c'è
        return testo
    return _elemento(testo, metodo).percorso


@proprieta(GalleriaLeo, "numero_elementi")
def _numero(_g_: GalleriaLeo) -> int:
    return len(_g().galleria().carica().elementi)


@metodo_oggetto(GalleriaLeo, "cerca")
def cerca(_g_, testo, categoria=""):
    """galleria.cerca(testo, categoria = ""): gli elementi che corrispondono al testo, come percorsi.

    Esempio: `galleria.cerca("drago")` -> `["galleria:nemici/drago"]`; `galleria.cerca("", "suoni")` tutti i suoni.
    """
    t = _testo(testo, "cerca", "testo")
    c = _testo(categoria, "cerca", "categoria")
    return [e.percorso for e in _g().galleria().elenca(c, "", t)]


@metodo_oggetto(GalleriaLeo, "trova")
def trova(_g_, testo):
    """galleria.trova(testo): il primo elemento che corrisponde (percorso "galleria:..."), per le proprietà.

    Esempio: `Immagine1.immagine = galleria.trova("cavaliere")`.
    """
    return _elemento(testo, "trova").percorso


@metodo_oggetto(GalleriaLeo, "categorie")
def categorie(_g_):
    """galleria.categorie(): i nomi delle categorie che hanno elementi (personaggi, nemici, suoni...)."""
    return [c["nome"] for c in _g().galleria().categorie() if c["quanti"]]


@metodo_oggetto(GalleriaLeo, "elementi")
def elementi(_g_, categoria):
    """galleria.elementi(categoria): tutti gli elementi di una categoria, come percorsi.

    Esempio: `per ogni elem in galleria.elementi("personaggi") fai stampa(elem) fine`.
    """
    c = _testo(categoria, "elementi", "categoria")
    G = _g()
    g = G.galleria().carica()
    nome = G.nome_elemento(c)
    if nome not in {x["nome"] for x in g.categorie()}:
        from ..errori import ErroreValore

        raise ErroreValore(f"Nella galleria non c'è la categoria `{c}`.",
                           suggerimento="Le categorie sono: " + ", ".join(categorie(None)) + ".")
    return [e.percorso for e in g.elenca(nome)]


@metodo_oggetto(GalleriaLeo, "file")
def file(_g_, elemento):
    """galleria.file(elemento): il file vero dell'elemento sul disco (lo estrae dal pacchetto se serve).

    Esempio: `galleria.file("moneta")`.
    """
    G = _g()
    return str(G.risolvi(_percorso(elemento, "file")))


@metodo_oggetto(GalleriaLeo, "percorso")
def percorso(_g_, elemento):
    """galleria.percorso(elemento): il percorso del file vero sul disco (come `galleria.file`).

    Utile per le funzioni che vogliono un file, per esempio `leggi_byte(galleria.percorso("moneta"))`.
    Un elemento extra non ancora scaricato dà un errore che spiega come scaricarlo dalla Galleria.
    """
    return file(_g_, elemento)


@metodo_oggetto(GalleriaLeo, "fotogrammi")
def fotogrammi(_g_, elemento):
    """galleria.fotogrammi(elemento): i file dei fotogrammi di un'animazione (per animare un personaggio).

    Esempio: `galleria.fotogrammi("galleria:personaggi/cavaliere/cammina")`.
    """
    G = _g()
    return [str(p) for p in G.fotogrammi(_percorso(elemento, "fotogrammi"))]


@metodo_oggetto(GalleriaLeo, "info")
def info(_g_, elemento):
    """galleria.info(elemento): un dizionario con titolo, categoria, licenza, autore, stato e animazioni.

    Esempio: `stampa(galleria.info("drago")["licenza"])`.
    """
    G = _g()
    g = G.galleria()
    e = _elemento(elemento, "info")
    return {"percorso": e.percorso, "titolo": e.titolo, "categoria": e.categoria, "sottocategoria": e.sottocategoria,
            "tipo": e.tipo, "licenza": e.licenza, "autore": e.autore, "fonte": e.fonte, "stato": g.stato(e),
            "pacchetto": e.pacchetto, "animazioni": list(e.animazioni), "parole": list(e.parole),
            "extra": bool(e.extra), "peso": e.peso, "provenienza": e.marchio}


@metodo_oggetto(GalleriaLeo, "licenza")
def licenza(_g_, elemento):
    """galleria.licenza(elemento): licenza e autore dell'elemento, in una riga.

    Esempio: `stampa(galleria.licenza("cavaliere"))`.
    """
    e = _elemento(elemento, "licenza")
    return f"{e.titolo}: {e.licenza or 'licenza non indicata'} - {e.autore or 'autore non indicato'}" + \
        (f" ({e.fonte})" if e.fonte else "") + (f" - {e.marchio}" if e.marchio else "")


@metodo_oggetto(GalleriaLeo, "crediti")
def crediti(_g_, elementi=None):
    """galleria.crediti(elementi = nulla): il testo dei crediti (autore e licenza) degli elementi indicati o di tutti."""
    G = _g()
    g = G.galleria()
    if elementi is None:
        return g.crediti()
    if not isinstance(elementi, list):
        elementi = [elementi]
    return g.crediti([_elemento(x, "crediti").id for x in elementi])


@metodo_oggetto(GalleriaLeo, "suona", interprete=True)
def suona(interprete, _g_, suono, aspetta=False):
    """galleria.suona(suono, aspetta = falso): fa sentire un suono o una musica della galleria.

    Esempio: `galleria.suona("moneta")`.
    """
    e = _elemento(suono, "suona", "suoni")
    if e.tipo not in ("suono", "musica"):
        from ..errori import ErroreValore

        raise ErroreValore(f"`{e.titolo}` non è un suono.",
                           suggerimento="Cerca i suoni con `galleria.cerca(\"\", \"suoni\")`.")
    if _suona_sul_telefono(interprete, e.percorso):
        return None
    from .suoni import suona_file

    return suona_file(interprete, e.percorso, aspetta)


def _suona_sul_telefono(interprete: Any, percorso: str) -> bool:
    """Sul telefono, in un programma con finestre, il suono lo fa l'app (come il controllo Suono)."""
    from ..piattaforma import e_android

    programma = getattr(getattr(interprete, "ponte_grafico", None), "_programma", None)
    finestre = getattr(programma, "finestre", None)
    if not e_android() or not isinstance(finestre, dict):
        return False
    finestra = next((f for f in finestre.values() if getattr(f, "aperta", False)), None)
    if finestra is None:
        return False
    from ..grafica.web.hardware import richiedi

    vero = str(_g().risolvi(percorso, getattr(programma, "cartella", None)))
    richiedi(programma, finestra, "", {"azione": "suono", "file": vero, "volume": 1.0, "ripeti": False})
    return True


@metodo_oggetto(GalleriaLeo, "pacchetti")
def pacchetti(_g_):
    """galleria.pacchetti(): i pacchetti della galleria con il loro stato (pronto, da aprire, nuvola, scaricato)."""
    G = _g()
    g = G.galleria().carica()
    uscita = []
    for p in g.pacchetti.values():
        pronto = g.pacchetto_pronto(p.nome)
        stato = ("scaricato" if pronto else "nuvola") if p.tipo == "nuvola" else ("pronto" if pronto else "da aprire")
        voce = {"nome": p.nome, "titolo": p.titolo, "elementi": len(p.elementi), "peso": G.formatta_peso(p.peso),
                 "stato": stato}
        if p.tipo == "nuvola":
            voce["scaricati"] = len(p.elementi) - len(g.da_scaricare(p.nome))
            if p.marchio:
                voce["provenienza"] = p.marchio
        uscita.append(voce)
    return uscita
