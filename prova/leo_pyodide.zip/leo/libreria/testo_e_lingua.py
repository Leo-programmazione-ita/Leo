"""Libreria: testo, lingua italiana e formati di testo.

Trenta funzioni che completano i metodi dei testi (``testi.py``) e i modelli
(``modelli.py``, ``modelli_testo.py``) senza ripeterli:

* **numeri e parole**: ``numero_in_lettere``, ``euro_in_lettere`` (anche per gli
  assegni), ``lettere_in_numero``, ``ordinale_in_lettere``, ``data_in_parole``;
* **lingua italiana**: ``sillabe``, ``plurale``, ``con_articolo``,
  ``togli_accenti``, ``indice_gulpease``;
* **contare**: ``conta_parole``, ``conta_occorrenze``, ``frequenza_parole``,
  ``statistiche_testo``;
* **confrontare**: ``somiglianza``, ``differenze_testi``, ``forse_cercavi``,
  ``sono_anagrammi``, ``e_palindromo``;
* **impaginare**: ``vai_a_capo``, ``incolonna``, ``riempi_segnaposti``,
  ``testo_a_url``, ``censura``;
* **formati**: ``markdown_a_html``, ``html_a_testo``, ``da_xml``, ``a_xml``,
  ``da_yaml``, ``a_yaml``.

Solo libreria standard di Python (difflib, unicodedata, textwrap, html,
xml.etree): funziona anche su Android e negli .exe. Per YAML c'è un lettore e
scrittore del sottoinsieme comune; se il lettore non capisce il testo e PyYAML
è installato, si prova con quello.
"""

from __future__ import annotations

import datetime
import difflib
import html as _html
import re
import textwrap
import unicodedata
from collections import Counter
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from html.parser import HTMLParser
from typing import Any

from ..errori import ErroreTipo, ErroreValore
from ..valori import e_intero, e_numero, rappresenta
from .date import GIORNI, MESI, richiedi_data
from .generali import (articolo, funzione_libreria, lunghezza_intervallo, mostra, richiedi_intero,
                       richiedi_logico, richiedi_numero, richiedi_testo)

# ===========================================================================
# Strumenti comuni
# ===========================================================================

#: Testi più lunghi di così non si elaborano con gli algoritmi lenti (sillabe, differenze...).
_MASSIMO_TESTO = 5_000_000


def _testo(valore: Any, funzione: str, parametro: str) -> str:
    richiedi_testo(valore, funzione, parametro)
    if len(valore) > _MASSIMO_TESTO:
        raise ErroreValore(f"Il testo passato a `{funzione}` è troppo lungo ({len(valore)} caratteri).",
                           suggerimento="Dividilo in pezzi più piccoli.")
    return valore


def _senza_segni(testo: str) -> str:
    """Il testo senza accenti e altri segni sulle lettere."""
    scomposto = unicodedata.normalize("NFD", testo)
    return unicodedata.normalize("NFC", "".join(c for c in scomposto if unicodedata.category(c) != "Mn"))


def _chiave(testo: str) -> str:
    """Forma per i confronti: minuscolo e senza accenti."""
    return _senza_segni(testo).lower()


_PAROLA = re.compile(r"\d+(?:[.,]\d+)*|[^\W\d_]+")
_SOLO_LETTERE = re.compile(r"[^\W\d_]+")
_FINE_FRASE = re.compile(r"[.!?…]+")


def _parole(testo: str) -> list[str]:
    return _PAROLA.findall(testo)


def _conta_frasi(testo: str) -> int:
    return sum(1 for pezzo in _FINE_FRASE.split(testo) if _PAROLA.search(pezzo))


def _logico(valore: Any, funzione: str, parametro: str) -> bool:
    return richiedi_logico(valore, funzione, parametro)


# ===========================================================================
# Numeri in lettere
# ===========================================================================

_UNITA = ["zero", "uno", "due", "tre", "quattro", "cinque", "sei", "sette", "otto", "nove", "dieci",
          "undici", "dodici", "tredici", "quattordici", "quindici", "sedici", "diciassette", "diciotto",
          "diciannove"]
_DECINE = ["", "", "venti", "trenta", "quaranta", "cinquanta", "sessanta", "settanta", "ottanta", "novanta"]
#: (valore, singolare, plurale) dal più grande.
_SCALE = [(10 ** 21, "triliardo", "triliardi"), (10 ** 18, "trilione", "trilioni"),
          (10 ** 15, "biliardo", "biliardi"), (10 ** 12, "bilione", "bilioni"),
          (10 ** 9, "miliardo", "miliardi"), (10 ** 6, "milione", "milioni")]
_MASSIMO_NUMERO = 10 ** 24 - 1


def _accento(parola: str) -> str:
    """ventitre -> ventitré (solo in fondo alla parola, non per "tre" da solo)."""
    if parola.endswith("tre") and len(parola) > 3:
        return parola[:-1] + "é"
    return parola


def _fino_a_999(n: int) -> str:
    centinaia, resto = divmod(n, 100)
    parola = ""
    if centinaia:
        parola = ("" if centinaia == 1 else _UNITA[centinaia]) + "cento"
    if resto:
        if resto < 20:
            pezzo = _UNITA[resto]
        else:
            decina, unita = divmod(resto, 10)
            dec = _DECINE[decina]
            if unita in (1, 8):  # ventuno, ventotto
                dec = dec[:-1]
            pezzo = dec + (_UNITA[unita] if unita else "")
        if centinaia and resto // 10 == 8:  # centottanta
            parola = parola[:-1]
        parola += pezzo
    return parola


def _moltiplicatore(n: int) -> str:
    """Il numero davanti a "mila"/"milioni": ventuno -> ventun."""
    parola = _fino_a_999(n)
    return parola[:-1] if parola.endswith("uno") else parola


def _sotto_milione(n: int) -> str:
    migliaia, resto = divmod(n, 1000)
    parola = ""
    if migliaia == 1:
        parola = "mille"
    elif migliaia:
        parola = _moltiplicatore(migliaia) + "mila"
    if resto:
        parola += _fino_a_999(resto)
    return _accento(parola)


def _intero_in_lettere(n: int, unito: bool = False) -> str:
    if n == 0:
        return "zero"
    parti = []
    for valore, singolare, plurale in _SCALE:
        quanti, n = divmod(n, valore)
        if quanti == 1:
            parti.append("un" + ("" if unito else " ") + singolare)
        elif quanti:
            parti.append(_accento(_moltiplicatore(quanti)) + ("" if unito else " ") + plurale)
    if n:
        parti.append(_sotto_milione(n))
    return ("" if unito else " ").join(parti)


def _numero_grande(n: Any) -> ErroreValore:
    return ErroreValore(f"Il numero {mostra(n)} è troppo grande da scrivere in lettere.",
                        suggerimento="Arrivo fino a 999 triliardi (24 cifre).")


def _decimale_esatto(x: float) -> Decimal:
    return Decimal(repr(x))


@funzione_libreria("numero_in_lettere")
def numero_in_lettere(numero):
    """numero_in_lettere(numero): il numero scritto in lettere, in italiano corretto.

    Funziona con gli interi (anche negativi) e con i decimali ("virgola").
    Esempi: `numero_in_lettere(123)` è "centoventitré"; `numero_in_lettere(1281)` è
    "milleduecentottantuno"; `numero_in_lettere(2000000)` è "due milioni";
    `numero_in_lettere(3.14)` è "tre virgola quattordici".
    """
    richiedi_numero(numero, "numero_in_lettere", "numero")
    if isinstance(numero, float):
        if numero != numero or numero in (float("inf"), float("-inf")):
            raise ErroreValore("Non posso scrivere in lettere un numero infinito o `non_numero`.")
        if abs(numero) > _MASSIMO_NUMERO:
            raise _numero_grande(numero)
        cifre = format(_decimale_esatto(abs(numero)), "f")
        intera, _, decimi = cifre.partition(".")
        decimi = decimi.rstrip("0")
        segno = "meno " if numero < 0 and (int(intera) or decimi) else ""
        parole = _intero_in_lettere(int(intera))
        if decimi:
            zeri = len(decimi) - len(decimi.lstrip("0"))
            resto = decimi.lstrip("0")
            dopo = ["zero"] * zeri + ([_intero_in_lettere(int(resto))] if len(resto) <= 24 else
                                     [_UNITA[int(c)] for c in resto])
            parole += " virgola " + " ".join(dopo)
        return segno + parole
    if abs(numero) > _MASSIMO_NUMERO:
        raise _numero_grande(numero)
    return ("meno " if numero < 0 else "") + _intero_in_lettere(abs(numero))


def _importo(valore: Any, funzione: str) -> Decimal:
    if getattr(type(valore), "NOME_TIPO_DANTE", None) == "soldi":
        importo = valore.valore
    else:
        richiedi_numero(valore, funzione, "importo")
        if isinstance(valore, float) and (valore != valore or valore in (float("inf"), float("-inf"))):
            raise ErroreValore("L'importo deve essere un numero vero, non infinito o `non_numero`.")
        importo = _decimale_esatto(valore) if isinstance(valore, float) else Decimal(valore)
    if importo < 0:
        raise ErroreValore("L'importo da scrivere in lettere non può essere negativo.",
                           suggerimento="Togli il segno meno, per esempio con `assoluto(...)`.")
    if importo > _MASSIMO_NUMERO:
        raise _numero_grande(valore)
    return importo.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


@funzione_libreria("euro_in_lettere")
def euro_in_lettere(importo, assegno=False):
    """euro_in_lettere(importo, assegno = falso): un importo in euro scritto in lettere.

    Si arrotonda al centesimo. Con `assegno = vero` si scrive come sugli assegni e sui
    bonifici: tutto attaccato, con i centesimi in cifre dopo la barra.
    Esempi: `euro_in_lettere(1234.56)` è "milleduecentotrentaquattro euro e cinquantasei centesimi";
    `euro_in_lettere(1234.56, assegno = vero)` è "milleduecentotrentaquattro/56".
    Va bene anche un valore `soldi(1234.56)`.
    """
    valore = _importo(importo, "euro_in_lettere")
    per_assegno = _logico(assegno, "euro_in_lettere", "assegno")
    euro = int(valore)
    centesimi = int((valore - euro) * 100)
    if per_assegno:
        return f"{_intero_in_lettere(euro, unito=True)}/{centesimi:02d}"
    if euro == 1:
        parte_euro = "un euro"
    else:
        parte_euro = _intero_in_lettere(euro) + " euro"
    if not centesimi:
        return parte_euro
    parte_cent = "un centesimo" if centesimi == 1 else _intero_in_lettere(centesimi) + " centesimi"
    if euro == 0:
        return parte_cent
    return f"{parte_euro} e {parte_cent}"


# --- dalle lettere al numero ---------------------------------------------------

_PEZZI: dict[str, int] = {"un": 1}
for _i, _p in enumerate(_UNITA[1:], start=1):
    _PEZZI[_p] = _i
for _i, _p in enumerate(_DECINE[2:], start=2):
    _PEZZI[_p] = _i * 10
    _PEZZI[_p[:-1]] = _i * 10
_CENTO = -1
_PEZZI["cento"] = _CENTO
_PEZZI["cent"] = _CENTO
_PEZZI_ORDINATI = sorted(_PEZZI, key=len, reverse=True)


def _pezzi(s: str) -> list[int] | None:
    """Divide "centoventitre" in [cento, venti, tre] (con i valori); `None` se non si può."""
    if len(s) > 40:  # sotto mille non servono parole più lunghe
        return None
    memoria: dict[int, list[int] | None] = {}

    def da(i: int) -> list[int] | None:
        if i == len(s):
            return []
        if i not in memoria:
            memoria[i] = None
            for p in _PEZZI_ORDINATI:
                if s.startswith(p, i):
                    resto = da(i + len(p))
                    if resto is not None:
                        memoria[i] = [_PEZZI[p]] + resto
                        break
        return memoria[i]

    return da(0)


def _leggi_fino_999(s: str) -> int:
    pezzi = _pezzi(s)
    if not pezzi:
        raise ValueError(s)
    # forma ammessa: [unità] cento? [decina [unità]] | [da uno a diciannove]
    totale, i = 0, 0
    if len(pezzi) > 1 and 1 <= pezzi[0] <= 9 and pezzi[1] == _CENTO and pezzi[0] != 1:
        totale, i = pezzi[0] * 100, 2
    elif pezzi[0] == _CENTO:
        totale, i = 100, 1
    if i < len(pezzi) and pezzi[i] >= 20 and pezzi[i] % 10 == 0:
        totale += pezzi[i]
        i += 1
        if i < len(pezzi) and 1 <= pezzi[i] <= 9:
            totale += pezzi[i]
            i += 1
    elif i < len(pezzi) and 1 <= pezzi[i] <= 19:
        totale += pezzi[i]
        i += 1
    if i != len(pezzi):
        raise ValueError(s)
    return totale


def _leggi_intero(s: str) -> int:
    if s == "zero":
        return 0
    for valore, singolare, plurale in _SCALE:
        for forma in (plurale, singolare):
            i = s.find(forma)
            if i >= 0:
                sinistra, destra = s[:i], s[i + len(forma):]
                if sinistra.endswith("un"):
                    sinistra += "o"
                quanti = 1 if sinistra in ("", "uno") else _leggi_fino_999(sinistra)
                resto = _leggi_intero(destra) if destra else 0
                if resto >= valore:
                    raise ValueError(s)
                return quanti * valore + resto
    i = s.find("mila")
    if i >= 0:
        sinistra, destra = s[:i], s[i + 4:]
        if sinistra.endswith("un"):
            sinistra += "o"
        quanti = _leggi_fino_999(sinistra)
        if quanti < 2:
            raise ValueError(s)
        return quanti * 1000 + (_leggi_fino_999(destra) if destra else 0)
    if s.startswith("mille"):
        destra = s[5:]
        return 1000 + (_leggi_fino_999(destra) if destra else 0)
    return _leggi_fino_999(s)


@funzione_libreria("lettere_in_numero")
def lettere_in_numero(testo):
    """lettere_in_numero(testo): il numero scritto in lettere diventa un numero.

    Capisce anche "meno", "virgola" e gli spazi, i trattini o le "e" in mezzo; accenti e maiuscole
    non contano. Esempi: `lettere_in_numero("centoventitré")` è 123;
    `lettere_in_numero("due milioni trecentomila")` è 2300000;
    `lettere_in_numero("tre virgola quattordici")` è 3.14.
    """
    _testo(testo, "lettere_in_numero", "testo")
    parole = [p for p in re.split(r"[\s\-']+", _chiave(testo).strip()) if p and p != "e"]
    originale = testo

    def errore() -> ErroreValore:
        return ErroreValore(f"Non riesco a leggere {mostra(originale)} come numero in lettere.",
                            suggerimento="Scrivilo come \"centoventitré\" o \"tre virgola cinque\". "
                                         "Per un testo in cifre come \"123\" usa `intero(...)`.")

    if not parole or len(testo) > 500:
        raise errore()
    negativo = parole[0] == "meno"
    if negativo:
        parole = parole[1:]
    if "virgola" in parole:
        i = parole.index("virgola")
        prima, dopo = parole[:i], parole[i + 1:]
        if not dopo:
            raise errore()
    else:
        prima, dopo = parole, []
    try:
        intera = _leggi_intero("".join(prima))
        decimi = ""
        while dopo and dopo[0] == "zero":
            decimi += "0"
            dopo = dopo[1:]
        if dopo:
            decimi += str(_leggi_intero("".join(dopo)))
    except (ValueError, RecursionError):
        raise errore() from None
    if decimi:
        valore = float(f"{intera}.{decimi}")
        return -valore if negativo else valore
    return -intera if negativo else intera


_ORDINALI = ["", "primo", "secondo", "terzo", "quarto", "quinto", "sesto", "settimo", "ottavo", "nono", "decimo"]


def _ordinale(n: int) -> str:
    if n <= 10:
        return _ORDINALI[n]
    parola = _intero_in_lettere(n, unito=True)
    if parola.startswith("un") and n in {v for v, _, _ in _SCALE}:
        parola = parola[2:]  # unmilione -> milione(simo)
    if parola.endswith("tré"):
        return parola[:-1] + "eesimo"  # ventitreesimo
    if parola.endswith("sei"):
        return parola + "esimo"  # ventiseiesimo
    if parola.endswith("mila"):
        return parola[:-4] + "millesimo"  # duemillesimo
    return parola[:-1] + "esimo"


@funzione_libreria("ordinale_in_lettere")
def ordinale_in_lettere(numero, femminile=False):
    """ordinale_in_lettere(numero, femminile = falso): il numero ordinale in lettere ("primo", "terzo"...).

    Esempi: `ordinale_in_lettere(3)` è "terzo"; `ordinale_in_lettere(21)` è "ventunesimo";
    `ordinale_in_lettere(23)` è "ventitreesimo"; `ordinale_in_lettere(1, femminile = vero)` è "prima".
    """
    richiedi_intero(numero, "ordinale_in_lettere", "numero")
    femm = _logico(femminile, "ordinale_in_lettere", "femminile")
    if numero < 1:
        raise ErroreValore(f"Gli ordinali partono da 1 (primo), non da {mostra(numero)}.")
    if numero > _MASSIMO_NUMERO:
        raise _numero_grande(numero)
    parola = _ordinale(numero)
    return parola[:-1] + "a" if femm else parola


@funzione_libreria("data_in_parole")
def data_in_parole(d, con_giorno=False):
    """data_in_parole(d, con_giorno = falso): la data tutta in lettere, come nei documenti ufficiali.

    Anche l'anno è in lettere; il primo del mese è "primo". `d` è una data o un testo come "25/12/2026".
    Esempi: `data_in_parole(data(2026, 12, 25))` è "venticinque dicembre duemilaventisei";
    `data_in_parole("1/5/2027", con_giorno = vero)` è "sabato primo maggio duemilaventisette".
    """
    v = richiedi_data(d, "data_in_parole", "d").valore
    giorno = "primo" if v.day == 1 else _intero_in_lettere(v.day)
    testo = f"{giorno} {MESI[v.month - 1]} {_intero_in_lettere(v.year, unito=True)}"
    if _logico(con_giorno, "data_in_parole", "con_giorno"):
        testo = f"{GIORNI[v.weekday()]} {testo}"
    return testo


# ===========================================================================
# Sillabe
# ===========================================================================

_VOCALI = set("aeiouàèéìíòóùúîïü")
_FORTI = set("aeoàèéòóìíùú")  # le vocali accentate i/u sono "forti": fanno iato
_INSIEME = {a + b for a in "bcdfgptv" for b in "r"} | {a + b for a in "bcfgpv" for b in "l"} | {
    "ch", "gh", "gn", "sc"}


def _taglio_consonanti(gruppo: str) -> int:
    """Quante consonanti del gruppo restano nella sillaba prima."""
    if len(gruppo) == 1:
        return 0
    if gruppo[0] == gruppo[1] or gruppo[:2] == "cq":
        return 1
    if gruppo[0] == "s":
        return 0
    if gruppo[0] in "lmnr":
        return 1
    if gruppo in _INSIEME or (len(gruppo) >= 3 and gruppo[:2] in _INSIEME and gruppo[2] in "lr"):
        return 0
    return 1


def _sillabe_parola(parola: str) -> list[str]:
    p = parola.lower()
    n = len(p)
    vocale = [c in _VOCALI for c in p]
    # "i" tra due vocali fa da consonante: a-ia, gua-io
    for i in range(1, n - 1):
        if p[i] == "i" and vocale[i - 1] and vocale[i + 1] and p[i - 1] in "aeouàèéòóù":
            vocale[i] = False
    tagli = []
    i = 0
    # primo nucleo vocalico
    while i < n and not vocale[i]:
        i += 1
    while i < n:
        # nucleo di vocali
        j = i
        while j + 1 < n and vocale[j + 1]:
            if p[j] in _FORTI and p[j + 1] in _FORTI:
                tagli.append(j + 1)
            j += 1
        k = j + 1
        while k < n and not vocale[k]:
            k += 1
        if k >= n:
            break
        gruppo = p[j + 1:k]
        tagli.append(j + 1 + _taglio_consonanti(gruppo))
        i = k
    pezzi, inizio = [], 0
    for t in sorted(set(tagli)):
        if 0 < t < n:
            pezzi.append(parola[inizio:t])
            inizio = t
    pezzi.append(parola[inizio:])
    return [x for x in pezzi if x]


@funzione_libreria("sillabe")
def sillabe(testo, separatore=None):
    """sillabe(testo, separatore = nulla): divide una parola (o una frase) in sillabe, all'italiana.

    Senza separatore restituisce la lista delle sillabe; con un separatore le unisce in un testo.
    Le doppie si dividono (gat-to), la s va con la consonante dopo (ca-sta), le vocali forti
    vicine si separano (pa-e-se). Le parole con l'accento non scritto (mì-a, zì-o) restano unite.
    Esempi: `sillabe("casa")` è ["ca", "sa"]; `sillabe("aiuola", "-")` è "a-iuo-la".
    """
    _testo(testo, "sillabe", "testo")
    if separatore is not None:
        richiedi_testo(separatore, "sillabe", "separatore")
    risultato: list[str] = []
    for parola in _SOLO_LETTERE.findall(testo):
        risultato.extend(_sillabe_parola(parola))
    if separatore is None:
        return risultato
    if len(_SOLO_LETTERE.findall(testo)) <= 1:
        return separatore.join(risultato)
    # frase: il separatore dentro le parole, gli spazi e la punteggiatura restano
    return _SOLO_LETTERE.sub(lambda m: separatore.join(_sillabe_parola(m.group(0))), testo)


# ===========================================================================
# Contare
# ===========================================================================

@funzione_libreria("conta_parole")
def conta_parole(testo):
    """conta_parole(testo): quante parole ci sono nel testo (anche i numeri contano come parole).

    L'apostrofo separa: "l'albero" sono due parole.
    Esempio: `conta_parole("C'era una volta un re.")` è 6.
    """
    return len(_parole(_testo(testo, "conta_parole", "testo")))


@funzione_libreria("conta_occorrenze")
def conta_occorrenze(testo, cosa, ignora_maiuscole=False, parole_intere=False):
    """conta_occorrenze(testo, cosa, ignora_maiuscole = falso, parole_intere = falso): quante volte c'è `cosa`.

    Con `parole_intere = vero` conta solo le parole intere ("re" non si trova in "remo").
    Esempi: `conta_occorrenze("banana", "a")` è 3;
    `conta_occorrenze("Il re e la regina", "re", parole_intere = vero)` è 1.
    """
    _testo(testo, "conta_occorrenze", "testo")
    richiedi_testo(cosa, "conta_occorrenze", "cosa")
    maiuscole = _logico(ignora_maiuscole, "conta_occorrenze", "ignora_maiuscole")
    intere = _logico(parole_intere, "conta_occorrenze", "parole_intere")
    if cosa == "":
        raise ErroreValore("`conta_occorrenze` non può contare un testo vuoto.",
                           suggerimento="Scrivi cosa cercare, per esempio `conta_occorrenze(frase, \"a\")`.")
    if not intere and not maiuscole:
        return testo.count(cosa)
    modello = re.escape(cosa)
    if intere:
        modello = r"(?<!\w)" + modello + r"(?!\w)"
    return len(re.findall(modello, testo, re.IGNORECASE if maiuscole else 0))


_PAROLE_COMUNI = frozenset("""
a ad al allo alla ai agli alle anche avere c che chi ci col come con cui d da dal dallo dalla dai dagli dalle
de dei del dell della delle dello degli di dopo dove e ed è era erano essere fa gli ha hanno ho i il in io l
la le lei li lo loro lui ma mi mia mie miei mio ne negli nei nel nell nella nelle nello noi non nostro o per
perché più poi quale quando quella quelle quelli quello questa queste questi questo se sei si sia siamo sono
su sua sue sui sul sull sulla sulle suo suoi ti tra fra tu tua tue tuo tuoi tutto tutti un una uno vi voi
""".split())


@funzione_libreria("frequenza_parole")
def frequenza_parole(testo, quante=0, togli_comuni=False):
    """frequenza_parole(testo, quante = 0, togli_comuni = falso): quante volte compare ogni parola.

    Restituisce un dizionario parola -> volte, dalla più frequente; le maiuscole non contano.
    `quante` tiene solo le prime (0 = tutte). `togli_comuni = vero` salta articoli,
    preposizioni e congiunzioni ("il", "di", "e"...).
    Esempio: `frequenza_parole("il gatto e il topo e il cane", 2)` è {"il": 3, "e": 2}.
    """
    _testo(testo, "frequenza_parole", "testo")
    richiedi_intero(quante, "frequenza_parole", "quante")
    togli = _logico(togli_comuni, "frequenza_parole", "togli_comuni")
    if quante < 0:
        raise ErroreValore("`quante` non può essere negativo (0 vuol dire tutte).")
    conteggio = Counter(p.lower() for p in _parole(testo))
    if togli:
        for p in list(conteggio):
            if p in _PAROLE_COMUNI:
                del conteggio[p]
    return dict(conteggio.most_common(quante or None))


def _e_vocale(c: str) -> bool:
    return _chiave(c) in "aeiou" and c.isalpha()


@funzione_libreria("statistiche_testo")
def statistiche_testo(testo):
    """statistiche_testo(testo): un dizionario con tutti i conteggi del testo.

    Chiavi: "caratteri", "lettere", "vocali", "consonanti", "cifre", "spazi", "parole",
    "parole_diverse", "frasi", "righe", "sillabe", "lettere_per_parola", "parole_per_frase".
    Esempio: `statistiche_testo("Ciao mondo!")["vocali"]` è 4.
    """
    _testo(testo, "statistiche_testo", "testo")
    lettere = [c for c in testo if c.isalpha()]
    vocali = sum(1 for c in lettere if _e_vocale(c))
    parole = _parole(testo)
    frasi = _conta_frasi(testo)
    lettere_parole = _SOLO_LETTERE.findall(testo)
    return {
        "caratteri": len(testo),
        "lettere": len(lettere),
        "vocali": vocali,
        "consonanti": len(lettere) - vocali,
        "cifre": sum(1 for c in testo if c.isdigit()),
        "spazi": sum(1 for c in testo if c.isspace()),
        "parole": len(parole),
        "parole_diverse": len({p.lower() for p in parole}),
        "frasi": frasi,
        "righe": testo.count("\n") + 1 if testo else 0,
        "sillabe": sum(len(_sillabe_parola(p)) for p in lettere_parole) if len(testo) < 1_000_000 else 0,
        "lettere_per_parola": round(len(lettere) / len(parole), 1) if parole else 0,
        "parole_per_frase": round(len(parole) / frasi, 1) if frasi else 0,
    }


@funzione_libreria("indice_gulpease")
def indice_gulpease(testo):
    """indice_gulpease(testo): quanto è facile da leggere un testo italiano, da 0 a 100.

    È l'indice Gulpease: 89 + (300 × frasi − 10 × lettere) / parole. Sotto 80 è difficile per chi
    ha la licenza elementare, sotto 60 per chi ha la licenza media, sotto 40 per chi ha il diploma.
    Esempio: `indice_gulpease("Il gatto dorme. Il cane gioca.")` è 100.
    """
    _testo(testo, "indice_gulpease", "testo")
    parole = _parole(testo)
    if not parole:
        raise ErroreValore("Per calcolare la leggibilità serve un testo con almeno una parola.")
    lettere = sum(len(p) for p in parole)
    frasi = max(1, _conta_frasi(testo))
    valore = 89 + (300 * frasi - 10 * lettere) / len(parole)
    return round(min(100.0, max(0.0, valore)), 1)


# ===========================================================================
# Lingua: accenti, plurali, articoli
# ===========================================================================

_ACCENTATE = {"à": "a", "è": "e", "é": "e", "ì": "i", "í": "i", "ò": "o", "ó": "o", "ù": "u", "ú": "u"}


@funzione_libreria("togli_accenti")
def togli_accenti(testo, con_apostrofo=False):
    """togli_accenti(testo, con_apostrofo = falso): il testo senza accenti (è -> e, ñ -> n...).

    Con `con_apostrofo = vero` le vocali accentate diventano vocale e apostrofo, come sulle
    tastiere senza accenti: "perché" -> "perche'".
    Esempi: `togli_accenti("Perché è così?")` è "Perche e cosi?";
    `togli_accenti("città", con_apostrofo = vero)` è "citta'".
    """
    _testo(testo, "togli_accenti", "testo")
    if _logico(con_apostrofo, "togli_accenti", "con_apostrofo"):
        testo = "".join(
            (_ACCENTATE[c.lower()].upper() if c.isupper() else _ACCENTATE[c]) + "'"
            if c.lower() in _ACCENTATE else c for c in unicodedata.normalize("NFC", testo))
    return _senza_segni(testo)


_PLURALI_IRREGOLARI = {
    "uomo": "uomini", "dio": "dei", "bue": "buoi", "uovo": "uova", "paio": "paia", "dito": "dita",
    "braccio": "braccia", "ginocchio": "ginocchia", "labbro": "labbra", "lenzuolo": "lenzuola",
    "osso": "ossa", "mano": "mani", "ala": "ali", "arma": "armi", "mille": "mila", "tempio": "templi",
    "moglie": "mogli", "ciglio": "ciglia", "centinaio": "centinaia", "migliaio": "migliaia",
    "miglio": "miglia", "riso": "risa", "amico": "amici", "nemico": "nemici", "greco": "greci",
    "porco": "porci", "antico": "antichi", "carico": "carichi", "incarico": "incarichi",
    "scarico": "scarichi", "valigia": "valigie", "ciliegia": "ciliegie", "camicia": "camicie",
    "effigie": "effigie", "superficie": "superfici", "eco": "echi", "belga": "belgi",
}
_INVARIABILI = frozenset(
    "foto moto radio auto bici cinema serie specie re gru vaglia gorilla boia sosia euro"
    " dopoguerra paia crisi tesi analisi".split())
_MASCHILI_IN_A = frozenset(
    "problema sistema tema teorema poeta pianeta programma clima dramma schema telegramma diploma papa"
    " atleta pilota collega profeta monarca patriarca duca poema panorama enigma dilemma fantasma"
    " diagramma cruciverba pigiama".split())
_AMBIGUI_IN_A = frozenset("collega atleta pilota".split())
_IO_ACCENTATO = frozenset("zio pendio leggio addio fruscio mormorio brusio rinvio invio oblio gorgoglio"
                          " luccichio pigolio calpestio ronzio tintinnio".split())
_OLOGO_CON_H = frozenset("dialogo catalogo prologo monologo decalogo epilogo analogo".split())


def _plurale_minuscolo(p: str, femminile: bool) -> str:
    if p in _PLURALI_IRREGOLARI:
        return _PLURALI_IRREGOLARI[p]
    if p in _INVARIABILI or len(p) < 2:
        return p
    ultima = p[-1]
    if ultima not in "aeiou" or p.endswith(("i", "ie")):
        return p  # città, sport, bar, crisi, serie
    if p.endswith("co"):
        # sdrucciole (medico, tecnico) -> ci; piane (gioco, bosco) -> chi
        if p.endswith("ico") and len(_sillabe_parola(p)) >= 3:
            return p[:-2] + "ci"
        return p[:-2] + "chi"
    if p.endswith("go"):
        if p.endswith("ologo") and p not in _OLOGO_CON_H or p.endswith("fago"):
            return p[:-2] + "gi"
        return p[:-2] + "ghi"
    if p.endswith("io"):
        return p[:-1] + "i" if p in _IO_ACCENTATO else p[:-1]
    if p.endswith("ista") or p.endswith("cida") or p in _AMBIGUI_IN_A and femminile:
        if femminile:
            return p[:-1] + ("he" if p.endswith(("ca", "ga")) else "e")
        return p[:-1] + "i"
    if p in _MASCHILI_IN_A:
        return p[:-1] + ("hi" if p.endswith(("ca", "ga")) else "i")
    if p.endswith("ca") and p not in _MASCHILI_IN_A:
        return p[:-1] + "he"
    if p.endswith("ga") and p not in _MASCHILI_IN_A:
        return p[:-1] + "he"
    if p.endswith(("cia", "gia")) and len(p) > 3:
        return p[:-2] + "e" if p[-4] not in "aeiou" else p[:-1] + "e"
    if ultima == "a":
        return p[:-1] + "e"
    return p[:-1] + "i"  # -o, -e


@funzione_libreria("plurale")
def plurale(parola, femminile=False):
    """plurale(parola, femminile = falso): il plurale di un nome italiano.

    Segue le regole (gioco -> giochi, medico -> medici, arancia -> arance, camicia -> camicie,
    problema -> problemi) e conosce i plurali irregolari più comuni (uomo -> uomini, uovo -> uova).
    Le parole straniere, accentate o abbreviate non cambiano (città, sport, foto).
    `femminile = vero` serve per le parole in -ista (il turista -> i turisti, la turista -> le turiste).
    Esempi: `plurale("gatto")` è "gatti"; `plurale("amica")` è "amiche"; `plurale("re")` è "re".
    """
    _testo(parola, "plurale", "parola")
    femm = _logico(femminile, "plurale", "femminile")
    p = parola.strip()
    if not p:
        raise ErroreValore("`plurale` vuole una parola, non un testo vuoto.")
    if len(p.split()) > 1 or not p.replace("'", "").isalpha():
        raise ErroreValore(f"`plurale` vuole una parola sola, non {mostra(parola)}.",
                           suggerimento="Per una frase, fai il plurale di ogni parola con un ciclo.")
    risultato = _plurale_minuscolo(p.lower(), femm)
    if p.isupper() and len(p) > 1:
        return risultato.upper()
    if p[0].isupper():
        return risultato[0].upper() + risultato[1:]
    return risultato


def _genere_femminile(p: str, plurale: bool) -> bool:
    """Indovina il genere dalla fine della parola (maschile se non si capisce)."""
    if p in _MASCHILI_IN_A or p in _PLURALI_IRREGOLARI and p not in ("ala", "arma", "mano", "moglie"):
        return p in ("valigia", "ciliegia", "camicia", "effigie", "superficie", "eco")
    if plurale:
        if p in ("uova", "paia", "dita", "braccia", "ginocchia", "labbra", "lenzuola", "ossa", "ciglia",
                 "centinaia", "migliaia", "miglia", "risa", "mila", "mani", "ali", "armi", "mogli"):
            return True
        if p.endswith("e"):
            return True
        if p.endswith("i"):
            return p.endswith(("zioni", "sioni", "gioni", "trici", "crisi", "tesi", "analisi"))
    return p.endswith(("a", "tà", "tù", "zione", "sione", "gione", "ie", "trice", "udine", "igine",
                       "crisi", "tesi", "analisi", "foto", "moto", "radio", "auto", "bici"))


def _inizio_speciale(p: str) -> bool:
    """Parole che vogliono lo/gli/uno: s+consonante, z, x, y, gn, ps, pn, i+vocale."""
    if not p:
        return False
    if p[0] in "zxy":
        return True
    if p[0] == "s" and len(p) > 1 and p[1] not in "aeiouàèéìòù":
        return True
    if p.startswith(("gn", "ps", "pn")):
        return True
    return p[0] == "i" and len(p) > 1 and p[1] in "aeiouàèéòù"


def _inizia_con_vocale(p: str) -> bool:
    if p[:1] == "h" and len(p) > 1:  # hotel, hamburger (h muta)
        p = p[1:]
    return p[:1] in "aeiouàèéìòù" and not (p[0] == "i" and len(p) > 1 and p[1] in "aeiouàèéòù")


@funzione_libreria("con_articolo")
def con_articolo(parola, indeterminativo=False, femminile=None, plurale=False):
    """con_articolo(parola, indeterminativo = falso, femminile = nulla, plurale = falso): la parola con l'articolo giusto.

    Sceglie tra il, lo, la, l', i, gli, le (o un, uno, una, un', dei, degli, delle).
    Il genere si indovina dalla fine della parola; se sbaglia, dillo con `femminile = vero/falso`.
    Esempi: `con_articolo("zaino")` è "lo zaino"; `con_articolo("amica", indeterminativo = vero)` è
    "un'amica"; `con_articolo("gnomi", plurale = vero)` è "gli gnomi".
    """
    _testo(parola, "con_articolo", "parola")
    indet = _logico(indeterminativo, "con_articolo", "indeterminativo")
    plur = _logico(plurale, "con_articolo", "plurale")
    parola = parola.strip()
    if not parola:
        raise ErroreValore("`con_articolo` vuole una parola, non un testo vuoto.")
    p = parola.lower()
    if femminile is None:
        femm = _genere_femminile(p.split()[0], plur)
    else:
        femm = _logico(femminile, "con_articolo", "femminile")
    vocale = _inizia_con_vocale(p)
    speciale = _inizio_speciale(p)
    if femm:
        if plur:
            art = "delle " if indet else "le "
        elif indet:
            art = "un'" if vocale else "una "
        else:
            art = "l'" if vocale else "la "
    elif plur:
        art = ("degli " if indet else "gli ") if vocale or speciale else ("dei " if indet else "i ")
    elif indet:
        art = "uno " if speciale else "un "
    else:
        art = "l'" if vocale else "lo " if speciale else "il "
    return art + parola


# ===========================================================================
# Confrontare
# ===========================================================================

@funzione_libreria("somiglianza")
def somiglianza(primo, secondo, ignora_maiuscole=True):
    """somiglianza(primo, secondo, ignora_maiuscole = vero): quanto si somigliano due testi, da 0 a 100.

    100 vuol dire uguali, 0 niente in comune.
    Esempi: `somiglianza("gatto", "gatti")` è 80.0; `somiglianza("Ciao", "ciao")` è 100.0.
    """
    a = _testo(primo, "somiglianza", "primo")
    b = _testo(secondo, "somiglianza", "secondo")
    if _logico(ignora_maiuscole, "somiglianza", "ignora_maiuscole"):
        a, b = a.lower(), b.lower()
    if a == b:
        return 100.0
    if len(a) * len(b) > 10 ** 8:
        a, b = a[:10_000], b[:10_000]
    return round(difflib.SequenceMatcher(None, a, b, autojunk=False).ratio() * 100, 1)


@funzione_libreria("differenze_testi")
def differenze_testi(prima, dopo, solo_cambiamenti=False):
    """differenze_testi(prima, dopo, solo_cambiamenti = falso): cosa è cambiato tra due testi, riga per riga.

    Nel risultato le righe tolte iniziano con "- ", quelle aggiunte con "+ ", quelle uguali con
    due spazi. Con `solo_cambiamenti = vero` restano solo le righe cambiate ("" se i testi sono uguali).
    Esempio: `differenze_testi("pane\\nlatte", "pane\\nuova")` è "  pane\\n- latte\\n+ uova".
    """
    a = _testo(prima, "differenze_testi", "prima").split("\n")
    b = _testo(dopo, "differenze_testi", "dopo").split("\n")
    solo = _logico(solo_cambiamenti, "differenze_testi", "solo_cambiamenti")
    righe = []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if op == "equal":
            if not solo:
                righe.extend("  " + r for r in a[i1:i2])
            continue
        righe.extend("- " + r for r in a[i1:i2])
        righe.extend("+ " + r for r in b[j1:j2])
    return "\n".join(righe)


@funzione_libreria("forse_cercavi")
def forse_cercavi(parola, scelte, quanti=1, soglia=60):
    """forse_cercavi(parola, scelte, quanti = 1, soglia = 60): la scelta più simile a una parola scritta male.

    `scelte` è una lista di testi (o un dizionario: si guardano le chiavi). Maiuscole e accenti
    non contano. Con `quanti = 1` restituisce un testo (o `nulla` se niente somiglia almeno
    `soglia` su 100); con `quanti` più grande, una lista.
    Esempio: `forse_cercavi("banan", ["mela", "banana", "pera"])` è "banana".
    """
    _testo(parola, "forse_cercavi", "parola")
    if isinstance(scelte, dict):
        scelte = list(scelte)
    if not isinstance(scelte, list):
        raise ErroreTipo(f"`scelte` di `forse_cercavi` deve essere una lista di testi, non {articolo(scelte)}.",
                         suggerimento="Per esempio `forse_cercavi(\"pera\", [\"mela\", \"pera\"])`.")
    richiedi_intero(quanti, "forse_cercavi", "quanti")
    richiedi_numero(soglia, "forse_cercavi", "soglia")
    if quanti < 1:
        raise ErroreValore("`quanti` di `forse_cercavi` deve essere almeno 1.")
    if not 0 <= soglia <= 100:
        raise ErroreValore("La `soglia` di `forse_cercavi` va da 0 a 100.")
    originali: dict[str, str] = {}
    for s in scelte:
        if not isinstance(s, str):
            raise ErroreTipo(f"Le scelte di `forse_cercavi` devono essere testi, non {articolo(s)} ({mostra(s)}).")
        originali.setdefault(_chiave(s), s)
    trovate = difflib.get_close_matches(_chiave(parola), list(originali), n=min(quanti, len(originali) or 1),
                                        cutoff=soglia / 100)
    risultato = [originali[t] for t in trovate]
    if quanti == 1:
        return risultato[0] if risultato else None
    return risultato


def _solo_lettere_cifre(testo: str) -> str:
    return "".join(c for c in _chiave(testo) if c.isalnum())


@funzione_libreria("sono_anagrammi")
def sono_anagrammi(primo, secondo):
    """sono_anagrammi(primo, secondo): `vero` se i due testi usano esattamente le stesse lettere.

    Spazi, punteggiatura, maiuscole e accenti non contano.
    Esempi: `sono_anagrammi("Roma", "amor")` è `vero`; `sono_anagrammi("calendario", "locandiera")` è `vero`.
    """
    a = _solo_lettere_cifre(_testo(primo, "sono_anagrammi", "primo"))
    b = _solo_lettere_cifre(_testo(secondo, "sono_anagrammi", "secondo"))
    return bool(a) and sorted(a) == sorted(b)


@funzione_libreria("e_palindromo")
def e_palindromo(testo):
    """e_palindromo(testo): `vero` se il testo (o il numero) si legge uguale anche al contrario.

    Spazi, punteggiatura, maiuscole e accenti non contano.
    Esempi: `e_palindromo("I topi non avevano nipoti")` è `vero`; `e_palindromo(12321)` è `vero`.
    """
    if e_intero(testo):
        cifre = str(testo) if testo >= 0 and testo.bit_length() < 10_000 else ""
        return bool(cifre) and cifre == cifre[::-1]
    if not isinstance(testo, str):
        raise ErroreTipo(f"`e_palindromo` vuole un testo o un intero, non {articolo(testo)}.")
    lettere = _solo_lettere_cifre(_testo(testo, "e_palindromo", "testo"))
    return bool(lettere) and lettere == lettere[::-1]


# ===========================================================================
# Impaginare
# ===========================================================================

_ALLINEAMENTI = ("sinistra", "destra", "centro", "giustificato")


def _giustifica(riga: str, larghezza: int) -> str:
    parole = riga.split()
    if len(parole) < 2:
        return riga
    spazi = larghezza - sum(len(p) for p in parole)
    buchi = len(parole) - 1
    base, extra = divmod(spazi, buchi)
    return "".join(p + (" " * (base + (1 if i < extra else 0)) if i < buchi else "")
                   for i, p in enumerate(parole))


@funzione_libreria("vai_a_capo")
def vai_a_capo(testo, larghezza=40, allinea="sinistra"):
    """vai_a_capo(testo, larghezza = 40, allinea = "sinistra"): va a capo in modo che nessuna riga superi la larghezza.

    Non spezza le parole (se non sono più lunghe della riga) e tiene gli a capo che c'erano già.
    `allinea` può essere "sinistra", "destra", "centro" o "giustificato".
    Esempio: `vai_a_capo("nel mezzo del cammin di nostra vita", 15)` è
    "nel mezzo del\\ncammin di\\nnostra vita".
    """
    _testo(testo, "vai_a_capo", "testo")
    richiedi_intero(larghezza, "vai_a_capo", "larghezza")
    richiedi_testo(allinea, "vai_a_capo", "allinea")
    if not 1 <= larghezza <= 10_000:
        raise ErroreValore(f"La `larghezza` di `vai_a_capo` va da 1 a 10000, non {mostra(larghezza)}.")
    modo = allinea.strip().lower()
    if modo not in _ALLINEAMENTI:
        raise ErroreValore(f"Non conosco l'allineamento {mostra(allinea)}.",
                           suggerimento="Usa \"sinistra\", \"destra\", \"centro\" o \"giustificato\".")
    uscita = []
    for paragrafo in testo.split("\n"):
        righe = textwrap.wrap(paragrafo, larghezza, break_on_hyphens=False) or [""]
        for i, r in enumerate(righe):
            if modo == "destra":
                r = r.rjust(larghezza)
            elif modo == "centro":
                r = r.center(larghezza).rstrip()
            elif modo == "giustificato" and i < len(righe) - 1:
                r = _giustifica(r, larghezza)
            uscita.append(r)
    return "\n".join(uscita)


def _cella(v: Any) -> str:
    try:
        return rappresenta(v)
    except ValueError:
        return "(numero enorme)"


@funzione_libreria("incolonna")
def incolonna(tabella, intestazione=None, separatore="  "):
    """incolonna(tabella, intestazione = nulla, separatore = "  "): una tabella di testo con le colonne allineate.

    `tabella` è una lista di righe (liste), una lista di dizionari (le chiavi fanno l'intestazione)
    o un dizionario (due colonne). I numeri si allineano a destra. Sotto l'intestazione c'è una riga di trattini.
    Esempio: `stampa(incolonna([["Ada", 36], ["Leo", 9]], ["nome", "anni"]))` stampa
    "nome  anni", "----  ----", "Ada     36", "Leo      9".
    """
    richiedi_testo(separatore, "incolonna", "separatore")
    if isinstance(tabella, dict):
        righe = [[k, v] for k, v in tabella.items()]
    elif isinstance(tabella, list):
        if tabella and all(isinstance(r, dict) for r in tabella):
            chiavi: list = []
            for r in tabella:
                chiavi.extend(k for k in r if k not in chiavi)
            if intestazione is None:
                intestazione = [_cella(k) for k in chiavi]
            righe = [[r.get(k, "") for k in chiavi] for r in tabella]
        else:
            righe = [r if isinstance(r, list) else [r] for r in tabella]
    else:
        raise ErroreTipo(f"`incolonna` vuole una lista di righe o un dizionario, non {articolo(tabella)}.",
                         suggerimento="Per esempio `incolonna([[\"Ada\", 36], [\"Leo\", 9]])`.")
    if intestazione is not None and not isinstance(intestazione, list):
        raise ErroreTipo(f"L'`intestazione` di `incolonna` deve essere una lista di titoli, non {articolo(intestazione)}.")
    if sum(len(r) for r in righe) > 1_000_000:
        raise ErroreValore("La tabella è troppo grande per `incolonna`.")
    celle = [[(_cella(v), e_numero(v)) for v in r] for r in righe]
    titoli = [(_cella(v), False) for v in intestazione] if intestazione else None
    tutte = ([titoli] if titoli else []) + celle
    colonne = max((len(r) for r in tutte), default=0)
    larghe = [max((len(r[c][0]) for r in tutte if c < len(r)), default=0) for c in range(colonne)]

    def riga(r: list) -> str:
        pezzi = [(t.rjust(larghe[c]) if num else t.ljust(larghe[c])) for c, (t, num) in enumerate(r)]
        return separatore.join(pezzi).rstrip()

    uscita = []
    if titoli:
        uscita.append(riga(titoli))
        uscita.append(separatore.join("-" * w for w in larghe[:len(titoli)]).rstrip())
    uscita.extend(riga(r) for r in celle)
    return "\n".join(uscita)


_SEGNAPOSTO = re.compile(r"\{\s*([^{}\s]+)\s*\}")


@funzione_libreria("riempi_segnaposti")
def riempi_segnaposti(modello, dati, lascia_mancanti=False):
    """riempi_segnaposti(modello, dati, lascia_mancanti = falso): mette i valori del dizionario al posto dei {segnaposti}.

    Serve per lettere, email e pagine preparate prima (per esempio lette da un file).
    Con il punto si entra nei dizionari: {cliente.nome}. Se manca un valore è un errore,
    a meno di `lascia_mancanti = vero`. Nei testi scritti nel programma le graffe si scrivono `\\{` e `\\}`.
    Esempio: `riempi_segnaposti("Ciao \\{nome\\}!", {"nome": "Ada"})` è "Ciao Ada!".
    """
    _testo(modello, "riempi_segnaposti", "modello")
    if not isinstance(dati, dict):
        raise ErroreTipo(f"`dati` di `riempi_segnaposti` deve essere un dizionario, non {articolo(dati)}.",
                         suggerimento="Per esempio `riempi_segnaposti(lettera, {\"nome\": \"Ada\"})`.")
    lascia = _logico(lascia_mancanti, "riempi_segnaposti", "lascia_mancanti")

    def valore(m: re.Match) -> str:
        nome = m.group(1)
        if nome in dati:
            return _cella(dati[nome])
        corrente: Any = dati
        for pezzo in nome.split("."):
            if isinstance(corrente, dict) and pezzo in corrente:
                corrente = corrente[pezzo]
            else:
                break
        else:
            return _cella(corrente)
        if lascia:
            return m.group(0)
        chiavi = [k for k in dati if isinstance(k, str)]
        simili = difflib.get_close_matches(nome, chiavi, n=1)
        raise ErroreValore(f"Nei dati manca il valore per il segnaposto {{{nome}}}.",
                           suggerimento=f"Forse intendevi {{{simili[0]}}}?" if simili else
                           "Aggiungilo al dizionario o usa `lascia_mancanti = vero`.")

    return _SEGNAPOSTO.sub(valore, modello)


@funzione_libreria("testo_a_url")
def testo_a_url(testo, separatore="-"):
    """testo_a_url(testo, separatore = "-"): il testo adatto a un indirizzo web o a un nome di file.

    Minuscole, niente accenti, trattini al posto degli spazi e dei simboli.
    Esempio: `testo_a_url("Perché il cielo è blu?")` è "perche-il-cielo-e-blu".
    """
    _testo(testo, "testo_a_url", "testo")
    richiedi_testo(separatore, "testo_a_url", "separatore")
    semplice = _senza_segni(unicodedata.normalize("NFKC", testo)).lower().replace("&", " e ")
    semplice = semplice.replace("ß", "ss").replace("æ", "ae").replace("ø", "o").replace("œ", "oe")
    pezzi = re.findall(r"[a-z0-9]+", semplice)
    return separatore.join(pezzi)


@funzione_libreria("censura")
def censura(testo, parole, simbolo="*"):
    """censura(testo, parole, simbolo = "*"): nasconde le parole indicate con asterischi (o un altro simbolo).

    Si nascondono solo le parole intere; maiuscole e minuscole non contano. `parole` è un testo o una lista.
    Esempio: `censura("Che stupido errore!", ["stupido"])` è "Che ******* errore!".
    """
    _testo(testo, "censura", "testo")
    richiedi_testo(simbolo, "censura", "simbolo")
    if simbolo == "":
        raise ErroreValore("Il `simbolo` di `censura` non può essere vuoto.", suggerimento="Usa per esempio \"*\".")
    if isinstance(parole, str):
        parole = [parole]
    if not isinstance(parole, list):
        raise ErroreTipo(f"`parole` di `censura` deve essere un testo o una lista di testi, non {articolo(parole)}.")
    elenco = []
    for p in parole:
        if not isinstance(p, str):
            raise ErroreTipo(f"Le parole da censurare devono essere testi, non {articolo(p)} ({mostra(p)}).")
        if p.strip():
            elenco.append(re.escape(p.strip()))
    if not elenco:
        return testo
    elenco.sort(key=len, reverse=True)
    modello = re.compile(r"(?<!\w)(?:" + "|".join(elenco) + r")(?!\w)", re.IGNORECASE)
    return modello.sub(lambda m: (simbolo * len(m.group(0)))[:len(m.group(0))], testo)


# ===========================================================================
# Markdown e HTML
# ===========================================================================

_MD_IMMAGINE = re.compile(r"!\[([^\]]*)\]\(([^)\s]+)\)")
_MD_LINK = re.compile(r"\[([^\]]+)\]\(([^)\s]+)\)")
_MD_GRASSETTO = re.compile(r"(\*\*|__)(?=\S)(.+?)(?<=\S)\1")
_MD_CORSIVO = re.compile(r"(?<![\w*])([*_])(?=\S)(.+?)(?<=\S)\1(?![\w*])")
_MD_BARRATO = re.compile(r"~~(?=\S)(.+?)(?<=\S)~~")


def _attributo(testo: str) -> str:
    return testo.replace('"', "&quot;")


def _indirizzo(url: str) -> str:
    """Indirizzo già protetto da html.escape; niente javascript: nei collegamenti."""
    if re.match(r"^\s*(javascript|vbscript|data):", _html.unescape(url), re.IGNORECASE):
        return "#"
    return _attributo(url)


def _md_in_riga(testo: str) -> str:
    pezzi = re.split(r"(`[^`]+`)", testo)
    uscita = []
    for pezzo in pezzi:
        if len(pezzo) > 1 and pezzo.startswith("`") and pezzo.endswith("`"):
            uscita.append("<code>" + _html.escape(pezzo[1:-1], quote=False) + "</code>")
            continue
        t = _html.escape(pezzo, quote=False)
        t = _MD_IMMAGINE.sub(lambda m: f'<img src="{_indirizzo(m.group(2))}" alt="{_attributo(m.group(1))}">', t)
        t = _MD_LINK.sub(lambda m: f'<a href="{_indirizzo(m.group(2))}">{m.group(1)}</a>', t)
        t = _MD_GRASSETTO.sub(r"<strong>\2</strong>", t)
        t = _MD_CORSIVO.sub(r"<em>\2</em>", t)
        t = _MD_BARRATO.sub(r"<del>\1</del>", t)
        uscita.append(t)
    risultato = "".join(uscita)
    return re.sub(r" {2,}$", "<br>", risultato)


def _md_blocchi(righe: list[str]) -> list[str]:
    uscita: list[str] = []
    paragrafo: list[str] = []
    i = 0

    def chiudi_paragrafo() -> None:
        if paragrafo:
            uscita.append("<p>" + "\n".join(_md_in_riga(r) for r in paragrafo) + "</p>")
            paragrafo.clear()

    while i < len(righe):
        riga = righe[i]
        pulita = riga.strip()
        if pulita.startswith("```"):
            chiudi_paragrafo()
            lingua = pulita[3:].strip()
            codice = []
            i += 1
            while i < len(righe) and not righe[i].strip().startswith("```"):
                codice.append(righe[i])
                i += 1
            classe = f' class="language-{_html.escape(lingua)}"' if lingua else ""
            uscita.append(f"<pre><code{classe}>" + _html.escape("\n".join(codice), quote=False) + "</code></pre>")
            i += 1
            continue
        if not pulita:
            chiudi_paragrafo()
            i += 1
            continue
        m = re.match(r"^(#{1,6})\s+(.*?)\s*#*\s*$", pulita)
        if m:
            chiudi_paragrafo()
            n = len(m.group(1))
            uscita.append(f"<h{n}>{_md_in_riga(m.group(2))}</h{n}>")
            i += 1
            continue
        if re.match(r"^([-*_])(\s*\1){2,}$", pulita):
            chiudi_paragrafo()
            uscita.append("<hr>")
            i += 1
            continue
        if pulita.startswith(">"):
            chiudi_paragrafo()
            citazione = []
            while i < len(righe) and righe[i].strip().startswith(">"):
                citazione.append(re.sub(r"^\s*>\s?", "", righe[i]))
                i += 1
            uscita.append("<blockquote>\n" + "\n".join(_md_blocchi(citazione)) + "\n</blockquote>")
            continue
        elenco = re.match(r"^\s*([-*+]|\d+[.)])\s+", riga)
        if elenco:
            chiudi_paragrafo()
            numerato = elenco.group(1)[0].isdigit()
            voci = []
            while i < len(righe):
                m2 = re.match(r"^\s*([-*+]|\d+[.)])\s+(.*)$", righe[i])
                if not m2 or m2.group(1)[0].isdigit() != numerato:
                    break
                voci.append("<li>" + _md_in_riga(m2.group(2)) + "</li>")
                i += 1
            tag = "ol" if numerato else "ul"
            uscita.append(f"<{tag}>\n" + "\n".join(voci) + f"\n</{tag}>")
            continue
        if "|" in pulita and i + 1 < len(righe) and re.match(r"^\s*\|?\s*:?-+:?\s*(\|\s*:?-+:?\s*)*\|?\s*$",
                                                                 righe[i + 1]):
            chiudi_paragrafo()

            def celle(r: str) -> list[str]:
                return [c.strip() for c in r.strip().strip("|").split("|")]

            testa = "".join(f"<th>{_md_in_riga(c)}</th>" for c in celle(riga))
            corpo = []
            i += 2
            while i < len(righe) and "|" in righe[i] and righe[i].strip():
                corpo.append("<tr>" + "".join(f"<td>{_md_in_riga(c)}</td>" for c in celle(righe[i])) + "</tr>")
                i += 1
            uscita.append(f"<table>\n<tr>{testa}</tr>\n" + "\n".join(corpo) + "\n</table>")
            continue
        paragrafo.append(pulita if not riga.endswith("  ") else pulita + "  ")
        i += 1
    chiudi_paragrafo()
    return uscita


@funzione_libreria("markdown_a_html")
def markdown_a_html(testo, pagina_intera=False):
    """markdown_a_html(testo, pagina_intera = falso): trasforma un testo Markdown in HTML.

    Capisce titoli (#), paragrafi, **grassetto**, *corsivo*, ~~barrato~~, `codice`, blocchi di codice
    (```), elenchi puntati e numerati, citazioni (>), linee (---), collegamenti, immagini e tabelle.
    Con `pagina_intera = vero` restituisce una pagina HTML completa.
    Esempio: `markdown_a_html("# Ciao\\n\\nSono **Leo**")` è "<h1>Ciao</h1>\\n<p>Sono <strong>Leo</strong></p>".
    """
    _testo(testo, "markdown_a_html", "testo")
    intera = _logico(pagina_intera, "markdown_a_html", "pagina_intera")
    corpo = "\n".join(_md_blocchi(testo.replace("\r\n", "\n").replace("\t", "    ").split("\n")))
    if not intera:
        return corpo
    titolo = re.search(r"<h1>(.*?)</h1>", corpo)
    nome = re.sub(r"<[^>]+>", "", titolo.group(1)) if titolo else "Pagina"
    return ("<!DOCTYPE html>\n<html lang=\"it\">\n<head>\n<meta charset=\"utf-8\">\n"
            f"<title>{nome}</title>\n</head>\n<body>\n{corpo}\n</body>\n</html>")


_BLOCCHI_HTML = frozenset("p div section article header footer nav aside main h1 h2 h3 h4 h5 h6 ul ol table tr "
                          "blockquote pre form fieldset figure figcaption dl dt dd address hr title".split()) - {"tr"}
_SALTA_HTML = frozenset(("script", "style", "head", "noscript", "template", "svg"))


_PARAGRAFO = "\x01"


class _LettoreHtml(HTMLParser):
    """Raccoglie il testo: "\\x01" separa i paragrafi, "\\n" le righe, "\\x00" gli a capo dentro <pre>."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.pezzi: list[str] = []
        self.salta = 0
        self.pre = 0
        self.elenchi: list[list] = []

    def handle_starttag(self, tag: str, attrs: list) -> None:
        if tag in _SALTA_HTML:
            self.salta += 1
        elif tag == "br":
            self.pezzi.append("\x00" if self.pre else "\n")
        elif tag == "li":
            rientro = "  " * max(0, len(self.elenchi) - 1)
            if self.elenchi and self.elenchi[-1][0] == "ol":
                self.elenchi[-1][1] += 1
                self.pezzi.append(f"\n{rientro}{self.elenchi[-1][1]}. ")
            else:
                self.pezzi.append(f"\n{rientro}- ")
        elif tag in ("ul", "ol"):
            self.pezzi.append("\n" if self.elenchi else _PARAGRAFO)
            self.elenchi.append([tag, 0])
        elif tag == "tr":
            self.pezzi.append("\n")
        elif tag in ("td", "th"):
            self.pezzi.append("\t")
        elif tag == "img":
            alt = dict(attrs).get("alt")
            if alt:
                self.pezzi.append(f"[{alt}]")
        elif tag == "pre":
            self.pre += 1
            self.pezzi.append(_PARAGRAFO)
        elif tag in _BLOCCHI_HTML:
            self.pezzi.append(_PARAGRAFO)

    def handle_endtag(self, tag: str) -> None:
        if tag in _SALTA_HTML:
            self.salta = max(0, self.salta - 1)
        elif tag in ("ul", "ol"):
            if self.elenchi:
                self.elenchi.pop()
            if not self.elenchi:
                self.pezzi.append(_PARAGRAFO)
        elif tag == "pre":
            self.pre = max(0, self.pre - 1)
            self.pezzi.append(_PARAGRAFO)
        elif tag in _BLOCCHI_HTML:
            self.pezzi.append(_PARAGRAFO)

    def handle_data(self, data: str) -> None:
        if self.salta:
            return
        if self.pre:
            self.pezzi.append(data.replace("\n", "\x00").replace(" ", "\x02"))
        else:
            self.pezzi.append(re.sub(r"\s+", " ", data))


@funzione_libreria("html_a_testo")
def html_a_testo(html):
    """html_a_testo(html): il testo semplice di una pagina HTML, senza etichette, script e stili.

    I paragrafi restano separati da una riga vuota, gli elementi degli elenchi iniziano con "- ",
    i simboli come &amp;egrave; diventano lettere (è).
    Esempio: `html_a_testo("<p>Ciao <b>mondo</b></p><ul><li>uno</li></ul>")` è "Ciao mondo\\n\\n- uno".
    """
    _testo(html, "html_a_testo", "html")
    lettore = _LettoreHtml()
    try:
        lettore.feed(html)
        lettore.close()
    except (AssertionError, ValueError):  # HTML molto rovinato
        pass
    testo = "".join(lettore.pezzi)
    # spazi e tabulazioni attorno agli a capo via; più a capo di fila: uno solo, o una riga vuota tra paragrafi
    testo = re.sub(r"[ \t]*[\n\x01](?:[ \t]*[\n\x01])*",
                   lambda m: "\n\n" if _PARAGRAFO in m.group(0) else "\n", testo)
    # a inizio riga resta solo il rientro degli elenchi dentro altri elenchi (due spazi o più)
    testo = re.sub(r"(^|\n)(?: (?! )|\t+)", r"\1", testo)
    testo = testo.strip(" \t\n").replace("\x00", "\n").replace("\x02", " ")
    return testo


# ===========================================================================
# XML
# ===========================================================================

def _nome_xml(tag: str) -> str:
    return tag.split("}", 1)[1] if tag.startswith("{") else tag


def _da_elemento(el: Any) -> Any:
    figli = list(el)
    attributi = {"@" + _nome_xml(k): v for k, v in el.attrib.items()}
    testo = (el.text or "").strip()
    if not figli and not attributi:
        return testo
    risultato: dict = dict(attributi)
    for f in figli:
        nome = _nome_xml(f.tag) if isinstance(f.tag, str) else None
        if nome is None:
            continue
        valore = _da_elemento(f)
        if nome in risultato:
            if not isinstance(risultato[nome], list):
                risultato[nome] = [risultato[nome]]
            risultato[nome].append(valore)
        else:
            risultato[nome] = valore
    testi = testo + "".join((f.tail or "").strip() for f in figli)
    if testi:
        risultato["#testo"] = testi
    return risultato


@funzione_libreria("da_xml")
def da_xml(testo):
    """da_xml(testo): legge un testo XML e lo trasforma in un dizionario facile da usare.

    Ogni elemento diventa una chiave; gli elementi ripetuti diventano una lista; gli attributi
    hanno la chiocciola davanti ("@id"); il testo di un elemento con attributi sta in "#testo".
    I valori restano testi. Per un file: `da_xml(leggi_file("dati.xml"))`.
    Esempio: `da_xml("<libro id=\\"7\\"><titolo>Pinocchio</titolo></libro>")` è
    {"libro": {"@id": "7", "titolo": "Pinocchio"}}.
    """
    import xml.etree.ElementTree as ET

    _testo(testo, "da_xml", "testo")
    if "<!ENTITY" in testo:
        raise ErroreValore("Per sicurezza `da_xml` non accetta i testi XML con le entità (<!ENTITY ...>).")
    try:
        radice = ET.fromstring(testo.strip().lstrip("﻿"))
    except ET.ParseError as e:
        riga, colonna = getattr(e, "position", (0, 0))
        raise ErroreValore(f"Il testo non è un XML valido (riga {riga}, colonna {colonna + 1}).",
                           suggerimento="Controlla che ogni <etichetta> abbia la sua </etichetta>.") from None
    except (ValueError, RecursionError):
        raise ErroreValore("Il testo non è un XML valido.") from None
    try:
        return {_nome_xml(radice.tag): _da_elemento(radice)}
    except RecursionError:
        raise ErroreValore("L'XML ha troppi livelli uno dentro l'altro.") from None


_NOME_XML_VALIDO = re.compile(r"^[^\W\d][\w.\-]*$")


def _testo_xml(v: Any) -> str:
    if v is None:
        return ""
    if isinstance(v, bool):
        return "vero" if v else "falso"
    return _cella(v)


def _a_elemento(ET: Any, genitore: Any, nome: Any, valore: Any, profondita: int) -> None:
    if profondita > 200:
        raise ErroreValore("I dati hanno troppi livelli uno dentro l'altro per diventare XML.")
    if not isinstance(nome, str) or not _NOME_XML_VALIDO.match(nome) or nome.lower().startswith("xml"):
        raise ErroreValore(f"{mostra(nome)} non va bene come nome di un elemento XML.",
                           suggerimento="Usa nomi fatti di lettere, cifre, _ e -, che iniziano con una lettera.")
    if isinstance(valore, list):
        for v in valore:
            _a_elemento(ET, genitore, nome, v, profondita + 1)
        return
    el = ET.SubElement(genitore, nome)
    _riempi_elemento(ET, el, valore, profondita)


def _riempi_elemento(ET: Any, el: Any, valore: Any, profondita: int) -> None:
    if isinstance(valore, dict):
        for k, v in valore.items():
            if isinstance(k, str) and k.startswith("@"):
                if not _NOME_XML_VALIDO.match(k[1:]):
                    raise ErroreValore(f"{mostra(k)} non va bene come nome di un attributo XML.")
                el.set(k[1:], _testo_xml(v))
            elif k == "#testo":
                el.text = _testo_xml(v)
            else:
                _a_elemento(ET, el, k, v, profondita + 1)
    else:
        el.text = _testo_xml(valore)


@funzione_libreria("a_xml")
def a_xml(dati, radice=None, rientro=True):
    """a_xml(dati, radice = nulla, rientro = vero): trasforma un dizionario in un testo XML (l'inverso di `da_xml`).

    Se il dizionario ha una sola chiave, quella è l'elemento principale; altrimenti si usa `radice`
    (o "dati"). Le liste diventano elementi ripetuti, le chiavi con "@" attributi.
    Esempio: `a_xml({"libro": {"@id": 7, "titolo": "Pinocchio"}}, rientro = falso)` è
    "<libro id=\\"7\\"><titolo>Pinocchio</titolo></libro>".
    """
    import xml.etree.ElementTree as ET

    con_rientro = _logico(rientro, "a_xml", "rientro")
    if radice is not None:
        richiedi_testo(radice, "a_xml", "radice")
    if radice is None and isinstance(dati, dict) and len(dati) == 1:
        (nome, valore), = dati.items()
        if isinstance(nome, str) and not nome.startswith(("@", "#")) and not isinstance(valore, list):
            radice, dati = nome, valore
    nome_radice = radice or "dati"
    if not _NOME_XML_VALIDO.match(nome_radice):
        raise ErroreValore(f"{mostra(nome_radice)} non va bene come nome dell'elemento principale.")
    principale = ET.Element(nome_radice)
    if isinstance(dati, list):
        for v in dati:
            _a_elemento(ET, principale, "elemento", v, 1)
    else:
        _riempi_elemento(ET, principale, dati, 0)
    if con_rientro:
        ET.indent(principale, space="  ")
    return ET.tostring(principale, encoding="unicode")


# ===========================================================================
# YAML (sottoinsieme comune)
# ===========================================================================

class _ErroreYaml(Exception):
    def __init__(self, riga: int, messaggio: str) -> None:
        super().__init__(messaggio)
        self.riga = riga
        self.messaggio = messaggio


_INTERO_YAML = re.compile(r"^[-+]?(0|[1-9][0-9_]*)$")
_DECIMALE_YAML = re.compile(r"^[-+]?(\d[\d_]*)?\.\d+([eE][-+]?\d+)?$|^[-+]?\d[\d_]*(\.\d*)?[eE][-+]?\d+$|^[-+]?\d+\.$")


def _scalare_yaml(s: str, riga: int) -> Any:
    s = s.strip()
    if s == "" or s in ("~", "null", "Null", "NULL"):
        return None
    if s[0] == '"':
        if len(s) < 2 or not s.endswith('"'):
            raise _ErroreYaml(riga, "manca la virgoletta \" di chiusura")
        interno = s[1:-1]
        try:
            import json
            return json.loads('"' + interno.replace("\t", "\\t") + '"')
        except ValueError:
            raise _ErroreYaml(riga, "testo tra virgolette non valido") from None
    if s[0] == "'":
        if len(s) < 2 or not s.endswith("'"):
            raise _ErroreYaml(riga, "manca la virgoletta ' di chiusura")
        return s[1:-1].replace("''", "'")
    if s[0] == "[" or s[0] == "{":
        return _flusso_yaml(s, riga)
    if s in ("true", "True", "TRUE"):
        return True
    if s in ("false", "False", "FALSE"):
        return False
    if _INTERO_YAML.match(s):
        return int(s.replace("_", ""))
    if _DECIMALE_YAML.match(s):
        return float(s.replace("_", ""))
    if s in (".inf", "+.inf", ".Inf"):
        return float("inf")
    if s in ("-.inf", "-.Inf"):
        return float("-inf")
    if s[0] in "&*!|>%@`":
        raise _ErroreYaml(riga, f"non conosco questa forma YAML: {s[:20]}")
    return s


def _dividi_flusso(s: str, riga: int) -> list[str]:
    pezzi, livello, attuale, virgolette = [], 0, [], None
    for c in s:
        if virgolette:
            attuale.append(c)
            if c == virgolette:
                virgolette = None
            continue
        if c in "\"'":
            virgolette = c
        elif c in "[{":
            livello += 1
        elif c in "]}":
            livello -= 1
        elif c == "," and livello == 0:
            pezzi.append("".join(attuale))
            attuale = []
            continue
        attuale.append(c)
    if virgolette or livello:
        raise _ErroreYaml(riga, "parentesi o virgolette non chiuse")
    if "".join(attuale).strip():
        pezzi.append("".join(attuale))
    return pezzi


def _flusso_yaml(s: str, riga: int) -> Any:
    if s[0] == "[":
        if not s.endswith("]"):
            raise _ErroreYaml(riga, "manca la ] di chiusura")
        return [_scalare_yaml(p, riga) for p in _dividi_flusso(s[1:-1], riga)]
    if not s.endswith("}"):
        raise _ErroreYaml(riga, "manca la } di chiusura")
    risultato = {}
    for p in _dividi_flusso(s[1:-1], riga):
        chiave, sep, valore = _dividi_chiave(p)
        if not sep:
            raise _ErroreYaml(riga, f"nel dizionario tra graffe manca i due punti in {p.strip()[:20]!r}")
        risultato[chiave] = _scalare_yaml(valore, riga)
    return risultato


def _dividi_chiave(riga: str) -> tuple[Any, bool, str]:
    """"nome: Ada" -> ("nome", True, "Ada"). Rispetta le virgolette nella chiave."""
    r = riga.strip()
    if r and r[0] in "\"'":
        chiusa = r.find(r[0], 1)
        while r[0] == "'" and chiusa > 0 and r[chiusa + 1:chiusa + 2] == "'":
            chiusa = r.find("'", chiusa + 2)
        if chiusa > 0 and r[chiusa + 1:chiusa + 2] == ":" and (len(r) == chiusa + 2 or r[chiusa + 2] in " \t"):
            return _scalare_yaml(r[:chiusa + 1], 0), True, r[chiusa + 2:]
        return None, False, r
    m = re.match(r"^([^\s#\[\]{},][^:#]*?|[^\s#\[\]{},]):(?:\s+|$)(.*)$", r)
    if not m:
        return None, False, r
    chiave = _scalare_yaml(m.group(1), 0)
    if isinstance(chiave, (dict, list)) or chiave is None:
        chiave = m.group(1).strip()
    return chiave, True, m.group(2)


def _togli_commento(riga: str) -> str:
    virgolette = None
    for i, c in enumerate(riga):
        if virgolette:
            if c == virgolette:
                virgolette = None
        elif c in "\"'" and (i == 0 or riga[i - 1] in " :[{,-"):
            virgolette = c
        elif c == "#" and (i == 0 or riga[i - 1] in " \t"):
            return riga[:i].rstrip()
    return riga.rstrip()


class _LettoreYaml:
    def __init__(self, testo: str) -> None:
        self.righe: list[tuple[int, int, str, str]] = []  # (numero, rientro, contenuto, originale)
        for n, originale in enumerate(testo.replace("\r\n", "\n").split("\n"), start=1):
            if "\t" in originale[:len(originale) - len(originale.lstrip())]:
                raise _ErroreYaml(n, "in YAML il rientro si fa con gli spazi, non con il tasto Tab")
            contenuto = _togli_commento(originale)
            if contenuto.strip() in ("---", "...") and not originale.startswith(" "):
                if contenuto.strip() == "---" and any(r[2] for r in self.righe):
                    raise _ErroreYaml(n, "ci sono più documenti YAML (---): ne leggo uno solo")
                continue
            if contenuto.strip().startswith("%"):
                continue
            self.righe.append((n, len(originale) - len(originale.lstrip(" ")), contenuto.strip(), originale))
        self.i = 0

    def _salta_vuote(self) -> None:
        while self.i < len(self.righe) and not self.righe[self.i][2]:
            self.i += 1

    def documento(self) -> Any:
        self._salta_vuote()
        if self.i >= len(self.righe):
            return None
        valore = self.blocco(self.righe[self.i][1])
        self._salta_vuote()
        if self.i < len(self.righe):
            raise _ErroreYaml(self.righe[self.i][0], "rientro sbagliato")
        return valore

    def blocco(self, rientro: int) -> Any:
        self._salta_vuote()
        n, r, contenuto, _ = self.righe[self.i]
        if contenuto.startswith("- ") or contenuto == "-":
            return self.lista(r)
        chiave, sep, _ = _dividi_chiave(contenuto)
        if sep:
            return self.mappa(r)
        # scalare su più righe (testo semplice spezzato)
        pezzi = []
        while self.i < len(self.righe) and (not self.righe[self.i][2] or self.righe[self.i][1] >= rientro):
            if self.righe[self.i][2]:
                pezzi.append(self.righe[self.i][2])
            self.i += 1
        return _scalare_yaml(" ".join(pezzi), n)

    def valore_dopo(self, resto: str, rientro: int, n: int) -> Any:
        resto = resto.strip()
        if resto and resto[0] in "|>":
            return self.testo_a_blocco(resto, rientro, n)
        if resto:
            if resto[0] in "[{" and not self._chiuso(resto):
                # flusso su più righe
                pezzi = [resto]
                while self.i < len(self.righe) and not self._chiuso(" ".join(pezzi)):
                    pezzi.append(self.righe[self.i][2])
                    self.i += 1
                resto = " ".join(pezzi)
            return _scalare_yaml(resto, n)
        self._salta_vuote()
        if self.i < len(self.righe):
            _, r, contenuto, _ = self.righe[self.i]
            if r > rientro or (r == rientro and contenuto.startswith("-")):
                return self.blocco(r)
        return None

    @staticmethod
    def _chiuso(s: str) -> bool:
        try:
            _dividi_flusso(s, 0)
            return True
        except _ErroreYaml:
            return False

    def testo_a_blocco(self, intestazione: str, rientro: int, n: int) -> str:
        piegato = intestazione[0] == ">"
        finale = "strip" if "-" in intestazione else "keep" if "+" in intestazione else "clip"
        righe: list[str] = []
        margine = None
        while self.i < len(self.righe):
            _, r, contenuto, originale = self.righe[self.i]
            if originale.strip() == "":
                righe.append("")
                self.i += 1
                continue
            if r <= rientro:
                break
            if margine is None:
                margine = r
            if r < margine:
                break
            righe.append(originale[margine:].rstrip())
            self.i += 1
        vuote_in_fondo = 0
        while righe and righe[-1] == "":
            righe.pop()
            vuote_in_fondo += 1
        if piegato:
            testo = ""
            for j, riga in enumerate(righe):
                if j == 0:
                    testo = riga
                elif riga == "" or righe[j - 1] == "":
                    testo += "\n" if riga == "" else riga
                else:
                    testo += " " + riga
        else:
            testo = "\n".join(righe)
        if finale == "clip" and testo:
            testo += "\n"
        elif finale == "keep":
            testo += "\n" * (1 + vuote_in_fondo)
        return testo

    def lista(self, rientro: int) -> list:
        risultato = []
        while True:
            self._salta_vuote()
            if self.i >= len(self.righe):
                break
            n, r, contenuto, originale = self.righe[self.i]
            if r != rientro or not (contenuto.startswith("- ") or contenuto == "-"):
                if r > rientro:
                    raise _ErroreYaml(n, "rientro sbagliato nella lista")
                break
            self.i += 1
            resto = contenuto[1:].strip()
            sep = bool(resto) and resto[0] not in "[{" and _dividi_chiave(resto)[1]
            if sep:
                # "- nome: Ada" seguito da altre chiavi rientrate
                interno = r + 2 + (len(contenuto[1:]) - len(contenuto[1:].lstrip()) - 1)
                self.righe[self.i - 1] = (n, interno, resto, " " * interno + resto)
                self.i -= 1
                risultato.append(self.mappa(interno))
            elif resto.startswith("- "):
                interno = r + 2
                self.righe[self.i - 1] = (n, interno, resto, " " * interno + resto)
                self.i -= 1
                risultato.append(self.lista(interno))
            else:
                risultato.append(self.valore_dopo(resto, r, n))
        return risultato

    def mappa(self, rientro: int) -> dict:
        risultato: dict = {}
        while True:
            self._salta_vuote()
            if self.i >= len(self.righe):
                break
            n, r, contenuto, _ = self.righe[self.i]
            if r < rientro:
                break
            if r > rientro:
                raise _ErroreYaml(n, "rientro sbagliato")
            if contenuto.startswith("- ") or contenuto == "-":
                break
            chiave, sep, valore = _dividi_chiave(contenuto)
            if not sep:
                raise _ErroreYaml(n, f"mi aspettavo \"chiave: valore\", non {contenuto[:30]!r}")
            if isinstance(chiave, (list, dict)):
                chiave = str(chiave)
            if chiave in risultato:
                raise _ErroreYaml(n, f"la chiave {chiave!r} è ripetuta")
            self.i += 1
            risultato[chiave] = self.valore_dopo(valore, r, n)
        return risultato


def _converti_yaml(v: Any, profondita: int = 0) -> Any:
    """Valori di PyYAML -> valori Leo (date e tipi strani diventano testi)."""
    if profondita > 500:
        raise RecursionError
    if isinstance(v, dict):
        return {(k if isinstance(k, (str, int, float, bool)) or k is None else str(k)): _converti_yaml(x, profondita + 1)
                for k, x in v.items()}
    if isinstance(v, (list, tuple, set)):
        return [_converti_yaml(x, profondita + 1) for x in v]
    if v is None or isinstance(v, (str, int, float, bool)):
        return v
    if isinstance(v, (datetime.date, datetime.datetime)):
        return v.isoformat()
    if isinstance(v, bytes):
        return v.decode("utf-8", "replace")
    return str(v)


@funzione_libreria("da_yaml")
def da_yaml(testo):
    """da_yaml(testo): legge un testo YAML (file di configurazione) e restituisce dizionari e liste.

    Capisce il YAML di tutti i giorni: "chiave: valore", liste con "- ", rientri, commenti (#),
    testi tra virgolette, numeri, true/false, null, [liste] e {dizionari} su una riga, testi su più
    righe con | e >. Per un file: `da_yaml(leggi_file("impostazioni.yaml"))`.
    Esempio: `da_yaml("nome: Ada\\nanni: 36")` è {"nome": "Ada", "anni": 36}.
    """
    _testo(testo, "da_yaml", "testo")
    try:
        return _LettoreYaml(testo.lstrip("﻿")).documento()
    except _ErroreYaml as e:
        errore = e
    except RecursionError:
        raise ErroreValore("Lo YAML ha troppi livelli uno dentro l'altro.") from None
    try:  # facoltativo: il YAML completo se PyYAML c'è
        import yaml  # type: ignore[import-not-found]
        return _converti_yaml(yaml.safe_load(testo))
    except Exception:  # noqa: BLE001 - PyYAML assente o testo non valido: vale il nostro errore
        pass
    raise ErroreValore(f"Il testo non è un YAML che so leggere (riga {errore.riga}): {errore.messaggio}.",
                       suggerimento="Controlla i due punti dopo le chiavi e che i rientri siano fatti di spazi.")


_PAROLE_YAML_SPECIALI = frozenset("true false yes no on off null ~ y n".split())


def _scalare_a_yaml(v: Any) -> str:
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, float):
        if v != v:
            return ".nan"
        if v in (float("inf"), float("-inf")):
            return ".inf" if v > 0 else "-.inf"
        testo = repr(v)
        if "e" in testo and "." not in testo:  # 1e+20 -> 1.0e+20 (anche per i lettori YAML più vecchi)
            testo = testo.replace("e", ".0e", 1)
        return testo
    if isinstance(v, int):
        return _intero_yaml(v)
    if not isinstance(v, str):
        v = _cella(v)
    serve_virgolette = (
        v == "" or v != v.strip() or v.lower() in _PAROLE_YAML_SPECIALI or v[0] in "-?:,[]{}#&*!|>'\"%@`"
        or ": " in v or " #" in v or v.endswith(":") or re.match(r"^[-+.]?\d", v) or v.startswith(".")
        or any(ord(c) < 32 for c in v))
    if serve_virgolette:
        import json
        return json.dumps(v, ensure_ascii=False)
    return v


def _intero_yaml(n: int) -> str:
    try:
        return str(n)
    except ValueError:
        raise ErroreValore("Il numero è troppo grande per YAML.") from None


def _a_yaml(v: Any, rientro: int, profondita: int) -> list[str]:
    if profondita > 200:
        raise ErroreValore("I dati hanno troppi livelli uno dentro l'altro per diventare YAML.")
    spazi = " " * rientro
    righe: list[str] = []
    if isinstance(v, dict):
        if not v:
            return [spazi + "{}"]
        for k, x in v.items():
            chiave = _scalare_a_yaml(k)
            if isinstance(x, (dict, list)) and x:
                righe.append(f"{spazi}{chiave}:")
                righe.extend(_a_yaml(x, rientro + (2 if isinstance(x, dict) else 0), profondita + 1))
            elif _va_a_blocco(x):
                righe.append(f"{spazi}{chiave}: {'|' if x.endswith(chr(10)) else '|-'}")
                righe.extend((spazi + "  " + r) if r else "" for r in x.rstrip("\n").split("\n"))
            else:
                righe.append(f"{spazi}{chiave}: {_valore_breve(x)}")
        return righe
    if isinstance(v, list):
        if not v:
            return [spazi + "[]"]
        for x in v:
            if isinstance(x, (dict, list)) and x:
                interne = _a_yaml(x, rientro + 2, profondita + 1)
                righe.append(spazi + "- " + interne[0][rientro + 2:])
                righe.extend(interne[1:])
            else:
                righe.append(f"{spazi}- {_valore_breve(x)}")
        return righe
    return [spazi + _valore_breve(v)]


def _va_a_blocco(x: Any) -> bool:
    """Testi su più righe che si possono scrivere con | (e rileggere uguali)."""
    if not isinstance(x, str) or "\n" not in x.rstrip("\n") or x.endswith("\n\n") or x[:1] in (" ", "\n"):
        return False
    if any(ord(c) < 32 and c != "\n" for c in x):
        return False
    return all(r == r.rstrip() for r in x.split("\n"))


def _valore_breve(x: Any) -> str:
    if isinstance(x, dict):
        return "{}"
    if isinstance(x, list):
        return "[]"
    if isinstance(x, range):
        if lunghezza_intervallo(x) > 10_000:
            raise ErroreValore("L'intervallo è troppo lungo per diventare YAML (al massimo 10000 numeri).")
        return "[" + ", ".join(str(i) for i in x) + "]"
    return _scalare_a_yaml(x)


@funzione_libreria("a_yaml")
def a_yaml(dati):
    """a_yaml(dati): trasforma dizionari e liste in un testo YAML ordinato (l'inverso di `da_yaml`).

    I testi che potrebbero confondersi con numeri o con true/false si mettono tra virgolette.
    Per salvarlo: `scrivi_file("impostazioni.yaml", a_yaml(dati))`.
    Esempio: `a_yaml({"nome": "Ada", "linguaggi": ["Leo", "Python"]})` è
    "nome: Ada\\nlinguaggi:\\n- Leo\\n- Python\\n".
    """
    try:
        return "\n".join(_a_yaml(dati, 0, 0)) + "\n"
    except RecursionError:
        raise ErroreValore("I dati hanno troppi livelli uno dentro l'altro per diventare YAML.") from None
