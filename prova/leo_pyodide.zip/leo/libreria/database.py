"""Libreria: database SQLite con comandi in italiano.

``apri_database`` (sinonimo ``crea_database``) restituisce un valore di tipo
``database`` con i metodi:

* ``crea_tabella(nome, colonne)``, ``tabelle()``, ``colonne(tabella)``,
  ``elimina_tabella(nome)``;
* ``inserisci(tabella, riga)`` (un dizionario, o una lista di dizionari);
* ``cerca(tabella, condizioni, ordina, limite)`` (sinonimo ``trova``),
  ``primo(...)``, ``conta(tabella, condizioni)``;
* ``aggiorna(tabella, condizioni, valori)``, ``elimina(tabella, condizioni)``,
  ``svuota(tabella)``;
* ``esegui(sql, parametri)`` per l'SQL avanzato, sempre con i parametri ``?``
  o ``:nome``;
* ``transazione(azione)`` e ``inizia_transazione()``/``conferma()``/``annulla()``;
* ``esporta_csv(tabella, percorso)``, ``importa_csv(percorso, tabella)``;
* ``chiudi()``.

Altri metodi (unioni tra tabelle, somme e medie, raggruppamenti, ricerca nel
testo, JSON, indici, copie di sicurezza...) sono in :mod:`leo.libreria.database_avanzato`,
che si carica insieme al primo database aperto.

Sicurezza: i valori non entrano MAI nel testo SQL. Le condizioni diventano
parametri ``?`` e i nomi di tabelle e colonne sono controllati (solo lettere,
cifre e ``_``) e verificati sulla tabella vera: un testo come
``"x' OR '1'='1"`` resta un valore da confrontare, non un pezzo di comando.

Il motore è :class:`leo.grafica.servizi.bancadati.BancaDati` (lo stesso del
controllo grafico ``BancaDati``): tipi delle colonne, condizioni e
ordinamenti funzionano allo stesso modo.
"""

from __future__ import annotations

import re
from typing import Any

from ..errori import ErroreDante, ErroreTipo, ErroreValore
from ..grafica.servizi.bancadati import BancaDati, TIPI_COLONNA
from .archivi import leggi_tabella, scrivi_tabella
from .date import DataDante
from .generali import articolo, funzione_libreria, mostra, richiedi_logico, richiedi_testo
from .ingresso_uscita import _controlla_percorso
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta

__all__ = ["Database", "apri_database", "crea_database"]


class Database(OggettoLibreria):
    """Un database SQLite aperto da un programma Leo."""

    NOME_TIPO_DANTE = "database"
    SUGGERIMENTO_MODIFICA = "Per cambiare i dati usa i metodi `inserisci`, `aggiorna` ed `elimina`."

    def __init__(self, percorso: str) -> None:
        self.percorso = percorso
        self.motore = BancaDati(percorso)
        self.motore.converti_data = DataDante  # le colonne `data` tornano valori `data` di Leo
        # i metodi in più (unisci, somma, raggruppa...) vivono in un altro modulo: si
        # caricano qui, così ci sono sempre quando esiste un database
        from . import database_avanzato  # noqa: F401

    def testo_dante(self) -> str:
        stato = "" if self.motore.aperta else " (chiuso)"
        nome = "in memoria" if self.percorso == ":memory:" else self.percorso
        return f"<database {nome}{stato}>"

    def __repr__(self) -> str:
        return f"Database({self.percorso!r})"


def _apri(percorso: Any, nome: str) -> Database:
    if percorso is None or percorso == "":
        percorso = ":memory:"
    richiedi_testo(percorso, nome, "percorso")
    if percorso != ":memory:":
        _controlla_percorso(percorso, nome)
    return Database(percorso)


@funzione_libreria("apri_database")
def apri_database(percorso=":memory:"):
    """apri_database(percorso = ":memory:"): apre un database SQLite (lo crea se il file non c'è).

    Senza percorso il database vive solo in memoria e sparisce alla fine del programma.
    Esempio: `variabile db = apri_database("negozio.db")`, poi `db.crea_tabella("alunni", {"nome": "testo"})`,
    `db.inserisci("alunni", {"nome": "Ada"})`, `db.cerca("alunni")`. Alla fine `db.chiudi()`.
    """
    return _apri(percorso, "apri_database")


@funzione_libreria("crea_database")
def crea_database(percorso=":memory:"):
    """crea_database(percorso = ":memory:"): sinonimo di `apri_database`.

    Se il file esiste già lo apre senza cancellare niente.
    Esempio: `variabile db = crea_database("scuola.db")`.
    """
    return _apri(percorso, "crea_database")


# ---------------------------------------------------------------------------
# Proprietà
# ---------------------------------------------------------------------------

@proprieta(Database, "percorso")
def _percorso(db: Database) -> str:
    return db.percorso


@proprieta(Database, "aperto")
def _aperto(db: Database) -> bool:
    return db.motore.aperta


@proprieta(Database, "in_transazione")
def _in_transazione(db: Database) -> bool:
    return db.motore.in_transazione


# ---------------------------------------------------------------------------
# Tabelle
# ---------------------------------------------------------------------------

def _condizioni(condizioni: Any, metodo: str, filtri: dict | None = None) -> dict | None:
    """Le condizioni come dizionario; ``filtri`` (argomenti per nome come ``classe = "5A"``)
    si aggiungono."""
    if filtri:
        if condizioni is None:
            return dict(filtri)
        insieme = dict(_condizioni(condizioni, metodo) or {})
        insieme.update(filtri)
        return insieme
    if condizioni is None:
        return None
    if not isinstance(condizioni, dict):
        raise ErroreTipo(f"Le condizioni di `{metodo}` devono essere un dizionario, non {articolo(condizioni)}.",
                         suggerimento="Esempi: {\"nome\": \"Ada\"}, {\"età\": [\">\", 18]}, "
                                      "{\"città\": [\"in\", [\"Roma\", \"Milano\"]]}.")
    return condizioni


@metodo_oggetto(Database, "crea_tabella")
def db_crea_tabella(db, nome, colonne):
    """db.crea_tabella(nome, colonne): crea la tabella se non c'è già.

    `colonne` è un dizionario nome -> tipo: `intero`, `decimale`, `testo`, `logico`, seguiti
    se vuoi da `chiave`, `obbligatorio`, `unico`. Se non c'è una colonna `id` Leo ne aggiunge
    una automatica. Esempio:
    `db.crea_tabella("studenti", {"nome": "testo obbligatorio", "età": "intero", "email": "testo unico"})`.
    """
    db.motore.crea_tabella(nome, colonne)
    return None


@metodo_oggetto(Database, "tabelle")
def db_tabelle(db):
    """db.tabelle(): i nomi delle tabelle, in ordine alfabetico."""
    return db.motore.tabelle()


@metodo_oggetto(Database, "colonne")
def db_colonne(db, tabella):
    """db.colonne(tabella): dizionario colonna -> tipo (per esempio {"id": "intero", "nome": "testo"})."""
    return db.motore.colonne(tabella)


@metodo_oggetto(Database, "elimina_tabella")
def db_elimina_tabella(db, nome):
    """db.elimina_tabella(nome): cancella la tabella con tutte le sue righe.

    Restituisce `vero` se la tabella c'era, `falso` se non esisteva.
    """
    return db.motore.elimina_tabella(nome)


# ---------------------------------------------------------------------------
# Righe
# ---------------------------------------------------------------------------

@metodo_oggetto(Database, "inserisci")
def db_inserisci(db, tabella, riga):
    """db.inserisci(tabella, riga): aggiunge una riga e restituisce il suo `id`.

    `riga` è un dizionario colonna -> valore; con una lista di dizionari le inserisce tutte
    (tutte o nessuna, se una è sbagliata) e restituisce la lista degli `id`.
    Esempio: `variabile id = db.inserisci("studenti", {"nome": "Ada", "età": 20})`.
    """
    if isinstance(riga, list):
        if not all(isinstance(r, dict) for r in riga):
            raise ErroreTipo("Per inserire più righe serve una lista di dizionari.",
                             suggerimento="Esempio: [{\"nome\": \"Ada\"}, {\"nome\": \"Bruno\"}].")
        return _in_blocco(db, lambda: [db.motore.inserisci(tabella, r) for r in riga])
    if not isinstance(riga, dict):
        raise ErroreTipo(f"La riga da inserire deve essere un dizionario, non {articolo(riga)}.",
                         suggerimento="Esempio: {\"nome\": \"Ada\", \"età\": 20}.")
    return db.motore.inserisci(tabella, riga)


def _in_blocco(db: Database, azione):
    """Esegue ``azione`` in una transazione (se non ce n'è già una aperta)."""
    if db.motore.in_transazione:
        return azione()
    db.motore.inizia_transazione()
    try:
        risultato = azione()
    except BaseException:
        if db.motore.in_transazione:
            db.motore.annulla()
        raise
    db.motore.conferma()
    return risultato


@metodo_oggetto(Database, "cerca")
def db_cerca(db, tabella, /, condizioni=None, ordina="", limite=0, **filtri):
    """db.cerca(tabella, condizioni = nulla, ordina = "", limite = 0): le righe che rispettano le condizioni.

    Il risultato è una lista di dizionari. Condizioni: {"nome": "Ada"} (uguale),
    {"età": [">", 18]}, {"nome": ["contiene", "an"]}, {"voto": ["tra", 18, 30]},
    {"città": ["in", ["Roma", "Milano"]]}; più condizioni valgono tutte insieme.
    Le condizioni di uguaglianza si possono scrivere anche per nome:
    `db.cerca("alunni", classe = "5A")`.
    Ordinamento: "nome", "età discendente", "cognome, nome". Esempio:
    `db.cerca("studenti", {"età": [">=", 18]}, ordina = "nome", limite = 10)`.
    """
    return db.motore.cerca(tabella, _condizioni(condizioni, "cerca", filtri), ordina or "",
                           _limite(limite, "cerca"))


@metodo_oggetto(Database, "trova")
def db_trova(db, tabella, /, condizioni=None, ordina="", limite=0, **filtri):
    """db.trova(tabella, condizioni = nulla, ordina = "", limite = 0): sinonimo di `cerca`.

    Esempio: `db.trova("prodotti", {"prezzo": ["<", 10]})`, `db.trova("alunni", classe = "5A")`.
    """
    return db.motore.cerca(tabella, _condizioni(condizioni, "trova", filtri), ordina or "",
                           _limite(limite, "trova"))


def _limite(limite: Any, metodo: str) -> int:
    if limite is None:
        return 0
    if isinstance(limite, bool) or not isinstance(limite, int):
        raise ErroreTipo(f"`limite` di `{metodo}` deve essere un intero, non {articolo(limite)}.")
    if limite < 0:
        raise ErroreValore(f"`limite` di `{metodo}` non può essere negativo (0 = nessun limite).")
    return limite


@metodo_oggetto(Database, "primo")
def db_primo(db, tabella, /, condizioni=None, ordina="", **filtri):
    """db.primo(tabella, condizioni = nulla, ordina = ""): la prima riga trovata, o `nulla` se non ce n'è.

    Esempio: `variabile s = db.primo("studenti", {"email": "ada@esempio.it"})`
    oppure `db.primo("studenti", email = "ada@esempio.it")`.
    """
    righe = db.motore.cerca(tabella, _condizioni(condizioni, "primo", filtri), ordina or "", 1)
    return righe[0] if righe else None


@metodo_oggetto(Database, "conta")
def db_conta(db, tabella, /, condizioni=None, **filtri):
    """db.conta(tabella, condizioni = nulla): quante righe rispettano le condizioni (tutte, senza condizioni).

    Esempio: `db.conta("studenti", {"età": ["<", 18]})`, `db.conta("alunni", classe = "5A")`.
    """
    return db.motore.conta(tabella, _condizioni(condizioni, "conta", filtri))


def _richiedi_condizioni(condizioni: Any, tutte: Any, metodo: str) -> dict | None:
    richiedi_logico(tutte, metodo, "tutte")
    condizioni = _condizioni(condizioni, metodo)
    if not condizioni and not tutte:
        raise ErroreValore(
            f"`{metodo}` senza condizioni {'cancellerebbe' if metodo == 'elimina' else 'cambierebbe'} "
            "TUTTE le righe della tabella.",
            suggerimento=f"Indica quali righe, per esempio {{\"id\": 3}}; se vuoi davvero tutte "
                         f"le righe scrivi `tutte = vero`.")
    return condizioni or None


@metodo_oggetto(Database, "aggiorna")
def db_aggiorna(db, tabella, condizioni, valori, tutte=False):
    """db.aggiorna(tabella, condizioni, valori, tutte = falso): cambia i valori delle righe scelte.

    Restituisce quante righe sono cambiate. Senza condizioni serve `tutte = vero` (protezione
    contro gli sbagli). Esempio: `db.aggiorna("studenti", {"nome": "Ada"}, {"età": 21})`.
    """
    return db.motore.aggiorna(tabella, _richiedi_condizioni(condizioni, tutte, "aggiorna"), valori)


@metodo_oggetto(Database, "elimina")
def db_elimina(db, tabella, condizioni, tutte=False):
    """db.elimina(tabella, condizioni, tutte = falso): cancella le righe scelte e dice quante erano.

    Senza condizioni serve `tutte = vero` (oppure usa `svuota`).
    Esempio: `db.elimina("studenti", {"id": 3})`.
    """
    return db.motore.elimina(tabella, _richiedi_condizioni(condizioni, tutte, "elimina"))


@metodo_oggetto(Database, "svuota")
def db_svuota(db, tabella):
    """db.svuota(tabella): cancella tutte le righe della tabella (la tabella resta) e dice quante erano.

    Esempio: `db.svuota("carrello")`.
    """
    return db.motore.elimina(tabella, None)


# ---------------------------------------------------------------------------
# SQL avanzato e transazioni
# ---------------------------------------------------------------------------

_VALORE_INCOLLATO = re.compile(r"(=|<|>|\blike\b|\bin\b)\s*'[^']*'\s*$", re.IGNORECASE)


@metodo_oggetto(Database, "esegui")
def db_esegui(db, sql, parametri=None):
    """db.esegui(sql, parametri = nulla): esegue un comando SQL e restituisce le righe (lista di dizionari).

    I valori vanno SEMPRE nei parametri, mai incollati nel testo: `?` con una lista oppure
    `:nome` con un dizionario. Esempi:
    `db.esegui("SELECT città, COUNT(*) AS quanti FROM studenti WHERE età > ? GROUP BY città", [18])`,
    `db.esegui("UPDATE prodotti SET prezzo = prezzo * :k", {"k": 1.1})`.
    """
    richiedi_testo(sql, "esegui", "sql")
    if parametri is not None and not isinstance(parametri, (list, dict)):
        raise ErroreTipo(f"I parametri di `esegui` devono essere una lista (per i `?`) o un dizionario "
                         f"(per i `:nome`), non {articolo(parametri)}.",
                         suggerimento="Esempio: `db.esegui(\"SELECT * FROM t WHERE id = ?\", [3])`.")
    try:
        return db.motore.esegui(sql, parametri)
    except ErroreDante as e:
        if parametri is None and _VALORE_INCOLLATO.search(sql.strip().rstrip(";")):
            consiglio = ("Non incollare i valori nel testo SQL: scrivi `?` al loro posto e passali "
                         "nella lista dei parametri.")
            e.suggerimento = f"{e.suggerimento} {consiglio}" if e.suggerimento else consiglio
        raise


@metodo_oggetto(Database, "transazione", interprete=True)
def db_transazione(interprete, db, azione):
    """db.transazione(azione): esegue la funzione `azione` tutta o niente.

    Se dentro `azione` c'è un errore, tutte le modifiche fatte fin lì vengono annullate
    e l'errore prosegue; altrimenti vengono salvate. Restituisce il risultato di `azione`.
    Esempio:
    `db.transazione(funzione () db.aggiorna("conti", {"id": 1}, {"saldo": 50}) fine)`.
    """
    from ..valori import Richiamabile

    if not isinstance(azione, Richiamabile):
        raise ErroreTipo(f"`transazione` vuole una funzione da eseguire, non {articolo(azione)}.",
                         suggerimento="Esempio: `db.transazione(funzione () ... fine)`.")
    return _in_blocco(db, lambda: interprete.chiama(azione, []))


@metodo_oggetto(Database, "inizia_transazione")
def db_inizia_transazione(db):
    """db.inizia_transazione(): da qui le modifiche restano in sospeso fino a `conferma()` o `annulla()`."""
    db.motore.inizia_transazione()
    return None


@metodo_oggetto(Database, "conferma")
def db_conferma(db):
    """db.conferma(): salva le modifiche della transazione aperta con `inizia_transazione()`."""
    db.motore.conferma()
    return None


@metodo_oggetto(Database, "annulla")
def db_annulla(db):
    """db.annulla(): annulla le modifiche fatte da `inizia_transazione()` in poi."""
    db.motore.annulla()
    return None


# ---------------------------------------------------------------------------
# CSV
# ---------------------------------------------------------------------------

@metodo_oggetto(Database, "esporta_csv")
def db_esporta_csv(db, tabella, percorso, separatore=",", condizioni=None, ordina=""):
    """db.esporta_csv(tabella, percorso, separatore = ",", condizioni = nulla, ordina = ""): salva le righe in un file CSV.

    La prima riga del file ha i nomi delle colonne. Restituisce quante righe ha scritto.
    Esempio: `db.esporta_csv("studenti", "studenti.csv", separatore = ";")` (il `;` piace a Excel).
    """
    _controlla_percorso(percorso, "esporta_csv")
    nomi = list(db.motore.colonne(tabella))
    righe = db.motore.cerca(tabella, _condizioni(condizioni, "esporta_csv"), ordina or "")
    tabella_csv = [nomi] + [[r.get(n) for n in nomi] for r in righe]
    scrivi_tabella(percorso, tabella_csv, separatore)
    return len(righe)


_NON_PAROLA = re.compile(r"[^\w]+")


def _nome_colonna(intestazione: str, posizione: int) -> str:
    nome = _NON_PAROLA.sub("_", intestazione.strip()).strip("_")
    if not nome:
        nome = f"colonna{posizione}"
    if nome[0].isdigit():
        nome = "c_" + nome
    return nome


_VERI = {"vero", "sì", "si", "true", "1", "x"}
_FALSI = {"falso", "no", "false", "0", ""}


def _converti(cella: Any, tipo: str, separatore: str) -> Any:
    """Cella del CSV (testo) -> valore per una colonna del tipo dato; ValueError se non va."""
    if cella is None:
        return None
    testo = str(cella).strip()
    if tipo == "testo":
        return str(cella)
    if testo == "":
        return None
    if tipo == "intero":
        return int(testo.replace("_", ""))
    if tipo == "decimale":
        if "," in testo and separatore != ",":
            testo = testo.replace(".", "").replace(",", ".") if "." in testo else testo.replace(",", ".")
        return float(testo)
    if tipo == "logico":
        minuscolo = testo.lower()
        if minuscolo in _VERI:
            return True
        if minuscolo in _FALSI:
            return False
        raise ValueError(testo)
    return str(cella)


def _indovina_tipo(valori: list, separatore: str) -> str:
    pieni = [v for v in valori if v is not None and str(v).strip() != ""]
    if not pieni:
        return "testo"
    for tipo in ("intero", "decimale"):
        try:
            for v in pieni:
                t = str(v).strip()
                cifre = t.lstrip("+-")
                if len(cifre) > 1 and cifre[0] == "0" and cifre[1].isdigit():
                    raise ValueError(t)  # "007", "00100": codici, non numeri
                _converti(v, tipo, separatore)
            return tipo
        except ValueError:
            continue
    minuscoli = {str(v).strip().lower() for v in pieni}
    if minuscoli <= {"vero", "falso"}:
        return "logico"
    return "testo"


@metodo_oggetto(Database, "importa_csv")
def db_importa_csv(db, percorso, tabella, separatore=None):
    """db.importa_csv(percorso, tabella, separatore = nulla): aggiunge alla tabella le righe di un file CSV.

    La prima riga del file deve avere i nomi delle colonne. Se la tabella non c'è la crea,
    indovinando i tipi (intero, decimale, logico o testo). Tutto o niente: con una riga
    sbagliata non inserisce nulla. Restituisce quante righe ha aggiunto.
    Esempio: `db.importa_csv("prodotti.csv", "prodotti")`.
    """
    richiedi_testo(tabella, "importa_csv", "tabella")
    if separatore is not None:
        richiedi_testo(separatore, "importa_csv", "separatore")
    righe = leggi_tabella(percorso, separatore, True, False)
    if separatore is None:
        from .archivi import _indovina_separatore
        from .ingresso_uscita import leggi_file
        separatore = _indovina_separatore(leggi_file(percorso).split("\n", 1)[0])
    if not righe:
        return 0
    intestazioni = list(righe[0])
    nomi = [_nome_colonna(str(h), i + 1) for i, h in enumerate(intestazioni)]
    if len(set(nomi)) != len(nomi):
        raise ErroreValore(f"Il file `{percorso}` ha due colonne con lo stesso nome.",
                           suggerimento="Rinomina le colonne nella prima riga del file.")
    if tabella.strip() in db.motore.tabelle():
        tipi = db.motore.colonne(tabella)
        mancanti = [n for n in nomi if n not in tipi]
        if mancanti:
            raise ErroreValore(
                f"La tabella `{tabella}` non ha le colonne " + ", ".join(f"`{n}`" for n in mancanti) + ".",
                suggerimento="Colonne della tabella: " + ", ".join(f"`{c}`" for c in tipi) + ".")
    else:
        tipi = {n: _indovina_tipo([r.get(h) for r in righe], separatore) for n, h in zip(nomi, intestazioni)}
        definizione = dict(tipi)
        if "id" in definizione and definizione["id"] == "intero":
            definizione["id"] = "intero chiave"
        db.motore.crea_tabella(tabella, definizione)
    convertite = []
    for numero, r in enumerate(righe, start=2):
        voce = {}
        for n, h in zip(nomi, intestazioni):
            tipo = tipi.get(n, "testo")
            tipo = tipo if tipo in TIPI_COLONNA else "testo"
            try:
                voce[n] = _converti(r.get(h), tipo, separatore)
            except ValueError:
                raise ErroreValore(
                    f"Riga {numero} di `{percorso}`: {mostra(r.get(h))} non va bene per la colonna "
                    f"`{n}` ({tipo}).",
                    suggerimento="Correggi il file oppure importa in una tabella nuova.") from None
        convertite.append(voce)
    _in_blocco(db, lambda: [db.motore.inserisci(tabella, v) for v in convertite])
    return len(convertite)


# ---------------------------------------------------------------------------
# Chiusura
# ---------------------------------------------------------------------------

@metodo_oggetto(Database, "chiudi")
def db_chiudi(db):
    """db.chiudi(): chiude il database (le modifiche sono già salvate). Chiamarlo due volte non è un errore."""
    if db.motore.in_transazione:
        db.motore.annulla()
    db.motore.chiudi()
    return None

