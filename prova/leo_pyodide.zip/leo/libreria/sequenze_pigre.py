"""Libreria: sequenze pigre (flussi che producono gli elementi uno alla volta, solo quando servono).

Una **sequenza pigra** è una lista che non esiste ancora tutta in memoria: gli
elementi si calcolano *mentre* la percorri, uno dopo l'altro. Così puoi avere
sequenze lunghissime o addirittura **senza fine** (i numeri 1, 2, 3, ... per
sempre) e lavorarci senza riempire la memoria: finché prendi solo i primi, gli
altri non vengono mai calcolati.

Perché serve, accanto al parallelismo di Leo (``in parallelo``, canali): i
lavori ``in parallelo`` fanno più cose *insieme*; le sequenze pigre fanno *una
cosa alla volta, al momento giusto*. Niente ``async``/``await`` e niente
"funzioni colorate": una sequenza pigra è un valore normale che si percorre con
``per ogni`` come una lista.

Si creano con:

* ``pigra(qualcosa)``: rende pigra una lista, un intervallo, un testo, un
  dizionario o un canale (così puoi concatenare ``mappa``/``filtra`` senza
  costruire liste in mezzo);
* ``numeri_infiniti(inizio, passo)``: i numeri ``inizio, inizio+passo, ...`` senza
  fine;
* ``genera_sequenza(stato, passo)``: costruisci la tua sequenza passo dopo passo
  (``passo(stato)`` dà ``[valore, nuovo_stato]`` per continuare, oppure
  ``nulla`` per fermarsi);
* ``ripeti_valore(valore, volte)``: lo stesso valore, ``volte`` volte (o senza
  fine).

I metodi che *trasformano* (``mappa``, ``filtra``, ``prendi``, ``salta``,
``finche``, ``salta_finche``, ``con_indice``, ``unisci``) danno SEMPRE una nuova
sequenza pigra e non calcolano niente finché non la percorri. I metodi che
*consumano* (``a_lista``, ``primo``, ``conta``, ``riduci``, ``trova``,
``per_ciascuno``) percorrono davvero la sequenza e danno un risultato: su una
sequenza senza fine vanno usati solo dopo un ``prendi``/``finche``.

Solo libreria standard: funziona anche sul telefono e negli .exe.
"""

from __future__ import annotations

import itertools
from typing import Any, Callable, Iterator

from ..errori import ErroreTipo, ErroreValore
from ..valori import iterabile as _iterabile_valore
from ..valori import rappresenta
from .funzionali import _chiamante, _logico, richiedi_funzione
from .generali import articolo, funzione_libreria, richiedi_intero
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta

__all__ = ["SequenzaPigra", "pigra", "numeri_infiniti", "genera_sequenza", "ripeti_valore"]

#: Ogni quanti elementi i metodi che consumano controllano se il programma è stato fermato
#: (così `conta`/`a_lista` su una sequenza troppo lunga rispondono a Ctrl+C).
PASSO_CONTROLLO_ARRESTO = 4096


class SequenzaPigra(OggettoLibreria):
    """Una sequenza pigra: produce i suoi elementi uno alla volta, solo quando servono.

    Dentro c'è una *fabbrica*: una funzione senza argomenti che, ogni volta che
    serve, dà un nuovo iteratore Python dall'inizio. Così la stessa sequenza si
    può percorrere più volte (come una lista) e i metodi che trasformano la
    avvolgono senza calcolare niente subito.
    """

    NOME_TIPO_DANTE = "sequenza"
    SUGGERIMENTO_MODIFICA = ("Le sequenze pigre non si cambiano: i metodi come `mappa`, `filtra` e "
                             "`prendi` danno sempre una sequenza nuova.")

    def __init__(self, fabbrica: Callable[[], Iterator[Any]], descrizione: str = "sequenza pigra") -> None:
        self._fabbrica = fabbrica
        self._descrizione = descrizione

    def __iter__(self) -> Iterator[Any]:
        return iter(self._fabbrica())

    def elementi_per_ogni(self) -> Iterator[Any]:
        """`per ogni x in sequenza fai`: gli elementi, calcolati uno alla volta."""
        return iter(self._fabbrica())

    def testo_dante(self) -> str:
        return f"<{self._descrizione}>"

    def __repr__(self) -> str:  # pragma: no cover - solo per il debug di Python
        return f"SequenzaPigra({self._descrizione!r})"


# ===========================================================================
# Aiuti interni
# ===========================================================================

def _richiedi_sequenza(valore: Any, nome: str, parametro: str = "sequenza") -> SequenzaPigra:
    if isinstance(valore, SequenzaPigra):
        return valore
    raise ErroreTipo(f"L'argomento `{parametro}` di `{nome}` deve essere una sequenza pigra, non {articolo(valore)}.",
                     suggerimento="Le sequenze pigre si creano con `pigra(...)`, `numeri_infiniti(...)` o `genera_sequenza(...)`.")


def _iteratore(valore: Any) -> Iterator[Any]:
    """Un iteratore su un valore percorribile (lista, intervallo, testo, dizionario, canale, sequenza)."""
    if isinstance(valore, SequenzaPigra):
        return iter(valore._fabbrica())
    return _iterabile_valore(valore)


def _nuova(fabbrica: Callable[[], Iterator[Any]], descrizione: str) -> SequenzaPigra:
    return SequenzaPigra(fabbrica, descrizione)


# ===========================================================================
# Costruttori (funzioni globali)
# ===========================================================================

@funzione_libreria("pigra")
def pigra(percorribile):
    """pigra(percorribile): rende pigra una lista, un intervallo, un testo, un dizionario o un canale.

    Non copia niente subito: gli elementi arrivano mentre percorri. Serve per
    concatenare `mappa`/`filtra`/`prendi` senza costruire liste in mezzo.
    Esempio: `pigra(1..1000000).mappa(quadrato).prendi(5).a_lista()`.
    """
    if isinstance(percorribile, SequenzaPigra):
        return percorribile
    try:
        _iterabile_valore(percorribile)
    except ErroreTipo:
        raise ErroreTipo(f"`pigra` vuole qualcosa da percorrere (lista, intervallo, testo, dizionario, canale), "
                         f"non {articolo(percorribile)}.",
                         suggerimento="Per una sequenza senza fine usa `numeri_infiniti(...)` o `genera_sequenza(...)`.") from None
    descrizione = f"sequenza pigra da {articolo(percorribile)}"
    return _nuova(lambda: _iterabile_valore(percorribile), descrizione)


@funzione_libreria("numeri_infiniti")
def numeri_infiniti(inizio=0, passo=1):
    """numeri_infiniti(inizio = 0, passo = 1): i numeri `inizio, inizio+passo, inizio+2*passo, ...` SENZA fine.

    È pigra: non finisce mai da sola, quindi usala con `prendi(n)` o `finche(...)`.
    Esempio: `numeri_infiniti(1).prendi(5).a_lista()` è [1, 2, 3, 4, 5].
    """
    from ..valori import e_numero

    if not e_numero(inizio) or isinstance(inizio, bool):
        raise ErroreTipo(f"`numeri_infiniti` vuole un numero come `inizio`, non {articolo(inizio)}.")
    if not e_numero(passo) or isinstance(passo, bool):
        raise ErroreTipo(f"`numeri_infiniti` vuole un numero come `passo`, non {articolo(passo)}.")
    if passo == 0:
        raise ErroreValore("Il `passo` di `numeri_infiniti` non può essere 0 (la sequenza non avanzerebbe mai).",
                           suggerimento="Usa 1 per contare in avanti o -1 per contare all'indietro.")

    def fabbrica() -> Iterator[Any]:
        n = inizio
        while True:
            yield n
            n += passo

    return _nuova(fabbrica, f"numeri da {rappresenta(inizio)} a passo {rappresenta(passo)}")


@funzione_libreria("genera_sequenza", interprete=True)
def genera_sequenza(interprete, stato, passo):
    """genera_sequenza(stato, passo): costruisci una sequenza pigra passo dopo passo, partendo da `stato`.

    A ogni passo chiama `passo(stato)`: se dà `nulla` la sequenza finisce;
    altrimenti deve dare una lista `[valore, nuovo_stato]`: `valore` entra nella
    sequenza e `nuovo_stato` è lo stato del passo dopo.
    Esempio (Fibonacci): `genera_sequenza([0, 1], funzione (s) restituisci [s[0], [s[1], s[0] + s[1]]] fine)`.
    """
    f = richiedi_funzione(passo, "genera_sequenza", "passo")
    chiama = _chiamante(interprete, f)

    def fabbrica() -> Iterator[Any]:
        corrente = stato
        while True:
            esito = chiama([corrente])
            if esito is None:
                return
            if not isinstance(esito, list) or len(esito) != 2:
                raise ErroreTipo("La funzione `passo` di `genera_sequenza` deve dare `nulla` (per finire) oppure una "
                                 f"lista di due elementi `[valore, nuovo_stato]`, non {articolo(esito)}.",
                                 suggerimento="Per esempio `restituisci [s, s + 1]`.")
            yield esito[0]
            corrente = esito[1]

    return _nuova(fabbrica, "sequenza generata")


@funzione_libreria("ripeti_valore")
def ripeti_valore(valore, volte=None):
    """ripeti_valore(valore, volte = nulla): una sequenza pigra con lo stesso valore ripetuto.

    Con `volte` lo ripete quel numero di volte; senza `volte` lo ripete SENZA
    fine (usala con `prendi`).
    Esempio: `ripeti_valore("ciao", 3).a_lista()` è ["ciao", "ciao", "ciao"].
    """
    if volte is not None:
        richiedi_intero(volte, "ripeti_valore", "volte")
        if volte < 0:
            raise ErroreValore("`volte` non può essere negativo.", suggerimento="Usa 0 per una sequenza vuota.")

    def fabbrica() -> Iterator[Any]:
        if volte is None:
            while True:
                yield valore
        else:
            for _ in range(volte):
                yield valore

    quante = "senza fine" if volte is None else f"{volte} volte"
    return _nuova(fabbrica, f"valore ripetuto {quante}")


# ===========================================================================
# Metodi che TRASFORMANO: danno una nuova sequenza pigra, non calcolano niente
# ===========================================================================

@metodo_oggetto(SequenzaPigra, "mappa", interprete=True)
def _seq_mappa(interprete, sequenza, funzione):
    """sequenza.mappa(funzione): una nuova sequenza con la funzione applicata a ogni elemento (pigra).

    Esempio: `numeri_infiniti(1).mappa(funzione (x) restituisci x * x fine)`."""
    f = richiedi_funzione(funzione, "mappa")
    chiama = _chiamante(interprete, f)

    def fabbrica() -> Iterator[Any]:
        for x in _iteratore(sequenza):
            yield chiama([x])

    return _nuova(fabbrica, "sequenza mappata")


@metodo_oggetto(SequenzaPigra, "filtra", interprete=True)
def _seq_filtra(interprete, sequenza, funzione):
    """sequenza.filtra(funzione): una nuova sequenza con solo gli elementi per cui la funzione dà `vero` (pigra).

    Esempio: `numeri_infiniti(1).filtra(funzione (x) restituisci x % 2 == 0 fine)` (i pari)."""
    f = richiedi_funzione(funzione, "filtra")
    chiama = _chiamante(interprete, f)

    def fabbrica() -> Iterator[Any]:
        for x in _iteratore(sequenza):
            if _logico(chiama([x]), "filtra", x):
                yield x

    return _nuova(fabbrica, "sequenza filtrata")


@metodo_oggetto(SequenzaPigra, "prendi")
def _seq_prendi(sequenza, quanti):
    """sequenza.prendi(quanti): una nuova sequenza con solo i primi `quanti` elementi.

    È il modo normale per "chiudere" una sequenza senza fine.
    Esempio: `numeri_infiniti(1).prendi(3).a_lista()` è [1, 2, 3]."""
    richiedi_intero(quanti, "prendi", "quanti")
    if quanti < 0:
        raise ErroreValore("`prendi` non può prendere un numero negativo di elementi.",
                           suggerimento="Usa 0 per una sequenza vuota.")

    def fabbrica() -> Iterator[Any]:
        return itertools.islice(_iteratore(sequenza), quanti)

    return _nuova(fabbrica, f"primi {quanti} elementi")


@metodo_oggetto(SequenzaPigra, "salta")
def _seq_salta(sequenza, quanti):
    """sequenza.salta(quanti): una nuova sequenza senza i primi `quanti` elementi.

    Esempio: `numeri_infiniti(1).salta(2).prendi(3).a_lista()` è [3, 4, 5]."""
    richiedi_intero(quanti, "salta", "quanti")
    if quanti < 0:
        raise ErroreValore("`salta` non può saltare un numero negativo di elementi.")

    def fabbrica() -> Iterator[Any]:
        return itertools.islice(_iteratore(sequenza), quanti, None)

    return _nuova(fabbrica, f"senza i primi {quanti} elementi")


@metodo_oggetto(SequenzaPigra, "finche", interprete=True)
def _seq_finche(interprete, sequenza, funzione):
    """sequenza.finche(funzione): elementi dall'inizio FINCHÉ la funzione dà `vero`, poi si ferma (pigra).

    Appena un elemento dà `falso`, la sequenza finisce (quello e i successivi non ci sono).
    Esempio: `numeri_infiniti(1).finche(funzione (x) restituisci x < 100 fine)`."""
    f = richiedi_funzione(funzione, "finche")
    chiama = _chiamante(interprete, f)

    def fabbrica() -> Iterator[Any]:
        for x in _iteratore(sequenza):
            if not _logico(chiama([x]), "finche", x):
                return
            yield x

    return _nuova(fabbrica, "sequenza fino a una condizione")


@metodo_oggetto(SequenzaPigra, "salta_finche", interprete=True)
def _seq_salta_finche(interprete, sequenza, funzione):
    """sequenza.salta_finche(funzione): salta gli elementi iniziali FINCHÉ la funzione dà `vero`, poi dà il resto (pigra).

    Esempio: `pigra([1, 2, 10, 3]).salta_finche(funzione (x) restituisci x < 5 fine).a_lista()` è [10, 3]."""
    f = richiedi_funzione(funzione, "salta_finche")
    chiama = _chiamante(interprete, f)

    def fabbrica() -> Iterator[Any]:
        it = _iteratore(sequenza)
        for x in it:
            if not _logico(chiama([x]), "salta_finche", x):
                yield x
                break
        yield from it

    return _nuova(fabbrica, "sequenza senza l'inizio")


@metodo_oggetto(SequenzaPigra, "con_indice")
def _seq_con_indice(sequenza, da=0):
    """sequenza.con_indice(da = 0): una nuova sequenza di coppie `[indice, elemento]` (pigra).

    Comoda con `per ogni i, x in sequenza.con_indice() fai`.
    Esempio: `pigra(["a", "b"]).con_indice().a_lista()` è [[0, "a"], [1, "b"]]."""
    richiedi_intero(da, "con_indice", "da")

    def fabbrica() -> Iterator[Any]:
        for i, x in enumerate(_iteratore(sequenza), da):
            yield [i, x]

    return _nuova(fabbrica, "sequenza con indice")


@metodo_oggetto(SequenzaPigra, "unisci")
def _seq_unisci(sequenza, altra):
    """sequenza.unisci(altra): una nuova sequenza con prima questi elementi e poi quelli di `altra` (pigra).

    `altra` può essere un'altra sequenza pigra o una lista/intervallo/testo.
    Esempio: `numeri_infiniti(1).prendi(2).unisci([9, 8]).a_lista()` è [1, 2, 9, 8]."""
    try:
        _iteratore(altra)
    except ErroreTipo:
        raise ErroreTipo(f"`unisci` vuole una sequenza o qualcosa da percorrere, non {articolo(altra)}.") from None

    def fabbrica() -> Iterator[Any]:
        yield from _iteratore(sequenza)
        yield from _iteratore(altra)

    return _nuova(fabbrica, "due sequenze unite")


# ===========================================================================
# Metodi che CONSUMANO: percorrono la sequenza e danno un risultato
# ===========================================================================

def _controlla_arresto(interprete, contatore: int) -> int:
    """Ogni tanto controlla se il programma è stato fermato (Ctrl+C), per non restare bloccati su una sequenza lunga."""
    contatore += 1
    if contatore >= PASSO_CONTROLLO_ARRESTO:
        if getattr(interprete, "fermato", False):
            from ..errori import SegnaleFermaProgramma
            raise SegnaleFermaProgramma()
        return 0
    return contatore


@metodo_oggetto(SequenzaPigra, "a_lista", interprete=True)
def _seq_a_lista(interprete, sequenza):
    """sequenza.a_lista(): percorre tutta la sequenza e ne fa una lista vera.

    ATTENZIONE: su una sequenza senza fine non termina mai. Usa prima `prendi(n)` o `finche(...)`.
    Esempio: `numeri_infiniti(1).prendi(3).a_lista()` è [1, 2, 3]."""
    risultato: list = []
    contatore = 0
    for x in _iteratore(sequenza):
        risultato.append(x)
        contatore = _controlla_arresto(interprete, contatore)
    return risultato


@metodo_oggetto(SequenzaPigra, "primo")
def _seq_primo(sequenza, predefinito=None):
    """sequenza.primo(predefinito = nulla): il primo elemento, o `predefinito` se la sequenza è vuota.

    Calcola solo il primo elemento (il resto no).
    Esempio: `numeri_infiniti(10).primo()` è 10."""
    for x in _iteratore(sequenza):
        return x
    return predefinito


@metodo_oggetto(SequenzaPigra, "conta", interprete=True)
def _seq_conta(interprete, sequenza):
    """sequenza.conta(): quanti elementi ha la sequenza (la percorre tutta).

    ATTENZIONE: su una sequenza senza fine non termina mai. Usa prima `prendi(n)` o `finche(...)`.
    Esempio: `numeri_infiniti(1).prendi(100).conta()` è 100."""
    totale = 0
    contatore = 0
    for _ in _iteratore(sequenza):
        totale += 1
        contatore = _controlla_arresto(interprete, contatore)
    return totale


_NESSUNO = object()


@metodo_oggetto(SequenzaPigra, "riduci", interprete=True)
def _seq_riduci(interprete, sequenza, funzione, iniziale=_NESSUNO):
    """sequenza.riduci(funzione, iniziale): combina tutti gli elementi in un solo valore (percorre tutta la sequenza).

    La funzione riceve il risultato "fin qui" e l'elemento successivo.
    Esempio: `numeri_infiniti(1).prendi(4).riduci(funzione (t, x) restituisci t + x fine)` è 10."""
    f = richiedi_funzione(funzione, "riduci")
    chiama = _chiamante(interprete, f)
    it = _iteratore(sequenza)
    if iniziale is _NESSUNO:
        for primo in it:
            risultato = primo
            break
        else:
            raise ErroreValore("Non posso `riduci`re una sequenza vuota senza un valore `iniziale`.",
                               suggerimento="Aggiungi il punto di partenza: `sequenza.riduci(f, iniziale = 0)`.")
    else:
        risultato = iniziale
    contatore = 0
    for x in it:
        risultato = chiama([risultato, x])
        contatore = _controlla_arresto(interprete, contatore)
    return risultato


@metodo_oggetto(SequenzaPigra, "trova", interprete=True)
def _seq_trova(interprete, sequenza, funzione, predefinito=None):
    """sequenza.trova(funzione, predefinito = nulla): il primo elemento per cui la funzione dà `vero`.

    Si ferma appena lo trova (gli elementi dopo non vengono calcolati). Se non
    c'è, dà `predefinito`.
    Esempio: `numeri_infiniti(1).trova(funzione (x) restituisci x * x > 50 fine)` è 8."""
    f = richiedi_funzione(funzione, "trova")
    chiama = _chiamante(interprete, f)
    for x in _iteratore(sequenza):
        if _logico(chiama([x]), "trova", x):
            return x
    return predefinito


@metodo_oggetto(SequenzaPigra, "per_ciascuno", interprete=True)
def _seq_per_ciascuno(interprete, sequenza, funzione):
    """sequenza.per_ciascuno(funzione): chiama la funzione su ogni elemento (per gli effetti, es. stampare).

    ATTENZIONE: su una sequenza senza fine non termina mai. Non dà un risultato (`nulla`).
    Esempio: `pigra([1, 2, 3]).per_ciascuno(stampa)`."""
    f = richiedi_funzione(funzione, "per_ciascuno")
    chiama = _chiamante(interprete, f)
    contatore = 0
    for x in _iteratore(sequenza):
        chiama([x])
        contatore = _controlla_arresto(interprete, contatore)
    return None
