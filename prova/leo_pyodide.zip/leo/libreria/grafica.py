"""Libreria grafica: messaggio, domanda, apri_finestra, chiudi_finestra e le forme.

Le prime quattro usano il ponte grafico dell'interprete
(``interprete.ponte_grafico``); in un programma senza finestre usano
``PonteConsole``, che scrive e legge sul terminale.

Le funzioni ``forma_*`` creano le forme delle finestre (``Finestra1.forma =
forma_stella(5)``) delegando a ``leo.grafica.forme``, importato solo quando
servono (così la libreria si carica anche senza la parte grafica).
"""

from __future__ import annotations

from typing import Any

from ..errori import ErroreDante, ErroreTipo, ErroreValore
from ..valori import OggettoControllo, e_numero, nome_tipo, rappresenta
from .generali import (articolo, funzione_libreria, mostra, richiedi_intero, richiedi_numero,
                       richiedi_testo)


def _ponte(interprete: Any):
    ponte = getattr(interprete, "ponte_grafico", None)
    if ponte is None:
        from ..grafica.ponte import PonteConsole

        ponte = PonteConsole(interprete)
    return ponte


def _testo_da_mostrare(valore: Any) -> str:
    return valore if isinstance(valore, str) else rappresenta(valore)


@funzione_libreria("messaggio", interprete=True)
def messaggio(interprete, testo, titolo="Leo"):
    """messaggio(testo, titolo = "Leo"): mostra una finestrella con il testo e il pulsante OK.

    Il programma aspetta che l'utente prema OK. Esempio: `messaggio("Salvataggio completato!")`.
    """
    richiedi_testo(titolo, "messaggio", "titolo")
    _ponte(interprete).messaggio(_testo_da_mostrare(testo), titolo)
    return None


@funzione_libreria("domanda", interprete=True)
def domanda(interprete, testo, titolo="Leo"):
    """domanda(testo, titolo = "Leo"): chiede Sì/No all'utente; restituisce `vero` per Sì.

    Esempio: `se domanda("Vuoi uscire?") allora chiudi_finestra("Finestra1") fine`.
    """
    richiedi_testo(titolo, "domanda", "titolo")
    return bool(_ponte(interprete).domanda(_testo_da_mostrare(testo), titolo))


def _nome_finestra(nome: Any, funzione_nome: str) -> str:
    if isinstance(nome, OggettoControllo) and not getattr(nome, "E_VALORE_LIBRERIA", False):
        return nome.nome
    if isinstance(nome, str):
        if not nome.strip():
            raise ErroreValore(f"Il nome della finestra per `{funzione_nome}` è vuoto.",
                               suggerimento=f"Scrivi per esempio `{funzione_nome}(\"Finestra2\")`.")
        return nome
    raise ErroreTipo(f"`{funzione_nome}` vuole il nome della finestra (un testo), non {articolo(nome)}.",
                     suggerimento=f"Scrivi per esempio `{funzione_nome}(\"Finestra2\")`.")


@funzione_libreria("apri_finestra", interprete=True)
def apri_finestra(interprete, nome):
    """apri_finestra(nome): mostra un'altra finestra del progetto.

    Esempio: `apri_finestra("Impostazioni")`.
    """
    _ponte(interprete).apri_finestra(_nome_finestra(nome, "apri_finestra"))
    return None


@funzione_libreria("chiudi_finestra", interprete=True)
def chiudi_finestra(interprete, nome):
    """chiudi_finestra(nome): chiude una finestra; chiudere la finestra iniziale termina il programma.

    Esempio: `chiudi_finestra("Impostazioni")`.
    """
    _ponte(interprete).chiudi_finestra(_nome_finestra(nome, "chiudi_finestra"))
    return None


# ---------------------------------------------------------------------------
# Forme delle finestre
# ---------------------------------------------------------------------------

def _delega(nome: str, *argomenti: Any) -> Any:
    """Chiama ``leo.grafica.forme.<nome>(*argomenti)`` con import pigro."""
    try:
        from ..grafica import forme
        funzione_forme = getattr(forme, nome)
    except (ImportError, AttributeError):
        raise ErroreValore(f"`{nome}` non è disponibile: manca il modulo delle forme di Leo.") from None
    try:
        return funzione_forme(*argomenti)
    except ErroreDante:
        raise
    except NotImplementedError:
        raise ErroreValore(f"`{nome}` non è ancora disponibile in questa versione di Leo.") from None
    except (TypeError, ValueError, ArithmeticError, IndexError, KeyError, AttributeError) as e:
        raise ErroreValore(f"Non posso creare la forma con `{nome}`: {e}.") from None


def _richiedi_forma(valore: Any, funzione_nome: str, parametro: str) -> Any:
    if nome_tipo(valore) in ("forma", "testo"):
        return valore
    raise ErroreTipo(
        f"L'argomento `{parametro}` di `{funzione_nome}` deve essere una forma o il nome di una forma, "
        f"non {articolo(valore)}.",
        suggerimento="Per esempio `\"cerchio\"`, `\"rettangolo\"` o `forma_poligono(6)`.",
    )


@funzione_libreria("forma_poligono")
def forma_poligono(lati):
    """forma_poligono(lati): un poligono regolare con quel numero di lati (almeno 3).

    Esempio: `Finestra1.forma = forma_poligono(6)` dà una finestra a esagono.
    """
    richiedi_intero(lati, "forma_poligono", "lati")
    return _delega("forma_poligono", lati)


@funzione_libreria("forma_stella")
def forma_stella(punte, profondita=0.5):
    """forma_stella(punte, profondita = 0.5): una stella con quel numero di punte (almeno 3).

    `profondita` (tra 0 e 1, esclusi) dice quanto sono profonde le rientranze.
    Esempio: `Finestra1.forma = forma_stella(5)`.
    """
    richiedi_intero(punte, "forma_stella", "punte")
    richiedi_numero(profondita, "forma_stella", "profondita")
    return _delega("forma_stella", punte, profondita)


@funzione_libreria("forma_punti")
def forma_punti(punti):
    """forma_punti(punti): una forma libera con i vertici indicati in pixel (almeno 3).

    Esempio: `Finestra1.forma = forma_punti([[0, 0], [300, 40], [150, 260]])`.
    """
    if not isinstance(punti, list):
        raise ErroreTipo(f"`forma_punti` vuole una lista di punti [x, y], non {articolo(punti)}.",
                         suggerimento="Per esempio `forma_punti([[0, 0], [300, 40], [150, 260]])`.")
    for i, punto in enumerate(punti):
        if not (isinstance(punto, list) and len(punto) == 2 and all(e_numero(c) for c in punto)):
            raise ErroreTipo(f"Il punto {i} di `forma_punti` deve essere una lista di due numeri [x, y], "
                             f"non {mostra(punto)}.")
    return _delega("forma_punti", punti)


@funzione_libreria("forma_immagine")
def forma_immagine(percorso):
    """forma_immagine(percorso): la forma ricavata da un'immagine PNG (le parti trasparenti restano fuori).

    Esempio: `Finestra1.forma = forma_immagine("gatto.png")`.
    """
    richiedi_testo(percorso, "forma_immagine", "percorso")
    if not percorso.strip():
        raise ErroreValore("Il percorso dell'immagine per `forma_immagine` è vuoto.")
    return _delega("forma_immagine", percorso)


@funzione_libreria("forma_unisci")
def forma_unisci(a, b):
    """forma_unisci(a, b): la forma fatta da `a` più `b` (un punto è dentro se sta in una delle due).

    `a` e `b` sono forme o nomi di forme. Esempio: `forma_unisci("cerchio", forma_stella(5))`.
    """
    _richiedi_forma(a, "forma_unisci", "a")
    _richiedi_forma(b, "forma_unisci", "b")
    return _delega("forma_unisci", a, b)


@funzione_libreria("forma_sottrai")
def forma_sottrai(a, b):
    """forma_sottrai(a, b): la forma `a` a cui si toglie `b` (per esempio una ciambella).

    Esempio: `forma_sottrai("cerchio", forma_poligono(8))`.
    """
    _richiedi_forma(a, "forma_sottrai", "a")
    _richiedi_forma(b, "forma_sottrai", "b")
    return _delega("forma_sottrai", a, b)


# ---------------------------------------------------------------------------
# Codici dei colori
# ---------------------------------------------------------------------------

@funzione_libreria("rgb")
def rgb(rosso, verde, blu):
    """rgb(rosso, verde, blu): il codice di un colore dai tre numeri da 0 a 255.

    `Finestra1.sfondo = rgb(255, 136, 0)` colora di arancione. Restituisce
    un testo come "#FF8800", che si può usare dovunque serva un colore.
    """
    valori = []
    for nome, v in (("rosso", rosso), ("verde", verde), ("blu", blu)):
        n = richiedi_intero(v, "rgb", nome)
        if not 0 <= n <= 255:
            raise ErroreValore(f"In `rgb` il {nome} deve essere tra 0 e 255, non {n}.",
                               suggerimento="Per esempio `rgb(255, 136, 0)` è arancione.")
        valori.append(n)
    return "#{:02X}{:02X}{:02X}".format(*valori)
