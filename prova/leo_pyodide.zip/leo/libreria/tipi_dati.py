"""Libreria: copie, tipi scritti e campi delle strutture (programmi grandi).

* ``copia(valore)``: una copia modificabile e indipendente (anche annidata) di
  liste, dizionari e strutture, per esempio del contenuto di una ``costante``;
* ``ha_tipo(valore, "lista di intero")``: il valore è di quel tipo?
* ``campi(valore)``: i campi di una struttura in un dizionario.
"""

from __future__ import annotations

from ..errori import ErroreTipo, ErroreValore
from .generali import articolo, funzione_libreria, richiedi_testo


@funzione_libreria("copia")
def copia(valore):
    """copia(valore): una copia indipendente di una lista, di un dizionario o di una struttura (anche annidati).

    Cambiare la copia non cambia l'originale. Serve anche per lavorare sul
    contenuto di una `costante`, che non si può modificare.
    Esempio: `variabile mia = copia(PRIMI)` e poi `mia.aggiungi(7)`.
    """
    from ..controllo.strutture import sblocca

    return sblocca(valore)


@funzione_libreria("ha_tipo")
def ha_tipo(valore, tipo):
    """ha_tipo(valore, tipo): `vero` se il valore è del tipo scritto nel testo `tipo`.

    Il tipo si scrive come nelle dichiarazioni: `"intero"`, `"testo?"`,
    `"lista di decimale"`, il nome di una struttura o di un tipo a varianti.
    Esempio: `ha_tipo([1, 2], "lista di intero")` è `vero`.
    """
    from ..controllo.tipi import conforme, leggi_tipo

    richiedi_testo(tipo, "ha_tipo", "tipo")
    try:
        leggi_tipo(tipo)
    except ValueError as e:
        raise ErroreValore(str(e), suggerimento="Per esempio `\"intero\"`, `\"testo?\"`, `\"lista di decimale\"`.") \
            from None
    return conforme(valore, tipo)


@funzione_libreria("campi")
def campi(valore):
    """campi(valore): i campi di una struttura con i loro valori, in un dizionario.

    Esempio: con `struttura Punto` (campi `x` e `y`), `campi(Punto(1, 2))` è `{"x": 1, "y": 2}`.
    """
    dati = getattr(valore, "valori_campi", None)
    if dati is None:
        raise ErroreTipo(f"`campi` vuole il valore di una `struttura`, non {articolo(valore)}.")
    return dict(dati)
