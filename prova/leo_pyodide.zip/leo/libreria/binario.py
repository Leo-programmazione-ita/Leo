"""Libreria: dati binari e sicurezza difensiva.

* il tipo ``dati_binari`` (una sequenza di byte da 0 a 255) creato da un testo,
  una lista di byte, un testo esadecimale/Base64/Base32/Base85/bit o un file,
  con i metodi ``pezzo``, ``unisci``, ``cerca``, ``in_lista``, ``in_testo``,
  ``codifica``, ``leggi_numero`` (interi e decimali come ``struct``, ma con parole
  italiane), ``salva``; ``numero_in_byte`` fa il contrario di ``leggi_numero``;
* file: ``vista_esadecimale`` (come *hexdump*), ``riconosci_tipo_file`` (dai primi
  byte, anche se l'estensione mente), ``entropia_file``, ``leggi_exif`` e
  ``togli_exif`` (i metadati delle foto, con la posizione GPS);
* ``comprimi_dati``/``decomprimi_dati`` (gzip, zlib, bz2, xz), con un limite contro
  le "bombe" di compressione;
* cifratura vera (AES-256-GCM con chiave derivata dalla password con scrypt) e
  firme digitali Ed25519: servono il pacchetto facoltativo ``cryptography``; se
  manca, un messaggio italiano spiega come installarlo. Nessun cifrario fatto a mano;
* ``impronta_cartella``/``confronta_impronte``: controllo di integrità di una cartella;
* ``cifrario_cesare``, ``cifrario_vigenere``, ``prova_tutti_cesare``: cifrari
  storici SOLO DIDATTICI, non sicuri (il terzo mostra perché);
* ``e_password_comune``: la password è tra quelle più usate (elenco locale)?
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import math
import os
import secrets
import struct
import zlib
from collections import Counter
from typing import Any

from ..errori import ErroreFile, ErroreTipo, ErroreValore
from ..valori import e_numero
from .generali import (articolo, funzione_libreria, mostra, richiedi_intero, richiedi_logico, richiedi_testo)
from .ingresso_uscita import _controlla_percorso, _errore_file
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta

#: Dati più grandi di così (in byte) non si trattano in memoria.
MASSIMO_DATI = 256 * 1024 * 1024
#: Limite dei dati decompressi (contro le "bombe" di compressione).
MASSIMO_DECOMPRESSO = 256 * 1024 * 1024
#: Quanti byte mostra al massimo `vista_esadecimale`.
MASSIMO_VISTA = 64 * 1024


# ===========================================================================
# Strumenti comuni
# ===========================================================================

def _serve_cryptography(nome_funzione: str):
    try:
        from cryptography.hazmat.primitives.asymmetric import ed25519  # noqa: F401
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM  # noqa: F401
    except Exception:  # noqa: BLE001 - pacchetto assente o rotto
        raise ErroreValore(
            f"`{nome_funzione}` ha bisogno del pacchetto `cryptography`, che su questo computer non c'è.",
            suggerimento="Installalo con `pip install cryptography` (nell'app per il telefono aggiungilo ai "
                         "pacchetti). Leo non usa cifrari fatti in casa: non sarebbero sicuri.") from None
    import cryptography.exceptions as eccezioni
    from cryptography.hazmat.primitives.asymmetric import ed25519
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    return AESGCM, ed25519, eccezioni


def _byte(dati: Any, nome_funzione: str, parametro: str = "dati") -> bytes:
    """Un testo (UTF-8), una lista di numeri 0-255 o un ``dati_binari`` come ``bytes``."""
    if isinstance(dati, DatiBinari):
        return dati.valore
    if isinstance(dati, str):
        if len(dati) > MASSIMO_DATI:
            raise ErroreValore(f"Il testo dato a `{nome_funzione}` è troppo lungo.")
        return dati.encode("utf-8", "surrogatepass")
    if isinstance(dati, list):
        if len(dati) > MASSIMO_DATI:
            raise ErroreValore(f"La lista di byte data a `{nome_funzione}` è troppo lunga.")
        for i, b in enumerate(dati):
            if type(b) is not int or not 0 <= b <= 255:
                raise ErroreValore(f"Nella lista di byte di `{nome_funzione}` l'elemento in posizione {i} "
                                   f"({mostra(b)}) non è un numero da 0 a 255.")
        return bytes(dati)
    raise ErroreTipo(f"L'argomento `{parametro}` di `{nome_funzione}` deve essere un testo, una lista di byte "
                     f"o dei `dati_binari`, non {articolo(dati)}.")


def _leggi_file(percorso: Any, nome_funzione: str, massimo: int = MASSIMO_DATI) -> bytes:
    _controlla_percorso(percorso, nome_funzione)
    try:
        with open(percorso, "rb") as f:
            contenuto = f.read(massimo + 1)
    except OSError as e:
        raise _errore_file(e, percorso, "leggere") from None
    if len(contenuto) > massimo:
        raise ErroreValore(f"Il file `{percorso}` è troppo grande per `{nome_funzione}` "
                           f"(massimo {massimo // (1024 * 1024)} MB).")
    return contenuto


def _scrivi_file(percorso: str, contenuto: bytes, sovrascrivi: bool, nome_funzione: str) -> None:
    """Scrive passando da un file temporaneo: se qualcosa va storto il file vecchio resta intatto."""
    if os.path.isdir(percorso):
        raise ErroreFile(f"`{percorso}` è una cartella, non un file.")
    if not sovrascrivi and os.path.exists(percorso):
        raise ErroreFile(f"Il file `{percorso}` esiste già e `{nome_funzione}` non lo sovrascrive.",
                         suggerimento="Scegli un altro nome oppure aggiungi `sovrascrivi = vero`.")
    temporaneo = f"{percorso}.leo_parziale_{secrets.token_hex(4)}"
    try:
        with open(temporaneo, "wb") as f:
            f.write(contenuto)
        os.replace(temporaneo, percorso)
    except OSError as e:
        try:
            os.remove(temporaneo)
        except OSError:
            pass
        raise _errore_file(e, percorso, "scrivere") from None


def _testo_utf8(contenuto: bytes, nome_funzione: str, suggerimento: str) -> str:
    try:
        return contenuto.decode("utf-8")
    except UnicodeDecodeError:
        raise ErroreValore(f"Il risultato di `{nome_funzione}` non è un testo leggibile (sono dati binari).",
                           suggerimento=suggerimento) from None


# ===========================================================================
# Il tipo `dati_binari`
# ===========================================================================

class DatiBinari(OggettoLibreria):
    """Valore Leo di tipo ``dati_binari``: una sequenza immutabile di byte."""

    NOME_TIPO_DANTE = "dati_binari"
    SUGGERIMENTO_MODIFICA = "I dati binari non si cambiano: crea dati nuovi, per esempio `d = d.unisci([0])`."

    def __init__(self, valore: bytes) -> None:
        self.valore = bytes(valore)

    def testo_dante(self) -> str:
        n = len(self.valore)
        anteprima = " ".join(f"{b:02X}" for b in self.valore[:16])
        altro = " ..." if n > 16 else ""
        return f"dati_binari({n} byte{': ' if n else ''}{anteprima}{altro})"

    def __eq__(self, altro: object) -> bool:
        return isinstance(altro, DatiBinari) and altro.valore == self.valore

    def __hash__(self) -> int:
        return hash(self.valore)

    def __repr__(self) -> str:
        return self.testo_dante()


_FORMATI = ("testo", "esadecimale", "base64", "base32", "base85", "bit", "file")


def _nome_formato(formato: Any, nome_funzione: str) -> str:
    richiedi_testo(formato, nome_funzione, "formato")
    chiave = formato.strip().lower().replace(" ", "").replace("_", "")
    chiave = {"hex": "esadecimale", "esa": "esadecimale", "binario": "bit", "bits": "bit",
              "utf8": "testo", "utf-8": "testo"}.get(chiave, chiave)
    if chiave not in _FORMATI:
        raise ErroreValore(f"Non conosco il formato {mostra(formato)}.",
                           suggerimento="Formati: " + ", ".join(f'"{f}"' for f in _FORMATI) + ".")
    return chiave


def _decodifica(testo: str, formato: str, nome_funzione: str) -> bytes:
    pulito = "".join(testo.split())
    if len(pulito) > MASSIMO_DATI:
        raise ErroreValore(f"Il testo dato a `{nome_funzione}` è troppo lungo.")
    try:
        if formato == "esadecimale":
            pulito = pulito.replace(":", "").replace("-", "")
            if pulito[:2].lower() == "0x":
                pulito = pulito[2:]
            if len(pulito) % 2:
                raise ErroreValore(f"Il testo esadecimale {mostra(testo)} ha un numero dispari di cifre.",
                                   suggerimento="Ogni byte si scrive con due cifre: \"0A\", non \"A\".")
            return bytes.fromhex(pulito)
        if formato == "base64":
            pulito = pulito.replace("-", "+").replace("_", "/")
            return base64.b64decode(pulito + "=" * (-len(pulito) % 4), validate=True)
        if formato == "base32":
            pulito = pulito.upper()
            return base64.b32decode(pulito + "=" * (-len(pulito) % 8))
        if formato == "base85":
            return base64.b85decode(pulito)
        # bit: gruppi di 0 e 1, 8 per byte
        if set(pulito) - {"0", "1"}:
            raise ErroreValore(f"Il testo {mostra(testo)} non contiene solo bit (0 e 1).")
        if len(pulito) % 8:
            raise ErroreValore(f"Il numero di bit ({len(pulito)}) non è un multiplo di 8.",
                               suggerimento="Ogni byte ha 8 bit, per esempio \"01001100\".")
        return bytes(int(pulito[i:i + 8], 2) for i in range(0, len(pulito), 8))
    except (binascii.Error, ValueError, UnicodeEncodeError) as e:
        if isinstance(e, ErroreValore):
            raise
        raise ErroreValore(f"Il testo {mostra(testo)} non è {formato} valido.",
                           suggerimento="Controlla di aver copiato tutto il testo, senza lettere in più.") from None


@funzione_libreria("dati_binari")
def dati_binari(valore=None, formato="testo"):
    """dati_binari(valore, formato = "testo"): una sequenza di byte (numeri da 0 a 255) comoda da maneggiare.

    `valore` può essere un testo, una lista di byte o altri dati binari. Il `formato` dice come leggere un testo:
    "testo" (le lettere in UTF-8), "esadecimale", "base64", "base32", "base85", "bit" o "file" (il testo è il
    percorso di un file da leggere). Proprietà: `lunghezza`. Metodi: `pezzo`, `unisci`, `cerca`, `in_lista`,
    `in_testo`, `codifica`, `leggi_numero`, `salva`.
    Esempi: `dati_binari("Leo")`; `dati_binari("4C 65 6F", "esadecimale")`; `dati_binari("foto.png", "file")`.
    """
    fmt = _nome_formato(formato, "dati_binari")
    if valore is None:
        return DatiBinari(b"")
    if fmt == "file":
        return DatiBinari(_leggi_file(valore, "dati_binari"))
    if fmt != "testo":
        richiedi_testo(valore, "dati_binari", "valore")
        return DatiBinari(_decodifica(valore, fmt, "dati_binari"))
    return DatiBinari(_byte(valore, "dati_binari", "valore"))


proprieta(DatiBinari, "lunghezza")(lambda d: len(d.valore))


def _posizione(n: Any, lunghezza: int, nome: str, parametro: str) -> int:
    richiedi_intero(n, nome, parametro)
    if n < 0:
        n += lunghezza
    if not 0 <= n <= lunghezza:
        raise ErroreValore(f"La posizione {mostra(n)} di `{nome}` è fuori dai dati (sono {lunghezza} byte).",
                           suggerimento=f"Le posizioni vanno da 0 a {lunghezza}; i numeri negativi contano dalla fine.")
    return n


@metodo_oggetto(DatiBinari, "pezzo")
def binari_pezzo(d, inizio=0, fine=None):
    """dati.pezzo(inizio, fine = nulla): i byte da `inizio` (compreso) a `fine` (escluso), come nuovi dati binari.

    I numeri negativi contano dalla fine. Esempio: `dati_binari("ciao").pezzo(1, 3).in_testo()` è "ia".
    """
    n = len(d.valore)
    a = _posizione(inizio, n, "pezzo", "inizio")
    b = n if fine is None else _posizione(fine, n, "pezzo", "fine")
    return DatiBinari(d.valore[a:max(a, b)])


@metodo_oggetto(DatiBinari, "unisci")
def binari_unisci(d, *altri):
    """dati.unisci(altri...): questi dati seguiti da altri (testi, liste di byte o dati binari).

    Esempio: `dati_binari("Le").unisci("o", [33]).in_testo()` è "Leo!".
    """
    pezzi = [d.valore] + [_byte(a, "unisci", "altri") for a in altri]
    if sum(len(p) for p in pezzi) > MASSIMO_DATI:
        raise ErroreValore("I dati uniti sarebbero troppo grandi.")
    return DatiBinari(b"".join(pezzi))


@metodo_oggetto(DatiBinari, "cerca")
def binari_cerca(d, sequenza, da=0):
    """dati.cerca(sequenza, da = 0): la posizione della prima volta che compare `sequenza`, o `nulla`.

    Esempio: `dati_binari("banana").cerca("na")` è 2; `dati_binari("banana").cerca("na", 3)` è 4.
    """
    cercati = _byte(sequenza, "cerca", "sequenza")
    inizio = _posizione(da, len(d.valore), "cerca", "da")
    p = d.valore.find(cercati, inizio)
    return None if p < 0 else p


@metodo_oggetto(DatiBinari, "in_lista")
def binari_in_lista(d):
    """dati.in_lista(): i byte come lista di numeri da 0 a 255.

    Esempio: `dati_binari("Leo").in_lista()` è [76, 101, 111].
    """
    return list(d.valore)


@metodo_oggetto(DatiBinari, "in_testo")
def binari_in_testo(d, codifica="utf-8"):
    """dati.in_testo(codifica = "utf-8"): i byte letti come lettere di un testo.

    Altre codifiche: "latin-1", "cp1252" (Windows), "utf-16", "ascii".
    Esempio: `dati_binari([76, 101, 111]).in_testo()` è "Leo".
    """
    richiedi_testo(codifica, "in_testo", "codifica")
    nome = codifica.strip().lower()
    if not nome:
        raise ErroreValore("La codifica di `in_testo` è vuota.", suggerimento="Usa \"utf-8\".")
    try:
        "".encode(nome)
    except (LookupError, ValueError):
        raise ErroreValore(f"Non conosco la codifica {mostra(codifica)}.",
                           suggerimento="Prova \"utf-8\", \"latin-1\" o \"cp1252\".") from None
    try:
        return d.valore.decode(nome)
    except (UnicodeDecodeError, ValueError):
        raise ErroreValore(f"Questi byte non sono un testo valido in {nome}.",
                           suggerimento="Forse sono dati binari (un'immagine, un file compresso): guardali con "
                                        "`vista_esadecimale(dati)`, oppure prova la codifica \"latin-1\".") from None


@metodo_oggetto(DatiBinari, "codifica")
def binari_codifica(d, formato="esadecimale", separatore=""):
    """dati.codifica(formato = "esadecimale", separatore = ""): i byte scritti come testo in un formato.

    Formati: "esadecimale", "base64", "base32", "base85", "bit" (8 zeri e uni per byte).
    Il `separatore` va tra un byte e l'altro (solo per "esadecimale" e "bit").
    Esempi: `dati_binari("Leo").codifica()` è "4c656f"; `dati_binari("A").codifica("bit")` è "01000001".
    """
    fmt = _nome_formato(formato, "codifica")
    richiedi_testo(separatore, "codifica", "separatore")
    if fmt in ("testo", "file"):
        raise ErroreValore(f"`codifica` non usa il formato \"{fmt}\".",
                           suggerimento="Per le lettere usa `in_testo()`, per un file usa `salva(percorso)`.")
    if fmt == "esadecimale":
        return separatore.join(f"{b:02x}" for b in d.valore)
    if fmt == "bit":
        return separatore.join(f"{b:08b}" for b in d.valore)
    if fmt == "base64":
        return base64.b64encode(d.valore).decode("ascii")
    if fmt == "base32":
        return base64.b32encode(d.valore).decode("ascii")
    return base64.b85encode(d.valore).decode("ascii")


def _ordine(ordine: Any, nome_funzione: str) -> str:
    richiedi_testo(ordine, nome_funzione, "ordine")
    chiave = ordine.strip().lower()
    if chiave in ("piccolo", "little", "piccola", "intel"):
        return "<"
    if chiave in ("grande", "big", "rete", "grossa"):
        return ">"
    raise ErroreValore(f"L'ordine dei byte {mostra(ordine)} non esiste.",
                       suggerimento="Usa \"piccolo\" (prima il byte meno importante, come nei PC) oppure "
                                    "\"grande\" (prima il byte più importante, come in rete).")


def _quanti_byte(byte: Any, nome_funzione: str, decimale: bool) -> int:
    richiedi_intero(byte, nome_funzione, "byte")
    ammessi = (2, 4, 8) if decimale else (1, 2, 4, 8, 16)
    if byte not in ammessi:
        cosa = "un decimale" if decimale else "un intero"
        raise ErroreValore(f"{cosa.capitalize()} non si scrive in {mostra(byte)} byte.",
                           suggerimento="Per " + cosa + " usa " + ", ".join(map(str, ammessi)) + " byte.")
    return byte


@metodo_oggetto(DatiBinari, "leggi_numero")
def binari_leggi_numero(d, posizione=0, byte=4, ordine="piccolo", con_segno=False, decimale=False):
    """dati.leggi_numero(posizione = 0, byte = 4, ordine = "piccolo", con_segno = falso, decimale = falso): legge un numero.

    Legge `byte` byte a partire da `posizione`. `ordine` è "piccolo" (prima il byte meno importante, come nei PC,
    nei WAV e nei BMP) o "grande" (come in rete e nei PNG); `con_segno = vero` per i numeri che possono essere
    negativi; `decimale = vero` per i decimali (2, 4 o 8 byte). Esempi: `dati_binari([1, 2]).leggi_numero(0, 2)` è 513;
    `dati_binari([1, 2]).leggi_numero(0, 2, "grande")` è 258.
    """
    richiedi_logico(con_segno, "leggi_numero", "con_segno")
    richiedi_logico(decimale, "leggi_numero", "decimale")
    quanti = _quanti_byte(byte, "leggi_numero", decimale)
    simbolo = _ordine(ordine, "leggi_numero")
    n = len(d.valore)
    inizio = _posizione(posizione, n, "leggi_numero", "posizione")
    if inizio + quanti > n:
        raise ErroreValore(f"Per leggere {quanti} byte dalla posizione {inizio} servono dati più lunghi "
                           f"(ce ne sono {n}).")
    pezzo = d.valore[inizio:inizio + quanti]
    if decimale:
        return struct.unpack(simbolo + {2: "e", 4: "f", 8: "d"}[quanti], pezzo)[0]
    return int.from_bytes(pezzo, "little" if simbolo == "<" else "big", signed=con_segno)


@metodo_oggetto(DatiBinari, "salva")
def binari_salva(d, percorso, sovrascrivi=True):
    """dati.salva(percorso, sovrascrivi = vero): scrive i byte in un file e restituisce quanti sono.

    Esempio: `dati_binari("ciao").salva("saluto.bin")` è 4.
    """
    _controlla_percorso(percorso, "salva")
    richiedi_logico(sovrascrivi, "salva", "sovrascrivi")
    _scrivi_file(percorso, d.valore, sovrascrivi, "salva")
    return len(d.valore)


@funzione_libreria("numero_in_byte")
def numero_in_byte(numero, byte=None, ordine="piccolo", con_segno=False):
    """numero_in_byte(numero, byte = nulla, ordine = "piccolo", con_segno = falso): un numero scritto come byte.

    È il contrario di `dati.leggi_numero(...)`. Un intero usa 4 byte se non dici altro, un decimale 8.
    `ordine` è "piccolo" (prima il byte meno importante) o "grande". Per i negativi serve `con_segno = vero`.
    Esempi: `numero_in_byte(513, 2).in_lista()` è [1, 2]; `numero_in_byte(-1, 1, con_segno = vero).in_lista()` è [255].
    """
    richiedi_logico(con_segno, "numero_in_byte", "con_segno")
    simbolo = _ordine(ordine, "numero_in_byte")
    if isinstance(numero, bool) or not e_numero(numero):
        raise ErroreTipo(f"L'argomento `numero` di `numero_in_byte` deve essere un numero, non {articolo(numero)}.")
    decimale = isinstance(numero, float)
    quanti = _quanti_byte((8 if decimale else 4) if byte is None else byte, "numero_in_byte", decimale)
    if decimale:
        try:
            return DatiBinari(struct.pack(simbolo + {2: "e", 4: "f", 8: "d"}[quanti], numero))
        except (OverflowError, struct.error):
            raise ErroreValore(f"Il decimale {mostra(numero)} non entra in {quanti} byte.",
                               suggerimento="Usa 8 byte.") from None
    try:
        return DatiBinari(numero.to_bytes(quanti, "little" if simbolo == "<" else "big", signed=con_segno))
    except OverflowError:
        if numero < 0 and not con_segno:
            raise ErroreValore(f"Il numero {mostra(numero)} è negativo: serve `con_segno = vero`.") from None
        massimo = 2 ** (8 * quanti - (1 if con_segno else 0)) - 1
        raise ErroreValore(f"Il numero {mostra(numero)} non entra in {quanti} byte (massimo {massimo}).",
                           suggerimento="Usa più byte, per esempio `byte = 8`.") from None


# ===========================================================================
# File: vista esadecimale, tipo vero, entropia
# ===========================================================================

@funzione_libreria("vista_esadecimale")
def vista_esadecimale(sorgente, quanti=256, da=0):
    """vista_esadecimale(sorgente, quanti = 256, da = 0): i byte di un file (o di dati) in righe leggibili, come hexdump.

    Ogni riga mostra la posizione, 16 byte in esadecimale e le lettere stampabili (gli altri byte sono `.`).
    `sorgente` è il percorso di un file, una lista di byte o dei dati binari.
    Esempio: `stampa(vista_esadecimale("foto.png", 32))` mostra "00000000  89 50 4e 47 ...  |.PNG....|".
    """
    richiedi_intero(quanti, "vista_esadecimale", "quanti")
    richiedi_intero(da, "vista_esadecimale", "da")
    if not 0 < quanti <= MASSIMO_VISTA:
        raise ErroreValore(f"`quanti` deve essere tra 1 e {MASSIMO_VISTA} (hai scritto {mostra(quanti)}).")
    if da < 0:
        raise ErroreValore("`da` non può essere negativo.")
    if isinstance(sorgente, str):
        _controlla_percorso(sorgente, "vista_esadecimale")
        try:
            with open(sorgente, "rb") as f:
                f.seek(da)
                contenuto = f.read(quanti)
        except (OSError, OverflowError) as e:
            if isinstance(e, OverflowError):
                raise ErroreValore(f"La posizione {mostra(da)} è troppo grande.") from None
            raise _errore_file(e, sorgente, "leggere") from None
    else:
        contenuto = _byte(sorgente, "vista_esadecimale", "sorgente")[da:da + quanti]
    righe = []
    for i in range(0, len(contenuto), 16):
        pezzo = contenuto[i:i + 16]
        esa = " ".join(f"{b:02x}" for b in pezzo[:8]) + "  " + " ".join(f"{b:02x}" for b in pezzo[8:])
        lettere = "".join(chr(b) if 32 <= b < 127 else "." for b in pezzo)
        righe.append(f"{da + i:08x}  {esa:<48}  |{lettere}|")
    return "\n".join(righe)


#: (inizio, firma, tipo, descrizione, estensioni, e_programma)
_FIRME: tuple[tuple[int, bytes, str, str, tuple[str, ...], bool], ...] = (
    (0, b"\x89PNG\r\n\x1a\n", "PNG", "immagine PNG", ("png",), False),
    (0, b"\xff\xd8\xff", "JPEG", "foto JPEG", ("jpg", "jpeg", "jpe", "jfif"), False),
    (0, b"GIF87a", "GIF", "immagine GIF", ("gif",), False),
    (0, b"GIF89a", "GIF", "immagine GIF", ("gif",), False),
    (0, b"BM", "BMP", "immagine BMP", ("bmp", "dib"), False),
    (0, b"II*\x00", "TIFF", "immagine TIFF", ("tif", "tiff", "dng", "nef", "cr2", "arw"), False),
    (0, b"MM\x00*", "TIFF", "immagine TIFF", ("tif", "tiff", "dng", "nef"), False),
    (0, b"\x00\x00\x01\x00", "ICO", "icona di Windows", ("ico",), False),
    (0, b"%PDF-", "PDF", "documento PDF", ("pdf",), False),
    (0, b"PK\x03\x04", "ZIP", "archivio ZIP (anche documenti Office, OpenDocument, APK, JAR, EPUB)",
     ("zip", "docx", "xlsx", "pptx", "odt", "ods", "odp", "jar", "apk", "epub", "xpi", "whl", "leoapp"), False),
    (0, b"PK\x05\x06", "ZIP", "archivio ZIP vuoto", ("zip",), False),
    (0, b"Rar!\x1a\x07", "RAR", "archivio RAR", ("rar",), False),
    (0, b"7z\xbc\xaf\x27\x1c", "7Z", "archivio 7-Zip", ("7z",), False),
    (0, b"\x1f\x8b", "GZIP", "file compresso gzip", ("gz", "tgz"), False),
    (0, b"BZh", "BZIP2", "file compresso bzip2", ("bz2", "tbz2"), False),
    (0, b"\xfd7zXZ\x00", "XZ", "file compresso xz", ("xz", "txz"), False),
    (0, b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1", "OLE", "documento Office vecchio o installatore MSI",
     ("doc", "xls", "ppt", "msi", "msg"), False),
    (0, b"SQLite format 3\x00", "SQLITE", "database SQLite", ("db", "sqlite", "sqlite3"), False),
    (0, b"MZ", "EXE", "programma di Windows (exe o dll)", ("exe", "dll", "sys", "scr", "com", "cpl", "ocx"), True),
    (0, b"\x7fELF", "ELF", "programma di Linux o Android", ("", "so", "elf", "bin", "o"), True),
    (0, b"\xcf\xfa\xed\xfe", "MACHO", "programma del Mac", ("", "dylib"), True),
    (0, b"\xca\xfe\xba\xbe", "CLASS", "classe Java o programma del Mac", ("class", ""), True),
    (0, b"dex\n", "DEX", "codice di un'app Android", ("dex",), True),
    (0, b"\x00asm", "WASM", "programma WebAssembly", ("wasm",), True),
    (0, b"#!", "SCRIPT", "script da eseguire (shell, Python...)", ("sh", "py", "pl", "rb", ""), True),
    (0, b"ID3", "MP3", "audio MP3", ("mp3",), False),
    (0, b"\xff\xfb", "MP3", "audio MP3", ("mp3",), False),
    (0, b"\xff\xf3", "MP3", "audio MP3", ("mp3",), False),
    (0, b"OggS", "OGG", "audio o video Ogg", ("ogg", "oga", "ogv", "opus"), False),
    (0, b"fLaC", "FLAC", "audio FLAC", ("flac",), False),
    (0, b"MThd", "MIDI", "musica MIDI", ("mid", "midi"), False),
    (4, b"ftyp", "MP4", "video o audio MP4 / MOV / HEIC", ("mp4", "m4a", "m4v", "mov", "heic", "heif", "3gp", "avif"),
     False),
    (0, b"\x1aE\xdf\xa3", "MKV", "video Matroska / WebM", ("mkv", "webm", "mka"), False),
    (0, b"{\\rtf", "RTF", "documento RTF", ("rtf",), False),
    (0, b"wOFF", "WOFF", "carattere per il web", ("woff",), False),
    (0, b"wOF2", "WOFF2", "carattere per il web", ("woff2",), False),
    (257, b"ustar", "TAR", "archivio TAR", ("tar",), False),
)
_RIFF = {b"WEBP": ("WEBP", "immagine WebP", ("webp",)), b"WAVE": ("WAV", "audio WAV", ("wav",)),
         b"AVI ": ("AVI", "video AVI", ("avi",))}
#: estensioni che un utente apre pensando che siano innocue
_ESTENSIONI_INNOCUE = {"pdf", "jpg", "jpeg", "png", "gif", "txt", "doc", "docx", "xls", "xlsx", "mp3", "mp4",
                       "zip", "csv", "odt", "bmp", "webp", "mov", "avi", "wav", "html", "htm", "rtf", "leo"}


def _riconosci(testa: bytes) -> tuple[str, str, tuple[str, ...], bool]:
    if testa[:4] == b"RIFF" and testa[8:12] in _RIFF:
        tipo, descrizione, estensioni = _RIFF[testa[8:12]]
        return tipo, descrizione, estensioni, False
    for inizio, firma, tipo, descrizione, estensioni, programma in _FIRME:
        if testa[inizio:inizio + len(firma)] == firma:
            return tipo, descrizione, estensioni, programma
    if not testa:
        return "VUOTO", "file vuoto", (), False
    if b"\x00" not in testa:
        try:
            testo = testa.decode("utf-8")
        except UnicodeDecodeError as e:
            testo = testa[:e.start].decode("utf-8") if e.start >= len(testa) - 3 else None
        if testo is not None:
            inizio = testo.lstrip("﻿ \t\r\n")[:200].lower()
            if inizio.startswith(("<!doctype html", "<html")):
                return "HTML", "pagina web HTML", ("html", "htm"), False
            if inizio.startswith("<?xml") or inizio.startswith("<svg"):
                return "XML", "documento XML o SVG", ("xml", "svg", "xaml", "plist"), False
            return "TESTO", "file di testo", ("txt", "csv", "leo", "py", "md", "json", "ini", "toml", "log", "html",
                                               "xml", "js", "css", "bat", "ps1", "sh", "yaml", "yml", ""), False
    return "SCONOSCIUTO", "tipo sconosciuto", (), False


@funzione_libreria("riconosci_tipo_file")
def riconosci_tipo_file(percorso):
    """riconosci_tipo_file(percorso): il vero tipo di un file, riconosciuto dai primi byte e non dal nome.

    Restituisce un dizionario con "tipo" (per esempio "PNG", "PDF", "EXE", "TESTO"), "descrizione",
    "estensioni" (quelle giuste), "estensione_giusta" (vero, falso o nulla) e "avviso" (un testo o nulla).
    Serve a scoprire un file travestito: un programma che si chiama "compiti.pdf.exe" o "foto.jpg".
    Esempio: `riconosci_tipo_file("foto.jpg")["tipo"]` è "JPEG" (o "PNG" se il nome mente).
    """
    _controlla_percorso(percorso, "riconosci_tipo_file")
    try:
        with open(percorso, "rb") as f:
            testa = f.read(4096)
    except OSError as e:
        raise _errore_file(e, percorso, "leggere") from None
    tipo, descrizione, estensioni, programma = _riconosci(testa)
    nome = os.path.basename(percorso)
    estensione = os.path.splitext(nome)[1].lower().lstrip(".")
    giusta = None if tipo in ("SCONOSCIUTO", "VUOTO") else estensione in estensioni
    avviso = None
    if programma and estensione in _ESTENSIONI_INNOCUE:
        avviso = (f"ATTENZIONE: `{nome}` sembra un .{estensione} ma in realtà è un {descrizione}. "
                  f"Non aprirlo se non sai da dove viene: potrebbe essere un programma dannoso travestito.")
    elif programma:
        avviso = f"`{nome}` è un {descrizione}: aprilo solo se ti fidi di chi te l'ha dato."
    elif giusta is False and estensione:
        avviso = (f"L'estensione .{estensione} non corrisponde: il file è in realtà un {descrizione} "
                  f"(di solito .{estensioni[0] if estensioni and estensioni[0] else '?'}).")
    return {"tipo": tipo, "descrizione": descrizione, "estensioni": [e for e in estensioni if e],
            "estensione_giusta": giusta, "avviso": avviso}


@funzione_libreria("entropia_file")
def entropia_file(percorso):
    """entropia_file(percorso): quanto sono "disordinati" i byte di un file, da 0 a 8 (bit per byte).

    Un testo sta intorno a 4-5; un file compresso (ZIP, JPEG, MP3) o cifrato arriva quasi a 8. Un file di
    documenti con entropia vicina a 8 e un nome strano può essere stato cifrato da un virus (ransomware).
    Esempio: `entropia_file("archivio.zip")` è per esempio 7.998.
    """
    _controlla_percorso(percorso, "entropia_file")
    conteggi = [0] * 256
    totale = 0
    try:
        with open(percorso, "rb") as f:
            while True:
                pezzo = f.read(1024 * 1024)
                if not pezzo:
                    break
                totale += len(pezzo)
                for b, c in Counter(pezzo).items():
                    conteggi[b] += c
    except OSError as e:
        raise _errore_file(e, percorso, "leggere") from None
    if not totale:
        return 0.0
    h = -sum(c / totale * math.log2(c / totale) for c in conteggi if c)
    return round(abs(h), 3)


# ===========================================================================
# EXIF: metadati delle foto
# ===========================================================================

_DIMENSIONI_TIFF = {1: 1, 2: 1, 3: 2, 4: 4, 5: 8, 6: 1, 7: 1, 8: 2, 9: 4, 10: 8, 11: 4, 12: 8}


class _Tiff:
    """Lettore prudente di una struttura TIFF (quella dentro l'EXIF): mai eccezioni, solo valori mancanti."""

    def __init__(self, dati: bytes) -> None:
        self.dati = dati
        self.o = "<" if dati[:2] == b"II" else ">"

    def _valore(self, tipo: int, quanti: int, posizione: int) -> Any:
        dim = _DIMENSIONI_TIFF.get(tipo)
        if dim is None or quanti <= 0 or quanti > 10000:
            return None
        grezzi = self.dati[posizione:posizione + dim * quanti]
        if len(grezzi) < dim * quanti:
            return None
        if tipo == 2:
            return grezzi.split(b"\x00", 1)[0].decode("utf-8", "replace").strip()
        if tipo in (1, 7):
            return grezzi if tipo == 7 else list(grezzi)
        codice = {3: "H", 4: "I", 8: "h", 9: "i", 11: "f", 12: "d", 6: "b"}.get(tipo)
        if codice:
            valori = list(struct.unpack(f"{self.o}{quanti}{codice}", grezzi))
        else:  # razionali
            c = "I" if tipo == 5 else "i"
            coppie = struct.unpack(f"{self.o}{2 * quanti}{c}", grezzi)
            valori = [coppie[i] / coppie[i + 1] if coppie[i + 1] else 0.0 for i in range(0, len(coppie), 2)]
        return valori[0] if quanti == 1 else valori

    def cartella(self, posizione: int) -> dict[int, Any]:
        voci: dict[int, Any] = {}
        if posizione <= 0 or posizione + 2 > len(self.dati):
            return voci
        (n,) = struct.unpack(self.o + "H", self.dati[posizione:posizione + 2])
        for i in range(min(n, 500)):
            p = posizione + 2 + 12 * i
            if p + 12 > len(self.dati):
                break
            etichetta, tipo, quanti = struct.unpack(self.o + "HHI", self.dati[p:p + 8])
            dim = _DIMENSIONI_TIFF.get(tipo, 0) * quanti
            dove = p + 8 if dim <= 4 else struct.unpack(self.o + "I", self.dati[p + 8:p + 12])[0]
            voci[etichetta] = self._valore(tipo, quanti, dove)
        return voci

    def prima(self) -> int:
        if len(self.dati) < 8 or self.dati[:2] not in (b"II", b"MM"):
            return 0
        return struct.unpack(self.o + "I", self.dati[4:8])[0]


def _trova_tiff_exif(dati: bytes) -> bytes | None:
    """La struttura TIFF dell'EXIF dentro un JPEG, PNG, WebP o TIFF (``None`` se non c'è)."""
    if dati[:3] == b"\xff\xd8\xff":
        for marcatore, inizio, fine in _segmenti_jpeg(dati):
            if marcatore == 0xE1 and dati[inizio + 4:inizio + 10] == b"Exif\x00\x00":
                return dati[inizio + 10:fine]
        return None
    if dati[:8] == b"\x89PNG\r\n\x1a\n":
        for tipo, inizio, fine in _blocchi_png(dati):
            if tipo == b"eXIf":
                return dati[inizio + 8:fine - 4]
        return None
    if dati[:4] == b"RIFF" and dati[8:12] == b"WEBP":
        for tipo, inizio, fine in _blocchi_webp(dati):
            if tipo == b"EXIF":
                contenuto = dati[inizio + 8:fine]
                return contenuto[6:] if contenuto[:6] == b"Exif\x00\x00" else contenuto
        return None
    if dati[:4] in (b"II*\x00", b"MM\x00*"):
        return dati
    return None


def _segmenti_jpeg(dati: bytes):
    """(marcatore, inizio, fine) di ogni segmento prima dell'immagine vera (SOS)."""
    p = 2
    while p + 4 <= len(dati):
        if dati[p] != 0xFF:
            return
        while p < len(dati) and dati[p] == 0xFF:
            p += 1
        if p >= len(dati):
            return
        marcatore = dati[p]
        inizio = p - 1
        p += 1
        if marcatore in (0x01,) or 0xD0 <= marcatore <= 0xD7:
            yield marcatore, inizio, p
            continue
        if marcatore == 0xD9 or p + 2 > len(dati):
            return
        lunghezza = struct.unpack(">H", dati[p:p + 2])[0]
        if lunghezza < 2:
            return
        fine = min(p + lunghezza, len(dati))
        yield marcatore, inizio, fine
        if marcatore == 0xDA:  # inizio dell'immagine: il resto sono dati compressi
            return
        p = fine


def _blocchi_png(dati: bytes):
    p = 8
    while p + 12 <= len(dati):
        lunghezza = struct.unpack(">I", dati[p:p + 4])[0]
        tipo = dati[p + 4:p + 8]
        fine = p + 12 + lunghezza
        if fine > len(dati):
            return
        yield tipo, p, fine
        if tipo == b"IEND":
            return
        p = fine


def _blocchi_webp(dati: bytes):
    p = 12
    while p + 8 <= len(dati):
        tipo = dati[p:p + 4]
        lunghezza = struct.unpack("<I", dati[p + 4:p + 8])[0]
        fine = p + 8 + lunghezza
        if fine > len(dati):
            return
        yield tipo, p, fine
        p = fine + (lunghezza & 1)


def _data_exif(v: Any) -> Any:
    if isinstance(v, str) and len(v) >= 19 and v[4] == ":" and v[7] == ":":
        return v[:4] + "-" + v[5:7] + "-" + v[8:10] + v[10:19]
    return v


def _gradi(v: Any, riferimento: Any, negativo: str) -> float | None:
    if not isinstance(v, list) or len(v) != 3 or not all(isinstance(x, float) for x in v):
        return None
    g = v[0] + v[1] / 60 + v[2] / 3600
    if isinstance(riferimento, str) and riferimento.upper().startswith(negativo):
        g = -g
    return round(g, 6)


@funzione_libreria("leggi_exif")
def leggi_exif(percorso):
    """leggi_exif(percorso): i metadati EXIF di una foto (JPEG, PNG, WebP, TIFF) in un dizionario.

    Chiavi possibili: "marca", "modello", "programma", "data_scatto", "data_modifica", "autore", "copyright",
    "orientamento", "larghezza", "altezza", "esposizione", "diaframma", "iso", "focale", "obiettivo" e "gps"
    (un dizionario con "latitudine", "longitudine", "altitudine", "mappa"). Se la foto non ha metadati il
    dizionario è vuoto. ATTENZIONE alla privacy: la posizione GPS dice dove è stata scattata la foto (per
    esempio casa tua): prima di condividerla toglila con `togli_exif`.
    Esempio: `variabile m = leggi_exif("vacanze.jpg")` e poi `se "gps" in m allora stampa(m["avviso_privacy"]) fine`.
    """
    dati = _leggi_file(percorso, "leggi_exif", 64 * 1024 * 1024)
    tiff = _trova_tiff_exif(dati)
    if not tiff:
        if not dati.startswith((b"\xff\xd8\xff", b"\x89PNG", b"RIFF", b"II*\x00", b"MM\x00*")):
            raise ErroreValore(f"`{percorso}` non è una foto JPEG, PNG, WebP o TIFF.",
                               suggerimento="Controlla il tipo con `riconosci_tipo_file(percorso)`.")
        return {}
    try:
        return _interpreta_exif(_Tiff(tiff))
    except (struct.error, IndexError, ValueError, OverflowError):
        return {}


def _interpreta_exif(t: _Tiff) -> dict:
    principale = t.cartella(t.prima())
    exif = t.cartella(principale.get(0x8769)) if isinstance(principale.get(0x8769), int) else {}
    gps = t.cartella(principale.get(0x8825)) if isinstance(principale.get(0x8825), int) else {}
    risultato: dict[str, Any] = {}

    def metti(chiave: str, v: Any) -> None:
        if isinstance(v, bytes):
            v = v.split(b"\x00", 1)[0].decode("ascii", "replace").strip() or None
        if isinstance(v, float):
            if math.isnan(v) or math.isinf(v):
                return
            v = round(v, 4)
        if v not in (None, "", []) and not isinstance(v, list):
            risultato[chiave] = v

    metti("marca", principale.get(0x010F))
    metti("modello", principale.get(0x0110))
    metti("programma", principale.get(0x0131))
    metti("data_scatto", _data_exif(exif.get(0x9003)))
    metti("data_modifica", _data_exif(principale.get(0x0132)))
    metti("autore", principale.get(0x013B))
    metti("copyright", principale.get(0x8298))
    metti("orientamento", principale.get(0x0112))
    metti("larghezza", exif.get(0xA002))
    metti("altezza", exif.get(0xA003))
    esposizione = exif.get(0x829A)
    if isinstance(esposizione, float) and 0 < esposizione < 1:
        risultato["esposizione"] = f"1/{round(1 / esposizione)}"
    else:
        metti("esposizione", esposizione)
    metti("diaframma", exif.get(0x829D))
    metti("iso", exif.get(0x8827))
    metti("focale", exif.get(0x920A))
    metti("obiettivo", exif.get(0xA434))
    lat = _gradi(gps.get(2), gps.get(1), "S")
    lon = _gradi(gps.get(4), gps.get(3), "W")
    if lat is not None and lon is not None and -90 <= lat <= 90 and -180 <= lon <= 180:
        posizione: dict[str, Any] = {"latitudine": lat, "longitudine": lon}
        alt = gps.get(6)
        if isinstance(alt, float) and math.isfinite(alt):
            sotto = gps.get(5)
            posizione["altitudine"] = round(-alt if sotto in ([1], 1, b"\x01") else alt, 1)
        posizione["mappa"] = f"https://www.openstreetmap.org/?mlat={lat}&mlon={lon}#map=17/{lat}/{lon}"
        risultato["gps"] = posizione
    if "gps" in risultato or "autore" in risultato:
        risultato["avviso_privacy"] = ("Questa foto contiene informazioni personali (" +
                                       ("la posizione GPS di dove è stata scattata" if "gps" in risultato
                                        else "il nome dell'autore") +
                                       "). Prima di pubblicarla o mandarla a sconosciuti usa `togli_exif`.")
    return risultato


@funzione_libreria("togli_exif")
def togli_exif(percorso, destinazione=None):
    """togli_exif(percorso, destinazione = nulla): toglie da una foto i metadati (EXIF, GPS, XMP, commenti).

    L'immagine resta identica: si tolgono solo le informazioni nascoste. Funziona con JPEG, PNG e WebP.
    Senza `destinazione` sostituisce il file stesso. Restituisce quanti blocchi di metadati ha tolto (0 se la foto
    era già pulita). Nota: la foto perde anche l'"orientamento", quindi alcune potrebbero apparire ruotate.
    Esempio: `togli_exif("vacanze.jpg", "vacanze_da_condividere.jpg")`.
    """
    dati = _leggi_file(percorso, "togli_exif")
    if destinazione is None:
        destinazione = percorso
    _controlla_percorso(destinazione, "togli_exif")
    if dati[:3] == b"\xff\xd8\xff":
        pulito, tolti = _pulisci_jpeg(dati)
    elif dati[:8] == b"\x89PNG\r\n\x1a\n":
        pulito, tolti = _pulisci_png(dati)
    elif dati[:4] == b"RIFF" and dati[8:12] == b"WEBP":
        pulito, tolti = _pulisci_webp(dati)
    else:
        raise ErroreValore(f"`togli_exif` sa pulire solo foto JPEG, PNG e WebP: `{percorso}` non lo è.",
                           suggerimento="Controlla il tipo con `riconosci_tipo_file(percorso)`.")
    if tolti or destinazione != percorso:
        _scrivi_file(destinazione, pulito, True, "togli_exif")
    return tolti


def _pulisci_jpeg(dati: bytes) -> tuple[bytes, int]:
    pezzi = [dati[:2]]
    tolti = 0
    ultimo = 2
    for marcatore, inizio, fine in _segmenti_jpeg(dati):
        # APP1 (EXIF, XMP), APP13 (IPTC di Photoshop), COM (commenti); resta APP2 (profilo colore)
        if marcatore in (0xE1, 0xED, 0xFE):
            tolti += 1
        else:
            pezzi.append(dati[inizio:fine])
        ultimo = fine
        if marcatore == 0xDA:
            break
    pezzi.append(dati[ultimo:])
    return b"".join(pezzi), tolti


def _pulisci_png(dati: bytes) -> tuple[bytes, int]:
    pezzi = [dati[:8]]
    tolti = 0
    ultimo = 8
    for tipo, inizio, fine in _blocchi_png(dati):
        if tipo in (b"eXIf", b"tEXt", b"zTXt", b"iTXt", b"tIME"):
            tolti += 1
        else:
            pezzi.append(dati[inizio:fine])
        ultimo = fine
    pezzi.append(dati[ultimo:])
    return b"".join(pezzi), tolti


def _pulisci_webp(dati: bytes) -> tuple[bytes, int]:
    pezzi = []
    tolti = 0
    for tipo, inizio, fine in _blocchi_webp(dati):
        blocco = dati[inizio:fine + ((fine - inizio) & 1)]
        if tipo in (b"EXIF", b"XMP "):
            tolti += 1
            continue
        if tipo == b"VP8X" and fine - inizio >= 9:
            blocco = blocco[:8] + bytes((blocco[8] & ~0x0C,)) + blocco[9:]  # niente più EXIF (8) e XMP (4)
        pezzi.append(blocco)
    corpo = b"WEBP" + b"".join(pezzi)
    return b"RIFF" + struct.pack("<I", len(corpo)) + corpo, tolti


# ===========================================================================
# Compressione
# ===========================================================================

_METODI_COMPRESSIONE = ("gzip", "zlib", "bz2", "xz")


@funzione_libreria("comprimi_dati")
def comprimi_dati(dati, metodo="gzip"):
    """comprimi_dati(dati, metodo = "gzip"): i dati compressi (più piccoli), come dati binari.

    Metodi: "gzip" (il più diffuso), "zlib", "bz2", "xz" (il più piccolo, ma più lento). Un testo che si ripete
    si comprime tanto; una foto JPEG o un file ZIP quasi niente (sono già compressi).
    Esempio: `comprimi_dati("ciao " * 1000).lunghezza` è molto meno di 5000.
    """
    contenuto = _byte(dati, "comprimi_dati")
    richiedi_testo(metodo, "comprimi_dati", "metodo")
    m = metodo.strip().lower().replace("lzma", "xz").replace("bzip2", "bz2")
    if m == "gzip":
        import gzip
        return DatiBinari(gzip.compress(contenuto, mtime=0))
    if m == "zlib":
        return DatiBinari(zlib.compress(contenuto, 9))
    if m == "bz2":
        return DatiBinari(_bz2("comprimi_dati").compress(contenuto))
    if m == "xz":
        return DatiBinari(_lzma("comprimi_dati").compress(contenuto))
    raise ErroreValore(f"Non conosco il metodo di compressione {mostra(metodo)}.",
                       suggerimento="Metodi: " + ", ".join(f'"{x}"' for x in _METODI_COMPRESSIONE) + ".")


def _bz2(nome_funzione: str):
    try:
        import bz2
    except ImportError:  # pragma: no cover - Python compilato senza bz2
        raise ErroreValore(f"Su questo computer il metodo \"bz2\" di `{nome_funzione}` non c'è.",
                           suggerimento="Usa \"gzip\".") from None
    return bz2


def _lzma(nome_funzione: str):
    try:
        import lzma
    except ImportError:  # pragma: no cover - Python compilato senza lzma
        raise ErroreValore(f"Su questo computer il metodo \"xz\" di `{nome_funzione}` non c'è.",
                           suggerimento="Usa \"gzip\" o \"bz2\".") from None
    return lzma


@funzione_libreria("decomprimi_dati")
def decomprimi_dati(dati):
    """decomprimi_dati(dati): il contrario di `comprimi_dati`; il metodo si riconosce da solo.

    Riconosce gzip, zlib, bz2 e xz. Si ferma se il risultato supera 256 MB (i file "bomba" minuscoli che
    diventano enormi servono a bloccare i computer). Esempio: `decomprimi_dati(comprimi_dati("ciao")).in_testo()` è "ciao".
    """
    contenuto = _byte(dati, "decomprimi_dati")
    if contenuto[:2] == b"\x1f\x8b":
        fatto, nome = zlib.decompressobj(wbits=31), "gzip"
    elif contenuto[:3] == b"BZh":
        fatto, nome = _bz2("decomprimi_dati").BZ2Decompressor(), "bz2"
    elif contenuto[:6] == b"\xfd7zXZ\x00":
        fatto, nome = _lzma("decomprimi_dati").LZMADecompressor(), "xz"
    elif len(contenuto) >= 2 and contenuto[0] & 0x0F == 8 and (contenuto[0] << 8 | contenuto[1]) % 31 == 0:
        fatto, nome = zlib.decompressobj(), "zlib"
    else:
        raise ErroreValore("Questi dati non sono compressi con gzip, zlib, bz2 o xz.",
                           suggerimento="Guarda i primi byte con `vista_esadecimale(dati)`.")
    try:
        if nome in ("gzip", "zlib"):
            uscita = fatto.decompress(contenuto, MASSIMO_DECOMPRESSO + 1)
            completo = fatto.eof
        else:
            uscita = fatto.decompress(contenuto, max_length=MASSIMO_DECOMPRESSO + 1)
            completo = fatto.eof
    except (zlib.error, OSError, EOFError, ValueError, MemoryError) as e:
        if isinstance(e, MemoryError):
            raise ErroreValore("I dati decompressi sono troppo grandi.") from None
        raise ErroreValore(f"I dati {nome} sono rovinati o incompleti.") from None
    except Exception as e:  # noqa: BLE001 - lzma.LZMAError
        raise ErroreValore(f"I dati {nome} sono rovinati o incompleti ({type(e).__name__}).") from None
    if len(uscita) > MASSIMO_DECOMPRESSO:
        raise ErroreValore("Decompressi, i dati supererebbero 256 MB: mi fermo per sicurezza.",
                           suggerimento="Potrebbe essere una \"bomba di compressione\": non fidarti di questo file.")
    if not completo:
        raise ErroreValore(f"I dati {nome} sono incompleti: manca la fine.")
    return DatiBinari(uscita)


# ===========================================================================
# Cifratura AES-256-GCM con password (cryptography)
# ===========================================================================

_MAGIA = b"LEO"
_VERSIONE = 1
_LOG_N = 15          # scrypt: N = 2**15, r = 8, p = 1 (circa 32 MB e 0,1 secondi)
_SALE, _NONCE = 16, 12


def _chiave(password: str, sale: bytes, log_n: int) -> bytes:
    return hashlib.scrypt(password.encode("utf-8", "surrogatepass"), salt=sale, n=2 ** log_n, r=8, p=1,
                          maxmem=256 * 1024 * 1024, dklen=32)


def _password(password: Any, nome_funzione: str) -> str:
    richiedi_testo(password, nome_funzione, "password")
    if not password:
        raise ErroreValore(f"La password di `{nome_funzione}` è vuota.",
                           suggerimento="Usa una frase lunga che ricordi bene: senza password i dati non si "
                                        "recuperano più.")
    if len(password) > 4096:
        raise ErroreValore(f"La password di `{nome_funzione}` è troppo lunga.")
    return password


def _cifra(contenuto: bytes, password: str, nome_funzione: str) -> bytes:
    AESGCM, _, _ = _serve_cryptography(nome_funzione)
    sale, nonce = secrets.token_bytes(_SALE), secrets.token_bytes(_NONCE)
    testa = _MAGIA + bytes((_VERSIONE, _LOG_N)) + sale + nonce
    return testa + AESGCM(_chiave(password, sale, _LOG_N)).encrypt(nonce, contenuto, testa)


def _decifra(cifrato: bytes, password: str, nome_funzione: str) -> bytes:
    AESGCM, _, eccezioni = _serve_cryptography(nome_funzione)
    lunghezza_testa = 5 + _SALE + _NONCE
    if len(cifrato) < lunghezza_testa + 16 or cifrato[:3] != _MAGIA:
        raise ErroreValore(f"Questi dati non sono stati cifrati con `cifra_testo` o `cifra_file`.")
    if cifrato[3] != _VERSIONE or not 10 <= cifrato[4] <= 20:
        raise ErroreValore("Questi dati sono cifrati con una versione di Leo diversa.",
                           suggerimento="Aggiorna Leo e riprova.")
    testa = cifrato[:lunghezza_testa]
    sale, nonce = testa[5:5 + _SALE], testa[5 + _SALE:]
    try:
        return AESGCM(_chiave(password, sale, cifrato[4])).decrypt(nonce, cifrato[lunghezza_testa:], testa)
    except eccezioni.InvalidTag:
        raise ErroreValore("Non riesco a decifrare: la password è sbagliata oppure i dati sono stati modificati.",
                           suggerimento="Controlla maiuscole e spazi della password.") from None


@funzione_libreria("cifra_testo")
def cifra_testo(dati, password):
    """cifra_testo(dati, password): cifra un testo (o dei byte) con una password; il risultato è un testo illeggibile.

    Usa AES-256-GCM, un cifrario vero, con la chiave ricavata dalla password con scrypt: chi non conosce la password
    non può leggere né modificare di nascosto il messaggio. Ogni volta il risultato è diverso (è normale).
    Serve il pacchetto `cryptography`. Se dimentichi la password i dati sono persi per sempre.
    Esempio: `variabile segreto = cifra_testo("Il tesoro è sotto il pino", "gatto-blu-salta-alto")`.
    """
    contenuto = _byte(dati, "cifra_testo")
    return base64.b64encode(_cifra(contenuto, _password(password, "cifra_testo"), "cifra_testo")).decode("ascii")


@funzione_libreria("decifra_testo")
def decifra_testo(testo, password, come_byte=False):
    """decifra_testo(testo, password, come_byte = falso): rimette in chiaro un testo di `cifra_testo`.

    Con la password sbagliata (o se qualcuno ha cambiato anche una sola lettera) dà un errore.
    Con `come_byte = vero` restituisce dati binari invece di un testo.
    Esempio: `decifra_testo(segreto, "gatto-blu-salta-alto")` è "Il tesoro è sotto il pino".
    """
    richiedi_testo(testo, "decifra_testo", "testo")
    richiedi_logico(come_byte, "decifra_testo", "come_byte")
    pw = _password(password, "decifra_testo")
    cifrato = _decodifica(testo, "base64", "decifra_testo")
    chiaro = _decifra(cifrato, pw, "decifra_testo")
    if come_byte:
        return DatiBinari(chiaro)
    return _testo_utf8(chiaro, "decifra_testo", "Aggiungi `come_byte = vero` per avere i dati binari.")


@funzione_libreria("cifra_file")
def cifra_file(percorso, password, destinazione=None, sovrascrivi=False):
    """cifra_file(percorso, password, destinazione = nulla, sovrascrivi = falso): cifra un file con una password.

    Crea un file nuovo (di solito con ".leocifrato" in fondo al nome) e lascia com'è l'originale: cancellalo tu
    quando hai controllato che `decifra_file` funziona. Usa AES-256-GCM (serve il pacchetto `cryptography`).
    Restituisce il percorso del file cifrato. Esempio: `cifra_file("diario.txt", "la mia frase segreta lunga")`.
    """
    contenuto = _leggi_file(percorso, "cifra_file")
    pw = _password(password, "cifra_file")
    richiedi_logico(sovrascrivi, "cifra_file", "sovrascrivi")
    if destinazione is None:
        destinazione = percorso + ".leocifrato"
    _controlla_percorso(destinazione, "cifra_file")
    _scrivi_file(destinazione, _cifra(contenuto, pw, "cifra_file"), sovrascrivi, "cifra_file")
    return destinazione


@funzione_libreria("decifra_file")
def decifra_file(percorso, password, destinazione=None, sovrascrivi=False):
    """decifra_file(percorso, password, destinazione = nulla, sovrascrivi = falso): il contrario di `cifra_file`.

    Senza `destinazione` toglie ".leocifrato" dal nome (se il file esiste già serve `sovrascrivi = vero`).
    Restituisce il percorso del file decifrato. Esempio: `decifra_file("diario.txt.leocifrato", "la mia frase segreta lunga")`.
    """
    contenuto = _leggi_file(percorso, "decifra_file")
    pw = _password(password, "decifra_file")
    richiedi_logico(sovrascrivi, "decifra_file", "sovrascrivi")
    if destinazione is None:
        destinazione = percorso[:-len(".leocifrato")] if percorso.endswith(".leocifrato") else percorso + ".decifrato"
    _controlla_percorso(destinazione, "decifra_file")
    chiaro = _decifra(contenuto, pw, "decifra_file")
    _scrivi_file(destinazione, chiaro, sovrascrivi, "decifra_file")
    return destinazione


# ===========================================================================
# Firme digitali Ed25519 (cryptography)
# ===========================================================================

_PREFISSO_PRIVATA = "ed25519-privata:"
_PREFISSO_PUBBLICA = "ed25519-pubblica:"


def _chiave_testo(testo: Any, prefisso: str, altro: str, nome_funzione: str, parametro: str) -> bytes:
    richiedi_testo(testo, nome_funzione, parametro)
    pulito = testo.strip()
    if pulito.startswith(altro):
        if parametro == "chiave_privata":
            raise ErroreValore("Hai dato la chiave pubblica: per firmare serve la chiave privata.")
        raise ErroreValore("Hai dato la chiave privata! Per verificare basta la pubblica: la privata non si "
                           "mostra a nessuno.")
    if pulito.startswith(prefisso):
        pulito = pulito[len(prefisso):]
    grezza = _decodifica(pulito, "base64", nome_funzione)
    if len(grezza) != 32:
        raise ErroreValore(f"La `{parametro}` di `{nome_funzione}` non è una chiave Ed25519 valida.",
                           suggerimento="Usa una chiave creata con `crea_chiavi_firma()`.")
    return grezza


@funzione_libreria("crea_chiavi_firma")
def crea_chiavi_firma():
    """crea_chiavi_firma(): una nuova coppia di chiavi per le firme digitali Ed25519, in un dizionario.

    "privata" serve a firmare e va tenuta segreta (come una password); "pubblica" si dà a tutti e serve a
    controllare che i tuoi file o messaggi vengano proprio da te e non siano stati cambiati.
    Serve il pacchetto `cryptography`. Esempio: `variabile chiavi = crea_chiavi_firma()`.
    """
    _, ed25519, _ = _serve_cryptography("crea_chiavi_firma")
    from cryptography.hazmat.primitives import serialization as s
    privata = ed25519.Ed25519PrivateKey.generate()
    grezza_privata = privata.private_bytes(s.Encoding.Raw, s.PrivateFormat.Raw, s.NoEncryption())
    grezza_pubblica = privata.public_key().public_bytes(s.Encoding.Raw, s.PublicFormat.Raw)
    return {"privata": _PREFISSO_PRIVATA + base64.b64encode(grezza_privata).decode("ascii"),
            "pubblica": _PREFISSO_PUBBLICA + base64.b64encode(grezza_pubblica).decode("ascii")}


@funzione_libreria("firma_dati")
def firma_dati(dati, chiave_privata):
    """firma_dati(dati, chiave_privata): la firma digitale (un testo) di un testo o di dati binari.

    Chi ha la tua chiave pubblica controlla la firma con `verifica_firma`. Per firmare un file:
    `firma_dati(dati_binari("programma.zip", "file"), chiavi["privata"])`.
    Esempio: `variabile firma = firma_dati("Vale 10 punti", chiavi["privata"])`.
    """
    contenuto = _byte(dati, "firma_dati")
    _, ed25519, _ = _serve_cryptography("firma_dati")
    grezza = _chiave_testo(chiave_privata, _PREFISSO_PRIVATA, _PREFISSO_PUBBLICA, "firma_dati", "chiave_privata")
    firma = ed25519.Ed25519PrivateKey.from_private_bytes(grezza).sign(contenuto)
    return base64.b64encode(firma).decode("ascii")


@funzione_libreria("verifica_firma")
def verifica_firma(dati, firma, chiave_pubblica):
    """verifica_firma(dati, firma, chiave_pubblica): vero se la firma è stata fatta con la chiave privata giusta
    su proprio questi dati.

    Falso se anche un solo byte dei dati o della firma è cambiato, o se ha firmato qualcun altro.
    Esempio: `verifica_firma("Vale 10 punti", firma, chiavi["pubblica"])` è vero.
    """
    contenuto = _byte(dati, "verifica_firma")
    _, ed25519, eccezioni = _serve_cryptography("verifica_firma")
    grezza = _chiave_testo(chiave_pubblica, _PREFISSO_PUBBLICA, _PREFISSO_PRIVATA, "verifica_firma", "chiave_pubblica")
    richiedi_testo(firma, "verifica_firma", "firma")
    try:
        firma_grezza = _decodifica(firma, "base64", "verifica_firma")
    except ErroreValore:
        return False
    if len(firma_grezza) != 64:
        return False
    try:
        chiave = ed25519.Ed25519PublicKey.from_public_bytes(grezza)
    except ValueError:
        raise ErroreValore("La chiave pubblica non è valida.") from None
    try:
        chiave.verify(firma_grezza, contenuto)
    except eccezioni.InvalidSignature:
        return False
    return True


# ===========================================================================
# Integrità di una cartella
# ===========================================================================

@funzione_libreria("impronta_cartella")
def impronta_cartella(cartella):
    """impronta_cartella(cartella): l'impronta SHA-256 di ogni file di una cartella (anche nelle sottocartelle).

    Restituisce un dizionario percorso -> impronta (i percorsi sono relativi alla cartella, con `/`).
    Salvalo con `scrivi_json` e più avanti confrontalo con `confronta_impronte` per sapere che cosa è cambiato.
    Esempio: `scrivi_json("foto_prima.json", impronta_cartella("documenti"))`.
    """
    _controlla_percorso(cartella, "impronta_cartella")
    if not os.path.isdir(cartella):
        if os.path.exists(cartella):
            raise ErroreFile(f"`{cartella}` è un file, non una cartella.",
                             suggerimento="Per un solo file usa `impronta_file(percorso)`.")
        raise ErroreFile(f"La cartella `{cartella}` non esiste.",
                         suggerimento=f"Controlla il nome: ora sei in `{os.getcwd()}`.")
    risultato: dict[str, str] = {}
    for radice, cartelle, file in os.walk(cartella, followlinks=False):
        cartelle.sort()
        for nome in sorted(file):
            completo = os.path.join(radice, nome)
            if os.path.islink(completo):
                continue
            relativo = os.path.relpath(completo, cartella).replace(os.sep, "/")
            calcolo = hashlib.sha256()
            try:
                with open(completo, "rb") as f:
                    while True:
                        pezzo = f.read(1024 * 1024)
                        if not pezzo:
                            break
                        calcolo.update(pezzo)
            except OSError as e:
                raise _errore_file(e, completo, "leggere") from None
            risultato[relativo] = calcolo.hexdigest()
    return risultato


def _impronte(valore: Any, parametro: str) -> dict:
    if isinstance(valore, str):
        return impronta_cartella(valore)
    if not isinstance(valore, dict):
        raise ErroreTipo(f"L'argomento `{parametro}` di `confronta_impronte` deve essere un dizionario di "
                         f"`impronta_cartella` o il nome di una cartella, non {articolo(valore)}.")
    for k, v in valore.items():
        if not isinstance(k, str) or not isinstance(v, str):
            raise ErroreValore(f"`{parametro}` non sembra un risultato di `impronta_cartella`: la voce "
                               f"{mostra(k)} non è percorso -> impronta.")
    return valore


@funzione_libreria("confronta_impronte")
def confronta_impronte(prima, dopo):
    """confronta_impronte(prima, dopo): che cosa è cambiato tra due "fotografie" di una cartella.

    `prima` e `dopo` sono dizionari di `impronta_cartella` (o `dopo` è direttamente il nome della cartella).
    Restituisce un dizionario con le liste "aggiunti", "tolti", "cambiati", il numero "uguali" e "intatta"
    (vero se non è cambiato niente). Esempio: `confronta_impronte(leggi_json("foto_prima.json"), "documenti")`.
    """
    a = _impronte(prima, "prima")
    b = _impronte(dopo, "dopo")
    aggiunti = sorted(k for k in b if k not in a)
    tolti = sorted(k for k in a if k not in b)
    cambiati = sorted(k for k in a if k in b and not hmac.compare_digest(a[k].lower(), b[k].lower()))
    uguali = sum(1 for k in a if k in b) - len(cambiati)
    return {"aggiunti": aggiunti, "tolti": tolti, "cambiati": cambiati, "uguali": uguali,
            "intatta": not (aggiunti or tolti or cambiati)}


# ===========================================================================
# Cifrari storici (SOLO DIDATTICI: non sicuri)
# ===========================================================================

def _sposta_lettera(c: str, passi: int) -> str:
    if "a" <= c <= "z":
        return chr((ord(c) - 97 + passi) % 26 + 97)
    if "A" <= c <= "Z":
        return chr((ord(c) - 65 + passi) % 26 + 65)
    return c


def _testo_didattico(testo: Any, nome_funzione: str) -> str:
    richiedi_testo(testo, nome_funzione, "testo")
    if len(testo) > 10_000_000:
        raise ErroreValore(f"Il testo dato a `{nome_funzione}` è troppo lungo.")
    return testo


@funzione_libreria("cifrario_cesare")
def cifrario_cesare(testo, spostamento=3):
    """cifrario_cesare(testo, spostamento = 3): il cifrario di Giulio Cesare. SOLO PER GIOCO: NON È SICURO.

    Ogni lettera (A-Z) va avanti di `spostamento` posti nell'alfabeto; le altre restano uguali. Per decifrare
    usa lo spostamento negativo. Ci sono solo 26 chiavi: `prova_tutti_cesare` le prova tutte in un attimo.
    Per i segreti veri usa `cifra_testo`. Esempio: `cifrario_cesare("Ciao", 3)` è "Fldr".
    """
    t = _testo_didattico(testo, "cifrario_cesare")
    richiedi_intero(spostamento, "cifrario_cesare", "spostamento")
    passi = spostamento % 26
    return "".join(_sposta_lettera(c, passi) for c in t)


@funzione_libreria("cifrario_vigenere")
def cifrario_vigenere(testo, chiave, decifra=False):
    """cifrario_vigenere(testo, chiave, decifra = falso): il cifrario di Vigenère. SOLO PER GIOCO: NON È SICURO.

    Come Cesare, ma lo spostamento cambia a ogni lettera seguendo le lettere della `chiave` (A = 0, B = 1...).
    Si rompe contando le lettere che si ripetono (metodo di Kasiski, 1863). Per i segreti veri usa `cifra_testo`.
    Esempio: `cifrario_vigenere("attacca all'alba", "leo")` è "lxhlgql ezw'ezme".
    """
    t = _testo_didattico(testo, "cifrario_vigenere")
    richiedi_testo(chiave, "cifrario_vigenere", "chiave")
    richiedi_logico(decifra, "cifrario_vigenere", "decifra")
    passi = [ord(c) - 97 for c in chiave.lower() if "a" <= c <= "z"]
    if not passi:
        raise ErroreValore("La chiave di `cifrario_vigenere` deve contenere almeno una lettera dalla A alla Z.",
                           suggerimento="Per esempio `cifrario_vigenere(testo, \"segreto\")`.")
    segno = -1 if decifra else 1
    uscita, i = [], 0
    for c in t:
        if "a" <= c.lower() <= "z" and c.isascii():
            uscita.append(_sposta_lettera(c, segno * passi[i % len(passi)]))
            i += 1
        else:
            uscita.append(c)
    return "".join(uscita)


@funzione_libreria("prova_tutti_cesare")
def prova_tutti_cesare(testo):
    """prova_tutti_cesare(testo): mostra perché il cifrario di Cesare è debole, provando tutte le 26 chiavi.

    Restituisce la lista delle 26 decifrature: nella posizione `n` c'è il testo decifrato con lo spostamento `n`.
    Una sola sarà italiano sensato: basta leggerle. È un esempio per imparare; i cifrari veri (come quello
    di `cifra_testo`) hanno più chiavi degli atomi della Terra.
    Esempio: `prova_tutti_cesare("Fldr")[3]` è "Ciao".
    """
    t = _testo_didattico(testo, "prova_tutti_cesare")
    if len(t) > 100_000:
        raise ErroreValore("Per provare tutte le chiavi basta un pezzo: usa al massimo 100000 caratteri.")
    return ["".join(_sposta_lettera(c, -n) for c in t) for n in range(26)]


# ===========================================================================
# Password comuni
# ===========================================================================

#: Piccolo elenco locale delle password più usate (dagli elenchi pubblici delle fughe di dati) più alcune
#: italiane. Tutte in minuscolo.
_PASSWORD_COMUNI = frozenset("""
123456 123456789 12345678 12345 1234567 1234567890 1234 123 111111 000000 123123 654321 666666 121212
112233 123321 11111111 00000000 987654321 88888888 55555555 777777 999999 222222 555555 888888 1111 0000
password password1 passw0rd p@ssw0rd p4ssw0rd qwerty qwertyuiop qwerty123 qwertz azerty asdfgh asdfghjkl
zxcvbnm 1q2w3e4r 1q2w3e 1qaz2wsx qazwsx abc123 abcd1234 abcdef abcdefg a1b2c3 aaaaaa iloveyou letmein
welcome admin administrator root toor guest user login test test123 master monkey dragon football
baseball sunshine princess shadow superman batman starwars pokemon minecraft fortnite roblox trustno1
hello freedom whatever michael jordan jennifer charlie secret secret123 changeme default computer
internet samsung google iphone
ciao ciaociao ciao123 amore amore123 tiamo tiamo123 tvb tvtb ciaone buongiorno ciaobella ciccio
cicciobello topolino paperino pippo pluto juventus juve forzajuve forzajuventus milan forzamilan
inter forzainter napoli forzanapoli roma forzaroma lazio forzalazio fiorentina torino italia
italia2006 mario francesco giuseppe giovanni andrea marco luca matteo alessandro davide simone federica
giulia chiara francesca sara martina valentina alessandra laura anna maria gatto cane mamma papa
famiglia principessa calcio pallone segreto parola parolasegreta password123 accesso entra apriti
apritisesamo lasagna pizza gelato nutella stella sole luna cuore tesoro angelo
""".split())


def _sequenza(t: str) -> bool:
    if len(t) < 3:
        return False
    salti = {ord(b) - ord(a) for a, b in zip(t, t[1:])}
    return salti in ({1}, {-1}, {0})


@funzione_libreria("e_password_comune")
def e_password_comune(password):
    """e_password_comune(password): vero se la password è tra le più usate al mondo (o una loro variante facile).

    Controlla un piccolo elenco locale (niente va su Internet), le varianti con maiuscole, numeri o simboli in
    fondo (come "Juventus2024!") e le sequenze come "abcdef" o "98765". Una password comune si indovina in
    pochi secondi: scegline un'altra, per esempio con `password_casuale()`.
    Esempio: `e_password_comune("Password123")` è vero; `e_password_comune("gatto-blu-salta-alto")` è falso.
    """
    richiedi_testo(password, "e_password_comune", "password")
    p = password.strip().lower()
    if len(p) > 1000:
        return False
    if len(p) < 4 or p in _PASSWORD_COMUNI or _sequenza(p):
        return True
    base = p.rstrip("0123456789!?.*#@$_-+ ")
    if base != p and (base in _PASSWORD_COMUNI or (len(base) >= 3 and _sequenza(base)) or not base):
        return True
    simili = base.translate(str.maketrans("4@310$!5", "aaeiosis"))
    return simili in _PASSWORD_COMUNI
