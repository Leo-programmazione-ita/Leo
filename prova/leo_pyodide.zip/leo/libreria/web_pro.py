"""Libreria: Web PRO (client HTTP comodo e server web con rotte).

Un livello di comodità sopra ``internet`` e ``web``: una risposta-oggetto che
si legge con proprietà chiare (``risposta.stato``, ``risposta.testo``,
``risposta.json_risposta``, ``risposta.riuscita``) e un piccolo server web con
instradamento (`routing`) per percorso e metodo, cosa che il server di
``internet`` (un solo gestore con `quando ....richiesta`) non offre.

Solo libreria standard di Python (``urllib``, ``http``, ``json``): niente da
installare, stesso comportamento su PC e telefono.

Funzioni:

* ``ottieni_pagina(indirizzo)``: una GET che restituisce una `risposta_web`;
* ``invia_json(indirizzo, dati)``: invia dati come JSON (POST, o altro metodo);
* ``invia_dati(indirizzo, campi)``: invia un modulo web (``application/x-www-form-urlencoded``);
* ``componi_risposta(contenuto, stato, tipo, intestazioni)``: una risposta su misura dentro una rotta;
* ``crea_server_web(porta)`` + ``aggiungi_rotta(server, percorso, funzione, metodo)`` +
  ``avvia_server(server)`` + ``ferma_server(server)``: un server web con rotte.

La risposta (`risposta_web`) ha le proprietà ``stato``, ``riuscita``,
``messaggio``, ``spiegazione``, ``testo``, ``json_risposta``, ``intestazioni``,
``tipo`` e ``indirizzo``, e il metodo ``solleva_se_errore()``.

Il server ascolta solo su questo computer (127.0.0.1): le rotte possono avere
parti variabili (``"/utenti/:id"`` -> ``richiesta["variabili"]["id"]``) e una
parte finale jolly (``"/file/*"``). La funzione-gestore riceve la richiesta
(``metodo``, ``percorso``, ``parametri``, ``corpo``, ``json``, ``intestazioni``,
``variabili``, ``cliente``) e risponde con un testo, un dizionario/lista (JSON),
un numero, oppure ``componi_risposta(...)`` per decidere stato e intestazioni.

Errori in italiano con suggerimento, come nel resto di Leo.
"""

from __future__ import annotations

import queue
import threading
import time
from typing import Any

from ..errori import ErroreDante, ErroreFile, ErroreTipo, ErroreValore
from ..grafica.servizi import rete
from ..valori import Richiamabile
from .generali import articolo, funzione_libreria, mostra, richiedi_testo
from .internet import _esegui as _esegui_http
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta

__all__ = ["RispostaWeb", "ServerConRotte"]


# ===========================================================================
# Risposta comoda del cliente
# ===========================================================================

class RispostaWeb(OggettoLibreria):
    """La risposta a una richiesta web, da leggere con proprietà chiare.

    La ottieni da ``ottieni_pagina``, ``invia_json`` e ``invia_dati``. Uno stato
    di errore (404, 500...) NON ferma il programma: controlla ``riuscita``.
    """

    NOME_TIPO_DANTE = "risposta_web"
    SUGGERIMENTO_MODIFICA = ("La risposta si legge e basta: usa `risposta.stato`, `risposta.testo`, "
                             "`risposta.json_risposta`.")

    def __init__(self, dati: dict) -> None:
        self._dati = dati

    def testo_dante(self) -> str:
        return f"<risposta_web {self._dati['stato']} {self._dati['indirizzo']}>"


@proprieta(RispostaWeb, "stato")
def _risposta_stato(r: RispostaWeb) -> int:
    """risposta.stato: il codice HTTP (200 = andata bene, 404 = non trovato...)."""
    return r._dati["stato"]


@proprieta(RispostaWeb, "riuscita")
def _risposta_riuscita(r: RispostaWeb) -> bool:
    """risposta.riuscita: `vero` se lo stato è tra 200 e 299."""
    return r._dati["riuscita"]


@proprieta(RispostaWeb, "messaggio")
def _risposta_messaggio(r: RispostaWeb) -> str:
    """risposta.messaggio: il nome breve dello stato ("Non trovato", "OK"...)."""
    return r._dati["messaggio"]


@proprieta(RispostaWeb, "spiegazione")
def _risposta_spiegazione(r: RispostaWeb) -> str:
    """risposta.spiegazione: una frase che spiega lo stato."""
    return r._dati["spiegazione"]


@proprieta(RispostaWeb, "testo")
def _risposta_testo(r: RispostaWeb) -> str:
    """risposta.testo: il contenuto come testo (l'HTML, il testo, il JSON grezzo)."""
    return r._dati["testo"]


@proprieta(RispostaWeb, "json_risposta")
def _risposta_json(r: RispostaWeb) -> Any:
    """risposta.json_risposta: i dati JSON già trasformati in valori Leo (o `nulla`)."""
    return r._dati["json"]


@proprieta(RispostaWeb, "intestazioni")
def _risposta_intestazioni(r: RispostaWeb) -> dict:
    """risposta.intestazioni: le intestazioni della risposta (un dizionario)."""
    return r._dati["intestazioni"]


@proprieta(RispostaWeb, "tipo")
def _risposta_tipo(r: RispostaWeb) -> str:
    """risposta.tipo: il tipo di contenuto (per esempio "application/json")."""
    return r._dati["intestazioni"].get("Content-Type", "")


@proprieta(RispostaWeb, "indirizzo")
def _risposta_indirizzo(r: RispostaWeb) -> str:
    """risposta.indirizzo: l'indirizzo finale (dopo eventuali reindirizzamenti)."""
    return r._dati["indirizzo"]


@metodo_oggetto(RispostaWeb, "solleva_se_errore")
def _risposta_solleva(r: RispostaWeb):
    """risposta.solleva_se_errore(): ferma il programma con un errore se lo stato non è 2xx.

    Comodo quando vuoi che un 404 o un 500 diventi subito un errore invece di
    controllare `risposta.riuscita`. Se va tutto bene restituisce la risposta
    stessa, così puoi concatenare: `variabile r = ottieni_pagina(u).solleva_se_errore()`.
    """
    if not r._dati["riuscita"]:
        raise ErroreFile(f"Il sito ha risposto con un errore. {r._dati['spiegazione']}.",
                         suggerimento="Controlla `risposta.stato` e `risposta.testo` per capire cosa è successo.")
    return r


# ===========================================================================
# Cliente HTTP
# ===========================================================================

@funzione_libreria("ottieni_pagina")
def ottieni_pagina(indirizzo, parametri=None, intestazioni=None, tempo_massimo=15):
    """ottieni_pagina(indirizzo, parametri = nulla, intestazioni = nulla, tempo_massimo = 15): chiede una pagina o dei dati (GET).

    Restituisce una `risposta_web` da leggere con `risposta.stato`, `risposta.testo`,
    `risposta.json_risposta`, `risposta.riuscita`. Un codice di errore (404, 500...) NON
    ferma il programma. `parametri` finisce nell'indirizzo (?a=1&b=2).
    Esempio: `variabile r = ottieni_pagina("https://api.esempio.it/cerca", parametri = {"q": "Dante"})`.
    """
    return RispostaWeb(_esegui_http("ottieni_pagina", indirizzo, "GET", parametri, None, None,
                                    intestazioni, tempo_massimo))


@funzione_libreria("invia_json")
def invia_json(indirizzo, dati, intestazioni=None, metodo="POST", tempo_massimo=15):
    """invia_json(indirizzo, dati, intestazioni = nulla, metodo = "POST", tempo_massimo = 15): invia dati come JSON.

    `dati` (un dizionario o una lista) viene inviato come JSON. Con `metodo` scegli
    "POST" (predefinito), "PUT", "PATCH" o "DELETE". Restituisce una `risposta_web`.
    Esempio: `variabile r = invia_json("https://api.esempio.it/voti", {"voto": 30})`.
    """
    richiedi_testo(metodo, "invia_json", "metodo")
    return RispostaWeb(_esegui_http("invia_json", indirizzo, metodo, None, None, dati,
                                    intestazioni, tempo_massimo))


@funzione_libreria("invia_dati")
def invia_dati(indirizzo, campi, intestazioni=None, metodo="POST", tempo_massimo=15):
    """invia_dati(indirizzo, campi, intestazioni = nulla, metodo = "POST", tempo_massimo = 15): invia un modulo web.

    `campi` è un dizionario inviato come un modulo compilato nel browser
    (``application/x-www-form-urlencoded``), non come JSON. Restituisce una `risposta_web`.
    Esempio: `invia_dati("https://sito.esempio.it/accesso", {"utente": "aldo", "parola": "..."})`.
    """
    if not isinstance(campi, dict):
        raise ErroreTipo(f"`campi` di `invia_dati` deve essere un dizionario nome -> valore, "
                         f"non {articolo(campi)}.",
                         suggerimento="Per inviare JSON (liste/dizionari annidati) usa `invia_json`.")
    richiedi_testo(metodo, "invia_dati", "metodo")
    return RispostaWeb(_esegui_http("invia_dati", indirizzo, metodo, None, campi, None,
                                    intestazioni, tempo_massimo))


# ===========================================================================
# Risposta su misura dentro una rotta
# ===========================================================================

@funzione_libreria("componi_risposta")
def componi_risposta(contenuto=None, stato=200, tipo=None, intestazioni=None):
    """componi_risposta(contenuto = nulla, stato = 200, tipo = nulla, intestazioni = nulla): una risposta su misura.

    Si restituisce dalla funzione di una rotta quando vuoi decidere lo `stato`
    (per esempio 404 o 201), il `tipo` o le `intestazioni`. Un testo che comincia
    con `<html>` diventa HTML, un dizionario o una lista diventano JSON.
    Esempio: `funzione gestisci(r) restituisci componi_risposta({"errore": "non trovato"}, stato = 404) fine`.
    """
    if isinstance(stato, bool) or not isinstance(stato, int) or not 100 <= stato <= 599:
        raise ErroreValore(f"`stato` di `componi_risposta` deve essere un codice HTTP tra 100 e 599, "
                           f"non {mostra(stato)}.")
    risposta: dict = {"stato": stato}
    if isinstance(contenuto, (dict, list)):
        risposta["json"] = contenuto
    elif isinstance(contenuto, (bool, int, float)):
        risposta["json"] = contenuto
    elif contenuto is None:
        risposta["testo"] = ""
    elif isinstance(contenuto, str):
        risposta["testo"] = contenuto
    else:
        raise ErroreTipo(f"`componi_risposta` può inviare un testo, un numero, una lista o un dizionario, "
                         f"non {articolo(contenuto)}.")
    if tipo is not None:
        richiedi_testo(tipo, "componi_risposta", "tipo")
        risposta["tipo"] = tipo
    if intestazioni is not None:
        if not isinstance(intestazioni, dict):
            raise ErroreTipo(f"`intestazioni` di `componi_risposta` deve essere un dizionario, "
                             f"non {articolo(intestazioni)}.")
        risposta["intestazioni"] = intestazioni
    return risposta


# ===========================================================================
# Server web con rotte
# ===========================================================================

class _Lavoro:
    """Una richiesta in attesa che il programma Leo la gestisca (sul suo thread)."""

    def __init__(self, funzione: Any, richiesta: dict) -> None:
        self.funzione = funzione
        self.richiesta = richiesta
        self.risposta: Any = None
        self.fatto = threading.Event()


class _Rotta:
    """Una rotta: metodo, i pezzi del percorso (con variabili e jolly), la funzione."""

    def __init__(self, metodo: str, percorso: str, funzione: Any) -> None:
        self.metodo = metodo
        self.percorso = percorso
        self.funzione = funzione
        self.pezzi = tuple(p for p in percorso.split("/") if p != "")
        self.variabile = tuple(p.startswith(":") for p in self.pezzi)
        self.jolly = bool(self.pezzi) and self.pezzi[-1] == "*"
        self.esatta = not any(self.variabile) and not self.jolly

    def combacia(self, pezzi: tuple) -> dict | None:
        """Restituisce le variabili se il percorso combacia, altrimenti ``None``."""
        if self.jolly:
            fissi = self.pezzi[:-1]
            if len(pezzi) < len(fissi):
                return None
            for p, atteso, e_var in zip(pezzi, fissi, self.variabile):
                if not e_var and p != atteso:
                    return None
            variabili = {a[1:]: p for p, a, v in zip(pezzi, fissi, self.variabile) if v}
            variabili["*"] = "/".join(pezzi[len(fissi):])
            return variabili
        if len(pezzi) != len(self.pezzi):
            return None
        variabili = {}
        for p, atteso, e_var in zip(pezzi, self.pezzi, self.variabile):
            if e_var:
                variabili[atteso[1:]] = p
            elif p != atteso:
                return None
        return variabili


class ServerConRotte(OggettoLibreria):
    """Un piccolo server web su questo computer, con rotte per percorso e metodo.

    Le richieste arrivano su un thread secondario; la funzione di ogni rotta la
    esegue però `avvia_server` sul thread del programma (il codice Leo gira
    sempre in un solo thread).
    """

    NOME_TIPO_DANTE = "server_web_pro"
    SUGGERIMENTO_MODIFICA = "Per aggiungere una rotta usa `aggiungi_rotta(server, percorso, funzione)`."
    ATTESA_MASSIMA = 30.0

    def __init__(self, porta: int, host: str = "127.0.0.1") -> None:
        self.porta_richiesta = porta
        self.rotte: list[_Rotta] = []
        self.servite = 0
        self._coda: "queue.Queue[_Lavoro]" = queue.Queue()
        self._in_servizio = False
        self._stop = threading.Event()
        self._locale = rete.ServerLocale(porta, self._gestisci, host)

    def testo_dante(self) -> str:
        return f"<server_web_pro {self._locale.indirizzo or 'spento'}>"

    # -- registrazione -----------------------------------------------------------
    def aggiungi(self, percorso: str, funzione: Any, metodo: str) -> None:
        self.rotte = [r for r in self.rotte if not (r.metodo == metodo and r.percorso == percorso)]
        self.rotte.append(_Rotta(metodo, percorso, funzione))

    def _cerca(self, percorso: str, metodo: str) -> tuple[Any, dict] | tuple[None, bool]:
        """(funzione, variabili) se combacia; (None, vero) se il percorso c'è ma non il metodo;
        (None, falso) se il percorso non esiste."""
        pezzi = tuple(p for p in percorso.split("/") if p != "")
        percorso_esiste = False
        for soltanto_esatte in (True, False):
            for r in self.rotte:
                if r.esatta != soltanto_esatte:
                    continue
                variabili = r.combacia(pezzi)
                if variabili is None:
                    continue
                percorso_esiste = True
                if r.metodo == metodo or (r.metodo == "GET" and metodo == "HEAD"):
                    return r.funzione, variabili
        return None, percorso_esiste

    # -- thread del server -------------------------------------------------------
    def _gestisci(self, richiesta: dict) -> Any:
        if not self._in_servizio:
            return {"stato": 503, "testo": "Il server non sta ancora servendo le richieste."}
        funzione, info = self._cerca(richiesta["percorso"], richiesta["metodo"])
        if funzione is None:
            if info:  # il percorso esiste ma non per questo metodo
                return {"stato": 405, "testo": f"Metodo {richiesta['metodo']} non permesso "
                                               f"su {richiesta['percorso']}."}
            return {"stato": 404, "testo": f"Pagina non trovata: {richiesta['percorso']}"}
        richiesta = dict(richiesta)
        richiesta["variabili"] = info
        lavoro = _Lavoro(funzione, richiesta)
        self._coda.put(lavoro)
        if not lavoro.fatto.wait(self.ATTESA_MASSIMA):
            return {"stato": 503, "testo": "Il programma non ha risposto in tempo."}
        return lavoro.risposta

    # -- comandi -----------------------------------------------------------------
    def avvia(self) -> None:
        self._locale.avvia()

    def ferma(self) -> None:
        self._stop.set()
        self._in_servizio = False
        self._locale.ferma()
        while True:
            try:
                lavoro = self._coda.get_nowait()
            except queue.Empty:
                break
            lavoro.risposta = {"stato": 503, "testo": "Il server si sta spegnendo."}
            lavoro.fatto.set()


def _porta(porta: Any) -> int:
    if isinstance(porta, bool) or not isinstance(porta, int) or not 0 <= porta <= 65535:
        raise ErroreValore("`porta` di `crea_server_web` deve essere un intero tra 1024 e 65535 "
                           "(0 = una porta libera).",
                           suggerimento="Esempio: `crea_server_web(8080)`.")
    return porta


@funzione_libreria("crea_server_web")
def crea_server_web(porta=8080):
    """crea_server_web(porta = 8080): crea un server web su questo computer, con rotte.

    Poi aggiungi le rotte con `aggiungi_rotta(server, percorso, funzione)` e accendi
    con `avvia_server(server)`. Ascolta solo su 127.0.0.1 (questo computer). `porta = 0`
    sceglie una porta libera (la leggi da `server.indirizzo`).
    Esempio: `variabile server = crea_server_web(8080)`.
    """
    return ServerConRotte(_porta(porta))


@funzione_libreria("aggiungi_rotta")
def aggiungi_rotta(server, percorso, funzione, metodo="GET"):
    """aggiungi_rotta(server, percorso, funzione, metodo = "GET"): collega una funzione a un percorso.

    La `funzione` riceve la richiesta (`metodo`, `percorso`, `parametri`, `corpo`,
    `json`, `intestazioni`, `variabili`, `cliente`) e restituisce un testo, un
    dizionario/lista (JSON), un numero oppure `componi_risposta(...)`. Il percorso
    può avere parti variabili (`"/utenti/:id"` -> `richiesta["variabili"]["id"]`) e
    una parte finale jolly (`"/file/*"`).
    Esempio: `aggiungi_rotta(server, "/ciao", funzione (richiesta) restituisci "Ciao!" fine)`.
    """
    if not isinstance(server, ServerConRotte):
        raise ErroreTipo(f"`aggiungi_rotta` vuole come primo argomento un server di `crea_server_web`, "
                         f"non {articolo(server)}.")
    if not isinstance(percorso, str) or not percorso.startswith("/"):
        raise ErroreValore(f"Il percorso di una rotta deve cominciare con \"/\", non {mostra(percorso)}.",
                           suggerimento="Esempi: \"/\", \"/dati\", \"/utenti/:id\".")
    if not isinstance(funzione, Richiamabile):
        raise ErroreTipo(f"`aggiungi_rotta` vuole una funzione da eseguire, non {articolo(funzione)}.",
                         suggerimento="Esempio: `aggiungi_rotta(server, \"/ciao\", funzione (r) restituisci \"Ciao\" fine)`.")
    richiedi_testo(metodo, "aggiungi_rotta", "metodo")
    m = metodo.strip().upper()
    if m not in rete.METODI:
        raise ErroreValore(f"Il metodo {mostra(metodo)} non esiste.",
                           suggerimento="Usa \"GET\" (leggere), \"POST\" (inviare), \"PUT\", \"PATCH\" o \"DELETE\".")
    server.aggiungi(percorso, funzione, m)
    return None


def _controlla_limite(valore: Any, parametro: str) -> None:
    if valore is not None and (isinstance(valore, bool) or not isinstance(valore, (int, float))
                               or valore <= 0 or (parametro == "richieste" and not isinstance(valore, int))):
        raise ErroreValore(f"`{parametro}` di `avvia_server` deve essere un numero maggiore di zero.")


@funzione_libreria("avvia_server", interprete=True)
def avvia_server(interprete, server, richieste=None, secondi=None):
    """avvia_server(server, richieste = nulla, secondi = nulla): accende il server e risponde alle richieste.

    Resta in ascolto ed esegue la funzione della rotta che combacia con ogni
    richiesta. Si ferma dopo `richieste` richieste, dopo `secondi` secondi, con
    `ferma_server(server)` (anche dentro una rotta) o con Ctrl+C. Restituisce
    quante richieste ha servito. L'indirizzo è in `server.indirizzo`.
    Esempio: `avvia_server(server, richieste = 10)`.
    """
    if not isinstance(server, ServerConRotte):
        raise ErroreTipo(f"`avvia_server` vuole un server di `crea_server_web`, non {articolo(server)}.")
    if not server.rotte:
        raise ErroreValore("Il server non ha nessuna rotta da servire.",
                           suggerimento="Aggiungine almeno una con `aggiungi_rotta(server, \"/\", funzione ...)`.")
    _controlla_limite(richieste, "richieste")
    _controlla_limite(secondi, "secondi")
    server._stop.clear()
    server.avvia()
    server._in_servizio = True
    servite = 0
    fine_tempo = time.monotonic() + secondi if secondi is not None else None
    try:
        while not server._stop.is_set():
            if richieste is not None and servite >= richieste:
                break
            if getattr(interprete, "_ferma_richiesta", False):
                break
            attesa = 0.2
            if fine_tempo is not None:
                rimasto = fine_tempo - time.monotonic()
                if rimasto <= 0:
                    break
                attesa = min(attesa, rimasto)
            try:
                lavoro = server._coda.get(timeout=attesa)
            except queue.Empty:
                continue
            try:
                valore = interprete.chiama(lavoro.funzione, [lavoro.richiesta])
                lavoro.risposta = valore
            except ErroreDante as e:
                lavoro.risposta = {"stato": 500, "testo": f"Errore nel programma: {e.messaggio}"}
                raise
            except BaseException:
                lavoro.risposta = {"stato": 500, "testo": "Errore nel programma."}
                raise
            finally:
                lavoro.fatto.set()
                servite += 1
                server.servite += 1
    finally:
        server._in_servizio = False
    return servite


@funzione_libreria("ferma_server")
def ferma_server(server):
    """ferma_server(server): spegne il server.

    Si può chiamare anche dentro la funzione di una rotta: il server finisce di
    rispondere a quella richiesta e poi `avvia_server` termina.
    """
    if not isinstance(server, ServerConRotte):
        raise ErroreTipo(f"`ferma_server` vuole un server di `crea_server_web`, non {articolo(server)}.")
    server.ferma()
    return None


@proprieta(ServerConRotte, "indirizzo")
def _server_indirizzo(s: ServerConRotte) -> str:
    """server.indirizzo: l'indirizzo da aprire nel browser (vuoto se spento)."""
    return s._locale.indirizzo


@proprieta(ServerConRotte, "porta")
def _server_porta(s: ServerConRotte) -> int:
    """server.porta: la porta su cui ascolta (quella vera, anche se hai chiesto 0)."""
    srv = s._locale._server
    return int(srv.server_address[1]) if srv is not None else s.porta_richiesta


@proprieta(ServerConRotte, "attivo")
def _server_attivo(s: ServerConRotte) -> bool:
    """server.attivo: `vero` se il server è acceso."""
    return s._locale.attivo


@proprieta(ServerConRotte, "richieste_servite")
def _server_servite(s: ServerConRotte) -> int:
    """server.richieste_servite: quante richieste ha servito finora."""
    return s.servite


@proprieta(ServerConRotte, "rotte")
def _server_rotte(s: ServerConRotte) -> list:
    """server.rotte: l'elenco delle rotte come testi ("GET /utenti/:id")."""
    return [f"{r.metodo} {r.percorso}" for r in s.rotte]
