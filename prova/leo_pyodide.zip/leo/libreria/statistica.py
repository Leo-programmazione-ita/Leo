"""Libreria: statistica semplice su liste di numeri.

``media``, ``mediana``, ``moda``, ``varianza``, ``deviazione``.
Accettano una lista di numeri o un intervallo.
"""

from __future__ import annotations

import math
import operator
from collections import Counter
from typing import Any

from ..errori import ErroreTipo, ErroreValore
from ..valori import e_numero, uguali
from .generali import articolo, funzione_libreria, lunghezza_intervallo, richiedi_logico, tipi, tutti_numeri

# Gli intervalli non diventano mai liste: media, mediana, moda e varianza di
# ``1..1000000000`` si calcolano con le formule delle progressioni aritmetiche.


def _troppo_grande(nome: str) -> ErroreValore:
    return ErroreValore(f"Il risultato di `{nome}` è troppo grande per essere calcolato.",
                        suggerimento="I numeri della lista sono enormi: prova a dividerli prima per 1000.")


def _vuota(nome: str) -> ErroreValore:
    return ErroreValore(f"Non posso calcolare `{nome}` di una lista vuota.",
                        suggerimento="Controlla prima con `se non vuota(lista) allora`.")


def _numeri(valore: Any, nome: str, *, minimo: int = 1) -> list | range:
    """I numeri su cui lavorare: la lista stessa (controllata) o l'intervallo così com'è."""
    if isinstance(valore, range):
        n = lunghezza_intervallo(valore)
    elif isinstance(valore, list):
        if not tutti_numeri(valore):
            for v in valore:
                if not e_numero(v):
                    suggerimento = None
                    if isinstance(v, str):
                        suggerimento = "Trasforma prima i testi in numeri: `mappa(lista, decimale)`."
                    raise ErroreTipo(f"`{nome}` lavora solo con numeri, ma nella lista c'è {articolo(v)}.",
                                     suggerimento=suggerimento)
        n = len(valore)
    else:
        raise ErroreTipo(f"`{nome}` vuole una lista di numeri, non {articolo(valore)}.",
                         suggerimento=f"Esempio: `{nome}([28, 30, 24])`.")
    if n < minimo:
        if n == 0:
            raise _vuota(nome)
        raise ErroreValore(f"Per calcolare `{nome}` servono almeno {minimo} numeri.")
    return valore


def _somma_precisa(dati: list, nome: str) -> float:
    """Somma di decimali senza errori di arrotondamento accumulati."""
    try:
        return math.fsum(dati)
    except OverflowError:  # un intero enorme insieme a dei decimali
        raise _troppo_grande(nome) from None
    except ValueError:  # infinito meno infinito
        return math.nan


def _dividi(totale: int, n: int, nome: str) -> int | float:
    """``totale / n``: un intero se la divisione è esatta, altrimenti un decimale."""
    if totale % n == 0:
        return totale // n
    try:
        return totale / n  # la divisione tra interi di Python è arrotondata correttamente
    except OverflowError:
        raise _troppo_grande(nome) from None


def _media(dati: list, nome: str = "media") -> int | float:
    if tipi(dati) == {int}:
        return _dividi(sum(dati), len(dati), nome)
    try:
        return _somma_precisa(dati, nome) / len(dati)
    except OverflowError:  # pragma: no cover - fsum dà già un decimale finito o infinito
        raise _troppo_grande(nome) from None


@funzione_libreria("media")
def media(lista):
    """media(lista): la media dei numeri (la somma divisa per quanti sono).

    Esempio: `media([28, 30, 24])` è 27. Se la media è intera il risultato è un intero.
    """
    dati = _numeri(lista, "media")
    if isinstance(dati, range):
        # media di una progressione aritmetica: (primo + ultimo) / 2
        return _dividi(dati[0] + dati[-1], 2, "media")
    return _media(dati)


@funzione_libreria("mediana")
def mediana(lista):
    """mediana(lista): il numero che sta nel mezzo, dopo aver messo i numeri in ordine.

    Esempio: `mediana([3, 1, 100])` è 3; con un numero pari di valori è la media dei due centrali:
    `mediana([1, 2, 3, 4])` è 2.5.
    """
    dati = _numeri(lista, "mediana")
    if isinstance(dati, range):
        ordinati = dati if dati.step > 0 else dati[::-1]  # un intervallo è già in ordine
    else:
        if float in tipi(dati) and any(v != v for v in dati):
            raise ErroreValore("Non posso calcolare `mediana` se c'è `non_numero`.")
        ordinati = sorted(dati)
    n = lunghezza_intervallo(ordinati) if isinstance(ordinati, range) else len(ordinati)
    meta = n // 2
    if n % 2:
        return ordinati[meta]
    return _media([ordinati[meta - 1], ordinati[meta]], "mediana")


_VERO, _FALSO = object(), object()


@funzione_libreria("moda")
def moda(lista):
    """moda(lista): il valore che compare più volte (a parità, il primo che si incontra).

    Esempio: `moda([3, 5, 3, 8])` è 3. Funziona anche con i testi: `moda(["sì", "no", "sì"])` è "sì".
    """
    if isinstance(lista, range):
        dati = _numeri(lista, "moda")
        return dati[0]  # ogni numero compare una volta sola: vince il primo
    if not isinstance(lista, list):
        raise ErroreTipo(f"`moda` vuole una lista, non {articolo(lista)}.")
    if not lista:
        raise ErroreValore("Non posso calcolare `moda` di una lista vuota.")
    presenti = tipi(lista)
    if presenti <= {int, float, str, type(None)}:
        # veloce: per questi valori l'uguaglianza di Python è quella di Leo (3 == 3.0, "3" != 3).
        # Counter ricorda il primo valore incontrato e l'ordine: max tiene il primo a parità.
        conteggi = Counter(lista)
        return max(conteggi.items(), key=operator.itemgetter(1))[0]
    if presenti <= {int, float, str, type(None), bool}:
        # `vero` non è 1: i logici diventano segnaposti diversi dai numeri
        chiavi = [(_VERO if v else _FALSO) if type(v) is bool else v for v in lista]
        chiave = max(Counter(chiavi).items(), key=operator.itemgetter(1))[0]
        return True if chiave is _VERO else False if chiave is _FALSO else chiave
    visti: list = []
    for v in lista:
        for coppia in visti:
            if uguali(coppia[0], v):
                coppia[1] += 1
                break
        else:
            visti.append([v, 1])
    return max(visti, key=lambda c: c[1])[0]


def _varianza(dati: list | range, campione: bool, nome: str) -> float:
    if isinstance(dati, range):
        # progressione aritmetica: passo² · (n² - 1) / 12, oppure passo² · n · (n + 1) / 12 (campione)
        n = lunghezza_intervallo(dati)
        numeratore = dati.step * dati.step * (n * (n + 1) if campione else n * n - 1)
        return _decimale(numeratore, 12, nome)
    n = len(dati)
    divisore = n - (1 if campione else 0)
    if tipi(dati) == {int}:
        # calcolo esatto con gli interi, poi un solo arrotondamento: (n·Σx² - (Σx)²) / (n · divisore)
        totale = sum(dati)
        quadrati = sum(map(operator.mul, dati, dati))
        return _decimale(n * quadrati - totale * totale, n * divisore, nome)
    m = _somma_precisa(dati, nome) / n
    try:
        scarti = [x - m for x in dati]
        return _somma_precisa(list(map(operator.mul, scarti, scarti)), nome) / divisore
    except OverflowError:
        raise _troppo_grande(nome) from None


def _decimale(numeratore: int, denominatore: int, nome: str) -> float:
    try:
        return numeratore / denominatore
    except OverflowError:
        raise _troppo_grande(nome) from None


@funzione_libreria("varianza")
def varianza(lista, campione=False):
    """varianza(lista, campione = falso): quanto i numeri sono sparpagliati (media dei quadrati degli scarti).

    Esempio: `varianza([2, 4, 4, 4, 5, 5, 7, 9])` è 4.0. Con `campione = vero` divide per n - 1.
    """
    richiedi_logico(campione, "varianza", "campione")
    return _varianza(_numeri(lista, "varianza", minimo=2 if campione else 1), campione, "varianza")


@funzione_libreria("deviazione")
def deviazione(lista, campione=False):
    """deviazione(lista, campione = falso): la deviazione standard, cioè di quanto in media i numeri
    si allontanano dalla media.

    Esempio: `deviazione([2, 4, 4, 4, 5, 5, 7, 9])` è 2.0.
    """
    richiedi_logico(campione, "deviazione", "campione")
    v = _varianza(_numeri(lista, "deviazione", minimo=2 if campione else 1), campione, "deviazione")
    return math.sqrt(v) if v >= 0 or v != v else math.nan
