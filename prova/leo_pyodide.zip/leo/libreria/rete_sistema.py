"""Libreria "rete e sistema": parlare con altri programmi e conoscere il computer, su ogni sistema.

Solo libreria standard di Python (``socket``, ``ssl``, ``ipaddress``, ``imaplib``,
``smtplib``, ``ftplib``, ``subprocess``, ``platform``, ``shutil``). Funziona su
Windows, Linux, macOS e, dove ha senso, nell'app Android.

Gruppi di funzioni:

* **collegamenti TCP**: ``collegati`` (oggetto ``connessione`` con ``invia``,
  ``ricevi``, ``ricevi_riga``, ``chiudi``) e ``server_tcp`` (``aspetta_cliente``,
  ``chiudi``) per far parlare due programmi Leo;
* **messaggi UDP**: ``invia_udp``, ``ricevi_udp``;
* **porte**: ``porta_aperta`` (un solo indirizzo e una sola porta), ``porta_libera``;
* **nomi e indirizzi**: ``indirizzo_di``, ``indirizzi_di``, ``nome_di_indirizzo``,
  ``e_indirizzo_ip``, ``info_indirizzo_ip``, ``indirizzo_in_rete``, ``info_rete``;
* **certificati dei siti**: ``certificato_sito``, ``giorni_scadenza_certificato``;
* **posta**: ``apri_posta`` (IMAP: ``cartelle``, ``elenco_messaggi``, ``leggi_messaggio``,
  ``cerca_messaggi``, ``salva_allegati``, ``chiudi``) e ``invia_email_con_allegati``;
* **FTP**: ``apri_ftp`` (``elenca``, ``scarica``, ``carica``, ``chiudi``);
* **processi**: ``avvia_in_sfondo`` (oggetto ``processo`` con ``leggi_uscita``,
  ``aspetta``, ``ferma``);
* **sistema**: ``sistema_operativo``, ``info_sistema``, ``memoria_sistema``,
  ``spazio_disco``, ``fai_ping``, ``osserva_cartella`` (``novita``,
  ``aspetta_novita``), ``velocita_scaricamento``.

Sicurezza (vale per tutto il modulo): solo usi legittimi e difensivi. Niente
scansioni di reti o di computer altrui: ``porta_aperta`` controlla UNA porta di
UN indirizzo per volta, con una pausa minima fra un controllo e l'altro verso
altri computer; niente pacchetti grezzi, niente ascolto del traffico altrui.
I server ascoltano solo su questo computer (127.0.0.1); per aprirli alla rete
di casa serve ``in_rete = vero`` e il permesso dell'utente. Le password non
viaggiano mai senza cifratura (tranne verso questo computer) e non compaiono
nei messaggi d'errore. ``ferma`` chiude solo i processi avviati dal programma.
"""

from __future__ import annotations

import binascii
import codecs
import datetime
import email
import email.policy
import ftplib
import imaplib
import ipaddress
import locale
import mimetypes
import os
import platform
import re
import select
import shutil
import signal
import smtplib
import socket
import ssl
import subprocess
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from email.message import EmailMessage
from email.utils import formatdate, make_msgid, parsedate_to_datetime
from typing import Any

from ..errori import ErroreDante, ErroreFile, ErroreTipo, ErroreValore
from .date import DataDante
from .generali import articolo, funzione_libreria, mostra, richiedi_logico, richiedi_testo
from .internet import _errore_rete, _indirizzi_email, _misura, _senza_segreti
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta

_HOST_LOCALI = {"localhost", "127.0.0.1", "::1"}
#: Pausa minima (secondi) fra due controlli di porta verso un altro computer: niente scansioni.
PAUSA_CONTROLLI = 1.0
_ULTIMO_CONTROLLO = [0.0]
#: Porte per cui l'utente ha già dato il permesso di ascoltare in rete (vale per tutta l'esecuzione).
_PERMESSI_RETE: set[tuple[str, int]] = set()
#: Righe e messaggi troppo lunghi: probabilmente l'altro programma non manda righe.
MASSIMO_RIGA = 1024 * 1024
MASSIMO_UDP = 60000
MASSIMO_ALLEGATI = 25 * 1024 * 1024


# ===========================================================================
# Controlli comuni
# ===========================================================================

def _fermato(interprete: Any) -> bool:
    return bool(getattr(interprete, "fermato", False))


def _pausa(interprete: Any, secondi: float) -> None:
    """Aspetta un po' (con la grafica lascia vivere la finestra)."""
    ponte = getattr(interprete, "ponte_grafico", None)
    if ponte is not None and hasattr(ponte, "attendi"):
        ponte.attendi(secondi)
    else:
        time.sleep(secondi)


def _tempo(valore: Any, nome: str, parametro: str = "tempo_massimo", nulla_ok: bool = False) -> float | None:
    if valore is None and nulla_ok:
        return None
    if isinstance(valore, bool) or not isinstance(valore, (int, float)):
        altro = ", oppure `nulla` per aspettare senza limite" if nulla_ok else ""
        raise ErroreTipo(f"`{parametro}` di `{nome}` deve essere un numero di secondi, non {articolo(valore)}.",
                         suggerimento=f"Scrivi per esempio `{parametro} = 10`{altro}.")
    if valore != valore or valore <= 0:
        raise ErroreValore(f"`{parametro}` di `{nome}` deve essere maggiore di zero.")
    if valore > 10_000_000:
        raise ErroreValore(f"`{parametro}` di `{nome}` è troppo grande.",
                           suggerimento="Usa un numero di secondi ragionevole, per esempio 30.")
    return float(valore)


def _porta(valore: Any, nome: str, server: bool = False) -> int:
    if isinstance(valore, bool) or not isinstance(valore, int):
        raise ErroreTipo(f"La `porta` di `{nome}` deve essere un numero intero, non {articolo(valore)}.",
                         suggerimento="Esempio: 5000.")
    if server:
        if valore != 0 and not 1024 <= valore <= 65535:
            raise ErroreValore(f"La `porta` di `{nome}` deve essere tra 1024 e 65535 (0 = una porta libera).",
                               suggerimento="Le porte sotto 1024 sono riservate al sistema: usa per esempio 5000.")
    elif not 1 <= valore <= 65535:
        raise ErroreValore(f"La `porta` di `{nome}` deve essere tra 1 e 65535.")
    return valore


_ETICHETTA = re.compile(r"^[A-Za-z0-9_]([A-Za-z0-9_-]{0,62})$")


def _host(valore: Any, nome: str, parametro: str = "indirizzo") -> str:
    """Un nome di computer o un indirizzo IP scritto bene (accetta anche un indirizzo web)."""
    richiedi_testo(valore, nome, parametro)
    host = valore.strip()
    if "://" in host:
        try:
            host = urllib.parse.urlsplit(host).hostname or ""
        except ValueError:
            host = ""
    if host.startswith("[") and host.endswith("]"):
        host = host[1:-1]
    esempio = f"Scrivi per esempio `{nome}(\"www.esempio.it\")` oppure un indirizzo come \"192.168.1.10\"."
    if not host:
        raise ErroreValore(f"Il parametro `{parametro}` di `{nome}` è vuoto.", suggerimento=esempio)
    try:
        return str(ipaddress.ip_address(host))
    except ValueError:
        pass
    try:
        ascii_ = host.encode("idna").decode("ascii") if not host.isascii() else host
    except UnicodeError:
        ascii_ = ""
    parti = ascii_.rstrip(".").split(".") if ascii_ else [""]
    if (len(ascii_) > 253 or not all(_ETICHETTA.match(p) for p in parti)
            or not re.search(r"[A-Za-z_]", ascii_) or (len(parti) > 1 and parti[-1][0].isdigit())):
        raise ErroreValore(f"{mostra(valore)} non è un nome di computer o un indirizzo valido.", suggerimento=esempio)
    return ascii_


def _e_locale(host: str) -> bool:
    if host.lower() in _HOST_LOCALI:
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def _errore(e: BaseException, host: str, porta: int, tempo: float) -> ErroreFile:
    return _errore_rete(e, urllib.parse.urlsplit(f"tcp://{_con_parentesi(host)}:{porta}"), tempo)


def _con_parentesi(host: str) -> str:
    return f"[{host}]" if ":" in host else host


def _chiedi_rete(interprete: Any, nome: str, porta: int, protocollo: str) -> None:
    from ..sistema._win import chiedi_conferma

    chiave = (protocollo, porta)
    if chiave in _PERMESSI_RETE and porta != 0:
        return
    testo = (f"Il programma vuole ricevere collegamenti ({protocollo}) dagli altri computer della rete "
             f"sulla porta {porta or 'scelta dal sistema'}.\n\nVuoi permetterlo?")
    if not chiedi_conferma(interprete, testo):
        raise ErroreValore(f"`{nome}`: l'utente non ha dato il permesso di ascoltare in rete.",
                           suggerimento="Senza `in_rete = vero` il programma parla solo con questo computer.")
    _PERMESSI_RETE.add(chiave)


def _ip_di_casa() -> str:
    """L'indirizzo di questo computer nella rete di casa (senza mandare niente in rete)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))  # UDP: connect non invia pacchetti
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def _data(dt: datetime.datetime | None) -> DataDante | None:
    if dt is None:
        return None
    if dt.tzinfo is not None:
        dt = dt.astimezone().replace(tzinfo=None)
    return DataDante(dt.replace(microsecond=0))


def _aspetta_lettura(interprete: Any, sock: socket.socket, scadenza: float | None) -> bool:
    """Vero quando ``sock`` ha qualcosa da leggere; falso a tempo scaduto o se il programma si ferma."""
    ponte = getattr(interprete, "ponte_grafico", None)
    while True:
        if _fermato(interprete):
            return False
        rimasto = None if scadenza is None else scadenza - time.monotonic()
        if rimasto is not None and rimasto <= 0:
            try:
                return bool(select.select([sock], [], [], 0)[0])
            except (OSError, ValueError):
                return True
        passo = 0.2 if rimasto is None else min(0.2, rimasto)
        try:
            pronto = select.select([sock], [], [], 0 if ponte is not None else passo)[0]
        except (OSError, ValueError):
            return True  # socket chiuso: la lettura dirà che cosa è successo
        if pronto:
            return True
        if ponte is not None:
            _pausa(interprete, min(0.05, passo))


# ===========================================================================
# Collegamenti TCP
# ===========================================================================

class Connessione(OggettoLibreria):
    """Un collegamento TCP con un altro programma (testo in UTF-8)."""

    NOME_TIPO_DANTE = "connessione"
    SUGGERIMENTO_MODIFICA = "Per mandare un messaggio usa `connessione.invia(testo)`."

    def __init__(self, sock: socket.socket, host: str, porta: int, tempo: float | None) -> None:
        self.sock = sock
        self.host = host
        self.porta = porta
        self.tempo = tempo
        self.aperta = True
        self.buffer = bytearray()
        self.decodificatore = codecs.getincrementaldecoder("utf-8")("replace")
        sock.settimeout(30)  # si legge solo dopo `select`: il limite serve a non restare appesi inviando

    def testo_dante(self) -> str:
        stato = "aperta" if self.aperta else "chiusa"
        return f"<connessione con {_con_parentesi(self.host)}:{self.porta} {stato}>"

    def chiudi(self) -> None:
        if self.aperta:
            self.aperta = False
            try:
                self.sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
        try:
            self.sock.close()
        except OSError:
            pass

    def _leggi_pezzo(self, interprete: Any, scadenza: float | None) -> bool:
        """Aggiunge al buffer quello che arriva; falso se non arriva niente (tempo o chiusura)."""
        if not self.aperta:
            return False
        # Con TLS i byte decifrati possono essere già pronti dentro la libreria: `select`
        # non li vede, quindi prima di aspettare controlliamo il "pending" del socket sicuro.
        in_sospeso = getattr(self.sock, "pending", None)
        if not (in_sospeso is not None and in_sospeso() > 0):
            if not _aspetta_lettura(interprete, self.sock, scadenza):
                return False
        try:
            dati = self.sock.recv(65536)
        except ssl.SSLWantReadError:
            return True  # serve altro traffico di rete: riproveremo
        except (ConnectionResetError, ConnectionAbortedError, OSError):
            dati = b""
        if not dati:
            self.chiudi()
            return False
        self.buffer += dati
        return True


def _scadenza(c: Connessione, tempo_massimo: Any, nome: str) -> float | None:
    tempo = c.tempo if tempo_massimo is None else _tempo(tempo_massimo, nome)
    return None if tempo is None else time.monotonic() + tempo


@funzione_libreria("collegati")
def collegati(indirizzo, porta, tempo_massimo=10, tls=False, verifica=True):
    """collegati(indirizzo, porta, tempo_massimo = 10, tls = falso): si collega a un programma che ascolta su quella porta.

    Restituisce una `connessione`: `invia(testo)`, `ricevi()`, `ricevi_riga()`, `chiudi()`;
    `aperta` dice se il collegamento è ancora attivo. Si parla in testo (UTF-8).
    Con `tls = vero` il collegamento è cifrato (per i servizi sicuri); con `verifica = falso`
    accetta anche un certificato non riconosciuto (comodo per i TUOI server di prova, meno sicuro).
    Esempio: `variabile c = collegati("127.0.0.1", 5000)` poi `c.invia("Ciao!")` e `stampa(c.ricevi_riga())`.
    """
    host = _host(indirizzo, "collegati")
    porta = _porta(porta, "collegati")
    tempo = _tempo(tempo_massimo, "collegati")
    richiedi_logico(tls, "collegati", "tls")
    richiedi_logico(verifica, "collegati", "verifica")
    try:
        sock = socket.create_connection((host, porta), timeout=tempo)
        if tls:
            sock = _avvolgi_tls(sock, host, verifica, tempo)
    except (OSError, UnicodeError) as e:
        raise _errore(e, host, porta, tempo) from None
    return Connessione(sock, host, porta, None)


def _avvolgi_tls(grezzo: socket.socket, host: str, verifica: bool, tempo: float | None) -> ssl.SSLSocket:
    """Trasforma un socket TCP in un socket cifrato (TLS) lato cliente."""
    nome_sni = None if e_indirizzo_ip(host) else host
    if verifica:
        contesto = ssl.create_default_context()
    else:
        contesto = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        contesto.check_hostname = False
        contesto.verify_mode = ssl.CERT_NONE
    try:
        return contesto.wrap_socket(grezzo, server_hostname=nome_sni or host)
    except ssl.SSLCertVerificationError:
        grezzo.close()
        raise ErroreFile(f"Il certificato di `{host}` non è riconosciuto.",
                         suggerimento="Se è un tuo server di prova usa `collegati(..., tls = vero, verifica = falso)`.") \
            from None


@proprieta(Connessione, "aperta")
def _conn_aperta(c: Connessione) -> bool:
    return c.aperta


@proprieta(Connessione, "indirizzo")
def _conn_indirizzo(c: Connessione) -> str:
    return c.host


@proprieta(Connessione, "porta")
def _conn_porta(c: Connessione) -> int:
    return c.porta


@metodo_oggetto(Connessione, "invia")
def connessione_invia(c, testo, a_capo=True):
    """connessione.invia(testo, a_capo = vero): manda un testo all'altro programma.

    Con `a_capo = vero` (predefinito) aggiunge "\\n" alla fine: così l'altro lo legge con `ricevi_riga()`.
    Esempio: `c.invia("Ciao, sono Ada")`.
    """
    richiedi_testo(testo, "invia", "testo")
    richiedi_logico(a_capo, "invia", "a_capo")
    if not c.aperta:
        raise ErroreFile("La connessione è chiusa: non posso inviare.",
                         suggerimento="Controlla `connessione.aperta` o collegati di nuovo con `collegati(...)`.")
    dati = (testo + ("\n" if a_capo and not testo.endswith("\n") else "")).encode("utf-8", "replace")
    try:
        c.sock.sendall(dati)
    except OSError:
        c.chiudi()
        raise ErroreFile(f"La connessione con `{c.host}` si è interrotta mentre inviavo.",
                         suggerimento="Forse l'altro programma si è chiuso.") from None
    return None


@metodo_oggetto(Connessione, "ricevi", interprete=True)
def connessione_ricevi(interprete, c, tempo_massimo=None):
    """connessione.ricevi(tempo_massimo = nulla): il testo arrivato (aspetta finché arriva qualcosa).

    Restituisce `nulla` se passa `tempo_massimo` secondi senza niente o se l'altro chiude
    (allora `connessione.aperta` diventa `falso`).
    Esempio: `variabile arrivato = c.ricevi(5)`.
    """
    scadenza = _scadenza(c, tempo_massimo, "ricevi")
    if not c.buffer:
        c._leggi_pezzo(interprete, scadenza)
    if not c.buffer:
        return None
    dati = bytes(c.buffer)
    c.buffer.clear()
    return c.decodificatore.decode(dati)


@metodo_oggetto(Connessione, "ricevi_riga", interprete=True)
def connessione_ricevi_riga(interprete, c, tempo_massimo=None):
    """connessione.ricevi_riga(tempo_massimo = nulla): la prossima riga arrivata (senza "\\n").

    È il modo più semplice per parlare fra due programmi: uno fa `invia(...)`, l'altro `ricevi_riga()`.
    Restituisce `nulla` a tempo scaduto o se l'altro ha chiuso.
    Esempio: `mentre c.aperta fai stampa(c.ricevi_riga()) fine`.
    """
    scadenza = _scadenza(c, tempo_massimo, "ricevi_riga")
    while b"\n" not in c.buffer:
        if len(c.buffer) > MASSIMO_RIGA:
            raise ErroreValore("La riga arrivata è troppo lunga (oltre 1 MB).",
                               suggerimento="Forse l'altro programma non manda righe: usa `ricevi()`.")
        if not c._leggi_pezzo(interprete, scadenza):
            if not c.aperta and c.buffer:  # l'ultima riga senza "a capo"
                break
            return None
    posizione = c.buffer.find(b"\n")
    if posizione < 0:
        riga, c.buffer = bytes(c.buffer), bytearray()
    else:
        riga = bytes(c.buffer[:posizione])
        del c.buffer[:posizione + 1]
    return riga.decode("utf-8", "replace").rstrip("\r")


@metodo_oggetto(Connessione, "chiudi")
def connessione_chiudi(c):
    """connessione.chiudi(): chiude il collegamento (l'altro programma riceve `nulla`).

    Esempio: `c.chiudi()`.
    """
    c.chiudi()
    return None


class ServerTcp(OggettoLibreria):
    """Un piccolo server TCP: aspetta che altri programmi si colleghino."""

    NOME_TIPO_DANTE = "server_tcp"

    def __init__(self, sock: socket.socket, in_rete: bool) -> None:
        self.sock = sock
        self.in_rete = in_rete
        self.porta = sock.getsockname()[1]
        self.attivo = True
        self.clienti = 0

    def testo_dante(self) -> str:
        return f"<server_tcp {_indirizzo_server(self)} {'attivo' if self.attivo else 'chiuso'}>"


@funzione_libreria("server_tcp", interprete=True)
def server_tcp(interprete, porta, in_rete=False):
    """server_tcp(porta, in_rete = falso): apre un server che aspetta collegamenti sulla `porta`.

    Normalmente ascolta solo su questo computer (127.0.0.1). Con `in_rete = vero` anche gli altri
    computer della rete di casa possono collegarsi, ma prima l'utente deve dare il permesso.
    `porta = 0` sceglie una porta libera (la leggi in `server.porta`). Poi `server.aspetta_cliente()`
    restituisce una `connessione`.
    Esempio: `variabile server = server_tcp(5000)` poi `variabile c = server.aspetta_cliente()`.
    """
    porta = _porta(porta, "server_tcp", server=True)
    richiedi_logico(in_rete, "server_tcp", "in_rete")
    if in_rete:
        _chiedi_rete(interprete, "server_tcp", porta, "TCP")
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        if os.name != "nt":
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("0.0.0.0" if in_rete else "127.0.0.1", porta))
        sock.listen(5)
    except OSError:
        sock.close()
        raise ErroreFile(f"Non riesco ad aprire il server sulla porta {porta}: forse è già usata.",
                         suggerimento="Prova un'altra porta, oppure controlla con `porta_libera(porta)`.") from None
    return ServerTcp(sock, in_rete)


def _indirizzo_server(s: ServerTcp) -> str:
    return f"{_ip_di_casa() if s.in_rete else '127.0.0.1'}:{s.porta}"


@proprieta(ServerTcp, "porta")
def _server_porta(s: ServerTcp) -> int:
    return s.porta


@proprieta(ServerTcp, "indirizzo")
def _server_indirizzo(s: ServerTcp) -> str:
    return _indirizzo_server(s)


@proprieta(ServerTcp, "attivo")
def _server_attivo(s: ServerTcp) -> bool:
    return s.attivo


@proprieta(ServerTcp, "clienti_accolti")
def _server_clienti(s: ServerTcp) -> int:
    return s.clienti


@metodo_oggetto(ServerTcp, "aspetta_cliente", interprete=True)
def server_aspetta_cliente(interprete, s, tempo_massimo=None):
    """server.aspetta_cliente(tempo_massimo = nulla): aspetta che un programma si colleghi.

    Restituisce la `connessione` con lui, oppure `nulla` se passano `tempo_massimo` secondi.
    Esempio: `variabile c = server.aspetta_cliente(60)`.
    """
    tempo = _tempo(tempo_massimo, "aspetta_cliente", nulla_ok=True)
    if not s.attivo:
        raise ErroreFile("Il server è chiuso.", suggerimento="Creane uno nuovo con `server_tcp(porta)`.")
    scadenza = None if tempo is None else time.monotonic() + tempo
    if not _aspetta_lettura(interprete, s.sock, scadenza):
        return None
    try:
        sock, remoto = s.sock.accept()
    except OSError:
        return None
    s.clienti += 1
    return Connessione(sock, remoto[0], remoto[1], None)


@metodo_oggetto(ServerTcp, "chiudi")
def server_chiudi(s):
    """server.chiudi(): smette di accettare collegamenti (quelli già aperti restano).

    Esempio: `server.chiudi()`.
    """
    s.attivo = False
    try:
        s.sock.close()
    except OSError:
        pass
    return None


# ===========================================================================
# Messaggi UDP
# ===========================================================================

@funzione_libreria("invia_udp")
def invia_udp(messaggio, indirizzo, porta):
    """invia_udp(messaggio, indirizzo, porta): manda un breve messaggio UDP a un programma.

    `indirizzo = "tutti"` lo manda a tutti i computer della rete di casa (broadcast).
    UDP è veloce ma non garantisce che il messaggio arrivi. Restituisce `vero`.
    Esempio: `invia_udp("Chi c'è?", "tutti", 5005)`.
    """
    richiedi_testo(messaggio, "invia_udp", "messaggio")
    dati = messaggio.encode("utf-8", "replace")
    if len(dati) > MASSIMO_UDP:
        raise ErroreValore("Il messaggio UDP è troppo lungo (al massimo circa 60.000 caratteri).",
                           suggerimento="Per testi lunghi usa `collegati` e `invia`.")
    tutti = isinstance(indirizzo, str) and indirizzo.strip().lower() == "tutti"
    host = "255.255.255.255" if tutti else _host(indirizzo, "invia_udp")
    porta = _porta(porta, "invia_udp")
    famiglia = socket.AF_INET6 if ":" in host else socket.AF_INET
    try:
        if famiglia == socket.AF_INET and not tutti:
            famiglia = socket.getaddrinfo(host, porta, 0, socket.SOCK_DGRAM)[0][0]
        with socket.socket(famiglia, socket.SOCK_DGRAM) as s:
            if tutti:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            s.sendto(dati, (host, porta))
    except (OSError, UnicodeError) as e:
        raise _errore(e, host, porta, 5) from None
    return True


@funzione_libreria("ricevi_udp", interprete=True)
def ricevi_udp(interprete, porta, tempo_massimo=10, in_rete=False):
    """ricevi_udp(porta, tempo_massimo = 10, in_rete = falso): aspetta un messaggio UDP sulla `porta`.

    Restituisce un dizionario con "messaggio", "mittente" (indirizzo) e "porta" del mittente,
    oppure `nulla` se non arriva niente in tempo. Con `in_rete = vero` ascolta anche i messaggi
    degli altri computer di casa (serve il permesso dell'utente).
    Esempio: `variabile m = ricevi_udp(5005, in_rete = vero)` poi `stampa(m["messaggio"])`.
    """
    porta = _porta(porta, "ricevi_udp", server=True)
    tempo = _tempo(tempo_massimo, "ricevi_udp", nulla_ok=True)
    richiedi_logico(in_rete, "ricevi_udp", "in_rete")
    if porta == 0:
        raise ErroreValore("`ricevi_udp` ha bisogno di una porta precisa (tra 1024 e 65535).",
                           suggerimento="Esempio: `ricevi_udp(5005)`.")
    if in_rete:
        _chiedi_rete(interprete, "ricevi_udp", porta, "UDP")
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("0.0.0.0" if in_rete else "127.0.0.1", porta))
        except OSError:
            raise ErroreFile(f"Non riesco ad ascoltare sulla porta {porta}: forse è già usata.",
                             suggerimento="Prova un'altra porta.") from None
        scadenza = None if tempo is None else time.monotonic() + tempo
        if not _aspetta_lettura(interprete, s, scadenza):
            return None
        try:
            dati, mittente = s.recvfrom(65536)
        except OSError:
            return None
    finally:
        s.close()
    return {"messaggio": dati.decode("utf-8", "replace"), "mittente": mittente[0], "porta": mittente[1]}


# ===========================================================================
# Porte
# ===========================================================================

@funzione_libreria("porta_aperta")
def porta_aperta(indirizzo, porta, tempo_massimo=3):
    """porta_aperta(indirizzo, porta, tempo_massimo = 3): `vero` se su quell'indirizzo un programma ascolta alla `porta`.

    Serve a controllare i TUOI servizi (il tuo server, la tua stampante...). Controlla una sola
    porta di un solo indirizzo; fra due controlli verso altri computer passa almeno un secondo.
    Esempio: `se porta_aperta("127.0.0.1", 8080) allora stampa("Il mio server è acceso") fine`.
    """
    host = _host(indirizzo, "porta_aperta")
    porta = _porta(porta, "porta_aperta")
    tempo = _tempo(tempo_massimo, "porta_aperta")
    if tempo > 30:
        raise ErroreValore("`tempo_massimo` di `porta_aperta` è al massimo 30 secondi.")
    if not _e_locale(host):
        attesa = _ULTIMO_CONTROLLO[0] + PAUSA_CONTROLLI - time.monotonic()
        if attesa > 0:
            time.sleep(attesa)
        _ULTIMO_CONTROLLO[0] = time.monotonic()
    try:
        with socket.create_connection((host, porta), timeout=tempo):
            return True
    except (OSError, UnicodeError):
        return False


@funzione_libreria("porta_libera")
def porta_libera(porta):
    """porta_libera(porta): `vero` se su questo computer la `porta` non è usata da nessun programma.

    Utile prima di aprire un server. Esempio: `se porta_libera(5000) allora server = server_tcp(5000) fine`.
    """
    porta = _porta(porta, "porta_libera")
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        if os.name == "nt":
            s.setsockopt(socket.SOL_SOCKET, getattr(socket, "SO_EXCLUSIVEADDRUSE", socket.SO_REUSEADDR), 1)
        s.bind(("127.0.0.1", porta))
        return True
    except OSError:
        return False
    finally:
        s.close()


# ===========================================================================
# Nomi e indirizzi
# ===========================================================================

def _risolvi(nome: Any, funzione: str) -> list[str]:
    host = _host(nome, funzione, "nome")
    try:
        risultati = socket.getaddrinfo(host, None, 0, socket.SOCK_STREAM)
    except (OSError, UnicodeError) as e:
        if isinstance(e, socket.gaierror):
            raise ErroreFile(f"Non trovo il computer o il sito `{host}`.",
                             suggerimento="Controlla di aver scritto bene il nome e di essere collegato alla rete.") from None
        raise _errore(e, host, 0, 5) from None
    visti: list[str] = []
    for famiglia, *_resto, indirizzo in risultati:
        ip = indirizzo[0].split("%", 1)[0]
        if ip not in visti:
            visti.append(ip)
    # prima gli IPv4 (più facili da leggere)
    return sorted(visti, key=lambda ip: ":" in ip)


@funzione_libreria("indirizzo_di")
def indirizzo_di(nome):
    """indirizzo_di(nome): l'indirizzo IP di un sito o di un computer (per esempio "93.184.216.34").

    Esempio: `stampa(indirizzo_di("localhost"))` scrive 127.0.0.1.
    """
    return _risolvi(nome, "indirizzo_di")[0]


@funzione_libreria("indirizzi_di")
def indirizzi_di(nome):
    """indirizzi_di(nome): la lista di tutti gli indirizzi IP (IPv4 e IPv6) di un sito o di un computer.

    Esempio: `per ogni ip in indirizzi_di("www.esempio.it") fai stampa(ip) fine`.
    """
    return _risolvi(nome, "indirizzi_di")


@funzione_libreria("nome_di_indirizzo")
def nome_di_indirizzo(indirizzo):
    """nome_di_indirizzo(indirizzo): il nome del computer che ha quell'indirizzo IP, o `nulla` se non ha un nome.

    Esempio: `stampa(nome_di_indirizzo("127.0.0.1"))` scrive per esempio "localhost".
    """
    richiedi_testo(indirizzo, "nome_di_indirizzo", "indirizzo")
    ip = _ip(indirizzo, "nome_di_indirizzo")
    try:
        return socket.gethostbyaddr(str(ip))[0]
    except (OSError, UnicodeError):
        return None


def _ip(valore: Any, funzione: str, parametro: str = "indirizzo") -> ipaddress.IPv4Address | ipaddress.IPv6Address:
    richiedi_testo(valore, funzione, parametro)
    try:
        return ipaddress.ip_address(valore.strip().strip("[]"))
    except ValueError:
        raise ErroreValore(f"{mostra(valore)} non è un indirizzo IP.",
                           suggerimento="Un indirizzo IPv4 è fatto di 4 numeri da 0 a 255 separati da punti, "
                                        "per esempio \"192.168.1.10\".") from None


def _rete(valore: Any, funzione: str) -> ipaddress.IPv4Network | ipaddress.IPv6Network:
    richiedi_testo(valore, funzione, "rete")
    try:
        return ipaddress.ip_network(valore.strip(), strict=False)
    except ValueError:
        raise ErroreValore(f"{mostra(valore)} non è una rete valida.",
                           suggerimento="Scrivi l'indirizzo e la lunghezza del prefisso, per esempio "
                                        "\"192.168.1.0/24\".") from None


@funzione_libreria("e_indirizzo_ip")
def e_indirizzo_ip(testo):
    """e_indirizzo_ip(testo): `vero` se il testo è un indirizzo IP scritto bene (IPv4 o IPv6).

    Esempio: `e_indirizzo_ip("192.168.1.300")` è `falso` (300 è troppo grande).
    """
    if not isinstance(testo, str):
        return False
    try:
        ipaddress.ip_address(testo.strip())
        return True
    except ValueError:
        return False


@funzione_libreria("info_indirizzo_ip")
def info_indirizzo_ip(indirizzo):
    """info_indirizzo_ip(indirizzo): che tipo di indirizzo è: versione, privato o pubblico, questo computer...

    Restituisce un dizionario con "indirizzo", "versione" (4 o 6), "privato" (rete di casa o
    ufficio), "pubblico" (Internet), "questo_computer" (loopback), "multicast", "riservato", "tipo"
    (spiegazione in parole).
    Esempio: `stampa(info_indirizzo_ip("192.168.1.10")["tipo"])`.
    """
    ip = _ip(indirizzo, "info_indirizzo_ip")
    if ip.is_loopback:
        tipo = "questo computer (loopback)"
    elif ip.is_link_local:
        tipo = "collegamento locale (assegnato da solo, senza router)"
    elif ip.is_multicast:
        tipo = "multicast (un messaggio per un gruppo di computer)"
    elif ip.is_unspecified:
        tipo = "indirizzo non specificato (tutti gli indirizzi di questo computer)"
    elif ip.is_private:
        tipo = "privato (rete di casa o dell'ufficio)"
    elif ip.is_global:
        tipo = "pubblico (Internet)"
    else:
        tipo = "riservato (usi speciali)"
    return {
        "indirizzo": str(ip),
        "versione": ip.version,
        "privato": bool(ip.is_private and not ip.is_loopback and not ip.is_link_local),
        "pubblico": bool(ip.is_global),
        "questo_computer": bool(ip.is_loopback),
        "multicast": bool(ip.is_multicast),
        "riservato": bool(ip.is_reserved or ip.is_unspecified),
        "tipo": tipo,
    }


@funzione_libreria("indirizzo_in_rete")
def indirizzo_in_rete(indirizzo, rete):
    """indirizzo_in_rete(indirizzo, rete): `vero` se l'indirizzo IP fa parte della rete.

    Esempio: `indirizzo_in_rete("192.168.1.42", "192.168.1.0/24")` è `vero`.
    """
    ip = _ip(indirizzo, "indirizzo_in_rete")
    r = _rete(rete, "indirizzo_in_rete")
    return ip.version == r.version and ip in r


@funzione_libreria("info_rete")
def info_rete(rete):
    """info_rete(rete): le informazioni su una rete scritta come "192.168.1.0/24".

    Restituisce un dizionario con "rete", "maschera", "prefisso", "broadcast", "primo" e "ultimo"
    indirizzo utilizzabile, "quanti" (numero di indirizzi per i computer), "privata".
    Esempio: `stampa(info_rete("192.168.1.0/24")["quanti"])` scrive 254.
    """
    r = _rete(rete, "info_rete")
    totale = r.num_addresses
    if r.version == 4 and r.prefixlen <= 30:
        primo, ultimo, quanti = r.network_address + 1, r.broadcast_address - 1, totale - 2
    else:
        primo, ultimo, quanti = r.network_address, r.broadcast_address, totale
    return {
        "rete": str(r),
        "indirizzo_rete": str(r.network_address),
        "maschera": str(r.netmask),
        "prefisso": r.prefixlen,
        "broadcast": str(r.broadcast_address) if r.version == 4 else None,
        "primo": str(primo),
        "ultimo": str(ultimo),
        "quanti": quanti,
        "versione": r.version,
        "privata": bool(r.is_private),
    }


# ===========================================================================
# Certificati dei siti
# ===========================================================================

def _contesto_verificato() -> ssl.SSLContext:
    return ssl.create_default_context()


_PROBLEMI_CERTIFICATO = (
    ("expired", "il certificato è scaduto"),
    ("self-signed", "il certificato è autofirmato (non viene da un'autorità riconosciuta)"),
    ("self signed", "il certificato è autofirmato (non viene da un'autorità riconosciuta)"),
    ("hostname mismatch", "il certificato è di un altro sito"),
    ("ip address mismatch", "il certificato è di un altro indirizzo"),
    ("not yet valid", "il certificato non è ancora valido"),
    ("unable to get local issuer", "l'emittente del certificato non è riconosciuto"),
    ("revoked", "il certificato è stato revocato"),
)


def _spiega_problema(e: ssl.SSLCertVerificationError) -> str:
    testo = f"{getattr(e, 'verify_message', '')} {e}".lower()
    for chiave, spiegazione in _PROBLEMI_CERTIFICATO:
        if chiave in testo:
            return spiegazione
    return "il certificato non è valido"


def _decodifica_der(der: bytes) -> dict:
    decodifica = getattr(getattr(ssl, "_ssl", None), "_test_decode_cert", None)
    if decodifica is None or not der:
        return {}
    fd, percorso = tempfile.mkstemp(suffix=".pem")
    try:
        with os.fdopen(fd, "w", encoding="ascii") as f:
            f.write(ssl.DER_cert_to_PEM_cert(der))
        return decodifica(percorso)
    except (OSError, ValueError, ssl.SSLError):
        return {}
    finally:
        try:
            os.unlink(percorso)
        except OSError:
            pass


def _campo(nome_distinto: Any, *chiavi: str) -> str | None:
    valori: dict[str, str] = {}
    for gruppo in nome_distinto or ():
        for chiave, valore in gruppo:
            valori.setdefault(chiave, valore)
    for c in chiavi:
        if c in valori:
            return valori[c]
    return None


def _data_certificato(testo: Any) -> DataDante | None:
    if not isinstance(testo, str):
        return None
    try:
        secondi = ssl.cert_time_to_seconds(testo)
    except ValueError:
        return None
    return _data(datetime.datetime.fromtimestamp(secondi, datetime.timezone.utc))


def _certificato(sito: Any, porta: Any, tempo_massimo: Any, nome: str) -> dict:
    host = _host(sito, nome, "sito")
    porta = _porta(porta, nome)
    tempo = _tempo(tempo_massimo, nome)
    nome_sni = None if e_indirizzo_ip(host) else host
    problema = None
    versione = None
    try:
        with socket.create_connection((host, porta), timeout=tempo) as grezzo:
            with _contesto_verificato().wrap_socket(grezzo, server_hostname=nome_sni or host) as s:
                cert = s.getpeercert() or {}
                versione = s.version()
    except ssl.SSLCertVerificationError as e:
        problema = _spiega_problema(e)
        contesto = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        contesto.check_hostname = False
        contesto.verify_mode = ssl.CERT_NONE
        try:
            with socket.create_connection((host, porta), timeout=tempo) as grezzo:
                with contesto.wrap_socket(grezzo, server_hostname=nome_sni) as s:
                    cert = _decodifica_der(s.getpeercert(binary_form=True) or b"")
                    versione = s.version()
        except (OSError, ssl.SSLError) as e2:
            raise _errore(e2, host, porta, tempo) from None
    except ssl.SSLError:
        raise ErroreFile(f"`{host}` alla porta {porta} non parla in modo sicuro (TLS).",
                         suggerimento="Controlla la porta: per i siti è 443.") from None
    except (OSError, UnicodeError) as e:
        raise _errore(e, host, porta, tempo) from None
    scadenza = _data_certificato(cert.get("notAfter"))
    giorni = None
    if scadenza is not None:
        giorni = (scadenza.valore - datetime.datetime.now()).days
    return {
        "sito": host,
        "valido": problema is None,
        "problema": problema,
        "soggetto": _campo(cert.get("subject"), "commonName", "organizationName"),
        "emittente": _campo(cert.get("issuer"), "organizationName", "commonName"),
        "valido_dal": _data_certificato(cert.get("notBefore")),
        "scadenza": scadenza,
        "giorni_rimasti": giorni,
        "nomi": [v for t, v in cert.get("subjectAltName", ()) if t in ("DNS", "IP Address")],
        "versione_tls": versione,
    }


@funzione_libreria("certificato_sito")
def certificato_sito(sito, porta=443, tempo_massimo=10):
    """certificato_sito(sito, porta = 443, tempo_massimo = 10): le informazioni sul certificato di sicurezza di un sito.

    Restituisce un dizionario con "valido" (`vero`/`falso`), "problema" (in parole, o `nulla`),
    "soggetto", "emittente", "valido_dal", "scadenza" (date), "giorni_rimasti", "nomi" (i siti
    coperti), "versione_tls". Utile per controllare che i propri siti non abbiano il certificato scaduto.
    Esempio: `variabile c = certificato_sito("www.esempio.it")` poi `stampa(c["scadenza"])`.
    """
    return _certificato(sito, porta, tempo_massimo, "certificato_sito")


@funzione_libreria("giorni_scadenza_certificato")
def giorni_scadenza_certificato(sito, porta=443):
    """giorni_scadenza_certificato(sito, porta = 443): quanti giorni mancano alla scadenza del certificato del sito.

    Un numero negativo vuol dire che è già scaduto.
    Esempio: `se giorni_scadenza_certificato("www.miosito.it") < 15 allora stampa("Rinnova il certificato!") fine`.
    """
    giorni = _certificato(sito, porta, 10, "giorni_scadenza_certificato")["giorni_rimasti"]
    if giorni is None:
        raise ErroreFile("Non riesco a leggere la scadenza del certificato.")
    return giorni


# ===========================================================================
# Posta: IMAP
# ===========================================================================

def _utf7_decodifica(testo: str) -> str:
    """Nomi delle cartelle IMAP ("UTF-7 modificato": "Posta &AOg-" -> "Posta è")."""
    def parte(m: re.Match) -> str:
        pezzo = m.group(1)
        if not pezzo:
            return "&"
        b64 = pezzo.replace(",", "/")
        b64 += "=" * (-len(b64) % 4)
        try:
            return binascii.a2b_base64(b64).decode("utf-16-be")
        except (binascii.Error, UnicodeDecodeError):
            return m.group(0)
    return re.sub(r"&([A-Za-z0-9+,]*)-", parte, testo)


def _utf7_codifica(testo: str) -> str:
    risultato, fuori = [], []

    def svuota() -> None:
        if fuori:
            b64 = binascii.b2a_base64("".join(fuori).encode("utf-16-be"), newline=False).decode("ascii")
            risultato.append("&" + b64.rstrip("=").replace("/", ",") + "-")
            fuori.clear()

    for c in testo:
        if 0x20 <= ord(c) <= 0x7E:
            svuota()
            risultato.append("&-" if c == "&" else c)
        else:
            fuori.append(c)
    svuota()
    return "".join(risultato)


def _virgolette(testo: str) -> str:
    return '"' + testo.replace("\\", "\\\\").replace('"', '\\"') + '"'


class CasellaPosta(OggettoLibreria):
    """Una casella di posta aperta con IMAP (solo lettura: i messaggi restano come sono)."""

    NOME_TIPO_DANTE = "casella_posta"

    def __init__(self, conn: Any, server: str, utente: str, segreti: list[str]) -> None:
        self.conn = conn
        self.server = server
        self.utente = utente
        self.segreti = segreti
        self.aperta = True
        self.selezionata: str | None = None

    def testo_dante(self) -> str:
        return f"<casella_posta {self.utente} su {self.server}{'' if self.aperta else ' chiusa'}>"

    def comando(self, azione: str, *argomenti: Any) -> list:
        if not self.aperta:
            raise ErroreFile("La casella di posta è chiusa.",
                             suggerimento="Aprila di nuovo con `apri_posta(...)`.")
        try:
            if azione == "uid":
                stato, dati = self.conn.uid(*argomenti)
            else:
                stato, dati = getattr(self.conn, azione)(*argomenti)
        except imaplib.IMAP4.abort:
            self.aperta = False
            raise ErroreFile(f"Il server di posta `{self.server}` ha chiuso il collegamento.",
                             suggerimento="Apri di nuovo la casella con `apri_posta(...)`.") from None
        except imaplib.IMAP4.error as e:
            raise ErroreFile("Il server di posta ha rifiutato la richiesta.",
                             suggerimento=_senza_segreti(f"Dettaglio tecnico: {e}", self.segreti)) from None
        except (OSError, ssl.SSLError) as e:
            self.aperta = False
            raise _errore(e, self.server, 993, 30) from None
        if stato != "OK":
            dettaglio = b" ".join(d for d in dati if isinstance(d, bytes)).decode("utf-8", "replace")
            raise ErroreFile("Il server di posta ha risposto con un errore.",
                             suggerimento=_senza_segreti(f"Dettaglio tecnico: {dettaglio}", self.segreti))
        return dati

    def seleziona(self, cartella: Any, nome: str) -> None:
        richiedi_testo(cartella, nome, "cartella")
        if not cartella.strip() or "\n" in cartella or "\r" in cartella or "\0" in cartella:
            raise ErroreValore(f"Il nome della cartella di posta {mostra(cartella)} non è valido.",
                               suggerimento="Di solito la posta in arrivo è \"INBOX\"; l'elenco con `cartelle()`.")
        if self.selezionata == cartella:
            return
        try:
            self.comando("select", _virgolette(_utf7_codifica(cartella)), True)  # sola lettura
        except ErroreFile:
            raise ErroreFile(f"La cartella di posta `{cartella}` non esiste.",
                             suggerimento="L'elenco delle cartelle lo dà `posta.cartelle()`.") from None
        self.selezionata = cartella


@funzione_libreria("apri_posta")
def apri_posta(server, utente, password, porta=993, tls=True, tempo_massimo=30):
    """apri_posta(server, utente, password, porta = 993, tls = vero, tempo_massimo = 30): apre una casella di posta (IMAP).

    Restituisce una `casella_posta` con `cartelle()`, `elenco_messaggi()`, `leggi_messaggio(numero)`,
    `cerca_messaggi(...)`, `salva_allegati(numero)`, `chiudi()`. Legge soltanto: non cancella e non
    segna i messaggi come letti. La password non viaggia mai senza cifratura e non compare nei messaggi.
    Esempio: `variabile posta = apri_posta("imap.esempio.it", "ada@esempio.it", leggi_file("password.txt"))`.
    """
    richiedi_testo(server, "apri_posta", "server")
    richiedi_testo(utente, "apri_posta", "utente")
    richiedi_testo(password, "apri_posta", "password")
    host = _host(server, "apri_posta", "server")
    porta = _porta(porta, "apri_posta")
    richiedi_logico(tls, "apri_posta", "tls")
    tempo = _tempo(tempo_massimo, "apri_posta")
    if not utente.strip() or "\n" in utente or "\r" in utente:
        raise ErroreValore("Il nome `utente` di `apri_posta` non è valido.",
                           suggerimento="Di solito è il tuo indirizzo email.")
    if not tls and not _e_locale(host):
        raise ErroreValore("Non invio la password senza cifratura: chiunque sulla rete potrebbe leggerla.",
                           suggerimento="Lascia `tls = vero` (è il valore predefinito).")
    segreti = [password] if password else []
    try:
        if tls and porta != 143:
            conn = imaplib.IMAP4_SSL(host, porta, ssl_context=ssl.create_default_context(), timeout=tempo)
        else:
            conn = imaplib.IMAP4(host, porta, timeout=tempo)
            if tls:
                conn.starttls(ssl.create_default_context())
        conn.login(utente, password)
    except imaplib.IMAP4.error as e:
        testo = str(e).lower()
        if "auth" in testo or "login" in testo or "credential" in testo or "password" in testo:
            raise ErroreFile(f"Accesso non riuscito a `{host}`: nome utente o password sbagliati.",
                             suggerimento="Molti servizi (Gmail, Outlook) vogliono una \"password per le app\" "
                                          "invece della password normale.") from None
        raise ErroreFile(f"Il server di posta `{host}` ha rifiutato il collegamento.",
                         suggerimento=_senza_segreti(f"Dettaglio tecnico: {e}", segreti)) from None
    except (OSError, ssl.SSLError, UnicodeError) as e:
        raise _errore(e, host, porta, tempo) from None
    return CasellaPosta(conn, host, utente, segreti)


@proprieta(CasellaPosta, "aperta")
def _posta_aperta(p: CasellaPosta) -> bool:
    return p.aperta


def _quanti(valore: Any, nome: str, massimo: int = 500) -> int:
    if isinstance(valore, bool) or not isinstance(valore, int):
        raise ErroreTipo(f"`quanti` di `{nome}` deve essere un numero intero, non {articolo(valore)}.")
    if not 1 <= valore <= massimo:
        raise ErroreValore(f"`quanti` di `{nome}` deve essere tra 1 e {massimo}.")
    return valore


def _numero_messaggio(valore: Any, nome: str) -> int:
    if isinstance(valore, bool) or not isinstance(valore, int) or valore < 1:
        raise ErroreTipo(f"Il `numero` del messaggio di `{nome}` deve essere un intero positivo, "
                         f"non {articolo(valore) if not isinstance(valore, int) else valore}.",
                         suggerimento="I numeri si leggono in `elenco_messaggi()`, alla chiave \"numero\".")
    return valore


_PARSER = email.policy.default


def _intestazione(messaggio: Any, nome: str) -> str:
    try:
        valore = messaggio.get(nome)
        return str(valore) if valore is not None else ""
    except (ValueError, TypeError, IndexError, LookupError):
        return ""


def _data_messaggio(testo: str) -> DataDante | str | None:
    if not testo:
        return None
    try:
        return _data(parsedate_to_datetime(testo))
    except (TypeError, ValueError, IndexError, OverflowError):
        return testo


def _sommari(p: CasellaPosta, uid: list[bytes]) -> list[dict]:
    if not uid:
        return []
    dati = p.comando("uid", "FETCH", b",".join(uid).decode("ascii"),
                     "(UID FLAGS RFC822.SIZE BODY.PEEK[HEADER.FIELDS (FROM TO SUBJECT DATE)])")
    risultato = []
    for parte in dati:
        if not isinstance(parte, tuple) or len(parte) < 2:
            continue
        testa = parte[0].decode("utf-8", "replace") if isinstance(parte[0], bytes) else str(parte[0])
        m_uid = re.search(r"UID (\d+)", testa)
        if not m_uid:
            continue
        m_flag = re.search(r"FLAGS \(([^)]*)\)", testa)
        m_dim = re.search(r"RFC822\.SIZE (\d+)", testa)
        msg = email.message_from_bytes(parte[1] if isinstance(parte[1], bytes) else b"", policy=_PARSER)
        risultato.append({
            "numero": int(m_uid.group(1)),
            "mittente": _intestazione(msg, "From"),
            "destinatari": _intestazione(msg, "To"),
            "oggetto": _intestazione(msg, "Subject"),
            "data": _data_messaggio(_intestazione(msg, "Date")),
            "letto": bool(m_flag and "\\seen" in m_flag.group(1).lower()),
            "dimensione": int(m_dim.group(1)) if m_dim else None,
        })
    risultato.sort(key=lambda d: d["numero"], reverse=True)
    return risultato


def _cerca(p: CasellaPosta, criteri: list[str], letterale: bytes | None) -> list[bytes]:
    if letterale is not None:
        p.conn.literal = letterale
        dati = p.comando("uid", "SEARCH", "CHARSET", "UTF-8", *criteri)
    else:
        dati = p.comando("uid", "SEARCH", *criteri)
    testo = b" ".join(d for d in dati if isinstance(d, bytes))
    return [n for n in testo.split() if n.isdigit()]


@metodo_oggetto(CasellaPosta, "cartelle")
def posta_cartelle(p):
    """posta.cartelle(): la lista delle cartelle della casella ("INBOX", "Inviata", "Spam"...).

    Esempio: `stampa(posta.cartelle())`.
    """
    cartelle = []
    for riga in p.comando("list"):
        if not isinstance(riga, bytes):
            continue
        testo = riga.decode("utf-8", "replace")
        m = re.match(r'\((?P<flag>[^)]*)\)\s+(?:"[^"]*"|NIL)\s+(?P<nome>.+)$', testo)
        if not m or "\\noselect" in m.group("flag").lower():
            continue
        nome = m.group("nome").strip()
        if nome.startswith('"') and nome.endswith('"'):
            nome = nome[1:-1].replace('\\"', '"').replace("\\\\", "\\")
        cartelle.append(_utf7_decodifica(nome))
    return cartelle


@metodo_oggetto(CasellaPosta, "elenco_messaggi")
def posta_elenco(p, cartella="INBOX", quanti=10):
    """posta.elenco_messaggi(cartella = "INBOX", quanti = 10): gli ultimi messaggi, dal più nuovo.

    Ogni messaggio è un dizionario con "numero", "mittente", "destinatari", "oggetto", "data",
    "letto", "dimensione". Il "numero" serve a `leggi_messaggio`.
    Esempio: `per ogni m in posta.elenco_messaggi() fai stampa(m["mittente"], "-", m["oggetto"]) fine`.
    """
    quanti = _quanti(quanti, "elenco_messaggi")
    p.seleziona(cartella, "elenco_messaggi")
    uid = _cerca(p, ["ALL"], None)
    return _sommari(p, uid[-quanti:])


@metodo_oggetto(CasellaPosta, "cerca_messaggi")
def posta_cerca(p, testo=None, mittente=None, oggetto=None, non_letti=False, cartella="INBOX", quanti=50):
    """posta.cerca_messaggi(testo = nulla, mittente = nulla, oggetto = nulla, non_letti = falso, cartella = "INBOX", quanti = 50): cerca i messaggi.

    Tutte le condizioni date devono valere insieme. Restituisce la stessa lista di `elenco_messaggi`.
    Esempio: `variabile trovati = posta.cerca_messaggi(mittente = "scuola", non_letti = vero)`.
    """
    quanti = _quanti(quanti, "cerca_messaggi")
    richiedi_logico(non_letti, "cerca_messaggi", "non_letti")
    criteri: list[str] = []
    letterale = chiave_letterale = None
    for chiave, valore, parametro in (("TEXT", testo, "testo"), ("FROM", mittente, "mittente"),
                                      ("SUBJECT", oggetto, "oggetto")):
        if valore is None:
            continue
        richiedi_testo(valore, "cerca_messaggi", parametro)
        if not valore.strip() or any(c in valore for c in "\r\n\0"):
            raise ErroreValore(f"`{parametro}` di `cerca_messaggi` deve essere un testo su una riga, non vuoto.")
        if valore.isascii():
            criteri += [chiave, _virgolette(valore)]
        elif letterale is None:
            letterale, chiave_letterale = valore.encode("utf-8"), chiave
        else:
            raise ErroreValore("`cerca_messaggi` può cercare una sola parola con lettere accentate alla volta.",
                               suggerimento="Togli gli accenti da una delle parole, o fai due ricerche.")
    if chiave_letterale is not None:
        criteri.append(chiave_letterale)  # il valore arriva come "letterale", in fondo al comando
    if non_letti:
        criteri.insert(0, "UNSEEN")
    if not criteri:
        criteri = ["ALL"]
    p.seleziona(cartella, "cerca_messaggi")
    uid = _cerca(p, criteri, letterale)
    return _sommari(p, uid[-quanti:])


def _scarica_messaggio(p: CasellaPosta, numero: int) -> Any:
    dati = p.comando("uid", "FETCH", str(numero), "(BODY.PEEK[])")
    for parte in dati:
        if isinstance(parte, tuple) and len(parte) >= 2 and isinstance(parte[1], bytes):
            return email.message_from_bytes(parte[1], policy=_PARSER)
    raise ErroreValore(f"Il messaggio numero {numero} non c'è.",
                       suggerimento="I numeri si leggono in `elenco_messaggi()`, alla chiave \"numero\".")


def _nome_allegato(parte: Any) -> str | None:
    try:
        return parte.get_filename()
    except (ValueError, TypeError, IndexError, LookupError):
        return None


@metodo_oggetto(CasellaPosta, "leggi_messaggio")
def posta_leggi(p, numero, cartella="INBOX"):
    """posta.leggi_messaggio(numero, cartella = "INBOX"): tutto il messaggio in un dizionario.

    Chiavi: "numero", "mittente", "destinatari", "copia", "oggetto", "data", "testo", "html"
    (o `nulla`), "allegati" (lista di nomi). Il messaggio non viene segnato come letto.
    Esempio: `variabile m = posta.leggi_messaggio(42)` poi `stampa(m["testo"])`.
    """
    numero = _numero_messaggio(numero, "leggi_messaggio")
    p.seleziona(cartella, "leggi_messaggio")
    msg = _scarica_messaggio(p, numero)
    testo = html = None
    try:
        corpo = msg.get_body(preferencelist=("plain",))
        testo = corpo.get_content() if corpo is not None else None
        corpo = msg.get_body(preferencelist=("html",))
        html = corpo.get_content() if corpo is not None else None
    except (LookupError, ValueError, TypeError, KeyError, AttributeError):
        pass
    allegati = [n for n in (_nome_allegato(x) for x in msg.walk()) if n]
    return {
        "numero": numero,
        "mittente": _intestazione(msg, "From"),
        "destinatari": _intestazione(msg, "To"),
        "copia": _intestazione(msg, "Cc"),
        "oggetto": _intestazione(msg, "Subject"),
        "data": _data_messaggio(_intestazione(msg, "Date")),
        "testo": testo if testo is not None else "",
        "html": html,
        "allegati": allegati,
    }


def _nome_file_sicuro(nome: str) -> str:
    nome = os.path.basename(nome.replace("\\", "/"))
    nome = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", nome).strip(" .")
    return nome[:150] or "allegato"


def _percorso_nuovo(cartella: str, nome: str) -> str:
    base, estensione = os.path.splitext(nome)
    percorso, n = os.path.join(cartella, nome), 1
    while os.path.exists(percorso):
        n += 1
        percorso = os.path.join(cartella, f"{base} ({n}){estensione}")
    return percorso


@metodo_oggetto(CasellaPosta, "salva_allegati")
def posta_salva_allegati(p, numero, cartella_destinazione=".", cartella="INBOX"):
    """posta.salva_allegati(numero, cartella_destinazione = ".", cartella = "INBOX"): salva gli allegati del messaggio.

    I file già presenti non vengono sovrascritti ("foto (2).jpg"). Restituisce la lista dei percorsi salvati.
    Esempio: `stampa(posta.salva_allegati(42, "allegati"))`.
    """
    numero = _numero_messaggio(numero, "salva_allegati")
    richiedi_testo(cartella_destinazione, "salva_allegati", "cartella_destinazione")
    if not cartella_destinazione.strip() or "\0" in cartella_destinazione:
        raise ErroreValore("La `cartella_destinazione` di `salva_allegati` non è valida.")
    p.seleziona(cartella, "salva_allegati")
    msg = _scarica_messaggio(p, numero)
    salvati = []
    for parte in msg.walk():
        nome = _nome_allegato(parte)
        if not nome:
            continue
        contenuto = parte.get_payload(decode=True) or b""
        try:
            os.makedirs(cartella_destinazione, exist_ok=True)
            percorso = _percorso_nuovo(cartella_destinazione, _nome_file_sicuro(nome))
            with open(percorso, "xb") as f:
                f.write(contenuto)
        except OSError as e:
            raise ErroreFile(f"Non riesco a salvare l'allegato `{nome}`: {e.strerror or e}.") from None
        salvati.append(percorso)
    return salvati


@metodo_oggetto(CasellaPosta, "chiudi")
def posta_chiudi(p):
    """posta.chiudi(): chiude la casella di posta.

    Esempio: `posta.chiudi()`.
    """
    if p.aperta:
        p.aperta = False
        try:
            p.conn.logout()
        except (imaplib.IMAP4.error, OSError):
            pass
    return None


# ===========================================================================
# Posta: invio con allegati
# ===========================================================================

def _allegati(valore: Any) -> list[str]:
    elenco = valore if isinstance(valore, list) else [valore]
    if not elenco:
        raise ErroreValore("La lista `allegati` di `invia_email_con_allegati` è vuota.",
                           suggerimento="Per un'email senza allegati usa `invia_email`.")
    percorsi, totale = [], 0
    for p in elenco:
        richiedi_testo(p, "invia_email_con_allegati", "allegati")
        if not p.strip() or "\0" in p:
            raise ErroreValore(f"{mostra(p)} non è il percorso di un file.")
        if not os.path.isfile(p):
            raise ErroreFile(f"L'allegato `{p}` non esiste (o è una cartella).",
                             suggerimento=f"Controlla il nome: ora sei in `{os.getcwd()}`.")
        totale += os.path.getsize(p)
        percorsi.append(p)
    if totale > MASSIMO_ALLEGATI:
        raise ErroreValore(f"Gli allegati sono troppo grandi ({_misura(totale)}): al massimo 25 MB.",
                           suggerimento="Comprimi i file (`comprimi_zip`) o condividili con un link.")
    return percorsi


@funzione_libreria("invia_email_con_allegati")
def invia_email_con_allegati(destinatario, oggetto, testo, allegati, mittente, server, porta=587, utente=None,
                             password=None, tls=True, tempo_massimo=60):
    """invia_email_con_allegati(destinatario, oggetto, testo, allegati, mittente, server, porta = 587, utente = nulla, password = nulla, tls = vero, tempo_massimo = 60): invia un'email con dei file.

    `allegati` è il percorso di un file o una lista di percorsi (al massimo 25 MB in tutto).
    Il resto funziona come `invia_email`: connessione cifrata, password mai mostrata. Restituisce `vero`.
    Esempio: `invia_email_con_allegati("ada@esempio.it", "Foto", "Eccole!", ["mare.jpg", "monti.jpg"],
    "leo@esempio.it", "smtp.esempio.it", utente = "leo@esempio.it", password = leggi_file("password.txt"))`.
    """
    nome = "invia_email_con_allegati"
    a = _indirizzi_email(destinatario, "destinatario")
    da = _indirizzi_email(mittente, "mittente")
    if len(da) != 1:
        raise ErroreValore(f"Il `mittente` di `{nome}` è uno solo.")
    richiedi_testo(oggetto, nome, "oggetto")
    richiedi_testo(testo, nome, "testo")
    if "\n" in oggetto or "\r" in oggetto:
        raise ErroreValore("L'`oggetto` dell'email deve stare su una riga sola.")
    percorsi = _allegati(allegati)
    host = _host(server, nome, "server")
    porta = _porta(porta, nome)
    richiedi_logico(tls, nome, "tls")
    tempo = _tempo(tempo_massimo, nome)
    if password is not None:
        richiedi_testo(password, nome, "password")
        if utente is None:
            utente = da[0]
    if utente is not None:
        richiedi_testo(utente, nome, "utente")
    if password and not tls and not _e_locale(host):
        raise ErroreValore("Non invio la password senza cifratura: chiunque sulla rete potrebbe leggerla.",
                           suggerimento="Lascia `tls = vero` (è il valore predefinito).")
    messaggio = EmailMessage()
    messaggio["From"] = da[0]
    messaggio["To"] = ", ".join(a)
    messaggio["Subject"] = oggetto
    messaggio["Date"] = formatdate(localtime=True)
    messaggio["Message-ID"] = make_msgid(domain=(da[0].rsplit("@", 1)[-1].strip(">") or "leo.local"))
    messaggio.set_content(testo)
    for percorso in percorsi:
        tipo, codifica = mimetypes.guess_type(percorso)
        if tipo is None or codifica is not None:
            tipo = "application/octet-stream"
        principale, secondario = tipo.split("/", 1)
        try:
            with open(percorso, "rb") as f:
                contenuto = f.read()
        except OSError as e:
            raise ErroreFile(f"Non riesco a leggere l'allegato `{percorso}`: {e.strerror or e}.") from None
        messaggio.add_attachment(contenuto, maintype=principale, subtype=secondario,
                                 filename=os.path.basename(percorso))
    segreti = [password] if password else []
    contesto = ssl.create_default_context()
    try:
        if tls and porta == 465:
            connessione = smtplib.SMTP_SSL(host, porta, timeout=tempo, context=contesto)
        else:
            connessione = smtplib.SMTP(host, porta, timeout=tempo)
        with connessione:
            connessione.ehlo()
            if tls and porta != 465:
                if not connessione.has_extn("starttls"):
                    raise ErroreFile(f"Il server `{host}` non permette una connessione cifrata (STARTTLS).",
                                     suggerimento="Controlla server e porta (di solito 587), oppure prova la 465.")
                connessione.starttls(context=contesto)
                connessione.ehlo()
            if password is not None:
                connessione.login(utente, password)
            rifiutati = connessione.send_message(messaggio, from_addr=da[0], to_addrs=a)
    except ErroreDante:
        raise
    except smtplib.SMTPAuthenticationError:
        raise ErroreFile(f"Accesso non riuscito a `{host}`: nome utente o password sbagliati.",
                         suggerimento="Molti servizi (Gmail, Outlook) vogliono una \"password per le app\".") from None
    except smtplib.SMTPRecipientsRefused as e:
        raise ErroreFile("Il server ha rifiutato il destinatario: " + ", ".join(f"`{k}`" for k in e.recipients) + ".",
                         suggerimento="Controlla l'indirizzo del destinatario.") from None
    except smtplib.SMTPException as e:
        raise ErroreFile("Il server di posta ha rifiutato il messaggio.",
                         suggerimento=_senza_segreti(f"Dettaglio tecnico: {e}", segreti)) from None
    except (OSError, ssl.SSLError) as e:
        errore = _errore(e, host, porta, tempo)
        errore.messaggio = _senza_segreti(errore.messaggio, segreti)
        raise errore from None
    if rifiutati:
        raise ErroreFile("Alcuni destinatari sono stati rifiutati: " + ", ".join(f"`{k}`" for k in rifiutati) + ".")
    return True


# ===========================================================================
# FTP
# ===========================================================================

class ConnessioneFtp(OggettoLibreria):
    """Un collegamento con un server FTP."""

    NOME_TIPO_DANTE = "connessione_ftp"

    def __init__(self, ftp: Any, server: str, segreti: list[str]) -> None:
        self.ftp = ftp
        self.server = server
        self.segreti = segreti
        self.aperta = True

    def testo_dante(self) -> str:
        return f"<connessione_ftp {self.server}{'' if self.aperta else ' chiusa'}>"

    def esegui(self, azione: str, *argomenti: Any) -> Any:
        if not self.aperta:
            raise ErroreFile("La connessione FTP è chiusa.", suggerimento="Aprila di nuovo con `apri_ftp(...)`.")
        try:
            return getattr(self.ftp, azione)(*argomenti)
        except ftplib.error_perm as e:
            testo = _senza_segreti(str(e), self.segreti)
            if testo.startswith("550"):
                raise ErroreFile("Il file o la cartella sul server non esiste (o non hai il permesso).",
                                 suggerimento=f"Risposta del server: {testo}") from None
            raise ErroreFile("Il server FTP ha rifiutato l'operazione.",
                             suggerimento=f"Risposta del server: {testo}") from None
        except (ftplib.Error, EOFError) as e:
            raise ErroreFile("Il server FTP ha risposto in modo inatteso.",
                             suggerimento=_senza_segreti(f"Dettaglio tecnico: {e}", self.segreti)) from None
        except (OSError, ssl.SSLError) as e:
            self.aperta = False
            raise _errore(e, self.server, 21, 30) from None


def _nome_remoto(valore: Any, nome: str, parametro: str) -> str:
    richiedi_testo(valore, nome, parametro)
    if not valore.strip() or any(c in valore for c in "\r\n\0"):
        raise ErroreValore(f"`{parametro}` di `{nome}` non è un nome di file valido.")
    return valore


@funzione_libreria("apri_ftp")
def apri_ftp(server, utente="anonymous", password="", porta=21, tls=None, tempo_massimo=30):
    """apri_ftp(server, utente = "anonymous", password = "", porta = 21, tls = nulla, tempo_massimo = 30): si collega a un server FTP.

    Restituisce una `connessione_ftp` con `elenca()`, `scarica(nome)`, `carica(percorso)`, `chiudi()`.
    Con una password la connessione è cifrata (FTPS); senza cifratura la password si manda solo a
    questo computer.
    Esempio: `variabile ftp = apri_ftp("ftp.esempio.it")` poi `stampa(ftp.elenca())`.
    """
    host = _host(server, "apri_ftp", "server")
    richiedi_testo(utente, "apri_ftp", "utente")
    richiedi_testo(password, "apri_ftp", "password")
    porta = _porta(porta, "apri_ftp")
    tempo = _tempo(tempo_massimo, "apri_ftp")
    if any(c in utente + password for c in "\r\n\0"):
        raise ErroreValore("`utente` e `password` di `apri_ftp` devono stare su una riga.")
    anonimo = utente.strip().lower() in ("", "anonymous", "ftp")
    if tls is None:
        tls = bool(password) and not anonimo and not _e_locale(host)
    richiedi_logico(tls, "apri_ftp", "tls")
    if not tls and password and not anonimo and not _e_locale(host):
        raise ErroreValore("Non invio la password senza cifratura: chiunque sulla rete potrebbe leggerla.",
                           suggerimento="Usa `tls = vero` (FTPS). Se il server non lo permette, usa un "
                                        "server più sicuro (SFTP).")
    segreti = [password] if password else []
    try:
        ftp = ftplib.FTP_TLS(context=ssl.create_default_context(), timeout=tempo) if tls else ftplib.FTP(timeout=tempo)
        ftp.connect(host, porta)
        ftp.login(utente or "anonymous", password)
        if tls:
            ftp.prot_p()
    except ftplib.error_perm as e:
        raise ErroreFile(f"Accesso non riuscito al server FTP `{host}`.",
                         suggerimento=_senza_segreti(f"Controlla utente e password. Risposta del server: {e}",
                                                     segreti)) from None
    except (ftplib.Error, EOFError) as e:
        raise ErroreFile(f"Il server FTP `{host}` ha risposto in modo inatteso.",
                         suggerimento=_senza_segreti(f"Dettaglio tecnico: {e}", segreti)) from None
    except (OSError, ssl.SSLError, UnicodeError) as e:
        raise _errore(e, host, porta, tempo) from None
    return ConnessioneFtp(ftp, host, segreti)


@proprieta(ConnessioneFtp, "aperta")
def _ftp_aperta(f: ConnessioneFtp) -> bool:
    return f.aperta


@metodo_oggetto(ConnessioneFtp, "elenca")
def ftp_elenca(f, cartella=None):
    """ftp.elenca(cartella = nulla): la lista dei nomi dei file e delle cartelle sul server.

    Esempio: `per ogni nome in ftp.elenca() fai stampa(nome) fine`.
    """
    argomenti = [] if cartella is None else [_nome_remoto(cartella, "elenca", "cartella")]
    try:
        nomi = f.esegui("nlst", *argomenti)
    except ErroreFile as e:
        if "550" in (e.suggerimento or "") and cartella is None:
            return []  # cartella vuota: alcuni server rispondono "550 No files found"
        raise
    return sorted(os.path.basename(n.rstrip("/")) or n for n in nomi if n not in (".", ".."))


@metodo_oggetto(ConnessioneFtp, "scarica")
def ftp_scarica(f, nome, percorso=None):
    """ftp.scarica(nome, percorso = nulla): scarica un file dal server e restituisce dove l'ha salvato.

    Senza `percorso` il file va nella cartella corrente con lo stesso nome. Il file compare solo quando è completo.
    Esempio: `ftp.scarica("listino.pdf", "documenti/listino.pdf")`.
    """
    remoto = _nome_remoto(nome, "scarica", "nome")
    if percorso is None:
        percorso = _nome_file_sicuro(remoto)
    richiedi_testo(percorso, "scarica", "percorso")
    if not percorso.strip() or "\0" in percorso:
        raise ErroreValore("Il `percorso` di `scarica` non è valido.")
    if os.path.isdir(percorso):
        percorso = os.path.join(percorso, _nome_file_sicuro(remoto))
    cartella = os.path.dirname(os.path.abspath(percorso))
    if not os.path.isdir(cartella):
        raise ErroreFile(f"La cartella `{cartella}` non esiste.", suggerimento="Creala prima con `crea_cartella`.")
    fd, temporaneo = tempfile.mkstemp(dir=cartella, suffix=".parziale")
    try:
        with os.fdopen(fd, "wb") as uscita:
            f.esegui("retrbinary", f"RETR {remoto}", uscita.write)
        os.replace(temporaneo, percorso)
    finally:
        if os.path.exists(temporaneo):
            os.unlink(temporaneo)
    return percorso


@metodo_oggetto(ConnessioneFtp, "carica")
def ftp_carica(f, percorso, nome=None):
    """ftp.carica(percorso, nome = nulla): manda un file di questo computer al server.

    Senza `nome` sul server avrà lo stesso nome. Restituisce `vero`.
    Esempio: `ftp.carica("sito/index.html")`.
    """
    richiedi_testo(percorso, "carica", "percorso")
    if not percorso.strip() or "\0" in percorso or not os.path.isfile(percorso):
        raise ErroreFile(f"Il file {mostra(percorso)} non esiste.",
                         suggerimento=f"Controlla il nome: ora sei in `{os.getcwd()}`.")
    remoto = os.path.basename(percorso) if nome is None else _nome_remoto(nome, "carica", "nome")
    try:
        with open(percorso, "rb") as ingresso:
            f.esegui("storbinary", f"STOR {remoto}", ingresso)
    except OSError as e:
        raise ErroreFile(f"Non riesco a leggere `{percorso}`: {e.strerror or e}.") from None
    return True


@metodo_oggetto(ConnessioneFtp, "chiudi")
def ftp_chiudi(f):
    """ftp.chiudi(): chiude il collegamento con il server FTP.

    Esempio: `ftp.chiudi()`.
    """
    if f.aperta:
        f.aperta = False
        try:
            f.ftp.quit()
        except (ftplib.Error, OSError, EOFError):
            try:
                f.ftp.close()
            except OSError:
                pass
    return None


# ===========================================================================
# Processi
# ===========================================================================

def _decodifica_uscita(dati: bytes) -> str:
    try:
        return dati.decode("utf-8")
    except UnicodeDecodeError:
        return dati.decode(locale.getpreferredencoding(False) or "latin-1", "replace")


class Processo(OggettoLibreria):
    """Un programma avviato in sfondo da questo programma Leo."""

    NOME_TIPO_DANTE = "processo"

    def __init__(self, popen: subprocess.Popen, comando: str) -> None:
        self.popen = popen
        self.comando = comando
        self.pezzi: list[bytes] = []
        self.blocco = threading.Lock()
        self.lettore = threading.Thread(target=self._leggi, daemon=True)
        self.lettore.start()

    def _leggi(self) -> None:
        flusso = self.popen.stdout
        try:
            while True:
                dati = flusso.read1(65536) if hasattr(flusso, "read1") else flusso.read(65536)
                if not dati:
                    break
                with self.blocco:
                    self.pezzi.append(dati)
        except (OSError, ValueError):
            pass
        finally:
            try:
                flusso.close()
            except OSError:
                pass

    def testo_dante(self) -> str:
        stato = "in esecuzione" if self.popen.poll() is None else f"finito (codice {self.popen.returncode})"
        return f"<processo {self.popen.pid} {stato}>"

    def termina(self) -> None:
        if self.popen.poll() is not None:
            return
        try:
            if os.name == "nt":
                subprocess.run(["taskkill", "/PID", str(self.popen.pid), "/T", "/F"],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10)
            else:
                os.killpg(self.popen.pid, signal.SIGTERM)
        except (OSError, subprocess.SubprocessError):
            self.popen.terminate()
        try:
            self.popen.wait(3)
        except subprocess.TimeoutExpired:
            try:
                if os.name != "nt":
                    os.killpg(self.popen.pid, signal.SIGKILL)
                else:
                    self.popen.kill()
            except OSError:
                self.popen.kill()
            self.popen.wait(3)


@funzione_libreria("avvia_in_sfondo", interprete=True)
def avvia_in_sfondo(interprete, comando, cartella=None, senza_conferma=False):
    """avvia_in_sfondo(comando, cartella = nulla, senza_conferma = falso): avvia un comando e intanto il programma prosegue.

    Il comando viene mostrato all'utente, che deve dare il permesso (salvo `senza_conferma = vero`).
    Restituisce un `processo`: `leggi_uscita()` dà quello che ha scritto finora, `aspetta()` aspetta
    che finisca, `ferma()` lo chiude; `in_esecuzione`, `codice` e `pid` sono proprietà.
    Funziona su Windows, Linux e macOS (non nell'app Android).
    Esempio: `variabile p = avvia_in_sfondo("python3 -m http.server 8000")` e più tardi `p.ferma()`.
    """
    from ..piattaforma import non_su_android
    from ..sistema._win import chiedi_conferma

    richiedi_testo(comando, "avvia_in_sfondo", "comando")
    if not comando.strip() or "\0" in comando:
        raise ErroreValore("Il `comando` di `avvia_in_sfondo` è vuoto o non valido.",
                           suggerimento='Esempio: `avvia_in_sfondo("ping 127.0.0.1")`.')
    if cartella is not None:
        richiedi_testo(cartella, "avvia_in_sfondo", "cartella")
        if "\0" in cartella or not os.path.isdir(cartella):
            raise ErroreFile(f"La cartella {mostra(cartella)} non esiste.")
    richiedi_logico(senza_conferma, "avvia_in_sfondo", "senza_conferma")
    non_su_android("avvia_in_sfondo")
    if not senza_conferma and not chiedi_conferma(
            interprete, f"Il programma vuole avviare questo comando:\n\n{comando}\n\nVuoi permetterlo?"):
        raise ErroreValore("`avvia_in_sfondo`: l'utente non ha dato il permesso.",
                           suggerimento="Il comando non è stato avviato.")
    extra: dict[str, Any] = {}
    if os.name == "nt":
        extra["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    else:
        extra["start_new_session"] = True  # così `ferma` chiude anche i suoi figli
    try:
        popen = subprocess.Popen(comando, shell=True, cwd=cartella, stdin=subprocess.DEVNULL,
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT, **extra)
    except OSError as e:
        raise ErroreFile(f"`avvia_in_sfondo` non è riuscito a partire: {e.strerror or e}.",
                         suggerimento="Controlla il nome del comando.") from None
    return Processo(popen, comando)


@proprieta(Processo, "in_esecuzione")
def _proc_in_esecuzione(p: Processo) -> bool:
    return p.popen.poll() is None


@proprieta(Processo, "codice")
def _proc_codice(p: Processo) -> int | None:
    return p.popen.poll()


@proprieta(Processo, "pid")
def _proc_pid(p: Processo) -> int:
    return p.popen.pid


@proprieta(Processo, "comando")
def _proc_comando(p: Processo) -> str:
    return p.comando


@metodo_oggetto(Processo, "leggi_uscita")
def processo_leggi_uscita(p):
    """processo.leggi_uscita(): il testo scritto dal processo dall'ultima lettura (senza aspettare).

    Esempio: `stampa(p.leggi_uscita())`.
    """
    with p.blocco:
        dati, p.pezzi = b"".join(p.pezzi), []
    return _decodifica_uscita(dati)


@metodo_oggetto(Processo, "aspetta", interprete=True)
def processo_aspetta(interprete, p, tempo_massimo=None):
    """processo.aspetta(tempo_massimo = nulla): aspetta che il processo finisca e restituisce il codice (0 = tutto bene).

    Se passa `tempo_massimo` secondi e il processo lavora ancora restituisce `nulla`.
    Esempio: `variabile codice = p.aspetta(30)`.
    """
    tempo = _tempo(tempo_massimo, "aspetta", nulla_ok=True)
    fine = None if tempo is None else time.monotonic() + tempo
    while p.popen.poll() is None:
        if _fermato(interprete) or (fine is not None and time.monotonic() >= fine):
            return None
        _pausa(interprete, 0.05 if fine is None else max(0.0, min(0.05, fine - time.monotonic())))
    p.lettore.join(1)
    return p.popen.returncode


@metodo_oggetto(Processo, "ferma")
def processo_termina(p):
    """processo.ferma(): chiude il processo (e i programmi che ha avviato lui). `vero` se era ancora acceso.

    Si possono chiudere solo i processi avviati dal programma con `avvia_in_sfondo`.
    Esempio: `p.ferma()`.
    """
    acceso = p.popen.poll() is None
    p.termina()
    return acceso


# ===========================================================================
# Informazioni sul sistema
# ===========================================================================

@funzione_libreria("sistema_operativo")
def sistema_operativo():
    """sistema_operativo(): il nome del sistema: "Windows", "Linux", "macOS" o "Android".

    Esempio: `se sistema_operativo() == "Windows" allora stampa("Sei su Windows") fine`.
    """
    from ..piattaforma import e_android

    if e_android():
        return "Android"
    nome = platform.system()
    return {"Darwin": "macOS", "": "sconosciuto"}.get(nome, nome)


def _memoria() -> tuple[int, int] | None:
    """(totale, disponibile) in byte, o ``None``."""
    if os.name == "nt":
        try:
            import ctypes

            class _Stato(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]

            stato = _Stato()
            stato.dwLength = ctypes.sizeof(_Stato)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stato)):
                return int(stato.ullTotalPhys), int(stato.ullAvailPhys)
        except (OSError, AttributeError, ImportError):
            return None
        return None
    try:
        with open("/proc/meminfo", encoding="ascii", errors="replace") as f:
            valori = {}
            for riga in f:
                chiave, _, resto = riga.partition(":")
                parti = resto.split()
                if parti and parti[0].isdigit():
                    valori[chiave] = int(parti[0]) * 1024
        if "MemTotal" in valori:
            libera = valori.get("MemAvailable", valori.get("MemFree", 0) + valori.get("Cached", 0))
            return valori["MemTotal"], libera
    except OSError:
        pass
    if platform.system() == "Darwin":
        try:
            totale = int(subprocess.run(["sysctl", "-n", "hw.memsize"], capture_output=True, text=True,
                                        timeout=5).stdout.strip())
            vm = subprocess.run(["vm_stat"], capture_output=True, text=True, timeout=5).stdout
            pagina = int(re.search(r"page size of (\d+)", vm).group(1)) if "page size of" in vm else 4096
            pagine = sum(int(m.group(2)) for m in re.finditer(r"Pages (free|inactive|speculative):\s+(\d+)", vm))
            return totale, pagine * pagina
        except (OSError, ValueError, AttributeError, subprocess.SubprocessError):
            pass
    try:
        pagina = os.sysconf("SC_PAGE_SIZE")
        return os.sysconf("SC_PHYS_PAGES") * pagina, os.sysconf("SC_AVPHYS_PAGES") * pagina
    except (ValueError, OSError, AttributeError):
        return None


def _percentuale(parte: int, totale: int) -> float:
    return round(parte * 100 / totale, 1) if totale else 0.0


def _leggibile(n: int) -> str:
    for unita, grandezza in (("TB", 1024 ** 4), ("GB", 1024 ** 3), ("MB", 1024 ** 2), ("KB", 1024)):
        if n >= grandezza:
            return f"{n / grandezza:.1f} {unita}".replace(".", ",")
    return f"{n} B"


@funzione_libreria("memoria_sistema")
def memoria_sistema():
    """memoria_sistema(): la memoria (RAM) del computer: "totale", "libera", "usata" (in byte), "percentuale_usata", "testo".

    Funziona su Windows, Linux, macOS e Android.
    Esempio: `stampa(memoria_sistema()["testo"])` scrive per esempio "5,2 GB liberi su 16,0 GB".
    """
    valori = _memoria()
    if valori is None:
        raise ErroreValore("Su questo sistema non riesco a leggere la memoria.",
                           suggerimento="Il sistema non lo permette: prova su Windows, Linux o macOS.")
    totale, libera = valori
    usata = max(0, totale - libera)
    return {"totale": totale, "libera": libera, "usata": usata, "percentuale_usata": _percentuale(usata, totale),
            "testo": f"{_leggibile(libera)} liberi su {_leggibile(totale)}"}


@funzione_libreria("spazio_disco")
def spazio_disco(percorso=None):
    """spazio_disco(percorso = nulla): lo spazio del disco che contiene `percorso` (senza: la cartella di casa).

    Restituisce "totale", "libero", "usato" (in byte), "percentuale_usata", "testo".
    Funziona su Windows, Linux, macOS e Android.
    Esempio: `se spazio_disco()["libero"] < 1000000000 allora stampa("Meno di 1 GB libero!") fine`.
    """
    if percorso is None:
        percorso = os.path.expanduser("~")
    richiedi_testo(percorso, "spazio_disco", "percorso")
    if not percorso.strip() or "\0" in percorso:
        raise ErroreValore("Il `percorso` di `spazio_disco` è vuoto o non valido.",
                           suggerimento='Esempio: `spazio_disco("C:/")` oppure `spazio_disco("/")`.')
    try:
        uso = shutil.disk_usage(percorso)
    except OSError:
        raise ErroreFile(f"Il percorso `{percorso}` non esiste.",
                         suggerimento="Scrivi una cartella che c'è, per esempio la cartella di casa.") from None
    return {"totale": uso.total, "libero": uso.free, "usato": uso.used,
            "percentuale_usata": _percentuale(uso.used, uso.total),
            "testo": f"{_leggibile(uso.free)} liberi su {_leggibile(uso.total)}"}


@funzione_libreria("info_sistema")
def info_sistema():
    """info_sistema(): un dizionario con le informazioni principali sul computer, su ogni sistema.

    Chiavi: "sistema", "versione", "nome_computer", "utente", "processori", "architettura",
    "memoria_totale", "memoria_libera", "disco_totale", "disco_libero", "cartella_casa", "versione_python".
    Esempio: `per ogni chiave in chiavi(info_sistema()) fai stampa(chiave, info_sistema()[chiave]) fine`.
    """
    try:
        import getpass

        utente = getpass.getuser()
    except (ImportError, KeyError, OSError):
        utente = None
    memoria = _memoria()
    try:
        disco = shutil.disk_usage(os.path.expanduser("~"))
    except OSError:
        disco = None
    sistema = sistema_operativo()
    if sistema == "macOS":
        versione = platform.mac_ver()[0] or platform.release()
    elif sistema == "Windows":
        versione = platform.version()
    else:
        versione = platform.release()
    return {
        "sistema": sistema,
        "versione": versione or None,
        "nome_computer": platform.node() or None,
        "utente": utente,
        "processori": os.cpu_count(),
        "architettura": platform.machine() or None,
        "memoria_totale": memoria[0] if memoria else None,
        "memoria_libera": memoria[1] if memoria else None,
        "disco_totale": disco.total if disco else None,
        "disco_libero": disco.free if disco else None,
        "cartella_casa": os.path.expanduser("~"),
        "versione_python": platform.python_version(),
    }


# ===========================================================================
# Ping
# ===========================================================================

_TEMPO_PING = re.compile(r"(?:time|durata|tempo|zeit|temps|tiempo)\s*[=<]\s*([\d.,]+)\s*ms", re.IGNORECASE)


@funzione_libreria("fai_ping")
def fai_ping(indirizzo, volte=1, tempo_massimo=5):
    """fai_ping(indirizzo, volte = 1, tempo_massimo = 5): controlla se un computer risponde e quanto è veloce.

    Usa il comando `ping` del sistema verso UN indirizzo (da 1 a 10 volte). Restituisce un dizionario
    con "raggiungibile" (`vero`/`falso`), "millisecondi" (tempo medio, o `nulla`), "risposte", "inviati".
    Esempio: `variabile r = fai_ping("192.168.1.1")` poi `stampa(r["millisecondi"], "ms")`.
    """
    host = _host(indirizzo, "fai_ping")
    if isinstance(volte, bool) or not isinstance(volte, int):
        raise ErroreTipo(f"`volte` di `fai_ping` deve essere un numero intero, non {articolo(volte)}.")
    if not 1 <= volte <= 10:
        raise ErroreValore("`volte` di `fai_ping` deve essere tra 1 e 10.")
    tempo = _tempo(tempo_massimo, "fai_ping")
    if tempo > 60:
        raise ErroreValore("`tempo_massimo` di `fai_ping` è al massimo 60 secondi.")
    attesa = max(1, int(tempo))
    sistema = platform.system()
    if os.name == "nt":
        comando = ["ping", "-n", str(volte), "-w", str(attesa * 1000), host]
    elif sistema == "Darwin":
        comando = ["ping", "-c", str(volte), "-t", str(attesa + volte), host]
    else:
        comando = ["ping", "-c", str(volte), "-W", str(attesa), host]
    if ":" in host and os.name != "nt" and sistema == "Darwin":
        comando[0] = "ping6"
    extra = {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)} if os.name == "nt" else {}
    try:
        r = subprocess.run(comando, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                           timeout=attesa * volte + 5, **extra)
        uscita = _decodifica_uscita(r.stdout)
    except FileNotFoundError:
        raise ErroreValore("Il comando `ping` non c'è su questo sistema.",
                           suggerimento="Per sapere se un computer risponde puoi usare "
                                        "`porta_aperta(indirizzo, 443)`.") from None
    except subprocess.TimeoutExpired:
        return {"raggiungibile": False, "millisecondi": None, "risposte": 0, "inviati": volte}
    except OSError as e:
        raise ErroreValore(f"Non riesco a usare il comando `ping`: {e.strerror or e}.") from None
    tempi = [float(m.group(1).replace(",", ".")) for m in _TEMPO_PING.finditer(uscita)]
    if not tempi and r.returncode == 0 and ("<1ms" in uscita.replace(" ", "") or "<1 ms" in uscita):
        tempi = [0.5] * volte
    return {"raggiungibile": bool(tempi) or r.returncode == 0,
            "millisecondi": round(sum(tempi) / len(tempi), 1) if tempi else None,
            "risposte": len(tempi), "inviati": volte}


# ===========================================================================
# Osservare una cartella
# ===========================================================================

MASSIMO_FILE_OSSERVATI = 50_000


class Osservatore(OggettoLibreria):
    """Guarda una cartella e dice quali file sono nuovi, cambiati o spariti."""

    NOME_TIPO_DANTE = "osservatore"

    def __init__(self, cartella: str, sottocartelle: bool) -> None:
        self.cartella = cartella
        self.sottocartelle = sottocartelle
        self.stato = self.istantanea()

    def testo_dante(self) -> str:
        return f"<osservatore di {self.cartella}>"

    def istantanea(self) -> dict[str, tuple[int, int]]:
        risultato: dict[str, tuple[int, int]] = {}
        da_visitare = [""]
        while da_visitare:
            relativa = da_visitare.pop()
            try:
                with os.scandir(os.path.join(self.cartella, relativa)) as voci:
                    for voce in voci:
                        nome = f"{relativa}/{voce.name}" if relativa else voce.name
                        try:
                            if voce.is_dir(follow_symlinks=False):
                                if self.sottocartelle:
                                    da_visitare.append(nome)
                                continue
                            info = voce.stat()
                        except OSError:
                            continue
                        risultato[nome] = (info.st_mtime_ns, info.st_size)
                        if len(risultato) >= MASSIMO_FILE_OSSERVATI:
                            return risultato
            except OSError:
                if not relativa:
                    raise ErroreFile(f"Non riesco più a leggere la cartella `{self.cartella}`.",
                                     suggerimento="Forse è stata cancellata o spostata.") from None
        return risultato

    def novita(self) -> dict | None:
        nuovo = self.istantanea()
        vecchio = self.stato
        self.stato = nuovo
        nuovi = sorted(set(nuovo) - set(vecchio))
        eliminati = sorted(set(vecchio) - set(nuovo))
        modificati = sorted(n for n in set(nuovo) & set(vecchio) if nuovo[n] != vecchio[n])
        if not (nuovi or eliminati or modificati):
            return None
        return {"nuovi": nuovi, "modificati": modificati, "eliminati": eliminati}


@funzione_libreria("osserva_cartella")
def osserva_cartella(percorso, sottocartelle=False):
    """osserva_cartella(percorso, sottocartelle = falso): comincia a guardare una cartella per vedere i file nuovi o cambiati.

    Restituisce un `osservatore`: `novita()` dice cosa è cambiato dall'ultima volta, `aspetta_novita()`
    aspetta che cambi qualcosa. Le novità sono un dizionario con "nuovi", "modificati", "eliminati".
    Esempio: `variabile arrivi = osserva_cartella("Download")` poi `stampa(arrivi.aspetta_novita()["nuovi"])`.
    """
    richiedi_testo(percorso, "osserva_cartella", "percorso")
    richiedi_logico(sottocartelle, "osserva_cartella", "sottocartelle")
    if not percorso.strip() or "\0" in percorso or not os.path.isdir(percorso):
        raise ErroreFile(f"La cartella {mostra(percorso)} non esiste.",
                         suggerimento=f"Controlla il nome: ora sei in `{os.getcwd()}`.")
    return Osservatore(os.path.abspath(percorso), sottocartelle)


@proprieta(Osservatore, "cartella")
def _oss_cartella(o: Osservatore) -> str:
    return o.cartella


@proprieta(Osservatore, "quanti_file")
def _oss_quanti(o: Osservatore) -> int:
    return len(o.stato)


@metodo_oggetto(Osservatore, "novita")
def osservatore_novita(o):
    """osservatore.novita(): cosa è cambiato dall'ultima volta ("nuovi", "modificati", "eliminati"), o `nulla` se niente.

    Esempio: `variabile n = arrivi.novita()` poi `se n != nulla allora stampa(n["nuovi"]) fine`.
    """
    return o.novita()


@metodo_oggetto(Osservatore, "aspetta_novita", interprete=True)
def osservatore_aspetta(interprete, o, tempo_massimo=None, ogni=1):
    """osservatore.aspetta_novita(tempo_massimo = nulla, ogni = 1): aspetta che nella cartella cambi qualcosa.

    Guarda la cartella ogni `ogni` secondi; restituisce le novità, o `nulla` se passa `tempo_massimo`.
    Esempio: `mentre vero fai stampa("Nuovi file:", arrivi.aspetta_novita()["nuovi"]) fine`.
    """
    tempo = _tempo(tempo_massimo, "aspetta_novita", nulla_ok=True)
    passo = _tempo(ogni, "aspetta_novita", "ogni")
    passo = max(0.05, min(passo, 3600.0))
    fine = None if tempo is None else time.monotonic() + tempo
    while True:
        cambiamenti = o.novita()
        if cambiamenti is not None:
            return cambiamenti
        if _fermato(interprete):
            return None
        rimasto = None if fine is None else fine - time.monotonic()
        if rimasto is not None and rimasto <= 0:
            return None
        _pausa(interprete, passo if rimasto is None else min(passo, rimasto))


# ===========================================================================
# Velocità di scaricamento
# ===========================================================================

@funzione_libreria("velocita_scaricamento")
def velocita_scaricamento(indirizzo, secondi_massimi=10):
    """velocita_scaricamento(indirizzo, secondi_massimi = 10): misura quanto è veloce scaricare da quell'indirizzo web.

    Scarica il file (senza salvarlo) per al massimo `secondi_massimi` secondi. Restituisce "byte",
    "secondi", "megabit_al_secondo", "kilobyte_al_secondo" e "testo" (per esempio "23,4 Mbit/s").
    Esempio: `stampa(velocita_scaricamento("https://www.esempio.it/file-di-prova.bin")["testo"])`.
    """
    richiedi_testo(indirizzo, "velocita_scaricamento", "indirizzo")
    try:
        parti = urllib.parse.urlsplit(indirizzo.strip())
    except ValueError:
        parti = None
    if parti is None or parti.scheme not in ("http", "https") or not parti.hostname:
        raise ErroreValore(f"{mostra(indirizzo)} non è un indirizzo web.",
                           suggerimento='Deve cominciare con "https://" (o "http://").')
    durata = _tempo(secondi_massimi, "velocita_scaricamento", "secondi_massimi")
    if durata > 120:
        raise ErroreValore("`secondi_massimi` di `velocita_scaricamento` è al massimo 120.")
    richiesta = urllib.request.Request(indirizzo.strip(), headers={"User-Agent": "Leo/1.0 (linguaggio in italiano)"})
    if _e_locale(parti.hostname):
        apri = urllib.request.build_opener(urllib.request.ProxyHandler({})).open
    else:
        apri = urllib.request.urlopen
    byte = 0
    inizio = time.monotonic()
    try:
        with apri(richiesta, timeout=min(durata, 30)) as risposta:
            inizio = time.monotonic()
            while time.monotonic() - inizio < durata:
                pezzo = risposta.read(65536)
                if not pezzo:
                    break
                byte += len(pezzo)
    except urllib.error.HTTPError as e:
        raise ErroreFile(f"Il sito ha risposto con un errore ({e.code}).",
                         suggerimento="Controlla l'indirizzo del file di prova.") from None
    except (urllib.error.URLError, OSError, ValueError) as e:
        if isinstance(e, ValueError):
            raise ErroreValore(f"Indirizzo non valido: {mostra(indirizzo)}.") from None
        raise _errore_rete(e, parti, durata) from None
    secondi = max(time.monotonic() - inizio, 1e-6)
    megabit = byte * 8 / secondi / 1_000_000
    return {"byte": byte, "secondi": round(secondi, 3), "megabit_al_secondo": round(megabit, 2),
            "kilobyte_al_secondo": round(byte / 1024 / secondi, 1),
            "testo": f"{megabit:.1f} Mbit/s".replace(".", ",")}
