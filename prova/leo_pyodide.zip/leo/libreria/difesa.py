"""Libreria: difesa, robustezza dei propri account e crittografia completa.

Questo modulo COMPLETA la sicurezza già presente in Leo (impronte, HMAC,
password scrypt in ``sicurezza_dati``; AES-GCM, firme Ed25519 e password comuni
in ``binario``): non la ripete, la mette insieme e aggiunge i pezzi che
mancavano. Tutto serve a proteggere i TUOI dati e i TUOI account, mai ad
attaccare quelli di altri.

* **robustezza (sui tuoi dati)**: ``misura_forza_password`` e
  ``spiega_forza_password`` (dicono *perché* una password è debole, con la stima
  del tempo per indovinarla), ``genera_frase_password`` (una frase lunga e
  memorizzabile in italiano, stile "diceware"), ``genera_password_pronunciabile``,
  ``genera_pin``; codici OTP a tempo standard (TOTP/HOTP) per proteggere i tuoi
  account: ``genera_segreto_otp``, ``codice_otp``, ``codice_otp_a``,
  ``verifica_codice_otp``, ``codice_otp_contatore``, ``uri_otp``, ``qr_otp_svg``,
  ``salva_qr_otp``; controllo delle proprie impostazioni:
  ``porte_locali_in_ascolto`` (solo 127.0.0.1, nessuna scansione di altri),
  ``permessi_file``, ``controlla_permessi_file``, ``rendi_file_privato``;
* **crittografia a chiave pubblica**: ``crea_chiavi_riservatezza`` (coppia
  X25519), ``cifra_per``/``decifra_da`` (cifra per un destinatario),
  ``cifra_file_per``/``decifra_file_da``, e la "busta" per più destinatari
  (``busta_per_molti``/``apri_busta`` e le versioni su file);
* **gestione delle chiavi**: ``impronta_chiave`` e ``parole_impronta`` (per
  confrontare a voce due chiavi), ``confronta_chiavi``, ``esporta_chiave_pubblica``,
  ``importa_chiave_pubblica``, ``salva_chiave``/``carica_chiave`` (la chiave
  privata si salva cifrata; non si stampa MAI);
* **firme di file e messaggi** (Ed25519): ``firma_file``, ``verifica_firma_file``,
  ``scrivi_firma_file``, ``verifica_file_firmato`` (le chiavi sono le stesse di
  ``crea_chiavi_firma``);
* **didattica**: sfide "cattura la bandiera" su file preparati in locale
  (``prepara_sfida_segreto``, ``prepara_sfida_cifrata``, ``prepara_sfida_firma``,
  ``verifica_bandiera``) e ``mostra_attacco_dizionario``, che fa vedere — SOLO
  sulla TUA impronta — perché un'impronta senza sale di una password comune si
  "rompe" subito, così impari a difenderti usando scrypt e il sale.

LINEA ETICA. Qui ci sono solo mattoni difensivi e didattici: proteggere, cifrare,
firmare, misurare la robustezza dei PROPRI dati. Niente strumenti d'attacco
pronti all'uso: nessuna scansione di reti o porte altrui (il controllo resta su
127.0.0.1), nessuna forza bruta contro servizi o password di altri, nessun invio
di password da nessuna parte (gli elenchi di password comuni sono LOCALI).
``mostra_attacco_dizionario`` mostra come funziona un attacco al SOLO scopo di
riconoscerlo e difendersi, e lavora solo sull'impronta che gli dai tu.

La crittografia vera richiede il pacchetto facoltativo ``cryptography`` (sul PC
``pip install cryptography``, sul telefono si aggiunge ai pacchetti); se manca,
l'errore lo spiega. ``md5`` e ``sha1`` restano marcati non sicuri (vedi
``sicurezza_dati``); l'HMAC-SHA1 dentro TOTP è lo standard di interoperabilità e
non è un uso debole.
"""

from __future__ import annotations

import base64
import binascii
import hashlib
import hmac
import math
import os
import secrets
import socket
import stat as _stat
import struct
import time
from typing import Any

from ..errori import ErroreFile, ErroreTipo, ErroreValore
from .generali import (articolo, funzione_libreria, mostra, richiedi_intero,
                       richiedi_logico, richiedi_testo)
from .ingresso_uscita import _controlla_percorso, _errore_file

#: Dati più grandi di così (in byte) non si trattano in memoria.
MASSIMO_DATI = 64 * 1024 * 1024
#: Livelli di forza di una password, dal più basso al più alto (indici 0-4).
LIVELLI_FORZA: tuple[str, ...] = ("pessima", "debole", "sufficiente", "buona", "ottima")

# Prefissi dei testi delle chiavi (gli Ed25519 sono gli stessi di `crea_chiavi_firma`).
_PRE_FIRMA_PRIV = "ed25519-privata:"
_PRE_FIRMA_PUB = "ed25519-pubblica:"
_PRE_RIS_PRIV = "x25519-privata:"
_PRE_RIS_PUB = "x25519-pubblica:"
_PRE_CHIAVE_CIFRATA = "leo-chiave-cifrata:"

# Magie dei formati binari (poi in base64).
_MAGIA_BUSTA1 = b"LEOX"      # busta per un destinatario (X25519 + AES-GCM)
_MAGIA_BUSTAN = b"LEOM"      # busta per più destinatari

#: Parole italiane comuni per le frasi-password e per leggere a voce le impronte.
#: Tutte minuscole, senza accenti, da 3 a 8 lettere.
_PAROLE_GREZZE = """
abete acero ago albero alba amaca amico ancora anello angolo ape aquila arancia
arco aria arpa asino avena azzurro balena banco barca basilico bosco botte braccio
bruco bue burro cactus caffe calamaro calcio camino campana cane canto capra
carota casa cascata castello cavallo cedro cena cervo chiave cielo ciliegia cigno
cinghiale cioccolato citta civetta coccinella collina colomba conchiglia coniglio
corallo corda corvo costa cotone cristallo cubo cuoco cuore delfino dente dito dono
drago duna elefante erba fabbro faggio falco fame faro farfalla fata felce ferro
fiamma fico fieno fifa fila finestra fiocco fiore fiume foca foglia fondo fontana
foresta formica forno fragola freccia fretta fulmine fumo fungo gabbia gabbiano
galassia gallina gallo gamba gatto gelato gelo ghianda ghiaccio giada giardino
giglio gioco gioia gomito gondola gonna gradino grano grillo grotta gufo iena isola
ippopotamo lago lampada lana latte lavagna legno leone lepre lettera libro limone
lince lino lontra luce luna lupo maglia mandorla mano mappa mare margherita matita
melo mela mento miele mimosa minestra mirtillo molla monte mora mosca muro musica
nave nebbia neve nido nocciola nodo noce notte nuvola oasi oca olmo ombra onda oro
orso ortica orto osso ostrica paglia palla pane panino pantera pappagallo passero
pasta pavone pecora penna pera pesca pesce petalo piano piazza picco piede pietra
pigna pino pioggia piuma polpo pomodoro ponte porta prato primula prugna pulce
quaderno quadro quercia radice ragno rame rana rete riccio riso riva roccia rondine
rosa rospo rotaia rubino ruota sabbia sacco sale salice salto sardina sasso scala
scialle scoglio scimmia scoiattolo scudo sedano sedia selva sentiero seta sillaba
sole sorgente sorriso spada spiga spina stagno stella stiletto storia strada
tamburo tana tartaruga tasso tavolo tazza telaio tempesta tenda terra tesoro tetto
tigre torre tralcio treno trono tulipano tuono uccello ulivo uovo uva valle vapore
vela veliero vento verme vetro vigna viola violino vipera volpe zaino zampa zebra
zenzero zolla zucca
"""
_PAROLE: tuple[str, ...] = tuple(sorted(set(_PAROLE_GREZZE.split())))

_VOCALI = "aeiou"
_CONSONANTI = "bcdfglmnprstv"
_AMBIGUI = set("Il1O0o")
_SIMBOLI_PIN = "0123456789"

# Porte locali che vale la pena controllare sui PROPRI servizi (solo 127.0.0.1).
_PORTE_NOTE = {
    22: "SSH (accesso remoto)", 80: "web (HTTP)", 443: "web sicuro (HTTPS)",
    3306: "MySQL/MariaDB", 5432: "PostgreSQL", 6379: "Redis", 27017: "MongoDB",
    3389: "desktop remoto (RDP)", 5900: "VNC", 8080: "web di prova",
    8000: "web di prova", 5000: "web di prova", 9000: "servizio locale",
    11211: "Memcached", 25: "posta (SMTP)", 21: "FTP", 23: "Telnet (non sicuro)",
}


# ===========================================================================
# Strumenti comuni
# ===========================================================================

def _cryptography(nome_funzione: str):
    """Restituisce i moduli di ``cryptography`` o un errore chiaro se manca."""
    try:
        from cryptography.hazmat.primitives.asymmetric import ed25519, x25519  # noqa: F401
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM  # noqa: F401
    except Exception:  # noqa: BLE001 - pacchetto assente o rotto
        raise ErroreValore(
            f"`{nome_funzione}` ha bisogno del pacchetto `cryptography`, che su questo computer non c'è.",
            suggerimento="Installalo con `pip install cryptography` (nell'app per il telefono aggiungilo ai "
                         "pacchetti). Leo non usa cifrari fatti in casa: non sarebbero sicuri.") from None
    import cryptography.exceptions as eccezioni
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ed25519, x25519
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from cryptography.hazmat.primitives.kdf.hkdf import HKDF
    return {"AESGCM": AESGCM, "ed25519": ed25519, "x25519": x25519, "HKDF": HKDF,
            "hashes": hashes, "serialization": serialization, "eccezioni": eccezioni}


def _in_byte(dati: Any, nome_funzione: str, parametro: str = "dati") -> bytes:
    """Un testo (UTF-8) o una lista di byte 0-255 come ``bytes``."""
    from .binario import DatiBinari
    if isinstance(dati, DatiBinari):
        return bytes(dati.valore)
    if isinstance(dati, str):
        if len(dati) > MASSIMO_DATI:
            raise ErroreValore(f"Il testo dato a `{nome_funzione}` è troppo lungo.")
        return dati.encode("utf-8", "surrogatepass")
    if isinstance(dati, list):
        if len(dati) > MASSIMO_DATI:
            raise ErroreValore(f"La lista di byte data a `{nome_funzione}` è troppo lunga.")
        for i, b in enumerate(dati):
            if type(b) is not int or not 0 <= b <= 255:
                raise ErroreValore(f"Nella lista di byte di `{nome_funzione}` l'elemento in posizione {i} "
                                   f"({mostra(b)}) non è un numero da 0 a 255.")
        return bytes(dati)
    raise ErroreTipo(f"L'argomento `{parametro}` di `{nome_funzione}` deve essere un testo o una lista di byte, "
                     f"non {articolo(dati)}.")


def _b64(dati: bytes) -> str:
    return base64.b64encode(dati).decode("ascii")


def _da_b64(testo: str, nome_funzione: str) -> bytes:
    try:
        pulito = "".join(str(testo).split())
        return base64.b64decode(pulito + "=" * (-len(pulito) % 4), validate=True)
    except (binascii.Error, ValueError) as e:
        raise ErroreValore(f"`{nome_funzione}`: il testo non è in Base64 valido.",
                           suggerimento="Usa esattamente il testo prodotto da Leo, senza cambiarlo.") from e


def _leggi_file(percorso: Any, nome_funzione: str) -> bytes:
    _controlla_percorso(percorso, nome_funzione)
    try:
        if os.path.getsize(percorso) > MASSIMO_DATI:
            raise ErroreValore(f"Il file `{percorso}` è troppo grande per `{nome_funzione}` (oltre 64 MB).")
        with open(percorso, "rb") as f:
            return f.read()
    except OSError as e:
        raise _errore_file(e, percorso, "leggere") from None


def _scrivi_file(percorso: str, contenuto: bytes, sovrascrivi: bool, nome_funzione: str,
                 privato: bool = False) -> None:
    _controlla_percorso(percorso, nome_funzione)
    if os.path.exists(percorso) and not sovrascrivi:
        raise ErroreFile(f"Il file `{percorso}` esiste già.",
                         suggerimento="Scegli un altro nome oppure aggiungi `sovrascrivi = vero`.")
    try:
        with open(percorso, "wb") as f:
            f.write(contenuto)
        if privato:
            _rendi_privato(percorso)
    except OSError as e:
        raise _errore_file(e, percorso, "scrivere") from None


def _rendi_privato(percorso: str) -> bool:
    """Toglie i permessi a gruppo e altri (0600/0700). Vero se fatto davvero."""
    if os.name == "nt":
        return False
    try:
        modo = _stat.S_IRWXU if os.path.isdir(percorso) else (_stat.S_IRUSR | _stat.S_IWUSR)
        os.chmod(percorso, modo)
        return True
    except OSError:
        return False


# ===========================================================================
# Robustezza delle password (estende il misuratore e `e_password_comune`)
# ===========================================================================

def _classi(pw: str) -> dict[str, bool]:
    return {"minuscole": any("a" <= c.lower() <= "z" and c.islower() for c in pw),
            "maiuscole": any(c.isupper() for c in pw),
            "cifre": any(c.isdigit() for c in pw),
            "simboli": any(not c.isalnum() for c in pw)}


def _dimensione_alfabeto(pw: str) -> int:
    classi = _classi(pw)
    dimensione = 0
    if classi["minuscole"]:
        dimensione += 26
    if classi["maiuscole"]:
        dimensione += 26
    if classi["cifre"]:
        dimensione += 10
    if classi["simboli"]:
        dimensione += 33
    # caratteri fuori dall'ASCII (lettere accentate, altri alfabeti)
    if any(ord(c) > 127 for c in pw):
        dimensione += 20
    return max(dimensione, 1)


def _ha_sequenza(pw: str, lunghezza: int = 4) -> bool:
    minuscola = pw.lower()
    for i in range(len(minuscola) - lunghezza + 1):
        pezzo = minuscola[i:i + lunghezza]
        if pezzo.isalnum():
            salti = {ord(pezzo[k + 1]) - ord(pezzo[k]) for k in range(lunghezza - 1)}
            if salti in ({1}, {-1}):
                return True
    for riga in ("qwertyuiop", "asdfghjkl", "zxcvbnm", "1234567890"):
        for i in range(len(riga) - lunghezza + 1):
            pezzo = riga[i:i + lunghezza]
            if pezzo in minuscola or pezzo[::-1] in minuscola:
                return True
    return False


def _ha_ripetizioni(pw: str) -> bool:
    import re
    if re.search(r"(.)\1\1", pw):
        return True
    return bool(re.fullmatch(r"(.{1,4})\1{2,}.?", pw)) and len(pw) >= 6


def _ha_anno(pw: str) -> bool:
    import re
    return bool(re.search(r"(?:19|20)\d\d", pw)
                or re.search(r"(?<!\d)(?:0?[1-9]|[12]\d|3[01])[/.\-](?:0?[1-9]|1[0-2])", pw))


def _tempo_per_tentativi(tentativi: float) -> str:
    """Stima leggibile del tempo per provare ``tentativi`` ipotesi (10 miliardi al secondo)."""
    secondi = tentativi / 1e10
    scale = ((1, "meno di un secondo"), (60, "secondi"), (3600, "minuti"), (86400, "ore"),
             (86400 * 30, "giorni"), (86400 * 365, "mesi"), (86400 * 365 * 100, "anni"),
             (86400 * 365 * 1_000_000, "secoli"))
    if secondi < 1:
        return "meno di un secondo"
    for limite, nome in scale:
        if secondi < limite * 60 or nome in ("secoli",):
            valore = secondi / max(limite, 1)
            if nome == "secoli":
                return "milioni di anni" if secondi > 86400 * 365 * 1e8 else "molti secoli"
            return f"circa {int(valore)} {nome}" if valore >= 1 else f"meno di un {nome[:-1]}"
    return "molti secoli"


@funzione_libreria("misura_forza_password")
def misura_forza_password(password):
    """misura_forza_password(password): quanto è robusta una password, in un dizionario con il punteggio e i problemi.

    Restituisce `punteggio` (da 0 a 4), `livello` ("pessima".."ottima"), `bit` (quanta casualità ha, in bit),
    `tempo` (stima di quanto ci vuole a indovinarla), `comune` (vero se è tra le più usate) e `problemi` (perché
    è debole). Nessuna password esce dal computer. Esempio: `misura_forza_password("Password1")["livello"]`.
    """
    richiedi_testo(password, "misura_forza_password", "password")
    from .binario import e_password_comune
    pw = password
    problemi: list[str] = []
    if not pw:
        return {"punteggio": 0, "livello": "pessima", "bit": 0.0, "tempo": "meno di un secondo",
                "comune": True, "problemi": ["È vuota: non protegge niente."]}
    lunghezza = len(pw)
    classi = _classi(pw)
    varieta = sum(classi.values())
    diversi = len(set(pw))
    bit = lunghezza * math.log2(_dimensione_alfabeto(pw))
    if diversi < lunghezza:
        bit -= (lunghezza - diversi) * 1.0           # i caratteri ripetuti aggiungono poco
    comune = e_password_comune(pw)

    if lunghezza < 8:
        problemi.append("È troppo corta: usa almeno 12 caratteri.")
    elif lunghezza < 12:
        problemi.append("Allungala: con almeno 12 caratteri diventa molto più difficile da indovinare.")
    # i consigli sulla varietà servono solo alle password corte: una frase lunga è forte anche tutta minuscola.
    if lunghezza < 16:
        if not classi["minuscole"] or not classi["maiuscole"]:
            problemi.append("Mescola lettere minuscole e maiuscole.")
        if not classi["cifre"]:
            problemi.append("Aggiungi qualche numero.")
        if not classi["simboli"]:
            problemi.append("Aggiungi un simbolo, per esempio ! ? # @ % &.")
    if _ha_sequenza(pw):
        problemi.append("Contiene una sequenza come \"abcd\", \"1234\" o \"qwerty\": si prova per prima.")
        bit = min(bit, 28)
    if _ha_ripetizioni(pw):
        problemi.append("Ripete gli stessi caratteri (come \"aaa\" o \"abab\"): aggiunge poca sicurezza.")
        bit = min(bit, 28)
    if _ha_anno(pw):
        problemi.append("Contiene un anno o una data (come un compleanno): sono tra le prime cose che si provano.")
        bit = min(bit, 30)
    if comune:
        problemi.append("È tra le password più usate al mondo (o una loro variante facile): si indovina subito.")
        bit = min(bit, 12)

    bit = max(0.0, round(bit, 1))
    if comune or bit < 28:
        punteggio = 0 if bit < 20 else 1
    elif bit < 40:
        punteggio = 2
    elif bit < 60:
        punteggio = 3
    else:
        punteggio = 4
    if punteggio == 4 and bit < 90 and (varieta < 3 or lunghezza < 12):
        punteggio = 3
    tentativi = 2 ** bit
    return {"punteggio": punteggio, "livello": LIVELLI_FORZA[punteggio], "bit": bit,
            "tempo": _tempo_per_tentativi(tentativi), "comune": comune, "problemi": problemi}


@funzione_libreria("spiega_forza_password")
def spiega_forza_password(password):
    """spiega_forza_password(password): un testo in italiano che spiega quanto è robusta una password e perché.

    Dice il livello, la stima del tempo per indovinarla e, riga per riga, che cosa la rende debole e come
    migliorarla. Comodo da stampare. Esempio: `stampa(spiega_forza_password("juventus"))`.
    """
    dati = misura_forza_password(password)
    righe = [f"Forza: {dati['livello']} ({dati['punteggio']} su 4).",
             f"Casualità stimata: {dati['bit']} bit; indovinarla a tentativi richiederebbe {dati['tempo']}."]
    if dati["problemi"]:
        righe.append("Da migliorare:")
        righe.extend(f"- {p}" for p in dati["problemi"])
    else:
        righe.append("Nessun problema evidente: usala su un solo sito e conservala in un gestore di password.")
    return "\n".join(righe)


@funzione_libreria("genera_frase_password")
def genera_frase_password(parole=6, separatore="-", con_numero=True, maiuscole=False):
    """genera_frase_password(parole = 6, separatore = "-", con_numero = vero, maiuscole = falso): una frase-password robusta e facile da ricordare.

    Sceglie a caso (in modo crittografico) parole italiane comuni, come "fiume-gatto-stella-...": lunga da
    indovinare ma facile da ricordare. Ogni parola aggiunge circa 8 bit; con 6 parole sei intorno ai 48 bit.
    Esempio: `genera_frase_password(6)` è per esempio "vela-oca-mandorla-grillo-faro-tetto".
    """
    richiedi_intero(parole, "genera_frase_password", "parole")
    richiedi_testo(separatore, "genera_frase_password", "separatore")
    richiedi_logico(con_numero, "genera_frase_password", "con_numero")
    richiedi_logico(maiuscole, "genera_frase_password", "maiuscole")
    if not 3 <= parole <= 20:
        raise ErroreValore(f"`parole` di `genera_frase_password` deve essere tra 3 e 20 (hai scritto {mostra(parole)}).",
                           suggerimento="Per un account importante usane almeno 6.")
    scelte = [secrets.choice(_PAROLE) for _ in range(parole)]
    if maiuscole:
        scelte = [p.capitalize() for p in scelte]
    frase = separatore.join(scelte)
    if con_numero:
        frase += separatore + str(secrets.randbelow(100)).zfill(2)
    return frase


@funzione_libreria("genera_password_pronunciabile")
def genera_password_pronunciabile(sillabe=5, con_numero=True):
    """genera_password_pronunciabile(sillabe = 5, con_numero = vero): una password casuale ma leggibile ad alta voce.

    Alterna consonanti e vocali (come "bo-ki-ne-ta-ру"): più facile da dire e scrivere di una password a caso,
    un po' meno robusta. Esempio: `genera_password_pronunciabile(5)` è per esempio "fokinalu47".
    """
    richiedi_intero(sillabe, "genera_password_pronunciabile", "sillabe")
    richiedi_logico(con_numero, "genera_password_pronunciabile", "con_numero")
    if not 3 <= sillabe <= 20:
        raise ErroreValore(f"`sillabe` deve essere tra 3 e 20 (hai scritto {mostra(sillabe)}).")
    pezzi = [secrets.choice(_CONSONANTI) + secrets.choice(_VOCALI) for _ in range(sillabe)]
    testo = "".join(pezzi)
    if con_numero:
        testo += str(secrets.randbelow(100)).zfill(2)
    return testo


@funzione_libreria("genera_pin")
def genera_pin(cifre=6):
    """genera_pin(cifre = 6): un PIN numerico casuale che evita gli schemi deboli (1234, 1111, anni, date).

    Usa il generatore crittografico del sistema. Esempio: `genera_pin(6)` è per esempio "804137".
    """
    richiedi_intero(cifre, "genera_pin", "cifre")
    if not 4 <= cifre <= 12:
        raise ErroreValore(f"`cifre` di `genera_pin` deve essere tra 4 e 12 (hai scritto {mostra(cifre)}).")
    for _ in range(1000):
        pin = "".join(secrets.choice(_SIMBOLI_PIN) for _ in range(cifre))
        if len(set(pin)) < 2 or _ha_sequenza(pin, 3) or _ha_ripetizioni(pin):
            continue
        if pin[:2] in ("19", "20") and cifre == 4:   # sembra un anno
            continue
        return pin
    return pin  # pragma: no cover - praticamente impossibile


# ===========================================================================
# Codici OTP a tempo (TOTP, RFC 6238) e a contatore (HOTP, RFC 4226)
# ===========================================================================

_ALGORITMI_OTP = {"sha1": hashlib.sha1, "sha256": hashlib.sha256, "sha512": hashlib.sha512}


def _segreto_otp_byte(segreto: Any, nome_funzione: str) -> bytes:
    richiedi_testo(segreto, nome_funzione, "segreto")
    pulito = segreto.strip().replace(" ", "").replace("-", "").upper()
    pulito += "=" * (-len(pulito) % 8)
    try:
        grezzo = base64.b32decode(pulito, casefold=True)
    except (binascii.Error, ValueError):
        raise ErroreValore(f"`{nome_funzione}`: il segreto non è in Base32 valido.",
                           suggerimento="Usa un segreto creato con `genera_segreto_otp()`.") from None
    if not grezzo:
        raise ErroreValore(f"`{nome_funzione}`: il segreto è vuoto.")
    return grezzo


def _algoritmo_otp(algoritmo: Any, nome_funzione: str):
    richiedi_testo(algoritmo, nome_funzione, "algoritmo")
    chiave = algoritmo.strip().lower().replace("-", "")
    if chiave not in _ALGORITMI_OTP:
        raise ErroreValore(f"`{nome_funzione}`: algoritmo OTP {mostra(algoritmo)} sconosciuto.",
                           suggerimento='Usa "sha1" (lo standard), "sha256" o "sha512".')
    return _ALGORITMI_OTP[chiave]


def _cifre_otp(cifre: Any, nome_funzione: str) -> int:
    richiedi_intero(cifre, nome_funzione, "cifre")
    if not 6 <= cifre <= 10:
        raise ErroreValore(f"`cifre` di `{nome_funzione}` deve essere tra 6 e 10 (hai scritto {mostra(cifre)}).")
    return cifre


def _hotp(segreto: bytes, contatore: int, cifre: int, hashfn) -> str:
    mac = hmac.new(segreto, struct.pack(">Q", contatore), hashfn).digest()
    offset = mac[-1] & 0x0F
    troncato = struct.unpack(">I", mac[offset:offset + 4])[0] & 0x7FFFFFFF
    return str(troncato % (10 ** cifre)).zfill(cifre)


@funzione_libreria("genera_segreto_otp")
def genera_segreto_otp(byte=20):
    """genera_segreto_otp(byte = 20): un nuovo segreto per i codici OTP, in Base32 (lo standard delle app come Google Authenticator).

    Dà questo segreto UNA volta all'app di autenticazione (o mettilo nel QR con `uri_otp`/`qr_otp_svg`) e tienilo
    al sicuro: con quello si generano i codici a 6 cifre. Esempio: `variabile s = genera_segreto_otp()`.
    """
    richiedi_intero(byte, "genera_segreto_otp", "byte")
    if not 10 <= byte <= 64:
        raise ErroreValore(f"`byte` deve essere tra 10 e 64 (hai scritto {mostra(byte)}).",
                           suggerimento="Lo standard usa 20 byte (160 bit).")
    return base64.b32encode(secrets.token_bytes(byte)).decode("ascii").rstrip("=")


@funzione_libreria("codice_otp")
def codice_otp(segreto, cifre=6, periodo=30, algoritmo="sha1"):
    """codice_otp(segreto, cifre = 6, periodo = 30, algoritmo = "sha1"): il codice OTP di ADESSO per quel segreto.

    È lo stesso codice che mostra l'app di autenticazione. Cambia ogni `periodo` secondi (di solito 30).
    Per proteggere i TUOI account. Esempio: `stampa(codice_otp(mio_segreto))`.
    """
    return codice_otp_a(segreto, int(time.time()), cifre, periodo, algoritmo)


@funzione_libreria("codice_otp_a")
def codice_otp_a(segreto, secondi, cifre=6, periodo=30, algoritmo="sha1"):
    """codice_otp_a(segreto, secondi, cifre = 6, periodo = 30, algoritmo = "sha1"): il codice OTP a un dato istante (in secondi dal 1970).

    Come `codice_otp` ma per un momento preciso: utile per le prove e per capire come funziona.
    Esempio: `codice_otp_a("GEZDGNBVGY3TQOJQGEZDGNBVGY3TQOJQ", 59, 8)` è "94287082".
    """
    grezzo = _segreto_otp_byte(segreto, "codice_otp_a")
    richiedi_intero(secondi, "codice_otp_a", "secondi")
    cifre = _cifre_otp(cifre, "codice_otp_a")
    richiedi_intero(periodo, "codice_otp_a", "periodo")
    if not 1 <= periodo <= 3600:
        raise ErroreValore(f"`periodo` deve essere tra 1 e 3600 secondi (hai scritto {mostra(periodo)}).")
    hashfn = _algoritmo_otp(algoritmo, "codice_otp_a")
    if not 0 <= secondi <= 2 ** 63:
        raise ErroreValore(f"`secondi` di `codice_otp_a` deve essere tra 0 e {2 ** 63} (secondi dal 1970).")
    return _hotp(grezzo, secondi // periodo, cifre, hashfn)


@funzione_libreria("codice_otp_contatore")
def codice_otp_contatore(segreto, contatore, cifre=6, algoritmo="sha1"):
    """codice_otp_contatore(segreto, contatore, cifre = 6, algoritmo = "sha1"): il codice OTP "a contatore" (HOTP) per quel numero.

    Come TOTP ma invece del tempo usa un contatore che avanza di 1 a ogni uso. Esempio: `codice_otp_contatore(s, 0)`.
    """
    grezzo = _segreto_otp_byte(segreto, "codice_otp_contatore")
    richiedi_intero(contatore, "codice_otp_contatore", "contatore")
    if not 0 <= contatore <= 2 ** 63:
        raise ErroreValore(f"`contatore` di `codice_otp_contatore` deve essere tra 0 e {2 ** 63}.")
    cifre = _cifre_otp(cifre, "codice_otp_contatore")
    hashfn = _algoritmo_otp(algoritmo, "codice_otp_contatore")
    return _hotp(grezzo, contatore, cifre, hashfn)


@funzione_libreria("verifica_codice_otp")
def verifica_codice_otp(segreto, codice, finestra=1, cifre=6, periodo=30, algoritmo="sha1"):
    """verifica_codice_otp(segreto, codice, finestra = 1, cifre = 6, periodo = 30, algoritmo = "sha1"): vero se il codice OTP è giusto in questo momento.

    `finestra` accetta anche i codici di poco prima/dopo (per gli orologi non proprio allineati): 1 vuol dire
    i 30 secondi prima e dopo. Il confronto è a tempo costante. Esempio: `verifica_codice_otp(s, chiedi("Codice: "))`.
    """
    grezzo = _segreto_otp_byte(segreto, "verifica_codice_otp")
    richiedi_testo(codice, "verifica_codice_otp", "codice")
    richiedi_intero(finestra, "verifica_codice_otp", "finestra")
    if not 0 <= finestra <= 10:
        raise ErroreValore(f"`finestra` deve essere tra 0 e 10 (hai scritto {mostra(finestra)}).")
    cifre = _cifre_otp(cifre, "verifica_codice_otp")
    richiedi_intero(periodo, "verifica_codice_otp", "periodo")
    if not 1 <= periodo <= 3600:
        raise ErroreValore(f"`periodo` deve essere tra 1 e 3600 secondi (hai scritto {mostra(periodo)}).")
    hashfn = _algoritmo_otp(algoritmo, "verifica_codice_otp")
    pulito = codice.strip().replace(" ", "")
    contatore = int(time.time()) // periodo
    giusto = False
    atteso_byte = pulito.encode("utf-8", "replace")
    for salto in range(-finestra, finestra + 1):
        passo = contatore + salto
        if passo < 0:
            continue
        candidato = _hotp(grezzo, passo, cifre, hashfn).encode("ascii")
        if hmac.compare_digest(candidato, atteso_byte):
            giusto = True
    return giusto


def _testo_breve(valore: Any, nome_funzione: str, parametro: str, massimo: int = 256) -> str:
    richiedi_testo(valore, nome_funzione, parametro)
    if len(valore) > massimo:
        raise ErroreValore(f"`{parametro}` di `{nome_funzione}` è troppo lungo (al massimo {massimo} caratteri).")
    return valore


def _quota_url(testo: str) -> str:
    sicuri = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_.~"
    pezzi = []
    for b in testo.encode("utf-8"):
        c = chr(b)
        pezzi.append(c if c in sicuri else f"%{b:02X}")
    return "".join(pezzi)


@funzione_libreria("uri_otp")
def uri_otp(segreto, conto, emittente="", cifre=6, periodo=30, algoritmo="sha1"):
    """uri_otp(segreto, conto, emittente = "", cifre = 6, periodo = 30, algoritmo = "sha1"): l'indirizzo "otpauth://" da mettere in un QR per configurare l'app.

    `conto` è il tuo nome o email sul servizio; `emittente` è il nome del servizio. Le app di autenticazione
    leggono questo testo (di solito da un QR) e iniziano a mostrare i codici. Esempio: `uri_otp(s, "io@mail.it", "Leo")`.
    """
    grezzo = _segreto_otp_byte(segreto, "uri_otp")       # convalida il segreto
    conto = _testo_breve(conto, "uri_otp", "conto", 128)
    emittente = _testo_breve(emittente, "uri_otp", "emittente", 128)
    cifre = _cifre_otp(cifre, "uri_otp")
    richiedi_intero(periodo, "uri_otp", "periodo")
    if not 1 <= periodo <= 3600:
        raise ErroreValore(f"`periodo` deve essere tra 1 e 3600 secondi (hai scritto {mostra(periodo)}).")
    richiedi_testo(algoritmo, "uri_otp", "algoritmo")
    chiave_alg = algoritmo.strip().lower().replace("-", "")
    if chiave_alg not in _ALGORITMI_OTP:
        raise ErroreValore(f'Algoritmo OTP {mostra(algoritmo)} sconosciuto.', suggerimento='Usa "sha1", "sha256" o "sha512".')
    etichetta = f"{emittente}:{conto}" if emittente else conto
    segreto32 = base64.b32encode(grezzo).decode("ascii").rstrip("=")
    parametri = [f"secret={segreto32}", f"algorithm={chiave_alg.upper()}", f"digits={cifre}", f"period={periodo}"]
    if emittente:
        parametri.append(f"issuer={_quota_url(emittente)}")
    return f"otpauth://totp/{_quota_url(etichetta)}?" + "&".join(parametri)


@funzione_libreria("qr_otp_svg")
def qr_otp_svg(segreto, conto, emittente="", modulo=4):
    """qr_otp_svg(segreto, conto, emittente = ""): un'immagine QR (testo SVG) per configurare l'app di autenticazione.

    Mostra o salva l'SVG e inquadralo con l'app: configurerà l'OTP del tuo account. Esempio:
    `scrivi_testo("otp.svg", qr_otp_svg(s, "io@mail.it", "Leo"))`.
    """
    uri = uri_otp(segreto, conto, emittente)
    richiedi_intero(modulo, "qr_otp_svg", "modulo")
    from ..grafica.servizi import qr
    return qr.svg_qr(uri, modulo=modulo, correzione="M")


@funzione_libreria("salva_qr_otp")
def salva_qr_otp(percorso, segreto, conto, emittente="", modulo=8):
    """salva_qr_otp(percorso, segreto, conto, emittente = ""): salva in un file PNG il QR per configurare l'OTP.

    Inquadra il PNG con l'app di autenticazione. Restituisce il percorso. Esempio:
    `salva_qr_otp("otp.png", s, "io@mail.it", "Leo")`.
    """
    uri = uri_otp(segreto, conto, emittente)
    richiedi_intero(modulo, "salva_qr_otp", "modulo")
    _controlla_percorso(percorso, "salva_qr_otp")
    from ..grafica.servizi import qr
    qr.png_qr(uri, percorso, modulo=modulo)
    return percorso


@funzione_libreria("codice_qr_svg")
def codice_qr_svg(testo, modulo=4, correzione="M"):
    """codice_qr_svg(testo, modulo = 4, correzione = "M"): un codice QR di un testo qualunque, come immagine SVG.

    Comodo per link, contatti, testi brevi. `correzione` è "L", "M", "Q" o "H" (più alto = più resistente).
    Esempio: `scrivi_testo("sito.svg", codice_qr_svg("https://esempio.it"))`.
    """
    richiedi_testo(testo, "codice_qr_svg", "testo")
    richiedi_intero(modulo, "codice_qr_svg", "modulo")
    richiedi_testo(correzione, "codice_qr_svg", "correzione")
    from ..grafica.servizi import qr
    return qr.svg_qr(testo, modulo=modulo, correzione=correzione)


@funzione_libreria("salva_codice_qr")
def salva_codice_qr(percorso, testo, modulo=8, correzione="M"):
    """salva_codice_qr(percorso, testo, modulo = 8, correzione = "M"): salva un codice QR di un testo in un file PNG.

    Restituisce il percorso. Esempio: `salva_codice_qr("sito.png", "https://esempio.it")`.
    """
    richiedi_testo(testo, "salva_codice_qr", "testo")
    richiedi_intero(modulo, "salva_codice_qr", "modulo")
    richiedi_testo(correzione, "salva_codice_qr", "correzione")
    _controlla_percorso(percorso, "salva_codice_qr")
    from ..grafica.servizi import qr
    qr.png_qr(testo, percorso, modulo=modulo, correzione=correzione)
    return percorso


# ===========================================================================
# Controllo delle proprie impostazioni (solo i PROPRI sistemi)
# ===========================================================================

@funzione_libreria("porte_locali_in_ascolto")
def porte_locali_in_ascolto(porte=None):
    """porte_locali_in_ascolto(porte = nulla): quali servizi stanno ascoltando su QUESTO computer (solo 127.0.0.1).

    Controlla alcune porte note (o quelle che indichi tu) SOLO su 127.0.0.1: serve a sapere che cosa hai acceso
    sul tuo computer, non a scansionare altri. Restituisce la lista delle porte in ascolto con il servizio tipico.
    Esempio: `per ogni p in porte_locali_in_ascolto() fai stampa(p["porta"], p["servizio"]) fine`.
    """
    if porte is None:
        da_controllare = sorted(_PORTE_NOTE)
    elif isinstance(porte, list):
        da_controllare = []
        for p in porte:
            if type(p) is not int or not 1 <= p <= 65535:
                raise ErroreValore(f"In `porte_locali_in_ascolto` la porta {mostra(p)} non è un numero da 1 a 65535.")
            da_controllare.append(p)
        if len(da_controllare) > 64:
            raise ErroreValore("`porte_locali_in_ascolto` controlla al massimo 64 porte per volta.",
                               suggerimento="Non è uno scanner di rete: controlla solo i tuoi servizi locali.")
    else:
        raise ErroreTipo(f"`porte` di `porte_locali_in_ascolto` deve essere una lista di numeri o nulla, "
                         f"non {articolo(porte)}.")
    risultato = []
    for p in da_controllare:
        aperta = False
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.25)
        try:
            aperta = s.connect_ex(("127.0.0.1", p)) == 0
        except OSError:
            aperta = False
        finally:
            s.close()
        if aperta:
            risultato.append({"porta": p, "servizio": _PORTE_NOTE.get(p, "servizio sconosciuto")})
    return risultato


def _descrivi_permessi(modo: int) -> dict[str, bool]:
    return {"proprietario_legge": bool(modo & _stat.S_IRUSR),
            "proprietario_scrive": bool(modo & _stat.S_IWUSR),
            "proprietario_esegue": bool(modo & _stat.S_IXUSR),
            "gruppo_legge": bool(modo & _stat.S_IRGRP),
            "gruppo_scrive": bool(modo & _stat.S_IWGRP),
            "altri_leggono": bool(modo & _stat.S_IROTH),
            "altri_scrivono": bool(modo & _stat.S_IWOTH),
            "altri_eseguono": bool(modo & _stat.S_IXOTH)}


@funzione_libreria("permessi_file")
def permessi_file(percorso):
    """permessi_file(percorso): chi può leggere, scrivere ed eseguire un file (i tuoi file), in un dizionario.

    Restituisce `ottale` (per esempio "600"), `e_cartella`, chi legge/scrive/esegue e `solo_proprietario`
    (vero se nessun altro può toccarlo). Su Windows i permessi funzionano in modo diverso: `nota_windows` lo dice.
    Esempio: `permessi_file("chiave.txt")["solo_proprietario"]`.
    """
    _controlla_percorso(percorso, "permessi_file")
    try:
        st = os.stat(percorso)
    except OSError as e:
        raise _errore_file(e, percorso, "leggere") from None
    modo = _stat.S_IMODE(st.st_mode)
    perm = _descrivi_permessi(modo)
    solo_proprietario = not any(modo & b for b in (_stat.S_IRWXG, _stat.S_IRWXO))
    risultato = {"ottale": format(modo, "03o"), "e_cartella": os.path.isdir(percorso),
                 "solo_proprietario": solo_proprietario}
    risultato.update(perm)
    if os.name == "nt":
        risultato["nota_windows"] = ("Su Windows i permessi non si leggono così: usa le proprietà del file o "
                                     "BitLocker/EFS per proteggerlo davvero.")
    return risultato


@funzione_libreria("controlla_permessi_file")
def controlla_permessi_file(percorso):
    """controlla_permessi_file(percorso): avvisi se un tuo file è troppo aperto (lo possono leggere o cambiare altri).

    Restituisce una lista di avvisi in italiano (vuota se va bene). Pensato per file delicati come le chiavi.
    Esempio: `per ogni a in controlla_permessi_file("chiave.txt") fai stampa(a) fine`.
    """
    dati = permessi_file(percorso)
    avvisi: list[str] = []
    if os.name == "nt":
        avvisi.append("Su Windows questo controllo è limitato: proteggi i file delicati con il tuo account e, "
                      "per i segreti, con la cifratura (cifra_file).")
        return avvisi
    nome = "La cartella" if dati["e_cartella"] else "Il file"
    if dati["altri_scrivono"]:
        avvisi.append(f"{nome} è scrivibile da chiunque sul computer: chiudilo con `rendi_file_privato`.")
    if dati["altri_leggono"]:
        avvisi.append(f"{nome} è leggibile da chiunque sul computer: se contiene segreti, usa `rendi_file_privato`.")
    if dati["gruppo_scrive"]:
        avvisi.append(f"{nome} è scrivibile dal gruppo: valuta se serve davvero.")
    return avvisi


@funzione_libreria("rendi_file_privato")
def rendi_file_privato(percorso):
    """rendi_file_privato(percorso): toglie a tutti gli altri il permesso di leggere o scrivere un tuo file (permessi 600).

    Per le cartelle usa 700. Restituisce vero se è riuscito. Su Windows i permessi funzionano diversamente: lì
    restituisce falso e conviene usare la cifratura o le impostazioni dell'account. Esempio: `rendi_file_privato("chiave.txt")`.
    """
    _controlla_percorso(percorso, "rendi_file_privato")
    if not os.path.exists(percorso):
        raise ErroreFile(f"Il file `{percorso}` non esiste.", suggerimento="Controlla il nome e il percorso.")
    if os.name == "nt":
        return False
    if not _rendi_privato(percorso):
        raise ErroreFile(f"Non riesco a cambiare i permessi di `{percorso}`.",
                         suggerimento="Controlla di esserne il proprietario.")
    return True


# ===========================================================================
# Chiavi: parser e impronte
# ===========================================================================

def _grezza_da_testo(testo: Any, atteso_pub: bool, famiglia: str, nome_funzione: str, parametro: str) -> bytes:
    """Byte grezzi (32) di una chiave testuale, controllando famiglia (firma/riservatezza) e privata/pubblica."""
    richiedi_testo(testo, nome_funzione, parametro)
    pulito = testo.strip()
    coppie = {"firma": (_PRE_FIRMA_PRIV, _PRE_FIRMA_PUB), "riservatezza": (_PRE_RIS_PRIV, _PRE_RIS_PUB)}
    priv_atteso, pub_atteso = coppie[famiglia]
    altra = {"firma": coppie["riservatezza"], "riservatezza": coppie["firma"]}[famiglia]
    if pulito.startswith(altra[0]) or pulito.startswith(altra[1]):
        servizio = "le firme" if famiglia == "firma" else "la cifratura"
        raise ErroreValore(f"`{nome_funzione}`: questa chiave è di un altro tipo; qui serve una chiave per {servizio}.",
                           suggerimento="Le chiavi di firma e quelle di cifratura non sono intercambiabili.")
    prefisso = pub_atteso if atteso_pub else priv_atteso
    opposto = priv_atteso if atteso_pub else pub_atteso
    if pulito.startswith(opposto):
        if atteso_pub:
            raise ErroreValore(f"`{nome_funzione}`: hai dato la chiave privata; qui basta (e si deve usare) la pubblica.")
        raise ErroreValore(f"`{nome_funzione}`: hai dato la chiave pubblica; qui serve la chiave privata.")
    if pulito.startswith(prefisso):
        pulito = pulito[len(prefisso):]
    grezza = _da_b64(pulito, nome_funzione)
    if len(grezza) != 32:
        raise ErroreValore(f"`{nome_funzione}`: la `{parametro}` non è una chiave valida.",
                           suggerimento="Usa una chiave creata da Leo (crea_chiavi_firma / crea_chiavi_riservatezza).")
    return grezza


def _pub_grezza(chiave: Any, nome_funzione: str) -> tuple[str, bytes]:
    """(famiglia, byte pubblici) da un dizionario di chiavi o da un testo (privato o pubblico)."""
    if isinstance(chiave, dict):
        if "pubblica" in chiave and isinstance(chiave["pubblica"], str):
            return _pub_grezza(chiave["pubblica"], nome_funzione)
        if "privata" in chiave and isinstance(chiave["privata"], str):
            return _pub_grezza(chiave["privata"], nome_funzione)
        raise ErroreValore(f"`{nome_funzione}`: il dizionario non contiene una chiave \"pubblica\" o \"privata\".")
    richiedi_testo(chiave, nome_funzione, "chiave")
    pulito = chiave.strip()
    moduli = _cryptography(nome_funzione)
    if pulito.startswith(_PRE_FIRMA_PUB):
        return "firma", _grezza_da_testo(pulito, True, "firma", nome_funzione, "chiave")
    if pulito.startswith(_PRE_RIS_PUB):
        return "riservatezza", _grezza_da_testo(pulito, True, "riservatezza", nome_funzione, "chiave")
    if pulito.startswith(_PRE_FIRMA_PRIV):
        grezza = _grezza_da_testo(pulito, False, "firma", nome_funzione, "chiave")
        pub = moduli["ed25519"].Ed25519PrivateKey.from_private_bytes(grezza).public_key()
        return "firma", pub.public_bytes(moduli["serialization"].Encoding.Raw, moduli["serialization"].PublicFormat.Raw)
    if pulito.startswith(_PRE_RIS_PRIV):
        grezza = _grezza_da_testo(pulito, False, "riservatezza", nome_funzione, "chiave")
        pub = moduli["x25519"].X25519PrivateKey.from_private_bytes(grezza).public_key()
        return "riservatezza", pub.public_bytes(moduli["serialization"].Encoding.Raw, moduli["serialization"].PublicFormat.Raw)
    raise ErroreValore(f"`{nome_funzione}`: non riconosco questa chiave.",
                       suggerimento="Usa una chiave creata da `crea_chiavi_firma` o `crea_chiavi_riservatezza`.")


@funzione_libreria("impronta_chiave")
def impronta_chiave(chiave):
    """impronta_chiave(chiave): l'impronta di una chiave (la sua "carta d'identità") per controllarla a colpo d'occhio.

    Vale per una chiave pubblica, privata o un dizionario di chiavi: l'impronta è sempre quella della parte
    pubblica, quindi la puoi confrontare con quella dell'altra persona. Esempio:
    `stampa(impronta_chiave(chiavi["pubblica"]))` è per esempio "SHA256:3a7f:...".
    """
    _famiglia, pub = _pub_grezza(chiave, "impronta_chiave")
    riassunto = hashlib.sha256(pub).digest()
    gruppi = [riassunto[i:i + 2].hex() for i in range(0, 16, 2)]
    return "SHA256:" + ":".join(gruppi)


@funzione_libreria("parole_impronta")
def parole_impronta(chiave, parole=6):
    """parole_impronta(chiave, parole = 6): l'impronta di una chiave come poche parole italiane, da leggere a voce.

    Due persone che leggono la stessa sequenza di parole hanno la stessa chiave: utile per accorgersi se qualcuno
    si è messo in mezzo. Esempio: `stampa(parole_impronta(chiavi["pubblica"]))` è per esempio "faro gatto ...".
    """
    richiedi_intero(parole, "parole_impronta", "parole")
    if not 2 <= parole <= 16:
        raise ErroreValore(f"`parole` deve essere tra 2 e 16 (hai scritto {mostra(parole)}).")
    _famiglia, pub = _pub_grezza(chiave, "parole_impronta")
    riassunto = hashlib.sha256(pub).digest()
    return " ".join(_PAROLE[riassunto[i] % len(_PAROLE)] for i in range(parole))


@funzione_libreria("confronta_chiavi")
def confronta_chiavi(prima, seconda):
    """confronta_chiavi(prima, seconda): vero se due chiavi hanno la stessa parte pubblica (stessa impronta).

    Confronto a tempo costante. Comodo per controllare che una chiave ricevuta sia davvero quella attesa.
    Esempio: `se confronta_chiavi(ricevuta, attesa) allora stampa("Chiave giusta") fine`.
    """
    _f1, p1 = _pub_grezza(prima, "confronta_chiavi")
    _f2, p2 = _pub_grezza(seconda, "confronta_chiavi")
    return hmac.compare_digest(p1, p2)


@funzione_libreria("esporta_chiave_pubblica")
def esporta_chiave_pubblica(chiave):
    """esporta_chiave_pubblica(chiave): il testo della SOLA chiave pubblica, da dare agli altri senza rischi.

    Accetta una chiave privata, una pubblica o un dizionario: restituisce sempre e solo la parte pubblica.
    La chiave privata non esce mai. Esempio: `variabile pub = esporta_chiave_pubblica(chiavi)`.
    """
    famiglia, pub = _pub_grezza(chiave, "esporta_chiave_pubblica")
    prefisso = _PRE_FIRMA_PUB if famiglia == "firma" else _PRE_RIS_PUB
    return prefisso + _b64(pub)


@funzione_libreria("importa_chiave_pubblica")
def importa_chiave_pubblica(testo):
    """importa_chiave_pubblica(testo): controlla e "pulisce" il testo di una chiave pubblica ricevuta da qualcuno.

    Dà errore se per sbaglio è una chiave privata o un testo rovinato. Restituisce la chiave pubblica pronta
    da usare con `cifra_per` o `verifica_firma`. Esempio: `variabile pub = importa_chiave_pubblica(ricevuta)`.
    """
    richiedi_testo(testo, "importa_chiave_pubblica", "testo")
    pulito = testo.strip()
    if pulito.startswith(_PRE_FIRMA_PRIV) or pulito.startswith(_PRE_RIS_PRIV):
        raise ErroreValore("Questa è una chiave PRIVATA: non va importata come pubblica né condivisa.",
                           suggerimento="Chiedi all'altra persona la sua chiave PUBBLICA.")
    if pulito.startswith(_PRE_FIRMA_PUB):
        _grezza_da_testo(pulito, True, "firma", "importa_chiave_pubblica", "testo")
        return _PRE_FIRMA_PUB + pulito[len(_PRE_FIRMA_PUB):].strip()
    if pulito.startswith(_PRE_RIS_PUB):
        _grezza_da_testo(pulito, True, "riservatezza", "importa_chiave_pubblica", "testo")
        return _PRE_RIS_PUB + pulito[len(_PRE_RIS_PUB):].strip()
    raise ErroreValore("Non riconosco questa chiave pubblica.",
                       suggerimento="Deve iniziare con \"ed25519-pubblica:\" o \"x25519-pubblica:\".")


# ===========================================================================
# Salvataggio e caricamento delle chiavi (la privata si salva cifrata)
# ===========================================================================

def _e_testo_chiave(testo: str) -> bool:
    return any(testo.strip().startswith(p) for p in
               (_PRE_FIRMA_PRIV, _PRE_FIRMA_PUB, _PRE_RIS_PRIV, _PRE_RIS_PUB))


@funzione_libreria("salva_chiave")
def salva_chiave(chiave, percorso, password=None, sovrascrivi=False):
    """salva_chiave(chiave, percorso, password = nulla, sovrascrivi = falso): salva una chiave in un file, in modo sicuro.

    Se la chiave è privata e dai una `password`, viene salvata CIFRATA; senza password il file viene reso privato
    (solo tu lo leggi). La chiave pubblica si salva in chiaro. Restituisce il percorso. Esempio:
    `salva_chiave(chiavi["privata"], "mia.chiave", "una frase lunga")`.
    """
    richiedi_testo(chiave, "salva_chiave", "chiave")
    richiedi_logico(sovrascrivi, "salva_chiave", "sovrascrivi")
    testo = chiave.strip()
    if not _e_testo_chiave(testo):
        raise ErroreValore("`salva_chiave`: questo non è il testo di una chiave di Leo.",
                           suggerimento="Passa chiavi[\"privata\"] o chiavi[\"pubblica\"].")
    privata = testo.startswith(_PRE_FIRMA_PRIV) or testo.startswith(_PRE_RIS_PRIV)
    if password is not None:
        richiedi_testo(password, "salva_chiave", "password")
        if not privata:
            raise ErroreValore("La chiave pubblica non va cifrata: si può dare a tutti.",
                               suggerimento="Togli la password per salvare una chiave pubblica.")
        from .binario import cifra_testo
        contenuto = (_PRE_CHIAVE_CIFRATA + cifra_testo(testo, password)).encode("ascii")
    else:
        contenuto = testo.encode("ascii")
    _scrivi_file(percorso, contenuto, sovrascrivi, "salva_chiave", privato=privata)
    return percorso


@funzione_libreria("carica_chiave")
def carica_chiave(percorso, password=None):
    """carica_chiave(percorso, password = nulla): rilegge una chiave salvata con `salva_chiave`.

    Se il file è cifrato serve la `password` giusta. Restituisce il testo della chiave (la privata NON viene
    mai stampata da Leo). Esempio: `variabile priv = carica_chiave("mia.chiave", "una frase lunga")`.
    """
    contenuto = _leggi_file(percorso, "carica_chiave")
    try:
        testo = contenuto.decode("utf-8").strip()
    except UnicodeDecodeError:
        raise ErroreValore(f"`{percorso}` non sembra un file di chiave di Leo.") from None
    if testo.startswith(_PRE_CHIAVE_CIFRATA):
        if password is None:
            raise ErroreValore("Questa chiave è salvata cifrata: serve la password.",
                               suggerimento="Passa la password: `carica_chiave(percorso, password)`.")
        richiedi_testo(password, "carica_chiave", "password")
        from .binario import decifra_testo
        testo = decifra_testo(testo[len(_PRE_CHIAVE_CIFRATA):], password).strip()
    if not _e_testo_chiave(testo):
        raise ErroreValore(f"`{percorso}` non contiene una chiave valida.")
    return testo


# ===========================================================================
# Firme di file e messaggi (Ed25519, stesse chiavi di `crea_chiavi_firma`)
# ===========================================================================

@funzione_libreria("crea_chiavi_riservatezza")
def crea_chiavi_riservatezza():
    """crea_chiavi_riservatezza(): una coppia di chiavi per CIFRARE i messaggi (X25519), in un dizionario.

    "pubblica" si dà a chi deve scriverti in segreto (ci cifra con `cifra_per`); "privata" resta solo tua e
    serve a leggere (`decifra_da`). Diversa dalle chiavi di firma. Esempio: `variabile mie = crea_chiavi_riservatezza()`.
    """
    moduli = _cryptography("crea_chiavi_riservatezza")
    s = moduli["serialization"]
    priv = moduli["x25519"].X25519PrivateKey.generate()
    grezza_priv = priv.private_bytes(s.Encoding.Raw, s.PrivateFormat.Raw, s.NoEncryption())
    grezza_pub = priv.public_key().public_bytes(s.Encoding.Raw, s.PublicFormat.Raw)
    return {"privata": _PRE_RIS_PRIV + _b64(grezza_priv), "pubblica": _PRE_RIS_PUB + _b64(grezza_pub)}


def _ed25519_privata(chiave: Any, nome_funzione: str):
    moduli = _cryptography(nome_funzione)
    grezza = _grezza_da_testo(chiave, False, "firma", nome_funzione, "chiave_privata")
    return moduli, moduli["ed25519"].Ed25519PrivateKey.from_private_bytes(grezza)


@funzione_libreria("firma_file")
def firma_file(percorso, chiave_privata):
    """firma_file(percorso, chiave_privata): la firma digitale (un testo) di un file, con la tua chiave privata di firma.

    Chi ha la tua chiave pubblica controlla con `verifica_firma_file` che il file venga da te e non sia cambiato.
    Esempio: `variabile f = firma_file("programma.zip", chiavi["privata"])`.
    """
    contenuto = _leggi_file(percorso, "firma_file")
    _moduli, priv = _ed25519_privata(chiave_privata, "firma_file")
    return _b64(priv.sign(contenuto))


@funzione_libreria("verifica_firma_file")
def verifica_firma_file(percorso, firma, chiave_pubblica):
    """verifica_firma_file(percorso, firma, chiave_pubblica): vero se la firma del file è giusta per quella chiave pubblica.

    Falso se il file o la firma sono cambiati, o se ha firmato un altro. Esempio:
    `verifica_firma_file("programma.zip", f, pub)`.
    """
    contenuto = _leggi_file(percorso, "verifica_firma_file")
    richiedi_testo(firma, "verifica_firma_file", "firma")
    moduli = _cryptography("verifica_firma_file")
    grezza = _grezza_da_testo(chiave_pubblica, True, "firma", "verifica_firma_file", "chiave_pubblica")
    try:
        firma_grezza = _da_b64(firma, "verifica_firma_file")
    except ErroreValore:
        return False
    if len(firma_grezza) != 64:
        return False
    chiave = moduli["ed25519"].Ed25519PublicKey.from_public_bytes(grezza)
    try:
        chiave.verify(firma_grezza, contenuto)
    except moduli["eccezioni"].InvalidSignature:
        return False
    return True


@funzione_libreria("scrivi_firma_file")
def scrivi_firma_file(percorso, chiave_privata, percorso_firma=None, sovrascrivi=False):
    """scrivi_firma_file(percorso, chiave_privata, percorso_firma = nulla, sovrascrivi = falso): firma un file e salva la firma accanto.

    Senza `percorso_firma` crea un file con ".firma" in fondo al nome. Restituisce il percorso della firma.
    Esempio: `scrivi_firma_file("programma.zip", chiavi["privata"])` crea "programma.zip.firma".
    """
    firma = firma_file(percorso, chiave_privata)
    if percorso_firma is None:
        percorso_firma = str(percorso) + ".firma"
    richiedi_logico(sovrascrivi, "scrivi_firma_file", "sovrascrivi")
    _scrivi_file(percorso_firma, (firma + "\n").encode("ascii"), sovrascrivi, "scrivi_firma_file")
    return percorso_firma


@funzione_libreria("verifica_file_firmato")
def verifica_file_firmato(percorso, chiave_pubblica, percorso_firma=None):
    """verifica_file_firmato(percorso, chiave_pubblica, percorso_firma = nulla): legge il file ".firma" e verifica il file.

    Senza `percorso_firma` cerca il file con ".firma" in fondo al nome. Esempio:
    `verifica_file_firmato("programma.zip", pub)`.
    """
    if percorso_firma is None:
        percorso_firma = str(percorso) + ".firma"
    firma = _leggi_file(percorso_firma, "verifica_file_firmato").decode("utf-8", "replace").strip()
    return verifica_firma_file(percorso, firma, chiave_pubblica)


# ===========================================================================
# Cifratura a chiave pubblica (X25519 + HKDF + AES-256-GCM) e "busta"
# ===========================================================================

def _chiave_condivisa(moduli, condivisa: bytes, pub_eff: bytes, pub_dest: bytes) -> bytes:
    # il sale ha SEMPRE lo stesso ordine (effimera, destinatario): così cifratura e decifratura coincidono.
    hkdf = moduli["HKDF"](algorithm=moduli["hashes"].SHA256(), length=32,
                          salt=pub_eff + pub_dest, info=b"leo-busta-v1")
    return hkdf.derive(condivisa)


def _sigilla(dati: bytes, pub_dest: bytes, nome_funzione: str) -> bytes:
    moduli = _cryptography(nome_funzione)
    s = moduli["serialization"]
    eff = moduli["x25519"].X25519PrivateKey.generate()
    pub_eff = eff.public_key().public_bytes(s.Encoding.Raw, s.PublicFormat.Raw)
    condivisa = eff.exchange(moduli["x25519"].X25519PublicKey.from_public_bytes(pub_dest))
    chiave = _chiave_condivisa(moduli, condivisa, pub_eff, pub_dest)
    nonce = secrets.token_bytes(12)
    testa = _MAGIA_BUSTA1 + bytes((1,)) + pub_eff + nonce
    cifrato = moduli["AESGCM"](chiave).encrypt(nonce, dati, testa)
    return testa + cifrato


def _apri_sigillo(busta: bytes, priv_testo: Any, nome_funzione: str) -> bytes:
    moduli = _cryptography(nome_funzione)
    s = moduli["serialization"]
    testa_len = len(_MAGIA_BUSTA1) + 1 + 32 + 12
    if len(busta) < testa_len + 16 or busta[:4] != _MAGIA_BUSTA1 or busta[4] != 1:
        raise ErroreValore(f"`{nome_funzione}`: questi dati non sono una busta cifrata di Leo.")
    pub_eff = busta[5:37]
    nonce = busta[37:testa_len]
    testa = busta[:testa_len]
    grezza_priv = _grezza_da_testo(priv_testo, False, "riservatezza", nome_funzione, "chiave_privata")
    priv = moduli["x25519"].X25519PrivateKey.from_private_bytes(grezza_priv)
    pub_dest = priv.public_key().public_bytes(s.Encoding.Raw, s.PublicFormat.Raw)
    condivisa = priv.exchange(moduli["x25519"].X25519PublicKey.from_public_bytes(pub_eff))
    chiave = _chiave_condivisa(moduli, condivisa, pub_eff, pub_dest)
    try:
        return moduli["AESGCM"](chiave).decrypt(nonce, busta[testa_len:], testa)
    except moduli["eccezioni"].InvalidTag:
        raise ErroreValore(f"`{nome_funzione}`: non riesco ad aprire la busta (chiave sbagliata o dati modificati).",
                           suggerimento="La busta va aperta con la chiave privata del destinatario giusto.") from None


@funzione_libreria("cifra_per")
def cifra_per(dati, chiave_pubblica):
    """cifra_per(dati, chiave_pubblica): cifra un testo (o byte) in modo che SOLO chi ha la chiave privata possa leggerlo.

    Tu usi solo la chiave PUBBLICA del destinatario: non serve condividere password. Il risultato è un testo.
    Esempio: `variabile busta = cifra_per("Ci vediamo alle 8", pub_di_anna)`.
    """
    contenuto = _in_byte(dati, "cifra_per")
    famiglia, pub = _pub_grezza(chiave_pubblica, "cifra_per")
    if famiglia != "riservatezza":
        raise ErroreValore("`cifra_per`: serve una chiave di cifratura (x25519), non una chiave di firma.",
                           suggerimento="Usa una chiave di `crea_chiavi_riservatezza`.")
    return _b64(_sigilla(contenuto, pub, "cifra_per"))


@funzione_libreria("decifra_da")
def decifra_da(busta, chiave_privata, come_byte=False):
    """decifra_da(busta, chiave_privata, come_byte = falso): legge un messaggio cifrato per te con `cifra_per`.

    Serve la TUA chiave privata di riservatezza. Con `come_byte = vero` restituisce i byte. Esempio:
    `decifra_da(busta, mie["privata"])`.
    """
    richiedi_testo(busta, "decifra_da", "busta")
    richiedi_logico(come_byte, "decifra_da", "come_byte")
    chiaro = _apri_sigillo(_da_b64(busta, "decifra_da"), chiave_privata, "decifra_da")
    if come_byte:
        from .binario import DatiBinari
        return DatiBinari(chiaro)
    try:
        return chiaro.decode("utf-8")
    except UnicodeDecodeError:
        raise ErroreValore("Il contenuto decifrato non è un testo (sono byte).",
                           suggerimento="Aggiungi `come_byte = vero` per avere i dati binari.") from None


@funzione_libreria("cifra_file_per")
def cifra_file_per(percorso, chiave_pubblica, destinazione=None, sovrascrivi=False):
    """cifra_file_per(percorso, chiave_pubblica, destinazione = nulla, sovrascrivi = falso): cifra un file per un destinatario.

    Solo chi ha la chiave privata corrispondente potrà aprirlo con `decifra_file_da`. Senza `destinazione`
    aggiunge ".busta" al nome. Restituisce il percorso. Esempio: `cifra_file_per("foto.jpg", pub_di_anna)`.
    """
    contenuto = _leggi_file(percorso, "cifra_file_per")
    famiglia, pub = _pub_grezza(chiave_pubblica, "cifra_file_per")
    if famiglia != "riservatezza":
        raise ErroreValore("`cifra_file_per`: serve una chiave di cifratura (x25519), non una di firma.")
    if destinazione is None:
        destinazione = str(percorso) + ".busta"
    richiedi_logico(sovrascrivi, "cifra_file_per", "sovrascrivi")
    _scrivi_file(destinazione, _sigilla(contenuto, pub, "cifra_file_per"), sovrascrivi, "cifra_file_per")
    return destinazione


@funzione_libreria("decifra_file_da")
def decifra_file_da(percorso, chiave_privata, destinazione=None, sovrascrivi=False):
    """decifra_file_da(percorso, chiave_privata, destinazione = nulla, sovrascrivi = falso): apre un file cifrato con `cifra_file_per`.

    Serve la tua chiave privata di riservatezza. Senza `destinazione` toglie ".busta" dal nome. Restituisce il
    percorso del file in chiaro. Esempio: `decifra_file_da("foto.jpg.busta", mie["privata"])`.
    """
    contenuto = _leggi_file(percorso, "decifra_file_da")
    chiaro = _apri_sigillo(contenuto, chiave_privata, "decifra_file_da")
    if destinazione is None:
        p = str(percorso)
        destinazione = p[:-len(".busta")] if p.endswith(".busta") else p + ".aperto"
    richiedi_logico(sovrascrivi, "decifra_file_da", "sovrascrivi")
    _scrivi_file(destinazione, chiaro, sovrascrivi, "decifra_file_da")
    return destinazione


def _pubbliche_riservatezza(chiavi: Any, nome_funzione: str) -> list[bytes]:
    if not isinstance(chiavi, list) or not chiavi:
        raise ErroreTipo(f"`{nome_funzione}`: le chiavi dei destinatari devono essere una lista non vuota.")
    if len(chiavi) > 100:
        raise ErroreValore(f"`{nome_funzione}`: al massimo 100 destinatari.")
    grezze: list[bytes] = []
    for ch in chiavi:
        famiglia, pub = _pub_grezza(ch, nome_funzione)
        if famiglia != "riservatezza":
            raise ErroreValore(f"`{nome_funzione}`: tutte le chiavi devono essere di cifratura (x25519).")
        grezze.append(pub)
    return grezze


def _impacchetta_busta(dati: bytes, pubbliche: list[bytes], nome_funzione: str) -> bytes:
    moduli = _cryptography(nome_funzione)
    chiave_dati = secrets.token_bytes(32)
    nonce = secrets.token_bytes(12)
    cifrato = moduli["AESGCM"](chiave_dati).encrypt(nonce, dati, _MAGIA_BUSTAN)
    pezzi = [_MAGIA_BUSTAN, bytes((1,)), struct.pack(">H", len(pubbliche))]
    for pub in pubbliche:
        involto = _sigilla(chiave_dati, pub, nome_funzione)
        pezzi.append(hashlib.sha256(pub).digest()[:8])
        pezzi.append(struct.pack(">H", len(involto)))
        pezzi.append(involto)
    pezzi.append(nonce)
    pezzi.append(cifrato)
    return b"".join(pezzi)


def _spacchetta_busta(busta: bytes, priv_testo: Any, nome_funzione: str) -> bytes:
    moduli = _cryptography(nome_funzione)
    s = moduli["serialization"]
    if len(busta) < 7 or busta[:4] != _MAGIA_BUSTAN or busta[4] != 1:
        raise ErroreValore(f"`{nome_funzione}`: questi dati non sono una busta per più destinatari di Leo.")
    quanti = struct.unpack(">H", busta[5:7])[0]
    i = 7
    grezza_priv = _grezza_da_testo(priv_testo, False, "riservatezza", nome_funzione, "chiave_privata")
    priv = moduli["x25519"].X25519PrivateKey.from_private_bytes(grezza_priv)
    mia_pub = priv.public_key().public_bytes(s.Encoding.Raw, s.PublicFormat.Raw)
    mia_impronta = hashlib.sha256(mia_pub).digest()[:8]
    involti: list[bytes] = []
    for _ in range(quanti):
        if i + 10 > len(busta):
            raise ErroreValore(f"`{nome_funzione}`: la busta è rovinata.")
        impronta = busta[i:i + 8]
        lung = struct.unpack(">H", busta[i + 8:i + 10])[0]
        i += 10
        involto = busta[i:i + lung]
        i += lung
        if hmac.compare_digest(impronta, mia_impronta):
            involti.insert(0, involto)       # prova per primo il mio
        else:
            involti.append(involto)
    corpo = busta[i:]
    if len(corpo) < 12 + 16:
        raise ErroreValore(f"`{nome_funzione}`: la busta è incompleta.")
    nonce, cifrato = corpo[:12], corpo[12:]
    for involto in involti:
        try:
            chiave_dati = _apri_sigillo(involto, priv_testo, nome_funzione)
        except ErroreValore:
            continue
        try:
            return moduli["AESGCM"](chiave_dati).decrypt(nonce, cifrato, _MAGIA_BUSTAN)
        except moduli["eccezioni"].InvalidTag:
            continue
    raise ErroreValore(f"`{nome_funzione}`: questa busta non è stata cifrata per la tua chiave.",
                       suggerimento="Serve la chiave privata di uno dei destinatari.")


@funzione_libreria("busta_per_molti")
def busta_per_molti(dati, chiavi_pubbliche):
    """busta_per_molti(dati, chiavi_pubbliche): cifra un testo (o byte) UNA volta per PIÙ destinatari.

    `chiavi_pubbliche` è la lista delle chiavi pubbliche di riservatezza. Ognuno la aprirà con `apri_busta`
    usando la propria chiave privata. Esempio: `busta_per_molti("Riunione alle 9", [pub_anna, pub_bruno])`.
    """
    contenuto = _in_byte(dati, "busta_per_molti")
    pubbliche = _pubbliche_riservatezza(chiavi_pubbliche, "busta_per_molti")
    return _b64(_impacchetta_busta(contenuto, pubbliche, "busta_per_molti"))


@funzione_libreria("apri_busta")
def apri_busta(busta, chiave_privata, come_byte=False):
    """apri_busta(busta, chiave_privata, come_byte = falso): apre una busta fatta con `busta_per_molti`, se sei un destinatario.

    Serve la tua chiave privata di riservatezza. Esempio: `apri_busta(busta, mie["privata"])`.
    """
    richiedi_testo(busta, "apri_busta", "busta")
    richiedi_logico(come_byte, "apri_busta", "come_byte")
    chiaro = _spacchetta_busta(_da_b64(busta, "apri_busta"), chiave_privata, "apri_busta")
    if come_byte:
        from .binario import DatiBinari
        return DatiBinari(chiaro)
    try:
        return chiaro.decode("utf-8")
    except UnicodeDecodeError:
        raise ErroreValore("Il contenuto non è un testo (sono byte).",
                           suggerimento="Aggiungi `come_byte = vero`.") from None


@funzione_libreria("cifra_file_per_molti")
def cifra_file_per_molti(percorso, chiavi_pubbliche, destinazione=None, sovrascrivi=False):
    """cifra_file_per_molti(percorso, chiavi_pubbliche, destinazione = nulla, sovrascrivi = falso): cifra un file per più destinatari.

    Ognuno lo aprirà con `apri_busta_file` e la propria chiave privata. Senza `destinazione` aggiunge ".busta".
    Restituisce il percorso. Esempio: `cifra_file_per_molti("verbale.pdf", [pub_anna, pub_bruno])`.
    """
    contenuto = _leggi_file(percorso, "cifra_file_per_molti")
    pubbliche = _pubbliche_riservatezza(chiavi_pubbliche, "cifra_file_per_molti")
    if destinazione is None:
        destinazione = str(percorso) + ".busta"
    richiedi_logico(sovrascrivi, "cifra_file_per_molti", "sovrascrivi")
    _scrivi_file(destinazione, _impacchetta_busta(contenuto, pubbliche, "cifra_file_per_molti"),
                 sovrascrivi, "cifra_file_per_molti")
    return destinazione


@funzione_libreria("apri_busta_file")
def apri_busta_file(percorso, chiave_privata, destinazione=None, sovrascrivi=False):
    """apri_busta_file(percorso, chiave_privata, destinazione = nulla, sovrascrivi = falso): apre un file cifrato con `cifra_file_per_molti`.

    Senza `destinazione` toglie ".busta" dal nome. Restituisce il percorso del file in chiaro. Esempio:
    `apri_busta_file("verbale.pdf.busta", mie["privata"])`.
    """
    contenuto = _leggi_file(percorso, "apri_busta_file")
    chiaro = _spacchetta_busta(contenuto, chiave_privata, "apri_busta_file")
    if destinazione is None:
        p = str(percorso)
        destinazione = p[:-len(".busta")] if p.endswith(".busta") else p + ".aperto"
    richiedi_logico(sovrascrivi, "apri_busta_file", "sovrascrivi")
    _scrivi_file(destinazione, chiaro, sovrascrivi, "apri_busta_file")
    return destinazione


# ===========================================================================
# Didattica: sfide "cattura la bandiera" su file locali e riconoscimento attacchi
# ===========================================================================

def _cartella_scrivibile(cartella: Any, nome_funzione: str) -> str:
    _controlla_percorso(cartella, nome_funzione)
    try:
        os.makedirs(cartella, exist_ok=True)
    except OSError as e:
        raise _errore_file(e, cartella, "creare") from None
    return str(cartella)


def _controllo_bandiera(bandiera: str) -> str:
    """Un gettone opaco per verificare la bandiera senza rivelarla (HMAC con chiave fissa didattica)."""
    return hmac.new(b"leo-sfida-didattica", bandiera.encode("utf-8"), hashlib.sha256).hexdigest()


@funzione_libreria("prepara_sfida_segreto")
def prepara_sfida_segreto(cartella):
    """prepara_sfida_segreto(cartella): crea un file con un segreto nascosto dentro, da ritrovare per esercizio.

    Il segreto (la "bandiera") è nascosto in mezzo ad altro testo, codificato in Base64. Restituisce `percorso`,
    un `aiuto` e un `controllo` (gettone per `verifica_bandiera`): la bandiera NON viene svelata. Esempio:
    `variabile sfida = prepara_sfida_segreto("sfide")`.
    """
    base = _cartella_scrivibile(cartella, "prepara_sfida_segreto")
    bandiera = "LEO{" + secrets.token_hex(4) + "}"
    nascosto = base64.b64encode(bandiera.encode("ascii")).decode("ascii")
    riempi = secrets.token_hex(20)
    testo = ("Appunti di laboratorio\n"
             "Riga 1: niente di importante qui.\n"
             f"Rumore: {riempi}\n"
             f"Dato codificato: {nascosto}\n"
             "Fine appunti.\n")
    percorso = os.path.join(base, "sfida_segreto.txt")
    _scrivi_file(percorso, testo.encode("utf-8"), True, "prepara_sfida_segreto")
    return {"percorso": percorso,
            "aiuto": "C'è una riga 'Dato codificato:' in Base64. Decodificala con `decodifica_base64` "
                     "per trovare la bandiera nella forma LEO{...}.",
            "controllo": _controllo_bandiera(bandiera)}


@funzione_libreria("prepara_sfida_cifrata")
def prepara_sfida_cifrata(cartella):
    """prepara_sfida_cifrata(cartella): crea un file cifrato con una password, da decifrare per esercizio.

    Restituisce `percorso`, la `password` (te la dà, è un esercizio di decifratura), un `aiuto` e un `controllo`.
    Decifra il file con `decifra_file` e la password per leggere la bandiera. Esempio: `prepara_sfida_cifrata("sfide")`.
    """
    base = _cartella_scrivibile(cartella, "prepara_sfida_cifrata")
    bandiera = "LEO{" + secrets.token_hex(4) + "}"
    password = genera_frase_password(4)
    testo = f"Complimenti, hai decifrato il file.\nLa bandiera è: {bandiera}\n"
    percorso = os.path.join(base, "sfida_cifrata.leocifrato")
    from .binario import _cifra
    dati_cifrati = _cifra(testo.encode("utf-8"), password, "prepara_sfida_cifrata")
    _scrivi_file(percorso, dati_cifrati, True, "prepara_sfida_cifrata")
    return {"percorso": percorso, "password": password,
            "aiuto": "Usa `decifra_file(percorso, password)` per creare il file in chiaro e leggere la bandiera.",
            "controllo": _controllo_bandiera(bandiera)}


@funzione_libreria("prepara_sfida_firma")
def prepara_sfida_firma(cartella):
    """prepara_sfida_firma(cartella): crea due file quasi uguali ma uno solo è firmato davvero, da riconoscere.

    Restituisce i percorsi dei file e della firma, la `chiave_pubblica` per controllare, un `aiuto` e il
    `controllo`: la bandiera è il nome del file autentico. Usa `verifica_firma_file`. Esempio:
    `prepara_sfida_firma("sfide")`.
    """
    base = _cartella_scrivibile(cartella, "prepara_sfida_firma")
    chiavi = crea_chiavi_firma_interno()
    autentico = "Messaggio ufficiale: la riunione è confermata.\n"
    falso = "Messaggio ufficiale: la riunione è annullata.\n"
    p_autentico = os.path.join(base, "messaggio_A.txt")
    p_falso = os.path.join(base, "messaggio_B.txt")
    _scrivi_file(p_autentico, autentico.encode("utf-8"), True, "prepara_sfida_firma")
    _scrivi_file(p_falso, falso.encode("utf-8"), True, "prepara_sfida_firma")
    firma = firma_file(p_autentico, chiavi["privata"])
    p_firma = os.path.join(base, "messaggio.firma")
    _scrivi_file(p_firma, (firma + "\n").encode("ascii"), True, "prepara_sfida_firma")
    return {"file": [p_autentico, p_falso], "percorso_firma": p_firma, "chiave_pubblica": chiavi["pubblica"],
            "aiuto": "La firma vale per uno solo dei due file. Prova `verifica_firma_file` su ciascuno con la "
                     "chiave pubblica: la bandiera è il nome del file autentico (per esempio messaggio_A.txt).",
            "controllo": _controllo_bandiera(os.path.basename(p_autentico))}


@funzione_libreria("verifica_bandiera")
def verifica_bandiera(controllo, risposta):
    """verifica_bandiera(controllo, risposta): vero se hai trovato la bandiera giusta di una sfida.

    `controllo` è il gettone restituito da `prepara_sfida_...`; `risposta` è la bandiera che hai trovato.
    Il confronto è a tempo costante e non svela la bandiera. Esempio: `verifica_bandiera(sfida["controllo"], trovata)`.
    """
    richiedi_testo(controllo, "verifica_bandiera", "controllo")
    richiedi_testo(risposta, "verifica_bandiera", "risposta")
    atteso = controllo.strip().lower()
    calcolato = _controllo_bandiera(risposta.strip())
    return hmac.compare_digest(atteso.encode("ascii", "replace"), calcolato.encode("ascii"))


@funzione_libreria("mostra_attacco_dizionario")
def mostra_attacco_dizionario(impronta, algoritmo="sha256"):
    """mostra_attacco_dizionario(impronta, algoritmo = "sha256"): perché un'impronta SENZA SALE di una password comune si "rompe".

    Prova le password dell'ELENCO LOCALE: se l'impronta (md5/sha1/sha256...) corrisponde a una di esse, la
    ritrova subito. Serve per capire perché le password NON si salvano come semplice impronta: usa
    `impronta_password` (scrypt con sale). Lavora solo sull'impronta che gli dai TU. Restituisce un dizionario
    con `trovata`, `password` (se trovata) e `spiegazione`. Esempio: `mostra_attacco_dizionario(impronta("123456"))`.
    """
    richiedi_testo(impronta, "mostra_attacco_dizionario", "impronta")
    from .binario import _PASSWORD_COMUNI
    from .sicurezza_dati import impronta as fai_impronta
    bersaglio = impronta.strip().lower()
    trovata = None
    for comune in _PASSWORD_COMUNI:
        if fai_impronta(comune, algoritmo) == bersaglio:
            trovata = comune
            break
    if trovata is not None:
        return {"trovata": True, "password": trovata,
                "spiegazione": ("L'impronta era di una password comune: provando un piccolo elenco locale si "
                                "ritrova in un lampo. Per questo le password si salvano con `impronta_password` "
                                "(scrypt con un sale casuale): due password uguali danno impronte diverse e non "
                                "si possono precalcolare.")}
    return {"trovata": False, "password": None,
            "spiegazione": ("Non è tra le password comuni dell'elenco locale. Resta comunque meglio salvare le "
                            "password con `impronta_password` (sale + scrypt), non come semplice impronta.")}


# Versione interna di crea_chiavi_firma, per non dipendere dall'import pigro di `binario`
def crea_chiavi_firma_interno() -> dict:
    moduli = _cryptography("prepara_sfida_firma")
    s = moduli["serialization"]
    priv = moduli["ed25519"].Ed25519PrivateKey.generate()
    grezza_priv = priv.private_bytes(s.Encoding.Raw, s.PrivateFormat.Raw, s.NoEncryption())
    grezza_pub = priv.public_key().public_bytes(s.Encoding.Raw, s.PublicFormat.Raw)
    return {"privata": _PRE_FIRMA_PRIV + _b64(grezza_priv), "pubblica": _PRE_FIRMA_PUB + _b64(grezza_pub)}
