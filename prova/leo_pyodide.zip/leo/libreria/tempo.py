"""Libreria: ora, oggi, attendi."""

from __future__ import annotations

import datetime
import math
import time

from ..errori import ErroreValore
from ..valori import rappresenta
from .generali import funzione_libreria, richiedi_numero

#: Attesa massima ammessa (un giorno): oltre, quasi certamente è un errore.
ATTESA_MASSIMA = 24 * 60 * 60
#: Durata dei "pezzi" in cui si divide l'attesa, per accorgersi di una richiesta di arresto.
_PEZZO = 0.1


@funzione_libreria("ora")
def ora():
    """ora(): l'ora attuale come testo "HH:MM:SS".

    Esempio: `stampa("Sono le {ora()}")` scrive per esempio "Sono le 09:05:30".
    """
    return datetime.datetime.now().strftime("%H:%M:%S")


@funzione_libreria("oggi")
def oggi():
    """oggi(): la data di oggi come testo "GG/MM/AAAA".

    Esempio: `stampa("Oggi è il {oggi()}")` scrive per esempio "Oggi è il 25/09/2026".
    """
    return datetime.date.today().strftime("%d/%m/%Y")


def _fermato(interprete) -> bool:
    try:
        return bool(getattr(interprete, "fermato", False))
    except Exception:  # noqa: BLE001 - interprete finto o incompleto
        return False


@funzione_libreria("attendi", interprete=True)
def attendi(interprete, secondi):
    """attendi(secondi): aspetta il numero di secondi indicato (anche decimale) prima di continuare.

    Esempio: `attendi(0.5)` aspetta mezzo secondo. In un programma con finestre
    l'interfaccia continua a rispondere mentre aspetti.
    """
    richiedi_numero(secondi, "attendi", "secondi")
    if isinstance(secondi, float) and math.isnan(secondi):
        raise ErroreValore("Non posso attendere `non_numero` secondi.")
    if secondi < 0:
        raise ErroreValore(f"Non posso attendere un tempo negativo ({rappresenta(secondi)} secondi).",
                           suggerimento="Scrivi un numero di secondi uguale o maggiore di 0.")
    if secondi > ATTESA_MASSIMA:
        raise ErroreValore(f"L'attesa di {rappresenta(secondi)} secondi è troppo lunga: "
                           f"il massimo è {ATTESA_MASSIMA} secondi (un giorno).")
    secondi = float(secondi)
    ponte = getattr(interprete, "ponte_grafico", None)
    if ponte is not None:
        ponte.attendi(secondi)
        return None
    # attesa a pezzi: se nel frattempo qualcuno chiede di fermare il programma, smette prima
    fine = time.monotonic() + secondi
    while True:
        rimasto = fine - time.monotonic()
        if rimasto <= 0 or _fermato(interprete):
            break
        time.sleep(min(rimasto, _PEZZO))
    return None
