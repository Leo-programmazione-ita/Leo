"""Libreria: matematica avanzata (frazioni, soldi, complessi, matrici, primi, basi, romani, arrotondamenti).

Completa ``leo.libreria.matematica`` e ``statistica`` senza ripeterne le funzioni:

* tipi con proprietà e metodi: ``frazione`` ("3/4", esatta), ``soldi``
  (decimali precisi con arrotondamento commerciale, "1.234,50 €") e
  ``complesso`` ("3 + 4i"). In Leo gli operatori ``+ - * /`` valgono per i
  numeri: questi tipi si combinano con i metodi ``piu``, ``meno``, ``per``,
  ``diviso`` (per esempio ``a.piu(b)``);
* matrici e vettori come liste (di liste) di numeri: ``somma_matrici``,
  ``prodotto_matrici``, ``trasposta``, ``determinante``, ``inversa``...;
* numeri primi (``e_primo``, ``fattorizza``, ``primi_fino_a``), ``mcd``, ``mcm``;
* basi (``in_binario``, ``numero_in_base``, ``numero_da_base``...) e numeri romani;
* arrotondamenti per difetto, per eccesso, "del banchiere" e al multiplo.
"""

from __future__ import annotations

import cmath
import math
import re
from decimal import (ROUND_CEILING, ROUND_FLOOR, ROUND_HALF_EVEN, ROUND_HALF_UP, Decimal, InvalidOperation,
                     localcontext)
from fractions import Fraction
from typing import Any

from ..errori import ErroreDivisione, ErroreTipo, ErroreValore
from ..valori import e_intero, e_numero, rappresenta
from .generali import (articolo, funzione_libreria, lunghezza_intervallo, mostra, richiedi_intero, richiedi_lista,
                       richiedi_numero, richiedi_testo)
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta


def _troppo_grande() -> ErroreValore:
    return ErroreValore("Il risultato è troppo grande per essere calcolato.")


def _numero_finito(x: Any, nome_funzione: str, parametro: str) -> int | float:
    richiedi_numero(x, nome_funzione, parametro)
    if isinstance(x, float) and (math.isnan(x) or math.isinf(x)):
        raise ErroreValore(f"`{nome_funzione}` non può usare {rappresenta(x)}.")
    return x


def _da_razionale(q: Fraction) -> int | float:
    """Un razionale come valore Leo: intero se possibile, altrimenti decimale."""
    if q.denominator == 1:
        return q.numerator
    try:
        return q.numerator / q.denominator
    except OverflowError:
        raise _troppo_grande() from None


# ===========================================================================
# Frazioni
# ===========================================================================

_RE_FRAZIONE = re.compile(r"\s*([+-]?\d+)\s*/\s*([+-]?\d+)\s*")
_MASSIMI_BIT = 100_000


class FrazioneDante(OggettoLibreria):
    """Valore Leo di tipo ``frazione`` (sempre ridotta ai minimi termini)."""

    NOME_TIPO_DANTE = "frazione"
    SUGGERIMENTO_MODIFICA = "Crea una frazione nuova, per esempio `f = f.piu(frazione(1, 2))`."

    def __init__(self, valore: Fraction) -> None:
        if valore.numerator.bit_length() > _MASSIMI_BIT or valore.denominator.bit_length() > _MASSIMI_BIT:
            raise _troppo_grande()
        self.valore = valore

    def testo_dante(self) -> str:
        q = self.valore
        if q.denominator == 1:
            return rappresenta(q.numerator)
        return f"{rappresenta(q.numerator)}/{rappresenta(q.denominator)}"

    def __eq__(self, altra: object) -> bool:
        return isinstance(altra, FrazioneDante) and altra.valore == self.valore

    def __hash__(self) -> int:
        return hash(self.valore)

    def __repr__(self) -> str:
        return f"FrazioneDante({self.testo_dante()})"


def _razionale(x: Any, nome_funzione: str, parametro: str) -> Fraction:
    """Un valore Leo (frazione, intero, decimale, testo "3/4" o "0.75") come ``Fraction``."""
    if isinstance(x, FrazioneDante):
        return x.valore
    if e_intero(x):
        return Fraction(x)
    if isinstance(x, float):
        _numero_finito(x, nome_funzione, parametro)
        return Fraction(repr(x))  # 0.1 -> 1/10 (come si scrive), non 3602879701896397/36028797018963968
    if isinstance(x, str):
        m = _RE_FRAZIONE.fullmatch(x)
        try:
            if m:
                return Fraction(int(m.group(1)), int(m.group(2)))
            return Fraction(x.strip().replace(",", "."))
        except ZeroDivisionError:
            raise ErroreDivisione(f"La frazione {mostra(x)} ha il denominatore zero.") from None
        except ValueError:
            raise ErroreValore(f"Non capisco la frazione {mostra(x)}.",
                               suggerimento="Scrivila come \"3/4\" oppure come numero decimale \"0.75\".") from None
    raise ErroreTipo(f"L'argomento `{parametro}` di `{nome_funzione}` deve essere una frazione, un numero "
                     f"o un testo come \"3/4\", non {articolo(x)}.")


@funzione_libreria("frazione")
def frazione(numeratore, denominatore=1):
    """frazione(numeratore, denominatore = 1): una frazione esatta, sempre ridotta ai minimi termini.

    Si stampa come "3/4". Accetta anche un testo o un decimale: `frazione("6/8")` è 3/4, `frazione(0.25)` è 1/4.
    Metodi: `piu`, `meno`, `per`, `diviso`, `potenza`, `inversa`, `uguale_a`, `minore_di`, `in_misto`;
    proprietà: `numeratore`, `denominatore`, `valore`.
    Esempio: `frazione(1, 2).piu(frazione(1, 3))` è 5/6.
    """
    alto = _razionale(numeratore, "frazione", "numeratore")
    basso = _razionale(denominatore, "frazione", "denominatore")
    if basso == 0:
        raise ErroreDivisione("Il denominatore di una frazione non può essere zero.")
    return FrazioneDante(alto / basso)


proprieta(FrazioneDante, "numeratore")(lambda f: f.valore.numerator)
proprieta(FrazioneDante, "denominatore")(lambda f: f.valore.denominator)
proprieta(FrazioneDante, "valore")(lambda f: _da_razionale(f.valore))


def _metodo_frazione(nome: str, operazione, spiegazione: str) -> None:
    def calcola(f, altra):
        b = _razionale(altra, nome, "altra")
        return FrazioneDante(operazione(f.valore, b))

    calcola.__doc__ = spiegazione
    metodo_oggetto(FrazioneDante, nome)(calcola)


_metodo_frazione("piu", lambda a, b: a + b, "frazione.piu(altra): la somma, come nuova frazione.")
_metodo_frazione("meno", lambda a, b: a - b, "frazione.meno(altra): la differenza, come nuova frazione.")
_metodo_frazione("per", lambda a, b: a * b, "frazione.per(altra): il prodotto, come nuova frazione.")


@metodo_oggetto(FrazioneDante, "diviso")
def frazione_diviso(f, altra):
    """frazione.diviso(altra): il quoziente, come nuova frazione."""
    b = _razionale(altra, "diviso", "altra")
    if b == 0:
        raise ErroreDivisione("Non si può dividere una frazione per zero.")
    return FrazioneDante(f.valore / b)


@metodo_oggetto(FrazioneDante, "potenza")
def frazione_potenza(f, esponente):
    """frazione.potenza(esponente): la frazione elevata a un intero (anche negativo)."""
    richiedi_intero(esponente, "potenza", "esponente")
    if abs(esponente) > 10_000:
        raise _troppo_grande()
    if esponente < 0 and f.valore == 0:
        raise ErroreDivisione("Zero elevato a un numero negativo non esiste.")
    if max(f.valore.numerator.bit_length(), f.valore.denominator.bit_length()) * abs(esponente) > _MASSIMI_BIT:
        raise _troppo_grande()
    return FrazioneDante(f.valore ** esponente)


@metodo_oggetto(FrazioneDante, "inversa")
def frazione_inversa(f):
    """frazione.inversa(): la frazione capovolta (3/4 diventa 4/3)."""
    if f.valore == 0:
        raise ErroreDivisione("Zero non ha l'inversa.")
    return FrazioneDante(1 / f.valore)


@metodo_oggetto(FrazioneDante, "uguale_a")
def frazione_uguale_a(f, altra):
    """frazione.uguale_a(altra): `vero` se le due frazioni valgono uguale (2/4 è uguale a 1/2)."""
    return f.valore == _razionale(altra, "uguale_a", "altra")


@metodo_oggetto(FrazioneDante, "minore_di")
def frazione_minore_di(f, altra):
    """frazione.minore_di(altra): `vero` se questa frazione è più piccola dell'altra."""
    return f.valore < _razionale(altra, "minore_di", "altra")


@metodo_oggetto(FrazioneDante, "in_misto")
def frazione_in_misto(f):
    """frazione.in_misto(): la frazione come numero misto, per esempio 7/2 diventa "3 e 1/2"."""
    q = f.valore
    segno = "-" if q < 0 else ""
    intera, resto = divmod(abs(q.numerator), q.denominator)
    if resto == 0:
        return segno + rappresenta(intera)
    if intera == 0:
        return f"{segno}{rappresenta(resto)}/{rappresenta(q.denominator)}"
    return f"{segno}{rappresenta(intera)} e {rappresenta(resto)}/{rappresenta(q.denominator)}"


# ===========================================================================
# Soldi (decimali precisi)
# ===========================================================================

_CENTESIMO = Decimal("0.01")
#: Importi oltre questo valore (in valore assoluto) si rifiutano: nessun conto reale li raggiunge.
MASSIMO_SOLDI = Decimal(10) ** 15


def _arrotonda_centesimi(d: Decimal) -> Decimal:
    if not d.is_finite() or abs(d) >= MASSIMO_SOLDI:
        raise ErroreValore("L'importo è troppo grande (al massimo un milione di miliardi).")
    with localcontext() as ctx:
        ctx.prec = 40
        return d.quantize(_CENTESIMO, rounding=ROUND_HALF_UP)


def _decimale_da_testo(t: str, nome_funzione: str) -> Decimal:
    pulito = t.strip().replace("€", "").replace("EUR", "").replace(" ", "").replace("'", "")
    if "," in pulito:  # stile italiano: 1.234,56
        pulito = pulito.replace(".", "").replace(",", ".")
    if not re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)", pulito):
        raise ErroreValore(f"Non capisco l'importo {mostra(t)}.",
                           suggerimento="Scrivilo come \"12,50\", \"1.234,50\" o \"12.50\".")
    if len(pulito) > 40:
        raise ErroreValore("L'importo è troppo grande (al massimo un milione di miliardi).")
    return Decimal(pulito)


def _importo(x: Any, nome_funzione: str, parametro: str) -> Decimal:
    if isinstance(x, SoldiDante):
        return x.valore
    if e_intero(x):
        if abs(x) >= MASSIMO_SOLDI:
            raise ErroreValore("L'importo è troppo grande (al massimo un milione di miliardi).")
        return Decimal(x)
    if isinstance(x, float):
        _numero_finito(x, nome_funzione, parametro)
        return Decimal(repr(x))  # 0.1 resta 0.1 (non 0.1000000000000000055...)
    if isinstance(x, str):
        return _decimale_da_testo(x, nome_funzione)
    raise ErroreTipo(f"L'argomento `{parametro}` di `{nome_funzione}` deve essere un importo (numero, testo "
                     f"come \"12,50\" o valore di tipo `soldi`), non {articolo(x)}.")


def _gruppi_migliaia(cifre: str) -> str:
    gruppi = []
    while len(cifre) > 3:
        gruppi.insert(0, cifre[-3:])
        cifre = cifre[:-3]
    gruppi.insert(0, cifre)
    return ".".join(gruppi)


class SoldiDante(OggettoLibreria):
    """Valore Leo di tipo ``soldi``: un importo preciso al centesimo."""

    NOME_TIPO_DANTE = "soldi"
    SUGGERIMENTO_MODIFICA = "Crea un importo nuovo, per esempio `totale = totale.piu(prezzo)`."

    def __init__(self, valore: Decimal, valuta: str = "€") -> None:
        self.valore = _arrotonda_centesimi(valore)
        self.valuta = valuta

    def testo_dante(self) -> str:
        segno = "-" if self.valore < 0 else ""
        intera, _, decimi = f"{abs(self.valore):.2f}".partition(".")
        testo = f"{segno}{_gruppi_migliaia(intera)},{decimi}"
        return f"{testo} {self.valuta}" if self.valuta else testo

    def __eq__(self, altra: object) -> bool:
        return isinstance(altra, SoldiDante) and (altra.valore, altra.valuta) == (self.valore, self.valuta)

    def __hash__(self) -> int:
        return hash((self.valore, self.valuta))

    def __repr__(self) -> str:
        return f"SoldiDante({self.testo_dante()!r})"


@funzione_libreria("soldi")
def soldi(importo, valuta="€"):
    """soldi(importo, valuta = "€"): un importo preciso al centesimo, con arrotondamento commerciale.

    Niente errori dei decimali: `soldi(0.1).piu(0.2)` è esattamente 0,30 €. Si stampa all'italiana, "1.234,50 €".
    Accetta numeri e testi come "12,50" o "1.234,50". Metodi: `piu`, `meno`, `per`, `diviso`, `percentuale`,
    `con_iva`, `scorpora_iva`, `ripartisci`, `uguale_a`, `maggiore_di`; proprietà: `valore`, `centesimi`, `valuta`.
    Esempio: `soldi("19,99").per(3)` è 59,97 €.
    """
    richiedi_testo(valuta, "soldi", "valuta")
    if isinstance(importo, SoldiDante):
        return SoldiDante(importo.valore, valuta)
    return SoldiDante(_importo(importo, "soldi", "importo"), valuta.strip())


proprieta(SoldiDante, "valore")(lambda s: int(s.valore) if s.valore == s.valore.to_integral_value() else float(s.valore))
proprieta(SoldiDante, "centesimi")(lambda s: int(s.valore * 100))
proprieta(SoldiDante, "valuta")(lambda s: s.valuta)


def _stessa_valuta(s: SoldiDante, altra: Any, nome: str) -> Decimal:
    if isinstance(altra, SoldiDante) and altra.valuta != s.valuta:
        raise ErroreValore(f"Non posso usare `{nome}` con due valute diverse ({s.valuta} e {altra.valuta}).")
    return _importo(altra, nome, "altro")


def _fattore(x: Any, nome_funzione: str, parametro: str) -> Decimal:
    if isinstance(x, SoldiDante):
        raise ErroreTipo(f"`{nome_funzione}` vuole un numero, non un importo: non si moltiplicano soldi per soldi.")
    _numero_finito(x, nome_funzione, parametro)
    if abs(x) >= MASSIMO_SOLDI:
        raise ErroreValore("Il numero è troppo grande.")
    return Decimal(x) if e_intero(x) else Decimal(repr(x))


@metodo_oggetto(SoldiDante, "piu")
def soldi_piu(s, altro):
    """soldi.piu(altro): la somma dei due importi."""
    return SoldiDante(s.valore + _stessa_valuta(s, altro, "piu"), s.valuta)


@metodo_oggetto(SoldiDante, "meno")
def soldi_meno(s, altro):
    """soldi.meno(altro): la differenza dei due importi."""
    return SoldiDante(s.valore - _stessa_valuta(s, altro, "meno"), s.valuta)


@metodo_oggetto(SoldiDante, "per")
def soldi_per(s, numero):
    """soldi.per(numero): l'importo moltiplicato per un numero (per esempio la quantità), arrotondato al centesimo."""
    with localcontext() as ctx:
        ctx.prec = 60
        return SoldiDante(s.valore * _fattore(numero, "per", "numero"), s.valuta)


@metodo_oggetto(SoldiDante, "diviso")
def soldi_diviso(s, numero):
    """soldi.diviso(numero): l'importo diviso per un numero, arrotondato al centesimo (per dividere senza perdere centesimi usa `ripartisci`)."""
    f = _fattore(numero, "diviso", "numero")
    if f == 0:
        raise ErroreDivisione("Non si può dividere un importo per zero.")
    with localcontext() as ctx:
        ctx.prec = 60
        return SoldiDante(s.valore / f, s.valuta)


@metodo_oggetto(SoldiDante, "percentuale")
def soldi_percentuale(s, percento):
    """soldi.percentuale(percento): quella percentuale dell'importo. Esempio: `soldi(200).percentuale(15)` è 30,00 €."""
    with localcontext() as ctx:
        ctx.prec = 60
        return SoldiDante(s.valore * _fattore(percento, "percentuale", "percento") / 100, s.valuta)


@metodo_oggetto(SoldiDante, "con_iva")
def soldi_con_iva(s, aliquota=22):
    """soldi.con_iva(aliquota = 22): l'importo con l'IVA aggiunta. Esempio: `soldi(100).con_iva()` è 122,00 €."""
    a = _fattore(aliquota, "con_iva", "aliquota")
    with localcontext() as ctx:
        ctx.prec = 60
        return SoldiDante(s.valore * (100 + a) / 100, s.valuta)


@metodo_oggetto(SoldiDante, "scorpora_iva")
def soldi_scorpora_iva(s, aliquota=22):
    """soldi.scorpora_iva(aliquota = 22): l'imponibile di un prezzo IVA compresa. Esempio: `soldi(122).scorpora_iva()` è 100,00 €."""
    a = _fattore(aliquota, "scorpora_iva", "aliquota")
    if a <= -100:
        raise ErroreValore("L'aliquota dell'IVA deve essere maggiore di -100.")
    with localcontext() as ctx:
        ctx.prec = 60
        return SoldiDante(s.valore * 100 / (100 + a), s.valuta)


@metodo_oggetto(SoldiDante, "ripartisci")
def soldi_ripartisci(s, parti):
    """soldi.ripartisci(parti): divide l'importo in `parti` quote che sommate danno ESATTAMENTE il totale.

    Esempio: `soldi(100).ripartisci(3)` è [33,34 €, 33,33 €, 33,33 €].
    """
    richiedi_intero(parti, "ripartisci", "parti")
    if not 1 <= parti <= 100_000:
        raise ErroreValore(f"Le parti devono essere da 1 a 100000 (hai scritto {mostra(parti)}).")
    centesimi = int(s.valore * 100)
    base, resto = divmod(abs(centesimi), parti)
    segno = -1 if centesimi < 0 else 1
    return [SoldiDante(Decimal(segno * (base + (1 if i < resto else 0))) / 100, s.valuta) for i in range(parti)]


@metodo_oggetto(SoldiDante, "uguale_a")
def soldi_uguale_a(s, altro):
    """soldi.uguale_a(altro): `vero` se i due importi sono uguali al centesimo."""
    return s.valore == _arrotonda_centesimi(_stessa_valuta(s, altro, "uguale_a"))


@metodo_oggetto(SoldiDante, "maggiore_di")
def soldi_maggiore_di(s, altro):
    """soldi.maggiore_di(altro): `vero` se questo importo è più grande dell'altro."""
    return s.valore > _stessa_valuta(s, altro, "maggiore_di")


# ===========================================================================
# Numeri complessi
# ===========================================================================

def _testo_reale(x: float) -> str:
    if x == int(x) and abs(x) < 1e15:
        return rappresenta(int(x))
    return rappresenta(round(x, 12))


class ComplessoDante(OggettoLibreria):
    """Valore Leo di tipo ``complesso``: un numero con parte reale e parte immaginaria."""

    NOME_TIPO_DANTE = "complesso"
    SUGGERIMENTO_MODIFICA = "Crea un numero nuovo, per esempio `z = z.piu(complesso(0, 1))`."

    def __init__(self, valore: complex) -> None:
        if not (math.isfinite(valore.real) and math.isfinite(valore.imag)):
            raise _troppo_grande()
        self.valore = valore

    def testo_dante(self) -> str:
        a, b = self.valore.real, self.valore.imag
        if b == 0:
            return _testo_reale(a)
        immaginaria = "i" if abs(b) == 1 else _testo_reale(abs(b)) + "i"
        if a == 0:
            return ("-" if b < 0 else "") + immaginaria
        return f"{_testo_reale(a)} {'-' if b < 0 else '+'} {immaginaria}"

    def __eq__(self, altro: object) -> bool:
        return isinstance(altro, ComplessoDante) and altro.valore == self.valore

    def __hash__(self) -> int:
        return hash(self.valore)

    def __repr__(self) -> str:
        return f"ComplessoDante({self.testo_dante()})"


def _in_complesso(x: Any, nome_funzione: str, parametro: str) -> complex:
    if isinstance(x, ComplessoDante):
        return x.valore
    if isinstance(x, str):
        pulito = x.strip().replace(" ", "").replace(",", ".").replace("I", "i")
        try:
            if not pulito or len(pulito) > 100 or "j" in pulito:
                raise ValueError
            valore = complex(pulito.replace("i", "j"))
        except (ValueError, OverflowError):
            raise ErroreValore(f"Non capisco il numero complesso {mostra(x)}.",
                               suggerimento="Scrivilo come \"3+4i\", \"2i\" o \"-1.5-2i\".") from None
        return valore
    try:
        return complex(_numero_finito(x, nome_funzione, parametro))
    except OverflowError:
        raise _troppo_grande() from None


def _complesso_calcolo(f):
    try:
        return ComplessoDante(f())
    except ZeroDivisionError:
        raise ErroreDivisione("Non si può dividere per zero.") from None
    except (OverflowError, ValueError):
        raise _troppo_grande() from None


@funzione_libreria("complesso")
def complesso(reale=0, immaginario=0):
    """complesso(reale = 0, immaginario = 0): un numero complesso, stampato come "3 + 4i".

    Accetta anche un testo: `complesso("3+4i")`. Proprietà: `reale`, `immaginario`, `modulo`,
    `argomento` (in radianti), `argomento_gradi`. Metodi: `piu`, `meno`, `per`, `diviso`,
    `potenza`, `coniugato`, `radice`.
    Esempio: `complesso(3, 4).modulo` è 5.0; `complesso(0, 1).per(complesso(0, 1))` è -1.
    """
    if isinstance(reale, str) and immaginario == 0:
        return ComplessoDante(_in_complesso(reale, "complesso", "reale"))
    a = _numero_finito(reale, "complesso", "reale")
    b = _numero_finito(immaginario, "complesso", "immaginario")
    try:
        return ComplessoDante(complex(float(a), float(b)))
    except OverflowError:
        raise _troppo_grande() from None


def _reale(x: float) -> int | float:
    return int(x) if x == int(x) and abs(x) < 2 ** 53 else x


proprieta(ComplessoDante, "reale")(lambda z: _reale(z.valore.real))
proprieta(ComplessoDante, "immaginario")(lambda z: _reale(z.valore.imag))
proprieta(ComplessoDante, "modulo")(lambda z: abs(z.valore))
proprieta(ComplessoDante, "argomento")(lambda z: cmath.phase(z.valore))
proprieta(ComplessoDante, "argomento_gradi")(lambda z: math.degrees(cmath.phase(z.valore)))


def _metodo_complesso(nome: str, operazione, spiegazione: str) -> None:
    def calcola(z, altro):
        w = _in_complesso(altro, nome, "altro")
        return _complesso_calcolo(lambda: operazione(z.valore, w))

    calcola.__doc__ = spiegazione
    metodo_oggetto(ComplessoDante, nome)(calcola)


_metodo_complesso("piu", lambda a, b: a + b, "complesso.piu(altro): la somma.")
_metodo_complesso("meno", lambda a, b: a - b, "complesso.meno(altro): la differenza.")
_metodo_complesso("per", lambda a, b: a * b, "complesso.per(altro): il prodotto.")
_metodo_complesso("diviso", lambda a, b: a / b, "complesso.diviso(altro): il quoziente.")


@metodo_oggetto(ComplessoDante, "potenza")
def complesso_potenza(z, esponente):
    """complesso.potenza(esponente): il numero elevato a un esponente (intero o decimale)."""
    e = _numero_finito(esponente, "potenza", "esponente")
    if abs(e) > 10_000:
        raise _troppo_grande()
    return _complesso_calcolo(lambda: z.valore ** e)


@metodo_oggetto(ComplessoDante, "coniugato")
def complesso_coniugato(z):
    """complesso.coniugato(): il numero con la parte immaginaria cambiata di segno (3 + 4i diventa 3 - 4i)."""
    return ComplessoDante(z.valore.conjugate())


@metodo_oggetto(ComplessoDante, "radice")
def complesso_radice(z):
    """complesso.radice(): la radice quadrata principale. Esempio: `complesso(-4).radice()` è 2i."""
    return _complesso_calcolo(lambda: cmath.sqrt(z.valore))


# ===========================================================================
# Matrici e vettori (liste di liste di numeri)
# ===========================================================================

MASSIMA_DIMENSIONE = 200
MASSIMA_DIMENSIONE_ELIMINAZIONE = 20


def _elemento_razionale(x: Any, nome_funzione: str) -> Fraction:
    if isinstance(x, bool) or not e_numero(x):
        raise ErroreTipo(f"`{nome_funzione}` lavora solo con numeri, ma ha trovato {articolo(x)}.")
    if isinstance(x, float):
        if math.isnan(x) or math.isinf(x):
            raise ErroreValore(f"`{nome_funzione}` non può usare {rappresenta(x)}.")
        return Fraction(repr(x))
    return Fraction(x)


def _matrice(m: Any, nome_funzione: str, parametro: str = "matrice") -> list[list[Fraction]]:
    if not isinstance(m, list) or not m:
        raise ErroreTipo(f"L'argomento `{parametro}` di `{nome_funzione}` deve essere una matrice: una lista di righe, "
                         f"per esempio [[1, 2], [3, 4]]; non {articolo(m) if m != [] else 'una lista vuota'}.")
    if len(m) > MASSIMA_DIMENSIONE:
        raise ErroreValore(f"La matrice di `{nome_funzione}` è troppo grande (al massimo {MASSIMA_DIMENSIONE} righe).")
    righe = []
    colonne = None
    for i, riga in enumerate(m):
        if not isinstance(riga, list) or not riga:
            raise ErroreTipo(f"In `{nome_funzione}` ogni riga della matrice deve essere una lista di numeri: "
                             f"la riga {i + 1} è {articolo(riga)}.",
                             suggerimento="Un vettore semplice va scritto come matrice di una riga: [[1, 2, 3]].")
        if colonne is None:
            colonne = len(riga)
            if colonne > MASSIMA_DIMENSIONE:
                raise ErroreValore(f"La matrice di `{nome_funzione}` è troppo grande "
                                   f"(al massimo {MASSIMA_DIMENSIONE} colonne).")
        elif len(riga) != colonne:
            raise ErroreValore(f"In `{nome_funzione}` le righe della matrice hanno lunghezze diverse "
                               f"(la riga 1 ha {colonne} numeri, la riga {i + 1} ne ha {len(riga)}).")
        righe.append([_elemento_razionale(x, nome_funzione) for x in riga])
    return righe


def _vettore(v: Any, nome_funzione: str, parametro: str) -> list[Fraction]:
    richiedi_lista(v, nome_funzione, parametro)
    if not v:
        raise ErroreValore(f"Il vettore `{parametro}` di `{nome_funzione}` è vuoto.")
    if len(v) > 100_000:
        raise ErroreValore(f"Il vettore di `{nome_funzione}` è troppo lungo.")
    return [_elemento_razionale(x, nome_funzione) for x in v]


def _uscita(m: list[list[Fraction]]) -> list[list[int | float]]:
    return [[_da_razionale(x) for x in riga] for riga in m]


def _stesse_dimensioni(a: list, b: list, nome_funzione: str) -> None:
    if len(a) != len(b) or len(a[0]) != len(b[0]):
        raise ErroreValore(f"`{nome_funzione}` vuole due matrici con le stesse dimensioni "
                           f"({len(a)}x{len(a[0])} e {len(b)}x{len(b[0])} sono diverse).")


@funzione_libreria("somma_matrici")
def somma_matrici(a, b):
    """somma_matrici(a, b): la somma elemento per elemento di due matrici con le stesse dimensioni.

    Esempio: `somma_matrici([[1, 2], [3, 4]], [[10, 20], [30, 40]])` è [[11, 22], [33, 44]].
    """
    x, y = _matrice(a, "somma_matrici", "a"), _matrice(b, "somma_matrici", "b")
    _stesse_dimensioni(x, y, "somma_matrici")
    return _uscita([[p + q for p, q in zip(r, s)] for r, s in zip(x, y)])


@funzione_libreria("sottrai_matrici")
def sottrai_matrici(a, b):
    """sottrai_matrici(a, b): la differenza elemento per elemento (a meno b).

    Esempio: `sottrai_matrici([[5, 5]], [[1, 2]])` è [[4, 3]].
    """
    x, y = _matrice(a, "sottrai_matrici", "a"), _matrice(b, "sottrai_matrici", "b")
    _stesse_dimensioni(x, y, "sottrai_matrici")
    return _uscita([[p - q for p, q in zip(r, s)] for r, s in zip(x, y)])


@funzione_libreria("scala_matrice")
def scala_matrice(matrice, numero):
    """scala_matrice(matrice, numero): la matrice con ogni elemento moltiplicato per il numero.

    Esempio: `scala_matrice([[1, 2], [3, 4]], 10)` è [[10, 20], [30, 40]].
    """
    m = _matrice(matrice, "scala_matrice")
    k = _elemento_razionale(numero, "scala_matrice")
    return _uscita([[x * k for x in riga] for riga in m])


@funzione_libreria("prodotto_matrici")
def prodotto_matrici(a, b):
    """prodotto_matrici(a, b): il prodotto righe per colonne (le colonne di `a` devono essere quante le righe di `b`).

    Esempio: `prodotto_matrici([[1, 2], [3, 4]], [[5], [6]])` è [[17], [39]].
    """
    x, y = _matrice(a, "prodotto_matrici", "a"), _matrice(b, "prodotto_matrici", "b")
    if len(x[0]) != len(y):
        raise ErroreValore(f"Per moltiplicare le matrici, le colonne della prima ({len(x[0])}) devono essere "
                           f"quante le righe della seconda ({len(y)}).")
    colonne = list(zip(*y))
    return _uscita([[sum((p * q for p, q in zip(riga, col)), Fraction(0)) for col in colonne] for riga in x])


@funzione_libreria("trasposta")
def trasposta(matrice):
    """trasposta(matrice): la matrice con righe e colonne scambiate.

    Esempio: `trasposta([[1, 2, 3], [4, 5, 6]])` è [[1, 4], [2, 5], [3, 6]].
    """
    m = _matrice(matrice, "trasposta")
    return _uscita([list(col) for col in zip(*m)])


@funzione_libreria("matrice_identita")
def matrice_identita(dimensione):
    """matrice_identita(dimensione): la matrice quadrata con 1 sulla diagonale e 0 altrove.

    Esempio: `matrice_identita(2)` è [[1, 0], [0, 1]].
    """
    richiedi_intero(dimensione, "matrice_identita", "dimensione")
    if not 1 <= dimensione <= MASSIMA_DIMENSIONE:
        raise ErroreValore(f"La dimensione deve essere tra 1 e {MASSIMA_DIMENSIONE} (hai scritto {mostra(dimensione)}).")
    return [[1 if i == j else 0 for j in range(dimensione)] for i in range(dimensione)]


def _quadrata(matrice: Any, nome_funzione: str) -> list[list[Fraction]]:
    m = _matrice(matrice, nome_funzione)
    if len(m) != len(m[0]):
        raise ErroreValore(f"`{nome_funzione}` vuole una matrice quadrata (tante righe quante colonne), "
                           f"non {len(m)}x{len(m[0])}.")
    if len(m) > MASSIMA_DIMENSIONE_ELIMINAZIONE:
        raise ErroreValore(f"`{nome_funzione}` lavora con matrici fino a "
                           f"{MASSIMA_DIMENSIONE_ELIMINAZIONE}x{MASSIMA_DIMENSIONE_ELIMINAZIONE}.")
    return m


def _elimina(m: list[list[Fraction]], destra: list[list[Fraction]] | None):
    """Eliminazione di Gauss-Jordan esatta: (determinante, destra ridotta o None)."""
    n = len(m)
    a = [riga[:] + (destra[i][:] if destra else []) for i, riga in enumerate(m)]
    det = Fraction(1)
    for c in range(n):
        perno = next((r for r in range(c, n) if a[r][c] != 0), None)
        if perno is None:
            return Fraction(0), None
        if perno != c:
            a[c], a[perno] = a[perno], a[c]
            det = -det
        p = a[c][c]
        det *= p
        a[c] = [x / p for x in a[c]]
        for r in range(n):
            if r != c and a[r][c] != 0:
                k = a[r][c]
                a[r] = [x - k * y for x, y in zip(a[r], a[c])]
    return det, [riga[n:] for riga in a] if destra else None


@funzione_libreria("determinante")
def determinante(matrice):
    """determinante(matrice): il determinante di una matrice quadrata (calcolo esatto con gli interi).

    Esempi: `determinante([[1, 2], [3, 4]])` è -2; `determinante([[2]])` è 2.
    """
    det, _ = _elimina(_quadrata(matrice, "determinante"), None)
    return _da_razionale(det)


@funzione_libreria("inversa")
def inversa(matrice):
    """inversa(matrice): la matrice inversa (moltiplicata per l'originale dà la matrice identità).

    Esempio: `inversa([[2, 0], [0, 4]])` è [[0.5, 0], [0, 0.25]]. Se il determinante è 0 l'inversa non esiste.
    """
    m = _quadrata(matrice, "inversa")
    identita = [[Fraction(int(i == j)) for j in range(len(m))] for i in range(len(m))]
    det, risultato = _elimina(m, identita)
    if det == 0 or risultato is None:
        raise ErroreValore("Questa matrice non ha l'inversa: il suo determinante è 0.",
                           suggerimento="Succede quando una riga è combinazione delle altre (per esempio due righe uguali).")
    return _uscita(risultato)


@funzione_libreria("somma_vettori")
def somma_vettori(v, w):
    """somma_vettori(v, w): la somma elemento per elemento di due vettori della stessa lunghezza.

    Esempio: `somma_vettori([1, 2, 3], [10, 20, 30])` è [11, 22, 33].
    """
    a, b = _vettore(v, "somma_vettori", "v"), _vettore(w, "somma_vettori", "w")
    if len(a) != len(b):
        raise ErroreValore(f"I vettori di `somma_vettori` hanno lunghezze diverse ({len(a)} e {len(b)}).")
    return [_da_razionale(x + y) for x, y in zip(a, b)]


@funzione_libreria("prodotto_scalare")
def prodotto_scalare(v, w):
    """prodotto_scalare(v, w): la somma dei prodotti elemento per elemento di due vettori.

    Esempio: `prodotto_scalare([1, 2, 3], [4, 5, 6])` è 32.
    """
    a, b = _vettore(v, "prodotto_scalare", "v"), _vettore(w, "prodotto_scalare", "w")
    if len(a) != len(b):
        raise ErroreValore(f"I vettori di `prodotto_scalare` hanno lunghezze diverse ({len(a)} e {len(b)}).")
    return _da_razionale(sum((x * y for x, y in zip(a, b)), Fraction(0)))


@funzione_libreria("prodotto_vettoriale")
def prodotto_vettoriale(v, w):
    """prodotto_vettoriale(v, w): il prodotto vettoriale di due vettori a 3 componenti.

    Esempio: `prodotto_vettoriale([1, 0, 0], [0, 1, 0])` è [0, 0, 1].
    """
    a, b = _vettore(v, "prodotto_vettoriale", "v"), _vettore(w, "prodotto_vettoriale", "w")
    if len(a) != 3 or len(b) != 3:
        raise ErroreValore("Il prodotto vettoriale si fa tra due vettori di 3 numeri, come [1, 0, 0].")
    return [_da_razionale(x) for x in (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])]


@funzione_libreria("norma_vettore")
def norma_vettore(v):
    """norma_vettore(v): la lunghezza del vettore (radice della somma dei quadrati).

    Esempio: `norma_vettore([3, 4])` è 5.0.
    """
    a = _vettore(v, "norma_vettore", "v")
    try:
        return math.hypot(*(float(x) for x in a))
    except OverflowError:
        raise _troppo_grande() from None


# ===========================================================================
# Numeri primi, mcd, mcm
# ===========================================================================

_BASI_MR = (2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71)
MASSIMO_BIT_PRIMO = 4096
MASSIMO_FATTORIZZA = 10 ** 24
MASSIMO_PRIMI_FINO_A = 10_000_000


def _intero_positivo_limitato(n: Any, nome_funzione: str, parametro: str = "n") -> int:
    richiedi_intero(n, nome_funzione, parametro)
    return n


def _e_primo(n: int) -> bool:
    if n < 2:
        return False
    for p in _BASI_MR:
        if n % p == 0:
            return n == p
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    for a in _BASI_MR:  # deterministico sotto 3.3 * 10^24, praticamente certo oltre
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(s - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True


@funzione_libreria("e_primo")
def e_primo(n):
    """e_primo(n): `vero` se il numero intero è primo (divisibile solo per 1 e per se stesso).

    Veloce anche con numeri enormi. Esempi: `e_primo(97)` è `vero`; `e_primo(91)` è `falso` (7 x 13).
    """
    _intero_positivo_limitato(n, "e_primo")
    if n.bit_length() > MASSIMO_BIT_PRIMO:
        raise ErroreValore(f"Il numero è troppo grande per `e_primo` (al massimo {MASSIMO_BIT_PRIMO} bit).")
    return _e_primo(n)


def _rho(n: int) -> int | None:
    """Un divisore non banale di n (composto, dispari) con Pollard-Brent, o None."""
    for c in range(1, 40):
        y, m, g, r, q = 2, 128, 1, 1, 1
        x = ys = 2
        passi = 0
        while g == 1:
            x = y
            for _ in range(r):
                y = (y * y + c) % n
            k = 0
            while k < r and g == 1:
                ys = y
                for _ in range(min(m, r - k)):
                    y = (y * y + c) % n
                    q = q * abs(x - y) % n
                g = math.gcd(q, n)
                k += m
            r *= 2
            passi += r
            if passi > 5_000_000:
                return None
        if g == n:
            g = 1
            while g == 1:
                ys = (ys * ys + c) % n
                g = math.gcd(abs(x - ys), n)
        if g != n:
            return g
    return None


def _fattori(n: int) -> list[int]:
    fattori = []
    for p in (2, 3, 5):
        while n % p == 0:
            fattori.append(p)
            n //= p
    d, passi = 7, (4, 2, 4, 2, 4, 6, 2, 6)
    i = 0
    while d * d <= n and d < 10_000:
        while n % d == 0:
            fattori.append(d)
            n //= d
        d += passi[i]
        i = (i + 1) % 8
    da_fare = [n] if n > 1 else []
    while da_fare:
        m = da_fare.pop()
        if _e_primo(m):
            fattori.append(m)
            continue
        divisore = _rho(m)
        if divisore is None:
            raise ErroreValore("Non riesco a scomporre questo numero in un tempo ragionevole.")
        da_fare += [divisore, m // divisore]
    return sorted(fattori)


@funzione_libreria("fattorizza")
def fattorizza(n):
    """fattorizza(n): la lista dei fattori primi del numero (ripetuti quante volte servono), in ordine.

    Esempi: `fattorizza(360)` è [2, 2, 2, 3, 3, 5]; `fattorizza(97)` è [97].
    """
    _intero_positivo_limitato(n, "fattorizza")
    if n < 2:
        raise ErroreValore(f"Si scompongono in fattori primi i numeri da 2 in su, non {mostra(n)}.")
    if n > MASSIMO_FATTORIZZA:
        raise ErroreValore("Il numero è troppo grande per `fattorizza` (al massimo 10^24).")
    return _fattori(n)


@funzione_libreria("primi_fino_a")
def primi_fino_a(n):
    """primi_fino_a(n): la lista dei numeri primi da 2 fino a `n` compreso (crivello di Eratostene).

    Esempio: `primi_fino_a(20)` è [2, 3, 5, 7, 11, 13, 17, 19].
    """
    _intero_positivo_limitato(n, "primi_fino_a")
    if n > MASSIMO_PRIMI_FINO_A:
        raise ErroreValore(f"`primi_fino_a` arriva al massimo a {MASSIMO_PRIMI_FINO_A}.",
                           suggerimento="Per un numero solo usa `e_primo(n)`.")
    if n < 2:
        return []
    crivello = bytearray([1]) * (n + 1)
    crivello[0] = crivello[1] = 0
    for i in range(2, math.isqrt(n) + 1):
        if crivello[i]:
            crivello[i * i::i] = bytes(len(range(i * i, n + 1, i)))
    return [i for i in range(n + 1) if crivello[i]]


def _interi_da(valori: tuple, nome_funzione: str) -> list[int]:
    if len(valori) == 1 and isinstance(valori[0], (list, range)):
        dati = valori[0]
        if isinstance(dati, range):
            if lunghezza_intervallo(dati) > 1_000_000:
                raise ErroreValore(f"L'intervallo è troppo grande per `{nome_funzione}`.")
            dati = list(dati)
        if not dati:
            raise ErroreValore(f"`{nome_funzione}` di una lista vuota non esiste.")
    elif len(valori) >= 2:
        dati = list(valori)
    else:
        raise ErroreTipo(f"`{nome_funzione}` vuole almeno due numeri interi, oppure una lista.",
                         suggerimento=f"Esempi: `{nome_funzione}(12, 18)` oppure `{nome_funzione}([12, 18, 30])`.")
    for v in dati:
        richiedi_intero(v, nome_funzione, "numeri")
        if v.bit_length() > _MASSIMI_BIT:
            raise _troppo_grande()
    return dati


@funzione_libreria("mcd")
def mcd(*numeri):
    """mcd(a, b, ...) oppure mcd(lista): il massimo comun divisore di numeri interi.

    Esempi: `mcd(12, 18)` è 6; `mcd([12, 18, 30])` è 6.
    """
    dati = _interi_da(numeri, "mcd")
    risultato = 0
    for v in dati:
        risultato = math.gcd(risultato, v)
    return risultato


@funzione_libreria("mcm")
def mcm(*numeri):
    """mcm(a, b, ...) oppure mcm(lista): il minimo comune multiplo di numeri interi.

    Esempi: `mcm(4, 6)` è 12; `mcm([2, 3, 4])` è 12.
    """
    dati = _interi_da(numeri, "mcm")
    risultato = 1
    for v in dati:
        if v == 0:
            return 0
        risultato = abs(risultato * v) // math.gcd(risultato, v)
        if risultato.bit_length() > _MASSIMI_BIT:
            raise _troppo_grande()
    return risultato


# ===========================================================================
# Basi e numeri romani
# ===========================================================================

_CIFRE = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
MASSIMI_BIT_BASE = 20_000


def _base(base: Any, nome_funzione: str) -> int:
    richiedi_intero(base, nome_funzione, "base")
    if not 2 <= base <= 36:
        raise ErroreValore(f"La base deve essere un numero da 2 a 36, non {mostra(base)}.",
                           suggerimento="Le basi più usate sono 2 (binario), 8 (ottale), 10 e 16 (esadecimale).")
    return base


def _in_base(n: int, base: int, cifre_minime: int) -> str:
    if n.bit_length() > MASSIMI_BIT_BASE:
        raise _troppo_grande()
    segno = "-" if n < 0 else ""
    n = abs(n)
    if base == 2:
        testo = format(n, "b")
    elif base == 8:
        testo = format(n, "o")
    elif base == 16:
        testo = format(n, "X")
    elif base == 10:
        testo = str(n)
    else:
        pezzi = []
        while n:
            n, r = divmod(n, base)
            pezzi.append(_CIFRE[r])
        testo = "".join(reversed(pezzi)) or "0"
    return segno + testo.rjust(cifre_minime, "0")


def _cifre_minime(cifre: Any, nome_funzione: str) -> int:
    richiedi_intero(cifre, nome_funzione, "cifre")
    if not 0 <= cifre <= 1000:
        raise ErroreValore(f"`cifre` di `{nome_funzione}` deve essere tra 0 e 1000.")
    return cifre


@funzione_libreria("numero_in_base")
def numero_in_base(n, base, cifre=0):
    """numero_in_base(n, base, cifre = 0): il numero intero scritto in una base da 2 a 36, come testo.

    `cifre` aggiunge zeri davanti fino a quella lunghezza. Esempi: `numero_in_base(255, 16)` è "FF";
    `numero_in_base(5, 2, 8)` è "00000101"; `numero_in_base(35, 36)` è "Z".
    """
    richiedi_intero(n, "numero_in_base", "n")
    return _in_base(n, _base(base, "numero_in_base"), _cifre_minime(cifre, "numero_in_base"))


@funzione_libreria("numero_da_base")
def numero_da_base(testo, base):
    """numero_da_base(testo, base): il numero intero scritto nel testo in quella base (spazi e `_` ignorati).

    Esempi: `numero_da_base("FF", 16)` è 255; `numero_da_base("1010", 2)` è 10; `numero_da_base("0x1F", 16)` è 31.
    """
    richiedi_testo(testo, "numero_da_base", "testo")
    b = _base(base, "numero_da_base")
    pulito = "".join(testo.split()).replace("_", "")
    segno = 1
    if pulito[:1] in "+-" and pulito:
        segno = -1 if pulito[0] == "-" else 1
        pulito = pulito[1:]
    prefissi = {2: "0b", 8: "0o", 16: "0x"}
    if b in prefissi and pulito.lower().startswith(prefissi[b]):
        pulito = pulito[2:]
    if not pulito or len(pulito) > 10_000:
        raise ErroreValore(f"Il testo {mostra(testo)} non è un numero in base {b}.")
    for c in pulito:
        if c.upper() not in _CIFRE[:b]:
            raise ErroreValore(f"Il carattere {mostra(c)} non è una cifra valida in base {b}.",
                               suggerimento=f"In base {b} le cifre sono {_CIFRE[0]}-{_CIFRE[b - 1]}.")
    return segno * int(pulito, b)


@funzione_libreria("in_binario")
def in_binario(n, cifre=0):
    """in_binario(n, cifre = 0): il numero intero scritto in base 2. Esempio: `in_binario(10)` è "1010"; `in_binario(5, 8)` è "00000101"."""
    richiedi_intero(n, "in_binario", "n")
    return _in_base(n, 2, _cifre_minime(cifre, "in_binario"))


@funzione_libreria("in_ottale")
def in_ottale(n, cifre=0):
    """in_ottale(n, cifre = 0): il numero intero scritto in base 8. Esempio: `in_ottale(64)` è "100"."""
    richiedi_intero(n, "in_ottale", "n")
    return _in_base(n, 8, _cifre_minime(cifre, "in_ottale"))


@funzione_libreria("in_esadecimale")
def in_esadecimale(n, cifre=0):
    """in_esadecimale(n, cifre = 0): il numero intero scritto in base 16 (cifre 0-9 e A-F). Esempio: `in_esadecimale(255)` è "FF"."""
    richiedi_intero(n, "in_esadecimale", "n")
    return _in_base(n, 16, _cifre_minime(cifre, "in_esadecimale"))


_ROMANI = [(1000, "M"), (900, "CM"), (500, "D"), (400, "CD"), (100, "C"), (90, "XC"),
           (50, "L"), (40, "XL"), (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")]


def _romano(n: int) -> str:
    pezzi = []
    for valore, simbolo in _ROMANI:
        q, n = divmod(n, valore)
        pezzi.append(simbolo * q)
    return "".join(pezzi)


@funzione_libreria("in_romano")
def in_romano(n):
    """in_romano(n): il numero (da 1 a 3999) scritto in numeri romani.

    Esempi: `in_romano(2026)` è "MMXXVI"; `in_romano(49)` è "XLIX".
    """
    richiedi_intero(n, "in_romano", "n")
    if not 1 <= n <= 3999:
        raise ErroreValore(f"I numeri romani vanno da 1 a 3999, non {mostra(n)}.",
                           suggerimento="I Romani non avevano lo zero né i numeri negativi.")
    return _romano(n)


@funzione_libreria("da_romano")
def da_romano(testo):
    """da_romano(testo): il valore di un numero romano scritto correttamente (maiuscole o minuscole).

    Esempi: `da_romano("MMXXVI")` è 2026; `da_romano("xlix")` è 49. Forme scorrette come "IIII" danno errore.
    """
    richiedi_testo(testo, "da_romano", "testo")
    pulito = testo.strip().upper()
    valori = {"I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000}
    if not pulito or len(pulito) > 20 or any(c not in valori for c in pulito):
        raise ErroreValore(f"{mostra(testo)} non è un numero romano.",
                           suggerimento="I numeri romani usano solo le lettere I, V, X, L, C, D, M.")
    totale = 0
    for i, c in enumerate(pulito):
        v = valori[c]
        if i + 1 < len(pulito) and valori[pulito[i + 1]] > v:
            totale -= v
        else:
            totale += v
    if not 1 <= totale <= 3999 or _romano(totale) != pulito:
        corretto = f" Forse volevi scrivere \"{_romano(totale)}\"?" if 1 <= totale <= 3999 else ""
        raise ErroreValore(f"{mostra(testo)} non è scritto secondo le regole dei numeri romani.{corretto}")
    return totale


# ===========================================================================
# Arrotondamenti
# ===========================================================================

def _arrotonda(x: Any, cifre: Any, modo: str, nome_funzione: str) -> int | float:
    _numero_finito(x, nome_funzione, "x")
    richiedi_intero(cifre, nome_funzione, "cifre")
    if not -300 <= cifre <= 300:
        raise ErroreValore(f"`cifre` di `{nome_funzione}` deve essere tra -300 e 300.")
    if isinstance(x, int) and cifre >= 0:
        return x
    valore = Decimal(x) if isinstance(x, int) else Decimal(repr(x))
    with localcontext() as ctx:
        ctx.prec = max(28, abs(valore.adjusted()) + abs(cifre) + 10)
        try:
            risultato = valore.quantize(Decimal(1).scaleb(-cifre), rounding=modo)
        except InvalidOperation:  # pragma: no cover
            raise _troppo_grande() from None
    if cifre <= 0:
        return int(risultato)
    return float(risultato)


@funzione_libreria("arrotonda_per_difetto")
def arrotonda_per_difetto(x, cifre=0):
    """arrotonda_per_difetto(x, cifre = 0): arrotonda verso il basso (verso meno infinito).

    Esempi: `arrotonda_per_difetto(2.9)` è 2; `arrotonda_per_difetto(-2.1)` è -3; `arrotonda_per_difetto(3.149, 2)` è 3.14.
    """
    return _arrotonda(x, cifre, ROUND_FLOOR, "arrotonda_per_difetto")


@funzione_libreria("arrotonda_per_eccesso")
def arrotonda_per_eccesso(x, cifre=0):
    """arrotonda_per_eccesso(x, cifre = 0): arrotonda verso l'alto (verso più infinito).

    Esempi: `arrotonda_per_eccesso(2.1)` è 3; `arrotonda_per_eccesso(3.141, 2)` è 3.15.
    """
    return _arrotonda(x, cifre, ROUND_CEILING, "arrotonda_per_eccesso")


@funzione_libreria("arrotonda_bancario")
def arrotonda_bancario(x, cifre=0):
    """arrotonda_bancario(x, cifre = 0): a metà strada va verso la cifra PARI ("arrotondamento del banchiere").

    Sulle lunghe serie di numeri non sposta la media. Esempi: `arrotonda_bancario(2.5)` è 2;
    `arrotonda_bancario(3.5)` è 4; `arrotonda_bancario(0.125, 2)` è 0.12.
    """
    return _arrotonda(x, cifre, ROUND_HALF_EVEN, "arrotonda_bancario")


@funzione_libreria("arrotonda_a_multiplo")
def arrotonda_a_multiplo(x, multiplo):
    """arrotonda_a_multiplo(x, multiplo): il multiplo più vicino (a metà strada va lontano dallo zero).

    Esempi: `arrotonda_a_multiplo(17, 5)` è 15; `arrotonda_a_multiplo(2.37, 0.05)` è 2.35 (contanti al 5 cent.).
    """
    _numero_finito(x, "arrotonda_a_multiplo", "x")
    _numero_finito(multiplo, "arrotonda_a_multiplo", "multiplo")
    if multiplo <= 0:
        raise ErroreValore(f"Il `multiplo` deve essere maggiore di zero, non {mostra(multiplo)}.")
    a = Decimal(x) if isinstance(x, int) else Decimal(repr(x))
    m = Decimal(multiplo) if isinstance(multiplo, int) else Decimal(repr(multiplo))
    with localcontext() as ctx:
        ctx.prec = max(28, abs(a.adjusted()) + abs(m.adjusted()) + 10)
        if ctx.prec > 1000:
            raise _troppo_grande()
        try:
            volte = (a / m).quantize(Decimal(1), rounding=ROUND_HALF_UP)
            risultato = volte * m
        except InvalidOperation:  # pragma: no cover
            raise _troppo_grande() from None
    if isinstance(x, int) and isinstance(multiplo, int):
        return int(risultato)
    try:
        return float(risultato)
    except OverflowError:  # pragma: no cover
        raise _troppo_grande() from None
