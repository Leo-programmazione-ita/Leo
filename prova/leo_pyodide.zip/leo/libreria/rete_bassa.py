"""Libreria "rete di basso livello": DNS completo, certificati, catture e il proprio sistema.

Completa il modulo :mod:`leo.libreria.rete_sistema` (TCP/UDP/DNS di base/TLS/IMAP/FTP/ping)
con gli strumenti di analisi di *basso livello*, al livello della libreria standard di
Python (``socket``, ``ssl``, ``struct``, ``ipaddress``). Solo libreria standard: funziona
su Windows, Linux, macOS e, dove ha senso, nell'app Android (Chaquopy, Python 3.11).

Gruppi di funzioni:

* **DNS completo** (sola lettura): ``interroga_dns`` e le scorciatoie ``dns_a``, ``dns_aaaa``,
  ``dns_mx``, ``dns_txt``, ``dns_ns``, ``dns_cname``, ``dns_soa``, ``dns_ptr``, ``dns_inverso``;
  ``server_dns_sistema`` (i server DNS di questo computer); ``indirizzo_pubblico_dns``.
* **TLS e certificati** (dei TUOI servizi o di un sito che controlli): ``certificato_completo``,
  ``catena_certificati``, ``algoritmi_certificato``, ``impronta_certificato``, ``avvisi_certificato``,
  ``verifica_certificato_sito``, e da file ``certificato_da_file``, ``controlla_catena_file``.
* **Catture di rete** (``.pcap`` / ``.pcapng``, SOLA LETTURA): ``apri_cattura`` restituisce un
  oggetto ``cattura`` con ``pacchetti``, ``pacchetto``, ``riassunto``, ``conversazioni``,
  ``flussi_tcp``, ``protocolli``, ``top_parlatori``, ``porte_piu_usate``, ``filtra``, ``dns``,
  ``payload``; ``genera_cattura_prova`` scrive un piccolo ``.pcap`` di esempio.
* **Il proprio sistema**: ``interfacce_rete``, ``indirizzi_locali``, ``indirizzo_locale``,
  ``nome_computer``, ``connessioni_aperte``, ``tabella_routing``, ``gateway_predefinito``.

LINEA ETICA (obbligatoria, vale per tutto il modulo). Qui ci sono solo mattoni *difensivi*,
di analisi e di didattica: si **legge** e si **analizza** il proprio traffico e i propri
servizi. NON c'è e non ci sarà: invio/iniezione/falsificazione di pacchetti forgiati (le
catture si leggono soltanto; ``genera_cattura_prova`` scrive un FILE di esempio, non manda
niente in rete), scansione di intervalli di indirizzi o di porte di sistemi altrui (il
controllo di una porta resta in ``rete_sistema.porta_aperta``, una porta per volta), forza
bruta, exploit, keylogger o programmi nascosti. Le interrogazioni DNS e la lettura dei
certificati sono normali operazioni di sola lettura. Le password non compaiono mai nei
messaggi d'errore. Tutto ciò che va in rete passa dai permessi "rete"; leggere una cattura
o un certificato da file passa dai permessi "file"; le informazioni sul proprio computer dai
permessi "sistema". Confronto con Python: Leo copre *lettura e analisi* (come ``socket``,
``ssl`` e, per le catture, la parte di lettura di ``scapy``/``dpkt``), NON l'iniezione.
"""

from __future__ import annotations

import datetime
import hashlib
import ipaddress
import os
import platform
import random
import re
import socket
import ssl
import struct
import subprocess
from typing import Any

from ..errori import ErroreFile, ErroreTipo, ErroreValore
from .date import DataDante
from .generali import articolo, funzione_libreria, mostra, richiedi_intero, richiedi_logico, richiedi_testo
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta
from .rete_sistema import (_certificato, _con_parentesi, _data, _errore, _host, _ip, _ip_di_casa, _porta,
                           _tempo, e_indirizzo_ip)

#: Dimensione massima di un file di cattura che accettiamo di leggere (per non riempire la memoria).
MASSIMO_CATTURA = 200 * 1024 * 1024
#: Numero massimo di pacchetti letti da una cattura.
MASSIMO_PACCHETTI = 1_000_000
#: Lunghezza massima di un messaggio DNS (UDP).
MASSIMO_DNS = 65535


def _motivo(e: BaseException) -> str:
    """Il motivo di un errore di file in parole semplici."""
    return getattr(e, "strerror", None) or str(e) or type(e).__name__


# ===========================================================================
# DNS completo (sola lettura: normali interrogazioni a un server DNS)
# ===========================================================================

#: Tipi di record DNS che sappiamo chiedere e leggere.
TIPI_DNS: dict[str, int] = {"A": 1, "NS": 2, "CNAME": 5, "SOA": 6, "PTR": 12, "MX": 15, "TXT": 16, "AAAA": 28}
_TIPI_DNS_NUMERO = {numero: nome for nome, numero in TIPI_DNS.items()}
_RCODE = {
    1: "la domanda era scritta male (errore di formato)",
    2: "il server DNS ha avuto un problema interno",
    3: None,  # NXDOMAIN: il nome non esiste -> lista vuota, non è un errore
    4: "il server DNS non sa rispondere a questo tipo di domanda",
    5: "il server DNS ha rifiutato di rispondere",
}


def _tipo_dns(valore: Any, nome_funzione: str) -> int:
    richiedi_testo(valore, nome_funzione, "tipo")
    tipo = valore.strip().upper()
    if tipo not in TIPI_DNS:
        raise ErroreValore(f"{mostra(valore)} non è un tipo di record DNS che conosco.",
                           suggerimento="Usa uno di: " + ", ".join(f'"{t}"' for t in TIPI_DNS) + ".")
    return TIPI_DNS[tipo]


def _codifica_nome_dns(nome: str) -> bytes:
    out = bytearray()
    for etichetta in nome.rstrip(".").split("."):
        grezzo = etichetta.encode("ascii", "replace")
        if len(grezzo) > 63:
            raise ErroreValore("Una parte del nome è troppo lunga per il DNS (oltre 63 caratteri).")
        out.append(len(grezzo))
        out += grezzo
    out.append(0)
    return bytes(out)


def _leggi_nome_dns(dati: bytes, offset: int) -> tuple[str, int]:
    """Legge un nome DNS (con i "puntatori" di compressione). Ritorna (nome, offset dopo il nome)."""
    etichette: list[str] = []
    saltato = False
    dopo = offset
    passi = 0
    while True:
        if offset >= len(dati):
            raise ValueError("nome DNS troncato")
        lung = dati[offset]
        if lung & 0xC0 == 0xC0:  # puntatore a un'altra parte del messaggio
            if offset + 1 >= len(dati):
                raise ValueError("puntatore DNS troncato")
            if not saltato:
                dopo = offset + 2
            offset = ((lung & 0x3F) << 8) | dati[offset + 1]
            saltato = True
            passi += 1
            if passi > 128:
                raise ValueError("puntatori DNS in cerchio")
            continue
        offset += 1
        if lung == 0:
            break
        etichette.append(dati[offset:offset + lung].decode("ascii", "replace"))
        offset += lung
    return ".".join(etichette), (dopo if saltato else offset)


def _leggi_rdata(tipo: int, dati: bytes, inizio: int, lung: int) -> Any:
    rdata = dati[inizio:inizio + lung]
    if tipo == 1 and len(rdata) == 4:
        return socket.inet_ntop(socket.AF_INET, rdata)
    if tipo == 28 and len(rdata) == 16:
        return socket.inet_ntop(socket.AF_INET6, rdata)
    if tipo in (2, 5, 12):  # NS, CNAME, PTR
        return _leggi_nome_dns(dati, inizio)[0]
    if tipo == 15:  # MX
        priorita = struct.unpack(">H", rdata[:2])[0]
        return {"priorita": priorita, "server": _leggi_nome_dns(dati, inizio + 2)[0]}
    if tipo == 16:  # TXT: una o più stringhe con la lunghezza davanti
        testo, i = [], 0
        while i < len(rdata):
            n = rdata[i]
            testo.append(rdata[i + 1:i + 1 + n].decode("utf-8", "replace"))
            i += 1 + n
        return "".join(testo)
    if tipo == 6:  # SOA
        mname, i = _leggi_nome_dns(dati, inizio)
        rname, i = _leggi_nome_dns(dati, i)
        serie, aggiorna, riprova, scade, minimo = struct.unpack(">IIIII", dati[i:i + 20])
        return {"server_principale": mname, "responsabile": rname, "serie": serie,
                "aggiornamento": aggiorna, "riprova": riprova, "scadenza": scade, "minimo": minimo}
    return rdata.hex()


def _analizza_risposta_dns(messaggio: bytes, atteso_id: int, tipo: int) -> list[dict]:
    """Legge un messaggio di risposta DNS e ritorna i record del tipo richiesto (CNAME inclusi se servono)."""
    if len(messaggio) < 12:
        raise ValueError("risposta DNS troppo corta")
    ident, flag, qd, an, ns, ar = struct.unpack(">HHHHHH", messaggio[:12])
    if atteso_id is not None and ident != atteso_id:
        raise ValueError("risposta DNS con identificativo sbagliato")
    rcode = flag & 0x0F
    if rcode == 3:  # il nome non esiste
        return []
    if rcode in _RCODE and _RCODE[rcode] is not None:
        raise ErroreFile(f"Il server DNS non ha risposto: {_RCODE[rcode]}.")
    offset = 12
    for _ in range(qd):  # salta le domande
        _, offset = _leggi_nome_dns(messaggio, offset)
        offset += 4
    record: list[dict] = []
    for _ in range(an + ns + ar):
        if offset >= len(messaggio):
            break
        _nome_rr, offset = _leggi_nome_dns(messaggio, offset)
        if offset + 10 > len(messaggio):
            break
        rtipo, _classe, ttl, rdlung = struct.unpack(">HHIH", messaggio[offset:offset + 10])
        offset += 10
        try:
            valore = _leggi_rdata(rtipo, messaggio, offset, rdlung)
        except (ValueError, struct.error):
            valore = messaggio[offset:offset + rdlung].hex()
        offset += rdlung
        record.append({"tipo": _TIPI_DNS_NUMERO.get(rtipo, str(rtipo)), "nome": _nome_rr, "ttl": ttl,
                       "valore": valore})
    # teniamo i record del tipo chiesto; per A/AAAA includiamo i CNAME nella catena
    voluti = {_TIPI_DNS_NUMERO.get(tipo, str(tipo))}
    if tipo in (1, 28):
        voluti.add("CNAME")
    return [r for r in record if r["tipo"] in voluti]


def _dns_di_sistema() -> list[str]:
    """I server DNS configurati su questo computer (best-effort, multipiattaforma)."""
    server: list[str] = []
    if os.name == "nt":
        try:
            extra = {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)}
            r = subprocess.run(["ipconfig", "/all"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                               timeout=8, **extra)
            testo = r.stdout.decode("utf-8", "replace") if r.stdout else ""
            dentro = False
            for riga in testo.splitlines():
                if re.search(r"DNS Servers|Server DNS", riga, re.IGNORECASE):
                    dentro = True
                    riga = riga.split(":", 1)[1] if ":" in riga else ""
                elif dentro and not riga[:1].isspace():
                    dentro = False
                if dentro or ":" not in riga:
                    for ip in re.findall(r"[0-9a-fA-F:.]+", riga):
                        if e_indirizzo_ip(ip):
                            server.append(ip)
        except (OSError, subprocess.SubprocessError):
            pass
    else:
        for percorso in ("/etc/resolv.conf",):
            try:
                with open(percorso, "r", encoding="utf-8", errors="replace") as f:
                    for riga in f:
                        riga = riga.strip()
                        if riga.startswith("nameserver"):
                            parti = riga.split()
                            if len(parti) >= 2 and e_indirizzo_ip(parti[1]):
                                server.append(parti[1])
            except OSError:
                pass
    visti: list[str] = []
    for ip in server:
        if ip not in visti:
            visti.append(ip)
    return visti


def _server_per_dns(server: Any, porta: int, nome_funzione: str) -> tuple[int, tuple]:
    if server is None:
        lista = _dns_di_sistema()
        if not lista:
            raise ErroreValore("Non riesco a trovare il server DNS di questo computer.",
                               suggerimento='Indicane uno tu, per esempio '
                                            f'`{nome_funzione}(..., server = "1.1.1.1")`.')
        server = lista[0]
    host = _host(server, nome_funzione, "server")
    try:
        info = socket.getaddrinfo(host, porta, 0, socket.SOCK_DGRAM)
    except (OSError, UnicodeError) as e:
        raise _errore(e, host, porta, 5) from None
    return info[0][0], info[0][4]


def _interroga(nome_dns: str, tipo: int, server: Any, porta: int, tempo: float, nome_funzione: str) -> list[dict]:
    famiglia, indirizzo = _server_per_dns(server, porta, nome_funzione)
    ident = random.randint(0, 0xFFFF)
    domanda = struct.pack(">HHHHHH", ident, 0x0100, 1, 0, 0, 0) + _codifica_nome_dns(nome_dns) \
        + struct.pack(">HH", tipo, 1)
    try:
        with socket.socket(famiglia, socket.SOCK_DGRAM) as s:
            s.settimeout(tempo)
            s.sendto(domanda, indirizzo)
            while True:
                risposta, mittente = s.recvfrom(MASSIMO_DNS)
                if len(risposta) >= 2 and struct.unpack(">H", risposta[:2])[0] == ident:
                    break
    except socket.timeout:
        raise ErroreFile(f"Il server DNS non ha risposto entro {tempo:g} secondi.",
                         suggerimento="Riprova o indica un altro `server` (per esempio \"8.8.8.8\").") from None
    except (OSError, UnicodeError) as e:
        raise _errore(e, str(indirizzo[0]), porta, tempo) from None
    if risposta and (struct.unpack(">H", risposta[2:4])[0] & 0x0200):  # bit TC: risposta troncata -> TCP
        risposta = _interroga_tcp(domanda, famiglia, indirizzo, tempo)
    try:
        return _analizza_risposta_dns(risposta, ident, tipo)
    except ValueError as e:
        raise ErroreFile(f"Non riesco a leggere la risposta del server DNS ({e}).") from None


def _interroga_tcp(domanda: bytes, famiglia: int, indirizzo: tuple, tempo: float) -> bytes:
    with socket.socket(famiglia, socket.SOCK_STREAM) as s:
        s.settimeout(tempo)
        s.connect(indirizzo)
        s.sendall(struct.pack(">H", len(domanda)) + domanda)
        intestazione = s.recv(2)
        if len(intestazione) < 2:
            return b""
        attesi = struct.unpack(">H", intestazione)[0]
        dati = bytearray()
        while len(dati) < attesi:
            pezzo = s.recv(attesi - len(dati))
            if not pezzo:
                break
            dati += pezzo
        return bytes(dati)


def _nome_dns(valore: Any, nome_funzione: str) -> str:
    return _host(valore, nome_funzione, "nome")


@funzione_libreria("interroga_dns")
def interroga_dns(nome, tipo="A", server=None, porta=53, tempo_massimo=5):
    """interroga_dns(nome, tipo = "A", server = nulla, porta = 53): chiede al DNS i record di un nome.

    `tipo` può essere "A", "AAAA", "MX", "TXT", "NS", "CNAME", "SOA", "PTR". Con `server = nulla` usa
    il server DNS di questo computer. Restituisce una lista di dizionari con "tipo", "nome", "ttl" e
    "valore" (per MX e SOA il valore è a sua volta un dizionario). È una normale interrogazione di
    sola lettura. Esempio: `per ogni r in interroga_dns("esempio.it", "MX") fai stampa(r["valore"]) fine`.
    """
    nome_dns = _nome_dns(nome, "interroga_dns")
    numero = _tipo_dns(tipo, "interroga_dns")
    porta = _porta(porta, "interroga_dns")
    tempo = _tempo(tempo_massimo, "interroga_dns")
    return _interroga(nome_dns, numero, server, porta, tempo, "interroga_dns")


@funzione_libreria("dns_a")
def dns_a(nome, server=None, porta=53):
    """dns_a(nome, server = nulla): gli indirizzi IPv4 (record A) di un nome, come lista di testi.

    Esempio: `per ogni ip in dns_a("esempio.it") fai stampa(ip) fine`.
    """
    nome_dns = _nome_dns(nome, "dns_a")
    porta = _porta(porta, "dns_a")
    return [r["valore"] for r in _interroga(nome_dns, 1, server, porta, 5, "dns_a") if r["tipo"] == "A"]


@funzione_libreria("dns_aaaa")
def dns_aaaa(nome, server=None, porta=53):
    """dns_aaaa(nome, server = nulla): gli indirizzi IPv6 (record AAAA) di un nome, come lista di testi.

    Esempio: `stampa(dns_aaaa("esempio.it"))`.
    """
    nome_dns = _nome_dns(nome, "dns_aaaa")
    porta = _porta(porta, "dns_aaaa")
    return [r["valore"] for r in _interroga(nome_dns, 28, server, porta, 5, "dns_aaaa") if r["tipo"] == "AAAA"]


@funzione_libreria("dns_mx")
def dns_mx(nome, server=None, porta=53):
    """dns_mx(nome, server = nulla): i server di posta (record MX), ordinati per priorità.

    Ogni elemento è un dizionario con "priorita" (più basso = prima scelta) e "server".
    Esempio: `stampa(dns_mx("esempio.it")[0]["server"])`.
    """
    nome_dns = _nome_dns(nome, "dns_mx")
    porta = _porta(porta, "dns_mx")
    record = [r["valore"] for r in _interroga(nome_dns, 15, server, porta, 5, "dns_mx")]
    return sorted(record, key=lambda m: m.get("priorita", 0))


@funzione_libreria("dns_txt")
def dns_txt(nome, server=None, porta=53):
    """dns_txt(nome, server = nulla): i record TXT di un nome (per esempio SPF o verifiche), come lista di testi.

    Esempio: `per ogni t in dns_txt("esempio.it") fai stampa(t) fine`.
    """
    nome_dns = _nome_dns(nome, "dns_txt")
    porta = _porta(porta, "dns_txt")
    return [r["valore"] for r in _interroga(nome_dns, 16, server, porta, 5, "dns_txt") if r["tipo"] == "TXT"]


@funzione_libreria("dns_ns")
def dns_ns(nome, server=None, porta=53):
    """dns_ns(nome, server = nulla): i server DNS autorevoli (record NS) di un dominio, come lista di testi.

    Esempio: `stampa(dns_ns("esempio.it"))`.
    """
    nome_dns = _nome_dns(nome, "dns_ns")
    porta = _porta(porta, "dns_ns")
    return [r["valore"] for r in _interroga(nome_dns, 2, server, porta, 5, "dns_ns") if r["tipo"] == "NS"]


@funzione_libreria("dns_cname")
def dns_cname(nome, server=None, porta=53):
    """dns_cname(nome, server = nulla): il nome "vero" a cui punta un alias (record CNAME), o `nulla`.

    Esempio: `stampa(dns_cname("www.esempio.it"))`.
    """
    nome_dns = _nome_dns(nome, "dns_cname")
    porta = _porta(porta, "dns_cname")
    for r in _interroga(nome_dns, 5, server, porta, 5, "dns_cname"):
        if r["tipo"] == "CNAME":
            return r["valore"]
    return None


@funzione_libreria("dns_soa")
def dns_soa(nome, server=None, porta=53):
    """dns_soa(nome, server = nulla): i dati "SOA" di un dominio (chi lo gestisce, ogni quanto si aggiorna).

    Restituisce un dizionario con "server_principale", "responsabile", "serie", "aggiornamento",
    "riprova", "scadenza", "minimo", oppure `nulla`.
    Esempio: `stampa(dns_soa("esempio.it")["server_principale"])`.
    """
    nome_dns = _nome_dns(nome, "dns_soa")
    porta = _porta(porta, "dns_soa")
    for r in _interroga(nome_dns, 6, server, porta, 5, "dns_soa"):
        if r["tipo"] == "SOA":
            return r["valore"]
    return None


def _nome_inverso(indirizzo: Any, nome_funzione: str) -> str:
    ip = _ip(indirizzo, nome_funzione)
    return ip.reverse_pointer


@funzione_libreria("dns_ptr")
def dns_ptr(indirizzo, server=None, porta=53):
    """dns_ptr(indirizzo, server = nulla): i nomi associati a un indirizzo IP (record PTR, DNS inverso).

    Esempio: `stampa(dns_ptr("8.8.8.8"))`.
    """
    nome_dns = _nome_inverso(indirizzo, "dns_ptr")
    porta = _porta(porta, "dns_ptr")
    return [r["valore"] for r in _interroga(nome_dns, 12, server, porta, 5, "dns_ptr") if r["tipo"] == "PTR"]


@funzione_libreria("dns_inverso")
def dns_inverso(indirizzo, server=None, porta=53):
    """dns_inverso(indirizzo, server = nulla): il nome del computer che ha quell'indirizzo IP, o `nulla`.

    È il "DNS inverso": da un indirizzo risale al nome, chiedendo il record PTR al DNS.
    Esempio: `stampa(dns_inverso("8.8.8.8"))` scrive per esempio "dns.google".
    """
    nomi = dns_ptr(indirizzo, server, porta)
    return nomi[0] if nomi else None


@funzione_libreria("server_dns_sistema")
def server_dns_sistema():
    """server_dns_sistema(): la lista dei server DNS che questo computer usa per cercare i nomi.

    Esempio: `stampa(server_dns_sistema())`.
    """
    return _dns_di_sistema()


@funzione_libreria("indirizzo_pubblico_dns")
def indirizzo_pubblico_dns(server=None, porta=53, tempo_massimo=5):
    """indirizzo_pubblico_dns(server = nulla): il tuo indirizzo IP pubblico, chiesto via DNS a un resolver.

    Chiede "myip.opendns.com" a un resolver di OpenDNS (che risponde con l'indirizzo da cui arrivi):
    è un modo leggero e difensivo per scoprire con che indirizzo ti vede Internet. Con `server`
    puoi indicare un altro resolver. Restituisce un testo, o `nulla` se non arriva risposta.
    Esempio: `stampa(indirizzo_pubblico_dns())`.
    """
    porta = _porta(porta, "indirizzo_pubblico_dns")
    tempo = _tempo(tempo_massimo, "indirizzo_pubblico_dns")
    if server is None:
        try:
            server = socket.gethostbyname("resolver1.opendns.com")
        except OSError:
            raise ErroreFile("Non riesco a contattare il resolver per sapere l'indirizzo pubblico.",
                             suggerimento="Controlla la connessione, oppure indica un `server`.") from None
    record = _interroga("myip.opendns.com", 1, server, porta, tempo, "indirizzo_pubblico_dns")
    for r in record:
        if r["tipo"] == "A":
            return r["valore"]
    return None


# ===========================================================================
# TLS e certificati (lettura dei propri servizi o di un sito che si controlla)
# ===========================================================================

_OID_FIRMA: dict[str, tuple[str, bool]] = {
    "1.2.840.113549.1.1.4": ("MD5 con RSA", True),
    "1.2.840.113549.1.1.5": ("SHA-1 con RSA", True),
    "1.2.840.113549.1.1.11": ("SHA-256 con RSA", False),
    "1.2.840.113549.1.1.12": ("SHA-384 con RSA", False),
    "1.2.840.113549.1.1.13": ("SHA-512 con RSA", False),
    "1.2.840.113549.1.1.10": ("RSASSA-PSS", False),
    "1.2.840.10045.4.3.1": ("ECDSA con SHA-224", True),
    "1.2.840.10045.4.3.2": ("ECDSA con SHA-256", False),
    "1.2.840.10045.4.3.3": ("ECDSA con SHA-384", False),
    "1.2.840.10045.4.3.4": ("ECDSA con SHA-512", False),
    "1.3.101.112": ("Ed25519", False),
}
_OID_CHIAVE = {"1.2.840.113549.1.1.1": "RSA", "1.2.840.10045.2.1": "ECDSA", "1.3.101.112": "Ed25519",
               "1.2.840.113549.1.1.10": "RSA"}
_OID_CURVA = {"1.2.840.10045.3.1.1": 192, "1.2.840.10045.3.1.7": 256, "1.3.132.0.34": 384, "1.3.132.0.35": 521}


def _der(dati: bytes, i: int) -> tuple[int, bytes, int]:
    tag = dati[i]
    i += 1
    lung = dati[i]
    i += 1
    if lung & 0x80:
        n = lung & 0x7F
        lung = int.from_bytes(dati[i:i + n], "big")
        i += n
    return tag, dati[i:i + lung], i + lung


def _der_figli(contenuto: bytes) -> list[tuple[int, bytes]]:
    figli, i = [], 0
    while i < len(contenuto):
        tag, dato, i = _der(contenuto, i)
        figli.append((tag, dato))
    return figli


def _oid(contenuto: bytes) -> str:
    if not contenuto:
        return ""
    primo = contenuto[0]
    valori = [primo // 40, primo % 40]
    n = 0
    for b in contenuto[1:]:
        n = (n << 7) | (b & 0x7F)
        if not b & 0x80:
            valori.append(n)
            n = 0
    return ".".join(str(v) for v in valori)


def _analizza_der(der: bytes) -> dict:
    """Legge dal certificato (DER) l'algoritmo di firma, quello della chiave, la robustezza e il seriale."""
    info: dict[str, Any] = {"algoritmo_firma": None, "algoritmo_chiave": None, "bit_chiave": None,
                            "numero_serie": None, "debole": False, "motivi_debolezza": []}
    try:
        _tag, corpo, _ = _der(der, 0)
        figli = _der_figli(corpo)
        tbs = figli[0][1]
    except (IndexError, ValueError):
        return info
    # algoritmo di firma (seconda voce del certificato)
    try:
        oid_firma = _oid(_der_figli(figli[1][1])[0][1])
        nome_firma, firma_debole = _OID_FIRMA.get(oid_firma, (oid_firma, False))
        info["algoritmo_firma"] = nome_firma
        if firma_debole:
            info["debole"] = True
            info["motivi_debolezza"].append(f"firma con {nome_firma}")
    except (IndexError, ValueError):
        pass
    # dentro il tbsCertificate: [versione?] serie, firma, emittente, validità, soggetto, chiave pubblica
    try:
        voci = _der_figli(tbs)
        idx = 1 if voci and voci[0][0] == 0xA0 else 0
        serie = voci[idx][1]
        info["numero_serie"] = int.from_bytes(serie, "big") if serie else None
        spki = voci[idx + 5][1]
        spki_figli = _der_figli(spki)
        alg_figli = _der_figli(spki_figli[0][1])
        oid_chiave = _oid(alg_figli[0][1])
        info["algoritmo_chiave"] = _OID_CHIAVE.get(oid_chiave, oid_chiave)
        if oid_chiave == "1.2.840.113549.1.1.1":  # RSA: il modulo dà la robustezza
            # subjectPublicKey è un BIT STRING: il primo byte è "bit inutilizzati" (0), poi il DER della chiave
            der_chiave = spki_figli[1][1][1:]
            modulo = _der_figli(_der(der_chiave, 0)[1])[0][1]
            modulo = modulo.lstrip(b"\x00")
            info["bit_chiave"] = len(modulo) * 8
            if info["bit_chiave"] < 2048:
                info["debole"] = True
                info["motivi_debolezza"].append(f"chiave RSA di soli {info['bit_chiave']} bit")
        elif oid_chiave == "1.2.840.10045.2.1" and len(alg_figli) > 1:  # EC: la curva dà la robustezza
            curva = _oid(alg_figli[1][1])
            info["bit_chiave"] = _OID_CURVA.get(curva)
            if info["bit_chiave"] and info["bit_chiave"] < 256:
                info["debole"] = True
                info["motivi_debolezza"].append(f"curva ellittica di soli {info['bit_chiave']} bit")
        elif oid_chiave == "1.3.101.112":
            info["bit_chiave"] = 256
    except (IndexError, ValueError):
        pass
    return info


def _impronta(der: bytes, algoritmo: str) -> str:
    funzione = {"sha256": hashlib.sha256, "sha1": hashlib.sha1, "md5": hashlib.md5}[algoritmo]
    grezzo = funzione(der).hexdigest()
    return ":".join(grezzo[i:i + 2] for i in range(0, len(grezzo), 2)).upper()


def _der_del_sito(sito: Any, porta: Any, tempo: Any, nome_funzione: str) -> tuple[dict, bytes, str | None, Any]:
    """Si collega in TLS e prende il certificato (dizionario di base + byte DER + versione TLS/cifrario)."""
    host = _host(sito, nome_funzione, "sito")
    porta = _porta(porta, nome_funzione)
    tempo = _tempo(tempo, nome_funzione)
    nome_sni = None if e_indirizzo_ip(host) else host
    contesto = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    contesto.check_hostname = False
    contesto.verify_mode = ssl.CERT_NONE
    try:
        with socket.create_connection((host, porta), timeout=tempo) as grezzo:
            with contesto.wrap_socket(grezzo, server_hostname=nome_sni) as s:
                der = s.getpeercert(binary_form=True) or b""
                versione = s.version()
                cifrario = s.cipher()
    except ssl.SSLError:
        raise ErroreFile(f"`{host}` alla porta {porta} non parla in modo sicuro (TLS).",
                         suggerimento="Per i siti la porta sicura è 443.") from None
    except (OSError, UnicodeError) as e:
        raise _errore(e, host, porta, tempo) from None
    from .rete_sistema import _decodifica_der
    return _decodifica_der(der), der, versione, cifrario


@funzione_libreria("certificato_completo")
def certificato_completo(sito, porta=443, tempo_massimo=10):
    """certificato_completo(sito, porta = 443): tutto quello che si può leggere del certificato di un sito.

    Oltre a quello di `certificato_sito` (soggetto, emittente, date, validità) aggiunge "algoritmo_firma",
    "algoritmo_chiave", "bit_chiave", "numero_serie", "impronta_sha256", "versione_tls", "cifrario",
    "debole" (`vero` se usa algoritmi o chiavi deboli) e "avvisi" (lista di problemi in parole).
    Utile per controllare la salute dei TUOI servizi. Esempio: `stampa(certificato_completo("www.miosito.it")["avvisi"])`.
    """
    base = _certificato(sito, porta, tempo_massimo, "certificato_completo")
    _cert, der, versione, cifrario = _der_del_sito(sito, porta, tempo_massimo, "certificato_completo")
    analisi = _analizza_der(der)
    base.update({
        "algoritmo_firma": analisi["algoritmo_firma"],
        "algoritmo_chiave": analisi["algoritmo_chiave"],
        "bit_chiave": analisi["bit_chiave"],
        "numero_serie": analisi["numero_serie"],
        "impronta_sha256": _impronta(der, "sha256") if der else None,
        "versione_tls": versione or base.get("versione_tls"),
        "cifrario": cifrario[0] if cifrario else None,
    })
    base["debole"] = bool(analisi["debole"] or (versione and versione in ("SSLv3", "TLSv1", "TLSv1.1")))
    avvisi = _avvisi_da(base, analisi, versione)
    base["avvisi"] = avvisi
    return base


def _avvisi_da(base: dict, analisi: dict, versione: str | None) -> list[str]:
    avvisi: list[str] = []
    if base.get("problema"):
        avvisi.append(base["problema"])
    giorni = base.get("giorni_rimasti")
    if giorni is not None:
        if giorni < 0:
            avvisi.append(f"il certificato è scaduto da {-giorni} giorni")
        elif giorni < 15:
            avvisi.append(f"il certificato scade tra {giorni} giorni: conviene rinnovarlo")
    avvisi.extend(analisi.get("motivi_debolezza", []))
    if versione in ("SSLv3", "TLSv1", "TLSv1.1"):
        avvisi.append(f"usa una versione di TLS vecchia e insicura ({versione})")
    return avvisi


@funzione_libreria("catena_certificati")
def catena_certificati(sito, porta=443, tempo_massimo=10):
    """catena_certificati(sito, porta = 443): i certificati che il sito presenta, dal suo a quelli che lo firmano.

    Restituisce una lista di dizionari (soggetto, emittente, scadenza, algoritmi). Nota: con Python 3.11
    (come nell'app Android) il sistema dà solo il certificato del sito; per vedere tutta la catena di un
    TUO servizio leggi il file del certificato con `controlla_catena_file("fullchain.pem")`.
    Esempio: `stampa(catena_certificati("www.esempio.it")[0]["emittente"])`.
    """
    foglia = certificato_completo(sito, porta, tempo_massimo)
    return [_voce_catena(foglia)]


def _voce_catena(c: dict) -> dict:
    return {"soggetto": c.get("soggetto"), "emittente": c.get("emittente"), "valido_dal": c.get("valido_dal"),
            "scadenza": c.get("scadenza"), "giorni_rimasti": c.get("giorni_rimasti"),
            "algoritmo_firma": c.get("algoritmo_firma"), "algoritmo_chiave": c.get("algoritmo_chiave"),
            "bit_chiave": c.get("bit_chiave"), "impronta_sha256": c.get("impronta_sha256")}


@funzione_libreria("algoritmi_certificato")
def algoritmi_certificato(sito, porta=443, tempo_massimo=10):
    """algoritmi_certificato(sito, porta = 443): gli algoritmi di sicurezza usati dal certificato di un sito.

    Restituisce un dizionario con "firma", "chiave", "bit", "versione_tls", "cifrario", "debole".
    Esempio: `stampa(algoritmi_certificato("www.esempio.it")["firma"])`.
    """
    _cert, der, versione, cifrario = _der_del_sito(sito, porta, tempo_massimo, "algoritmi_certificato")
    analisi = _analizza_der(der)
    debole = bool(analisi["debole"] or (versione and versione in ("SSLv3", "TLSv1", "TLSv1.1")))
    return {"firma": analisi["algoritmo_firma"], "chiave": analisi["algoritmo_chiave"],
            "bit": analisi["bit_chiave"], "versione_tls": versione,
            "cifrario": cifrario[0] if cifrario else None, "debole": debole}


@funzione_libreria("impronta_certificato")
def impronta_certificato(sito, porta=443, algoritmo="sha256", tempo_massimo=10):
    """impronta_certificato(sito, porta = 443, algoritmo = "sha256"): l'impronta (fingerprint) del certificato.

    Serve a riconoscere un certificato in modo sicuro. `algoritmo` può essere "sha256" (consigliato),
    "sha1" o "md5" (questi due sono deboli: solo per confronti con sistemi vecchi).
    Esempio: `stampa(impronta_certificato("www.esempio.it"))`.
    """
    richiedi_testo(algoritmo, "impronta_certificato", "algoritmo")
    alg = algoritmo.strip().lower()
    if alg not in ("sha256", "sha1", "md5"):
        raise ErroreValore(f"{mostra(algoritmo)} non è un algoritmo di impronta che conosco.",
                           suggerimento='Usa "sha256" (consigliato), "sha1" o "md5".')
    _cert, der, _versione, _cifrario = _der_del_sito(sito, porta, tempo_massimo, "impronta_certificato")
    if not der:
        raise ErroreFile("Non sono riuscito a leggere il certificato.")
    return _impronta(der, alg)


@funzione_libreria("avvisi_certificato")
def avvisi_certificato(sito, porta=443, tempo_massimo=10):
    """avvisi_certificato(sito, porta = 443): la lista dei problemi del certificato di un sito (vuota se sta bene).

    Avvisa se è scaduto o sta per scadere, se usa algoritmi o chiavi deboli, se la versione di TLS è vecchia.
    Esempio: `se avvisi_certificato("www.miosito.it") == [] allora stampa("Tutto a posto") fine`.
    """
    return certificato_completo(sito, porta, tempo_massimo)["avvisi"]


@funzione_libreria("verifica_certificato_sito")
def verifica_certificato_sito(sito, porta=443, tempo_massimo=10):
    """verifica_certificato_sito(sito, porta = 443): controlla che il certificato di un sito sia valido e fidato.

    Verifica davvero la catena di fiducia (come fa il browser): nome giusto, emittente riconosciuto,
    non scaduto. Restituisce un dizionario con "valido" (`vero`/`falso`), "problema" (in parole, o
    `nulla`), "scaduto", "giorni_rimasti".
    Esempio: `se non verifica_certificato_sito("www.miosito.it")["valido"] allora stampa("Attenzione!") fine`.
    """
    base = _certificato(sito, porta, tempo_massimo, "verifica_certificato_sito")
    giorni = base.get("giorni_rimasti")
    return {"valido": base["valido"], "problema": base["problema"],
            "scaduto": bool(giorni is not None and giorni < 0), "giorni_rimasti": giorni}


def _certificati_da_pem(testo: str) -> list[bytes]:
    import base64
    import binascii
    blocchi = re.findall(r"-----BEGIN CERTIFICATE-----(.+?)-----END CERTIFICATE-----", testo, re.DOTALL)
    certi: list[bytes] = []
    for b in blocchi:
        try:
            certi.append(base64.b64decode("".join(b.split())))
        except (ValueError, binascii.Error):
            pass
    return certi


def _leggi_file_certificati(percorso: str, nome_funzione: str) -> list[bytes]:
    try:
        with open(percorso, "rb") as f:
            grezzo = f.read(MASSIMO_CATTURA)
    except (OSError, ValueError) as e:
        raise ErroreFile(f"Non riesco a leggere il file del certificato: {_motivo(e)}.",
                         suggerimento="Controlla il percorso del file.") from None
    testo = grezzo.decode("ascii", "replace")
    if "-----BEGIN CERTIFICATE-----" in testo:
        certi = _certificati_da_pem(testo)
    elif grezzo[:1] == b"\x30":  # DER (un solo certificato)
        certi = [grezzo]
    else:
        raise ErroreValore(f"Il file {mostra(percorso)} non sembra un certificato (PEM o DER).",
                           suggerimento="Un file PEM inizia con `-----BEGIN CERTIFICATE-----`.")
    if not certi:
        raise ErroreValore(f"Nel file {mostra(percorso)} non ho trovato nessun certificato.")
    return certi


def _dizionario_certificato(der: bytes) -> dict:
    from .rete_sistema import _campo, _data_certificato, _decodifica_der
    cert = _decodifica_der(der)
    analisi = _analizza_der(der)
    scadenza = _data_certificato(cert.get("notAfter"))
    giorni = (scadenza.valore - datetime.datetime.now()).days if scadenza is not None else None
    return {
        "soggetto": _campo(cert.get("subject"), "commonName", "organizationName"),
        "emittente": _campo(cert.get("issuer"), "organizationName", "commonName"),
        "valido_dal": _data_certificato(cert.get("notBefore")),
        "scadenza": scadenza,
        "giorni_rimasti": giorni,
        "nomi": [v for t, v in cert.get("subjectAltName", ()) if t in ("DNS", "IP Address")],
        "algoritmo_firma": analisi["algoritmo_firma"],
        "algoritmo_chiave": analisi["algoritmo_chiave"],
        "bit_chiave": analisi["bit_chiave"],
        "numero_serie": analisi["numero_serie"],
        "impronta_sha256": _impronta(der, "sha256"),
        "debole": analisi["debole"],
        "avvisi": _avvisi_da({"problema": None, "giorni_rimasti": giorni}, analisi, None),
        "soggetto_grezzo": _campo(cert.get("subject"), "commonName") or "",
        "emittente_grezzo": _campo(cert.get("issuer"), "commonName") or "",
    }


@funzione_libreria("certificato_da_file")
def certificato_da_file(percorso):
    """certificato_da_file(percorso): legge un certificato salvato in un file (.pem o .der) e lo analizza.

    Comodo per controllare il certificato di un TUO servizio senza collegarti. Restituisce lo stesso tipo
    di dizionario di `certificato_completo` (soggetto, emittente, date, algoritmi, impronta, "debole", "avvisi").
    Esempio: `stampa(certificato_da_file("certificato.pem")["scadenza"])`.
    """
    richiedi_testo(percorso, "certificato_da_file", "percorso")
    der = _leggi_file_certificati(percorso, "certificato_da_file")[0]
    dato = _dizionario_certificato(der)
    dato.pop("soggetto_grezzo", None)
    dato.pop("emittente_grezzo", None)
    return dato


@funzione_libreria("controlla_catena_file")
def controlla_catena_file(percorso):
    """controlla_catena_file(percorso): controlla una catena di certificati salvata in un file PEM.

    Legge tutti i certificati del file (per esempio "fullchain.pem") e verifica che siano in ordine
    (ognuno firmato dal successivo) e nessuno scaduto. È un controllo *strutturale*, non crittografico:
    per la verifica vera della firma collegati con `verifica_certificato_sito`. Restituisce un dizionario
    con "valida" (`vero`/`falso`), "quanti", "problemi" (lista in parole) e "certificati" (lista di dizionari).
    Esempio: `stampa(controlla_catena_file("fullchain.pem")["problemi"])`.
    """
    richiedi_testo(percorso, "controlla_catena_file", "percorso")
    certi = [_dizionario_certificato(der) for der in _leggi_file_certificati(percorso, "controlla_catena_file")]
    problemi: list[str] = []
    for i, c in enumerate(certi):
        giorni = c.get("giorni_rimasti")
        if giorni is not None and giorni < 0:
            problemi.append(f"il certificato {i + 1} ({c.get('soggetto') or '?'}) è scaduto")
        problemi.extend(f"il certificato {i + 1}: {m}" for m in c.get("avvisi", []) if "scadut" not in m)
        if i + 1 < len(certi):
            if c.get("emittente_grezzo") and c["emittente_grezzo"] != certi[i + 1].get("soggetto_grezzo"):
                problemi.append(f"il certificato {i + 1} non è firmato dal {i + 2} (catena interrotta)")
    for c in certi:
        c.pop("soggetto_grezzo", None)
        c.pop("emittente_grezzo", None)
    return {"valida": not problemi, "quanti": len(certi), "problemi": problemi, "certificati": certi}


# ===========================================================================
# Informazioni di rete del proprio sistema
# ===========================================================================

@funzione_libreria("indirizzo_locale")
def indirizzo_locale():
    """indirizzo_locale(): l'indirizzo IP di questo computer nella rete di casa (per esempio "192.168.1.23").

    È l'indirizzo con cui ti vedono gli altri computer della tua rete. Esempio: `stampa(indirizzo_locale())`.
    """
    return _ip_di_casa()


@funzione_libreria("indirizzi_locali")
def indirizzi_locali():
    """indirizzi_locali(): tutti gli indirizzi IP di questo computer (lista di dizionari).

    Ogni elemento ha "indirizzo", "versione" (4 o 6), "tipo" (in parole: "questo computer", "privato"...).
    Esempio: `per ogni a in indirizzi_locali() fai stampa(a["indirizzo"], a["tipo"]) fine`.
    """
    from .rete_sistema import info_indirizzo_ip
    grezzi: list[str] = ["127.0.0.1", "::1", _ip_di_casa()]
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None):
            grezzi.append(info[4][0].split("%", 1)[0])
    except (OSError, UnicodeError):
        pass
    visti: list[dict] = []
    gia: set[str] = set()
    for ip in grezzi:
        if ip in gia or not e_indirizzo_ip(ip):
            continue
        gia.add(ip)
        dato = info_indirizzo_ip(ip)
        visti.append({"indirizzo": dato["indirizzo"], "versione": dato["versione"], "tipo": dato["tipo"]})
    return sorted(visti, key=lambda d: (d["versione"], d["indirizzo"]))


def _interfacce_linux() -> list[dict]:
    import fcntl

    interfacce: list[dict] = []
    for _indice, nome in socket.if_nameindex():
        voce: dict[str, Any] = {"nome": nome, "indirizzi": [], "mac": None, "attiva": None}
        try:
            with open(f"/sys/class/net/{nome}/address", "r", encoding="ascii") as f:
                mac = f.read().strip()
                voce["mac"] = mac or None
        except OSError:
            pass
        try:
            with open(f"/sys/class/net/{nome}/operstate", "r", encoding="ascii") as f:
                voce["attiva"] = f.read().strip() == "up"
        except OSError:
            pass
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                pacchetto = struct.pack("256s", nome.encode("ascii")[:15])
                ip = socket.inet_ntoa(fcntl.ioctl(s.fileno(), 0x8915, pacchetto)[20:24])  # SIOCGIFADDR
                voce["indirizzi"].append({"indirizzo": ip, "versione": 4})
            except OSError:
                pass
            finally:
                s.close()
        except OSError:
            pass
        try:
            with open("/proc/net/if_inet6", "r", encoding="ascii") as f:
                for riga in f:
                    parti = riga.split()
                    if len(parti) >= 6 and parti[5] == nome:
                        gruppi = [parti[0][i:i + 4] for i in range(0, 32, 4)]
                        ip6 = socket.inet_ntop(socket.AF_INET6, bytes.fromhex("".join(gruppi)))
                        voce["indirizzi"].append({"indirizzo": ip6, "versione": 6})
        except OSError:
            pass
        interfacce.append(voce)
    return interfacce


@funzione_libreria("interfacce_rete")
def interfacce_rete():
    """interfacce_rete(): le schede di rete di questo computer con i loro indirizzi (lista di dizionari).

    Ogni elemento ha "nome", "indirizzi" (lista di {"indirizzo", "versione"}), "mac" e "attiva".
    I dettagli completi (indirizzi, MAC, stato) sono disponibili su Linux e Android; su Windows e macOS
    si ottengono i nomi delle schede e gli indirizzi principali del computer.
    Esempio: `per ogni i in interfacce_rete() fai stampa(i["nome"], i["indirizzi"]) fine`.
    """
    if platform.system() == "Linux":
        try:
            return _interfacce_linux()
        except (OSError, ImportError):
            pass
    # Altrove: nomi delle schede (se disponibili) e indirizzi principali del computer
    indirizzi = [{"indirizzo": a["indirizzo"], "versione": a["versione"]}
                 for a in indirizzi_locali() if a["tipo"] != "questo computer (loopback)"]
    nomi: list[str] = []
    if hasattr(socket, "if_nameindex"):
        try:
            nomi = [n for _i, n in socket.if_nameindex()]
        except OSError:
            nomi = []
    if not nomi:
        return [{"nome": socket.gethostname(), "indirizzi": indirizzi, "mac": None, "attiva": True}]
    return [{"nome": n, "indirizzi": indirizzi if i == 0 else [], "mac": None, "attiva": None}
            for i, n in enumerate(nomi)]


def _hex_ip(testo: str) -> str:
    """Un indirizzo come lo scrive /proc/net (little-endian) -> testo normale."""
    grezzo = bytes.fromhex(testo)
    if len(grezzo) == 4:
        return socket.inet_ntop(socket.AF_INET, grezzo[::-1])
    gruppi = [grezzo[i:i + 4][::-1] for i in range(0, 16, 4)]
    return socket.inet_ntop(socket.AF_INET6, b"".join(gruppi))


_STATI_TCP = {"01": "collegata", "02": "in ascolto (SYN)", "03": "in apertura", "0A": "in ascolto",
              "06": "in chiusura", "08": "in chiusura", "07": "chiusa", "0B": "ultima conferma"}


def _connessioni_linux() -> list[dict]:
    inode_pid = _mappa_inode_pid()
    risultati: list[dict] = []
    for nome_file, protocollo, versione in (("tcp", "TCP", 4), ("tcp6", "TCP", 6),
                                            ("udp", "UDP", 4), ("udp6", "UDP", 6)):
        try:
            with open(f"/proc/net/{nome_file}", "r", encoding="ascii") as f:
                righe = f.read().splitlines()[1:]
        except OSError:
            continue
        for riga in righe:
            parti = riga.split()
            if len(parti) < 10:
                continue
            l_ip, l_porta = parti[1].split(":")
            r_ip, r_porta = parti[2].split(":")
            inode = parti[9]
            pid, programma = inode_pid.get(inode, (None, None))
            risultati.append({
                "protocollo": protocollo, "versione": versione,
                "locale_indirizzo": _hex_ip(l_ip), "locale_porta": int(l_porta, 16),
                "remoto_indirizzo": _hex_ip(r_ip), "remoto_porta": int(r_porta, 16),
                "stato": _STATI_TCP.get(parti[3], parti[3]) if protocollo == "TCP" else "-",
                "pid": pid, "programma": programma,
            })
    return risultati


def _mappa_inode_pid() -> dict[str, tuple[int, str | None]]:
    mappa: dict[str, tuple[int, str | None]] = {}
    try:
        pids = [p for p in os.listdir("/proc") if p.isdigit()]
    except OSError:
        return mappa
    for p in pids:
        try:
            fds = os.listdir(f"/proc/{p}/fd")
        except OSError:
            continue
        nome = None
        for fd in fds:
            try:
                collegamento = os.readlink(f"/proc/{p}/fd/{fd}")
            except OSError:
                continue
            if collegamento.startswith("socket:["):
                inode = collegamento[8:-1]
                if nome is None:
                    try:
                        with open(f"/proc/{p}/comm", "r", encoding="utf-8", errors="replace") as f:
                            nome = f.read().strip()
                    except OSError:
                        nome = None
                mappa[inode] = (int(p), nome)
    return mappa


def _connessioni_altro() -> list[dict]:
    comando = ["netstat", "-ano"] if os.name == "nt" else ["netstat", "-n"]
    extra = {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)} if os.name == "nt" else {}
    try:
        r = subprocess.run(comando, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=15, **extra)
        testo = r.stdout.decode("utf-8", "replace") if r.stdout else ""
    except (OSError, subprocess.SubprocessError):
        raise ErroreFile("Non riesco a leggere le connessioni aperte su questo sistema.",
                         suggerimento="Su Windows e macOS serve il comando `netstat`.") from None
    risultati: list[dict] = []
    for riga in testo.splitlines():
        parti = riga.split()
        if len(parti) < 4 or not parti[0].upper().startswith(("TCP", "UDP")):
            continue
        protocollo = "TCP" if parti[0].upper().startswith("TCP") else "UDP"
        try:
            locale, remoto = parti[1], parti[2]
            l_ip, l_porta = locale.rsplit(":", 1)
            r_ip, r_porta = remoto.rsplit(":", 1)
        except ValueError:
            continue
        pid = int(parti[-1]) if os.name == "nt" and parti[-1].isdigit() else None
        stato = parti[3] if protocollo == "TCP" and not parti[3].isdigit() else "-"
        risultati.append({"protocollo": protocollo, "versione": 6 if l_ip.count(":") > 1 else 4,
                          "locale_indirizzo": l_ip.strip("[]"), "locale_porta": _intero_o(l_porta),
                          "remoto_indirizzo": r_ip.strip("[]"), "remoto_porta": _intero_o(r_porta),
                          "stato": stato, "pid": pid, "programma": None})
    return risultati


def _intero_o(testo: str) -> int | None:
    try:
        return int(testo)
    except ValueError:
        return None


@funzione_libreria("connessioni_aperte")
def connessioni_aperte():
    """connessioni_aperte(): le connessioni di rete aperte da questo computer e quali programmi le usano.

    Restituisce una lista di dizionari con "protocollo" (TCP/UDP), "locale_indirizzo", "locale_porta",
    "remoto_indirizzo", "remoto_porta", "stato", "pid" e "programma" (il nome del programma, dove si può
    sapere). Il nome del programma e il PID sono disponibili su Linux e Android; su Windows c'è il PID;
    su macOS di norma solo gli indirizzi. Serve a capire chi sta parlando con la rete dal TUO computer.
    Esempio: `per ogni c in connessioni_aperte() fai stampa(c["programma"], c["remoto_indirizzo"]) fine`.
    """
    if platform.system() == "Linux":
        try:
            return _connessioni_linux()
        except OSError:
            pass
    return _connessioni_altro()


def _routing_linux() -> list[dict]:
    rotte: list[dict] = []
    try:
        with open("/proc/net/route", "r", encoding="ascii") as f:
            for riga in f.read().splitlines()[1:]:
                p = riga.split()
                if len(p) < 11:
                    continue
                dest = _hex_ip(p[1])
                gw = _hex_ip(p[2])
                maschera = _hex_ip(p[7])
                prefisso = bin(int.from_bytes(bytes.fromhex(p[7])[::-1], "big")).count("1")
                rotte.append({"destinazione": dest, "maschera": maschera, "prefisso": prefisso,
                              "gateway": gw if gw != "0.0.0.0" else None, "interfaccia": p[0],
                              "metrica": int(p[6]), "versione": 4,
                              "predefinita": dest == "0.0.0.0" and maschera == "0.0.0.0"})
    except OSError:
        pass
    try:
        with open("/proc/net/ipv6_route", "r", encoding="ascii") as f:
            for riga in f.read().splitlines():
                p = riga.split()
                if len(p) < 10:
                    continue
                prefisso = int(p[1], 16)
                dest = socket.inet_ntop(socket.AF_INET6, bytes.fromhex(p[0]))
                gw = socket.inet_ntop(socket.AF_INET6, bytes.fromhex(p[4]))
                rotte.append({"destinazione": dest, "maschera": None, "prefisso": prefisso,
                              "gateway": gw if gw != "::" else None, "interfaccia": p[9],
                              "metrica": int(p[5], 16), "versione": 6,
                              "predefinita": prefisso == 0})
    except OSError:
        pass
    return rotte


def _routing_altro() -> list[dict]:
    comando = ["route", "print"] if os.name == "nt" else ["netstat", "-rn"]
    extra = {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0)} if os.name == "nt" else {}
    try:
        r = subprocess.run(comando, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=15, **extra)
        testo = r.stdout.decode("utf-8", "replace") if r.stdout else ""
    except (OSError, subprocess.SubprocessError):
        raise ErroreFile("Non riesco a leggere la tabella di routing di questo sistema.") from None
    rotte: list[dict] = []
    for riga in testo.splitlines():
        p = riga.split()
        if len(p) < 2:
            continue
        primo = p[0].lower()
        if primo in ("default", "0.0.0.0"):
            rotte.append({"destinazione": "0.0.0.0", "maschera": None, "prefisso": 0,
                          "gateway": p[1] if e_indirizzo_ip(p[1]) else (p[2] if len(p) > 2 and e_indirizzo_ip(p[2]) else None),
                          "interfaccia": p[-1], "metrica": None, "versione": 4, "predefinita": True})
        elif e_indirizzo_ip(primo):
            gw = next((x for x in p[1:] if e_indirizzo_ip(x)), None)
            rotte.append({"destinazione": primo, "maschera": None, "prefisso": None, "gateway": gw,
                          "interfaccia": p[-1], "metrica": None,
                          "versione": 6 if ":" in primo else 4, "predefinita": False})
    return rotte


@funzione_libreria("tabella_routing")
def tabella_routing():
    """tabella_routing(): la tabella di instradamento di questo computer (dove manda i pacchetti).

    Restituisce una lista di dizionari con "destinazione", "prefisso", "gateway", "interfaccia",
    "metrica", "versione" e "predefinita" (`vero` per la rotta di default verso Internet).
    Esempio: `per ogni r in tabella_routing() fai stampa(r["destinazione"], "->", r["gateway"]) fine`.
    """
    if platform.system() == "Linux":
        rotte = _routing_linux()
        if rotte:
            return rotte
    return _routing_altro()


@funzione_libreria("gateway_predefinito")
def gateway_predefinito():
    """gateway_predefinito(): l'indirizzo del router che porta a Internet (il "gateway"), o `nulla`.

    Esempio: `stampa(gateway_predefinito())` scrive per esempio "192.168.1.1".
    """
    for rotta in tabella_routing():
        if rotta.get("predefinita") and rotta.get("gateway"):
            return rotta["gateway"]
    return None


# ===========================================================================
# Lettura di catture .pcap / .pcapng (SOLA LETTURA)
# ===========================================================================

#: Tipi di collegamento (link type) delle catture che sappiamo leggere.
_LINK_ETHERNET, _LINK_NULL, _LINK_RAW, _LINK_LOOP, _LINK_SLL, _LINK_IPV4, _LINK_IPV6 = 1, 0, 101, 108, 113, 228, 229


def _nome_protocollo_ip(numero: int) -> str:
    return {1: "ICMP", 2: "IGMP", 6: "TCP", 17: "UDP", 58: "ICMPv6", 41: "IPv6"}.get(numero, f"IP/{numero}")


def _flag_tcp(flag: int) -> str:
    nomi = [("FIN", 0x01), ("SYN", 0x02), ("RST", 0x04), ("PSH", 0x08),
            ("ACK", 0x10), ("URG", 0x20), ("ECE", 0x40), ("CWR", 0x80)]
    return ",".join(n for n, bit in nomi if flag & bit)


def _analizza_ip(dati: bytes, versione_link: str) -> dict | None:
    if not dati:
        return None
    versione = dati[0] >> 4
    campi: dict[str, Any] = {}
    if versione == 4 and len(dati) >= 20:
        ihl = (dati[0] & 0x0F) * 4
        proto = dati[9]
        campi["sorgente"] = socket.inet_ntop(socket.AF_INET, dati[12:16])
        campi["destinazione"] = socket.inet_ntop(socket.AF_INET, dati[16:20])
        resto = dati[ihl:]
    elif versione == 6 and len(dati) >= 40:
        proto = dati[6]
        campi["sorgente"] = socket.inet_ntop(socket.AF_INET6, dati[8:24])
        campi["destinazione"] = socket.inet_ntop(socket.AF_INET6, dati[24:40])
        resto = dati[40:]
    else:
        return None
    campi["versione_ip"] = versione
    campi["protocollo"] = _nome_protocollo_ip(proto)
    campi["porta_sorgente"] = None
    campi["porta_destinazione"] = None
    campi["flag"] = None
    campi["payload"] = b""
    if proto == 6 and len(resto) >= 20:  # TCP
        sport, dport = struct.unpack(">HH", resto[:4])
        offset = (resto[12] >> 4) * 4
        campi["porta_sorgente"], campi["porta_destinazione"] = sport, dport
        campi["flag"] = _flag_tcp(resto[13])
        campi["payload"] = resto[offset:]
    elif proto == 17 and len(resto) >= 8:  # UDP
        sport, dport, lung = struct.unpack(">HHH", resto[:6])
        campi["porta_sorgente"], campi["porta_destinazione"] = sport, dport
        campi["payload"] = resto[8:lung] if 8 <= lung <= len(resto) else resto[8:]
    elif proto in (1, 58) and len(resto) >= 4:  # ICMP / ICMPv6
        campi["icmp_tipo"], campi["icmp_codice"] = resto[0], resto[1]
        campi["payload"] = resto[4:]
    return campi


def _analizza_arp(dati: bytes) -> dict:
    campi: dict[str, Any] = {"protocollo": "ARP", "porta_sorgente": None, "porta_destinazione": None,
                             "flag": None, "payload": b"", "versione_ip": None}
    if len(dati) >= 28:
        opcode = struct.unpack(">H", dati[6:8])[0]
        campi["sorgente"] = socket.inet_ntop(socket.AF_INET, dati[14:18])
        campi["destinazione"] = socket.inet_ntop(socket.AF_INET, dati[24:28])
        campi["arp_operazione"] = "richiesta" if opcode == 1 else ("risposta" if opcode == 2 else str(opcode))
    else:
        campi["sorgente"] = campi["destinazione"] = "?"
    return campi


def _analizza_frame(linktype: int, frame: bytes) -> dict | None:
    """Da un pacchetto grezzo ai campi (sorgente, destinazione, protocollo, porte, payload)."""
    try:
        if linktype == _LINK_ETHERNET:
            if len(frame) < 14:
                return None
            ethertype = struct.unpack(">H", frame[12:14])[0]
            corpo = frame[14:]
            if ethertype == 0x8100 and len(frame) >= 18:  # VLAN
                ethertype = struct.unpack(">H", frame[16:18])[0]
                corpo = frame[18:]
            sorgente_mac = frame[6:12].hex(":")
            destinazione_mac = frame[0:6].hex(":")
            if ethertype == 0x0800:
                campi = _analizza_ip(corpo, "4")
            elif ethertype == 0x86DD:
                campi = _analizza_ip(corpo, "6")
            elif ethertype == 0x0806:
                campi = _analizza_arp(corpo)
            else:
                campi = {"protocollo": f"ethertype 0x{ethertype:04x}", "sorgente": sorgente_mac,
                         "destinazione": destinazione_mac, "porta_sorgente": None,
                         "porta_destinazione": None, "flag": None, "payload": b"", "versione_ip": None}
            if campi is not None:
                campi.setdefault("sorgente_mac", sorgente_mac)
                campi.setdefault("destinazione_mac", destinazione_mac)
            return campi
        if linktype in (_LINK_NULL, _LINK_LOOP):
            if len(frame) < 4:
                return None
            famiglia = struct.unpack("<I", frame[:4])[0] if linktype == _LINK_NULL else struct.unpack(">I", frame[:4])[0]
            return _analizza_ip(frame[4:], "6" if famiglia in (24, 28, 30) else "4")
        if linktype in (_LINK_RAW, _LINK_IPV4, _LINK_IPV6):
            return _analizza_ip(frame, "4")
        if linktype == _LINK_SLL:
            if len(frame) < 16:
                return None
            ethertype = struct.unpack(">H", frame[14:16])[0]
            corpo = frame[16:]
            if ethertype == 0x0800:
                return _analizza_ip(corpo, "4")
            if ethertype == 0x86DD:
                return _analizza_ip(corpo, "6")
            if ethertype == 0x0806:
                return _analizza_arp(corpo)
            return {"protocollo": f"ethertype 0x{ethertype:04x}", "sorgente": "?", "destinazione": "?",
                    "porta_sorgente": None, "porta_destinazione": None, "flag": None, "payload": b"",
                    "versione_ip": None}
    except (struct.error, ValueError, OSError):
        return None
    return None


def _e_dns(campi: dict) -> bool:
    return campi.get("protocollo") == "UDP" and 53 in (campi.get("porta_sorgente"), campi.get("porta_destinazione"))


def _riassunto_dns(payload: bytes) -> dict | None:
    if len(payload) < 12:
        return None
    try:
        ident, flag, qd, an, _ns, _ar = struct.unpack(">HHHHHH", payload[:12])
        nome, offset = _leggi_nome_dns(payload, 12)
        qtipo = struct.unpack(">H", payload[offset:offset + 2])[0]
    except (struct.error, ValueError):
        return None
    risposta = bool(flag & 0x8000)
    return {"risposta": risposta, "nome": nome, "tipo": _TIPI_DNS_NUMERO.get(qtipo, str(qtipo)),
            "domande": qd, "risposte": an}


def _leggi_pcap_classico(dati: bytes) -> tuple[list[dict], int]:
    magic = dati[:4]
    if magic in (b"\xa1\xb2\xc3\xd4", b"\xa1\xb2\x3c\x4d"):
        ordine, nano = ">", magic == b"\xa1\xb2\x3c\x4d"
    elif magic in (b"\xd4\xc3\xb2\xa1", b"\x4d\x3c\xb2\xa1"):
        ordine, nano = "<", magic == b"\x4d\x3c\xb2\xa1"
    else:
        raise ValueError("non è un file pcap")
    linktype = struct.unpack(ordine + "I", dati[20:24])[0]
    pacchetti: list[dict] = []
    i = 24
    while i + 16 <= len(dati):
        ts_sec, ts_frac, incl, orig = struct.unpack(ordine + "IIII", dati[i:i + 16])
        i += 16
        frame = dati[i:i + incl]
        i += incl
        tempo = ts_sec + (ts_frac / 1_000_000_000 if nano else ts_frac / 1_000_000)
        pacchetti.append({"_tempo": tempo, "lunghezza": orig, "catturati": incl, "frame": frame})
        if len(pacchetti) >= MASSIMO_PACCHETTI:
            break
    return pacchetti, linktype


def _leggi_pcapng(dati: bytes) -> tuple[list[dict], int]:
    if dati[8:12] == b"\x1a\x2b\x3c\x4d":  # magic di ordine byte: big-endian
        ordine = ">"
    elif dati[8:12] == b"\x4d\x3c\x2b\x1a":  # little-endian
        ordine = "<"
    else:
        ordine = "<"
    pacchetti: list[dict] = []
    interfacce: list[tuple[int, int]] = []  # (linktype, tsresol)
    i = 0
    while i + 8 <= len(dati):
        tipo, lung = struct.unpack(ordine + "II", dati[i:i + 8])
        if lung < 12 or i + lung > len(dati):
            break
        corpo = dati[i + 8:i + lung - 4]
        if tipo == 0x00000001:  # Interface Description Block
            linktype = struct.unpack(ordine + "H", corpo[:2])[0]
            tsresol = _tsresol_pcapng(corpo[8:], ordine)
            interfacce.append((linktype, tsresol))
        elif tipo == 0x00000006 and len(corpo) >= 20:  # Enhanced Packet Block
            id_if, ts_hi, ts_lo, incl, orig = struct.unpack(ordine + "IIIII", corpo[:20])
            frame = corpo[20:20 + incl]
            _aggiungi_pcapng(pacchetti, interfacce, id_if, (ts_hi << 32) | ts_lo, incl, orig, frame)
        elif tipo == 0x00000003 and len(corpo) >= 4:  # Simple Packet Block
            orig = struct.unpack(ordine + "I", corpo[:4])[0]
            frame = corpo[4:4 + orig]
            _aggiungi_pcapng(pacchetti, interfacce, 0, 0, len(frame), orig, frame)
        elif tipo == 0x00000002 and len(corpo) >= 20:  # (vecchio) Packet Block
            id_if, _drops, ts_hi, ts_lo, incl, orig = struct.unpack(ordine + "HHIIII", corpo[:20])
            frame = corpo[20:20 + incl]
            _aggiungi_pcapng(pacchetti, interfacce, id_if, (ts_hi << 32) | ts_lo, incl, orig, frame)
        i += lung
        if len(pacchetti) >= MASSIMO_PACCHETTI:
            break
    linktype = interfacce[0][0] if interfacce else _LINK_ETHERNET
    return pacchetti, linktype


def _tsresol_pcapng(opzioni: bytes, ordine: str) -> int:
    i = 0
    while i + 4 <= len(opzioni):
        codice, lung = struct.unpack(ordine + "HH", opzioni[i:i + 4])
        if codice == 0:
            break
        if codice == 9 and lung >= 1:  # if_tsresol
            valore = opzioni[i + 4]
            return 10 ** valore if not valore & 0x80 else 2 ** (valore & 0x7F)
        i += 4 + ((lung + 3) // 4) * 4
    return 1_000_000


def _aggiungi_pcapng(pacchetti, interfacce, id_if, ts, incl, orig, frame) -> None:
    tsresol = interfacce[id_if][1] if id_if < len(interfacce) else 1_000_000
    pacchetti.append({"_tempo": ts / tsresol if tsresol else 0, "_linktype_id": id_if,
                      "lunghezza": orig, "catturati": incl, "frame": frame})


class Cattura(OggettoLibreria):
    """Una cattura di rete (.pcap o .pcapng) aperta in sola lettura: si leggono e si analizzano i pacchetti."""

    NOME_TIPO_DANTE = "cattura"
    SUGGERIMENTO_MODIFICA = "Una cattura si legge soltanto: usa per esempio `cattura.riassunto()`."

    def __init__(self, percorso: str, formato: str, grezzi: list[dict], linktype: int) -> None:
        self.percorso = percorso
        self.formato = formato
        self.linktype = linktype
        self._grezzi = grezzi
        self._base = grezzi[0]["_tempo"] if grezzi else 0.0
        self._analizzati: list[dict] = []
        self._payload: list[bytes] = []
        for numero, g in enumerate(grezzi, 1):
            lt = self.linktype
            if "_linktype_id" in g:  # pcapng con più interfacce
                lt = linktype
            campi = _analizza_frame(lt, g["frame"]) or {}
            payload = campi.get("payload", b"")
            protocollo = campi.get("protocollo", "sconosciuto")
            if _e_dns(campi) and payload:
                dns = _riassunto_dns(payload)
                if dns is not None:
                    protocollo = "DNS"
            pacchetto = {
                "numero": numero,
                "tempo": _data(datetime.datetime.fromtimestamp(g["_tempo"], datetime.timezone.utc)),
                "secondi": round(g["_tempo"] - self._base, 6),
                "lunghezza": g["lunghezza"],
                "catturati": g["catturati"],
                "protocollo": protocollo,
                "sorgente": campi.get("sorgente", "?"),
                "destinazione": campi.get("destinazione", "?"),
                "porta_sorgente": campi.get("porta_sorgente"),
                "porta_destinazione": campi.get("porta_destinazione"),
                "flag": campi.get("flag"),
                "versione_ip": campi.get("versione_ip"),
            }
            pacchetto["info"] = _descrivi_pacchetto(pacchetto, campi, payload)
            self._analizzati.append(pacchetto)
            self._payload.append(payload)

    def testo_dante(self) -> str:
        return f"<cattura {self.formato} di {len(self._analizzati)} pacchetti>"


def _descrivi_pacchetto(p: dict, campi: dict, payload: bytes) -> str:
    proto = p["protocollo"]
    if proto == "DNS":
        dns = _riassunto_dns(payload)
        if dns:
            verso = "risposta" if dns["risposta"] else "domanda"
            return f"DNS {verso} {dns['tipo']} {dns['nome']}"
    if p["porta_sorgente"] is not None:
        inizio = f"{proto} {p['sorgente']}:{p['porta_sorgente']} -> {p['destinazione']}:{p['porta_destinazione']}"
        return inizio + (f" [{p['flag']}]" if p["flag"] else "")
    if proto == "ARP":
        return f"ARP {campi.get('arp_operazione', '')} {p['sorgente']} -> {p['destinazione']}".strip()
    if proto in ("ICMP", "ICMPv6"):
        return f"{proto} tipo {campi.get('icmp_tipo')} da {p['sorgente']} a {p['destinazione']}"
    return f"{proto} {p['sorgente']} -> {p['destinazione']}"


def _leggi_cattura(percorso: str) -> Cattura:
    try:
        dimensione = os.path.getsize(percorso)
    except (OSError, ValueError) as e:
        raise ErroreFile(f"Non riesco ad aprire la cattura: {_motivo(e)}.",
                         suggerimento="Controlla il percorso del file.") from None
    if dimensione > MASSIMO_CATTURA:
        raise ErroreValore(f"Il file è troppo grande ({dimensione // (1024 * 1024)} MB): leggo al massimo "
                           f"{MASSIMO_CATTURA // (1024 * 1024)} MB.")
    try:
        with open(percorso, "rb") as f:
            dati = f.read()
    except (OSError, ValueError) as e:
        raise ErroreFile(f"Non riesco a leggere la cattura: {_motivo(e)}.") from None
    if len(dati) < 24:
        raise ErroreValore(f"Il file {mostra(percorso)} è troppo corto per essere una cattura.")
    try:
        if dati[:4] == b"\x0a\x0d\x0d\x0a":
            grezzi, linktype = _leggi_pcapng(dati)
            formato = "pcapng"
        else:
            grezzi, linktype = _leggi_pcap_classico(dati)
            formato = "pcap"
    except (ValueError, struct.error):
        raise ErroreValore(f"Il file {mostra(percorso)} non è una cattura .pcap o .pcapng che so leggere.",
                           suggerimento="Esportala in formato \"pcap\" o \"pcapng\" dal tuo programma di cattura.") \
            from None
    return Cattura(percorso, formato, grezzi, linktype)


@funzione_libreria("apri_cattura")
def apri_cattura(percorso):
    """apri_cattura(percorso): apre una cattura di rete (.pcap o .pcapng) in sola lettura e la analizza.

    Restituisce un oggetto `cattura` con `quanti`, `formato`, `durata` e i metodi `pacchetti()`,
    `pacchetto(n)`, `riassunto()`, `conversazioni()`, `flussi_tcp()`, `protocolli()`, `top_parlatori()`,
    `porte_piu_usate()`, `filtra(...)`, `dns()`, `payload(n)`. Legge soltanto: non manda niente in rete.
    Esempio: `variabile c = apri_cattura("traffico.pcap")` poi `stampa(c.riassunto())`.
    """
    richiedi_testo(percorso, "apri_cattura", "percorso")
    return _leggi_cattura(percorso)


def _richiedi_cattura(valore: Any, nome_funzione: str) -> Cattura:
    if not isinstance(valore, Cattura):
        raise ErroreTipo(f"`{nome_funzione}` vuole una cattura, non {articolo(valore)}.",
                         suggerimento='Aprine una con `apri_cattura("traffico.pcap")`.')
    return valore


@funzione_libreria("riassunto_cattura")
def riassunto_cattura(cattura):
    """riassunto_cattura(cattura): un riassunto della cattura (come `cattura.riassunto()`), in forma di funzione.

    Esempio: `variabile c = apri_cattura("prova.pcap")` poi `stampa(riassunto_cattura(c))`.
    """
    return cattura_riassunto(_richiedi_cattura(cattura, "riassunto_cattura"))


@funzione_libreria("estrai_payload")
def estrai_payload(cattura, numero):
    """estrai_payload(cattura, numero): i dati trasportati dal pacchetto `numero` (come `cattura.payload(n)`).

    Esempio: `stampa(estrai_payload(c, 4))`.
    """
    return cattura_payload(_richiedi_cattura(cattura, "estrai_payload"), numero)


@proprieta(Cattura, "quanti")
def _cat_quanti(c: Cattura) -> int:
    return len(c._analizzati)


@proprieta(Cattura, "formato")
def _cat_formato(c: Cattura) -> str:
    return c.formato


@proprieta(Cattura, "file")
def _cat_file(c: Cattura) -> str:
    return c.percorso


@proprieta(Cattura, "inizio")
def _cat_inizio(c: Cattura) -> DataDante | None:
    return c._analizzati[0]["tempo"] if c._analizzati else None


@proprieta(Cattura, "fine")
def _cat_fine(c: Cattura) -> DataDante | None:
    return c._analizzati[-1]["tempo"] if c._analizzati else None


@proprieta(Cattura, "durata")
def _cat_durata(c: Cattura) -> float:
    return round(c._analizzati[-1]["secondi"], 6) if c._analizzati else 0.0


@proprieta(Cattura, "byte_totali")
def _cat_byte(c: Cattura) -> int:
    return sum(p["lunghezza"] for p in c._analizzati)


@metodo_oggetto(Cattura, "pacchetti")
def cattura_pacchetti(c, da=1, quanti=100):
    """cattura.pacchetti(da = 1, quanti = 100): la lista dei pacchetti (dal numero `da`, al massimo `quanti`).

    Ogni pacchetto è un dizionario con "numero", "tempo", "secondi", "protocollo", "sorgente",
    "destinazione", "porta_sorgente", "porta_destinazione", "flag", "lunghezza", "info".
    Esempio: `per ogni p in c.pacchetti(1, 20) fai stampa(p["info"]) fine`.
    """
    da = richiedi_intero(da, "pacchetti", "da")
    quanti = richiedi_intero(quanti, "pacchetti", "quanti")
    if da < 1:
        raise ErroreValore("`da` di `pacchetti` parte da 1.")
    if quanti < 0:
        raise ErroreValore("`quanti` di `pacchetti` non può essere negativo.")
    return [dict(p) for p in c._analizzati[da - 1:da - 1 + quanti]]


@metodo_oggetto(Cattura, "pacchetto")
def cattura_pacchetto(c, numero):
    """cattura.pacchetto(numero): il pacchetto numero `numero` (il primo è 1), come dizionario.

    Esempio: `stampa(c.pacchetto(1)["info"])`.
    """
    numero = richiedi_intero(numero, "pacchetto", "numero")
    if not 1 <= numero <= len(c._analizzati):
        raise ErroreValore(f"La cattura ha {len(c._analizzati)} pacchetti: `{numero}` non c'è.",
                           suggerimento="I pacchetti vanno da 1 a `cattura.quanti`.")
    return dict(c._analizzati[numero - 1])


@metodo_oggetto(Cattura, "payload")
def cattura_payload(c, numero):
    """cattura.payload(numero): i dati trasportati dal pacchetto (il "contenuto"), come `dati_binari`.

    È quello che sta dentro TCP o UDP, senza le intestazioni. Sui dati puoi usare `.in_testo()`,
    `.codifica()`, `.in_lista()`, `.salva(...)`. Esempio: `stampa(c.payload(4).in_testo())`.
    """
    numero = richiedi_intero(numero, "payload", "numero")
    if not 1 <= numero <= len(c._payload):
        raise ErroreValore(f"La cattura ha {len(c._analizzati)} pacchetti: `{numero}` non c'è.")
    from .binario import DatiBinari
    return DatiBinari(c._payload[numero - 1])


@metodo_oggetto(Cattura, "protocolli")
def cattura_protocolli(c):
    """cattura.protocolli(): quante volte compare ogni protocollo (dizionario protocollo -> numero).

    Esempio: `stampa(c.protocolli())` scrive per esempio {"TCP": 40, "DNS": 4}.
    """
    conteggio: dict[str, int] = {}
    for p in c._analizzati:
        conteggio[p["protocollo"]] = conteggio.get(p["protocollo"], 0) + 1
    return dict(sorted(conteggio.items(), key=lambda kv: -kv[1]))


@metodo_oggetto(Cattura, "conversazioni")
def cattura_conversazioni(c):
    """cattura.conversazioni(): chi parla con chi (coppie di indirizzi IP), con pacchetti e byte.

    Restituisce una lista di dizionari con "a", "b", "pacchetti", "byte", ordinata dai più attivi.
    Esempio: `per ogni v in c.conversazioni() fai stampa(v["a"], "<->", v["b"], v["pacchetti"]) fine`.
    """
    gruppi: dict[tuple, dict] = {}
    for p in c._analizzati:
        a, b = p["sorgente"], p["destinazione"]
        if a == "?" or b == "?":
            continue
        chiave = tuple(sorted((a, b)))
        voce = gruppi.setdefault(chiave, {"a": chiave[0], "b": chiave[1], "pacchetti": 0, "byte": 0})
        voce["pacchetti"] += 1
        voce["byte"] += p["lunghezza"]
    return sorted(gruppi.values(), key=lambda v: (-v["pacchetti"], -v["byte"]))


@metodo_oggetto(Cattura, "top_parlatori")
def cattura_top_parlatori(c, quanti=10):
    """cattura.top_parlatori(quanti = 10): gli indirizzi IP più attivi (per numero di pacchetti).

    Restituisce una lista di dizionari con "indirizzo", "pacchetti", "byte".
    Esempio: `stampa(c.top_parlatori(5))`.
    """
    quanti = richiedi_intero(quanti, "top_parlatori", "quanti")
    conteggio: dict[str, dict] = {}
    for p in c._analizzati:
        for ip in (p["sorgente"], p["destinazione"]):
            if ip == "?":
                continue
            voce = conteggio.setdefault(ip, {"indirizzo": ip, "pacchetti": 0, "byte": 0})
            voce["pacchetti"] += 1
            voce["byte"] += p["lunghezza"]
    ordinati = sorted(conteggio.values(), key=lambda v: (-v["pacchetti"], -v["byte"]))
    return ordinati[:max(0, quanti)]


@metodo_oggetto(Cattura, "porte_piu_usate")
def cattura_porte(c, quanti=10):
    """cattura.porte_piu_usate(quanti = 10): le porte più usate nella cattura.

    Restituisce una lista di dizionari con "porta", "protocollo", "pacchetti".
    Esempio: `stampa(c.porte_piu_usate())`.
    """
    quanti = richiedi_intero(quanti, "porte_piu_usate", "quanti")
    conteggio: dict[tuple, dict] = {}
    for p in c._analizzati:
        proto = "TCP" if p["protocollo"] == "TCP" else ("UDP" if p["protocollo"] in ("UDP", "DNS") else p["protocollo"])
        for porta in (p["porta_sorgente"], p["porta_destinazione"]):
            if porta is None:
                continue
            voce = conteggio.setdefault((porta, proto), {"porta": porta, "protocollo": proto, "pacchetti": 0})
            voce["pacchetti"] += 1
    ordinati = sorted(conteggio.values(), key=lambda v: -v["pacchetti"])
    return ordinati[:max(0, quanti)]


@metodo_oggetto(Cattura, "filtra")
def cattura_filtra(c, ip=None, porta=None, protocollo=None):
    """cattura.filtra(ip = nulla, porta = nulla, protocollo = nulla): i pacchetti che rispettano i filtri.

    Puoi filtrare per indirizzo `ip` (sorgente o destinazione), per `porta` o per `protocollo`
    (per esempio "TCP", "UDP", "DNS", "ARP"). Restituisce la lista dei pacchetti (come `pacchetti()`).
    Esempio: `per ogni p in c.filtra(protocollo = "DNS") fai stampa(p["info"]) fine`.
    """
    if ip is not None:
        richiedi_testo(ip, "filtra", "ip")
    if porta is not None:
        porta = richiedi_intero(porta, "filtra", "porta")
    proto = None
    if protocollo is not None:
        richiedi_testo(protocollo, "filtra", "protocollo")
        proto = protocollo.strip().upper()
    risultato = []
    for p in c._analizzati:
        if ip is not None and ip not in (p["sorgente"], p["destinazione"]):
            continue
        if porta is not None and porta not in (p["porta_sorgente"], p["porta_destinazione"]):
            continue
        if proto is not None and p["protocollo"].upper() != proto:
            continue
        risultato.append(dict(p))
    return risultato


@metodo_oggetto(Cattura, "dns")
def cattura_dns(c):
    """cattura.dns(): tutte le domande e risposte DNS trovate nella cattura.

    Restituisce una lista di dizionari con "numero" (del pacchetto), "risposta" (`vero`/`falso`),
    "nome", "tipo", "domande", "risposte".
    Esempio: `per ogni d in c.dns() fai stampa(d["nome"], d["tipo"]) fine`.
    """
    risultato = []
    for i, p in enumerate(c._analizzati):
        if p["protocollo"] == "DNS":
            dns = _riassunto_dns(c._payload[i])
            if dns is not None:
                risultato.append({"numero": p["numero"], **dns})
    return risultato


@metodo_oggetto(Cattura, "flussi_tcp")
def cattura_flussi_tcp(c):
    """cattura.flussi_tcp(): i flussi TCP ricostruiti (una "conversazione" TCP per ogni coppia di porte).

    Ogni flusso è un dizionario con "da", "a" (indirizzo:porta), "pacchetti", "byte", "apertura"
    (`vero` se c'è il SYN), "chiusura" (`vero` se c'è il FIN), "dati_cliente" e "dati_server" (i byte
    trasportati nelle due direzioni, rimessi in ordine alla meglio).
    Esempio: `per ogni f in c.flussi_tcp() fai stampa(f["da"], "->", f["a"], f["byte"]) fine`.
    """
    flussi: dict[tuple, dict] = {}
    for i, p in enumerate(c._analizzati):
        if p["protocollo"] != "TCP" or p["porta_sorgente"] is None:
            continue
        a = (p["sorgente"], p["porta_sorgente"])
        b = (p["destinazione"], p["porta_destinazione"])
        chiave = tuple(sorted((a, b)))
        flusso = flussi.get(chiave)
        if flusso is None:
            primo = a  # il primo che vediamo lo trattiamo come "cliente"
            flusso = flussi[chiave] = {"_cliente": primo, "da": f"{a[0]}:{a[1]}", "a": f"{b[0]}:{b[1]}",
                                       "pacchetti": 0, "byte": 0, "apertura": False, "chiusura": False,
                                       "_c": [], "_s": []}
        flusso["pacchetti"] += 1
        flusso["byte"] += p["lunghezza"]
        if p["flag"] and "SYN" in p["flag"]:
            flusso["apertura"] = True
        if p["flag"] and "FIN" in p["flag"]:
            flusso["chiusura"] = True
        payload = c._payload[i]
        if payload:
            verso = "_c" if a == flusso["_cliente"] else "_s"
            flusso[verso].append(payload)
    from .binario import DatiBinari
    risultato = []
    for flusso in flussi.values():
        flusso["dati_cliente"] = DatiBinari(b"".join(flusso.pop("_c")))
        flusso["dati_server"] = DatiBinari(b"".join(flusso.pop("_s")))
        flusso.pop("_cliente", None)
        risultato.append(flusso)
    return sorted(risultato, key=lambda f: -f["pacchetti"])


@metodo_oggetto(Cattura, "riassunto")
def cattura_riassunto(c):
    """cattura.riassunto(): un riassunto della cattura (pacchetti, byte, durata, protocolli, chi parla...).

    Restituisce un dizionario con "pacchetti", "byte", "durata", "protocolli", "conversazioni" (quante),
    "flussi_tcp" (quanti), "top_parlatori" (i primi 5), "porte_piu_usate" (le prime 5).
    Esempio: `stampa(c.riassunto()["protocolli"])`.
    """
    return {
        "pacchetti": len(c._analizzati),
        "byte": sum(p["lunghezza"] for p in c._analizzati),
        "durata": round(c._analizzati[-1]["secondi"], 6) if c._analizzati else 0.0,
        "protocolli": cattura_protocolli(c),
        "conversazioni": len(cattura_conversazioni(c)),
        "flussi_tcp": len(cattura_flussi_tcp(c)),
        "top_parlatori": cattura_top_parlatori(c, 5),
        "porte_piu_usate": cattura_porte(c, 5),
    }


# ===========================================================================
# Generare un piccolo .pcap di esempio (scrive un FILE, non manda niente in rete)
# ===========================================================================

def _mac_byte(testo: str) -> bytes:
    return bytes.fromhex(testo.replace(":", ""))


def _frame_eth(dst: str, src: str, ethertype: int, payload: bytes) -> bytes:
    return _mac_byte(dst) + _mac_byte(src) + struct.pack(">H", ethertype) + payload


def _frame_ipv4(proto: int, src: str, dst: str, payload: bytes) -> bytes:
    totale = 20 + len(payload)
    intestazione = struct.pack(">BBHHHBBH", 0x45, 0, totale, 0, 0x4000, 64, proto, 0) \
        + socket.inet_aton(src) + socket.inet_aton(dst)
    return intestazione + payload


def _frame_tcp(sport: int, dport: int, seq: int, ack: int, flag: int, payload: bytes) -> bytes:
    return struct.pack(">HHIIBBHHH", sport, dport, seq, ack, 5 << 4, flag, 65535, 0, 0) + payload


def _frame_udp(sport: int, dport: int, payload: bytes) -> bytes:
    return struct.pack(">HHHH", sport, dport, 8 + len(payload), 0) + payload


def _frame_icmp(tipo: int, codice: int, payload: bytes) -> bytes:
    return struct.pack(">BBHHH", tipo, codice, 0, 1, 1) + payload


def _dns_domanda(nome: str, tipo: int = 1, ident: int = 0x1234) -> bytes:
    return struct.pack(">HHHHHH", ident, 0x0100, 1, 0, 0, 0) + _codifica_nome_dns(nome) + struct.pack(">HH", tipo, 1)


def _dns_risposta(nome: str, ip: str, ident: int = 0x1234) -> bytes:
    testa = struct.pack(">HHHHHH", ident, 0x8180, 1, 1, 0, 0)
    domanda = _codifica_nome_dns(nome) + struct.pack(">HH", 1, 1)
    risposta = b"\xc0\x0c" + struct.pack(">HHIH", 1, 1, 60, 4) + socket.inet_aton(ip)
    return testa + domanda + risposta


def _pacchetti_esempio() -> list[tuple[float, bytes]]:
    mac_c, mac_s, mac_r = "aa:bb:cc:00:00:01", "aa:bb:cc:00:00:02", "aa:bb:cc:00:00:03"
    cli, srv, dns, icmp_dst = "192.168.1.10", "93.184.216.34", "192.168.1.1", "8.8.8.8"
    frames: list[tuple[float, bytes]] = []

    def eth_ip(dst_mac, src_mac, proto, src, dst, payload):
        return _frame_eth(dst_mac, src_mac, 0x0800, _frame_ipv4(proto, src, dst, payload))

    frames.append((0.000, eth_ip(mac_s, mac_c, 6, cli, srv, _frame_tcp(49152, 80, 1000, 0, 0x02, b""))))       # SYN
    frames.append((0.012, eth_ip(mac_c, mac_s, 6, srv, cli, _frame_tcp(80, 49152, 5000, 1001, 0x12, b""))))     # SYN-ACK
    frames.append((0.013, eth_ip(mac_s, mac_c, 6, cli, srv, _frame_tcp(49152, 80, 1001, 5001, 0x10, b""))))     # ACK
    richiesta = b"GET / HTTP/1.1\r\nHost: esempio.it\r\n\r\n"
    frames.append((0.015, eth_ip(mac_s, mac_c, 6, cli, srv, _frame_tcp(49152, 80, 1001, 5001, 0x18, richiesta))))
    risposta = b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\n\r\nok"
    frames.append((0.030, eth_ip(mac_c, mac_s, 6, srv, cli, _frame_tcp(80, 49152, 5001, 1001 + len(richiesta), 0x18, risposta))))
    frames.append((0.035, eth_ip(mac_s, mac_c, 6, cli, srv, _frame_tcp(49152, 80, 1001 + len(richiesta), 5001 + len(risposta), 0x11, b""))))  # FIN-ACK
    frames.append((0.100, eth_ip(mac_r, mac_c, 17, cli, dns, _frame_udp(51000, 53, _dns_domanda("esempio.it")))))
    frames.append((0.110, eth_ip(mac_c, mac_r, 17, dns, cli, _frame_udp(53, 51000, _dns_risposta("esempio.it", srv)))))
    frames.append((0.200, eth_ip(mac_r, mac_c, 1, cli, icmp_dst, _frame_icmp(8, 0, b"ciao-leo"))))              # ICMP echo
    return frames


@funzione_libreria("genera_cattura_prova")
def genera_cattura_prova(percorso, pacchetti=None):
    """genera_cattura_prova(percorso): scrive un piccolo file .pcap di esempio (per imparare e per i test).

    Crea un file .pcap con alcuni pacchetti finti (una pagina web via TCP, una domanda DNS, un ping ICMP).
    SCRIVE SOLO UN FILE sul disco: non manda e non inietta niente in rete. Poi lo puoi aprire con
    `apri_cattura(percorso)`. Restituisce un dizionario con "file" e "pacchetti".
    Esempio: `genera_cattura_prova("prova.pcap")` poi `stampa(apri_cattura("prova.pcap").riassunto())`.
    """
    richiedi_testo(percorso, "genera_cattura_prova", "percorso")
    if pacchetti is not None:
        pacchetti = richiedi_intero(pacchetti, "genera_cattura_prova", "pacchetti")
        if not 1 <= pacchetti <= 100_000:
            raise ErroreValore("`pacchetti` di `genera_cattura_prova` deve essere tra 1 e 100000.",
                               suggerimento="È solo una cattura di esempio: bastano pochi pacchetti.")
    frames = _pacchetti_esempio()
    if pacchetti is not None:
        frames = (frames * ((pacchetti // len(frames)) + 1))[:pacchetti]
    try:
        with open(percorso, "wb") as f:
            f.write(struct.pack("<IHHiIII", 0xA1B2C3D4, 2, 4, 0, 0, 65535, _LINK_ETHERNET))
            base = 1_700_000_000
            for tempo, frame in frames:
                sec = base + int(tempo)
                usec = int((tempo - int(tempo)) * 1_000_000)
                f.write(struct.pack("<IIII", sec, usec, len(frame), len(frame)) + frame)
    except (OSError, ValueError) as e:
        raise ErroreFile(f"Non riesco a scrivere la cattura di prova: {_motivo(e)}.",
                         suggerimento="Controlla il percorso e i permessi della cartella.") from None
    return {"file": percorso, "pacchetti": len(frames)}
