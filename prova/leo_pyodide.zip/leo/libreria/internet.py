"""Libreria: Internet (pagine, file, richieste web, email, piccolo server).

Solo libreria standard di Python (``urllib``, ``http``, ``json``, ``ssl``,
``smtplib``, ``email``).

Funzioni:

* ``scarica_pagina`` (sinonimo ``scarica_testo``), ``scarica_json``,
  ``scarica_file`` (con avanzamento);
* ``richiesta_web``, ``richiesta_get``, ``richiesta_post``: la risposta è un
  dizionario con ``stato``, ``riuscita``, ``messaggio``, ``spiegazione``,
  ``testo``, ``json``, ``intestazioni``, ``indirizzo``;
* ``spiega_stato_http``, ``codifica_url``, ``decodifica_url``, ``componi_url``;
* ``invia_email`` (SMTP con TLS; la password non compare mai nei messaggi);
* ``server_web`` + ``rispondi`` (con ``quando server.richiesta fai ... fine``);
* ``connessione_attiva`` (sinonimo ``internet_disponibile``).

Errori in italiano: "nessuna connessione", "sito non trovato", "tempo
scaduto", "connessione rifiutata", codici HTTP spiegati. I problemi di rete
sono ``ErroreFile`` (come una risorsa che non si riesce a leggere), gli
argomenti sbagliati ``ErroreTipo``/``ErroreValore``.

Gli indirizzi locali (``localhost``, ``127.0.0.1``) non passano mai per un
proxy.
"""

from __future__ import annotations

import errno
import json as _json
import os
import queue
import re
import smtplib
import socket
import ssl
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from email.message import EmailMessage
from email.utils import formatdate, make_msgid
from typing import Any

from ..errori import ErroreDante, ErroreFile, ErroreTipo, ErroreValore
from ..grafica.servizi import rete
from ..valori import Richiamabile
from .generali import articolo, funzione_libreria, mostra, richiedi_logico, richiedi_testo
from .ingresso_uscita import _controlla_percorso, _errore_file
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta

__all__ = ["ServerWeb", "spiega_stato_http"]

AGENTE = "Leo/1.0 (linguaggio in italiano)"
_HOST_LOCALI = {"localhost", "127.0.0.1", "::1"}

# ===========================================================================
# Codici HTTP spiegati
# ===========================================================================

_SPIEGAZIONI = {
    400: "il server non ha capito la richiesta: controlla i dati che hai inviato",
    401: "serve l'accesso: manca la password, la chiave o il token",
    403: "accesso vietato: non hai il permesso di vedere questa risorsa",
    404: "la pagina non esiste: controlla l'indirizzo",
    405: "il sito non accetta questo metodo (per esempio POST al posto di GET)",
    408: "il server ha smesso di aspettare la richiesta",
    410: "la pagina è stata tolta per sempre",
    413: "i dati inviati sono troppo grandi",
    415: "il server non accetta questo tipo di dati (forse vuole JSON)",
    422: "i dati sono arrivati ma non sono validi",
    429: "hai fatto troppe richieste: aspetta un po' prima di riprovare",
    500: "il server ha avuto un problema interno: non dipende da te, riprova più tardi",
    501: "il server non sa fare questa operazione",
    502: "un server intermedio ha ricevuto una risposta sbagliata: riprova più tardi",
    503: "il servizio è momentaneamente non disponibile (sovraccarico o manutenzione)",
    504: "un server intermedio non ha ricevuto risposta in tempo",
}


@funzione_libreria("spiega_stato_http")
def spiega_stato_http(stato):
    """spiega_stato_http(stato): spiega in italiano un codice di stato HTTP.

    Esempio: `spiega_stato_http(404)` è "Pagina non trovata (404): la pagina non esiste: controlla l'indirizzo".
    """
    if isinstance(stato, bool) or not isinstance(stato, int):
        raise ErroreTipo(f"`stato` di `spiega_stato_http` deve essere un intero, non {articolo(stato)}.",
                         suggerimento="Esempio: `spiega_stato_http(404)`.")
    base = rete.descrizione_stato(stato)
    if stato in _SPIEGAZIONI:
        return f"{base}: {_SPIEGAZIONI[stato]}"
    if 200 <= stato < 300:
        return f"{base}: tutto a posto"
    if 300 <= stato < 400:
        return f"{base}: la risorsa si trova a un altro indirizzo"
    if 400 <= stato < 500:
        return f"{base}: c'è qualcosa che non va nella richiesta"
    if stato >= 500:
        return f"{base}: il problema è del server, riprova più tardi"
    return base


# ===========================================================================
# Strumenti comuni
# ===========================================================================

def _tempo(tempo_massimo: Any, nome: str) -> float:
    if isinstance(tempo_massimo, bool) or not isinstance(tempo_massimo, (int, float)) \
            or not tempo_massimo > 0 or tempo_massimo == float("inf"):
        raise ErroreValore(f"`tempo_massimo` di `{nome}` deve essere un numero di secondi maggiore di zero, "
                           f"non {mostra(tempo_massimo)}.", suggerimento="Esempio: `tempo_massimo = 10`.")
    return float(tempo_massimo)


def _indirizzo(indirizzo: Any, nome: str) -> urllib.parse.SplitResult:
    richiedi_testo(indirizzo, nome, "indirizzo")
    pulito = indirizzo.strip()
    if any(c in pulito for c in " \t\r\n"):
        raise ErroreValore(f"L'indirizzo {mostra(pulito)} contiene spazi.",
                           suggerimento="Negli indirizzi gli spazi si scrivono `%20`: usa `codifica_url(...)` "
                                        "per i pezzi variabili.")
    parti = urllib.parse.urlsplit(pulito)
    if parti.scheme.lower() not in ("http", "https") or not parti.netloc:
        if pulito and "://" not in pulito:
            suggerimento = f"Forse intendevi \"https://{pulito}\"?"
        else:
            suggerimento = "Un indirizzo web comincia con \"http://\" o \"https://\"."
        raise ErroreValore(f"{mostra(pulito)} non è un indirizzo web valido.", suggerimento=suggerimento)
    try:
        parti.port  # noqa: B018  (solleva ValueError se la porta non è un numero valido)
    except ValueError:
        raise ErroreValore(f"La porta nell'indirizzo {mostra(pulito)} non è valida.") from None
    return parti


def _richiedi_dizionario(valore: Any, nome: str, parametro: str) -> dict | None:
    if valore is None:
        return None
    if not isinstance(valore, dict):
        raise ErroreTipo(f"`{parametro}` di `{nome}` deve essere un dizionario, non {articolo(valore)}.",
                         suggerimento="Esempio: {\"chiave\": \"valore\"}.")
    return valore


def _testo_semplice(v: Any) -> str:
    if v is True:
        return "vero"
    if v is False:
        return "falso"
    if v is None:
        return ""
    if isinstance(v, (dict, list)):
        return _json.dumps(v, ensure_ascii=False)
    return str(v)


def _query(parametri: dict) -> str:
    coppie = []
    for k, v in parametri.items():
        if isinstance(v, list):
            coppie.extend((str(k), _testo_semplice(x)) for x in v)
        else:
            coppie.append((str(k), _testo_semplice(v)))
    return urllib.parse.urlencode(coppie)


def _host(parti: urllib.parse.SplitResult) -> str:
    return (parti.hostname or "").lower()


def _errore_rete(e: BaseException, parti: urllib.parse.SplitResult, tempo: float) -> ErroreFile:
    """Trasforma un problema di rete in un ``ErroreFile`` con parole semplici."""
    host = _host(parti) or parti.netloc
    motivo: Any = e.reason if isinstance(e, urllib.error.URLError) else e
    if isinstance(motivo, (socket.timeout, TimeoutError)):
        return ErroreFile(f"Tempo scaduto: `{host}` non ha risposto entro {tempo:g} secondi.",
                          suggerimento="Il sito è lento o irraggiungibile: riprova più tardi o aumenta `tempo_massimo`.")
    if isinstance(motivo, socket.gaierror):
        if motivo.errno in (getattr(socket, "EAI_NONAME", -2), getattr(socket, "EAI_NODATA", -5), 11001, 11004):
            return ErroreFile(f"Sito non trovato: `{host}` non esiste.",
                              suggerimento="Controlla di aver scritto bene l'indirizzo.")
        return ErroreFile(f"Nessuna connessione: non riesco a cercare `{host}`.",
                          suggerimento="Controlla di essere collegato a Internet (Wi-Fi o cavo).")
    if isinstance(motivo, ConnectionRefusedError):
        return ErroreFile(f"Connessione rifiutata da `{parti.netloc}`.",
                          suggerimento="Forse il server è spento o la porta è sbagliata.")
    if isinstance(motivo, ssl.SSLCertVerificationError):
        return ErroreFile(f"Il certificato di sicurezza di `{host}` non è valido.",
                          suggerimento="Non è sicuro continuare: controlla l'indirizzo (forse `http://`?).")
    if isinstance(motivo, ssl.SSLError):
        return ErroreFile(f"La connessione sicura con `{host}` non è riuscita.",
                          suggerimento="Prova più tardi o controlla l'indirizzo.")
    numero = getattr(motivo, "errno", None)
    if numero in (errno.ENETUNREACH, errno.EHOSTUNREACH, errno.ENETDOWN, 10051, 10065):
        return ErroreFile(f"Nessuna connessione: la rete non raggiunge `{host}`.",
                          suggerimento="Controlla di essere collegato a Internet (Wi-Fi o cavo).")
    if isinstance(motivo, (ConnectionResetError, ConnectionAbortedError, BrokenPipeError)):
        return ErroreFile(f"La connessione con `{host}` si è interrotta.",
                          suggerimento="Riprova: la rete potrebbe essere instabile.")
    return ErroreFile(f"Non riesco a collegarmi a `{host}`.",
                      suggerimento=f"Controlla la connessione a Internet. Dettaglio tecnico: {motivo}")


def _apri(parti: urllib.parse.SplitResult, url: str, metodo: str, corpo: bytes | None,
          intestazioni: dict, tempo: float):
    """Apre la connessione; restituisce la risposta (anche se lo stato è 4xx/5xx)."""
    richiesta = urllib.request.Request(url, data=corpo, headers=intestazioni, method=metodo)
    if _host(parti) in _HOST_LOCALI:
        apri = urllib.request.build_opener(urllib.request.ProxyHandler({})).open
    else:
        apri = urllib.request.urlopen
    try:
        return apri(richiesta, timeout=tempo)
    except urllib.error.HTTPError as e:
        return e  # anche gli stati di errore hanno un corpo da leggere
    except (urllib.error.URLError, OSError) as e:
        raise _errore_rete(e, parti, tempo) from None
    except ValueError as e:
        raise ErroreValore(f"Indirizzo non valido: {mostra(url)} ({e}).") from None


def _stato(risposta: Any) -> int:
    stato = getattr(risposta, "status", None)
    return int(stato if stato is not None else risposta.getcode())


def _leggi_tutto(risposta: Any, parti: urllib.parse.SplitResult, tempo: float) -> bytes:
    try:
        with risposta:
            return risposta.read()
    except (OSError, urllib.error.URLError) as e:
        raise _errore_rete(e, parti, tempo) from None
    except Exception as e:  # http.client.IncompleteRead e simili
        raise ErroreFile(f"La risposta di `{_host(parti)}` è arrivata a metà.",
                         suggerimento=f"Riprova. Dettaglio tecnico: {type(e).__name__}") from None


def _prepara(nome: str, indirizzo: Any, metodo: Any, parametri: Any, dati: Any, json: Any,
             intestazioni: Any, tempo_massimo: Any):
    parti = _indirizzo(indirizzo, nome)
    richiedi_testo(metodo, nome, "metodo")
    metodo = metodo.strip().upper()
    if metodo not in rete.METODI:
        raise ErroreValore(f"Il metodo {mostra(metodo)} non esiste.",
                           suggerimento="Usa \"GET\" (leggere), \"POST\" (inviare), \"PUT\", \"PATCH\" o \"DELETE\".")
    tempo = _tempo(tempo_massimo, nome)
    parametri = _richiedi_dizionario(parametri, nome, "parametri")
    intestazioni = _richiedi_dizionario(intestazioni, nome, "intestazioni")
    if dati is not None and json is not None:
        raise ErroreValore(f"`{nome}`: usa `dati` oppure `json`, non tutti e due.")
    url = indirizzo.strip()
    if parametri:
        url += ("&" if parti.query else "?") + _query(parametri)
    testate = {"User-Agent": AGENTE, "Accept": "*/*"}
    corpo: bytes | None = None
    if json is not None:
        try:
            corpo = _json.dumps(json, ensure_ascii=False).encode("utf-8")
        except (TypeError, ValueError):
            raise ErroreTipo(f"Questi dati non si possono inviare come JSON: {mostra(json)}.",
                             suggerimento="Usa solo dizionari, liste, testi, numeri, logici e `nulla`.") from None
        testate["Content-Type"] = "application/json; charset=utf-8"
    elif isinstance(dati, dict):
        corpo = _query(dati).encode("utf-8")
        testate["Content-Type"] = "application/x-www-form-urlencoded; charset=utf-8"
    elif isinstance(dati, str):
        corpo = dati.encode("utf-8")
        testate["Content-Type"] = "text/plain; charset=utf-8"
    elif dati is not None:
        raise ErroreTipo(f"`dati` di `{nome}` deve essere un testo o un dizionario, non {articolo(dati)}.",
                         suggerimento="Per inviare liste o dizionari come JSON usa `json = ...`.")
    for k, v in (intestazioni or {}).items():
        testate[str(k)] = rete._latino(v)
    return parti, url, metodo, corpo, testate, tempo


def _risposta(stato: int, contenuto: bytes, testate: Any, url: str) -> dict:
    testo = rete._decodifica(contenuto, testate)
    tipo = testate.get("Content-Type", "") if testate is not None else ""
    return {
        "stato": stato,
        "riuscita": 200 <= stato < 300,
        "messaggio": rete.descrizione_stato(stato),
        "spiegazione": spiega_stato_http(stato),
        "testo": testo,
        "json": rete._prova_json(testo, tipo),
        "intestazioni": rete._intestazioni_dict(testate),
        "indirizzo": url,
    }


def _esegui(nome, indirizzo, metodo="GET", parametri=None, dati=None, json=None, intestazioni=None,
            tempo_massimo=15) -> dict:
    parti, url, metodo, corpo, testate, tempo = _prepara(nome, indirizzo, metodo, parametri, dati, json,
                                                         intestazioni, tempo_massimo)
    risposta = _apri(parti, url, metodo, corpo, testate, tempo)
    stato = _stato(risposta)
    contenuto = _leggi_tutto(risposta, parti, tempo)
    return _risposta(stato, contenuto, risposta.headers, getattr(risposta, "url", None) or url)


def _errore_stato(risposta: dict) -> ErroreFile:
    return ErroreFile(f"Il sito ha risposto con un errore. {risposta['spiegazione']}.",
                      suggerimento="Per leggere anche le risposte di errore usa `richiesta_web(...)`, "
                                   "che non si ferma e ti dà lo `stato`.")


# ===========================================================================
# Richieste
# ===========================================================================

@funzione_libreria("richiesta_web")
def richiesta_web(indirizzo, metodo="GET", parametri=None, dati=None, json=None, intestazioni=None,
                  tempo_massimo=15):
    """richiesta_web(indirizzo, metodo = "GET", parametri = nulla, dati = nulla, json = nulla, intestazioni = nulla, tempo_massimo = 15): una richiesta HTTP completa.

    Restituisce un dizionario: `stato` (200, 404...), `riuscita` (vero se 2xx), `messaggio`,
    `spiegazione`, `testo`, `json` (già trasformato in valori Leo, o `nulla`), `intestazioni`,
    `indirizzo`. Un codice di errore (404, 500...) NON ferma il programma: controlla `riuscita`.
    `parametri` va nell'indirizzo (?a=1&b=2), `json` si invia come JSON, `dati` come modulo web.
    Esempio: `variabile r = richiesta_web("https://api.esempio.it/voti", metodo = "POST", json = {"voto": 30})`.
    """
    return _esegui("richiesta_web", indirizzo, metodo, parametri, dati, json, intestazioni, tempo_massimo)


@funzione_libreria("richiesta_get")
def richiesta_get(indirizzo, parametri=None, intestazioni=None, tempo_massimo=15):
    """richiesta_get(indirizzo, parametri = nulla, intestazioni = nulla, tempo_massimo = 15): chiede una risorsa (GET).

    Come `richiesta_web` con metodo "GET". Esempio:
    `variabile r = richiesta_get("https://api.esempio.it/cerca", parametri = {"q": "Petrarca"})`.
    """
    return _esegui("richiesta_get", indirizzo, "GET", parametri, None, None, intestazioni, tempo_massimo)


@funzione_libreria("richiesta_post")
def richiesta_post(indirizzo, json=None, dati=None, intestazioni=None, tempo_massimo=15):
    """richiesta_post(indirizzo, json = nulla, dati = nulla, intestazioni = nulla, tempo_massimo = 15): invia dati (POST).

    Come `richiesta_web` con metodo "POST". Esempio:
    `richiesta_post("https://api.esempio.it/messaggi", json = {"testo": "Ciao"}, intestazioni = {"Authorization": "Bearer ..."})`.
    """
    return _esegui("richiesta_post", indirizzo, "POST", None, dati, json, intestazioni, tempo_massimo)


def _pagina(nome: str, indirizzo: Any, tempo_massimo: Any, parametri: Any = None,
            intestazioni: Any = None) -> dict:
    risposta = _esegui(nome, indirizzo, "GET", parametri, None, None, intestazioni, tempo_massimo)
    if not risposta["riuscita"]:
        raise _errore_stato(risposta)
    return risposta


@funzione_libreria("scarica_pagina")
def scarica_pagina(indirizzo, tempo_massimo=15):
    """scarica_pagina(indirizzo, tempo_massimo = 15): il testo (o l'HTML) di una pagina web.

    Se il sito risponde con un errore (per esempio 404) ricevi un `ErroreFile` che lo spiega.
    Esempio: `variabile html = scarica_pagina("https://www.esempio.it")`.
    """
    return _pagina("scarica_pagina", indirizzo, tempo_massimo)["testo"]


@funzione_libreria("scarica_testo")
def scarica_testo(indirizzo, tempo_massimo=15):
    """scarica_testo(indirizzo, tempo_massimo = 15): sinonimo di `scarica_pagina`.

    Esempio: `stampa(scarica_testo("https://www.esempio.it/leggimi.txt"))`.
    """
    return _pagina("scarica_testo", indirizzo, tempo_massimo)["testo"]


@funzione_libreria("scarica_json")
def scarica_json(indirizzo, parametri=None, intestazioni=None, tempo_massimo=15):
    """scarica_json(indirizzo, parametri = nulla, intestazioni = nulla, tempo_massimo = 15): scarica dati JSON come valori Leo.

    Esempio: `variabile meteo = scarica_json("https://api.esempio.it/meteo", parametri = {"città": "Roma"})`
    e poi `stampa(meteo["temperatura"])`.
    """
    risposta = _pagina("scarica_json", indirizzo, tempo_massimo, parametri, intestazioni)
    if risposta["json"] is None:
        testo = risposta["testo"].strip()
        if testo == "null":
            return None
        raise ErroreValore(f"La risposta di {mostra(risposta['indirizzo'])} non è JSON.",
                           suggerimento="Comincia con " + mostra(testo[:30]) + ": forse è una pagina HTML? "
                                        "Usa `scarica_pagina` per leggerla come testo.")
    return risposta["json"]


def _nome_da_indirizzo(parti: urllib.parse.SplitResult) -> str:
    ultimo = urllib.parse.unquote(parti.path.rstrip("/").rsplit("/", 1)[-1])
    ultimo = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", ultimo).strip(" .")
    return ultimo or "scaricato"


def _misura(n: int) -> str:
    if n < 1024:
        return f"{n} B"
    if n < 1024 * 1024:
        return f"{n / 1024:.1f} KB".replace(".", ",")
    return f"{n / (1024 * 1024):.1f} MB".replace(".", ",")


@funzione_libreria("scarica_file", interprete=True)
def scarica_file(interprete, indirizzo, percorso=None, avanzamento=False, tempo_massimo=30):
    """scarica_file(indirizzo, percorso = nulla, avanzamento = falso, tempo_massimo = 30): salva su disco un file preso dal web.

    Senza `percorso` usa il nome che il file ha nell'indirizzo. Con `avanzamento = vero` stampa
    a che punto è; puoi anche passare una funzione `(scaricati, totale)` (byte; `totale` è
    `nulla` se il sito non lo dice). Il file compare solo quando è completo. Restituisce il percorso.
    Esempio: `scarica_file("https://www.esempio.it/logo.png", "immagini/logo.png", avanzamento = vero)`.
    """
    parti = _indirizzo(indirizzo, "scarica_file")
    tempo = _tempo(tempo_massimo, "scarica_file")
    if percorso is None:
        percorso = _nome_da_indirizzo(parti)
    _controlla_percorso(percorso, "scarica_file")
    if not (isinstance(avanzamento, bool) or isinstance(avanzamento, Richiamabile)):
        raise ErroreTipo(f"`avanzamento` di `scarica_file` deve essere `vero`, `falso` o una funzione, "
                         f"non {articolo(avanzamento)}.")
    if os.path.isdir(percorso):
        percorso = os.path.join(percorso, _nome_da_indirizzo(parti))
    url = indirizzo.strip()
    risposta = _apri(parti, url, "GET", None, {"User-Agent": AGENTE, "Accept": "*/*"}, tempo)
    stato = _stato(risposta)
    if not 200 <= stato < 300:
        with risposta:
            pass
        raise ErroreFile(f"Non posso scaricare {mostra(url)}. {spiega_stato_http(stato)}.")
    totale_testo = risposta.headers.get("Content-Length")
    totale = int(totale_testo) if totale_testo and totale_testo.isdigit() else None
    cartella = os.path.dirname(os.path.abspath(percorso))
    try:
        descrittore, provvisorio = tempfile.mkstemp(prefix=".scaricamento-", dir=cartella)
    except OSError as e:
        with risposta:
            pass
        raise _errore_file(e, percorso, "scrivere") from None
    scaricati = 0
    ultimo_quarto = -1
    ultimo_mega = 0

    def segnala() -> None:
        nonlocal ultimo_quarto, ultimo_mega
        if avanzamento is False:
            return
        if isinstance(avanzamento, Richiamabile):
            interprete.chiama(avanzamento, [scaricati, totale])
            return
        if totale:
            quarto = min(4, scaricati * 4 // totale) if totale else 4
            if quarto > ultimo_quarto:
                ultimo_quarto = quarto
                interprete.scrivi(f"Scaricamento: {quarto * 25}% ({_misura(scaricati)} di {_misura(totale)})\n")
        elif scaricati - ultimo_mega >= 1024 * 1024 or scaricati == 0:
            ultimo_mega = scaricati
            interprete.scrivi(f"Scaricamento: {_misura(scaricati)}\n")

    try:
        with os.fdopen(descrittore, "wb") as f, risposta:
            segnala()
            while True:
                try:
                    blocco = risposta.read(64 * 1024)
                except (OSError, urllib.error.URLError) as e:
                    raise _errore_rete(e, parti, tempo) from None
                if not blocco:
                    break
                f.write(blocco)
                scaricati += len(blocco)
                segnala()
        if totale is not None and scaricati < totale:
            raise ErroreFile(f"Lo scaricamento di {mostra(url)} si è interrotto a metà "
                             f"({_misura(scaricati)} di {_misura(totale)}).", suggerimento="Riprova.")
        if avanzamento is True and not totale:
            interprete.scrivi(f"Scaricamento completato: {_misura(scaricati)}\n")
        os.replace(provvisorio, percorso)
    except BaseException as e:
        try:
            os.unlink(provvisorio)
        except OSError:
            pass
        if isinstance(e, OSError) and not isinstance(e, ErroreDante):
            raise _errore_file(e, percorso, "scrivere") from None
        raise
    return percorso


# ===========================================================================
# Indirizzi
# ===========================================================================

@funzione_libreria("codifica_url")
def codifica_url(valore):
    """codifica_url(valore): prepara un testo (o un dizionario di parametri) per metterlo in un indirizzo web.

    Esempi: `codifica_url("caffè e latte")` è "caff%C3%A8%20e%20latte";
    `codifica_url({"q": "Petrarca", "pagina": 2})` è "q=Petrarca&pagina=2".
    """
    if isinstance(valore, dict):
        return _query(valore)
    if isinstance(valore, bool) or valore is None or isinstance(valore, (list, range)):
        raise ErroreTipo(f"`codifica_url` vuole un testo o un dizionario, non {articolo(valore)}.")
    if isinstance(valore, (int, float)):
        valore = str(valore)
    richiedi_testo(valore, "codifica_url", "valore")
    return urllib.parse.quote(valore, safe="")


@funzione_libreria("decodifica_url")
def decodifica_url(testo):
    """decodifica_url(testo): il contrario di `codifica_url` (%20 torna uno spazio, %C3%A8 torna "è").

    Esempio: `decodifica_url("caff%C3%A8%20e%20latte")` è "caffè e latte".
    """
    richiedi_testo(testo, "decodifica_url", "testo")
    return urllib.parse.unquote_plus(testo)


@funzione_libreria("componi_url")
def componi_url(indirizzo, parametri):
    """componi_url(indirizzo, parametri): aggiunge i parametri (un dizionario) a un indirizzo, già codificati.

    Esempio: `componi_url("https://www.esempio.it/cerca", {"q": "più voti"})` è
    "https://www.esempio.it/cerca?q=pi%C3%B9+voti".
    """
    parti = _indirizzo(indirizzo, "componi_url")
    _richiedi_dizionario(parametri, "componi_url", "parametri")
    if not parametri:
        return indirizzo.strip()
    return indirizzo.strip() + ("&" if parti.query else "?") + _query(parametri)


# ===========================================================================
# Connessione
# ===========================================================================

def _connessione(nome: str, sito: Any, porta: Any, tempo_massimo: Any) -> bool:
    richiedi_testo(sito, nome, "sito")
    if isinstance(porta, bool) or not isinstance(porta, int) or not 0 < porta < 65536:
        raise ErroreValore(f"`porta` di `{nome}` deve essere un intero tra 1 e 65535.")
    tempo = _tempo(tempo_massimo, nome)
    host = sito.strip()
    if "://" in host:
        host = urllib.parse.urlsplit(host).hostname or ""
    if not host:
        return False
    try:
        with socket.create_connection((host, porta), timeout=tempo):
            return True
    except (OSError, ValueError, UnicodeError):
        return False


@funzione_libreria("connessione_attiva")
def connessione_attiva(sito="www.google.com", porta=443, tempo_massimo=3):
    """connessione_attiva(sito = "www.google.com", porta = 443, tempo_massimo = 3): `vero` se Internet (o quel sito) risponde.

    Non dà mai errore: senza rete restituisce `falso`.
    Esempio: `se non connessione_attiva() allora stampa("Sei offline") fine`.
    """
    return _connessione("connessione_attiva", sito, porta, tempo_massimo)


@funzione_libreria("internet_disponibile")
def internet_disponibile(sito="www.google.com", porta=443, tempo_massimo=3):
    """internet_disponibile(sito = "www.google.com", porta = 443, tempo_massimo = 3): sinonimo di `connessione_attiva`.

    Esempio: `se internet_disponibile() allora stampa("rete attiva") fine`.
    """
    return _connessione("internet_disponibile", sito, porta, tempo_massimo)


# ===========================================================================
# Email
# ===========================================================================

_EMAIL = re.compile(r"^[^@\s<>,;]+@[^@\s<>,;]+\.[^@\s<>,;]+$|^[^@\s<>,;]+@localhost$")


def _indirizzi_email(valore: Any, parametro: str) -> list[str]:
    elenco = valore if isinstance(valore, list) else [valore]
    if not elenco:
        raise ErroreValore(f"`{parametro}` di `invia_email` è una lista vuota.")
    risultato = []
    for v in elenco:
        richiedi_testo(v, "invia_email", parametro)
        # "Nome <indirizzo>": si controlla la parte tra < >
        m = re.fullmatch(r"\s*(?:[^<>]*<)?\s*([^<>]+?)\s*>?\s*", v)
        puro = m.group(1) if m else v
        if "\n" in v or "\r" in v or not _EMAIL.match(puro.strip()):
            raise ErroreValore(f"{mostra(v)} non è un indirizzo email valido.",
                               suggerimento="Un indirizzo email è fatto come nome@dominio.it.")
        risultato.append(v.strip())
    return risultato


def _senza_segreti(testo: str, segreti: list[str]) -> str:
    for s in segreti:
        if s:
            testo = testo.replace(s, "****")
    return testo


@funzione_libreria("invia_email")
def invia_email(destinatario, oggetto, testo, mittente, server, porta=587, utente=None, password=None,
                tls=True, html=None, copia=None, tempo_massimo=30):
    """invia_email(destinatario, oggetto, testo, mittente, server, porta = 587, utente = nulla, password = nulla, tls = vero, html = nulla, copia = nulla, tempo_massimo = 30): invia un'email con un server SMTP.

    `destinatario` e `copia` possono essere un indirizzo o una lista. Con `tls = vero` la
    connessione è cifrata (porta 587 con STARTTLS, porta 465 cifrata da subito). La password
    non compare mai nei messaggi e non viene inviata senza cifratura (tranne che a questo computer).
    `html` aggiunge una versione HTML del messaggio. Restituisce `vero`.
    Esempio: `invia_email("ada@esempio.it", "Ciao", "Il programma è finito!", "leo@esempio.it",
    "smtp.esempio.it", utente = "leo@esempio.it", password = leggi_file("password.txt"))`.
    """
    a = _indirizzi_email(destinatario, "destinatario")
    cc = _indirizzi_email(copia, "copia") if copia is not None else []
    da = _indirizzi_email(mittente, "mittente")
    if len(da) != 1:
        raise ErroreValore("Il `mittente` di `invia_email` è uno solo.")
    richiedi_testo(oggetto, "invia_email", "oggetto")
    richiedi_testo(testo, "invia_email", "testo")
    richiedi_testo(server, "invia_email", "server")
    if html is not None:
        richiedi_testo(html, "invia_email", "html")
    if isinstance(porta, bool) or not isinstance(porta, int) or not 0 < porta < 65536:
        raise ErroreValore("`porta` di `invia_email` deve essere un intero tra 1 e 65535 (di solito 587 o 465).")
    richiedi_logico(tls, "invia_email", "tls")
    tempo = _tempo(tempo_massimo, "invia_email")
    if password is not None:
        if not isinstance(password, str):
            raise ErroreTipo(f"`password` di `invia_email` deve essere un testo, non {articolo(password)}.")
        if utente is None:
            utente = da[0]
    if utente is not None:
        richiedi_testo(utente, "invia_email", "utente")
    host = server.strip()
    if not host or any(c in host for c in " /\\"):
        raise ErroreValore(f"{mostra(server)} non è un nome di server valido.",
                           suggerimento="Esempio: \"smtp.gmail.com\".")
    locale = host.lower() in _HOST_LOCALI
    if password and not tls and not locale:
        raise ErroreValore("Non invio la password senza cifratura: chiunque sulla rete potrebbe leggerla.",
                           suggerimento="Lascia `tls = vero` (è il valore predefinito).")
    if "\n" in oggetto or "\r" in oggetto:
        raise ErroreValore("L'`oggetto` dell'email deve stare su una riga sola.")

    messaggio = EmailMessage()
    messaggio["From"] = da[0]
    messaggio["To"] = ", ".join(a)
    if cc:
        messaggio["Cc"] = ", ".join(cc)
    messaggio["Subject"] = oggetto
    messaggio["Date"] = formatdate(localtime=True)
    messaggio["Message-ID"] = make_msgid(domain=(da[0].rsplit("@", 1)[-1].strip(">") or "leo.local"))
    messaggio.set_content(testo)
    if html is not None:
        messaggio.add_alternative(html, subtype="html")

    segreti = [password] if password else []
    contesto = ssl.create_default_context()
    try:
        if tls and porta == 465:
            connessione = smtplib.SMTP_SSL(host, porta, timeout=tempo, context=contesto)
        else:
            connessione = smtplib.SMTP(host, porta, timeout=tempo)
        with connessione:
            connessione.ehlo()
            if tls and porta != 465:
                if not connessione.has_extn("starttls"):
                    raise ErroreFile(f"Il server `{host}` non permette una connessione cifrata (STARTTLS).",
                                     suggerimento="Controlla server e porta (di solito 587), oppure prova "
                                                  "la porta 465.")
                connessione.starttls(context=contesto)
                connessione.ehlo()
            if password is not None:
                if not connessione.has_extn("auth"):
                    raise ErroreFile(f"Il server `{host}` non chiede l'accesso: togli `utente` e `password`.")
                connessione.login(utente, password)
            rifiutati = connessione.send_message(messaggio, from_addr=da[0], to_addrs=a + cc)
    except ErroreDante:
        raise
    except smtplib.SMTPAuthenticationError:
        raise ErroreFile(f"Accesso non riuscito a `{host}`: nome utente o password sbagliati.",
                         suggerimento="Molti servizi (Gmail, Outlook) vogliono una \"password per le app\" "
                                      "invece della password normale.") from None
    except smtplib.SMTPRecipientsRefused as e:
        raise ErroreFile("Il server ha rifiutato il destinatario: "
                         + ", ".join(f"`{k}`" for k in e.recipients) + ".",
                         suggerimento="Controlla l'indirizzo del destinatario.") from None
    except smtplib.SMTPSenderRefused:
        raise ErroreFile(f"Il server ha rifiutato il mittente `{da[0]}`.",
                         suggerimento="Di solito il mittente deve essere l'indirizzo con cui accedi.") from None
    except (smtplib.SMTPConnectError, smtplib.SMTPServerDisconnected, smtplib.SMTPHeloError) as e:
        raise ErroreFile(f"Il server di posta `{host}` ha chiuso la connessione.",
                         suggerimento=_senza_segreti(f"Controlla server e porta. Dettaglio tecnico: {e}",
                                                     segreti)) from None
    except smtplib.SMTPNotSupportedError:
        raise ErroreFile(f"Il server `{host}` non supporta questa operazione (cifratura o accesso).",
                         suggerimento="Controlla la porta: di solito 587 (STARTTLS) o 465 (cifrata).") from None
    except smtplib.SMTPException as e:
        raise ErroreFile("Il server di posta ha rifiutato il messaggio.",
                         suggerimento=_senza_segreti(f"Dettaglio tecnico: {e}", segreti)) from None
    except (OSError, ssl.SSLError) as e:
        parti = urllib.parse.urlsplit(f"smtp://{host}:{porta}")
        errore = _errore_rete(e, parti, tempo)
        errore.messaggio = _senza_segreti(errore.messaggio, segreti)
        if errore.suggerimento:
            errore.suggerimento = _senza_segreti(errore.suggerimento, segreti)
        raise errore from None
    if rifiutati:
        raise ErroreFile("Alcuni destinatari sono stati rifiutati: "
                         + ", ".join(f"`{k}`" for k in rifiutati) + ".")
    return True


# ===========================================================================
# Server web
# ===========================================================================

#: Risposta preparata da `rispondi` durante la richiesta in corso (per thread).
_CORRENTE = threading.local()


class _Lavoro:
    """Una richiesta arrivata al server, in attesa che il programma Leo la gestisca."""

    def __init__(self, richiesta: dict) -> None:
        self.richiesta = richiesta
        self.risposta: Any = None
        self.fatto = threading.Event()


class ServerWeb(OggettoLibreria):
    """Piccolo server web su questo computer (127.0.0.1).

    Le pagine fisse (``pagine``) le serve un thread secondario, anche mentre
    il programma fa altro (``avvia``). Le richieste per il codice Leo
    (``quando server.richiesta`` o una funzione ``gestore``) vengono invece
    passate al thread del programma da ``servi``: il codice Leo gira sempre
    in un solo thread.
    """

    NOME_TIPO_DANTE = "server_web"
    SUGGERIMENTO_MODIFICA = "Per aggiungere una pagina usa `server.aggiungi_pagina(percorso, contenuto)`."
    ATTESA_MASSIMA = 30.0

    def __init__(self, porta: int, pagine: dict, nome: str) -> None:
        self.porta_richiesta = porta
        self.pagine = pagine
        self.nome_eventi = nome
        self.servite = 0
        self._coda: queue.Queue[_Lavoro] = queue.Queue()
        self._in_servizio = False
        self._stop = threading.Event()
        self._locale = rete.ServerLocale(porta, self._gestisci)

    def testo_dante(self) -> str:
        return f"<server_web {self._locale.indirizzo or 'spento'}>"

    # -- thread del server -------------------------------------------------------
    def _gestisci(self, richiesta: dict) -> Any:
        percorso = richiesta["percorso"]
        if percorso in self.pagine and richiesta["metodo"] in ("GET", "HEAD"):
            self.servite += 1
            return self.pagine[percorso]
        if not self._in_servizio:
            return {"stato": 404, "testo": f"Pagina non trovata: {percorso}"}
        lavoro = _Lavoro(richiesta)
        self._coda.put(lavoro)
        if not lavoro.fatto.wait(self.ATTESA_MASSIMA):
            return {"stato": 503, "testo": "Il programma non ha risposto in tempo."}
        return lavoro.risposta

    # -- comandi -----------------------------------------------------------------
    def avvia(self) -> None:
        self._locale.avvia()

    def ferma(self) -> None:
        self._stop.set()
        self._in_servizio = False
        self._locale.ferma()
        # chi aspettava una risposta riceve un 503 invece di restare appeso
        while True:
            try:
                lavoro = self._coda.get_nowait()
            except queue.Empty:
                break
            lavoro.risposta = {"stato": 503, "testo": "Il server si sta spegnendo."}
            lavoro.fatto.set()


def _porta(porta: Any, nome: str) -> int:
    if isinstance(porta, bool) or not isinstance(porta, int) or not 0 <= porta <= 65535:
        raise ErroreValore(f"`porta` di `{nome}` deve essere un intero tra 1024 e 65535 (0 = una porta libera).",
                           suggerimento="Esempio: `server_web(8080)`.")
    return porta


def _controlla_pagine(pagine: Any) -> dict:
    risultato = {}
    for percorso, contenuto in pagine.items():
        if not isinstance(percorso, str) or not percorso.startswith("/"):
            raise ErroreValore(f"Il percorso di pagina {mostra(percorso)} deve cominciare con \"/\".",
                               suggerimento="Esempio: {\"/\": \"<h1>Ciao</h1>\", \"/dati\": {\"voto\": 30}}.")
        risultato[percorso] = _risposta_da(contenuto, None, None, None, "server_web")
    return risultato


@funzione_libreria("server_web")
def server_web(porta=8080, pagina=None, pagine=None, nome="server"):
    """server_web(porta = 8080, pagina = nulla, pagine = nulla, nome = "server"): crea un piccolo server web su questo computer.

    `pagina` è il contenuto dell'indirizzo "/" (HTML o testo); `pagine` un dizionario
    percorso -> contenuto (un dizionario o una lista diventano JSON). `porta = 0` sceglie una
    porta libera. Poi `server.avvia()` accende il server e il programma prosegue (serve solo
    le pagine fisse); `server.servi()` resta ad ascoltare e manda ogni altra richiesta a
    `quando server.richiesta fai ... fine` (i dati sono in `evento`, la risposta con `rispondi`).
    Esempio: `variabile server = server_web(8080, pagina = "<h1>Ciao!</h1>")`.
    """
    porta = _porta(porta, "server_web")
    richiedi_testo(nome, "server_web", "nome")
    tutte: dict = {}
    if pagine is not None:
        if not isinstance(pagine, dict):
            raise ErroreTipo(f"`pagine` di `server_web` deve essere un dizionario percorso -> contenuto, "
                             f"non {articolo(pagine)}.")
        tutte.update(_controlla_pagine(pagine))
    if pagina is not None:
        tutte["/"] = _risposta_da(pagina, None, None, None, "server_web")
    return ServerWeb(porta, tutte, nome.strip())


@proprieta(ServerWeb, "indirizzo")
def _server_indirizzo(s: ServerWeb) -> str:
    return s._locale.indirizzo


@proprieta(ServerWeb, "porta")
def _server_porta(s: ServerWeb) -> int:
    server = s._locale._server
    return int(server.server_address[1]) if server is not None else s.porta_richiesta


@proprieta(ServerWeb, "attivo")
def _server_attivo(s: ServerWeb) -> bool:
    return s._locale.attivo


@proprieta(ServerWeb, "richieste_servite")
def _server_servite(s: ServerWeb) -> int:
    return s.servite


@metodo_oggetto(ServerWeb, "avvia")
def server_avvia(s):
    """server.avvia(): accende il server senza fermare il programma (serve le pagine fisse).

    L'indirizzo da aprire nel browser è `server.indirizzo`.
    """
    s.avvia()
    return None


@metodo_oggetto(ServerWeb, "ferma")
def server_ferma(s):
    """server.ferma(): spegne il server (dentro `quando server.richiesta` termina `servi` dopo questa risposta)."""
    s.ferma()
    return None


@metodo_oggetto(ServerWeb, "aggiungi_pagina")
def server_aggiungi_pagina(s, percorso, contenuto):
    """server.aggiungi_pagina(percorso, contenuto): aggiunge (o sostituisce) una pagina fissa.

    Esempio: `server.aggiungi_pagina("/info", "<p>Fatto con Leo</p>")`.
    """
    s.pagine.update(_controlla_pagine({percorso: contenuto}))
    return None


def _cerca_gestore(interprete: Any, nome: str) -> str | None:
    """Il controllo del blocco ``quando <nome>.richiesta``; se il nome è diverso ma c'è un
    solo blocco ``quando ....richiesta`` nel programma, quello (la variabile può chiamarsi
    come vuoi)."""
    gestori = getattr(interprete, "gestori_evento", {}) or {}
    if (nome, "richiesta") in gestori:
        return nome
    candidati = [c for (c, e) in gestori if e == "richiesta"]
    return candidati[0] if len(candidati) == 1 else None


@metodo_oggetto(ServerWeb, "servi", interprete=True)
def server_servi(interprete, s, gestore=None, richieste=None, secondi=None):
    """server.servi(gestore = nulla, richieste = nulla, secondi = nulla): ascolta e risponde alle richieste.

    Ogni richiesta (tranne le pagine fisse) va a `quando server.richiesta fai ... fine`
    (scritto PRIMA di `servi`), oppure alla funzione `gestore(richiesta)` se la passi. La
    richiesta ha `percorso`, `metodo`, `parametri`, `corpo`, `json`, `intestazioni`, `cliente`.
    Si ferma dopo `richieste` richieste, dopo `secondi` secondi, con `server.ferma()` o con Ctrl+C.
    Restituisce quante richieste ha servito.
    Esempio: `server.servi(richieste = 10)`.
    """
    if gestore is not None and not isinstance(gestore, Richiamabile):
        raise ErroreTipo(f"`gestore` di `servi` deve essere una funzione, non {articolo(gestore)}.",
                         suggerimento="Esempio: `server.servi(funzione (richiesta) restituisci \"Ciao\" fine)`.")
    for valore, parametro in ((richieste, "richieste"), (secondi, "secondi")):
        if valore is not None and (isinstance(valore, bool) or not isinstance(valore, (int, float))
                                   or valore <= 0 or (parametro == "richieste" and not isinstance(valore, int))):
            raise ErroreValore(f"`{parametro}` di `servi` deve essere un numero maggiore di zero.")
    controllo = _cerca_gestore(interprete, s.nome_eventi) if gestore is None else None
    usa_quando = controllo is not None
    if usa_quando:
        s.nome_eventi = controllo
    if gestore is None and not usa_quando and not s.pagine:
        raise ErroreValore(
            "Il server non ha niente da servire.",
            suggerimento=f"Scrivi prima di `servi` un blocco `quando {s.nome_eventi}.richiesta fai ... fine`, "
                         "oppure passa `pagina = ...` a `server_web`.")
    s._stop.clear()
    s.avvia()
    s._in_servizio = True
    servite = 0
    fine_tempo = time.monotonic() + secondi if secondi is not None else None
    try:
        while not s._stop.is_set():
            if richieste is not None and servite >= richieste:
                break
            if getattr(interprete, "_ferma_richiesta", False):
                break
            attesa = 0.2
            if fine_tempo is not None:
                rimasto = fine_tempo - time.monotonic()
                if rimasto <= 0:
                    break
                attesa = min(attesa, rimasto)
            try:
                lavoro = s._coda.get(timeout=attesa)
            except queue.Empty:
                continue
            try:
                lavoro.risposta = _esegui_gestore(interprete, s, gestore, usa_quando, lavoro.richiesta)
            except ErroreDante as e:
                lavoro.risposta = {"stato": 500, "testo": f"Errore nel programma: {e.messaggio}"}
                raise
            except BaseException:
                lavoro.risposta = {"stato": 500, "testo": "Errore nel programma."}
                raise
            finally:
                lavoro.fatto.set()
                servite += 1
                s.servite += 1
    finally:
        s._in_servizio = False
    return servite


def _esegui_gestore(interprete: Any, s: ServerWeb, gestore: Any, usa_quando: bool, richiesta: dict) -> Any:
    precedente = getattr(_CORRENTE, "risposta", None), getattr(_CORRENTE, "attiva", False)
    _CORRENTE.risposta, _CORRENTE.attiva = None, True
    try:
        if gestore is not None:
            valore = interprete.chiama(gestore, [dict(richiesta)])
        elif usa_quando:
            interprete.chiama_gestore(s.nome_eventi, "richiesta", dict(richiesta))
            valore = None
        else:
            valore = None
        preparata = _CORRENTE.risposta
    finally:
        _CORRENTE.risposta, _CORRENTE.attiva = precedente
    if preparata is not None:
        return preparata
    if valore is not None:
        return _risposta_da(valore, None, None, None, "servi")
    if gestore is None and not usa_quando:
        return {"stato": 404, "testo": f"Pagina non trovata: {richiesta['percorso']}"}
    return {"stato": 204, "testo": ""}


def _risposta_da(contenuto: Any, stato: Any, tipo: Any, intestazioni: Any, nome: str) -> dict:
    """Contenuto Leo -> dizionario di risposta per ``rete._prepara_risposta``."""
    risposta: dict = {}
    if isinstance(contenuto, (dict, list)):
        risposta["json"] = contenuto
        try:
            _json.dumps(contenuto)
        except (TypeError, ValueError):
            raise ErroreTipo(f"`{nome}`: questo contenuto non si può inviare come JSON.") from None
    elif contenuto is None:
        risposta["testo"] = ""
    elif isinstance(contenuto, str):
        risposta["testo"] = contenuto
    elif isinstance(contenuto, (bool, int, float)):
        risposta["json"] = contenuto
    else:
        raise ErroreTipo(f"`{nome}` può inviare un testo, un numero, una lista o un dizionario, "
                         f"non {articolo(contenuto)}.")
    if stato is not None:
        if isinstance(stato, bool) or not isinstance(stato, int) or not 100 <= stato <= 599:
            raise ErroreValore(f"`stato` di `{nome}` deve essere un codice HTTP tra 100 e 599, non {mostra(stato)}.")
        risposta["stato"] = stato
    if tipo is not None:
        richiedi_testo(tipo, nome, "tipo")
        risposta["tipo"] = tipo
    if intestazioni is not None:
        _richiedi_dizionario(intestazioni, nome, "intestazioni")
        risposta["intestazioni"] = {str(k): _testo_semplice(v) for k, v in intestazioni.items()}
    risposta.setdefault("stato", 200)
    return risposta


@funzione_libreria("rispondi")
def rispondi(contenuto=None, stato=200, tipo=None, intestazioni=None):
    """rispondi(contenuto = nulla, stato = 200, tipo = nulla, intestazioni = nulla): la risposta alla richiesta del server web.

    Si usa dentro `quando server.richiesta fai ... fine`. Un testo che comincia con `<html>` o
    `<!doctype` è una pagina HTML, un dizionario o una lista diventano JSON.
    Esempi: `rispondi("<h1>Ciao {evento["parametri"]["nome"]}</h1>")`,
    `rispondi({"errore": "non trovato"}, stato = 404)`.
    """
    if not getattr(_CORRENTE, "attiva", False):
        raise ErroreValore("`rispondi` si usa solo mentre il server web gestisce una richiesta.",
                           suggerimento="Scrivilo dentro `quando server.richiesta fai ... fine` e poi chiama "
                                        "`server.servi()`.")
    _CORRENTE.risposta = _risposta_da(contenuto, stato, tipo, intestazioni, "rispondi")
    return None


__all__ += ["scarica_pagina", "scarica_testo", "scarica_json", "scarica_file", "richiesta_web",
            "richiesta_get", "richiesta_post", "codifica_url", "decodifica_url", "componi_url",
            "connessione_attiva", "internet_disponibile", "invia_email", "server_web", "rispondi"]
