"""Valori "con proprietà e metodi" della libreria (``data``, ``cronometro``...).

Si appoggiano al protocollo di :class:`leo.valori.OggettoControllo` che
l'interprete già conosce: ``d.giorno`` legge una proprietà (senza parentesi),
``d.aggiungi_giorni(3)`` chiama un metodo. Così i nuovi tipi non hanno
bisogno di voci in ``registro.METODI`` e i messaggi d'errore restano in
italiano (proprietà sconosciuta con suggerimento, oggetto che non si può
modificare).

Per creare un tipo: sottoclasse di :class:`OggettoLibreria` con
``NOME_TIPO_DANTE``, e poi i decoratori :func:`proprieta` e
:func:`metodo_oggetto` sulla classe.
"""

from __future__ import annotations

import difflib
from typing import Any, Callable

from .. import permessi as _permessi
from ..errori import ErroreNome, ErroreTipo
from ..valori import FunzioneNativa, MetodoLegato, OggettoControllo, Richiamabile


class OggettoLibreria(OggettoControllo):
    """Base dei valori della libreria che hanno proprietà (sola lettura) e metodi."""

    NOME_TIPO_DANTE = "oggetto"
    #: Riconosce questi valori rispetto ai veri controlli grafici.
    E_VALORE_LIBRERIA = True
    _PROPRIETA: dict[str, Callable[[Any], Any]] = {}
    _METODI: dict[str, FunzioneNativa] = {}

    def __init_subclass__(cls, **kw: Any) -> None:
        super().__init_subclass__(**kw)
        cls._PROPRIETA = {}
        cls._METODI = {}

    # nomi usati da OggettoControllo / MetodoLegato nei messaggi
    @property
    def nome(self) -> str:  # type: ignore[override]
        return self.NOME_TIPO_DANTE

    @property
    def tipo_controllo(self) -> str:  # type: ignore[override]
        return self.NOME_TIPO_DANTE

    def metodo(self, nome: str) -> Richiamabile | None:
        f = self._METODI.get(nome)
        return MetodoLegato(self, f) if f is not None else None

    def leggi(self, proprieta: str) -> Any:
        lettore = self._PROPRIETA.get(proprieta)
        if lettore is not None:
            return lettore(self)
        tutti = sorted(self._PROPRIETA) + sorted(self._METODI)
        simili = difflib.get_close_matches(proprieta, tutti, n=1, cutoff=0.6)
        if simili:
            s = simili[0]
            suggerimento = f"Forse intendevi `{s}`" + ("()" if s in self._METODI else "") + "?"
        else:
            suggerimento = "Puoi usare: " + ", ".join(
                [f"`{p}`" for p in sorted(self._PROPRIETA)] + [f"`{m}()`" for m in sorted(self._METODI)]) + "."
        raise ErroreNome(f"Un valore di tipo `{self.NOME_TIPO_DANTE}` non ha `{proprieta}`.",
                         suggerimento=suggerimento, nome=proprieta)

    def scrivi(self, proprieta: str, valore: Any) -> None:
        raise ErroreTipo(f"Un valore di tipo `{self.NOME_TIPO_DANTE}` non si può modificare.",
                         suggerimento=self.SUGGERIMENTO_MODIFICA)

    SUGGERIMENTO_MODIFICA: str | None = None

    def elenco_proprieta(self) -> list[str]:
        return sorted(self._PROPRIETA)

    def elenco_metodi(self) -> list[str]:
        return sorted(self._METODI)


def proprieta(classe: type[OggettoLibreria], nome: str) -> Callable:
    """Decoratore: ``lettore(oggetto)`` diventa la proprietà ``oggetto.nome``."""

    def decora(f: Callable) -> Callable:
        classe._PROPRIETA[nome] = f
        return f

    return decora


def metodo_oggetto(classe: type[OggettoLibreria], nome: str, *, interprete: bool = False) -> Callable:
    """Decoratore: ``f(oggetto, ...)`` diventa il metodo ``oggetto.nome(...)``."""

    def decora(f: Callable) -> Callable:
        nativa = FunzioneNativa(nome, f, vuole_interprete=interprete, e_metodo=True)
        classe._METODI[nome] = _permessi.proteggi(nativa, None, f"{classe.NOME_TIPO_DANTE}.{nome}")
        return f

    return decora
