"""Libreria "scienza": matematica per la scuola, statistica, probabilità, geometria,
geografia, unità di misura, finanza italiana, chimica, equazioni, analisi e
un po' di intelligenza artificiale semplice e spiegabile.

Trenta funzioni, tutte con la sola libreria standard di Python (math, fractions,
decimal, statistics): funzionano identiche sul telefono e negli .exe.

* trigonometria e logaritmi: ``seno``, ``coseno``, ``tangente`` (in gradi, come a
  scuola), ``logaritmo``;
* statistica: ``correlazione``, ``regressione_lineare`` (una ``retta`` che sa
  ``prevedi``), ``percentile``, ``quartili``, ``normalizza``, ``media_mobile``,
  ``valori_anomali``;
* probabilità: ``combinazioni``, ``probabilita_normale``;
* geometria: ``area_triangolo``, ``ipotenusa``, ``misure_poligono``, ``volume_solido``;
* geografia e misure: ``distanza_gps``, ``converti``;
* finanza (con i ``soldi`` precisi al centesimo): ``interesse_composto``,
  ``rata_mutuo``, ``piano_ammortamento``;
* chimica: ``massa_molare``;
* equazioni e analisi: ``risolvi_equazione``, ``risolvi_sistema``, ``derivata``,
  ``integrale``;
* intelligenza artificiale: ``raggruppa_punti`` (k-medie), ``classifica_vicini``
  (k vicini), ``addestra_percettrone`` (un neurone che spiega cosa ha imparato).

I risultati decimali si arrotondano a 12 cifre significative: `seno(30)` è 0.5,
non 0.49999999999999994.
"""

from __future__ import annotations

import difflib
import math
import re
import unicodedata
from collections import Counter
from decimal import ROUND_HALF_UP, Decimal, localcontext
from fractions import Fraction
from typing import Any

from ..errori import ErroreTipo, ErroreValore
from ..valori import Richiamabile, e_intero, e_numero, rappresenta
from .funzionali import chiama_funzione, richiedi_funzione
from .generali import (articolo, funzione_libreria, lunghezza_intervallo, mostra, richiedi_intero,
                       richiedi_logico, richiedi_numero, richiedi_testo)
from .matematica_avanzata import SoldiDante, _importo
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta

#: Al massimo tanti elementi nelle liste di numeri (un intervallo più lungo si rifiuta).
MASSIMI_ELEMENTI = 1_000_000


# ===========================================================================
# Strumenti comuni
# ===========================================================================

def _troppo_grande(nome: str) -> ErroreValore:
    return ErroreValore(f"Il risultato di `{nome}` è troppo grande per essere calcolato.",
                        suggerimento="Prova con numeri più piccoli.")


def _reale(x: Any, nome: str, parametro: str) -> float:
    """Un numero finito come decimale Python (errori italiani per testi, infiniti, enormi)."""
    richiedi_numero(x, nome, parametro)
    try:
        f = float(x)
    except OverflowError:
        raise ErroreValore(f"Il numero `{parametro}` di `{nome}` è troppo grande.",
                           suggerimento="Usa numeri con meno cifre.") from None
    if math.isnan(f) or math.isinf(f):
        raise ErroreValore(f"`{nome}` non può usare {rappresenta(x)} come `{parametro}`.",
                           suggerimento="Serve un numero normale, per esempio 3 o 2.5.")
    return f


def _positivo(x: Any, nome: str, parametro: str, *, zero: bool = False) -> float:
    f = _reale(x, nome, parametro)
    if f < 0 or (f == 0 and not zero):
        cosa = "negativo" if zero else "zero o negativo"
        raise ErroreValore(f"In `{nome}` il valore `{parametro}` non può essere {cosa} (hai scritto {rappresenta(x)}).",
                           suggerimento="Le misure sono numeri positivi, per esempio 3 o 2.5.")
    return f


def _razionale(x: Any, nome: str, parametro: str) -> Fraction:
    """Il numero esatto: 0.1 resta un decimo (non 0.1000000000000000055...)."""
    richiedi_numero(x, nome, parametro)
    if e_intero(x):
        return Fraction(x)
    _reale(x, nome, parametro)
    return Fraction(Decimal(repr(float(x))))


def _bello(x: float, nome: str = "calcolo") -> float:
    """12 cifre significative: toglie la "polvere" dei decimali binari."""
    if math.isnan(x) or math.isinf(x):
        raise _troppo_grande(nome)
    if x == 0:
        return 0.0
    return float(f"{x:.12g}")


def _da_razionale(q: Fraction, nome: str) -> int | float:
    if q.denominator == 1:
        return q.numerator
    try:
        return _bello(q.numerator / q.denominator, nome)
    except OverflowError:
        raise _troppo_grande(nome) from None


def _numeri(valore: Any, nome: str, parametro: str = "lista", *, minimo: int = 1) -> list[float]:
    """Lista (o intervallo) di numeri finiti come decimali Python."""
    if isinstance(valore, range):
        if lunghezza_intervallo(valore) > MASSIMI_ELEMENTI:
            raise ErroreValore(f"L'intervallo è troppo lungo per `{nome}` (al massimo {MASSIMI_ELEMENTI} numeri).")
        valore = list(valore)
    if not isinstance(valore, list):
        raise ErroreTipo(f"L'argomento `{parametro}` di `{nome}` deve essere una lista di numeri, "
                         f"non {articolo(valore)}.",
                         suggerimento=f"Esempio: `{nome}([3, 5, 8, 13])`.")
    if len(valore) > MASSIMI_ELEMENTI:
        raise ErroreValore(f"La lista è troppo lunga per `{nome}` (al massimo {MASSIMI_ELEMENTI} numeri).")
    risultato = []
    for v in valore:
        if not e_numero(v):
            suggerimento = ("Trasforma prima i testi in numeri: `mappa(lista, decimale)`."
                            if isinstance(v, str) else None)
            raise ErroreTipo(f"`{nome}` lavora solo con numeri, ma nella lista c'è {articolo(v)} ({mostra(v)}).",
                             suggerimento=suggerimento)
        risultato.append(_reale(v, nome, parametro))
    if len(risultato) < minimo:
        if not risultato:
            raise ErroreValore(f"Non posso calcolare `{nome}` di una lista vuota.",
                               suggerimento="Controlla prima con `se non vuota(lista) allora`.")
        raise ErroreValore(f"Per `{nome}` servono almeno {minimo} numeri (ne hai dati {len(risultato)}).")
    return risultato


def _punto(valore: Any, nome: str, parametro: str) -> list[float]:
    """Un punto: un numero (una sola dimensione) o una lista di coordinate."""
    if e_numero(valore):
        return [_reale(valore, nome, parametro)]
    if isinstance(valore, list) and valore:
        if len(valore) > 1000:
            raise ErroreValore(f"Il punto `{parametro}` di `{nome}` ha troppe coordinate.")
        return [_reale(c, nome, parametro) for c in _numeri(valore, nome, parametro)]
    raise ErroreTipo(f"`{nome}` vuole come `{parametro}` un punto: un numero oppure una lista come [3, 4], "
                     f"non {articolo(valore)}.",
                     suggerimento="Esempio di punto sul piano: [2, 5] (x = 2, y = 5).")


def _punti(valore: Any, nome: str, parametro: str = "punti", *, minimo: int = 1) -> list[list[float]]:
    if isinstance(valore, range):
        if lunghezza_intervallo(valore) > 100_000:
            raise ErroreValore(f"Troppi punti per `{nome}` (al massimo 100000).")
        valore = list(valore)
    if not isinstance(valore, list):
        raise ErroreTipo(f"L'argomento `{parametro}` di `{nome}` deve essere una lista di punti, "
                         f"non {articolo(valore)}.",
                         suggerimento="Esempio: [[1, 2], [2, 1], [8, 9]] oppure [3, 5, 40].")
    if len(valore) > 100_000:
        raise ErroreValore(f"Troppi punti per `{nome}` (al massimo 100000).")
    punti = [_punto(p, nome, parametro) for p in valore]
    if len(punti) < minimo:
        raise ErroreValore(f"Per `{nome}` servono almeno {minimo} punti (ne hai dati {len(punti)}).")
    if punti and any(len(p) != len(punti[0]) for p in punti):
        raise ErroreValore(f"In `{nome}` tutti i punti devono avere lo stesso numero di coordinate.",
                           suggerimento="Per esempio tutti [x, y] oppure tutti [x, y, z].")
    return punti


def _distanza2(a: list[float], b: list[float]) -> float:
    return math.fsum((x - y) * (x - y) for x, y in zip(a, b))


def _coppie(x: Any, y: Any, nome: str) -> tuple[list[float], list[float]]:
    """Due liste della stessa lunghezza, oppure una sola lista di coppie [x, y]."""
    if y is None:
        if isinstance(x, list) and all(isinstance(p, list) and len(p) == 2 for p in x):
            return (_numeri([p[0] for p in x], nome, "x", minimo=2),
                    _numeri([p[1] for p in x], nome, "y", minimo=2))
        raise ErroreTipo(f"`{nome}` vuole due liste di numeri (x e y) oppure una lista di coppie [x, y].",
                         suggerimento=f"Esempio: `{nome}([1, 2, 3], [2, 4, 6])`.")
    xs = _numeri(x, nome, "x", minimo=2)
    ys = _numeri(y, nome, "y", minimo=2)
    if len(xs) != len(ys):
        raise ErroreValore(f"In `{nome}` le due liste devono essere lunghe uguali ({len(xs)} e {len(ys)}).",
                           suggerimento="A ogni x corrisponde una y: controlla di non aver dimenticato un numero.")
    return xs, ys


# ===========================================================================
# Trigonometria e logaritmi
# ===========================================================================

def _angolo_radianti(angolo: Any, radianti: Any, nome: str) -> float:
    richiedi_logico(radianti, nome, "radianti")
    richiedi_numero(angolo, nome, "angolo")
    if radianti:
        return _reale(angolo, nome, "angolo")
    if e_intero(angolo):
        angolo = angolo % 360          # anche per interi enormi: il giro si ripete
    gradi = _reale(angolo, nome, "angolo")
    return math.radians(math.fmod(gradi, 360.0))


def _seno_coseno(r: float) -> tuple[float, float]:
    # 12 cifre dopo la virgola: seno(180) è 0, non 1.2e-16
    return round(math.sin(r), 12) + 0.0, round(math.cos(r), 12) + 0.0


@funzione_libreria("seno")
def seno(angolo, radianti=False):
    """seno(angolo, radianti = falso): il seno dell'angolo, in gradi come a scuola.

    Esempi: `seno(30)` è 0.5, `seno(90)` è 1.0. Con `radianti = vero` l'angolo è in radianti:
    `seno(PI_GRECO / 2, radianti = vero)` è 1.0.
    """
    return _seno_coseno(_angolo_radianti(angolo, radianti, "seno"))[0]


@funzione_libreria("coseno")
def coseno(angolo, radianti=False):
    """coseno(angolo, radianti = falso): il coseno dell'angolo, in gradi come a scuola.

    Esempi: `coseno(60)` è 0.5, `coseno(180)` è -1.0.
    """
    return _seno_coseno(_angolo_radianti(angolo, radianti, "coseno"))[1]


@funzione_libreria("tangente")
def tangente(angolo, radianti=False):
    """tangente(angolo, radianti = falso): la tangente dell'angolo (seno diviso coseno), in gradi.

    Esempio: `tangente(45)` è 1.0. Non esiste per 90 e 270 gradi.
    """
    r = _angolo_radianti(angolo, radianti, "tangente")
    s, c = _seno_coseno(r)
    if c == 0:
        raise ErroreValore(f"La tangente di {rappresenta(angolo)} {'radianti' if radianti else 'gradi'} non esiste: "
                           "il coseno è zero.",
                           suggerimento="La tangente non esiste per 90 e 270 gradi (la retta è verticale).")
    if s == 0:
        return 0.0
    return _bello(math.tan(r), "tangente")


@funzione_libreria("logaritmo")
def logaritmo(x, base=10):
    """logaritmo(x, base = 10): l'esponente a cui elevare la base per ottenere x.

    Esempi: `logaritmo(1000)` è 3.0, `logaritmo(8, 2)` è 3.0. Con `base = "e"` è il logaritmo
    naturale: `logaritmo(1, "e")` è 0.0.
    """
    richiedi_numero(x, "logaritmo", "x")
    if isinstance(x, float):
        _reale(x, "logaritmo", "x")
    if x <= 0:
        raise ErroreValore(f"Il logaritmo esiste solo per numeri maggiori di zero (hai scritto {rappresenta(x)}).",
                           suggerimento="Nessun esponente fa diventare 10 uguale a zero o negativo.")
    if isinstance(base, str):
        if base.strip().lower() != "e":
            raise ErroreValore(f"La base del logaritmo è un numero oppure \"e\", non {mostra(base)}.")
        return _bello(math.log(x), "logaritmo")
    richiedi_numero(base, "logaritmo", "base")
    if isinstance(base, float):
        _reale(base, "logaritmo", "base")
    if base <= 0 or base == 1:
        raise ErroreValore(f"La base del logaritmo deve essere maggiore di zero e diversa da 1 "
                           f"(hai scritto {rappresenta(base)}).",
                           suggerimento="Le basi più usate sono 10, 2 e \"e\".")
    if base == 10:
        return _bello(math.log10(x), "logaritmo")
    if base == 2:
        return _bello(math.log2(x), "logaritmo")
    return _bello(math.log(x) / math.log(base), "logaritmo")


# ===========================================================================
# Statistica
# ===========================================================================

def _media(v: list[float]) -> float:
    return math.fsum(v) / len(v)


def _covarianze(xs: list[float], ys: list[float]) -> tuple[float, float, float]:
    mx, my = _media(xs), _media(ys)
    dx = [x - mx for x in xs]
    dy = [y - my for y in ys]
    try:
        return (math.fsum(a * b for a, b in zip(dx, dy)), math.fsum(a * a for a in dx),
                math.fsum(b * b for b in dy))
    except OverflowError:  # pragma: no cover - fsum dà infinito, non solleva
        raise _troppo_grande("correlazione") from None


@funzione_libreria("correlazione")
def correlazione(x, y=None):
    """correlazione(x, y): quanto due liste di numeri "vanno insieme", da -1 a 1.

    1 vuol dire che crescono insieme in modo perfetto, -1 che quando una cresce l'altra cala,
    0 che non c'è legame. Esempio: `correlazione([1, 2, 3, 4], [2, 4, 5, 8])` è circa 0.98.
    Accetta anche una lista di coppie: `correlazione([[1, 2], [2, 4], [3, 5]])`.
    """
    xs, ys = _coppie(x, y, "correlazione")
    sxy, sxx, syy = _covarianze(xs, ys)
    if sxx == 0 or syy == 0:
        raise ErroreValore("Per la `correlazione` i numeri di ogni lista non possono essere tutti uguali.",
                           suggerimento="Se una lista non cambia mai, non si può dire se va insieme all'altra.")
    r = sxy / math.sqrt(sxx) / math.sqrt(syy)
    if math.isnan(r) or math.isinf(r):
        raise _troppo_grande("correlazione")
    return _bello(max(-1.0, min(1.0, r)), "correlazione")


class RettaDante(OggettoLibreria):
    """Valore Leo di tipo ``retta``: y = pendenza · x + intercetta."""

    NOME_TIPO_DANTE = "retta"
    SUGGERIMENTO_MODIFICA = "Calcola una retta nuova con `regressione_lineare(x, y)`."

    def __init__(self, pendenza: float, intercetta: float, r2: float) -> None:
        self.pendenza = pendenza
        self.intercetta = intercetta
        self.r2 = r2

    def testo_dante(self) -> str:
        p, q = rappresenta(self.pendenza), rappresenta(abs(self.intercetta))
        segno = "-" if self.intercetta < 0 else "+"
        return f"y = {p} · x {segno} {q}"

    def __repr__(self) -> str:
        return f"RettaDante({self.testo_dante()!r})"


proprieta(RettaDante, "pendenza")(lambda r: r.pendenza)
proprieta(RettaDante, "intercetta")(lambda r: r.intercetta)
proprieta(RettaDante, "affidabilita")(lambda r: r.r2)


@metodo_oggetto(RettaDante, "prevedi")
def retta_prevedi(r, x):
    """retta.prevedi(x): il valore di y che la retta prevede per x. Esempio: `r.prevedi(10)`."""
    return _bello(r.pendenza * _reale(x, "prevedi", "x") + r.intercetta, "prevedi")


@funzione_libreria("regressione_lineare")
def regressione_lineare(x, y=None):
    """regressione_lineare(x, y): la retta che passa più vicina a tutti i punti (minimi quadrati).

    Restituisce una `retta` con le proprietà `pendenza`, `intercetta` e `affidabilita` (da 0 a 1:
    1 vuol dire che i punti stanno tutti sulla retta) e il metodo `prevedi(x)`.
    Esempio: `r = regressione_lineare([1, 2, 3], [3, 5, 7])` dà la retta y = 2·x + 1 e `r.prevedi(10)` è 21.0.
    """
    xs, ys = _coppie(x, y, "regressione_lineare")
    sxy, sxx, syy = _covarianze(xs, ys)
    if sxx == 0:
        raise ErroreValore("Per la `regressione_lineare` servono almeno due valori di x diversi.",
                           suggerimento="Con tutti gli x uguali la retta sarebbe verticale.")
    pendenza = sxy / sxx
    intercetta = _media(ys) - pendenza * _media(xs)
    r2 = 1.0 if syy == 0 else min(1.0, (sxy * sxy) / (sxx * syy))
    if any(math.isnan(v) or math.isinf(v) for v in (pendenza, intercetta, r2)):
        raise _troppo_grande("regressione_lineare")
    return RettaDante(_bello(pendenza), _bello(intercetta), _bello(r2))


def _percentile(ordinati: list[float], p: float) -> float:
    posizione = (len(ordinati) - 1) * p / 100
    basso = math.floor(posizione)
    alto = min(basso + 1, len(ordinati) - 1)
    frazione = posizione - basso
    return ordinati[basso] + (ordinati[alto] - ordinati[basso]) * frazione


@funzione_libreria("percentile")
def percentile(lista, p):
    """percentile(lista, p): il valore sotto cui sta il p per cento dei numeri (p da 0 a 100).

    Esempio: `percentile([10, 20, 30, 40, 50], 90)` è 46.0: il 90% dei valori è sotto 46.
    `percentile(lista, 50)` è la mediana.
    """
    dati = sorted(_numeri(lista, "percentile"))
    q = _reale(p, "percentile", "p")
    if not 0 <= q <= 100:
        raise ErroreValore(f"Il percentile `p` va da 0 a 100 (hai scritto {rappresenta(p)}).",
                           suggerimento="Per esempio 25 (primo quartile), 50 (mediana) o 90.")
    return _bello(_percentile(dati, q), "percentile")


@funzione_libreria("quartili")
def quartili(lista):
    """quartili(lista): i tre numeri che dividono i dati ordinati in quattro parti uguali.

    Restituisce [primo, secondo (la mediana), terzo]. Esempio: `quartili([1, 2, 3, 4, 5])` è [2.0, 3.0, 4.0].
    """
    dati = sorted(_numeri(lista, "quartili"))
    return [_bello(_percentile(dati, q), "quartili") for q in (25, 50, 75)]


@funzione_libreria("normalizza")
def normalizza(lista):
    """normalizza(lista): porta i numeri tra 0 e 1 (il più piccolo diventa 0, il più grande 1).

    Utile per confrontare misure diverse o prepararle per l'intelligenza artificiale.
    Esempio: `normalizza([10, 15, 20])` è [0.0, 0.5, 1.0].
    """
    dati = _numeri(lista, "normalizza")
    basso, alto = min(dati), max(dati)
    if basso == alto:
        raise ErroreValore("Non posso normalizzare una lista di numeri tutti uguali.",
                           suggerimento="Serve almeno un numero diverso dagli altri.")
    ampiezza = alto - basso
    if math.isinf(ampiezza):
        raise _troppo_grande("normalizza")
    return [_bello((v - basso) / ampiezza) for v in dati]


@funzione_libreria("media_mobile")
def media_mobile(lista, finestra=3):
    """media_mobile(lista, finestra = 3): le medie di ogni gruppo di `finestra` numeri vicini.

    Serve a "lisciare" i dati che saltano su e giù (temperature, voti, prezzi).
    Esempio: `media_mobile([1, 2, 3, 4, 5], 3)` è [2.0, 3.0, 4.0].
    """
    dati = _numeri(lista, "media_mobile")
    richiedi_intero(finestra, "media_mobile", "finestra")
    if not 1 <= finestra <= len(dati):
        raise ErroreValore(f"La `finestra` di `media_mobile` va da 1 a {len(dati)} (quanti sono i numeri); "
                           f"hai scritto {finestra}.",
                           suggerimento="Di solito si usano 3, 5 o 7 numeri alla volta.")
    return [_bello(math.fsum(dati[i:i + finestra]) / finestra, "media_mobile")
            for i in range(len(dati) - finestra + 1)]


@funzione_libreria("valori_anomali")
def valori_anomali(lista):
    """valori_anomali(lista): i numeri molto lontani dagli altri (regola di Tukey sui quartili).

    Un valore è anomalo se sta sotto Q1 - 1.5·(Q3 - Q1) o sopra Q3 + 1.5·(Q3 - Q1).
    Esempio: `valori_anomali([10, 12, 11, 13, 12, 95])` è [95]. Restituisce i valori nell'ordine della lista.
    """
    dati = _numeri(lista, "valori_anomali")
    ordinati = sorted(dati)
    q1, q3 = _percentile(ordinati, 25), _percentile(ordinati, 75)
    salto = 1.5 * (q3 - q1)
    basso, alto = q1 - salto, q3 + salto
    originali = lista if isinstance(lista, list) else list(lista)
    return [o for o, v in zip(originali, dati) if v < basso or v > alto]


# ===========================================================================
# Probabilità
# ===========================================================================

_MASSIME_COMBINAZIONI = 100_000


@funzione_libreria("combinazioni")
def combinazioni(n, k):
    """combinazioni(n, k): in quanti modi si scelgono k cose tra n, senza badare all'ordine.

    Esempio: `combinazioni(90, 6)` è 622614630 (le sestine possibili del Superenalotto).
    Se `n` è una lista, restituisce le scelte vere e proprie:
    `combinazioni(["a", "b", "c"], 2)` è [["a", "b"], ["a", "c"], ["b", "c"]].
    """
    richiedi_intero(k, "combinazioni", "k")
    if isinstance(n, list):
        if not 0 <= k <= len(n):
            raise ErroreValore(f"In `combinazioni` puoi scegliere da 0 a {len(n)} elementi (hai scritto {k}).")
        if math.comb(len(n), k) > _MASSIME_COMBINAZIONI:
            raise ErroreValore(f"Le combinazioni sono troppe da elencare (più di {_MASSIME_COMBINAZIONI}).",
                               suggerimento=f"Per sapere solo quante sono scrivi `combinazioni({len(n)}, {k})`.")
        from itertools import combinations
        return [list(c) for c in combinations(n, k)]
    if not e_intero(n):
        raise ErroreTipo(f"Il primo argomento di `combinazioni` deve essere un intero o una lista, non {articolo(n)}.",
                         suggerimento="Esempio: `combinazioni(5, 2)` è 10.")
    if n < 0 or k < 0:
        raise ErroreValore("In `combinazioni(n, k)` i numeri non possono essere negativi.")
    if k > n:
        return 0
    if n > 1_000_000 and min(k, n - k) > 1000:
        raise ErroreValore("Il numero di combinazioni è troppo grande da calcolare.",
                           suggerimento="Prova con numeri più piccoli.")
    return math.comb(n, k)


@funzione_libreria("probabilita_normale")
def probabilita_normale(x, media=0, deviazione=1):
    """probabilita_normale(x, media = 0, deviazione = 1): la probabilità che un valore "a campana"
    (distribuzione normale o di Gauss) sia minore o uguale a x.

    Esempio: se le altezze hanno media 170 e deviazione 10, `probabilita_normale(180, 170, 10)` è circa
    0.841: l'84% delle persone è alto al massimo 180 cm.
    """
    v = _reale(x, "probabilita_normale", "x")
    m = _reale(media, "probabilita_normale", "media")
    d = _positivo(deviazione, "probabilita_normale", "deviazione")
    z = (v - m) / d
    if math.isinf(z) or math.isnan(z):
        return 1.0 if v > m else 0.0
    return _bello(0.5 * math.erfc(-z / math.sqrt(2)), "probabilita_normale")


# ===========================================================================
# Geometria
# ===========================================================================

@funzione_libreria("area_triangolo")
def area_triangolo(a, b, c=None):
    """area_triangolo(a, b, c): l'area di un triangolo dai tre lati (formula di Erone).

    Esempio: `area_triangolo(3, 4, 5)` è 6.0. Con due soli numeri sono base e altezza:
    `area_triangolo(10, 3)` è 15.0.
    """
    if c is None:
        base = _positivo(a, "area_triangolo", "base")
        altezza = _positivo(b, "area_triangolo", "altezza")
        return _bello(base * altezza / 2, "area_triangolo")
    lati = sorted((_positivo(a, "area_triangolo", "a"), _positivo(b, "area_triangolo", "b"),
                   _positivo(c, "area_triangolo", "c")), reverse=True)
    x, y, z = lati  # x il più lungo
    if x > y + z:
        raise ErroreValore(f"Con i lati {rappresenta(a)}, {rappresenta(b)} e {rappresenta(c)} non si forma un triangolo.",
                           suggerimento="Il lato più lungo deve essere più corto della somma degli altri due.")
    # formula di Erone "stabile" (Kahan): precisa anche per triangoli molto schiacciati
    prodotto = (x + (y + z)) * (z - (x - y)) * (z + (x - y)) * (x + (y - z))
    if math.isinf(prodotto):
        raise _troppo_grande("area_triangolo")
    return _bello(math.sqrt(max(prodotto, 0.0)) / 4, "area_triangolo")


@funzione_libreria("ipotenusa")
def ipotenusa(a, b):
    """ipotenusa(a, b): il lato lungo di un triangolo rettangolo dai due cateti (teorema di Pitagora).

    Esempio: `ipotenusa(3, 4)` è 5.0. Per trovare un cateto: `radice(ipotenusa * ipotenusa - cateto * cateto)`.
    """
    x = _positivo(a, "ipotenusa", "a")
    y = _positivo(b, "ipotenusa", "b")
    return _bello(math.hypot(x, y), "ipotenusa")


@funzione_libreria("misure_poligono")
def misure_poligono(lati, lato):
    """misure_poligono(lati, lato): perimetro, area, apotema e angolo interno di un poligono regolare.

    Restituisce un dizionario. Esempio: `misure_poligono(6, 2)["area"]` è 10.3923048454 (esagono di lato 2);
    `misure_poligono(4, 3)` dà perimetro 12, area 9.0, apotema 1.5 e angolo_interno 90.
    """
    richiedi_intero(lati, "misure_poligono", "lati")
    if not 3 <= lati <= 1_000_000:
        raise ErroreValore(f"Un poligono ha almeno 3 lati (hai scritto {lati}).",
                           suggerimento="Triangolo 3, quadrato 4, pentagono 5, esagono 6...")
    l_ = _positivo(lato, "misure_poligono", "lato")
    apotema = l_ / (2 * math.tan(math.pi / lati))
    perimetro = lati * l_
    angolo = Fraction(180 * (lati - 2), lati)
    return {"perimetro": _bello(perimetro) if not e_intero(lato) else lati * lato,
            "area": _bello(perimetro * apotema / 2, "misure_poligono"),
            "apotema": _bello(apotema, "misure_poligono"),
            "angolo_interno": _da_razionale(angolo, "misure_poligono")}


_SOLIDI = {
    "cubo": (("lato",), lambda l: l ** 3),
    "parallelepipedo": (("lunghezza", "larghezza", "altezza"), lambda a, b, c: a * b * c),
    "sfera": (("raggio",), lambda r: 4 / 3 * math.pi * r ** 3),
    "cilindro": (("raggio", "altezza"), lambda r, h: math.pi * r * r * h),
    "cono": (("raggio", "altezza"), lambda r, h: math.pi * r * r * h / 3),
    "piramide": (("lato_base", "altezza"), lambda l, h: l * l * h / 3),
    "prisma": (("area_base", "altezza"), lambda a, h: a * h),
}


@funzione_libreria("volume_solido")
def volume_solido(forma, *misure):
    """volume_solido(forma, misure...): il volume di un solido.

    Forme: "cubo" (lato), "parallelepipedo" (lunghezza, larghezza, altezza), "sfera" (raggio),
    "cilindro" (raggio, altezza), "cono" (raggio, altezza), "piramide" (lato della base quadrata, altezza),
    "prisma" (area della base, altezza).
    Esempi: `volume_solido("cubo", 3)` è 27.0, `volume_solido("sfera", 1)` è 4.18879020479.
    """
    richiedi_testo(forma, "volume_solido", "forma")
    chiave = forma.strip().lower()
    if chiave not in _SOLIDI:
        simili = difflib.get_close_matches(chiave, list(_SOLIDI), n=1, cutoff=0.6)
        raise ErroreValore(f"Non conosco il solido {mostra(forma)}.",
                           suggerimento=(f"Forse intendevi \"{simili[0]}\"? " if simili else "")
                           + "Solidi: " + ", ".join(f'"{s}"' for s in _SOLIDI) + ".")
    nomi, formula = _SOLIDI[chiave]
    if len(misure) != len(nomi):
        raise ErroreValore(f"Per il volume di un {chiave} servono {len(nomi)} misure: {', '.join(nomi)} "
                           f"(ne hai date {len(misure)}).",
                           suggerimento=f"Esempio: `volume_solido(\"{chiave}\", {', '.join('2' for _ in nomi)})`.")
    valori = [_positivo(m, "volume_solido", n) for m, n in zip(misure, nomi)]
    try:
        return _bello(formula(*valori), "volume_solido")
    except OverflowError:
        raise _troppo_grande("volume_solido") from None


# ===========================================================================
# Geografia
# ===========================================================================

#: Raggio medio della Terra in chilometri.
RAGGIO_TERRA_KM = 6371.0088


def _coordinata(p: Any, nome: str, parametro: str) -> tuple[float, float]:
    if not (isinstance(p, list) and len(p) == 2):
        raise ErroreTipo(f"In `{nome}` il punto `{parametro}` deve essere una lista [latitudine, longitudine], "
                         f"non {articolo(p)}.",
                         suggerimento="Esempio: Roma è [41.9028, 12.4964].")
    lat = _reale(p[0], nome, "latitudine")
    lon = _reale(p[1], nome, "longitudine")
    if not -90 <= lat <= 90:
        raise ErroreValore(f"La latitudine va da -90 a 90 (hai scritto {rappresenta(p[0])}).",
                           suggerimento="Forse hai scambiato latitudine e longitudine: prima viene la latitudine.")
    if not -180 <= lon <= 180:
        raise ErroreValore(f"La longitudine va da -180 a 180 (hai scritto {rappresenta(p[1])}).")
    return lat, lon


@funzione_libreria("distanza_gps")
def distanza_gps(punto1, punto2, *altri):
    """distanza_gps(punto1, punto2): i chilometri in linea d'aria tra due posti sulla Terra.

    Ogni punto è [latitudine, longitudine] in gradi. Esempio:
    `distanza_gps([45.4642, 9.19], [41.9028, 12.4964])` è circa 477 (Milano–Roma).
    Si può anche scrivere con quattro numeri: `distanza_gps(45.4642, 9.19, 41.9028, 12.4964)`.
    """
    if altri:
        if len(altri) != 2:
            raise ErroreValore("`distanza_gps` vuole due punti [lat, lon] oppure quattro numeri.")
        punto1, punto2 = [punto1, punto2], list(altri)
    lat1, lon1 = map(math.radians, _coordinata(punto1, "distanza_gps", "punto1"))
    lat2, lon2 = map(math.radians, _coordinata(punto2, "distanza_gps", "punto2"))
    # formula dell'emisenoverso (haversine)
    h = math.sin((lat2 - lat1) / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2
    return _bello(2 * RAGGIO_TERRA_KM * math.asin(min(1.0, math.sqrt(h))), "distanza_gps")


# ===========================================================================
# Unità di misura
# ===========================================================================

def _F(testo: str) -> Fraction:
    return Fraction(testo)


# (grandezza, fattore verso l'unità base, nomi)
_UNITA_DATI: list[tuple[str, Any, tuple[str, ...]]] = [
    # lunghezze (base: metro)
    ("lunghezza", _F("0.001"), ("mm", "millimetro", "millimetri")),
    ("lunghezza", _F("0.01"), ("cm", "centimetro", "centimetri")),
    ("lunghezza", _F("0.1"), ("dm", "decimetro", "decimetri")),
    ("lunghezza", _F("1"), ("m", "metro", "metri")),
    ("lunghezza", _F("10"), ("dam", "decametro", "decametri")),
    ("lunghezza", _F("100"), ("hm", "ettometro", "ettometri")),
    ("lunghezza", _F("1000"), ("km", "chilometro", "chilometri")),
    ("lunghezza", _F("0.0254"), ("pollice", "pollici", "in")),
    ("lunghezza", _F("0.3048"), ("piede", "piedi", "ft")),
    ("lunghezza", _F("0.9144"), ("iarda", "iarde", "yd")),
    ("lunghezza", _F("1609.344"), ("miglio", "miglia", "mi")),
    ("lunghezza", _F("1852"), ("miglio_nautico", "miglia_nautiche", "nmi")),
    ("lunghezza", _F("9460730472580800"), ("anno_luce", "anni_luce")),
    # pesi (base: chilogrammo)
    ("peso", _F("0.000001"), ("mg", "milligrammo", "milligrammi")),
    ("peso", _F("0.001"), ("g", "grammo", "grammi")),
    ("peso", _F("0.1"), ("hg", "etto", "etti", "ettogrammo", "ettogrammi")),
    ("peso", _F("1"), ("kg", "chilo", "chili", "chilogrammo", "chilogrammi")),
    ("peso", _F("100"), ("q", "quintale", "quintali")),
    ("peso", _F("1000"), ("t", "tonnellata", "tonnellate")),
    ("peso", _F("0.028349523125"), ("oncia", "once", "oz")),
    ("peso", _F("0.45359237"), ("libbra", "libbre", "lb")),
    # volumi (base: litro)
    ("volume", _F("0.001"), ("ml", "millilitro", "millilitri", "cm3", "cc", "centimetro_cubo", "centimetri_cubi")),
    ("volume", _F("0.01"), ("cl", "centilitro", "centilitri")),
    ("volume", _F("0.1"), ("dl", "decilitro", "decilitri")),
    ("volume", _F("1"), ("l", "litro", "litri", "dm3", "decimetro_cubo", "decimetri_cubi")),
    ("volume", _F("100"), ("hl", "ettolitro", "ettolitri")),
    ("volume", _F("1000"), ("m3", "metro_cubo", "metri_cubi")),
    ("volume", _F("0.005"), ("cucchiaino", "cucchiaini")),
    ("volume", _F("0.015"), ("cucchiaio", "cucchiai")),
    ("volume", _F("0.25"), ("tazza", "tazze")),
    ("volume", _F("3.785411784"), ("gallone", "galloni", "gal")),
    # superfici (base: metro quadrato)
    ("superficie", _F("0.000001"), ("mm2", "millimetro_quadrato", "millimetri_quadrati")),
    ("superficie", _F("0.0001"), ("cm2", "centimetro_quadrato", "centimetri_quadrati")),
    ("superficie", _F("0.01"), ("dm2", "decimetro_quadrato", "decimetri_quadrati")),
    ("superficie", _F("1"), ("m2", "metro_quadrato", "metri_quadrati", "mq")),
    ("superficie", _F("100"), ("ara", "are")),
    ("superficie", _F("10000"), ("ettaro", "ettari", "ha")),
    ("superficie", _F("1000000"), ("km2", "chilometro_quadrato", "chilometri_quadrati")),
    ("superficie", _F("4046.8564224"), ("acro", "acri")),
    # velocità (base: metri al secondo)
    ("velocità", _F("1"), ("m/s", "metri_al_secondo")),
    ("velocità", Fraction(1000, 3600), ("km/h", "kmh", "chilometri_orari", "chilometri_all_ora")),
    ("velocità", Fraction(1609344, 3600000), ("mph", "miglia_orarie", "miglia_all_ora")),
    ("velocità", Fraction(1852, 3600), ("nodo", "nodi")),
    # tempo (base: secondo)
    ("tempo", _F("0.001"), ("ms", "millisecondo", "millisecondi")),
    ("tempo", _F("1"), ("s", "sec", "secondo", "secondi")),
    ("tempo", _F("60"), ("min", "minuto", "minuti")),
    ("tempo", _F("3600"), ("h", "ora", "ore")),
    ("tempo", _F("86400"), ("giorno", "giorni")),
    ("tempo", _F("604800"), ("settimana", "settimane")),
    ("tempo", _F("31536000"), ("anno", "anni")),
    # dati (base: byte; kb = 1000 byte, kib = 1024 byte)
    ("dati", _F("0.125"), ("bit",)),
    ("dati", _F("1"), ("byte", "b")),
    ("dati", _F("1000"), ("kb", "kilobyte")),
    ("dati", _F("1000000"), ("mb", "megabyte")),
    ("dati", _F("1000000000"), ("gb", "gigabyte")),
    ("dati", _F("1000000000000"), ("tb", "terabyte")),
    ("dati", Fraction(1024), ("kib", "kibibyte")),
    ("dati", Fraction(1024 ** 2), ("mib", "mebibyte")),
    ("dati", Fraction(1024 ** 3), ("gib", "gibibyte")),
    ("dati", Fraction(1024 ** 4), ("tib", "tebibyte")),
    # energia (base: joule)
    ("energia", _F("1"), ("j", "joule")),
    ("energia", _F("1000"), ("kj", "chilojoule")),
    ("energia", _F("4.184"), ("cal", "caloria", "calorie")),
    ("energia", _F("4184"), ("kcal", "chilocaloria", "chilocalorie")),
    ("energia", _F("3600"), ("wh", "wattora")),
    ("energia", _F("3600000"), ("kwh", "chilowattora")),
    # angoli (base: radiante; i gradi non sono una frazione esatta)
    ("angolo", 1.0, ("rad", "radiante", "radianti")),
    ("angolo", math.pi / 180, ("grado", "gradi", "°")),
    # temperature: trattate a parte
    ("temperatura", None, ("c", "celsius", "°c", "gradi_celsius")),
    ("temperatura", None, ("f", "fahrenheit", "°f", "gradi_fahrenheit")),
    ("temperatura", None, ("k", "kelvin")),
]

_UNITA: dict[str, tuple[str, Any, str]] = {}
for _grandezza, _fattore, _nomi in _UNITA_DATI:
    for _n in _nomi:
        _UNITA[_n] = (_grandezza, _fattore, _nomi[0])


def _nome_unita(testo: str) -> str:
    t = unicodedata.normalize("NFKD", testo.strip().lower())
    t = "".join(c for c in t if not unicodedata.combining(c) or c == "°")
    t = t.replace("²", "2").replace("³", "3").replace("'", "_").replace(" ", "_")
    return re.sub(r"_+", "_", t)


def _unita(testo: Any, parametro: str) -> tuple[str, Any, str]:
    richiedi_testo(testo, "converti", parametro)
    chiave = _nome_unita(testo)
    if chiave in _UNITA:
        return _UNITA[chiave]
    simili = difflib.get_close_matches(chiave, list(_UNITA), n=3, cutoff=0.6)
    raise ErroreValore(f"Non conosco l'unità di misura {mostra(testo)}.",
                       suggerimento=("Forse intendevi " + " o ".join(f'"{s}"' for s in simili) + "?"
                                     if simili else "Esempi: \"km\", \"miglia\", \"kg\", \"litri\", \"celsius\", \"gb\"."))


def _in_celsius(v: Fraction, unita: str) -> Fraction:
    if unita == "c":
        return v
    if unita == "f":
        return (v - 32) * Fraction(5, 9)
    return v - Fraction("273.15")


def _da_celsius(v: Fraction, unita: str) -> Fraction:
    if unita == "c":
        return v
    if unita == "f":
        return v * Fraction(9, 5) + 32
    return v + Fraction("273.15")


@funzione_libreria("converti")
def converti(valore, da, a):
    """converti(valore, da, a): trasforma una misura da un'unità a un'altra.

    Esempi: `converti(10, "km", "miglia")` è 6.21371192237, `converti(100, "celsius", "fahrenheit")` è 212,
    `converti(2, "ore", "minuti")` è 120, `converti(1, "gb", "mb")` è 1000.
    Grandezze: lunghezze (mm, cm, m, km, pollici, piedi, miglia...), pesi (g, etti, kg, quintali, libbre...),
    volumi (ml, litri, m3, cucchiai...), superfici (m2, ettari, km2...), velocità (km/h, m/s, nodi, mph),
    tempo (secondi, minuti, ore, giorni, settimane, anni di 365 giorni), dati (bit, byte, kb, mb, gb, tb e
    kib, mib, gib da 1024), energia (joule, calorie, kcal, kwh), angoli (gradi, radianti) e temperature
    (celsius, fahrenheit, kelvin).
    """
    v = _razionale(valore, "converti", "valore")
    g_da, f_da, n_da = _unita(da, "da")
    g_a, f_a, n_a = _unita(a, "a")
    if g_da != g_a:
        raise ErroreValore(f"Non posso convertire {mostra(da)} in {mostra(a)}: "
                           f"sono misure diverse ({g_da} e {g_a}).",
                           suggerimento=f"Converti una {g_da} in un'altra unità di {g_da}.")
    if g_da == "temperatura":
        celsius = _in_celsius(v, n_da)
        if celsius < Fraction("-273.15"):
            raise ErroreValore(f"{rappresenta(valore)} {da} è sotto lo zero assoluto: nessuna temperatura è così bassa.",
                               suggerimento="Il freddo più freddo possibile è -273,15 °C (0 kelvin).")
        return _da_razionale(_da_celsius(celsius, n_a), "converti")
    if isinstance(f_da, float) or isinstance(f_a, float):
        try:
            return _bello(float(v) * float(f_da) / float(f_a), "converti")
        except OverflowError:
            raise _troppo_grande("converti") from None
    if abs(v.numerator) > 10 ** 1000:
        raise _troppo_grande("converti")
    return _da_razionale(v * f_da / f_a, "converti")


# ===========================================================================
# Finanza (importi precisi con i `soldi`)
# ===========================================================================

def _tasso(x: Any, nome: str) -> Decimal:
    t = _reale(x, nome, "tasso")
    if not -100 < t <= 1000:
        raise ErroreValore(f"Il `tasso` di `{nome}` è una percentuale: scrivi per esempio 3 per il 3% "
                           f"(hai scritto {rappresenta(x)}).",
                           suggerimento="Deve essere tra -100 e 1000.")
    return Decimal(x) if e_intero(x) else Decimal(repr(float(x)))


def _capitale(x: Any, nome: str, parametro: str = "capitale") -> tuple[Decimal, str]:
    valuta = x.valuta if isinstance(x, SoldiDante) else "€"
    d = _importo(x, nome, parametro)
    if d <= 0:
        raise ErroreValore(f"Il valore `{parametro}` di `{nome}` deve essere maggiore di zero.")
    return d, valuta


@funzione_libreria("interesse_composto")
def interesse_composto(capitale, tasso, anni, volte_all_anno=1):
    """interesse_composto(capitale, tasso, anni, volte_all_anno = 1): quanto diventa un capitale
    se gli interessi si sommano al capitale e producono a loro volta interessi.

    Il `tasso` è la percentuale annua. Restituisce dei `soldi` precisi al centesimo.
    Esempio: `interesse_composto(1000, 5, 10)` è 1.628,89 €; con gli interessi ogni mese:
    `interesse_composto(1000, 5, 10, 12)` è 1.647,01 €.
    """
    c, valuta = _capitale(capitale, "interesse_composto")
    t = _tasso(tasso, "interesse_composto")
    richiedi_numero(anni, "interesse_composto", "anni")
    n_anni = _positivo(anni, "interesse_composto", "anni", zero=True)
    if n_anni > 1000:
        raise ErroreValore("Al massimo 1000 anni in `interesse_composto`.")
    richiedi_intero(volte_all_anno, "interesse_composto", "volte_all_anno")
    if not 1 <= volte_all_anno <= 366:
        raise ErroreValore("`volte_all_anno` va da 1 (una volta l'anno) a 365 (ogni giorno).",
                           suggerimento="Ogni mese: 12; ogni trimestre: 4.")
    periodi = Decimal(anni) if e_intero(anni) else Decimal(repr(float(anni)))
    periodi *= volte_all_anno
    with localcontext() as ctx:
        ctx.prec = 50
        fattore = (1 + t / 100 / volte_all_anno) ** periodi
        montante = c * fattore
    if montante.adjusted() >= 15:
        raise ErroreValore("L'importo è troppo grande (al massimo un milione di miliardi).")
    return SoldiDante(montante, valuta)


def _mutuo(importo: Any, tasso: Any, anni: Any, nome: str) -> tuple[Decimal, Decimal, int, str]:
    c, valuta = _capitale(importo, nome, "importo")
    t = _tasso(tasso, nome)
    if t < 0:
        raise ErroreValore(f"Il tasso di `{nome}` non può essere negativo.")
    richiedi_intero(anni, nome, "anni")
    if not 1 <= anni <= 50:
        raise ErroreValore(f"Gli `anni` di `{nome}` vanno da 1 a 50 (hai scritto {anni}).")
    return c, t / 1200, anni * 12, valuta


def _rata(c: Decimal, i: Decimal, n: int) -> Decimal:
    with localcontext() as ctx:
        ctx.prec = 50
        if i == 0:
            rata = c / n
        else:
            rata = c * i / (1 - (1 + i) ** -n)
        return rata.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


@funzione_libreria("rata_mutuo")
def rata_mutuo(importo, tasso, anni):
    """rata_mutuo(importo, tasso, anni): la rata mensile di un mutuo o prestito (ammortamento alla francese,
    rate tutte uguali). Il `tasso` è la percentuale annua (TAN).

    Esempio: `rata_mutuo(100000, 3, 20)` è 554,60 € al mese. Il piano mese per mese: `piano_ammortamento`.
    """
    c, i, n, valuta = _mutuo(importo, tasso, anni, "rata_mutuo")
    return SoldiDante(_rata(c, i, n), valuta)


@funzione_libreria("piano_ammortamento")
def piano_ammortamento(importo, tasso, anni):
    """piano_ammortamento(importo, tasso, anni): la tabella del mutuo mese per mese.

    Ogni riga è un dizionario con "mese", "rata", "interessi", "capitale" (la quota che riduce il debito)
    e "debito" (quanto resta da pagare); gli importi sono `soldi` precisi e l'ultima rata chiude
    il debito esattamente a zero.
    Esempio: `piano_ammortamento(1200, 0, 1)[0]["rata"]` è 100,00 €.
    """
    c, i, n, valuta = _mutuo(importo, tasso, anni, "piano_ammortamento")
    rata = _rata(c, i, n)
    debito = c
    righe = []
    centesimo = Decimal("0.01")
    for mese in range(1, n + 1):
        interessi = (debito * i).quantize(centesimo, rounding=ROUND_HALF_UP)
        quota = rata - interessi
        if mese == n or quota > debito:
            quota = debito
        debito -= quota
        righe.append({"mese": mese, "rata": SoldiDante(quota + interessi, valuta),
                      "interessi": SoldiDante(interessi, valuta), "capitale": SoldiDante(quota, valuta),
                      "debito": SoldiDante(debito, valuta)})
        if debito == 0:
            break
    return righe


# ===========================================================================
# Chimica
# ===========================================================================

_MASSE_ATOMICHE = dict(zip(
    ("H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr "
     "Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb "
     "Lu Hf Ta W Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr "
     "Rf Db Sg Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og").split(),
    map(Decimal, (
        "1.008 4.0026 6.94 9.0122 10.81 12.011 14.007 15.999 18.998 20.180 22.990 24.305 26.982 28.085 "
        "30.974 32.06 35.45 39.948 39.098 40.078 44.956 47.867 50.942 51.996 54.938 55.845 58.933 58.693 "
        "63.546 65.38 69.723 72.630 74.922 78.971 79.904 83.798 85.468 87.62 88.906 91.224 92.906 95.95 "
        "98 101.07 102.91 106.42 107.87 112.41 114.82 118.71 121.76 127.60 126.90 131.29 132.91 137.33 "
        "138.91 140.12 140.91 144.24 145 150.36 151.96 157.25 158.93 162.50 164.93 167.26 168.93 173.05 "
        "174.97 178.49 180.95 183.84 186.21 190.23 192.22 195.08 196.97 200.59 204.38 207.2 208.98 209 "
        "210 222 223 226 227 232.04 231.04 238.03 237 244 243 247 247 251 252 257 258 259 262 "
        "267 268 269 270 277 278 281 282 285 286 289 290 293 294 294").split())))


class _Formula:
    """Legge una formula chimica: H2O, Ca(OH)2, CuSO4·5H2O."""

    def __init__(self, testo: str) -> None:
        self.testo = testo
        self.pos = 0

    def errore(self, messaggio: str, suggerimento: str | None = None) -> ErroreValore:
        return ErroreValore(f"Non capisco la formula {mostra(self.testo)}: {messaggio}",
                            suggerimento=suggerimento or "Esempi: \"H2O\", \"NaCl\", \"C6H12O6\", \"Ca(OH)2\".")

    def numero(self) -> int:
        inizio = self.pos
        while self.pos < len(self.testo) and self.testo[self.pos].isdigit():
            self.pos += 1
        if inizio == self.pos:
            return 1
        cifre = self.testo[inizio:self.pos]
        if len(cifre) > 6:
            raise self.errore("un numero è troppo grande.")
        return int(cifre)

    def gruppo(self, chiusura: str | None) -> Counter:
        atomi: Counter = Counter()
        while self.pos < len(self.testo):
            c = self.testo[self.pos]
            if c in "([":
                self.pos += 1
                dentro = self.gruppo(")" if c == "(" else "]")
                volte = self.numero()
                for k, v in dentro.items():
                    atomi[k] += v * volte
            elif c in ")]":
                if c != chiusura:
                    raise self.errore(f"la parentesi `{c}` non è stata aperta.")
                self.pos += 1
                return atomi
            elif c.isupper():
                simbolo = c
                self.pos += 1
                if self.pos < len(self.testo) and self.testo[self.pos].islower():
                    simbolo += self.testo[self.pos]
                    self.pos += 1
                if simbolo not in _MASSE_ATOMICHE:
                    if simbolo[0] in _MASSE_ATOMICHE and len(simbolo) == 2:
                        sugg = f"Gli elementi si scrivono con la maiuscola: forse \"{simbolo[0]}{simbolo[1].upper()}\"?"
                    else:
                        sugg = None
                    raise self.errore(f"l'elemento `{simbolo}` non esiste.", sugg)
                atomi[simbolo] += self.numero()
            elif c.islower():
                raise self.errore(f"`{c}` dovrebbe essere maiuscola.",
                                  f"I simboli degli elementi iniziano con la maiuscola: prova {mostra(self.testo.capitalize())}.")
            else:
                raise self.errore(f"non capisco il carattere `{c}`.")
        if chiusura is not None:
            raise self.errore("manca una parentesi chiusa.")
        return atomi


@funzione_libreria("massa_molare")
def massa_molare(formula):
    """massa_molare(formula): quanti grammi pesa una mole della sostanza (g/mol).

    Esempi: `massa_molare("H2O")` è 18.015 (acqua), `massa_molare("NaCl")` è 58.44 (sale da cucina),
    `massa_molare("Ca(OH)2")` è 74.092. Gli idrati si scrivono col punto: "CuSO4·5H2O".
    """
    richiedi_testo(formula, "massa_molare", "formula")
    testo = formula.strip().replace(" ", "")
    if not testo:
        raise ErroreValore("La formula di `massa_molare` è vuota.", suggerimento="Esempio: `massa_molare(\"H2O\")`.")
    if len(testo) > 500:
        raise ErroreValore("La formula è troppo lunga.")
    totale: Counter = Counter()
    for parte in re.split(r"[·*•]", testo):
        lettore = _Formula(formula)
        m = re.match(r"\d+", parte)
        volte = int(m.group()) if m and len(m.group()) <= 6 else 1
        lettore.testo = parte[m.end():] if m else parte
        if not lettore.testo:
            raise lettore.errore("manca una parte dopo il punto.")
        for k, v in lettore.gruppo(None).items():
            totale[k] += v * volte
    massa = sum((_MASSE_ATOMICHE[k] * v for k, v in totale.items()), Decimal(0))
    return float(massa.quantize(Decimal("0.001"), rounding=ROUND_HALF_UP))


# ===========================================================================
# Equazioni
# ===========================================================================

def _uscita_esatta(q: Fraction, nome: str) -> int | float:
    return _da_razionale(q, nome)


def _radice_razionale(q: Fraction) -> Fraction | None:
    """La radice quadrata esatta di un razionale, se esiste."""
    if q < 0:
        return None
    n, d = math.isqrt(q.numerator), math.isqrt(q.denominator)
    if n * n == q.numerator and d * d == q.denominator:
        return Fraction(n, d)
    return None


@funzione_libreria("risolvi_equazione")
def risolvi_equazione(a, b, c=None):
    """risolvi_equazione(a, b, c): le soluzioni di un'equazione di primo o secondo grado.

    Esempi: con due numeri risolve a·x + b = 0, `risolvi_equazione(2, -6)` è [3].
    Con tre risolve a·x² + b·x + c = 0: `risolvi_equazione(1, -5, 6)` è [2, 3].
    Restituisce la lista delle soluzioni reali in ordine (vuota se non ce ne sono).
    """
    qa = _razionale(a, "risolvi_equazione", "a")
    qb = _razionale(b, "risolvi_equazione", "b")
    if c is None or qa == 0:
        if c is not None:  # a = 0: diventa di primo grado b·x + c = 0
            qa, qb = qb, _razionale(c, "risolvi_equazione", "c")
        if qa == 0:
            if qb == 0:
                raise ErroreValore("L'equazione è sempre vera: ogni numero è una soluzione.",
                                   suggerimento="Controlla i coefficienti: sono tutti zero.")
            return []
        return [_uscita_esatta(-qb / qa, "risolvi_equazione")]
    qc = _razionale(c, "risolvi_equazione", "c")
    if max(abs(q.numerator).bit_length() + q.denominator.bit_length() for q in (qa, qb, qc)) > 20_000:
        raise _troppo_grande("risolvi_equazione")
    delta = qb * qb - 4 * qa * qc
    if delta < 0:
        return []
    if delta == 0:
        return [_uscita_esatta(-qb / (2 * qa), "risolvi_equazione")]
    esatta = _radice_razionale(delta)
    if esatta is not None:
        soluzioni = [(-qb - esatta) / (2 * qa), (-qb + esatta) / (2 * qa)]
        return [_uscita_esatta(s, "risolvi_equazione") for s in sorted(soluzioni)]
    try:
        fa, fb, fd = float(qa), float(qb), math.sqrt(float(delta))
    except OverflowError:
        raise _troppo_grande("risolvi_equazione") from None
    # formula stabile: niente cancellazioni quando b è grande
    q = -0.5 * (fb + math.copysign(fd, fb))
    try:
        x1, x2 = q / fa, float(qc) / q
    except (ZeroDivisionError, OverflowError):
        raise ErroreValore("I coefficienti sono troppo diversi tra loro per calcolare le soluzioni.",
                           suggerimento="Prova a dividere tutti i coefficienti per lo stesso numero.") from None
    return sorted(_bello(x, "risolvi_equazione") for x in (x1, x2))


@funzione_libreria("risolvi_sistema")
def risolvi_sistema(coefficienti, termini):
    """risolvi_sistema(coefficienti, termini): risolve un sistema di equazioni lineari (2x2, 3x3...).

    Esempio: per  2x + y = 5  e  x - y = 1  scrivi `risolvi_sistema([[2, 1], [1, -1]], [5, 1])`: il risultato è
    [2, 1], cioè x = 2 e y = 1. I conti sono esatti (con le frazioni).
    """
    if not (isinstance(coefficienti, list) and coefficienti and all(isinstance(r, list) for r in coefficienti)):
        raise ErroreTipo(f"I `coefficienti` di `risolvi_sistema` sono una lista di righe, non {articolo(coefficienti)}.",
                         suggerimento="Esempio: [[2, 1], [1, -1]] per 2x + y e x - y.")
    n = len(coefficienti)
    if n > 30:
        raise ErroreValore("`risolvi_sistema` risolve al massimo 30 equazioni.")
    if any(len(r) != n for r in coefficienti):
        raise ErroreValore(f"Servono tante incognite quante equazioni: {n} righe di {n} numeri ciascuna.",
                           suggerimento="Se un'incognita manca in un'equazione, scrivi 0 al suo posto.")
    if not isinstance(termini, list):
        raise ErroreTipo(f"I `termini` di `risolvi_sistema` sono una lista di numeri, non {articolo(termini)}.")
    if len(termini) != n:
        raise ErroreValore(f"Servono {n} termini noti (uno per equazione), ne hai dati {len(termini)}.")
    m = [[_razionale(v, "risolvi_sistema", "coefficienti") for v in riga]
         + [_razionale(t, "risolvi_sistema", "termini")] for riga, t in zip(coefficienti, termini)]
    if any(abs(q.numerator).bit_length() > 5000 or q.denominator.bit_length() > 5000 for r in m for q in r):
        raise _troppo_grande("risolvi_sistema")
    for col in range(n):
        perno = next((r for r in range(col, n) if m[r][col] != 0), None)
        if perno is None:
            raise ErroreValore("Il sistema non ha una soluzione unica (nessuna oppure infinite).",
                               suggerimento="Controlla che le equazioni non siano una il multiplo dell'altra.")
        m[col], m[perno] = m[perno], m[col]
        p = m[col][col]
        m[col] = [v / p for v in m[col]]
        for r in range(n):
            if r != col and m[r][col] != 0:
                f = m[r][col]
                m[r] = [x - f * y for x, y in zip(m[r], m[col])]
    return [_uscita_esatta(r[n], "risolvi_sistema") for r in m]


# ===========================================================================
# Analisi: derivata e integrale di una funzione Leo
# ===========================================================================

def _valuta(interprete: Any, f: Richiamabile, x: float, nome: str) -> float:
    y = chiama_funzione(interprete, f, [x])
    if not e_numero(y):
        raise ErroreTipo(f"La funzione data a `{nome}` deve restituire un numero, ma per x = {rappresenta(x)} "
                         f"ha restituito {articolo(y)}.",
                         suggerimento="Per esempio: `funzione (x) restituisci x * x fine`.")
    try:
        v = float(y)
    except OverflowError:
        raise _troppo_grande(nome) from None
    if math.isnan(v) or math.isinf(v):
        raise ErroreValore(f"La funzione data a `{nome}` non ha un valore finito per x = {rappresenta(x)}.")
    return v


@funzione_libreria("derivata", interprete=True)
def derivata(interprete, funzione, x):
    """derivata(funzione, x): la pendenza della funzione nel punto x (calcolo numerico).

    Esempio: `derivata(funzione (x) restituisci x * x fine, 3)` è 6.0 (la derivata di x² è 2x).
    """
    f = richiedi_funzione(funzione, "derivata")
    x0 = _reale(x, "derivata", "x")
    h = 1e-2 * max(1.0, abs(x0))

    def centrale(passo: float) -> float:
        return (_valuta(interprete, f, x0 + passo, "derivata") - _valuta(interprete, f, x0 - passo, "derivata")) / (2 * passo)

    # estrapolazione di Richardson: toglie quasi tutto l'errore del passo
    d1, d2 = centrale(h), centrale(h / 2)
    risultato = (4 * d2 - d1) / 3
    if math.isnan(risultato) or math.isinf(risultato):
        raise _troppo_grande("derivata")
    return 0.0 if abs(risultato) < 1e-9 else float(f"{risultato:.9g}")


@funzione_libreria("integrale", interprete=True)
def integrale(interprete, funzione, da, a):
    """integrale(funzione, da, a): l'area sotto la funzione tra `da` e `a` (metodo di Simpson).

    Esempio: `integrale(funzione (x) restituisci x * x fine, 0, 3)` è 9.0.
    Se `da` è più grande di `a` il risultato cambia segno.
    """
    f = richiedi_funzione(funzione, "integrale")
    x0 = _reale(da, "integrale", "da")
    x1 = _reale(a, "integrale", "a")
    if x0 == x1:
        return 0.0
    if math.isinf(x1 - x0):
        raise _troppo_grande("integrale")
    cache: dict[float, float] = {}

    def valore(x: float) -> float:
        if x not in cache:
            cache[x] = _valuta(interprete, f, x, "integrale")
        return cache[x]

    def simpson(n: int) -> float:
        passo = (x1 - x0) / n
        somma = [valore(x0), valore(x1)]
        somma += [(4 if k % 2 else 2) * valore(x0 + k * passo) for k in range(1, n)]
        return math.fsum(somma) * passo / 3

    precedente = simpson(16)
    n = 32
    while True:
        attuale = simpson(n)
        if abs(attuale - precedente) <= 1e-10 * max(1.0, abs(attuale)) or n >= 4096:
            break
        precedente, n = attuale, n * 2
    risultato = attuale + (attuale - precedente) / 15   # Richardson sul metodo di Simpson
    if math.isnan(risultato) or math.isinf(risultato):
        raise _troppo_grande("integrale")
    return 0.0 if abs(risultato) < 1e-10 else float(f"{risultato:.9g}")


# ===========================================================================
# Intelligenza artificiale semplice e spiegabile
# ===========================================================================

def _numero_leo(v: float) -> int | float:
    return _bello(v)


@funzione_libreria("raggruppa_punti")
def raggruppa_punti(punti, k):
    """raggruppa_punti(punti, k): divide i punti in k gruppi di punti vicini (algoritmo k-medie).

    Ogni gruppo ha un "centro"; a ogni giro ogni punto va col centro più vicino e i centri si spostano
    nella media del loro gruppo, finché non cambia più niente. Restituisce un dizionario con "gruppi"
    (le liste di punti), "centri" ed "etichette" (il numero del gruppo di ogni punto, da 0).
    Esempio: `raggruppa_punti([1, 2, 3, 20, 21, 22], 2)["gruppi"]` è [[1, 2, 3], [20, 21, 22]].
    """
    originali = punti if isinstance(punti, list) else None
    dati = _punti(punti, "raggruppa_punti")
    if originali is None:
        originali = [p[0] for p in dati]
    richiedi_intero(k, "raggruppa_punti", "k")
    if not 1 <= k <= len(dati):
        raise ErroreValore(f"`k` (quanti gruppi) va da 1 a {len(dati)} (quanti sono i punti); hai scritto {k}.",
                           suggerimento="Prova con 2 o 3 gruppi.")
    if len(dati) * k > 2_000_000:
        raise ErroreValore("Troppi punti o troppi gruppi per `raggruppa_punti`.")
    # centri iniziali sempre uguali (niente caso): il primo punto, poi ogni volta il più lontano dai centri scelti
    centri = [list(dati[0])]
    while len(centri) < k:
        lontano = max(range(len(dati)), key=lambda i: min(_distanza2(dati[i], c) for c in centri))
        centri.append(list(dati[lontano]))
    etichette = [-1] * len(dati)
    for _giro in range(300):
        nuove = [min(range(k), key=lambda j: _distanza2(p, centri[j])) for p in dati]
        if nuove == etichette:
            break
        etichette = nuove
        for j in range(k):
            membri = [p for p, e in zip(dati, etichette) if e == j]
            if membri:
                centri[j] = [math.fsum(col) / len(membri) for col in zip(*membri)]
    # gruppi numerati da sinistra a destra (per il primo numero del centro): più facili da leggere
    ordine = sorted(range(k), key=lambda j: centri[j])
    nuovo_numero = {vecchio: nuovo for nuovo, vecchio in enumerate(ordine)}
    etichette = [nuovo_numero[e] for e in etichette]
    centri = [centri[j] for j in ordine]
    gruppi: list[list] = [[] for _ in range(k)]
    for orig, e in zip(originali, etichette):
        gruppi[e].append(orig)
    una_dimensione = all(e_numero(o) for o in originali)
    return {"gruppi": gruppi,
            "centri": [_numero_leo(c[0]) if una_dimensione else [_numero_leo(v) for v in c] for c in centri],
            "etichette": etichette}


@funzione_libreria("classifica_vicini")
def classifica_vicini(esempi, etichette, punto, k=3):
    """classifica_vicini(esempi, etichette, punto, k = 3): indovina l'etichetta di un punto nuovo guardando
    i k esempi più vicini (algoritmo dei k vicini): vince l'etichetta più frequente tra loro.

    Esempio: con `esempi = [[1, 1], [1, 2], [8, 9], [9, 8]]` ed `etichette = ["gatto", "gatto", "cane", "cane"]`,
    `classifica_vicini(esempi, etichette, [2, 1])` è "gatto". A parità vince l'esempio più vicino.
    """
    dati = _punti(esempi, "classifica_vicini", "esempi")
    if not isinstance(etichette, list):
        raise ErroreTipo(f"Le `etichette` di `classifica_vicini` sono una lista, non {articolo(etichette)}.",
                         suggerimento="Una etichetta per ogni esempio, per esempio [\"gatto\", \"cane\"].")
    if len(etichette) != len(dati):
        raise ErroreValore(f"Serve un'etichetta per ogni esempio: {len(dati)} esempi e {len(etichette)} etichette.")
    p = _punto(punto, "classifica_vicini", "punto")
    if len(p) != len(dati[0]):
        raise ErroreValore(f"Il punto ha {len(p)} coordinate, gli esempi {len(dati[0])}.")
    richiedi_intero(k, "classifica_vicini", "k")
    if not 1 <= k <= len(dati):
        raise ErroreValore(f"`k` (quanti vicini guardare) va da 1 a {len(dati)}; hai scritto {k}.",
                           suggerimento="Di solito si usa un numero dispari piccolo: 3 o 5.")
    vicini = sorted(range(len(dati)), key=lambda i: _distanza2(dati[i], p))[:k]
    voti: dict[int, int] = {}
    rappresentanti: dict[int, Any] = {}
    for i in vicini:  # dal più vicino: a parità di voti vince chi è apparso per primo
        chiave = next((j for j, e in rappresentanti.items() if _uguali(e, etichette[i])), None)
        if chiave is None:
            chiave = len(rappresentanti)
            rappresentanti[chiave] = etichette[i]
        voti[chiave] = voti.get(chiave, 0) + 1
    migliore = max(voti, key=lambda j: (voti[j], -j))
    return rappresentanti[migliore]


def _uguali(a: Any, b: Any) -> bool:
    from ..valori import uguali
    return uguali(a, b)


class PercettroneDante(OggettoLibreria):
    """Valore Leo di tipo ``percettrone``: un neurone artificiale addestrato."""

    NOME_TIPO_DANTE = "percettrone"
    SUGGERIMENTO_MODIFICA = "Addestra un percettrone nuovo con `addestra_percettrone(esempi, etichette)`."

    def __init__(self, pesi: list[float], soglia: float, classi: tuple, giri: int, errori: int,
                 totale: int, minimi: list[float], ampiezze: list[float]) -> None:
        self.pesi, self.soglia, self.classi = pesi, soglia, classi
        self.giri, self.errori, self.totale = giri, errori, totale
        self.minimi, self.ampiezze = minimi, ampiezze

    def punteggio(self, p: list[float]) -> float:
        normali = [(v - m) / a for v, m, a in zip(p, self.minimi, self.ampiezze)]
        return math.fsum(w * v for w, v in zip(self.pesi, normali)) - self.soglia

    def testo_dante(self) -> str:
        return f"percettrone({rappresenta(self.classi[1])} / {rappresenta(self.classi[0])}, " \
               f"{self.totale - self.errori} esempi giusti su {self.totale})"

    def __repr__(self) -> str:
        return f"PercettroneDante({self.testo_dante()!r})"


proprieta(PercettroneDante, "pesi")(lambda p: [_bello(w) for w in p.pesi])
proprieta(PercettroneDante, "soglia")(lambda p: _bello(p.soglia))
proprieta(PercettroneDante, "giri")(lambda p: p.giri)
proprieta(PercettroneDante, "errori")(lambda p: p.errori)
proprieta(PercettroneDante, "precisione")(lambda p: _bello((p.totale - p.errori) / p.totale))


@metodo_oggetto(PercettroneDante, "prevedi")
def percettrone_prevedi(p, punto):
    """percettrone.prevedi(punto): l'etichetta che il neurone sceglie per il punto."""
    x = _punto(punto, "prevedi", "punto")
    if len(x) != len(p.pesi):
        raise ErroreValore(f"Il punto deve avere {len(p.pesi)} numeri, come gli esempi dell'addestramento.")
    return p.classi[1] if p.punteggio(x) > 0 else p.classi[0]


@metodo_oggetto(PercettroneDante, "spiega")
def percettrone_spiega(p):
    """percettrone.spiega(): racconta in italiano la regola che il neurone ha imparato."""
    parti = []
    piu_forte = max(abs(v) for v in p.pesi)
    for i, w in enumerate(p.pesi):
        if abs(w) < 1e-12:
            parti.append(f"- la misura {i + 1} (peso 0) non conta: non aiuta a decidere")
            continue
        importanza = "molto" if abs(w) >= piu_forte * 0.66 else "poco"
        verso = "fa pensare a" if w > 0 else "allontana da"
        parti.append(f"- la misura {i + 1} (peso {_bello(w):.3g}) conta {importanza}: "
                     f"più è grande, più {verso} {rappresenta(p.classi[1])}")
    esito = ("Ho imparato a separare tutti gli esempi." if p.errori == 0 else
             f"Sbaglio ancora {p.errori} esempi su {p.totale}: forse non si separano con una linea dritta.")
    return (f"Sono un neurone. Moltiplico ogni misura (portata tra 0 e 1) per il suo peso e sommo: "
            f"se il totale supera {_bello(p.soglia):.3g} rispondo {rappresenta(p.classi[1])}, "
            f"altrimenti {rappresenta(p.classi[0])}.\n" + "\n".join(parti) +
            f"\nMi sono allenato per {p.giri} giri sugli esempi. {esito}")


@funzione_libreria("addestra_percettrone")
def addestra_percettrone(esempi, etichette, giri=100):
    """addestra_percettrone(esempi, etichette, giri = 100): allena un neurone artificiale (percettrone)
    a distinguere due tipi di cose.

    Ogni esempio è una lista di misure, ogni etichetta uno dei due tipi. Il neurone dà un "peso" a ogni
    misura; quando sbaglia un esempio corregge i pesi un pochino, e ripete. Restituisce un `percettrone`
    con i metodi `prevedi(punto)` e `spiega()` e le proprietà `pesi`, `soglia`, `giri`, `errori`, `precisione`.
    Esempio: `p = addestra_percettrone([[1, 1], [2, 1], [8, 9], [9, 8]], ["piccolo", "piccolo", "grande", "grande"])`
    e poi `p.prevedi([7, 7])` è "grande".
    """
    dati = _punti(esempi, "addestra_percettrone", "esempi", minimo=2)
    if not isinstance(etichette, list):
        raise ErroreTipo(f"Le `etichette` di `addestra_percettrone` sono una lista, non {articolo(etichette)}.")
    if len(etichette) != len(dati):
        raise ErroreValore(f"Serve un'etichetta per ogni esempio: {len(dati)} esempi e {len(etichette)} etichette.")
    richiedi_intero(giri, "addestra_percettrone", "giri")
    if not 1 <= giri <= 10_000:
        raise ErroreValore("I `giri` di addestramento vanno da 1 a 10000.")
    if len(dati) * giri > 5_000_000:
        raise ErroreValore("Troppi esempi o troppi giri per `addestra_percettrone`.")
    classi: list = []
    for e in etichette:
        if not any(_uguali(e, c) for c in classi):
            classi.append(e)
    if len(classi) != 2:
        raise ErroreValore(f"Il percettrone distingue esattamente due tipi di cose, ma le etichette sono "
                           f"{len(classi)} diverse.",
                           suggerimento="Per più di due tipi usa `classifica_vicini`.")
    bersagli = [1 if _uguali(e, classi[1]) else -1 for e in etichette]
    dimensioni = len(dati[0])
    minimi = [min(p[i] for p in dati) for i in range(dimensioni)]
    ampiezze = [(max(p[i] for p in dati) - minimi[i]) or 1.0 for i in range(dimensioni)]
    if any(math.isinf(a) for a in ampiezze):
        raise _troppo_grande("addestra_percettrone")
    normali = [[(v - m) / a for v, m, a in zip(p, minimi, ampiezze)] for p in dati]
    pesi, soglia, passo = [0.0] * dimensioni, 0.0, 0.1
    migliori = (len(dati) + 1, pesi[:], soglia)
    fatti = 0
    for fatti in range(1, giri + 1):
        sbagli = 0
        for x, t in zip(normali, bersagli):
            uscita = 1 if math.fsum(w * v for w, v in zip(pesi, x)) - soglia > 0 else -1
            if uscita != t:
                sbagli += 1
                pesi = [w + passo * t * v for w, v in zip(pesi, x)]
                soglia -= passo * t
        errori = sum(1 for x, t in zip(normali, bersagli)
                     if (1 if math.fsum(w * v for w, v in zip(pesi, x)) - soglia > 0 else -1) != t)
        if errori < migliori[0]:
            migliori = (errori, pesi[:], soglia)   # tiene i pesi migliori visti (percettrone "tascabile")
        if sbagli == 0:
            break
    errori, pesi, soglia = migliori
    return PercettroneDante(pesi, soglia, (classi[0], classi[1]), fatti, errori, len(dati), minimi, ampiezze)
