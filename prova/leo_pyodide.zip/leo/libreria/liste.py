"""Libreria: metodi delle liste.

``aggiungi``, ``inserisci``, ``rimuovi``, ``estrai``, ``ordina``, ``inverti``,
``trova``, ``conta``. I metodi che modificano la lista restituiscono ``nulla``.
Le uguaglianze usano la regola di Leo (``valori.uguali``): ``vero`` non è ``1``.
"""

from __future__ import annotations

from ..errori import ErroreIndice, ErroreTipo, ErroreValore
from ..valori import e_numero, uguali
from .generali import articolo, metodo_libreria, mostra, richiedi_intero, richiedi_logico, tipi


def _posizione(lista: list, x, inizio: int = 0) -> int | None:
    """Posizione del primo elemento uguale a ``x`` (regola di Leo) da ``inizio``, o ``None``.

    Dove si può usa ``list.index`` (in C, molto più veloce di un ciclo Python) e poi
    scarta i falsi positivi di Python: ``1 == vero`` e ``0 == falso``.
    """
    tx = type(x)
    if tx is str or x is None:
        try:
            return lista.index(x, inizio)
        except ValueError:
            return None
    if tx is bool or ((tx is int or tx is float) and x == x):
        cerco_logico = tx is bool
        while True:
            try:
                i = lista.index(x, inizio)
            except ValueError:
                return None
            if (type(lista[i]) is bool) is cerco_logico:
                return i
            inizio = i + 1
    # non_numero, liste, dizionari, date...: confronto elemento per elemento
    for i in range(inizio, len(lista)):
        if uguali(lista[i], x):
            return i
    return None


def _conta(lista: list, x) -> int:
    tx = type(x)
    if tx is str or x is None:
        return lista.count(x)
    if (tx is int or tx is float) and x == x:
        if (x != 0 and x != 1) or bool not in tipi(lista):
            return lista.count(x)
    elif tx is bool:
        if not tipi(lista) & {int, float}:
            return lista.count(x)
    return sum(1 for elemento in lista if uguali(elemento, x))


def _fuori(indice: int, n: int) -> ErroreIndice:
    if n == 0:
        return ErroreIndice(f"L'indice {indice} è fuori dalla lista: la lista è vuota.")
    return ErroreIndice(f"L'indice {indice} è fuori dalla lista: gli indici vanno da 0 a {n - 1}.",
                        suggerimento="Con gli indici negativi si conta dal fondo: `-1` è l'ultimo elemento."
                        if indice < 0 else None)


@metodo_libreria("lista", "aggiungi")
def lista_aggiungi(lista, x):
    """lista.aggiungi(x): mette `x` in fondo alla lista.

    Esempio: `voti.aggiungi(28)`.
    """
    lista.append(x)
    return None


# stesso risultato, senza passare da Python: il compilatore la usa quando l'oggetto e' una lista
lista_aggiungi.equivalente_veloce = list.append


@metodo_libreria("lista", "inserisci")
def lista_inserisci(lista, indice, x):
    """lista.inserisci(indice, x): mette `x` nella posizione `indice`, spostando in avanti gli altri.

    Esempio: `nomi.inserisci(0, "Ada")` mette "Ada" all'inizio. `indice` può valere
    anche `lunghezza(lista)` (in fondo) o essere negativo (conta dal fondo).
    """
    richiedi_intero(indice, "inserisci", "indice")
    n = len(lista)
    if not -n <= indice <= n:
        raise ErroreIndice(f"Non posso inserire alla posizione {indice}: le posizioni vanno da 0 a {n}.",
                           suggerimento="Per mettere un elemento in fondo usa `.aggiungi(x)`.")
    lista.insert(indice, x)
    return None


@metodo_libreria("lista", "rimuovi")
def lista_rimuovi(lista, x):
    """lista.rimuovi(x): toglie dalla lista il primo elemento uguale a `x`.

    Esempio: `frutti.rimuovi("pera")`. Se `x` non c'è ricevi un `ErroreValore`
    (controlla prima con `x in lista`). Per togliere per posizione usa `lista.estrai(0)`.
    """
    i = _posizione(lista, x)
    if i is not None:
        del lista[i]
        return None
    raise ErroreValore(f"{mostra(x)} non è nella lista, quindi non posso rimuoverlo.",
                       suggerimento="Controlla prima con `se x in lista allora`.")


@metodo_libreria("lista", "estrai")
def lista_estrai(lista, indice=-1):
    """lista.estrai(indice = -1): toglie dalla lista l'elemento in posizione `indice` e lo restituisce.

    Senza indice estrae l'ultimo. Esempio: `variabile ultimo = pila.estrai()`.
    """
    richiedi_intero(indice, "estrai", "indice")
    n = len(lista)
    if n == 0:
        raise ErroreIndice("Non posso estrarre niente: la lista è vuota.",
                           suggerimento="Controlla prima con `se non vuota(lista) allora`.")
    if not -n <= indice < n:
        raise _fuori(indice, n)
    return lista.pop(indice)


@metodo_libreria("lista", "ordina")
def lista_ordina(lista, decrescente=False):
    """lista.ordina(decrescente = falso): mette in ordine la lista (dal più piccolo al più grande).

    Gli elementi devono essere tutti numeri o tutti testi (i testi in ordine alfabetico).
    Esempi: `voti.ordina()`, `voti.ordina(decrescente = vero)`.
    """
    richiedi_logico(decrescente, "ordina", "decrescente")
    presenti = tipi(lista)
    if presenti == {str} or not lista:
        pass
    elif presenti <= {int, float} or all(e_numero(v) for v in lista):
        if float in presenti and any(v != v for v in lista):
            raise ErroreValore("Non posso ordinare una lista che contiene `non_numero`.")
    elif not all(isinstance(v, str) for v in lista):
        for v in lista:
            if not e_numero(v) and not isinstance(v, str):
                raise ErroreTipo(f"`ordina` ordina solo numeri o testi, ma nella lista c'è {articolo(v)}.")
        raise ErroreTipo("`ordina` non può mettere in ordine numeri e testi insieme.",
                         suggerimento="Usa una lista con valori tutti dello stesso tipo.")
    lista.sort(reverse=decrescente)
    return None


@metodo_libreria("lista", "inverti")
def lista_inverti(lista):
    """lista.inverti(): rovescia l'ordine degli elementi della lista.

    Esempio: dopo `l.inverti()` la lista [1, 2, 3] diventa [3, 2, 1].
    """
    lista.reverse()
    return None


lista_inverti.equivalente_veloce = list.reverse


@metodo_libreria("lista", "trova")
def lista_trova(lista, x):
    """lista.trova(x): la posizione del primo elemento uguale a `x`, oppure `nulla` se non c'è.

    Esempio: `["a", "b", "c"].trova("b")` è 1.
    """
    return _posizione(lista, x)


@metodo_libreria("lista", "conta")
def lista_conta(lista, x):
    """lista.conta(x): quante volte `x` compare nella lista.

    Esempio: `[30, 28, 30].conta(30)` è 2.
    """
    return _conta(lista, x)
