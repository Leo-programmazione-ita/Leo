"""Libreria: il web (pagine HTML, indirizzi, sessioni e API, feed, piccoli siti).

Estende ``internet.py`` (che resta com'è) con la sola libreria standard di
Python (``html.parser``, ``urllib``, ``http.cookiejar``, ``http.server``,
``xml.etree``, ``urllib.robotparser``):

* **pagine HTML**: ``analizza_html``, ``leggi_pagina_web`` restituiscono una
  ``pagina_html`` con ``cerca``/``primo`` (selettori CSS semplici),
  ``collegamenti``, ``immagini``, ``tabelle``, ``titoli``, ``moduli``,
  ``meta``; ogni ``elemento_html`` ha ``testo``, ``attributo``, ``figli``...;
  ``html_in_testo``, ``proteggi_html``, ``tabella_in_html``, ``modello_html``;
* **indirizzi**: ``parti_url``, ``dominio_url``, ``parametri_url``,
  ``url_assoluto``, ``e_url``;
* **sessioni e API**: ``sessione_web`` (intestazioni, cookie, token,
  password, tempi massimi, nuovi tentativi, JSON automatico, moduli con file,
  scaricamenti) con ``prendi``/``invia``/``aggiorna``/``modifica``/``cancella``;
* **buone maniere**: ``robots_consente``;
* **feed**: ``leggi_feed`` (RSS e Atom);
* **siti**: ``sito_web`` con pagine, percorsi con parti variabili, risposte
  JSON, file statici; ``risposta_web``, ``reindirizza``. Ascolta solo su
  questo computer (127.0.0.1), a meno di ``aperto_in_rete = vero``.

Gli errori di rete sono ``ErroreFile`` in parole semplici (come in ``internet``).
"""

from __future__ import annotations

import difflib
import html as _html
import json as _json
import mimetypes
import os
import posixpath
import queue
import re
import socket
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import urllib.robotparser
import uuid
from html.parser import HTMLParser
from http.cookiejar import CookieJar
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any

from ..errori import ErroreChiave, ErroreDante, ErroreFile, ErroreTipo, ErroreValore
from ..grafica.servizi import rete
from ..valori import Richiamabile
from . import internet as _rete
from .generali import articolo, funzione_libreria, lunghezza_intervallo, mostra, richiedi_testo
from .ingresso_uscita import _controlla_percorso, _errore_file
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta

__all__ = ["PaginaHtml", "ElementoHtml", "SessioneWeb", "SitoWeb", "RispostaWeb"]

def _tempo(tempo_massimo: Any, nome: str) -> float:
    """Come ``internet._tempo``, ma anche con interi enormi (niente ``OverflowError``)."""
    if isinstance(tempo_massimo, int) and not isinstance(tempo_massimo, bool) and tempo_massimo > 10 ** 9:
        raise ErroreValore(f"`tempo_massimo` di `{nome}` è troppo grande: {mostra(tempo_massimo)} secondi.",
                           suggerimento="Esempio: `tempo_massimo = 10`.")
    return _rete._tempo(tempo_massimo, nome)


# ===========================================================================
# Albero HTML
# ===========================================================================

#: Elementi senza chiusura.
_VUOTI = frozenset("area base br col embed hr img input keygen link meta param source track wbr".split())
#: Elementi "a blocco": nel testo vanno a capo.
_BLOCCHI = frozenset(("address article aside blockquote body center dd details dialog dir div dl dt "
                      "fieldset figcaption figure footer form h1 h2 h3 h4 h5 h6 header hgroup hr html "
                      "li main menu nav ol p pre section summary table tbody td tfoot th thead tr ul "
                      "caption option select textarea").split())
#: Il cui contenuto non è testo da leggere.
_NASCOSTI = frozenset(("script", "style", "head", "template", "noscript", "svg", "iframe", "object", "select",
                       "datalist"))
#: Un nuovo ``<p>`` o blocco chiude il ``<p>`` aperto.
_CHIUDONO_P = frozenset(("address article aside blockquote div dl fieldset footer form h1 h2 h3 h4 h5 h6 "
                         "header hr main menu nav ol p pre section table ul").split())
#: tag -> (tag che chiude se aperti, confini oltre i quali non cerca).
_CHIUSURE_AUTOMATICHE = {
    "li": ({"li"}, {"ul", "ol", "menu"}),
    "dt": ({"dt", "dd"}, {"dl"}),
    "dd": ({"dt", "dd"}, {"dl"}),
    "tr": ({"tr", "td", "th"}, {"table", "thead", "tbody", "tfoot"}),
    "td": ({"td", "th"}, {"tr", "table"}),
    "th": ({"td", "th"}, {"tr", "table"}),
    "thead": ({"thead", "tbody", "tfoot", "tr", "td", "th"}, {"table"}),
    "tbody": ({"thead", "tbody", "tfoot", "tr", "td", "th"}, {"table"}),
    "tfoot": ({"thead", "tbody", "tfoot", "tr", "td", "th"}, {"table"}),
    "option": ({"option"}, {"select", "datalist"}),
    "optgroup": ({"optgroup", "option"}, {"select"}),
}
#: Oltre questa dimensione un testo HTML non si analizza (difesa da pagine enormi).
_HTML_MASSIMO = 20 * 1024 * 1024


class ElementoHtml(OggettoLibreria):
    """Un elemento di una pagina HTML (``<a>``, ``<div>``...) con i suoi figli."""

    NOME_TIPO_DANTE = "elemento_html"
    SUGGERIMENTO_MODIFICA = "Gli elementi di una pagina si leggono soltanto."

    def __init__(self, tag: str, attributi: dict | None = None, genitore: "ElementoHtml | None" = None) -> None:
        self.tag = tag
        self.attributi: dict[str, str] = attributi or {}
        self.figli: list[Any] = []   # ElementoHtml o testo
        self.genitore = genitore

    def testo_dante(self) -> str:
        extra = ""
        if self.attributi.get("id"):
            extra += f' id="{self.attributi["id"]}"'
        if self.attributi.get("class"):
            extra += f' class="{self.attributi["class"]}"'
        return f"<elemento_html <{self.tag}{extra}>>"

    def elementi(self):
        """I discendenti (non sé stesso) in ordine di documento."""
        pila = list(reversed([f for f in self.figli if isinstance(f, ElementoHtml)]))
        while pila:
            el = pila.pop()
            yield el
            pila.extend(reversed([f for f in el.figli if isinstance(f, ElementoHtml)]))

    def fratelli(self) -> list["ElementoHtml"]:
        if self.genitore is None:
            return [self]
        return [f for f in self.genitore.figli if isinstance(f, ElementoHtml)]


class _Costruttore(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.radice = ElementoHtml("#documento")
        self.pila = [self.radice]

    def _chiudi_fino(self, indice: int) -> None:
        del self.pila[indice:]

    def _chiusure(self, tag: str) -> None:
        regola = _CHIUSURE_AUTOMATICHE.get(tag)
        if regola is not None:
            chiude, confini = regola
            for i in range(len(self.pila) - 1, 0, -1):
                t = self.pila[i].tag
                if t in confini:
                    break
                if t in chiude:
                    self._chiudi_fino(i)
                    break
        if tag in _CHIUDONO_P:
            for i in range(len(self.pila) - 1, 0, -1):
                t = self.pila[i].tag
                if t == "p":
                    self._chiudi_fino(i)
                    break
                if t in ("button", "table", "td", "th", "li", "div", "section", "article", "body"):
                    break

    def handle_starttag(self, tag: str, attrs: list) -> None:
        tag = tag.lower()
        self._chiusure(tag)
        attributi = {}
        for k, v in attrs:
            attributi.setdefault(k.lower(), "" if v is None else v)
        el = ElementoHtml(tag, attributi, self.pila[-1])
        self.pila[-1].figli.append(el)
        if tag not in _VUOTI:
            self.pila.append(el)

    def handle_startendtag(self, tag: str, attrs: list) -> None:
        tag = tag.lower()
        self._chiusure(tag)
        attributi = {}
        for k, v in attrs:
            attributi.setdefault(k.lower(), "" if v is None else v)
        self.pila[-1].figli.append(ElementoHtml(tag, attributi, self.pila[-1]))

    def handle_endtag(self, tag: str) -> None:
        tag = tag.lower()
        for i in range(len(self.pila) - 1, 0, -1):
            if self.pila[i].tag == tag:
                self._chiudi_fino(i)
                return

    def handle_data(self, dati: str) -> None:
        figli = self.pila[-1].figli
        if figli and isinstance(figli[-1], str):
            figli[-1] += dati
        else:
            figli.append(dati)


def _albero(testo: str) -> ElementoHtml:
    costruttore = _Costruttore()
    try:
        costruttore.feed(testo)
        costruttore.close()
    except Exception:  # html.parser è tollerante, ma non si sa mai: si tiene quel che c'è
        pass
    return costruttore.radice


_SPAZI = re.compile(r"\s+")


def _testo_semplice(el: ElementoHtml) -> str:
    """Il testo dell'elemento su una riga (spazi compattati, senza script e stili)."""
    pezzi: list[str] = []

    def visita(e: ElementoHtml) -> None:
        for f in e.figli:
            if isinstance(f, str):
                pezzi.append(f)
            elif f.tag in _NASCOSTI and f is not el:
                continue
            else:
                if f.tag == "br" or f.tag in _BLOCCHI:
                    pezzi.append(" ")
                if f.tag == "img" and f.attributi.get("alt"):
                    pezzi.append(f.attributi["alt"])
                visita(f)
                if f.tag in _BLOCCHI:
                    pezzi.append(" ")

    visita(el)
    return _SPAZI.sub(" ", "".join(pezzi)).strip()


_PARAGRAFI = frozenset(("h1", "h2", "h3", "h4", "h5", "h6", "p", "pre", "blockquote", "table", "ul", "ol",
                        "dl", "figure", "form"))


class _Scrittore:
    """Accumula il testo tenendo il conto degli a capo in fondo."""

    def __init__(self) -> None:
        self.pezzi: list[str] = []
        self.a_capo_finali = 0
        self.inizio_riga = True

    def scrivi(self, testo: str) -> None:
        if not testo:
            return
        self.pezzi.append(testo)
        tolto = testo.rstrip("\n")
        if tolto:
            self.a_capo_finali = len(testo) - len(tolto)
        else:
            self.a_capo_finali += len(testo)
        self.inizio_riga = testo.endswith("\n")

    def a_capo(self, n: int) -> None:
        if not self.pezzi:
            return
        if self.a_capo_finali < n:
            self.scrivi("\n" * (n - self.a_capo_finali))

    def parole(self, testo: str) -> None:
        pezzo = _SPAZI.sub(" ", testo)
        if self.inizio_riga or not self.pezzi or self.pezzi[-1].endswith(" "):
            pezzo = pezzo.lstrip(" ")
        self.scrivi(pezzo)


def _testo_formattato(el: ElementoHtml) -> str:
    """Il testo con gli a capo dei paragrafi, degli elenchi e delle tabelle."""
    s = _Scrittore()

    def visita(e: ElementoHtml, pre: bool) -> None:
        for f in e.figli:
            if isinstance(f, str):
                s.scrivi(f) if pre else s.parole(f)
                continue
            t = f.tag
            if t in _NASCOSTI:
                continue
            if t == "br":
                s.scrivi("\n")
                continue
            if t == "img":
                if f.attributi.get("alt"):
                    s.parole(f"[{f.attributi['alt']}]")
                continue
            if t in _PARAGRAFI:
                s.a_capo(2)
            elif t == "li":
                s.a_capo(1)
                s.scrivi("- ")
            elif t in ("td", "th"):
                if not s.inizio_riga:
                    s.scrivi(" | ")
            elif t in _BLOCCHI:
                s.a_capo(1)
            visita(f, pre or t == "pre")
            if t in _PARAGRAFI:
                s.a_capo(2)
            elif t in _BLOCCHI and t not in ("td", "th"):
                s.a_capo(1)

    visita(el, el.tag == "pre")
    righe = [r.rstrip() for r in "".join(s.pezzi).split("\n")]
    return re.sub(r"\n{3,}", "\n\n", "\n".join(righe)).strip()


def _html_di(el: ElementoHtml, interno: bool = False) -> str:
    pezzi: list[str] = []

    def scrivi(e: Any, grezzo: bool) -> None:
        if isinstance(e, str):
            pezzi.append(e if grezzo else _html.escape(e, quote=False))
            return
        attributi = "".join(f' {k}="{_html.escape(v, quote=True)}"' for k, v in e.attributi.items())
        pezzi.append(f"<{e.tag}{attributi}>")
        if e.tag in _VUOTI:
            return
        for f in e.figli:
            scrivi(f, e.tag in ("script", "style"))
        pezzi.append(f"</{e.tag}>")

    if interno or el.tag == "#documento":
        for f in el.figli:
            scrivi(f, el.tag in ("script", "style"))
    else:
        scrivi(el, False)
    return "".join(pezzi)


# ---------------------------------------------------------------------------
# Selettori CSS semplici
# ---------------------------------------------------------------------------

_SUGG_SELETTORE = ("Selettori che puoi usare: \"a\", \".classe\", \"#id\", \"div.notizia\", \"ul > li\", "
                   "\"div p\", \"[href]\", \"a[href^=https]\", \"h1, h2\", \"li:first-child\".")

_NOME_CSS = r"-?[_a-zA-Z\u00a0-\uffff][_a-zA-Z0-9\-\u00a0-\uffff]*"
_PARTE = re.compile(
    r"(?P<tag>\*|" + _NOME_CSS + r")"
    r"|\#(?P<id>" + _NOME_CSS + r")"
    r"|\.(?P<classe>" + _NOME_CSS + r")"
    r"|\[\s*(?P<attr>[^\s~|^$*=\]]+)\s*(?:(?P<op>[~|^$*]?=)\s*(?P<val>\"[^\"]*\"|'[^']*'|[^\]\s]*)\s*)?\]"
    r"|:(?P<pseudo>first-child|last-child|nth-child\(\s*\d+\s*\)|not\([^()]*\))"
)


class _Composto:
    __slots__ = ("tag", "id", "classi", "attributi", "pseudo", "negati")

    def __init__(self) -> None:
        self.tag: str | None = None
        self.id: str | None = None
        self.classi: list[str] = []
        self.attributi: list[tuple[str, str | None, str | None]] = []
        self.pseudo: list[tuple[str, int]] = []
        self.negati: list["_Composto"] = []


def _errore_selettore(selettore: str, dettaglio: str) -> ErroreValore:
    return ErroreValore(f"Il selettore {mostra(selettore)} non è valido: {dettaglio}.",
                        suggerimento=_SUGG_SELETTORE)


def _analizza_composto(testo: str, selettore: str) -> _Composto:
    c = _Composto()
    pos = 0
    while pos < len(testo):
        m = _PARTE.match(testo, pos)
        if m is None:
            raise _errore_selettore(selettore, f"non capisco {mostra(testo[pos:])}")
        if m.group("tag"):
            if pos != 0:
                raise _errore_selettore(selettore, f"il nome del tag {mostra(m.group('tag'))} va all'inizio")
            if m.group("tag") != "*":
                c.tag = m.group("tag").lower()
        elif m.group("id"):
            c.id = m.group("id")
        elif m.group("classe"):
            c.classi.append(m.group("classe"))
        elif m.group("attr"):
            val = m.group("val")
            if val is not None and len(val) >= 2 and val[0] == val[-1] and val[0] in "\"'":
                val = val[1:-1]
            c.attributi.append((m.group("attr").lower(), m.group("op"), val))
        else:
            p = m.group("pseudo")
            if p.startswith("nth-child"):
                c.pseudo.append(("nth", int(p[p.index("(") + 1:-1])))
            elif p.startswith("not("):
                interno = p[4:-1].strip()
                if not interno:
                    raise _errore_selettore(selettore, ":not() è vuoto")
                c.negati.append(_analizza_composto(interno, selettore))
            else:
                c.pseudo.append((p, 0))
        pos = m.end()
    return c


def _analizza_selettore(selettore: str) -> list[list[tuple[str, _Composto]]]:
    """``"ul > li.a, h1"`` -> gruppi di [(combinatore, composto), ...]."""
    s = selettore.strip()
    if not s:
        raise _errore_selettore(selettore, "è vuoto")
    gruppi = []
    for pezzo in _dividi_fuori_parentesi(s, ","):
        pezzo = pezzo.strip()
        if not pezzo:
            raise _errore_selettore(selettore, "c'è una virgola di troppo")
        catena: list[tuple[str, _Composto]] = []
        segni = re.split(r"(\s*>\s*|\s+)(?![^\[]*\])(?![^(]*\))", pezzo)
        combinatore = " "
        for i, segno in enumerate(segni):
            if i % 2 == 1:
                combinatore = ">" if ">" in segno else " "
                continue
            if not segno:
                if i == 0 or i == len(segni) - 1:
                    raise _errore_selettore(selettore, "c'è un `>` senza niente da una parte")
                continue
            if segno.startswith(("+", "~")):
                raise _errore_selettore(selettore, "i combinatori `+` e `~` non ci sono")
            catena.append((combinatore, _analizza_composto(segno, selettore)))
        if not catena:
            raise _errore_selettore(selettore, "è vuoto")
        gruppi.append(catena)
    return gruppi


def _dividi_fuori_parentesi(testo: str, separatore: str) -> list[str]:
    parti, livello, attuale = [], 0, []
    for ch in testo:
        if ch in "([":
            livello += 1
        elif ch in ")]":
            livello = max(0, livello - 1)
        if ch == separatore and livello == 0:
            parti.append("".join(attuale))
            attuale = []
        else:
            attuale.append(ch)
    parti.append("".join(attuale))
    return parti


def _corrisponde(el: ElementoHtml, c: _Composto) -> bool:
    if c.tag is not None and el.tag != c.tag:
        return False
    if c.id is not None and el.attributi.get("id") != c.id:
        return False
    if c.classi:
        classi = el.attributi.get("class", "").split()
        if any(k not in classi for k in c.classi):
            return False
    for nome, op, val in c.attributi:
        if nome not in el.attributi:
            return False
        if op is None:
            continue
        v = el.attributi[nome]
        if op == "=" and v != val:
            return False
        if op == "~=" and val not in v.split():
            return False
        if op == "|=" and not (v == val or v.startswith(val + "-")):
            return False
        if op == "^=" and not (val and v.startswith(val)):
            return False
        if op == "$=" and not (val and v.endswith(val)):
            return False
        if op == "*=" and not (val and val in v):
            return False
    for p, n in c.pseudo:
        fratelli = el.fratelli()
        if p == "first-child" and fratelli[0] is not el:
            return False
        if p == "last-child" and fratelli[-1] is not el:
            return False
        if p == "nth" and (n < 1 or n > len(fratelli) or fratelli[n - 1] is not el):
            return False
    return not any(_corrisponde(el, neg) for neg in c.negati)


def _corrisponde_catena(el: ElementoHtml, catena: list, indice: int, radice: ElementoHtml) -> bool:
    combinatore, composto = catena[indice]
    if not _corrisponde(el, composto):
        return False
    if indice == 0:
        return True
    padre = el.genitore
    if combinatore == ">":
        return padre is not None and padre.tag != "#documento" \
            and _corrisponde_catena(padre, catena, indice - 1, radice)
    while padre is not None and padre.tag != "#documento":
        if _corrisponde_catena(padre, catena, indice - 1, radice):
            return True
        padre = padre.genitore
    return False


def _cerca(el: ElementoHtml, selettore: Any, testo: Any, nome: str) -> list[ElementoHtml]:
    richiedi_testo(selettore, nome, "selettore")
    if testo is not None:
        richiedi_testo(testo, nome, "testo")
    gruppi = _analizza_selettore(selettore)
    trovati = []
    cercato = testo.casefold() if testo is not None else None
    for e in el.elementi():
        if any(_corrisponde_catena(e, catena, len(catena) - 1, el) for catena in gruppi):
            if cercato is None or cercato in _testo_semplice(e).casefold():
                trovati.append(e)
    return trovati


# ---------------------------------------------------------------------------
# Pagina
# ---------------------------------------------------------------------------

class PaginaHtml(OggettoLibreria):
    """Una pagina HTML analizzata, in cui si può cercare."""

    NOME_TIPO_DANTE = "pagina_html"
    SUGGERIMENTO_MODIFICA = "Una pagina si legge soltanto: per crearne una nuova usa `analizza_html(testo)`."

    def __init__(self, testo: str, indirizzo: str = "") -> None:
        self.sorgente = testo
        self.indirizzo = indirizzo
        self.radice = _albero(testo)
        base = next((e for e in self.radice.elementi() if e.tag == "base" and e.attributi.get("href")), None)
        self.base = urllib.parse.urljoin(indirizzo, base.attributi["href"]) if base is not None else indirizzo

    def testo_dante(self) -> str:
        titolo = _pagina_titolo(self)
        return f"<pagina_html {mostra(titolo)}>" if titolo else "<pagina_html>"

    def assoluto(self, collegamento: str) -> str:
        collegamento = collegamento.strip()
        return urllib.parse.urljoin(self.base, collegamento) if self.base else collegamento


# proprietà e metodi comuni a pagina ed elemento --------------------------------

def _radice(x: Any) -> ElementoHtml:
    return x.radice if isinstance(x, PaginaHtml) else x


@metodo_oggetto(PaginaHtml, "cerca")
def pagina_cerca(p, selettore, testo=None):
    """pagina.cerca(selettore, testo = nulla): tutti gli elementi che corrispondono al selettore CSS.

    Il selettore può essere un tag ("a"), una classe (".notizia"), un id ("#menu"), una
    combinazione ("div.notizia > h2", "ul li", "a[href^=https]") o più selettori separati da
    virgole ("h1, h2"). Con `testo` tiene solo gli elementi che contengono quel testo.
    Esempio: `per ogni t in pagina.cerca("h2.titolo") fai stampa(t.testo) fine`.
    """
    return _cerca(_radice(p), selettore, testo, "cerca")


@metodo_oggetto(PaginaHtml, "primo")
def pagina_primo(p, selettore, testo=None):
    """pagina.primo(selettore, testo = nulla): il primo elemento che corrisponde al selettore, o `nulla`.

    Esempio: `variabile prezzo = pagina.primo(".prezzo")` e poi `se prezzo != nulla allora stampa(prezzo.testo) fine`.
    """
    trovati = _cerca(_radice(p), selettore, testo, "primo")
    return trovati[0] if trovati else None


metodo_oggetto(ElementoHtml, "cerca")(pagina_cerca)
metodo_oggetto(ElementoHtml, "primo")(pagina_primo)


def _pagina_titolo(p: PaginaHtml) -> str:
    el = next((e for e in p.radice.elementi() if e.tag == "title"), None)
    return _testo_semplice(el) if el is not None else ""


proprieta(PaginaHtml, "titolo")(_pagina_titolo)
proprieta(PaginaHtml, "testo")(lambda p: _testo_formattato(p.radice))
proprieta(PaginaHtml, "html")(lambda p: p.sorgente)
proprieta(PaginaHtml, "indirizzo")(lambda p: p.indirizzo)
proprieta(PaginaHtml, "lingua")(lambda p: next((e.attributi.get("lang", "") for e in p.radice.elementi()
                                                if e.tag == "html"), ""))

proprieta(ElementoHtml, "tag")(lambda e: e.tag)
proprieta(ElementoHtml, "testo")(_testo_semplice)
proprieta(ElementoHtml, "html")(lambda e: _html_di(e))
proprieta(ElementoHtml, "html_interno")(lambda e: _html_di(e, interno=True))
proprieta(ElementoHtml, "attributi")(lambda e: dict(e.attributi))
proprieta(ElementoHtml, "classi")(lambda e: e.attributi.get("class", "").split())
proprieta(ElementoHtml, "id")(lambda e: e.attributi.get("id", ""))
proprieta(ElementoHtml, "figli")(lambda e: [f for f in e.figli if isinstance(f, ElementoHtml)])
proprieta(ElementoHtml, "genitore")(lambda e: e.genitore if e.genitore is not None
                                    and e.genitore.tag != "#documento" else None)


@metodo_oggetto(ElementoHtml, "attributo")
def elemento_attributo(e, nome, predefinito=None):
    """elemento.attributo(nome, predefinito = nulla): il valore di un attributo (`href`, `src`, `class`...).

    Se l'attributo non c'è restituisce `predefinito`.
    Esempio: `stampa(collegamento.attributo("href"))`.
    """
    richiedi_testo(nome, "attributo", "nome")
    return e.attributi.get(nome.strip().lower(), predefinito)


@metodo_oggetto(PaginaHtml, "collegamenti")
def pagina_collegamenti(p, contiene=None):
    """pagina.collegamenti(contiene = nulla): tutti i collegamenti (`<a href>`) come dizionari `testo` e `indirizzo`.

    Gli indirizzi sono completi (relativi alla pagina). Senza doppioni. Con `contiene` tiene
    solo quelli il cui indirizzo contiene quel testo.
    Esempio: `per ogni c in pagina.collegamenti() fai stampa(c["testo"], "->", c["indirizzo"]) fine`.
    """
    if contiene is not None:
        richiedi_testo(contiene, "collegamenti", "contiene")
    visti: set[str] = set()
    risultato = []
    for e in p.radice.elementi():
        if e.tag not in ("a", "area") or "href" not in e.attributi:
            continue
        href = e.attributi["href"].strip()
        if not href or href.lower().startswith(("javascript:", "data:")) or href.startswith("#"):
            continue
        indirizzo = p.assoluto(href)
        if indirizzo in visti or (contiene is not None and contiene not in indirizzo):
            continue
        visti.add(indirizzo)
        risultato.append({"testo": _testo_semplice(e) or e.attributi.get("title", ""), "indirizzo": indirizzo})
    return risultato


@metodo_oggetto(PaginaHtml, "immagini")
def pagina_immagini(p):
    """pagina.immagini(): tutte le immagini come dizionari `indirizzo`, `descrizione` (il testo `alt`), `larghezza`, `altezza`.

    Esempio: `per ogni img in pagina.immagini() fai stampa(img["indirizzo"]) fine`.
    """
    risultato = []
    for e in p.radice.elementi():
        if e.tag != "img":
            continue
        src = (e.attributi.get("src") or e.attributi.get("data-src") or "").strip()
        if not src:
            continue

        def misura(nome: str) -> Any:
            v = e.attributi.get(nome, "").strip().removesuffix("px")
            return int(v) if v.isdigit() else None

        risultato.append({"indirizzo": src if src.startswith("data:") else p.assoluto(src),
                          "descrizione": e.attributi.get("alt", ""),
                          "larghezza": misura("width"), "altezza": misura("height")})
    return risultato


def _converti(cella: str) -> Any:
    from .archivi import _converti_cella
    try:
        return _converti_cella(cella, ";")
    except Exception:
        return cella


def _righe_tabella(tabella: ElementoHtml) -> list[tuple[list[str], bool]]:
    """Righe della tabella (senza le tabelle annidate): (celle, tutte_intestazioni)."""
    righe = []
    occupate: dict[int, tuple[int, str]] = {}  # colonna -> (righe rimaste, testo) per rowspan

    def righe_di(el: ElementoHtml):
        for f in el.figli:
            if not isinstance(f, ElementoHtml):
                continue
            if f.tag == "tr":
                yield f
            elif f.tag in ("thead", "tbody", "tfoot"):
                yield from righe_di(f)

    for tr in righe_di(tabella):
        celle: list[str] = []
        tutte_th = True
        colonna = 0
        for td in (f for f in tr.figli if isinstance(f, ElementoHtml) and f.tag in ("td", "th")):
            while colonna in occupate:
                rimaste, testo = occupate[colonna]
                celle.append(testo)
                if rimaste <= 1:
                    del occupate[colonna]
                else:
                    occupate[colonna] = (rimaste - 1, testo)
                colonna += 1
            testo = _testo_semplice(td)
            tutte_th = tutte_th and td.tag == "th"
            quante = td.attributi.get("colspan", "1").strip()
            quante_n = min(int(quante), 100) if quante.isdigit() and int(quante) > 0 else 1
            alte = td.attributi.get("rowspan", "1").strip()
            alte_n = min(int(alte), 1000) if alte.isdigit() and int(alte) > 0 else 1
            for _ in range(quante_n):
                celle.append(testo)
                if alte_n > 1:
                    occupate[colonna] = (alte_n - 1, testo)
                colonna += 1
        while colonna in occupate:
            rimaste, testo = occupate[colonna]
            celle.append(testo)
            if rimaste <= 1:
                del occupate[colonna]
            else:
                occupate[colonna] = (rimaste - 1, testo)
            colonna += 1
        if celle:
            righe.append((celle, tutte_th))
    return righe


def _tabella_dati(tabella: ElementoHtml, converti: bool) -> list:
    righe = _righe_tabella(tabella)
    if not righe:
        return []
    valore = _converti if converti else (lambda x: x)
    celle, intestazione = righe[0]
    ha_thead = any(isinstance(f, ElementoHtml) and f.tag == "thead" for f in tabella.figli)
    if intestazione or ha_thead:
        nomi: list[str] = []
        for i, n in enumerate(celle):
            n = n or f"colonna{i + 1}"
            base, k = n, 2
            while n in nomi:
                n, k = f"{base}_{k}", k + 1
            nomi.append(n)
        risultato = []
        for riga, _ in righe[1:]:
            riga = riga + [""] * (len(nomi) - len(riga))
            risultato.append({nome: valore(c) for nome, c in zip(nomi, riga)})
        return risultato
    return [[valore(c) for c in riga] for riga, _ in righe]


@metodo_oggetto(PaginaHtml, "tabelle")
def pagina_tabelle(p, converti_numeri=True):
    """pagina.tabelle(converti_numeri = vero): le tabelle HTML della pagina come tabelle di dati.

    Ogni tabella è una lista di righe: se la tabella ha la riga di intestazione (`<th>`) ogni
    riga è un dizionario colonna -> valore (come `leggi_tabella`), altrimenti una lista. I
    numeri diventano numeri (anche "3,5").
    Esempio: `variabile classifica = pagina.tabelle()[0]` e poi `stampa(classifica[0]["Squadra"])`.
    """
    if not isinstance(converti_numeri, bool):
        raise ErroreTipo(f"`converti_numeri` di `tabelle` deve essere `vero` o `falso`, non {articolo(converti_numeri)}.")
    return [_tabella_dati(e, converti_numeri) for e in p.radice.elementi() if e.tag == "table"]


@metodo_oggetto(PaginaHtml, "titoli")
def pagina_titoli(p):
    """pagina.titoli(): i titoli della pagina (`<h1>`...`<h6>`) come dizionari `livello` e `testo`, in ordine.

    È l'indice della pagina. Esempio:
    `per ogni t in pagina.titoli() fai stampa("  " * (t["livello"] - 1) + t["testo"]) fine`.
    """
    return [{"livello": int(e.tag[1]), "testo": _testo_semplice(e)}
            for e in p.radice.elementi() if re.fullmatch(r"h[1-6]", e.tag)]


@metodo_oggetto(PaginaHtml, "moduli")
def pagina_moduli(p):
    """pagina.moduli(): i moduli (`<form>`) della pagina: `azione` (indirizzo completo), `metodo` e `campi` (nome -> valore).

    Utile con `sessione.invia_modulo(...)`: i campi nascosti (per esempio i gettoni di sicurezza)
    sono già dentro `campi`. Esempio: `variabile m = pagina.moduli()[0]` e poi `stampa(m["campi"])`.
    """
    risultato = []
    for form in (e for e in p.radice.elementi() if e.tag == "form"):
        campi: dict[str, Any] = {}
        for c in form.elementi():
            nome = c.attributi.get("name")
            if not nome or "disabled" in c.attributi:
                continue
            if c.tag == "input":
                tipo = c.attributi.get("type", "text").lower()
                if tipo in ("submit", "button", "image", "reset", "file"):
                    continue
                if tipo in ("checkbox", "radio"):
                    if "checked" in c.attributi:
                        campi[nome] = c.attributi.get("value", "on")
                    else:
                        campi.setdefault(nome, None) if tipo == "checkbox" else None
                    continue
                campi[nome] = c.attributi.get("value", "")
            elif c.tag == "textarea":
                campi[nome] = "".join(f for f in c.figli if isinstance(f, str))
            elif c.tag == "select":
                opzioni = [o for o in c.elementi() if o.tag == "option"]
                scelta = next((o for o in opzioni if "selected" in o.attributi), opzioni[0] if opzioni else None)
                if scelta is not None:
                    campi[nome] = scelta.attributi.get("value", _testo_semplice(scelta))
        campi = {k: v for k, v in campi.items() if v is not None}
        azione = form.attributi.get("action", "").strip()
        risultato.append({"azione": p.assoluto(azione) if azione else p.indirizzo,
                          "metodo": (form.attributi.get("method") or "GET").upper(),
                          "campi": campi,
                          "id": form.attributi.get("id", "")})
    return risultato


@metodo_oggetto(PaginaHtml, "meta")
def pagina_meta(p):
    """pagina.meta(): le informazioni `<meta>` della pagina (descrizione, autore, parole chiave...) come dizionario.

    Esempio: `stampa(pagina.meta().ottieni("description", "nessuna descrizione"))`.
    """
    risultato = {}
    for e in p.radice.elementi():
        if e.tag != "meta":
            continue
        nome = e.attributi.get("name") or e.attributi.get("property") or e.attributi.get("http-equiv")
        if nome and "content" in e.attributi:
            risultato.setdefault(nome.lower(), e.attributi["content"])
        elif "charset" in e.attributi:
            risultato.setdefault("charset", e.attributi["charset"])
    return risultato


# ---------------------------------------------------------------------------
# Funzioni sull'HTML
# ---------------------------------------------------------------------------

def _testo_html(valore: Any, nome: str) -> str:
    richiedi_testo(valore, nome, "html")
    if len(valore) > _HTML_MASSIMO:
        raise ErroreValore(f"Il testo HTML passato a `{nome}` è troppo grande (più di 20 MB).")
    return valore


@funzione_libreria("analizza_html")
def analizza_html(html, indirizzo=None):
    """analizza_html(html, indirizzo = nulla): trasforma un testo HTML in una `pagina_html` in cui cercare.

    Con `indirizzo` (l'indirizzo da cui viene la pagina) i collegamenti relativi diventano completi.
    Esempio: `variabile p = analizza_html("<ul><li>uno</li><li>due</li></ul>")` e poi
    `per ogni li in p.cerca("li") fai stampa(li.testo) fine`.
    """
    _testo_html(html, "analizza_html")
    if indirizzo is not None:
        richiedi_testo(indirizzo, "analizza_html", "indirizzo")
    return PaginaHtml(html, (indirizzo or "").strip())


@funzione_libreria("leggi_pagina_web")
def leggi_pagina_web(indirizzo, tempo_massimo=15):
    """leggi_pagina_web(indirizzo, tempo_massimo = 15): scarica una pagina web e la restituisce come `pagina_html`.

    È `scarica_pagina` + `analizza_html`. Se il sito risponde con un errore (404...) ricevi un
    `ErroreFile` che lo spiega.
    Esempio: `variabile p = leggi_pagina_web("https://www.esempio.it")` e poi `stampa(p.titolo)`.
    """
    risposta = _rete._pagina("leggi_pagina_web", indirizzo, _tempo(tempo_massimo, "leggi_pagina_web"))
    return PaginaHtml(risposta["testo"], risposta["indirizzo"])


@funzione_libreria("html_in_testo")
def html_in_testo(html):
    """html_in_testo(html): toglie i tag da un testo HTML e lascia il testo leggibile, con gli a capo.

    Script e stili spariscono, `&amp;` e simili diventano i caratteri veri, gli elenchi hanno il trattino.
    Esempio: `html_in_testo("<p>Ciao <b>Ada</b> &amp; Leo</p>")` è "Ciao Ada & Leo".
    """
    return _testo_formattato(_albero(_testo_html(html, "html_in_testo")))


@funzione_libreria("proteggi_html")
def proteggi_html(testo):
    """proteggi_html(testo): prepara un testo per metterlo dentro una pagina HTML (`<` diventa `&lt;`...).

    Serve con i testi scritti dagli utenti: così non possono inserire tag o script nella pagina.
    Esempio: `proteggi_html("<b>3 > 2</b>")` è "&lt;b&gt;3 &gt; 2&lt;/b&gt;".
    """
    if isinstance(testo, (int, float)) and not isinstance(testo, bool):
        testo = str(testo)
    richiedi_testo(testo, "proteggi_html", "testo")
    return _html.escape(testo, quote=True)


def _cella_html(v: Any) -> str:
    return _html.escape(_rete._testo_semplice(v), quote=False)


def tabella_in_html(righe, titolo=None, intestazione=None, classe=None):
    """La funzione `tabella_in_html` è una sola per tutta la libreria: sta nella libreria ufficio
    (didascalia, numeri a destra, intestazione automatica o scelta, classe CSS)."""
    from . import ufficio as _ufficio
    return _ufficio.tabella_in_html(righe, titolo, intestazione, classe)


_MARCA = re.compile(r"\[\[\s*(.*?)\s*\]\]", re.S)
_BLOCCO_DA_SOLO = re.compile(r"^[ \t]*(\[\[\s*(?:per ogni\s[^\]]*|se\s[^\]]*|altrimenti|fine)\s*\]\])[ \t]*\r?\n",
                             re.M)
_NOME_MODELLO = re.compile(r"[^\W\d]\w*(?:\.\w+)*|\.", re.U)
_SUGG_MODELLO = ("Nel modello puoi scrivere: `[[nome]]`, `[[html nome]]`, `[[per ogni x in lista]] ... [[fine]]`, "
                 "`[[se nome]] ... [[altrimenti]] ... [[fine]]`.")


def _cerca_valore(contesti: list, nome: str, obbligatorio: bool) -> Any:
    parti = nome.split(".")
    for ctx in reversed(contesti):
        if isinstance(ctx, dict) and parti[0] in ctx:
            valore = ctx[parti[0]]
            for p in parti[1:]:
                if isinstance(valore, dict) and p in valore:
                    valore = valore[p]
                elif isinstance(valore, list) and p.isdigit() and int(p) < len(valore):
                    valore = valore[int(p)]
                else:
                    if not obbligatorio:
                        return None
                    raise ErroreChiave(f"Nel modello c'è `[[{nome}]]` ma `{p}` non si trova nei dati.")
            return valore
    if not obbligatorio:
        return None
    chiavi = sorted({str(k) for ctx in contesti if isinstance(ctx, dict) for k in ctx})
    simili = difflib.get_close_matches(parti[0], chiavi, n=1, cutoff=0.6)
    suggerimento = (f"Forse intendevi `[[{simili[0]}]]`?" if simili
                    else ("Chiavi nei dati: " + ", ".join(f"`{k}`" for k in chiavi[:10]) + "." if chiavi
                          else "Passa i dati come dizionario: `modello_html(modello, {\"nome\": \"Ada\"})`."))
    raise ErroreChiave(f"Nel modello c'è `[[{nome}]]` ma nei dati non c'è {mostra(parti[0])}.",
                       suggerimento=suggerimento)


def _vero(v: Any) -> bool:
    return not (v is None or v is False or v == "" or v == [] or v == {} or v == 0)


def _nome_valido(nome: str, marca: str) -> str:
    if not _NOME_MODELLO.fullmatch(nome):
        raise ErroreValore(f"Nel modello non capisco `[[{marca}]]`.", suggerimento=_SUGG_MODELLO)
    return nome


def _analizza_modello(modello: str) -> list:
    """Albero: testo, ("var", nome, grezzo), ("per", variabile, nome, figli), ("se", nome, negato, si, no)."""
    # un blocco da solo sulla sua riga non lascia una riga vuota
    modello = _BLOCCO_DA_SOLO.sub(r"\1", modello)
    radice: list = []
    #: (genere, contenitore corrente, nodo)
    pila: list[tuple[str, list, Any]] = [("", radice, None)]
    pos = 0
    for m in _MARCA.finditer(modello):
        pila[-1][1].append(modello[pos:m.start()])
        pos = m.end()
        marca = _SPAZI.sub(" ", m.group(1))
        parole = marca.split(" ")
        if not marca:
            raise ErroreValore("Nel modello c'è `[[ ]]` senza niente dentro.", suggerimento=_SUGG_MODELLO)
        if parole[0] == "per" and len(parole) >= 2 and parole[1] == "ogni":
            if len(parole) != 5 or parole[3] != "in":
                raise ErroreValore(f"Nel modello `[[{marca}]]` è scritto male.",
                                   suggerimento="Si scrive `[[per ogni voto in voti]] ... [[fine]]`.")
            figli: list = []
            pila[-1][1].append(("per", _nome_valido(parole[2], marca), _nome_valido(parole[4], marca), figli))
            pila.append(("per", figli, None))
        elif parole[0] == "se":
            negato = len(parole) == 3 and parole[1] == "non"
            if len(parole) != (3 if negato else 2):
                raise ErroreValore(f"Nel modello `[[{marca}]]` è scritto male.",
                                   suggerimento="Si scrive `[[se nome]] ... [[fine]]` o `[[se non nome]] ... [[fine]]`.")
            nodo = ("se", _nome_valido(parole[-1], marca), negato, [], [])
            pila[-1][1].append(nodo)
            pila.append(("se", nodo[3], nodo))
        elif marca == "altrimenti":
            if pila[-1][0] != "se" or pila[-1][1] is not pila[-1][2][3]:
                raise ErroreValore("Nel modello c'è `[[altrimenti]]` fuori da un `[[se ...]]`.",
                                   suggerimento=_SUGG_MODELLO)
            pila[-1] = ("se", pila[-1][2][4], pila[-1][2])
        elif marca == "fine":
            if len(pila) == 1:
                raise ErroreValore("Nel modello c'è un `[[fine]]` di troppo.", suggerimento=_SUGG_MODELLO)
            pila.pop()
        elif parole[0] == "html" and len(parole) == 2:
            pila[-1][1].append(("var", _nome_valido(parole[1], marca), True))
        else:
            pila[-1][1].append(("var", _nome_valido(marca, marca), False))
    pila[-1][1].append(modello[pos:])
    if len(pila) > 1:
        genere = "[[per ogni ...]]" if pila[-1][0] == "per" else "[[se ...]]"
        raise ErroreValore(f"Nel modello un `{genere}` non ha il suo `[[fine]]`.",
                           suggerimento="Aggiungi `[[fine]]` dove finisce il pezzo da ripetere o da mostrare.")
    return radice


def _componi(nodi: list, contesti: list, uscita: list, profondita: int = 0) -> None:
    if profondita > 50:
        raise ErroreValore("Il modello ha troppi blocchi uno dentro l'altro.")
    for n in nodi:
        if isinstance(n, str):
            uscita.append(n)
        elif n[0] == "var":
            v = contesti[-1] if n[1] == "." else _cerca_valore(contesti, n[1], True)
            t = _rete._testo_semplice(v)
            uscita.append(t if n[2] else _html.escape(t, quote=True))
        elif n[0] == "per":
            _, variabile, nome, figli = n
            v = _cerca_valore(contesti, nome, True)
            if isinstance(v, dict):
                v = list(v)
            if not isinstance(v, (list, range, str)):
                raise ErroreTipo(f"Nel modello `[[per ogni {variabile} in {nome}]]` vuole una lista, "
                                 f"ma `{nome}` è {articolo(v)}.")
            if isinstance(v, range) and lunghezza_intervallo(v) > 100_000:
                raise ErroreValore(f"Nel modello `{nome}` ha troppi elementi da ripetere.")
            for elemento in v:
                _componi(figli, contesti + [{variabile: elemento}], uscita, profondita + 1)
        else:
            _, nome, negato, si, no = n
            v = _vero(_cerca_valore(contesti, nome, False))
            _componi(si if v != negato else no, contesti, uscita, profondita + 1)


@funzione_libreria("modello_html")
def modello_html(modello, dati=None):
    """modello_html(modello, dati = nulla): riempie un modello HTML con i dati di un dizionario, proteggendo i testi.

    Nel modello: `[[nome]]` mette il valore protetto (niente tag), `[[html nome]]` lo mette così
    com'è, `[[utente.nome]]` entra nei dizionari; `[[per ogni v in voti]] ... [[fine]]` ripete il
    pezzo per ogni elemento; `[[se nome]] ... [[altrimenti]] ... [[fine]]` lo mostra solo se il
    valore c'è (`[[se non nome]]` il contrario). Il modello può venire da un file (`leggi_file`).
    Esempio: `modello_html("<h1>Ciao [[nome]]</h1><ul>[[per ogni v in voti]]<li>[[v]]</li>[[fine]]</ul>", {"nome": "Ada", "voti": [8, 9]})`.
    """
    richiedi_testo(modello, "modello_html", "modello")
    if dati is None:
        dati = {}
    if not isinstance(dati, dict):
        raise ErroreTipo(f"`dati` di `modello_html` deve essere un dizionario, non {articolo(dati)}.",
                         suggerimento="Esempio: `modello_html(\"<p>[[nome]]</p>\", {\"nome\": \"Ada\"})`.")
    uscita: list[str] = []
    _componi(_analizza_modello(modello), [dati], uscita)
    return "".join(uscita)


# ===========================================================================
# Indirizzi
# ===========================================================================

def _parti_generiche(indirizzo: Any, nome: str) -> urllib.parse.SplitResult:
    richiedi_testo(indirizzo, nome, "indirizzo")
    pulito = indirizzo.strip()
    parti = urllib.parse.urlsplit(pulito)
    if not parti.scheme or not parti.netloc:
        suggerimento = (f"Forse intendevi \"https://{pulito}\"?" if pulito and "://" not in pulito
                        and " " not in pulito else "Un indirizzo è fatto come \"https://www.esempio.it/pagina\".")
        raise ErroreValore(f"{mostra(pulito)} non è un indirizzo completo.", suggerimento=suggerimento)
    try:
        parti.port  # noqa: B018
    except ValueError:
        raise ErroreValore(f"La porta nell'indirizzo {mostra(pulito)} non è valida.") from None
    return parti


_PORTE = {"http": 80, "https": 443, "ftp": 21, "ws": 80, "wss": 443}


@funzione_libreria("parti_url")
def parti_url(indirizzo):
    """parti_url(indirizzo): divide un indirizzo web nelle sue parti, in un dizionario.

    Chiavi: `schema` ("https"), `dominio`, `porta`, `percorso`, `parametri` (dizionario),
    `frammento` (dopo `#`), `utente`.
    Esempio: `parti_url("https://www.esempio.it:8080/cerca?q=leo#fine")["percorso"]` è "/cerca".
    """
    parti = _parti_generiche(indirizzo, "parti_url")
    schema = parti.scheme.lower()
    return {
        "schema": schema,
        "dominio": (parti.hostname or "").lower(),
        "porta": parti.port if parti.port is not None else _PORTE.get(schema),
        "percorso": urllib.parse.unquote(parti.path) or "/",
        "parametri": rete._parametri(parti.query),
        "frammento": urllib.parse.unquote(parti.fragment),
        "utente": urllib.parse.unquote(parti.username) if parti.username else None,
    }


@funzione_libreria("dominio_url")
def dominio_url(indirizzo):
    """dominio_url(indirizzo): il nome del sito di un indirizzo web (senza `https://`, porta e percorso).

    Esempio: `dominio_url("https://www.esempio.it/notizie?id=3")` è "www.esempio.it".
    """
    return (_parti_generiche(indirizzo, "dominio_url").hostname or "").lower()


@funzione_libreria("parametri_url")
def parametri_url(indirizzo):
    """parametri_url(indirizzo): i parametri di un indirizzo (la parte dopo `?`) come dizionario.

    Un parametro ripetuto diventa una lista. Funziona anche con la sola parte `?a=1&b=2`.
    Esempio: `parametri_url("https://www.esempio.it/cerca?q=pi%C3%B9+voti&pagina=2")` è
    `{"q": "più voti", "pagina": "2"}`.
    """
    richiedi_testo(indirizzo, "parametri_url", "indirizzo")
    testo = indirizzo.strip()
    if "?" in testo:
        testo = testo.split("?", 1)[1]
    elif "://" in testo:
        testo = ""
    return rete._parametri(testo.split("#", 1)[0])


@funzione_libreria("url_assoluto")
def url_assoluto(base, collegamento):
    """url_assoluto(base, collegamento): l'indirizzo completo di un collegamento relativo trovato nella pagina `base`.

    Esempio: `url_assoluto("https://www.esempio.it/notizie/oggi.html", "../foto/gatto.png")` è
    "https://www.esempio.it/foto/gatto.png".
    """
    _parti_generiche(base, "url_assoluto")
    richiedi_testo(collegamento, "url_assoluto", "collegamento")
    return urllib.parse.urljoin(base.strip(), collegamento.strip())


@funzione_libreria("e_url")
def e_url(testo):
    """e_url(testo): `vero` se il testo è un indirizzo web completo (`http://` o `https://` con il nome del sito).

    Non dà mai errore. Esempi: `e_url("https://www.esempio.it")` è vero, `e_url("esempio")` è falso.
    """
    if not isinstance(testo, str):
        return False
    t = testo.strip()
    if not t or any(c.isspace() for c in t) or len(t) > 8000:
        return False
    try:
        parti = urllib.parse.urlsplit(t)
        parti.port  # noqa: B018
    except ValueError:
        return False
    host = parti.hostname or ""
    if parti.scheme.lower() not in ("http", "https") or not host:
        return False
    return bool(re.fullmatch(r"[\w.\-]+|\[[0-9a-fA-F:.]+\]", host) or ":" in host) and ".." not in host \
        and not host.startswith(".")


# ===========================================================================
# Sessioni web e API
# ===========================================================================

_IDEMPOTENTI = frozenset(("GET", "HEAD", "PUT", "DELETE", "OPTIONS"))


class SessioneWeb(OggettoLibreria):
    """Una serie di richieste allo stesso sito, con intestazioni, cookie e accesso in comune."""

    NOME_TIPO_DANTE = "sessione_web"
    SUGGERIMENTO_MODIFICA = "Per cambiare le intestazioni usa `sessione.imposta_intestazione(nome, valore)`."
    #: Attesa prima del primo nuovo tentativo (poi raddoppia).
    ATTESA_BASE = 0.5
    ATTESA_MASSIMA = 30.0

    def __init__(self, base: str, intestazioni: dict, tempo: float, tentativi: int) -> None:
        self.base = base
        self.intestazioni = intestazioni
        self.autorizzazione: str | None = None
        self.tempo = tempo
        self.tentativi = tentativi
        self.cookie = CookieJar()
        self.ultima: dict | None = None
        self._aperture = {
            False: urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.cookie)),
            True: urllib.request.build_opener(urllib.request.ProxyHandler({}),
                                              urllib.request.HTTPCookieProcessor(self.cookie)),
        }

    def testo_dante(self) -> str:
        return f"<sessione_web {self.base}>" if self.base else "<sessione_web>"

    def url(self, percorso: Any, nome: str) -> str:
        if percorso is None:
            percorso = ""
        richiedi_testo(percorso, nome, "percorso")
        p = percorso.strip()
        if p.lower().startswith(("http://", "https://")):
            return p
        if not self.base:
            raise ErroreValore(f"{mostra(p)} non è un indirizzo completo e la sessione non ha un indirizzo base.",
                               suggerimento="Scrivi l'indirizzo intero (\"https://...\") oppure crea la sessione "
                                            "con `sessione_web(\"https://api.esempio.it\")`.")
        if not p:
            return self.base
        if p.startswith("?"):
            return self.base + p
        return self.base.rstrip("/") + "/" + p.lstrip("/")

    def esegui(self, nome: str, percorso: Any, metodo: str, parametri: Any = None, corpo: bytes | None = None,
               tipo: str | None = None, intestazioni: Any = None, flusso: bool = False):
        url = self.url(percorso, nome)
        parti = _rete._indirizzo(url, nome)
        parametri = _rete._richiedi_dizionario(parametri, nome, "parametri")
        intestazioni = _rete._richiedi_dizionario(intestazioni, nome, "intestazioni")
        if parametri:
            url += ("&" if parti.query else "?") + _rete._query(parametri)
        testate = dict(self.intestazioni)
        if tipo:
            testate["Content-Type"] = tipo
        for k, v in (intestazioni or {}).items():
            testate[str(k)] = rete._latino(v)
        locale = _rete._host(parti) in _rete._HOST_LOCALI
        tentativo = 0
        while True:
            richiesta = urllib.request.Request(url, data=corpo, headers=testate, method=metodo)
            if self.autorizzazione:
                # non ripetuta se il sito rimanda a un altro indirizzo: il segreto resta qui
                richiesta.add_unredirected_header("Authorization", self.autorizzazione)
            try:
                risposta = self._aperture[locale].open(richiesta, timeout=self.tempo)
            except urllib.error.HTTPError as e:
                risposta = e
            except (urllib.error.URLError, OSError) as e:
                motivo = e.reason if isinstance(e, urllib.error.URLError) else e
                if (tentativo + 1 < self.tentativi and metodo in _IDEMPOTENTI
                        and not isinstance(motivo, (socket.gaierror, ValueError))
                        and not type(motivo).__name__.startswith("SSLCert")):
                    self._aspetta(tentativo, None)
                    tentativo += 1
                    continue
                raise _rete._errore_rete(e, parti, self.tempo) from None
            except ValueError as e:
                raise ErroreValore(f"Indirizzo non valido: {mostra(url)} ({e}).") from None
            stato = _rete._stato(risposta)
            riprova = stato in (429, 503) or (stato in (502, 504) and metodo in _IDEMPOTENTI)
            if riprova and tentativo + 1 < self.tentativi:
                attesa = risposta.headers.get("Retry-After", "") if risposta.headers else ""
                with risposta:
                    pass
                self._aspetta(tentativo, attesa)
                tentativo += 1
                continue
            if flusso:
                return stato, risposta, parti, url
            contenuto = _rete._leggi_tutto(risposta, parti, self.tempo)
            finale = getattr(risposta, "url", None) or url
            risultato = _rete._risposta(stato, contenuto, risposta.headers, finale)
            risultato["metodo"] = metodo
            self.ultima = risultato
            return risultato

    def _aspetta(self, tentativo: int, retry_after: str | None) -> None:
        attesa = self.ATTESA_BASE * (2 ** tentativo)
        if retry_after and retry_after.strip().isdigit():
            attesa = float(retry_after.strip())
        time.sleep(min(max(attesa, 0.0), self.ATTESA_MASSIMA))

    def dati(self, nome: str, risultato: dict) -> Any:
        if not risultato["riuscita"]:
            suggerimento = "Per leggere anche le risposte di errore usa `sessione.richiesta(...)`: ti dà lo `stato`."
            if risultato["stato"] == 401:
                suggerimento = "Controlla il token o la password: `sessione_web(indirizzo, token = \"...\")`."
            dettaglio = ""
            if isinstance(risultato["json"], dict):
                for chiave in ("errore", "error", "messaggio", "message", "detail"):
                    if isinstance(risultato["json"].get(chiave), str):
                        dettaglio = f" Il server dice: {mostra(risultato['json'][chiave])}."
                        break
            raise ErroreFile(f"`{nome}` di {mostra(risultato['indirizzo'])} non è riuscita. "
                             f"{risultato['spiegazione']}.{dettaglio}", suggerimento=suggerimento)
        if risultato["json"] is not None:
            return risultato["json"]
        if risultato["testo"].strip() == "null":
            return None
        return risultato["testo"]


def _corpo(dati: Any, nome: str) -> tuple[bytes | None, str | None]:
    """Dati Leo -> corpo della richiesta: dizionari, liste, numeri e logici come JSON, testi come testo."""
    if dati is None:
        return None, None
    if isinstance(dati, str):
        return dati.encode("utf-8"), "text/plain; charset=utf-8"
    if isinstance(dati, (dict, list, int, float, bool)):
        try:
            return (_json.dumps(dati, ensure_ascii=False, allow_nan=False).encode("utf-8"),
                    "application/json; charset=utf-8")
        except (TypeError, ValueError):
            raise ErroreTipo(f"`{nome}`: questi dati non si possono inviare come JSON: {mostra(dati)}.",
                             suggerimento="Usa solo dizionari, liste, testi, numeri, logici e `nulla`.") from None
    raise ErroreTipo(f"`{nome}` può inviare un dizionario, una lista, un testo o un numero, non {articolo(dati)}.")


def _numero_positivo(valore: Any, nome: str, parametro: str, intero: bool = False) -> Any:
    if isinstance(valore, bool) or not isinstance(valore, (int, float)) or valore != valore \
            or valore in (float("inf"), float("-inf")) or (intero and not isinstance(valore, int)):
        raise ErroreTipo(f"`{parametro}` di `{nome}` deve essere un numero {'intero ' if intero else ''}"
                         f"maggiore di zero, non {articolo(valore)}.")
    if valore <= 0:
        raise ErroreValore(f"`{parametro}` di `{nome}` deve essere maggiore di zero, non {mostra(valore)}.")
    return valore


@funzione_libreria("sessione_web")
def sessione_web(indirizzo_base=None, intestazioni=None, token=None, utente=None, password=None,
                 tempo_massimo=15, tentativi=3):
    """sessione_web(indirizzo_base = nulla, intestazioni = nulla, token = nulla, utente = nulla, password = nulla, tempo_massimo = 15, tentativi = 3): prepara una serie di richieste allo stesso sito o alla stessa API.

    La sessione ricorda i cookie (come un browser), manda a ogni richiesta le `intestazioni`,
    il `token` ("Bearer ...") oppure `utente` e `password`, aspetta al massimo `tempo_massimo`
    secondi e, se il sito è occupato o la rete cade, riprova fino a `tentativi` volte.
    Poi: `prendi`, `invia`, `aggiorna`, `modifica`, `cancella`, `invia_modulo`, `scarica`,
    `pagina`, `richiesta`. I percorsi si aggiungono all'indirizzo base.
    Esempio: `variabile api = sessione_web("https://api.esempio.it/v1", token = "abc")` e poi
    `variabile utenti = api.prendi("utenti")`.
    """
    base = ""
    if indirizzo_base is not None:
        _rete._indirizzo(indirizzo_base, "sessione_web")
        base = indirizzo_base.strip()
    intestazioni = _rete._richiedi_dizionario(intestazioni, "sessione_web", "intestazioni") or {}
    tempo = _tempo(tempo_massimo, "sessione_web")
    _numero_positivo(tentativi, "sessione_web", "tentativi", intero=True)
    testate = {"User-Agent": _rete.AGENTE, "Accept": "application/json, text/html;q=0.9, */*;q=0.8"}
    for k, v in intestazioni.items():
        testate[str(k)] = rete._latino(v)
    s = SessioneWeb(base, testate, tempo, min(tentativi, 10))
    if token is not None:
        richiedi_testo(token, "sessione_web", "token")
        s.autorizzazione = _autorizzazione_token(token)
    if utente is not None or password is not None:
        if token is not None:
            raise ErroreValore("`sessione_web`: usa `token` oppure `utente` e `password`, non tutti e due.")
        if utente is None or password is None:
            raise ErroreValore("`sessione_web`: servono sia `utente` sia `password`.")
        richiedi_testo(utente, "sessione_web", "utente")
        richiedi_testo(password, "sessione_web", "password")
        import base64
        s.autorizzazione = "Basic " + base64.b64encode(f"{utente}:{password}".encode("utf-8")).decode("ascii")
    return s


def _autorizzazione_token(token: str) -> str:
    t = token.strip()
    if any(c in t for c in "\r\n"):
        raise ErroreValore("Il token non può contenere a capo.")
    if t.lower().startswith(("bearer ", "token ", "basic ")):
        return rete._latino(t)
    return "Bearer " + rete._latino(t)


proprieta(SessioneWeb, "indirizzo_base")(lambda s: s.base)
proprieta(SessioneWeb, "cookie")(lambda s: {c.name: c.value for c in s.cookie})
proprieta(SessioneWeb, "intestazioni")(lambda s: dict(s.intestazioni))
proprieta(SessioneWeb, "ultima_risposta")(lambda s: dict(s.ultima) if s.ultima is not None else None)


@metodo_oggetto(SessioneWeb, "richiesta")
def sessione_richiesta(s, percorso=None, metodo="GET", parametri=None, dati=None, intestazioni=None):
    """sessione.richiesta(percorso, metodo = "GET", parametri = nulla, dati = nulla, intestazioni = nulla): una richiesta completa che non si ferma mai per un codice di errore.

    Restituisce un dizionario come `richiesta_web`: `stato`, `riuscita`, `spiegazione`, `testo`,
    `json`, `intestazioni`, `indirizzo`. `dati`: un dizionario o una lista vanno come JSON.
    Esempio: `variabile r = api.richiesta("utenti/7", metodo = "DELETE")` e poi `stampa(r["stato"])`.
    """
    richiedi_testo(metodo, "richiesta", "metodo")
    m = metodo.strip().upper()
    if m not in rete.METODI:
        raise ErroreValore(f"Il metodo {mostra(metodo)} non esiste.",
                           suggerimento="Usa \"GET\", \"POST\", \"PUT\", \"PATCH\" o \"DELETE\".")
    corpo, tipo = _corpo(dati, "richiesta")
    return s.esegui("richiesta", percorso, m, parametri, corpo, tipo, intestazioni)


@metodo_oggetto(SessioneWeb, "prendi")
def sessione_prendi(s, percorso=None, parametri=None):
    """sessione.prendi(percorso = "", parametri = nulla): legge una risorsa (GET) e restituisce i dati (JSON già trasformato, o il testo).

    Se il sito risponde con un errore ricevi un `ErroreFile` che lo spiega.
    Esempio: `variabile libri = api.prendi("libri", parametri = {"autore": "Collodi"})`.
    """
    return s.dati("prendi", s.esegui("prendi", percorso, "GET", parametri))


def _con_corpo(nome: str, metodo: str):
    def f(s, percorso=None, dati=None, parametri=None):
        corpo, tipo = _corpo(dati, nome)
        return s.dati(nome, s.esegui(nome, percorso, metodo, parametri, corpo, tipo))
    return f


_invia = _con_corpo("invia", "POST")
_aggiorna = _con_corpo("aggiorna", "PUT")
_modifica = _con_corpo("modifica", "PATCH")


@metodo_oggetto(SessioneWeb, "invia")
def sessione_invia(s, percorso=None, dati=None, parametri=None):
    """sessione.invia(percorso, dati = nulla, parametri = nulla): crea una risorsa (POST); dizionari e liste vanno come JSON.

    Restituisce la risposta del sito (JSON già trasformato, o il testo).
    Esempio: `variabile nuovo = api.invia("libri", {"titolo": "Pinocchio", "anno": 1883})`.
    """
    return _invia(s, percorso, dati, parametri)


@metodo_oggetto(SessioneWeb, "aggiorna")
def sessione_aggiorna(s, percorso=None, dati=None, parametri=None):
    """sessione.aggiorna(percorso, dati = nulla, parametri = nulla): sostituisce una risorsa (PUT) con i nuovi dati.

    Esempio: `api.aggiorna("libri/3", {"titolo": "Pinocchio", "anno": 1883})`.
    """
    return _aggiorna(s, percorso, dati, parametri)


@metodo_oggetto(SessioneWeb, "modifica")
def sessione_modifica(s, percorso=None, dati=None, parametri=None):
    """sessione.modifica(percorso, dati = nulla, parametri = nulla): cambia solo alcuni campi di una risorsa (PATCH).

    Esempio: `api.modifica("libri/3", {"letto": vero})`.
    """
    return _modifica(s, percorso, dati, parametri)


@metodo_oggetto(SessioneWeb, "cancella")
def sessione_cancella(s, percorso=None, parametri=None):
    """sessione.cancella(percorso, parametri = nulla): elimina una risorsa (DELETE) e restituisce la risposta del sito.

    Esempio: `api.cancella("libri/3")`.
    """
    return s.dati("cancella", s.esegui("cancella", percorso, "DELETE", parametri))


def _multipart(campi: dict, file: dict, nome: str) -> tuple[bytes, str]:
    confine = "----LeoConfine" + uuid.uuid4().hex
    pezzi: list[bytes] = []

    def nome_sicuro(n: str) -> str:
        return str(n).replace("\\", "\\\\").replace('"', '\\"').replace("\r", " ").replace("\n", " ")

    for k, v in campi.items():
        valori = v if isinstance(v, list) else [v]
        for x in valori:
            pezzi.append(f'--{confine}\r\nContent-Disposition: form-data; name="{nome_sicuro(k)}"\r\n\r\n'
                         .encode("utf-8") + _rete._testo_semplice(x).encode("utf-8") + b"\r\n")
    for k, percorso in file.items():
        richiedi_testo(percorso, nome, "file")
        _controlla_percorso(percorso, nome)
        try:
            with open(percorso, "rb") as f:
                contenuto = f.read()
        except OSError as e:
            raise _errore_file(e, percorso, "leggere") from None
        nome_file = os.path.basename(percorso)
        tipo = mimetypes.guess_type(nome_file)[0] or "application/octet-stream"
        pezzi.append(f'--{confine}\r\nContent-Disposition: form-data; name="{nome_sicuro(k)}"; '
                     f'filename="{nome_sicuro(nome_file)}"\r\nContent-Type: {tipo}\r\n\r\n'.encode("utf-8")
                     + contenuto + b"\r\n")
    pezzi.append(f"--{confine}--\r\n".encode("ascii"))
    return b"".join(pezzi), f"multipart/form-data; boundary={confine}"


@metodo_oggetto(SessioneWeb, "invia_modulo")
def sessione_invia_modulo(s, percorso=None, campi=None, file=None):
    """sessione.invia_modulo(percorso, campi = nulla, file = nulla): invia un modulo web (POST), anche con dei file da caricare.

    `campi` è un dizionario nome -> valore; `file` un dizionario nome del campo -> percorso del
    file sul computer (oppure solo il percorso: il campo si chiama "file").
    Esempio: `sito.invia_modulo("carica", {"titolo": "Gita"}, file = {"foto": "gita.jpg"})`.
    """
    campi = _rete._richiedi_dizionario(campi, "invia_modulo", "campi") or {}
    if isinstance(file, str):
        file = {"file": file}
    file = _rete._richiedi_dizionario(file, "invia_modulo", "file") or {}
    if file:
        corpo, tipo = _multipart(campi, file, "invia_modulo")
    else:
        corpo, tipo = _rete._query(campi).encode("utf-8"), "application/x-www-form-urlencoded; charset=utf-8"
    return s.dati("invia_modulo", s.esegui("invia_modulo", percorso, "POST", None, corpo, tipo))


@metodo_oggetto(SessioneWeb, "pagina")
def sessione_pagina(s, percorso=None, parametri=None):
    """sessione.pagina(percorso = "", parametri = nulla): scarica una pagina (con i cookie della sessione) come `pagina_html`.

    Esempio: `variabile p = sito.pagina("notizie")` e poi `stampa(p.titolo)`.
    """
    risultato = s.esegui("pagina", percorso, "GET", parametri)
    if not risultato["riuscita"]:
        s.dati("pagina", risultato)
    return PaginaHtml(risultato["testo"], risultato["indirizzo"])


@metodo_oggetto(SessioneWeb, "imposta_intestazione")
def sessione_imposta_intestazione(s, nome, valore=None):
    """sessione.imposta_intestazione(nome, valore): aggiunge o cambia un'intestazione per tutte le richieste successive (`nulla` la toglie).

    Esempio: `api.imposta_intestazione("Accept-Language", "it")`.
    """
    richiedi_testo(nome, "imposta_intestazione", "nome")
    n = nome.strip()
    if not n or not re.fullmatch(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+", n):
        raise ErroreValore(f"{mostra(nome)} non è un nome di intestazione valido.",
                           suggerimento="Esempi: \"Accept-Language\", \"X-Api-Key\".")
    if n.lower() == "authorization":
        s.autorizzazione = None if valore is None else rete._latino(_rete._testo_semplice(valore))
        return None
    if valore is None:
        for k in [k for k in s.intestazioni if k.lower() == n.lower()]:
            del s.intestazioni[k]
    else:
        s.intestazioni[n] = rete._latino(_rete._testo_semplice(valore))
    return None


@metodo_oggetto(SessioneWeb, "scarica", interprete=True)
def sessione_scarica(interprete, s, percorso=None, file=None, avanzamento=False):
    """sessione.scarica(percorso, file = nulla, avanzamento = falso): salva su disco un file preso dal sito (con i cookie e l'accesso della sessione).

    Con `avanzamento = vero` scrive la percentuale; puoi anche passare una funzione
    `(scaricati, totale)`. Il file compare solo quando è completo. Restituisce il percorso.
    Esempio: `api.scarica("rapporti/2024.pdf", "rapporto.pdf", avanzamento = vero)`.
    """
    if not (isinstance(avanzamento, bool) or isinstance(avanzamento, Richiamabile)):
        raise ErroreTipo(f"`avanzamento` di `scarica` deve essere `vero`, `falso` o una funzione, "
                         f"non {articolo(avanzamento)}.")
    url = s.url(percorso, "scarica")
    parti = _rete._indirizzo(url, "scarica")
    if file is None:
        file = _rete._nome_da_indirizzo(parti)
    _controlla_percorso(file, "scarica")
    if os.path.isdir(file):
        file = os.path.join(file, _rete._nome_da_indirizzo(parti))
    stato, risposta, parti, url = s.esegui("scarica", percorso, "GET", flusso=True)
    if not 200 <= stato < 300:
        with risposta:
            pass
        raise ErroreFile(f"Non posso scaricare {mostra(url)}. {_rete.spiega_stato_http(stato)}.")
    lunghezza = risposta.headers.get("Content-Length") if risposta.headers else None
    totale = int(lunghezza) if lunghezza and lunghezza.isdigit() else None
    try:
        descrittore, provvisorio = tempfile.mkstemp(prefix=".scaricamento-", dir=os.path.dirname(os.path.abspath(file)))
    except OSError as e:
        with risposta:
            pass
        raise _errore_file(e, file, "scrivere") from None
    scaricati, ultimo = 0, -1

    def segnala() -> None:
        nonlocal ultimo
        if avanzamento is False:
            return
        if isinstance(avanzamento, Richiamabile):
            interprete.chiama(avanzamento, [scaricati, totale])
        elif totale:
            quarto = min(4, scaricati * 4 // totale)
            if quarto > ultimo:
                ultimo = quarto
                interprete.scrivi(f"Scaricamento: {quarto * 25}% ({_rete._misura(scaricati)} di "
                                  f"{_rete._misura(totale)})\n")

    try:
        with os.fdopen(descrittore, "wb") as f, risposta:
            segnala()
            while True:
                try:
                    blocco = risposta.read(64 * 1024)
                except (OSError, urllib.error.URLError) as e:
                    raise _rete._errore_rete(e, parti, s.tempo) from None
                if not blocco:
                    break
                f.write(blocco)
                scaricati += len(blocco)
                segnala()
        if totale is not None and scaricati < totale:
            raise ErroreFile(f"Lo scaricamento di {mostra(url)} si è interrotto a metà.", suggerimento="Riprova.")
        if avanzamento is True and not totale:
            interprete.scrivi(f"Scaricamento completato: {_rete._misura(scaricati)}\n")
        os.replace(provvisorio, file)
    except BaseException as e:
        try:
            os.unlink(provvisorio)
        except OSError:
            pass
        if isinstance(e, OSError) and not isinstance(e, ErroreDante):
            raise _errore_file(e, file, "scrivere") from None
        raise
    return file


# ===========================================================================
# robots.txt
# ===========================================================================

_ROBOTS: dict[str, tuple[float, Any]] = {}
_ROBOTS_DURATA = 600.0
_ROBOTS_BLOCCO = threading.Lock()


def _regole_robots(parti: urllib.parse.SplitResult, tempo: float) -> Any:
    """``RobotFileParser`` del sito, oppure ``True`` (tutto permesso) / ``False`` (niente)."""
    chiave = f"{parti.scheme.lower()}://{parti.netloc.lower()}"
    with _ROBOTS_BLOCCO:
        in_memoria = _ROBOTS.get(chiave)
        if in_memoria is not None and time.monotonic() - in_memoria[0] < _ROBOTS_DURATA:
            return in_memoria[1]
    url = chiave + "/robots.txt"
    try:
        risposta = _rete._apri(parti, url, "GET", None, {"User-Agent": _rete.AGENTE}, tempo)
        stato = _rete._stato(risposta)
        contenuto = _rete._leggi_tutto(risposta, parti, tempo)[:512 * 1024]
    except ErroreFile:
        regole: Any = False   # sito irraggiungibile: per prudenza niente
    else:
        if 200 <= stato < 300:
            regole = urllib.robotparser.RobotFileParser()
            regole.parse(contenuto.decode("utf-8", errors="replace").splitlines())
        elif 400 <= stato < 500:
            regole = True     # nessun robots.txt: tutto permesso (RFC 9309)
        else:
            regole = False    # errore del server: per prudenza niente
    with _ROBOTS_BLOCCO:
        _ROBOTS[chiave] = (time.monotonic(), regole)
    return regole


@funzione_libreria("robots_consente")
def robots_consente(indirizzo, agente="Leo", tempo_massimo=10):
    """robots_consente(indirizzo, agente = "Leo", tempo_massimo = 10): `vero` se il file robots.txt del sito permette ai programmi di leggere quell'indirizzo.

    Un programma che legge tante pagine di un sito (un "ragno") deve chiederlo prima: è la
    buona educazione del web. Se il sito non ha robots.txt è tutto permesso; se non risponde,
    per prudenza no. La risposta resta in memoria 10 minuti.
    Esempio: `se robots_consente("https://www.esempio.it/notizie") allora stampa("posso scaricare") fine`.
    """
    parti = _rete._indirizzo(indirizzo, "robots_consente")
    richiedi_testo(agente, "robots_consente", "agente")
    tempo = _tempo(tempo_massimo, "robots_consente")
    regole = _regole_robots(parti, tempo)
    if isinstance(regole, bool):
        return regole
    return bool(regole.can_fetch(agente.strip() or "*", indirizzo.strip()))


# ===========================================================================
# Feed RSS e Atom
# ===========================================================================

_ATOM = "{http://www.w3.org/2005/Atom}"
_RSS1 = "{http://purl.org/rss/1.0/}"
_DC = "{http://purl.org/dc/elements/1.1/}"
_CONTENT = "{http://purl.org/rss/1.0/modules/content/}"


def _nome_locale(tag: Any) -> str:
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


def _figlio(el: Any, *nomi: str) -> Any:
    for n in nomi:
        trovato = el.find(n)
        if trovato is not None:
            return trovato
    return None


def _testo_xml(el: Any) -> str:
    if el is None:
        return ""
    return "".join(el.itertext()).strip()


def _pulisci(testo: str) -> str:
    if "<" in testo or "&" in testo:
        return _testo_formattato(_albero(testo))
    return testo.strip()


def _collegamento_atom(el: Any) -> str:
    migliore = ""
    for link in el.findall(_ATOM + "link"):
        rel = link.get("rel", "alternate")
        if rel == "alternate" and link.get("href"):
            return link.get("href")
        if not migliore and link.get("href"):
            migliore = link.get("href")
    return migliore


@funzione_libreria("leggi_feed")
def leggi_feed(sorgente, tempo_massimo=15):
    """leggi_feed(sorgente, tempo_massimo = 15): legge un feed di notizie RSS o Atom (da un indirizzo o da un testo XML).

    Restituisce un dizionario con `titolo`, `collegamento`, `descrizione` e `notizie`: una lista
    di dizionari con `titolo`, `collegamento`, `data`, `descrizione` (testo senza tag), `autore`, `id`.
    Esempio: `per ogni n in leggi_feed("https://www.esempio.it/rss")["notizie"] fai stampa(n["titolo"]) fine`.
    """
    richiedi_testo(sorgente, "leggi_feed", "sorgente")
    testo = sorgente.strip()
    if testo.lower().startswith(("http://", "https://")) and "\n" not in testo and "<" not in testo:
        testo = _rete._pagina("leggi_feed", testo, _tempo(tempo_massimo, "leggi_feed"))["testo"]
    if len(testo) > _HTML_MASSIMO:
        raise ErroreValore("Il feed è troppo grande (più di 20 MB).")
    if "<!ENTITY" in testo.upper():
        raise ErroreValore("Il feed contiene definizioni di entità XML (`<!ENTITY`): per sicurezza non lo leggo.")
    import xml.etree.ElementTree as ET
    try:
        radice = ET.fromstring(testo.lstrip("\ufeff"))
    except ET.ParseError as e:
        raise ErroreValore(f"Questo non è un feed XML valido ({e}).",
                           suggerimento="Controlla l'indirizzo: forse è una pagina HTML e non il feed "
                                        "(di solito finisce con /rss, /feed o .xml).") from None
    nome = _nome_locale(radice.tag).lower()
    notizie = []
    if nome == "feed":   # Atom
        for e in radice.findall(_ATOM + "entry"):
            autore = _figlio(e, _ATOM + "author")
            notizie.append({
                "titolo": _pulisci(_testo_xml(e.find(_ATOM + "title"))),
                "collegamento": _collegamento_atom(e),
                "data": _testo_xml(_figlio(e, _ATOM + "published", _ATOM + "updated")),
                "descrizione": _pulisci(_testo_xml(_figlio(e, _ATOM + "summary", _ATOM + "content"))),
                "autore": _testo_xml(autore.find(_ATOM + "name")) if autore is not None else "",
                "id": _testo_xml(e.find(_ATOM + "id")),
            })
        return {"titolo": _pulisci(_testo_xml(radice.find(_ATOM + "title"))),
                "collegamento": _collegamento_atom(radice),
                "descrizione": _pulisci(_testo_xml(radice.find(_ATOM + "subtitle"))),
                "notizie": notizie}
    if nome in ("rss", "rdf"):
        canale = radice.find("channel") if nome == "rss" else radice.find(_RSS1 + "channel")
        if nome == "rss":
            elementi = canale.findall("item") if canale is not None else []
            pre = ""
        else:
            elementi = radice.findall(_RSS1 + "item")
            pre = _RSS1
        for e in elementi:
            notizie.append({
                "titolo": _pulisci(_testo_xml(e.find(pre + "title"))),
                "collegamento": _testo_xml(e.find(pre + "link")),
                "data": _testo_xml(_figlio(e, "pubDate", _DC + "date")),
                "descrizione": _pulisci(_testo_xml(_figlio(e, pre + "description", _CONTENT + "encoded"))),
                "autore": _testo_xml(_figlio(e, "author", _DC + "creator")),
                "id": _testo_xml(e.find("guid")) or _testo_xml(e.find(pre + "link")),
            })
        c = canale if canale is not None else radice
        return {"titolo": _pulisci(_testo_xml(c.find(pre + "title"))),
                "collegamento": _testo_xml(c.find(pre + "link")),
                "descrizione": _pulisci(_testo_xml(c.find(pre + "description"))),
                "notizie": notizie}
    raise ErroreValore(f"Questo XML non è un feed RSS o Atom (comincia con `<{_nome_locale(radice.tag)}>`).")


# ===========================================================================
# Sito web: pagine, percorsi, file statici
# ===========================================================================

_TIPI_BREVI = {
    "html": "text/html; charset=utf-8", "testo": "text/plain; charset=utf-8", "json": "application/json; charset=utf-8",
    "css": "text/css; charset=utf-8", "js": "text/javascript; charset=utf-8", "javascript": "text/javascript; charset=utf-8",
    "xml": "application/xml; charset=utf-8", "csv": "text/csv; charset=utf-8", "svg": "image/svg+xml",
}


class RispostaWeb(OggettoLibreria):
    """Una risposta preparata per un sito: contenuto, stato e intestazioni."""

    NOME_TIPO_DANTE = "risposta_web"

    def __init__(self, stato: int, tipo: str, corpo: bytes, intestazioni: dict) -> None:
        self.stato = stato
        self.tipo = tipo
        self.corpo = corpo
        self.intestazioni = intestazioni

    def testo_dante(self) -> str:
        return f"<risposta_web {self.stato}>"


proprieta(RispostaWeb, "stato")(lambda r: r.stato)
proprieta(RispostaWeb, "tipo")(lambda r: r.tipo)
proprieta(RispostaWeb, "testo")(lambda r: r.corpo.decode("utf-8", errors="replace"))
proprieta(RispostaWeb, "intestazioni")(lambda r: dict(r.intestazioni))


def _contenuto(valore: Any, nome: str) -> tuple[str, bytes]:
    if isinstance(valore, str):
        html = valore.lstrip()[:1] == "<"
        return (_TIPI_BREVI["html"] if html else _TIPI_BREVI["testo"]), valore.encode("utf-8")
    if valore is None:
        return _TIPI_BREVI["testo"], b""
    if isinstance(valore, (dict, list, int, float, bool)):
        try:
            return _TIPI_BREVI["json"], _json.dumps(valore, ensure_ascii=False, allow_nan=False).encode("utf-8")
        except (TypeError, ValueError):
            raise ErroreTipo(f"`{nome}`: questo contenuto non si può inviare come JSON.",
                             suggerimento="Usa solo dizionari, liste, testi, numeri, logici e `nulla`.") from None
    raise ErroreTipo(f"`{nome}` può inviare un testo, un numero, una lista o un dizionario, non {articolo(valore)}.")


def _intestazioni_risposta(intestazioni: Any, nome: str) -> dict:
    intestazioni = _rete._richiedi_dizionario(intestazioni, nome, "intestazioni") or {}
    risultato = {}
    for k, v in intestazioni.items():
        chiave = str(k)
        if not re.fullmatch(r"[!#$%&'*+.^_`|~0-9A-Za-z-]+", chiave):
            raise ErroreValore(f"{mostra(chiave)} non è un nome di intestazione valido.")
        risultato[chiave] = rete._latino(_rete._testo_semplice(v))
    return risultato


@funzione_libreria("risposta_web")
def risposta_web(contenuto=None, stato=200, tipo=None, intestazioni=None):
    """risposta_web(contenuto = nulla, stato = 200, tipo = nulla, intestazioni = nulla): prepara la risposta di una pagina del `sito_web` con il codice di stato che vuoi.

    `tipo` può essere "html", "testo", "json", "css", "js", "xml", "csv" o un tipo MIME completo.
    Senza `tipo`: un testo che comincia con `<` è HTML, un dizionario o una lista sono JSON.
    Esempio: `funzione gestisci(r) restituisci risposta_web({"errore": "libro non trovato"}, stato = 404) fine`.
    """
    if isinstance(stato, bool) or not isinstance(stato, int) or not 100 <= stato <= 599:
        raise ErroreValore(f"`stato` di `risposta_web` deve essere un codice HTTP tra 100 e 599, non {mostra(stato)}.",
                           suggerimento="Esempi: 200 (tutto bene), 404 (non trovato), 400 (dati sbagliati).")
    tipo_mime, corpo = _contenuto(contenuto, "risposta_web")
    if tipo is not None:
        richiedi_testo(tipo, "risposta_web", "tipo")
        t = tipo.strip()
        if any(c in t for c in "\r\n") or not t:
            raise ErroreValore(f"Il tipo {mostra(tipo)} non è valido.", suggerimento="Esempi: \"html\", \"json\".")
        tipo_mime = _TIPI_BREVI.get(t.lower(), t)
    return RispostaWeb(stato, tipo_mime, corpo, _intestazioni_risposta(intestazioni, "risposta_web"))


@funzione_libreria("reindirizza")
def reindirizza(indirizzo, permanente=False):
    """reindirizza(indirizzo, permanente = falso): risposta del `sito_web` che manda il browser a un altro indirizzo.

    Esempio: dopo aver salvato un modulo, `funzione gestisci(r) restituisci reindirizza("/grazie") fine`.
    """
    richiedi_testo(indirizzo, "reindirizza", "indirizzo")
    if not isinstance(permanente, bool):
        raise ErroreTipo(f"`permanente` di `reindirizza` deve essere `vero` o `falso`, non {articolo(permanente)}.")
    destinazione = indirizzo.strip()
    if not destinazione or any(c in destinazione for c in "\r\n"):
        raise ErroreValore(f"{mostra(indirizzo)} non è un indirizzo valido per `reindirizza`.",
                           suggerimento="Esempi: \"/grazie\", \"https://www.esempio.it\".")
    corpo = f'<p>Vai a <a href="{_html.escape(destinazione)}">{_html.escape(destinazione)}</a></p>'
    return RispostaWeb(301 if permanente else 303, _TIPI_BREVI["html"], corpo.encode("utf-8"),
                       {"Location": rete._latino(destinazione)})


def _pagina_errore(stato: int, titolo: str, dettaglio: str) -> tuple[int, str, bytes, dict]:
    corpo = (f"<!doctype html><html lang=\"it\"><head><meta charset=\"utf-8\"><title>{stato} {_html.escape(titolo)}"
             f"</title></head><body style=\"font-family:sans-serif;margin:3em\"><h1>{_html.escape(titolo)}</h1>"
             f"<p>{_html.escape(dettaglio)}</p></body></html>")
    return stato, _TIPI_BREVI["html"], corpo.encode("utf-8"), {}


class _Rotta:
    def __init__(self, percorso: str, contenuto: Any, metodi: set[str]) -> None:
        self.percorso = percorso
        self.contenuto = contenuto
        self.metodi = metodi
        self.nomi: list[str] = []
        pezzi = []
        for i, parte in enumerate(re.split(r"(<[^<>/]+>)", percorso)):
            if i % 2:
                nome = parte[1:-1].strip()
                resto = nome.startswith("*")
                nome = nome.lstrip("*")
                self.nomi.append(nome)
                pezzi.append(f"(?P<{_nome_gruppo(len(self.nomi))}>{'.+' if resto else '[^/]+'})")
            else:
                pezzi.append(re.escape(parte))
        self.modello = re.compile("".join(pezzi) + "/?" if percorso != "/" else "/")

    def corrisponde(self, percorso: str) -> dict | None:
        m = self.modello.fullmatch(percorso)
        if m is None:
            return None
        return {nome: m.group(_nome_gruppo(i + 1)) for i, nome in enumerate(self.nomi)}


def _nome_gruppo(i: int) -> str:
    return f"p{i}"


class _LavoroSito:
    def __init__(self, funzione: Any, richiesta: dict) -> None:
        self.funzione = funzione
        self.richiesta = richiesta
        self.risposta: Any = None
        self.fatto = threading.Event()


class SitoWeb(OggettoLibreria):
    """Un piccolo sito: pagine fisse, pagine fatte da funzioni Leo, file statici."""

    NOME_TIPO_DANTE = "sito_web"
    SUGGERIMENTO_MODIFICA = "Per aggiungere una pagina usa `sito.pagina(percorso, contenuto)`."
    ATTESA_MASSIMA = 30.0
    CORPO_MASSIMO = 10 * 1024 * 1024

    def __init__(self, porta: int, host: str, titolo: str) -> None:
        self.porta_richiesta = porta
        self.host = host
        self.titolo = titolo
        self.rotte: list[_Rotta] = []
        self.statici: list[tuple[str, str]] = []
        self.servite = 0
        self._coda: queue.Queue[_LavoroSito] = queue.Queue()
        self._in_servizio = False
        self._stop = threading.Event()
        self._server: ThreadingHTTPServer | None = None
        self._blocco = threading.Lock()

    def testo_dante(self) -> str:
        return f"<sito_web {self.indirizzo or 'spento'}>"

    @property
    def indirizzo(self) -> str:
        if self._server is None:
            return ""
        host = "127.0.0.1" if self.host in ("", "0.0.0.0") else self.host
        return f"http://{host}:{self._server.server_address[1]}/"

    # -- thread del server ---------------------------------------------------------
    def gestisci(self, richiesta: dict) -> tuple[int, str, bytes, dict]:
        percorso = richiesta["percorso"]
        metodo = richiesta["metodo"]
        metodo_rotta = "GET" if metodo == "HEAD" else metodo
        permessi: set[str] = set()
        for rotta in list(self.rotte):
            valori = rotta.corrisponde(percorso)
            if valori is None:
                continue
            if metodo_rotta not in rotta.metodi and "*" not in rotta.metodi:
                permessi |= rotta.metodi
                continue
            self.servite += 1
            if isinstance(rotta.contenuto, Richiamabile):
                richiesta = dict(richiesta)
                richiesta["valori"] = valori
                parametri = dict(richiesta["parametri"])
                parametri.update(richiesta.get("modulo") or {})
                parametri.update(valori)
                richiesta["parametri"] = parametri
                return self._al_programma(rotta.contenuto, richiesta)
            return _in_risposta(rotta.contenuto, "pagina")
        if metodo_rotta == "GET":
            for prefisso, cartella in list(self.statici):
                risposta = _file_statico(prefisso, cartella, percorso)
                if risposta is not None:
                    self.servite += 1
                    return risposta
        if permessi:
            stato, tipo, corpo, extra = _pagina_errore(405, "Metodo non permesso",
                                                       f"Questa pagina accetta solo {', '.join(sorted(permessi))}.")
            extra["Allow"] = ", ".join(sorted(permessi | {"HEAD"} if "GET" in permessi else permessi))
            return stato, tipo, corpo, extra
        return _pagina_errore(404, "Pagina non trovata", f"La pagina {percorso} non esiste su questo sito.")

    def _al_programma(self, funzione: Any, richiesta: dict) -> tuple[int, str, bytes, dict]:
        if not self._in_servizio:
            return _pagina_errore(503, "Il programma non sta ascoltando",
                                  "Questa pagina è fatta da una funzione: il programma deve chiamare sito.servi().")
        lavoro = _LavoroSito(funzione, richiesta)
        self._coda.put(lavoro)
        if not lavoro.fatto.wait(self.ATTESA_MASSIMA):
            return _pagina_errore(503, "Nessuna risposta", "Il programma non ha risposto in tempo.")
        return lavoro.risposta

    # -- comandi ----------------------------------------------------------------------
    def avvia(self) -> None:
        with self._blocco:
            if self._server is not None:
                return
            gestore = type("GestoreSito", (_GestoreSito,), {"sito": self})
            try:
                server = ThreadingHTTPServer((self.host, self.porta_richiesta), gestore)
            except OSError as e:
                if getattr(e, "errno", None) in (98, 48, 10048) or "in use" in str(e).lower():
                    raise ErroreFile(f"La porta {self.porta_richiesta} è già in uso da un altro programma.",
                                     suggerimento="Scegli un'altra porta, per esempio 8081 (o 0 per una libera).") from None
                raise ErroreFile(f"Non riesco ad accendere il sito sulla porta {self.porta_richiesta} ({e}).",
                                 suggerimento="Prova un'altra porta (sopra 1024).") from None
            server.daemon_threads = True
            self._server = server
            threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.2},
                             name="Leo-SitoWeb", daemon=True).start()

    def ferma(self) -> None:
        self._stop.set()
        self._in_servizio = False
        with self._blocco:
            server, self._server = self._server, None
        if server is not None:
            server.shutdown()
            server.server_close()
        while True:
            try:
                lavoro = self._coda.get_nowait()
            except queue.Empty:
                break
            lavoro.risposta = _pagina_errore(503, "Sito spento", "Il sito si sta spegnendo.")
            lavoro.fatto.set()


def _in_risposta(valore: Any, nome: str) -> tuple[int, str, bytes, dict]:
    if isinstance(valore, RispostaWeb):
        return valore.stato, valore.tipo, valore.corpo, dict(valore.intestazioni)
    if isinstance(valore, PaginaHtml):
        return 200, _TIPI_BREVI["html"], valore.sorgente.encode("utf-8"), {}
    tipo, corpo = _contenuto(valore, nome)
    return 200, tipo, corpo, {}


def _file_statico(prefisso: str, cartella: str, percorso: str) -> tuple[int, str, bytes, dict] | None:
    if prefisso != "/" and not (percorso == prefisso or percorso.startswith(prefisso + "/")):
        return None
    resto = percorso[len(prefisso):] if prefisso != "/" else percorso
    parti = [p for p in posixpath.normpath("/" + resto).split("/") if p]
    if any(p.startswith(".") or "\\" in p or ":" in p or "\0" in p for p in parti):
        return None   # niente file nascosti, niente uscite dalla cartella
    reale_base = os.path.realpath(cartella)
    destinazione = os.path.realpath(os.path.join(reale_base, *parti))
    if os.path.commonpath([reale_base, destinazione]) != reale_base:
        return None
    if os.path.isdir(destinazione):
        destinazione = os.path.join(destinazione, "index.html")
    if not os.path.isfile(destinazione):
        return None
    try:
        with open(destinazione, "rb") as f:
            corpo = f.read()
    except OSError:
        return _pagina_errore(403, "Accesso negato", "Questo file non si può leggere.")
    tipo = mimetypes.guess_type(destinazione)[0] or "application/octet-stream"
    if tipo.startswith("text/") or tipo in ("application/javascript", "application/json"):
        tipo += "; charset=utf-8"
    return 200, tipo, corpo, {}


class _GestoreSito(BaseHTTPRequestHandler):
    server_version = "LeoSito/1.0"
    protocol_version = "HTTP/1.1"
    sito: SitoWeb

    def log_message(self, formato: str, *argomenti: Any) -> None:  # silenzioso
        pass

    def _gestisci(self) -> None:
        try:
            lunghezza = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            lunghezza = -1
        if lunghezza < 0 or lunghezza > self.sito.CORPO_MASSIMO:
            self._invia(*_pagina_errore(413, "Dati troppo grandi", "La richiesta supera i 10 MB."), chiudi=True)
            return
        grezzo = self.rfile.read(lunghezza) if lunghezza > 0 else b""
        parti = urllib.parse.urlsplit(self.path)
        corpo = rete._decodifica(grezzo, self.headers)
        tipo = self.headers.get("Content-Type", "")
        modulo = rete._parametri(corpo) if "application/x-www-form-urlencoded" in tipo.lower() else {}
        richiesta = {
            "percorso": urllib.parse.unquote(parti.path) or "/",
            "metodo": self.command,
            "parametri": rete._parametri(parti.query),
            "modulo": modulo,
            "corpo": corpo,
            "json": rete._prova_json(corpo, tipo),
            "intestazioni": rete._intestazioni_dict(self.headers),
            "cookie": _cookie_richiesta(self.headers.get("Cookie", "")),
            "cliente": self.client_address[0],
        }
        try:
            risposta = self.sito.gestisci(richiesta)
        except ErroreDante as e:
            risposta = _pagina_errore(500, "Errore nel programma", e.messaggio)
        except Exception as e:  # il sito non deve fermarsi per un imprevisto
            risposta = _pagina_errore(500, "Errore nel programma", str(e))
        self._invia(*risposta)

    def _invia(self, stato: int, tipo: str, corpo: bytes, extra: dict, chiudi: bool = False) -> None:
        self.send_response(stato)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(corpo)))
        self.send_header("X-Content-Type-Options", "nosniff")
        for chiave, valore in extra.items():
            self.send_header(chiave, valore)
        if chiudi:
            self.send_header("Connection", "close")
            self.close_connection = True
        self.end_headers()
        if self.command != "HEAD":
            self.wfile.write(corpo)

    do_GET = do_POST = do_PUT = do_DELETE = do_PATCH = do_HEAD = do_OPTIONS = _gestisci


def _cookie_richiesta(testo: str) -> dict:
    risultato = {}
    for pezzo in testo.split(";"):
        if "=" in pezzo:
            k, v = pezzo.split("=", 1)
            risultato[k.strip()] = urllib.parse.unquote(v.strip().strip('"'))
    return risultato


@funzione_libreria("sito_web")
def sito_web(porta=8080, titolo="Il mio sito", aperto_in_rete=False):
    """sito_web(porta = 8080, titolo = "Il mio sito", aperto_in_rete = falso): crea un piccolo sito web vero su questo computer.

    Poi: `sito.pagina(percorso, contenuto)` aggiunge una pagina (un testo HTML, un dizionario
    che diventa JSON, o una funzione che riceve la richiesta); `sito.file_statici(...)` serve una
    cartella (immagini, CSS); `sito.servi()` accende il sito e risponde. Il sito si apre solo da
    questo computer; con `aperto_in_rete = vero` anche dagli altri della stessa rete (Wi-Fi di casa).
    `porta = 0` sceglie una porta libera.
    Esempio: `variabile sito = sito_web(8080)` e poi `sito.pagina("/", "<h1>Benvenuti!</h1>")`.
    """
    porta = _rete._porta(porta, "sito_web")
    richiedi_testo(titolo, "sito_web", "titolo")
    if not isinstance(aperto_in_rete, bool):
        raise ErroreTipo(f"`aperto_in_rete` di `sito_web` deve essere `vero` o `falso`, non {articolo(aperto_in_rete)}.")
    return SitoWeb(porta, "0.0.0.0" if aperto_in_rete else "127.0.0.1", titolo.strip())


proprieta(SitoWeb, "indirizzo")(lambda s: s.indirizzo)
proprieta(SitoWeb, "porta")(lambda s: int(s._server.server_address[1]) if s._server is not None else s.porta_richiesta)
proprieta(SitoWeb, "attivo")(lambda s: s._server is not None)
proprieta(SitoWeb, "titolo")(lambda s: s.titolo)
proprieta(SitoWeb, "pagine")(lambda s: [r.percorso for r in s.rotte])
proprieta(SitoWeb, "richieste_servite")(lambda s: s.servite)


def _metodi_rotta(metodo: Any) -> set[str]:
    elenco = metodo if isinstance(metodo, list) else [metodo]
    if not elenco:
        raise ErroreValore("`metodo` di `pagina` è una lista vuota.")
    risultato = set()
    for m in elenco:
        richiedi_testo(m, "pagina", "metodo")
        mm = m.strip().upper()
        if mm in ("*", "TUTTI", "QUALSIASI"):
            risultato.add("*")
        elif mm in rete.METODI:
            risultato.add(mm)
        else:
            raise ErroreValore(f"Il metodo {mostra(m)} non esiste.",
                               suggerimento="Usa \"GET\" (leggere), \"POST\" (moduli), \"PUT\", \"PATCH\", "
                                            "\"DELETE\" o \"*\" (tutti).")
    return risultato


@metodo_oggetto(SitoWeb, "pagina")
def sito_pagina(s, percorso, contenuto, metodo="GET"):
    """sito.pagina(percorso, contenuto, metodo = "GET"): aggiunge una pagina al sito.

    `contenuto` può essere un testo (HTML se comincia con `<`), un dizionario o una lista
    (risposta JSON, per fare un'API), una `risposta_web` oppure una funzione che riceve la
    richiesta (`percorso`, `metodo`, `parametri`, `modulo`, `json`, `cookie`...) e restituisce il
    contenuto. Nel percorso le parti tra `<` e `>` sono variabili: con "/libri/<numero>" la
    funzione trova `richiesta["parametri"]["numero"]`. `metodo` può essere "POST" per i moduli.
    Esempio: `sito.pagina("/saluta/<nome>", funzione (r) restituisci "<h1>Ciao {r["parametri"]["nome"]}!</h1>" fine)`.
    """
    richiedi_testo(percorso, "pagina", "percorso")
    p = percorso.strip()
    if not p.startswith("/"):
        raise ErroreValore(f"Il percorso {mostra(percorso)} deve cominciare con \"/\".",
                           suggerimento=f"Scrivi \"/{p}\".")
    if not isinstance(contenuto, Richiamabile):
        _in_risposta(contenuto, "pagina")   # controlla subito che si possa inviare
    metodi = _metodi_rotta(metodo)
    nuova = _Rotta(p, contenuto, metodi)
    s.rotte = [r for r in s.rotte if not (r.percorso == p and r.metodi == metodi)] + [nuova]
    return None


@metodo_oggetto(SitoWeb, "file_statici")
def sito_file_statici(s, cartella, percorso="/"):
    """sito.file_statici(cartella, percorso = "/"): pubblica i file di una cartella del computer (immagini, CSS, pagine HTML già pronte).

    I file nascosti (che cominciano con il punto) e quelli fuori dalla cartella non si vedono mai.
    Esempio: `sito.file_statici("immagini", "/immagini")`: il file "immagini/gatto.png" si apre
    a "/immagini/gatto.png".
    """
    richiedi_testo(cartella, "file_statici", "cartella")
    richiedi_testo(percorso, "file_statici", "percorso")
    _controlla_percorso(cartella, "file_statici")
    if not os.path.isdir(cartella):
        raise ErroreFile(f"La cartella {mostra(cartella)} non esiste.",
                         suggerimento="Controlla il nome; la cartella si cerca a partire da quella del programma.")
    p = "/" + percorso.strip().strip("/")
    s.statici = [x for x in s.statici if x[0] != p] + [(p, os.path.abspath(cartella))]
    return None


@metodo_oggetto(SitoWeb, "avvia")
def sito_avvia(s):
    """sito.avvia(): accende il sito senza fermare il programma (servono subito le pagine fisse e i file).

    Le pagine fatte da una funzione rispondono solo mentre il programma è dentro `sito.servi()`.
    Esempio: `sito.avvia()` e poi `stampa("Apri", sito.indirizzo)`.
    """
    s.avvia()
    return None


@metodo_oggetto(SitoWeb, "ferma")
def sito_ferma(s):
    """sito.ferma(): spegne il sito (dentro una pagina fatta da una funzione, `servi` finisce dopo questa risposta).

    Esempio: `sito.pagina("/spegni", funzione (r) sito.ferma() fine)`.
    """
    s.ferma()
    return None


@metodo_oggetto(SitoWeb, "servi", interprete=True)
def sito_servi(interprete, s, richieste=None, secondi=None, apri_browser=False):
    """sito.servi(richieste = nulla, secondi = nulla, apri_browser = falso): accende il sito e risponde alle richieste finché non lo fermi.

    Si ferma dopo `richieste` richieste, dopo `secondi` secondi, con `sito.ferma()` o con Ctrl+C.
    Con `apri_browser = vero` apre la pagina nel browser. Restituisce quante richieste ha servito.
    Esempio: `sito.servi(apri_browser = vero)`.
    """
    for valore, parametro in ((richieste, "richieste"), (secondi, "secondi")):
        if valore is not None:
            _numero_positivo(valore, "servi", parametro, intero=parametro == "richieste")
    if not isinstance(apri_browser, bool):
        raise ErroreTipo(f"`apri_browser` di `servi` deve essere `vero` o `falso`, non {articolo(apri_browser)}.")
    if not s.rotte and not s.statici:
        raise ErroreValore("Il sito non ha ancora nessuna pagina.",
                           suggerimento="Aggiungine una prima di `servi`: `sito.pagina(\"/\", \"<h1>Ciao!</h1>\")`.")
    s._stop.clear()
    s.avvia()
    s._in_servizio = True
    if apri_browser:
        try:
            import webbrowser
            webbrowser.open(s.indirizzo)
        except Exception:
            interprete.scrivi(f"Apri nel browser: {s.indirizzo}\n")
    iniziali = s.servite
    fine_tempo = time.monotonic() + secondi if secondi is not None else None
    try:
        while not s._stop.is_set():
            if richieste is not None and s.servite - iniziali >= richieste:
                break
            if getattr(interprete, "_ferma_richiesta", False):
                break
            attesa = 0.1
            if fine_tempo is not None:
                rimasto = fine_tempo - time.monotonic()
                if rimasto <= 0:
                    break
                attesa = min(attesa, rimasto)
            try:
                lavoro = s._coda.get(timeout=attesa)
            except queue.Empty:
                continue
            try:
                lavoro.risposta = _esegui_funzione(interprete, lavoro)
            except ErroreDante as e:
                lavoro.risposta = _pagina_errore(500, "Errore nel programma", e.messaggio)
                raise
            except BaseException:
                lavoro.risposta = _pagina_errore(500, "Errore nel programma", "Il programma si è fermato.")
                raise
            finally:
                lavoro.fatto.set()
        # le ultime risposte partono prima di spegnere
        time.sleep(0.05)
    finally:
        s._in_servizio = False
    return s.servite - iniziali


def _esegui_funzione(interprete: Any, lavoro: _LavoroSito) -> tuple[int, str, bytes, dict]:
    corrente = _rete._CORRENTE
    precedente = getattr(corrente, "risposta", None), getattr(corrente, "attiva", False)
    corrente.risposta, corrente.attiva = None, True
    try:
        valore = interprete.chiama(lavoro.funzione, [lavoro.richiesta])
        preparata = corrente.risposta
    finally:
        corrente.risposta, corrente.attiva = precedente
    if preparata is not None:   # la funzione ha usato `rispondi(...)`
        stato, tipo, corpo, extra = rete._prepara_risposta(preparata)
        if "testo" in preparata and "tipo" not in preparata and str(preparata["testo"]).lstrip()[:1] == "<":
            tipo = _TIPI_BREVI["html"]
        return stato, tipo, corpo, extra
    if valore is None:
        return 204, _TIPI_BREVI["testo"], b"", {}
    return _in_risposta(valore, "pagina")


__all__ += ["analizza_html", "leggi_pagina_web", "html_in_testo", "proteggi_html", "tabella_in_html",
            "modello_html", "parti_url", "dominio_url", "parametri_url", "url_assoluto", "e_url", "sessione_web",
            "robots_consente", "leggi_feed", "risposta_web", "reindirizza", "sito_web"]
