"""Pubblicazione di un sito su GitHub Pages, dal codice Leo (per Leo Web).

`pubblica_su_github(cartella, repository, token)` prende una cartella di file (HTML, CSS, JS,
immagini: il sito che Leo ha creato), crea o aggiorna un repository su GitHub, ci carica i file e
accende **GitHub Pages**, poi restituisce l'indirizzo pubblico del sito.

Serve un **token personale** di GitHub (Settings -> Developer settings -> Personal access tokens),
con il permesso sui repository. Il token lo passa il programma: Leo non lo salva da nessuna parte.

Tutta la rete passa per una funzione sostituibile, così la logica si prova senza internet.
"""

from __future__ import annotations

import base64
import json
import os
from typing import Any, Callable

from ..errori import ErroreFile, ErroreValore
from .generali import funzione_libreria, richiedi_testo

API = "https://api.github.com"
#: cartelle/file da non caricare mai
_SALTA = {".git", ".github", "__pycache__", ".ds_store", "thumbs.db", ".gitignore"}


def _chiamata_reale(metodo: str, url: str, token: str, corpo: dict | None) -> tuple[int, dict]:  # pragma: no cover - rete
    import urllib.error
    import urllib.request

    dati = json.dumps(corpo).encode("utf-8") if corpo is not None else None
    richiesta = urllib.request.Request(url, data=dati, method=metodo, headers={
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "Leo-Web",
        "Content-Type": "application/json",
    })
    try:
        with urllib.request.urlopen(richiesta, timeout=30) as r:  # noqa: S310 (https, API fissa)
            testo = r.read().decode("utf-8") or "{}"
            return r.status, json.loads(testo)
    except urllib.error.HTTPError as e:
        try:
            corpo_err = json.loads(e.read().decode("utf-8") or "{}")
        except Exception:
            corpo_err = {}
        return e.code, corpo_err
    except urllib.error.URLError as e:
        raise ErroreValore("Non riesco a raggiungere GitHub.",
                           suggerimento="Controlla la connessione a internet.") from e


def _controlla_token(stato: int) -> None:
    if stato in (401, 403):
        raise ErroreValore("GitHub non accetta il token.",
                           suggerimento="Crea un token su github.com -> Settings -> Developer settings -> "
                           "Personal access tokens, con il permesso sui repository (Contents e Pages), e passalo a "
                           "`pubblica_su_github`.")


def _file_del_sito(cartella: str) -> list[tuple[str, str]]:
    """[(percorso_locale, percorso_remoto)] di tutti i file del sito, saltando .git e simili."""
    fuori: list[tuple[str, str]] = []
    radice = os.path.abspath(cartella)
    for base, cartelle, file in os.walk(radice):
        cartelle[:] = [c for c in cartelle if c.lower() not in _SALTA and not c.startswith(".")]
        for nome in file:
            if nome.lower() in _SALTA:
                continue
            locale = os.path.join(base, nome)
            remoto = os.path.relpath(locale, radice).replace(os.sep, "/")
            fuori.append((locale, remoto))
    return sorted(fuori, key=lambda x: x[1])


@funzione_libreria("pubblica_su_github", interprete=True)
def pubblica_su_github(interprete, cartella, repository, token, messaggio="Sito pubblicato con Leo",
                       privato=False, http=None):
    """pubblica_su_github(cartella, repository, token): carica il sito nella `cartella` su GitHub e
    accende GitHub Pages; restituisce l'indirizzo pubblico. `repository` è "nome" o "utente/nome";
    `token` è un token personale di GitHub. Esempio:
    `variabile sito = pubblica_su_github("MioSito", "mio-sito", "ghp_...")`.
    """
    cartella = richiedi_testo(cartella, "pubblica_su_github", "cartella")
    repository = richiedi_testo(repository, "pubblica_su_github", "repository").strip()
    token = richiedi_testo(token, "pubblica_su_github", "token").strip()
    messaggio = richiedi_testo(messaggio, "pubblica_su_github", "messaggio") if messaggio != "Sito pubblicato con Leo" else "Sito pubblicato con Leo"
    if not os.path.isdir(cartella):
        raise ErroreFile(f"La cartella del sito `{cartella}` non esiste.")
    if not repository:
        raise ErroreValore("Devi dire il nome del repository (per esempio \"mio-sito\").")
    if not token:
        raise ErroreValore("Serve un token personale di GitHub.",
                           suggerimento="github.com -> Settings -> Developer settings -> Personal access tokens.")

    chiama: Callable[[str, str, str, dict | None], tuple[int, dict]] = http if callable(http) else _chiamata_reale

    # 1) chi sono (e validazione del token)
    stato, io = chiama("GET", f"{API}/user", token, None)
    _controlla_token(stato)
    if stato != 200 or "login" not in io:
        raise ErroreValore("GitHub non mi ha detto chi sei: token non valido.")
    utente = io["login"]
    if "/" in repository:
        proprietario, nome = repository.split("/", 1)
    else:
        proprietario, nome = utente, repository
    nome = nome.strip("/")

    # 2) il repository esiste? altrimenti crealo
    stato, _ = chiama("GET", f"{API}/repos/{proprietario}/{nome}", token, None)
    if stato == 404:
        stato, risp = chiama("POST", f"{API}/user/repos", token,
                             {"name": nome, "private": bool(privato), "auto_init": True,
                              "description": "Sito creato con Leo"})
        _controlla_token(stato)
        if stato not in (200, 201):
            raise ErroreValore(f"Non riesco a creare il repository `{nome}`: {risp.get('message', 'errore')}.")
    elif stato != 200:
        _controlla_token(stato)
        raise ErroreValore(f"Non riesco a leggere il repository `{proprietario}/{nome}`.")

    # 3) carica i file (crea o aggiorna)
    file = _file_del_sito(cartella)
    if not file:
        raise ErroreValore(f"Nella cartella `{cartella}` non ci sono file da pubblicare.")
    caricati = 0
    for locale, remoto in file:
        with open(locale, "rb") as f:
            contenuto = base64.b64encode(f.read()).decode("ascii")
        url = f"{API}/repos/{proprietario}/{nome}/contents/{remoto}"
        stato_g, esistente = chiama("GET", url, token, None)
        corpo: dict[str, Any] = {"message": messaggio, "content": contenuto}
        if stato_g == 200 and isinstance(esistente, dict) and esistente.get("sha"):
            corpo["sha"] = esistente["sha"]
        stato_p, risp = chiama("PUT", url, token, corpo)
        _controlla_token(stato_p)
        if stato_p not in (200, 201):
            raise ErroreValore(f"Non riesco a caricare `{remoto}`: {risp.get('message', 'errore')}.")
        caricati += 1

    # 4) accendi GitHub Pages (dal ramo main)
    url_pages = f"{API}/repos/{proprietario}/{nome}/pages"
    stato_pg, _ = chiama("GET", url_pages, token, None)
    if stato_pg == 404:
        chiama("POST", url_pages, token, {"source": {"branch": "main", "path": "/"}})

    indirizzo = f"https://{proprietario}.github.io/{nome}/"
    return {"indirizzo": indirizzo, "repository": f"{proprietario}/{nome}",
            "file_caricati": caricati, "pronto_tra_minuti": 2}


@funzione_libreria("guida_token_github")
def guida_token_github():
    """guida_token_github(): le istruzioni, passo per passo, per creare il token di GitHub che serve
    a `pubblica_su_github`. Restituisce un testo da mostrare all'utente."""
    return (
        "Per pubblicare il sito su GitHub ti serve un token personale (una sola volta):\n"
        "1. Vai su github.com e accedi (se non hai un account, crealo: è gratis).\n"
        "2. In alto a destra: la tua foto -> Settings.\n"
        "3. In fondo a sinistra: Developer settings -> Personal access tokens -> Tokens (classic).\n"
        "4. Generate new token (classic). Dagli un nome (es. \"Leo\") e spunta il permesso \"repo\".\n"
        "5. Generate token, poi COPIA il codice (inizia con ghp_...): si vede una volta sola.\n"
        "6. Incolla quel codice in `pubblica_su_github(... , token)`.\n"
        "Il token resta sul tuo computer: Leo non lo salva e non lo manda a nessuno tranne GitHub."
    )


@funzione_libreria("genera_sitemap")
def genera_sitemap(cartella, indirizzo):
    """genera_sitemap(cartella, indirizzo): crea il file sitemap.xml di un sito (elenco delle pagine .html)
    e lo salva nella cartella. `indirizzo` è l'indirizzo pubblico (es. "https://miosito.it/").
    Restituisce il numero di pagine. Esempio: `genera_sitemap("MioSito", "https://miosito.it/")`.
    """
    import os
    cartella = richiedi_testo(cartella, "genera_sitemap", "cartella")
    indirizzo = richiedi_testo(indirizzo, "genera_sitemap", "indirizzo").strip()
    if not os.path.isdir(cartella):
        raise ErroreFile(f"La cartella `{cartella}` non esiste.")
    if not indirizzo.startswith("http"):
        raise ErroreValore("L'indirizzo deve iniziare con http:// o https://.")
    base = indirizzo.rstrip("/") + "/"
    pagine = []
    for cartella_base, _c, file in os.walk(cartella):
        for nome in sorted(file):
            if nome.lower().endswith(".html") and not nome.startswith("_"):
                rel = os.path.relpath(os.path.join(cartella_base, nome), cartella).replace(os.sep, "/")
                pagine.append(base + ("" if rel == "index.html" else rel))
    righe = ['<?xml version="1.0" encoding="UTF-8"?>',
             '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">']
    for u in sorted(set(pagine)):
        righe.append(f"  <url><loc>{u}</loc></url>")
    righe.append("</urlset>")
    with open(os.path.join(cartella, "sitemap.xml"), "w", encoding="utf-8") as f:
        f.write("\n".join(righe) + "\n")
    return len(pagine)


@funzione_libreria("controlla_collegamenti")
def controlla_collegamenti(cartella):
    """controlla_collegamenti(cartella): controlla un sito in locale e trova i collegamenti interni rotti
    (href/src verso file che non esistono). Restituisce la lista dei problemi {"pagina", "collegamento"}.
    Esempio: `per ogni p in controlla_collegamenti("MioSito") fai stampa(p["collegamento"]) fine`.
    """
    import os
    import re
    cartella = richiedi_testo(cartella, "controlla_collegamenti", "cartella")
    if not os.path.isdir(cartella):
        raise ErroreFile(f"La cartella `{cartella}` non esiste.")
    radice = os.path.abspath(cartella)
    rotti = []
    for base, _c, file in os.walk(radice):
        for nome in file:
            if not nome.lower().endswith((".html", ".htm")):
                continue
            percorso = os.path.join(base, nome)
            try:
                testo = open(percorso, "r", encoding="utf-8", errors="replace").read()
            except OSError:
                continue
            for m in re.finditer(r'(?:href|src)\s*=\s*["\']([^"\'#?]+)', testo):
                link = m.group(1).strip()
                if not link or link.startswith(("http://", "https://", "//", "mailto:", "tel:", "data:", "javascript:")):
                    continue
                dest = os.path.normpath(os.path.join(base, link))
                if not (os.path.exists(dest) or os.path.exists(os.path.join(dest, "index.html"))):
                    rel = os.path.relpath(percorso, radice).replace(os.sep, "/")
                    rotti.append({"pagina": rel, "collegamento": link})
    return rotti


__all__ = ["pubblica_su_github", "guida_token_github", "genera_sitemap", "controlla_collegamenti"]
