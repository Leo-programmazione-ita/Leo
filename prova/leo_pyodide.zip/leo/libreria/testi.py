"""Libreria: metodi dei testi.

``maiuscolo``, ``minuscolo``, ``dividi``, ``unisci``, ``sostituisci``,
``contiene``, ``inizia_con``, ``finisce_con``, ``pulisci``.
I testi non si modificano mai: ogni metodo restituisce un testo (o una lista) nuovo.
"""

from __future__ import annotations

from ..errori import ErroreTipo, ErroreValore
from .generali import articolo, metodo_libreria, mostra, richiedi_testo


@metodo_libreria("testo", "maiuscolo")
def testo_maiuscolo(testo):
    """testo.maiuscolo(): il testo tutto in lettere maiuscole.

    Esempio: `"ciao".maiuscolo()` è "CIAO".
    """
    return testo.upper()


testo_maiuscolo.equivalente_veloce = str.upper  # stesso risultato, senza passare da Python


@metodo_libreria("testo", "minuscolo")
def testo_minuscolo(testo):
    """testo.minuscolo(): il testo tutto in lettere minuscole.

    Esempio: `"CIAO".minuscolo()` è "ciao".
    """
    return testo.lower()


testo_minuscolo.equivalente_veloce = str.lower  # stesso risultato, senza passare da Python


@metodo_libreria("testo", "dividi")
def testo_dividi(testo, separatore=None):
    """testo.dividi(separatore): spezza il testo in una lista di pezzi.

    Senza separatore divide agli spazi (e agli a capo), ignorando quelli ripetuti.
    Esempi: `"a b  c".dividi()` è ["a", "b", "c"]; `"1,2,3".dividi(",")` è ["1", "2", "3"].
    """
    if separatore is None:
        return testo.split()
    if type(separatore) is str and separatore:  # via veloce
        return testo.split(separatore)
    richiedi_testo(separatore, "dividi", "separatore")
    if separatore == "":
        raise ErroreValore("Il `separatore` di `dividi` non può essere un testo vuoto.",
                           suggerimento="Per avere i singoli caratteri usa `per ogni c in testo fai ... fine`.")
    return testo.split(separatore)


@metodo_libreria("testo", "unisci")
def testo_unisci(testo, lista):
    """separatore.unisci(lista): unisce i testi della lista mettendo in mezzo il separatore.

    Esempi: `", ".unisci(["a", "b", "c"])` è "a, b, c"; `"".unisci(["a", "b"])` è "ab".
    """
    if isinstance(lista, range):
        raise ErroreTipo("`unisci` vuole una lista di testi, non un `intervallo`.",
                         suggerimento="Un intervallo contiene numeri: trasformali in testi con `testo(...)`.")
    if not isinstance(lista, list):
        raise ErroreTipo(f"`unisci` vuole una lista di testi, non {articolo(lista)}.",
                         suggerimento="Per unire due testi usa `+`." if isinstance(lista, str) else None)
    for i, elemento in enumerate(lista):
        if not isinstance(elemento, str):
            raise ErroreTipo(
                f"`unisci` unisce solo testi, ma l'elemento {i} della lista è {articolo(elemento)} "
                f"({mostra(elemento)}).",
                suggerimento="Trasforma prima gli elementi con `testo(...)`.",
            )
    return testo.join(lista)


@metodo_libreria("testo", "sostituisci")
def testo_sostituisci(testo, vecchio, nuovo):
    """testo.sostituisci(vecchio, nuovo): il testo con ogni `vecchio` cambiato in `nuovo`.

    Esempio: `"3,14".sostituisci(",", ".")` è "3.14".
    """
    richiedi_testo(vecchio, "sostituisci", "vecchio")
    richiedi_testo(nuovo, "sostituisci", "nuovo")
    if vecchio == "":
        raise ErroreValore("Il testo da sostituire (`vecchio`) non può essere vuoto.")
    return testo.replace(vecchio, nuovo)


@metodo_libreria("testo", "contiene")
def testo_contiene(testo, pezzo):
    """testo.contiene(pezzo): `vero` se `pezzo` compare dentro il testo.

    Esempio: `"buongiorno".contiene("giorno")` è vero. Si può scrivere anche `"giorno" in testo`.
    """
    richiedi_testo(pezzo, "contiene", "pezzo")
    return pezzo in testo


@metodo_libreria("testo", "inizia_con")
def testo_inizia_con(testo, pezzo):
    """testo.inizia_con(pezzo): `vero` se il testo comincia con `pezzo`.

    Esempio: `"Dante Alighieri".inizia_con("Dante")` è vero.
    """
    richiedi_testo(pezzo, "inizia_con", "pezzo")
    return testo.startswith(pezzo)


@metodo_libreria("testo", "finisce_con")
def testo_finisce_con(testo, pezzo):
    """testo.finisce_con(pezzo): `vero` se il testo termina con `pezzo`.

    Esempio: `"foto.png".finisce_con(".png")` è vero.
    """
    richiedi_testo(pezzo, "finisce_con", "pezzo")
    return testo.endswith(pezzo)


@metodo_libreria("testo", "pulisci")
def testo_pulisci(testo):
    """testo.pulisci(): il testo senza spazi (e a capo) all'inizio e alla fine.

    Esempio: `"  ciao  ".pulisci()` è "ciao".
    """
    return testo.strip()


testo_pulisci.equivalente_veloce = str.strip  # stesso risultato, senza passare da Python
