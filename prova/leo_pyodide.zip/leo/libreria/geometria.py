"""Libreria: giochi e geometria 2D (categoria ``geometria``).

Funzioni di **calcolo** utili per scrivere giochi 2D: punti e vettori sul piano,
collisioni (rettangoli e cerchi), interpolazione e movimento, angoli e qualche
scelta a caso comoda. Qui NON ci sono finestre o controlli (quelli stanno nei
programmi con finestre e nella galleria dei giochi): solo numeri che entrano e
numeri che escono, così puoi usarli ovunque, anche sul telefono. Tutto in Python
puro con il solo modulo ``math`` della libreria standard.

Un **punto** (o vettore) è una lista di due numeri ``[x, y]``, come nel resto di
Leo. Creane uno con :func:`crea_punto`. Un **rettangolo** è una lista di quattro
numeri ``[x, y, larghezza, altezza]``: ``x`` e ``y`` sono l'angolo in alto a
sinistra. Un **cerchio** si dà con due argomenti separati, il suo ``centro`` (un
punto) e il suo ``raggio`` (un numero).

Gli **angoli** sono in gradi, misurati come a scuola: 0 verso destra e crescenti
girando in senso antiorario. Per trasformarli usa :func:`gradi_in_radianti` e
:func:`radianti_in_gradi`.

Leo ha già altre funzioni che qui non ripetiamo: ``limita`` (tieni un numero fra
un minimo e un massimo), ``rimappa`` (porta un numero da un intervallo a un
altro), ``scegli_a_caso`` (un elemento a caso da una lista) e ``distanza_gps``
per le coordinate sulla Terra.
"""

from __future__ import annotations

import math
from typing import Any

from ..errori import ErroreTipo, ErroreValore
from ..valori import e_numero, rappresenta
from .generali import articolo, funzione_libreria, richiedi_numero
from .matematica import GENERATORE


# ===========================================================================
# Strumenti interni (non registrati): controllo degli argomenti
# ===========================================================================

def _num(valore: Any, nome: str, parametro: str) -> int | float:
    """Un numero utilizzabile nei conti: non testo, non infinito, non troppo grande.

    Restituisce il valore **invariato** (un intero resta intero, così i risultati
    restano puliti), ma garantisce che stia nei decimali: così nessuna funzione
    solleva un'eccezione Python, solo errori Leo in italiano.
    """
    richiedi_numero(valore, nome, parametro)
    try:
        f = float(valore)
    except OverflowError:
        raise ErroreValore(f"Il numero `{parametro}` di `{nome}` è troppo grande.",
                           suggerimento="Usa numeri con meno cifre.") from None
    if math.isnan(f) or math.isinf(f):
        raise ErroreValore(f"`{nome}` non può usare {rappresenta(valore)} come `{parametro}`.",
                           suggerimento="Serve un numero normale, per esempio 3 o 2.5.")
    return valore


def _punto(valore: Any, nome: str, parametro: str) -> tuple:
    """Un punto 2D: una lista ``[x, y]`` di due numeri. Restituisce ``(x, y)``."""
    if isinstance(valore, list) and len(valore) == 2:
        x = _num(valore[0], nome, parametro)
        y = _num(valore[1], nome, parametro)
        return x, y
    if isinstance(valore, list):
        raise ErroreValore(
            f"Il punto `{parametro}` di `{nome}` deve avere due coordinate [x, y] "
            f"(ne ha {len(valore)}).",
            suggerimento="Crea un punto con `crea_punto(x, y)`, per esempio `crea_punto(3, 4)`.")
    raise ErroreTipo(
        f"L'argomento `{parametro}` di `{nome}` deve essere un punto [x, y], non {articolo(valore)}.",
        suggerimento="Crea un punto con `crea_punto(x, y)`, per esempio `crea_punto(3, 4)`.")


def _rettangolo(valore: Any, nome: str, parametro: str = "rettangolo") -> tuple:
    """Un rettangolo: ``[x, y, larghezza, altezza]``. Restituisce ``(x, y, larghezza, altezza)``."""
    if isinstance(valore, list) and len(valore) == 4 and all(e_numero(v) for v in valore):
        x = _num(valore[0], nome, parametro)
        y = _num(valore[1], nome, parametro)
        larghezza = _num(valore[2], nome, parametro)
        altezza = _num(valore[3], nome, parametro)
        if larghezza < 0 or altezza < 0:
            raise ErroreValore(
                f"Il rettangolo `{parametro}` di `{nome}` ha larghezza o altezza negativa "
                f"({larghezza} e {altezza}).",
                suggerimento="Un rettangolo è [x, y, larghezza, altezza] con larghezza e altezza da 0 in su.")
        return x, y, larghezza, altezza
    if isinstance(valore, list):
        raise ErroreValore(
            f"Il rettangolo `{parametro}` di `{nome}` deve essere [x, y, larghezza, altezza] "
            f"(quattro numeri).",
            suggerimento="Per esempio [10, 20, 100, 50]: angolo in alto a sinistra in (10, 20), largo 100 e alto 50.")
    raise ErroreTipo(
        f"L'argomento `{parametro}` di `{nome}` deve essere un rettangolo [x, y, larghezza, altezza], "
        f"non {articolo(valore)}.",
        suggerimento="Per esempio [10, 20, 100, 50]: angolo in alto a sinistra in (10, 20), largo 100 e alto 50.")


def _raggio(valore: Any, nome: str, parametro: str) -> int | float:
    r = _num(valore, nome, parametro)
    if r < 0:
        raise ErroreValore(
            f"Il raggio `{parametro}` di `{nome}` non può essere negativo (è {r}).",
            suggerimento="Il raggio è la distanza dal centro al bordo: un numero da 0 in su.")
    return r


def _pulito(x: float) -> float:
    """Arrotonda a 12 cifre dopo la virgola: così `ruota_punto([1, 0], 90)` dà [0.0, 1.0]."""
    return round(x, 12) + 0.0


# ===========================================================================
# Vettori 2D
# ===========================================================================

@funzione_libreria("crea_punto")
def crea_punto(x, y):
    """crea_punto(x, y): un punto (o vettore) 2D, cioè la lista [x, y].

    Esempio: `crea_punto(3, 4)` è [3, 4].
    """
    _num(x, "crea_punto", "x")
    _num(y, "crea_punto", "y")
    return [x, y]


@funzione_libreria("somma_punti")
def somma_punti(a, b):
    """somma_punti(a, b): somma due punti coordinata per coordinata.

    Utile per spostare un punto di un vettore. Esempio: `somma_punti([1, 2], [3, 4])` è [4, 6].
    """
    ax, ay = _punto(a, "somma_punti", "a")
    bx, by = _punto(b, "somma_punti", "b")
    return [ax + bx, ay + by]


@funzione_libreria("sottrai_punti")
def sottrai_punti(a, b):
    """sottrai_punti(a, b): il vettore che va da `b` ad `a` (a meno b, coordinata per coordinata).

    Esempio: `sottrai_punti([5, 7], [2, 3])` è [3, 4].
    """
    ax, ay = _punto(a, "sottrai_punti", "a")
    bx, by = _punto(b, "sottrai_punti", "b")
    return [ax - bx, ay - by]


@funzione_libreria("scala_punto")
def scala_punto(punto, fattore):
    """scala_punto(punto, fattore): moltiplica le due coordinate per lo stesso numero.

    Esempio: `scala_punto([2, 3], 10)` è [20, 30].
    """
    x, y = _punto(punto, "scala_punto", "punto")
    _num(fattore, "scala_punto", "fattore")
    return [x * fattore, y * fattore]


@funzione_libreria("lunghezza_vettore")
def lunghezza_vettore(punto):
    """lunghezza_vettore(punto): la lunghezza del vettore dall'origine al punto.

    È la distanza di [x, y] da [0, 0]. Esempio: `lunghezza_vettore([3, 4])` è 5.0.
    """
    x, y = _punto(punto, "lunghezza_vettore", "punto")
    return math.hypot(x, y)


@funzione_libreria("normalizza_vettore")
def normalizza_vettore(punto):
    """normalizza_vettore(punto): lo stesso vettore ma lungo 1 (stessa direzione).

    Serve per avere una direzione pura, senza velocità. Esempio: `normalizza_vettore([3, 4])` è [0.6, 0.8].
    """
    x, y = _punto(punto, "normalizza_vettore", "punto")
    lunghezza = math.hypot(x, y)
    if lunghezza == 0:
        raise ErroreValore(
            "Non posso normalizzare il vettore [0, 0]: non ha una direzione.",
            suggerimento="Controlla che il vettore non sia nullo prima di normalizzarlo.")
    return [x / lunghezza, y / lunghezza]


@funzione_libreria("distanza_punti")
def distanza_punti(a, b):
    """distanza_punti(a, b): la distanza in linea retta fra due punti.

    Esempio: `distanza_punti([0, 0], [3, 4])` è 5.0.
    """
    ax, ay = _punto(a, "distanza_punti", "a")
    bx, by = _punto(b, "distanza_punti", "b")
    return math.hypot(bx - ax, by - ay)


@funzione_libreria("angolo_tra")
def angolo_tra(a, b):
    """angolo_tra(a, b): l'angolo in gradi (da 0 a 180) fra due vettori che partono dall'origine.

    Esempio: `angolo_tra([1, 0], [0, 1])` è 90.0.
    """
    ax, ay = _punto(a, "angolo_tra", "a")
    bx, by = _punto(b, "angolo_tra", "b")
    la = math.hypot(ax, ay)
    lb = math.hypot(bx, by)
    if la == 0 or lb == 0:
        raise ErroreValore(
            "Non posso misurare l'angolo con un vettore nullo [0, 0].",
            suggerimento="L'angolo è fra due direzioni: nessuno dei due vettori deve essere [0, 0].")
    coseno = max(-1.0, min(1.0, (ax * bx + ay * by) / (la * lb)))
    return _pulito(math.degrees(math.acos(coseno)))


@funzione_libreria("ruota_punto")
def ruota_punto(punto, gradi, centro=None):
    """ruota_punto(punto, gradi, centro = [0, 0]): ruota il punto attorno a `centro`, in senso antiorario.

    Esempi: `ruota_punto([1, 0], 90)` è [0.0, 1.0]; `ruota_punto([3, 0], 180, centro = [1, 0])` è [-1.0, 0.0].
    """
    x, y = _punto(punto, "ruota_punto", "punto")
    _num(gradi, "ruota_punto", "gradi")
    cx, cy = (0, 0) if centro is None else _punto(centro, "ruota_punto", "centro")
    r = math.radians(gradi)
    coseno, seno = math.cos(r), math.sin(r)
    dx, dy = x - cx, y - cy
    return [_pulito(cx + dx * coseno - dy * seno), _pulito(cy + dx * seno + dy * coseno)]


# ===========================================================================
# Collisioni
# ===========================================================================

@funzione_libreria("punto_in_rettangolo")
def punto_in_rettangolo(punto, rettangolo):
    """punto_in_rettangolo(punto, rettangolo): `vero` se il punto è dentro il rettangolo (bordi inclusi).

    Il rettangolo è [x, y, larghezza, altezza]. Esempio: `punto_in_rettangolo([2, 2], [0, 0, 5, 5])` è vero.
    """
    x, y = _punto(punto, "punto_in_rettangolo", "punto")
    rx, ry, larghezza, altezza = _rettangolo(rettangolo, "punto_in_rettangolo")
    return rx <= x <= rx + larghezza and ry <= y <= ry + altezza


@funzione_libreria("rettangoli_si_toccano")
def rettangoli_si_toccano(a, b):
    """rettangoli_si_toccano(a, b): `vero` se i due rettangoli si sovrappongono o si toccano sul bordo.

    Ogni rettangolo è [x, y, larghezza, altezza]. Esempio: `rettangoli_si_toccano([0, 0, 2, 2], [1, 1, 2, 2])` è vero.
    """
    ax, ay, aw, ah = _rettangolo(a, "rettangoli_si_toccano", "a")
    bx, by, bw, bh = _rettangolo(b, "rettangoli_si_toccano", "b")
    return ax <= bx + bw and bx <= ax + aw and ay <= by + bh and by <= ay + ah


@funzione_libreria("cerchi_si_toccano")
def cerchi_si_toccano(centro1, raggio1, centro2, raggio2):
    """cerchi_si_toccano(centro1, raggio1, centro2, raggio2): `vero` se i due cerchi si toccano o si sovrappongono.

    Esempio: `cerchi_si_toccano([0, 0], 3, [5, 0], 3)` è vero.
    """
    x1, y1 = _punto(centro1, "cerchi_si_toccano", "centro1")
    x2, y2 = _punto(centro2, "cerchi_si_toccano", "centro2")
    r1 = _raggio(raggio1, "cerchi_si_toccano", "raggio1")
    r2 = _raggio(raggio2, "cerchi_si_toccano", "raggio2")
    return math.hypot(x2 - x1, y2 - y1) <= r1 + r2


@funzione_libreria("cerchio_tocca_rettangolo")
def cerchio_tocca_rettangolo(centro, raggio, rettangolo):
    """cerchio_tocca_rettangolo(centro, raggio, rettangolo): `vero` se il cerchio tocca o entra nel rettangolo.

    Il rettangolo è [x, y, larghezza, altezza]. Esempio: `cerchio_tocca_rettangolo([10, 1], 2, [0, 0, 9, 9])` è vero.
    """
    cx, cy = _punto(centro, "cerchio_tocca_rettangolo", "centro")
    r = _raggio(raggio, "cerchio_tocca_rettangolo", "raggio")
    rx, ry, larghezza, altezza = _rettangolo(rettangolo, "cerchio_tocca_rettangolo")
    vicino_x = max(rx, min(cx, rx + larghezza))
    vicino_y = max(ry, min(cy, ry + altezza))
    return math.hypot(cx - vicino_x, cy - vicino_y) <= r


# ===========================================================================
# Interpolazione e movimento
# ===========================================================================

@funzione_libreria("interpola")
def interpola(inizio, fine, t):
    """interpola(inizio, fine, t): il numero fra `inizio` e `fine` (t = 0 dà inizio, t = 1 dà fine).

    È la "lerp" dei giochi: con t = 0.5 sei a metà. Esempio: `interpola(0, 10, 0.5)` è 5.0.
    """
    _num(inizio, "interpola", "inizio")
    _num(fine, "interpola", "fine")
    _num(t, "interpola", "t")
    return inizio + (fine - inizio) * t


@funzione_libreria("interpola_punto")
def interpola_punto(inizio, fine, t):
    """interpola_punto(inizio, fine, t): il punto fra due punti (t = 0 dà inizio, t = 1 dà fine).

    Fa scivolare un oggetto da un punto all'altro. Esempio: `interpola_punto([0, 0], [10, 20], 0.5)` è [5.0, 10.0].
    """
    ax, ay = _punto(inizio, "interpola_punto", "inizio")
    bx, by = _punto(fine, "interpola_punto", "fine")
    _num(t, "interpola_punto", "t")
    return [ax + (bx - ax) * t, ay + (by - ay) * t]


@funzione_libreria("avvicina")
def avvicina(valore, verso, passo):
    """avvicina(valore, verso, passo): avvicina `valore` a `verso` di al più `passo`, senza superarlo.

    Comodo per muovere un numero poco alla volta. Esempi: `avvicina(5, 10, 3)` è 8; `avvicina(5, 10, 100)` è 10.
    """
    _num(valore, "avvicina", "valore")
    _num(verso, "avvicina", "verso")
    _num(passo, "avvicina", "passo")
    passo = abs(passo)
    if valore < verso:
        return min(valore + passo, verso)
    if valore > verso:
        return max(valore - passo, verso)
    return verso


@funzione_libreria("rimbalza")
def rimbalza(valore, minimo, massimo):
    """rimbalza(valore, minimo, massimo): riporta `valore` fra minimo e massimo facendolo rimbalzare sui bordi.

    A differenza di `limita`, che si ferma al bordo, qui il valore torna indietro come una pallina.
    Esempi: `rimbalza(12, 0, 10)` è 8; `rimbalza(23, 0, 10)` è 3.
    """
    _num(valore, "rimbalza", "valore")
    _num(minimo, "rimbalza", "minimo")
    _num(massimo, "rimbalza", "massimo")
    if massimo < minimo:
        raise ErroreValore(
            f"In `rimbalza` il minimo ({minimo}) deve essere minore o uguale al massimo ({massimo}).",
            suggerimento="Scrivi prima il minimo e poi il massimo, per esempio `rimbalza(valore, 0, 10)`.")
    intervallo = massimo - minimo
    if intervallo == 0:
        return minimo
    t = (valore - minimo) % (2 * intervallo)
    if t > intervallo:
        t = 2 * intervallo - t
    return minimo + t


# ===========================================================================
# Angoli
# ===========================================================================

@funzione_libreria("gradi_in_radianti")
def gradi_in_radianti(gradi):
    """gradi_in_radianti(gradi): trasforma un angolo da gradi a radianti.

    Esempio: `gradi_in_radianti(180)` sono i radianti di mezzo giro (il PI_GRECO).
    """
    _num(gradi, "gradi_in_radianti", "gradi")
    return math.radians(gradi)


@funzione_libreria("radianti_in_gradi")
def radianti_in_gradi(radianti):
    """radianti_in_gradi(radianti): trasforma un angolo da radianti a gradi.

    Esempio: `radianti_in_gradi(PI_GRECO)` è 180.0.
    """
    _num(radianti, "radianti_in_gradi", "radianti")
    return math.degrees(radianti)


@funzione_libreria("direzione_verso")
def direzione_verso(da, a):
    """direzione_verso(da, a): l'angolo in gradi (da 0 a 360) per andare dal punto `da` al punto `a`.

    0 è verso destra e si gira in senso antiorario. Esempi: `direzione_verso([0, 0], [1, 0])` è 0.0;
    `direzione_verso([0, 0], [0, 1])` è 90.0.
    """
    ax, ay = _punto(da, "direzione_verso", "da")
    bx, by = _punto(a, "direzione_verso", "a")
    if ax == bx and ay == by:
        raise ErroreValore(
            "I due punti coincidono: non c'è una direzione da seguire.",
            suggerimento="Controlla con `distanza_punti(da, a)` che i punti siano diversi.")
    return _pulito(math.degrees(math.atan2(by - ay, bx - ax)) % 360)


@funzione_libreria("muovi_verso")
def muovi_verso(punto, bersaglio, velocita):
    """muovi_verso(punto, bersaglio, velocita): il nuovo punto dopo esserti mosso verso `bersaglio` di `velocita`.

    Se sei più vicino di `velocita` arrivi esattamente sul bersaglio. Esempio: `muovi_verso([0, 0], [10, 0], 3)` è [3.0, 0.0].
    """
    px, py = _punto(punto, "muovi_verso", "punto")
    bx, by = _punto(bersaglio, "muovi_verso", "bersaglio")
    velocita = _num(velocita, "muovi_verso", "velocita")
    if velocita < 0:
        raise ErroreValore(
            f"La velocità di `muovi_verso` non può essere negativa (è {velocita}).",
            suggerimento="La velocità è quanto ti sposti a ogni passo: un numero da 0 in su.")
    distanza = math.hypot(bx - px, by - py)
    if distanza == 0 or distanza <= velocita:
        return [bx, by]
    return [px + (bx - px) / distanza * velocita, py + (by - py) / distanza * velocita]


# ===========================================================================
# Casuale, utile ai giochi
# ===========================================================================

@funzione_libreria("punto_casuale_in_rettangolo")
def punto_casuale_in_rettangolo(rettangolo):
    """punto_casuale_in_rettangolo(rettangolo): un punto [x, y] a caso dentro il rettangolo.

    Il rettangolo è [x, y, larghezza, altezza]. Esempio: `punto_casuale_in_rettangolo([0, 0, 100, 100])`
    sceglie un punto a caso nel riquadro. Ogni volta dà un punto diverso.
    """
    x, y, larghezza, altezza = _rettangolo(rettangolo, "punto_casuale_in_rettangolo")
    return [GENERATORE.uniform(x, x + larghezza), GENERATORE.uniform(y, y + altezza)]
