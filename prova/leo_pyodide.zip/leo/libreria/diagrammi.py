"""Libreria: grafici di dati (barre, istogramma, linee, area, torta, anello, dispersione).

Un grafico è un valore Leo di tipo ``grafico``: si crea con ``grafico(...)``
(o con le scorciatoie ``grafico_barre``, ``grafico_linee``...), si arricchisce
con titolo, etichette degli assi, legenda, colori e più serie di dati, e poi:

* si mostra in una finestra (``g.mostra()``, serve PySide6);
* si disegna dentro un controllo ``Tela`` di una finestra del progetto
  (``g.disegna_su(Tela1)``);
* si salva in PNG o SVG (``g.salva("vendite.png")``).

Il modulo è diviso in tre parti:

1. **logica pura** (nessuna dipendenza da Qt, testata da sola): normalizzazione
   dei dati, scale "belle" (0, 10, 20...), tacche, posizioni di barre, punti e
   settori. :func:`elementi_grafico` trasforma un grafico in un elenco di
   *elementi* semplici (rettangoli, linee, poligoni, settori, testi) in pixel,
   con l'origine in alto a sinistra;
2. **disegnatori puri**: :func:`svg_da_elementi` (SVG scritto a mano) e
   :func:`comandi_tela` (comandi della ``Tela``: linee, rettangoli, cerchi,
   testi; i poligoni diventano righe orizzontali);
3. **funzioni Leo** registrate nella libreria.

Il disegno con ``QPainter`` e la finestra sono in ``leo.grafica.qt.diagrammi_qt``
(importato solo quando serve). Senza PySide6 il grafico si salva comunque in SVG.
"""

from __future__ import annotations

import math
import os
import re
from dataclasses import dataclass, field
from typing import Any, Iterable, Sequence
from xml.sax.saxutils import escape

from .. import variabile_ambiente
from ..errori import ErroreDante, ErroreFile, ErroreTipo, ErroreValore
from ..grafica.colori import da_esadecimale, mescola, normalizza_colore
from ..valori import OggettoControllo, e_numero, rappresenta
from .generali import articolo, funzione_libreria, mostra
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta

# ===========================================================================
# 1. Logica pura
# ===========================================================================

#: Tipi di grafico, nella forma canonica.
TIPI_GRAFICO = ("barre", "istogramma", "linee", "area", "torta", "anello", "dispersione")

#: Altri nomi accettati per i tipi.
ALIAS_TIPI = {
    "barra": "barre", "colonne": "barre", "colonna": "barre", "istogramma": "istogramma",
    "linea": "linee", "linee": "linee", "spezzata": "linee",
    "aree": "area", "area": "area",
    "torta": "torta", "settori": "torta",
    "anello": "anello", "ciambella": "anello",
    "dispersione": "dispersione", "punti": "dispersione", "nuvola": "dispersione",
    "barre": "barre",
}

#: Temi: "scuro" (nero e rosso di Leo, predefinito) e "chiaro".
TEMI_GRAFICO: dict[str, dict[str, Any]] = {
    "scuro": {
        "sfondo": "#0B0B0D", "testo": "#ECECEF", "testo_secondario": "#9C9CA6",
        "griglia": "#24242A", "assi": "#6E6E78",
        "serie": ("#E0182D", "#ECECEF", "#FF7A45", "#9C9CA6", "#FF3B4E", "#5B8DEF",
                  "#8E0F1D", "#3DBE8B", "#F2C94C", "#B36BFF"),
    },
    "chiaro": {
        "sfondo": "#FFFFFF", "testo": "#111114", "testo_secondario": "#5C5C66",
        "griglia": "#E6E6EA", "assi": "#9A9AA4",
        "serie": ("#C8102E", "#111114", "#E8612C", "#6E6E78", "#FF3B4E", "#2F6FDE",
                  "#8E0F1D", "#1F9D6B", "#C99A06", "#8A3FD1"),
    },
}
TEMA_PREDEFINITO = "scuro"

LARGHEZZA_PREDEFINITA = 640
ALTEZZA_PREDEFINITA = 400
MARGINE = 16
DIMENSIONE_TITOLO = 18
DIMENSIONE_TESTO = 12
#: Oltre questi valori per serie il grafico diventa illeggibile (e lentissimo).
MASSIMO_VALORI = 10_000
#: Limiti di larghezza e altezza di un grafico, in pixel.
MINIMO_PIXEL, MASSIMO_PIXEL = 120, 8000


class ErroreGrafico(ValueError):
    """Errore della logica pura: la libreria lo trasforma in ``ErroreValore``/``ErroreTipo``."""

    def __init__(self, messaggio: str, suggerimento: str | None = None, *, di_tipo: bool = False) -> None:
        super().__init__(messaggio)
        self.messaggio = messaggio
        self.suggerimento = suggerimento
        self.di_tipo = di_tipo


@dataclass
class Punto:
    """Un valore di una serie: etichetta (categoria) o x numerica, e y."""

    y: float
    etichetta: str | None = None
    x: float | None = None


@dataclass
class Serie:
    nome: str
    punti: list[Punto] = field(default_factory=list)
    colore: str = ""   # "" = colore del tema


# --- tipi e numeri -----------------------------------------------------------

def normalizza_tipo(tipo: Any) -> str:
    """Nome canonico di un tipo di grafico (``"punti"`` -> ``"dispersione"``)."""
    if not isinstance(tipo, str):
        raise ErroreGrafico(f"Il tipo del grafico si scrive come testo, non {articolo(tipo)}.",
                            _suggerimento_tipi(), di_tipo=True)
    chiave = tipo.strip().lower().replace(" ", "_")
    if chiave in ALIAS_TIPI:
        return ALIAS_TIPI[chiave]
    import difflib

    vicini = difflib.get_close_matches(chiave, list(ALIAS_TIPI), n=1, cutoff=0.6)
    suggerimento = f"Forse intendevi \"{ALIAS_TIPI[vicini[0]]}\"?" if vicini else _suggerimento_tipi()
    raise ErroreGrafico(f"Non conosco il tipo di grafico `{tipo}`.", suggerimento)


def _suggerimento_tipi() -> str:
    return "I tipi sono: " + ", ".join(f"\"{t}\"" for t in TIPI_GRAFICO) + "."


def _numero(v: Any, dove: str) -> float:
    if not e_numero(v):
        raise ErroreGrafico(f"{dove} deve essere un numero, non {articolo(v)} ({mostra(v)}).",
                            "Nei dati di un grafico servono numeri: per esempio [3, 5, 2].", di_tipo=True)
    try:
        x = float(v)
    except OverflowError:
        x = math.inf
    if math.isnan(x) or math.isinf(x):
        raise ErroreGrafico(f"{dove} non è un numero valido ({mostra(v)}).",
                            "Togli dai dati i valori `infinito` o non numerici.")
    return x


def _etichetta(v: Any) -> str:
    return v if isinstance(v, str) else rappresenta(v)


def normalizza_dati(dati: Any, tipo: str = "barre") -> list[Punto]:
    """Dati Leo -> lista di :class:`Punto`.

    Accetta: una lista di numeri (``[3, 5, 2]``); un dizionario
    ``{etichetta: valore}``; una lista di coppie ``[etichetta, valore]``;
    per linee, area e dispersione anche coppie di numeri ``[x, y]``.
    ``nulla`` = nessun dato. Solleva :class:`ErroreGrafico` con un messaggio umano.
    """
    if dati is None:
        return []
    if isinstance(dati, range):
        try:
            quanti = len(dati)
        except OverflowError:
            quanti = MASSIMO_VALORI + 1
        if quanti > MASSIMO_VALORI:
            raise _troppi(quanti)
        dati = list(dati)
    punti: list[Punto] = []
    if isinstance(dati, dict):
        if len(dati) > MASSIMO_VALORI:
            raise _troppi(len(dati))
        for k, v in dati.items():
            y = _numero(v, f"Il valore di `{_etichetta(k)}`")
            if tipo == "dispersione":
                punti.append(Punto(y, None, _numero(k, f"La x `{_etichetta(k)}`")))
            else:
                punti.append(Punto(y, _etichetta(k)))
        return punti
    if not isinstance(dati, list):
        raise ErroreGrafico(f"I dati del grafico devono essere una lista o un dizionario, non {articolo(dati)}.",
                            "Per esempio [3, 5, 2] oppure {\"Lun\": 3, \"Mar\": 5}.", di_tipo=True)
    if len(dati) > MASSIMO_VALORI:
        raise _troppi(len(dati))
    for i, elemento in enumerate(dati):
        if isinstance(elemento, list):
            if len(elemento) != 2:
                raise ErroreGrafico(f"L'elemento {i} dei dati deve essere una coppia [etichetta, valore], "
                                    f"non {mostra(elemento)}.",
                                    "Per esempio [[\"Lun\", 3], [\"Mar\", 5]].")
            a, b = elemento
            y = _numero(b, f"Il valore dell'elemento {i}")
            if tipo == "dispersione" or (e_numero(a) and tipo in ("linee", "area")):
                punti.append(Punto(y, None, _numero(a, f"La x dell'elemento {i}")))
            else:
                punti.append(Punto(y, _etichetta(a)))
        else:
            y = _numero(elemento, f"L'elemento {i} dei dati")
            if tipo == "dispersione":
                punti.append(Punto(y, None, float(i)))
            else:
                punti.append(Punto(y, None))
    return punti


def _troppi(n: int) -> ErroreGrafico:
    return ErroreGrafico(f"Troppi valori per un grafico ({n}): il massimo è {MASSIMO_VALORI}.",
                         "Raggruppa i dati (per esempio con un istogramma) prima di disegnarli.")


def scala_bella(minimo: float, massimo: float, tacche: int = 5) -> tuple[float, float, float]:
    """Scala "bella" che contiene [minimo, massimo]: ``(inizio, fine, passo)``.

    Il passo è 1, 2, 2.5 o 5 per una potenza di 10: ``scala_bella(0, 47)`` ->
    ``(0, 50, 10)``. Con minimo == massimo si allarga intorno al valore.
    """
    tacche = max(1, int(tacche))
    if not (math.isfinite(minimo) and math.isfinite(massimo)):
        return 0.0, 1.0, 0.2
    if minimo > massimo:
        minimo, massimo = massimo, minimo
    if massimo == minimo:
        if minimo == 0:
            return 0.0, 1.0, 0.2
        if minimo > 0:
            minimo = 0.0
        else:
            massimo = 0.0
    grezzo = (massimo - minimo) / tacche
    potenza = 10 ** math.floor(math.log10(grezzo))
    frazione = grezzo / potenza
    for bello in (1.0, 2.0, 2.5, 5.0, 10.0):
        if frazione <= bello + 1e-9:
            break
    passo = _arrotonda(bello * potenza)
    inizio = _arrotonda(math.floor(minimo / passo + 1e-9) * passo)
    fine = _arrotonda(math.ceil(massimo / passo - 1e-9) * passo)
    if fine <= inizio:
        fine = _arrotonda(inizio + passo)
    return inizio, fine, passo


def _arrotonda(x: float) -> float:
    """Toglie gli errori di arrotondamento dei decimali (0.30000000000000004 -> 0.3)."""
    if x == 0:
        return 0.0
    cifre = 12 - int(math.floor(math.log10(abs(x))))
    return round(x, max(0, cifre))


def valori_tacche(inizio: float, fine: float, passo: float) -> list[float]:
    """Le tacche da ``inizio`` a ``fine`` (incluse) ogni ``passo``."""
    if passo <= 0:
        return [inizio]
    n = int(round((fine - inizio) / passo))
    return [_arrotonda(inizio + i * passo) for i in range(min(n, 1000) + 1)]


def formatta_numero(v: float) -> str:
    """Numero da mostrare su assi ed etichette: ``20``, ``2.5``, ``15k``, ``1.5M``."""
    if not math.isfinite(v):
        return "?"
    a = abs(v)
    if a >= 1e9:
        return _compatto(v / 1e9) + "G"
    if a >= 1e6:
        return _compatto(v / 1e6) + "M"
    if a >= 1e4:
        return _compatto(v / 1e3) + "k"
    return _compatto(v)


def _compatto(v: float) -> str:
    if abs(v - round(v)) < 1e-9 * max(1.0, abs(v)):
        return str(int(round(v)))
    testo = f"{v:.2f}".rstrip("0").rstrip(".")
    if testo in ("0", "-0"):
        testo = f"{v:.2g}"
    return testo


def larghezza_testo(testo: str, dimensione: float = DIMENSIONE_TESTO) -> float:
    """Larghezza stimata di un testo in pixel (senza misurare i caratteri veri)."""
    return len(testo) * dimensione * 0.56


def classi_istogramma(valori: Sequence[float], classi: int | None = None) -> list[tuple[float, float, int]]:
    """Divide i valori in classi di uguale ampiezza: ``[(da, a, quanti), ...]``.

    Senza ``classi`` usa la regola di Sturges (1 + log2 n). L'ultimo intervallo
    include il suo estremo destro.
    """
    if not valori:
        return []
    n = len(valori)
    if classi is None:
        classi = max(1, int(math.ceil(math.log2(n) + 1)))
    classi = max(1, min(int(classi), 200))
    lo, hi = min(valori), max(valori)
    if lo == hi:
        return [(lo - 0.5, hi + 0.5, n)]
    ampiezza = (hi - lo) / classi
    conteggi = [0] * classi
    for v in valori:
        i = int((v - lo) / ampiezza)
        conteggi[min(max(i, 0), classi - 1)] += 1
    return [(_arrotonda(lo + i * ampiezza), _arrotonda(lo + (i + 1) * ampiezza), conteggi[i]) for i in range(classi)]


def angoli_torta(valori: Sequence[float]) -> list[tuple[float, float]]:
    """Angoli ``(inizio, fine)`` in gradi dei settori (0 = in alto, senso orario)."""
    totale = sum(v for v in valori if v > 0)
    risultato = []
    angolo = 0.0
    for v in valori:
        ampiezza = 360.0 * v / totale if totale > 0 and v > 0 else 0.0
        risultato.append((angolo, angolo + ampiezza))
        angolo += ampiezza
    return risultato


def punto_su_cerchio(cx: float, cy: float, r: float, gradi: float) -> tuple[float, float]:
    """Punto del cerchio a ``gradi`` (0 = in alto, senso orario; y verso il basso)."""
    rad = math.radians(gradi)
    return cx + r * math.sin(rad), cy - r * math.cos(rad)


def punti_settore(cx: float, cy: float, r: float, r_interno: float, inizio: float, fine: float,
                  passo: float = 3.0) -> list[tuple[float, float]]:
    """Poligono che approssima un settore (o un settore d'anello se ``r_interno`` > 0)."""
    n = max(1, int(math.ceil((fine - inizio) / passo)))
    esterno = [punto_su_cerchio(cx, cy, r, inizio + (fine - inizio) * i / n) for i in range(n + 1)]
    if r_interno > 0:
        interno = [punto_su_cerchio(cx, cy, r_interno, fine - (fine - inizio) * i / n) for i in range(n + 1)]
        return esterno + interno
    return [(cx, cy)] + esterno


# --- il modello del grafico ---------------------------------------------------

class Grafico(OggettoLibreria):
    """Valore Leo di tipo ``grafico`` (anche il modello puro usato dai disegnatori)."""

    NOME_TIPO_DANTE = "grafico"
    #: proprietà che si possono cambiare dal codice (``g.titolo = "Vendite"``)
    MODIFICABILI = ("tipo", "titolo", "titolo_x", "titolo_y", "tema", "legenda", "griglia", "mostra_valori",
                    "larghezza", "altezza", "colori", "classi", "sfondo")

    def __init__(self, tipo: str = "barre", titolo: str = "") -> None:
        self.tipo = normalizza_tipo(tipo)
        self.titolo = titolo
        self.titolo_x = ""
        self.titolo_y = ""
        self.tema = TEMA_PREDEFINITO
        self.legenda: bool | None = None     # None = automatica
        self.griglia = True
        self.mostra_valori = False
        self.larghezza = LARGHEZZA_PREDEFINITA
        self.altezza = ALTEZZA_PREDEFINITA
        self.colori: list[str] = []          # [] = colori del tema
        self.classi: int | None = None       # istogramma: None = automatiche
        self.sfondo = ""                     # "" = sfondo del tema
        self.serie: list[Serie] = []
        self.grezzi: list[list[float]] = []  # istogramma: i valori originali di ogni serie

    def testo_dante(self) -> str:
        titolo = f" \"{self.titolo}\"" if self.titolo else ""
        return f"<grafico {self.tipo}{titolo}, {len(self.serie)} serie>"

    # --- dati ---------------------------------------------------------------
    def aggiungi_serie(self, nome: str, dati: Any, colore: str = "") -> Serie:
        if self.tipo == "istogramma":
            valori = [p.y for p in normalizza_dati(dati, "barre")]
            self.grezzi.append(valori)
            serie = Serie(nome, [], colore)
        else:
            serie = Serie(nome, normalizza_dati(dati, self.tipo), colore)
        self.serie.append(serie)
        return serie

    def serie_da_disegnare(self) -> list[Serie]:
        """Le serie pronte per il disegno (per l'istogramma: le classi contate)."""
        if self.tipo != "istogramma":
            return self.serie
        risultato = []
        for serie, valori in zip(self.serie, self.grezzi):
            classi = classi_istogramma(valori, self.classi)
            punti = [Punto(float(q), f"{formatta_numero(a)}\u2013{formatta_numero(b)}") for a, b, q in classi]
            risultato.append(Serie(serie.nome, punti, serie.colore))
        return risultato

    # --- scrittura delle proprietà ------------------------------------------
    def scrivi(self, proprieta: str, valore: Any) -> None:
        if proprieta not in self.MODIFICABILI:
            if proprieta in self._PROPRIETA:
                raise ErroreTipo(f"La proprietà `{proprieta}` di un grafico si può solo leggere.")
            super().leggi(proprieta)  # ErroreNome con suggerimento
        try:
            imposta_proprieta(self, proprieta, valore)
        except ErroreGrafico as e:
            raise _errore_leo(e) from None


def imposta_proprieta(g: Grafico, nome: str, valore: Any) -> None:
    """Controlla e imposta una proprietà del grafico (``ErroreGrafico`` se non va bene)."""
    if nome == "tipo":
        nuovo = normalizza_tipo(valore)
        if (nuovo == "istogramma") != (g.tipo == "istogramma") and g.serie:
            raise ErroreGrafico("Non si può trasformare in (o da) un istogramma un grafico che ha già dati.",
                                "Crea un grafico nuovo con `istogramma(valori)`.")
        g.tipo = nuovo
    elif nome in ("titolo", "titolo_x", "titolo_y"):
        setattr(g, nome, "" if valore is None else _etichetta(valore))
    elif nome == "tema":
        if not isinstance(valore, str) or valore.strip().lower() not in TEMI_GRAFICO:
            raise ErroreGrafico(f"Il tema del grafico può essere \"scuro\" o \"chiaro\", non {mostra(valore)}.")
        g.tema = valore.strip().lower()
    elif nome in ("legenda", "griglia", "mostra_valori"):
        if not isinstance(valore, bool) and not (nome == "legenda" and valore is None):
            raise ErroreGrafico(f"`{nome}` vuole `vero` o `falso`, non {articolo(valore)}.", di_tipo=True)
        setattr(g, nome, valore)
    elif nome in ("larghezza", "altezza"):
        n = _numero(valore, f"`{nome}`")
        if not MINIMO_PIXEL <= n <= MASSIMO_PIXEL:
            raise ErroreGrafico(f"`{nome}` deve essere tra {MINIMO_PIXEL} e {MASSIMO_PIXEL} pixel, "
                                f"non {formatta_numero(n)}.")
        setattr(g, nome, int(round(n)))
    elif nome == "colori":
        if valore is None:
            g.colori = []
            return
        if isinstance(valore, str):
            valore = [valore]
        if not isinstance(valore, list):
            raise ErroreGrafico(f"`colori` vuole una lista di colori, non {articolo(valore)}.",
                                "Per esempio [\"rosso\", \"blu\", \"#FF8800\"].", di_tipo=True)
        g.colori = [colore_valido(c) for c in valore]
    elif nome == "classi":
        if valore is None:
            g.classi = None
            return
        if isinstance(valore, bool) or not isinstance(valore, int) or not 1 <= valore <= 200:
            raise ErroreGrafico(f"`classi` deve essere un intero da 1 a 200, non {mostra(valore)}.")
        g.classi = valore
    elif nome == "sfondo":
        g.sfondo = "" if valore in (None, "") else colore_valido(valore)


def colore_valido(valore: Any) -> str:
    """Colore Leo (nome italiano o ``#RRGGBB[AA]``) in forma ``#RRGGBB[AA]``."""
    try:
        risultato = normalizza_colore(valore)
    except ErroreDante as e:
        raise ErroreGrafico(e.messaggio, e.suggerimento, di_tipo=isinstance(e, ErroreTipo)) from None
    if not risultato:
        raise ErroreGrafico("Un colore vuoto non va bene qui.", "Scrivi per esempio \"rosso\" o \"#FF8800\".")
    return risultato


def colori_serie(g: Grafico, quanti: int) -> list[str]:
    """I colori da usare per ``quanti`` serie (o settori): scelti, poi quelli del tema."""
    tavolozza = list(g.colori) + [c for c in TEMI_GRAFICO[g.tema]["serie"] if c not in g.colori]
    return [tavolozza[i % len(tavolozza)] for i in range(quanti)]


# --- elementi del disegno ------------------------------------------------------

def _rett(x, y, w, h, riempimento, bordo="", spessore=0.0, opacita=1.0) -> dict:
    return {"tipo": "rettangolo", "x": x, "y": y, "larghezza": w, "altezza": h,
            "riempimento": riempimento, "bordo": bordo, "spessore": spessore, "opacita": opacita}


def _linea(x1, y1, x2, y2, colore, spessore=1.0) -> dict:
    return {"tipo": "linea", "x1": x1, "y1": y1, "x2": x2, "y2": y2, "colore": colore, "spessore": spessore}


def _testo(x, y, testo, colore, dimensione=DIMENSIONE_TESTO, allinea="centro", grassetto=False) -> dict:
    return {"tipo": "testo", "x": x, "y": y, "testo": testo, "colore": colore, "dimensione": dimensione,
            "allinea": allinea, "grassetto": grassetto}


def area_disegno(g: Grafico, larghezza: float, altezza: float) -> dict:
    """Riquadri del grafico: titolo, legenda e area dei dati (``x``, ``y``, ``larghezza``, ``altezza``)."""
    serie = g.serie_da_disegnare()
    alto = MARGINE + (DIMENSIONE_TITOLO + 14 if g.titolo else 0)
    basso = altezza - MARGINE
    sinistra, destra = MARGINE, larghezza - MARGINE
    voci = voci_legenda(g, serie)
    legenda = None
    if voci:
        larga = min(200.0, max(larghezza_testo(v) for v, _c in voci) + 30)
        if larga < (destra - sinistra) * 0.4:
            legenda = {"x": destra - larga, "y": alto, "larghezza": larga, "altezza": len(voci) * 20.0}
            destra -= larga + 12
    return {"alto": alto, "basso": basso, "sinistra": sinistra, "destra": destra, "legenda": legenda,
            "voci": voci}


def voci_legenda(g: Grafico, serie: list[Serie] | None = None) -> list[tuple[str, str]]:
    """Voci ``(testo, colore)`` della legenda; ``[]`` se non va mostrata."""
    serie = g.serie_da_disegnare() if serie is None else serie
    if g.legenda is False:
        return []
    if g.tipo in ("torta", "anello"):
        punti = serie[0].punti if serie else []
        colori = colori_serie(g, len(punti))
        voci = [(p.etichetta if p.etichetta is not None else str(i + 1), colori[i])
                for i, p in enumerate(punti) if p.y > 0]
        return voci[:30]
    automatica = len(serie) > 1
    if not (automatica or g.legenda is True):
        return []
    colori = colori_serie(g, len(serie))
    return [(s.nome, s.colore or colori[i]) for i, s in enumerate(serie)][:30]


def categorie(serie: list[Serie]) -> list[str]:
    """Etichette delle categorie di tutte le serie, nell'ordine in cui compaiono.

    I valori senza etichetta prendono la loro posizione (``"1"``, ``"2"``...).
    """
    viste: dict[str, None] = {}
    for s in serie:
        for i, p in enumerate(s.punti):
            viste.setdefault(p.etichetta if p.etichetta is not None else str(i + 1), None)
    return list(viste)


def _valore_per_categoria(s: Serie) -> dict[str, float]:
    risultato: dict[str, float] = {}
    for i, p in enumerate(s.punti):
        chiave = p.etichetta if p.etichetta is not None else str(i + 1)
        risultato[chiave] = risultato.get(chiave, 0.0) + p.y
    return risultato


def _numerico(serie: list[Serie]) -> bool:
    """Vero se tutte le serie hanno x numeriche (linee/area/dispersione con coppie [x, y])."""
    punti = [p for s in serie for p in s.punti]
    return bool(punti) and all(p.x is not None for p in punti)


def elementi_grafico(g: Grafico, larghezza: float | None = None, altezza: float | None = None) -> list[dict]:
    """Il grafico come elenco di elementi da disegnare (pixel, origine in alto a sinistra).

    Elementi: ``rettangolo`` (x, y, larghezza, altezza, riempimento, bordo,
    spessore, opacita), ``linea`` (x1, y1, x2, y2, colore, spessore),
    ``polilinea`` (punti, colore, spessore), ``poligono`` (punti, riempimento,
    opacita), ``cerchio`` (x, y, raggio, riempimento, bordo, opacita),
    ``settore`` (cx, cy, raggio, raggio_interno, inizio, fine, riempimento, bordo),
    ``testo`` (x, y = centro verticale, testo, colore, dimensione, allinea, grassetto).
    """
    w = float(larghezza if larghezza is not None else g.larghezza)
    h = float(altezza if altezza is not None else g.altezza)
    tema = TEMI_GRAFICO[g.tema]
    sfondo = g.sfondo or tema["sfondo"]
    elementi: list[dict] = [_rett(0, 0, w, h, sfondo)]
    if g.titolo:
        elementi.append(_testo(w / 2, MARGINE + DIMENSIONE_TITOLO / 2, g.titolo, tema["testo"],
                               DIMENSIONE_TITOLO, "centro", True))
    riquadro = area_disegno(g, w, h)
    serie = g.serie_da_disegnare()
    if g.tipo in ("torta", "anello"):
        ha_dati = bool(serie) and any(p.y > 0 for p in serie[0].punti)
    else:
        ha_dati = any(s.punti for s in serie)
    if not ha_dati:
        elementi.append(_testo((riquadro["sinistra"] + riquadro["destra"]) / 2,
                               (riquadro["alto"] + riquadro["basso"]) / 2, "Nessun dato da mostrare",
                               tema["testo_secondario"], 14))
        return elementi
    if g.tipo in ("torta", "anello"):
        elementi += _elementi_torta(g, serie[0], riquadro, tema, sfondo)
    else:
        elementi += _elementi_assi(g, serie, riquadro, tema, sfondo)
    if riquadro["legenda"]:
        elementi += _elementi_legenda(riquadro["legenda"], riquadro["voci"], tema)
    return elementi


def _elementi_legenda(riquadro: dict, voci: list[tuple[str, str]], tema: dict) -> list[dict]:
    elementi = []
    for i, (testo, colore) in enumerate(voci):
        y = riquadro["y"] + i * 20 + 10
        elementi.append(_rett(riquadro["x"], y - 6, 12, 12, colore))
        elementi.append(_testo(riquadro["x"] + 20, y, testo, tema["testo"], DIMENSIONE_TESTO, "sinistra"))
    return elementi


def _elementi_torta(g: Grafico, serie: Serie, riquadro: dict, tema: dict, sfondo: str) -> list[dict]:
    elementi: list[dict] = []
    sx, dx, alto, basso = riquadro["sinistra"], riquadro["destra"], riquadro["alto"], riquadro["basso"]
    cx, cy = (sx + dx) / 2, (alto + basso) / 2
    r = max(10.0, min(dx - sx, basso - alto) / 2 - 4)
    r_interno = r * 0.58 if g.tipo == "anello" else 0.0
    valori = [max(0.0, p.y) for p in serie.punti]
    totale = sum(valori)
    colori = colori_serie(g, len(valori))
    angoli = angoli_torta(valori)
    for i, (inizio, fine) in enumerate(angoli):
        if fine - inizio <= 0:
            continue
        elementi.append({"tipo": "settore", "cx": cx, "cy": cy, "raggio": r, "raggio_interno": r_interno,
                         "inizio": inizio, "fine": fine, "riempimento": colori[i], "bordo": sfondo})
    for i, (inizio, fine) in enumerate(angoli):
        if fine - inizio < 14:
            continue
        medio = (inizio + fine) / 2
        raggio_testo = (r + r_interno) / 2 if r_interno else r * 0.62
        x, y = punto_su_cerchio(cx, cy, raggio_testo, medio)
        testo = (formatta_numero(valori[i]) if g.mostra_valori
                 else f"{formatta_numero(round(100 * valori[i] / totale, 1))}%")
        elementi.append(_testo(x, y, testo, _testo_su(colori[i]), DIMENSIONE_TESTO, "centro", True))
    if r_interno:
        elementi.append(_testo(cx, cy - 8, formatta_numero(totale), tema["testo"], 20, "centro", True))
        elementi.append(_testo(cx, cy + 12, "totale", tema["testo_secondario"], 11, "centro"))
    return elementi


def _testo_su(colore: str) -> str:
    """Nero o bianco, quello che si legge meglio sul colore."""
    r, gr, b, _a = da_esadecimale(colore)
    return "#111114" if (0.299 * r + 0.587 * gr + 0.114 * b) > 150 else "#FFFFFF"


def _elementi_assi(g: Grafico, serie: list[Serie], riquadro: dict, tema: dict, sfondo: str) -> list[dict]:
    elementi: list[dict] = []
    numerico = g.tipo == "dispersione" or (g.tipo in ("linee", "area") and _numerico(serie))
    tutti_y = [p.y for s in serie for p in s.punti]
    lo, hi = min(tutti_y), max(tutti_y)
    if g.tipo in ("barre", "istogramma", "area"):
        lo, hi = min(lo, 0.0), max(hi, 0.0)
    elif g.tipo == "dispersione":
        lo, hi = _con_margine(lo, hi)
    y0, y1, passo_y = scala_bella(lo, hi)
    tacche_y = valori_tacche(y0, y1, passo_y)
    etichette_y = [formatta_numero(v) for v in tacche_y]
    sx = riquadro["sinistra"] + max(larghezza_testo(e) for e in etichette_y) + 10
    dx = riquadro["destra"]
    alto = riquadro["alto"] + (18 if g.titolo_y else 4)
    basso = riquadro["basso"] - 22 - (18 if g.titolo_x else 0)
    dx = max(dx, sx + 20)
    basso = max(basso, alto + 20)

    def ypix(v: float) -> float:
        return basso - (v - y0) / (y1 - y0) * (basso - alto)

    # griglia orizzontale ed etichette dell'asse y
    for v, testo in zip(tacche_y, etichette_y):
        y = ypix(v)
        if g.griglia:
            elementi.append(_linea(sx, y, dx, y, tema["griglia"], 1))
        elementi.append(_testo(sx - 8, y, testo, tema["testo_secondario"], 11, "destra"))
    if g.titolo_y:
        elementi.append(_testo(sx - 8, riquadro["alto"] + 6, g.titolo_y, tema["testo_secondario"], 11, "sinistra"))
    if g.titolo_x:
        elementi.append(_testo((sx + dx) / 2, riquadro["basso"] - 8, g.titolo_x, tema["testo_secondario"], 11))
    colori = colori_serie(g, len(serie))
    base = ypix(min(max(0.0, y0), y1))

    if numerico:
        xs = [p.x for s in serie for p in s.punti]
        xa, xb, passo_x = scala_bella(*(_con_margine(min(xs), max(xs)) if g.tipo == "dispersione"
                                         else (min(xs), max(xs))))
        if g.tipo in ("linee", "area") and min(xs) != max(xs):
            x0, x1 = min(xs), max(xs)
        else:
            x0, x1 = xa, xb

        def xpix(v: float) -> float:
            return sx + (v - x0) / (x1 - x0) * (dx - sx)

        for v in valori_tacche(xa, xb, passo_x):
            if not x0 - 1e-9 <= v <= x1 + 1e-9:
                continue
            x = xpix(v)
            if g.griglia and g.tipo == "dispersione":
                elementi.append(_linea(x, alto, x, basso, tema["griglia"], 1))
            elementi.append(_testo(x, basso + 12, formatta_numero(v), tema["testo_secondario"], 11))
        posizioni = [[(xpix(p.x), ypix(p.y), p.y) for p in sorted(s.punti, key=lambda p: p.x)] for s in serie]
    else:
        nomi = categorie(serie)
        n = max(1, len(nomi))
        slot = (dx - sx) / n
        indice = {c: i for i, c in enumerate(nomi)}
        passo_etichette = max(1, int(math.ceil(max(larghezza_testo(c, 11) for c in nomi) / max(slot, 1) * 1.1)))
        for i, c in enumerate(nomi):
            if i % passo_etichette == 0:
                elementi.append(_testo(sx + slot * (i + 0.5), basso + 12, _accorcia(c, slot * passo_etichette),
                                       tema["testo_secondario"], 11))
        posizioni = []
        for s in serie:
            per_cat = _valore_per_categoria(s)
            posizioni.append([(sx + slot * (indice[c] + 0.5), ypix(v), v) for c, v in per_cat.items()])

    if g.tipo in ("barre", "istogramma") and not numerico:
        nomi = categorie(serie)
        slot = (dx - sx) / max(1, len(nomi))
        gruppo = slot * (1.0 if g.tipo == "istogramma" else 0.72)
        larga = gruppo / max(1, len(serie))
        indice = {c: i for i, c in enumerate(nomi)}
        for j, s in enumerate(serie):
            colore = s.colore or colori[j]
            for c, v in _valore_per_categoria(s).items():
                x = sx + slot * indice[c] + (slot - gruppo) / 2 + j * larga
                y = ypix(v)
                cima, fondo = min(y, base), max(y, base)
                elementi.append(_rett(x, cima, max(1.0, larga - (1 if g.tipo == "istogramma" else 2)),
                                      max(0.0, fondo - cima), colore))
                if g.mostra_valori:
                    ty = cima - 9 if v >= 0 else fondo + 9
                    elementi.append(_testo(x + larga / 2, ty, formatta_numero(v), tema["testo"], 11))
    elif g.tipo == "dispersione":
        for j, s in enumerate(serie):
            colore = s.colore or colori[j]
            for x, y, _v in posizioni[j]:
                elementi.append({"tipo": "cerchio", "x": x, "y": y, "raggio": 4.0, "riempimento": colore,
                                 "bordo": sfondo, "opacita": 0.85})
    else:  # linee, area
        for j, s in enumerate(serie):
            colore = s.colore or colori[j]
            punti = [(x, y) for x, y, _v in posizioni[j]]
            if g.tipo == "area" and len(punti) >= 2:
                poligono = [(punti[0][0], base)] + punti + [(punti[-1][0], base)]
                elementi.append({"tipo": "poligono", "punti": poligono, "riempimento": colore, "opacita": 0.3})
            if len(punti) >= 2:
                elementi.append({"tipo": "polilinea", "punti": punti, "colore": colore, "spessore": 2.5})
            if len(punti) <= 60:
                for x, y in punti:
                    elementi.append({"tipo": "cerchio", "x": x, "y": y, "raggio": 3.5, "riempimento": colore,
                                     "bordo": sfondo, "opacita": 1.0})
            if g.mostra_valori:
                for x, y, v in posizioni[j]:
                    elementi.append(_testo(x, y - 12, formatta_numero(v), tema["testo"], 11))
    # assi sopra a tutto
    elementi.append(_linea(sx, base, dx, base, tema["assi"], 1))
    elementi.append(_linea(sx, alto, sx, basso, tema["assi"], 1))
    return elementi


def _con_margine(lo: float, hi: float) -> tuple[float, float]:
    """Allarga un poco l'intervallo, perché i punti non finiscano sugli assi."""
    margine = (hi - lo) * 0.05 or max(1.0, abs(lo) * 0.1)
    return lo - margine, hi + margine


def _accorcia(testo: str, spazio: float) -> str:
    massimo = max(3, int(spazio / (11 * 0.56)))
    return testo if len(testo) <= massimo else testo[:massimo - 1] + "."


# ===========================================================================
# 2. Disegnatori puri: SVG e comandi della Tela
# ===========================================================================

def _num(v: float) -> str:
    return f"{v:.2f}".rstrip("0").rstrip(".")


def _colore_svg(colore: str, attributo: str) -> str:
    """``fill="#RRGGBB"`` (+ ``fill-opacity`` se il colore ha la trasparenza)."""
    if not colore:
        return f'{attributo}="none"'
    if len(colore) == 9:
        alfa = int(colore[7:9], 16) / 255
        return f'{attributo}="{colore[:7]}" {attributo}-opacity="{_num(alfa)}"'
    return f'{attributo}="{colore}"'


def svg_da_elementi(elementi: Iterable[dict], larghezza: float, altezza: float, titolo: str = "") -> str:
    """Il disegno in formato SVG (testo), da aprire con il browser."""
    righe = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{_num(larghezza)}" height="{_num(altezza)}" '
             f'viewBox="0 0 {_num(larghezza)} {_num(altezza)}" '
             f'font-family="Segoe UI, Helvetica, Arial, sans-serif">']
    if titolo:
        righe.append(f"  <title>{escape(titolo)}</title>")
    ancore = {"sinistra": "start", "centro": "middle", "destra": "end"}
    for e in elementi:
        t = e["tipo"]
        opacita = e.get("opacita", 1.0)
        extra = f' opacity="{_num(opacita)}"' if opacita < 1 else ""
        if t == "rettangolo":
            bordo = (f' {_colore_svg(e["bordo"], "stroke")} stroke-width="{_num(e["spessore"])}"'
                     if e.get("bordo") and e.get("spessore") else "")
            righe.append(f'  <rect x="{_num(e["x"])}" y="{_num(e["y"])}" width="{_num(e["larghezza"])}" '
                         f'height="{_num(e["altezza"])}" {_colore_svg(e["riempimento"], "fill")}{bordo}{extra}/>')
        elif t == "linea":
            righe.append(f'  <line x1="{_num(e["x1"])}" y1="{_num(e["y1"])}" x2="{_num(e["x2"])}" '
                         f'y2="{_num(e["y2"])}" {_colore_svg(e["colore"], "stroke")} '
                         f'stroke-width="{_num(e["spessore"])}"/>')
        elif t == "polilinea":
            punti = " ".join(f"{_num(x)},{_num(y)}" for x, y in e["punti"])
            righe.append(f'  <polyline points="{punti}" fill="none" {_colore_svg(e["colore"], "stroke")} '
                         f'stroke-width="{_num(e["spessore"])}" stroke-linejoin="round" stroke-linecap="round"/>')
        elif t == "poligono":
            punti = " ".join(f"{_num(x)},{_num(y)}" for x, y in e["punti"])
            righe.append(f'  <polygon points="{punti}" {_colore_svg(e["riempimento"], "fill")}{extra}/>')
        elif t == "cerchio":
            bordo = f' {_colore_svg(e["bordo"], "stroke")} stroke-width="1"' if e.get("bordo") else ""
            righe.append(f'  <circle cx="{_num(e["x"])}" cy="{_num(e["y"])}" r="{_num(e["raggio"])}" '
                         f'{_colore_svg(e["riempimento"], "fill")}{bordo}{extra}/>')
        elif t == "settore":
            righe.append(f'  <path d="{_percorso_settore(e)}" {_colore_svg(e["riempimento"], "fill")} '
                         f'{_colore_svg(e["bordo"], "stroke")} stroke-width="2" stroke-linejoin="round"/>')
        elif t == "testo":
            peso = ' font-weight="bold"' if e.get("grassetto") else ""
            y = e["y"] + e["dimensione"] * 0.35
            righe.append(f'  <text x="{_num(e["x"])}" y="{_num(y)}" font-size="{_num(e["dimensione"])}" '
                         f'text-anchor="{ancore.get(e["allinea"], "middle")}" '
                         f'{_colore_svg(e["colore"], "fill")}{peso}>{escape(e["testo"])}</text>')
    righe.append("</svg>")
    return "\n".join(righe) + "\n"


def _percorso_settore(e: dict) -> str:
    cx, cy, r, ri = e["cx"], e["cy"], e["raggio"], e["raggio_interno"]
    inizio, fine = e["inizio"], e["fine"]
    if fine - inizio >= 359.999:  # cerchio intero: due mezzi archi
        fine = inizio + 359.99
    grande = 1 if fine - inizio > 180 else 0
    x1, y1 = punto_su_cerchio(cx, cy, r, inizio)
    x2, y2 = punto_su_cerchio(cx, cy, r, fine)
    if ri > 0:
        x3, y3 = punto_su_cerchio(cx, cy, ri, fine)
        x4, y4 = punto_su_cerchio(cx, cy, ri, inizio)
        return (f"M {_num(x1)} {_num(y1)} A {_num(r)} {_num(r)} 0 {grande} 1 {_num(x2)} {_num(y2)} "
                f"L {_num(x3)} {_num(y3)} A {_num(ri)} {_num(ri)} 0 {grande} 0 {_num(x4)} {_num(y4)} Z")
    return (f"M {_num(cx)} {_num(cy)} L {_num(x1)} {_num(y1)} "
            f"A {_num(r)} {_num(r)} 0 {grande} 1 {_num(x2)} {_num(y2)} Z")


def righe_riempimento(punti: Sequence[tuple[float, float]]) -> list[tuple[float, float, float]]:
    """Riempie un poligono con righe orizzontali: ``[(y, x_da, x_a), ...]`` (regola pari-dispari)."""
    if len(punti) < 3:
        return []
    ys = [p[1] for p in punti]
    risultato = []
    y = math.floor(min(ys)) + 0.5
    fondo = max(ys)
    n = len(punti)
    while y <= fondo:
        incroci = []
        for i in range(n):
            (xa, ya), (xb, yb) = punti[i], punti[(i + 1) % n]
            if (ya <= y < yb) or (yb <= y < ya):
                incroci.append(xa + (y - ya) * (xb - xa) / (yb - ya))
        incroci.sort()
        for k in range(0, len(incroci) - 1, 2):
            if incroci[k + 1] - incroci[k] > 0.01:
                risultato.append((y, incroci[k], incroci[k + 1]))
        y += 1.0
    return risultato


def comandi_tela(elementi: Iterable[dict], sfondo: str, ox: float = 0.0, oy: float = 0.0) -> list[dict]:
    """Gli elementi come comandi della ``Tela`` (``disegni``): linea, rettangolo, cerchio, testo.

    Poligoni e settori diventano righe orizzontali; l'opacità si simula
    mescolando il colore con lo ``sfondo``. I testi usano il carattere della tela.
    """
    comandi: list[dict] = []

    def tinta(colore: str, opacita: float = 1.0) -> str:
        colore = colore[:7] if colore else "#000000"
        return mescola(sfondo[:7], colore, opacita) if opacita < 1 else colore

    def riempi(punti, colore):
        for y, xa, xb in righe_riempimento([(x + ox, yy + oy) for x, yy in punti]):
            comandi.append({"figura": "linea", "x1": xa, "y1": y, "x2": xb, "y2": y, "colore": colore,
                            "spessore": 1.2})

    for e in elementi:
        t = e["tipo"]
        if t == "rettangolo":
            comandi.append({"figura": "rettangolo", "x": e["x"] + ox, "y": e["y"] + oy,
                            "larghezza": e["larghezza"], "altezza": e["altezza"], "riempito": True,
                            "colore": tinta(e["riempimento"], e.get("opacita", 1.0)), "spessore": 1})
        elif t == "linea":
            comandi.append({"figura": "linea", "x1": e["x1"] + ox, "y1": e["y1"] + oy, "x2": e["x2"] + ox,
                            "y2": e["y2"] + oy, "colore": tinta(e["colore"]), "spessore": e["spessore"]})
        elif t == "polilinea":
            p = e["punti"]
            for (xa, ya), (xb, yb) in zip(p, p[1:]):
                comandi.append({"figura": "linea", "x1": xa + ox, "y1": ya + oy, "x2": xb + ox, "y2": yb + oy,
                                "colore": tinta(e["colore"]), "spessore": e["spessore"]})
        elif t == "poligono":
            riempi(e["punti"], tinta(e["riempimento"], e.get("opacita", 1.0)))
        elif t == "settore":
            punti = punti_settore(e["cx"], e["cy"], e["raggio"], e["raggio_interno"], e["inizio"], e["fine"])
            riempi(punti, tinta(e["riempimento"]))
        elif t == "cerchio":
            comandi.append({"figura": "cerchio", "x": e["x"] + ox, "y": e["y"] + oy, "raggio": e["raggio"],
                            "riempito": True, "colore": tinta(e["riempimento"], e.get("opacita", 1.0)),
                            "spessore": 1})
        elif t == "testo":
            larga = larghezza_testo(e["testo"], 12)
            x = e["x"] - {"sinistra": 0.0, "centro": larga / 2, "destra": larga}.get(e["allinea"], 0.0)
            comandi.append({"figura": "testo", "x": x + ox, "y": e["y"] - 8 + oy, "testo": e["testo"],
                            "colore": tinta(e["colore"]), "spessore": 1})
    return comandi


def nome_file_grafico(g: Grafico, estensione: str = ".svg") -> str:
    """Nome di file ricavato dal titolo: ``"Vendite 2026"`` -> ``vendite_2026.svg``."""
    base = re.sub(r"[^\w]+", "_", g.titolo.lower(), flags=re.UNICODE).strip("_")[:40] or "grafico"
    return base + estensione


def modalita_finestra() -> bool:
    """Vero se ``mostra`` può aprire una finestra (PySide6 e niente ``LEO_GRAFICI=testo``)."""
    for nome in ("GRAFICI", "TARTARUGA"):
        if (variabile_ambiente(nome) or "").strip().lower() in ("testo", "svg", "no"):
            return False
    from ..piattaforma import e_android
    from ..tartaruga import pyside6_presente

    return not e_android() and pyside6_presente()


# ===========================================================================
# 3. Funzioni Leo
# ===========================================================================

def _errore_leo(e: ErroreGrafico) -> ErroreDante:
    classe = ErroreTipo if e.di_tipo else ErroreValore
    return classe(e.messaggio, suggerimento=e.suggerimento)


def _esegui(azione, *argomenti):
    try:
        return azione(*argomenti)
    except ErroreGrafico as e:
        raise _errore_leo(e) from None


def _richiedi_grafico(g: Any, funzione_nome: str) -> Grafico:
    if isinstance(g, Grafico):
        return g
    raise ErroreTipo(f"`{funzione_nome}` vuole un grafico, non {articolo(g)}.",
                     suggerimento="Crea il grafico con `grafico_barre(dati)` o `grafico(\"linee\", dati)`.")


def _nuovo(tipo: str, dati: Any, titolo: Any, funzione_nome: str) -> Grafico:
    if titolo is None:
        titolo = ""
    if not isinstance(titolo, str):
        raise ErroreTipo(f"Il titolo di `{funzione_nome}` deve essere un testo, non {articolo(titolo)}.")
    g = _esegui(Grafico, tipo, titolo)
    if dati is not None:
        _esegui(g.aggiungi_serie, "Serie 1", dati, "")
    return g


@funzione_libreria("grafico")
def grafico(tipo="barre", dati=None, titolo=""):
    """grafico(tipo = "barre", dati = nulla, titolo = ""): crea un grafico di dati.

    Tipi: "barre", "istogramma", "linee", "area", "torta", "anello", "dispersione".
    I dati sono una lista di numeri, un dizionario {etichetta: valore} o una
    lista di coppie [etichetta, valore]. Esempio:
    `variabile g = grafico("linee", {"Gen": 12, "Feb": 18, "Mar": 9}, "Visite")` poi `g.mostra()`.
    """
    return _nuovo(tipo, dati, titolo, "grafico")


@funzione_libreria("grafico_barre")
def grafico_barre(dati, titolo=""):
    """grafico_barre(dati, titolo = ""): un grafico a barre.

    Esempio: `grafico_barre({"Lun": 3, "Mar": 5, "Mer": 2}, "Ore di studio").salva("studio.png")`.
    """
    return _nuovo("barre", dati, titolo, "grafico_barre")


@funzione_libreria("grafico_linee")
def grafico_linee(dati, titolo=""):
    """grafico_linee(dati, titolo = ""): un grafico a linee (valori, coppie [etichetta, valore] o [x, y]).

    Esempio: `grafico_linee([3, 7, 4, 9], "Andamento").mostra()`.
    """
    return _nuovo("linee", dati, titolo, "grafico_linee")


@funzione_libreria("grafico_area")
def grafico_area(dati, titolo=""):
    """grafico_area(dati, titolo = ""): come le linee, con l'area sotto colorata.

    Esempio: `grafico_area({"Q1": 10, "Q2": 14, "Q3": 12}, "Ricavi")`.
    """
    return _nuovo("area", dati, titolo, "grafico_area")


@funzione_libreria("grafico_torta")
def grafico_torta(dati, titolo=""):
    """grafico_torta(dati, titolo = ""): un grafico a torta con le percentuali.

    Esempio: `grafico_torta({"Rosso": 5, "Nero": 3, "Bianco": 2}, "Voti")`.
    """
    return _nuovo("torta", dati, titolo, "grafico_torta")


@funzione_libreria("grafico_anello")
def grafico_anello(dati, titolo=""):
    """grafico_anello(dati, titolo = ""): una torta con il buco, e il totale al centro.

    Esempio: `grafico_anello({"Fatto": 7, "Da fare": 3}, "Compiti")`.
    """
    return _nuovo("anello", dati, titolo, "grafico_anello")


@funzione_libreria("grafico_dispersione")
def grafico_dispersione(dati, titolo=""):
    """grafico_dispersione(dati, titolo = ""): punti sparsi, da una lista di coppie [x, y].

    Esempio: `grafico_dispersione([[1, 2], [2, 3.5], [3, 3], [4, 5]], "Altezza e peso")`.
    """
    return _nuovo("dispersione", dati, titolo, "grafico_dispersione")


@funzione_libreria("istogramma")
def istogramma(valori, classi=None, titolo=""):
    """istogramma(valori, classi = nulla, titolo = ""): conta quanti valori cadono in ogni intervallo.

    Senza `classi` il numero di intervalli si sceglie da solo.
    Esempio: `istogramma([4, 7, 6, 8, 5, 9, 6, 7], classi = 3, titolo = "Voti")`.
    """
    g = _nuovo("istogramma", None, titolo, "istogramma")
    _esegui(imposta_proprieta, g, "classi", classi)
    if valori is not None:
        _esegui(g.aggiungi_serie, "Valori", valori, "")
    return g


@funzione_libreria("mostra_grafico", interprete=True)
def mostra_grafico(interprete, grafico, aspetta=True):
    """mostra_grafico(grafico, aspetta = vero): apre il grafico in una finestra (come `grafico.mostra()`).

    Senza la parte grafica (PySide6) il grafico viene salvato in un file SVG.
    """
    return _mostra(interprete, _richiedi_grafico(grafico, "mostra_grafico"), aspetta)


@funzione_libreria("salva_grafico", interprete=True)
def salva_grafico(interprete, grafico, percorso):
    """salva_grafico(grafico, percorso): salva il grafico in PNG o SVG (come `grafico.salva(percorso)`).

    Restituisce il nome del file scritto. Esempio: `salva_grafico(g, "vendite.svg")`.
    """
    return _salva(interprete, _richiedi_grafico(grafico, "salva_grafico"), percorso)


@funzione_libreria("disegna_grafico")
def disegna_grafico(grafico, tela):
    """disegna_grafico(grafico, tela): disegna il grafico dentro una Tela della finestra.

    Esempio (nell'evento di un pulsante): `disegna_grafico(g, Tela1)`.
    """
    return _disegna_su(_richiedi_grafico(grafico, "disegna_grafico"), tela)


# --- proprietà e metodi del valore `grafico` ---------------------------------

for _nome in Grafico.MODIFICABILI:
    proprieta(Grafico, _nome)(lambda g, _n=_nome: list(getattr(g, _n)) if _n == "colori" else getattr(g, _n))
proprieta(Grafico, "numero_serie")(lambda g: len(g.serie))
proprieta(Grafico, "nomi_serie")(lambda g: [s.nome for s in g.serie])


@metodo_oggetto(Grafico, "aggiungi_serie")
def grafico_aggiungi_serie(g, nome, dati, colore=None):
    """grafico.aggiungi_serie(nome, dati, colore = nulla): aggiunge un'altra serie di dati.

    Esempio: `g.aggiungi_serie("2026", {"Gen": 5, "Feb": 8}, "rosso")`. Con più serie compare la legenda.
    """
    if not isinstance(nome, str):
        raise ErroreTipo(f"Il nome della serie deve essere un testo, non {articolo(nome)}.")
    c = "" if colore is None else _esegui(colore_valido, colore)
    _esegui(g.aggiungi_serie, nome, dati, c)
    return None


@metodo_oggetto(Grafico, "aggiungi_valore")
def grafico_aggiungi_valore(g, valore, etichetta=None):
    """grafico.aggiungi_valore(valore, etichetta = nulla): aggiunge un valore all'ultima serie.

    Esempio: `g.aggiungi_valore(12, "Apr")`.
    """
    if not g.serie:
        _esegui(g.aggiungi_serie, "Serie 1", [], "")
    dato = [valore] if etichetta is None else [[etichetta, valore]]
    if g.tipo == "istogramma":
        g.grezzi[-1] += [p.y for p in _esegui(normalizza_dati, [valore], "barre")]
    else:
        g.serie[-1].punti += _esegui(normalizza_dati, dato, g.tipo)
    return None


@metodo_oggetto(Grafico, "svuota")
def grafico_svuota(g):
    """grafico.svuota(): toglie tutte le serie di dati (titolo e colori restano)."""
    g.serie.clear()
    g.grezzi.clear()
    return None


@metodo_oggetto(Grafico, "svg")
def grafico_svg(g):
    """grafico.svg(): il grafico come testo SVG (da scrivere in un file o in una pagina web)."""
    return svg_da_elementi(elementi_grafico(g), g.larghezza, g.altezza, g.titolo)


@metodo_oggetto(Grafico, "mostra", interprete=True)
def grafico_mostra(interprete, g, aspetta=True):
    """grafico.mostra(aspetta = vero): apre il grafico in una finestra che si adatta alle dimensioni.

    Con `aspetta` = vero il programma continua quando chiudi la finestra. Senza la parte
    grafica (PySide6) il grafico viene salvato in un file SVG da aprire con il browser.
    """
    return _mostra(interprete, g, aspetta)


@metodo_oggetto(Grafico, "salva", interprete=True)
def grafico_salva(interprete, g, percorso):
    """grafico.salva(percorso): salva il grafico in un file ".png" o ".svg"; restituisce il nome del file.

    Il PNG richiede PySide6: senza, il grafico viene salvato in SVG (e Leo lo dice).
    """
    return _salva(interprete, g, percorso)


@metodo_oggetto(Grafico, "disegna_su")
def grafico_disegna_su(g, tela):
    """grafico.disegna_su(tela): disegna il grafico dentro un controllo Tela, grande quanto la tela.

    Esempio: `g.disegna_su(Tela1)`.
    """
    return _disegna_su(g, tela)


# --- realizzazione -------------------------------------------------------------

def _avvisa(interprete: Any, testo: str) -> None:
    scrivi = getattr(interprete, "scrivi", None)
    if callable(scrivi):
        scrivi(testo + "\n")
    else:
        print(testo, flush=True)


def _scrivi_svg(g: Grafico, percorso: str) -> None:
    testo = svg_da_elementi(elementi_grafico(g), g.larghezza, g.altezza, g.titolo)
    try:
        with open(percorso, "w", encoding="utf-8") as f:
            f.write(testo)
    except OSError as e:
        raise ErroreFile(f"Non riesco a salvare il grafico in `{percorso}`: {e.strerror or e}.",
                         suggerimento="Controlla che la cartella esista e che il file non sia aperto altrove.") \
            from None


def _salva(interprete: Any, g: Grafico, percorso: Any) -> str:
    if not isinstance(percorso, str):
        raise ErroreTipo(f"Il percorso del file deve essere un testo, non {articolo(percorso)}.",
                         suggerimento="Per esempio \"vendite.png\" o \"vendite.svg\".")
    percorso = percorso.strip()
    if "\0" in percorso:
        raise ErroreValore("Il nome del file del grafico contiene un carattere non valido.")
    if not percorso:
        raise ErroreValore("Il nome del file del grafico è vuoto.",
                           suggerimento="Per esempio \"vendite.png\" o \"vendite.svg\".")
    base, estensione = os.path.splitext(percorso)
    estensione = estensione.lower()
    if estensione == "":
        percorso, estensione = percorso + ".png", ".png"
    if estensione == ".svg":
        _scrivi_svg(g, percorso)
        return percorso
    if estensione not in (".png", ".jpg", ".jpeg", ".bmp"):
        raise ErroreValore(f"Non so salvare un grafico in formato `{estensione}`.",
                           suggerimento="Usa \".png\" (immagine) oppure \".svg\" (disegno per il browser).")
    try:
        from ..grafica.qt import diagrammi_qt

        riuscito = diagrammi_qt.salva_immagine(g, percorso)
    except ImportError:
        riuscito = None
    if riuscito is None:
        alternativo = base + ".svg"
        _scrivi_svg(g, alternativo)
        _avvisa(interprete, f"Per salvare in {estensione.upper()[1:]} serve la parte grafica (PySide6): "
                            f"ho salvato il grafico in \"{alternativo}\" (si apre con il browser).")
        return alternativo
    if not riuscito:
        raise ErroreFile(f"Non riesco a salvare il grafico in `{percorso}`.",
                         suggerimento="Controlla che la cartella esista e che il file non sia aperto altrove.")
    return percorso


def _mostra(interprete: Any, g: Grafico, aspetta: Any) -> None:
    if not isinstance(aspetta, bool):
        raise ErroreTipo(f"`aspetta` vuole `vero` o `falso`, non {articolo(aspetta)}.")
    if modalita_finestra():
        try:
            from ..grafica.qt import diagrammi_qt

            diagrammi_qt.mostra_grafico(g, aspetta)
            return None
        except ImportError:
            pass
    percorso = nome_file_grafico(g)
    _scrivi_svg(g, percorso)
    _avvisa(interprete, f"Grafico salvato in \"{percorso}\" (si apre con il browser).")
    return None


def _disegna_su(g: Grafico, tela: Any) -> None:
    tipo = getattr(tela, "tipo_controllo", None)
    modello = getattr(tela, "modello", None)
    if not isinstance(tela, OggettoControllo) or getattr(tela, "E_VALORE_LIBRERIA", False) \
            or modello is None or tipo != "Tela":
        cosa = f"il controllo `{getattr(tela, 'nome', '?')}` ({tipo})" if tipo else articolo(tela)
        raise ErroreTipo(f"Un grafico si disegna dentro una Tela, non dentro {cosa}.",
                         suggerimento="Aggiungi alla finestra un controllo Tela e scrivi `g.disegna_su(Tela1)`.")
    proprieta_tela = modello.proprieta
    w = _dimensione(proprieta_tela.get("larghezza"), 320)
    h = _dimensione(proprieta_tela.get("altezza"), 240)
    elementi = elementi_grafico(g, w, h)
    sfondo = g.sfondo or TEMI_GRAFICO[g.tema]["sfondo"]
    comandi = comandi_tela(elementi, sfondo)
    disegni = proprieta_tela.get("disegni")
    if not isinstance(disegni, list):
        disegni = []
        proprieta_tela["disegni"] = disegni
    disegni.extend(comandi)
    avvisa = getattr(tela, "avvisa", None)
    if callable(avvisa):
        avvisa("disegni", disegni)
    return None


def _dimensione(v: Any, predefinita: int) -> int:
    return int(v) if e_numero(v) and 20 <= v <= MASSIMO_PIXEL else predefinita


__all__ = ["TIPI_GRAFICO", "TEMI_GRAFICO", "Grafico", "Serie", "Punto", "ErroreGrafico", "normalizza_tipo",
           "normalizza_dati", "scala_bella", "valori_tacche", "formatta_numero", "classi_istogramma",
           "angoli_torta", "punti_settore", "elementi_grafico", "svg_da_elementi", "comandi_tela",
           "righe_riempimento", "voci_legenda", "categorie", "nome_file_grafico", "modalita_finestra"]
