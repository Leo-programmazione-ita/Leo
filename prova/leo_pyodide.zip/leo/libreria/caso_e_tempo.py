"""Libreria: scelte a caso e misura del tempo.

``scegli_a_caso``, ``mescola`` (usano ``matematica.GENERATORE``, così
``GENERATORE.seed(n)`` rende ripetibili anche loro), ``cronometro`` (un
valore di tipo ``cronometro`` con i suoi metodi) e ``misura_tempo``.
"""

from __future__ import annotations

import sys
import time

from ..errori import ErroreValore
from ..valori import rappresenta
from .funzionali import MASSIMO_INTERVALLO, chiama_funzione, elementi, richiedi_funzione
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta
from .generali import funzione_libreria, lunghezza_intervallo, richiedi_intero
from .matematica import GENERATORE


@funzione_libreria("scegli_a_caso")
def scegli_a_caso(lista, quanti=None):
    """scegli_a_caso(lista, quanti = nulla): un elemento scelto a caso (o `quanti` elementi diversi).

    Esempi: `scegli_a_caso(["sasso", "carta", "forbici"])`; `scegli_a_caso(1..90, quanti = 6)`
    dà una lista di 6 numeri tutti diversi.
    """
    if isinstance(lista, range) and quanti is None:
        if lunghezza_intervallo(lista) == 0:
            raise ErroreValore("Non posso scegliere a caso da un intervallo vuoto.")
        return GENERATORE.randrange(lista.start, lista.stop, lista.step)
    if isinstance(lista, range) and quanti is not None:
        # si estrae direttamente dall'intervallo, senza trasformarlo in lista: stessi risultati
        # (a parità di GENERATORE.seed), ma immediato anche con 1..1000000000
        richiedi_intero(quanti, "scegli_a_caso", "quanti")
        n = lunghezza_intervallo(lista)
        if not 0 <= quanti <= n:
            raise ErroreValore(f"Non posso scegliere {quanti} elementi diversi da un intervallo che ne ha {n}.")
        if quanti > MASSIMO_INTERVALLO:
            raise ErroreValore(f"Troppi elementi da scegliere (al massimo {MASSIMO_INTERVALLO}).")
        if n <= sys.maxsize:
            return GENERATORE.sample(lista, quanti)
        # intervallo più lungo di quanto `sample` sappia gestire: estrazioni ripetute
        # (con numeri così tanti, i doppioni sono rarissimi e vengono scartati)
        scelti: dict = {}
        while len(scelti) < quanti:
            scelti.setdefault(lista[GENERATORE.randrange(n)], None)
        return list(scelti)
    dati = elementi(lista, "scegli_a_caso")
    if quanti is None:
        if not dati:
            raise ErroreValore("Non posso scegliere a caso da una lista vuota.",
                               suggerimento="Controlla prima con `se non vuota(lista) allora`.")
        return GENERATORE.choice(dati)
    richiedi_intero(quanti, "scegli_a_caso", "quanti")
    if not 0 <= quanti <= len(dati):
        raise ErroreValore(f"Non posso scegliere {quanti} elementi diversi da una lista che ne ha {len(dati)}.")
    return GENERATORE.sample(dati, quanti)


@funzione_libreria("mescola")
def mescola(lista):
    """mescola(lista): una NUOVA lista con gli stessi elementi in ordine casuale (la lista data non cambia).

    Esempio: `variabile mazzo = mescola(carte)`.
    """
    dati = list(elementi(lista, "mescola"))
    GENERATORE.shuffle(dati)
    return dati


class Cronometro(OggettoLibreria):
    """Valore Leo di tipo ``cronometro``: misura il tempo passato."""

    NOME_TIPO_DANTE = "cronometro"
    SUGGERIMENTO_MODIFICA = "Per ricominciare da 0 usa `c.azzera()`."

    def __init__(self) -> None:
        self.inizio = time.perf_counter()
        self.accumulato = 0.0
        self.in_corsa = True

    def trascorso(self) -> float:
        if self.in_corsa:
            return self.accumulato + (time.perf_counter() - self.inizio)
        return self.accumulato

    def testo_dante(self) -> str:
        stato = "" if self.in_corsa else ", fermo"
        return f"<cronometro {rappresenta(round(self.trascorso(), 3))} s{stato}>"


@funzione_libreria("cronometro")
def cronometro():
    """cronometro(): fa partire un cronometro. Poi `c.secondi` dice quanto tempo è passato.

    Esempio: `variabile c = cronometro()` ... `stampa("Ci hai messo {c.secondi} secondi")`.
    Proprietà: `secondi` (con 3 decimali), `millisecondi`, `in_corsa`.
    Metodi: `ferma()`, `riprendi()`, `azzera()`, `giro(decimali = 3)`.
    """
    return Cronometro()


proprieta(Cronometro, "secondi")(lambda c: round(c.trascorso(), 3))
proprieta(Cronometro, "millisecondi")(lambda c: int(c.trascorso() * 1000))
proprieta(Cronometro, "in_corsa")(lambda c: c.in_corsa)


@metodo_oggetto(Cronometro, "giro")
def cronometro_giro(c, decimali=3):
    """cronometro.giro(decimali = 3): i secondi passati, con quanti decimali vuoi."""
    richiedi_intero(decimali, "giro", "decimali")
    return round(c.trascorso(), max(0, min(decimali, 9)))


@metodo_oggetto(Cronometro, "ferma")
def cronometro_ferma(c):
    """cronometro.ferma(): mette in pausa il cronometro (il tempo smette di contare)."""
    if c.in_corsa:
        c.accumulato = c.trascorso()
        c.in_corsa = False
    return None


@metodo_oggetto(Cronometro, "riprendi")
def cronometro_riprendi(c):
    """cronometro.riprendi(): fa ripartire un cronometro fermato con `ferma()`."""
    if not c.in_corsa:
        c.inizio = time.perf_counter()
        c.in_corsa = True
    return None


@metodo_oggetto(Cronometro, "azzera")
def cronometro_azzera(c):
    """cronometro.azzera(): riporta il cronometro a 0 e lo fa ripartire."""
    c.accumulato = 0.0
    c.inizio = time.perf_counter()
    c.in_corsa = True
    return None


@funzione_libreria("misura_tempo", interprete=True)
def misura_tempo(interprete, funzione):
    """misura_tempo(funzione): esegue la funzione (senza argomenti) e dice quanti secondi ci ha messo.

    Esempio: `stampa(misura_tempo(funzione () restituisci somma(1..1000000) fine))`.
    """
    f = richiedi_funzione(funzione, "misura_tempo")
    inizio = time.perf_counter()
    chiama_funzione(interprete, f, [])
    return round(time.perf_counter() - inizio, 6)
