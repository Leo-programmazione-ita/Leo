"""Libreria: assoluto, arrotonda, radice, minimo, massimo, somma, casuale, PI_GRECO.

``GENERATORE`` è il generatore di numeri casuali usato da ``casuale``: i test
(e chi vuole risultati ripetibili) possono fare ``GENERATORE.seed(...)``.
"""

from __future__ import annotations

import math
import random
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation, localcontext
from typing import Any

from ..errori import ErroreTipo, ErroreValore
from ..registro import costante
from ..valori import e_numero, rappresenta
from .generali import (articolo, funzione_libreria, lunghezza_intervallo, richiedi_intero,
                       richiedi_numero, tipi, tutti_numeri)

#: Generatore dei numeri casuali di ``casuale`` (``GENERATORE.seed(n)`` per ripetere).
GENERATORE = random.Random()

costante("PI_GRECO", math.pi)


def _troppo_grande() -> ErroreValore:
    return ErroreValore("Il risultato è troppo grande per essere calcolato.")


@funzione_libreria("assoluto")
def assoluto(x):
    """assoluto(x): il valore del numero senza segno.

    Esempi: `assoluto(-5)` è 5, `assoluto(3.2)` è 3.2.
    """
    t = type(x)
    if t is int or t is float:  # via veloce
        return abs(x)
    richiedi_numero(x, "assoluto", "x")
    return abs(x)


@funzione_libreria("arrotonda")
def arrotonda(x, cifre=0):
    """arrotonda(x, cifre = 0): arrotonda il numero; a metà strada va lontano dallo zero.

    Senza `cifre` restituisce un intero: `arrotonda(2.5)` è 3, `arrotonda(-2.5)` è -3.
    Con `cifre` tiene quel numero di cifre dopo la virgola: `arrotonda(3.14159, 2)` è 3.14.
    """
    richiedi_numero(x, "arrotonda", "x")
    richiedi_intero(cifre, "arrotonda", "cifre")
    if cifre < 0:
        raise ErroreValore(f"Le `cifre` di `arrotonda` non possono essere negative (hai scritto {cifre}).",
                           suggerimento="Scrivi quante cifre vuoi dopo la virgola: 0, 1, 2...")
    if isinstance(x, float) and (math.isnan(x) or math.isinf(x)):
        raise ErroreValore(f"Non posso arrotondare {rappresenta(x)}.")
    if isinstance(x, int):
        if cifre == 0:
            return x
        try:
            return float(x)
        except OverflowError:
            raise _troppo_grande() from None
    if cifre > 400:  # nessun decimale ha così tante cifre dopo la virgola
        return x
    # repr() dà il decimale più corto che rappresenta x: 2.675 resta 2.675 (non 2.67499...)
    valore = Decimal(repr(x))
    with localcontext() as ctx:
        ctx.prec = max(28, valore.adjusted() + cifre + 10)
        try:
            arrotondato = valore.quantize(Decimal(1).scaleb(-cifre), rounding=ROUND_HALF_UP)
        except InvalidOperation:  # pragma: no cover - precisione già adeguata
            raise _troppo_grande() from None
    if cifre == 0:
        return int(arrotondato)
    return float(arrotondato)


@funzione_libreria("radice")
def radice(x):
    """radice(x): la radice quadrata del numero (sempre un decimale).

    Esempio: `radice(16)` è 4.0. Il numero non può essere negativo.
    """
    t = type(x)
    if (t is float and x >= 0.0) or (t is int and x >= 0 and x.bit_length() <= 1000):
        return math.sqrt(x)  # via veloce (i casi speciali li controlla il resto)
    richiedi_numero(x, "radice", "x")
    if x < 0:
        raise ErroreValore(f"Non esiste la radice quadrata di un numero negativo ({rappresenta(x)}).",
                           suggerimento="Forse ti serve `radice(assoluto(x))`.")
    if isinstance(x, int):
        if x.bit_length() > 1000:
            radice_intera = math.isqrt(x)
            try:
                return float(radice_intera)
            except OverflowError:
                raise _troppo_grande() from None
        return math.sqrt(x)
    if math.isnan(x):
        raise ErroreValore("Non posso calcolare la radice di `non_numero`.")
    return math.sqrt(x)


def _due_numeri(a: Any, b: Any) -> bool:
    """Via veloce di `minimo(a, b)`/`massimo(a, b)`: due interi, o un decimale vero
    (non `non_numero`) e un numero piccolo."""
    ta = type(a)
    tb = type(b)
    if ta is int and tb is int:
        return True
    return ((ta is float or ta is int) and (tb is float or tb is int) and a == a and b == b
            and -2 ** 53 < a < 2 ** 53 and -2 ** 53 < b < 2 ** 53)


def _elementi_confrontabili(nome: str, valori: tuple) -> tuple[list[Any] | range, str]:
    """Gli elementi tra cui cercare minimo o massimo e il loro "genere" ("numeri"/"testi")."""
    if len(valori) == 0:
        raise ErroreTipo(f"`{nome}` vuole una lista oppure almeno due valori.",
                         suggerimento=f"Esempi: `{nome}(voti)` oppure `{nome}(3, 7)`.")
    if len(valori) == 1:
        unico = valori[0]
        if isinstance(unico, range):
            if lunghezza_intervallo(unico) == 0:
                raise ErroreValore(f"`{nome}` di un intervallo vuoto non esiste.")
            return unico, "numeri"
        if not isinstance(unico, list):
            raise ErroreTipo(f"Con un solo argomento `{nome}` vuole una lista, non {articolo(unico)}.",
                             suggerimento=f"Per confrontare dei valori scrivili tutti: `{nome}(a, b)`.")
        elementi = unico
        if not elementi:
            raise ErroreValore(f"`{nome}` di una lista vuota non esiste.",
                               suggerimento="Controlla prima con `se non vuota(lista) allora`.")
    else:
        elementi = list(valori)
    presenti = tipi(elementi)
    if presenti == {str}:
        return elementi, "testi"
    if tutti_numeri(elementi):
        if float in presenti and any(v != v for v in elementi):
            raise ErroreValore(f"`{nome}` non può confrontare `non_numero`.")
        return elementi, "numeri"
    for v in elementi:
        if not e_numero(v) and not isinstance(v, str):
            raise ErroreTipo(f"`{nome}` confronta solo numeri o testi, non {articolo(v)}.")
    raise ErroreTipo(f"`{nome}` non può confrontare numeri e testi insieme.",
                     suggerimento="Usa valori tutti dello stesso tipo: o tutti numeri o tutti testi.")


@funzione_libreria("minimo")
def minimo(*valori):
    """minimo(lista) oppure minimo(a, b, ...): il valore più piccolo.

    Funziona con numeri o con testi (in ordine alfabetico), non mescolati.
    Esempi: `minimo([4, 2, 9])` è 2, `minimo(3, 7)` è 3.
    """
    if len(valori) == 2 and _due_numeri(valori[0], valori[1]):
        return min(valori)
    elementi, _ = _elementi_confrontabili("minimo", valori)
    if isinstance(elementi, range):
        return min(elementi[0], elementi[-1])
    try:
        return min(elementi)
    except OverflowError:  # pragma: no cover - interi enormi contro decimali
        raise _troppo_grande() from None


@funzione_libreria("massimo")
def massimo(*valori):
    """massimo(lista) oppure massimo(a, b, ...): il valore più grande.

    Funziona con numeri o con testi (in ordine alfabetico), non mescolati.
    Esempi: `massimo([28, 30, 24])` è 30, `massimo(3, 7)` è 7.
    """
    if len(valori) == 2 and _due_numeri(valori[0], valori[1]):
        return max(valori)
    elementi, _ = _elementi_confrontabili("massimo", valori)
    if isinstance(elementi, range):
        return max(elementi[0], elementi[-1])
    try:
        return max(elementi)
    except OverflowError:  # pragma: no cover
        raise _troppo_grande() from None


@funzione_libreria("somma")
def somma(lista):
    """somma(lista): la somma dei numeri di una lista o di un intervallo (0 se è vuota).

    Esempi: `somma([1, 2, 3])` è 6, `somma(1..100)` è 5050.
    """
    if isinstance(lista, range):
        n = lunghezza_intervallo(lista)
        if n == 0:
            return 0
        return n * (lista[0] + lista[-1]) // 2
    if not isinstance(lista, list):
        raise ErroreTipo(f"`somma` vuole una lista di numeri, non {articolo(lista)}.",
                         suggerimento="Per sommare due numeri usa `+`: `a + b`." if e_numero(lista) else None)
    presenti = tipi(lista)
    if not presenti <= {int, float}:
        for v in lista:
            if not e_numero(v):
                suggerimento = None
                if isinstance(v, str):
                    suggerimento = "Per unire dei testi usa `\"\".unisci(lista)`."
                raise ErroreTipo(f"`somma` somma solo numeri, ma nella lista c'è {articolo(v)}.",
                                 suggerimento=suggerimento)
    if float in presenti or not presenti <= {int, float}:
        try:
            return math.fsum(lista)  # somma precisa, senza errori di arrotondamento accumulati
        except (OverflowError, ValueError):  # infiniti o interi enormi: somma semplice
            pass
    try:
        return sum(lista)
    except OverflowError:
        raise _troppo_grande() from None


@funzione_libreria("casuale")
def casuale(da, a):
    """casuale(da, a): un numero intero a caso tra `da` e `a`, estremi compresi.

    Esempio: `casuale(1, 6)` è come lanciare un dado.
    """
    richiedi_intero(da, "casuale", "da")
    richiedi_intero(a, "casuale", "a")
    if da > a:
        raise ErroreValore(f"In `casuale(da, a)` il primo numero non può essere più grande del secondo "
                           f"(hai scritto {da} e {a}).",
                           suggerimento=f"Scrivi `casuale({a}, {da})`.")
    return GENERATORE.randint(da, a)
