"""Libreria: date e orari all'italiana.

Il tipo ``data`` (una data con, se serve, l'ora) si crea con ``data(...)`` o
``adesso()``; si stampa come ``25/09/2026`` (o ``25/09/2026 14:30:00`` se ha
un orario). ``giorno``, ``mese``, ``anno``, ``ore``, ``minuti``,
``secondi``, ``nome_giorno``, ``nome_mese``, ``giorno_settimana``,
``fine_settimana`` sono *proprietà* (si leggono senza parentesi: ``d.giorno``);
``aggiungi``, ``aggiungi_giorni``, ``formato``, ``in_lettere``, ``prima_di``,
``dopo_di``, ``uguale_a`` sono *metodi* (``d.aggiungi_giorni(3)``).
Funzioni: ``data``, ``adesso``, ``giorni_tra``, ``nome_giorno``, ``nome_mese``.
"""

from __future__ import annotations

import datetime
import re
from typing import Any

from ..errori import ErroreTipo, ErroreValore
from .generali import articolo, funzione_libreria, mostra, richiedi_intero, richiedi_numero, richiedi_testo
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta

GIORNI = ["lunedì", "martedì", "mercoledì", "giovedì", "venerdì", "sabato", "domenica"]
MESI = ["gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio", "agosto",
        "settembre", "ottobre", "novembre", "dicembre"]


class DataDante(OggettoLibreria):
    """Valore Leo di tipo ``data`` (immutabile)."""

    NOME_TIPO_DANTE = "data"
    SUGGERIMENTO_MODIFICA = "Crea una data nuova, per esempio con `d = d.aggiungi_giorni(1)`."

    def __init__(self, valore: datetime.datetime) -> None:
        self.valore = valore

    @property
    def ha_orario(self) -> bool:
        v = self.valore
        return bool(v.hour or v.minute or v.second)

    def testo_dante(self) -> str:
        # niente strftime: con gli anni prima del 1000 "%Y" dipende dal sistema
        # (Linux scrive "5", Windows "0005") e il testo non si rileggerebbe con data(...)
        v = self.valore
        testo = f"{v.day:02d}/{v.month:02d}/{v.year:04d}"
        if self.ha_orario:
            testo += f" {v.hour:02d}:{v.minute:02d}:{v.second:02d}"
        return testo

    def __eq__(self, altra: object) -> bool:
        return isinstance(altra, DataDante) and altra.valore == self.valore

    def __hash__(self) -> int:
        return hash(self.valore)

    def __repr__(self) -> str:  # utile nei test
        return f"DataDante({self.testo_dante()})"


_RE_ITALIANA = re.compile(r"^\s*(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})(?:[ T,]+(\d{1,2})[:.](\d{2})(?:[:.](\d{2}))?)?\s*$")
_RE_ISO = re.compile(r"^\s*(\d{4})-(\d{1,2})-(\d{1,2})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?\s*$")


def _costruisci(anno: int, mese: int, giorno: int, ore: int = 0, minuti: int = 0, secondi: int = 0) -> DataDante:
    if not 1 <= mese <= 12:
        raise ErroreValore(f"Il mese deve essere un numero da 1 a 12, non {mese}.")
    if not 1 <= anno <= 9999:
        raise ErroreValore(f"L'anno deve essere tra 1 e 9999, non {anno}.")
    try:
        return DataDante(datetime.datetime(anno, mese, giorno, ore, minuti, secondi))
    except (ValueError, OverflowError):
        pass
    if not 0 <= ore <= 23:
        raise ErroreValore(f"Le ore devono andare da 0 a 23, non {ore}.")
    if not 0 <= minuti <= 59 or not 0 <= secondi <= 59:
        raise ErroreValore("Minuti e secondi devono andare da 0 a 59.")
    import calendar
    ultimo = calendar.monthrange(anno, mese)[1]
    raise ErroreValore(f"Il giorno {giorno} non esiste a {MESI[mese - 1]} {anno}: "
                       f"quel mese ha {ultimo} giorni.")


def _da_testo(testo: str) -> DataDante:
    for regola, italiana in ((_RE_ITALIANA, True), (_RE_ISO, False)):
        m = regola.match(testo)
        if m:
            numeri = [int(g) if g else 0 for g in m.groups()]
            if italiana:
                g, me, a = numeri[:3]
            else:
                a, me, g = numeri[:3]
            return _costruisci(a, me, g, *numeri[3:])
    raise ErroreValore(f"Non capisco la data {mostra(testo)}.",
                       suggerimento="Scrivila come \"25/09/2026\", \"25/09/2026 14:30\" o \"2026-09-25\".")


def richiedi_data(valore: Any, nome_funzione: str, parametro: str) -> DataDante:
    """Una ``DataDante`` da una data o da un testo come "25/09/2026"."""
    if isinstance(valore, DataDante):
        return valore
    if isinstance(valore, str):
        return _da_testo(valore)
    raise ErroreTipo(f"L'argomento `{parametro}` di `{nome_funzione}` deve essere una data, non {articolo(valore)}.",
                     suggerimento="Crea una data con `data(2026, 9, 25)` o `data(\"25/09/2026\")`.")


@funzione_libreria("data")
def data(anno=None, mese=None, giorno=None, ore=0, minuti=0, secondi=0):
    """data(anno, mese, giorno, ore = 0, minuti = 0, secondi = 0): crea una data.

    Esempi: `data(2026, 9, 25)`, `data(2026, 12, 25, ore = 20)`, `data("25/09/2026")`,
    `data("25/09/2026 14:30")`. Senza argomenti è la data di oggi (a mezzanotte).
    """
    if anno is None and mese is None and giorno is None:
        oggi = datetime.date.today()
        return DataDante(datetime.datetime(oggi.year, oggi.month, oggi.day))
    if isinstance(anno, str) and mese is None and giorno is None:
        return _da_testo(anno)
    if isinstance(anno, DataDante) and mese is None and giorno is None:
        return anno
    if mese is None or giorno is None:
        raise ErroreTipo("`data` vuole anno, mese e giorno (per esempio `data(2026, 9, 25)`), "
                         "oppure un testo come `data(\"25/09/2026\")`.")
    numeri = []
    for nome, v in (("anno", anno), ("mese", mese), ("giorno", giorno),
                    ("ore", ore), ("minuti", minuti), ("secondi", secondi)):
        numeri.append(richiedi_intero(v, "data", nome))
    return _costruisci(*numeri)


@funzione_libreria("adesso")
def adesso():
    """adesso(): la data e l'ora di questo momento.

    Esempio: `stampa(adesso().formato("hh:mm"))` scrive per esempio "14:30".
    """
    return DataDante(datetime.datetime.now().replace(microsecond=0))


@funzione_libreria("giorni_tra")
def giorni_tra(prima, dopo):
    """giorni_tra(prima, dopo): quanti giorni passano da una data all'altra (negativo se `dopo` viene prima).

    Esempio: `giorni_tra(data(2026, 9, 25), data(2026, 12, 25))` è 91. Accetta anche testi:
    `giorni_tra(oggi(), "25/12/2026")`.
    """
    a = richiedi_data(prima, "giorni_tra", "prima").valore.date()
    b = richiedi_data(dopo, "giorni_tra", "dopo").valore.date()
    return (b - a).days


@funzione_libreria("nome_giorno")
def nome_giorno(numero):
    """nome_giorno(numero): il nome del giorno della settimana, da 1 (lunedì) a 7 (domenica).

    Esempio: `nome_giorno(5)` è "venerdì". Si può passare anche una data.
    """
    if isinstance(numero, (DataDante, str)):
        return GIORNI[richiedi_data(numero, "nome_giorno", "numero").valore.weekday()]
    richiedi_intero(numero, "nome_giorno", "numero")
    if not 1 <= numero <= 7:
        raise ErroreValore(f"I giorni della settimana vanno da 1 (lunedì) a 7 (domenica), non {numero}.")
    return GIORNI[numero - 1]


@funzione_libreria("nome_mese")
def nome_mese(numero):
    """nome_mese(numero): il nome del mese, da 1 (gennaio) a 12 (dicembre).

    Esempio: `nome_mese(9)` è "settembre". Si può passare anche una data.
    """
    if isinstance(numero, (DataDante, str)):
        return MESI[richiedi_data(numero, "nome_mese", "numero").valore.month - 1]
    richiedi_intero(numero, "nome_mese", "numero")
    if not 1 <= numero <= 12:
        raise ErroreValore(f"I mesi vanno da 1 (gennaio) a 12 (dicembre), non {numero}.")
    return MESI[numero - 1]


# ---------------------------------------------------------------------------
# Metodi del tipo data
# ---------------------------------------------------------------------------

def _parte(nome: str, lettore) -> None:
    proprieta(DataDante, nome)(lettore)


_parte("giorno", lambda d: d.valore.day)                          # 1..31
_parte("mese", lambda d: d.valore.month)                          # 1..12
_parte("anno", lambda d: d.valore.year)
_parte("ore", lambda d: d.valore.hour)
_parte("minuti", lambda d: d.valore.minute)
_parte("secondi", lambda d: d.valore.second)
_parte("nome_giorno", lambda d: GIORNI[d.valore.weekday()])       # "venerdì"
_parte("nome_mese", lambda d: MESI[d.valore.month - 1])           # "settembre"
_parte("giorno_settimana", lambda d: d.valore.isoweekday())       # 1 = lunedì ... 7 = domenica
_parte("fine_settimana", lambda d: d.valore.weekday() >= 5)       # sabato o domenica


def _sposta(d: DataDante, delta: datetime.timedelta) -> DataDante:
    try:
        return DataDante(d.valore + delta)
    except OverflowError:
        raise ErroreValore("La data risultante è fuori dal calendario (anni da 1 a 9999).") from None


@metodo_oggetto(DataDante, "aggiungi_giorni")
def data_aggiungi_giorni(d, giorni):
    """data.aggiungi_giorni(giorni): una nuova data spostata di tanti giorni (negativi = indietro).

    Esempio: `data(2026, 12, 31).aggiungi_giorni(1)` è 01/01/2027.
    """
    richiedi_intero(giorni, "aggiungi_giorni", "giorni")
    if abs(giorni) > 4_000_000:  # oltre 10000 anni: timedelta darebbe OverflowError
        raise ErroreValore("La data risultante è fuori dal calendario (anni da 1 a 9999).")
    return _sposta(d, datetime.timedelta(days=giorni))


@metodo_oggetto(DataDante, "aggiungi")
def data_aggiungi(d, giorni=0, ore=0, minuti=0, secondi=0):
    """data.aggiungi(giorni = 0, ore = 0, minuti = 0, secondi = 0): una nuova data spostata in avanti.

    Esempio: `adesso().aggiungi(ore = 2, minuti = 30)`. Con numeri negativi va indietro.
    """
    for nome, v in (("giorni", giorni), ("ore", ore), ("minuti", minuti), ("secondi", secondi)):
        richiedi_numero(v, "aggiungi", nome)
        if v != v:
            raise ErroreValore(f"Non posso spostare una data di `non_numero` {nome}.")
    try:
        delta = datetime.timedelta(days=giorni, hours=ore, minutes=minuti, seconds=secondi)
    except (OverflowError, ValueError):
        raise ErroreValore("Lo spostamento è troppo grande.") from None
    return _sposta(d, delta)


_SEGNAPOSTI = re.compile(r"AAAA|AA|MESE|MM|GIORNO|GG|hh|mm|ss")


@metodo_oggetto(DataDante, "formato")
def data_formato(d, modello):
    """data.formato(modello): la data scritta secondo un modello.

    Segnaposti: `GG` giorno, `MM` mese, `AAAA` anno (`AA` le ultime due cifre), `hh` ore,
    `mm` minuti, `ss` secondi, `GIORNO` nome del giorno, `MESE` nome del mese.
    Esempio: `data(2026, 9, 25).formato("GIORNO GG MESE AAAA")` è "venerdì 25 settembre 2026".
    """
    richiedi_testo(modello, "formato", "modello")
    v = d.valore
    valori = {"AAAA": f"{v.year:04d}", "AA": f"{v.year % 100:02d}", "MM": f"{v.month:02d}",
              "GG": f"{v.day:02d}", "hh": f"{v.hour:02d}", "mm": f"{v.minute:02d}",
              "ss": f"{v.second:02d}", "GIORNO": GIORNI[v.weekday()], "MESE": MESI[v.month - 1]}
    return _SEGNAPOSTI.sub(lambda m: valori[m.group(0)], modello)


@metodo_oggetto(DataDante, "in_lettere")
def data_in_lettere(d):
    """data.in_lettere(): la data scritta per esteso, per esempio "venerdì 25 settembre 2026"."""
    v = d.valore
    testo = f"{GIORNI[v.weekday()]} {v.day} {MESI[v.month - 1]} {v.year}"
    if d.ha_orario:
        testo += f" alle {v.hour:02d}:{v.minute:02d}"
    return testo


@metodo_oggetto(DataDante, "prima_di")
def data_prima_di(d, altra):
    """data.prima_di(altra): `vero` se questa data viene prima dell'altra."""
    return d.valore < richiedi_data(altra, "prima_di", "altra").valore


@metodo_oggetto(DataDante, "dopo_di")
def data_dopo_di(d, altra):
    """data.dopo_di(altra): `vero` se questa data viene dopo l'altra."""
    return d.valore > richiedi_data(altra, "dopo_di", "altra").valore


@metodo_oggetto(DataDante, "uguale_a")
def data_uguale_a(d, altra):
    """data.uguale_a(altra): `vero` se le due date (con l'orario) coincidono."""
    return d.valore == richiedi_data(altra, "uguale_a", "altra").valore
