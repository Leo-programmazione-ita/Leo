"""Libreria: immagini e foto (aprire, modificare, disegnare, salvare, EXIF, GIF, arte ASCII).

Un'immagine è un valore Leo di tipo ``immagine``: si apre da un file
(``apri_immagine("gatto.jpg")``), si crea vuota (``nuova_immagine(200, 100, "azzurro")``)
o da una lista di righe di colori (``immagine_da_pixel``). I suoi **metodi
cambiano l'immagine stessa e la restituiscono**, così si possono mettere in fila::

    variabile foto = apri_immagine("gatto.jpg")
    foto.ridimensiona(800).bianco_e_nero().scrivi_testo("Micio", 20, 20, "giallo", 48)
    foto.salva("gatto_bn.jpg", qualita = 85)

Per tenere l'originale si lavora su ``foto.copia()``.

Le **coordinate** partono dall'angolo in alto a sinistra: ``x`` va verso destra,
``y`` verso il basso (come nelle finestre). I **colori** si scrivono come nel
resto di Leo: ``"rosso"``, ``"#FF8800"``, ``"#FF880080"`` (con trasparenza),
``[255, 136, 0]`` o ``[255, 136, 0, 128]``.

**Dipendenze.** Con Pillow (``pip install pillow``, c'è anche su Android con
Chaquopy) funziona tutto: JPEG, WebP, GIF, filtri, testo, EXIF. Senza Pillow Leo
usa un ripiego scritto in Python puro che legge e scrive PNG e BMP e fa le cose
semplici (pixel, ritagli, capovolgimenti, rotazioni di 90 gradi, ridimensionamenti,
colori, forme, collage, arte ASCII); per il resto spiega come installare Pillow.
``dimensioni_immagine`` legge PNG, JPEG, GIF, BMP e WebP sempre senza Pillow.
``LEO_IMMAGINI_SENZA_PILLOW=1`` forza il ripiego (serve ai test).
"""

from __future__ import annotations

import functools
import math
import os
import struct
import zlib
from typing import Any, Callable

from .. import variabile_ambiente
from ..errori import ErroreDante, ErroreFile, ErroreTipo, ErroreValore
from ..valori import e_numero, rappresenta
from .generali import articolo, funzione_libreria, mostra
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta

#: Lato massimo e numero massimo di pixel di un'immagine creata o ingrandita da Leo.
LATO_MASSIMO = 20000
PIXEL_MASSIMI = 80_000_000
#: Estensioni che Leo sa scrivere e il formato di Pillow corrispondente.
FORMATI = {"png": "PNG", "jpg": "JPEG", "jpeg": "JPEG", "webp": "WEBP", "gif": "GIF", "bmp": "BMP",
           "tif": "TIFF", "tiff": "TIFF", "ico": "ICO"}
#: Estensioni riconosciute come foto da ``converti_immagini``.
ESTENSIONI_FOTO = (".png", ".jpg", ".jpeg", ".webp", ".gif", ".bmp", ".tif", ".tiff")
#: Caratteri dell'arte ASCII, dal più chiaro al più scuro.
CARATTERI_ASCII = " .:-=+*#%@"

_SUGG_PILLOW = ("Installa Pillow con `pip install pillow` (sul telefono è già nella app di Leo). "
                "Senza Pillow Leo sa aprire e salvare solo PNG e BMP.")


# ===========================================================================
# 1. Pillow facoltativo
# ===========================================================================

_PIL: Any = False  # False = non ancora cercato, None = assente


def pillow() -> Any:
    """Il modulo ``PIL`` (con Image, ImageOps, ... già importati) o ``None`` se manca."""
    global _PIL
    if (variabile_ambiente("IMMAGINI_SENZA_PILLOW") or "").strip() in ("1", "si", "sì", "vero"):
        return None
    if _PIL is False:
        try:
            import PIL
            from PIL import (Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter,  # noqa: F401
                             ImageFont, ImageOps, ImageStat)
            Image.MAX_IMAGE_PIXELS = PIXEL_MASSIMI
            _PIL = PIL
        except ImportError:
            _PIL = None
    return _PIL


def _serve_pillow(cosa: str) -> ErroreValore:
    return ErroreValore(f"Per {cosa} serve Pillow, che qui non è installato.", suggerimento=_SUGG_PILLOW)


# ===========================================================================
# 2. Ripiego in Python puro: pixel RGBA, PNG e BMP
# ===========================================================================

class Pixel:
    """Immagine RGBA in un ``bytearray`` (4 byte per pixel, riga dopo riga)."""

    def __init__(self, larghezza: int, altezza: int, colore: tuple = (0, 0, 0, 0),
                 dati: bytearray | None = None) -> None:
        self.w, self.h = larghezza, altezza
        self.dati = dati if dati is not None else bytearray(bytes(colore) * (larghezza * altezza))

    @property
    def size(self) -> tuple[int, int]:
        return self.w, self.h

    def prendi(self, x: int, y: int) -> tuple:
        i = (y * self.w + x) * 4
        return tuple(self.dati[i:i + 4])

    def metti(self, x: int, y: int, c: tuple) -> None:
        if 0 <= x < self.w and 0 <= y < self.h:
            i = (y * self.w + x) * 4
            if c[3] == 255 or self.dati[i + 3] == 0:
                self.dati[i:i + 4] = bytes(c)
            elif c[3]:
                self.dati[i:i + 4] = bytes(_fondi(self.prendi(x, y), c))

    def copia(self) -> "Pixel":
        return Pixel(self.w, self.h, dati=bytearray(self.dati))

    copy = copia  # stessa interfaccia di Pillow per le copie

    def righe(self) -> list[bytes]:
        passo = self.w * 4
        return [bytes(self.dati[y * passo:(y + 1) * passo]) for y in range(self.h)]

    def ritaglia(self, x0: int, y0: int, x1: int, y1: int) -> "Pixel":
        nuovo = Pixel(x1 - x0, y1 - y0)
        passo = (x1 - x0) * 4
        for y in range(y0, y1):
            i = (y * self.w + x0) * 4
            j = (y - y0) * passo
            nuovo.dati[j:j + passo] = self.dati[i:i + passo]
        return nuovo

    def capovolgi(self, orizzontale: bool) -> "Pixel":
        righe = self.righe()
        if orizzontale:
            righe = [b"".join(r[i:i + 4] for i in range(len(r) - 4, -1, -4)) for r in righe]
        else:
            righe.reverse()
        return Pixel(self.w, self.h, dati=bytearray(b"".join(righe)))

    def ruota_orario(self) -> "Pixel":
        nuovo = Pixel(self.h, self.w)
        for y in range(self.h):
            for x in range(self.w):
                i = (y * self.w + x) * 4
                j = (x * self.h + (self.h - 1 - y)) * 4
                nuovo.dati[j:j + 4] = self.dati[i:i + 4]
        return nuovo

    def ridimensiona(self, w: int, h: int) -> "Pixel":
        nuovo = Pixel(w, h)
        colonne = [min(self.w - 1, int((x + 0.5) * self.w / w)) * 4 for x in range(w)]
        for y in range(h):
            sy = min(self.h - 1, int((y + 0.5) * self.h / h))
            base = sy * self.w * 4
            riga = self.dati[base:base + self.w * 4]
            nuovo.dati[y * w * 4:(y + 1) * w * 4] = b"".join(bytes(riga[c:c + 4]) for c in colonne)
        return nuovo

    def mappa(self, f: Callable[[int, int, int], tuple]) -> None:
        memo: dict = {}
        d = self.dati
        for i in range(0, len(d), 4):
            chiave = (d[i], d[i + 1], d[i + 2])
            nuovo = memo.get(chiave)
            if nuovo is None:
                nuovo = memo[chiave] = tuple(max(0, min(255, int(round(v)))) for v in f(*chiave))
            d[i], d[i + 1], d[i + 2] = nuovo

    def incolla(self, altro: "Pixel", x0: int, y0: int, opacita: float = 1.0) -> None:
        for y in range(altro.h):
            for x in range(altro.w):
                c = altro.prendi(x, y)
                if opacita < 1:
                    c = c[:3] + (int(c[3] * opacita),)
                self.metti(x0 + x, y0 + y, c)

    def rettangolo(self, x0: int, y0: int, x1: int, y1: int, c: tuple) -> None:
        for y in range(max(0, y0), min(self.h, y1 + 1)):
            for x in range(max(0, x0), min(self.w, x1 + 1)):
                self.metti(x, y, c)

    def linea(self, x0: int, y0: int, x1: int, y1: int, c: tuple, spessore: int = 1) -> None:
        dx, dy = abs(x1 - x0), -abs(y1 - y0)
        sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
        err = dx + dy
        r = (spessore - 1) // 2
        while True:
            if r:
                self.rettangolo(x0 - r, y0 - r, x0 + r, y0 + r, c)
            else:
                self.metti(x0, y0, c)
            if x0 == x1 and y0 == y1:
                return
            e2 = 2 * err
            if e2 >= dy:
                err += dy
                x0 += sx
            if e2 <= dx:
                err += dx
                y0 += sy

    def ellisse(self, cx: float, cy: float, rx: float, ry: float, c: tuple, pieno: bool, spessore: int) -> None:
        if rx <= 0 or ry <= 0:
            return
        for y in range(max(0, int(cy - ry)), min(self.h, int(cy + ry) + 1)):
            for x in range(max(0, int(cx - rx)), min(self.w, int(cx + rx) + 1)):
                d = ((x - cx) / rx) ** 2 + ((y - cy) / ry) ** 2
                if d <= 1 and (pieno or d >= ((max(rx, ry) - spessore) / max(rx, ry)) ** 2):
                    self.metti(x, y, c)


def _fondi(sotto: tuple, sopra: tuple) -> tuple:
    """Colore di ``sopra`` (con trasparenza) appoggiato su ``sotto``."""
    a = sopra[3] / 255
    b = sotto[3] / 255 * (1 - a)
    tot = a + b
    if tot <= 0:
        return (0, 0, 0, 0)
    return tuple(int(round((sopra[k] * a + sotto[k] * b) / tot)) for k in range(3)) + (int(round(tot * 255)),)


def _blocco_png(tipo: bytes, dati: bytes) -> bytes:
    return struct.pack(">I", len(dati)) + tipo + dati + struct.pack(">I", zlib.crc32(tipo + dati) & 0xFFFFFFFF)


def png_da_pixel(p: Pixel) -> bytes:
    """Byte di un file PNG RGBA (8 bit) dai pixel."""
    grezzi = b"".join(b"\x00" + r for r in p.righe())
    return (b"\x89PNG\r\n\x1a\n"
            + _blocco_png(b"IHDR", struct.pack(">IIBBBBB", p.w, p.h, 8, 6, 0, 0, 0))
            + _blocco_png(b"IDAT", zlib.compress(grezzi, 6))
            + _blocco_png(b"IEND", b""))


def bmp_da_pixel(p: Pixel) -> bytes:
    """Byte di un file BMP a 24 bit (senza trasparenza) dai pixel."""
    riga = (p.w * 3 + 3) & ~3
    corpo = bytearray()
    for y in range(p.h - 1, -1, -1):
        base = y * p.w * 4
        r = bytearray()
        for x in range(p.w):
            i = base + x * 4
            r += bytes((p.dati[i + 2], p.dati[i + 1], p.dati[i]))
        corpo += r + b"\x00" * (riga - len(r))
    testa = struct.pack("<2sIHHI", b"BM", 54 + len(corpo), 0, 0, 54)
    info = struct.pack("<IiiHHIIiiII", 40, p.w, p.h, 1, 24, 0, len(corpo), 2835, 2835, 0, 0)
    return testa + info + bytes(corpo)


class FormatoNonLetto(ValueError):
    """Il ripiego puro non sa leggere questo file (serve Pillow)."""


def _paeth(a: int, b: int, c: int) -> int:
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    return b if pb <= pc else c


def leggi_png(dati: bytes) -> Pixel:
    """Pixel di un PNG a 8 bit non interlacciato (grigio, RGB, tavolozza, con o senza trasparenza)."""
    if dati[:8] != b"\x89PNG\r\n\x1a\n":
        raise FormatoNonLetto("non è un PNG")
    pos, idat, tavolozza, trasp = 8, bytearray(), b"", b""
    w = h = profondita = tipo = interlacciato = 0
    while pos + 8 <= len(dati):
        lung, nome = struct.unpack(">I4s", dati[pos:pos + 8])
        corpo = dati[pos + 8:pos + 8 + lung]
        pos += 12 + lung
        if nome == b"IHDR":
            w, h, profondita, tipo, _, _, interlacciato = struct.unpack(">IIBBBBB", corpo[:13])
        elif nome == b"PLTE":
            tavolozza = corpo
        elif nome == b"tRNS":
            trasp = corpo
        elif nome == b"IDAT":
            idat += corpo
        elif nome == b"IEND":
            break
    canali = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}.get(tipo)
    if profondita != 8 or interlacciato or canali is None or not w or not h:
        raise FormatoNonLetto("PNG particolare")
    if w * h > PIXEL_MASSIMI:
        raise FormatoNonLetto("troppo grande")
    grezzi = zlib.decompress(bytes(idat))
    passo = w * canali
    prima = bytearray(passo)
    p = Pixel(w, h)
    pos = 0
    for y in range(h):
        filtro = grezzi[pos]
        riga = bytearray(grezzi[pos + 1:pos + 1 + passo])
        pos += 1 + passo
        for i in range(passo):
            a = riga[i - canali] if i >= canali else 0
            b = prima[i]
            if filtro == 1:
                riga[i] = (riga[i] + a) & 255
            elif filtro == 2:
                riga[i] = (riga[i] + b) & 255
            elif filtro == 3:
                riga[i] = (riga[i] + ((a + b) >> 1)) & 255
            elif filtro == 4:
                riga[i] = (riga[i] + _paeth(a, b, prima[i - canali] if i >= canali else 0)) & 255
        prima = riga
        out = bytearray()
        for x in range(w):
            v = riga[x * canali:(x + 1) * canali]
            if tipo == 6:
                out += v
            elif tipo == 2:
                out += v + b"\xff"
            elif tipo == 0:
                out += bytes((v[0], v[0], v[0], 255))
            elif tipo == 4:
                out += bytes((v[0], v[0], v[0], v[1]))
            else:
                k = v[0]
                out += tavolozza[k * 3:k * 3 + 3] + bytes((trasp[k] if k < len(trasp) else 255,))
        p.dati[y * w * 4:(y + 1) * w * 4] = out
    return p


def leggi_bmp(dati: bytes) -> Pixel:
    """Pixel di un BMP non compresso a 24 o 32 bit."""
    if dati[:2] != b"BM" or len(dati) < 54:
        raise FormatoNonLetto("non è un BMP")
    inizio = struct.unpack("<I", dati[10:14])[0]
    w, h, _, bit, compressione = struct.unpack("<iiHHI", dati[18:34])
    if bit not in (24, 32) or compressione not in (0, 3) or w <= 0 or h == 0:
        raise FormatoNonLetto("BMP particolare")
    dal_basso = h > 0
    h = abs(h)
    if w * h > PIXEL_MASSIMI:
        raise FormatoNonLetto("troppo grande")
    byte = bit // 8
    riga = (w * byte + 3) & ~3
    p = Pixel(w, h)
    for y in range(h):
        base = inizio + (h - 1 - y if dal_basso else y) * riga
        for x in range(w):
            i = base + x * byte
            b, g, r = dati[i], dati[i + 1], dati[i + 2]
            a = dati[i + 3] if byte == 4 and compressione == 3 else 255
            j = (y * w + x) * 4
            p.dati[j:j + 4] = bytes((r, g, b, a))
    return p


def dimensioni_da_byte(dati: bytes) -> tuple[str, int, int] | None:
    """(formato, larghezza, altezza) leggendo solo l'inizio di un file PNG, JPEG, GIF, BMP o WebP."""
    if dati[:8] == b"\x89PNG\r\n\x1a\n" and len(dati) >= 24:
        w, h = struct.unpack(">II", dati[16:24])
        return "png", w, h
    if dati[:6] in (b"GIF87a", b"GIF89a") and len(dati) >= 10:
        w, h = struct.unpack("<HH", dati[6:10])
        return "gif", w, h
    if dati[:2] == b"BM" and len(dati) >= 26:
        w, h = struct.unpack("<ii", dati[18:26])
        return "bmp", w, abs(h)
    if dati[:4] == b"RIFF" and dati[8:12] == b"WEBP" and len(dati) >= 30:
        tipo = dati[12:16]
        if tipo == b"VP8X":
            w = 1 + int.from_bytes(dati[24:27], "little")
            h = 1 + int.from_bytes(dati[27:30], "little")
            return "webp", w, h
        if tipo == b"VP8L":
            b = int.from_bytes(dati[21:25], "little")
            return "webp", (b & 0x3FFF) + 1, ((b >> 14) & 0x3FFF) + 1
        if tipo == b"VP8 ":
            w, h = struct.unpack("<HH", dati[26:30])
            return "webp", w & 0x3FFF, h & 0x3FFF
    if dati[:2] == b"\xff\xd8":
        pos = 2
        while pos + 9 < len(dati):
            if dati[pos] != 0xFF:
                pos += 1
                continue
            marca = dati[pos + 1]
            if marca in (0xD8, 0x01) or 0xD0 <= marca <= 0xD7 or marca == 0xFF:
                pos += 1 if marca == 0xFF else 2
                continue
            lung = struct.unpack(">H", dati[pos + 2:pos + 4])[0]
            if marca in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                h, w = struct.unpack(">HH", dati[pos + 5:pos + 9])
                return "jpeg", w, h
            pos += 2 + lung
    return None


# ===========================================================================
# 3. Controlli degli argomenti
# ===========================================================================

def _intero(v: Any, funzione: str, parametro: str, minimo: int | None = None, massimo: int | None = None) -> int:
    if isinstance(v, bool) or not e_numero(v):
        raise ErroreTipo(f"`{parametro}` di `{funzione}` deve essere un numero, non {articolo(v)}.")
    if isinstance(v, float) and not math.isfinite(v):
        raise ErroreValore(f"`{parametro}` di `{funzione}` deve essere un numero normale, non {mostra(v)}.")
    n = int(round(v))
    if (minimo is not None and n < minimo) or (massimo is not None and n > massimo):
        limiti = (f"tra {minimo} e {massimo}" if minimo is not None and massimo is not None
                  else f"almeno {minimo}" if minimo is not None else f"al massimo {massimo}")
        raise ErroreValore(f"`{parametro}` di `{funzione}` deve essere {limiti}, non {mostra(v)}.")
    return n


def _numero(v: Any, funzione: str, parametro: str, minimo: float | None = None,
            massimo: float | None = None, esempio: str | None = None) -> float:
    if isinstance(v, bool) or not e_numero(v):
        raise ErroreTipo(f"`{parametro}` di `{funzione}` deve essere un numero, non {articolo(v)}.",
                         suggerimento=esempio)
    try:
        x = float(v)
    except OverflowError:
        x = math.inf
    if not math.isfinite(x) or (minimo is not None and x < minimo) or (massimo is not None and x > massimo):
        limiti = (f"tra {rappresenta(minimo)} e {rappresenta(massimo)}" if minimo is not None and massimo is not None
                  else f"almeno {rappresenta(minimo)}" if minimo is not None else "un numero normale")
        raise ErroreValore(f"`{parametro}` di `{funzione}` deve essere {limiti}, non {mostra(v)}.",
                           suggerimento=esempio)
    return x


def _logico(v: Any, funzione: str, parametro: str) -> bool:
    if not isinstance(v, bool):
        raise ErroreTipo(f"`{parametro}` di `{funzione}` vuole `vero` o `falso`, non {articolo(v)}.")
    return v


def _lato(v: Any, funzione: str, parametro: str) -> int:
    return _intero(v, funzione, parametro, 1, LATO_MASSIMO)


def _controlla_area(w: int, h: int, funzione: str) -> None:
    if w * h > PIXEL_MASSIMI:
        raise ErroreValore(f"L'immagine di `{funzione}` sarebbe troppo grande ({w} x {h} pixel).",
                           suggerimento=f"Il massimo è {PIXEL_MASSIMI // 1_000_000} milioni di pixel.")


def colore_rgba(v: Any, funzione: str = "", parametro: str = "colore") -> tuple[int, int, int, int]:
    """(r, g, b, a) da un nome italiano, ``#RRGGBB[AA]`` o una lista di 3-4 numeri."""
    esempio = "Per esempio \"rosso\", \"#FF8800\" o [255, 136, 0]."
    dove = f"`{parametro}` di `{funzione}`" if funzione else "Il colore"
    if isinstance(v, list):
        if len(v) in (3, 4) and all(e_numero(c) and not isinstance(c, bool) for c in v):
            try:
                valori = [int(round(c)) for c in v]
            except (OverflowError, ValueError):
                valori = [-1]
            if all(0 <= c <= 255 for c in valori):
                return tuple(valori + [255] * (4 - len(valori)))  # type: ignore[return-value]
        raise ErroreValore(f"{dove} come lista vuole 3 o 4 numeri da 0 a 255: [rosso, verde, blu].",
                           suggerimento=esempio)
    if not isinstance(v, str):
        raise ErroreTipo(f"{dove} deve essere un colore, non {articolo(v)}.", suggerimento=esempio)
    from ..grafica.colori import da_esadecimale, normalizza_colore

    try:
        esa = normalizza_colore(v)
    except ErroreDante as e:
        raise ErroreValore(e.messaggio, suggerimento=e.suggerimento or esempio) from None
    if not esa:
        raise ErroreValore(f"{dove} è vuoto.", suggerimento=esempio)
    return da_esadecimale(esa)


def esadecimale(c: tuple) -> str:
    base = "#{:02X}{:02X}{:02X}".format(*c[:3])
    return base if len(c) < 4 or c[3] == 255 else base + f"{c[3]:02X}"


def _percorso(v: Any, funzione: str, esempio: str = "foto.png") -> str:
    if not isinstance(v, str):
        raise ErroreTipo(f"Il percorso di `{funzione}` deve essere un testo, non {articolo(v)}.",
                         suggerimento=f"Per esempio \"{esempio}\".")
    if not v.strip() or "\0" in v:
        raise ErroreValore(f"Il nome del file di `{funzione}` è vuoto o non valido.",
                           suggerimento=f"Per esempio \"{esempio}\".")
    return os.path.expanduser(v.strip())


def _estensione(percorso: str, funzione: str) -> str:
    est = os.path.splitext(percorso)[1].lower().lstrip(".")
    if est not in FORMATI:
        raise ErroreValore(f"Non so salvare immagini `.{est}`." if est else
                           f"Il file di `{funzione}` non ha l'estensione (.png, .jpg...).",
                           suggerimento="Usa .png, .jpg, .webp, .gif o .bmp alla fine del nome.")
    return est


def _errore_file(e: OSError, percorso: str) -> ErroreFile:
    if isinstance(e, FileNotFoundError):
        return ErroreFile(f"Il file `{percorso}` non esiste.", suggerimento="Controlla il nome e la cartella.")
    if isinstance(e, PermissionError):
        return ErroreFile(f"Non ho il permesso di usare `{percorso}`.",
                          suggerimento="Scegli un'altra cartella o chiudi il programma che lo usa.")
    return ErroreFile(f"Non riesco a usare `{percorso}`: {e.strerror or e}.")


def _sicuro(azione: str) -> Callable:
    """Trasforma gli errori di Pillow o del sistema in errori Leo italiani."""

    def decora(f: Callable) -> Callable:
        @functools.wraps(f)
        def avvolta(*a: Any, **k: Any) -> Any:
            try:
                return f(*a, **k)
            except ErroreDante:
                raise
            except MemoryError:
                raise ErroreValore(f"Memoria finita mentre provavo a {azione}.",
                                   suggerimento="Usa immagini più piccole.") from None
            except FileNotFoundError as e:
                raise _errore_file(e, e.filename or "") from None
            except (OSError, ValueError, SyntaxError, EOFError, zlib.error, struct.error) as e:
                raise ErroreValore(f"Non sono riuscito a {azione}: {e}.",
                                   suggerimento="Controlla che il file sia un'immagine valida.") from None
        return avvolta

    return decora


# ===========================================================================
# 4. Il valore `immagine`
# ===========================================================================

class Immagine(OggettoLibreria):
    """Valore Leo di tipo ``immagine``: un'immagine di Pillow (RGB/RGBA) o di :class:`Pixel`."""

    NOME_TIPO_DANTE = "immagine"
    SUGGERIMENTO_MODIFICA = ("Le proprietà di un'immagine si leggono soltanto: per cambiarla usa i metodi, "
                             "per esempio `ridimensiona(200)` o `ruota(90)`.")

    def __init__(self, im: Any, nome: str = "", formato: str = "") -> None:
        self.im = im
        self.nome_file = nome
        self.formato = formato

    @property
    def e_pura(self) -> bool:
        return isinstance(self.im, Pixel)

    @property
    def dimensioni(self) -> tuple[int, int]:
        return tuple(self.im.size)  # type: ignore[return-value]

    def testo_dante(self) -> str:
        w, h = self.dimensioni
        nome = f" {self.nome_file}" if self.nome_file else ""
        return f"<immagine{nome} {w}x{h}>"

    def pil(self, cosa: str) -> Any:
        """L'immagine di Pillow, oppure un errore chiaro se si usa il ripiego."""
        if self.e_pura:
            raise _serve_pillow(cosa)
        return self.im

    def pixel_rgba(self, lato: int = 0) -> tuple[int, int, list[tuple]]:
        """(w, h, pixel RGBA) di una copia rimpicciolita al massimo a ``lato`` (0 = com'è)."""
        w, h = self.dimensioni
        if lato and max(w, h) > lato:
            s = lato / max(w, h)
            w, h = max(1, round(w * s)), max(1, round(h * s))
        if self.e_pura:
            p = self.im if (w, h) == self.dimensioni else self.im.ridimensiona(w, h)
            d = p.dati
            return w, h, [tuple(d[i:i + 4]) for i in range(0, len(d), 4)]
        im = self.im if (w, h) == self.dimensioni else self.im.resize((w, h), pillow().Image.Resampling.BOX)
        d = im.convert("RGBA").tobytes()
        return w, h, [tuple(d[i:i + 4]) for i in range(0, len(d), 4)]


def _da_pil(im: Any, nome: str = "", formato: str = "") -> Immagine:
    if im.mode not in ("RGB", "RGBA"):
        trasparente = "A" in im.getbands() or "transparency" in im.info
        im = im.convert("RGBA" if trasparente else "RGB")
    return Immagine(im, nome, formato)


def _immagine(v: Any, funzione: str, parametro: str = "immagine") -> Immagine:
    if isinstance(v, Immagine):
        return v
    if isinstance(v, str):
        return apri_immagine(v)
    raise ErroreTipo(f"`{parametro}` di `{funzione}` deve essere un'immagine o il nome di un file, "
                     f"non {articolo(v)}.", suggerimento="Per esempio `apri_immagine(\"gatto.jpg\")`.")


def _nuova(w: int, h: int, c: tuple) -> Any:
    PIL = pillow()
    if PIL is None:
        return Pixel(w, h, c)
    return PIL.Image.new("RGBA" if c[3] < 255 else "RGB", (w, h), c if c[3] < 255 else c[:3])


def _su_rgb(im: Any, f: Callable[[Any], Any]) -> Any:
    """Applica ``f`` alla parte RGB e rimette la trasparenza."""
    if im.mode == "RGBA":
        alfa = im.getchannel("A")
        nuova = f(im.convert("RGB")).convert("RGBA")
        nuova.putalpha(alfa)
        return nuova
    return f(im)


# ===========================================================================
# 5. Funzioni Leo
# ===========================================================================

@funzione_libreria("apri_immagine")
@_sicuro("aprire l'immagine")
def apri_immagine(percorso):
    """apri_immagine(percorso): apre una foto o un disegno (PNG, JPEG, GIF, WebP, BMP...) come immagine.

    Le foto del telefono vengono raddrizzate da sole. Esempio:
    `variabile foto = apri_immagine("gatto.jpg")` e poi `stampa(foto.larghezza)`.
    """
    p = _percorso(percorso, "apri_immagine")
    if os.path.isdir(p):
        raise ErroreFile(f"`{p}` è una cartella, non un'immagine.",
                         suggerimento="Per lavorare su tutte le foto di una cartella usa `converti_immagini`.")
    try:
        with open(p, "rb") as f:
            dati = f.read()
    except OSError as e:
        raise _errore_file(e, p) from None
    nome = os.path.basename(p)
    PIL = pillow()
    if PIL is None:
        try:
            if dati[:2] == b"BM":
                return Immagine(leggi_bmp(dati), nome, "bmp")
            return Immagine(leggi_png(dati), nome, "png")
        except FormatoNonLetto:
            raise _serve_pillow(f"aprire `{nome}`") from None
    import io
    try:
        im = PIL.Image.open(io.BytesIO(dati))
        formato = (im.format or "").lower()
        im = PIL.ImageOps.exif_transpose(im)
        im.load()
    except PIL.UnidentifiedImageError:
        raise ErroreValore(f"`{nome}` non è un'immagine che so aprire.",
                           suggerimento="Leo apre PNG, JPEG, GIF, WebP, BMP e TIFF.") from None
    except PIL.Image.DecompressionBombError:
        raise ErroreValore(f"`{nome}` è troppo grande da aprire.",
                           suggerimento=f"Il massimo è {PIXEL_MASSIMI // 1_000_000} milioni di pixel.") from None
    return _da_pil(im, nome, "jpeg" if formato == "mpo" else formato)


@funzione_libreria("nuova_immagine")
def nuova_immagine(larghezza, altezza, colore="bianco"):
    """nuova_immagine(larghezza, altezza, colore = "bianco"): un'immagine nuova tutta di un colore.

    Serve come foglio su cui disegnare. `"trasparente"` la fa trasparente (da salvare in PNG).
    Esempio: `variabile cartolina = nuova_immagine(400, 300, "azzurro")`.
    """
    w, h = _lato(larghezza, "nuova_immagine", "larghezza"), _lato(altezza, "nuova_immagine", "altezza")
    _controlla_area(w, h, "nuova_immagine")
    return Immagine(_nuova(w, h, colore_rgba(colore, "nuova_immagine")))


@funzione_libreria("immagine_da_pixel")
def immagine_da_pixel(righe, lato=1):
    """immagine_da_pixel(righe, lato = 1): disegno a quadretti da una lista di righe di colori.

    Ogni riga è una lista di colori; `nulla` lascia il quadretto trasparente.
    `lato` è quanti pixel è grande ogni quadretto.
    Esempio: `immagine_da_pixel([["rosso", "bianco"], ["bianco", "rosso"]], lato = 20)`.
    """
    if not isinstance(righe, list) or not righe or not all(isinstance(r, list) and r for r in righe):
        raise ErroreTipo("`righe` di `immagine_da_pixel` deve essere una lista di righe, e ogni riga "
                         "una lista di colori.", suggerimento="Per esempio [[\"rosso\", \"blu\"], [\"blu\", \"rosso\"]].")
    q = _intero(lato, "immagine_da_pixel", "lato", 1, 500)
    w, h = max(len(r) for r in righe), len(righe)
    _controlla_area(w * q, h * q, "immagine_da_pixel")
    memo: dict = {}
    p = Pixel(w, h)
    for y, riga in enumerate(righe):
        for x, c in enumerate(riga):
            if c is None:
                continue
            chiave = c if isinstance(c, str) else repr(c)
            if chiave not in memo:
                memo[chiave] = colore_rgba(c, "immagine_da_pixel", f"riga {y + 1}, colonna {x + 1}")
            i = (y * w + x) * 4
            p.dati[i:i + 4] = bytes(memo[chiave])
    if q > 1:
        p = p.ridimensiona(w * q, h * q)
    return _da_pixel(p)


def _da_pixel(p: Pixel) -> Immagine:
    PIL = pillow()
    if PIL is None:
        return Immagine(p)
    return Immagine(PIL.Image.frombytes("RGBA", p.size, bytes(p.dati)))


@funzione_libreria("dimensioni_immagine")
@_sicuro("leggere le dimensioni dell'immagine")
def dimensioni_immagine(percorso):
    """dimensioni_immagine(percorso): [larghezza, altezza] di un file immagine, senza aprirlo tutto.

    Funziona con PNG, JPEG, GIF, BMP e WebP anche senza Pillow.
    Esempio: `variabile misure = dimensioni_immagine("foto.jpg")`.
    """
    p = _percorso(percorso, "dimensioni_immagine")
    try:
        with open(p, "rb") as f:
            testa = f.read(64 * 1024)
    except OSError as e:
        raise _errore_file(e, p) from None
    trovate = dimensioni_da_byte(testa)
    if trovate is None and pillow() is not None:
        with pillow().Image.open(p) as im:
            return list(im.size)
    if trovate is None:
        raise ErroreValore(f"Non riconosco `{os.path.basename(p)}` come immagine.",
                           suggerimento="Leo riconosce PNG, JPEG, GIF, BMP e WebP.")
    return [trovate[1], trovate[2]]


def _lista_immagini(v: Any, funzione: str, minimo: int = 1) -> list[Immagine]:
    if not isinstance(v, list) or len(v) < minimo:
        raise ErroreTipo(f"`{funzione}` vuole una lista di immagini (o di nomi di file)"
                         + (f" con almeno {minimo} elementi" if minimo > 1 else "") + f", non {mostra(v)}.",
                         suggerimento="Per esempio [\"foto1.jpg\", \"foto2.jpg\"].")
    if len(v) > 1000:
        raise ErroreValore(f"`{funzione}` accetta al massimo 1000 immagini.")
    return [_immagine(e, funzione, "immagini") for e in v]


@funzione_libreria("collage")
@_sicuro("fare il collage")
def collage(immagini, colonne=None, lato=200, spazio=10, sfondo="bianco"):
    """collage(immagini, colonne = nulla, lato = 200, spazio = 10, sfondo = "bianco"): foto in una griglia.

    Ogni foto entra in un quadrato di `lato` pixel; senza `colonne` la griglia è quasi quadrata.
    Esempio: `collage(["mare.jpg", "monti.jpg", "lago.jpg"], colonne = 3).salva("vacanze.jpg")`.
    """
    lista = _lista_immagini(immagini, "collage")
    q = _intero(lato, "collage", "lato", 8, 4000)
    s = _intero(spazio, "collage", "spazio", 0, 1000)
    n = len(lista)
    c = math.ceil(math.sqrt(n)) if colonne is None else _intero(colonne, "collage", "colonne", 1, 1000)
    r = math.ceil(n / c)
    w, h = c * q + (c + 1) * s, r * q + (r + 1) * s
    _controlla_area(w, h, "collage")
    foglio = nuova_immagine(w, h, sfondo)
    for i, foto in enumerate(lista):
        piccola = foto.copia_interna()
        _metodo_miniatura(piccola, q)
        pw, ph = piccola.dimensioni
        x = s + (i % c) * (q + s) + (q - pw) // 2
        y = s + (i // c) * (q + s) + (q - ph) // 2
        _incolla(foglio, piccola, x, y, 1.0)
    return foglio


@funzione_libreria("gif_animata")
@_sicuro("creare la GIF animata")
def gif_animata(immagini, percorso, durata=0.5, ripeti=True):
    """gif_animata(immagini, percorso, durata = 0.5, ripeti = vero): salva un'animazione GIF.

    `durata` è quanti secondi resta ogni fotogramma; tutte prendono le misure della prima.
    Esempio: `gif_animata(["passo1.png", "passo2.png", "passo3.png"], "cammina.gif", 0.2)`.
    """
    lista = _lista_immagini(immagini, "gif_animata")
    p = _percorso(percorso, "gif_animata", "animazione.gif")
    if not p.lower().endswith(".gif"):
        raise ErroreValore("Il file di `gif_animata` deve finire con .gif.", suggerimento="Per esempio \"cammina.gif\".")
    d = _numero(durata, "gif_animata", "durata", 0.02, 60, "Per esempio 0.5 (mezzo secondo).")
    giro = _logico(ripeti, "gif_animata", "ripeti")
    fotogrammi = [f.pil("creare una GIF animata") for f in lista]
    misura = fotogrammi[0].size
    pronti = []
    for im in fotogrammi:
        if im.size != misura:
            im = im.resize(misura, pillow().Image.Resampling.LANCZOS)
        pronti.append(im.convert("RGBA").quantize(255) if im.mode == "RGBA" else im.convert("RGB"))
    extra = {"loop": 0} if giro else {}
    try:
        pronti[0].save(p, save_all=True, append_images=pronti[1:], duration=int(d * 1000), disposal=2, **extra)
    except OSError as e:
        raise _errore_file(e, p) from None
    return p


@funzione_libreria("fotogrammi_gif")
@_sicuro("leggere la GIF")
def fotogrammi_gif(percorso):
    """fotogrammi_gif(percorso): la lista delle immagini (fotogrammi) di una GIF animata.

    Esempio: `per ogni f in fotogrammi_gif("cammina.gif") fai f.salva("fotogramma.png") fine`.
    """
    p = _percorso(percorso, "fotogrammi_gif", "animazione.gif")
    PIL = pillow()
    if PIL is None:
        raise _serve_pillow("leggere le GIF")
    try:
        im = PIL.Image.open(p)
    except OSError as e:
        raise (_errore_file(e, p) if isinstance(e, (FileNotFoundError, PermissionError)) else
               ErroreValore(f"`{os.path.basename(p)}` non è un'immagine che so aprire.")) from None
    risultato = []
    with im:
        for i in range(getattr(im, "n_frames", 1)):
            if i >= 1000:
                break
            im.seek(i)
            risultato.append(_da_pil(im.convert("RGBA"), f"{os.path.basename(p)}#{i + 1}", "gif"))
    return risultato


@funzione_libreria("differenza_immagini")
@_sicuro("confrontare le immagini")
def differenza_immagini(prima, seconda):
    """differenza_immagini(prima, seconda): quanto sono diverse due immagini, da 0 (uguali) a 100.

    Se hanno misure diverse la seconda viene adattata alla prima.
    Esempio: `se differenza_immagini("prima.png", "dopo.png") > 5 allora stampa("È cambiato qualcosa!") fine`.
    """
    a = _immagine(prima, "differenza_immagini", "prima")
    b = _immagine(seconda, "differenza_immagini", "seconda")
    if not a.e_pura and not b.e_pura:
        PIL = pillow()
        ia, ib = a.im.convert("RGBA"), b.im.convert("RGBA")
        if ib.size != ia.size:
            ib = ib.resize(ia.size, PIL.Image.Resampling.BILINEAR)
        diff = PIL.ImageChops.difference(ia, ib)
        media = sum(PIL.ImageStat.Stat(diff).mean) / 4
        return round(media / 255 * 100, 2)
    lato = max(a.dimensioni)
    w, h, pa = a.pixel_rgba(min(lato, 256))
    b2 = b.copia_interna()
    b2.im = b2.im.ridimensiona(w, h) if b2.e_pura else b2.im.resize((w, h))
    _, _, pb = b2.pixel_rgba()
    totale = sum(abs(x - y) for p, q in zip(pa, pb) for x, y in zip(p, q))
    return round(totale / (len(pa) * 4 * 255) * 100, 2)


@funzione_libreria("converti_immagini")
@_sicuro("convertire le immagini")
def converti_immagini(cartella, destinazione, formato="jpg", lato_massimo=None, qualita=85):
    """converti_immagini(cartella, destinazione, formato = "jpg", lato_massimo = nulla, qualita = 85): tutte le foto.

    Converte ogni foto di `cartella` nel `formato` e la mette in `destinazione`; con `lato_massimo`
    le rimpicciolisce. Restituisce la lista dei file creati.
    Esempio: `converti_immagini("vacanze", "vacanze_piccole", "jpg", lato_massimo = 1280)`.
    """
    sorgente = _percorso(cartella, "converti_immagini", "vacanze")
    arrivo = _percorso(destinazione, "converti_immagini", "vacanze_piccole")
    if not isinstance(formato, str):
        raise ErroreTipo(f"`formato` di `converti_immagini` deve essere un testo, non {articolo(formato)}.")
    est = formato.strip().lower().lstrip(".")
    _estensione("x." + est, "converti_immagini")
    lato = None if lato_massimo is None else _lato(lato_massimo, "converti_immagini", "lato_massimo")
    _qualita(qualita, "converti_immagini")
    if not os.path.isdir(sorgente):
        raise ErroreFile(f"La cartella `{sorgente}` non esiste.", suggerimento="Controlla il nome della cartella.")
    if os.path.abspath(sorgente) == os.path.abspath(arrivo):
        raise ErroreValore("In `converti_immagini` la destinazione deve essere un'altra cartella.",
                           suggerimento="Così le foto originali restano come sono.")
    os.makedirs(arrivo, exist_ok=True)
    creati = []
    for nome in sorted(os.listdir(sorgente)):
        origine = os.path.join(sorgente, nome)
        if not os.path.isfile(origine) or not nome.lower().endswith(ESTENSIONI_FOTO):
            continue
        foto = apri_immagine(origine)
        if lato is not None:
            _metodo_miniatura(foto, lato)
        nuovo = os.path.join(arrivo, os.path.splitext(nome)[0] + "." + est)
        _salva(foto, nuovo, qualita, "converti_immagini")
        creati.append(nuovo)
    return creati


# leggi_exif e togli_exif stanno nella libreria binario (pure, senza Pillow, senza ricomprimere la foto).


@funzione_libreria("immagine_ascii")
@_sicuro("fare l'arte ASCII")
def immagine_ascii(immagine, larghezza=60, caratteri=CARATTERI_ASCII):
    """immagine_ascii(immagine, larghezza = 60, caratteri = " .:-=+*#%@"): l'immagine disegnata con le lettere.

    Restituisce un testo da stampare nel terminale; i caratteri vanno dal più chiaro al più scuro.
    Esempio: `stampa(immagine_ascii("gatto.jpg", 50))`.
    """
    foto = _immagine(immagine, "immagine_ascii")
    colonne = _intero(larghezza, "immagine_ascii", "larghezza", 4, 400)
    if not isinstance(caratteri, str) or len(caratteri) < 2:
        raise ErroreValore("`caratteri` di `immagine_ascii` vuole un testo di almeno 2 caratteri.",
                           suggerimento=f"Per esempio \"{CARATTERI_ASCII}\".")
    w, h = foto.dimensioni
    righe_n = max(1, round(h / w * colonne * 0.5))
    copia = foto.copia_interna()
    copia.im = copia.im.ridimensiona(colonne, righe_n) if copia.e_pura else \
        copia.im.convert("RGBA").resize((colonne, righe_n), pillow().Image.Resampling.BOX)
    _, _, pixel = copia.pixel_rgba()
    n = len(caratteri) - 1
    righe = []
    for y in range(righe_n):
        riga = []
        for x in range(colonne):
            r, g, b, a = pixel[y * colonne + x]
            chiaro = (0.299 * r + 0.587 * g + 0.114 * b) * a / 255 + 255 * (1 - a / 255)
            riga.append(caratteri[round((1 - chiaro / 255) * n)])
        righe.append("".join(riga).rstrip())
    return "\n".join(righe)


# ===========================================================================
# 6. Proprietà e metodi del valore `immagine`
# ===========================================================================

proprieta(Immagine, "larghezza")(lambda i: i.dimensioni[0])
proprieta(Immagine, "altezza")(lambda i: i.dimensioni[1])
proprieta(Immagine, "dimensioni")(lambda i: list(i.dimensioni))
proprieta(Immagine, "formato")(lambda i: i.formato)
proprieta(Immagine, "nome")(lambda i: i.nome_file)
proprieta(Immagine, "trasparente")(lambda i: i.e_pura or i.im.mode == "RGBA")


def _copia_interna(self: Immagine) -> Immagine:
    return Immagine(self.im.copy(), self.nome_file, self.formato)


Immagine.copia_interna = _copia_interna  # type: ignore[attr-defined]


def _qualita(v: Any, funzione: str) -> int:
    return _intero(v, funzione, "qualita", 1, 100)


def _salva(img: Immagine, percorso: str, qualita: Any, funzione: str) -> str:
    est = _estensione(percorso, funzione)
    q = _qualita(qualita, funzione)
    cartella = os.path.dirname(percorso)
    if cartella and not os.path.isdir(cartella):
        raise ErroreFile(f"La cartella `{cartella}` non esiste.", suggerimento="Creala prima o scegli un'altra cartella.")
    if img.e_pura:
        if est == "png":
            dati = png_da_pixel(img.im)
        elif est == "bmp":
            dati = bmp_da_pixel(img.im)
        else:
            raise _serve_pillow(f"salvare in formato .{est}")
        try:
            with open(percorso, "wb") as f:
                f.write(dati)
        except OSError as e:
            raise _errore_file(e, percorso) from None
        return percorso
    im = img.im
    formato = FORMATI[est]
    extra: dict = {}
    if formato in ("JPEG", "BMP") and im.mode == "RGBA":
        fondo = pillow().Image.new("RGB", im.size, (255, 255, 255))
        fondo.paste(im, mask=im.getchannel("A"))
        im = fondo
    if formato == "JPEG":
        extra = {"quality": q, "optimize": True}
    elif formato == "WEBP":
        extra = {"quality": q}
    elif formato == "PNG":
        extra = {"optimize": q >= 90}
    elif formato == "ICO":
        lato = min(256, min(im.size))
        extra = {"sizes": [(lato, lato)]}
    try:
        im.save(percorso, formato, **extra)
    except OSError as e:
        if isinstance(e, (FileNotFoundError, PermissionError, IsADirectoryError)):
            raise _errore_file(e, percorso) from None
        raise
    return percorso


@metodo_oggetto(Immagine, "salva")
@_sicuro("salvare l'immagine")
def immagine_salva(img, percorso, qualita=90):
    """immagine.salva(percorso, qualita = 90): scrive l'immagine in un file; il formato viene dall'estensione.

    .png, .jpg, .webp, .gif, .bmp, .tiff, .ico. `qualita` (1-100) conta per JPEG e WebP:
    più bassa = file più piccolo. Esempio: `foto.salva("piccola.jpg", qualita = 70)`.
    """
    return _salva(img, _percorso(percorso, "salva"), qualita, "salva")


@metodo_oggetto(Immagine, "copia")
def immagine_copia(img):
    """immagine.copia(): un'immagine nuova uguale a questa, da modificare senza toccare l'originale.

    Esempio: `variabile piccola = foto.copia().miniatura(100)`.
    """
    return img.copia_interna()


def _metodo_ridimensiona(img: Immagine, w: int, h: int, liscio: bool = True) -> Immagine:
    _controlla_area(w, h, "ridimensiona")
    if img.e_pura:
        img.im = img.im.ridimensiona(w, h)
    else:
        R = pillow().Image.Resampling
        img.im = img.im.resize((w, h), R.LANCZOS if liscio else R.NEAREST)
    return img


@metodo_oggetto(Immagine, "ridimensiona")
@_sicuro("ridimensionare l'immagine")
def immagine_ridimensiona(img, larghezza, altezza=None, liscio=True):
    """immagine.ridimensiona(larghezza, altezza = nulla, liscio = vero): cambia le misure.

    Senza `altezza` (o con `larghezza = nulla`) mantiene le proporzioni. `liscio = falso` tiene i
    quadretti netti (per il pixel art). Esempio: `foto.ridimensiona(800)`, `icona.ridimensiona(64, 64)`.
    """
    w0, h0 = img.dimensioni
    liscio = _logico(liscio, "ridimensiona", "liscio")
    if larghezza is None and altezza is None:
        raise ErroreValore("`ridimensiona` vuole almeno la larghezza o l'altezza.",
                           suggerimento="Per esempio `foto.ridimensiona(800)`.")
    if altezza is None:
        w = _lato(larghezza, "ridimensiona", "larghezza")
        h = max(1, round(h0 * w / w0))
    elif larghezza is None:
        h = _lato(altezza, "ridimensiona", "altezza")
        w = max(1, round(w0 * h / h0))
    else:
        w, h = _lato(larghezza, "ridimensiona", "larghezza"), _lato(altezza, "ridimensiona", "altezza")
    if w > LATO_MASSIMO or h > LATO_MASSIMO:
        raise ErroreValore(f"Con queste proporzioni l'immagine diventerebbe {w} x {h} pixel: troppo grande.")
    return _metodo_ridimensiona(img, w, h, liscio)


def _metodo_miniatura(img: Immagine, lato: int) -> Immagine:
    w, h = img.dimensioni
    if max(w, h) <= lato:
        return img
    s = lato / max(w, h)
    return _metodo_ridimensiona(img, max(1, round(w * s)), max(1, round(h * s)))


@metodo_oggetto(Immagine, "miniatura")
@_sicuro("fare la miniatura")
def immagine_miniatura(img, lato=128):
    """immagine.miniatura(lato = 128): rimpicciolisce l'immagine perché entri in un quadrato di `lato` pixel.

    Mantiene le proporzioni e non ingrandisce mai. Esempio: `apri_immagine("foto.jpg").miniatura(200).salva("mini.jpg")`.
    """
    return _metodo_miniatura(img, _lato(lato, "miniatura", "lato"))


@metodo_oggetto(Immagine, "ritaglia")
@_sicuro("ritagliare l'immagine")
def immagine_ritaglia(img, x, y, larghezza, altezza):
    """immagine.ritaglia(x, y, larghezza, altezza): tiene solo il rettangolo che parte da (x, y).

    Esempio: `foto.ritaglia(100, 50, 300, 300)` tiene un quadrato di 300 pixel.
    """
    W, H = img.dimensioni
    x0, y0 = _intero(x, "ritaglia", "x"), _intero(y, "ritaglia", "y")
    w, h = _lato(larghezza, "ritaglia", "larghezza"), _lato(altezza, "ritaglia", "altezza")
    x0, y0, x1, y1 = max(0, x0), max(0, y0), min(W, x0 + w), min(H, y0 + h)
    if x1 <= x0 or y1 <= y0:
        raise ErroreValore(f"Il rettangolo di `ritaglia` è fuori dall'immagine ({W} x {H} pixel).",
                           suggerimento="x e y partono da 0 in alto a sinistra.")
    img.im = img.im.ritaglia(x0, y0, x1, y1) if img.e_pura else img.im.crop((x0, y0, x1, y1))
    return img


@metodo_oggetto(Immagine, "ruota")
@_sicuro("ruotare l'immagine")
def immagine_ruota(img, gradi, sfondo="trasparente"):
    """immagine.ruota(gradi, sfondo = "trasparente"): gira l'immagine in senso orario (come l'orologio).

    Con angoli non multipli di 90 l'immagine si allarga e gli angoli si riempiono con `sfondo`.
    Esempio: `foto.ruota(90)`, `foto.ruota(-45, "bianco")`.
    """
    g = _numero(gradi, "ruota", "gradi", -3600, 3600, "Per esempio 90 (senso orario) o -90.") % 360
    c = colore_rgba(sfondo, "ruota", "sfondo")
    if img.e_pura:
        if g % 90:
            raise _serve_pillow("ruotare di angoli che non sono multipli di 90")
        for _ in range(int(g // 90)):
            img.im = img.im.ruota_orario()
        return img
    im = img.im
    if g % 90 == 0:
        T = pillow().Image.Transpose
        img.im = {0: im, 90: im.transpose(T.ROTATE_270), 180: im.transpose(T.ROTATE_180),
                  270: im.transpose(T.ROTATE_90)}[int(g)]
        return img
    if c[3] < 255 and im.mode != "RGBA":
        im = im.convert("RGBA")
    img.im = im.rotate(-g, pillow().Image.Resampling.BICUBIC, expand=True,
                       fillcolor=c if im.mode == "RGBA" else c[:3])
    return img


@metodo_oggetto(Immagine, "capovolgi")
@_sicuro("capovolgere l'immagine")
def immagine_capovolgi(img, direzione="orizzontale"):
    """immagine.capovolgi(direzione = "orizzontale"): specchia l'immagine ("orizzontale" o "verticale").

    Orizzontale scambia destra e sinistra (come uno specchio), verticale alto e basso.
    Esempio: `foto.capovolgi()`, `foto.capovolgi("verticale")`.
    """
    if not isinstance(direzione, str) or direzione.strip().lower() not in ("orizzontale", "verticale"):
        raise ErroreValore(f"`direzione` di `capovolgi` è \"orizzontale\" o \"verticale\", non {mostra(direzione)}.")
    orizz = direzione.strip().lower() == "orizzontale"
    if img.e_pura:
        img.im = img.im.capovolgi(orizz)
    else:
        T = pillow().Image.Transpose
        img.im = img.im.transpose(T.FLIP_LEFT_RIGHT if orizz else T.FLIP_TOP_BOTTOM)
    return img


def _grigio(r: int, g: int, b: int) -> tuple:
    v = 0.299 * r + 0.587 * g + 0.114 * b
    return v, v, v


@metodo_oggetto(Immagine, "bianco_e_nero")
@_sicuro("fare il bianco e nero")
def immagine_bianco_e_nero(img):
    """immagine.bianco_e_nero(): toglie i colori e lascia i grigi.

    Esempio: `apri_immagine("nonna.jpg").bianco_e_nero().salva("nonna_bn.jpg")`.
    """
    if img.e_pura:
        img.im.mappa(_grigio)
    else:
        img.im = _su_rgb(img.im, lambda im: im.convert("L").convert("RGB"))
    return img


def _seppia(r: int, g: int, b: int) -> tuple:
    return (0.393 * r + 0.769 * g + 0.189 * b, 0.349 * r + 0.686 * g + 0.168 * b, 0.272 * r + 0.534 * g + 0.131 * b)


@metodo_oggetto(Immagine, "seppia")
@_sicuro("fare l'effetto seppia")
def immagine_seppia(img):
    """immagine.seppia(): colori marroncini come nelle foto antiche.

    Esempio: `foto.seppia().salva("antica.jpg")`.
    """
    if img.e_pura:
        img.im.mappa(_seppia)
    else:
        matrice = (0.393, 0.769, 0.189, 0, 0.349, 0.686, 0.168, 0, 0.272, 0.534, 0.131, 0)
        img.im = _su_rgb(img.im, lambda im: im.convert("RGB", matrice))
    return img


@metodo_oggetto(Immagine, "negativo")
@_sicuro("fare il negativo")
def immagine_negativo(img):
    """immagine.negativo(): scambia chiari e scuri e ogni colore con il suo opposto.

    Esempio: `foto.negativo()`.
    """
    if img.e_pura:
        img.im.mappa(lambda r, g, b: (255 - r, 255 - g, 255 - b))
    else:
        img.im = _su_rgb(img.im, pillow().ImageOps.invert)
    return img


def _fattore(v: Any, funzione: str) -> float:
    return _numero(v, funzione, "fattore", 0, 20, "1 lascia com'è, 1.5 aumenta del 50%, 0.5 dimezza.")


@metodo_oggetto(Immagine, "luminosita")
@_sicuro("cambiare la luminosità")
def immagine_luminosita(img, fattore):
    """immagine.luminosita(fattore): schiarisce (più di 1) o scurisce (meno di 1) l'immagine.

    1 la lascia com'è, 1.5 è più chiara del 50%, 0.5 è scura a metà. Esempio: `foto.luminosita(1.3)`.
    """
    f = _fattore(fattore, "luminosita")
    if img.e_pura:
        img.im.mappa(lambda r, g, b: (r * f, g * f, b * f))
    else:
        img.im = _su_rgb(img.im, lambda im: pillow().ImageEnhance.Brightness(im).enhance(f))
    return img


@metodo_oggetto(Immagine, "contrasto")
@_sicuro("cambiare il contrasto")
def immagine_contrasto(img, fattore):
    """immagine.contrasto(fattore): più di 1 rende i colori più decisi, meno di 1 più slavati.

    Esempio: `foto.contrasto(1.4)`.
    """
    f = _fattore(fattore, "contrasto")
    if img.e_pura:
        _, _, pixel = img.pixel_rgba(128)
        media = sum(0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2] for p in pixel) / len(pixel)
        img.im.mappa(lambda r, g, b: tuple(media + (v - media) * f for v in (r, g, b)))
    else:
        img.im = _su_rgb(img.im, lambda im: pillow().ImageEnhance.Contrast(im).enhance(f))
    return img


@metodo_oggetto(Immagine, "saturazione")
@_sicuro("cambiare la saturazione")
def immagine_saturazione(img, fattore):
    """immagine.saturazione(fattore): colori più vivaci (più di 1) o più spenti (meno di 1; 0 = grigio).

    Esempio: `foto.saturazione(1.5)`.
    """
    f = _fattore(fattore, "saturazione")
    if img.e_pura:
        def satura(r: int, g: int, b: int) -> tuple:
            v = 0.299 * r + 0.587 * g + 0.114 * b
            return tuple(v + (c - v) * f for c in (r, g, b))
        img.im.mappa(satura)
    else:
        img.im = _su_rgb(img.im, lambda im: pillow().ImageEnhance.Color(im).enhance(f))
    return img


@metodo_oggetto(Immagine, "sfoca")
@_sicuro("sfocare l'immagine")
def immagine_sfoca(img, raggio=3):
    """immagine.sfoca(raggio = 3): rende l'immagine sfocata; più grande il raggio, più sfocata.

    Esempio: `foto.sfoca(8)` per uno sfondo morbido.
    """
    r = _numero(raggio, "sfoca", "raggio", 0, 200)
    im = img.pil("sfocare")
    img.im = im.filter(pillow().ImageFilter.GaussianBlur(r))
    return img


@metodo_oggetto(Immagine, "nitidezza")
@_sicuro("aumentare la nitidezza")
def immagine_nitidezza(img, fattore=2):
    """immagine.nitidezza(fattore = 2): rende più netti i bordi (più di 1) o più morbidi (meno di 1).

    Esempio: `foto.nitidezza(2.5)`.
    """
    f = _fattore(fattore, "nitidezza")
    im = img.pil("cambiare la nitidezza")
    img.im = _su_rgb(im, lambda x: pillow().ImageEnhance.Sharpness(x).enhance(f))
    return img


@metodo_oggetto(Immagine, "contorni")
@_sicuro("trovare i contorni")
def immagine_contorni(img):
    """immagine.contorni(): un disegno a matita: linee scure dove l'immagine cambia, il resto bianco.

    Esempio: `apri_immagine("casa.jpg").contorni().salva("da_colorare.png")` per un disegno da colorare.
    """
    im = img.pil("trovare i contorni")
    PIL = pillow()
    grigio = im.convert("L").filter(PIL.ImageFilter.FIND_EDGES)
    grigio = PIL.ImageOps.autocontrast(grigio)
    img.im = PIL.ImageOps.invert(grigio).convert("RGB")
    return img


def _xy(x: Any, y: Any, funzione: str) -> tuple[int, int]:
    return _intero(x, funzione, "x", -LATO_MASSIMO, 2 * LATO_MASSIMO), _intero(y, funzione, "y", -LATO_MASSIMO,
                                                                               2 * LATO_MASSIMO)


def _disegno(img: Immagine) -> Any:
    PIL = pillow()
    if img.im.mode != "RGBA":
        img.im = img.im.convert("RGBA")
    return PIL.ImageDraw.Draw(img.im, "RGBA")


@metodo_oggetto(Immagine, "disegna_rettangolo")
@_sicuro("disegnare il rettangolo")
def immagine_disegna_rettangolo(img, x, y, larghezza, altezza, colore="nero", pieno=True, spessore=3):
    """immagine.disegna_rettangolo(x, y, larghezza, altezza, colore = "nero", pieno = vero, spessore = 3).

    Disegna un rettangolo con l'angolo in alto a sinistra in (x, y); `pieno = falso` fa solo il bordo.
    Esempio: `foglio.disegna_rettangolo(20, 20, 100, 60, "#FF000080")` (rosso trasparente).
    """
    x0, y0 = _xy(x, y, "disegna_rettangolo")
    w, h = _lato(larghezza, "disegna_rettangolo", "larghezza"), _lato(altezza, "disegna_rettangolo", "altezza")
    c = colore_rgba(colore, "disegna_rettangolo")
    p = _logico(pieno, "disegna_rettangolo", "pieno")
    s = _intero(spessore, "disegna_rettangolo", "spessore", 1, 1000)
    x1, y1 = x0 + w - 1, y0 + h - 1
    if img.e_pura:
        if p:
            img.im.rettangolo(x0, y0, x1, y1, c)
        else:
            for k in range(min(s, (min(w, h) + 1) // 2)):
                img.im.linea(x0 + k, y0 + k, x1 - k, y0 + k, c)
                img.im.linea(x0 + k, y1 - k, x1 - k, y1 - k, c)
                img.im.linea(x0 + k, y0 + k + 1, x0 + k, y1 - k - 1, c)
                img.im.linea(x1 - k, y0 + k + 1, x1 - k, y1 - k - 1, c)
        return img
    d = _disegno(img)
    d.rectangle((x0, y0, x1, y1), fill=c if p else None, outline=None if p else c, width=s)
    return img


@metodo_oggetto(Immagine, "disegna_cerchio")
@_sicuro("disegnare il cerchio")
def immagine_disegna_cerchio(img, x, y, raggio, colore="nero", pieno=True, spessore=3):
    """immagine.disegna_cerchio(x, y, raggio, colore = "nero", pieno = vero, spessore = 3): un cerchio con centro (x, y).

    Esempio: `foglio.disegna_cerchio(200, 150, 50, "giallo")` è un sole.
    """
    cx, cy = _xy(x, y, "disegna_cerchio")
    r = _intero(raggio, "disegna_cerchio", "raggio", 1, LATO_MASSIMO)
    c = colore_rgba(colore, "disegna_cerchio")
    p = _logico(pieno, "disegna_cerchio", "pieno")
    s = _intero(spessore, "disegna_cerchio", "spessore", 1, 1000)
    if img.e_pura:
        img.im.ellisse(cx, cy, r, r, c, p, s)
        return img
    _disegno(img).ellipse((cx - r, cy - r, cx + r, cy + r), fill=c if p else None, outline=None if p else c, width=s)
    return img


@metodo_oggetto(Immagine, "disegna_linea")
@_sicuro("disegnare la linea")
def immagine_disegna_linea(img, x1, y1, x2, y2, colore="nero", spessore=3):
    """immagine.disegna_linea(x1, y1, x2, y2, colore = "nero", spessore = 3): una linea da (x1, y1) a (x2, y2).

    Esempio: `foglio.disegna_linea(0, 0, 400, 300, "blu", 5)`.
    """
    a, b = _xy(x1, y1, "disegna_linea")
    c2, d2 = _xy(x2, y2, "disegna_linea")
    c = colore_rgba(colore, "disegna_linea")
    s = _intero(spessore, "disegna_linea", "spessore", 1, 1000)
    if img.e_pura:
        img.im.linea(a, b, c2, d2, c, s)
        return img
    _disegno(img).line((a, b, c2, d2), fill=c, width=s)
    return img


def _carattere(nome: Any, dimensione: int) -> Any:
    ImageFont = pillow().ImageFont
    candidati = []
    if isinstance(nome, str) and nome.strip():
        n = nome.strip()
        candidati += [n, n + ".ttf", n.lower() + ".ttf", n.replace(" ", "") + ".ttf"]
    elif nome is not None:
        raise ErroreTipo(f"`carattere` di `scrivi_testo` deve essere un testo, non {articolo(nome)}.")
    candidati += ["DejaVuSans.ttf", "arial.ttf", "Arial.ttf", "Roboto-Regular.ttf",
                  "/system/fonts/Roboto-Regular.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
                  "/Library/Fonts/Arial.ttf", "/System/Library/Fonts/Supplemental/Arial.ttf"]
    for c in candidati:
        try:
            return ImageFont.truetype(c, dimensione)
        except OSError:
            continue
    try:
        return ImageFont.load_default(dimensione)
    except TypeError:
        return ImageFont.load_default()


@metodo_oggetto(Immagine, "scrivi_testo")
@_sicuro("scrivere il testo")
def immagine_scrivi_testo(img, testo, x=10, y=10, colore="nero", dimensione=24, carattere=None, bordo=None):
    """immagine.scrivi_testo(testo, x = 10, y = 10, colore = "nero", dimensione = 24, carattere = nulla, bordo = nulla).

    Scrive un testo con l'angolo in alto a sinistra in (x, y). `carattere` è il nome di un font
    (per esempio "arial"); `bordo` è il colore del contorno delle lettere, per leggerle su ogni foto.
    Esempio: `foto.scrivi_testo("Buon compleanno!", 30, 30, "giallo", 60, bordo = "nero")`.
    """
    if not isinstance(testo, str):
        testo = rappresenta(testo)
    x0, y0 = _xy(x, y, "scrivi_testo")
    c = colore_rgba(colore, "scrivi_testo")
    d = _intero(dimensione, "scrivi_testo", "dimensione", 4, 2000)
    b = None if bordo is None else colore_rgba(bordo, "scrivi_testo", "bordo")
    img.pil("scrivere un testo sull'immagine")
    font = _carattere(carattere, d)
    extra = {"stroke_width": max(1, d // 15), "stroke_fill": b} if b else {}
    _disegno(img).multiline_text((x0, y0), testo, fill=c, font=font, **extra)
    return img


def _incolla(img: Immagine, altra: Immagine, x: int, y: int, opacita: float) -> None:
    if img.e_pura or altra.e_pura:
        sopra = altra.im if altra.e_pura else Pixel(*altra.im.size, dati=bytearray(altra.im.convert("RGBA").tobytes()))
        if img.e_pura:
            img.im.incolla(sopra, x, y, opacita)
            return
        altra = _da_pixel(sopra)
    pezzo = altra.im.convert("RGBA")
    if opacita < 1:
        alfa = pezzo.getchannel("A").point(lambda v: int(v * opacita))
        pezzo.putalpha(alfa)
    if img.im.mode == "RGBA":
        img.im.alpha_composite(pezzo, (x, y)) if x >= 0 and y >= 0 else img.im.paste(pezzo, (x, y), pezzo)
    else:
        img.im.paste(pezzo, (x, y), pezzo)


@metodo_oggetto(Immagine, "incolla")
@_sicuro("incollare l'immagine")
def immagine_incolla(img, altra, x=0, y=0, opacita=1):
    """immagine.incolla(altra, x = 0, y = 0, opacita = 1): mette un'altra immagine sopra questa, in (x, y).

    Le parti trasparenti dell'altra lasciano vedere sotto; `opacita` da 0 (invisibile) a 1 (piena).
    Esempio: `foto.incolla(apri_immagine("logo.png").miniatura(80), 10, 10, 0.7)`.
    """
    sopra = _immagine(altra, "incolla", "altra")
    x0, y0 = _xy(x, y, "incolla")
    o = _numero(opacita, "incolla", "opacita", 0, 1, "0 = invisibile, 1 = piena.")
    _incolla(img, sopra, x0, y0, o)
    return img


_POSIZIONI = ("alto_sinistra", "alto_destra", "basso_sinistra", "basso_destra", "centro")


@metodo_oggetto(Immagine, "filigrana")
@_sicuro("mettere la filigrana")
def immagine_filigrana(img, marchio, posizione="basso_destra", opacita=0.5):
    """immagine.filigrana(marchio, posizione = "basso_destra", opacita = 0.5): firma o logo semitrasparente.

    `marchio` è un testo (la tua firma) o un'immagine (un logo, rimpicciolito da solo);
    `posizione`: "alto_sinistra", "alto_destra", "basso_sinistra", "basso_destra" o "centro".
    Esempio: `foto.filigrana("(c) Giulia 2026")`, `foto.filigrana("logo.png", "alto_destra")`.
    """
    if not isinstance(posizione, str) or posizione.strip().lower().replace(" ", "_") not in _POSIZIONI:
        raise ErroreValore(f"`posizione` di `filigrana` non può essere {mostra(posizione)}.",
                           suggerimento="Usa " + ", ".join(f"\"{p}\"" for p in _POSIZIONI) + ".")
    pos = posizione.strip().lower().replace(" ", "_")
    o = _numero(opacita, "filigrana", "opacita", 0, 1, "0 = invisibile, 1 = piena.")
    W, H = img.dimensioni
    margine = max(4, min(W, H) // 40)
    if isinstance(marchio, Immagine) or (isinstance(marchio, str) and os.path.splitext(marchio)[1].lower()
                                         in ESTENSIONI_FOTO and os.path.isfile(os.path.expanduser(marchio))):
        logo = _immagine(marchio, "filigrana", "marchio").copia_interna()
        _metodo_miniatura(logo, max(8, min(W, H) // 4))
    elif isinstance(marchio, str) and marchio.strip():
        img.pil("scrivere una filigrana di testo")
        d = max(10, min(W, H) // 18)
        font = _carattere(None, d)
        prova = pillow().ImageDraw.Draw(pillow().Image.new("RGBA", (1, 1)))
        sx, sy, ex, ey = prova.multiline_textbbox((0, 0), marchio, font=font, stroke_width=max(1, d // 15))
        tela = pillow().Image.new("RGBA", (ex - min(0, sx) + 2, ey - min(0, sy) + 2), (0, 0, 0, 0))
        pillow().ImageDraw.Draw(tela).multiline_text((-min(0, sx) + 1, -min(0, sy) + 1), marchio,
                                                     fill=(255, 255, 255, 255), font=font,
                                                     stroke_width=max(1, d // 15), stroke_fill=(0, 0, 0, 255))
        logo = Immagine(tela)
    else:
        raise ErroreTipo(f"`marchio` di `filigrana` deve essere un testo o un'immagine, non {articolo(marchio)}.",
                         suggerimento="Per esempio `foto.filigrana(\"(c) Giulia\")`.")
    lw, lh = logo.dimensioni
    x = margine if pos.endswith("sinistra") else W - lw - margine
    y = margine if pos.startswith("alto") else H - lh - margine
    if pos == "centro":
        x, y = (W - lw) // 2, (H - lh) // 2
    _incolla(img, logo, x, y, o)
    return img


def _dentro(img: Immagine, x: Any, y: Any, funzione: str) -> tuple[int, int]:
    W, H = img.dimensioni
    if isinstance(x, bool) or not isinstance(x, int) or isinstance(y, bool) or not isinstance(y, int):
        raise ErroreTipo(f"`x` e `y` di `{funzione}` devono essere interi.", suggerimento="Per esempio (0, 0).")
    if not (0 <= x < W and 0 <= y < H):
        raise ErroreValore(f"Il punto ({x}, {y}) è fuori dall'immagine, che è {W} x {H} pixel.",
                           suggerimento=f"x va da 0 a {W - 1} e y da 0 a {H - 1}.")
    return x, y


@metodo_oggetto(Immagine, "colore_pixel")
def immagine_colore_pixel(img, x, y):
    """immagine.colore_pixel(x, y): il colore del punto (x, y), come "#RRGGBB".

    Esempio: `stampa(foto.colore_pixel(0, 0))` dice il colore dell'angolo in alto a sinistra.
    """
    x, y = _dentro(img, x, y, "colore_pixel")
    if img.e_pura:
        return esadecimale(img.im.prendi(x, y))
    v = img.im.getpixel((x, y))
    return esadecimale(tuple(v) if isinstance(v, tuple) else (v, v, v))


@metodo_oggetto(Immagine, "imposta_pixel")
def immagine_imposta_pixel(img, x, y, colore):
    """immagine.imposta_pixel(x, y, colore): colora un solo punto.

    Esempio: `per ogni x in 0..99 fai foglio.imposta_pixel(x, 50, "rosso") fine`.
    """
    x, y = _dentro(img, x, y, "imposta_pixel")
    c = colore_rgba(colore, "imposta_pixel")
    if img.e_pura:
        i = (y * img.im.w + x) * 4
        img.im.dati[i:i + 4] = bytes(c)
    else:
        img.im.putpixel((x, y), c if img.im.mode == "RGBA" else c[:3])
    return img


@metodo_oggetto(Immagine, "colori_dominanti")
def immagine_colori_dominanti(img, quanti=5):
    """immagine.colori_dominanti(quanti = 5): i colori più usati nell'immagine, dal più frequente.

    Utile per scegliere i colori di un sito o di un disegno che stiano bene con una foto.
    Esempio: `stampa(apri_immagine("tramonto.jpg").colori_dominanti(3))`.
    """
    n = _intero(quanti, "colori_dominanti", "quanti", 1, 64)
    _, _, pixel = img.pixel_rgba(150)
    gruppi: dict = {}
    for r, g, b, a in pixel:
        if a < 128:
            continue
        k = (r >> 5, g >> 5, b >> 5)
        s = gruppi.get(k)
        if s is None:
            gruppi[k] = [1, r, g, b]
        else:
            s[0] += 1
            s[1] += r
            s[2] += g
            s[3] += b
    ordinati = sorted(gruppi.values(), key=lambda s: -s[0])
    return [esadecimale((s[1] // s[0], s[2] // s[0], s[3] // s[0])) for s in ordinati[:n]]


@metodo_oggetto(Immagine, "sostituisci_colore")
@_sicuro("sostituire il colore")
def immagine_sostituisci_colore(img, vecchio, nuovo, tolleranza=30):
    """immagine.sostituisci_colore(vecchio, nuovo, tolleranza = 30): cambia un colore con un altro.

    `tolleranza` (0-255) dice quanto può essere diverso un colore per essere cambiato anche lui:
    0 solo quello esatto. Con `nuovo = "trasparente"` si toglie uno sfondo.
    Esempio: `logo.sostituisci_colore("bianco", "trasparente").salva("logo.png")`.
    """
    v = colore_rgba(vecchio, "sostituisci_colore", "vecchio")
    c = colore_rgba(nuovo, "sostituisci_colore", "nuovo")
    t = _intero(tolleranza, "sostituisci_colore", "tolleranza", 0, 255)
    if img.e_pura:
        d = img.im.dati
        for i in range(0, len(d), 4):
            if abs(d[i] - v[0]) <= t and abs(d[i + 1] - v[1]) <= t and abs(d[i + 2] - v[2]) <= t:
                d[i:i + 4] = bytes(c)
        return img
    PIL = pillow()
    im = img.im.convert("RGBA") if c[3] < 255 or img.im.mode == "RGBA" else img.im
    bande = im.split()[:3]
    maschere = [b.point(lambda x, lo=v[k] - t, hi=v[k] + t: 255 if lo <= x <= hi else 0) for k, b in enumerate(bande)]
    maschera = PIL.ImageChops.multiply(PIL.ImageChops.multiply(maschere[0], maschere[1]), maschere[2])
    im.paste(c if im.mode == "RGBA" else c[:3], (0, 0, *im.size), maschera)
    img.im = im
    return img


@metodo_oggetto(Immagine, "ascii")
def immagine_in_ascii(img, larghezza=60):
    """immagine.ascii(larghezza = 60): l'immagine disegnata con le lettere (vedi `immagine_ascii`).

    Esempio: `stampa(foto.ascii(40))`.
    """
    return immagine_ascii(img, larghezza)


__all__ = ["Immagine", "Pixel", "FORMATI", "pillow", "colore_rgba", "esadecimale", "png_da_pixel", "bmp_da_pixel",
           "leggi_png", "leggi_bmp", "dimensioni_da_byte", "FormatoNonLetto"]
