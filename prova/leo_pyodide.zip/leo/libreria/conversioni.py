"""Libreria: tipo, intero, decimale, testo, logico.

In Leo le conversioni sono sempre esplicite: ``intero("42")``,
``decimale(3)``, ``testo(3.5)``, ``logico(1)``.
"""

from __future__ import annotations

import math
import re

from ..errori import ErroreTipo, ErroreValore
from ..valori import nome_tipo, rappresenta
from .generali import MASSIME_CIFRE, articolo, funzione_libreria, mostra, testo_a_intero

#: intero scritto come testo: segno facoltativo, cifre con ``_`` solo tra cifre
_RE_INTERO = re.compile(r"[+-]?[0-9]+(?:_[0-9]+)*")
#: decimale scritto col punto: ``3.14``, ``.5``, ``3.``, ``2e-3``, ``1_000.5``
_RE_DECIMALE = re.compile(
    r"[+-]?(?:[0-9]+(?:_[0-9]+)*(?:\.(?:[0-9]+(?:_[0-9]+)*)?)?|\.[0-9]+(?:_[0-9]+)*)(?:[eE][+-]?[0-9]+)?"
)
#: decimale scritto con la virgola all'italiana: ``3,14``
_RE_VIRGOLA = re.compile(r"[+-]?[0-9]+(?:_[0-9]+)*,[0-9]+(?:_[0-9]+)*")


@funzione_libreria("tipo")
def tipo(x):
    """tipo(x): il nome del tipo di un valore, come testo.

    Esempi: `tipo(3)` è "intero", `tipo(3.5)` è "decimale", `tipo("ciao")` è "testo",
    `tipo([1, 2])` è "lista", `tipo(nulla)` è "nulla".
    """
    return nome_tipo(x)


def _testo_a_intero(x: str) -> int:
    pulito = x.strip()
    if not pulito:
        raise ErroreValore("Non posso trasformare un testo vuoto in un intero.",
                           suggerimento="Controlla che sia stato scritto un numero.")
    if _RE_INTERO.fullmatch(pulito):
        try:
            return testo_a_intero(pulito)  # anche oltre il limite di Python delle 4300 cifre
        except ValueError:  # più di MASSIME_CIFRE cifre
            raise ErroreValore(f"Il numero {mostra(x)} ha troppe cifre per essere trasformato "
                               f"(al massimo {MASSIME_CIFRE}).") from None
    if _RE_DECIMALE.fullmatch(pulito):
        raise ErroreValore(
            f"Il testo {mostra(x)} è un numero con la virgola, non un intero.",
            suggerimento=f"Per arrotondarlo usa `arrotonda(decimale({mostra(x)}))`; "
                         f"per tenere la parte intera usa `intero(decimale({mostra(x)}))`.",
        )
    if _RE_VIRGOLA.fullmatch(pulito):
        punto = pulito.replace(",", ".")
        raise ErroreValore(
            f"Il testo {mostra(x)} è un numero con la virgola, non un intero.",
            suggerimento=f"In Leo i decimali si scrivono con il punto (\"{punto}\"); "
                         f"per arrotondarlo usa `arrotonda(...)`.",
        )
    raise ErroreValore(f"Non posso trasformare il testo {mostra(x)} in un intero.",
                       suggerimento="Un intero si scrive con sole cifre, eventualmente col segno: \"42\", \"-7\".")


@funzione_libreria("intero")
def intero(x):
    """intero(x): trasforma un testo, un decimale o un logico in un numero intero.

    Da testo: `intero("42")` è 42 (spazi ai bordi ignorati). Da decimale toglie la
    parte dopo la virgola: `intero(3.9)` è 3, `intero(-3.9)` è -3 (per arrotondare usa
    `arrotonda`). Da logico: `intero(vero)` è 1, `intero(falso)` è 0.
    """
    if isinstance(x, bool):
        return 1 if x else 0
    if isinstance(x, int):
        return x
    if isinstance(x, float):
        if math.isnan(x) or math.isinf(x):
            raise ErroreValore(f"Non posso trasformare {rappresenta(x)} in un intero.")
        return int(x)
    if isinstance(x, str):
        return _testo_a_intero(x)
    suggerimento = None
    if isinstance(x, (list, dict, range)):
        suggerimento = "Per sapere quanti elementi ha usa `lunghezza(...)`."
    raise ErroreTipo(f"Non posso trasformare {articolo(x)} in un intero.", suggerimento=suggerimento)


def _testo_a_decimale(x: str) -> float:
    pulito = x.strip()
    if not pulito:
        raise ErroreValore("Non posso trasformare un testo vuoto in un decimale.",
                           suggerimento="Controlla che sia stato scritto un numero.")
    if _RE_DECIMALE.fullmatch(pulito):
        try:
            valore = float(pulito)
        except (ValueError, OverflowError):  # pragma: no cover - l'espressione regolare lo evita
            valore = math.inf
        if math.isinf(valore):
            raise ErroreValore(f"Il numero {mostra(x)} è troppo grande per un decimale.")
        return valore
    if _RE_VIRGOLA.fullmatch(pulito):
        punto = pulito.replace(",", ".")
        raise ErroreValore(
            f"Il testo {mostra(x)} usa la virgola: in Leo i decimali si scrivono con il punto.",
            suggerimento=f"Usa il punto: \"{punto}\". Se il testo viene dall'utente puoi scrivere "
                         f"`decimale(risposta.sostituisci(\",\", \".\"))`.",
        )
    raise ErroreValore(f"Non posso trasformare il testo {mostra(x)} in un decimale.",
                       suggerimento="Un decimale si scrive con il punto: \"3.14\", \"-0.5\", \"2e-3\".")


@funzione_libreria("decimale")
def decimale(x):
    """decimale(x): trasforma un testo o un intero in un numero decimale.

    Il testo deve usare il punto: `decimale("3.14")` è 3.14 (con "3,14" ricevi un errore).
    Esempio: `decimale(3)` è 3.0.
    """
    if isinstance(x, bool):
        raise ErroreTipo("Non posso trasformare un `logico` in un decimale.",
                         suggerimento="`vero` e `falso` non sono numeri; se ti serve 1 o 0 usa `intero(...)`.")
    if isinstance(x, float):
        return x
    if isinstance(x, int):
        try:
            return float(x)
        except OverflowError:
            raise ErroreValore("Il numero è troppo grande per un decimale.") from None
    if isinstance(x, str):
        return _testo_a_decimale(x)
    raise ErroreTipo(f"Non posso trasformare {articolo(x)} in un decimale.")


@funzione_libreria("testo")
def testo(x):
    """testo(x): il valore scritto come testo, come lo mostra `stampa`.

    Serve per unire testi e numeri: `"Hai " + testo(3) + " anni"`.
    Esempi: `testo(3.5)` è "3.5", `testo(vero)` è "vero", `testo([1, 2])` è "[1, 2]".
    """
    return rappresenta(x)


@funzione_libreria("logico")
def logico(x):
    """logico(x): trasforma in `vero` o `falso`.

    Numeri: `vero` se diversi da zero (`logico(1)` è vero, `logico(0)` è falso).
    Testi: solo "vero" e "falso". Un logico resta com'è.
    """
    if isinstance(x, bool):
        return x
    if isinstance(x, (int, float)):
        if isinstance(x, float) and math.isnan(x):
            raise ErroreValore("Non posso trasformare `non_numero` in un logico.")
        return x != 0
    if isinstance(x, str):
        pulito = x.strip().lower()
        if pulito == "vero":
            return True
        if pulito == "falso":
            return False
        raise ErroreValore(f"Non posso trasformare il testo {mostra(x)} in un logico.",
                           suggerimento="Si trasformano solo i testi \"vero\" e \"falso\".")
    suggerimento = None
    if isinstance(x, (list, dict, range)):
        suggerimento = "Per sapere se è vuota usa `vuota(...)`."
    elif x is None:
        suggerimento = "Per controllare se un valore è `nulla` scrivi `x è nulla`."
    raise ErroreTipo(f"Non posso trasformare {articolo(x)} in un logico.", suggerimento=suggerimento)
