"""Libreria: tabelle di dati (righe e colonne con un nome), semplici come un foglio di calcolo.

Il valore ``tabella`` si crea con:

* ``tabella(dati, colonne)``: da una lista di dizionari, da una lista di liste
  (la prima riga sono i nomi delle colonne), da un dizionario di colonne;
* ``tabella_da_file(percorso)``: da un file CSV (anche di Excel) o JSON;
* ``tabella_da_csv(testo)``, ``tabella_da_json(testo)``;
* ``tabella_da_database(database, nome_o_sql)``.

I metodi che trasformano (``filtra``, ``ordina``, ``seleziona``, ``raggruppa``...)
restituiscono SEMPRE una tabella nuova e lasciano com'è quella di partenza:
``variabile promossi = voti.filtra("voto", ">=", 6)``. Solo ``aggiungi_riga``
cambia la tabella stessa (come ``lista.aggiungi``).

I dati stanno per colonne (una lista Python per colonna): filtri, ordinamenti e
raggruppamenti con i nomi delle colonne lavorano in Python puro e restano
veloci anche con centinaia di migliaia di righe. Le funzioni scritte in Leo
(``filtra(funzione (r) ... fine)``) si chiamano una volta per riga.

Una cella "mancante" è ``nulla`` (anche le celle vuote dei file CSV).
Solo libreria standard: funziona anche sul telefono e negli .exe.
"""

from __future__ import annotations

import csv
import html
import io
import math
import os
import random
from typing import Any, Callable

from ..errori import ErroreDante, ErroreFile, ErroreIndice, ErroreNome, ErroreTipo, ErroreValore
from ..valori import Richiamabile, e_numero, rappresenta
from .archivi import _converti_cella, _controlla_separatore, _indovina_separatore, _spiega_csv, da_json
from .funzionali import chiama_funzione
from .generali import (articolo, funzione_libreria, mostra, richiedi_intero, richiedi_logico,
                       richiedi_testo)
from .ingresso_uscita import _controlla_percorso, _errore_file, leggi_file
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta

__all__ = ["Tabella", "tabella", "tabella_da_file", "tabella_da_csv", "tabella_da_json",
           "tabella_da_database"]

#: Quante righe mostra ``stampa(t)`` prima di saltare quelle in mezzo.
RIGHE_IN_STAMPA = 30
#: Caratteri al massimo di una cella nella stampa (le celle più lunghe si accorciano).
LARGHEZZA_CELLA = 30


class Tabella(OggettoLibreria):
    """Una tabella di dati: colonne con un nome, tutte lunghe uguali."""

    NOME_TIPO_DANTE = "tabella"
    SUGGERIMENTO_MODIFICA = ("Le tabelle si cambiano con i metodi: per esempio "
                             "`t = t.aggiungi_colonna(\"totale\", ...)` o `t.aggiungi_riga({...})`.")

    def __init__(self, nomi: list[str], dati: dict[str, list], righe_n: int | None = None) -> None:
        self.nomi = nomi
        self.dati = dati
        self.righe_n = righe_n if righe_n is not None else (len(dati[nomi[0]]) if nomi else 0)

    def testo_dante(self) -> str:
        return formatta(self, RIGHE_IN_STAMPA)

    def __repr__(self) -> str:
        return f"Tabella({self.nomi!r}, {self.righe_n} righe)"

    def __eq__(self, altro: object) -> bool:
        return (isinstance(altro, Tabella) and self.nomi == altro.nomi
                and all(self.dati[n] == altro.dati[n] for n in self.nomi))

    __hash__ = None  # type: ignore[assignment]

    def elementi_per_ogni(self) -> list[dict]:
        """`per ogni r in t fai`: le righe, come dizionari."""
        return self.righe_dict()

    def lunghezza_dante(self) -> int:
        """`lunghezza(t)`: il numero di righe."""
        return self.righe_n

    # --- aiuti interni -------------------------------------------------------
    def riga_dict(self, i: int) -> dict:
        return {n: self.dati[n][i] for n in self.nomi}

    def righe_dict(self) -> list[dict]:
        nomi = self.nomi
        colonne = [self.dati[n] for n in nomi]
        return [dict(zip(nomi, valori)) for valori in zip(*colonne)] if nomi else []

    def prendi_righe(self, indici: list[int]) -> "Tabella":
        return Tabella(list(self.nomi), {n: [c[i] for i in indici] for n, c in self.dati.items()},
                       len(indici))


# ===========================================================================
# Strumenti
# ===========================================================================

def mancante(v: Any) -> bool:
    """`vero` per le celle vuote: `nulla`, testo vuoto (o di soli spazi), decimale NaN."""
    if v is None:
        return True
    if type(v) is str:
        return not v.strip()
    return type(v) is float and v != v


def _richiedi_tabella(t: Any, nome: str, parametro: str = "tabella") -> Tabella:
    if isinstance(t, Tabella):
        return t
    raise ErroreTipo(f"L'argomento `{parametro}` di `{nome}` deve essere una tabella, non {articolo(t)}.",
                     suggerimento="Crea una tabella con `tabella([...])` o `tabella_da_file(\"dati.csv\")`.")


def _nome_colonna(t: Tabella, nome: Any, metodo: str) -> str:
    """Il nome di una colonna che esiste (con suggerimento se è scritto male)."""
    if not isinstance(nome, str):
        raise ErroreTipo(f"In `{metodo}` il nome della colonna deve essere un testo, non {articolo(nome)}.",
                         suggerimento=f"Colonne: {_elenco(t.nomi)}." if t.nomi else None)
    if nome in t.dati:
        return nome
    # nomi scritti con maiuscole o spazi diversi
    for n in t.nomi:
        if n.strip().casefold() == nome.strip().casefold():
            return n
    import difflib

    simili = difflib.get_close_matches(nome, t.nomi, n=1, cutoff=0.6)
    if simili:
        suggerimento = f"Forse intendevi `{simili[0]}`? Colonne: {_elenco(t.nomi)}."
    elif t.nomi:
        suggerimento = f"Colonne: {_elenco(t.nomi)}."
    else:
        suggerimento = "La tabella non ha ancora colonne."
    raise ErroreNome(f"La tabella non ha la colonna `{nome}`.", suggerimento=suggerimento, nome=nome)


def _elenco(nomi: list[str], massimo: int = 12) -> str:
    parti = [f"`{n}`" for n in nomi[:massimo]]
    if len(nomi) > massimo:
        parti.append(f"e altre {len(nomi) - massimo}")
    return ", ".join(parti)


def _nomi_colonne(t: Tabella, colonne: Any, metodo: str, parametro: str = "colonne") -> list[str]:
    """Una colonna (testo) o più colonne (lista di testi) -> lista di nomi esistenti."""
    if isinstance(colonne, str):
        colonne = [colonne]
    if not isinstance(colonne, list):
        raise ErroreTipo(f"`{parametro}` di `{metodo}` deve essere il nome di una colonna o una lista di nomi, "
                         f"non {articolo(colonne)}.",
                         suggerimento=f"Esempio: `{metodo}(\"nome\")` oppure `{metodo}([\"classe\", \"nome\"])`.")
    if not colonne:
        raise ErroreValore(f"`{metodo}` vuole almeno una colonna.")
    risultato: list[str] = []
    for c in colonne:
        n = _nome_colonna(t, c, metodo)
        if n not in risultato:
            risultato.append(n)
    return risultato


def _nome_nuovo(nome: Any, metodo: str) -> str:
    if not isinstance(nome, str):
        raise ErroreTipo(f"Il nome della colonna in `{metodo}` deve essere un testo, non {articolo(nome)}.")
    if not nome.strip():
        raise ErroreValore(f"Il nome della colonna in `{metodo}` non può essere vuoto.")
    return nome


def _testo_colonna(k: Any, i: int) -> str:
    if isinstance(k, str):
        return k.strip() or f"colonna{i + 1}"
    if k is None:
        return f"colonna{i + 1}"
    try:
        return rappresenta(k)
    except (ValueError, RecursionError):
        return f"colonna{i + 1}"


def _unici(nomi: list[str]) -> list[str]:
    """Nomi di colonna tutti diversi: il secondo `voto` diventa `voto_2`."""
    visti: set[str] = set()
    risultato = []
    for n in nomi:
        nuovo, k = n, 2
        while nuovo in visti:
            nuovo, k = f"{n}_{k}", k + 1
        visti.add(nuovo)
        risultato.append(nuovo)
    return risultato


def _chiave(v: Any) -> Any:
    """Chiave per confrontare celle (duplicati, gruppi, unioni): 1 e 1.0 uguali, `vero` e 1 no."""
    if v is None:
        return (0,)
    t = type(v)
    if t is bool:
        return (1, v)
    if t is int or t is float:
        return (2, v) if v == v else (0,)
    if t is str:
        return (3, v) if v.strip() else (0,)
    try:
        hash(v)
        return (4, v)
    except TypeError:
        return (5, rappresenta(v))


def _ordine(v: Any) -> tuple:
    """Chiave di ordinamento: numeri, poi testi (senza badare alle maiuscole), poi il resto."""
    t = type(v)
    if t is int or t is float:
        return (0, v, "")
    if t is bool:
        return (0, int(v), "")
    if t is str:
        return (1, v.casefold(), v)
    try:
        return (2, rappresenta(v), "")
    except (ValueError, RecursionError):
        return (2, "", "")


def _crea(nomi: list[str], righe: list[list]) -> Tabella:
    """Tabella da nomi e righe-lista (già della lunghezza giusta)."""
    if not righe:
        return Tabella(nomi, {n: [] for n in nomi}, 0)
    colonne = list(zip(*righe))
    return Tabella(nomi, {n: list(c) for n, c in zip(nomi, colonne)}, len(righe))


def _da_dizionari(righe: list, nome: str) -> Tabella:
    nomi: list[str] = []
    visti: dict[Any, str] = {}
    for r in righe:
        for k in r:
            segno = (type(k) is bool, k) if _hashable(k) else (None, rappresenta(k))
            if segno not in visti:
                visti[segno] = _testo_colonna(k, len(nomi))
                nomi.append(visti[segno])
    nomi_unici = _unici(nomi)
    if nomi_unici == nomi and all(isinstance(k, str) and k.strip() for k in visti):
        # caso comune (chiavi di testo): veloce
        return Tabella(nomi, {n: [r.get(n) for r in righe] for n in nomi}, len(righe))
    mappa = dict(zip(visti.keys(), nomi_unici))
    dati: dict[str, list] = {n: [None] * len(righe) for n in nomi_unici}
    for i, r in enumerate(righe):
        for k, v in r.items():
            segno = (type(k) is bool, k) if _hashable(k) else (None, rappresenta(k))
            dati[mappa[segno]][i] = v
    return Tabella(nomi_unici, dati, len(righe))


def _hashable(k: Any) -> bool:
    try:
        hash(k)
        return True
    except TypeError:
        return False


def _da_liste(righe: list, colonne: list[str] | None, nome: str) -> Tabella:
    if colonne is None:
        if not righe:
            return Tabella([], {}, 0)
        colonne = _unici([_testo_colonna(k, i) for i, k in enumerate(righe[0])])
        righe = righe[1:]
    larghezza = len(colonne)
    pronte = []
    for i, r in enumerate(righe):
        if len(r) < larghezza:
            r = list(r) + [None] * (larghezza - len(r))
        elif len(r) > larghezza:
            raise ErroreValore(f"La riga {i} ha {len(r)} valori, ma le colonne sono {larghezza}.",
                               suggerimento=f"Colonne: {_elenco(colonne)}.")
        pronte.append(r)
    return _crea(colonne, pronte)


def _controlla_colonne(colonne: Any, nome: str) -> list[str] | None:
    if colonne is None:
        return None
    if not isinstance(colonne, list) or not all(isinstance(c, str) for c in colonne):
        raise ErroreTipo(f"`colonne` di `{nome}` deve essere una lista di testi (i nomi delle colonne), "
                         f"non {articolo(colonne)}.",
                         suggerimento="Esempio: `colonne = [\"nome\", \"voto\"]`.")
    return _unici([_testo_colonna(c, i) for i, c in enumerate(colonne)])


def crea_tabella_da(dati: Any, colonne: Any, nome: str) -> Tabella:
    """Il cuore di ``tabella(...)``."""
    nomi = _controlla_colonne(colonne, nome)
    if dati is None:
        return Tabella(nomi or [], {n: [] for n in nomi or []}, 0)
    if isinstance(dati, Tabella):
        t = Tabella(list(dati.nomi), {n: list(c) for n, c in dati.dati.items()}, dati.righe_n)
        return t if nomi is None else _seleziona(t, nomi, nome)
    if isinstance(dati, dict):
        if dati and all(isinstance(v, list) for v in dati.values()):
            lunghezze = {len(v) for v in dati.values()}
            if len(lunghezze) > 1:
                raise ErroreValore(f"In `{nome}` tutte le colonne devono avere lo stesso numero di valori "
                                   f"(qui ce ne sono {', '.join(str(n) for n in sorted(lunghezze))}).")
            chiavi = _unici([_testo_colonna(k, i) for i, k in enumerate(dati)])
            t = Tabella(chiavi, {n: list(v) for n, v in zip(chiavi, dati.values())},
                        lunghezze.pop() if lunghezze else 0)
        else:
            t = _da_dizionari([dati], nome)  # un dizionario solo: una riga
        return t if nomi is None else _seleziona(t, nomi, nome)
    if isinstance(dati, list):
        if not dati:
            return Tabella(nomi or [], {n: [] for n in nomi or []}, 0)
        if all(isinstance(r, dict) for r in dati):
            t = _da_dizionari(dati, nome)
            if nomi is not None:
                for n in nomi:
                    if n not in t.dati:
                        t.nomi.append(n)
                        t.dati[n] = [None] * t.righe_n
                t = _seleziona(t, nomi, nome)
            return t
        if all(isinstance(r, list) for r in dati):
            return _da_liste(dati, nomi, nome)
        if nomi is not None and len(nomi) == 1 and not any(isinstance(r, (list, dict)) for r in dati):
            return Tabella(nomi, {nomi[0]: list(dati)}, len(dati))
        raise ErroreTipo(f"`{nome}` vuole una lista di dizionari (una per riga) oppure una lista di liste, "
                         "non un miscuglio.",
                         suggerimento="Esempi: `tabella([{\"nome\": \"Ada\", \"voto\": 9}])` oppure "
                                      "`tabella([[\"nome\", \"voto\"], [\"Ada\", 9]])`.")
    raise ErroreTipo(f"`{nome}` vuole una lista o un dizionario, non {articolo(dati)}.",
                     suggerimento="Esempio: `tabella([{\"nome\": \"Ada\", \"voto\": 9}, {\"nome\": \"Bruno\", "
                                  "\"voto\": 7}])`.")


def _seleziona(t: Tabella, nomi: list[str], metodo: str) -> Tabella:
    scelti = [_nome_colonna(t, n, metodo) for n in nomi]
    return Tabella(list(scelti), {n: list(t.dati[n]) for n in scelti}, t.righe_n)


# ===========================================================================
# Stampa
# ===========================================================================

def _cella_testo(v: Any) -> str:
    if v is None:
        return ""
    if type(v) is float:
        if v != v:
            return ""
        if v.is_integer() and abs(v) < 1e15:
            return rappresenta(v)
        v = round(v, 4) if abs(v) >= 0.001 else v
    try:
        s = rappresenta(v)
    except (ValueError, RecursionError):
        s = mostra(v)
    s = s.replace("\r", " ").replace("\n", " ").replace("\t", " ")
    if len(s) > LARGHEZZA_CELLA:
        s = s[:LARGHEZZA_CELLA - 3] + "..."
    return s


def formatta(t: Tabella, massimo: int | None, tagli_in_mezzo: bool = True) -> str:
    """La tabella come testo allineato (per il terminale)."""
    if not t.nomi:
        return "(tabella vuota: nessuna colonna)"
    n = t.righe_n
    if massimo is None or n <= massimo:
        indici = list(range(n))
        salto = None
    elif tagli_in_mezzo:
        testa = max(1, massimo * 2 // 3)
        coda = max(1, massimo - testa)
        indici = list(range(testa)) + list(range(n - coda, n))
        salto = testa
    else:
        indici = list(range(massimo))
        salto = massimo
    celle = {c: [_cella_testo(t.dati[c][i]) for i in indici] for c in t.nomi}
    numeriche = {c: all(e_numero(t.dati[c][i]) or t.dati[c][i] is None for i in indici) for c in t.nomi}
    intestazioni = [_cella_testo(c) for c in t.nomi]
    larghezze = [max([len(h)] + [len(s) for s in celle[c]]) for c, h in zip(t.nomi, intestazioni)]

    def riga(valori: list[str], destra: list[bool]) -> str:
        return " " + " | ".join(v.rjust(w) if d else v.ljust(w)
                                for v, w, d in zip(valori, larghezze, destra)).rstrip()

    destra = [numeriche[c] for c in t.nomi]
    righe = [riga(intestazioni, [False] * len(t.nomi)),
             "-" + "-+-".join("-" * w for w in larghezze) + "-"]
    for k in range(len(indici)):
        if salto is not None and k == salto:
            righe.append(" ...")
        righe.append(riga([celle[c][k] for c in t.nomi], destra))
    if salto is not None and salto >= len(indici):
        altre = n - len(indici)
        righe.append(" ... e un'altra riga" if altre == 1 else f" ... e altre {altre} righe")
    parole_righe = "1 riga" if n == 1 else f"{n} righe"
    parole_colonne = "1 colonna" if len(t.nomi) == 1 else f"{len(t.nomi)} colonne"
    righe.append(f"({parole_righe}, {parole_colonne})")
    return "\n".join(righe)


# ===========================================================================
# Funzioni per creare le tabelle
# ===========================================================================

@funzione_libreria("tabella")
def tabella(dati=None, colonne=None):
    """tabella(dati = nulla, colonne = nulla): crea una tabella di dati con righe e colonne.

    `dati` può essere una lista di dizionari (uno per riga), una lista di liste (la prima riga
    sono i nomi delle colonne, oppure li dai con `colonne`) o un dizionario di colonne.
    Esempio: `variabile t = tabella([{"nome": "Ada", "voto": 9}, {"nome": "Bruno", "voto": 7}])`,
    poi `stampa(t)`.
    """
    return crea_tabella_da(dati, colonne, "tabella")


def _tabella_da_testo_csv(testo: str, separatore: Any, nome: str, origine: str) -> Tabella:
    if testo.startswith("\ufeff"):
        testo = testo[1:]
    if "\r" in testo:
        testo = testo.replace("\r\n", "\n").replace("\r", "\n")
    if separatore is None:
        separatore = _indovina_separatore(testo.split("\n", 1)[0])
    _controlla_separatore(separatore, nome)
    try:
        righe = [r for r in csv.reader(io.StringIO(testo, newline=""), delimiter=separatore)
                 if r and any(c.strip() for c in r)]
    except csv.Error as e:
        raise ErroreFile(f"{origine} non è una tabella CSV valida: {_spiega_csv(e)}.") from None
    if not righe:
        return Tabella([], {}, 0)
    nomi = _unici([_testo_colonna(k, i) for i, k in enumerate(righe[0])])
    larghezza = len(nomi)
    colonne: list[list] = [[] for _ in nomi]
    conv = _converti_cella
    for r in righe[1:]:
        if len(r) > larghezza:
            # celle in più (per esempio separatori in fondo alla riga): se sono vuote si ignorano
            if any(c.strip() for c in r[larghezza:]):
                for k in range(larghezza, len(r)):
                    nomi.append(f"colonna{k + 1}")
                    colonne.append([None] * (len(colonne[0]) if colonne else 0))
                nomi = _unici(nomi)
                larghezza = len(nomi)
        for k in range(larghezza):
            if k < len(r):
                c = r[k]
                if not c.strip():
                    colonne[k].append(None)
                elif c in _LOGICI:
                    colonne[k].append(_LOGICI[c])
                else:
                    colonne[k].append(conv(c, separatore))
            else:
                colonne[k].append(None)
    return Tabella(nomi, dict(zip(nomi, colonne)), len(righe) - 1)


#: Le celle "vero" e "falso" (come le scrive Leo) tornano valori logici.
_LOGICI = {"vero": True, "falso": False}


@funzione_libreria("tabella_da_csv")
def tabella_da_csv(testo, separatore=None):
    """tabella_da_csv(testo, separatore = nulla): crea una tabella da un testo CSV (la prima riga sono i nomi delle colonne).

    Il separatore (`,` `;` o tabulazione) si indovina da solo, i numeri diventano numeri e le
    celle vuote diventano `nulla`.
    Esempio: `variabile t = tabella_da_csv("nome;voto\\nAda;9\\nBruno;7")`.
    """
    richiedi_testo(testo, "tabella_da_csv", "testo")
    return _tabella_da_testo_csv(testo, separatore, "tabella_da_csv", "Il testo")


def _da_valore_json(valore: Any, nome: str) -> Tabella:
    if isinstance(valore, dict):
        # {"righe": [...]} o {"dati": [...]}: molte API mettono la lista dentro un dizionario
        liste = [v for v in valore.values() if isinstance(v, list) and v and all(isinstance(r, dict) for r in v)]
        if len(liste) == 1:
            valore = liste[0]
    if isinstance(valore, list) and valore and not all(isinstance(r, (dict, list)) for r in valore):
        raise ErroreValore(f"Il JSON di `{nome}` deve essere una lista di oggetti (una per riga) "
                           "o un oggetto con le colonne.",
                           suggerimento="Esempio: [{\"nome\": \"Ada\", \"voto\": 9}, {\"nome\": \"Bruno\", \"voto\": 7}].")
    if not isinstance(valore, (list, dict)):
        raise ErroreValore(f"Il JSON di `{nome}` contiene {articolo(valore)}, non una tabella.",
                           suggerimento="Serve una lista di oggetti: [{\"nome\": \"Ada\"}, {\"nome\": \"Bruno\"}].")
    return crea_tabella_da(valore, None, nome)


@funzione_libreria("tabella_da_json")
def tabella_da_json(testo):
    """tabella_da_json(testo): crea una tabella da un testo JSON (una lista di oggetti, uno per riga).

    Esempio: `variabile t = tabella_da_json(leggi_file("classe.json"))`, oppure con un testo
    (le graffe nei testi di Leo si scrivono `\\{`): `tabella_da_json("[\\{\\"nome\\": \\"Ada\\"\\}]")`.
    """
    richiedi_testo(testo, "tabella_da_json", "testo")
    return _da_valore_json(da_json(testo), "tabella_da_json")


_ESTENSIONI_CSV = (".csv", ".tsv", ".txt", ".tab")


@funzione_libreria("tabella_da_file", interprete=True)
def tabella_da_file(interprete, percorso, separatore=None):
    """tabella_da_file(percorso, separatore = nulla): legge una tabella da un file CSV (anche salvato da Excel) o JSON.

    Il tipo si capisce dall'estensione (.csv, .tsv, .txt, .json). Le celle vuote diventano `nulla`.
    Esempio: `variabile voti = tabella_da_file("voti.csv")`, poi `stampa(voti.prime(5))`.
    """
    richiedi_testo(percorso, "tabella_da_file", "percorso")
    estensione = os.path.splitext(percorso)[1].lower()
    if estensione in (".xlsx", ".xlsm", ".xls", ".ods"):
        return _da_foglio(interprete, percorso)
    if estensione in (".db", ".sqlite", ".sqlite3"):
        raise ErroreValore(f"`{percorso}` è un database: serve anche il nome della tabella.",
                           suggerimento=f"Usa `tabella_da_database(\"{percorso}\", \"nome_tabella\")`.")
    testo = leggi_file(percorso)
    if estensione == ".json" or (estensione not in _ESTENSIONI_CSV and testo.lstrip()[:1] in ("[", "{")):
        try:
            valore = da_json(testo)
        except ErroreValore as e:
            raise ErroreFile(f"Il file `{percorso}` non contiene JSON valido: {e.messaggio}",
                             suggerimento=e.suggerimento) from None
        return _da_valore_json(valore, "tabella_da_file")
    if separatore is None and estensione == ".tsv":
        separatore = "\t"
    return _tabella_da_testo_csv(testo, separatore, "tabella_da_file", f"Il file `{percorso}`")


def _da_foglio(interprete: Any, percorso: str) -> Tabella:
    """File di Excel: se la libreria ha una funzione che li legge la si usa, altrimenti si spiega."""
    from .. import registro

    for nome in ("leggi_excel", "leggi_foglio"):
        f = registro.FUNZIONI.get(nome)
        if f is not None:
            dati = chiama_funzione(interprete, f, [percorso])
            if isinstance(dati, Tabella):
                return dati
            return crea_tabella_da(dati, None, "tabella_da_file")
    raise ErroreValore(f"Non so ancora leggere direttamente il file di Excel `{percorso}`.",
                       suggerimento="In Excel scegli File > Salva con nome > \"CSV (delimitato dal separatore)\" "
                                    "e poi usa `tabella_da_file` con il file .csv.")


def _database(database: Any, nome: str, crea: bool) -> tuple[Any, bool]:
    """(database aperto, da chiudere alla fine) da un valore `database` o da un percorso."""
    from .database import Database, _apri

    if isinstance(database, Database):
        if not database.motore.aperta:
            raise ErroreValore("Il database è chiuso.", suggerimento="Aprilo di nuovo con `apri_database(...)`.")
        return database, False
    if isinstance(database, str):
        if not crea and database != ":memory:" and not os.path.isfile(database):
            raise ErroreFile(f"Il database `{database}` non esiste.",
                             suggerimento="Controlla il nome del file e la cartella.")
        return _apri(database, nome), True
    raise ErroreTipo(f"Il primo argomento di `{nome}` deve essere un database (da `apri_database`) "
                     f"o il percorso di un file, non {articolo(database)}.",
                     suggerimento="Esempio: `tabella_da_database(\"negozio.db\", \"prodotti\")`.")


@funzione_libreria("tabella_da_database")
def tabella_da_database(database, nome_o_sql, parametri=None):
    """tabella_da_database(database, nome_o_sql, parametri = nulla): crea una tabella da una tabella di un database SQLite o da una ricerca SQL.

    `database` è un database aperto con `apri_database` oppure il percorso del file.
    Esempi: `tabella_da_database("negozio.db", "prodotti")`,
    `tabella_da_database(db, "SELECT nome, prezzo FROM prodotti WHERE prezzo < ?", [10])`.
    """
    from .database import db_esegui

    richiedi_testo(nome_o_sql, "tabella_da_database", "nome_o_sql")
    db, chiudi = _database(database, "tabella_da_database", False)
    try:
        testo = nome_o_sql.strip()
        if " " in testo or "\n" in testo:
            righe = db_esegui(db, testo, parametri)
            if not isinstance(righe, list):
                righe = []
            return crea_tabella_da(righe, None, "tabella_da_database")
        if parametri is not None:
            raise ErroreValore("I `parametri` servono solo con una ricerca SQL, non con il nome di una tabella.")
        colonne = list(db.motore.colonne(testo))
        righe = db.motore.cerca(testo)
        return crea_tabella_da(righe, colonne, "tabella_da_database")
    finally:
        if chiudi:
            db.motore.chiudi()


# ===========================================================================
# Proprietà
# ===========================================================================

@proprieta(Tabella, "numero_righe")
def _numero_righe(t: Tabella) -> int:
    return t.righe_n


@proprieta(Tabella, "numero_colonne")
def _numero_colonne(t: Tabella) -> int:
    return len(t.nomi)


# ===========================================================================
# Metodi: guardare dentro
# ===========================================================================

@metodo_oggetto(Tabella, "colonne")
def tab_colonne(t):
    """t.colonne(): la lista dei nomi delle colonne.

    Esempio: `stampa(voti.colonne())` scrive ["nome", "classe", "voto"].
    """
    return list(t.nomi)


@metodo_oggetto(Tabella, "righe")
def tab_righe(t):
    """t.righe(): tutte le righe, come lista di dizionari (colonna -> valore).

    Esempio: `per ogni r in voti.righe() fai stampa(r["nome"], r["voto"]) fine`.
    """
    return t.righe_dict()


@metodo_oggetto(Tabella, "colonna")
def tab_colonna(t, nome, senza_mancanti=False):
    """t.colonna(nome, senza_mancanti = falso): i valori di una colonna, come lista.

    Con `senza_mancanti = vero` le celle vuote restano fuori (comodo per i calcoli).
    Esempio: `stampa(media(voti.colonna("voto", senza_mancanti = vero)))`.
    """
    valori = t.dati[_nome_colonna(t, nome, "colonna")]
    if richiedi_logico(senza_mancanti, "colonna", "senza_mancanti"):
        return [v for v in valori if not mancante(v)]
    return list(valori)


def _indice_riga(t: Tabella, indice: Any, metodo: str) -> int:
    richiedi_intero(indice, metodo, "indice")
    n = t.righe_n
    if -n <= indice < n:
        return indice % n
    if n == 0:
        raise ErroreIndice("La tabella non ha righe.")
    raise ErroreIndice(f"La riga {indice} non c'è: le righe vanno da 0 a {n - 1}.",
                       suggerimento="Con gli indici negativi si conta dal fondo: `riga(-1)` è l'ultima.")


@metodo_oggetto(Tabella, "riga")
def tab_riga(t, indice):
    """t.riga(indice): una riga come dizionario (la prima è la riga 0, l'ultima è -1).

    Esempio: `variabile primo = classifica.riga(0)` poi `stampa(primo["nome"])`.
    """
    return t.riga_dict(_indice_riga(t, indice, "riga"))


def _quante(n: Any, metodo: str) -> int:
    richiedi_intero(n, metodo, "quante")
    if n < 0:
        raise ErroreValore(f"`{metodo}` vuole un numero di righe da 0 in su, non {n}.")
    return n


@metodo_oggetto(Tabella, "prime")
def tab_prime(t, quante=5):
    """t.prime(quante = 5): una tabella con solo le prime righe.

    Esempio: `stampa(voti.ordina("voto", decrescente = vero).prime(3))` (il podio).
    """
    n = min(_quante(quante, "prime"), t.righe_n)
    return t.prendi_righe(list(range(n)))


@metodo_oggetto(Tabella, "ultime")
def tab_ultime(t, quante=5):
    """t.ultime(quante = 5): una tabella con solo le ultime righe.

    Esempio: `stampa(misure.ultime(10))`.
    """
    n = min(_quante(quante, "ultime"), t.righe_n)
    return t.prendi_righe(list(range(t.righe_n - n, t.righe_n)))


@metodo_oggetto(Tabella, "campione")
def tab_campione(t, quante=5, seme=None):
    """t.campione(quante = 5, seme = nulla): alcune righe scelte a caso (con `seme` sempre le stesse).

    Esempio: `stampa(domande.campione(3))`.
    """
    n = min(_quante(quante, "campione"), t.righe_n)
    if seme is not None:
        richiedi_intero(seme, "campione", "seme")
        generatore = random.Random(seme)
    else:
        generatore = random.Random()
    indici = sorted(generatore.sample(range(t.righe_n), n))
    return t.prendi_righe(indici)


@metodo_oggetto(Tabella, "copia")
def tab_copia(t):
    """t.copia(): una copia della tabella (cambiare la copia non cambia l'originale).

    Esempio: `variabile bozza = voti.copia()` poi `bozza.aggiungi_riga({"voto": 7})`.
    """
    return Tabella(list(t.nomi), {n: list(c) for n, c in t.dati.items()}, t.righe_n)


@metodo_oggetto(Tabella, "mostra", interprete=True)
def tab_mostra(interprete, t, righe=20):
    """t.mostra(righe = 20): scrive la tabella allineata, al massimo con quel numero di righe.

    Esempio: `voti.mostra()` oppure `voti.mostra(5)`.
    """
    richiedi_intero(righe, "mostra", "righe")
    if righe < 1:
        raise ErroreValore("`mostra` vuole almeno 1 riga.")
    testo = formatta(t, righe, tagli_in_mezzo=False) + "\n"
    scrivi = getattr(interprete, "scrivi", None)
    if scrivi is not None:
        scrivi(testo)
    else:  # senza interprete (non capita nei programmi)
        print(testo, end="")
    return None


# ===========================================================================
# Metodi: filtrare e cercare
# ===========================================================================

def _uguali(a: Any, b: Any) -> bool:
    if type(a) is bool or type(b) is bool:
        return type(a) is type(b) and a == b
    try:
        return bool(a == b)
    except Exception:  # noqa: BLE001 - confronto strano: diversi
        return False


def _confronta(simbolo: str) -> Callable[[Any, Any], bool]:
    def confronto(a: Any, b: Any) -> bool:
        if a is None or type(a) is bool or type(b) is bool:
            return False
        try:
            if simbolo == "<":
                return bool(a < b)
            if simbolo == "<=":
                return bool(a <= b)
            if simbolo == ">":
                return bool(a > b)
            return bool(a >= b)
        except (TypeError, ValueError):
            return False
        except ErroreDante:
            return False

    return confronto


def _minuscolo(v: Any) -> str:
    if isinstance(v, str):
        return v.casefold()
    if v is None:
        return ""
    try:
        return rappresenta(v).casefold()
    except (ValueError, RecursionError):
        return ""


_OPERATORI = {
    "=": "=", "==": "=", "uguale": "=", "è": "=",
    "!=": "!=", "<>": "!=", "diverso": "!=", "non è": "!=",
    "<": "<", "minore": "<", "minore di": "<", ">": ">", "maggiore": ">", "maggiore di": ">",
    "<=": "<=", "minore o uguale": "<=", "minore o uguale a": "<=",
    ">=": ">=", "maggiore o uguale": ">=", "maggiore o uguale a": ">=",
    "uguale a": "=", "diverso da": "!=",
    "contiene": "contiene", "non contiene": "non contiene",
    "inizia con": "inizia con", "inizia": "inizia con", "comincia con": "inizia con",
    "finisce con": "finisce con", "finisce": "finisce con",
    "in": "in", "non in": "non in", "tra": "tra",
    "mancante": "mancante", "vuoto": "mancante", "non mancante": "non mancante", "pieno": "non mancante",
}


def _operatore(op: Any, metodo: str) -> str:
    if not isinstance(op, str):
        raise ErroreTipo(f"L'operatore di `{metodo}` deve essere un testo come \">\" o \"contiene\", "
                         f"non {articolo(op)}.")
    chiave = " ".join(op.strip().lower().replace("_", " ").split())
    if chiave in _OPERATORI:
        return _OPERATORI[chiave]
    raise ErroreValore(f"Non conosco l'operatore {mostra(op)}.",
                       suggerimento="Operatori: \"=\", \"!=\", \"<\", \"<=\", \">\", \">=\", \"contiene\", "
                                    "\"inizia con\", \"finisce con\", \"in\", \"non in\", \"tra\", \"mancante\".")


def _prova(op: str, valore: Any, altro: Any, metodo: str) -> Callable[[Any], bool]:
    """La funzione cella -> vero/falso per ``colonna op valore``."""
    if op == "=":
        if mancante(valore):
            return mancante
        return lambda v: _uguali(v, valore)
    if op == "!=":
        if mancante(valore):
            return lambda v: not mancante(v)
        return lambda v: not _uguali(v, valore)
    if op in ("<", "<=", ">", ">="):
        confronto = _confronta(op)
        return lambda v: confronto(v, valore)
    if op in ("contiene", "non contiene", "inizia con", "finisce con"):
        if not isinstance(valore, str):
            valore = _minuscolo(valore)
        cerca = valore.casefold()
        if op == "contiene":
            return lambda v: cerca in _minuscolo(v)
        if op == "non contiene":
            return lambda v: cerca not in _minuscolo(v)
        if op == "inizia con":
            return lambda v: _minuscolo(v).startswith(cerca)
        return lambda v: _minuscolo(v).endswith(cerca)
    if op in ("in", "non in"):
        if not isinstance(valore, list):
            raise ErroreTipo(f"Con \"{op}\" il valore di `{metodo}` deve essere una lista, non {articolo(valore)}.",
                             suggerimento=f"Esempio: `{metodo}(\"città\", \"in\", [\"Roma\", \"Milano\"])`.")
        chiavi = {_chiave(x) for x in valore}
        if op == "in":
            return lambda v: _chiave(v) in chiavi
        return lambda v: _chiave(v) not in chiavi
    if op == "tra":
        if isinstance(valore, list) and len(valore) == 2 and altro is None:
            valore, altro = valore
        if valore is None or altro is None:
            raise ErroreValore(f"Con \"tra\" servono due valori: `{metodo}(\"voto\", \"tra\", 6, 8)`.")
        sopra, sotto = _confronta(">="), _confronta("<=")
        return lambda v: sopra(v, valore) and sotto(v, altro)
    if op == "mancante":
        return mancante
    return lambda v: not mancante(v)


def _logico(risultato: Any, metodo: str, riga: dict) -> bool:
    if isinstance(risultato, bool):
        return risultato
    raise ErroreTipo(f"La funzione data a `{metodo}` deve restituire `vero` o `falso`, "
                     f"ma per la riga {mostra(riga)} ha restituito {articolo(risultato)}.",
                     suggerimento="Scrivi una condizione, per esempio `restituisci r[\"voto\"] >= 6`.")


_MANCA = object()


@metodo_oggetto(Tabella, "filtra", interprete=True)
def tab_filtra(interprete, t, condizione, operatore=_MANCA, valore=_MANCA, fino_a=None):
    """t.filtra(condizione, operatore, valore): una tabella con solo le righe che rispettano la condizione.

    Esempi, nei vari modi: `t.filtra("voto", ">=", 6)`, `t.filtra("città", "Roma")` (uguale),
    `t.filtra({"classe": "1A", "voto": [">", 7]})` (tutte insieme), oppure con una funzione che
    riceve la riga: `t.filtra(funzione (r) restituisci r["voto"] > r["media"] fine)`.
    Operatori: = != < <= > >= contiene, inizia con, finisce con, in, non in, tra, mancante.
    """
    n = t.righe_n
    if isinstance(condizione, Richiamabile):
        if operatore is not _MANCA:
            raise ErroreValore("Con una funzione `filtra` non vuole altri argomenti.")
        indici = []
        nomi = t.nomi
        colonne = [t.dati[c] for c in nomi]
        for i, valori in enumerate(zip(*colonne) if nomi else []):
            r = dict(zip(nomi, valori))
            if _logico(chiama_funzione(interprete, condizione, [r]), "filtra", r):
                indici.append(i)
        return t.prendi_righe(indici)
    if isinstance(condizione, dict):
        if operatore is not _MANCA:
            raise ErroreValore("Con un dizionario di condizioni `filtra` non vuole altri argomenti.")
        prove = []
        for colonna, regola in condizione.items():
            nome = _nome_colonna(t, colonna, "filtra")
            if isinstance(regola, list) and regola and isinstance(regola[0], str) \
                    and " ".join(regola[0].strip().lower().replace("_", " ").split()) in _OPERATORI:
                op = _operatore(regola[0], "filtra")
                argomenti = regola[1:]
                primo = argomenti[0] if argomenti else None
                secondo = argomenti[1] if len(argomenti) > 1 else None
                prove.append((t.dati[nome], _prova(op, primo, secondo, "filtra")))
            else:
                prove.append((t.dati[nome], _prova("=", regola, None, "filtra")))
        indici = [i for i in range(n) if all(p(c[i]) for c, p in prove)]
        return t.prendi_righe(indici)
    if isinstance(condizione, str):
        nome = _nome_colonna(t, condizione, "filtra")
        if operatore is _MANCA:
            raise ErroreValore("`filtra` con il nome di una colonna vuole anche il valore da cercare.",
                               suggerimento=f"Esempi: `filtra(\"{nome}\", \"Roma\")`, `filtra(\"{nome}\", \">\", 10)`.")
        if valore is _MANCA:
            op_testo = operatore
            if isinstance(operatore, str) and " ".join(operatore.strip().lower().replace("_", " ").split()) in \
                    ("mancante", "vuoto", "non mancante", "pieno"):
                op, valore = _operatore(operatore, "filtra"), None
            else:
                op, valore = "=", op_testo
        else:
            op = _operatore(operatore, "filtra")
        prova = _prova(op, valore, fino_a, "filtra")
        colonna = t.dati[nome]
        return t.prendi_righe([i for i, v in enumerate(colonna) if prova(v)])
    raise ErroreTipo(f"`filtra` vuole il nome di una colonna, un dizionario di condizioni o una funzione, "
                     f"non {articolo(condizione)}.",
                     suggerimento="Esempio: `t.filtra(\"voto\", \">=\", 6)`.")


@metodo_oggetto(Tabella, "cerca")
def tab_cerca(t, testo, colonne=None):
    """t.cerca(testo, colonne = nulla): le righe in cui una cella contiene il testo (senza badare alle maiuscole).

    Esempio: `stampa(rubrica.cerca("rossi"))`, oppure solo in alcune colonne:
    `rubrica.cerca("rossi", ["cognome"])`.
    """
    if not isinstance(testo, str):
        testo = _minuscolo(testo)
    cerca = testo.casefold()
    nomi = t.nomi if colonne is None else _nomi_colonne(t, colonne, "cerca")
    colonne_dati = [t.dati[c] for c in nomi]
    indici = [i for i in range(t.righe_n) if any(cerca in _minuscolo(c[i]) for c in colonne_dati)]
    return t.prendi_righe(indici)


# ===========================================================================
# Metodi: colonne
# ===========================================================================

def _lista_colonne(colonne: tuple) -> Any:
    if len(colonne) == 1:
        return colonne[0]
    return list(colonne)


@metodo_oggetto(Tabella, "seleziona")
def tab_seleziona(t, *colonne):
    """t.seleziona(colonne...): una tabella con solo le colonne scelte, nell'ordine scelto.

    Esempio: `stampa(voti.seleziona("nome", "voto"))` (va bene anche una lista di nomi).
    """
    if not colonne:
        raise ErroreValore("`seleziona` vuole almeno il nome di una colonna.",
                           suggerimento=f"Colonne: {_elenco(t.nomi)}." if t.nomi else None)
    nomi = _nomi_colonne(t, _lista_colonne(colonne), "seleziona")
    return Tabella(nomi, {n: list(t.dati[n]) for n in nomi}, t.righe_n)


@metodo_oggetto(Tabella, "togli_colonne")
def tab_togli_colonne(t, *colonne):
    """t.togli_colonne(colonne...): una tabella senza le colonne indicate.

    Esempio: `variabile pubblica = iscritti.togli_colonne("email", "telefono")`.
    """
    if not colonne:
        raise ErroreValore("`togli_colonne` vuole almeno il nome di una colonna.")
    via = set(_nomi_colonne(t, _lista_colonne(colonne), "togli_colonne"))
    nomi = [n for n in t.nomi if n not in via]
    return Tabella(nomi, {n: list(t.dati[n]) for n in nomi}, t.righe_n)


@metodo_oggetto(Tabella, "rinomina")
def tab_rinomina(t, vecchio, nuovo=None):
    """t.rinomina(vecchio, nuovo): una tabella con una colonna che ha un nome nuovo.

    Per cambiarne tante insieme usa un dizionario: `t.rinomina({"nm": "nome", "vt": "voto"})`.
    Esempio: `variabile t2 = t.rinomina("Voto finale", "voto")`.
    """
    if isinstance(vecchio, dict):
        if nuovo is not None:
            raise ErroreValore("Con un dizionario `rinomina` non vuole il secondo argomento.")
        cambi = vecchio
    else:
        if nuovo is None:
            raise ErroreValore("`rinomina` vuole il nome vecchio e quello nuovo.",
                               suggerimento="Esempio: `t.rinomina(\"vt\", \"voto\")`.")
        cambi = {_nome_colonna(t, vecchio, "rinomina"): nuovo}
    mappa: dict[str, str] = {}
    for v, n in cambi.items():
        mappa[_nome_colonna(t, v, "rinomina")] = _nome_nuovo(n, "rinomina")
    nomi = [mappa.get(n, n) for n in t.nomi]
    doppi = sorted({n for n in nomi if nomi.count(n) > 1})
    if doppi:
        raise ErroreValore(f"Dopo `rinomina` ci sarebbero due colonne `{doppi[0]}`.",
                           suggerimento="Scegli un nome che la tabella non ha già.")
    return Tabella(nomi, {mappa.get(n, n): list(c) for n, c in t.dati.items()}, t.righe_n)


@metodo_oggetto(Tabella, "aggiungi_colonna", interprete=True)
def tab_aggiungi_colonna(interprete, t, nome, valori):
    """t.aggiungi_colonna(nome, valori): una tabella con una colonna in più (o cambiata, se c'è già).

    `valori` è una funzione che riceve la riga e calcola la cella, una lista (un valore per riga)
    o un valore solo, uguale per tutte le righe.
    Esempio: `t = t.aggiungi_colonna("totale", funzione (r) restituisci r["prezzo"] * r["quantità"] fine)`.
    """
    nome = _nome_nuovo(nome, "aggiungi_colonna")
    n = t.righe_n
    if isinstance(valori, Richiamabile):
        nomi = t.nomi
        colonne = [t.dati[c] for c in nomi]
        if nomi:
            nuova = [chiama_funzione(interprete, valori, [dict(zip(nomi, riga))]) for riga in zip(*colonne)]
        else:
            nuova = []
    elif isinstance(valori, list):
        if len(valori) != n:
            raise ErroreValore(f"La lista di `aggiungi_colonna` ha {len(valori)} valori, ma la tabella ha {n} righe.",
                               suggerimento="Serve un valore per ogni riga (oppure una funzione che lo calcola).")
        nuova = list(valori)
    else:
        nuova = [valori] * n
    esistente = None
    for c in t.nomi:
        if c == nome:
            esistente = c
    nomi = list(t.nomi) if esistente else t.nomi + [nome]
    dati = {c: (nuova if c == nome else list(t.dati[c])) for c in nomi}
    return Tabella(nomi, dati, n)


@metodo_oggetto(Tabella, "trasforma_colonna", interprete=True)
def tab_trasforma_colonna(interprete, t, nome, funzione):
    """t.trasforma_colonna(nome, funzione): una tabella in cui ogni cella della colonna è cambiata dalla funzione.

    Esempio: `t = t.trasforma_colonna("nome", maiuscolo)` oppure
    `t.trasforma_colonna("prezzo", funzione (p) restituisci arrotonda(p * 1.22, 2) fine)`.
    """
    nome = _nome_colonna(t, nome, "trasforma_colonna")
    if not isinstance(funzione, Richiamabile):
        raise ErroreTipo(f"Il secondo argomento di `trasforma_colonna` deve essere una funzione, "
                         f"non {articolo(funzione)}.",
                         suggerimento="Esempio: `t.trasforma_colonna(\"nome\", maiuscolo)`.")
    nuova = [chiama_funzione(interprete, funzione, [v]) for v in t.dati[nome]]
    return Tabella(list(t.nomi), {c: (nuova if c == nome else list(v)) for c, v in t.dati.items()}, t.righe_n)


# ===========================================================================
# Metodi: righe
# ===========================================================================

@metodo_oggetto(Tabella, "aggiungi_riga")
def tab_aggiungi_riga(t, riga):
    """t.aggiungi_riga(riga): aggiunge una riga in fondo alla tabella (cambia proprio questa tabella).

    La riga è un dizionario (le colonne che mancano restano `nulla`, quelle nuove si aggiungono)
    oppure una lista con un valore per colonna.
    Esempio: `voti.aggiungi_riga({"nome": "Carla", "voto": 8})`.
    """
    if isinstance(riga, dict):
        for k, v in riga.items():
            if not isinstance(k, str) or not k.strip():
                raise ErroreTipo(f"I nomi delle colonne devono essere testi, non {articolo(k)}.")
        nuove = [k for k in riga if k not in t.dati]
        for k in nuove:
            t.nomi.append(k)
            t.dati[k] = [None] * t.righe_n
        for c in t.nomi:
            t.dati[c].append(riga.get(c))
    elif isinstance(riga, list):
        if len(riga) != len(t.nomi):
            raise ErroreValore(f"La riga ha {len(riga)} valori, ma la tabella ha {len(t.nomi)} colonne.",
                               suggerimento=f"Colonne: {_elenco(t.nomi)}." if t.nomi else
                               "Per una tabella senza colonne usa un dizionario: `{\"nome\": \"Ada\"}`.")
        for c, v in zip(t.nomi, riga):
            t.dati[c].append(v)
    else:
        raise ErroreTipo(f"`aggiungi_riga` vuole un dizionario o una lista, non {articolo(riga)}.",
                         suggerimento="Esempio: `t.aggiungi_riga({\"nome\": \"Carla\", \"voto\": 8})`.")
    t.righe_n += 1
    return None


def _come_tabella(altra: Any, metodo: str) -> Tabella:
    if isinstance(altra, Tabella):
        return altra
    if isinstance(altra, list):
        return crea_tabella_da(altra, None, metodo)
    raise ErroreTipo(f"`{metodo}` vuole un'altra tabella, non {articolo(altra)}.",
                     suggerimento="Esempio: `classe_a.accoda(classe_b)`.")


@metodo_oggetto(Tabella, "accoda")
def tab_accoda(t, altra):
    """t.accoda(altra): una tabella con le righe di questa e poi quelle dell'altra (le colonne si uniscono).

    Esempio: `variabile tutti = classe_a.accoda(classe_b)`.
    """
    b = _come_tabella(altra, "accoda")
    nomi = list(t.nomi) + [n for n in b.nomi if n not in t.dati]
    dati = {n: (t.dati[n] if n in t.dati else [None] * t.righe_n)
            + (b.dati[n] if n in b.dati else [None] * b.righe_n) for n in nomi}
    return Tabella(nomi, dati, t.righe_n + b.righe_n)


@metodo_oggetto(Tabella, "togli_duplicati")
def tab_togli_duplicati(t, colonne=None):
    """t.togli_duplicati(colonne = nulla): una tabella senza righe ripetute (resta la prima).

    Con `colonne` due righe sono uguali se sono uguali solo in quelle colonne.
    Esempi: `t.togli_duplicati()`, `iscritti.togli_duplicati("email")`.
    """
    nomi = t.nomi if colonne is None else _nomi_colonne(t, colonne, "togli_duplicati")
    colonne_dati = [t.dati[c] for c in nomi]
    visti: set = set()
    indici = []
    for i in range(t.righe_n):
        k = tuple(_chiave(c[i]) for c in colonne_dati)
        if k not in visti:
            visti.add(k)
            indici.append(i)
    return t.prendi_righe(indici)


@metodo_oggetto(Tabella, "togli_mancanti")
def tab_togli_mancanti(t, colonne=None):
    """t.togli_mancanti(colonne = nulla): una tabella senza le righe che hanno celle vuote.

    Con `colonne` si guardano solo quelle colonne.
    Esempio: `variabile complete = sondaggio.togli_mancanti(["età", "voto"])`.
    """
    nomi = t.nomi if colonne is None else _nomi_colonne(t, colonne, "togli_mancanti")
    colonne_dati = [t.dati[c] for c in nomi]
    indici = [i for i in range(t.righe_n) if not any(mancante(c[i]) for c in colonne_dati)]
    return t.prendi_righe(indici)


@metodo_oggetto(Tabella, "riempi_mancanti")
def tab_riempi_mancanti(t, valore, colonne=None):
    """t.riempi_mancanti(valore, colonne = nulla): una tabella in cui le celle vuote hanno quel valore.

    Con un dizionario si sceglie un valore per colonna: `t.riempi_mancanti({"voto": 0, "note": "-"})`.
    Esempio: `variabile t2 = t.riempi_mancanti(0)`.
    """
    if isinstance(valore, dict):
        if colonne is not None:
            raise ErroreValore("Con un dizionario `riempi_mancanti` non vuole anche `colonne`.")
        valori = {_nome_colonna(t, c, "riempi_mancanti"): v for c, v in valore.items()}
    else:
        nomi = t.nomi if colonne is None else _nomi_colonne(t, colonne, "riempi_mancanti")
        valori = {c: valore for c in nomi}
    dati = {}
    for c in t.nomi:
        if c in valori:
            v = valori[c]
            dati[c] = [v if mancante(x) else x for x in t.dati[c]]
        else:
            dati[c] = list(t.dati[c])
    return Tabella(list(t.nomi), dati, t.righe_n)


# ===========================================================================
# Metodi: ordinare
# ===========================================================================

_DECRESCENTE = ("decrescente", "discendente", "dal più grande", "desc")
_CRESCENTE = ("crescente", "ascendente", "asc")


def _criteri(t: Tabella, colonne: Any, decrescente: bool) -> list[tuple[str, bool]]:
    if isinstance(colonne, str):
        colonne = colonne.split(",") if "," in colonne and colonne not in t.dati else [colonne]
    if not isinstance(colonne, list) or not colonne:
        raise ErroreTipo(f"`ordina` vuole il nome di una colonna o una lista di nomi, non {articolo(colonne)}.",
                         suggerimento="Esempi: `t.ordina(\"voto\")`, `t.ordina([\"classe\", \"nome\"])`, "
                                      "`t.ordina(\"voto decrescente, nome\")`.")
    criteri = []
    for c in colonne:
        giu = decrescente
        if isinstance(c, str) and c.strip() not in t.dati:
            parole = c.strip().rsplit(None, 1)
            if len(parole) == 2 and parole[1].lower() in _DECRESCENTE + _CRESCENTE:
                c, giu = parole[0], parole[1].lower() in _DECRESCENTE
        criteri.append((_nome_colonna(t, c.strip() if isinstance(c, str) else c, "ordina"), giu))
    return criteri


@metodo_oggetto(Tabella, "ordina")
def tab_ordina(t, colonne, decrescente=False):
    """t.ordina(colonne, decrescente = falso): una tabella con le righe in ordine secondo una o più colonne.

    I testi vanno in ordine alfabetico (senza badare alle maiuscole), le celle vuote sempre in fondo.
    Esempi: `t.ordina("voto", decrescente = vero)`, `t.ordina(["classe", "nome"])`,
    `t.ordina("classe, voto decrescente")`.
    """
    richiedi_logico(decrescente, "ordina", "decrescente")
    indici = list(range(t.righe_n))
    for nome, giu in reversed(_criteri(t, colonne, decrescente)):
        colonna = t.dati[nome]
        pieni = [i for i in indici if not mancante(colonna[i])]
        vuoti = [i for i in indici if mancante(colonna[i])]
        pieni.sort(key=lambda i: _ordine(colonna[i]), reverse=giu)
        indici = pieni + vuoti
    return t.prendi_righe(indici)


# ===========================================================================
# Metodi: raggruppare e riassumere
# ===========================================================================

def _numeri(valori: list, calcolo: str, colonna: str) -> list:
    numeri = [v for v in valori if not mancante(v)]
    for v in numeri:
        if not e_numero(v):
            raise ErroreTipo(f"Non posso calcolare \"{calcolo}\" sulla colonna `{colonna}`: contiene "
                             f"{articolo(v)} ({mostra(v)}).",
                             suggerimento="Si può fare solo con i numeri. Con i testi usa \"conta\", \"primo\", "
                                          "\"elenco\" o \"diversi\".")
    return numeri


def _somma(v: list, c: str) -> Any:
    numeri = _numeri(v, "somma", c)
    if all(type(x) is int for x in numeri):
        return sum(numeri)
    return math.fsum(numeri)


def _media(v: list, c: str) -> Any:
    numeri = _numeri(v, "media", c)
    return math.fsum(numeri) / len(numeri) if numeri else None


def _mediana(v: list, c: str) -> Any:
    numeri = sorted(_numeri(v, "mediana", c))
    if not numeri:
        return None
    m = len(numeri) // 2
    return numeri[m] if len(numeri) % 2 else (numeri[m - 1] + numeri[m]) / 2


def _estremo(v: list, c: str, piu_grande: bool) -> Any:
    pieni = [x for x in v if not mancante(x)]
    if not pieni:
        return None
    scelta = max if piu_grande else min
    return scelta(pieni, key=_ordine)


def _distinti(v: list) -> int:
    return len({_chiave(x) for x in v if not mancante(x)})


_CALCOLI: dict[str, Callable[[list, str], Any]] = {
    "somma": _somma,
    "media": _media,
    "mediana": _mediana,
    "conta": lambda v, c: sum(1 for x in v if not mancante(x)),
    "minimo": lambda v, c: _estremo(v, c, False),
    "massimo": lambda v, c: _estremo(v, c, True),
    "primo": lambda v, c: next((x for x in v if not mancante(x)), None),
    "ultimo": lambda v, c: next((x for x in reversed(v) if not mancante(x)), None),
    "elenco": lambda v, c: [x for x in v if not mancante(x)],
    "diversi": lambda v, c: _distinti(v),
}
_SINONIMI_CALCOLO = {"totale": "somma", "conteggio": "conta", "quanti": "conta", "min": "minimo",
                     "max": "massimo", "lista": "elenco", "distinti": "diversi", "media aritmetica": "media"}


def _calcolo(nome: Any, metodo: str) -> str:
    if not isinstance(nome, str):
        raise ErroreTipo(f"Il calcolo di `{metodo}` deve essere un testo come \"somma\" o \"media\", "
                         f"non {articolo(nome)}.")
    chiave = nome.strip().lower()
    chiave = _SINONIMI_CALCOLO.get(chiave, chiave)
    if chiave not in _CALCOLI:
        raise ErroreValore(f"Non conosco il calcolo {mostra(nome)}.",
                           suggerimento="Calcoli: " + ", ".join(f"\"{c}\"" for c in _CALCOLI) + ".")
    return chiave


def _gruppi(t: Tabella, nomi: list[str], in_ordine: bool = True) -> tuple[list[tuple], dict[tuple, list[int]]]:
    """Le chiavi dei gruppi (in ordine, o come compaiono) e gli indici delle righe di ogni gruppo."""
    colonne = [t.dati[c] for c in nomi]
    indici: dict[tuple, list[int]] = {}
    esempio: dict[tuple, tuple] = {}
    for i in range(t.righe_n):
        valori = tuple(c[i] for c in colonne)
        k = tuple(_chiave(v) for v in valori)
        gruppo = indici.get(k)
        if gruppo is None:
            indici[k] = [i]
            esempio[k] = tuple(None if mancante(v) else v for v in valori)
        else:
            gruppo.append(i)

    def ordine(k: tuple) -> tuple:
        return tuple((1,) if v is None else (0, _ordine(v)) for v in esempio[k])

    chiavi = sorted(indici, key=ordine) if in_ordine else list(indici)
    return [(k, esempio[k]) for k in chiavi], indici


@metodo_oggetto(Tabella, "raggruppa")
def tab_raggruppa(t, colonne, calcoli=None):
    """t.raggruppa(colonne, calcoli = nulla): una riga per ogni gruppo, con i calcoli sulle altre colonne.

    `calcoli` è un dizionario colonna -> calcolo ("somma", "media", "mediana", "conta", "minimo",
    "massimo", "primo", "ultimo", "elenco", "diversi"), anche più di uno con una lista.
    Le colonne nuove si chiamano come "media_voto". Senza calcoli conta le righe di ogni gruppo.
    Esempio: `stampa(voti.raggruppa("classe", {"voto": ["media", "massimo"], "nome": "conta"}))`.
    """
    nomi = _nomi_colonne(t, colonne, "raggruppa")
    richieste: list[tuple[str, str, str]] = []  # (colonna, calcolo, nome nuovo)
    if calcoli is None:
        pass
    elif isinstance(calcoli, dict):
        for c, quali in calcoli.items():
            colonna = _nome_colonna(t, c, "raggruppa")
            for q in (quali if isinstance(quali, list) else [quali]):
                calcolo = _calcolo(q, "raggruppa")
                richieste.append((colonna, calcolo, f"{calcolo}_{colonna}"))
    elif isinstance(calcoli, str):
        calcolo = _calcolo(calcoli, "raggruppa")
        for colonna in t.nomi:
            if colonna not in nomi:
                richieste.append((colonna, calcolo, f"{calcolo}_{colonna}"))
    else:
        raise ErroreTipo(f"I calcoli di `raggruppa` devono essere un dizionario, non {articolo(calcoli)}.",
                         suggerimento="Esempio: `t.raggruppa(\"classe\", {\"voto\": \"media\"})`.")
    chiavi, indici = _gruppi(t, nomi)
    nuovi = _unici(list(nomi) + ([n for _, _, n in richieste] if richieste else ["conteggio"]))
    risultato: list[list] = []
    for k, valori in chiavi:
        righe = indici[k]
        riga = list(valori)
        if not richieste:
            riga.append(len(righe))
        for colonna, calcolo, _ in richieste:
            dati = t.dati[colonna]
            riga.append(_CALCOLI[calcolo]([dati[i] for i in righe], colonna))
        risultato.append(riga)
    return _crea(nuovi, risultato)


@metodo_oggetto(Tabella, "tabella_incrociata")
def tab_tabella_incrociata(t, righe, colonne, valori=None, calcolo="somma"):
    """t.tabella_incrociata(righe, colonne, valori = nulla, calcolo = "somma"): una tabella pivot (a doppia entrata).

    Una riga per ogni valore della colonna `righe`, una colonna per ogni valore della colonna
    `colonne` (nell'ordine in cui compaiono); nelle celle il calcolo sulla colonna `valori`
    (senza `valori` conta le righe).
    Esempio: `stampa(vendite.tabella_incrociata("negozio", "mese", "incasso"))`.
    """
    nome_righe = _nome_colonna(t, righe, "tabella_incrociata")
    nome_colonne = _nome_colonna(t, colonne, "tabella_incrociata")
    if valori is None:
        nome_valori, calcolo_nome = None, "conta"
    else:
        nome_valori = _nome_colonna(t, valori, "tabella_incrociata")
        calcolo_nome = _calcolo(calcolo, "tabella_incrociata")
    chiavi_r, _ = _gruppi(t, [nome_righe])
    chiavi_c, _ = _gruppi(t, [nome_colonne], in_ordine=False)
    if len(chiavi_c) > 1000:
        raise ErroreValore(f"La colonna `{nome_colonne}` ha {len(chiavi_c)} valori diversi: "
                           "troppi per diventare colonne.",
                           suggerimento="Scegli per `colonne` una colonna con pochi valori diversi (come il mese).")
    celle: dict[tuple, list] = {}
    dr, dc = t.dati[nome_righe], t.dati[nome_colonne]
    dv = t.dati[nome_valori] if nome_valori else None
    for i in range(t.righe_n):
        k = (_chiave(dr[i]), _chiave(dc[i]))
        celle.setdefault(k, []).append(dv[i] if dv is not None else 1)
    intestazioni = ["(vuoto)" if v[0] is None else _testo_colonna(v[0], j) for j, (_, v) in enumerate(chiavi_c)]
    nomi = _unici([nome_righe] + intestazioni)
    risultato = []
    for kr, vr in chiavi_r:
        riga = [vr[0]]
        for kc, _ in chiavi_c:
            lista = celle.get((kr[0], kc[0]))
            if lista is None:
                riga.append(0 if calcolo_nome in ("conta", "somma") else None)
            else:
                riga.append(len(lista) if nome_valori is None else _CALCOLI[calcolo_nome](lista, nome_valori))
        risultato.append(riga)
    return _crea(nomi, risultato)


@metodo_oggetto(Tabella, "conta_valori")
def tab_conta_valori(t, colonna):
    """t.conta_valori(colonna): quante volte compare ogni valore della colonna, dal più frequente.

    Il risultato ha le colonne: il valore, `conteggio` e `percentuale`.
    Esempio: `stampa(sondaggio.conta_valori("colore_preferito"))`.
    """
    nome = _nome_colonna(t, colonna, "conta_valori")
    conteggi: dict[Any, int] = {}
    esempio: dict[Any, Any] = {}
    for v in t.dati[nome]:
        k = _chiave(v)
        if k in conteggi:
            conteggi[k] += 1
        else:
            conteggi[k] = 1
            esempio[k] = None if mancante(v) else v
    totale = t.righe_n
    ordine = sorted(conteggi, key=lambda k: (-conteggi[k], esempio[k] is None, _ordine(esempio[k])))
    righe = [[esempio[k], conteggi[k], round(conteggi[k] * 100 / totale, 2)] for k in ordine]
    return _crea(_unici([nome, "conteggio", "percentuale"]), righe)


@metodo_oggetto(Tabella, "riassumi")
def tab_riassumi(t):
    """t.riassumi(): una tabella con le statistiche di ogni colonna.

    Per ogni colonna: tipo, valori pieni, mancanti, valori diversi, minimo, massimo, media e
    somma (queste ultime due solo per le colonne di numeri).
    Esempio: `stampa(voti.riassumi())`.
    """
    righe = []
    for c in t.nomi:
        dati = t.dati[c]
        pieni = [v for v in dati if not mancante(v)]
        numeri = all(e_numero(v) for v in pieni)
        if not pieni:
            tipo = "vuota"
        elif numeri:
            tipo = "numeri"
        elif all(isinstance(v, str) for v in pieni):
            tipo = "testi"
        else:
            tipo = "misto"
        media = somma = None
        if pieni and numeri:
            somma = _somma(pieni, c)
            media = somma / len(pieni)
        righe.append([c, tipo, len(pieni), t.righe_n - len(pieni), _distinti(pieni),
                      _estremo(pieni, c, False), _estremo(pieni, c, True), media, somma])
    return _crea(["colonna", "tipo", "valori", "mancanti", "diversi", "minimo", "massimo", "media", "somma"],
                 righe)


@metodo_oggetto(Tabella, "statistiche")
def tab_statistiche(t, colonna):
    """t.statistiche(colonna): un dizionario con i numeri principali di una colonna.

    Chiavi: "conta" (celle piene), "mancanti", "diversi", "minimo", "massimo" e, per le colonne
    di numeri, anche "somma", "media", "mediana" e "deviazione" (deviazione standard).
    Esempio: `variabile s = voti.statistiche("voto")` poi `stampa(s["media"], s["massimo"])`.
    """
    nome = _nome_colonna(t, colonna, "statistiche")
    dati = t.dati[nome]
    pieni = [v for v in dati if not mancante(v)]
    risultato = {"conta": len(pieni), "mancanti": t.righe_n - len(pieni), "diversi": _distinti(pieni),
                 "minimo": _estremo(pieni, nome, False), "massimo": _estremo(pieni, nome, True)}
    if pieni and all(e_numero(v) for v in pieni):
        somma = _somma(pieni, nome)
        media = math.fsum(pieni) / len(pieni)
        scarti = math.fsum((v - media) ** 2 for v in pieni)
        risultato.update({"somma": somma, "media": media, "mediana": _mediana(pieni, nome),
                          "deviazione": math.sqrt(scarti / (len(pieni) - 1)) if len(pieni) > 1 else 0.0})
    return risultato


@metodo_oggetto(Tabella, "valori_diversi")
def tab_valori_diversi(t, colonna):
    """t.valori_diversi(colonna): la lista dei valori di una colonna, ognuno una volta sola (nell'ordine in cui compaiono).

    Le celle vuote restano fuori.
    Esempio: `stampa(voti.valori_diversi("classe"))` scrive ["1A", "1B"].
    """
    nome = _nome_colonna(t, colonna, "valori_diversi")
    visti: set = set()
    risultato = []
    for v in t.dati[nome]:
        if mancante(v):
            continue
        k = _chiave(v)
        if k not in visti:
            visti.add(k)
            risultato.append(v)
    return risultato


@metodo_oggetto(Tabella, "mancanti")
def tab_mancanti(t):
    """t.mancanti(): un dizionario che dice, per ogni colonna, quante celle sono vuote.

    Esempio: `stampa(sondaggio.mancanti())` scrive per esempio {"nome": 0, "età": 3}.
    """
    return {c: sum(1 for v in t.dati[c] if mancante(v)) for c in t.nomi}


# ===========================================================================
# Metodi: unire tabelle
# ===========================================================================

_MODI = {"interno": "interno", "solo comuni": "interno", "comuni": "interno",
         "sinistra": "sinistra", "tutte a sinistra": "sinistra", "prima": "sinistra",
         "completo": "completo", "tutte": "completo", "esterno": "completo"}


@metodo_oggetto(Tabella, "unisci")
def tab_unisci(t, altra, colonna, modo="interno"):
    """t.unisci(altra, colonna, modo = "interno"): affianca le righe delle due tabelle che hanno lo stesso valore nella colonna.

    Modi: "interno" (solo le righe che si trovano in tutte e due), "sinistra" (tutte le righe di
    questa tabella, anche senza compagna), "completo" (tutte le righe di tutte e due).
    Le colonne con lo stesso nome nell'altra tabella prendono "_2" in fondo.
    Esempio: `variabile pagelle = studenti.unisci(voti, "matricola")`.
    """
    b = _come_tabella(altra, "unisci")
    nomi_a = _nomi_colonne(t, colonna, "unisci", "colonna")
    nomi_b = _nomi_colonne(b, colonna, "unisci", "colonna")
    if not isinstance(modo, str) or modo.strip().lower() not in _MODI:
        raise ErroreValore(f"Il modo di `unisci` deve essere \"interno\", \"sinistra\" o \"completo\", "
                           f"non {mostra(modo)}.")
    modo = _MODI[modo.strip().lower()]
    altre_b = [n for n in b.nomi if n not in nomi_b]
    nomi = list(t.nomi)
    nuovi_b = []
    for n in altre_b:
        nuovo, k = n, 2
        while nuovo in nomi:
            nuovo, k = f"{n}_{k}", k + 1
        nomi.append(nuovo)
        nuovi_b.append(nuovo)
    indice_b: dict[tuple, list[int]] = {}
    chiavi_b = [b.dati[c] for c in nomi_b]
    for j in range(b.righe_n):
        k = tuple(_chiave(c[j]) for c in chiavi_b)
        if (0,) not in k:  # le celle vuote non si uniscono mai
            indice_b.setdefault(k, []).append(j)
    chiavi_a = [t.dati[c] for c in nomi_a]
    usate_b: set[int] = set()
    risultato: list[list] = []
    colonne_a = [t.dati[c] for c in t.nomi]
    colonne_b = [b.dati[c] for c in altre_b]
    vuoti_b = [None] * len(altre_b)
    for i in range(t.righe_n):
        k = tuple(_chiave(c[i]) for c in chiavi_a)
        compagne = indice_b.get(k) if (0,) not in k else None
        riga_a = [c[i] for c in colonne_a]
        if compagne:
            for j in compagne:
                usate_b.add(j)
                risultato.append(riga_a + [c[j] for c in colonne_b])
        elif modo != "interno":
            risultato.append(riga_a + vuoti_b)
    if modo == "completo":
        posizioni = {n: t.nomi.index(n) for n in nomi_a}
        for j in range(b.righe_n):
            if j not in usate_b:
                riga = [None] * len(t.nomi)
                for na, nb in zip(nomi_a, nomi_b):
                    riga[posizioni[na]] = b.dati[nb][j]
                risultato.append(riga + [c[j] for c in colonne_b])
    return _crea(nomi, risultato)


# ===========================================================================
# Metodi: salvare e disegnare
# ===========================================================================

def _cella_csv(v: Any, excel: bool) -> str:
    if v is None or (type(v) is float and v != v):
        return ""
    if excel and type(v) is float:
        return rappresenta(v).replace(".", ",")
    try:
        return rappresenta(v)
    except (ValueError, RecursionError):
        return mostra(v)


def testo_csv(t: Tabella, separatore: str, excel: bool) -> str:
    uscita = io.StringIO()
    scrittore = csv.writer(uscita, delimiter=separatore, lineterminator="\r\n" if excel else "\n")
    scrittore.writerow(t.nomi)
    colonne = [t.dati[c] for c in t.nomi]
    virgola = excel and separatore != ","
    for i in range(t.righe_n):
        scrittore.writerow([_cella_csv(c[i], virgola) for c in colonne])
    return uscita.getvalue()


def testo_json(t: Tabella) -> str:
    from .archivi import a_json

    return a_json(t.righe_dict(), 2)


def testo_html(t: Tabella, titolo: str = "") -> str:
    e = html.escape
    parti = ["<table>"]
    if titolo:
        parti.append(f"  <caption>{e(titolo)}</caption>")
    parti.append("  <thead><tr>" + "".join(f"<th>{e(c)}</th>" for c in t.nomi) + "</tr></thead>")
    parti.append("  <tbody>")
    colonne = [t.dati[c] for c in t.nomi]
    for i in range(t.righe_n):
        celle = []
        for c in colonne:
            v = c[i]
            classe = ' class="numero"' if e_numero(v) else ""
            celle.append(f"<td{classe}>{e(_cella_csv(v, False))}</td>")
        parti.append("    <tr>" + "".join(celle) + "</tr>")
    parti.append("  </tbody>")
    parti.append("</table>")
    return "\n".join(parti)


_STILE_HTML = ("body{font-family:sans-serif;margin:2em}table{border-collapse:collapse}"
               "th,td{border:1px solid #ccc;padding:4px 10px}th{background:#eef}"
               "td.numero{text-align:right}caption{font-weight:bold;margin-bottom:.5em}")


def _pagina_html(t: Tabella, titolo: str) -> str:
    return ("<!doctype html>\n<html lang=\"it\">\n<head>\n<meta charset=\"utf-8\">\n"
            f"<title>{html.escape(titolo or 'Tabella')}</title>\n<style>{_STILE_HTML}</style>\n</head>\n<body>\n"
            + testo_html(t, titolo) + "\n</body>\n</html>\n")


def _testo_markdown(t: Tabella) -> str:
    def cella(v: Any) -> str:
        return _cella_csv(v, False).replace("|", "\\|").replace("\n", " ")

    righe = ["| " + " | ".join(cella(c) for c in t.nomi) + " |",
             "|" + "|".join("---" for _ in t.nomi) + "|"]
    colonne = [t.dati[c] for c in t.nomi]
    for i in range(t.righe_n):
        righe.append("| " + " | ".join(cella(c[i]) for c in colonne) + " |")
    return "\n".join(righe) + "\n"


@metodo_oggetto(Tabella, "salva")
def tab_salva(t, percorso, excel=False):
    """t.salva(percorso, excel = falso): salva la tabella in un file; il formato dipende dall'estensione.

    .csv (con `excel = vero` pronto per l'Excel italiano: `;` e virgola decimale), .tsv, .json,
    .html (una pagina da aprire nel browser) o .md. Restituisce il percorso.
    Esempio: `classifica.salva("classifica.csv")`.
    """
    _controlla_percorso(percorso, "salva")
    richiedi_logico(excel, "salva", "excel")
    estensione = os.path.splitext(percorso)[1].lower()
    codifica = "utf-8"
    if estensione in (".csv", ".txt", ""):
        testo = testo_csv(t, ";" if excel else ",", excel)
        codifica = "utf-8-sig" if excel else "utf-8"
    elif estensione in (".tsv", ".tab"):
        testo = testo_csv(t, "\t", excel)
    elif estensione == ".json":
        testo = testo_json(t) + "\n"
    elif estensione in (".html", ".htm"):
        testo = _pagina_html(t, os.path.splitext(os.path.basename(percorso))[0])
    elif estensione == ".md":
        testo = _testo_markdown(t)
    else:
        raise ErroreValore(f"Non so salvare una tabella in un file `{estensione}`.",
                           suggerimento="Usa un nome che finisce con .csv, .tsv, .json, .html o .md.")
    try:
        with open(percorso, "w", encoding=codifica, newline="") as f:
            f.write(testo)
    except OSError as e:
        raise _errore_file(e, percorso, "scrivere") from None
    except ValueError:
        raise ErroreFile(f"Il percorso `{percorso}` non è valido.") from None
    return percorso


@metodo_oggetto(Tabella, "in_html")
def tab_in_html(t, titolo=""):
    """t.in_html(titolo = ""): la tabella come testo HTML (`<table>...</table>`), da mettere in una pagina.

    Esempio: `variabile pagina = "<h1>Voti</h1>" + voti.in_html()`.
    """
    richiedi_testo(titolo, "in_html", "titolo")
    return testo_html(t, titolo)


@metodo_oggetto(Tabella, "in_csv")
def tab_in_csv(t, separatore=","):
    """t.in_csv(separatore = ","): la tabella come testo CSV (la prima riga sono i nomi delle colonne).

    Esempio: `scrivi_file("voti.csv", voti.in_csv())` oppure `voti.in_csv(";")`.
    """
    _controlla_separatore(separatore, "in_csv")
    return testo_csv(t, separatore, False)


@metodo_oggetto(Tabella, "in_json")
def tab_in_json(t):
    """t.in_json(): la tabella come testo JSON (una lista di oggetti, uno per riga).

    Esempio: `variabile testo = voti.in_json()`, da mandare a un sito o da salvare.
    """
    return testo_json(t)


@metodo_oggetto(Tabella, "salva_in_database")
def tab_salva_in_database(t, database, nome, sostituisci=False):
    """t.salva_in_database(database, nome, sostituisci = falso): copia le righe in una tabella di un database SQLite.

    Se la tabella del database non c'è, si crea con i tipi giusti; se c'è si aggiungono le righe
    (con `sostituisci = vero` prima si cancella). `database` è un database aperto o un percorso.
    Esempio: `voti.salva_in_database("scuola.db", "voti")`.
    """
    from .database import db_inserisci

    richiedi_testo(nome, "salva_in_database", "nome")
    richiedi_logico(sostituisci, "salva_in_database", "sostituisci")
    if not t.nomi:
        raise ErroreValore("La tabella non ha colonne: non c'è niente da salvare.")
    db, chiudi = _database(database, "salva_in_database", True)
    try:
        esiste = nome in db.motore.tabelle()
        if esiste and sostituisci:
            db.motore.elimina_tabella(nome)
            esiste = False
        if not esiste:
            db.motore.crea_tabella(nome, {c: _tipo_sql(t.dati[c]) for c in t.nomi})
        if t.righe_n:
            righe = [{c: (None if mancante(v) else v) for c, v in r.items()} for r in t.righe_dict()]
            db_inserisci(db, nome, righe)
        return t.righe_n
    finally:
        if chiudi:
            db.motore.chiudi()


def _tipo_sql(valori: list) -> str:
    pieni = [v for v in valori if not mancante(v)]
    if pieni and all(type(v) is bool for v in pieni):
        return "logico"
    if pieni and all(type(v) is int for v in pieni):
        return "intero"
    if pieni and all(type(v) in (int, float) for v in pieni):
        return "decimale"
    return "testo"


@metodo_oggetto(Tabella, "grafico")
def tab_grafico(t, tipo="barre", etichette=None, valori=None, titolo=""):
    """t.grafico(tipo = "barre", etichette = nulla, valori = nulla, titolo = ""): un grafico con i dati della tabella.

    `etichette` è la colonna dei nomi sull'asse, `valori` una colonna di numeri (o una lista di
    colonne, per più serie). Senza `valori` conta quante volte compare ogni etichetta.
    Per "istogramma" basta una colonna di numeri; per "dispersione" le colonne x e y.
    Esempi: `vendite.grafico("barre", "mese", "incasso").mostra()`,
    `sondaggio.grafico("torta", "colore").salva("colori.png")`.
    """
    from .diagrammi import _esegui, _nuovo, normalizza_tipo

    tipo_n = _esegui(normalizza_tipo, tipo)
    if not isinstance(titolo, str):
        raise ErroreTipo(f"Il titolo di `grafico` deve essere un testo, non {articolo(titolo)}.")
    if tipo_n == "istogramma":
        nome = _nome_colonna(t, valori if valori is not None else etichette, "grafico")
        g = _nuovo("istogramma", None, titolo, "grafico")
        _esegui(g.aggiungi_serie, nome, _numeri(t.dati[nome], "istogramma", nome), "")
        g.titolo_x = nome
        return g
    if etichette is None:
        raise ErroreValore("`grafico` vuole almeno la colonna delle etichette.",
                           suggerimento="Esempio: `t.grafico(\"barre\", \"mese\", \"incasso\")`.")
    nome_x = _nome_colonna(t, etichette, "grafico")
    g = _nuovo(tipo_n, None, titolo, "grafico")
    g.titolo_x = nome_x
    colonna_x = t.dati[nome_x]
    if valori is None:
        conteggi = tab_conta_valori(t, nome_x)
        dati = [[_cella_csv(v, False) or "(vuoto)", q]
                for v, q in zip(conteggi.dati[conteggi.nomi[0]], conteggi.dati["conteggio"])]
        _esegui(g.aggiungi_serie, "conteggio", dati, "")
        return g
    nomi_y = _nomi_colonne(t, valori, "grafico", "valori")
    if tipo_n in ("torta", "anello") and len(nomi_y) > 1:
        raise ErroreValore(f"Un grafico a {tipo_n} ha una sola serie: scegli una sola colonna di valori.")
    for nome_y in nomi_y:
        colonna_y = t.dati[nome_y]
        _numeri(colonna_y, "grafico", nome_y)
        if tipo_n == "dispersione":
            _numeri(colonna_x, "dispersione", nome_x)
            dati = [[x, y] for x, y in zip(colonna_x, colonna_y) if not mancante(x) and not mancante(y)]
        else:
            dati = [[_cella_csv(x, False) or "(vuoto)", y] for x, y in zip(colonna_x, colonna_y)
                    if not mancante(y)]
        _esegui(g.aggiungi_serie, nome_y, dati, "")
    if len(nomi_y) == 1:
        g.titolo_y = nomi_y[0]
    return g
