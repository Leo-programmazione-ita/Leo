"""Colorazione della sintassi di Leo (API in docs/CONTRATTI.md, sezione 11.1).

La colorazione riusa il lexer dell'interprete (modalita' ``tollerante`` +
``conserva_commenti``), cosi' editor e linguaggio non possono mai essere in
disaccordo. Se il lexer non e' disponibile o fallisce, un lexer di ripiego
interno (piu' semplice) produce comunque segmenti sensati: :func:`colora` non
solleva mai eccezioni.

API del contratto::

    Segmento(riga, colonna, lunghezza, categoria, sinonimo_di=None, errore=None)
    colora(sorgente, *, sinonimi=None, stile=None, controlli=()) -> list[Segmento]
    colora_riga(testo, stato=0, *, sinonimi=None, stile=None, controlli=(),
                funzioni_utente=(), nomi_noti=None, riga=None) -> tuple[list[Segmento], int]
    funzioni_definite(sorgente) -> set[str]
    nomi_noti(sorgente, *, sinonimi=None, stile=None) -> NomiNoti   # variabili, costanti, parametri
    coppia_blocco(sorgente, riga, colonna) -> tuple[int, int] | None
    ansi(sorgente, tema) -> str

Funzioni pubbliche in piu' (per il terminale di Studio, senza Qt)::

    segmenti_ansi(testo) -> list[tuple[str, dict]]
    AnalizzatoreAnsi().analizza(pezzo)             # come sopra, con stato tra i pezzi
    rientro_dopo(riga) -> bool                     # rientro automatico dell'editor
    separa_sequenza_incompleta(testo) -> tuple[str, str]
    colore_ansi_16(indice, tema=None) -> str
    trova_riferimento_riga(testo) -> tuple[str, int] | None
    trova_riferimenti_riga(testo) -> list[tuple[int, int, str, int]]

Note:

* ``sinonimi=None`` significa **sinonimi predefiniti** (``dati/sinonimi.toml``),
  perche' nell'editor i sinonimi sono attivi per impostazione; per
  ``--rigoroso`` si passa ``Sinonimi.vuoti()``.
* ``stile=None``: in :func:`colora` si legge l'intestazione ``#stile:`` del
  sorgente; in :func:`colora_riga` si usa lo stile predefinito.
* I segmenti non si sovrappongono e sono ordinati per posizione; un commento
  su piu' righe diventa un segmento per riga. Gli spazi non sono coperti.
* In :func:`colora_riga` ``riga`` vale sempre 1 e le colonne (da 1) sono
  relative alla riga; gli errori che dipendono da altre righe (parentesi
  aperte o chiuse altrove, commento ``#[`` che continua) non si segnalano.
* Categorie di contesto (giro colori): un nome dichiarato o assegnato
  (``variabile x``, ``x = 1``, ``per ogni x in``, ``cattura come e``) e'
  ``VARIABILI``; ``costante N`` e le costanti di libreria (``PI_GRECO``) sono
  ``COSTANTI``; i parametri di una funzione, nel suo corpo, sono ``PARAMETRI``
  (anche ``evento`` dentro ``quando``); dopo il punto: ``EVENTI`` in
  ``quando Pulsante1.clic``, ``PROPRIETA`` per i controlli e i metodi,
  ``CAMPI`` per gli oggetti del programma (``errore.tipo``). L'analisi del
  sorgente intero e' :func:`nomi_noti`: l'editor la passa a
  :func:`colora_riga` (con il numero di ``riga`` nel documento per sapere in
  quale funzione si trova); i nomi dichiarati sulla riga stessa si
  riconoscono comunque, anche prima dell'analisi.
"""

from __future__ import annotations

from bisect import bisect_right
import re
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Iterable

from .categorie import Categoria, categoria_statica
from .tokens import (
    COPPIE_DI_PAROLE,
    OPERATORI,
    PAROLE_CHIAVE,
    ParteInterpolata,
    TipoToken,
    Token,
    parole_potenza,
    teste_di_blocco_potenza,
)

if TYPE_CHECKING:  # pragma: no cover
    from .temi import Tema

T = TipoToken

__all__ = [
    "Segmento", "colora", "colora_riga", "funzioni_definite", "coppia_blocco", "ansi",
    "NomiNoti", "nomi_noti",
    "segmenti_ansi", "separa_sequenza_incompleta", "colore_ansi_16",
    "trova_riferimento_riga", "trova_riferimenti_riga", "AnalizzatoreAnsi", "rientro_dopo",
    "STATO_TESTO_LUNGO",
]

#: Stato di :func:`colora_riga` quando la riga finisce dentro un testo su piu'
#: righe (``\"\"\"``). E' positivo e molto piu' grande di qualunque profondita' di
#: commenti ``#[``, cosi' gli editor che salvano lo stato cosi' com'e' funzionano.
STATO_TESTO_LUNGO = 1_000_000


@dataclass
class Segmento:
    """Un tratto di testo colorato. ``riga``/``colonna`` partono da 1."""

    riga: int
    colonna: int
    lunghezza: int
    categoria: Categoria
    sinonimo_di: str | None = None     # "mentre" se il testo e' un sinonimo (sottolineatura tratteggiata)
    errore: str | None = None          # messaggio se e' un token ERRORE


# ===========================================================================
# Contesto: sinonimi, stile, nomi della libreria e degli errori
# ===========================================================================

_CACHE: dict[str, Any] = {}


def _sinonimi_predefiniti():
    if "sinonimi" not in _CACHE:
        try:
            from .sinonimi import carica_sinonimi

            _CACHE["sinonimi"] = carica_sinonimi()
        except Exception:
            try:
                from .sinonimi import Sinonimi

                _CACHE["sinonimi"] = Sinonimi.vuoti()
            except Exception:
                _CACHE["sinonimi"] = None
    return _CACHE["sinonimi"]


def _stile_di(sorgente: str, stile):
    if stile is not None:
        return stile
    try:
        from .stile import Stile

        return Stile.da_sorgente(sorgente)
    except Exception:
        return None


#: Funzioni di libreria di PROGETTO.md: si colorano anche se la libreria non e' caricabile.
_LIBRERIA_BASE = frozenset({
    "stampa", "chiedi", "leggi_file", "scrivi_file", "tipo", "intero", "decimale", "testo",
    "logico", "lunghezza", "vuota", "intervallo", "assoluto", "arrotonda", "radice", "minimo",
    "massimo", "somma", "casuale", "ora", "oggi", "attendi",
})


def _nomi_libreria() -> set[str]:
    """Nomi delle funzioni di libreria (registro + elenco di base), in cache finche' il registro non cambia."""
    try:
        from . import registro

        try:
            registro.carica_libreria()      # l'import e' in cache: costa poco
        except Exception:
            pass
        chiave = (len(registro.FUNZIONI), len(registro.COSTANTI))
        memo = _CACHE.get("libreria")
        if memo is not None and memo[0] == chiave:
            return memo[1]
        nomi = set(_LIBRERIA_BASE)
        nomi.update(registro.FUNZIONI)
        _CACHE["libreria"] = (chiave, nomi)
        _CACHE["costanti_libreria"] = frozenset(str(n) for n in registro.COSTANTI)
        return nomi
    except Exception:
        return set(_LIBRERIA_BASE)


def _costanti_libreria() -> frozenset[str]:
    """Costanti predefinite (``PI_GRECO``...)."""
    if "costanti_libreria" not in _CACHE:
        _nomi_libreria()
    return _CACHE.get("costanti_libreria") or frozenset({"PI_GRECO"})


#: Eventi comuni dei controlli (se il catalogo dei controlli non e' caricabile).
_EVENTI_BASE = frozenset({
    "clic", "doppio_clic", "apertura", "chiusura", "cambio", "cambia", "invio", "tasto",
    "scatto", "ridimensionamento", "cambio_scheda", "tasto_premuto", "tasto_rilasciato",
    "mouse_premuto", "mouse_rilasciato", "mouse_mosso", "entra", "esce", "fuoco", "perde_fuoco",
})


def _nomi_eventi() -> frozenset[str]:
    """Nomi degli eventi dei controlli che non sono anche nomi di proprieta'."""
    if "eventi" not in _CACHE:
        eventi: set[str] = set(_EVENTI_BASE)
        proprieta: set[str] = set()
        try:
            from .grafica.metadati import carica_catalogo

            for tipo in carica_catalogo().values():
                eventi.update(str(e) for e in (getattr(tipo, "eventi", ()) or ()))
                proprieta.update(str(p) for p in (getattr(tipo, "proprieta", {}) or {}))
        except Exception:
            pass
        _CACHE["eventi"] = frozenset(eventi - proprieta)
    return _CACHE["eventi"]


def _nomi_errori() -> set[str]:
    try:
        from .errori import TIPI_ERRORE

        return set(TIPI_ERRORE)
    except Exception:
        return {"ErroreSintassi", "ErroreNome", "ErroreTipo", "ErroreValore", "ErroreIndice",
                "ErroreChiave", "ErroreDivisione", "ErroreRicorsione", "ErroreFile"}


# ===========================================================================
# Lessico: lexer vero, con ripiego interno
# ===========================================================================

def _lessico(sorgente: str, sinonimi, stile, nomi: Iterable[str] = (),
             comandi: Iterable[str] = ()) -> tuple[list[Token], int]:
    """Token (tollerante, con commenti) e profondita' di ``#[`` aperti alla fine.
    ``nomi``/``comandi``: nomi e comandi dell'utente definiti fuori da ``sorgente``
    (le altre righe del documento), per i comandi senza parentesi."""
    try:
        from .lexer import Lexer

        lx = Lexer(sorgente, sinonimi=sinonimi, stile=stile, conserva_commenti=True, tollerante=True,
                   nomi_noti=nomi, comandi_noti=comandi)
        token = lx.tokenizza()
        if (token and token[0].tipo is T.ERRORE and token[0].origine == "sintetico"
                and str(token[0].valore).startswith("Errore interno")):
            raise RuntimeError(token[0].valore)
        profondita = getattr(lx, "profondita_commento", None)
        if not isinstance(profondita, int):
            profondita = _profondita_finale(sorgente)
        if getattr(lx, "testo_lungo_aperto", False) and not profondita:
            profondita = STATO_TESTO_LUNGO
        return token, profondita
    except Exception:
        return _Ripiego(sorgente, sinonimi, stile).esegui()


def _profondita_finale(sorgente: str, iniziale: int = 0) -> int:
    """Quanti ``#[`` restano aperti alla fine di ``sorgente`` (salta testi e ``#``)."""
    profondita = iniziale
    i, n = 0, len(sorgente)
    while i < n:
        if profondita > 0:
            if sorgente.startswith("#[", i):
                profondita += 1
                i += 2
            elif sorgente.startswith("]#", i):
                profondita -= 1
                i += 2
            else:
                i += 1
            continue
        c = sorgente[i]
        if sorgente.startswith("#[", i):
            profondita = 1
            i += 2
        elif c == "#":
            fine = sorgente.find("\n", i)
            i = n if fine == -1 else fine + 1
        elif c == '"':
            i += 1
            while i < n and sorgente[i] not in '"\n':
                i += 2 if sorgente[i] == "\\" else 1
            i += 1
        else:
            i += 1
    return profondita


class _Ripiego:
    """Lexer semplificato (espressioni regolari) usato solo se ``leo.lexer`` manca o fallisce."""

    _NUMERO = re.compile(r"\d[\d_]*(?:\.\d[\d_]*)?(?:[eE][+-]?\d+)?")
    _SPAZI = " \t\f\v ﻿"

    def __init__(self, sorgente: str, sinonimi, stile, base: int = 0, righe: list[int] | None = None) -> None:
        self.src = sorgente.replace("\r\n", "\n").replace("\r", "\n")
        self.token: list[Token] = []
        self.profondita = 0
        self.inizi = righe if righe is not None else [0] + [i + 1 for i, c in enumerate(self.src) if c == "\n"]
        self.sinonimi = sinonimi
        self.stile = stile
        tabella: dict[tuple[str, ...], tuple[TipoToken, str]] = {}
        try:
            for chiave, tipo in (sinonimi.mappa.items() if sinonimi is not None else ()):
                tabella[tuple("è" if p == "e'" else p for p in chiave)] = (tipo, "sinonimo")
        except Exception:
            pass
        try:
            if stile is not None:
                for chiave, tipo in stile.forme_lessicali().items():
                    tabella[tuple(chiave)] = (tipo, "stile")
        except Exception:
            pass
        for parola, tipo in PAROLE_CHIAVE.items():
            tabella[(parola,)] = (tipo, "canonica")
        for chiave, tipo in COPPIE_DI_PAROLE.items():
            tabella[chiave] = (tipo, "canonica")
        self.tabella = tabella
        self.massimo = max((len(k) for k in tabella), default=1)

    def _pos(self, offset: int) -> tuple[int, int]:
        import bisect

        riga = bisect.bisect_right(self.inizi, offset)
        return riga, offset - self.inizi[riga - 1] + 1

    def _emetti(self, tipo: TipoToken, valore: Any, inizio: int, fine: int, origine: str = "canonica") -> None:
        riga, colonna = self._pos(inizio)
        self.token.append(Token(tipo, valore, riga, colonna, self.src[inizio:fine], fine - inizio, origine))

    def esegui(self, inizio: int = 0, fine: int | None = None) -> tuple[list[Token], int]:
        src = self.src
        fine = len(src) if fine is None else fine
        i = inizio
        while i < fine:
            c = src[i]
            if c == "\n":
                if self.token and self.token[-1].tipo is not T.FINE_RIGA:
                    self._emetti(T.FINE_RIGA, "\n", i, i + 1)
                i += 1
            elif c in self._SPAZI:
                i += 1
            elif src.startswith("#[", i, fine):
                profondita, j = 0, i
                while j < fine:
                    if src.startswith("#[", j, fine):
                        profondita += 1
                        j += 2
                    elif src.startswith("]#", j, fine):
                        profondita -= 1
                        j += 2
                        if profondita == 0:
                            break
                    else:
                        j += 1
                self._emetti(T.COMMENTO, src[i:j], i, j)
                if profondita > 0:
                    self.profondita = profondita
                i = j
            elif c == "#":
                j = src.find("\n", i, fine)
                j = fine if j == -1 else j
                self._emetti(T.COMMENTO, src[i:j], i, j)
                i = j
            elif c == '"':
                i = self._testo(i, fine)
            elif c.isdigit():
                m = self._NUMERO.match(src, i, fine)
                j = m.end() if m else i + 1
                testo = src[i:j].replace("_", "")
                try:
                    valore: Any = int(testo)
                    tipo = T.INTERO
                except ValueError:
                    try:
                        valore, tipo = float(testo), T.DECIMALE
                    except ValueError:
                        valore, tipo = 0, T.INTERO
                self._emetti(tipo, valore, i, j)
                i = j
            elif c.isalpha() or c == "_":
                i = self._parola(i, fine)
            else:
                for simbolo, tipo in OPERATORI:
                    if src.startswith(simbolo, i, fine):
                        self._emetti(tipo, simbolo, i, i + len(simbolo))
                        i += len(simbolo)
                        break
                else:
                    self._emetti(T.ERRORE, f"Il carattere `{c}` non fa parte di Leo.", i, i + 1)
                    i += 1
        riga, colonna = self._pos(fine)
        self.token.append(Token(T.FINE_FILE, None, riga, colonna, None, 0, "sintetico"))
        return self.token, self.profondita

    def _leggi_parola(self, i: int, fine: int) -> int:
        j = i + 1
        while j < fine and (self.src[j].isalnum() or self.src[j] == "_"):
            j += 1
        if self.src[i:j] == "e" and j < fine and self.src[j] == "'":
            j += 1
        return j

    def _parola(self, i: int, fine: int) -> int:
        src = self.src
        parole: list[tuple[str, int, int]] = []
        k = i
        while len(parole) < self.massimo and k < fine and (src[k].isalpha() or src[k] == "_"):
            j = self._leggi_parola(k, fine)
            parola = src[k:j]
            parole.append(("è" if parola == "e'" else parola, k, j))
            m = j
            while m < fine and src[m] in " \t":
                m += 1
            if m == j:
                break
            k = m
        for quante in range(len(parole), 0, -1):
            chiave = tuple(p for p, _, _ in parole[:quante])
            trovato = self.tabella.get(chiave)
            if trovato is not None:
                tipo, origine = trovato
                fine_parola = parole[quante - 1][2]
                self._emetti(tipo, tipo.value, i, fine_parola, origine)
                return fine_parola
        _, _, j = parole[0]
        self._emetti(T.NOME, src[i:j], i, j)
        return j

    def _testo(self, i: int, fine: int) -> int:
        src = self.src
        fine_riga = src.find("\n", i, fine)
        fine_riga = fine if fine_riga == -1 else fine_riga
        parti: list[Any] = []
        buffer: list[str] = []
        j = i + 1
        chiuso = False
        while j < fine_riga:
            c = src[j]
            if c == '"':
                j += 1
                chiuso = True
                break
            if c == "\\" and j + 1 < fine_riga:
                buffer.append(src[j + 1])
                j += 2
                continue
            if c == "{":
                k = self._fine_graffa(j, fine_riga)
                if k is not None and src[j + 1:k].strip():
                    if buffer:
                        parti.append("".join(buffer))
                        buffer = []
                    riga, colonna = self._pos(j + 1)
                    interno = _Ripiego.__new__(_Ripiego)
                    interno.__dict__.update(self.__dict__)
                    interno.token = []
                    interno.profondita = 0
                    token, _ = interno.esegui(j + 1, k)
                    parti.append(ParteInterpolata(src[j + 1:k], riga, colonna, token))
                    j = k + 1
                    continue
            buffer.append(c)
            j += 1
        if not chiuso:
            j = fine_riga
        if any(isinstance(p, ParteInterpolata) for p in parti):
            if buffer:
                parti.append("".join(buffer))
            self._emetti(T.TESTO_INTERPOLATO, parti, i, j)
        else:
            self._emetti(T.TESTO, "".join(buffer), i, j)
        return j

    def _fine_graffa(self, j: int, limite: int) -> int | None:
        modi = ["g"]
        k = j + 1
        src = self.src
        while k < limite:
            c = src[k]
            if modi[-1] == "t":
                if c == "\\":
                    k += 2
                    continue
                if c == '"':
                    modi.pop()
            elif c == "{":
                modi.append("g")
            elif c == "}":
                modi.pop()
                if not modi:
                    return k
            elif c == '"':
                modi.append("t")
            k += 1
        return None


# ===========================================================================
# Analisi dei nomi del sorgente (variabili, costanti, parametri)
# ===========================================================================

class NomiNoti:
    """Nomi dichiarati in un sorgente, per colorarli riga per riga.

    ``variabili``, ``costanti``, ``funzioni``: insiemi di nomi;
    ``parametri``: ``{nome: ((prima_riga, ultima_riga), ...)}`` = righe del
    corpo delle funzioni (e dei ``quando``) in cui il nome e' un parametro.
    Due oggetti con gli stessi nomi sono uguali (l'editor ricolora solo se cambiano).
    """

    __slots__ = ("variabili", "costanti", "funzioni", "parametri", "comandi", "_indici")

    def __init__(self, variabili: Iterable[str] = (), costanti: Iterable[str] = (),
                 funzioni: Iterable[str] = (),
                 parametri: dict[str, Iterable[tuple[int, int]]] | None = None,
                 comandi: Iterable[str] = ()) -> None:
        self.variabili = frozenset(variabili or ())
        self.costanti = frozenset(costanti or ())
        self.funzioni = frozenset(funzioni or ())
        #: funzioni senza `restituisci`: si usano come comandi senza parentesi (`saluta Giulia`)
        self.comandi = frozenset(comandi or ())
        self.parametri: dict[str, tuple[tuple[int, int], ...]] = {
            str(n): tuple(sorted(set(r))) for n, r in (parametri or {}).items()}
        # nome -> (intervalli, inizi, massimo delle fini fino a ogni inizio),
        # calcolato alla prima domanda su quel nome
        self._indici: dict[str, tuple[tuple, list[int], list[int]]] = {}

    def parametro(self, nome: str, riga: int | None) -> bool:
        """Vero se ``nome`` e' un parametro alla ``riga`` (None = riga sconosciuta:
        basta che sia un parametro da qualche parte e non una variabile)."""
        intervalli = self.parametri.get(nome)
        if not intervalli:
            return False
        if riga is None:
            return nome not in self.variabili and nome not in self.costanti
        # Gli intervalli sono ordinati per inizio (possono sovrapporsi): la riga
        # sta in uno di essi se, tra quelli che iniziano entro la riga, la fine
        # piu' lontana arriva almeno alla riga. Ricerca binaria invece di `any`.
        indice = self._indici.get(nome)
        if indice is None or indice[0] is not intervalli:
            inizi: list[int] = []
            fini_massime: list[int] = []
            massimo = None
            for a, b in intervalli:
                massimo = b if massimo is None or b > massimo else massimo
                inizi.append(a)
                fini_massime.append(massimo)
            indice = (intervalli, inizi, fini_massime)
            self._indici[nome] = indice
        k = bisect_right(indice[1], riga)
        return k > 0 and indice[2][k - 1] >= riga

    def unisci(self, altri: "NomiNoti | None") -> "NomiNoti":
        """Unione (i parametri di ``altri`` si aggiungono con le loro righe)."""
        if altri is None:
            return self
        parametri: dict[str, list[tuple[int, int]]] = {n: list(r) for n, r in self.parametri.items()}
        for n, r in altri.parametri.items():
            parametri.setdefault(n, []).extend(r)
        return NomiNoti(self.variabili | altri.variabili, self.costanti | altri.costanti,
                        self.funzioni | altri.funzioni, parametri,
                        self.comandi | getattr(altri, "comandi", frozenset()))

    def tutti(self) -> frozenset[str]:
        """Tutti i nomi (variabili, costanti, funzioni, parametri)."""
        return self.variabili | self.costanti | self.funzioni | frozenset(self.parametri)

    def _chiave(self) -> tuple:
        return (self.variabili, self.costanti, self.funzioni, tuple(sorted(self.parametri.items())),
                self.comandi)

    def __eq__(self, altro: object) -> bool:
        return isinstance(altro, NomiNoti) and self._chiave() == altro._chiave()

    def __hash__(self) -> int:
        return hash(self._chiave())

    def __repr__(self) -> str:
        return (f"NomiNoti(variabili={sorted(self.variabili)}, costanti={sorted(self.costanti)}, "
                f"funzioni={sorted(self.funzioni)}, parametri={self.parametri})")


_APERTE = frozenset({T.PARENTESI_APERTA, T.QUADRA_APERTA, T.GRAFFA_APERTA})
_CHIUSE = frozenset({T.PARENTESI_CHIUSA, T.QUADRA_CHIUSA, T.GRAFFA_CHIUSA})
_ASSEGNAZIONI = frozenset({T.ASSEGNA, T.PIU_ASSEGNA, T.MENO_ASSEGNA, T.PER_ASSEGNA, T.DIVISO_ASSEGNA})
_BLOCCHI = frozenset({T.SE, T.MENTRE, T.PER_OGNI, T.RIPETI, T.FUNZIONE, T.PROVA, T.QUANDO})


def _nomi_in_elenco(sig: list[Token], j: int) -> tuple[list[str], int]:
    """``a, b, c`` a partire da ``sig[j]``: nomi e indice dopo l'elenco."""
    nomi: list[str] = []
    n = len(sig)
    while j < n and sig[j].tipo is T.NOME:
        nomi.append(str(sig[j].valore))
        j += 1
        if j < n and sig[j].tipo is T.VIRGOLA:
            j += 1
        else:
            break
    return nomi, j


def _analizza_nomi(token: list[Token], errori: Iterable[str] = ()) -> NomiNoti:
    """Un solo passaggio sui token: dichiarazioni, assegnazioni, cicli, catture e
    parametri (con le righe del corpo). Codice incompleto: si prende cio' che c'e'."""
    sig = [t for t in token if t.tipo not in (T.COMMENTO, T.ERRORE)]
    n = len(sig)
    errori = set(errori or ())
    variabili: set[str] = set()
    costanti: set[str] = set()
    funzioni: set[str] = set()
    parametri: dict[str, list[tuple[int, int]]] = {}
    pila: list[tuple[int, list[str]]] = []          # (riga di apertura, parametri del blocco)
    profondita = 0
    ultima_riga = max((t.riga for t in sig), default=1)
    salta = -1
    precedente: Token | None = None
    for i, tok in enumerate(sig):
        tipo = tok.tipo
        try:
            if i == salta:
                continue
            if tipo is T.FINE_RIGA:
                profondita = 0
                continue
            if tipo in _APERTE:
                profondita += 1
            elif tipo in _CHIUSE:
                profondita = max(0, profondita - 1)
            elif tipo is T.VARIABILE or tipo is T.COSTANTE:
                nomi, _ = _nomi_in_elenco(sig, i + 1)
                (variabili if tipo is T.VARIABILE else costanti).update(nomi)
            elif tipo is T.PER_OGNI:
                nomi, _ = _nomi_in_elenco(sig, i + 1)
                variabili.update(nomi)
                pila.append((tok.riga, []))
            elif tipo is T.FUNZIONE:
                j = i + 1
                if j < n and sig[j].tipo is T.NOME:
                    funzioni.add(str(sig[j].valore))
                    j += 1
                nomi_parametri: list[str] = []
                if j < n and sig[j].tipo is T.PARENTESI_APERTA:
                    livello, k = 0, j
                    while k < n and sig[k].tipo is not T.FINE_RIGA:
                        tk = sig[k]
                        if tk.tipo in _APERTE:
                            livello += 1
                        elif tk.tipo in _CHIUSE:
                            livello -= 1
                            if livello <= 0:
                                break
                        elif (tk.tipo is T.NOME and livello == 1
                              and sig[k - 1].tipo in (T.PARENTESI_APERTA, T.VIRGOLA, T.TRE_PUNTI)):
                            nomi_parametri.append(str(tk.valore))
                        k += 1
                pila.append((tok.riga, nomi_parametri))
            elif tipo is T.QUANDO:
                pila.append((tok.riga, ["evento"]))
            elif tipo in _BLOCCHI:
                pila.append((tok.riga, []))
            elif tipo is T.FINE:
                if i + 1 < n:
                    dopo = sig[i + 1]
                    if dopo.riga == tok.riga and (dopo.tipo in _ETICHETTE or
                                                  (dopo.tipo is T.NOME and dopo.valore in ("per", "scegli"))):
                        salta = i + 1
                if pila:
                    riga_apertura, nomi_blocco = pila.pop()
                    for nome in nomi_blocco:
                        parametri.setdefault(nome, []).append((riga_apertura, tok.riga))
            elif tipo is T.CATTURA:
                j = i + 1
                while j < n and sig[j].riga == tok.riga and sig[j].tipo is not T.FINE_RIGA:
                    tj = sig[j]
                    if tj.tipo is T.NOME and str(tj.valore) not in errori and (
                            sig[j - 1].tipo in (T.COME, T.CATTURA)):
                        variabili.add(str(tj.valore))
                    j += 1
            elif tipo is T.NOME:
                a_inizio = precedente is None or precedente.tipo is T.FINE_RIGA or precedente.tipo in (
                    T.ALLORA, T.FAI, T.ALTRIMENTI, T.PROVA, T.INFINE)
                if tok.valore == "scegli" and a_inizio and i + 1 < n and sig[i + 1].tipo not in _ASSEGNAZIONI \
                        and sig[i + 1].tipo is not T.FINE_RIGA:
                    pila.append((tok.riga, []))
                elif profondita == 0 and (precedente is None or precedente.tipo not in (
                        T.PUNTO, T.VIRGOLA, T.VARIABILE, T.COSTANTE, T.PER_OGNI)):
                    nomi, j = _nomi_in_elenco(sig, i)
                    if j < n and sig[j].tipo in _ASSEGNAZIONI:
                        variabili.update(nomi)
        except Exception:
            pass            # un token strano non ferma l'analisi
        finally:
            precedente = tok
    for riga_apertura, nomi_blocco in pila:          # blocchi non chiusi: fino alla fine
        for nome in nomi_blocco:
            parametri.setdefault(nome, []).append((riga_apertura, ultima_riga))
    return NomiNoti(variabili, costanti, funzioni, parametri)


def nomi_noti(sorgente: str, *, sinonimi=None, stile=None) -> NomiNoti:
    """Nomi dichiarati nel sorgente intero (per :func:`colora_riga`). Mai eccezioni."""
    try:
        sorgente = sorgente or ""
        sinonimi = sinonimi if sinonimi is not None else _sinonimi_predefiniti()
        token, _ = _lessico(sorgente, sinonimi, _stile_di(sorgente, stile))
        nomi = _analizza_nomi(token, _nomi_errori())
        try:
            from .comandi import trova_definizioni
            nomi.comandi = frozenset(trova_definizioni(sorgente).comandi)
        except Exception:
            pass
        return nomi
    except Exception:
        try:
            return NomiNoti(funzioni=funzioni_definite(sorgente))
        except Exception:
            return NomiNoti()


# ===========================================================================
# Da token a segmenti
# ===========================================================================

_PARENTESI = set("()[]{}")


class _Convertitore:
    def __init__(self, controlli: Iterable[str], funzioni_utente: Iterable[str], *, per_riga: bool,
                 sorgente_righe: list[str], riga_base: int = 0, colonna_base: int = 0,
                 nomi: NomiNoti | None = None, riga_documento: int | None = None) -> None:
        self.controlli = set(controlli or ())
        self.funzioni_utente = set(funzioni_utente or ())
        self.nomi = nomi if nomi is not None else NomiNoti()
        self.funzioni_utente |= self.nomi.funzioni
        #: numero della riga nel documento (solo per colora_riga; None = sconosciuto)
        self.riga_documento = riga_documento
        self.libreria = _nomi_libreria()
        self.costanti_libreria = _costanti_libreria()
        self.eventi = _nomi_eventi()
        self.errori = _nomi_errori()
        self.per_riga = per_riga
        self.righe = sorgente_righe
        self.riga_base = riga_base
        self.colonna_base = colonna_base
        self.segmenti: list[Segmento] = []

    # -- aggiunta con spostamento (colora_riga lavora su un pezzo della riga)
    def _aggiungi(self, riga: int, colonna: int, lunghezza: int, categoria: Categoria,
                  sinonimo_di: str | None = None, errore: str | None = None) -> None:
        if lunghezza <= 0 or riga <= 0 or colonna <= 0:
            return
        self.segmenti.append(Segmento(riga + self.riga_base, colonna + self.colonna_base,
                                      lunghezza, categoria, sinonimo_di, errore))

    def _testo_in(self, riga: int, colonna: int, lunghezza: int) -> str:
        if 1 <= riga <= len(self.righe):
            return self.righe[riga - 1][colonna - 1:colonna - 1 + lunghezza]
        return ""

    def converti(self, token: list[Token]) -> None:
        # parole dei costrutti `ogni`/`dopo`/`verifica "..." fai`/`aspettati`/`in parallelo`
        try:
            self._potenza = {id(token[k]) for k in parole_potenza(token)}
        except Exception:
            self._potenza = set()
        try:   # `struttura`, `tipo ... è uno di`, `richiede`, `ha valore`... (leo/controllo/sintassi.py)
            from .controllo.sintassi import parole_tipi

            self._potenza |= {id(token[k]) for k in parole_tipi(token)}
        except Exception:
            pass
        # contesto: i due token significativi prima e quello dopo
        significativi = [k for k, t in enumerate(token) if t.tipo not in (T.COMMENTO, T.ERRORE)]
        seguente: dict[int, Token] = {}
        for a, b in zip(significativi, significativi[1:]):
            seguente[a] = token[b]
        precedenti: list[Token] = []
        for k, tok in enumerate(token):
            try:
                self._uno(tok, precedenti[-1] if precedenti else None,
                          precedenti[-2] if len(precedenti) > 1 else None,
                          precedenti[-3] if len(precedenti) > 2 else None, seguente.get(k))
            except Exception:
                # mai eccezioni dalla colorazione: il token resta senza colore
                pass
            if tok.tipo not in (T.COMMENTO, T.ERRORE):
                precedenti.append(tok)
                if len(precedenti) > 3:
                    del precedenti[0]

    def _uno(self, tok: Token, precedente: Token | None, secondo: Token | None = None,
             terzo: Token | None = None, seguente: Token | None = None) -> None:
        tipo = tok.tipo
        if tipo in (T.FINE_RIGA, T.FINE_FILE):
            return
        if tok.lunghezza <= 0:
            # token sintetici dello stile "al" (``di`` -> PUNTO): si colora la parola scritta
            testo = tok.testo_originale or ""
            if tok.origine == "sintetico" and testo.isalpha() and \
                    self._testo_in(tok.riga, tok.colonna, len(testo)) == testo:
                self._aggiungi(tok.riga, tok.colonna, len(testo), Categoria.DICHIARAZIONI)
            return
        if tipo is T.COMMENTO:
            testo = tok.testo_originale if tok.testo_originale is not None else str(tok.valore)
            for k, pezzo in enumerate(testo.split("\n")):
                self._aggiungi(tok.riga + k, tok.colonna if k == 0 else 1, len(pezzo), Categoria.COMMENTI)
            return
        if id(tok) in getattr(self, "_potenza", ()):
            # `ogni`, `secondi`, `verifica`, `aspettati`, `errore`, `in parallelo`: parole del flusso
            self._aggiungi(tok.riga, tok.colonna, tok.lunghezza, Categoria.FLUSSO)
            return
        if tipo in (T.TESTO, T.TESTO_INTERPOLATO) and "\n" in (tok.testo_originale or ""):
            self._testo_lungo(tok)
            return
        if tipo is T.ERRORE:
            self._errore(tok)
            return
        if tok.origine == "comando" and tipo in (T.TESTO, T.TESTO_INTERPOLATO):
            self._testo_comando(tok)
            return
        if tipo is T.TESTO_INTERPOLATO and isinstance(tok.valore, list):
            self._interpolato(tok)
            return
        if tipo is T.NOME:
            self._aggiungi(tok.riga, tok.colonna, tok.lunghezza,
                           self._categoria_nome(tok, precedente, secondo, terzo, seguente))
            return
        sinonimo_di = str(tok.valore) if tok.origine == "sinonimo" else None
        self._aggiungi(tok.riga, tok.colonna, tok.lunghezza, categoria_statica(tipo), sinonimo_di)

    def _riga_di(self, tok: Token) -> int | None:
        if self.per_riga:
            return self.riga_documento
        return tok.riga + self.riga_base

    def _categoria_nome(self, tok: Token, precedente: Token | None, secondo: Token | None = None,
                        terzo: Token | None = None, seguente: Token | None = None) -> Categoria:
        nome = str(tok.valore)
        if precedente is not None and precedente.tipo is T.PUNTO:
            return self._categoria_membro(nome, secondo, terzo, seguente)
        if precedente is not None and precedente.tipo is T.FINE and precedente.riga == tok.riga:
            # etichetta di `fine` (`fine inizio`, `fine scegli`): parola del blocco, mai una variabile
            return categoria_statica(T.INIZIO) if nome == "inizio" else Categoria.FLUSSO
        if nome in self.errori:
            return Categoria.ERRORI
        if nome in self.controlli:
            return Categoria.CONTROLLI
        nomi = self.nomi
        chiamata = seguente is not None and seguente.tipo is T.PARENTESI_APERTA and seguente.lunghezza > 0
        if chiamata and nome in self.funzioni_utente:
            return Categoria.FUNZIONI_UTENTE
        if nomi.parametro(nome, self._riga_di(tok)):
            return Categoria.PARAMETRI
        if nome in self.funzioni_utente:
            return Categoria.FUNZIONI_UTENTE
        if chiamata and nome in self.libreria and nome not in nomi.variabili:
            return Categoria.LIBRERIA
        if nome in nomi.costanti:
            return Categoria.COSTANTI
        if nome in nomi.variabili:
            return Categoria.VARIABILI
        if nome in self.costanti_libreria:
            return Categoria.COSTANTI
        if nome in self.libreria:
            return Categoria.LIBRERIA
        return Categoria.TESTO_NORMALE

    def _categoria_membro(self, nome: str, oggetto: Token | None, prima: Token | None,
                          seguente: Token | None) -> Categoria:
        """Nome dopo il punto: evento, proprieta' (controlli e metodi) o campo."""
        nome_oggetto = str(oggetto.valore) if oggetto is not None and oggetto.tipo is T.NOME else None
        if prima is not None and prima.tipo is T.QUANDO:
            return Categoria.EVENTI                       # quando Pulsante1.clic / al clic di Pulsante1
        if nome_oggetto is not None and nome_oggetto in self.controlli:
            return Categoria.EVENTI if nome in self.eventi else Categoria.PROPRIETA
        if seguente is not None and seguente.tipo is T.PARENTESI_APERTA:
            return Categoria.PROPRIETA                    # metodo: lista.aggiungi(3)
        if nome_oggetto is not None and (nome_oggetto in self.nomi.variabili or nome_oggetto in self.nomi.costanti
                                         or nome_oggetto in self.nomi.parametri):
            return Categoria.CAMPI                        # errore.tipo, persona.nome
        return Categoria.PROPRIETA

    def _errore(self, tok: Token) -> None:
        messaggio = str(tok.valore)
        testo = tok.testo_originale or ""
        if self.per_riga:
            if testo.startswith("#["):
                return          # il commento continua sulle righe seguenti: non e' un errore qui
            if testo in _PARENTESI:
                # parentesi aperte o chiuse su altre righe: normale in una riga isolata
                self._aggiungi(tok.riga, tok.colonna, tok.lunghezza, Categoria.PUNTEGGIATURA)
                return
        categoria = Categoria.TESTI if testo.startswith('"') else Categoria.TESTO_NORMALE
        riga, colonna = tok.riga + self.riga_base, tok.colonna + self.colonna_base
        for seg in self.segmenti:
            if seg.riga == riga and seg.colonna == colonna and seg.errore is None:
                seg.errore = messaggio
                return
        self._aggiungi(tok.riga, tok.colonna, tok.lunghezza, categoria, errore=messaggio)

    def _testo_lungo(self, tok: Token) -> None:
        """Testo su piu' righe (``\"\"\"``): un segmento per riga; le parti ``{...}``
        si colorano come nei testi normali."""
        testo = tok.testo_originale or ""
        pezzi = testo.split("\n")
        parti = [p for p in (tok.valore if isinstance(tok.valore, list) else [])
                 if isinstance(p, ParteInterpolata)]
        for k, pezzo in enumerate(pezzi):
            riga = tok.riga + k
            inizio = tok.colonna if k == 0 else 1
            fine = inizio + len(pezzo)
            cursore = inizio
            for parte in parti:
                if parte.riga != riga:
                    continue
                graffa_aperta = parte.colonna - 1
                graffa_chiusa = parte.colonna + len(parte.sorgente)
                if graffa_aperta < cursore or graffa_chiusa >= fine:
                    continue
                self._aggiungi(riga, cursore, graffa_aperta - cursore, Categoria.TESTI)
                self._parte_interpolata(parte, riga, graffa_aperta, graffa_chiusa)
                cursore = graffa_chiusa + 1
            self._aggiungi(riga, cursore, fine - cursore, Categoria.TESTI)

    def _parte_interpolata(self, parte: ParteInterpolata, riga: int, graffa_aperta: int, graffa_chiusa: int) -> None:
        self._aggiungi(riga, graffa_aperta, 1, Categoria.INTERPOLAZIONE)
        interno = _Convertitore(self.controlli, self.funzioni_utente, per_riga=self.per_riga,
                                sorgente_righe=self.righe, riga_base=self.riga_base,
                                colonna_base=self.colonna_base, nomi=self.nomi,
                                riga_documento=self.riga_documento)
        interno.converti(list(parte.token or ()))
        self.segmenti.extend(s for s in interno.segmenti
                             if s.riga == riga + self.riga_base
                             and graffa_aperta + self.colonna_base < s.colonna
                             and s.colonna + s.lunghezza <= graffa_chiusa + self.colonna_base)
        formato = getattr(parte, "formato", None)
        if formato:
            # `{prezzo:2}`: i due punti e il formato come le graffe
            due_punti = str(parte.sorgente).rfind(":")
            if due_punti >= 0:
                colonna = parte.colonna + due_punti
                self._aggiungi(riga, colonna, graffa_chiusa - colonna, Categoria.INTERPOLAZIONE)
        self._aggiungi(riga, graffa_chiusa, 1, Categoria.INTERPOLAZIONE)

    def _testo_comando(self, tok: Token) -> None:
        """Testo di un comando senza parentesi (``stampa Ciao (nome)``): il testo come i
        testi, le parentesi che calcolano come le graffe dell'interpolazione, il calcolo
        dentro con i suoi colori; ``casuale(1, 6)`` nel testo come una chiamata."""
        riga = tok.riga
        fine = tok.colonna + tok.lunghezza
        cursore = tok.colonna
        parti = tok.valore if isinstance(tok.valore, list) else []
        for parte in parti:
            if not isinstance(parte, ParteInterpolata) or parte.riga != riga:
                continue
            inizio_parte = parte.colonna
            fine_parte = parte.colonna + len(parte.sorgente)          # colonna dopo la parte
            tonda = self._testo_in(riga, inizio_parte - 1, 1) == "(" and \
                self._testo_in(riga, fine_parte, 1) == ")"
            if tonda:
                inizio_parte -= 1
                fine_parte += 1
            if inizio_parte < cursore or fine_parte > fine:
                continue
            self._aggiungi(riga, cursore, inizio_parte - cursore, Categoria.TESTI)
            if tonda:
                self._parte_interpolata(parte, riga, inizio_parte, fine_parte - 1)
            else:
                interno = _Convertitore(self.controlli, self.funzioni_utente, per_riga=self.per_riga,
                                        sorgente_righe=self.righe, riga_base=self.riga_base,
                                        colonna_base=self.colonna_base, nomi=self.nomi,
                                        riga_documento=self.riga_documento)
                interno.converti(list(parte.token or ()))
                self.segmenti.extend(interno.segmenti)
            cursore = fine_parte
        self._aggiungi(riga, cursore, fine - cursore, Categoria.TESTI)

    def _interpolato(self, tok: Token) -> None:
        riga = tok.riga
        inizio = tok.colonna
        fine = tok.colonna + tok.lunghezza            # colonna dopo l'ultima virgoletta
        cursore = inizio
        for parte in tok.valore:
            if not isinstance(parte, ParteInterpolata):
                continue
            graffa_aperta = parte.colonna - 1
            graffa_chiusa = parte.colonna + len(parte.sorgente)
            if parte.riga != riga or graffa_aperta < cursore or graffa_chiusa >= fine:
                continue      # posizione incoerente: si lascia colorare come testo
            self._aggiungi(riga, cursore, graffa_aperta - cursore, Categoria.TESTI)
            self._parte_interpolata(parte, riga, graffa_aperta, graffa_chiusa)
            cursore = graffa_chiusa + 1
        self._aggiungi(riga, cursore, fine - cursore, Categoria.TESTI)


def _ordina(segmenti: list[Segmento]) -> list[Segmento]:
    """Ordina per posizione e toglie le sovrapposizioni (vince il primo)."""
    segmenti = sorted(segmenti, key=lambda s: (s.riga, s.colonna))
    risultato: list[Segmento] = []
    for seg in segmenti:
        if risultato:
            ultimo = risultato[-1]
            if ultimo.riga == seg.riga and seg.colonna < ultimo.colonna + ultimo.lunghezza:
                continue
        risultato.append(seg)
    return risultato


def _righe(sorgente: str) -> list[str]:
    return sorgente.replace("\r\n", "\n").replace("\r", "\n").split("\n")


# ===========================================================================
# API
# ===========================================================================

def colora(sorgente: str, *, sinonimi=None, stile=None, controlli: Iterable[str] = ()) -> list[Segmento]:
    """Segmenti colorati di un intero sorgente (non solleva mai eccezioni)."""
    try:
        sorgente = sorgente or ""
        sinonimi = sinonimi if sinonimi is not None else _sinonimi_predefiniti()
        stile = _stile_di(sorgente, stile)
        token, _ = _lessico(sorgente, sinonimi, stile)
        try:
            nomi = _analizza_nomi(token, _nomi_errori())
        except Exception:
            nomi = NomiNoti(funzioni=_funzioni_da_token(token))
        conv = _Convertitore(controlli, nomi.funzioni, per_riga=False, sorgente_righe=_righe(sorgente),
                             nomi=nomi)
        conv.converti(token)
        return _ordina(conv.segmenti)
    except Exception:
        return []


def colora_riga(testo: str, stato: int = 0, *, sinonimi=None, stile=None,
                controlli: Iterable[str] = (), funzioni_utente: Iterable[str] = (),
                nomi_noti: NomiNoti | None = None, riga: int | None = None
                ) -> tuple[list[Segmento], int]:
    """Colora una sola riga (per ``QSyntaxHighlighter``).

    ``stato``: profondita' dei commenti ``#[`` aperti all'inizio della riga
    (0 = nessuno). Restituisce i segmenti (``riga`` = 1, colonne relative alla
    riga) e lo stato alla fine della riga. ``nomi_noti``: l'analisi del
    sorgente intero (:func:`nomi_noti`), ``riga``: numero della riga nel
    documento (da 1) per i parametri; i nomi dichiarati sulla riga stessa
    si riconoscono comunque.
    """
    try:
        testo = (testo or "").replace("\r", "").replace("\n", " ").replace(" ", " ")
        stato = max(0, int(stato or 0))
    except Exception:
        return [], 0
    segmenti: list[Segmento] = []
    inizio = 0
    try:
        if stato >= STATO_TESTO_LUNGO:
            # la riga comincia dentro un testo su piu' righe: fino alle `"""` di chiusura
            j = 0
            while j < len(testo):
                if testo[j] == "\\":
                    j += 2
                    continue
                if testo.startswith('"""', j):
                    while j + 3 < len(testo) and testo[j + 3] == '"':
                        j += 1
                    break
                j += 1
            if j >= len(testo):
                if testo:
                    segmenti.append(Segmento(1, 1, len(testo), Categoria.TESTI))
                return segmenti, STATO_TESTO_LUNGO
            segmenti.append(Segmento(1, 1, j + 3, Categoria.TESTI))
            inizio = j + 3
            stato = 0
        if stato > 0:
            profondita, j = stato, 0
            while j < len(testo) and profondita > 0:
                if testo.startswith("#[", j):
                    profondita += 1
                    j += 2
                elif testo.startswith("]#", j):
                    profondita -= 1
                    j += 2
                else:
                    j += 1
            if j > 0:
                segmenti.append(Segmento(1, 1, j, Categoria.COMMENTI))
            if profondita > 0:
                return segmenti, profondita
            inizio = j
        resto = testo[inizio:]
        if not resto.strip():
            return segmenti, 0
        sinonimi = sinonimi if sinonimi is not None else _sinonimi_predefiniti()
        nomi = nomi_noti if isinstance(nomi_noti, NomiNoti) else NomiNoti()
        token, profondita = _lessico(resto, sinonimi, stile,
                                     nomi.tutti() | frozenset(funzioni_utente or ()) | frozenset(controlli or ()),
                                     nomi.comandi)
        try:
            locali = _analizza_nomi(token, _nomi_errori())
            if locali.variabili or locali.costanti or locali.funzioni or locali.parametri:
                # la riga stessa dichiara qualcosa (anche prima dell'analisi dell'editor)
                numero = riga if isinstance(riga, int) else 1
                nomi = nomi.unisci(NomiNoti(locali.variabili, locali.costanti, locali.funzioni,
                                            {n: [(numero, numero)] for n in locali.parametri}))
        except Exception:
            pass
        conv = _Convertitore(controlli, funzioni_utente, per_riga=True, sorgente_righe=[resto],
                             colonna_base=inizio, nomi=nomi,
                             riga_documento=riga if isinstance(riga, int) else None)
        conv.converti(token)
        if profondita >= STATO_TESTO_LUNGO:
            # la riga apre un testo su piu' righe che continua sotto: il lexer tollerante
            # ha dato un TESTO fino alla fine della riga, gia' colorato
            return _ordina(segmenti + conv.segmenti), STATO_TESTO_LUNGO
        return _ordina(segmenti + conv.segmenti), max(0, profondita)
    except Exception:
        return segmenti, _profondita_finale(testo[inizio:]) if inizio < len(testo) else 0


def _funzioni_da_token(token: list[Token]) -> set[str]:
    nomi: set[str] = set()
    significativi = [t for t in token if t.tipo not in (T.COMMENTO, T.ERRORE)]
    for i, tok in enumerate(significativi[:-1]):
        if tok.tipo is T.FUNZIONE and significativi[i + 1].tipo is T.NOME:
            nomi.add(str(significativi[i + 1].valore))
    return nomi


def funzioni_definite(sorgente: str) -> set[str]:
    """Nomi delle funzioni definite con ``funzione NOME`` (anche con le forme di stile)."""
    try:
        sorgente = sorgente or ""
        token, _ = _lessico(sorgente, _sinonimi_predefiniti(), _stile_di(sorgente, None))
        return _funzioni_da_token(token)
    except Exception:
        return set(re.findall(r"\bfunzione[ \t]+([^\W\d]\w*)", sorgente or ""))


_APERTURE = frozenset({T.SE, T.MENTRE, T.PER_OGNI, T.RIPETI, T.FUNZIONE, T.PROVA, T.QUANDO, T.INIZIO})
_INTERMEDI = frozenset({T.ALTRIMENTI, T.ALTRIMENTI_SE, T.CATTURA, T.INFINE})
_ETICHETTE = frozenset({T.SE, T.MENTRE, T.PER_OGNI, T.RIPETI, T.FUNZIONE, T.PROVA, T.QUANDO, T.INIZIO})


def _coppie(token: list[Token]) -> dict[tuple[int, int], tuple[int, int]]:
    """Posizione di ogni parola di blocco -> posizione della parola corrispondente."""
    coppie: dict[tuple[int, int], tuple[int, int]] = {}
    pila: list[tuple[Token, list[Token]]] = []     # (apertura, intermedi)
    try:
        teste_potenza = {id(token[k]) for k in teste_di_blocco_potenza(token)}
    except Exception:
        teste_potenza = set()
    significativi = [t for t in token if t.tipo not in (T.COMMENTO, T.ERRORE) and t.lunghezza > 0]
    i = 0
    while i < len(significativi):
        tok = significativi[i]
        pos = (tok.riga, tok.colonna)
        if tok.tipo is T.FINE:
            etichetta = None
            if i + 1 < len(significativi):
                dopo = significativi[i + 1]
                if dopo.riga == tok.riga and (dopo.tipo in _ETICHETTE or
                                              (dopo.tipo is T.NOME and dopo.valore in ("per", "inizio", "ogni", "dopo", "verifica",
                                                                           "aspettati", "parallelo"))):
                    etichetta = dopo
            if pila:
                apertura, intermedi = pila.pop()
                pos_apertura = (apertura.riga, apertura.colonna)
                coppie[pos_apertura] = pos
                coppie[pos] = pos_apertura
                for m in intermedi:
                    coppie[(m.riga, m.colonna)] = pos
                if etichetta is not None:
                    coppie[(etichetta.riga, etichetta.colonna)] = pos_apertura
            if etichetta is not None:
                i += 2
                continue
        elif tok.tipo in _APERTURE or id(tok) in teste_potenza:
            pila.append((tok, []))
        elif tok.tipo in _INTERMEDI and pila:
            pila[-1][1].append(tok)
        i += 1
    return coppie


def coppia_blocco(sorgente: str, riga: int, colonna: int) -> tuple[int, int] | None:
    """Con il cursore su ``se``/``mentre``/``per ogni``/``ripeti``/``funzione``/
    ``prova``/``quando`` restituisce la posizione del ``fine`` corrispondente, e
    viceversa; su ``altrimenti``/``cattura``/``infine`` il ``fine`` del blocco.
    ``None`` se il cursore non e' su una parola di blocco o manca la coppia.
    Il cursore subito dopo la parola conta come "sulla parola"."""
    try:
        sorgente = sorgente or ""
        token, _ = _lessico(sorgente, _sinonimi_predefiniti(), _stile_di(sorgente, None))
        coppie = _coppie(token)
        candidati = [t for t in token if t.riga == riga and t.lunghezza > 0
                     and t.colonna <= colonna <= t.colonna + t.lunghezza
                     and (t.riga, t.colonna) in coppie]
        if not candidati:
            return None
        # preferisci il token che contiene davvero la colonna (non quello appena prima)
        candidati.sort(key=lambda t: 0 if colonna < t.colonna + t.lunghezza else 1)
        return coppie[(candidati[0].riga, candidati[0].colonna)]
    except Exception:
        return None


_RIENTRO_ALLA_FINE = frozenset({T.ALLORA, T.FAI, T.ALTRIMENTI, T.PROVA, T.INFINE})
#: righe che aprono un blocco anche senza `allora`/`fai` finale (facoltativi a fine riga)
_RIENTRO_ALL_INIZIO = frozenset({T.FUNZIONE, T.CATTURA, T.QUANDO, T.SE, T.ALTRIMENTI_SE, T.MENTRE,
                                 T.PER_OGNI, T.RIPETI})


def rientro_dopo(riga: str, *, sinonimi=None, stile=None) -> bool:
    """Vero se dopo ``riga`` la riga nuova va rientrata di un livello.

    Succede dopo ``allora``/``fai``/``altrimenti``/``prova``/``infine`` a fine
    riga e dopo le righe che iniziano con ``funzione``/``cattura``/``quando``,
    se il blocco non si chiude sulla stessa riga con ``fine``.
    """
    try:
        sinonimi = sinonimi if sinonimi is not None else _sinonimi_predefiniti()
        token, _ = _lessico(riga or "", sinonimi, stile)
        utili = [t for t in token if t.tipo not in (T.COMMENTO, T.ERRORE, T.FINE_RIGA, T.FINE_FILE)]
        if not utili:
            return False
        if any(t.tipo is T.FINE for t in utili):
            return False
        if len(utili) == 1 and utili[0].tipo is T.INIZIO:
            return True                   # `inizio` da solo: apre il blocco facoltativo
        return utili[-1].tipo in _RIENTRO_ALLA_FINE or utili[0].tipo in _RIENTRO_ALL_INIZIO
    except Exception:
        return bool(re.search(r"\b(allora|fai)\s*(#.*)?$", riga or "")) or \
            (riga or "").lstrip().startswith("funzione ")


def ansi(sorgente: str, tema: "Tema") -> str:
    """Il sorgente con i colori del tema in sequenze ANSI a 24 bit (per REPL e messaggi).

    Il testo normale resta senza codici (colore del terminale); i token con
    errore sono sottolineati nel colore ``errore`` del tema.
    """
    try:
        from .temi import ANSI_RESET, StileCategoria, codice_ansi

        righe = _righe(sorgente or "")
        per_riga: dict[int, list[Segmento]] = {}
        for seg in colora(sorgente or ""):
            per_riga.setdefault(seg.riga, []).append(seg)
        uscita: list[str] = []
        for numero, testo in enumerate(righe, start=1):
            pezzi: list[str] = []
            cursore = 0
            for seg in per_riga.get(numero, ()):
                inizio = seg.colonna - 1
                fine = min(len(testo), inizio + seg.lunghezza)
                if inizio < cursore or inizio >= len(testo):
                    continue
                pezzi.append(testo[cursore:inizio])
                parola = testo[inizio:fine]
                if seg.errore:
                    codice = codice_ansi(StileCategoria(tema.errore))
                    codice = codice.replace("\x1b[", "\x1b[4;", 1) if codice else "\x1b[4m"
                    pezzi.append(codice + parola + ANSI_RESET)
                elif seg.categoria is Categoria.TESTO_NORMALE:
                    pezzi.append(parola)
                else:
                    codice = codice_ansi(tema.stile(seg.categoria))
                    pezzi.append(codice + parola + ANSI_RESET if codice else parola)
                cursore = fine
            pezzi.append(testo[cursore:])
            uscita.append("".join(pezzi))
        return "\n".join(uscita)
    except Exception:
        return sorgente or ""


# ===========================================================================
# ANSI in ingresso (terminale integrato) e riferimenti alle righe
# ===========================================================================

#: Palette dei 16 colori ANSI per temi scuri e chiari (indici 0-15), coerente con la
#: grafica nera e rossa di Studio (verde = successo, rosso = accento).
_PALETTE_SCURA = ("#000000", "#FF3B4E", "#3FB950", "#FFB020", "#6CA0FF", "#FF5C8A", "#4FD1C5", "#D2D2D8",
                  "#808080", "#FF6B7A", "#56D364", "#FFCB6B", "#8AB4FF", "#FF8AB0", "#7FE3DA", "#FFFFFF")
_PALETTE_CHIARA = ("#000000", "#C8102E", "#1A7F37", "#9A6700", "#0037DA", "#A3124F", "#0E7490", "#5A5A66",
                   "#595959", "#A50E26", "#0B6A0B", "#7A5700", "#0000C8", "#8A1F5A", "#005F87", "#111114")


def colore_ansi_16(indice: int, tema: "Tema | None" = None) -> str:
    """Colore ``#RRGGBB`` di uno dei 16 colori ANSI, adattato al tema.

    Rosso -> colore ``errore`` del tema, giallo -> ``avviso``; se il colore
    risultante non si legge sullo sfondo (contrasto < 3) si usa il testo del tema.
    """
    indice = max(0, min(15, int(indice)))
    scuro = True if tema is None else bool(tema.scuro)
    colore = (_PALETTE_SCURA if scuro else _PALETTE_CHIARA)[indice]
    if tema is None:
        return colore
    if indice in (1, 9):
        colore = tema.errore
    elif indice in (3, 11):
        colore = tema.avviso
    try:
        from .temi import rapporto_contrasto

        if rapporto_contrasto(colore[:7], tema.sfondo[:7]) < 3.0:
            colore = tema.testo
    except Exception:
        pass
    return colore


def _colore_256(n: int) -> str:
    n = max(0, min(255, n))
    if n < 16:
        return _PALETTE_SCURA[n]
    if n < 232:
        n -= 16
        livelli = (0, 95, 135, 175, 215, 255)
        r, g, b = livelli[n // 36], livelli[(n // 6) % 6], livelli[n % 6]
        return f"#{r:02X}{g:02X}{b:02X}"
    v = 8 + (n - 232) * 10
    return f"#{v:02X}{v:02X}{v:02X}"


def _attributi_vuoti() -> dict:
    return {"colore": None, "indice_colore": None, "sfondo": None, "indice_sfondo": None,
            "grassetto": False, "corsivo": False, "sottolineato": False}


def _applica_sgr(attributi: dict, parametri: str) -> None:
    try:
        numeri = [int(p) if p else 0 for p in parametri.replace(":", ";").split(";")] if parametri else [0]
    except ValueError:
        return
    i = 0
    while i < len(numeri):
        n = numeri[i]
        if n == 0:
            attributi.update(_attributi_vuoti())
        elif n == 1:
            attributi["grassetto"] = True
        elif n == 22:
            attributi["grassetto"] = False
        elif n == 3:
            attributi["corsivo"] = True
        elif n == 23:
            attributi["corsivo"] = False
        elif n == 4:
            attributi["sottolineato"] = True
        elif n == 24:
            attributi["sottolineato"] = False
        elif 30 <= n <= 37 or 90 <= n <= 97:
            indice = n - 30 if n < 90 else n - 90 + 8
            attributi["colore"], attributi["indice_colore"] = _PALETTE_SCURA[indice], indice
        elif n == 39:
            attributi["colore"], attributi["indice_colore"] = None, None
        elif 40 <= n <= 47 or 100 <= n <= 107:
            indice = n - 40 if n < 100 else n - 100 + 8
            attributi["sfondo"], attributi["indice_sfondo"] = _PALETTE_SCURA[indice], indice
        elif n == 49:
            attributi["sfondo"], attributi["indice_sfondo"] = None, None
        elif n in (38, 48) and i + 1 < len(numeri):
            chiave, chiave_indice = ("colore", "indice_colore") if n == 38 else ("sfondo", "indice_sfondo")
            if numeri[i + 1] == 5 and i + 2 < len(numeri):
                valore = numeri[i + 2]
                attributi[chiave] = _colore_256(valore)
                attributi[chiave_indice] = valore if valore < 16 else None
                i += 2
            elif numeri[i + 1] == 2 and i + 4 < len(numeri):
                r, g, b = (max(0, min(255, x)) for x in numeri[i + 2:i + 5])
                attributi[chiave] = f"#{r:02X}{g:02X}{b:02X}"
                attributi[chiave_indice] = None
                i += 4
            else:
                i += 1
        i += 1


_SEQUENZA = re.compile(
    r"\x1b\[([0-9;:?]*)([@-~])"          # CSI (SGR se finisce con m)
    r"|\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)"  # OSC (titolo della finestra, ecc.)
    r"|\x1b[@-Z\\-_]"                   # altre sequenze di due caratteri
    r"|\x1b"                            # ESC isolato
)


class AnalizzatoreAnsi:
    """Analizzatore ANSI con stato, per l'uscita che arriva a pezzi (terminale).

    Ricorda gli attributi SGR tra una chiamata e l'altra e tiene da parte una
    sequenza di controllo troncata alla fine di un pezzo.
    """

    def __init__(self) -> None:
        self.attributi = _attributi_vuoti()
        self._resto = ""

    def azzera(self) -> None:
        self.attributi = _attributi_vuoti()
        self._resto = ""

    def analizza(self, testo: str, *, fine: bool = False) -> list[tuple[str, dict]]:
        """Pezzi ``(testo, attributi)`` di ``testo`` (vedi :func:`segmenti_ansi`).

        Con ``fine=True`` una sequenza troncata in fondo viene scartata invece
        di aspettare il pezzo successivo.
        """
        testo = self._resto + (testo or "")
        if fine:
            self._resto = ""
        else:
            testo, self._resto = separa_sequenza_incompleta(testo)
        pezzi: list[tuple[str, dict]] = []

        def aggiungi(parte: str) -> None:
            if not parte:
                return
            if pezzi and pezzi[-1][1] == self.attributi:
                pezzi[-1] = (pezzi[-1][0] + parte, pezzi[-1][1])
            else:
                pezzi.append((parte, dict(self.attributi)))

        try:
            cursore = 0
            for m in _SEQUENZA.finditer(testo):
                aggiungi(testo[cursore:m.start()])
                cursore = m.end()
                if m.group(2) == "m" and "?" not in (m.group(1) or ""):
                    _applica_sgr(self.attributi, m.group(1) or "")
            aggiungi(testo[cursore:])
        except Exception:
            pulito = re.sub(r"\x1b\[[0-9;]*m", "", testo)
            return [(pulito, _attributi_vuoti())] if pulito else []
        return pezzi


def segmenti_ansi(testo: str) -> list[tuple[str, dict]]:
    """Divide un testo con sequenze ANSI SGR in pezzi ``(testo, attributi)``.

    ``attributi``: ``colore`` / ``sfondo`` (``"#RRGGBB"`` o ``None`` = del tema),
    ``indice_colore`` / ``indice_sfondo`` (0-15 per i 16 colori, da adattare
    al tema con :func:`colore_ansi_16`, altrimenti ``None``), ``grassetto``,
    ``corsivo``, ``sottolineato``. Le altre sequenze di controllo si tolgono;
    i pezzi vuoti si omettono e quelli vicini con gli stessi attributi si uniscono.
    """
    return AnalizzatoreAnsi().analizza(testo, fine=True)


def separa_sequenza_incompleta(testo: str) -> tuple[str, str]:
    """Separa una sequenza ANSI troncata alla fine di un pezzo di uscita.

    Restituisce ``(completo, resto)``: ``resto`` va messo davanti al pezzo
    successivo (l'uscita di un processo arriva a blocchi).
    """
    indice = (testo or "").rfind("\x1b")
    if indice == -1:
        return testo or "", ""
    coda = testo[indice:]
    if re.fullmatch(r"\x1b(?:\[[0-9;:?]*)?", coda) or re.fullmatch(r"\x1b\][^\x07\x1b]*\x1b?", coda):
        return testo[:indice], coda
    return testo, ""


_RIFERIMENTO = re.compile(
    r"\briga\s+(\d+)(?:\s*,\s*colonna\s+\d+)?"
    r"(?:\s+(?:di|in|del file)\s+(\"[^\"]+\"|`[^`]+`|<[^>\s]+>|[^\s,;()]+))?",
    re.IGNORECASE,
)
_RIFERIMENTO_DUE_PUNTI = re.compile(r"([^\s\"'`()]+\.(?:leo|leo|maschera|toml)):(\d+)")


def _sembra_file(nome: str) -> bool:
    return bool(nome) and ("." in nome or "/" in nome or "\\" in nome or nome.startswith("<"))


def trova_riferimenti_riga(testo: str) -> list[tuple[int, int, str, int]]:
    """Tutti i riferimenti a una riga in ``testo``: ``(inizio, fine, nome_file, riga)``.

    ``inizio``/``fine`` sono indici nel testo (per sottolineare il collegamento);
    ``nome_file`` e' ``""`` se il messaggio non lo dice. Riconosce
    "alla riga 7, colonna 11 di voti.leo", "alla riga 3" e "voti.leo:7".
    """
    trovati: list[tuple[int, int, str, int]] = []
    try:
        for m in _RIFERIMENTO.finditer(testo or ""):
            nome = m.group(2) or ""
            fine = m.end()
            nome_pulito = nome.strip("\"`").rstrip(".,:;!?")
            if nome and _sembra_file(nome_pulito):
                fine = m.start(2) + len(nome.rstrip(".,:;!?"))
            else:
                nome_pulito = ""
                fine = m.end(1)
            trovati.append((m.start(), fine, nome_pulito, int(m.group(1))))
        for m in _RIFERIMENTO_DUE_PUNTI.finditer(testo or ""):
            if not any(a <= m.start() < b for a, b, _, _ in trovati):
                trovati.append((m.start(), m.end(), m.group(1), int(m.group(2))))
    except Exception:
        return []
    return sorted(trovati)


def trova_riferimento_riga(testo: str) -> tuple[str, int] | None:
    """Il primo riferimento "riga N [di file]" nel testo: ``(nome_file, riga)`` o ``None``.

    Se ci sono piu' riferimenti si preferisce il primo che nomina un file.
    """
    riferimenti = trova_riferimenti_riga(testo)
    if not riferimenti:
        return None
    for _, _, nome, riga in riferimenti:
        if nome:
            return nome, riga
    return riferimenti[0][2], riferimenti[0][3]
