"""Progetti Leo (cartella con ``progetto.toml``) - CONTRATTO CONDIVISO.

Struttura di un progetto::

    MioProgetto/
        progetto.toml
        Finestra1.maschera      # controlli (TOML, generato da Leo Studio)
        Finestra1.leo         # codice degli eventi
        principale.leo        # facoltativo: progetto senza finestre
        sinonimi.toml           # facoltativo: sinonimi aggiuntivi del progetto

``progetto.toml``::

    [progetto]
    nome = "Saluto"
    versione_leo = "0.1"       # nei progetti vecchi: versione_dante
    finestra_iniziale = "Finestra1"   # vuoto -> programma testuale: esegue `principale`
    principale = "principale.leo"    # file eseguito se non ci sono finestre
    finestre = ["Finestra1"]           # facoltativo: altrimenti tutte le *.maschera

    [stile]                            # vedi leo.stile
    variabili = "variabile"

    [sinonimi]                         # facoltativo, come sinonimi.toml
    mentre = ["intanto che"]

    [esecuzione]
    rigoroso = false

API:
    carica_progetto(cartella) -> Progetto      # ErroreFile se manca progetto.toml
    Progetto.salva() -> None
    crea_progetto(cartella, nome, *, con_finestra=True) -> Progetto
    e_progetto(percorso) -> bool
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from . import ESTENSIONE_SORGENTE, e_sorgente, file_sorgente
from .errori import ErroreFile
from .stile import Stile

NOME_FILE_PROGETTO = "progetto.toml"
VERSIONE_DANTE = "0.1"


@dataclass
class Progetto:
    cartella: Path
    nome: str
    finestra_iniziale: str = ""
    principale: str = "principale" + ESTENSIONE_SORGENTE
    finestre_esplicite: list[str] = field(default_factory=list)
    stile: Stile = field(default_factory=Stile)
    sinonimi: dict = field(default_factory=dict)      # sezione [sinonimi]
    rigoroso: bool = False
    versione_dante: str = VERSIONE_DANTE
    extra: dict = field(default_factory=dict)         # altre sezioni, conservate al salvataggio

    @property
    def finestre(self) -> list[str]:
        if self.finestre_esplicite:
            return list(self.finestre_esplicite)
        return sorted(p.stem for p in self.cartella.glob("*.maschera"))

    def percorso_maschera(self, finestra: str) -> Path:
        return self.cartella / f"{finestra}.maschera"

    def percorso_codice(self, finestra: str) -> Path:
        """``<finestra>.leo``; per i progetti vecchi ``<finestra>.dante`` se c'e' solo quello."""
        return file_sorgente(self.cartella, finestra)

    @property
    def percorso_principale(self) -> Path:
        """Il file ``principale``; se manca, lo stesso nome con l'altra estensione (.leo/.dante)."""
        p = self.cartella / self.principale
        if not p.exists() and e_sorgente(p.name):
            base = p.name[: p.name.rfind(".")]
            alternativo = file_sorgente(p.parent, base)
            if alternativo.exists():
                return alternativo
        return p

    @property
    def file_sinonimi(self) -> Path | None:
        p = self.cartella / "sinonimi.toml"
        return p if p.is_file() else None

    @property
    def e_grafico(self) -> bool:
        return bool(self.finestra_iniziale) or bool(self.finestre)

    def a_dizionario(self) -> dict:
        dati = dict(self.extra)
        dati["progetto"] = {
            "nome": self.nome,
            "versione_leo": self.versione_dante,
            "finestra_iniziale": self.finestra_iniziale,
            "principale": self.principale,
        }
        if self.finestre_esplicite:
            dati["progetto"]["finestre"] = list(self.finestre_esplicite)
        dati["stile"] = self.stile.a_dizionario()
        if self.sinonimi:
            dati["sinonimi"] = self.sinonimi
        dati["esecuzione"] = {"rigoroso": self.rigoroso}
        return dati

    def salva(self) -> None:
        from .tomlutil import salva_toml

        salva_toml(self.cartella / NOME_FILE_PROGETTO, self.a_dizionario())


def e_progetto(percorso: str | os.PathLike) -> bool:
    p = Path(percorso)
    return p.is_dir() and (p / NOME_FILE_PROGETTO).is_file()


def carica_progetto(cartella: str | os.PathLike) -> Progetto:
    cartella = Path(cartella)
    file = cartella / NOME_FILE_PROGETTO
    if not file.is_file():
        raise ErroreFile(f"Nella cartella `{cartella}` manca `{NOME_FILE_PROGETTO}`: non è un progetto Leo.")
    from .tomlutil import carica_toml  # qui e non in cima: `e_progetto` resta leggero per `leo file.leo`

    dati = carica_toml(file)
    info = dati.get("progetto", {})
    extra = {k: v for k, v in dati.items() if k not in ("progetto", "stile", "sinonimi", "esecuzione")}
    return Progetto(
        cartella=cartella,
        nome=str(info.get("nome", cartella.name)),
        finestra_iniziale=str(info.get("finestra_iniziale", "")),
        principale=str(info.get("principale", "principale" + ESTENSIONE_SORGENTE)),
        finestre_esplicite=list(info.get("finestre", [])),
        stile=Stile.da_dizionario(dati.get("stile")),
        sinonimi=dict(dati.get("sinonimi", {})),
        rigoroso=bool(dati.get("esecuzione", {}).get("rigoroso", False)),
        # "versione_dante": nome della chiave nei progetti creati prima del cambio di nome
        versione_dante=str(info.get("versione_leo", info.get("versione_dante", VERSIONE_DANTE))),
        extra=extra,
    )


def crea_progetto(cartella: str | os.PathLike, nome: str | None = None, *, con_finestra: bool = True) -> Progetto:
    """Crea la cartella, ``progetto.toml`` e (se richiesto) Finestra1.maschera/.leo vuote."""
    cartella = Path(cartella)
    try:
        cartella.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise ErroreFile(f"Non riesco a creare la cartella `{cartella}`: {e.strerror or e}.") from e
    p = Progetto(cartella=cartella, nome=nome or cartella.name)
    if con_finestra:
        from .grafica.maschera import salva_maschera
        from .grafica.modello import ModelloMaschera

        p.finestra_iniziale = "Finestra1"
        salva_maschera(p.percorso_maschera("Finestra1"), ModelloMaschera.nuova("Finestra1"))
        codice = p.percorso_codice("Finestra1")
        if not codice.exists():
            codice.write_text("# Codice degli eventi di Finestra1\n", encoding="utf-8")
    else:
        principale = p.percorso_principale
        if not principale.exists():
            # forma consigliata: il programma principale tra `inizio` e `fine`
            principale.write_text('inizio\n    stampa("Ciao, mondo!")\nfine\n', encoding="utf-8")
    p.salva()
    return p
