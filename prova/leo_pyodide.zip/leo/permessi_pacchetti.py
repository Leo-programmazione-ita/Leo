"""Permessi dei pacchetti: punto unico e isolato (lo completa il sistema dei permessi di Leo).

Un pacchetto Leo dichiara in ``pacchetto.toml`` che cosa gli serve::

    [pacchetto]
    nome = "meteo_facile"
    versione = "1.2.0"
    permessi = ["rete"]

``leo aggiungi`` mostra i permessi prima di installare, li scrive in ``leo.lock``
e rifiuta i nomi sconosciuti. Questo modulo è l'UNICO punto in cui si decide:

* :func:`controlla_dichiarati` - permessi validi? (all'installazione)
* :func:`descrivi` - frasi italiane da mostrare all'utente
* :func:`permessi_installati` - i permessi del progetto letti da ``leo.lock``
* :func:`controlla_import_python` - chiamato da ``importa python``: il codice di un pacchetto
  Leo puo' importare librerie Python solo se ha dichiarato ``python``
* :func:`permesso_concesso` - chiamato quando il codice di un pacchetto usa una capacità
  (concesso se dichiarato)
* :func:`pacchetto_di` / :func:`controlla_categoria` - usati dal custode dei permessi di Leo
  (:mod:`leo.permessi`): quando una funzione protetta e' chiamata dal codice di un pacchetto
  installato (``.leo/pacchetti/<nome>/``), la categoria deve essere tra quelle dichiarate dal
  pacchetto; poi valgono le regole normali (dichiarazione del programma, domande).
* :func:`imposta_politica` - il sistema dei permessi sostituisce le regole
  predefinite con le sue (per esempio chiedendo conferma all'utente).

Nessun altro file decide sui permessi dei pacchetti: chi li vuole rendere più
severi cambia solo questo modulo o installa una politica con :func:`imposta_politica`.
"""

from __future__ import annotations

import os
from typing import Any, Iterable

from .errori import ErroreValore

#: Permessi che un pacchetto Leo può chiedere, con la frase mostrata all'utente.
PERMESSI_NOTI: dict[str, str] = {
    "rete": "usare Internet e la rete locale",
    "file": "leggere e scrivere file fuori dalla cartella del progetto",
    "sistema": "avviare programmi e comandi del computer",
    "python": "usare librerie Python (importa python)",
    "hardware": "usare fotocamera, microfono, sensori, Bluetooth e porte seriali",
    "posizione": "conoscere la posizione del dispositivo",
    "appunti": "leggere e scrivere gli appunti",
    "notifiche": "mostrare notifiche",
    "schermo": "catturare lo schermo e controllare le finestre di altri programmi",
}


#: Categorie di :mod:`leo.permessi` -> permessi dei pacchetti che le coprono.
PERMESSI_PER_CATEGORIA: dict[str, frozenset[str]] = {
    "file": frozenset({"file"}),
    "rete": frozenset({"rete"}),
    "sistema": frozenset({"sistema", "schermo"}),
    "processi": frozenset({"sistema"}),
    "appunti": frozenset({"appunti"}),
    "hardware": frozenset({"hardware"}),
}


def pacchetto_di(percorso: str | os.PathLike | None) -> tuple[str, str] | None:
    """``(nome del pacchetto, radice del progetto)`` se ``percorso`` è un file di un pacchetto Leo
    installato (``<progetto>/.leo/pacchetti/<nome>/...``), altrimenti None."""
    if not percorso:
        return None
    parti = os.path.abspath(os.fspath(percorso)).replace("\\", "/").split("/")
    for i in range(len(parti) - 3, 0, -1):
        if parti[i] == ".leo" and parti[i + 1] == "pacchetti" and i + 2 < len(parti) - 1:
            return parti[i + 2], "/".join(parti[:i]) or "/"
    return None


def permessi_che_coprono(categoria: str, dispositivo: str | None = None) -> frozenset[str]:
    """I permessi dei pacchetti che bastano per una categoria di :mod:`leo.permessi`."""
    coprono = PERMESSI_PER_CATEGORIA.get(categoria, frozenset({categoria}))
    if categoria == "hardware" and dispositivo == "posizione":
        coprono = coprono | {"posizione"}
    return coprono


def controlla_categoria(file_chiamante: str | None, categoria: str, dispositivo: str | None,
                        funzione: str) -> None:
    """Se a chiamare è il codice di un pacchetto Leo, la categoria deve essere dichiarata da lui.

    Solleva :class:`leo.permessi.ErrorePermesso` (nessuna domanda: il pacchetto non l'ha chiesta
    all'installazione, quindi chi l'ha installato non l'ha mai vista)."""
    trovato = pacchetto_di(file_chiamante)
    if trovato is None:
        return
    pacchetto, radice = trovato
    dichiarati = permessi_installati(radice).get(pacchetto, [])
    coprono = permessi_che_coprono(categoria, dispositivo)
    if any(_POLITICA[0].concesso(pacchetto, p, dichiarati) for p in coprono):
        return
    from .permessi import ErrorePermesso

    nome = sorted(coprono)[0]
    raise ErrorePermesso(
        f"Il pacchetto `{pacchetto}` usa `{funzione}`, che richiede il permesso «{nome}», "
        f"ma non l'ha dichiarato in pacchetto.toml.",
        suggerimento=f"Chi scrive il pacchetto deve aggiungere `permessi = [\"{nome}\"]` in pacchetto.toml; "
                     "poi `leo aggiungi` lo mostra e chiede di approvarlo.")


class Politica:
    """Regole predefinite. Il sistema dei permessi può sostituirle (``imposta_politica``)."""

    def import_python(self, modulo: str, radice_progetto: str | None, file_chiamante: str | None = None) -> None:
        """Solleva un ErroreDante per vietare ``importa python "modulo"``: il codice di un pacchetto
        Leo deve aver dichiarato ``python``; il programma stesso puo' sempre."""
        trovato = pacchetto_di(file_chiamante)
        if trovato is None:
            return None
        pacchetto, radice = trovato
        if self.concesso(pacchetto, "python", permessi_installati(radice).get(pacchetto, [])):
            return None
        from .permessi import ErrorePermesso

        raise ErrorePermesso(
            f"Il pacchetto `{pacchetto}` vuole importare la libreria Python `{modulo}`, ma non ha "
            "dichiarato il permesso «python» in pacchetto.toml.",
            suggerimento="Chi scrive il pacchetto deve aggiungere `permessi = [\"python\"]`.")

    def concesso(self, pacchetto: str, permesso: str, dichiarati: Iterable[str]) -> bool:
        """Il pacchetto ``pacchetto`` può usare ``permesso``? Predefinito: sì se l'ha dichiarato."""
        return permesso in set(dichiarati)


_POLITICA: list[Politica] = [Politica()]


def imposta_politica(politica: Politica | None) -> None:
    """Sostituisce le regole (None = torna a quelle predefinite)."""
    _POLITICA[0] = politica or Politica()


def controlla_dichiarati(permessi: Any, pacchetto: str) -> list[str]:
    """I permessi dichiarati da un pacchetto, controllati (ErroreValore se sbagliati)."""
    if permessi is None:
        return []
    if not isinstance(permessi, list) or not all(isinstance(p, str) for p in permessi):
        raise ErroreValore(f"Il pacchetto `{pacchetto}`: `permessi` deve essere una lista di testi, "
                           "per esempio `permessi = [\"rete\"]`.")
    sconosciuti = [p for p in permessi if p not in PERMESSI_NOTI]
    if sconosciuti:
        raise ErroreValore(f"Il pacchetto `{pacchetto}` chiede permessi sconosciuti: {', '.join(sconosciuti)}.",
                           suggerimento="Permessi possibili: " + ", ".join(PERMESSI_NOTI) + ".")
    return sorted(set(permessi))


def descrivi(permessi: Iterable[str]) -> list[str]:
    """Frasi italiane per i permessi (``rete`` -> ``rete: usare Internet e la rete locale``)."""
    return [f"{p}: {PERMESSI_NOTI.get(p, 'permesso sconosciuto')}" for p in permessi]


def permessi_installati(radice_progetto: str | os.PathLike) -> dict[str, list[str]]:
    """Pacchetto Leo -> permessi dichiarati, letti da ``leo.lock`` del progetto."""
    from .pacchetti import leggi_blocco

    blocco = leggi_blocco(radice_progetto)
    return {p["nome"]: list(p.get("permessi", [])) for p in blocco.get("leo", [])}


def controlla_import_python(modulo: str, radice_progetto: str | None, file_chiamante: str | None = None) -> None:
    """Chiamato da ``importa python``: può vietare l'importazione sollevando un errore."""
    try:
        _POLITICA[0].import_python(modulo, radice_progetto, file_chiamante)
    except TypeError:                     # politiche scritte prima di file_chiamante
        _POLITICA[0].import_python(modulo, radice_progetto)


def permesso_concesso(pacchetto: str, permesso: str, radice_progetto: str | os.PathLike | None = None,
                      dichiarati: Iterable[str] | None = None) -> bool:
    """Il codice del pacchetto Leo ``pacchetto`` può usare ``permesso``?"""
    if dichiarati is None:
        dichiarati = permessi_installati(radice_progetto).get(pacchetto, []) if radice_progetto else []
    return bool(_POLITICA[0].concesso(pacchetto, permesso, dichiarati))

