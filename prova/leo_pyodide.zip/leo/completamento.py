"""Logica pura degli editor di Leo: completamento, frammenti e aiuti di scrittura.

Questo modulo non importa PySide6 ed e' condiviso: l'editor Qt di Leo Studio
(``leo/studio/qt/editor_codice.py``, che lo importa come ``leo.studio.completamento``)
e l'editor dell'app Android (``leo_android.completa``) lo usano per decidere *cosa*
fare, poi applicano il risultato al loro documento.

Contenuto:

* **Completamento automatico** (:func:`proposte`): parole chiave di Leo,
  frammenti pronti, controlli della finestra, proprieta' e metodi di un
  controllo dopo il punto (``Pulsante1.``), eventi dopo ``quando Controllo.``,
  funzioni di libreria con firma e descrizione, metodi dei valori
  (``testo.maiuscolo``), funzioni e variabili del programma.
* **Frammenti** (:data:`FRAMMENTI`, :func:`frammento_per`, :func:`espandi`):
  ``quando`` + Tab diventa un blocco completo con i campi da riempire (Tab passa
  al campo successivo) e il cursore dentro al blocco.
* **Chiusura automatica** di parentesi e virgolette (:func:`azione_carattere`,
  :func:`cancella_coppia`).
* **Rientro intelligente** e ``fine`` automatico (:func:`rientro_dopo`,
  :func:`manca_fine`, :func:`rientro_chiusura`).
* **Commenta/decommenta** piu' righe (:func:`commuta_commento`).
* **Punti di arresto** che seguono le modifiche (:func:`sposta_punti`).
* **Cronologia** delle risposte del terminale (:class:`Cronologia`).
* **Motore a posizione** (:func:`suggerimenti`): sorgente + riga + colonna ->
  :class:`Suggerimento` pronti da applicare (testo da inserire, cursore,
  segnaposto), con stile del progetto, sinonimi e ricerca tollerante
  (prefisso, parte interna/lettere in ordine, refusi); :func:`righe_da_aprire`,
  :func:`rientro_per_nuova_riga`, :func:`commenta`, :func:`decommenta`.

Le colonne sono in caratteri Unicode (l'editor converte in unita' UTF-16).
"""

from __future__ import annotations

import inspect
import re
from dataclasses import dataclass, field
from typing import Iterable, Mapping

__all__ = [
    "Proposta", "Contesto", "DatiCompletamento", "Espansione", "Cronologia",
    "FRAMMENTI", "PAROLE_CHIAVE", "RIENTRO",
    "analizza_contesto", "proposte", "filtra", "espandi", "frammento_per", "modello_frammento",
    "azione_carattere", "cancella_coppia", "in_testo_o_commento",
    "rientro_di", "apre_blocco", "rientro_dopo", "manca_fine", "rientro_chiusura", "parola_di_chiusura",
    "commuta_commento", "sposta_punti", "trova_tutte", "indice_dopo", "chiamata_in_corso", "nomi_dichiarati", "tipo_da_nome",
    "descrivi_parola", "funzioni_libreria", "metodi_valori", "info_tipo_controllo",
]

#: Un livello di rientro.
RIENTRO = "    "

_PAROLA = re.compile(r"[^\W\d]\w*", re.UNICODE)
_PAROLA_FINALE = re.compile(r"([^\W\d]\w*)?$", re.UNICODE)


# ===========================================================================
# Proposte
# ===========================================================================

#: Ordine dei gruppi nell'elenco (a parita' di corrispondenza).
_ORDINE_TIPI = {
    "evento": 0, "proprieta": 1, "metodo": 2, "frammento": 3, "variabile": 4, "controllo": 5,
    "funzione_utente": 6, "parola_chiave": 7, "funzione": 8, "costante": 9, "errore": 10,
}

#: Etichetta breve di ogni tipo (mostrata nell'elenco a comparsa).
ETICHETTE_TIPI = {
    "parola_chiave": "parola chiave", "frammento": "frammento", "controllo": "controllo",
    "proprieta": "proprietà", "evento": "evento", "metodo": "metodo", "funzione": "funzione",
    "funzione_utente": "tua funzione", "variabile": "variabile", "costante": "costante",
    "errore": "errore",
}


@dataclass(frozen=True)
class Proposta:
    """Una voce dell'elenco a comparsa.

    ``testo`` sostituisce la parola che si sta scrivendo; ``modello`` (se non
    vuoto) e' un frammento con i campi ``${1:...}``/``$0`` da espandere al suo
    posto (vedi :func:`espandi`).
    """

    testo: str
    tipo: str
    dettaglio: str = ""
    descrizione: str = ""
    modello: str = ""

    @property
    def etichetta_tipo(self) -> str:
        return ETICHETTE_TIPI.get(self.tipo, self.tipo)

    def suggerimento(self) -> str:
        """Testo per il riquadro dei dettagli (firma e descrizione)."""
        righe = [self.dettaglio or self.testo]
        if self.descrizione:
            righe.append(self.descrizione)
        return "\n".join(righe)


#: Parole chiave con una breve spiegazione (in ordine di utilita' per chi inizia).
PAROLE_CHIAVE: dict[str, str] = {
    "variabile": "Crea una variabile: `variabile x = 0`.",
    "costante": "Crea un valore che non cambia: `costante PI = 3.14`.",
    "crea variabile": "Come `variabile` (\"crea\" è facoltativo).",
    "crea costante": "Come `costante` (\"crea\" è facoltativo).",
    "se": "Esegue un blocco solo se la condizione è vera: `se ... allora ... fine`.",
    "allora": "Chiude la condizione di `se` / `altrimenti se` / `caso`.",
    "altrimenti": "Il blocco da eseguire quando la condizione di `se` è falsa.",
    "altrimenti se": "Un'altra condizione da provare dopo `se`.",
    "fine": "Chiude un blocco (`se`, `mentre`, `per ogni`, `funzione`, `quando`...).",
    "mentre": "Ripete finché la condizione è vera: `mentre ... fai ... fine`.",
    "fai": "Apre il corpo di `mentre`, `per ogni` e `quando`.",
    "per ogni": "Scorre gli elementi: `per ogni x in lista fai ... fine`.",
    "in": "Separa la variabile dall'elenco in `per ogni`.",
    "ripeti": "Ripete un numero fisso di volte: `ripeti 3 volte ... fine`.",
    "volte": "Chiude il conteggio di `ripeti`.",
    "interrompi": "Esce subito dal ciclo.",
    "continua": "Passa al giro successivo del ciclo.",
    "funzione": "Definisce una funzione: `funzione nome(parametri) ... fine`.",
    "restituisci": "Restituisce un valore dalla funzione.",
    "quando": "Collega il codice a un evento: `quando Pulsante1.clic fai ... fine`.",
    "prova": "Prova un blocco che potrebbe dare errore: `prova ... cattura ... fine`.",
    "cattura": "Gestisce un errore nato nel blocco `prova`.",
    "infine": "Blocco eseguito sempre, dopo `prova` e `cattura`.",
    "lancia": "Solleva un errore: `lancia ErroreValore(\"messaggio\")`.",
    "come": "Dà un nome all'errore catturato: `cattura come e`.",
    "scegli": "Sceglie tra più casi: `scegli valore ... caso 1 allora ... fine`.",
    "caso": "Un caso di `scegli`: `caso 1 allora`.",
    "importa": "Usa il codice di un altro file: `importa \"file.leo\"`.",
    "verifica": "Controlla che una condizione sia vera (per i test).",
    "e": "Vero se entrambe le condizioni sono vere.",
    "o": "Vero se almeno una condizione è vera.",
    "non": "Rovescia una condizione.",
    "è": "Confronto: `x è 3` (uguale a `==`).",
    "non è": "Confronto: `x non è 3` (uguale a `!=`).",
    "vero": "Il valore logico vero.",
    "falso": "Il valore logico falso.",
    "nulla": "Nessun valore.",
}

#: Frammenti pronti: parola -> (descrizione, modello). Nel modello ``\t`` e' un
#: livello di rientro, ``${n:testo}`` un campo da riempire (Tab passa al
#: successivo), ``$0`` il punto dove finisce il cursore.
FRAMMENTI: dict[str, tuple[str, str]] = {
    "quando": ("Evento di un controllo", "quando ${1:Controllo}.${2:evento} fai\n\t$0\nfine"),
    "se": ("Condizione", "se ${1:condizione} allora\n\t$0\nfine"),
    "sealtrimenti": ("Condizione con altrimenti", "se ${1:condizione} allora\n\t$0\naltrimenti\n\t\nfine"),
    "per ogni": ("Ciclo sugli elementi", "per ogni ${1:elemento} in ${2:lista} fai\n\t$0\nfine"),
    "mentre": ("Ciclo con condizione", "mentre ${1:condizione} fai\n\t$0\nfine"),
    "ripeti": ("Ciclo a conteggio", "ripeti ${1:3} volte\n\t$0\nfine"),
    "funzione": ("Nuova funzione", "funzione ${1:nome}(${2})\n\t$0\nfine"),
    "prova": ("Gestione degli errori", "prova\n\t$0\ncattura come ${1:errore}\n\tstampa(${1:errore}.messaggio)\nfine"),
    "scegli": ("Scelta tra più casi", "scegli ${1:valore}\n\tcaso ${2:1} allora\n\t\t$0\n\taltrimenti\n\t\t\nfine"),
    "variabile": ("Nuova variabile", "variabile ${1:nome} = ${2:0}"),
}

#: Altre parole che fanno scattare un frammento con Tab.
_ALIAS_FRAMMENTI = {"per": "per ogni", "perogni": "per ogni", "sealt": "sealtrimenti",
                    "se altrimenti": "sealtrimenti"}


@dataclass
class DatiCompletamento:
    """Cosa sa l'editor in questo momento.

    ``controlli``: nome del controllo -> tipo (``None`` se non noto: il tipo si
    ricava dal nome, es. ``PulsanteCalcola`` -> ``Pulsante``).
    ``funzioni_utente``: nome -> firma (``"saluta(nome)"``).
    ``variabili``: nomi dichiarati nel programma.
    """

    controlli: dict[str, str | None] = field(default_factory=dict)
    funzioni_utente: dict[str, str] = field(default_factory=dict)
    variabili: set[str] = field(default_factory=set)

    @classmethod
    def da_sorgente(cls, sorgente: str, controlli: Mapping[str, str | None] | Iterable[str] = ()) -> "DatiCompletamento":
        if isinstance(controlli, Mapping):
            mappa = dict(controlli)
        else:
            mappa = {nome: None for nome in controlli}
        funzioni, variabili = nomi_dichiarati(sorgente)
        return cls(mappa, funzioni, variabili)

    def tipo_di(self, nome: str) -> str | None:
        """Tipo del controllo ``nome`` (dal progetto o dedotto dal nome)."""
        if nome not in self.controlli:
            return None
        return self.controlli[nome] or tipo_da_nome(nome)


@dataclass(frozen=True)
class Contesto:
    """Dove si trova il cursore.

    ``prefisso``: parola che si sta scrivendo; ``oggetto``: nome prima del punto
    (``Pulsante1`` in ``Pulsante1.te``) o ``None``; ``evento``: vero dopo
    ``quando Controllo.``; ``inizio_istruzione``: la parola e' la prima della riga;
    ``dopo_quando``: si sta scrivendo il controllo di ``quando``;
    ``protetto``: dentro un testo o un commento (niente completamento).
    """

    prefisso: str
    oggetto: str | None = None
    evento: bool = False
    inizio_istruzione: bool = False
    dopo_quando: bool = False
    protetto: bool = False


def in_testo_o_commento(prima: str) -> bool:
    """Vero se la fine di ``prima`` (testo della riga prima del cursore) e'
    dentro un testo ``"..."`` (fuori dalle ``{}`` di interpolazione) o dopo ``#``."""
    stato = _stato_riga(prima)
    return stato in ("testo", "commento")


def _stato_riga(prima: str) -> str:
    """"codice", "testo", "commento" oppure "interpolazione" alla fine di ``prima``."""
    in_testo = False
    graffe = 0
    i = 0
    while i < len(prima):
        c = prima[i]
        if in_testo and graffe == 0:
            if c == "\\":
                i += 2
                continue
            if c == '"':
                in_testo = False
            elif c == "{":
                graffe = 1
        elif in_testo:            # dentro {...} di un testo interpolato
            if c == "{":
                graffe += 1
            elif c == "}":
                graffe -= 1
        else:
            if c == "#":
                return "commento"
            if c == '"':
                in_testo = True
        i += 1
    if in_testo:
        return "interpolazione" if graffe else "testo"
    return "codice"


def analizza_contesto(prima: str) -> Contesto:
    """Contesto del completamento da ``prima`` = testo della riga prima del cursore."""
    if in_testo_o_commento(prima):
        return Contesto(prefisso="", protetto=True)
    corrispondenza = _PAROLA_FINALE.search(prima)
    prefisso = corrispondenza.group(1) or "" if corrispondenza else ""
    resto = prima[:len(prima) - len(prefisso)]
    oggetto = None
    evento = False
    if resto.endswith(".") and not resto.endswith(".."):
        prima_del_punto = _PAROLA_FINALE.search(resto[:-1])
        nome = prima_del_punto.group(1) if prima_del_punto else None
        if nome:
            oggetto = nome
            davanti = resto[:-1 - len(nome)]
            evento = davanti.strip() == "quando"
        elif resto[:-1].rstrip()[-1:] in (")", "]", '"', "}"):
            oggetto = ""                  # un valore qualunque: "ciao".maiuscolo, lista[0].
        else:
            return Contesto(prefisso="", protetto=True)     # 3.5, oppure un punto da solo
    davanti = resto.strip()
    inizio = oggetto is None and davanti == ""
    dopo_quando = oggetto is None and davanti == "quando"
    return Contesto(prefisso=prefisso, oggetto=oggetto, evento=evento,
                    inizio_istruzione=inizio, dopo_quando=dopo_quando)


# --- dati del linguaggio (caricati una volta, con ripieghi) ------------------------------

_CACHE: dict[str, object] = {}


def _prima_riga(testo: str) -> str:
    for riga in (testo or "").splitlines():
        if riga.strip():
            return riga.strip()
    return ""


def _firma_e_descrizione(nome: str, nativa, *, metodo: bool = False) -> tuple[str, str]:
    """(firma, descrizione) da una ``FunzioneNativa``: la prima riga della
    documentazione e' ``nome(parametri): descrizione``."""
    doc = _prima_riga(getattr(nativa, "descrizione", "") or "")
    corrispondenza = re.match(r"^\s*([\w.]*\w\([^)]*\))\s*:\s*(.*)$", doc)
    if corrispondenza:
        firma = corrispondenza.group(1)
        if metodo and "." in firma:
            firma = firma.split(".", 1)[1]
        return firma, corrispondenza.group(2)
    parametri = ""
    firma_py = getattr(nativa, "firma", None)
    if firma_py is not None:
        voci = list(firma_py.parameters.values())
        if getattr(nativa, "vuole_interprete", False) and voci:
            voci = voci[1:]
        if metodo and voci:
            voci = voci[1:]
        pezzi = []
        for p in voci:
            if p.kind is inspect.Parameter.VAR_POSITIONAL:
                pezzi.append(f"{p.name}...")
            elif p.kind is inspect.Parameter.VAR_KEYWORD:
                continue
            elif p.default is not inspect.Parameter.empty:
                pezzi.append(f"{p.name} = {p.default!r}")
            else:
                pezzi.append(p.name)
        parametri = ", ".join(pezzi)
    return f"{nome}({parametri})", doc


def funzioni_libreria() -> dict[str, tuple[str, str]]:
    """nome -> (firma, descrizione) delle funzioni di libreria."""
    if "funzioni" not in _CACHE:
        risultato: dict[str, tuple[str, str]] = {}
        try:
            from . import registro

            registro.carica_libreria()
            for nome, nativa in registro.FUNZIONI.items():
                risultato[nome] = _firma_e_descrizione(nome, nativa)
        except Exception:
            for nome in ("stampa", "chiedi", "lunghezza", "intervallo", "casuale", "messaggio"):
                risultato[nome] = (f"{nome}(...)", "")
        _CACHE["funzioni"] = risultato
    return _CACHE["funzioni"]  # type: ignore[return-value]


def metodi_valori() -> dict[str, tuple[str, str, str]]:
    """nome del metodo -> (firma, descrizione, tipi) dei metodi di testi, liste, dizionari..."""
    if "metodi" not in _CACHE:
        risultato: dict[str, tuple[str, str, str]] = {}
        try:
            from . import registro

            registro.carica_libreria()
            for tipo, metodi in sorted(registro.METODI.items()):
                for nome, nativa in metodi.items():
                    firma, descrizione = _firma_e_descrizione(nome, nativa, metodo=True)
                    if nome in risultato:
                        vecchio = risultato[nome]
                        risultato[nome] = (vecchio[0], vecchio[1], vecchio[2] + ", " + tipo)
                    else:
                        risultato[nome] = (firma, descrizione, tipo)
        except Exception:
            pass
        _CACHE["metodi"] = risultato
    return _CACHE["metodi"]  # type: ignore[return-value]


def _costanti_ed_errori() -> dict[str, tuple[str, str]]:
    if "costanti" not in _CACHE:
        risultato: dict[str, tuple[str, str]] = {}
        try:
            from . import registro

            registro.carica_libreria()
            for nome in registro.COSTANTI:
                risultato[nome] = ("costante", "Valore predefinito della libreria.")
        except Exception:
            pass
        try:
            from .errori import TIPI_ERRORE

            for nome in TIPI_ERRORE:
                risultato[nome] = ("errore", f"Tipo di errore: `lancia {nome}(\"messaggio\")` "
                                             f"o `cattura {nome} come e`.")
        except Exception:
            pass
        _CACHE["costanti"] = risultato
    return _CACHE["costanti"]  # type: ignore[return-value]


def _catalogo() -> dict:
    if "catalogo" not in _CACHE:
        try:
            from .grafica.metadati import carica_catalogo

            _CACHE["catalogo"] = dict(carica_catalogo())
        except Exception:
            _CACHE["catalogo"] = {}
    return _CACHE["catalogo"]  # type: ignore[return-value]


def tipo_da_nome(nome: str) -> str | None:
    """Tipo di controllo dedotto dal nome: il tipo (o prefisso) piu' lungo con cui
    il nome comincia (``PulsanteCalcola`` -> ``Pulsante``, ``Etichetta1`` -> ``Etichetta``)."""
    migliore: tuple[int, str] | None = None
    for tipo in _catalogo().values():
        for prefisso in {tipo.nome, getattr(tipo, "prefisso_nome", "") or ""}:
            if prefisso and nome.startswith(prefisso):
                if migliore is None or len(prefisso) > migliore[0]:
                    migliore = (len(prefisso), tipo.nome)
    return migliore[1] if migliore else None


def info_tipo_controllo(tipo: str | None):
    """Metadati (``TipoControllo``) del tipo, o ``None``."""
    if not tipo:
        return None
    return _catalogo().get(tipo)


def _descrizione_metodo_controllo(funzione) -> str:
    return _prima_riga(inspect.getdoc(funzione) or "")


def _firma_metodo_controllo(nome: str, funzione) -> str:
    try:
        voci = list(inspect.signature(funzione).parameters.values())[1:]   # il primo e' il controllo
    except (TypeError, ValueError):
        return f"{nome}()"
    pezzi = []
    for p in voci:
        if p.kind is inspect.Parameter.VAR_POSITIONAL:
            pezzi.append(f"{p.name}...")
        elif p.kind is inspect.Parameter.VAR_KEYWORD:
            continue
        elif p.default is not inspect.Parameter.empty:
            pezzi.append(f"{p.name} = {p.default!r}")
        else:
            pezzi.append(p.name)
    return f"{nome}({', '.join(pezzi)})"


# --- funzioni e variabili del programma ----------------------------------------------------

_RE_FUNZIONE = re.compile(r"^[ \t]*funzione[ \t]+([^\W\d]\w*)[ \t]*\(([^)]*)\)", re.MULTILINE | re.UNICODE)
_RE_VARIABILE = re.compile(r"^[ \t]*(?:crea[ \t]+)?(?:variabile|costante)[ \t]+([^\W\d]\w*)",
                           re.MULTILINE | re.UNICODE)
_RE_PER_OGNI = re.compile(r"\bper[ \t]+ogni[ \t]+([^\W\d]\w*)", re.UNICODE)
_RE_COME = re.compile(r"\bcattura\b[^\n#]*\bcome[ \t]+([^\W\d]\w*)", re.UNICODE)


def nomi_dichiarati(sorgente: str) -> tuple[dict[str, str], set[str]]:
    """(funzioni nome -> firma, variabili) dichiarate nel sorgente."""
    funzioni: dict[str, str] = {}
    variabili: set[str] = set()
    for m in _RE_FUNZIONE.finditer(sorgente or ""):
        parametri = [p.strip() for p in m.group(2).split(",") if p.strip()]
        funzioni[m.group(1)] = f"{m.group(1)}({', '.join(parametri)})"
        for p in parametri:
            nome = _PAROLA.match(p.lstrip("."))
            if nome:
                variabili.add(nome.group(0))
    for espressione in (_RE_VARIABILE, _RE_PER_OGNI, _RE_COME):
        for m in espressione.finditer(sorgente or ""):
            variabili.add(m.group(1))
    return funzioni, variabili


# --- proposte --------------------------------------------------------------------------------

def _corrisponde(candidato: str, prefisso: str) -> int | None:
    """Punteggio della corrispondenza (piu' basso = migliore) o ``None``.

    0 = inizia col prefisso (maiuscole uguali), 1 = inizia ignorando maiuscole e
    accenti, 2 = una parola interna inizia col prefisso (``_maiuscolo``,
    ``PulsanteCalcola`` con ``calc``), 3 = le lettere compaiono in ordine.
    """
    if not prefisso:
        return 0
    if candidato.startswith(prefisso):
        return 0
    c = _semplice(candidato)
    p = _semplice(prefisso)
    if c.startswith(p):
        return 1
    parti = re.split(r"[_ ]|(?<=[a-z0-9])(?=[A-Z])", candidato)
    if any(_semplice(parte).startswith(p) for parte in parti[1:] if parte):
        return 2
    if len(p) >= 2:
        i = 0
        for lettera in c:
            if i < len(p) and lettera == p[i]:
                i += 1
        if i == len(p) and c[0] == p[0]:
            return 3
    return None


def _semplice(testo: str) -> str:
    import unicodedata

    return "".join(ch for ch in unicodedata.normalize("NFD", testo.lower()) if not unicodedata.combining(ch))


def filtra(candidati: Iterable[Proposta], prefisso: str, *, limite: int = 200) -> list[Proposta]:
    """Tiene le proposte che corrispondono a ``prefisso`` e le ordina."""
    punteggiate = []
    visti: set[tuple[str, str]] = set()
    for p in candidati:
        chiave = (p.testo, p.tipo)
        if chiave in visti:
            continue
        visti.add(chiave)
        punti = _corrisponde(p.testo, prefisso)
        if punti is None:
            continue
        punteggiate.append((punti, _ORDINE_TIPI.get(p.tipo, 20), len(p.testo), p.testo.lower(), p))
    punteggiate.sort(key=lambda t: t[:4])
    return [t[4] for t in punteggiate[:limite]]


def modello_frammento(parola: str, dati: DatiCompletamento | None = None) -> str | None:
    """Modello del frammento ``parola`` (con i nomi veri del progetto per ``quando``)."""
    chiave = _ALIAS_FRAMMENTI.get(parola, parola)
    voce = FRAMMENTI.get(chiave)
    if voce is None:
        return None
    modello = voce[1]
    if chiave == "quando" and dati is not None and dati.controlli:
        nome, evento = _controllo_per_quando(dati)
        modello = modello.replace("${1:Controllo}", "${1:" + nome + "}").replace("${2:evento}", "${2:" + evento + "}")
    return modello


def _controllo_per_quando(dati: DatiCompletamento) -> tuple[str, str]:
    """Un controllo da proporre nel frammento ``quando`` (il primo pulsante, se c'e')."""
    nomi = list(dati.controlli)
    ordinati = sorted(nomi, key=lambda n: (0 if (dati.tipo_di(n) or "").startswith("Pulsante")
                                           else 2 if dati.tipo_di(n) == "Finestra" else 1))
    nome = ordinati[0]
    info = info_tipo_controllo(dati.tipo_di(nome))
    evento = "clic"
    if info is not None:
        evento = info.evento_predefinito or (info.eventi[0] if info.eventi else "clic")
    return nome, evento


def proposte(prima: str, dati: DatiCompletamento | None = None, *, dopo: str = "") -> tuple[Contesto, list[Proposta]]:
    """Contesto e proposte per il cursore alla fine di ``prima`` (testo della riga).

    Restituisce le proposte gia' filtrate col prefisso e ordinate.
    """
    dati = dati or DatiCompletamento()
    contesto = analizza_contesto(prima)
    if contesto.protetto:
        return contesto, []
    candidati: list[Proposta] = []
    if contesto.oggetto is not None:
        candidati = _proposte_dopo_punto(contesto, dati)
    elif contesto.dopo_quando:
        candidati = [Proposta(n, "controllo", dati.tipo_di(n) or "controllo",
                              "Scegli il controllo, poi scrivi il punto e l'evento.")
                     for n in dati.controlli]
    else:
        candidati = _proposte_generali(contesto, dati)
    return contesto, filtra(candidati, contesto.prefisso)


def _proposte_dopo_punto(contesto: Contesto, dati: DatiCompletamento) -> list[Proposta]:
    nome = contesto.oggetto or ""
    tipo = dati.tipo_di(nome)
    info = info_tipo_controllo(tipo)
    if info is not None:
        if contesto.evento:
            return [Proposta(e, "evento", f"{nome}.{e}",
                             ("Evento predefinito di " if e == info.evento_predefinito else "Evento di ") + tipo)
                    for e in info.eventi]
        voci = []
        for p in info.proprieta.values():
            if p.nome == "nome" or getattr(p, "solo_progettazione", False):
                continue
            dettaglio = f"{p.nome}: {p.tipo}" + ("  (sola lettura)" if getattr(p, "sola_lettura", False) else "")
            voci.append(Proposta(p.nome, "proprieta", dettaglio, p.descrizione or f"Proprietà di {tipo}"))
        for m, funzione in info.metodi.items():
            voci.append(Proposta(m, "metodo", _firma_metodo_controllo(m, funzione),
                                 _descrizione_metodo_controllo(funzione), modello=_modello_chiamata(m, funzione)))
        return voci
    if contesto.evento:
        return []
    # un valore qualunque (testo, lista, dizionario...): i metodi della libreria
    return [Proposta(n, "metodo", firma, descrizione + (f"  [{tipi}]" if tipi else ""),
                     modello=_modello_da_firma(n, firma))
            for n, (firma, descrizione, tipi) in metodi_valori().items()]


def _modello_da_firma(nome: str, firma: str) -> str:
    """``nome($0)`` se la funzione vuole argomenti, ``nome()$0`` altrimenti."""
    dentro = firma[firma.find("(") + 1:firma.rfind(")")] if "(" in firma else ""
    return f"{nome}($0)" if dentro.strip() else f"{nome}()$0"


def _modello_chiamata(nome: str, funzione) -> str:
    return _modello_da_firma(nome, _firma_metodo_controllo(nome, funzione))


def _proposte_generali(contesto: Contesto, dati: DatiCompletamento) -> list[Proposta]:
    voci: list[Proposta] = []
    if contesto.inizio_istruzione:
        for parola, (descrizione, _) in FRAMMENTI.items():
            voci.append(Proposta(parola, "frammento", descrizione, "Tab o Invio inserisce il blocco completo.",
                                 modello=modello_frammento(parola, dati) or ""))
    for parola, descrizione in PAROLE_CHIAVE.items():
        if contesto.inizio_istruzione and parola in FRAMMENTI:
            continue                      # c'e' gia' il frammento con lo stesso nome
        voci.append(Proposta(parola, "parola_chiave", parola, descrizione))
    for nome in dati.controlli:
        tipo = dati.tipo_di(nome)
        info = info_tipo_controllo(tipo)
        voci.append(Proposta(nome, "controllo", tipo or "controllo",
                             (info.descrizione if info is not None else "") or "Controllo della finestra."))
    for nome, firma in dati.funzioni_utente.items():
        voci.append(Proposta(nome, "funzione_utente", firma, "Funzione definita nel tuo programma.",
                             modello=_modello_da_firma(nome, firma)))
    for nome in dati.variabili:
        voci.append(Proposta(nome, "variabile", nome, "Variabile del tuo programma."))
    for nome, (firma, descrizione) in funzioni_libreria().items():
        voci.append(Proposta(nome, "funzione", firma, descrizione, modello=_modello_da_firma(nome, firma)))
    for nome, (tipo, descrizione) in _costanti_ed_errori().items():
        voci.append(Proposta(nome, tipo, nome, descrizione,
                             modello=f"{nome}($0)" if tipo == "errore" else ""))
    return voci


def descrivi_parola(parola: str, prima: str, dati: DatiCompletamento | None = None) -> str:
    """Spiegazione breve di ``parola`` (per il suggerimento al passaggio del mouse).

    ``prima`` e' il testo della riga prima della parola (serve per ``Controllo.parola``).
    """
    dati = dati or DatiCompletamento()
    if not parola:
        return ""
    if prima.endswith(".") and not prima.endswith(".."):
        m = _PAROLA_FINALE.search(prima[:-1])
        oggetto = m.group(1) if m else None
        info = info_tipo_controllo(dati.tipo_di(oggetto)) if oggetto else None
        if info is not None:
            if parola in info.proprieta:
                p = info.proprieta[parola]
                return f"{oggetto}.{parola}: {p.tipo}\n{p.descrizione}".rstrip()
            if parola in info.eventi:
                return f"Evento `{parola}` di {info.nome}"
            if parola in info.metodi:
                funzione = info.metodi[parola]
                return (_firma_metodo_controllo(parola, funzione) + "\n" +
                        _descrizione_metodo_controllo(funzione)).rstrip()
        metodo = metodi_valori().get(parola)
        if metodo:
            return f"{metodo[0]}\n{metodo[1]}".rstrip()
        return ""
    if parola in dati.controlli:
        tipo = dati.tipo_di(parola)
        info = info_tipo_controllo(tipo)
        testo = f"{parola}: {tipo or 'controllo'}"
        if info is not None and info.descrizione:
            testo += "\n" + info.descrizione
        return testo
    if parola in dati.funzioni_utente:
        return dati.funzioni_utente[parola] + "\nFunzione definita nel tuo programma."
    funzione = funzioni_libreria().get(parola)
    if funzione:
        return f"{funzione[0]}\n{funzione[1]}".rstrip()
    altro = _costanti_ed_errori().get(parola)
    if altro:
        return f"{parola}\n{altro[1]}"
    return ""


def chiamata_in_corso(prima: str) -> tuple[str, int] | None:
    """(nome della funzione, indice dell'argomento) se il cursore e' dentro le
    parentesi di una chiamata non ancora chiusa, es. ``stampa("a", |`` -> ("stampa", 1)."""
    profondita = 0
    virgole = 0
    stato_testo = False
    # si scorre all'indietro, ignorando in modo semplice i testi tra virgolette
    i = len(prima) - 1
    while i >= 0:
        c = prima[i]
        if c == '"' and (i == 0 or prima[i - 1] != "\\"):
            stato_testo = not stato_testo
        elif not stato_testo:
            if c in ")]}":
                profondita += 1
            elif c in "[{":
                if profondita == 0:
                    return None
                profondita -= 1
            elif c == "(":
                if profondita == 0:
                    m = _PAROLA_FINALE.search(prima[:i].rstrip())
                    nome = m.group(1) if m else None
                    if not nome or nome in ("se", "mentre", "e", "o", "non", "in"):
                        return None
                    return nome, virgole
                profondita -= 1
            elif c == "," and profondita == 0:
                virgole += 1
        i -= 1
    return None


# ===========================================================================
# Frammenti
# ===========================================================================

@dataclass(frozen=True)
class Espansione:
    """Testo di un frammento espanso.

    ``campi``: (inizio, lunghezza) di ogni campo da riempire, nell'ordine di Tab
    (le posizioni sono relative all'inizio di ``testo``, in caratteri Unicode);
    ``collegati``: per ogni campo, le altre copie dello stesso campo (stesso numero);
    ``cursore``: dove va il cursore alla fine (``$0``).
    """

    testo: str
    campi: tuple[tuple[int, int], ...]
    cursore: int
    collegati: tuple[tuple[tuple[int, int], ...], ...] = ()


_CAMPO = re.compile(r"\$\{(\d+)(?::([^}]*))?\}|\$(\d+)")


def espandi(modello: str, rientro_base: str = "", rientro: str = RIENTRO) -> Espansione:
    """Espande un modello: ``\\t`` -> ``rientro``, ogni riga dopo la prima
    riceve ``rientro_base``; i campi diventano posizioni."""
    modello = modello.replace("\t", rientro).replace("\n", "\n" + rientro_base)
    testo: list[str] = []
    lunghezza = 0
    posizioni: dict[int, list[tuple[int, int]]] = {}
    indice = 0
    for m in _CAMPO.finditer(modello):
        pezzo = modello[indice:m.start()]
        testo.append(pezzo)
        lunghezza += len(pezzo)
        numero = int(m.group(1) or m.group(3))
        valore = m.group(2) or ""
        posizioni.setdefault(numero, []).append((lunghezza, len(valore)))
        testo.append(valore)
        lunghezza += len(valore)
        indice = m.end()
    testo.append(modello[indice:])
    lunghezza += len(modello[indice:])
    numeri = sorted(n for n in posizioni if n > 0)
    campi = tuple(posizioni[n][0] for n in numeri)
    collegati = tuple(tuple(posizioni[n][1:]) for n in numeri)
    cursore = posizioni[0][0][0] if 0 in posizioni else lunghezza
    return Espansione("".join(testo), campi, cursore, collegati)


def frammento_per(prima: str, dopo: str = "", dati: DatiCompletamento | None = None) -> tuple[int, str] | None:
    """Frammento da espandere con Tab: (colonna dove inizia la parola, modello)
    se la riga contiene solo una parola di :data:`FRAMMENTI` (o un alias) prima
    del cursore e niente dopo; altrimenti ``None``."""
    if dopo.strip():
        return None
    parola = prima.strip()
    if not parola:
        return None
    chiave = _ALIAS_FRAMMENTI.get(parola, parola)
    if chiave not in FRAMMENTI:
        return None
    modello = modello_frammento(chiave, dati)
    if modello is None:
        return None
    return len(prima) - len(prima.lstrip()), modello


# ===========================================================================
# Parentesi e virgolette
# ===========================================================================

COPPIE = {"(": ")", "[": "]", "{": "}", '"': '"'}
_CHIUSURE = frozenset(")]}")


def azione_carattere(prima: str, dopo: str, carattere: str) -> str | None:
    """Cosa fare quando si scrive ``carattere`` tra ``prima`` e ``dopo``:

    * ``"coppia"``: inserire anche la chiusura (``(`` -> ``()``, cursore in mezzo);
    * ``"salta"``: la chiusura c'e' gia' subito dopo: basta spostare il cursore;
    * ``None``: comportamento normale.
    """
    stato = _stato_riga(prima)
    if stato == "commento":
        return None
    seguente = dopo[:1]
    libero = seguente == "" or seguente.isspace() or seguente in ")]},;:."
    if carattere in _CHIUSURE:
        if seguente == carattere and stato in ("codice", "interpolazione"):
            return "salta"
        if seguente == carattere == "}" and stato == "testo":
            return "salta"
        return None
    if carattere == '"':
        if stato == "testo":
            return "salta" if seguente == '"' else None
        if stato == "interpolazione":
            return None
        precedente = prima[-1:]
        if precedente and (precedente.isalnum() or precedente in "_\""):
            return None
        return "coppia" if libero else None
    if carattere in "([":
        if stato == "testo":
            return None
        return "coppia" if libero or seguente == '"' else None
    if carattere == "{":
        return "coppia" if libero or stato == "testo" else None
    return None


def cancella_coppia(prima: str, dopo: str) -> bool:
    """Vero se Backspace deve togliere insieme una coppia vuota (``(|)``, ``"|"``)."""
    if not prima or not dopo:
        return False
    apertura = prima[-1]
    if COPPIE.get(apertura) != dopo[0]:
        return False
    if apertura == '"':
        # "|" : la virgoletta prima deve aprire un testo (non chiuderne uno)
        return _stato_riga(prima) == "testo"
    return _stato_riga(prima[:-1]) != "commento"


# ===========================================================================
# Rientri e blocchi
# ===========================================================================

_APERTURE = ("se", "mentre", "per ogni", "ripeti", "funzione", "prova", "quando", "scegli", "inizio")
_INTERMEDIE = ("altrimenti se", "altrimenti", "cattura", "infine", "caso")


def rientro_di(riga: str) -> str:
    return riga[:len(riga) - len(riga.lstrip(" \t"))]


def _larghezza(rientro: str) -> int:
    return sum(len(RIENTRO) if c == "\t" else 1 for c in rientro)


def _token_testo(testo: str, sinonimi=None, stile=None) -> list | None:
    """Token significativi del testo (lexer vero di Leo) o ``None`` se il lexer non c'e'."""
    try:
        from .colorazione import _sinonimi_predefiniti  # noqa: PLC0415
        from .lexer import Lexer
        from .tokens import TipoToken as T

        lx = Lexer(testo, sinonimi=sinonimi if sinonimi is not None else _sinonimi_predefiniti(),
                   stile=stile, conserva_commenti=True, tollerante=True)
        return [t for t in lx.tokenizza()
                if t.tipo not in (T.COMMENTO, T.ERRORE, T.FINE_RIGA, T.FINE_FILE)]
    except Exception:
        return None


def _forma(t) -> str:
    valore = str(t.valore) if t.tipo.name == "NOME" else t.tipo.value
    return valore if isinstance(valore, str) else ""


def _ripiego_riga(riga: str) -> tuple[str, str, bool]:
    codice = riga.split("#", 1)[0].strip()
    parole = codice.split()
    if not parole:
        return "", "", False
    prima = parole[0]
    if prima == "per" and len(parole) > 1 and parole[1] == "ogni":
        prima = "per ogni"
    if prima == "altrimenti" and len(parole) > 1 and parole[1] == "se":
        prima = "altrimenti se"
    ultima = ")" if codice.endswith(")") else parole[-1]
    return prima, ultima, bool(re.search(r"\bfine\b", codice))


def _analisi_righe(righe: list[str], sinonimi=None, stile=None) -> list[tuple[str, str, bool]]:
    """Per ogni riga: (prima parola canonica, ultima parola canonica, contiene ``fine``).

    Un solo passaggio del lexer su tutto il testo (sinonimi e commenti ``#[ ]#`` compresi)."""
    token = _token_testo("\n".join(righe), sinonimi, stile)
    if token is None:
        return [_ripiego_riga(r) for r in righe]
    per_riga: list[list] = [[] for _ in righe]
    for t in token:
        if 1 <= t.riga <= len(righe):
            per_riga[t.riga - 1].append(t)
    risultato = []
    for lista in per_riga:
        if not lista:
            risultato.append(("", "", False))
        else:
            risultato.append((_forma(lista[0]), _forma(lista[-1]), any(t.tipo.name == "FINE" for t in lista)))
    return risultato


_ATTESA = {"se": ("allora",), "mentre": ("fai",), "per ogni": ("fai",), "quando": ("fai",),
           "ripeti": ("volte",), "funzione": (")",), "prova": ("prova",), "scegli": None,
           "inizio": ("inizio",)}   # `inizio` da solo sulla riga (``inizio = 2`` e' un nome)


def _apre(analisi: tuple[str, str, bool]) -> bool:
    prima, ultima, ha_fine = analisi
    if prima not in _APERTURE or ha_fine:
        return False
    attesa = _ATTESA[prima]
    return attesa is None or ultima in attesa


def _chiusura(analisi: tuple[str, str, bool]) -> str | None:
    prima = analisi[0]
    return prima if prima == "fine" or prima in _INTERMEDIE else None


def apre_blocco(riga: str, *, sinonimi=None, stile=None) -> bool:
    """Vero se la riga apre un blocco che va chiuso con ``fine``
    (``se ... allora``, ``mentre ... fai``, ``per ogni ... fai``, ``ripeti ... volte``,
    ``funzione nome(...)``, ``prova``, ``quando ... fai``, ``scegli ...``)."""
    return _apre(_analisi_righe([riga], sinonimi, stile)[0])


def rientro_dopo(riga: str, *, sinonimi=None, stile=None) -> bool:
    """Vero se la riga dopo ``riga`` va rientrata di un livello (apertura di un
    blocco, ``altrimenti``, ``cattura``, ``infine``, ``caso ... allora``)."""
    analisi = _analisi_righe([riga], sinonimi, stile)[0]
    if _apre(analisi):
        return True
    prima, ultima, ha_fine = analisi
    if ha_fine:
        return False
    if prima in ("altrimenti", "infine") and ultima == prima:
        return True
    if prima in ("altrimenti se", "caso", "altrimenti") and ultima == "allora":
        return True
    return prima == "cattura"


def parola_di_chiusura(riga: str, *, sinonimi=None, stile=None) -> str | None:
    """``fine``/``altrimenti``/``altrimenti se``/``cattura``/``infine``/``caso`` se
    la riga comincia con una di queste parole, altrimenti ``None``."""
    return _chiusura(_analisi_righe([riga], sinonimi, stile)[0])


def rientro_chiusura(righe: list[str], indice: int, *, sinonimi=None, stile=None) -> str | None:
    """Rientro giusto per la riga ``indice`` se comincia con ``fine``,
    ``altrimenti``, ``cattura``, ``infine`` (quello dell'apertura del blocco)
    o ``caso`` (un livello dentro ``scegli``); ``None`` se la riga non e' una chiusura
    o l'apertura non si trova."""
    if _chiusura(_analisi_righe([righe[indice]], sinonimi, stile)[0]) is None:
        return None                       # controllo veloce: solo la riga corrente
    analisi = _analisi_righe(righe[:indice + 1], sinonimi, stile)
    parola = _chiusura(analisi[indice])
    if parola is None:
        return None
    profondita = 0
    for i in range(indice - 1, -1, -1):
        if not righe[i].strip():
            continue
        prima = analisi[i][0]
        if prima == "fine":
            profondita += 1
        elif _apre(analisi[i]):
            if profondita == 0:
                if prima == "scegli" and parola in ("caso", "altrimenti"):
                    return rientro_di(righe[i]) + RIENTRO
                if parola == "caso":
                    return None
                return rientro_di(righe[i])
            profondita -= 1
    return None


def manca_fine(righe: list[str], indice: int, *, sinonimi=None, stile=None) -> bool:
    """Vero se dopo Invio alla fine della riga ``indice`` conviene aggiungere ``fine``.

    La riga deve aprire un blocco; la riga non vuota successiva non deve essere gia'
    piu' rientrata (il corpo c'e' gia'), ne' un ``fine``/``altrimenti``... allo
    stesso rientro; e nel testo le aperture devono superare i ``fine``.
    """
    analisi = _analisi_righe(righe, sinonimi, stile)
    if not _apre(analisi[indice]):
        return False
    mio = _larghezza(rientro_di(righe[indice]))
    for j in range(indice + 1, len(righe)):
        if not righe[j].strip():
            continue
        suo = _larghezza(rientro_di(righe[j]))
        if suo > mio:
            return False
        if suo == mio and _chiusura(analisi[j]) is not None:
            return False
        break
    aperture = sum(1 for a in analisi if _apre(a))
    chiusure = sum(1 for a in analisi if a[0] == "fine")
    return aperture > chiusure


# ===========================================================================
# Ricerca
# ===========================================================================

def trova_tutte(testo: str, cercato: str, *, maiuscole: bool = False, parola_intera: bool = False,
                limite: int = 10000) -> list[tuple[int, int]]:
    """Posizioni (inizio, fine) in caratteri di tutte le occorrenze di ``cercato``.

    ``maiuscole``: distingue maiuscole e minuscole; ``parola_intera``: solo se
    non e' attaccato ad altre lettere, cifre o ``_``."""
    if not cercato:
        return []
    schema = re.escape(cercato)
    if parola_intera:
        schema = r"(?<![\w])" + schema + r"(?![\w])"
    opzioni = re.UNICODE | (0 if maiuscole else re.IGNORECASE)
    risultato = []
    for m in re.finditer(schema, testo, opzioni):
        if m.end() > m.start():
            risultato.append((m.start(), m.end()))
            if len(risultato) >= limite:
                break
    return risultato


def indice_dopo(occorrenze: list[tuple[int, int]], posizione: int, *, indietro: bool = False) -> int:
    """Indice della prima occorrenza che comincia da ``posizione`` in poi (o
    l'ultima che finisce prima, con ``indietro``), ricominciando dall'altro capo; -1 se vuoto."""
    if not occorrenze:
        return -1
    if indietro:
        for i in range(len(occorrenze) - 1, -1, -1):
            if occorrenze[i][1] <= posizione:
                return i
        return len(occorrenze) - 1
    for i, (inizio, _) in enumerate(occorrenze):
        if inizio >= posizione:
            return i
    return 0


# ===========================================================================
# Commenti
# ===========================================================================

def commuta_commento(righe: list[str]) -> list[str]:
    """Commenta le righe con ``# `` (allo stesso rientro, il minimo tra le righe)
    oppure le decommenta se sono gia' tutte commentate. Le righe vuote restano."""
    piene = [r for r in righe if r.strip()]
    if not piene:
        return list(righe)

    def commentata(r: str) -> bool:
        s = r.lstrip()
        return s.startswith("#") and not s.startswith("#[")

    if all(commentata(r) for r in piene):
        risultato = []
        for r in righe:
            if not r.strip():
                risultato.append(r)
                continue
            rientro = rientro_di(r)
            resto = r[len(rientro) + 1:]
            if resto.startswith(" "):
                resto = resto[1:]
            risultato.append(rientro + resto)
        return risultato
    minimo = min(len(rientro_di(r)) for r in piene)
    return [r if not r.strip() else r[:minimo] + "# " + r[minimo:] for r in righe]


# ===========================================================================
# Punti di arresto
# ===========================================================================

def sposta_punti(punti: Iterable[int], riga_modificata: int, differenza: int) -> set[int]:
    """Punti di arresto (righe da 1) dopo una modifica.

    ``riga_modificata``: riga (da 1) dove e' avvenuta la modifica;
    ``differenza``: righe aggiunte (>0) o tolte (<0). I punti dopo quella riga
    scorrono; quelli sulle righe tolte spariscono.
    """
    risultato: set[int] = set()
    for p in punti:
        if p <= riga_modificata:
            risultato.add(p)
        elif differenza < 0 and p <= riga_modificata - differenza:
            continue                         # la riga e' stata unita o cancellata
        else:
            risultato.add(p + differenza)
    return {p for p in risultato if p >= 1}


# ===========================================================================
# Cronologia (terminale)
# ===========================================================================

class Cronologia:
    """Cronologia delle risposte date al programma, navigabile con le frecce.

    Come in una console: su = risposta precedente, giu' = successiva, oltre
    l'ultima si torna alla bozza che si stava scrivendo.
    """

    def __init__(self, massimo: int = 200) -> None:
        self.voci: list[str] = []
        self.massimo = massimo
        self._indice = 0
        self._bozza = ""

    def aggiungi(self, testo: str) -> None:
        if testo and (not self.voci or self.voci[-1] != testo):
            self.voci.append(testo)
            if len(self.voci) > self.massimo:
                del self.voci[:len(self.voci) - self.massimo]
        self._indice = len(self.voci)
        self._bozza = ""

    def precedente(self, attuale: str = "") -> str | None:
        """Voce precedente (``None`` se non ce ne sono)."""
        if not self.voci:
            return None
        if self._indice == len(self.voci):
            self._bozza = attuale
        if self._indice == 0:
            return self.voci[0]
        self._indice -= 1
        return self.voci[self._indice]

    def successiva(self) -> str | None:
        """Voce successiva; dopo l'ultima la bozza; ``None`` se si e' gia' in fondo."""
        if self._indice >= len(self.voci):
            return None
        self._indice += 1
        return self.voci[self._indice] if self._indice < len(self.voci) else self._bozza

    def svuota(self) -> None:
        self.voci.clear()
        self._indice = 0
        self._bozza = ""


# ===========================================================================
# Motore dei suggerimenti (API a posizione: codice + riga + colonna)
# ===========================================================================
#
# :func:`suggerimenti` e' l'ingresso "tutto in uno" per l'editor: riceve il
# sorgente intero e la posizione del cursore e restituisce le voci gia'
# ordinate per pertinenza, ognuna con il testo esatto da inserire e la
# posizione del cursore dopo l'inserimento. Rispetta lo stile del progetto
# (``[stile]`` o intestazione ``#stile:``) e i sinonimi delle parole chiave.
#
# Velocita': l'analisi delle dichiarazioni e' fatta riga per riga e ricordata
# (una riga non cambiata non viene rianalizzata), i candidati fissi (parole
# chiave, libreria, catalogo) sono preparati una volta sola: su un file di
# 2000 righe una richiesta costa pochi millisecondi.

import functools
import unicodedata

__all__ += [
    "Suggerimento", "TIPI_SUGGERIMENTO", "suggerimenti", "punteggio_ricerca", "ordina_suggerimenti",
    "frammenti_disponibili", "righe_da_aprire", "rientro_per_nuova_riga", "commenta", "decommenta",
    "dichiarazioni",
]

#: Tipi possibili di :attr:`Suggerimento.tipo`.
TIPI_SUGGERIMENTO = ("parola_chiave", "controllo", "proprieta", "evento", "funzione", "variabile", "frammento")


@dataclass(frozen=True)
class Suggerimento:
    """Una voce del completamento, pronta da applicare.

    * ``testo``: cio' che si vede nell'elenco (``"per ogni"``, ``"stampa"``);
    * ``tipo``: uno di :data:`TIPI_SUGGERIMENTO`;
    * ``dettaglio``: firma o tipo (``"stampa(valori..., separatore = \\" \\")"``,
      ``"testo: testo"``);
    * ``descrizione``: spiegazione breve in italiano;
    * ``testo_da_inserire``: sostituisce le colonne ``inizio``..``fine`` della
      riga (puo' contenere piu' righe, gia' rientrate come la riga corrente);
    * ``posizione_cursore``: dove mettere il cursore, in caratteri dall'inizio
      di ``testo_da_inserire``; se ``lunghezza_selezione`` > 0 quei caratteri
      (il primo segnaposto) vanno selezionati, cosi' scrivere li sostituisce;
    * ``campi``: tutti i segnaposto ``(inizio, lunghezza)`` relativi, in ordine
      di Tab; ``cursore_finale``: dove finisce il cursore dopo l'ultimo campo;
    * ``inizio``/``fine``: colonne (da 1, ``fine`` esclusa) della parola da
      sostituire nella riga del cursore;
    * ``corrispondenza``: ``"prefisso"``, ``"parziale"`` (parte interna o
      lettere in ordine) o ``"refuso"``;
    * ``collegati``: per ogni campo, le altre copie dello stesso segnaposto
      (come :attr:`Espansione.collegati`): scrivendo nel campo cambiano anche loro.
    """

    testo: str
    tipo: str
    dettaglio: str = ""
    descrizione: str = ""
    testo_da_inserire: str = ""
    posizione_cursore: int = -1
    lunghezza_selezione: int = 0
    campi: tuple[tuple[int, int], ...] = ()
    cursore_finale: int = -1
    inizio: int = 1
    fine: int = 1
    corrispondenza: str = "prefisso"
    collegati: tuple[tuple[tuple[int, int], ...], ...] = ()

    def __post_init__(self) -> None:
        if not self.testo_da_inserire:
            object.__setattr__(self, "testo_da_inserire", self.testo)
        if self.posizione_cursore < 0:
            object.__setattr__(self, "posizione_cursore", len(self.testo_da_inserire))
        if self.cursore_finale < 0:
            object.__setattr__(self, "cursore_finale", self.posizione_cursore)

    @property
    def firma(self) -> str:
        """Sinonimo di ``dettaglio`` (per le funzioni e' la firma)."""
        return self.dettaglio

    @property
    def etichetta_tipo(self) -> str:
        return ETICHETTE_TIPI.get(self.tipo, self.tipo)

    def applica(self, riga: str) -> tuple[str, int]:
        """(nuovo testo, posizione del cursore in caratteri) applicando la voce a ``riga``
        (la riga del cursore): utile ai test e agli editor semplici."""
        a = max(0, self.inizio - 1)
        b = max(a, self.fine - 1)
        nuovo = riga[:a] + self.testo_da_inserire + riga[b:]
        return nuovo, a + self.posizione_cursore


# --- ricerca tollerante ---------------------------------------------------------------------

@functools.lru_cache(maxsize=16384)
def _piano(testo: str) -> str:
    """Minuscole senza accenti (``Opacità`` -> ``opacita``)."""
    if testo.isascii():
        return testo.lower()
    return "".join(ch for ch in unicodedata.normalize("NFD", testo.lower()) if not unicodedata.combining(ch))


@functools.lru_cache(maxsize=16384)
def _parti(testo: str) -> tuple[str, ...]:
    """Parti interne di un nome (dopo ``_``, spazi o una maiuscola), gia' semplificate."""
    pezzi = re.split(r"[_ ]|(?<=[a-z0-9àèéìòù])(?=[A-Z])", testo)
    return tuple(_piano(p) for p in pezzi[1:] if p)


#: Colonne gia' calcolate della tabella delle distanze:
#: (a, massimo, inizio di b) -> (penultima colonna, ultima colonna, migliore finora).
#: Molti nomi cominciano allo stesso modo (``calcola1``, ``calcola2``...): le
#: colonne del pezzo comune si calcolano una volta sola.
_COLONNE: dict[tuple[str, int, str], tuple[tuple[int, ...], tuple[int, ...], int]] = {}


def _colonna(a: str, massimo: int, b: str) -> tuple[tuple[int, ...], tuple[int, ...], int]:
    """Colonne della tabella di Damerau-Levenshtein tra ``a`` e ``b`` (tutto ``b``)
    e la distanza minima tra ``a`` e gli inizi di ``b`` lunghi almeno ``len(a) - massimo``."""
    chiave = (a, massimo, b)
    trovata = _COLONNE.get(chiave)
    if trovata is not None:
        return trovata
    k = len(b)
    if k == 0:
        penultima: tuple[int, ...] = ()
        attuale: list[int] | tuple[int, ...] = tuple(range(len(a) + 1))
        migliore = len(a) if len(a) <= massimo else massimo + 1
    else:
        penultima, precedente, migliore = _colonna(a, massimo, b[:-1])
        bk = b[k - 1]
        attuale = [k]
        for i in range(1, len(a) + 1):
            ai = a[i - 1]
            v = precedente[i - 1] + (ai != bk)
            if precedente[i] + 1 < v:
                v = precedente[i] + 1
            if attuale[i - 1] + 1 < v:
                v = attuale[i - 1] + 1
            if k > 1 and i > 1 and ai == b[k - 2] and a[i - 2] == bk and penultima[i - 2] + 1 < v:
                v = penultima[i - 2] + 1
            attuale.append(v)
        if k >= len(a) - massimo and attuale[-1] < migliore:
            migliore = attuale[-1]
        penultima = precedente
    risultato = (penultima, tuple(attuale), migliore)
    if len(_COLONNE) > 200000:
        _COLONNE.clear()
    _COLONNE[chiave] = risultato
    return risultato


def _distanza_prefisso(a: str, b: str, massimo: int) -> int:
    """Minima distanza di Damerau-Levenshtein (scambio di due lettere vicine = 1
    errore) tra ``a`` e un inizio di ``b`` lungo da ``len(a) - massimo`` a
    ``len(a) + massimo``; al massimo ``massimo + 1``."""
    return min(_colonna(a, massimo, b[:len(a) + massimo])[2], massimo + 1)


def punteggio_ricerca(candidato: str, digitato: str) -> tuple[int, int] | None:
    """Quanto ``candidato`` corrisponde a ``digitato``: ``(gruppo, dettaglio)``, piu'
    basso = migliore, oppure ``None``.

    Gruppo 0 - **prefisso**: dettaglio 0 uguale, 1 inizia uguale (maiuscole
    comprese), 2 inizia ignorando maiuscole e accenti.
    Gruppo 1 - **parziale**: 0 una parte interna inizia cosi' (``calc`` ->
    ``PulsanteCalcola``), 1 le lettere compaiono in ordine (``lng`` -> ``lunghezza``).
    Gruppo 2 - **refuso**: una o due lettere sbagliate, mancanti, in piu' o
    scambiate (``lunhezza``, ``stmapa``); dettaglio = numero di errori.
    """
    if not digitato:
        return (0, 1)
    if candidato == digitato:
        return (0, 0)
    if candidato.startswith(digitato):
        return (0, 1)
    c = _piano(candidato)
    p = _piano(digitato)
    if c.startswith(p):
        return (0, 2)
    compatto = c.replace(" ", "") if " " in c else c
    if compatto[:1] != p[0] and p not in compatto and compatto[:2] != p[1::-1]:
        return None                       # scarto veloce: nessuna delle regole puo' valere
    if " " in c and compatto.startswith(p):
        return (0, 2)                     # "sealtrimenti" -> "se altrimenti"
    if any(parte.startswith(p) for parte in _parti(candidato)):
        return (1, 0)
    if len(p) >= 2 and compatto[:1] == p[0]:
        i = 0
        for posizione, lettera in enumerate(compatto):
            if lettera == p[i]:
                i += 1
                if i == len(p):
                    # con molte lettere scritte, lettere sparse su un nome lungo non valgono
                    # (``stmapa`` e' un refuso di ``stampa``, non ``sistema_operativo``)
                    if len(p) < 5 or posizione + 1 <= len(p) * 3 // 2 + 1:
                        return (1, 1)
                    break
    if len(p) >= 3 and (compatto[:1] == p[0] or compatto[:2] == p[1::-1]):
        massimo = 1 if len(p) <= 5 else 2
        if len(compatto) >= len(p) - massimo:
            errori = _distanza_prefisso(p, compatto[:len(p) + massimo], massimo)
            if errori <= massimo:
                return (2, errori)
    return None


_NOMI_CORRISPONDENZA = {0: "prefisso", 1: "parziale", 2: "refuso"}


def ordina_suggerimenti(voci: Iterable[tuple[Suggerimento, float]], digitato: str, *,
                        limite: int = 100) -> list[Suggerimento]:
    """Filtra e ordina ``(suggerimento, rango)``: prima il gruppo di
    corrispondenza (prefisso, parziale, refuso), poi il rango del contesto
    (piu' basso = piu' pertinente), poi la qualita', la lunghezza e l'alfabeto.
    A parita' di testo resta la voce di rango migliore."""
    return _ordina([(v.testo, v.tipo, rango, v) for v, rango in voci], digitato, limite)


def _ordina(voci: list[tuple], digitato: str, limite: int) -> list[Suggerimento]:
    """``voci``: ``(testo, tipo, rango, crea)`` dove ``crea`` e' un Suggerimento
    o una tupla di argomenti per costruirlo (costruito solo se serve)."""
    punteggiate = []
    for voce in voci:
        testo = voce[0]
        punti = punteggio_ricerca(testo, digitato)
        if punti is None:
            continue
        gruppo, dettaglio = punti
        rango = voce[2]
        if gruppo == 0 and dettaglio == 0 and digitato:
            rango -= 100                   # la parola scritta per intero va in cima
        punteggiate.append(((gruppo, rango, dettaglio, len(testo), testo.lower(), voce[1]), voce))
    punteggiate.sort(key=lambda t: t[0])
    risultato: list[Suggerimento] = []
    visti: set[str] = set()
    for chiave, voce in punteggiate:
        if voce[0] in visti:
            continue
        visti.add(voce[0])
        nome = _NOMI_CORRISPONDENZA[chiave[0]]
        crea = voce[3]
        if isinstance(crea, Suggerimento):
            elemento = crea if crea.corrispondenza == nome else _con(crea, corrispondenza=nome)
        else:
            elemento = Suggerimento(*crea, corrispondenza=nome)
        risultato.append(elemento)
        if len(risultato) >= limite:
            break
    return risultato


def _con(voce: Suggerimento, **modifiche) -> Suggerimento:
    from dataclasses import replace

    return replace(voce, **modifiche)


# --- stile e sinonimi ------------------------------------------------------------------------

def _stile_per(codice: str, stile):
    """Lo stile da usare: quello passato, l'intestazione ``#stile:`` del file o quello di serie."""
    try:
        from .stile import Stile

        if stile is None:
            return _stile_intestazione(_prima_riga_piena(codice))
        if isinstance(stile, Mapping):
            return Stile.da_dizionario(dict(stile))
        return stile
    except Exception:
        return None


def _prima_riga_piena(codice: str) -> str:
    """Prima riga non vuota (senza dividere tutto il file)."""
    inizio = 0
    while True:
        fine = codice.find("\n", inizio)
        riga = codice[inizio:] if fine < 0 else codice[inizio:fine]
        if riga.strip() or fine < 0:
            return riga
        inizio = fine + 1


@functools.lru_cache(maxsize=64)
def _stile_intestazione(riga: str):
    """Stile dell'intestazione ``#stile:`` (o quello di serie se manca o e' sbagliata)."""
    from .stile import Stile

    try:
        return Stile.da_intestazione(riga) or Stile()
    except Exception:
        return Stile()


def _sinonimi_per(sinonimi):
    """``False`` = nessun sinonimo (modo rigoroso); ``None`` = quelli di serie."""
    if sinonimi is False:
        return None
    if sinonimi is not None:
        return sinonimi
    try:
        from .colorazione import _sinonimi_predefiniti

        return _sinonimi_predefiniti()
    except Exception:
        return None


_MEMORIA_SINONIMI: dict[tuple[int, int, str], list[str]] = {}


def _sinonimi_di(sinonimi, canonica: str) -> list[str]:
    """Sinonimi di una parola chiave (ricordati finche' l'oggetto non cambia)."""
    if sinonimi is None:
        return []
    mappa = getattr(sinonimi, "mappa", None)
    chiave = (id(sinonimi), len(mappa) if mappa is not None else -1, canonica)
    trovati = _MEMORIA_SINONIMI.get(chiave)
    if trovati is None:
        try:
            from .tokens import tipo_da_canonica

            tipo = tipo_da_canonica(canonica)
            trovati = list(sinonimi.sinonimi_di(tipo)) if tipo is not None else []
        except Exception:
            trovati = []
        if len(_MEMORIA_SINONIMI) > 4096:
            _MEMORIA_SINONIMI.clear()
        _MEMORIA_SINONIMI[chiave] = trovati
    return trovati


def _valore_stile(stile, campo: str, predefinito: str) -> str:
    valore = getattr(stile, campo, None) if stile is not None else None
    return valore if isinstance(valore, str) and valore else predefinito


# --- dichiarazioni nel file (analisi riga per riga, con memoria) ----------------------------

_NOME = r"[^\W\d]\w*"


@dataclass(frozen=True)
class _Regole:
    """Espressioni per riconoscere le dichiarazioni con lo stile e i sinonimi del progetto.

    Ogni espressione comincia con una parola fissa (``variabile``, ``per``...):
    cosi' il motore delle espressioni salta subito ai punti giusti del testo
    invece di provare ogni posizione. L'inizio riga si controlla a parte."""

    variabile: tuple[re.Pattern, ...]
    funzione: tuple[re.Pattern, ...]
    funzione_con: tuple[re.Pattern, ...]
    per_ogni: tuple[re.Pattern, ...]
    cattura: re.Pattern
    implicita: re.Pattern | None


def _frasi(parole: Iterable[str]) -> list[str]:
    """Espressioni (una per frase, parole separate da spazi o tab) senza doppioni."""
    uniche = sorted({" ".join(p.split()) for p in parole if p and p.strip()}, key=len, reverse=True)
    return [r"[ \t]+".join(re.escape(w) for w in p.split()) for p in uniche]


_REGOLE: dict[tuple, _Regole] = {}
_MR = re.UNICODE | re.MULTILINE


def _regole(stile, sinonimi) -> _Regole:
    variabili = ["variabile", "crea variabile", "costante", "crea costante"]
    for campo in ("variabili", "costanti"):
        valore = _valore_stile(stile, campo, "")
        if valore and valore != "implicita":
            variabili.append(valore)
    funzioni = ["funzione", _valore_stile(stile, "funzioni", "funzione"), *_sinonimi_di(sinonimi, "funzione")]
    per_ogni = ["per ogni", *_sinonimi_di(sinonimi, "per ogni")]
    assegna = r"(?:=(?!=)|vale\b)" if _valore_stile(stile, "predefiniti", "=") == "vale" else r"=(?!=)"
    chiave = (tuple(variabili), tuple(funzioni), tuple(per_ogni), assegna,
              _valore_stile(stile, "variabili", ""), _valore_stile(stile, "parametri", ""))
    regole = _REGOLE.get(chiave)
    if regole is None:
        implicita = None
        if _valore_stile(stile, "variabili", "") == "implicita":
            implicita = re.compile(rf"^[ \t]*({_NOME})[ \t]*{assegna}", _MR)
        funzione_con: tuple[re.Pattern, ...] = ()
        if _valore_stile(stile, "parametri", "") == "con":
            funzione_con = tuple(
                re.compile(rf"{f}[ \t]+({_NOME})(?:[ \t]+con[ \t]+([^\n#]*))?[ \t]*(?:#[^\n]*)?(?=\n|\Z)", re.UNICODE)
                for f in _frasi(funzioni))
        regole = _Regole(
            variabile=tuple(re.compile(rf"{f}[ \t]+({_NOME})", re.UNICODE) for f in _frasi(variabili)),
            funzione=tuple(re.compile(rf"{f}[ \t]+({_NOME})[ \t]*\(([^)\n]*)\)", re.UNICODE)
                           for f in _frasi(funzioni)),
            funzione_con=funzione_con,
            per_ogni=tuple(re.compile(rf"{f}[ \t]+({_NOME})", re.UNICODE) for f in _frasi(per_ogni)),
            cattura=re.compile(rf"cattura\b[^\n#]*\bcome[ \t]+({_NOME})", re.UNICODE),
            implicita=implicita,
        )
        if len(_REGOLE) > 64:
            _REGOLE.clear()
        _REGOLE[chiave] = regole
    return regole


def _a_inizio_riga(testo: str, posizione: int) -> bool:
    """Vero se prima di ``posizione``, nella sua riga, ci sono solo spazi."""
    inizio = testo.rfind("\n", 0, posizione) + 1
    return inizio == posizione or not testo[inizio:posizione].strip(" \t")


def _parola_intera(testo: str, posizione: int) -> bool:
    return posizione == 0 or not (testo[posizione - 1].isalnum() or testo[posizione - 1] == "_")


def _parametri(testo: str) -> list[str]:
    """Nomi dei parametri da ``a, b: intero, saluto = "Ciao"``."""
    nomi = []
    for pezzo in testo.split(","):
        m = re.match(rf"[ \t]*\.*({_NOME})", pezzo, re.UNICODE)
        if m:
            nomi.append(m.group(1))
    return nomi


def _firma(nome: str, parametri: str) -> str:
    return f"{nome}({', '.join(p.strip() for p in parametri.split(',') if p.strip())})"


def _nel_codice(testo: str, posizione: int) -> bool:
    """Vero se ``posizione`` non e' dentro un testo o un commento della sua riga."""
    inizio_riga = testo.rfind("\n", 0, posizione) + 1
    davanti = testo[inizio_riga:posizione]
    if "#" not in davanti and '"' not in davanti:
        return True
    return _stato_riga(davanti) in ("codice", "interpolazione")


def _dichiarazioni_testo(testo: str, regole: _Regole) -> tuple[list[tuple[int, str, str]], list[tuple[int, str]]]:
    """(funzioni [(posizione, nome, firma)], variabili [(posizione, nome)]) trovate in ``testo``.

    Le espressioni lavorano sull'intero testo in una volta (molto piu' veloce
    che riga per riga); le posizioni servono a ricavare la riga."""
    funzioni: list[tuple[int, str, str]] = []
    variabili: list[tuple[int, str]] = []
    for espressione in regole.funzione:
        for m in espressione.finditer(testo):
            if _a_inizio_riga(testo, m.start()):
                funzioni.append((m.start(1), m.group(1), _firma(m.group(1), m.group(2))))
                variabili.extend((m.start(2), n) for n in _parametri(m.group(2)))
    for espressione in regole.funzione_con:
        for m in espressione.finditer(testo):
            if _a_inizio_riga(testo, m.start()):
                elenco = m.group(2) or ""
                funzioni.append((m.start(1), m.group(1), _firma(m.group(1), elenco)))
                variabili.extend((m.start(1) + 1, n) for n in _parametri(elenco))
    for espressione in regole.variabile:
        for m in espressione.finditer(testo):
            if _a_inizio_riga(testo, m.start()):
                variabili.append((m.start(1), m.group(1)))
    if regole.implicita is not None:
        for m in regole.implicita.finditer(testo):
            variabili.append((m.start(1), m.group(1)))
    for espressione in (*regole.per_ogni, regole.cattura):
        for m in espressione.finditer(testo):
            if _parola_intera(testo, m.start()) and _nel_codice(testo, m.start()):
                variabili.append((m.start(1), m.group(1)))
    return funzioni, variabili


def _dichiarazioni_riga(riga: str, regole: _Regole) -> tuple[tuple[tuple[str, str], ...], tuple[str, ...]]:
    """(funzioni (nome, firma), variabili) dichiarate in una sola riga."""
    funzioni, variabili = _dichiarazioni_testo(riga, regole)
    return (tuple((n, f) for _, n, f in sorted(funzioni)), tuple(n for _, n in sorted(variabili)))


def dichiarazioni(righe: Iterable[str], *, stile=None, sinonimi=None,
                  salta: int | None = None) -> tuple[dict[str, str], dict[str, int]]:
    """(funzioni nome -> firma, variabili nome -> riga da 1 della prima dichiarazione).

    Riconosce ``variabile``/``costante`` (con o senza ``crea``), le parole
    scelte nello stile (``sia``, ``fissa``, ``procedura``..., la dichiarazione
    implicita ``x = 0``, i parametri ``con``), i sinonimi di ``funzione`` e di
    ``per ogni``, i parametri delle funzioni, ``per ogni x`` e ``cattura come e``.
    ``salta``: indice (da 0) di una riga da ignorare (quella che si sta scrivendo).
    """
    regole = _regole(stile, _sinonimi_per(sinonimi))
    righe = righe if isinstance(righe, list) else list(righe)
    # di solito cambia solo la riga del cursore: se il resto e' uguale si riusa il risultato
    chiave = (id(regole), salta, len(righe))
    memoria = _MEMORIA_FILE.get("ultimo")
    if (memoria is not None and memoria[0] == chiave and salta is not None
            and memoria[1] == righe[:salta] and memoria[2] == righe[salta + 1:]):
        return dict(memoria[3]), dict(memoria[4])
    funzioni, variabili = _dichiarazioni_calcola(righe, regole, salta)
    if salta is not None:
        _MEMORIA_FILE["ultimo"] = (chiave, righe[:salta], righe[salta + 1:], dict(funzioni), dict(variabili))
    return funzioni, variabili


_MEMORIA_FILE: dict[str, tuple] = {}


def _dichiarazioni_calcola(righe: list[str], regole: _Regole,
                           salta: int | None) -> tuple[dict[str, str], dict[str, int]]:
    if salta is not None and 0 <= salta < len(righe):
        righe = [*righe[:salta], "", *righe[salta + 1:]]
    testo = "\n".join(righe)
    trovate_f, trovate_v = _dichiarazioni_testo(testo, regole)
    funzioni: dict[str, str] = {}
    for _, nome, firma in sorted(trovate_f):
        funzioni.setdefault(nome, firma)
    variabili: dict[str, int] = {}
    numero, ultima = 1, 0
    for posizione, nome in sorted(trovate_v):
        numero += testo.count("\n", ultima, posizione)     # righe contate a pezzi, senza ripassare
        ultima = posizione
        if nome not in variabili and nome not in funzioni:
            variabili[nome] = numero
    return funzioni, variabili


# --- controlli della maschera -------------------------------------------------------------

def _controlli_da(maschera) -> dict[str, str | None]:
    """nome -> tipo da una ``ModelloMaschera``, un dizionario o un elenco (di nomi o di controlli)."""
    if maschera is None:
        return {}
    if hasattr(maschera, "tutti") and callable(maschera.tutti):
        return {c.nome: getattr(c, "tipo", None) for c in maschera.tutti()}
    if isinstance(maschera, Mapping):
        return {str(k): (v if isinstance(v, str) else getattr(v, "tipo", None)) for k, v in maschera.items()}
    risultato: dict[str, str | None] = {}
    for voce in maschera:
        if isinstance(voce, str):
            risultato[voce] = None
        elif hasattr(voce, "nome"):
            risultato[voce.nome] = getattr(voce, "tipo", None)
    return risultato


def _tipo_dal_nome(nome: str, catalogo: Mapping) -> str | None:
    if catalogo is _catalogo():
        return tipo_da_nome(nome)
    migliore: tuple[int, str] | None = None
    for tipo in catalogo.values():
        for prefisso in {tipo.nome, getattr(tipo, "prefisso_nome", "") or ""}:
            if prefisso and nome.startswith(prefisso) and (migliore is None or len(prefisso) > migliore[0]):
                migliore = (len(prefisso), tipo.nome)
    return migliore[1] if migliore else None


def _tipo_controllo(nome: str, controlli: dict, catalogo: Mapping) -> str | None:
    """Tipo del controllo ``nome``: dalla maschera, oppure dedotto dal nome
    (``PulsanteCalcola`` -> ``Pulsante``) se comincia con la maiuscola."""
    if nome in controlli:
        return controlli[nome] or _tipo_dal_nome(nome, catalogo)
    if nome[:1].isupper():
        return _tipo_dal_nome(nome, catalogo)
    return None


# --- frammenti ------------------------------------------------------------------------------

def frammenti_disponibili(*, stile=None, controlli: Mapping[str, str | None] | None = None,
                          catalogo: Mapping | None = None) -> list[tuple[str, str, str]]:
    """(nome, descrizione, modello) dei frammenti, adattati allo stile del progetto.

    Nei modelli ``\\t`` e' un livello di rientro, ``${n:testo}`` un segnaposto
    (Tab passa al successivo, stesso numero = stesso testo) e ``$0`` il punto
    dove finisce il cursore (vedi :func:`espandi`).
    """
    catalogo = catalogo if catalogo is not None else _catalogo()
    controllo, evento = "Controllo", "evento"
    if controlli:
        nomi = sorted(controlli, key=lambda n: (0 if (_tipo_controllo(n, dict(controlli), catalogo) or "")
                                               .startswith("Pulsante")
                                               else 2 if _tipo_controllo(n, dict(controlli), catalogo) == "Finestra"
                                               else 1))
        controllo = nomi[0]
        info = catalogo.get(_tipo_controllo(controllo, dict(controlli), catalogo) or "")
        evento = "clic"
        if info is not None:
            evento = info.evento_predefinito or (info.eventi[0] if info.eventi else "clic")
    if _valore_stile(stile, "eventi", "quando") == "al":
        quando = f"al ${{2:{evento}}} di ${{1:{controllo}}} fai\n\t$0\nfine"
    else:
        quando = f"quando ${{1:{controllo}}}.${{2:{evento}}} fai\n\t$0\nfine"
    parola_funzione = _valore_stile(stile, "funzioni", "funzione")
    if _valore_stile(stile, "parametri", "parentesi") == "con":
        funzione = f"{parola_funzione} ${{1:nome}} con ${{2:parametro}}\n\t$0\nfine"
    else:
        funzione = f"{parola_funzione} ${{1:nome}}(${{2}})\n\t$0\nfine"
    assegna = "vale" if _valore_stile(stile, "predefiniti", "=") == "vale" else "="
    parola_variabile = _valore_stile(stile, "variabili", "variabile")
    variabile = (f"${{1:nome}} {assegna} ${{2:0}}$0" if parola_variabile == "implicita"
                 else f"{parola_variabile} ${{1:nome}} {assegna} ${{2:0}}$0")
    nome_variabile = "variabile" if parola_variabile == "implicita" else parola_variabile
    return [
        ("al" if quando.startswith("al ") else "quando", "Evento di un controllo", quando),
        ("se", "Condizione", "se ${1:condizione} allora\n\t$0\nfine"),
        ("se altrimenti", "Condizione con altrimenti", "se ${1:condizione} allora\n\t$0\naltrimenti\n\t\nfine"),
        ("mentre", "Ciclo con condizione", "mentre ${1:condizione} fai\n\t$0\nfine"),
        ("per ogni", "Ciclo sugli elementi", "per ogni ${1:elemento} in ${2:lista} fai\n\t$0\nfine"),
        ("ripeti", "Ciclo a conteggio", "ripeti ${1:3} volte\n\t$0\nfine"),
        (parola_funzione, "Nuova funzione", funzione),
        ("prova", "Gestione degli errori (prova/cattura)",
         "prova\n\t$0\ncattura come ${1:errore}\n\tstampa(${1:errore}.messaggio)\nfine"),
        ("scegli", "Scelta tra più casi (scegli/caso)",
         "scegli ${1:valore}\n\tcaso ${2:1} allora\n\t\t$0\n\taltrimenti\n\t\t\nfine"),
        (nome_variabile, "Nuova variabile", variabile),
    ]


def _da_modello(testo: str, tipo: str, dettaglio: str, descrizione: str, modello: str,
                rientro_base: str, inizio: int, fine: int) -> Suggerimento:
    e = espandi(modello, rientro_base)
    primo = e.campi[0] if e.campi else (e.cursore, 0)
    return Suggerimento(testo, tipo, dettaglio, descrizione, e.testo, primo[0], primo[1],
                        e.campi, e.cursore, inizio, fine, collegati=e.collegati)


# --- candidati fissi (preparati una volta) ------------------------------------------------

#: Parole chiave che hanno senso solo all'inizio di un'istruzione.
_SOLO_INIZIO = frozenset({
    "variabile", "costante", "crea variabile", "crea costante", "se", "altrimenti", "altrimenti se",
    "fine", "mentre", "per ogni", "ripeti", "interrompi", "continua", "funzione", "restituisci",
    "quando", "prova", "cattura", "infine", "lancia", "scegli", "caso", "importa", "verifica",
})

#: Parole chiave che sono valori (proposte come i nomi nelle espressioni).
_VALORI = frozenset({"vero", "falso", "nulla", "non"})

#: Parola che chiude l'intestazione di ogni blocco (``se ... allora``).
_CHIUSURA_INTESTAZIONE = {"se": "allora", "altrimenti se": "allora", "caso": "allora", "mentre": "fai",
                          "quando": "fai", "per ogni": "fai", "ripeti": "volte"}


def _funzioni_libreria_voci() -> list[tuple[str, str, str, str, int]]:
    """(nome, firma, descrizione, testo da inserire, cursore) di funzioni, costanti ed errori."""
    if "voci_libreria" not in _CACHE:
        voci = []
        for nome, (firma, descrizione) in funzioni_libreria().items():
            voci.append((nome, firma, descrizione, *_chiamata(nome, firma)))
        for nome, (tipo, descrizione) in _costanti_ed_errori().items():
            firma = nome if tipo == "costante" else f"{nome}(messaggio)"
            voci.append((nome, firma, descrizione, *_chiamata(nome, firma)))
        _CACHE["voci_libreria"] = voci
    return _CACHE["voci_libreria"]  # type: ignore[return-value]


def _chiamata(nome: str, firma: str) -> tuple[str, int]:
    """(testo da inserire, cursore): ``nome()`` col cursore tra le parentesi se servono argomenti."""
    dentro = firma[firma.find("(") + 1:firma.rfind(")")] if "(" in firma else None
    if dentro is None:
        return nome, len(nome)
    testo = nome + "()"
    return testo, (len(nome) + 1 if dentro.strip() else len(testo))


# --- analisi della riga ---------------------------------------------------------------------

def _prima_parola_canonica(parole: list[str], sinonimi) -> tuple[str, int]:
    """(forma canonica della prima parola chiave della riga, quante parole occupa)."""
    for n in (4, 3, 2, 1):
        if len(parole) < n:
            continue
        gruppo = parole[:n]
        testo = " ".join(gruppo)
        if testo in ("per ogni", "altrimenti se", "non è"):
            return testo, n
        if sinonimi is not None:
            try:
                tipo = sinonimi.tipo_di(tuple(gruppo))
            except Exception:
                tipo = None
            if tipo is not None:
                return tipo.value, n
    return (parole[0], 1) if parole else ("", 0)


def _attesa_nella_riga(davanti: str, sinonimi) -> str | None:
    """Parola che probabilmente serve adesso (``allora`` dopo ``se x > 3``, ``fai``
    dopo ``mentre ...``, ``in``/``fai`` in ``per ogni``, ``volte`` in ``ripeti``)."""
    parole = re.findall(r"[^\W\d]\w*|\S", davanti, re.UNICODE)
    if len(parole) < 2:
        return None
    canonica, n = _prima_parola_canonica(parole, sinonimi)
    chiusura = _CHIUSURA_INTESTAZIONE.get(canonica)
    if chiusura is None:
        return None
    resto = parole[n:]
    if not resto:
        return None
    if canonica == "per ogni":
        if "in" not in resto:
            return "in" if len(resto) >= 1 else None
        return None if "fai" in resto or resto[-1] == "in" else "fai"
    if chiusura in resto:
        return None
    if canonica == "quando" and "." in resto and resto[-1] == ".":
        return None
    return chiusura


# --- ingresso principale ------------------------------------------------------------------

_RE_PAROLA_DOPO = re.compile(r"\w*", re.UNICODE)
_RE_AL = re.compile(rf"^[ \t]*al[ \t]+({_NOME})?$", re.UNICODE)
_RE_AL_DI = re.compile(rf"^[ \t]*al[ \t]+({_NOME})[ \t]+di[ \t]+({_NOME})?$", re.UNICODE)


def suggerimenti(codice: str, riga: int, colonna: int, *, maschera=None, catalogo=None,
                 stile=None, sinonimi=None, limite: int = 100) -> list[Suggerimento]:
    """Suggerimenti per il cursore alla ``riga`` e ``colonna`` di ``codice``.

    Posizioni **da 1**, come nei messaggi di Leo (la colonna 1 e' prima del
    primo carattere; colonna = lunghezza della riga + 1 e' la fine). Valori
    fuori misura sono riportati nel testo.

    * ``maschera``: la finestra progettata (``ModelloMaschera``), oppure un
      dizionario ``nome -> tipo`` o un elenco di nomi: i controlli proposti;
    * ``catalogo``: ``nome del tipo -> TipoControllo`` (predefinito: quello di
      :mod:`leo.grafica.metadati`);
    * ``stile``: :class:`leo.stile.Stile` o sezione ``[stile]`` (predefinito:
      l'intestazione ``#stile:`` del file); ``sinonimi``: oggetto ``Sinonimi``,
      ``None`` = quelli di serie, ``False`` = nessuno (modo rigoroso).

    Contesti: inizio istruzione (frammenti, parole chiave e nomi), dopo
    ``Controllo.`` (proprieta' e metodi), dopo ``quando Controllo.`` (eventi),
    dopo ``quando`` (controlli), nel mezzo di un'espressione (variabili,
    funzioni del file e della libreria con la firma, la parola attesa come
    ``allora``/``fai``). Dentro testi e commenti non si propone nulla.
    Le voci sono ordinate per pertinenza (vedi :func:`ordina_suggerimenti`).
    """
    righe = codice.split("\n")
    indice = min(max(riga, 1), len(righe)) - 1
    testo_riga = righe[indice].rstrip("\r")
    col = min(max(colonna, 1), len(testo_riga) + 1) - 1
    prima, dopo = testo_riga[:col], testo_riga[col:]
    contesto = analizza_contesto(prima)
    if contesto.protetto:
        return []
    catalogo = catalogo if catalogo is not None else _catalogo()
    stile_usato = _stile_per(codice, stile)
    sinonimi_usati = _sinonimi_per(sinonimi)
    controlli = _controlli_da(maschera)
    prefisso = contesto.prefisso
    inizio = col - len(prefisso) + 1
    fine = col + len(_RE_PAROLA_DOPO.match(dopo).group(0)) + 1
    voci: list[tuple] = []

    def aggiungi(testo, tipo, dettaglio="", descrizione="", rango=50.0, inserire="", cursore=-1):
        voci.append((testo, tipo, rango,
                     (testo, tipo, dettaglio, descrizione, inserire or testo, cursore, 0, (), -1, inizio, fine)))

    resto_riga = dopo[fine - 1 - col:]

    def blocco_evento(testa: str) -> tuple[str, int]:
        """``testa`` (``clic fai``) con il corpo rientrato e ``fine`` se il blocco non e' gia'
        chiuso nel file: (testo da inserire, cursore sulla riga del corpo)."""
        riga_intera = prima[:len(prima) - len(prefisso)] + testa
        try:
            chiusura = righe_da_aprire(riga_intera, righe_precedenti=righe[:indice],
                                       righe_successive=righe[indice + 1:], sinonimi=sinonimi_usati,
                                       stile=stile_usato)
        except Exception:  # noqa: BLE001 - il completamento non deve mai fallire
            chiusura = []
        if not chiusura:
            return testa, len(testa)
        corpo = rientro_di(testo_riga) + RIENTRO
        return f"{testa}\n{corpo}\n{chiusura[0]}", len(testa) + 1 + len(corpo)
    # --- dopo il punto: proprieta', metodi o eventi -------------------------------------
    if contesto.oggetto is not None:
        nome = contesto.oggetto
        tipo = _tipo_controllo(nome, controlli, catalogo) if nome else None
        info = catalogo.get(tipo) if tipo else None
        if info is not None:
            if contesto.evento:
                aggiungi_fai = not resto_riga.strip()
                for e in info.eventi:
                    descrizione = ("Evento predefinito di " if e == info.evento_predefinito else "Evento di ") + info.nome
                    testo, cursore = blocco_evento(e + " fai") if aggiungi_fai else (e, -1)
                    aggiungi(e, "evento", f"quando {nome}.{e} fai", descrizione,
                             0 if e == info.evento_predefinito else 1, testo, cursore)
                return _ordina(voci, prefisso, limite)
            for p in info.proprieta.values():
                if p.nome == "nome" or getattr(p, "solo_progettazione", False):
                    continue
                dettaglio = f"{p.nome}: {p.tipo}" + ("  (sola lettura)" if getattr(p, "sola_lettura", False) else "")
                aggiungi(p.nome, "proprieta", dettaglio, p.descrizione or f"Proprietà di {info.nome}.", 0)
            for m, funzione in info.metodi.items():
                firma = _firma_metodo_controllo(m, funzione)
                testo, cursore = _chiamata(m, firma)
                aggiungi(m, "funzione", firma, _descrizione_metodo_controllo(funzione) or f"Metodo di {info.nome}.",
                         1, testo, cursore)
            return _ordina(voci, prefisso, limite)
        if contesto.evento:
            return []
        for m, (firma, descrizione, tipi) in metodi_valori().items():
            testo, cursore = _chiamata(m, firma)
            aggiungi(m, "funzione", firma, descrizione + (f"  [{tipi}]" if tipi else ""), 1, testo, cursore)
        return _ordina(voci, prefisso, limite)

    # --- dopo quando / al ... di: i controlli --------------------------------------------
    if _valore_stile(stile_usato, "eventi", "quando") == "al":
        m_al_di = _RE_AL_DI.match(prima)
        if m_al_di:
            evento = m_al_di.group(1)
            for n in controlli:
                info = catalogo.get(_tipo_controllo(n, controlli, catalogo) or "")
                if info is None or evento in info.eventi:
                    testo, cursore = blocco_evento(n + " fai") if not resto_riga.strip() else (n, -1)
                    aggiungi(n, "controllo", info.nome if info else "controllo",
                             f"Controllo con l'evento `{evento}`.", 0, testo, cursore)
            return _ordina(voci, prefisso, limite)
        if _RE_AL.match(prima):
            eventi: dict[str, set[str]] = {}
            for n in controlli:
                info = catalogo.get(_tipo_controllo(n, controlli, catalogo) or "")
                for e in (info.eventi if info is not None else ()):
                    eventi.setdefault(e, set()).add(n)
            for e, nomi in eventi.items():
                aggiungi(e, "evento", f"al {e} di ...", "Evento di " + ", ".join(sorted(nomi)) + ".", 0,
                         e + " di " if not resto_riga.strip() else e)
            return _ordina(voci, prefisso, limite)
    if contesto.dopo_quando:
        for n in controlli:
            tipo = _tipo_controllo(n, controlli, catalogo)
            aggiungi(n, "controllo", tipo or "controllo", "Scegli il controllo: poi il punto e l'evento.",
                     0, n + ".")
        return _ordina(voci, prefisso, limite)

    # --- parole chiave e frammenti ---------------------------------------------------------
    davanti = prima[:len(prima) - len(prefisso)]
    inizio_istruzione = contesto.inizio_istruzione
    attesa = None if inizio_istruzione else _attesa_nella_riga(davanti, sinonimi_usati)
    usati = set()
    if inizio_istruzione:
        rientro = rientro_di(testo_riga)
        solo_spazi_dopo = not resto_riga.strip()
        if solo_spazi_dopo:
            for numero, (nome, descrizione, modello) in enumerate(
                    frammenti_disponibili(stile=stile_usato, controlli=controlli, catalogo=catalogo)):
                voce = _da_modello(nome, "frammento", descrizione,
                                   "Inserisce il blocco completo: Tab passa al campo successivo.",
                                   modello, rientro, inizio, fine)
                # a prefisso vuoto restano nell'ordine della tabella (i piu' usati prima)
                voci.append((nome, "frammento", numero / 100 if not prefisso else 0, voce))
                usati.add(nome)
        for parola, descrizione in PAROLE_CHIAVE.items():
            if parola in usati:
                continue
            aggiungi(parola, "parola_chiave", parola, descrizione, 1 if parola in _SOLO_INIZIO else 6)
        # sinonimi: solo se chi scrive li sta usando (il prefisso li indica)
        if prefisso and sinonimi_usati is not None:
            for canonica in _SOLO_INIZIO | {"allora", "fai", "e", "o", "vero", "falso", "nulla"}:
                for s in _sinonimi_di(sinonimi_usati, canonica):
                    if punteggio_ricerca(s, prefisso) in ((0, 0), (0, 1)):
                        aggiungi(s, "parola_chiave", f"{s}  (= {canonica})", f"Sinonimo di `{canonica}`.",
                                 2 if canonica in _SOLO_INIZIO else 7)
        # parole dello stile del progetto (sia, fissa, procedura...)
        for campo in ("variabili", "costanti", "funzioni"):
            valore = _valore_stile(stile_usato, campo, "")
            if valore and valore != "implicita" and valore not in PAROLE_CHIAVE:
                aggiungi(valore, "parola_chiave", valore, f"Parola scelta nello stile del progetto ({campo}).", 1)
    else:
        for parola, descrizione in PAROLE_CHIAVE.items():
            if parola in _SOLO_INIZIO:
                continue
            rango = 0 if parola == attesa else 3 if parola in _VALORI else 8
            aggiungi(parola, "parola_chiave", parola, descrizione, rango)

    # --- nomi: variabili, funzioni, controlli, libreria ------------------------------------
    rango_nomi = 3 if inizio_istruzione else 1
    funzioni, variabili = dichiarazioni(righe, stile=stile_usato, sinonimi=sinonimi, salta=indice)
    # la riga del cursore: vale tutto tranne il nome che si sta scrivendo adesso
    parola_corrente = prefisso + _RE_PAROLA_DOPO.match(dopo).group(0)
    f_riga, v_riga = _dichiarazioni_riga(testo_riga, _regole(stile_usato, sinonimi_usati))
    for nome, firma in f_riga:
        if nome != parola_corrente:
            funzioni.setdefault(nome, firma)
    for nome in v_riga:
        if nome != parola_corrente and nome not in funzioni:
            variabili.setdefault(nome, indice + 1)
    for nome, riga_dichiarazione in variabili.items():
        if nome in controlli:
            continue
        aggiungi(nome, "variabile", nome, f"Variabile del tuo programma (riga {riga_dichiarazione}).", rango_nomi)
    for nome, firma in funzioni.items():
        testo, cursore = _chiamata(nome, firma)
        aggiungi(nome, "funzione", firma, "Funzione definita nel tuo programma.", rango_nomi, testo, cursore)
    for nome in controlli:
        tipo = _tipo_controllo(nome, controlli, catalogo)
        info = catalogo.get(tipo or "")
        aggiungi(nome, "controllo", tipo or "controllo",
                 (info.descrizione if info is not None else "") or "Controllo della finestra.", rango_nomi + 1)
    for nome, firma, descrizione, testo, cursore in _funzioni_libreria_voci():
        if nome in funzioni:
            continue
        aggiungi(nome, "funzione" if "(" in firma else "variabile", firma, descrizione, rango_nomi + 2,
                 testo, cursore)
    return _ordina(voci, prefisso, limite)


# ===========================================================================
# Invio, rientro e commenti (API semplice per l'editor)
# ===========================================================================

def _sinonimi_lexer(sinonimi):
    """Sinonimi per il lexer: ``False`` diventa "nessun sinonimo" (modo rigoroso)."""
    if sinonimi is False:
        try:
            from .sinonimi import Sinonimi

            return Sinonimi.vuoti()
        except Exception:
            return None
    return sinonimi


def righe_da_aprire(riga: str, *, righe_successive: Iterable[str] | None = None,
                    righe_precedenti: Iterable[str] | None = None, sinonimi=None, stile=None) -> list[str]:
    """Righe da aggiungere SOTTO la nuova riga quando si preme Invio alla fine di ``riga``.

    Se ``riga`` apre un blocco (``se ... allora``, ``mentre ... fai``,
    ``funzione f()``, ``quando P.clic fai``, anche con i sinonimi come
    ``qualora ... allora`` o con lo stile ``al clic di P fai``) restituisce
    ``[<rientro della riga> + "fine"]``, altrimenti ``[]``. Il cursore va sulla
    nuova riga, rientrata con :func:`rientro_per_nuova_riga`.

    ``righe_successive``: le righe che seguono nel file; se il blocco risulta
    gia' chiuso (il corpo e' gia' rientrato o c'e' gia' ``fine`` allo stesso
    rientro, oppure i ``fine`` bastano) non si aggiunge nulla.
    ``righe_precedenti``: le righe che vengono prima; servono per i blocchi
    annidati (``quando ... fai`` / ``se ... allora`` / ``fine``: il ``fine`` che
    segue chiude il ``quando``, quindi al ``se`` ne manca uno).
    """
    sin = _sinonimi_lexer(sinonimi)
    if not apre_blocco(riga, sinonimi=sin, stile=stile):
        return []
    if righe_successive is not None or righe_precedenti is not None:
        precedenti = list(righe_precedenti or ())
        tutte = [*precedenti, riga, *(righe_successive or ())]
        if not manca_fine(tutte, len(precedenti), sinonimi=sin, stile=stile):
            return []
    return [rientro_di(riga) + "fine"]


def rientro_per_nuova_riga(testo_precedente: str, *, sinonimi=None, stile=None,
                           rientro: str = RIENTRO) -> str:
    """Rientro della riga creata con Invio dopo ``testo_precedente``: lo stesso
    della riga, piu' un livello se la riga apre un blocco o e' ``altrimenti``,
    ``cattura``, ``infine``, ``caso ... allora``."""
    base = rientro_di(testo_precedente)
    if not testo_precedente.strip():
        return base
    if rientro_dopo(testo_precedente, sinonimi=_sinonimi_lexer(sinonimi), stile=stile):
        return base + rientro
    return base


def _commentata(riga: str) -> bool:
    s = riga.lstrip()
    return s.startswith("#") and not s.startswith("#[")


def commenta(righe: list[str]) -> list[str]:
    """Aggiunge ``# `` a ogni riga non vuota, allineato al rientro minimo
    (le righe vuote restano come sono)."""
    piene = [r for r in righe if r.strip()]
    if not piene:
        return list(righe)
    minimo = min(len(rientro_di(r)) for r in piene)
    return [r if not r.strip() else r[:minimo] + "# " + r[minimo:] for r in righe]


def decommenta(righe: list[str]) -> list[str]:
    """Toglie ``#`` (e uno spazio dopo) dalle righe commentate; le altre restano
    come sono. I commenti a blocco ``#[ ... ]#`` non si toccano."""
    risultato = []
    for r in righe:
        if not _commentata(r):
            risultato.append(r)
            continue
        rientro = rientro_di(r)
        resto = r[len(rientro) + 1:]
        if resto.startswith(" "):
            resto = resto[1:]
        risultato.append(rientro + resto)
    return risultato
