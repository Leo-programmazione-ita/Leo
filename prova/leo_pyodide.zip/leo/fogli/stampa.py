"""Stampa in PDF di un foglio (senza programmi esterni): griglia, testi formattati, grassetto,
colori di sfondo, intestazioni ripetute, numeri di pagina. Pagine A4, verticali od orizzontali."""

from __future__ import annotations

import datetime as _dt
import zlib
from typing import Any

from .calcolo import Cartella, Foglio
from .operazioni import testo_mostrato

__all__ = ["esporta_pdf"]

_A4 = (595.28, 841.89)
_LARGHEZZE_HELV = {  # larghezze (1/1000 em) dei caratteri più comuni di Helvetica
    **{ch: 556 for ch in "0123456789"}, " ": 278, ",": 278, ".": 278, "-": 333, "€": 556, "%": 889, "/": 278,
    ":": 278, "(": 333, ")": 333, "'": 191, '"': 355, "!": 278, "?": 556, "+": 584, "=": 584, "_": 556,
    **{ch: 556 for ch in "abcdeghnopqu"}, **{ch: 500 for ch in "ksvxyz"}, "f": 278, "i": 222, "j": 222,
    "l": 222, "m": 833, "r": 333, "t": 278, "w": 722, **{ch: 667 for ch in "ABEKPSVXY"}, "C": 722, "D": 722,
    "F": 611, "G": 778, "H": 722, "I": 278, "J": 500, "L": 556, "M": 833, "N": 722, "O": 778, "Q": 778,
    "R": 722, "T": 611, "U": 722, "W": 944, "Z": 611,
}


def _larghezza(testo: str, dimensione: float, grassetto: bool = False) -> float:
    k = 1.08 if grassetto else 1.0
    return sum(_LARGHEZZE_HELV.get(ch, 556) for ch in testo) * dimensione / 1000 * k


def _pdf_testo(t: str) -> bytes:
    b = t.encode("cp1252", errors="replace")
    return b"(" + b.replace(b"\\", b"\\\\").replace(b"(", b"\\(").replace(b")", b"\\)") + b")"


def _rgb(colore: str | None) -> tuple[float, float, float] | None:
    if not colore or not colore.startswith("#") or len(colore) < 7:
        return None
    return tuple(int(colore[i:i + 2], 16) / 255 for i in (1, 3, 5))  # type: ignore[return-value]


def esporta_pdf(cartella: Cartella, foglio: Foglio, percorso: str, orizzontale: bool | None = None,
                titolo: str | None = None, dimensione: float = 9) -> None:
    mr, mc = foglio.estensione()
    if mr < 0:
        mr, mc = 0, 0
    colonne = [c for c in range(mc + 1) if c not in foglio.colonne_nascoste]
    righe = [r for r in range(mr + 1) if r not in foglio.righe_nascoste and r not in foglio.righe_filtrate]
    scala = 0.75
    larg = {c: foglio.larghezze.get(c, 90) * scala for c in colonne}
    totale = sum(larg.values())
    if orizzontale is None:
        orizzontale = totale > _A4[0] - 60
    pw, ph = (_A4[1], _A4[0]) if orizzontale else _A4
    margine = 30
    disponibile = pw - 2 * margine
    if totale > disponibile:          # adatta alla larghezza della pagina
        f = disponibile / totale
        larg = {c: w * f for c, w in larg.items()}
        dimensione = max(5, dimensione * f)
    altezza_riga = dimensione * 1.8
    righe_pagina = int((ph - 2 * margine - 30) / altezza_riga)
    intestazione = foglio.blocca[0] if foglio.blocca[0] else 0
    ripetute = [r for r in righe if r < intestazione]
    corpo = [r for r in righe if r >= intestazione]
    pagine: list[list[int]] = []
    passo = max(1, righe_pagina - len(ripetute))
    for i in range(0, max(1, len(corpo)), passo):
        pagine.append(ripetute + corpo[i:i + passo])
    titolo = titolo if titolo is not None else (cartella.proprieta.get("titolo") or foglio.nome)
    flussi = []
    for n, pagina in enumerate(pagine, 1):
        out = []
        y = ph - margine
        out.append(b"BT /F2 11 Tf %.2f %.2f Td %s Tj ET" % (margine, y - 11, _pdf_testo(str(titolo))))
        piede = f"Pagina {n} di {len(pagine)} - Leo Fogli - {_dt.date.today().strftime('%d/%m/%Y')}"
        out.append(b"0.4 g BT /F1 7 Tf %.2f %.2f Td %s Tj ET 0 g" % (margine, margine - 12, _pdf_testo(piede)))
        y -= 26
        for r in pagina:
            x = margine
            for c in colonne:
                w = larg[c]
                stile = cartella.stile(foglio, r, c)
                fondo = _rgb(stile.get("colore_sfondo"))
                if fondo:
                    out.append(b"%.3f %.3f %.3f rg %.2f %.2f %.2f %.2f re f 0 g" % (*fondo, x, y - altezza_riga, w, altezza_riga))
                if foglio.mostra_griglia:
                    out.append(b"0.82 G 0.3 w %.2f %.2f %.2f %.2f re S 0 G" % (x, y - altezza_riga, w, altezza_riga))
                for chiave, (x1, y1, x2, y2) in (("bordo_sopra", (x, y, x + w, y)),
                                                  ("bordo_sotto", (x, y - altezza_riga, x + w, y - altezza_riga)),
                                                  ("bordo_sinistra", (x, y, x, y - altezza_riga)),
                                                  ("bordo_destra", (x + w, y, x + w, y - altezza_riga))):
                    if stile.get(chiave):
                        spessore = 1.2 if stile[chiave] in ("spesso", "medio", "doppio") else 0.6
                        out.append(b"%.2f w %.2f %.2f m %.2f %.2f l S" % (spessore, x1, y1, x2, y2))
                testo, colore, naturale = testo_mostrato(cartella, foglio, r, c)
                if testo:
                    grassetto = bool(stile.get("grassetto"))
                    font = b"/F2" if grassetto else b"/F1"
                    allinea = stile.get("allineamento") or naturale
                    while testo and _larghezza(testo, dimensione, grassetto) > w - 4:
                        testo = testo[:-1]
                    tw = _larghezza(testo, dimensione, grassetto)
                    tx = x + 2 if allinea == "sinistra" else (x + w - tw - 2 if allinea == "destra" else x + (w - tw) / 2)
                    col = _rgb(colore or stile.get("colore_testo"))
                    if col:
                        out.append(b"%.3f %.3f %.3f rg" % col)
                    out.append(b"BT %s %.2f Tf %.2f %.2f Td %s Tj ET" % (font, dimensione, tx, y - altezza_riga + dimensione * 0.55,
                                                                          _pdf_testo(testo)))
                    if col:
                        out.append(b"0 g")
                x += w
            y -= altezza_riga
        flussi.append(zlib.compress(b"\n".join(out)))
    # file PDF
    oggetti: list[bytes] = []

    def aggiungi(b: bytes) -> int:
        oggetti.append(b)
        return len(oggetti)

    catalogo = aggiungi(b"")
    radice_pagine = aggiungi(b"")
    f1 = aggiungi(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>")
    f2 = aggiungi(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>")
    figli = []
    for flusso in flussi:
        contenuto = aggiungi(b"<< /Length %d /Filter /FlateDecode >>\nstream\n" % len(flusso) + flusso + b"\nendstream")
        figli.append(aggiungi(b"<< /Type /Page /Parent %d 0 R /MediaBox [0 0 %.2f %.2f] /Contents %d 0 R "
                              b"/Resources << /Font << /F1 %d 0 R /F2 %d 0 R >> >> >>" % (radice_pagine, pw, ph, contenuto, f1, f2)))
    oggetti[catalogo - 1] = b"<< /Type /Catalog /Pages %d 0 R >>" % radice_pagine
    oggetti[radice_pagine - 1] = b"<< /Type /Pages /Kids [%s] /Count %d >>" % (
        b" ".join(b"%d 0 R" % k for k in figli), len(figli))
    dati = bytearray(b"%PDF-1.4\n%\xe2\xe3\xcf\xd3\n")
    posizioni = []
    for i, o in enumerate(oggetti, 1):
        posizioni.append(len(dati))
        dati += b"%d 0 obj\n" % i + o + b"\nendobj\n"
    xref = len(dati)
    dati += b"xref\n0 %d\n0000000000 65535 f \n" % (len(oggetti) + 1)
    for p in posizioni:
        dati += b"%010d 00000 n \n" % p
    dati += b"trailer\n<< /Size %d /Root %d 0 R >>\nstartxref\n%d\n%%%%EOF\n" % (len(oggetti) + 1, catalogo, xref)
    with open(percorso, "wb") as f:
        f.write(bytes(dati))
