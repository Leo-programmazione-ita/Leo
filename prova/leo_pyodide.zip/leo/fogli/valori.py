"""Valori delle celle di Leo Fogli: numeri, testi, logici, vuoto, errori e date.

Le date sono numeri seriali come in Excel (1 = 01/01/1900, con il famoso 29/02/1900
che non esiste, per restare compatibili con i file .xlsx); l'ora è la parte decimale.
I testi scritti dall'utente si leggono all'italiana: virgola decimale, punto delle
migliaia, date GG/MM/AAAA, "VERO"/"FALSO", "20%", "€ 1.234,50".
"""

from __future__ import annotations

import datetime as _dt
import math
import re
from typing import Any

__all__ = [
    "Errore", "ErroreFormula", "Matrice", "CODICI_ERRORE", "SPIEGAZIONI_ERRORI",
    "DIV0", "VALORE", "RIF", "NOME", "NUM", "ND", "NULLO", "CICLO", "SINTASSI", "ESPANSIONE", "CALC",
    "e_numero", "a_numero", "a_testo", "a_logico", "testo_generale", "leggi_inserimento",
    "data_in_seriale", "seriale_in_data", "seriale_in_datetime", "ora_in_seriale", "confronta",
    "uguali", "errore_da_eccezione",
]

# ---------------------------------------------------------------------------
# Errori
# ---------------------------------------------------------------------------

DIV0 = "#DIV/0!"
VALORE = "#VALORE!"
RIF = "#RIF!"
NOME = "#NOME?"
NUM = "#NUM!"
ND = "#N/D"
NULLO = "#NULLO!"
CICLO = "#CICLO!"
SINTASSI = "#ERRORE!"
ESPANSIONE = "#ESPANSIONE!"
CALC = "#CALC!"

CODICI_ERRORE = (DIV0, VALORE, RIF, NOME, NUM, ND, NULLO, CICLO, SINTASSI, ESPANSIONE, CALC)

#: Codici inglesi (file .xlsx) <-> italiani
ERRORI_INGLESI = {
    "#DIV/0!": DIV0, "#VALUE!": VALORE, "#REF!": RIF, "#NAME?": NOME, "#NUM!": NUM, "#N/A": ND,
    "#NULL!": NULLO, "#SPILL!": ESPANSIONE, "#CALC!": CALC,
}
ERRORI_IN_INGLESE = {v: k for k, v in ERRORI_INGLESI.items()}
ERRORI_IN_INGLESE[CICLO] = "#REF!"
ERRORI_IN_INGLESE[SINTASSI] = "#NAME?"

SPIEGAZIONI_ERRORI = {
    DIV0: "divisione per zero (o media di nessun numero)",
    VALORE: "un valore del tipo sbagliato: per esempio un testo dove serve un numero",
    RIF: "un riferimento a una cella che non esiste (o che è stata eliminata)",
    NOME: "un nome che Leo Fogli non conosce: controlla il nome della funzione",
    NUM: "un calcolo impossibile, per esempio la radice di un numero negativo",
    ND: "valore non disponibile: la ricerca non ha trovato niente",
    NULLO: "due intervalli che non si incrociano",
    CICLO: "riferimento circolare: la formula dipende da se stessa",
    SINTASSI: "la formula è scritta male: controlla parentesi, virgolette e punti e virgola",
    ESPANSIONE: "il risultato non entra: le celle dove dovrebbe espandersi non sono vuote",
    CALC: "il calcolo non ha prodotto risultati (per esempio FILTRO senza righe)",
}


class Errore:
    """Valore di errore dentro una cella (#DIV/0!, #VALORE!...)."""

    __slots__ = ("codice",)

    def __init__(self, codice: str) -> None:
        self.codice = codice

    def __eq__(self, altro: object) -> bool:
        return isinstance(altro, Errore) and altro.codice == self.codice

    def __hash__(self) -> int:
        return hash(("Errore", self.codice))

    def __repr__(self) -> str:
        return f"Errore({self.codice!r})"

    def __str__(self) -> str:
        return self.codice


class ErroreFormula(Exception):
    """Lanciata durante il calcolo: diventa il valore di errore della cella."""

    def __init__(self, codice: str, messaggio: str = "") -> None:
        super().__init__(messaggio or codice)
        self.codice = codice


class Matrice:
    """Risultato a più celle (matrice dinamica): righe di valori."""

    __slots__ = ("righe",)

    def __init__(self, righe: list[list[Any]]) -> None:
        if not righe or not righe[0]:
            raise ErroreFormula(CALC)
        self.righe = righe

    @property
    def altezza(self) -> int:
        return len(self.righe)

    @property
    def larghezza(self) -> int:
        return len(self.righe[0])

    def valore(self, r: int, c: int) -> Any:
        return self.righe[r][c]

    def __repr__(self) -> str:
        return f"Matrice({self.righe!r})"


def errore_da_eccezione(e: BaseException) -> Errore:
    if isinstance(e, ErroreFormula):
        return Errore(e.codice)
    if isinstance(e, ZeroDivisionError):
        return Errore(DIV0)
    if isinstance(e, (OverflowError, ValueError, ArithmeticError)):
        return Errore(NUM)
    if isinstance(e, RecursionError):
        return Errore(CICLO)
    return Errore(VALORE)


# ---------------------------------------------------------------------------
# Date (numeri seriali di Excel, sistema 1900)
# ---------------------------------------------------------------------------

_BASE = _dt.date(1899, 12, 30)
_BASE_DT = _dt.datetime(1899, 12, 30)


def data_in_seriale(d: _dt.date | _dt.datetime) -> float:
    if isinstance(d, _dt.datetime):
        delta = d - _BASE_DT
        s = delta.days + delta.seconds / 86400 + delta.microseconds / 86400e6
        giorno = delta.days
    else:
        giorno = (d - _BASE).days
        s = giorno
    if giorno < 61:            # prima del finto 29/02/1900
        s -= 1
    return s


def seriale_in_datetime(s: float) -> _dt.datetime:
    if s < 0 or s > 2958465.99999:
        raise ErroreFormula(NUM)
    giorni = math.floor(s)
    frazione = s - giorni
    if giorni < 61:
        giorni += 1
        if giorni == 61:        # il 29/02/1900 "di Excel": lo mostriamo come 28/02
            giorni = 60
    secondi = round(frazione * 86400)
    if secondi >= 86400:
        giorni += 1
        secondi -= 86400
    return _BASE_DT + _dt.timedelta(days=giorni, seconds=secondi)


def seriale_in_data(s: float) -> _dt.date:
    return seriale_in_datetime(s).date()


def ora_in_seriale(ore: float, minuti: float = 0, secondi: float = 0) -> float:
    return (ore * 3600 + minuti * 60 + secondi) / 86400


# ---------------------------------------------------------------------------
# Conversioni
# ---------------------------------------------------------------------------

def e_numero(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


_RE_MIGLIAIA_IT = re.compile(r"^[+-]?\d{1,3}(\.\d{3})+(,\d+)?$")
_RE_DECIMALE_IT = re.compile(r"^[+-]?(\d+(,\d*)?|,\d+)$")
_RE_DECIMALE_EN = re.compile(r"^[+-]?(\d+\.\d*|\.\d+)$")
_RE_MIGLIAIA_EN = re.compile(r"^[+-]?\d{1,3}(,\d{3})+(\.\d+)?$")
_RE_ESPONENTE = re.compile(r"^[+-]?(\d+([.,]\d*)?|[.,]\d+)[eE][+-]?\d+$")
_RE_DATA = re.compile(r"^(\d{1,2})[/.\-](\d{1,2})[/.\-](\d{2}|\d{4})$")
_RE_DATA_ISO = re.compile(r"^(\d{4})-(\d{1,2})-(\d{1,2})$")
_RE_ORA = re.compile(r"^(\d{1,2}):(\d{2})(?::(\d{2}))?$")
_VALUTE = ("€", "EUR", "$", "£")


def _numero_semplice(t: str) -> float | int | None:
    t = t.strip().replace(" ", "").replace(" ", "")
    if not t:
        return None
    if _RE_DECIMALE_IT.match(t):
        if "," in t:
            return float(t.replace(",", "."))
        return int(t)
    if _RE_MIGLIAIA_IT.match(t):
        return _intero_se_puoi(float(t.replace(".", "").replace(",", ".")))
    if _RE_DECIMALE_EN.match(t):
        return float(t)
    if _RE_ESPONENTE.match(t):
        return float(t.replace(",", "."))
    return None


def _intero_se_puoi(x: float) -> float | int:
    if isinstance(x, float) and x.is_integer() and abs(x) < 1e15:
        return int(x)
    return x


def _data_da_testo(t: str) -> float | None:
    m = _RE_DATA.match(t)
    if m:
        g, me, a = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if a < 100:
            a += 2000 if a < 30 else 1900
        try:
            return data_in_seriale(_dt.date(a, me, g))
        except ValueError:
            return None
    m = _RE_DATA_ISO.match(t)
    if m:
        try:
            return data_in_seriale(_dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3))))
        except ValueError:
            return None
    return None


def _ora_da_testo(t: str) -> float | None:
    m = _RE_ORA.match(t)
    if not m:
        return None
    h, mi, s = int(m.group(1)), int(m.group(2)), int(m.group(3) or 0)
    if mi > 59 or s > 59:
        return None
    return ora_in_seriale(h, mi, s)


def leggi_inserimento(testo: str) -> tuple[Any, str | None]:
    """Quello che l'utente scrive in una cella (non formula) -> (valore, formato suggerito).

    >>> leggi_inserimento("1.234,5")
    (1234.5, None)
    """
    if testo is None:
        return None, None
    t = str(testo)
    if t == "":
        return None, None
    if t.startswith("'"):
        return t[1:], None
    s = t.strip()
    if not s:
        return t, None
    su = s.upper()
    if su in ("VERO", "TRUE"):
        return True, None
    if su in ("FALSO", "FALSE"):
        return False, None
    if su in ERRORI_INGLESI:
        return Errore(ERRORI_INGLESI[su]), None
    if su in CODICI_ERRORE:
        return Errore(su), None
    n = _numero_semplice(s)
    if n is not None:
        return n, None
    # percentuale
    if s.endswith("%"):
        n = _numero_semplice(s[:-1])
        if n is not None:
            return n / 100, "0%" if float(n).is_integer() else "0.00%"
    # valuta
    for v in _VALUTE:
        if s.startswith(v) or s.endswith(v):
            corpo = s[len(v):] if s.startswith(v) else s[: -len(v)]
            n = _numero_semplice(corpo)
            if n is not None:
                return n, "€ #,##0.00" if v in ("€", "EUR") else f"{v} #,##0.00"
    # data e ora
    d = _data_da_testo(s)
    if d is not None:
        return d, "dd/mm/yyyy"
    o = _ora_da_testo(s)
    if o is not None:
        return o, "hh:mm" if s.count(":") == 1 else "hh:mm:ss"
    if " " in s:
        a, _, b = s.partition(" ")
        d = _data_da_testo(a)
        o = _ora_da_testo(b.strip())
        if d is not None and o is not None:
            return d + o, "dd/mm/yyyy hh:mm"
    return t, None


def numero_da_testo(t: str) -> float | int | None:
    """Testo -> numero per i calcoli (anche date, ore, percentuali, valute); None se non è un numero."""
    v, _ = leggi_inserimento(t)
    if e_numero(v):
        return v
    return None


def a_numero(v: Any) -> float | int:
    """Valore -> numero, come Excel nelle operazioni (+ - * /). Testo non numerico: #VALORE!."""
    if v is None:
        return 0
    if isinstance(v, bool):
        return 1 if v else 0
    if isinstance(v, (int, float)):
        return v
    if isinstance(v, Errore):
        raise ErroreFormula(v.codice)
    if isinstance(v, str):
        if v == "":
            return 0
        n = numero_da_testo(v)
        if n is None:
            raise ErroreFormula(VALORE)
        return n
    if isinstance(v, (_dt.date, _dt.datetime)):
        return data_in_seriale(v)
    raise ErroreFormula(VALORE)


def a_logico(v: Any) -> bool:
    if v is None:
        return False
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return v != 0
    if isinstance(v, Errore):
        raise ErroreFormula(v.codice)
    if isinstance(v, str):
        u = v.strip().upper()
        if u in ("VERO", "TRUE"):
            return True
        if u in ("FALSO", "FALSE"):
            return False
    raise ErroreFormula(VALORE)


def testo_generale(x: float | int) -> str:
    """Numero nel formato "Generale" all'italiana (virgola decimale, niente 0,30000000000000004)."""
    if isinstance(x, bool):
        return "VERO" if x else "FALSO"
    if isinstance(x, int):
        return str(x)
    if math.isnan(x) or math.isinf(x):
        return NUM
    if x == 0:
        return "0"
    ax = abs(x)
    if ax >= 1e15 or ax < 1e-9:
        s = f"{x:.6E}"
        mant, esp = s.split("E")
        mant = mant.rstrip("0").rstrip(".")
        return f"{mant}E{esp}".replace(".", ",")
    r = round(x, 10)
    if float(r).is_integer():
        return str(int(r))
    s = f"{r:.15g}"
    if "e" in s:
        s = f"{r:.12f}".rstrip("0").rstrip(".")
    return s.replace(".", ",")


def a_testo(v: Any) -> str:
    if v is None:
        return ""
    if isinstance(v, bool):
        return "VERO" if v else "FALSO"
    if isinstance(v, (int, float)):
        return testo_generale(v)
    if isinstance(v, Errore):
        raise ErroreFormula(v.codice)
    return str(v)


# ---------------------------------------------------------------------------
# Confronti (come Excel: numeri < testi < logici; i testi senza maiuscole)
# ---------------------------------------------------------------------------

def _rango(v: Any) -> int:
    if isinstance(v, bool):
        return 2
    if isinstance(v, (int, float)):
        return 0
    return 1


def confronta(a: Any, b: Any) -> int:
    if isinstance(a, Errore):
        raise ErroreFormula(a.codice)
    if isinstance(b, Errore):
        raise ErroreFormula(b.codice)
    if a is None and b is None:
        return 0
    if a is None:
        a = "" if isinstance(b, str) else (False if isinstance(b, bool) else 0)
    if b is None:
        b = "" if isinstance(a, str) else (False if isinstance(a, bool) else 0)
    ra, rb = _rango(a), _rango(b)
    if ra != rb:
        return -1 if ra < rb else 1
    if ra == 1:
        a, b = a.lower(), b.lower()
    if a < b:
        return -1
    if a > b:
        return 1
    return 0


def uguali(a: Any, b: Any) -> bool:
    try:
        return confronta(a, b) == 0
    except ErroreFormula:
        return False
