"""Formati dei numeri come in Excel ("#,##0.00", "0%", "dd/mm/yyyy", "€ #,##0.00;[Rosso]-€ #,##0.00").

I codici si salvano nella forma di Excel (punto decimale, virgola delle migliaia, d/m/y),
così passano tali e quali nei file .xlsx; il risultato si mostra all'italiana
(1.234,50 - lunedì 5 gennaio 2026). Si accettano anche i codici scritti all'italiana
(gg/mm/aaaa) e quelli della funzione TESTO in italiano ("0,00", "#.##0").
"""

from __future__ import annotations

import math
import re
from typing import Any

from .valori import Errore, seriale_in_datetime, testo_generale

__all__ = ["formatta", "FORMATI_PREDEFINITI", "e_formato_data", "codice_da_italiano", "MESI", "GIORNI"]

MESI = ["gennaio", "febbraio", "marzo", "aprile", "maggio", "giugno", "luglio", "agosto", "settembre",
        "ottobre", "novembre", "dicembre"]
GIORNI = ["lunedì", "martedì", "mercoledì", "giovedì", "venerdì", "sabato", "domenica"]

FORMATI_PREDEFINITI: dict[str, str] = {
    "Generale": "",
    "Numero": "#,##0.00",
    "Intero": "#,##0",
    "Valuta": "€ #,##0.00",
    "Valuta (negativi in rosso)": "€ #,##0.00;[Red]-€ #,##0.00",
    "Contabilità": "€ #,##0.00;-€ #,##0.00;€ -",
    "Percentuale": "0%",
    "Percentuale con decimali": "0.00%",
    "Data": "dd/mm/yyyy",
    "Data breve": "dd/mm/yy",
    "Data estesa": "dddd d mmmm yyyy",
    "Mese e anno": "mmmm yyyy",
    "Ora": "hh:mm",
    "Ora con secondi": "hh:mm:ss",
    "Data e ora": "dd/mm/yyyy hh:mm",
    "Durata (ore)": "[h]:mm",
    "Scientifico": "0.00E+00",
    "Testo": "@",
}

_COLORI = {
    "black": "#000000", "nero": "#000000", "red": "#D32F2F", "rosso": "#D32F2F", "green": "#2E7D32",
    "verde": "#2E7D32", "blue": "#1565C0", "blu": "#1565C0", "yellow": "#F9A825", "giallo": "#F9A825",
    "magenta": "#AD1457", "cyan": "#00838F", "ciano": "#00838F", "white": "#FFFFFF", "bianco": "#FFFFFF",
}

_RE_COND = re.compile(r"^\[(<=|>=|<>|<|>|=)(-?[\d.]+)\]")


def _sezioni(codice: str) -> list[str]:
    out, buf, i, n = [], [], 0, len(codice)
    while i < n:
        ch = codice[i]
        if ch == '"':
            j = codice.find('"', i + 1)
            j = n - 1 if j < 0 else j
            buf.append(codice[i:j + 1])
            i = j + 1
            continue
        if ch == "\\" and i + 1 < n:
            buf.append(codice[i:i + 2])
            i += 2
            continue
        if ch == "[":
            j = codice.find("]", i)
            j = n - 1 if j < 0 else j
            buf.append(codice[i:j + 1])
            i = j + 1
            continue
        if ch == ";":
            out.append("".join(buf))
            buf = []
            i += 1
            continue
        buf.append(ch)
        i += 1
    out.append("".join(buf))
    return out


def _senza_letterali(s: str) -> str:
    s = re.sub(r'"[^"]*"', "", s)
    s = re.sub(r"\\.", "", s)
    s = re.sub(r"\[[^\]]*\]", lambda m: "H" if m.group(0).lower() in ("[h]", "[hh]", "[m]", "[mm]", "[s]", "[ss]") else "", s)
    s = re.sub(r"_.", "", s)
    s = re.sub(r"\*.", "", s)
    return s


def e_formato_data(codice: str | None) -> bool:
    if not codice:
        return False
    s = _senza_letterali(_sezioni(codice)[0]).lower()
    if "0" in s or "#" in s or "?" in s:
        return False
    return any(ch in s for ch in "ydhsgaH") or ("m" in s)


def codice_da_italiano(codice: str) -> str:
    """Codice scritto all'italiana (TESTO(A1;"#.##0,00") o "gg/mm/aaaa") -> codice di Excel."""
    out, i, n = [], 0, len(codice)
    data = e_formato_data(codice.replace("a", "y").replace("g", "d").replace("A", "y").replace("G", "d"))
    while i < n:
        ch = codice[i]
        if ch == '"':
            j = codice.find('"', i + 1)
            j = n - 1 if j < 0 else j
            out.append(codice[i:j + 1])
            i = j + 1
            continue
        if ch == "[":
            j = codice.find("]", i)
            j = n - 1 if j < 0 else j
            out.append(codice[i:j + 1])
            i = j + 1
            continue
        if ch == "\\" and i + 1 < n:
            out.append(codice[i:i + 2])
            i += 2
            continue
        if data:
            out.append({"a": "y", "A": "y", "g": "d", "G": "d"}.get(ch, ch))
        else:
            out.append({".": ",", ",": "."}.get(ch, ch))
        i += 1
    return "".join(out)


def formatta(valore: Any, codice: str | None) -> tuple[str, str | None]:
    """(testo da mostrare, colore o None)."""
    if isinstance(valore, Errore):
        return valore.codice, None
    if valore is None:
        return "", None
    if isinstance(valore, bool):
        return ("VERO" if valore else "FALSO"), None
    if not codice or codice.lower() in ("general", "generale"):
        if isinstance(valore, (int, float)):
            return testo_generale(valore), None
        return str(valore), None
    sezioni = _sezioni(codice)
    if isinstance(valore, str):
        if len(sezioni) >= 4:
            s = sezioni[3]
        elif "@" in sezioni[0]:
            s = sezioni[0]
        else:
            return valore, None
        colore, s = _colore(s)
        return _letterali(s, valore), colore
    if not isinstance(valore, (int, float)):
        return str(valore), None
    v = float(valore)
    if math.isnan(v) or math.isinf(v):
        return "#NUM!", None
    # scelta della sezione (con condizioni [>100] se ci sono)
    sezione = sezioni[0]
    togli_segno = False
    if any(_RE_COND.match(_colore(s)[1]) for s in sezioni[:3]):
        for s in sezioni[:3]:
            _, ss = _colore(s)
            m = _RE_COND.match(ss)
            if m is None or _vale(v, m.group(1), float(m.group(2))):
                sezione = s
                togli_segno = m is not None and v < 0 and len(sezioni) > 1
                break
    elif len(sezioni) >= 2 and v < 0:
        sezione = sezioni[1]
        togli_segno = True
    elif len(sezioni) >= 3 and v == 0:
        sezione = sezioni[2]
    colore, sezione = _colore(sezione)
    sezione = _RE_COND.sub("", sezione)
    if togli_segno:
        v = abs(v)
    if e_formato_data(sezione):
        return _data(v, sezione), colore
    if "@" in sezione and not any(ch in _senza_letterali(sezione) for ch in "0#?"):
        return _letterali(sezione, testo_generale(valore)), colore
    return _numero(v, sezione), colore


def _vale(v: float, op: str, soglia: float) -> bool:
    return {"<": v < soglia, ">": v > soglia, "=": v == soglia, "<=": v <= soglia, ">=": v >= soglia,
            "<>": v != soglia}[op]


def _colore(s: str) -> tuple[str | None, str]:
    m = re.match(r"^\[([A-Za-zà-ù]+)\]", s)
    if m and m.group(1).lower() in _COLORI:
        return _COLORI[m.group(1).lower()], s[m.end():]
    m = re.match(r"^\[(?:Color|Colore)\s*(\d+)\]", s, re.I)
    if m:
        return None, s[m.end():]
    return None, s


def _letterali(s: str, testo: str) -> str:
    out, i, n = [], 0, len(s)
    while i < n:
        ch = s[i]
        if ch == '"':
            j = s.find('"', i + 1)
            j = n if j < 0 else j
            out.append(s[i + 1:j])
            i = j + 1
            continue
        if ch == "\\" and i + 1 < n:
            out.append(s[i + 1])
            i += 2
            continue
        if ch == "@":
            out.append(testo)
        elif ch == "_" and i + 1 < n:
            out.append(" ")
            i += 1
        elif ch == "*" and i + 1 < n:
            i += 1
        elif ch == "[":
            j = s.find("]", i)
            i = j if j > 0 else i
        else:
            out.append(ch)
        i += 1
    return "".join(out)


# ---------------------------------------------------------------------------
# Numeri
# ---------------------------------------------------------------------------

def _numero(v: float, sezione: str) -> str:
    # pezzi: letterali e il "segnaposto" numerico
    pezzi: list[tuple[str, str]] = []      # ("l", testo) o ("n", codice)
    i, n = 0, len(sezione)
    buf_n = []
    percento = 0

    def chiudi_numero() -> None:
        if buf_n:
            pezzi.append(("n", "".join(buf_n)))
            buf_n.clear()

    while i < n:
        ch = sezione[i]
        if ch == '"':
            chiudi_numero()
            j = sezione.find('"', i + 1)
            j = n if j < 0 else j
            pezzi.append(("l", sezione[i + 1:j]))
            i = j + 1
            continue
        if ch == "\\" and i + 1 < n:
            chiudi_numero()
            pezzi.append(("l", sezione[i + 1]))
            i += 2
            continue
        if ch == "_" and i + 1 < n:
            chiudi_numero()
            pezzi.append(("l", " "))
            i += 2
            continue
        if ch == "*" and i + 1 < n:
            chiudi_numero()
            i += 2
            continue
        if ch == "[":
            j = sezione.find("]", i)
            i = (j + 1) if j > 0 else n
            continue
        if ch in "0#?.," or (ch in "Ee" and i + 1 < n and sezione[i + 1] in "+-" and buf_n):
            if ch in "Ee":
                buf_n.append(sezione[i:i + 2])
                i += 2
                while i < n and sezione[i] in "0#":
                    buf_n.append(sezione[i])
                    i += 1
                continue
            if ch == "," and not buf_n:
                pezzi.append(("l", ","))
                i += 1
                continue
            buf_n.append(ch)
            i += 1
            continue
        if ch == "%":
            percento += 1
        chiudi_numero()
        pezzi.append(("l", ch))
        i += 1
    chiudi_numero()
    codici = [p for p in pezzi if p[0] == "n"]
    if not codici:
        return "".join(t for _, t in pezzi)
    v = v * (100 ** percento)
    codice = codici[0][1]
    testo_n = _formatta_codice(v, codice)
    # se non c'è un segno nel formato e il numero è negativo, il "-" va davanti a tutto
    out = []
    usato = False
    for tipo, t in pezzi:
        if tipo == "n" and not usato:
            out.append(testo_n)
            usato = True
        elif tipo == "l":
            out.append(t)
    s = "".join(out)
    if s.startswith("-") is False and testo_n.startswith("-"):
        # sposta il meno davanti ai simboli (€ -12,00 -> -€ 12,00)
        s = "-" + s.replace(testo_n, testo_n[1:], 1)
    return s


def _formatta_codice(v: float, codice: str) -> str:
    esponente = None
    m = re.search(r"[Ee][+-]", codice)
    if m:
        esponente = codice[m.start():]
        codice = codice[:m.start()]
    # virgole finali: divide per 1000
    while codice.endswith(","):
        v /= 1000
        codice = codice[:-1]
    if "." in codice:
        intera, decimale = codice.split(".", 1)
    else:
        intera, decimale = codice, ""
    decimale = decimale.replace(",", "")
    migliaia = "," in intera
    intera = intera.replace(",", "")
    n_dec = len(decimale)
    obbl_dec = len(decimale.rstrip("#?"))
    negativo = v < 0
    v = abs(v)
    exp_txt = ""
    if esponente is not None:
        if v == 0:
            e = 0
        else:
            e = math.floor(math.log10(v))
            cifre_int = max(1, len(intera.replace("#", "").replace("?", "")) or 1)
            e -= (cifre_int - 1)
        v = v / (10 ** e) if v else 0
        segno = "+" if e >= 0 else "-"
        cifre = len(esponente) - 2
        exp_txt = "E" + (segno if esponente[1] == "+" or e < 0 else "") + str(abs(e)).zfill(max(1, cifre))
    arrotondato = _arrotonda(v, n_dec)
    parte_int = int(arrotondato)
    frazione = round(arrotondato - parte_int, n_dec) if n_dec else 0
    txt_dec = ""
    if n_dec:
        txt_dec = f"{frazione:.{n_dec}f}".split(".")[1] if frazione else "0" * n_dec
        # togli gli zeri non obbligatori (#)
        while len(txt_dec) > obbl_dec and txt_dec.endswith("0"):
            txt_dec = txt_dec[:-1]
    min_int = len(intera) - len(intera.lstrip("#?"))
    obbl_int = len(intera) - min_int
    txt_int = str(parte_int) if (parte_int or obbl_int) else ""
    if obbl_int and len(txt_int) < obbl_int:
        txt_int = txt_int.zfill(obbl_int)
    if migliaia and txt_int:
        gruppi = []
        while len(txt_int) > 3:
            gruppi.insert(0, txt_int[-3:])
            txt_int = txt_int[:-3]
        gruppi.insert(0, txt_int)
        txt_int = ".".join(gruppi)
    s = txt_int
    if txt_dec:
        s += "," + txt_dec
    elif n_dec and obbl_dec == 0 and "." in codice:
        pass
    if not s:
        s = "0" if not n_dec else ("0" + ("," + txt_dec if txt_dec else ""))
    s += exp_txt
    if negativo and any(ch != "0" for ch in s if ch.isdigit()):
        s = "-" + s
    return s


def _arrotonda(v: float, cifre: int) -> float:
    # arrotondamento "commerciale" (le metà lontano da zero), senza errori di 2,675
    from decimal import ROUND_HALF_UP, Decimal
    q = Decimal(1).scaleb(-cifre)
    return float(Decimal(repr(v)).quantize(q, rounding=ROUND_HALF_UP))


# ---------------------------------------------------------------------------
# Date e ore
# ---------------------------------------------------------------------------

def _data(v: float, sezione: str) -> str:
    try:
        d = seriale_in_datetime(v)
    except Exception:  # noqa: BLE001
        return "#" * 8
    s = sezione
    out = []
    i, n = 0, len(s)
    ampm = "am/pm" in s.lower() or "a/p" in s.lower()
    precedente_ora = False
    while i < n:
        ch = s[i]
        low = s[i:].lower()
        if ch == '"':
            j = s.find('"', i + 1)
            j = n if j < 0 else j
            out.append(s[i + 1:j])
            i = j + 1
            continue
        if ch == "\\" and i + 1 < n:
            out.append(s[i + 1])
            i += 2
            continue
        if ch == "[":
            j = s.find("]", i)
            tok = s[i + 1:j].lower() if j > 0 else ""
            totale_ore = v * 24
            if tok in ("h", "hh"):
                out.append(str(int(math.floor(totale_ore + 1e-9))).zfill(len(tok)))
                precedente_ora = True
            elif tok in ("m", "mm"):
                out.append(str(int(math.floor(v * 1440 + 1e-9))).zfill(len(tok)))
            elif tok in ("s", "ss"):
                out.append(str(int(round(v * 86400))).zfill(len(tok)))
            i = (j + 1) if j > 0 else n
            continue
        if low.startswith("am/pm"):
            out.append("AM" if d.hour < 12 else "PM")
            i += 5
            continue
        if low.startswith("a/p"):
            out.append("A" if d.hour < 12 else "P")
            i += 3
            continue
        k = ch.lower()
        if k in "ydmhsag" and ch.isalpha():
            j = i
            while j < n and s[j].lower() == k:
                j += 1
            lung = j - i
            if k in ("y", "a"):
                out.append(str(d.year) if lung > 2 else str(d.year)[-2:])
                precedente_ora = False
            elif k in ("d", "g"):
                if lung >= 4:
                    out.append(GIORNI[d.weekday()])
                elif lung == 3:
                    out.append(GIORNI[d.weekday()][:3])
                else:
                    out.append(str(d.day).zfill(lung))
                precedente_ora = False
            elif k == "h":
                h = d.hour
                if ampm:
                    h = h % 12 or 12
                out.append(str(h).zfill(lung))
                precedente_ora = True
            elif k == "s":
                out.append(str(d.second).zfill(lung))
                precedente_ora = False
            elif k == "m":
                # minuti se dopo un'ora o prima dei secondi
                dopo = s[j:].lower().lstrip(":. ")
                if precedente_ora or dopo.startswith("s"):
                    out.append(str(d.minute).zfill(lung))
                else:
                    if lung >= 5:
                        out.append(MESI[d.month - 1][0].upper())
                    elif lung == 4:
                        out.append(MESI[d.month - 1])
                    elif lung == 3:
                        out.append(MESI[d.month - 1][:3])
                    else:
                        out.append(str(d.month).zfill(lung))
                precedente_ora = False
            i = j
            continue
        if ch == "." and i + 1 < n and s[i + 1] == "0":
            j = i + 1
            while j < n and s[j] == "0":
                j += 1
            cifre = j - i - 1
            frazione = (d.microsecond / 1e6)
            out.append("," + f"{frazione:.{cifre}f}"[2:])
            i = j
            continue
        if ch == "_" and i + 1 < n:
            out.append(" ")
            i += 2
            continue
        if ch == "*" and i + 1 < n:
            i += 2
            continue
        out.append(ch)
        i += 1
    return "".join(out)
