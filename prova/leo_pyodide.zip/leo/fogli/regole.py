"""Formattazione condizionale e convalida dei dati.

Una regola condizionale è un dizionario::

    {"area": [r1, c1, r2, c2], "tipo": "valore", "operatore": ">", "valore1": "100",
     "stile": {"colore_sfondo": "#FDE68A", "colore_testo": "#7C2D12", "grassetto": True}}

Tipi: "valore" (operatori =, <>, >, <, >=, <=, tra, fuori), "testo" (contiene, inizia, finisce),
"formula" (una formula scritta per la cella in alto a sinistra, es. "=$C2<OGGI()"),
"duplicati", "unici", "primi" / "ultimi" (valore1 = quanti), "sopra_media", "sotto_media",
"vuote", "errori", "scala" (colori: [minimo, (medio), massimo]), "barre" (colore).

Una convalida::

    {"area": [...], "tipo": "lista", "elenco": "Sì;No;Forse" (o "=$H$1:$H$9"),
     "messaggio": "Scegli dall'elenco", "blocca": True}

Tipi: "lista", "intero", "decimale", "data", "lunghezza" (con operatore e valori), "formula".
"""

from __future__ import annotations

from typing import Any

from . import analisi as A
from .calcolo import Cartella, Contesto, Foglio, compila, finale
from .funzioni._aiuti import criterio
from .valori import Errore, ErroreFormula, a_logico, confronta, e_numero, leggi_inserimento, numero_da_testo

__all__ = ["stile_condizionale", "verifica_convalida", "elenco_convalida", "regola_in", "OPERATORI"]

OPERATORI = {"=": "uguale a", "<>": "diverso da", ">": "maggiore di", "<": "minore di", ">=": "maggiore o uguale a",
             "<=": "minore o uguale a", "tra": "tra", "fuori": "non tra"}


def _dentro(area: list, r: int, c: int) -> bool:
    return area[0] <= r <= area[2] and area[1] <= c <= area[3]


def regola_in(regole: list[dict], r: int, c: int) -> list[dict]:
    return [g for g in regole if _dentro(g["area"], r, c)]


def _valuta_testo(cartella: Cartella, foglio: Foglio, testo: str, r: int, c: int, base: tuple[int, int]) -> Any:
    """Un valore della regola: numero, testo o formula (relativa alla cella in alto a sinistra)."""
    if testo is None:
        return None
    t = str(testo)
    if t.startswith("="):
        cache = cartella.__dict__.setdefault("_cache_regole", {})
        chiave = (t, base)
        fn = cache.get(chiave)
        if fn is None:
            try:
                fn = compila(A.analizza(t), base)[0]
            except ErroreFormula:
                fn = lambda ctx: Errore("#ERRORE!")  # noqa: E731
            cache[chiave] = fn
        try:
            return finale(fn(Contesto(cartella, foglio, r, c)))
        except Exception:  # noqa: BLE001
            return Errore("#VALORE!")
    v, _ = leggi_inserimento(t)
    return v


def _confronta_op(v: Any, op: str, a: Any, b: Any) -> bool:
    try:
        if op in ("tra", "fuori"):
            dentro = confronta(v, a) >= 0 and confronta(v, b) <= 0
            return dentro if op == "tra" else not dentro
        k = confronta(v, a)
        return {"=": k == 0, "<>": k != 0, ">": k > 0, "<": k < 0, ">=": k >= 0, "<=": k <= 0}.get(op, False)
    except ErroreFormula:
        return False


def _statistiche(cartella: Cartella, foglio: Foglio, regola: dict) -> dict:
    """Valori dell'area (con cache fino al prossimo ricalcolo)."""
    cache = cartella.__dict__.setdefault("_cache_statistiche", {})
    chiave = (id(foglio), id(regola), tuple(regola["area"]))
    s = cache.get(chiave)
    if s is not None:
        return s
    r1, c1, r2, c2 = regola["area"]
    mr, mc = foglio.estensione()
    valori = []
    for r in range(r1, min(r2, mr) + 1):
        for c in range(c1, min(c2, mc) + 1):
            valori.append(foglio.valore(r, c))
    numeri = [v for v in valori if e_numero(v)]
    conteggi: dict = {}
    for v in valori:
        if v is not None and v != "":
            k = v.lower() if isinstance(v, str) else v
            conteggi[k] = conteggi.get(k, 0) + 1
    s = {"numeri": sorted(numeri), "conteggi": conteggi,
         "min": min(numeri) if numeri else 0, "max": max(numeri) if numeri else 0,
         "media": sum(numeri) / len(numeri) if numeri else 0}
    cache[chiave] = s
    return s


def dimentica_cache(cartella: Cartella) -> None:
    cartella.__dict__.pop("_cache_statistiche", None)


def _mescola(c1: str, c2: str, t: float) -> str:
    a = [int(c1[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(c2[i:i + 2], 16) for i in (1, 3, 5)]
    return "#" + "".join(f"{round(x + (y - x) * t):02X}" for x, y in zip(a, b))


def stile_condizionale(cartella: Cartella, foglio: Foglio, r: int, c: int) -> dict:
    """Le modifiche di stile delle regole che valgono per la cella (le prime vincono).

    Può contenere anche "barra" (frazione 0-1) e "colore_barra" per le barre dei dati."""
    out: dict = {}
    for regola in foglio.condizionali:
        if not _dentro(regola["area"], r, c):
            continue
        v = foglio.valore(r, c)
        tipo = regola.get("tipo", "valore")
        base = (regola["area"][0], regola["area"][1])
        vale = False
        if tipo == "valore":
            if v is None:
                continue
            a = _valuta_testo(cartella, foglio, regola.get("valore1"), r, c, base)
            b = _valuta_testo(cartella, foglio, regola.get("valore2"), r, c, base)
            vale = _confronta_op(v, regola.get("operatore", "="), a, b)
        elif tipo == "testo":
            t = "" if v is None else str(v).lower()
            x = str(regola.get("valore1", "")).lower()
            op = regola.get("operatore", "contiene")
            vale = (x in t) if op == "contiene" else t.startswith(x) if op == "inizia" else \
                t.endswith(x) if op == "finisce" else (x not in t)
        elif tipo == "formula":
            x = _valuta_testo(cartella, foglio, regola.get("formula") or regola.get("valore1"), r, c, base)
            try:
                vale = not isinstance(x, Errore) and a_logico(x)
            except ErroreFormula:
                vale = False
        elif tipo in ("duplicati", "unici"):
            if v is None or v == "":
                continue
            k = v.lower() if isinstance(v, str) else v
            n = _statistiche(cartella, foglio, regola)["conteggi"].get(k, 0)
            vale = n > 1 if tipo == "duplicati" else n == 1
        elif tipo in ("primi", "ultimi"):
            if not e_numero(v):
                continue
            nums = _statistiche(cartella, foglio, regola)["numeri"]
            k = int(numero_da_testo(str(regola.get("valore1", "10"))) or 10)
            if regola.get("percento"):
                k = max(1, int(len(nums) * k / 100))
            if nums:
                soglia = nums[-k] if tipo == "primi" and k <= len(nums) else (nums[k - 1] if k <= len(nums) else None)
                if soglia is None:
                    vale = True
                else:
                    vale = v >= soglia if tipo == "primi" else v <= soglia
        elif tipo in ("sopra_media", "sotto_media"):
            if not e_numero(v):
                continue
            m = _statistiche(cartella, foglio, regola)["media"]
            vale = v > m if tipo == "sopra_media" else v < m
        elif tipo == "vuote":
            vale = v is None or v == ""
        elif tipo == "errori":
            vale = isinstance(v, Errore)
        elif tipo == "scala":
            if not e_numero(v):
                continue
            s = _statistiche(cartella, foglio, regola)
            colori = regola.get("colori") or ["#F8696B", "#FFEB84", "#63BE7B"]
            lo, hi = s["min"], s["max"]
            t = 0.5 if hi == lo else (v - lo) / (hi - lo)
            if len(colori) == 2:
                colore = _mescola(colori[0], colori[1], t)
            else:
                colore = _mescola(colori[0], colori[1], t * 2) if t < 0.5 else _mescola(colori[1], colori[2], (t - 0.5) * 2)
            out.setdefault("colore_sfondo", colore)
            continue
        elif tipo == "barre":
            if not e_numero(v):
                continue
            s = _statistiche(cartella, foglio, regola)
            lo, hi = min(0, s["min"]), s["max"]
            out.setdefault("barra", 0 if hi == lo else max(0.0, min(1.0, (v - lo) / (hi - lo))))
            out.setdefault("colore_barra", regola.get("colore", "#5B9BD5"))
            continue
        if vale:
            for k, x in (regola.get("stile") or {}).items():
                out.setdefault(k, x)
            if regola.get("ferma"):
                break
    return out


# ---------------------------------------------------------------------------
# Convalida
# ---------------------------------------------------------------------------

def _convalida(foglio: Foglio, r: int, c: int) -> dict | None:
    for g in foglio.convalide:
        if _dentro(g["area"], r, c):
            return g
    return None


def elenco_convalida(cartella: Cartella, foglio: Foglio, r: int, c: int) -> list[str] | None:
    """Le voci del menu a tendina della cella (None se non ha una convalida a elenco)."""
    g = _convalida(foglio, r, c)
    if g is None or g.get("tipo") != "lista":
        return None
    elenco = str(g.get("elenco", ""))
    if elenco.startswith("="):
        from .calcolo import Rif
        try:
            x = compila(A.analizza(elenco), None)[0](Contesto(cartella, foglio, r, c))
        except Exception:  # noqa: BLE001
            return []
        if isinstance(x, Rif):
            from .operazioni import testo_mostrato
            voci = []
            for rr in range(x.r1, min(x.r2, x.foglio.estensione()[0]) + 1):
                for cc in range(x.c1, x.c2 + 1):
                    t = testo_mostrato(cartella, x.foglio, rr, cc)[0]
                    if t:
                        voci.append(t)
            return voci
        return []
    sep = ";" if ";" in elenco else ","
    return [v.strip() for v in elenco.split(sep) if v.strip()]


def verifica_convalida(cartella: Cartella, foglio: Foglio, r: int, c: int, testo: str) -> tuple[bool, str]:
    """(va bene?, messaggio). Un testo vuoto va sempre bene."""
    g = _convalida(foglio, r, c)
    if g is None or testo in (None, ""):
        return True, ""
    messaggio = g.get("messaggio") or "Il valore non rispetta la convalida di questa cella."
    tipo = g.get("tipo")
    if testo.startswith("="):
        return True, ""
    if tipo == "lista":
        voci = elenco_convalida(cartella, foglio, r, c) or []
        ok = testo.strip().lower() in [v.lower() for v in voci]
        return ok, (messaggio if not ok else "")
    if tipo == "formula":
        x = _valuta_testo(cartella, foglio, g.get("formula"), r, c, (g["area"][0], g["area"][1]))
        try:
            ok = a_logico(x)
        except ErroreFormula:
            ok = False
        return ok, (messaggio if not ok else "")
    v, _ = leggi_inserimento(testo)
    base = (g["area"][0], g["area"][1])
    a = _valuta_testo(cartella, foglio, g.get("valore1"), r, c, base)
    b = _valuta_testo(cartella, foglio, g.get("valore2"), r, c, base)
    op = g.get("operatore", "tra")
    if tipo == "lunghezza":
        v = len(testo)
    elif tipo in ("intero", "decimale", "data"):
        if not e_numero(v):
            return False, messaggio
        if tipo == "intero" and float(v) != int(v):
            return False, messaggio
    if a is None:
        return True, ""
    ok = _confronta_op(v, op, a, b)
    return ok, (messaggio if not ok else "")
