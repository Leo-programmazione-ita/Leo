"""Nomi delle celle e degli intervalli: A1, $B$2, C:C, 3:5, Foglio2!A1:B9.

Dentro il motore righe e colonne contano da 0 (A1 = riga 0, colonna 0).
"""

from __future__ import annotations

import re

__all__ = [
    "MAX_RIGHE", "MAX_COLONNE", "lettere", "colonna", "nome_cella", "leggi_cella", "leggi_area",
    "nome_area", "nome_foglio_in_formula",
]

MAX_RIGHE = 1_048_576
MAX_COLONNE = 16_384

_RE_CELLA = re.compile(r"^\$?([A-Za-z]{1,3})\$?(\d{1,7})$")
_RE_FOGLIO_SEMPLICE = re.compile(r"^[A-Za-z_À-ÿ][\wÀ-ÿ.]*$")


def lettere(c: int) -> str:
    """0 -> "A", 25 -> "Z", 26 -> "AA"."""
    s = ""
    c += 1
    while c > 0:
        c, resto = divmod(c - 1, 26)
        s = chr(65 + resto) + s
    return s


def colonna(testo: str) -> int:
    """"A" -> 0, "AA" -> 26."""
    n = 0
    for ch in testo.upper():
        n = n * 26 + (ord(ch) - 64)
    return n - 1


def nome_cella(r: int, c: int, ass_r: bool = False, ass_c: bool = False) -> str:
    return f"{'$' if ass_c else ''}{lettere(c)}{'$' if ass_r else ''}{r + 1}"


def leggi_cella(testo: str) -> tuple[int, int] | None:
    """"B3" -> (2, 1); None se non è una cella valida."""
    m = _RE_CELLA.match(testo.strip())
    if not m:
        return None
    c = colonna(m.group(1))
    r = int(m.group(2)) - 1
    if not (0 <= r < MAX_RIGHE and 0 <= c < MAX_COLONNE):
        return None
    return r, c


def leggi_area(testo: str) -> tuple[int, int, int, int] | None:
    """"A1:C3" -> (0, 0, 2, 2) ordinati; anche una sola cella; "A:C" e "2:5" interi."""
    t = testo.strip()
    if "!" in t:
        t = t.rsplit("!", 1)[1]
    if ":" not in t:
        p = leggi_cella(t)
        return (p[0], p[1], p[0], p[1]) if p else None
    a, b = t.split(":", 1)
    pa, pb = leggi_cella(a), leggi_cella(b)
    if pa and pb:
        return min(pa[0], pb[0]), min(pa[1], pb[1]), max(pa[0], pb[0]), max(pa[1], pb[1])
    a, b = a.replace("$", ""), b.replace("$", "")
    if a.isalpha() and b.isalpha():
        c1, c2 = colonna(a), colonna(b)
        return 0, min(c1, c2), MAX_RIGHE - 1, max(c1, c2)
    if a.isdigit() and b.isdigit():
        r1, r2 = int(a) - 1, int(b) - 1
        return min(r1, r2), 0, max(r1, r2), MAX_COLONNE - 1
    return None


def nome_area(r1: int, c1: int, r2: int, c2: int) -> str:
    if r1 == r2 and c1 == c2:
        return nome_cella(r1, c1)
    return f"{nome_cella(r1, c1)}:{nome_cella(r2, c2)}"


def nome_foglio_in_formula(nome: str) -> str:
    """Nome del foglio come va scritto in una formula (tra apici se serve)."""
    if _RE_FOGLIO_SEMPLICE.match(nome) and not leggi_cella(nome) and nome.upper() not in ("VERO", "FALSO"):
        return nome
    return "'" + nome.replace("'", "''") + "'"
