"""Funzioni di testo."""

from __future__ import annotations

import re
import unicodedata
from typing import Any

from ..calcolo import Rif, scalare
from ..formato import codice_da_italiano, formatta
from ..valori import ND, VALORE, Errore, ErroreFormula, Matrice, a_testo, e_numero, numero_da_testo
from . import funzione
from ._aiuti import controlla, intero, logico, num, num_opzionale, testo, valori_argomento

C = "Testo"


@funzione("CONCATENA", "CONCATENATE", minimo=1, categoria=C, descrizione="Unisce più testi.",
          sintassi="CONCATENA(testo1; [testo2]; ...)")
def concatena(ctx, *a):
    out = []
    for x in a:
        for v in valori_argomento(x):
            out.append(a_testo(v))
    return "".join(out)


@funzione("CONCAT", "CONCAT", minimo=1, categoria=C, descrizione="Unisce testi e intervalli.")
def concat(ctx, *a):
    return concatena(ctx, *a)


@funzione("TESTO.UNISCI", "TEXTJOIN", alias=("UNISCI.TESTO",), minimo=3, categoria=C,
          descrizione="Unisce testi con un separatore, saltando le vuote se vuoi.",
          sintassi="TESTO.UNISCI(separatore; ignora_vuote; testo1; ...)")
def testo_unisci(ctx, sep, ignora, *a):
    s = testo(sep)
    salta = logico(ignora)
    parti = []
    for x in a:
        for v in valori_argomento(x):
            t = a_testo(v)
            if salta and t == "":
                continue
            parti.append(t)
    return s.join(parti)


@funzione("SINISTRA", "LEFT", minimo=1, massimo=2, elementare=2, categoria=C, descrizione="I primi caratteri.")
def sinistra(ctx, t, n=None):
    k = intero(n) if n is not None else 1
    controlla(k >= 0, VALORE)
    return testo(t)[:k]


@funzione("DESTRA", "RIGHT", minimo=1, massimo=2, elementare=2, categoria=C, descrizione="Gli ultimi caratteri.")
def destra(ctx, t, n=None):
    k = intero(n) if n is not None else 1
    controlla(k >= 0, VALORE)
    s = testo(t)
    return s[len(s) - k:] if k else ""


@funzione("STRINGA.ESTRAI", "MID", minimo=3, massimo=3, elementare=3, categoria=C,
          descrizione="Una parte del testo.", sintassi="STRINGA.ESTRAI(testo; inizio; quanti)")
def stringa_estrai(ctx, t, inizio, quanti):
    i, n = intero(inizio), intero(quanti)
    controlla(i >= 1 and n >= 0, VALORE)
    return testo(t)[i - 1:i - 1 + n]


@funzione("LUNGHEZZA", "LEN", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Numero di caratteri.")
def lunghezza(ctx, t):
    return len(testo(t))


@funzione("MAIUSC", "UPPER", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Tutto maiuscolo.")
def maiusc(ctx, t):
    return testo(t).upper()


@funzione("MINUSC", "LOWER", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Tutto minuscolo.")
def minusc(ctx, t):
    return testo(t).lower()


@funzione("MAIUSC.INIZ", "PROPER", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Iniziali maiuscole.")
def maiusc_iniz(ctx, t):
    return re.sub(r"[^\W\d_]+", lambda m: m.group(0)[0].upper() + m.group(0)[1:].lower(), testo(t))


@funzione("ANNULLA.SPAZI", "TRIM", minimo=1, massimo=1, elementare=1, categoria=C,
          descrizione="Toglie gli spazi in più (all'inizio, alla fine e doppi).")
def annulla_spazi(ctx, t):
    return " ".join(testo(t).split(" ")).strip() if False else re.sub(" +", " ", testo(t)).strip(" ")


@funzione("LIBERA", "CLEAN", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Toglie i caratteri non stampabili.")
def libera(ctx, t):
    return "".join(ch for ch in testo(t) if ord(ch) >= 32)


@funzione("TROVA", "FIND", minimo=2, massimo=3, elementare=3, categoria=C,
          descrizione="Posizione di un testo dentro un altro (maiuscole distinte).", sintassi="TROVA(cosa; dove; [inizio])")
def trova(ctx, cosa, dove, inizio=None):
    i = intero(inizio) if inizio is not None else 1
    s = testo(dove)
    controlla(1 <= i <= len(s) + 1, VALORE)
    p = s.find(testo(cosa), i - 1)
    controlla(p >= 0, VALORE)
    return p + 1


@funzione("RICERCA", "SEARCH", minimo=2, massimo=3, elementare=3, categoria=C,
          descrizione="Come TROVA ma senza distinguere le maiuscole, con i jolly * e ?.")
def ricerca(ctx, cosa, dove, inizio=None):
    from ._aiuti import _jolly
    i = intero(inizio) if inizio is not None else 1
    s = testo(dove)
    controlla(1 <= i <= len(s) + 1, VALORE)
    c = testo(cosa)
    if any(ch in c for ch in "*?"):
        schema = _jolly(c).pattern[1:-1]
        m = re.compile(schema, re.IGNORECASE | re.DOTALL).search(s, i - 1)
        controlla(m is not None, VALORE)
        return m.start() + 1
    p = s.lower().find(c.lower(), i - 1)
    controlla(p >= 0, VALORE)
    return p + 1


@funzione("SOSTITUISCI", "SUBSTITUTE", minimo=3, massimo=4, elementare=4, categoria=C,
          descrizione="Sostituisce un testo con un altro (tutte le volte o solo l'n-esima).",
          sintassi="SOSTITUISCI(testo; vecchio; nuovo; [quale])")
def sostituisci(ctx, t, vecchio, nuovo, quale=None):
    s, v, n = testo(t), testo(vecchio), testo(nuovo)
    if not v:
        return s
    if quale is None:
        return s.replace(v, n)
    k = intero(quale)
    controlla(k >= 1, VALORE)
    pos = -1
    for _ in range(k):
        pos = s.find(v, pos + 1)
        if pos < 0:
            return s
    return s[:pos] + n + s[pos + len(v):]


@funzione("RIMPIAZZA", "REPLACE", minimo=4, massimo=4, elementare=4, categoria=C,
          descrizione="Rimpiazza una parte del testo per posizione.", sintassi="RIMPIAZZA(testo; inizio; quanti; nuovo)")
def rimpiazza(ctx, t, inizio, quanti, nuovo):
    s = testo(t)
    i, n = intero(inizio), intero(quanti)
    controlla(i >= 1 and n >= 0, VALORE)
    return s[:i - 1] + testo(nuovo) + s[i - 1 + n:]


@funzione("RIPETI", "REPT", minimo=2, massimo=2, elementare=2, categoria=C, descrizione="Ripete un testo n volte.")
def ripeti(ctx, t, n):
    k = intero(n)
    controlla(0 <= k and len(testo(t)) * k <= 32767, VALORE)
    return testo(t) * k


@funzione("TESTO", "TEXT", minimo=2, massimo=2, elementare=2, categoria=C,
          descrizione="Numero o data scritti con un formato: TESTO(A1;\"#.##0,00\"), TESTO(B2;\"gg/mm/aaaa\").",
          sintassi="TESTO(valore; formato)")
def f_testo(ctx, v, fmt):
    v = scalare(v)
    if isinstance(v, Errore):
        raise ErroreFormula(v.codice)
    if isinstance(v, str):
        n = numero_da_testo(v)
        if n is not None:
            v = n
    return formatta(v, codice_da_italiano(testo(fmt)))[0]


@funzione("VALORE", "VALUE", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Da testo a numero.")
def valore(ctx, t):
    v = scalare(t)
    if e_numero(v):
        return v
    n = numero_da_testo(testo(v))
    controlla(n is not None, VALORE)
    return n


@funzione("NUMERO.VALORE", "NUMBERVALUE", minimo=1, massimo=3, elementare=1, categoria=C,
          descrizione="Da testo a numero indicando i separatori.", sintassi="NUMERO.VALORE(testo; [decimale]; [migliaia])")
def numero_valore(ctx, t, dec=None, mig=None):
    s = testo(t).replace(" ", "")
    d = testo(dec) if dec is not None else ","
    m = testo(mig) if mig is not None else "."
    if m:
        s = s.replace(m, "")
    s = s.replace(d, ".")
    perc = 0
    while s.endswith("%"):
        perc += 1
        s = s[:-1]
    try:
        x = float(s) if s else 0
    except ValueError:
        raise ErroreFormula(VALORE)
    return x / (100 ** perc)


@funzione("FISSO", "FIXED", minimo=1, massimo=3, elementare=1, categoria=C, descrizione="Numero arrotondato come testo.")
def fisso(ctx, x, dec=None, senza_punti=None):
    d = intero(dec) if dec is not None else 2
    codice = ("0" if senza_punti is not None and logico(senza_punti) else "#,##0") + ("." + "0" * d if d > 0 else "")
    return formatta(num(x), codice)[0]


@funzione("VALUTA", "DOLLAR", minimo=1, massimo=2, elementare=1, categoria=C, descrizione="Numero come importo in euro.")
def valuta(ctx, x, dec=None):
    d = intero(dec) if dec is not None else 2
    codice = "€ #,##0" + ("." + "0" * d if d > 0 else "")
    return formatta(num(x), codice)[0]


@funzione("CODICE", "CODE", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Codice del primo carattere.")
def codice(ctx, t):
    s = testo(t)
    controlla(bool(s), VALORE)
    return ord(s[0]) if ord(s[0]) < 256 else ord(s[0])


@funzione("CODICE.CARATT", "CHAR", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Carattere dal codice.")
def codice_caratt(ctx, n):
    k = intero(n)
    controlla(1 <= k <= 255, VALORE)
    return bytes([k]).decode("cp1252", errors="replace")


@funzione("UNICODE", "UNICODE", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Codice Unicode del primo carattere.")
def f_unicode(ctx, t):
    s = testo(t)
    controlla(bool(s), VALORE)
    return ord(s[0])


@funzione("CARATT.UNI", "UNICHAR", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Carattere Unicode dal codice.")
def caratt_uni(ctx, n):
    k = intero(n)
    controlla(1 <= k <= 0x10FFFF, VALORE)
    return chr(k)


@funzione("ESATTO", "EXACT", minimo=2, massimo=2, elementare=2, categoria=C, descrizione="VERO se due testi sono identici.")
def esatto(ctx, a, b):
    return testo(a) == testo(b)


@funzione("T", "T", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Il testo, oppure vuoto se non è testo.")
def f_t(ctx, v):
    v = scalare(v)
    return v if isinstance(v, str) else ""


def _occorrenza(s: str, sep: str, n: int, maiuscole: bool) -> int:
    hay, ago = (s, sep) if maiuscole else (s.lower(), sep.lower())
    if n > 0:
        pos = -1
        for _ in range(n):
            pos = hay.find(ago, pos + 1)
            if pos < 0:
                return -1
        return pos
    pos = len(hay) + 1
    for _ in range(-n):
        pos = hay.rfind(ago, 0, pos - 1 if pos > 0 else 0)
        if pos < 0:
            return -1
    return pos


@funzione("TESTO.PRECEDENTE", "TEXTBEFORE", alias=("TESTO.PRIMA",), minimo=2, massimo=6, elementare=2, categoria=C,
          descrizione="Il testo prima di un separatore.", sintassi="TESTO.PRECEDENTE(testo; separatore; [n])")
def testo_prima(ctx, t, sep, n=None, modo=None, fine=None, se_non=None):
    s, d = testo(t), testo(sep)
    k = intero(n) if n is not None else 1
    controlla(k != 0, VALORE)
    p = _occorrenza(s, d, k, not (modo is not None and intero(modo) == 1))
    if p < 0:
        if se_non is not None:
            return scalare(se_non)
        raise ErroreFormula(ND)
    return s[:p]


@funzione("TESTO.SUCCESSIVO", "TEXTAFTER", alias=("TESTO.DOPO",), minimo=2, massimo=6, elementare=2, categoria=C,
          descrizione="Il testo dopo un separatore.", sintassi="TESTO.SUCCESSIVO(testo; separatore; [n])")
def testo_dopo(ctx, t, sep, n=None, modo=None, fine=None, se_non=None):
    s, d = testo(t), testo(sep)
    k = intero(n) if n is not None else 1
    controlla(k != 0, VALORE)
    p = _occorrenza(s, d, k, not (modo is not None and intero(modo) == 1))
    if p < 0:
        if se_non is not None:
            return scalare(se_non)
        raise ErroreFormula(ND)
    return s[p + len(d):]


@funzione("DIVIDI.TESTO", "TEXTSPLIT", minimo=2, massimo=6, categoria=C,
          descrizione="Divide un testo in colonne (e righe) secondo i separatori.",
          sintassi="DIVIDI.TESTO(testo; sep_colonne; [sep_righe]; [ignora_vuoti])")
def dividi_testo(ctx, t, sep_col, sep_riga=None, ignora=None, modo=None, riempi=None):
    s = testo(t)
    sc = [a_testo(v) for v in valori_argomento(sep_col)] if sep_col is not None else []
    sr = [a_testo(v) for v in valori_argomento(sep_riga)] if sep_riga is not None else []
    salta = ignora is not None and logico(ignora)

    def spezza(x: str, seps: list[str]) -> list[str]:
        seps = [p for p in seps if p]
        if not seps:
            return [x]
        parti = re.split("|".join(re.escape(p) for p in seps), x)
        return [p for p in parti if p] if salta else parti

    righe = [spezza(r, sc) for r in spezza(s, sr)]
    w = max(len(r) for r in righe)
    pieno = scalare(riempi) if riempi is not None else Errore(ND)
    return Matrice([r + [pieno] * (w - len(r)) for r in righe]) if (len(righe) > 1 or w > 1) else righe[0][0]


@funzione("SENZA.ACCENTI", "SENZA.ACCENTI", minimo=1, massimo=1, elementare=1, categoria=C,
          descrizione="Toglie accenti e segni diacritici (perché → perche).")
def senza_accenti(ctx, t):
    return "".join(ch for ch in unicodedata.normalize("NFD", testo(t)) if unicodedata.category(ch) != "Mn")


@funzione("REGEX.CORRISPONDE", "REGEXTEST", minimo=2, massimo=3, elementare=2, categoria=C,
          descrizione="VERO se il testo corrisponde a un'espressione regolare.")
def regex_test(ctx, t, schema, maiuscole=None):
    flag = re.IGNORECASE if maiuscole is not None and intero(maiuscole) == 1 else 0
    try:
        return re.search(testo(schema), testo(t), flag) is not None
    except re.error:
        raise ErroreFormula(VALORE)


@funzione("REGEX.ESTRAI", "REGEXEXTRACT", minimo=2, massimo=4, elementare=2, categoria=C,
          descrizione="La parte del testo che corrisponde a un'espressione regolare.")
def regex_estrai(ctx, t, schema, modo=None, maiuscole=None):
    flag = re.IGNORECASE if maiuscole is not None and intero(maiuscole) == 1 else 0
    try:
        m = re.search(testo(schema), testo(t), flag)
    except re.error:
        raise ErroreFormula(VALORE)
    if m is None:
        raise ErroreFormula(ND)
    return m.group(0)


@funzione("REGEX.SOSTITUISCI", "REGEXREPLACE", minimo=3, massimo=5, elementare=3, categoria=C,
          descrizione="Sostituisce le parti che corrispondono a un'espressione regolare.")
def regex_sostituisci(ctx, t, schema, nuovo, quale=None, maiuscole=None):
    flag = re.IGNORECASE if maiuscole is not None and intero(maiuscole) == 1 else 0
    try:
        return re.sub(testo(schema), testo(nuovo).replace("$", "\\"), testo(t), flags=flag)
    except re.error:
        raise ErroreFormula(VALORE)
