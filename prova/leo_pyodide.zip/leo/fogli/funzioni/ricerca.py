"""Ricerca e riferimenti: CERCA.VERT, CERCA.X, INDICE, CONFRONTA, SCARTO, INDIRETTO..."""

from __future__ import annotations

import re
from typing import Any, Callable

from ..calcolo import Rif, scalare
from ..riferimenti import MAX_COLONNE, MAX_RIGHE, leggi_area, nome_cella, nome_foglio_in_formula, lettere
from ..valori import ND, RIF, VALORE, Errore, ErroreFormula, Matrice, confronta, e_numero
from . import funzione
from ._aiuti import _jolly, controlla, intero, logico, num, righe_di, testo

C = "Ricerca e riferimento"


def _uguale(cercato: Any, jolly: bool) -> Callable[[Any], bool]:
    if isinstance(cercato, str) and jolly and any(ch in cercato for ch in "*?~"):
        schema = _jolly(cercato)
        return lambda v: isinstance(v, str) and bool(schema.match(v))
    if isinstance(cercato, str):
        low = cercato.lower()
        return lambda v: isinstance(v, str) and v.lower() == low
    if isinstance(cercato, bool):
        return lambda v: isinstance(v, bool) and v == cercato
    if e_numero(cercato):
        return lambda v: e_numero(v) and v == cercato
    return lambda v: v is None


def _stesso_genere(a: Any, b: Any) -> bool:
    if isinstance(a, bool) or isinstance(b, bool):
        return isinstance(a, bool) and isinstance(b, bool)
    if e_numero(a):
        return e_numero(b)
    return isinstance(a, str) and isinstance(b, str)


def cerca_posizione(cercato: Any, valori: list, modo: int = 0, dal_fondo: bool = False) -> int:
    """Indice (da 0) secondo il modo: 0 esatto (con jolly), 1 il più grande <=, -1 il più piccolo >=; -1 se non c'è."""
    if isinstance(cercato, Errore):
        raise ErroreFormula(cercato.codice)
    ordine = range(len(valori) - 1, -1, -1) if dal_fondo else range(len(valori))
    if modo == 0 or modo == 2:
        prova = _uguale(cercato, True)
        for i in ordine:
            if prova(valori[i]):
                return i
        return -1
    migliore = -1
    for i in ordine:
        v = valori[i]
        if v is None or isinstance(v, Errore) or not _stesso_genere(v, cercato):
            continue
        k = confronta(v, cercato)
        if k == 0:
            return i
        if modo == 1 and k < 0 and (migliore < 0 or confronta(v, valori[migliore]) > 0):
            migliore = i
        if modo == -1 and k > 0 and (migliore < 0 or confronta(v, valori[migliore]) < 0):
            migliore = i
    return migliore


def _approssimata_ordinata(cercato: Any, valori: list) -> int:
    """Come Excel con l'intervallo ordinato: l'ultimo valore <= cercato prima del primo più grande."""
    trovato = -1
    for i, v in enumerate(valori):
        if v is None or isinstance(v, Errore) or not _stesso_genere(v, cercato):
            continue
        if confronta(v, cercato) <= 0:
            trovato = i
        else:
            break
    return trovato


@funzione("CERCA.VERT", "VLOOKUP", minimo=3, massimo=4, categoria=C,
          descrizione="Cerca nella prima colonna e dà il valore di un'altra colonna della stessa riga.",
          sintassi="CERCA.VERT(valore; tabella; indice_colonna; [intervallo])")
def cerca_vert(ctx, cercato, tabella, colonna, approssimato=None):
    cercato = scalare(cercato)
    righe = righe_di(tabella)
    k = intero(colonna)
    controlla(k >= 1, VALORE)
    controlla(k <= len(righe[0]), RIF)
    prima = [r[0] for r in righe]
    if approssimato is None or logico(approssimato):
        i = _approssimata_ordinata(cercato, prima)
    else:
        i = cerca_posizione(cercato, prima, 0)
    controlla(i >= 0, ND)
    v = righe[i][k - 1]
    return 0 if v is None else v


@funzione("CERCA.ORIZZ", "HLOOKUP", minimo=3, massimo=4, categoria=C,
          descrizione="Cerca nella prima riga e dà il valore di un'altra riga della stessa colonna.",
          sintassi="CERCA.ORIZZ(valore; tabella; indice_riga; [intervallo])")
def cerca_orizz(ctx, cercato, tabella, riga, approssimato=None):
    cercato = scalare(cercato)
    righe = righe_di(tabella)
    k = intero(riga)
    controlla(k >= 1, VALORE)
    controlla(k <= len(righe), RIF)
    prima = righe[0]
    if approssimato is None or logico(approssimato):
        i = _approssimata_ordinata(cercato, prima)
    else:
        i = cerca_posizione(cercato, prima, 0)
    controlla(i >= 0, ND)
    v = righe[k - 1][i]
    return 0 if v is None else v


def _vettore(a: Any) -> tuple[list, bool]:
    """Valori di una riga o colonna e se è verticale."""
    righe = righe_di(a)
    if len(righe) == 1:
        return list(righe[0]), False
    controlla(all(len(r) == 1 for r in righe), VALORE)
    return [r[0] for r in righe], True


@funzione("CERCA.X", "XLOOKUP", minimo=3, massimo=6, categoria=C,
          descrizione="La ricerca moderna: cerca in una colonna (o riga) e dà il valore corrispondente di un'altra.",
          sintassi="CERCA.X(valore; matrice_ricerca; matrice_restituita; [se_non_trovato]; [corrispondenza]; [ricerca])")
def cerca_x(ctx, cercato, dove, cosa, se_non=None, modo=None, ricerca=None):
    cercato = scalare(cercato)
    valori, verticale = _vettore(dove)
    m = intero(modo) if modo is not None else 0
    r = intero(ricerca) if ricerca is not None else 1
    controlla(m in (-1, 0, 1, 2) and r in (-2, -1, 1, 2), VALORE)
    if m == 0 and isinstance(cercato, str):
        prova = _uguale(cercato, False)
        ordine = range(len(valori) - 1, -1, -1) if r < 0 else range(len(valori))
        i = next((j for j in ordine if prova(valori[j])), -1)
    else:
        i = cerca_posizione(cercato, valori, m if m != 2 else 2, dal_fondo=r < 0)
    if i < 0:
        if se_non is not None:
            return scalare(se_non)
        raise ErroreFormula(ND)
    righe = righe_di(cosa)
    if verticale:
        controlla(len(righe) == len(valori), VALORE)
        riga = righe[i]
        return riga[0] if len(riga) == 1 else Matrice([[(0 if v is None else v) for v in riga]])
    controlla(len(righe[0]) == len(valori), VALORE)
    col = [r_[i] for r_ in righe]
    return col[0] if len(col) == 1 else Matrice([[0 if v is None else v] for v in col])


@funzione("CONFRONTA", "MATCH", minimo=2, massimo=3, categoria=C,
          descrizione="Posizione di un valore in una riga o colonna (0 = esatta, 1 = il più grande <=, -1 = il più piccolo >=).",
          sintassi="CONFRONTA(valore; matrice; [tipo])")
def confronta_f(ctx, cercato, dove, tipo=None):
    cercato = scalare(cercato)
    valori, _ = _vettore(dove)
    t = intero(tipo) if tipo is not None else 1
    if t == 0:
        i = cerca_posizione(cercato, valori, 0)
    elif t > 0:
        i = _approssimata_ordinata(cercato, valori)
    else:
        i = -1
        for j, v in enumerate(valori):
            if v is None or not _stesso_genere(v, cercato):
                continue
            if confronta(v, cercato) >= 0:
                i = j
            else:
                break
    controlla(i >= 0, ND)
    return i + 1


@funzione("CONFRONTA.X", "XMATCH", minimo=2, massimo=4, categoria=C, descrizione="Posizione di un valore (ricerca moderna).",
          sintassi="CONFRONTA.X(valore; matrice; [corrispondenza]; [ricerca])")
def confronta_x(ctx, cercato, dove, modo=None, ricerca=None):
    cercato = scalare(cercato)
    valori, _ = _vettore(dove)
    m = intero(modo) if modo is not None else 0
    r = intero(ricerca) if ricerca is not None else 1
    i = cerca_posizione(cercato, valori, m, dal_fondo=r < 0)
    controlla(i >= 0, ND)
    return i + 1


@funzione("INDICE", "INDEX", minimo=2, massimo=4, categoria=C,
          descrizione="Il valore (o la cella) a una certa riga e colonna di un intervallo.",
          sintassi="INDICE(matrice; riga; [colonna])")
def indice(ctx, matrice, riga, colonna=None, area=None):
    r = intero(riga) if riga is not None else 0
    h, w = (matrice.altezza, matrice.larghezza) if isinstance(matrice, (Rif, Matrice)) else (1, 1)
    if colonna is None:
        if h == 1 and w > 1:
            c, r = r, 1
        else:
            c = 1 if w == 1 else 0
            if w > 1 and r:
                c = 0
    else:
        c = intero(colonna)
    controlla(0 <= r <= h and 0 <= c <= w, RIF)
    if isinstance(matrice, Rif):
        r1 = matrice.r1 + (r - 1 if r else 0)
        r2 = matrice.r1 + (r - 1) if r else matrice.r2
        c1 = matrice.c1 + (c - 1 if c else 0)
        c2 = matrice.c1 + (c - 1) if c else matrice.c2
        return Rif(matrice.foglio, r1, c1, r2, c2)
    righe = righe_di(matrice)
    if r and c:
        return righe[r - 1][c - 1]
    if r:
        return Matrice([righe[r - 1]])
    if c:
        return Matrice([[x[c - 1]] for x in righe])
    return Matrice(righe)


@funzione("SCARTO", "OFFSET", minimo=3, massimo=5, dinamica=True, categoria=C,
          descrizione="Un intervallo spostato di alcune righe e colonne.",
          sintassi="SCARTO(rif; righe; colonne; [altezza]; [larghezza])")
def scarto(ctx, rif, righe, colonne, altezza=None, larghezza=None):
    controlla(isinstance(rif, Rif), VALORE)
    r1 = rif.r1 + intero(righe)
    c1 = rif.c1 + intero(colonne)
    h = intero(altezza) if altezza is not None else rif.altezza
    w = intero(larghezza) if larghezza is not None else rif.larghezza
    controlla(h > 0 and w > 0, RIF)
    controlla(0 <= r1 and 0 <= c1 and r1 + h <= MAX_RIGHE and c1 + w <= MAX_COLONNE, RIF)
    return Rif(rif.foglio, r1, c1, r1 + h - 1, c1 + w - 1)


@funzione("INDIRETTO", "INDIRECT", minimo=1, massimo=2, dinamica=True, categoria=C,
          descrizione="Il riferimento scritto in un testo: INDIRETTO(\"B\"&A1), INDIRETTO(\"Vendite!C3\").")
def indiretto(ctx, t, a1=None):
    s = testo(t).strip()
    controlla(bool(s), RIF)
    foglio = ctx.foglio
    if "!" in s:
        nome, s = s.rsplit("!", 1)
        if nome.startswith("'") and nome.endswith("'"):
            nome = nome[1:-1].replace("''", "'")
        foglio = ctx.cartella.foglio(nome)
        controlla(foglio is not None, RIF)
    area = leggi_area(s)
    if area is None:
        # forse un nome definito
        nome = s.upper()
        if nome in ctx.cartella.nomi:
            v = ctx.cartella.valuta_nome(nome, ctx)
            controlla(isinstance(v, Rif), RIF)
            return v
        raise ErroreFormula(RIF)
    return Rif(foglio, *area)


@funzione("RIF.RIGA", "ROW", minimo=0, massimo=1, categoria=C, descrizione="Numero di riga.")
def rif_riga(ctx, rif=None):
    if rif is None:
        return ctx.r + 1
    controlla(isinstance(rif, Rif), VALORE)
    if rif.altezza == 1:
        return rif.r1 + 1
    lim = rif if rif.altezza < 100000 else rif.limitata()
    return Matrice([[r + 1] for r in range(lim.r1, lim.r2 + 1)])


@funzione("RIF.COLONNA", "COLUMN", minimo=0, massimo=1, categoria=C, descrizione="Numero di colonna.")
def rif_colonna(ctx, rif=None):
    if rif is None:
        return ctx.c + 1
    controlla(isinstance(rif, Rif), VALORE)
    if rif.larghezza == 1:
        return rif.c1 + 1
    return Matrice([[c + 1 for c in range(rif.c1, rif.c2 + 1)]])


@funzione("RIGHE", "ROWS", minimo=1, massimo=1, categoria=C, descrizione="Quante righe ha un intervallo.")
def righe(ctx, a):
    if isinstance(a, (Rif, Matrice)):
        return a.altezza
    return 1


@funzione("COLONNE", "COLUMNS", minimo=1, massimo=1, categoria=C, descrizione="Quante colonne ha un intervallo.")
def colonne(ctx, a):
    if isinstance(a, (Rif, Matrice)):
        return a.larghezza
    return 1


@funzione("SCEGLI", "CHOOSE", minimo=2, pigra=True, categoria=C, descrizione="Sceglie un valore dall'elenco per posizione.",
          sintassi="SCEGLI(indice; valore1; [valore2]; ...)")
def scegli(ctx, indice_, *valori):
    i = intero(indice_())
    controlla(1 <= i <= len(valori), VALORE)
    v = valori[i - 1]()
    return 0 if v is None else v


@funzione("INDIRIZZO", "ADDRESS", minimo=2, massimo=5, categoria=C, descrizione="Il nome di una cella come testo.",
          sintassi="INDIRIZZO(riga; colonna; [assoluto]; [a1]; [foglio])")
def indirizzo(ctx, riga, colonna, ass=None, a1=None, foglio=None):
    r, c = intero(riga), intero(colonna)
    controlla(1 <= r <= MAX_RIGHE and 1 <= c <= MAX_COLONNE, VALORE)
    t = intero(ass) if ass is not None else 1
    ar = t in (1, 2)
    ac = t in (1, 3)
    s = nome_cella(r - 1, c - 1, ar, ac)
    if foglio is not None:
        s = nome_foglio_in_formula(testo(foglio)) + "!" + s
    return s


@funzione("CERCA", "LOOKUP", minimo=2, massimo=3, categoria=C, descrizione="Ricerca approssimata in un vettore ordinato.")
def cerca(ctx, cercato, vettore, risultato=None):
    cercato = scalare(cercato)
    valori, _ = _vettore(vettore)
    i = _approssimata_ordinata(cercato, valori)
    controlla(i >= 0, ND)
    if risultato is None:
        return valori[i]
    r, _ = _vettore(risultato)
    controlla(i < len(r), ND)
    return r[i]
