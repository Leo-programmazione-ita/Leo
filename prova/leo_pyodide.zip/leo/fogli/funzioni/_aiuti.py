"""Aiuti comuni alle funzioni: numeri da intervalli, criteri, matrici."""

from __future__ import annotations

import math
import re
from typing import Any, Callable, Iterable, Iterator

from ..calcolo import Rif, scalare
from ..valori import (DIV0, ND, NUM, VALORE, Errore, ErroreFormula, Matrice, a_logico, a_numero, a_testo,
                      confronta, e_numero, numero_da_testo)

__all__ = [
    "num", "testo", "logico", "intero", "numeri", "valori_piatti", "righe_di", "dimensioni", "criterio",
    "valori_argomento", "controlla", "errore", "risultato_matrice", "num_opzionale", "allinea", "media",
]


def errore(codice: str) -> None:
    raise ErroreFormula(codice)


def controlla(condizione: bool, codice: str = VALORE) -> None:
    if not condizione:
        raise ErroreFormula(codice)


def num(v: Any) -> float | int:
    v = scalare(v)
    if isinstance(v, Matrice):
        v = v.righe[0][0]
    return a_numero(v)


def num_opzionale(v: Any, predefinito: float | int) -> float | int:
    return predefinito if v is None else num(v)


def intero(v: Any) -> int:
    x = num(v)
    return int(math.floor(x)) if x >= 0 else -int(math.floor(-x))


def testo(v: Any) -> str:
    v = scalare(v)
    if isinstance(v, Matrice):
        v = v.righe[0][0]
    return a_testo(v)


def logico(v: Any) -> bool:
    v = scalare(v)
    if isinstance(v, Matrice):
        v = v.righe[0][0]
    return a_logico(v)


def valori_argomento(a: Any, solo_non_vuoti: bool = False) -> Iterator[Any]:
    """Tutti i valori di un argomento (intervallo, matrice o valore singolo)."""
    if isinstance(a, Rif):
        yield from (a.non_vuoti() if solo_non_vuoti else a.valori())
    elif isinstance(a, Matrice):
        for r in a.righe:
            yield from r
    else:
        yield a


def numeri(argomenti: Iterable[Any], *, testi_come_zero: bool = False, logici_in_rif: bool = False) -> list:
    """Numeri per SOMMA, MEDIA, MAX...: negli intervalli si saltano testi, vuote e logici;
    gli argomenti scritti direttamente si convertono (un testo non numerico è #VALORE!)."""
    out: list = []
    for a in argomenti:
        if isinstance(a, (Rif, Matrice)):
            for v in valori_argomento(a, solo_non_vuoti=True):
                if isinstance(v, bool):
                    if logici_in_rif:
                        out.append(1 if v else 0)
                    elif testi_come_zero:
                        out.append(1 if v else 0)
                elif isinstance(v, (int, float)):
                    out.append(v)
                elif isinstance(v, Errore):
                    raise ErroreFormula(v.codice)
                elif testi_come_zero and isinstance(v, str):
                    out.append(0)
        elif a is None:
            continue
        elif isinstance(a, Errore):
            raise ErroreFormula(a.codice)
        else:
            out.append(a_numero(a))
    return out


def valori_piatti(a: Any) -> list[Any]:
    return list(valori_argomento(a))


def righe_di(a: Any) -> list[list[Any]]:
    if isinstance(a, Rif):
        return a.righe()
    if isinstance(a, Matrice):
        return a.righe
    return [[a]]


def dimensioni(a: Any) -> tuple[int, int]:
    if isinstance(a, Rif):
        return a.altezza, a.larghezza
    if isinstance(a, Matrice):
        return a.altezza, a.larghezza
    return 1, 1


def risultato_matrice(righe: list[list[Any]]) -> Any:
    if not righe or not righe[0]:
        raise ErroreFormula("#CALC!")
    if len(righe) == 1 and len(righe[0]) == 1:
        return righe[0][0]
    return Matrice(righe)


# ---------------------------------------------------------------------------
# Criteri di SOMMA.SE, CONTA.SE...: ">10", "<>Roma", "Ros*", "=", 7
# ---------------------------------------------------------------------------

def _jolly(t: str) -> re.Pattern:
    out = []
    i = 0
    while i < len(t):
        ch = t[i]
        if ch == "~" and i + 1 < len(t):
            out.append(re.escape(t[i + 1]))
            i += 2
            continue
        if ch == "*":
            out.append(".*")
        elif ch == "?":
            out.append(".")
        else:
            out.append(re.escape(ch))
        i += 1
    return re.compile("^" + "".join(out) + "$", re.IGNORECASE | re.DOTALL)


def criterio(c: Any) -> Callable[[Any], bool]:
    c = scalare(c)
    if isinstance(c, Matrice):
        c = c.righe[0][0]
    if isinstance(c, Errore):
        raise ErroreFormula(c.codice)
    if c is None:
        return lambda v: v is None or v == ""
    if isinstance(c, bool):
        return lambda v: isinstance(v, bool) and v == c
    if isinstance(c, (int, float)):
        return lambda v: (e_numero(v) and v == c) or (isinstance(v, str) and numero_da_testo(v) == c)
    t = str(c)
    op = "="
    for simbolo in ("<=", ">=", "<>", "<", ">", "="):
        if t.startswith(simbolo):
            op = simbolo
            t = t[len(simbolo):]
            break
    if t == "":
        if op == "=":
            return lambda v: v is None or v == ""
        if op == "<>":
            return lambda v: v is not None and v != ""
    n = numero_da_testo(t)
    su = t.upper()
    if su in ("VERO", "FALSO", "TRUE", "FALSE") and n is None:
        b = su in ("VERO", "TRUE")
        if op == "=":
            return lambda v: isinstance(v, bool) and v == b
        if op == "<>":
            return lambda v: not (isinstance(v, bool) and v == b)
    if n is not None:
        def numerico(v: Any) -> bool:
            if isinstance(v, bool) or not isinstance(v, (int, float)):
                if isinstance(v, str):
                    x = numero_da_testo(v)
                    if x is None:
                        return op == "<>"
                    v = x
                else:
                    return op == "<>"
            return {"=": v == n, "<>": v != n, "<": v < n, ">": v > n, "<=": v <= n, ">=": v >= n}[op]
        return numerico
    if op in ("=", "<>"):
        if any(ch in t for ch in "*?~"):
            schema = _jolly(t)
            if op == "=":
                return lambda v: isinstance(v, str) and bool(schema.match(v))
            return lambda v: not (isinstance(v, str) and schema.match(v))
        tl = t.lower()
        if op == "=":
            return lambda v: isinstance(v, str) and v.lower() == tl
        return lambda v: not (isinstance(v, str) and v.lower() == tl)

    def testuale(v: Any) -> bool:
        if not isinstance(v, str):
            return False
        k = confronta(v, t)
        return {"<": k < 0, ">": k > 0, "<=": k <= 0, ">=": k >= 0}[op]
    return testuale


def allinea(*argomenti: Any) -> list[list[Any]]:
    """Valori (piatti, riga per riga) di più intervalli della stessa forma, come in SOMMA.PIÙ.SE.

    Gli intervalli interi (A:A) si tagliano all'area usata più grande tra tutti."""
    h = w = None
    for a in argomenti:
        if isinstance(a, Rif):
            lim = a.limitata()
            h = lim.altezza if h is None else max(h, min(lim.altezza, a.altezza))
            w = lim.larghezza if w is None else max(w, min(lim.larghezza, a.larghezza))
        elif h is None:
            rr = righe_di(a)
            h, w = len(rr), len(rr[0])
    out = []
    for a in argomenti:
        if isinstance(a, Rif):
            x = Rif(a.foglio, a.r1, a.c1, a.r1 + h - 1, a.c1 + w - 1)
            out.append([v for r in x.righe() for v in r])
        else:
            out.append([v for r in righe_di(a) for v in r])
    n = max(len(v) for v in out)
    for v in out:
        if len(v) < n:
            v.extend([None] * (n - len(v)))
    return out


def media(lista: list) -> float:
    if not lista:
        raise ErroreFormula(DIV0)
    return sum(lista) / len(lista)
