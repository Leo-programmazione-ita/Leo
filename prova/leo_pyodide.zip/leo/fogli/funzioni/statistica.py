"""Funzioni statistiche e di conteggio."""

from __future__ import annotations

import math
import statistics
from typing import Any

from ..calcolo import Rif, scalare
from ..valori import DIV0, ND, NUM, VALORE, Errore, ErroreFormula, Matrice, e_numero
from . import funzione
from ._aiuti import (allinea, controlla, criterio, intero, media, num, numeri, righe_di, valori_argomento)
from .matematica import piu_se

C = "Statistica"


def media_lista(l: list) -> float:
    return media(l)


def varianza(l: list, campione: bool = True) -> float:
    n = len(l)
    controlla(n >= (2 if campione else 1), DIV0)
    m = sum(l) / n
    return sum((x - m) ** 2 for x in l) / (n - 1 if campione else n)


def dev_st(l: list, campione: bool = True) -> float:
    return math.sqrt(varianza(l, campione))


@funzione("MEDIA", "AVERAGE", minimo=1, categoria=C, descrizione="Media aritmetica.", sintassi="MEDIA(numero1; [numero2]; ...)")
def f_media(ctx, *a):
    return media(numeri(a))


@funzione("MEDIA.VALORI", "AVERAGEA", minimo=1, categoria=C, descrizione="Media contando testi come 0 e VERO come 1.")
def media_valori(ctx, *a):
    return media(numeri(a, testi_come_zero=True))


@funzione("MIN", "MIN", minimo=1, categoria=C, descrizione="Il numero più piccolo.")
def f_min(ctx, *a):
    l = numeri(a)
    return min(l) if l else 0


@funzione("MAX", "MAX", minimo=1, categoria=C, descrizione="Il numero più grande.")
def f_max(ctx, *a):
    l = numeri(a)
    return max(l) if l else 0


@funzione("MIN.VALORI", "MINA", minimo=1, categoria=C, descrizione="Minimo contando testi come 0.")
def min_valori(ctx, *a):
    l = numeri(a, testi_come_zero=True)
    return min(l) if l else 0


@funzione("MAX.VALORI", "MAXA", minimo=1, categoria=C, descrizione="Massimo contando testi come 0.")
def max_valori(ctx, *a):
    l = numeri(a, testi_come_zero=True)
    return max(l) if l else 0


@funzione("CONTA.NUMERI", "COUNT", alias=("CONTA",), minimo=1, categoria=C, descrizione="Quante celle contengono numeri.")
def conta_numeri(ctx, *a):
    n = 0
    for x in a:
        for v in valori_argomento(x, solo_non_vuoti=True):
            if e_numero(v):
                n += 1
            elif not isinstance(x, (Rif, Matrice)) and isinstance(v, (str, bool)):
                try:
                    num(v)
                    n += 1
                except ErroreFormula:
                    pass
    return n


@funzione("CONTA.VALORI", "COUNTA", minimo=1, categoria=C, descrizione="Quante celle non sono vuote.")
def conta_valori(ctx, *a):
    n = 0
    for x in a:
        for v in valori_argomento(x, solo_non_vuoti=True):
            if v is not None:
                n += 1
    return n


@funzione("CONTA.VUOTE", "COUNTBLANK", minimo=1, massimo=1, categoria=C, descrizione="Quante celle sono vuote.")
def conta_vuote(ctx, a):
    if isinstance(a, Rif):
        piene = sum(1 for v in a.non_vuoti() if v != "")
        return a.altezza * a.larghezza - piene
    return sum(1 for v in valori_argomento(a) if v is None or v == "")


@funzione("CONTA.SE", "COUNTIF", minimo=2, massimo=2, categoria=C,
          descrizione="Conta le celle che rispettano un criterio.", sintassi="CONTA.SE(intervallo; criterio)")
def conta_se(ctx, intervallo, crit):
    prova = criterio(crit)
    if isinstance(intervallo, Rif):
        lim = intervallo.limitata()
        trovate = sum(1 for v in lim.valori() if prova(v))
        if prova(None):     # le celle vuote oltre l'area usata
            trovate += intervallo.altezza * intervallo.larghezza - lim.altezza * lim.larghezza
        return trovate
    return sum(1 for v in valori_argomento(intervallo) if prova(v))


@funzione("CONTA.PIÙ.SE", "COUNTIFS", minimo=2, categoria=C, descrizione="Conta le celle che rispettano più criteri.",
          sintassi="CONTA.PIÙ.SE(intervallo1; criterio1; [intervallo2; criterio2]; ...)")
def conta_piu_se(ctx, *a):
    indici, _ = piu_se(None, a)
    return len(indici)


@funzione("MEDIA.SE", "AVERAGEIF", minimo=2, massimo=3, categoria=C,
          descrizione="Media delle celle che rispettano un criterio.", sintassi="MEDIA.SE(intervallo; criterio; [int_media])")
def media_se(ctx, intervallo, crit, int_media=None):
    prova = criterio(crit)
    valori, corrisp = allinea(intervallo, int_media if int_media is not None else intervallo)
    return media([s for v, s in zip(valori, corrisp) if prova(v) and e_numero(s)])


@funzione("MEDIA.PIÙ.SE", "AVERAGEIFS", minimo=3, categoria=C, descrizione="Media con più criteri.",
          sintassi="MEDIA.PIÙ.SE(int_media; intervallo1; criterio1; ...)")
def media_piu_se(ctx, principale, *a):
    indici, valori = piu_se(principale, a)
    return media([valori[i] for i in indici if e_numero(valori[i])])


@funzione("MAX.PIÙ.SE", "MAXIFS", minimo=3, categoria=C, descrizione="Massimo con più criteri.")
def max_piu_se(ctx, principale, *a):
    indici, valori = piu_se(principale, a)
    l = [valori[i] for i in indici if e_numero(valori[i])]
    return max(l) if l else 0


@funzione("MIN.PIÙ.SE", "MINIFS", minimo=3, categoria=C, descrizione="Minimo con più criteri.")
def min_piu_se(ctx, principale, *a):
    indici, valori = piu_se(principale, a)
    l = [valori[i] for i in indici if e_numero(valori[i])]
    return min(l) if l else 0


@funzione("MEDIANA", "MEDIAN", minimo=1, categoria=C, descrizione="Il valore centrale.")
def mediana(ctx, *a):
    l = numeri(a)
    controlla(bool(l), NUM)
    return statistics.median(l)


@funzione("MODA.SNGL", "MODE.SNGL", alias=("MODA", "MODE"), minimo=1, categoria=C, descrizione="Il valore più frequente.")
def moda(ctx, *a):
    l = numeri(a)
    conteggi: dict = {}
    for x in l:
        conteggi[x] = conteggi.get(x, 0) + 1
    controlla(conteggi and max(conteggi.values()) > 1, ND)
    massimo = max(conteggi.values())
    for x in l:
        if conteggi[x] == massimo:
            return x


@funzione("DEV.ST.C", "STDEV.S", alias=("DEV.ST", "STDEV"), minimo=1, categoria=C, descrizione="Deviazione standard di un campione.")
def dev_st_c(ctx, *a):
    return dev_st(numeri(a), True)


@funzione("DEV.ST.P", "STDEV.P", alias=("DEV.ST.POP", "STDEVP"), minimo=1, categoria=C, descrizione="Deviazione standard della popolazione.")
def dev_st_p(ctx, *a):
    return dev_st(numeri(a), False)


@funzione("VAR.C", "VAR.S", alias=("VAR",), minimo=1, categoria=C, descrizione="Varianza di un campione.")
def var_c(ctx, *a):
    return varianza(numeri(a), True)


@funzione("VAR.P", "VAR.P", alias=("VAR.POP", "VARP"), minimo=1, categoria=C, descrizione="Varianza della popolazione.")
def var_p(ctx, *a):
    return varianza(numeri(a), False)


@funzione("GRANDE", "LARGE", minimo=2, massimo=2, categoria=C, descrizione="Il k-esimo valore più grande.",
          sintassi="GRANDE(matrice; k)")
def grande(ctx, m, k):
    l = sorted(numeri([m]), reverse=True)
    k = intero(k)
    controlla(1 <= k <= len(l), NUM)
    return l[k - 1]


@funzione("PICCOLO", "SMALL", minimo=2, massimo=2, categoria=C, descrizione="Il k-esimo valore più piccolo.")
def piccolo(ctx, m, k):
    l = sorted(numeri([m]))
    k = intero(k)
    controlla(1 <= k <= len(l), NUM)
    return l[k - 1]


@funzione("RANGO.UG", "RANK.EQ", alias=("RANGO", "RANK"), minimo=2, massimo=3, elementare=1, categoria=C,
          descrizione="Posizione di un numero in classifica.", sintassi="RANGO.UG(numero; rif; [ordine])")
def rango(ctx, x, rif, ordine=None):
    x = num(x)
    l = numeri([rif])
    controlla(x in l, ND)
    crescente = ordine is not None and num(ordine) != 0
    if crescente:
        return 1 + sum(1 for v in l if v < x)
    return 1 + sum(1 for v in l if v > x)


@funzione("RANGO.MEDIA", "RANK.AVG", minimo=2, massimo=3, elementare=1, categoria=C, descrizione="Posizione media in caso di pari merito.")
def rango_media(ctx, x, rif, ordine=None):
    x = num(x)
    l = numeri([rif])
    controlla(x in l, ND)
    crescente = ordine is not None and num(ordine) != 0
    prima = sum(1 for v in l if (v < x if crescente else v > x))
    uguali = sum(1 for v in l if v == x)
    return prima + (uguali + 1) / 2


def _percentile(l: list, p: float, esclusivo: bool = False) -> float:
    controlla(bool(l), NUM)
    l = sorted(l)
    n = len(l)
    if esclusivo:
        controlla(0 < p < 1, NUM)
        h = (n + 1) * p - 1
        controlla(0 <= h <= n - 1, NUM)
    else:
        controlla(0 <= p <= 1, NUM)
        h = (n - 1) * p
    i = int(math.floor(h))
    if i + 1 >= n:
        return l[-1]
    return l[i] + (h - i) * (l[i + 1] - l[i])


@funzione("PERCENTILE.INC", "PERCENTILE.INC", alias=("PERCENTILE",), minimo=2, massimo=2, categoria=C,
          descrizione="Il k-esimo percentile (k tra 0 e 1).")
def percentile(ctx, m, k):
    return _percentile(numeri([m]), num(k))


@funzione("PERCENTILE.ESC", "PERCENTILE.EXC", minimo=2, massimo=2, categoria=C, descrizione="Percentile esclusivo.")
def percentile_esc(ctx, m, k):
    return _percentile(numeri([m]), num(k), True)


@funzione("QUARTILE.INC", "QUARTILE.INC", alias=("QUARTILE",), minimo=2, massimo=2, categoria=C, descrizione="Quartile (0-4).")
def quartile(ctx, m, q):
    q = intero(q)
    controlla(0 <= q <= 4, NUM)
    return _percentile(numeri([m]), q / 4)


def _coppie_xy(y: Any, x: Any) -> tuple[list, list]:
    vy, vx = allinea(y, x)
    xs, ys = [], []
    for a, b in zip(vx, vy):
        if isinstance(a, Errore) or isinstance(b, Errore):
            raise ErroreFormula((a if isinstance(a, Errore) else b).codice)
        if e_numero(a) and e_numero(b):
            xs.append(a)
            ys.append(b)
    return xs, ys


def _regressione(y: Any, x: Any) -> tuple[float, float, list, list]:
    xs, ys = _coppie_xy(y, x)
    n = len(xs)
    controlla(n >= 2, DIV0)
    mx, my = sum(xs) / n, sum(ys) / n
    sxx = sum((a - mx) ** 2 for a in xs)
    controlla(sxx != 0, DIV0)
    sxy = sum((a - mx) * (b - my) for a, b in zip(xs, ys))
    b = sxy / sxx
    return b, my - b * mx, xs, ys


@funzione("PENDENZA", "SLOPE", minimo=2, massimo=2, categoria=C, descrizione="Pendenza della retta di regressione.",
          sintassi="PENDENZA(y_nota; x_nota)")
def pendenza(ctx, y, x):
    return _regressione(y, x)[0]


@funzione("INTERCETTA", "INTERCEPT", minimo=2, massimo=2, categoria=C, descrizione="Intercetta della retta di regressione.")
def intercetta(ctx, y, x):
    return _regressione(y, x)[1]


@funzione("PREVISIONE.LINEARE", "FORECAST.LINEAR", alias=("PREVISIONE", "FORECAST"), minimo=3, massimo=3,
          elementare=1, categoria=C, descrizione="Previsione lineare di y per un nuovo x.",
          sintassi="PREVISIONE.LINEARE(x; y_nota; x_nota)")
def previsione(ctx, x, y, xs):
    b, a, _, _ = _regressione(y, xs)
    return a + b * num(x)


@funzione("TENDENZA", "TREND", minimo=1, massimo=3, categoria=C, descrizione="Valori sulla retta di regressione.")
def tendenza(ctx, y, x=None, nuovi=None):
    righe_y = righe_di(y)
    if x is None:
        n = len([v for r in righe_y for v in r])
        x = Matrice([[i + 1] for i in range(n)])
    b, a, xs, _ = _regressione(y, x)
    nx = righe_di(nuovi) if nuovi is not None else righe_di(x)
    return Matrice([[a + b * num(v) for v in r] for r in nx])


@funzione("CORRELAZIONE", "CORREL", minimo=2, massimo=2, categoria=C, descrizione="Coefficiente di correlazione.")
def correlazione(ctx, a, b):
    xs, ys = _coppie_xy(a, b)
    n = len(xs)
    controlla(n >= 2, DIV0)
    mx, my = sum(xs) / n, sum(ys) / n
    sx = math.sqrt(sum((v - mx) ** 2 for v in xs))
    sy = math.sqrt(sum((v - my) ** 2 for v in ys))
    controlla(sx and sy, DIV0)
    return sum((p - mx) * (q - my) for p, q in zip(xs, ys)) / (sx * sy)


@funzione("RQ", "RSQ", minimo=2, massimo=2, categoria=C, descrizione="Quadrato del coefficiente di correlazione.")
def rq(ctx, y, x):
    return correlazione(ctx, y, x) ** 2


@funzione("COVARIANZA.C", "COVARIANCE.S", minimo=2, massimo=2, categoria=C, descrizione="Covarianza di un campione.")
def covarianza_c(ctx, a, b):
    xs, ys = _coppie_xy(a, b)
    n = len(xs)
    controlla(n >= 2, DIV0)
    mx, my = sum(xs) / n, sum(ys) / n
    return sum((p - mx) * (q - my) for p, q in zip(xs, ys)) / (n - 1)


@funzione("COVARIANZA.P", "COVARIANCE.P", minimo=2, massimo=2, categoria=C, descrizione="Covarianza della popolazione.")
def covarianza_p(ctx, a, b):
    xs, ys = _coppie_xy(a, b)
    n = len(xs)
    controlla(n >= 1, DIV0)
    mx, my = sum(xs) / n, sum(ys) / n
    return sum((p - mx) * (q - my) for p, q in zip(xs, ys)) / n


@funzione("MEDIA.GEOMETRICA", "GEOMEAN", minimo=1, categoria=C, descrizione="Media geometrica.")
def media_geometrica(ctx, *a):
    l = numeri(a)
    controlla(l and all(x > 0 for x in l), NUM)
    return math.exp(sum(math.log(x) for x in l) / len(l))


@funzione("MEDIA.ARMONICA", "HARMEAN", minimo=1, categoria=C, descrizione="Media armonica.")
def media_armonica(ctx, *a):
    l = numeri(a)
    controlla(l and all(x > 0 for x in l), NUM)
    return len(l) / sum(1 / x for x in l)


@funzione("NORMALIZZA", "STANDARDIZE", minimo=3, massimo=3, elementare=3, categoria=C, descrizione="Valore standardizzato (z).")
def normalizza(ctx, x, m, s):
    s = num(s)
    controlla(s > 0, NUM)
    return (num(x) - num(m)) / s


@funzione("DISTRIB.NORM.N", "NORM.DIST", minimo=4, massimo=4, elementare=3, categoria=C, descrizione="Distribuzione normale.")
def distrib_norm(ctx, x, m, s, cumulativa):
    from ._aiuti import logico
    x, m, s = num(x), num(m), num(s)
    controlla(s > 0, NUM)
    d = statistics.NormalDist(m, s)
    return d.cdf(x) if logico(cumulativa) else d.pdf(x)


@funzione("INV.NORM.N", "NORM.INV", minimo=3, massimo=3, elementare=3, categoria=C, descrizione="Inversa della normale.")
def inv_norm(ctx, p, m, s):
    p, m, s = num(p), num(m), num(s)
    controlla(0 < p < 1 and s > 0, NUM)
    return statistics.NormalDist(m, s).inv_cdf(p)


@funzione("DISTRIB.NORM.ST.N", "NORM.S.DIST", minimo=2, massimo=2, elementare=1, categoria=C, descrizione="Normale standard.")
def distrib_norm_st(ctx, z, cumulativa):
    from ._aiuti import logico
    d = statistics.NormalDist()
    z = num(z)
    return d.cdf(z) if logico(cumulativa) else d.pdf(z)


@funzione("INV.NORM.S", "NORM.S.INV", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Inversa della normale standard.")
def inv_norm_s(ctx, p):
    p = num(p)
    controlla(0 < p < 1, NUM)
    return statistics.NormalDist().inv_cdf(p)


@funzione("FREQUENZA", "FREQUENCY", minimo=2, massimo=2, categoria=C, descrizione="Quanti valori cadono in ogni classe.",
          sintassi="FREQUENZA(dati; classi)")
def frequenza(ctx, dati, classi):
    d = numeri([dati])
    c = sorted(numeri([classi]))
    out = []
    prec = None
    for lim in c:
        out.append([sum(1 for x in d if (prec is None or x > prec) and x <= lim)])
        prec = lim
    out.append([sum(1 for x in d if prec is None or x > prec)])
    return Matrice(out)
