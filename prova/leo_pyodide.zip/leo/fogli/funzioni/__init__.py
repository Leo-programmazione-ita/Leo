"""Le funzioni delle formule di Leo Fogli (nomi italiani di Excel, con i nomi inglesi come alias).

Ogni funzione si registra con il decoratore :func:`funzione`::

    @funzione("SOMMA", "SUM", minimo=1, categoria="Matematica",
              descrizione="Somma i numeri", sintassi="SOMMA(numero1; [numero2]; ...)")
    def somma(ctx, *argomenti): ...

Gli argomenti arrivano già calcolati: numeri, testi, logici, ``None`` (vuoto),
``Rif`` (riferimenti a celle) o ``Matrice``. Con ``pigra=True`` arrivano invece
come funzioni senza argomenti da chiamare solo se servono (SE, SE.ERRORE...).
Con ``elementare=N`` i primi N argomenti, se sono intervalli, si applicano a ogni
elemento e il risultato è una matrice (=MAIUSC(A1:A5)).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

__all__ = ["FUNZIONI", "funzione", "nome_canonico", "nome_inglese", "InfoFunzione", "elenco", "categorie"]


@dataclass
class InfoFunzione:
    nome: str
    inglese: str
    fn: Callable
    minimo: int = 0
    massimo: int = 255
    pigra: bool = False
    volatile: bool = False
    dinamica: bool = False
    elementare: int = 0
    categoria: str = ""
    descrizione: str = ""
    sintassi: str = ""
    alias: tuple[str, ...] = field(default_factory=tuple)


FUNZIONI: dict[str, InfoFunzione] = {}
_ALIAS: dict[str, str] = {}
_INGLESE: dict[str, str] = {}


def funzione(nome: str, inglese: str = "", *, alias: tuple[str, ...] = (), minimo: int = 0, massimo: int = 255,
             pigra: bool = False, volatile: bool = False, dinamica: bool = False, elementare: int = 0,
             categoria: str = "", descrizione: str = "", sintassi: str = "") -> Callable[[Callable], Callable]:
    def registra(fn: Callable) -> Callable:
        info = InfoFunzione(nome, inglese or nome, fn, minimo, massimo, pigra, volatile, dinamica, elementare,
                            categoria, descrizione, sintassi or f"{nome}(…)", alias)
        FUNZIONI[nome] = info
        _INGLESE[nome] = inglese or nome
        for a in (inglese, *alias):
            if a:
                _ALIAS.setdefault(a.upper(), nome)
        # forma senza accenti (SOMMA.PIU.SE) e con il prefisso dei file nuovi (_xlfn.)
        senza = (nome.replace("Ù", "U").replace("À", "A").replace("È", "E").replace("Ì", "I")
                 .replace("Ò", "O"))
        if senza != nome:
            _ALIAS.setdefault(senza, nome)
        return fn
    return registra


def nome_canonico(nome: str) -> str:
    n = nome.upper()
    if n.startswith("_XLFN."):
        n = n[6:]
    if n.startswith("_XLWS."):
        n = n[6:]
    if n in FUNZIONI:
        return n
    return _ALIAS.get(n, n)


def nome_inglese(nome: str) -> str:
    n = _INGLESE.get(nome, nome)
    return n


def elenco() -> list[InfoFunzione]:
    return sorted(FUNZIONI.values(), key=lambda i: i.nome)


def categorie() -> dict[str, list[InfoFunzione]]:
    out: dict[str, list[InfoFunzione]] = {}
    for i in elenco():
        out.setdefault(i.categoria or "Altre", []).append(i)
    return out


# registrazione: l'ordine non conta
from . import matematica, statistica, logica, testo, date, ricerca, informazioni, finanza, italia, matrici  # noqa: E402,F401
