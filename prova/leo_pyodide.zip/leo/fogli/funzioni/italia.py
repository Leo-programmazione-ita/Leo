"""Funzioni "all'italiana" che Excel non ha: IVA, festività, codice fiscale, partita IVA, IBAN,
importi in lettere, giorni lavorativi con le feste italiane."""

from __future__ import annotations

import datetime as _dt
import re

from ..calcolo import scalare
from ..valori import NUM, VALORE, ErroreFormula
from . import funzione
from ._aiuti import controlla, intero, num, num_opzionale, numeri, testo
from .date import a_data, conta_lavorativi, da_data, sposta_lavorativi

C = "Italia"


# ---------------------------------------------------------------------------
# Feste
# ---------------------------------------------------------------------------

def pasqua(anno: int) -> _dt.date:
    a = anno % 19
    b, c = divmod(anno, 100)
    d, e = divmod(b, 4)
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = divmod(c, 4)
    l_ = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l_) // 451
    mese = (h + l_ - 7 * m + 114) // 31
    giorno = (h + l_ - 7 * m + 114) % 31 + 1
    return _dt.date(anno, mese, giorno)


def festivita(anno: int) -> dict[_dt.date, str]:
    p = pasqua(anno)
    feste = {
        _dt.date(anno, 1, 1): "Capodanno",
        _dt.date(anno, 1, 6): "Epifania",
        p: "Pasqua",
        p + _dt.timedelta(days=1): "Lunedì dell'Angelo",
        _dt.date(anno, 4, 25): "Festa della Liberazione",
        _dt.date(anno, 5, 1): "Festa del Lavoro",
        _dt.date(anno, 6, 2): "Festa della Repubblica",
        _dt.date(anno, 8, 15): "Ferragosto",
        _dt.date(anno, 11, 1): "Ognissanti",
        _dt.date(anno, 12, 8): "Immacolata Concezione",
        _dt.date(anno, 12, 25): "Natale",
        _dt.date(anno, 12, 26): "Santo Stefano",
    }
    if anno >= 2026:     # festa nazionale di San Francesco d'Assisi (reintrodotta dal 2026)
        feste[_dt.date(anno, 10, 4)] = "San Francesco d'Assisi"
    return feste


def _patrono(arg) -> tuple[int, int] | None:
    if arg is None:
        return None
    v = scalare(arg)
    if isinstance(v, str) and re.fullmatch(r"\s*\d{1,2}/\d{1,2}\s*", v):
        g, m = v.strip().split("/")
        return int(m), int(g)
    d = a_data(v)
    return d.month, d.day


def festivi_italiani(da: _dt.date, a: _dt.date, patrono: tuple[int, int] | None = None) -> set[int]:
    out = set()
    for anno in range(min(da.year, a.year), max(da.year, a.year) + 1):
        for d in festivita(anno):
            out.add(da_data(d))
        if patrono:
            try:
                out.add(da_data(_dt.date(anno, patrono[0], patrono[1])))
            except ValueError:
                pass
    return out


@funzione("FESTIVO", "FESTIVO", minimo=1, massimo=2, elementare=1, categoria=C,
          descrizione="VERO se la data è una festa nazionale italiana (o la domenica, o il patrono indicato).",
          sintassi="FESTIVO(data; [patrono \"gg/mm\"])")
def festivo(ctx, d, patrono=None):
    x = a_data(d)
    p = _patrono(patrono)
    return x.weekday() == 6 or x in festivita(x.year) or (p is not None and (x.month, x.day) == p)


@funzione("NOME.FESTIVITÀ", "NOME.FESTIVITA", minimo=1, massimo=1, elementare=1, categoria=C,
          descrizione="Il nome della festa italiana di quel giorno (vuoto se non è festa).")
def nome_festivita(ctx, d):
    x = a_data(d)
    return festivita(x.year).get(x, "")


@funzione("PASQUA", "PASQUA", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="La data di Pasqua di un anno.")
def f_pasqua(ctx, anno):
    a = intero(anno)
    controlla(1900 <= a <= 9999, NUM)
    return da_data(pasqua(a))


@funzione("GIORNI.LAVORATIVI.IT", "GIORNI.LAVORATIVI.IT", minimo=2, massimo=4, categoria=C,
          descrizione="Giorni lavorativi tra due date, già senza sabati, domeniche e feste italiane (anche Pasquetta).",
          sintassi="GIORNI.LAVORATIVI.IT(inizio; fine; [patrono \"gg/mm\"]; [altre_festività])")
def giorni_lavorativi_it(ctx, inizio, fine, patrono=None, altre=None):
    a, b = a_data(inizio), a_data(fine)
    feste = festivi_italiani(a, b, _patrono(patrono)) | {int(x) for x in numeri([altre])} if altre is not None \
        else festivi_italiani(a, b, _patrono(patrono))
    return conta_lavorativi(a, b, feste, {5, 6})


@funzione("GIORNO.LAVORATIVO.IT", "GIORNO.LAVORATIVO.IT", minimo=2, massimo=3, categoria=C,
          descrizione="La data dopo n giorni lavorativi italiani (senza weekend e feste).",
          sintassi="GIORNO.LAVORATIVO.IT(inizio; giorni; [patrono])")
def giorno_lavorativo_it(ctx, inizio, giorni, patrono=None):
    a = a_data(inizio)
    n = intero(giorni)
    fine = a + _dt.timedelta(days=int(n * 1.6) + 30 * (1 if n >= 0 else -1))
    feste = festivi_italiani(min(a, fine), max(a, fine), _patrono(patrono))
    return da_data(sposta_lavorativi(a, n, feste, {5, 6}))


# ---------------------------------------------------------------------------
# IVA e ritenute
# ---------------------------------------------------------------------------

def _aliquota(a) -> float:
    x = num_opzionale(a, 0.22)
    return x / 100 if x >= 1 else x


@funzione("IVA", "IVA", minimo=1, massimo=2, elementare=2, categoria=C,
          descrizione="L'IVA su un imponibile (aliquota 22% se non indicata; vanno bene 22 o 22%).",
          sintassi="IVA(imponibile; [aliquota])")
def iva(ctx, imponibile, aliquota=None):
    return round(num(imponibile) * _aliquota(aliquota), 10)


@funzione("LORDO.IVA", "LORDO.IVA", minimo=1, massimo=2, elementare=2, categoria=C,
          descrizione="Imponibile più IVA.", sintassi="LORDO.IVA(imponibile; [aliquota])")
def lordo_iva(ctx, imponibile, aliquota=None):
    return round(num(imponibile) * (1 + _aliquota(aliquota)), 10)


@funzione("SCORPORO.IVA", "SCORPORO.IVA", minimo=1, massimo=2, elementare=2, categoria=C,
          descrizione="L'imponibile contenuto in un importo IVA compresa.", sintassi="SCORPORO.IVA(importo_lordo; [aliquota])")
def scorporo_iva(ctx, lordo, aliquota=None):
    return round(num(lordo) / (1 + _aliquota(aliquota)), 10)


@funzione("RITENUTA", "RITENUTA", minimo=1, massimo=2, elementare=2, categoria=C,
          descrizione="La ritenuta d'acconto (20% se non indicata).", sintassi="RITENUTA(imponibile; [aliquota])")
def ritenuta(ctx, imponibile, aliquota=None):
    x = num_opzionale(aliquota, 0.20)
    x = x / 100 if x >= 1 else x
    return round(num(imponibile) * x, 10)


# ---------------------------------------------------------------------------
# Codici
# ---------------------------------------------------------------------------

_DISPARI = {**{str(i): v for i, v in enumerate([1, 0, 5, 7, 9, 13, 15, 17, 19, 21])},
            **dict(zip("ABCDEFGHIJKLMNOPQRSTUVWXYZ",
                       [1, 0, 5, 7, 9, 13, 15, 17, 19, 21, 2, 4, 18, 20, 11, 3, 6, 8, 12, 14, 16, 10, 22, 25, 24, 23]))}
_PARI = {**{str(i): i for i in range(10)}, **{ch: i for i, ch in enumerate("ABCDEFGHIJKLMNOPQRSTUVWXYZ")}}
_RE_CF = re.compile(r"^[A-Z]{6}[0-9LMNPQRSTUV]{2}[ABCDEHLMPRST][0-9LMNPQRSTUV]{2}[A-Z][0-9LMNPQRSTUV]{3}[A-Z]$")


def cf_valido(cf: str) -> bool:
    cf = cf.strip().upper()
    if not _RE_CF.match(cf):
        return False
    s = sum(_DISPARI[ch] if i % 2 == 0 else _PARI[ch] for i, ch in enumerate(cf[:15]))
    return chr(65 + s % 26) == cf[15]


@funzione("CODICE.FISCALE.VALIDO", "CODICE.FISCALE.VALIDO", minimo=1, massimo=1, elementare=1, categoria=C,
          descrizione="VERO se il codice fiscale è scritto bene (con il carattere di controllo giusto).")
def codice_fiscale_valido(ctx, t):
    return cf_valido(testo(t))


@funzione("CODICE.FISCALE.NASCITA", "CODICE.FISCALE.NASCITA", minimo=1, massimo=1, elementare=1, categoria=C,
          descrizione="La data di nascita contenuta nel codice fiscale.")
def codice_fiscale_nascita(ctx, t):
    cf = testo(t).strip().upper()
    controlla(cf_valido(cf), VALORE)
    om = {ch: str(i) for i, ch in enumerate("LMNPQRSTUV")}
    norm = "".join(om.get(ch, ch) if i in (6, 7, 9, 10) else ch for i, ch in enumerate(cf))
    aa, mese, gg = int(norm[6:8]), "ABCDEHLMPRST".index(norm[8]) + 1, int(norm[9:11]) % 40
    oggi = _dt.date.today().year % 100
    anno = 2000 + aa if aa <= oggi else 1900 + aa
    return da_data(_dt.date(anno, mese, gg))


@funzione("CODICE.FISCALE.SESSO", "CODICE.FISCALE.SESSO", minimo=1, massimo=1, elementare=1, categoria=C,
          descrizione="\"M\" o \"F\" secondo il codice fiscale.")
def codice_fiscale_sesso(ctx, t):
    cf = testo(t).strip().upper()
    controlla(cf_valido(cf), VALORE)
    om = {ch: str(i) for i, ch in enumerate("LMNPQRSTUV")}
    gg = int("".join(om.get(ch, ch) for ch in cf[9:11]))
    return "F" if gg > 40 else "M"


def piva_valida(p: str) -> bool:
    p = re.sub(r"\s", "", p)
    if p.upper().startswith("IT"):
        p = p[2:]
    if not re.fullmatch(r"\d{11}", p):
        return False
    s = 0
    for i, ch in enumerate(p[:10]):
        n = int(ch)
        if i % 2 == 1:
            n *= 2
            if n > 9:
                n -= 9
        s += n
    return (10 - s % 10) % 10 == int(p[10])


@funzione("PARTITA.IVA.VALIDA", "PARTITA.IVA.VALIDA", minimo=1, massimo=1, elementare=1, categoria=C,
          descrizione="VERO se la partita IVA italiana è scritta bene (cifra di controllo).")
def partita_iva_valida(ctx, t):
    from ..calcolo import scalare as _sc
    v = _sc(t)
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return piva_valida(str(int(v)).zfill(11))     # lo zero iniziale perso se scritta come numero
    return piva_valida(testo(t))


def iban_valido(t: str) -> bool:
    s = re.sub(r"\s", "", t).upper()
    if not re.fullmatch(r"[A-Z]{2}\d{2}[A-Z0-9]{10,30}", s):
        return False
    if s.startswith("IT") and len(s) != 27:
        return False
    r = s[4:] + s[:4]
    n = "".join(str(int(ch, 36)) for ch in r)
    return int(n) % 97 == 1


@funzione("IBAN.VALIDO", "IBAN.VALIDO", minimo=1, massimo=1, elementare=1, categoria=C,
          descrizione="VERO se l'IBAN è scritto bene (controllo internazionale).")
def f_iban_valido(ctx, t):
    return iban_valido(testo(t))


# ---------------------------------------------------------------------------
# Numeri in lettere
# ---------------------------------------------------------------------------

_UNITA = ["zero", "uno", "due", "tre", "quattro", "cinque", "sei", "sette", "otto", "nove", "dieci", "undici",
          "dodici", "tredici", "quattordici", "quindici", "sedici", "diciassette", "diciotto", "diciannove"]
_DECINE = ["", "", "venti", "trenta", "quaranta", "cinquanta", "sessanta", "settanta", "ottanta", "novanta"]


def _fino_a_mille(n: int) -> str:
    if n < 20:
        return _UNITA[n] if n else ""
    if n < 100:
        d, u = divmod(n, 10)
        base = _DECINE[d]
        if u in (1, 8):
            base = base[:-1]
        return base + (("tré" if u == 3 else _UNITA[u]) if u else "")
    c, resto = divmod(n, 100)
    testa = "cento" if c == 1 else _UNITA[c] + "cento"
    if resto // 10 == 8:
        testa = testa[:-1]       # centottanta
    return testa + _fino_a_mille(resto)


def numero_in_lettere(n: int) -> str:
    if n == 0:
        return "zero"
    if n < 0:
        return "meno " + numero_in_lettere(-n)
    parti = []
    for valore, singolare, plurale in ((10 ** 9, "unmiliardo", "miliardi"), (10 ** 6, "unmilione", "milioni"),
                                       (1000, "mille", "mila")):
        q, n = divmod(n, valore)
        if q:
            if q == 1:
                parti.append(singolare)
            else:
                parti.append(numero_in_lettere(q) + plurale)
    if n:
        parti.append(_fino_a_mille(n))
    return "".join(parti)


@funzione("NUMERO.IN.LETTERE", "NUMERO.IN.LETTERE", minimo=1, massimo=1, elementare=1, categoria=C,
          descrizione="Il numero intero scritto in lettere (1234 → milleduecentotrentaquattro).")
def f_numero_in_lettere(ctx, x):
    n = intero(x)
    controlla(abs(n) < 10 ** 12, NUM)
    return numero_in_lettere(n)


@funzione("IMPORTO.IN.LETTERE", "IMPORTO.IN.LETTERE", minimo=1, massimo=1, elementare=1, categoria=C,
          descrizione="L'importo come sugli assegni: 1234,5 → milleduecentotrentaquattro/50.")
def importo_in_lettere(ctx, x):
    v = round(num(x), 2)
    controlla(v >= 0 and v < 10 ** 12, NUM)
    euro = int(v)
    cent = int(round((v - euro) * 100))
    return f"{numero_in_lettere(euro)}/{cent:02d}"
