"""Funzioni matematiche e di somma."""

from __future__ import annotations

import math
import random
from decimal import ROUND_HALF_UP, Decimal
from functools import reduce
from typing import Any

from ..calcolo import Rif, scalare
from ..valori import DIV0, NUM, VALORE, Errore, ErroreFormula, Matrice, e_numero
from . import funzione
from ._aiuti import allinea, controlla, criterio, dimensioni, intero, num, num_opzionale, numeri, righe_di, valori_argomento

C = "Matematica"


def arrotonda_excel(x: float, cifre: int) -> float | int:
    if not math.isfinite(x):
        raise ErroreFormula(NUM)
    d = Decimal(repr(float(x))).quantize(Decimal(1).scaleb(-cifre), rounding=ROUND_HALF_UP) if cifre >= 0 else \
        (Decimal(repr(float(x))) / Decimal(10) ** (-cifre)).quantize(Decimal(1), rounding=ROUND_HALF_UP) * Decimal(10) ** (-cifre)
    r = float(d)
    return int(r) if r.is_integer() and abs(r) < 1e15 else r


@funzione("SOMMA", "SUM", minimo=1, categoria=C, descrizione="Somma i numeri (negli intervalli salta testi e celle vuote).",
          sintassi="SOMMA(numero1; [numero2]; ...)")
def somma(ctx, *a):
    return sum(numeri(a))


@funzione("PRODOTTO", "PRODUCT", minimo=1, categoria=C, descrizione="Moltiplica tutti i numeri.",
          sintassi="PRODOTTO(numero1; [numero2]; ...)")
def prodotto(ctx, *a):
    l = numeri(a)
    return reduce(lambda x, y: x * y, l, 1) if l else 0


@funzione("SOMMA.Q", "SUMSQ", minimo=1, categoria=C, descrizione="Somma dei quadrati.")
def somma_q(ctx, *a):
    return sum(x * x for x in numeri(a))


@funzione("ARROTONDA", "ROUND", minimo=1, massimo=2, elementare=2, categoria=C,
          descrizione="Arrotonda a un numero di cifre (le metà lontano da zero).", sintassi="ARROTONDA(numero; [cifre])")
def arrotonda(ctx, x, cifre=None):
    return arrotonda_excel(num(x), intero(cifre) if cifre is not None else 0)


def _arr_direzione(x: float, cifre: int, su: bool) -> float | int:
    f = 10 ** cifre
    y = abs(x) * f
    y = math.ceil(y - 1e-9) if su else math.floor(y + 1e-9)
    r = math.copysign(y / f, x)
    return int(r) if float(r).is_integer() and abs(r) < 1e15 else r


@funzione("ARROTONDA.PER.ECC", "ROUNDUP", minimo=1, massimo=2, elementare=2, categoria=C,
          descrizione="Arrotonda per eccesso (lontano da zero).")
def arrotonda_su(ctx, x, cifre=None):
    return _arr_direzione(num(x), intero(cifre) if cifre is not None else 0, True)


@funzione("ARROTONDA.PER.DIF", "ROUNDDOWN", minimo=1, massimo=2, elementare=2, categoria=C,
          descrizione="Arrotonda per difetto (verso zero).")
def arrotonda_giu(ctx, x, cifre=None):
    return _arr_direzione(num(x), intero(cifre) if cifre is not None else 0, False)


@funzione("TRONCA", "TRUNC", minimo=1, massimo=2, elementare=2, categoria=C, descrizione="Tronca le cifre decimali.")
def tronca(ctx, x, cifre=None):
    return _arr_direzione(num(x), intero(cifre) if cifre is not None else 0, False)


@funzione("ARROTONDA.MULTIPLO", "MROUND", minimo=2, massimo=2, elementare=2, categoria=C,
          descrizione="Arrotonda al multiplo più vicino.")
def arrotonda_multiplo(ctx, x, m):
    x, m = num(x), num(m)
    if m == 0:
        return 0
    controlla(x * m >= 0, NUM)
    q = abs(x / m)
    return arrotonda_excel(math.copysign(math.floor(q + 0.5 + 1e-12), x) * abs(m), 10)


@funzione("ARROTONDA.ECCESSO", "CEILING", alias=("ARROTONDA.ECCESSO.MAT", "CEILING.MATH", "ISO.CEILING"),
          minimo=1, massimo=3, elementare=2, categoria=C, descrizione="Arrotonda per eccesso al multiplo indicato.")
def eccesso(ctx, x, m=None, modo=None):
    x = num(x)
    m = num_opzionale(m, 1)
    if m == 0:
        return 0
    m = abs(m)
    if x < 0 and modo is not None and num(modo) != 0:
        return arrotonda_excel(-math.ceil(-x / m - 1e-12) * m, 10)
    return arrotonda_excel(math.ceil(x / m - 1e-12) * m, 10)


@funzione("ARROTONDA.DIFETTO", "FLOOR", alias=("ARROTONDA.DIFETTO.MAT", "FLOOR.MATH"), minimo=1, massimo=3,
          elementare=2, categoria=C, descrizione="Arrotonda per difetto al multiplo indicato.")
def difetto(ctx, x, m=None, modo=None):
    x = num(x)
    m = num_opzionale(m, 1)
    if m == 0:
        return 0
    m = abs(m)
    if x < 0 and modo is not None and num(modo) != 0:
        return arrotonda_excel(-math.floor(-x / m + 1e-12) * m, 10)
    return arrotonda_excel(math.floor(x / m + 1e-12) * m, 10)


@funzione("INT", "INT", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Parte intera (per difetto).")
def f_int(ctx, x):
    return int(math.floor(num(x)))


@funzione("ASS", "ABS", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Valore assoluto.")
def ass(ctx, x):
    return abs(num(x))


@funzione("SEGNO", "SIGN", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="1, 0 o -1 secondo il segno.")
def segno(ctx, x):
    x = num(x)
    return (x > 0) - (x < 0)


@funzione("RADQ", "SQRT", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Radice quadrata.")
def radq(ctx, x):
    x = num(x)
    controlla(x >= 0, NUM)
    return math.sqrt(x)


@funzione("POTENZA", "POWER", minimo=2, massimo=2, elementare=2, categoria=C, descrizione="Elevamento a potenza.")
def potenza(ctx, x, y):
    from ..calcolo import _potenza
    return _potenza(num(x), num(y))


@funzione("RESTO", "MOD", minimo=2, massimo=2, elementare=2, categoria=C, descrizione="Resto della divisione (con il segno del divisore).")
def resto(ctx, x, d):
    x, d = num(x), num(d)
    controlla(d != 0, DIV0)
    r = x - d * math.floor(x / d)
    return int(r) if float(r).is_integer() else r


@funzione("QUOZIENTE", "QUOTIENT", minimo=2, massimo=2, elementare=2, categoria=C, descrizione="Parte intera della divisione.")
def quoziente(ctx, x, d):
    x, d = num(x), num(d)
    controlla(d != 0, DIV0)
    return int(x / d)


@funzione("EXP", "EXP", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="e elevato al numero.")
def f_exp(ctx, x):
    return math.exp(num(x))


@funzione("LN", "LN", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Logaritmo naturale.")
def ln(ctx, x):
    x = num(x)
    controlla(x > 0, NUM)
    return math.log(x)


@funzione("LOG", "LOG", minimo=1, massimo=2, elementare=2, categoria=C, descrizione="Logaritmo (base 10 se non indicata).")
def f_log(ctx, x, base=None):
    x = num(x)
    b = num_opzionale(base, 10)
    controlla(x > 0 and b > 0 and b != 1, NUM)
    return math.log(x, b)


@funzione("LOG10", "LOG10", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Logaritmo in base 10.")
def log10(ctx, x):
    x = num(x)
    controlla(x > 0, NUM)
    return math.log10(x)


@funzione("PI.GRECO", "PI", minimo=0, massimo=0, categoria=C, descrizione="Il numero π.")
def pi_greco(ctx):
    return math.pi


for _it, _en, _f in (("SEN", "SIN", math.sin), ("COS", "COS", math.cos), ("TAN", "TAN", math.tan),
                     ("ARCSEN", "ASIN", math.asin), ("ARCCOS", "ACOS", math.acos), ("ARCTAN", "ATAN", math.atan),
                     ("SENH", "SINH", math.sinh), ("COSH", "COSH", math.cosh), ("TANH", "TANH", math.tanh),
                     ("GRADI", "DEGREES", math.degrees), ("RADIANTI", "RADIANS", math.radians)):
    def _crea(f):
        def g(ctx, x):
            try:
                return f(num(x))
            except ValueError:
                raise ErroreFormula(NUM)
        return g
    funzione(_it, _en, minimo=1, massimo=1, elementare=1, categoria=C, descrizione=f"Funzione {_it.lower()}.")(_crea(_f))


@funzione("ARCTAN.2", "ATAN2", minimo=2, massimo=2, elementare=2, categoria=C, descrizione="Arcotangente da x e y.")
def arctan2(ctx, x, y):
    x, y = num(x), num(y)
    controlla(x != 0 or y != 0, DIV0)
    return math.atan2(y, x)


@funzione("FATTORIALE", "FACT", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Fattoriale n!.")
def fattoriale(ctx, x):
    n = int(num(x))
    controlla(0 <= n <= 170, NUM)
    return math.factorial(n)


@funzione("COMBINAZIONE", "COMBIN", minimo=2, massimo=2, elementare=2, categoria=C, descrizione="Combinazioni di n elementi a k a k.")
def combinazione(ctx, n, k):
    n, k = int(num(n)), int(num(k))
    controlla(0 <= k <= n, NUM)
    return math.comb(n, k)


@funzione("PERMUTAZIONE", "PERMUT", minimo=2, massimo=2, elementare=2, categoria=C, descrizione="Disposizioni di n elementi a k a k.")
def permutazione(ctx, n, k):
    n, k = int(num(n)), int(num(k))
    controlla(0 <= k <= n, NUM)
    return math.perm(n, k)


@funzione("MCD", "GCD", minimo=1, categoria=C, descrizione="Massimo comun divisore.")
def mcd(ctx, *a):
    l = [int(x) for x in numeri(a)]
    controlla(all(x >= 0 for x in l), NUM)
    return reduce(math.gcd, l, 0)


@funzione("MCM", "LCM", minimo=1, categoria=C, descrizione="Minimo comune multiplo.")
def mcm(ctx, *a):
    l = [int(x) for x in numeri(a)]
    controlla(all(x >= 0 for x in l), NUM)
    if any(x == 0 for x in l):
        return 0
    return reduce(lambda x, y: x * y // math.gcd(x, y), l, 1)


@funzione("PARI", "EVEN", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Arrotonda al numero pari successivo.")
def pari(ctx, x):
    x = num(x)
    n = math.ceil(abs(x))
    if n % 2:
        n += 1
    return int(math.copysign(n, x)) if x else 0


@funzione("DISPARI", "ODD", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Arrotonda al numero dispari successivo.")
def dispari(ctx, x):
    x = num(x)
    n = math.ceil(abs(x))
    if n % 2 == 0:
        n += 1
    return int(math.copysign(n, x))


@funzione("CASUALE", "RAND", minimo=0, massimo=0, volatile=True, categoria=C, descrizione="Numero casuale tra 0 e 1.")
def casuale(ctx):
    return random.random()


@funzione("CASUALE.TRA", "RANDBETWEEN", minimo=2, massimo=2, volatile=True, categoria=C,
          descrizione="Intero casuale tra due numeri.")
def casuale_tra(ctx, a, b):
    a, b = math.ceil(num(a)), math.floor(num(b))
    controlla(a <= b, NUM)
    return random.randint(a, b)


@funzione("MATR.SOMMA.PRODOTTO", "SUMPRODUCT", minimo=1, categoria=C,
          descrizione="Moltiplica gli elementi corrispondenti e somma i prodotti.",
          sintassi="MATR.SOMMA.PRODOTTO(matrice1; [matrice2]; ...)")
def somma_prodotto(ctx, *a):
    mats = [righe_di(scalare(x) if not isinstance(x, Rif) else x) for x in a]
    h, w = len(mats[0]), len(mats[0][0])
    for m in mats:
        controlla(len(m) == h and len(m[0]) == w, VALORE)
    tot = 0
    for i in range(h):
        for j in range(w):
            p = 1
            for m in mats:
                v = m[i][j]
                if isinstance(v, Errore):
                    raise ErroreFormula(v.codice)
                p *= v if e_numero(v) else 0
            tot += p
    return tot


def _coppie(intervallo: Any, altro: Any | None) -> tuple[list, list]:
    """Valori dell'intervallo dei criteri e quelli corrispondenti dell'intervallo da sommare."""
    if not isinstance(intervallo, Rif):
        valori = [v for r in righe_di(intervallo) for v in r]
        corrisp = valori if altro is None else [v for r in righe_di(altro) for v in r]
        return valori, corrisp
    lim = intervallo.limitata()
    valori = [v for r in lim.righe() for v in r]
    if altro is None:
        return valori, valori
    if isinstance(altro, Rif):
        stesso = Rif(altro.foglio, altro.r1, altro.c1, altro.r1 + lim.altezza - 1, altro.c1 + lim.larghezza - 1)
        corrisp = [v for r in stesso.righe() for v in r]
        corrisp += [None] * (len(valori) - len(corrisp))
        return valori, corrisp
    corrisp = [v for r in righe_di(altro) for v in r]
    return valori, corrisp


@funzione("SOMMA.SE", "SUMIF", minimo=2, massimo=3, categoria=C,
          descrizione="Somma le celle che rispettano un criterio (\">10\", \"Roma\", \"Ros*\").",
          sintassi="SOMMA.SE(intervallo; criterio; [int_somma])")
def somma_se(ctx, intervallo, crit, int_somma=None):
    prova = criterio(crit)
    valori, corrisp = _coppie(intervallo, int_somma)
    tot = 0
    for v, s in zip(valori, corrisp):
        if prova(v) and e_numero(s):
            tot += s
    return tot


def piu_se(principale: Any | None, argomenti: tuple) -> tuple[list[int], list]:
    """Posizioni che rispettano tutte le coppie intervallo/criterio, e i valori di `principale`."""
    controlla(len(argomenti) >= 2 and len(argomenti) % 2 == 0, VALORE)
    intervalli = [argomenti[k] for k in range(0, len(argomenti), 2)]
    tutti = intervalli + ([principale] if principale is not None else [])
    piatti = allinea(*tutti)
    indici = None
    for k, valori in enumerate(piatti[:len(intervalli)]):
        prova = criterio(argomenti[2 * k + 1])
        ok = {i for i, v in enumerate(valori) if prova(v)}
        indici = ok if indici is None else (indici & ok)
    return sorted(indici or ()), (piatti[-1] if principale is not None else [])


@funzione("SOMMA.PIÙ.SE", "SUMIFS", minimo=3, categoria=C,
          descrizione="Somma le celle che rispettano più criteri.",
          sintassi="SOMMA.PIÙ.SE(int_somma; intervallo1; criterio1; [intervallo2; criterio2]; ...)")
def somma_piu_se(ctx, int_somma, *argomenti):
    indici, valori = piu_se(int_somma, argomenti)
    return sum(valori[i] for i in indici if e_numero(valori[i]))


@funzione("SUBTOTALE", "SUBTOTAL", minimo=2, categoria=C,
          descrizione="Subtotale che salta le righe filtrate (1 MEDIA, 2 CONTA, 9 SOMMA...; +100 salta anche le nascoste).",
          sintassi="SUBTOTALE(funzione; rif1; [rif2]; ...)")
def subtotale(ctx, codice, *rif):
    n = intero(codice)
    salta_nascoste = n > 100
    n = n - 100 if n > 100 else n
    controlla(1 <= n <= 11, VALORE)
    valori = []
    for a in rif:
        controlla(isinstance(a, Rif), VALORE)
        f = a.foglio
        lim = a.limitata()
        for r in range(lim.r1, lim.r2 + 1):
            if r in f.righe_filtrate or (salta_nascoste and r in f.righe_nascoste):
                continue
            for c in range(lim.c1, lim.c2 + 1):
                cella = f.celle.get((r, c))
                if cella is not None and cella.ingresso and "SUBTOTALE(" in cella.ingresso.upper():
                    continue
                valori.append(f.valore(r, c))
    nums = [v for v in valori if e_numero(v)]
    from . import statistica as S
    if n == 1:
        return S.media_lista(nums)
    if n == 2:
        return len(nums)
    if n == 3:
        return sum(1 for v in valori if v is not None and v != "")
    if n == 4:
        return max(nums) if nums else 0
    if n == 5:
        return min(nums) if nums else 0
    if n == 6:
        return reduce(lambda x, y: x * y, nums, 1) if nums else 0
    if n == 7:
        return S.dev_st(nums, campione=True)
    if n == 8:
        return S.dev_st(nums, campione=False)
    if n == 9:
        return sum(nums)
    if n == 10:
        return S.varianza(nums, campione=True)
    return S.varianza(nums, campione=False)


_ROMANI = [(1000, "M"), (900, "CM"), (500, "D"), (400, "CD"), (100, "C"), (90, "XC"), (50, "L"), (40, "XL"),
           (10, "X"), (9, "IX"), (5, "V"), (4, "IV"), (1, "I")]


@funzione("ROMANO", "ROMAN", minimo=1, massimo=2, elementare=1, categoria=C, descrizione="Numero romano.")
def romano(ctx, x, forma=None):
    n = int(num(x))
    controlla(0 <= n <= 3999, VALORE)
    out = ""
    for v, s in _ROMANI:
        while n >= v:
            out += s
            n -= v
    return out


@funzione("ARABO", "ARABIC", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Da numero romano a numero.")
def arabo(ctx, t):
    from ._aiuti import testo
    s = testo(t).strip().upper()
    valori = {"I": 1, "V": 5, "X": 10, "L": 50, "C": 100, "D": 500, "M": 1000}
    controlla(all(ch in valori for ch in s), VALORE)
    tot = 0
    for i, ch in enumerate(s):
        v = valori[ch]
        if i + 1 < len(s) and valori[s[i + 1]] > v:
            tot -= v
        else:
            tot += v
    return tot
