"""Funzioni finanziarie: rate, valore attuale, VAN, TIR, ammortamenti."""

from __future__ import annotations

import math

from ..valori import NUM, VALORE, ErroreFormula
from . import funzione
from ._aiuti import controlla, intero, num, num_opzionale, numeri, righe_di

C = "Finanza"


def _rata(t: float, n: float, va: float, vf: float = 0, tipo: int = 0) -> float:
    controlla(n != 0, NUM)
    if t == 0:
        return -(va + vf) / n
    f = (1 + t) ** n
    return -(t * (va * f + vf)) / ((1 + t * tipo) * (f - 1))


def _vf(t: float, n: float, rata: float, va: float = 0, tipo: int = 0) -> float:
    if t == 0:
        return -(va + rata * n)
    f = (1 + t) ** n
    return -(va * f + rata * (1 + t * tipo) * (f - 1) / t)


def _va(t: float, n: float, rata: float, vf: float = 0, tipo: int = 0) -> float:
    if t == 0:
        return -(vf + rata * n)
    f = (1 + t) ** n
    return -(vf + rata * (1 + t * tipo) * (f - 1) / t) / f


@funzione("RATA", "PMT", minimo=3, massimo=5, elementare=5, categoria=C,
          descrizione="La rata di un prestito a tasso fisso (negativa = da pagare).",
          sintassi="RATA(tasso; periodi; valore_attuale; [valore_futuro]; [tipo])")
def rata(ctx, t, n, va, vf=None, tipo=None):
    return _rata(num(t), num(n), num(va), num_opzionale(vf, 0), intero(tipo) if tipo is not None else 0)


@funzione("VAL.FUT", "FV", minimo=3, massimo=5, elementare=5, categoria=C, descrizione="Valore futuro di un investimento.",
          sintassi="VAL.FUT(tasso; periodi; rata; [valore_attuale]; [tipo])")
def val_fut(ctx, t, n, r, va=None, tipo=None):
    return _vf(num(t), num(n), num(r), num_opzionale(va, 0), intero(tipo) if tipo is not None else 0)


@funzione("VA", "PV", minimo=3, massimo=5, elementare=5, categoria=C, descrizione="Valore attuale.",
          sintassi="VA(tasso; periodi; rata; [valore_futuro]; [tipo])")
def va(ctx, t, n, r, vf=None, tipo=None):
    return _va(num(t), num(n), num(r), num_opzionale(vf, 0), intero(tipo) if tipo is not None else 0)


@funzione("NUM.RATE", "NPER", minimo=3, massimo=5, elementare=5, categoria=C, descrizione="Numero di rate.",
          sintassi="NUM.RATE(tasso; rata; valore_attuale; [valore_futuro]; [tipo])")
def num_rate(ctx, t, r, va_, vf=None, tipo=None):
    t, r, va_ = num(t), num(r), num(va_)
    vf = num_opzionale(vf, 0)
    tp = intero(tipo) if tipo is not None else 0
    if t == 0:
        controlla(r != 0, NUM)
        return -(va_ + vf) / r
    a = r * (1 + t * tp) - vf * t
    b = va_ * t + r * (1 + t * tp)
    controlla(a / b > 0, NUM)
    return math.log(a / b) / math.log(1 + t)


@funzione("TASSO", "RATE", minimo=3, massimo=6, categoria=C, descrizione="Tasso di interesse per periodo.",
          sintassi="TASSO(periodi; rata; valore_attuale; [valore_futuro]; [tipo]; [ipotesi])")
def tasso(ctx, n, r, va_, vf=None, tipo=None, ipotesi=None):
    n, r, va_ = num(n), num(r), num(va_)
    vf = num_opzionale(vf, 0)
    tp = intero(tipo) if tipo is not None else 0
    t = num_opzionale(ipotesi, 0.1)

    def g(x: float) -> float:
        if abs(x) < 1e-12:
            return va_ + r * n + vf
        f = (1 + x) ** n
        return va_ * f + r * (1 + x * tp) * (f - 1) / x + vf

    for _ in range(200):
        h = 1e-7
        y = g(t)
        d = (g(t + h) - y) / h
        if d == 0:
            break
        nuovo = t - y / d
        if abs(nuovo - t) < 1e-12:
            return nuovo
        t = nuovo
        controlla(t > -1, NUM)
    raise ErroreFormula(NUM)


@funzione("VAN", "NPV", minimo=2, categoria=C, descrizione="Valore attuale netto di flussi periodici.",
          sintassi="VAN(tasso; valore1; [valore2]; ...)")
def van(ctx, t, *flussi):
    t = num(t)
    controlla(t != -1, NUM)
    return sum(v / (1 + t) ** (i + 1) for i, v in enumerate(numeri(flussi)))


@funzione("TIR.COST", "IRR", minimo=1, massimo=2, categoria=C, descrizione="Tasso interno di rendimento.",
          sintassi="TIR.COST(valori; [ipotesi])")
def tir(ctx, valori, ipotesi=None):
    flussi = numeri([valori])
    controlla(any(v > 0 for v in flussi) and any(v < 0 for v in flussi), NUM)
    t = num_opzionale(ipotesi, 0.1)
    for _ in range(500):
        f = sum(v / (1 + t) ** i for i, v in enumerate(flussi))
        d = sum(-i * v / (1 + t) ** (i + 1) for i, v in enumerate(flussi))
        if d == 0:
            break
        nuovo = t - f / d
        if abs(nuovo - t) < 1e-12:
            return nuovo
        t = nuovo
        controlla(t > -1, NUM)
    raise ErroreFormula(NUM)


def _interessi(t, per, n, va_, vf, tp) -> float:
    r = _rata(t, n, va_, vf, tp)
    if per == 1 and tp == 1:
        return 0.0
    saldo = _vf(t, per - 1, r, va_, tp)
    i = saldo * t
    if tp == 1:
        i /= (1 + t)
    return i


@funzione("INTERESSI", "IPMT", minimo=4, massimo=6, elementare=6, categoria=C,
          descrizione="La quota interessi di una rata.", sintassi="INTERESSI(tasso; periodo; periodi; valore_attuale; [vf]; [tipo])")
def interessi(ctx, t, per, n, va_, vf=None, tipo=None):
    p, nn = num(per), num(n)
    controlla(1 <= p <= nn, NUM)
    return _interessi(num(t), p, nn, num(va_), num_opzionale(vf, 0), intero(tipo) if tipo is not None else 0)


@funzione("P.RATA", "PPMT", minimo=4, massimo=6, elementare=6, categoria=C, descrizione="La quota capitale di una rata.")
def p_rata(ctx, t, per, n, va_, vf=None, tipo=None):
    t, p, nn, v = num(t), num(per), num(n), num(va_)
    controlla(1 <= p <= nn, NUM)
    f = num_opzionale(vf, 0)
    tp = intero(tipo) if tipo is not None else 0
    return _rata(t, nn, v, f, tp) - _interessi(t, p, nn, v, f, tp)


@funzione("AMMORT.COST", "SLN", minimo=3, massimo=3, elementare=3, categoria=C, descrizione="Ammortamento a quote costanti.",
          sintassi="AMMORT.COST(costo; valore_residuo; vita_utile)")
def ammort_cost(ctx, costo, residuo, vita):
    v = num(vita)
    controlla(v != 0, NUM)
    return (num(costo) - num(residuo)) / v


@funzione("AMMORT.ANNUO", "SYD", minimo=4, massimo=4, elementare=4, categoria=C, descrizione="Ammortamento a somma degli anni.")
def ammort_annuo(ctx, costo, residuo, vita, periodo):
    v, p = num(vita), num(periodo)
    controlla(v > 0 and 1 <= p <= v, NUM)
    return (num(costo) - num(residuo)) * (v - p + 1) * 2 / (v * (v + 1))


@funzione("AMMORT", "DDB", minimo=4, massimo=5, elementare=5, categoria=C, descrizione="Ammortamento a quote decrescenti.")
def ammort(ctx, costo, residuo, vita, periodo, fattore=None):
    c, r, v, p = num(costo), num(residuo), num(vita), num(periodo)
    f = num_opzionale(fattore, 2)
    controlla(v > 0 and 1 <= p <= v, NUM)
    valore = c
    quota = 0
    for _ in range(int(math.ceil(p))):
        quota = min(valore * f / v, max(0, valore - r))
        valore -= quota
    return quota


@funzione("AMMORT.FISSO", "DB", minimo=4, massimo=5, elementare=5, categoria=C, descrizione="Ammortamento a tasso fisso.")
def ammort_fisso(ctx, costo, residuo, vita, periodo, mesi=None):
    c, r, v, p = num(costo), num(residuo), num(vita), int(num(periodo))
    m = num_opzionale(mesi, 12)
    controlla(c > 0 and v > 0 and 1 <= p <= v + 1, NUM)
    tasso_ = round(1 - (r / c) ** (1 / v), 3)
    tot = 0.0
    quota = 0.0
    for k in range(1, p + 1):
        if k == 1:
            quota = c * tasso_ * m / 12
        elif k == v + 1:
            quota = (c - tot) * tasso_ * (12 - m) / 12
        else:
            quota = (c - tot) * tasso_
        tot += quota
    return quota


@funzione("TASSO.EFFETTIVO", "EFFECT", minimo=2, massimo=2, elementare=2, categoria=C, descrizione="Tasso effettivo annuo.")
def tasso_effettivo(ctx, nominale, periodi):
    n = intero(periodi)
    controlla(n >= 1 and num(nominale) > 0, NUM)
    return (1 + num(nominale) / n) ** n - 1


@funzione("TASSO.NOMINALE", "NOMINAL", minimo=2, massimo=2, elementare=2, categoria=C, descrizione="Tasso nominale annuo.")
def tasso_nominale(ctx, effettivo, periodi):
    n = intero(periodi)
    controlla(n >= 1 and num(effettivo) > 0, NUM)
    return n * ((1 + num(effettivo)) ** (1 / n) - 1)


@funzione("VAN.X", "XNPV", minimo=3, massimo=3, categoria=C, descrizione="VAN con flussi a date qualsiasi.")
def van_x(ctx, t, valori, date_):
    t = num(t)
    v = numeri([valori])
    d = numeri([date_])
    controlla(len(v) == len(d) and v, NUM)
    return sum(x / (1 + t) ** ((g - d[0]) / 365) for x, g in zip(v, d))


@funzione("TIR.X", "XIRR", minimo=2, massimo=3, categoria=C, descrizione="TIR con flussi a date qualsiasi.")
def tir_x(ctx, valori, date_, ipotesi=None):
    v = numeri([valori])
    d = numeri([date_])
    controlla(len(v) == len(d) and any(x > 0 for x in v) and any(x < 0 for x in v), NUM)
    t = num_opzionale(ipotesi, 0.1)
    for _ in range(500):
        f = sum(x / (1 + t) ** ((g - d[0]) / 365) for x, g in zip(v, d))
        df = sum(-((g - d[0]) / 365) * x / (1 + t) ** ((g - d[0]) / 365 + 1) for x, g in zip(v, d))
        if df == 0:
            break
        nuovo = t - f / df
        if abs(nuovo - t) < 1e-12:
            return nuovo
        t = nuovo
        controlla(t > -1, NUM)
    raise ErroreFormula(NUM)
