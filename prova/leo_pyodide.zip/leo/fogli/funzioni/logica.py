"""Funzioni logiche: SE, SE.ERRORE, PIÙ.SE, SWITCH, E, O..."""

from __future__ import annotations

from typing import Any

from ..calcolo import Rif, _elemento, scalare
from ..valori import ND, VALORE, Errore, ErroreFormula, Matrice, a_logico, uguali
from . import funzione
from ._aiuti import controlla, logico, valori_argomento

C = "Logica"


def _valore_pigro(f) -> Any:
    v = f()
    return v


@funzione("SE", "IF", minimo=2, massimo=3, pigra=True, categoria=C,
          descrizione="Se la condizione è vera dà il secondo valore, altrimenti il terzo.",
          sintassi="SE(test; [se_vero]; [se_falso])")
def se(ctx, test, se_vero, se_falso=None):
    t = scalare(test())
    if isinstance(t, Matrice):
        v = scalare(se_vero())
        f = scalare(se_falso()) if se_falso is not None else False
        out = []
        for i, riga in enumerate(t.righe):
            r = []
            for j, x in enumerate(riga):
                try:
                    if a_logico(x):
                        r.append(_elemento(v, i, j) if isinstance(v, Matrice) else (0 if v is None else v))
                    else:
                        r.append(_elemento(f, i, j) if isinstance(f, Matrice) else (0 if f is None else f))
                except ErroreFormula as e:
                    r.append(Errore(e.codice))
            out.append(r)
        return Matrice(out)
    if isinstance(t, Errore):
        raise ErroreFormula(t.codice)
    if a_logico(t):
        v = se_vero()
        return 0 if v is None else v
    if se_falso is None:
        return False
    v = se_falso()
    return 0 if v is None else v


@funzione("SE.ERRORE", "IFERROR", minimo=2, massimo=2, pigra=True, categoria=C,
          descrizione="Il valore, oppure un'alternativa se è un errore.", sintassi="SE.ERRORE(valore; valore_se_errore)")
def se_errore(ctx, valore, alternativa):
    try:
        v = scalare(valore())
    except ErroreFormula:
        return alternativa()
    if isinstance(v, Errore):
        return alternativa()
    if isinstance(v, Matrice):
        alt = None
        out = []
        for r in v.righe:
            riga = []
            for x in r:
                if isinstance(x, Errore):
                    if alt is None:
                        alt = scalare(alternativa())
                    riga.append(alt)
                else:
                    riga.append(x)
            out.append(riga)
        return Matrice(out)
    return v


@funzione("SE.NON.DISP", "IFNA", minimo=2, massimo=2, pigra=True, categoria=C,
          descrizione="Il valore, oppure un'alternativa se è #N/D.")
def se_non_disp(ctx, valore, alternativa):
    try:
        v = scalare(valore())
    except ErroreFormula as e:
        if e.codice == ND:
            return alternativa()
        raise
    if isinstance(v, Errore) and v.codice == ND:
        return alternativa()
    return v


@funzione("PIÙ.SE", "IFS", minimo=2, pigra=True, categoria=C,
          descrizione="Il primo valore la cui condizione è vera.", sintassi="PIÙ.SE(test1; valore1; [test2; valore2]; ...)")
def piu_se(ctx, *coppie):
    controlla(len(coppie) % 2 == 0, VALORE)
    for i in range(0, len(coppie), 2):
        if logico(coppie[i]()):
            v = coppie[i + 1]()
            return 0 if v is None else v
    raise ErroreFormula(ND)


@funzione("SWITCH", "SWITCH", alias=("SCEGLI.VALORE",), minimo=3, pigra=True, categoria=C,
          descrizione="Confronta un valore con un elenco e dà il risultato corrispondente.",
          sintassi="SWITCH(espressione; valore1; risultato1; [predefinito])")
def switch(ctx, espressione, *resto):
    e = scalare(espressione())
    if isinstance(e, Errore):
        raise ErroreFormula(e.codice)
    coppie = len(resto) // 2
    for i in range(coppie):
        v = scalare(resto[2 * i]())
        if uguali(e, v):
            return resto[2 * i + 1]()
    if len(resto) % 2 == 1:
        return resto[-1]()
    raise ErroreFormula(ND)


def _logici(argomenti: tuple) -> list[bool]:
    out = []
    for a in argomenti:
        for v in valori_argomento(a, solo_non_vuoti=isinstance(a, Rif)):
            if v is None or (isinstance(v, str) and isinstance(a, (Rif, Matrice))):
                continue
            if isinstance(v, Errore):
                raise ErroreFormula(v.codice)
            out.append(a_logico(v))
    controlla(bool(out), VALORE)
    return out


@funzione("E", "AND", minimo=1, categoria=C, descrizione="VERO se tutte le condizioni sono vere.")
def f_e(ctx, *a):
    return all(_logici(a))


@funzione("O", "OR", minimo=1, categoria=C, descrizione="VERO se almeno una condizione è vera.")
def f_o(ctx, *a):
    return any(_logici(a))


@funzione("XOR", "XOR", minimo=1, categoria=C, descrizione="VERO se un numero dispari di condizioni è vero.")
def f_xor(ctx, *a):
    return sum(_logici(a)) % 2 == 1


@funzione("NON", "NOT", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Inverte VERO e FALSO.")
def f_non(ctx, x):
    return not logico(x)


@funzione("VERO", "TRUE", minimo=0, massimo=0, categoria=C, descrizione="Il valore logico VERO.")
def f_vero(ctx):
    return True


@funzione("FALSO", "FALSE", minimo=0, massimo=0, categoria=C, descrizione="Il valore logico FALSO.")
def f_falso(ctx):
    return False


@funzione("LET", "LET", minimo=3, categoria=C,
          descrizione="Dà un nome a dei risultati intermedi: LET(x; A1*2; y; B1; x+y).",
          sintassi="LET(nome1; valore1; [nome2; valore2]; ...; calcolo)")
def let(ctx, *a):  # gestita a parte dal compilatore (vedi calcolo.compila)
    raise ErroreFormula(VALORE)
