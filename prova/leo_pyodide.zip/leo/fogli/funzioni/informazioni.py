"""Funzioni di informazione: VAL.NUMERO, VAL.ERRORE, TIPO..."""

from __future__ import annotations

from typing import Any

from ..calcolo import Rif, applica1, scalare
from ..valori import CODICI_ERRORE, ND, VALORE, Errore, ErroreFormula, Matrice, e_numero
from . import funzione
from ._aiuti import controlla, num

C = "Informazioni"


def _valuta(thunk) -> Any:
    try:
        return scalare(thunk())
    except ErroreFormula as e:
        return Errore(e.codice)


def _prova(nome: str, inglese: str, prova, descrizione: str, vuoto_vale=None) -> None:
    def f(ctx, x):
        v = _valuta(x)
        if isinstance(v, Matrice):
            return applica1(v, lambda e: prova(e))
        return prova(v)
    funzione(nome, inglese, minimo=1, massimo=1, pigra=True, categoria=C, descrizione=descrizione)(f)


_prova("VAL.VUOTO", "ISBLANK", lambda v: v is None, "VERO se la cella è vuota.")
_prova("VAL.NUMERO", "ISNUMBER", lambda v: e_numero(v), "VERO se è un numero.")
_prova("VAL.TESTO", "ISTEXT", lambda v: isinstance(v, str), "VERO se è un testo.")
_prova("VAL.NON.TESTO", "ISNONTEXT", lambda v: not isinstance(v, str), "VERO se non è un testo.")
_prova("VAL.LOGICO", "ISLOGICAL", lambda v: isinstance(v, bool), "VERO se è VERO o FALSO.")
_prova("VAL.ERRORE", "ISERROR", lambda v: isinstance(v, Errore), "VERO se è un errore qualunque.")
_prova("VAL.ERR", "ISERR", lambda v: isinstance(v, Errore) and v.codice != ND, "VERO se è un errore diverso da #N/D.")
_prova("VAL.NON.DISP", "ISNA", lambda v: isinstance(v, Errore) and v.codice == ND, "VERO se è #N/D.")


@funzione("VAL.PARI", "ISEVEN", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="VERO se il numero è pari.")
def val_pari(ctx, x):
    return int(num(x)) % 2 == 0


@funzione("VAL.DISPARI", "ISODD", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="VERO se il numero è dispari.")
def val_dispari(ctx, x):
    return int(num(x)) % 2 == 1


@funzione("VAL.FORMULA", "ISFORMULA", minimo=1, massimo=1, categoria=C, descrizione="VERO se la cella contiene una formula.")
def val_formula(ctx, rif):
    controlla(isinstance(rif, Rif), VALORE)
    c = rif.foglio.celle.get((rif.r1, rif.c1))
    return c is not None and c.formula is not None


@funzione("VAL.RIF", "ISREF", minimo=1, massimo=1, pigra=True, categoria=C, descrizione="VERO se è un riferimento.")
def val_rif(ctx, x):
    try:
        return isinstance(x(), Rif)
    except ErroreFormula:
        return False


@funzione("NON.DISP", "NA", minimo=0, massimo=0, categoria=C, descrizione="Il valore di errore #N/D.")
def non_disp(ctx):
    raise ErroreFormula(ND)


@funzione("TIPO", "TYPE", minimo=1, massimo=1, pigra=True, categoria=C,
          descrizione="Tipo del valore: 1 numero, 2 testo, 4 logico, 16 errore, 64 matrice.")
def tipo(ctx, x):
    v = _valuta(x)
    if isinstance(v, Matrice):
        return 64
    if isinstance(v, Errore):
        return 16
    if isinstance(v, bool):
        return 4
    if isinstance(v, str):
        return 2
    return 1


@funzione("ERRORE.TIPO", "ERROR.TYPE", minimo=1, massimo=1, pigra=True, categoria=C, descrizione="Numero del tipo di errore.")
def errore_tipo(ctx, x):
    v = _valuta(x)
    controlla(isinstance(v, Errore), ND)
    ordine = ["#NULLO!", "#DIV/0!", "#VALORE!", "#RIF!", "#NOME?", "#NUM!", "#N/D", "#ATTESA.DATI", "#ESPANSIONE!",
              "#CONNETTI!", "#BLOCCATO!", "#SCONOSCIUTO!", "#CAMPO!", "#CALC!"]
    return ordine.index(v.codice) + 1 if v.codice in ordine else 3


@funzione("N", "N", minimo=1, massimo=1, categoria=C, descrizione="Il numero, oppure 0.")
def f_n(ctx, x):
    v = scalare(x)
    if isinstance(v, Matrice):
        v = v.righe[0][0]
    if isinstance(v, bool):
        return 1 if v else 0
    if e_numero(v):
        return v
    if isinstance(v, Errore):
        raise ErroreFormula(v.codice)
    return 0


@funzione("TESTO.FORMULA", "FORMULATEXT", minimo=1, massimo=1, categoria=C, descrizione="Il testo della formula di una cella.")
def testo_formula(ctx, rif):
    controlla(isinstance(rif, Rif), VALORE)
    c = rif.foglio.celle.get((rif.r1, rif.c1))
    controlla(c is not None and c.formula is not None, ND)
    return c.ingresso


@funzione("FOGLIO", "SHEET", minimo=0, massimo=1, categoria=C, descrizione="Il numero del foglio.")
def foglio(ctx, rif=None):
    f = rif.foglio if isinstance(rif, Rif) else ctx.foglio
    if isinstance(rif, str):
        f = ctx.cartella.foglio(rif)
        controlla(f is not None, ND)
    return ctx.cartella.fogli.index(f) + 1


@funzione("FOGLI", "SHEETS", minimo=0, massimo=1, categoria=C, descrizione="Quanti fogli ci sono.")
def fogli(ctx, rif=None):
    return 1 if rif is not None else len(ctx.cartella.fogli)
