"""Funzioni di data e ora (le date sono numeri seriali come in Excel)."""

from __future__ import annotations

import calendar
import datetime as _dt
import math
from typing import Any

from ..calcolo import scalare
from ..valori import NUM, VALORE, ErroreFormula, data_in_seriale, numero_da_testo, seriale_in_datetime
from . import funzione
from ._aiuti import controlla, intero, num, numeri, testo

C = "Data e ora"


def a_data(v: Any) -> _dt.date:
    return seriale_in_datetime(num(v)).date()


def da_data(d: _dt.date) -> int:
    return int(data_in_seriale(d))


@funzione("OGGI", "TODAY", minimo=0, massimo=0, volatile=True, categoria=C, descrizione="La data di oggi.")
def oggi(ctx):
    return da_data(_dt.date.today())


@funzione("ADESSO", "NOW", minimo=0, massimo=0, volatile=True, categoria=C, descrizione="Data e ora attuali.")
def adesso(ctx):
    return data_in_seriale(_dt.datetime.now().replace(microsecond=0))


@funzione("DATA", "DATE", minimo=3, massimo=3, elementare=3, categoria=C, descrizione="Data da anno, mese e giorno.",
          sintassi="DATA(anno; mese; giorno)")
def data(ctx, a, m, g):
    anno, mese, giorno = intero(a), intero(m), intero(g)
    if 0 <= anno < 1900:
        anno += 1900
    anno += (mese - 1) // 12
    mese = (mese - 1) % 12 + 1
    controlla(1900 <= anno <= 9999, NUM)
    d = _dt.date(anno, mese, 1) + _dt.timedelta(days=giorno - 1)
    controlla(d.year >= 1900, NUM)
    return da_data(d)


@funzione("ORARIO", "TIME", minimo=3, massimo=3, elementare=3, categoria=C, descrizione="Ora da ore, minuti e secondi.")
def orario(ctx, h, m, s):
    t = (intero(h) * 3600 + intero(m) * 60 + intero(s)) % 86400
    controlla(t >= 0, NUM)
    return t / 86400


@funzione("ANNO", "YEAR", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="L'anno di una data.")
def anno(ctx, d):
    return a_data(d).year


@funzione("MESE", "MONTH", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Il mese (1-12) di una data.")
def mese(ctx, d):
    return a_data(d).month


@funzione("GIORNO", "DAY", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Il giorno del mese.")
def giorno(ctx, d):
    return a_data(d).day


@funzione("ORA", "HOUR", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="L'ora (0-23).")
def ora(ctx, d):
    return seriale_in_datetime(num(d)).hour


@funzione("MINUTO", "MINUTE", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="I minuti.")
def minuto(ctx, d):
    return seriale_in_datetime(num(d)).minute


@funzione("SECONDO", "SECOND", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="I secondi.")
def secondo(ctx, d):
    return seriale_in_datetime(num(d)).second


@funzione("GIORNO.SETTIMANA", "WEEKDAY", minimo=1, massimo=2, elementare=2, categoria=C,
          descrizione="Giorno della settimana (tipo 1: domenica=1; tipo 2: lunedì=1).",
          sintassi="GIORNO.SETTIMANA(data; [tipo])")
def giorno_settimana(ctx, d, tipo=None):
    wd = a_data(d).weekday()       # lunedì = 0
    t = intero(tipo) if tipo is not None else 1
    if t == 1:
        return (wd + 1) % 7 + 1
    if t == 2:
        return wd + 1
    if t == 3:
        return wd
    if 11 <= t <= 17:
        return (wd - (t - 11)) % 7 + 1
    raise ErroreFormula(NUM)


@funzione("NUM.SETTIMANA", "WEEKNUM", minimo=1, massimo=2, elementare=2, categoria=C, descrizione="Numero della settimana.")
def num_settimana(ctx, d, tipo=None):
    data_ = a_data(d)
    t = intero(tipo) if tipo is not None else 1
    if t == 21:
        return data_.isocalendar()[1]
    inizio = 6 if t in (1, 17) else (t - 11 if 11 <= t <= 16 else 0)
    primo = _dt.date(data_.year, 1, 1)
    offset = (primo.weekday() - inizio) % 7
    return (data_.timetuple().tm_yday + offset - 1) // 7 + 1


@funzione("NUM.SETTIMANA.ISO", "ISOWEEKNUM", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Settimana ISO.")
def num_settimana_iso(ctx, d):
    return a_data(d).isocalendar()[1]


def _aggiungi_mesi(d: _dt.date, n: int) -> _dt.date:
    m = d.month - 1 + n
    a = d.year + m // 12
    m = m % 12 + 1
    controlla(1900 <= a <= 9999, NUM)
    g = min(d.day, calendar.monthrange(a, m)[1])
    return _dt.date(a, m, g)


@funzione("DATA.MESE", "EDATE", minimo=2, massimo=2, elementare=2, categoria=C, descrizione="La data spostata di n mesi.")
def data_mese(ctx, d, n):
    return da_data(_aggiungi_mesi(a_data(d), intero(n)))


@funzione("FINE.MESE", "EOMONTH", minimo=2, massimo=2, elementare=2, categoria=C, descrizione="L'ultimo giorno del mese, n mesi dopo.")
def fine_mese(ctx, d, n):
    x = _aggiungi_mesi(a_data(d).replace(day=1), intero(n))
    return da_data(x.replace(day=calendar.monthrange(x.year, x.month)[1]))


@funzione("GIORNI", "DAYS", minimo=2, massimo=2, elementare=2, categoria=C, descrizione="Giorni tra due date.",
          sintassi="GIORNI(data_fine; data_inizio)")
def giorni(ctx, fine, inizio):
    return int(math.floor(num(fine))) - int(math.floor(num(inizio)))


@funzione("DATA.DIFF", "DATEDIF", minimo=3, massimo=3, elementare=3, categoria=C,
          descrizione="Differenza tra date in anni (\"Y\"), mesi (\"M\"), giorni (\"D\"), \"YM\", \"MD\", \"YD\".",
          sintassi="DATA.DIFF(inizio; fine; unità)")
def data_diff(ctx, inizio, fine, unita):
    a, b = a_data(inizio), a_data(fine)
    controlla(a <= b, NUM)
    u = testo(unita).upper()
    mesi = (b.year - a.year) * 12 + b.month - a.month - (1 if b.day < a.day else 0)
    if u == "Y":
        return mesi // 12
    if u == "M":
        return mesi
    if u == "D":
        return (b - a).days
    if u == "YM":
        return mesi % 12
    if u == "MD":
        prima = _aggiungi_mesi(a, mesi)
        return (b - prima).days
    if u == "YD":
        x = a.replace(year=b.year) if not (a.month == 2 and a.day == 29) else _dt.date(b.year, 3, 1)
        if x > b:
            x = a.replace(year=b.year - 1) if not (a.month == 2 and a.day == 29) else _dt.date(b.year - 1, 3, 1)
        return (b - x).days
    raise ErroreFormula(NUM)


def _festivi(arg: Any) -> set[int]:
    if arg is None:
        return set()
    return {int(math.floor(x)) for x in numeri([arg])}


def _feriale(d: _dt.date, festivi: set[int], fine_settimana: set[int]) -> bool:
    return d.weekday() not in fine_settimana and da_data(d) not in festivi


def _fine_settimana(codice: Any) -> set[int]:
    if codice is None:
        return {5, 6}
    if isinstance(scalare(codice), str) and len(testo(codice)) == 7:
        return {i for i, ch in enumerate(testo(codice)) if ch == "1"}
    n = intero(codice)
    mappa = {1: {5, 6}, 2: {6, 0}, 3: {0, 1}, 4: {1, 2}, 5: {2, 3}, 6: {3, 4}, 7: {4, 5},
             11: {6}, 12: {0}, 13: {1}, 14: {2}, 15: {3}, 16: {4}, 17: {5}}
    controlla(n in mappa, NUM)
    return mappa[n]


def conta_lavorativi(a: _dt.date, b: _dt.date, festivi: set[int], fs: set[int]) -> int:
    segno = 1
    if a > b:
        a, b, segno = b, a, -1
    n = 0
    d = a
    passo = _dt.timedelta(days=1)
    while d <= b:
        if _feriale(d, festivi, fs):
            n += 1
        d += passo
    return n * segno


def sposta_lavorativi(d: _dt.date, giorni_: int, festivi: set[int], fs: set[int]) -> _dt.date:
    passo = _dt.timedelta(days=1 if giorni_ >= 0 else -1)
    rimasti = abs(giorni_)
    while rimasti:
        d += passo
        if _feriale(d, festivi, fs):
            rimasti -= 1
    return d


@funzione("GIORNI.LAVORATIVI.TOT", "NETWORKDAYS", minimo=2, massimo=3, categoria=C,
          descrizione="Giorni lavorativi tra due date (sabato e domenica esclusi, più le festività indicate).",
          sintassi="GIORNI.LAVORATIVI.TOT(inizio; fine; [festività])")
def giorni_lavorativi(ctx, inizio, fine, festivi=None):
    return conta_lavorativi(a_data(inizio), a_data(fine), _festivi(festivi), {5, 6})


@funzione("GIORNI.LAVORATIVI.TOT.INTL", "NETWORKDAYS.INTL", minimo=2, massimo=4, categoria=C,
          descrizione="Giorni lavorativi scegliendo i giorni di riposo.")
def giorni_lavorativi_intl(ctx, inizio, fine, fs=None, festivi=None):
    return conta_lavorativi(a_data(inizio), a_data(fine), _festivi(festivi), _fine_settimana(fs))


@funzione("GIORNO.LAVORATIVO", "WORKDAY", minimo=2, massimo=3, categoria=C,
          descrizione="La data dopo n giorni lavorativi.", sintassi="GIORNO.LAVORATIVO(inizio; giorni; [festività])")
def giorno_lavorativo(ctx, inizio, n, festivi=None):
    return da_data(sposta_lavorativi(a_data(inizio), intero(n), _festivi(festivi), {5, 6}))


@funzione("GIORNO.LAVORATIVO.INTL", "WORKDAY.INTL", minimo=2, massimo=4, categoria=C,
          descrizione="La data dopo n giorni lavorativi scegliendo i giorni di riposo.")
def giorno_lavorativo_intl(ctx, inizio, n, fs=None, festivi=None):
    return da_data(sposta_lavorativi(a_data(inizio), intero(n), _festivi(festivi), _fine_settimana(fs)))


@funzione("DATA.VALORE", "DATEVALUE", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Da testo a data.")
def data_valore(ctx, t):
    n = numero_da_testo(testo(t))
    controlla(n is not None, VALORE)
    return int(math.floor(n))


@funzione("ORARIO.VALORE", "TIMEVALUE", minimo=1, massimo=1, elementare=1, categoria=C, descrizione="Da testo a ora.")
def orario_valore(ctx, t):
    n = numero_da_testo(testo(t))
    controlla(n is not None, VALORE)
    return n - math.floor(n)


@funzione("FRAZIONE.ANNO", "YEARFRAC", minimo=2, massimo=3, elementare=3, categoria=C, descrizione="Frazione d'anno tra due date.")
def frazione_anno(ctx, a, b, base=None):
    d1, d2 = sorted([a_data(a), a_data(b)])
    bb = intero(base) if base is not None else 0
    if bb == 0:      # 30/360 USA
        g1, g2 = min(d1.day, 30), d2.day
        if g1 == 30 and g2 == 31:
            g2 = 30
        return ((d2.year - d1.year) * 360 + (d2.month - d1.month) * 30 + (g2 - g1)) / 360
    if bb == 1:
        giorni_ = (d2 - d1).days
        anni = range(d1.year, d2.year + 1)
        media = sum(366 if calendar.isleap(y) else 365 for y in anni) / len(anni)
        return giorni_ / media
    if bb == 2:
        return (d2 - d1).days / 360
    if bb == 3:
        return (d2 - d1).days / 365
    if bb == 4:
        g1, g2 = min(d1.day, 30), min(d2.day, 30)
        return ((d2.year - d1.year) * 360 + (d2.month - d1.month) * 30 + (g2 - g1)) / 360
    raise ErroreFormula(NUM)
