"""Matrici dinamiche (come Excel 365): SEQUENZA, FILTRO, DATI.ORDINA, UNICI, RAGGRUPPA.PER, PIVOT.PER..."""

from __future__ import annotations

import random
from functools import cmp_to_key
from typing import Any

from ..calcolo import Rif, scalare
from ..valori import CALC, ND, NUM, VALORE, Errore, ErroreFormula, Matrice, a_logico, confronta, e_numero
from . import funzione
from ._aiuti import controlla, intero, logico, num, num_opzionale, risultato_matrice, righe_di, testo

C = "Matrici dinamiche"


def _m(a: Any) -> list[list[Any]]:
    if isinstance(a, Rif):
        return a.limitata().righe() if (a.altezza > 1048575 or a.larghezza > 16383) else a.righe()
    return righe_di(scalare(a) if not isinstance(a, Matrice) else a)


def _zero(v: Any) -> Any:
    return 0 if v is None else v


def _fuori(righe: list[list[Any]]) -> Any:
    return risultato_matrice([[_zero(v) for v in r] for r in righe])


@funzione("SEQUENZA", "SEQUENCE", minimo=1, massimo=4, categoria=C, descrizione="Una sequenza di numeri.",
          sintassi="SEQUENZA(righe; [colonne]; [inizio]; [passo])")
def sequenza(ctx, righe, colonne=None, inizio=None, passo=None):
    h = intero(righe)
    w = intero(colonne) if colonne is not None else 1
    a = num_opzionale(inizio, 1)
    p = num_opzionale(passo, 1)
    controlla(h >= 1 and w >= 1 and h * w <= 1_000_000, CALC)
    return risultato_matrice([[a + (i * w + j) * p for j in range(w)] for i in range(h)])


@funzione("MATR.CASUALE", "RANDARRAY", minimo=0, massimo=5, volatile=True, categoria=C, descrizione="Matrice di numeri casuali.",
          sintassi="MATR.CASUALE([righe]; [colonne]; [min]; [max]; [interi])")
def matr_casuale(ctx, righe=None, colonne=None, minimo=None, massimo=None, interi=None):
    h = intero(righe) if righe is not None else 1
    w = intero(colonne) if colonne is not None else 1
    lo, hi = num_opzionale(minimo, 0), num_opzionale(massimo, 1)
    controlla(h >= 1 and w >= 1 and lo <= hi, VALORE)
    if interi is not None and logico(interi):
        return risultato_matrice([[random.randint(int(lo), int(hi)) for _ in range(w)] for _ in range(h)])
    return risultato_matrice([[random.uniform(lo, hi) for _ in range(w)] for _ in range(h)])


@funzione("MATR.TRASPOSTA", "TRANSPOSE", minimo=1, massimo=1, categoria=C, descrizione="Scambia righe e colonne.")
def trasposta(ctx, a):
    m = _m(a)
    return _fuori([list(r) for r in zip(*m)])


@funzione("MATR.PRODOTTO", "MMULT", minimo=2, massimo=2, categoria=C, descrizione="Prodotto di due matrici.")
def matr_prodotto(ctx, a, b):
    x, y = _m(a), _m(b)
    controlla(len(x[0]) == len(y), VALORE)
    for r in x + y:
        for v in r:
            controlla(e_numero(v), VALORE)
    return _fuori([[sum(x[i][k] * y[k][j] for k in range(len(y))) for j in range(len(y[0]))] for i in range(len(x))])


@funzione("MATR.DETERM", "MDETERM", minimo=1, massimo=1, categoria=C, descrizione="Determinante di una matrice quadrata.")
def matr_determ(ctx, a):
    m = [[float(v) for v in r] for r in _m(a)]
    n = len(m)
    controlla(all(len(r) == n for r in m), VALORE)
    det = 1.0
    for i in range(n):
        p = max(range(i, n), key=lambda r: abs(m[r][i]))
        if abs(m[p][i]) < 1e-15:
            return 0
        if p != i:
            m[i], m[p] = m[p], m[i]
            det = -det
        det *= m[i][i]
        for r in range(i + 1, n):
            f = m[r][i] / m[i][i]
            for c in range(i, n):
                m[r][c] -= f * m[i][c]
    return det


@funzione("MATR.INVERSA", "MINVERSE", minimo=1, massimo=1, categoria=C, descrizione="Inversa di una matrice quadrata.")
def matr_inversa(ctx, a):
    m = [[float(v) for v in r] for r in _m(a)]
    n = len(m)
    controlla(all(len(r) == n for r in m), VALORE)
    aug = [r + [1.0 if i == j else 0.0 for j in range(n)] for i, r in enumerate(m)]
    for i in range(n):
        p = max(range(i, n), key=lambda r: abs(aug[r][i]))
        controlla(abs(aug[p][i]) > 1e-15, NUM)
        aug[i], aug[p] = aug[p], aug[i]
        piv = aug[i][i]
        aug[i] = [v / piv for v in aug[i]]
        for r in range(n):
            if r != i:
                f = aug[r][i]
                aug[r] = [vr - f * vi for vr, vi in zip(aug[r], aug[i])]
    return _fuori([r[n:] for r in aug])


@funzione("FILTRO", "FILTER", minimo=2, massimo=3, categoria=C,
          descrizione="Le righe (o colonne) che rispettano una condizione: FILTRO(A2:C50; B2:B50=\"Roma\").",
          sintassi="FILTRO(matrice; includi; [se_vuoto])")
def filtro(ctx, matrice, includi, se_vuoto=None):
    m = _m(matrice)
    cond = _m(includi)
    if len(cond) == len(m) and all(len(r) == 1 for r in cond):
        tenute = [r for r, c in zip(m, cond) if _vero(c[0])]
    elif len(cond) == 1 and len(cond[0]) == len(m[0]):
        idx = [j for j, c in enumerate(cond[0]) if _vero(c)]
        tenute = [[r[j] for j in idx] for r in m] if idx else []
        if tenute and not tenute[0]:
            tenute = []
    else:
        raise ErroreFormula(VALORE)
    if not tenute:
        if se_vuoto is not None:
            return scalare(se_vuoto)
        raise ErroreFormula(CALC)
    return _fuori(tenute)


def _vero(v: Any) -> bool:
    if isinstance(v, Errore):
        raise ErroreFormula(v.codice)
    try:
        return a_logico(v)
    except ErroreFormula:
        return False


def _confronta_righe(chiavi: list[tuple[int, int]]):
    def cmp(a, b):
        for col, ordine in chiavi:
            x, y = a[col], b[col]
            if x is None and y is None:
                continue
            if x is None:
                return 1
            if y is None:
                return -1
            k = confronta(x, y)
            if k:
                return k * ordine
        return 0
    return cmp_to_key(cmp)


@funzione("DATI.ORDINA", "SORT", alias=("ORDINA",), minimo=1, massimo=4, categoria=C,
          descrizione="La matrice ordinata (per la colonna indicata, crescente 1 o decrescente -1).",
          sintassi="DATI.ORDINA(matrice; [indice]; [ordine]; [per_colonna])")
def ordina(ctx, matrice, indice=None, ordine=None, per_colonna=None):
    m = _m(matrice)
    trasponi = per_colonna is not None and logico(per_colonna)
    if trasponi:
        m = [list(r) for r in zip(*m)]
    k = intero(indice) if indice is not None else 1
    o = intero(ordine) if ordine is not None else 1
    controlla(1 <= k <= len(m[0]) and o in (1, -1), VALORE)
    out = sorted(m, key=_confronta_righe([(k - 1, o)]))
    if trasponi:
        out = [list(r) for r in zip(*out)]
    return _fuori(out)


@funzione("DATI.ORDINA.PER", "SORTBY", alias=("ORDINA.PER",), minimo=2, categoria=C,
          descrizione="Ordina una matrice secondo altre colonne.", sintassi="DATI.ORDINA.PER(matrice; per1; [ordine1]; ...)")
def ordina_per(ctx, matrice, *criteri):
    m = _m(matrice)
    chiavi_col = []
    i = 0
    while i < len(criteri):
        col = [r[0] for r in _m(criteri[i])]
        controlla(len(col) == len(m), VALORE)
        o = intero(criteri[i + 1]) if i + 1 < len(criteri) else 1
        chiavi_col.append((col, o))
        i += 2
    righe = [list(r) + [c[0][j] for c in chiavi_col] for j, r in enumerate(m)]
    w = len(m[0])
    chiavi = [(w + n, c[1]) for n, c in enumerate(chiavi_col)]
    out = sorted(righe, key=_confronta_righe(chiavi))
    return _fuori([r[:w] for r in out])


def _chiave(riga: list) -> tuple:
    return tuple((v.lower() if isinstance(v, str) else v) for v in riga)


@funzione("UNICI", "UNIQUE", minimo=1, massimo=3, categoria=C, descrizione="I valori senza ripetizioni.",
          sintassi="UNICI(matrice; [per_colonna]; [solo_una_volta])")
def unici(ctx, matrice, per_colonna=None, una_volta=None):
    m = _m(matrice)
    trasponi = per_colonna is not None and logico(per_colonna)
    if trasponi:
        m = [list(r) for r in zip(*m)]
    conteggi: dict = {}
    ordine = []
    for r in m:
        k = _chiave(r)
        if k not in conteggi:
            conteggi[k] = 0
            ordine.append(r)
        conteggi[k] += 1
    if una_volta is not None and logico(una_volta):
        ordine = [r for r in ordine if conteggi[_chiave(r)] == 1]
    controlla(bool(ordine), CALC)
    if trasponi:
        ordine = [list(r) for r in zip(*ordine)]
    return _fuori(ordine)


@funzione("STACK.VERT", "VSTACK", minimo=1, categoria=C, descrizione="Mette le matrici una sotto l'altra.")
def stack_vert(ctx, *a):
    blocchi = [_m(x) for x in a]
    w = max(len(b[0]) for b in blocchi)
    out = []
    for b in blocchi:
        for r in b:
            out.append(list(r) + [Errore(ND)] * (w - len(r)))
    return _fuori(out)


@funzione("STACK.ORIZ", "HSTACK", minimo=1, categoria=C, descrizione="Mette le matrici una accanto all'altra.")
def stack_oriz(ctx, *a):
    blocchi = [_m(x) for x in a]
    h = max(len(b) for b in blocchi)
    out = [[] for _ in range(h)]
    for b in blocchi:
        w = len(b[0])
        for i in range(h):
            out[i].extend(b[i] if i < len(b) else [Errore(ND)] * w)
    return _fuori(out)


@funzione("PRENDI", "TAKE", minimo=2, massimo=3, categoria=C, descrizione="Le prime (o ultime, con numeri negativi) righe/colonne.")
def prendi(ctx, a, righe, colonne=None):
    m = _m(a)
    r = intero(righe) if righe is not None else len(m)
    m = m[:r] if r >= 0 else m[r:]
    if colonne is not None:
        c = intero(colonne)
        m = [x[:c] if c >= 0 else x[c:] for x in m]
    controlla(m and m[0], CALC)
    return _fuori(m)


@funzione("ESCLUDI", "DROP", minimo=2, massimo=3, categoria=C, descrizione="Toglie le prime (o ultime) righe/colonne.")
def escludi(ctx, a, righe, colonne=None):
    m = _m(a)
    r = intero(righe) if righe is not None else 0
    m = m[r:] if r >= 0 else m[:r]
    if colonne is not None:
        c = intero(colonne)
        m = [x[c:] if c >= 0 else x[:c] for x in m]
    controlla(m and m[0], CALC)
    return _fuori(m)


@funzione("SCEGLI.COL", "CHOOSECOLS", minimo=2, categoria=C, descrizione="Alcune colonne della matrice.")
def scegli_col(ctx, a, *colonne):
    m = _m(a)
    w = len(m[0])
    idx = []
    for c in colonne:
        k = intero(c)
        controlla(1 <= abs(k) <= w, VALORE)
        idx.append(k - 1 if k > 0 else w + k)
    return _fuori([[r[i] for i in idx] for r in m])


@funzione("SCEGLI.RIGA", "CHOOSEROWS", minimo=2, categoria=C, descrizione="Alcune righe della matrice.")
def scegli_riga(ctx, a, *righe):
    m = _m(a)
    h = len(m)
    out = []
    for r in righe:
        k = intero(r)
        controlla(1 <= abs(k) <= h, VALORE)
        out.append(m[k - 1 if k > 0 else h + k])
    return _fuori(out)


@funzione("A.COL", "TOCOL", minimo=1, massimo=3, categoria=C, descrizione="Tutti i valori in una colonna.")
def a_col(ctx, a, ignora=None, per_colonna=None):
    m = _m(a)
    if per_colonna is not None and logico(per_colonna):
        m = [list(r) for r in zip(*m)]
    k = intero(ignora) if ignora is not None else 0
    out = [[v] for r in m for v in r if not ((k in (1, 3) and v is None) or (k in (2, 3) and isinstance(v, Errore)))]
    return _fuori(out)


@funzione("A.RIGA", "TOROW", minimo=1, massimo=3, categoria=C, descrizione="Tutti i valori in una riga.")
def a_riga(ctx, a, ignora=None, per_colonna=None):
    col = a_col(ctx, a, ignora, per_colonna)
    righe = righe_di(col)
    return _fuori([[r[0] for r in righe]])


@funzione("ESPANDI", "EXPAND", minimo=2, massimo=4, categoria=C, descrizione="Allarga la matrice riempiendo con un valore.")
def espandi(ctx, a, righe, colonne=None, riempi=None):
    m = _m(a)
    h = intero(righe) if righe is not None else len(m)
    w = intero(colonne) if colonne is not None else len(m[0])
    controlla(h >= len(m) and w >= len(m[0]), VALORE)
    p = scalare(riempi) if riempi is not None else Errore(ND)
    out = [list(r) + [p] * (w - len(r)) for r in m] + [[p] * w for _ in range(h - len(m))]
    return _fuori(out)


# ---------------------------------------------------------------------------
# Riepiloghi: RAGGRUPPA.PER e PIVOT.PER
# ---------------------------------------------------------------------------

_AGGREGAZIONI = {
    "SOMMA": lambda l: sum(l),
    "MEDIA": lambda l: sum(l) / len(l) if l else Errore("#DIV/0!"),
    "CONTA": lambda l: len(l),
    "CONTA.NUMERI": lambda l: len(l),
    "CONTA.VALORI": lambda l: len(l),
    "MIN": lambda l: min(l) if l else 0,
    "MAX": lambda l: max(l) if l else 0,
    "PRODOTTO": lambda l: __import__("math").prod(l) if l else 0,
}
_ALIAS_AGG = {"SUM": "SOMMA", "AVERAGE": "MEDIA", "COUNT": "CONTA", "COUNTA": "CONTA.VALORI", "PRODUCT": "PRODOTTO"}


def _aggregazione(f: Any) -> tuple[str, Any]:
    from ..calcolo import RiferimentoFunzione
    if isinstance(f, RiferimentoFunzione):
        nome = f.nome
    else:
        nome = testo(f).strip().upper()
    nome = _ALIAS_AGG.get(nome, nome)
    controlla(nome in _AGGREGAZIONI, VALORE)
    return nome, _AGGREGAZIONI[nome]


def _applica(nome: str, fn, valori: list) -> Any:
    if nome in ("CONTA.VALORI",):
        return len([v for v in valori if v is not None and v != ""])
    nums = [v for v in valori if e_numero(v)]
    if nome == "CONTA":
        return len(nums)
    return fn(nums)


@funzione("RAGGRUPPA.PER", "GROUPBY", minimo=3, massimo=6, categoria=C,
          descrizione="Riepilogo per gruppi: RAGGRUPPA.PER(A2:A100; C2:C100; SOMMA) somma C per ogni valore di A.",
          sintassi="RAGGRUPPA.PER(campi_riga; valori; funzione; [intestazioni]; [totale]; [ordine])")
def raggruppa_per(ctx, campi, valori, funzione_, intestazioni=None, totale=None, ordine=None):
    chiavi = _m(campi)
    vals = _m(valori)
    controlla(len(chiavi) == len(vals), VALORE)
    nome, fn = _aggregazione(funzione_)
    ha_int = intestazioni is not None and intero(intestazioni) in (1, 3)
    testa_chiavi, testa_val = None, None
    if ha_int:
        testa_chiavi, testa_val = chiavi[0], vals[0]
        chiavi, vals = chiavi[1:], vals[1:]
    gruppi: dict = {}
    etichette: dict = {}
    for k, v in zip(chiavi, vals):
        if all(x is None for x in k):
            continue
        kk = _chiave(k)
        gruppi.setdefault(kk, []).append(v)
        etichette.setdefault(kk, list(k))
    righe_out = []
    w = len(vals[0]) if vals else 1
    for kk in sorted(gruppi, key=cmp_to_key(lambda a, b: _cmp_chiavi(a, b))):
        lista = gruppi[kk]
        risultati = [_applica(nome, fn, [r[j] for r in lista]) for j in range(w)]
        righe_out.append(etichette[kk] + risultati)
    if ordine is not None:
        o = intero(ordine)
        col = abs(o) - 1
        controlla(0 <= col < len(righe_out[0]) if righe_out else True, VALORE)
        righe_out.sort(key=_confronta_righe([(col, 1 if o > 0 else -1)]))
    mostra_totale = totale is None or intero(totale) != 0
    if mostra_totale and righe_out:
        tutti = [v for lista in gruppi.values() for v in lista]
        tot = [_applica(nome, fn, [r[j] for r in tutti]) for j in range(w)]
        righe_out.append(["Totale"] + [""] * (len(chiavi[0]) - 1) + tot)
    if ha_int and testa_chiavi is not None:
        righe_out.insert(0, list(testa_chiavi) + list(testa_val))
    controlla(bool(righe_out), CALC)
    return _fuori(righe_out)


def _cmp_chiavi(a: tuple, b: tuple) -> int:
    for x, y in zip(a, b):
        if x is None and y is None:
            continue
        if x is None:
            return 1
        if y is None:
            return -1
        k = confronta(x, y)
        if k:
            return k
    return 0


@funzione("PIVOT.PER", "PIVOTBY", minimo=4, massimo=8, categoria=C,
          descrizione="Tabella pivot con una formula: righe da un campo, colonne da un altro, valori aggregati.",
          sintassi="PIVOT.PER(campi_riga; campi_colonna; valori; funzione; [intestazioni])")
def pivot_per(ctx, campi_riga, campi_col, valori, funzione_, intestazioni=None, *altro):
    kr = [r[0] for r in _m(campi_riga)]
    kc = [r[0] for r in _m(campi_col)]
    vv = [r[0] for r in _m(valori)]
    controlla(len(kr) == len(kc) == len(vv), VALORE)
    nome, fn = _aggregazione(funzione_)
    testa = None
    if intestazioni is not None and intero(intestazioni) in (1, 3):
        testa = kr[0]
        kr, kc, vv = kr[1:], kc[1:], vv[1:]
    righe_k = sorted({_chiave([x])[0] for x in kr if x is not None}, key=cmp_to_key(lambda a, b: confronta(a, b)))
    col_k = sorted({_chiave([x])[0] for x in kc if x is not None}, key=cmp_to_key(lambda a, b: confronta(a, b)))
    etich_r = {}
    etich_c = {}
    celle: dict = {}
    for a, b, v in zip(kr, kc, vv):
        if a is None or b is None:
            continue
        ka, kb = _chiave([a])[0], _chiave([b])[0]
        etich_r.setdefault(ka, a)
        etich_c.setdefault(kb, b)
        celle.setdefault((ka, kb), []).append(v)
    out = [[testa if testa is not None else ""] + [etich_c[c] for c in col_k] + ["Totale"]]
    for r in righe_k:
        riga = [etich_r[r]]
        tutti = []
        for c in col_k:
            lista = celle.get((r, c), [])
            tutti += lista
            riga.append(_applica(nome, fn, lista) if lista else "")
        riga.append(_applica(nome, fn, tutti))
        out.append(riga)
    tot = ["Totale"]
    for c in col_k:
        lista = [v for (r, cc), l in celle.items() if cc == c for v in l]
        tot.append(_applica(nome, fn, lista))
    tot.append(_applica(nome, fn, [v for l in celle.values() for v in l]))
    out.append(tot)
    return _fuori(out)
