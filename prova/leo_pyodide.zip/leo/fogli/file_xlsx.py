"""File Excel (.xlsx): lettura e scrittura con formule vere, stili, più fogli, larghezze,
celle unite, riquadri bloccati, nomi definiti, formattazione condizionale e convalide.

Solo libreria standard di Python (zipfile + ElementTree). I file che arrivano da fuori
sono controllati: niente "bombe zip", niente DOCTYPE (entità XML).
"""

from __future__ import annotations

import datetime as _dt
import math
import os
import re
import zipfile
from typing import Any
from xml.etree import ElementTree as ET
from xml.sax.saxutils import escape

from . import analisi as A
from .calcolo import Cartella, Cella, Foglio
from .formato import e_formato_data
from .riferimenti import colonna, leggi_area, leggi_cella, lettere, nome_area, nome_cella
from .valori import ERRORI_IN_INGLESE, ERRORI_INGLESI, Errore, ErroreFormula, Matrice, e_numero

__all__ = ["salva_xlsx", "apri_xlsx"]

NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
NS_R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS_PKG = "http://schemas.openxmlformats.org/package/2006/relationships"
_N = "{%s}" % NS

FORMATI_INTERNI = {
    0: "", 1: "0", 2: "0.00", 3: "#,##0", 4: "#,##0.00", 9: "0%", 10: "0.00%", 11: "0.00E+00", 12: "# ?/?",
    13: "# ??/??", 14: "dd/mm/yyyy", 15: "d-mmm-yy", 16: "d-mmm", 17: "mmm-yy", 18: "h:mm AM/PM",
    19: "h:mm:ss AM/PM", 20: "hh:mm", 21: "hh:mm:ss", 22: "dd/mm/yyyy hh:mm", 37: "#,##0 ;(#,##0)",
    38: "#,##0 ;[Red](#,##0)", 39: "#,##0.00;(#,##0.00)", 40: "#,##0.00;[Red](#,##0.00)", 45: "mm:ss",
    46: "[h]:mm:ss", 47: "mmss.0", 48: "##0.0E+0", 49: "@",
}
_TEMA = ["FFFFFF", "000000", "E7E6E6", "44546A", "4472C4", "ED7D31", "A5A5A5", "FFC000", "5B9BD5", "70AD47"]
_LIMITE_DATI = 400 * 1024 * 1024


# ===========================================================================
# Scrittura
# ===========================================================================

def _colore_argb(c: str) -> str:
    c = c.lstrip("#").upper()
    if len(c) == 3:
        c = "".join(ch * 2 for ch in c)
    return "FF" + c[:6]


_BORDI = {"sottile": "thin", "medio": "medium", "spesso": "thick", "doppio": "double", "tratteggiato": "dashed",
          "punteggiato": "dotted"}
_BORDI_INV = {v: k for k, v in _BORDI.items()}
_ALLINEA = {"sinistra": "left", "centro": "center", "destra": "right", "giustificato": "justify"}
_ALLINEA_INV = {v: k for k, v in _ALLINEA.items()}
_VERT = {"alto": "top", "centro": "center", "basso": "bottom"}
_VERT_INV = {v: k for k, v in _VERT.items()}


class _Stili:
    def __init__(self) -> None:
        self.fonts = ['<font><sz val="11"/><name val="Calibri"/></font>']
        self.fills = ['<fill><patternFill patternType="none"/></fill>', '<fill><patternFill patternType="gray125"/></fill>']
        self.borders = ['<border><left/><right/><top/><bottom/><diagonal/></border>']
        self.numfmts: dict[str, int] = {}
        self.xfs = ['<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>']
        self.indice: dict[int, int] = {0: 0}
        self.dxfs: list[str] = []

    def _id(self, lista: list[str], xml: str) -> int:
        if xml in lista:
            return lista.index(xml)
        lista.append(xml)
        return len(lista) - 1

    def numfmt(self, codice: str) -> int:
        if not codice:
            return 0
        for k, v in FORMATI_INTERNI.items():
            if v == codice and k not in (14, 22):
                return k
        if codice not in self.numfmts:
            self.numfmts[codice] = 164 + len(self.numfmts)
        return self.numfmts[codice]

    def font(self, s: dict) -> str:
        parti = []
        if s.get("grassetto"):
            parti.append("<b/>")
        if s.get("corsivo"):
            parti.append("<i/>")
        if s.get("barrato"):
            parti.append("<strike/>")
        if s.get("sottolineato"):
            parti.append('<u/>')
        parti.append(f'<sz val="{s.get("dimensione", 11)}"/>')
        if s.get("colore_testo"):
            parti.append(f'<color rgb="{_colore_argb(s["colore_testo"])}"/>')
        parti.append(f'<name val="{escape(str(s.get("carattere", "Calibri")))}"/>')
        return "<font>" + "".join(parti) + "</font>"

    def xf(self, id_stile: int, s: dict) -> int:
        if id_stile in self.indice:
            return self.indice[id_stile]
        f = self._id(self.fonts, self.font(s))
        fill = 0
        if s.get("colore_sfondo"):
            fill = self._id(self.fills, f'<fill><patternFill patternType="solid"><fgColor rgb="{_colore_argb(s["colore_sfondo"])}"/>'
                                        f'<bgColor indexed="64"/></patternFill></fill>')
        bordo = 0
        lati = []
        for lato, chiave in (("left", "bordo_sinistra"), ("right", "bordo_destra"), ("top", "bordo_sopra"),
                             ("bottom", "bordo_sotto")):
            v = s.get(chiave)
            if v:
                col = _colore_argb(s.get("colore_bordo", "#000000"))
                lati.append(f'<{lato} style="{_BORDI.get(v, "thin")}"><color rgb="{col}"/></{lato}>')
            else:
                lati.append(f"<{lato}/>")
        if any("style" in x for x in lati):
            bordo = self._id(self.borders, "<border>" + "".join(lati) + "<diagonal/></border>")
        nf = self.numfmt(s.get("formato", ""))
        allin = ""
        attr = []
        if s.get("allineamento") in _ALLINEA:
            attr.append(f'horizontal="{_ALLINEA[s["allineamento"]]}"')
        if s.get("verticale") in _VERT:
            attr.append(f'vertical="{_VERT[s["verticale"]]}"')
        if s.get("a_capo"):
            attr.append('wrapText="1"')
        if s.get("rientro"):
            attr.append(f'indent="{int(s["rientro"])}"')
        if attr:
            allin = "<alignment " + " ".join(attr) + "/>"
        extra = ""
        if nf:
            extra += ' applyNumberFormat="1"'
        if f:
            extra += ' applyFont="1"'
        if fill:
            extra += ' applyFill="1"'
        if bordo:
            extra += ' applyBorder="1"'
        chiusura = ' applyAlignment="1">' + allin + "</xf>" if allin else "/>"
        xml = f'<xf numFmtId="{nf}" fontId="{f}" fillId="{fill}" borderId="{bordo}" xfId="0"' + extra + chiusura
        self.xfs.append(xml)
        self.indice[id_stile] = len(self.xfs) - 1
        return self.indice[id_stile]

    def dxf(self, s: dict) -> int:
        parti = []
        font = []
        if s.get("grassetto"):
            font.append("<b/>")
        if s.get("corsivo"):
            font.append("<i/>")
        if s.get("colore_testo"):
            font.append(f'<color rgb="{_colore_argb(s["colore_testo"])}"/>')
        if font:
            parti.append("<font>" + "".join(font) + "</font>")
        if s.get("colore_sfondo"):
            parti.append(f'<fill><patternFill patternType="solid"><bgColor rgb="{_colore_argb(s["colore_sfondo"])}"/></patternFill></fill>')
        self.dxfs.append("<dxf>" + "".join(parti) + "</dxf>")
        return len(self.dxfs) - 1

    def xml(self) -> str:
        nf = "".join(f'<numFmt numFmtId="{i}" formatCode="' + escape(c, {'"': "&quot;"}) + '"/>' for c, i in self.numfmts.items())
        return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<styleSheet xmlns="{NS}">'
                + (f'<numFmts count="{len(self.numfmts)}">{nf}</numFmts>' if self.numfmts else "")
                + f'<fonts count="{len(self.fonts)}">{"".join(self.fonts)}</fonts>'
                + f'<fills count="{len(self.fills)}">{"".join(self.fills)}</fills>'
                + f'<borders count="{len(self.borders)}">{"".join(self.borders)}</borders>'
                + '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
                + f'<cellXfs count="{len(self.xfs)}">{"".join(self.xfs)}</cellXfs>'
                + '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>'
                + f'<dxfs count="{len(self.dxfs)}">{"".join(self.dxfs)}</dxfs>'
                + "</styleSheet>")


def _testo_xml(t: str) -> str:
    t = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", t)
    return escape(t)


def _formula_inglese(ingresso: str) -> str | None:
    try:
        return A.in_inglese(ingresso)
    except ErroreFormula:
        return None


def _foglio_xml(cartella: Cartella, f: Foglio, stili: _Stili, condiviso: dict[str, int]) -> str:
    righe: dict[int, list[str]] = {}
    for (r, c), cella in sorted(f.celle.items()):
        rif = nome_cella(r, c)
        s = stili.xf(cella.stile, cartella.stili[cella.stile])
        sa = f' s="{s}"' if s else ""
        v = cella.valore
        if isinstance(v, Matrice):
            v = v.righe[0][0]
        if cella.formula is not None:
            fe = _formula_inglese(cella.ingresso)
            if fe is None:
                righe.setdefault(r, []).append(f'<c r="{rif}"{sa} t="str"><v>{_testo_xml(cella.ingresso)}</v></c>')
                continue
            dinamica = isinstance(cella.valore, Matrice)
            ftag = f'<f t="array" ref="{rif}:{nome_cella(r + cella.valore.altezza - 1, c + cella.valore.larghezza - 1)}">' \
                   f'{_testo_xml(fe)}</f>' if dinamica else f"<f>{_testo_xml(fe)}</f>"
            if isinstance(v, bool):
                righe.setdefault(r, []).append(f'<c r="{rif}"{sa} t="b">{ftag}<v>{int(v)}</v></c>')
            elif e_numero(v):
                righe.setdefault(r, []).append(f'<c r="{rif}"{sa}>{ftag}<v>{repr(float(v)) if isinstance(v, float) else v}</v></c>')
            elif isinstance(v, Errore):
                righe.setdefault(r, []).append(f'<c r="{rif}"{sa} t="e">{ftag}<v>{ERRORI_IN_INGLESE.get(v.codice, "#VALUE!")}</v></c>')
            else:
                righe.setdefault(r, []).append(f'<c r="{rif}"{sa} t="str">{ftag}<v>{_testo_xml("" if v is None else str(v))}</v></c>')
            continue
        if cella.ingresso is None:
            righe.setdefault(r, []).append(f'<c r="{rif}"{sa}/>')
        elif isinstance(v, bool):
            righe.setdefault(r, []).append(f'<c r="{rif}"{sa} t="b"><v>{int(v)}</v></c>')
        elif e_numero(v):
            righe.setdefault(r, []).append(f'<c r="{rif}"{sa}><v>{repr(float(v)) if isinstance(v, float) else v}</v></c>')
        elif isinstance(v, Errore):
            righe.setdefault(r, []).append(f'<c r="{rif}"{sa} t="e"><v>{ERRORI_IN_INGLESE.get(v.codice, "#VALUE!")}</v></c>')
        else:
            t = str(v)
            if t not in condiviso:
                condiviso[t] = len(condiviso)
            righe.setdefault(r, []).append(f'<c r="{rif}"{sa} t="s"><v>{condiviso[t]}</v></c>')
    for r in set(f.altezze) | set(f.righe_nascoste) | set(f.righe_filtrate):
        righe.setdefault(r, [])
    parti = [f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<worksheet xmlns="{NS}" xmlns:r="{NS_R}">']
    mr, mc = f.estensione()
    parti.append(f'<dimension ref="{"A1" if mr < 0 else nome_area(0, 0, max(mr, 0), max(mc, 0))}"/>')
    vista = '<sheetViews><sheetView workbookViewId="0"' + ('' if f.mostra_griglia else ' showGridLines="0"') + ">"
    br, bc = f.blocca
    if br or bc:
        divisioni = (' xSplit="%d"' % bc if bc else "") + (' ySplit="%d"' % br if br else "")
        vista += ('<pane' + divisioni + ' topLeftCell="' + nome_cella(br, bc)
                  + '" activePane="bottomRight" state="frozen"/>')
    vista += "</sheetView></sheetViews>"
    parti.append(vista)
    parti.append('<sheetFormatPr defaultRowHeight="15"/>')
    colonne = sorted(set(f.larghezze) | set(f.colonne_nascoste))
    if colonne:
        parti.append("<cols>")
        for c in colonne:
            w = f.larghezze.get(c, 64)
            larg = max(0.0, round((w - 5) / 7, 2))
            nascosta = ' hidden="1"' if c in f.colonne_nascoste else ""
            parti.append(f'<col min="{c + 1}" max="{c + 1}" width="{larg}" customWidth="1"{nascosta}/>')
        parti.append("</cols>")
    parti.append("<sheetData>")
    for r in sorted(righe):
        attr = ""
        if r in f.altezze:
            attr += f' ht="{round(f.altezze[r] * 0.75, 2)}" customHeight="1"'
        if r in f.righe_nascoste or r in f.righe_filtrate:
            attr += ' hidden="1"'
        parti.append(f'<row r="{r + 1}"{attr}>' + "".join(righe[r]) + "</row>")
    parti.append("</sheetData>")
    if f.filtro:
        parti.append(f'<autoFilter ref="{nome_area(*f.filtro["area"])}"/>')
    if f.unite:
        parti.append(f'<mergeCells count="{len(f.unite)}">' + "".join(f'<mergeCell ref="{nome_area(*u)}"/>' for u in f.unite)
                     + "</mergeCells>")
    priorita = 1
    for regola in f.condizionali:
        x = _regola_xml(regola, stili, priorita)
        if x:
            parti.append(f'<conditionalFormatting sqref="{nome_area(*regola["area"])}">{x}</conditionalFormatting>')
            priorita += 1
    convalide = [x for x in (_convalida_xml(g) for g in f.convalide) if x]
    if convalide:
        parti.append(f'<dataValidations count="{len(convalide)}">' + "".join(convalide) + "</dataValidations>")
    parti.append("</worksheet>")
    return "".join(parti)


_OP_XLSX = {"=": "equal", "<>": "notEqual", ">": "greaterThan", "<": "lessThan", ">=": "greaterThanOrEqual",
            "<=": "lessThanOrEqual", "tra": "between", "fuori": "notBetween"}
_OP_XLSX_INV = {v: k for k, v in _OP_XLSX.items()}


def _valore_regola_xml(v: Any) -> str:
    if v is None:
        return ""
    t = str(v)
    if t.startswith("="):
        e = _formula_inglese(t)
        return _testo_xml(e or t[1:])
    from .valori import leggi_inserimento
    x, _ = leggi_inserimento(t)
    if e_numero(x):
        return repr(float(x)) if isinstance(x, float) else str(x)
    return _testo_xml('"' + t.replace('"', '""') + '"')


def _regola_xml(g: dict, stili: _Stili, priorita: int) -> str:
    tipo = g.get("tipo", "valore")
    if tipo == "valore":
        d = stili.dxf(g.get("stile") or {})
        f2 = f"<formula>{_valore_regola_xml(g.get('valore2'))}</formula>" if g.get("operatore") in ("tra", "fuori") else ""
        return (f'<cfRule type="cellIs" dxfId="{d}" priority="{priorita}" operator="{_OP_XLSX.get(g.get("operatore", "="), "equal")}">'
                f"<formula>{_valore_regola_xml(g.get('valore1'))}</formula>{f2}</cfRule>")
    if tipo == "formula":
        d = stili.dxf(g.get("stile") or {})
        e = _formula_inglese(str(g.get("formula") or g.get("valore1") or "=FALSO"))
        return f'<cfRule type="expression" dxfId="{d}" priority="{priorita}"><formula>{_testo_xml(e or "FALSE")}</formula></cfRule>'
    if tipo in ("duplicati", "unici"):
        d = stili.dxf(g.get("stile") or {})
        return f'<cfRule type="{"duplicateValues" if tipo == "duplicati" else "uniqueValues"}" dxfId="{d}" priority="{priorita}"/>'
    if tipo == "scala":
        colori = g.get("colori") or ["#F8696B", "#FFEB84", "#63BE7B"]
        cfvo = '<cfvo type="min"/>' + ('<cfvo type="percentile" val="50"/>' if len(colori) == 3 else "") + '<cfvo type="max"/>'
        return (f'<cfRule type="colorScale" priority="{priorita}"><colorScale>{cfvo}'
                + "".join(f'<color rgb="{_colore_argb(c)}"/>' for c in colori) + "</colorScale></cfRule>")
    if tipo == "barre":
        return (f'<cfRule type="dataBar" priority="{priorita}"><dataBar><cfvo type="min"/><cfvo type="max"/>'
                f'<color rgb="{_colore_argb(g.get("colore", "#5B9BD5"))}"/></dataBar></cfRule>')
    return ""


def _convalida_xml(g: dict) -> str:
    tipo = g.get("tipo")
    sq = nome_area(*g["area"])
    msg = _testo_xml(str(g.get("messaggio", "")))
    errore = f' showErrorMessage="1" error="{msg}"' if g.get("blocca", True) else ""
    if tipo == "lista":
        el = str(g.get("elenco", ""))
        if el.startswith("="):
            f1 = _testo_xml(_formula_inglese(el) or el[1:])
        else:
            f1 = _testo_xml('"' + ",".join(v.strip() for v in el.replace(";", ",").split(",")) + '"')
        return f'<dataValidation type="list" allowBlank="1" showDropDown="0"{errore} sqref="{sq}"><formula1>{f1}</formula1></dataValidation>'
    mappa = {"intero": "whole", "decimale": "decimal", "data": "date", "lunghezza": "textLength", "formula": "custom"}
    if tipo not in mappa:
        return ""
    if tipo == "formula":
        f1 = _testo_xml(_formula_inglese(str(g.get("formula", "=VERO"))) or "TRUE")
        return f'<dataValidation type="custom" allowBlank="1"{errore} sqref="{sq}"><formula1>{f1}</formula1></dataValidation>'
    op = _OP_XLSX.get(g.get("operatore", "tra"), "between")
    f2 = f"<formula2>{_valore_regola_xml(g.get('valore2'))}</formula2>" if op in ("between", "notBetween") else ""
    return (f'<dataValidation type="{mappa[tipo]}" operator="{op}" allowBlank="1"{errore} sqref="{sq}">'
            f"<formula1>{_valore_regola_xml(g.get('valore1'))}</formula1>{f2}</dataValidation>")


def salva_xlsx(cartella: Cartella, percorso: str | os.PathLike) -> None:
    stili = _Stili()
    condiviso: dict[str, int] = {}
    fogli_xml = [_foglio_xml(cartella, f, stili, condiviso) for f in cartella.fogli]
    nomi = []
    for nome, testo in cartella.nomi.items():
        e = _formula_inglese(testo)
        if e:
            nomi.append(f'<definedName name="{escape(nome)}">{_testo_xml(e)}</definedName>')
    for i, f in enumerate(cartella.fogli):
        if f.filtro:
            a = f.filtro["area"]
            ref = "'" + f.nome.replace("'", "''") + f"'!{nome_cella(a[0], a[1], True, True)}:{nome_cella(a[2], a[3], True, True)}"
            nomi.append(f'<definedName name="_xlnm._FilterDatabase" localSheetId="{i}" hidden="1">{_testo_xml(ref)}</definedName>')
    workbook = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<workbook xmlns="{NS}" xmlns:r="{NS_R}">'
                '<bookViews><workbookView/></bookViews><sheets>'
                + "".join('<sheet name="' + escape(f.nome, {'"': "&quot;"}) + f'" sheetId="{i + 1}" r:id="rId{i + 1}"/>'
                          for i, f in enumerate(cartella.fogli))
                + "</sheets>" + (f"<definedNames>{''.join(nomi)}</definedNames>" if nomi else "")
                + '<calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>')
    n = len(cartella.fogli)
    rels = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="{NS_PKG}">'
            + "".join(f'<Relationship Id="rId{i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" '
                      f'Target="worksheets/sheet{i + 1}.xml"/>' for i in range(n))
            + f'<Relationship Id="rId{n + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
            + f'<Relationship Id="rId{n + 2}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>'
            + "</Relationships>")
    sst = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<sst xmlns="{NS}" count="{len(condiviso)}" uniqueCount="{len(condiviso)}">'
           + "".join(f'<si><t xml:space="preserve">{_testo_xml(t)}</t></si>' for t in condiviso) + "</sst>")
    tipi = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            + "".join(f'<Override PartName="/xl/worksheets/sheet{i + 1}.xml" '
                      'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(n))
            + '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            '<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>'
            '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
            '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
            "</Types>")
    radice = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
              f'<Relationships xmlns="{NS_PKG}">'
              '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
              '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
              '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
              "</Relationships>")
    adesso = _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    titolo = escape(str(cartella.proprieta.get("titolo", "")))
    autore = escape(str(cartella.proprieta.get("autore", "")))
    core = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
            'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" '
            'xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
            f"<dc:title>{titolo}</dc:title><dc:creator>{autore}</dc:creator>"
            f'<dcterms:created xsi:type="dcterms:W3CDTF">{adesso}</dcterms:created>'
            f'<dcterms:modified xsi:type="dcterms:W3CDTF">{adesso}</dcterms:modified></cp:coreProperties>')
    app = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
           '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">'
           "<Application>Leo Fogli</Application></Properties>")
    temporaneo = str(percorso) + ".tmp"
    with zipfile.ZipFile(temporaneo, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", tipi)
        z.writestr("_rels/.rels", radice)
        z.writestr("docProps/core.xml", core)
        z.writestr("docProps/app.xml", app)
        z.writestr("xl/workbook.xml", workbook)
        z.writestr("xl/_rels/workbook.xml.rels", rels)
        z.writestr("xl/styles.xml", stili.xml())
        z.writestr("xl/sharedStrings.xml", sst)
        for i, x in enumerate(fogli_xml):
            z.writestr(f"xl/worksheets/sheet{i + 1}.xml", x)
    os.replace(temporaneo, percorso)


# ===========================================================================
# Lettura
# ===========================================================================

def _xml(z: zipfile.ZipFile, nome: str) -> ET.Element | None:
    try:
        dati = z.read(nome)
    except KeyError:
        return None
    if b"<!DOCTYPE" in dati[:2000].upper() or b"<!ENTITY" in dati[:5000].upper():
        raise ValueError("Il file contiene costrutti XML non ammessi (DOCTYPE/ENTITY).")
    return ET.fromstring(dati)


def _figli(el: ET.Element | None) -> list[ET.Element]:
    return list(el) if el is not None else []


def _colore_da(el: ET.Element | None) -> str | None:
    if el is None:
        return None
    rgb = el.get("rgb")
    if rgb and len(rgb) >= 6:
        return "#" + rgb[-6:].upper()
    tema = el.get("theme")
    if tema is not None and tema.isdigit() and int(tema) < len(_TEMA):
        base = _TEMA[int(tema)]
        tinta = float(el.get("tint", "0") or 0)
        if tinta:
            rgb_ = [int(base[i:i + 2], 16) for i in (0, 2, 4)]
            if tinta > 0:
                rgb_ = [round(c + (255 - c) * tinta) for c in rgb_]
            else:
                rgb_ = [round(c * (1 + tinta)) for c in rgb_]
            return "#" + "".join(f"{c:02X}" for c in rgb_)
        return "#" + base
    if el.get("indexed") == "64" or el.get("auto"):
        return None
    return None


def _leggi_stili(radice: ET.Element | None) -> tuple[list[dict], list[dict]]:
    if radice is None:
        return [{}], []
    numfmts = dict(FORMATI_INTERNI)
    nf = radice.find(_N + "numFmts")
    if nf is not None:
        for x in nf:
            numfmts[int(x.get("numFmtId"))] = x.get("formatCode", "")
    fonts = []
    for f in _figli(radice.find(_N + "fonts")):
        d: dict = {}
        if f.find(_N + "b") is not None and f.find(_N + "b").get("val", "1") not in ("0", "false"):
            d["grassetto"] = True
        if f.find(_N + "i") is not None and f.find(_N + "i").get("val", "1") not in ("0", "false"):
            d["corsivo"] = True
        if f.find(_N + "u") is not None and f.find(_N + "u").get("val", "single") != "none":
            d["sottolineato"] = True
        if f.find(_N + "strike") is not None:
            d["barrato"] = True
        col = _colore_da(f.find(_N + "color"))
        if col and col not in ("#000000",):
            d["colore_testo"] = col
        sz = f.find(_N + "sz")
        if sz is not None:
            try:
                v = float(sz.get("val", "11"))
                if v != 11:
                    d["dimensione"] = int(v) if v.is_integer() else v
            except ValueError:
                pass
        nome = f.find(_N + "name")
        if nome is not None and nome.get("val") not in ("Calibri", None):
            d["carattere"] = nome.get("val")
        fonts.append(d)
    fills = []
    for f in _figli(radice.find(_N + "fills")):
        p = f.find(_N + "patternFill")
        col = None
        if p is not None and p.get("patternType") == "solid":
            col = _colore_da(p.find(_N + "fgColor")) or _colore_da(p.find(_N + "bgColor"))
        fills.append(col)
    bordi = []
    for b in _figli(radice.find(_N + "borders")):
        d = {}
        for lato, chiave in (("left", "bordo_sinistra"), ("right", "bordo_destra"), ("top", "bordo_sopra"),
                             ("bottom", "bordo_sotto")):
            x = b.find(_N + lato)
            if x is not None and x.get("style"):
                d[chiave] = _BORDI_INV.get(x.get("style"), "sottile")
                col = _colore_da(x.find(_N + "color"))
                if col and col != "#000000":
                    d["colore_bordo"] = col
        bordi.append(d)
    out = []
    for xf in _figli(radice.find(_N + "cellXfs")):
        d = {}
        d.update(fonts[int(xf.get("fontId", 0))] if int(xf.get("fontId", 0)) < len(fonts) else {})
        fid = int(xf.get("fillId", 0))
        if fid < len(fills) and fills[fid]:
            d["colore_sfondo"] = fills[fid]
        bid = int(xf.get("borderId", 0))
        if bid < len(bordi):
            d.update(bordi[bid])
        nid = int(xf.get("numFmtId", 0))
        codice = numfmts.get(nid, "")
        if codice and codice.lower() != "general":
            d["formato"] = codice
        al = xf.find(_N + "alignment")
        if al is not None:
            if al.get("horizontal") in _ALLINEA_INV:
                d["allineamento"] = _ALLINEA_INV[al.get("horizontal")]
            if al.get("vertical") in _VERT_INV and al.get("vertical") != "bottom":
                d["verticale"] = _VERT_INV[al.get("vertical")]
            if al.get("wrapText") in ("1", "true"):
                d["a_capo"] = True
            if al.get("indent"):
                d["rientro"] = int(al.get("indent"))
        out.append(d)
    dxfs = []
    for dx in _figli(radice.find(_N + "dxfs")):
        d = {}
        f = dx.find(_N + "font")
        if f is not None:
            if f.find(_N + "b") is not None:
                d["grassetto"] = True
            if f.find(_N + "i") is not None:
                d["corsivo"] = True
            col = _colore_da(f.find(_N + "color"))
            if col:
                d["colore_testo"] = col
        fl = dx.find(_N + "fill")
        if fl is not None:
            p = fl.find(_N + "patternFill")
            if p is not None:
                col = _colore_da(p.find(_N + "bgColor")) or _colore_da(p.find(_N + "fgColor"))
                if col:
                    d["colore_sfondo"] = col
        dxfs.append(d)
    return out or [{}], dxfs


def _testo_si(si: ET.Element) -> str:
    t = si.find(_N + "t")
    if t is not None and not list(si.findall(_N + "r")):
        return t.text or ""
    return "".join((x.text or "") for x in si.iter(_N + "t"))


def _formula_da_inglese(testo: str) -> str:
    try:
        return A.da_inglese(testo)
    except ErroreFormula:
        return "=" + testo


def _albero_inglese(testo: str) -> tuple:
    return A._AnalizzatoreInglese(testo).tutto()


def apri_xlsx(percorso: str | os.PathLike) -> Cartella:
    with zipfile.ZipFile(percorso) as z:
        if sum(i.file_size for i in z.infolist()) > _LIMITE_DATI:
            raise ValueError("Il file è troppo grande una volta decompresso.")
        wb = _xml(z, "xl/workbook.xml")
        if wb is None:
            raise ValueError("Non è un file Excel valido (manca xl/workbook.xml).")
        rels = _xml(z, "xl/_rels/workbook.xml.rels")
        destinazioni = {}
        if rels is not None:
            for r in rels:
                t = r.get("Target", "")
                t = t[1:] if t.startswith("/") else ("xl/" + t if not t.startswith("xl/") else t)
                destinazioni[r.get("Id")] = t
        stili, dxfs = _leggi_stili(_xml(z, "xl/styles.xml"))
        condivisi = []
        sst = _xml(z, "xl/sharedStrings.xml")
        if sst is not None:
            condivisi = [_testo_si(si) for si in sst.findall(_N + "si")]
        cartella = Cartella(nuovo_foglio=False)
        cartella.calcolo_automatico = False
        id_stili = [cartella.id_stile(s) for s in stili]
        elenco = []
        for s in _figli(wb.find(_N + "sheets")):
            rid = s.get("{%s}id" % NS_R)
            nome = s.get("name")
            f = Foglio(cartella, nome)
            cartella.fogli.append(f)
            cartella.dip_aree[f] = {}
            elenco.append((f, destinazioni.get(rid, ""), s.get("state")))
        dn = wb.find(_N + "definedNames")
        if dn is not None:
            for d in dn:
                nome = d.get("name", "")
                if nome.startswith("_xlnm.") or d.get("localSheetId") is not None:
                    continue
                if d.text:
                    cartella.nomi[nome.upper()] = _formula_da_inglese(d.text)
        for f, dove, stato in elenco:
            ws = _xml(z, dove)
            if ws is None:
                continue
            _leggi_foglio(cartella, f, ws, condivisi, id_stili, stili, dxfs)
    cartella.calcolo_automatico = True
    cartella._ricompila_tutto()
    return cartella


def _leggi_foglio(cartella: Cartella, f: Foglio, ws: ET.Element, condivisi: list[str], id_stili: list[int],
                  stili: list[dict], dxfs: list[dict]) -> None:
    condivise_formule: dict[str, tuple[tuple, int, int]] = {}
    sd = ws.find(_N + "sheetData")
    for riga in (sd if sd is not None else []):
        r_attr = riga.get("r")
        if riga.get("hidden") in ("1", "true") and r_attr:
            f.righe_nascoste.add(int(r_attr) - 1)
        if riga.get("customHeight") in ("1", "true") and riga.get("ht") and r_attr:
            f.altezze[int(r_attr) - 1] = round(float(riga.get("ht")) / 0.75)
        for c_el in riga.findall(_N + "c"):
            pos = leggi_cella(c_el.get("r", ""))
            if pos is None:
                continue
            r, c = pos
            s = int(c_el.get("s", 0) or 0)
            t = c_el.get("t", "n")
            v_el = c_el.find(_N + "v")
            f_el = c_el.find(_N + "f")
            ingresso = None
            if f_el is not None:
                tipo_f = f_el.get("t")
                testo_f = f_el.text or ""
                if tipo_f == "shared":
                    si = f_el.get("si")
                    if testo_f:
                        try:
                            condivise_formule[si] = (_albero_inglese(testo_f), r, c)
                        except ErroreFormula:
                            pass
                        ingresso = _formula_da_inglese(testo_f)
                    elif si in condivise_formule:
                        albero, r0, c0 = condivise_formule[si]
                        ingresso = "=" + A.scrivi(A.sposta(albero, r - r0, c - c0))
                elif testo_f:
                    ingresso = _formula_da_inglese(testo_f)
            if ingresso is None and v_el is not None and v_el.text is not None:
                x = v_el.text
                if t == "s":
                    try:
                        ingresso = _come_testo(condivisi[int(x)])
                    except (IndexError, ValueError):
                        ingresso = None
                elif t == "b":
                    ingresso = "VERO" if x.strip() in ("1", "true") else "FALSO"
                elif t == "e":
                    ingresso = ERRORI_INGLESI.get(x.strip(), x.strip())
                elif t in ("str", "inlineStr"):
                    ingresso = _come_testo(x)
                else:
                    try:
                        n = float(x)
                        ingresso = str(int(n)) if n.is_integer() and abs(n) < 1e15 else repr(n).replace(".", ",")
                    except ValueError:
                        ingresso = _come_testo(x)
            elif ingresso is None and t == "inlineStr":
                is_el = c_el.find(_N + "is")
                if is_el is not None:
                    ingresso = _come_testo(_testo_si(is_el))
            id_s = id_stili[s] if 0 <= s < len(id_stili) else 0
            if ingresso is None and id_s == 0:
                continue
            cella = Cella()
            cella.ingresso = ingresso
            cella.stile = id_s
            if ingresso is not None and not ingresso.startswith("="):
                from .valori import leggi_inserimento
                cella.valore = leggi_inserimento(ingresso)[0]
            f.celle[(r, c)] = cella
    cols = ws.find(_N + "cols")
    if cols is not None:
        for col in cols:
            try:
                a, b = int(col.get("min")), int(col.get("max"))
            except (TypeError, ValueError):
                continue
            if b - a > 200:
                continue
            for c in range(a - 1, b):
                if col.get("customWidth") in ("1", "true") and col.get("width"):
                    f.larghezze[c] = max(8, round(float(col.get("width")) * 7 + 5))
                if col.get("hidden") in ("1", "true"):
                    f.colonne_nascoste.add(c)
    for vista in ws.iter(_N + "pane"):
        if vista.get("state") in ("frozen", "frozenSplit"):
            f.blocca = (int(float(vista.get("ySplit", 0) or 0)), int(float(vista.get("xSplit", 0) or 0)))
    for sv in ws.iter(_N + "sheetView"):
        if sv.get("showGridLines") in ("0", "false"):
            f.mostra_griglia = False
    mc = ws.find(_N + "mergeCells")
    if mc is not None:
        for m in mc:
            a = leggi_area(m.get("ref", ""))
            if a:
                f.unite.append(a)
    af = ws.find(_N + "autoFilter")
    if af is not None and af.get("ref"):
        a = leggi_area(af.get("ref"))
        if a:
            f.filtro = {"area": list(a), "criteri": {}}
    for cf in ws.findall(_N + "conditionalFormatting"):
        for parte in (cf.get("sqref") or "").split():
            a = leggi_area(parte)
            if not a:
                continue
            for regola in cf.findall(_N + "cfRule"):
                g = _regola_da_xml(regola, list(a), dxfs)
                if g:
                    f.condizionali.append(g)
    dv = ws.find(_N + "dataValidations")
    if dv is not None:
        for d in dv:
            for parte in (d.get("sqref") or "").split():
                a = leggi_area(parte)
                if a:
                    g = _convalida_da_xml(d, list(a))
                    if g:
                        f.convalide.append(g)


def _come_testo(t: str) -> str:
    """Un testo letto dal file resta testo anche se sembra un numero o una formula."""
    from .valori import leggi_inserimento
    if t.startswith("=") or t.startswith("'") or leggi_inserimento(t)[0] != t:
        return "'" + t
    return t


def _da_formula_xml(t: str | None) -> str | None:
    if t is None:
        return None
    s = t.strip()
    if s.startswith('"') and s.endswith('"'):
        return s[1:-1].replace('""', '"')
    try:
        float(s)
        return s.replace(".", ",")
    except ValueError:
        return _formula_da_inglese(s)


def _regola_da_xml(el: ET.Element, area: list, dxfs: list[dict]) -> dict | None:
    tipo = el.get("type")
    stile = dxfs[int(el.get("dxfId"))] if el.get("dxfId") is not None and int(el.get("dxfId")) < len(dxfs) else {}
    formule = [x.text for x in el.findall(_N + "formula")]
    if tipo == "cellIs":
        return {"area": area, "tipo": "valore", "operatore": _OP_XLSX_INV.get(el.get("operator"), "="),
                "valore1": _da_formula_xml(formule[0] if formule else None),
                "valore2": _da_formula_xml(formule[1] if len(formule) > 1 else None), "stile": stile}
    if tipo == "expression" and formule:
        return {"area": area, "tipo": "formula", "formula": _formula_da_inglese(formule[0] or "FALSE"), "stile": stile}
    if tipo in ("duplicateValues", "uniqueValues"):
        return {"area": area, "tipo": "duplicati" if tipo == "duplicateValues" else "unici", "stile": stile}
    if tipo == "colorScale":
        cs = el.find(_N + "colorScale")
        colori = [c for c in (_colore_da(x) for x in cs.findall(_N + "color")) if c] if cs is not None else []
        return {"area": area, "tipo": "scala", "colori": colori or ["#F8696B", "#63BE7B"]}
    if tipo == "dataBar":
        db = el.find(_N + "dataBar")
        col = _colore_da(db.find(_N + "color")) if db is not None else None
        return {"area": area, "tipo": "barre", "colore": col or "#5B9BD5"}
    return None


def _convalida_da_xml(el: ET.Element, area: list) -> dict | None:
    tipo = el.get("type")
    f1 = el.find(_N + "formula1")
    f2 = el.find(_N + "formula2")
    t1 = f1.text if f1 is not None else None
    t2 = f2.text if f2 is not None else None
    msg = el.get("error") or ""
    blocca = el.get("showErrorMessage") in ("1", "true")
    if tipo == "list" and t1:
        if t1.startswith('"'):
            elenco = ";".join(v.strip() for v in t1.strip('"').split(","))
        else:
            elenco = _formula_da_inglese(t1)
        return {"area": area, "tipo": "lista", "elenco": elenco, "messaggio": msg, "blocca": blocca}
    mappa = {"whole": "intero", "decimal": "decimale", "date": "data", "textLength": "lunghezza", "custom": "formula"}
    if tipo in mappa:
        if tipo == "custom":
            return {"area": area, "tipo": "formula", "formula": _formula_da_inglese(t1 or "TRUE"), "messaggio": msg,
                    "blocca": blocca}
        return {"area": area, "tipo": mappa[tipo], "operatore": _OP_XLSX_INV.get(el.get("operator", "between"), "tra"),
                "valore1": _da_formula_xml(t1), "valore2": _da_formula_xml(t2), "messaggio": msg, "blocca": blocca}
    return None
