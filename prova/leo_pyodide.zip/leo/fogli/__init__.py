"""Leo Fogli: il motore di calcolo dei fogli di Leo (formule in italiano, come Excel e oltre).

Uso veloce da Python::

    from leo.fogli import Cartella
    c = Cartella()
    c.imposta(0, 0, 0, "10")          # foglio 0, riga 0 (A1)
    c.imposta(0, 1, 0, "=A1*2")
    c.valore(0, 1, 0)                 # 20

Dentro Leo lo usa il controllo ``Foglio`` (Leo Fogli) e la libreria ``fogli``.
"""

from .calcolo import Cartella, Cella, Contesto, Foglio, Rif
from .valori import Errore, Matrice

__all__ = ["Cartella", "Foglio", "Cella", "Rif", "Contesto", "Errore", "Matrice"]
