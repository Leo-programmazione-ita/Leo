"""CSV e testo: importazione con riconoscimento del separatore e dei numeri all'italiana, esportazione."""

from __future__ import annotations

import csv
import io
import os

from .calcolo import Cartella, Foglio
from .operazioni import testo_mostrato

__all__ = ["importa_csv", "esporta_csv", "indovina_separatore"]


def indovina_separatore(campione: str) -> str:
    righe = [r for r in campione.splitlines()[:20] if r.strip()]
    migliore, punti = ";", -1
    for sep in (";", "\t", ",", "|"):
        conteggi = [r.count(sep) for r in righe]
        if conteggi and min(conteggi) > 0:
            costanza = len(set(conteggi)) == 1
            p = min(conteggi) * (3 if costanza else 1)
            if p > punti:
                migliore, punti = sep, p
    return migliore


def _leggi(percorso: str | os.PathLike) -> str:
    dati = open(percorso, "rb").read()
    for codifica in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return dati.decode(codifica)
        except UnicodeDecodeError:
            continue
    return dati.decode("utf-8", errors="replace")


def importa_csv(cartella: Cartella, foglio: Foglio, percorso: str | os.PathLike, separatore: str | None = None,
                r: int = 0, c: int = 0) -> int:
    """Legge un CSV nel foglio a partire da (r, c). Restituisce quante righe ha letto."""
    testo = _leggi(percorso)
    sep = separatore or indovina_separatore(testo[:20000])
    lettore = csv.reader(io.StringIO(testo), delimiter=sep)
    n = 0
    with cartella.operazione("Importa CSV"):
        for i, riga in enumerate(lettore):
            for j, valore in enumerate(riga):
                if valore != "":
                    if valore.startswith("="):
                        valore = "'" + valore      # un CSV non porta formule (sicurezza)
                    cartella._imposta_ingresso(foglio, r + i, c + j, valore)
            n += 1
    return n


def esporta_csv(cartella: Cartella, foglio: Foglio, percorso: str | os.PathLike, separatore: str = ";",
                come_si_vede: bool = True) -> None:
    mr, mc = foglio.estensione()
    with open(percorso, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, delimiter=separatore, quoting=csv.QUOTE_MINIMAL)
        for r in range(mr + 1):
            riga = []
            for c in range(mc + 1):
                if come_si_vede:
                    t = testo_mostrato(cartella, foglio, r, c)[0]
                else:
                    v = foglio.valore(r, c)
                    t = "" if v is None else str(v)
                if t[:1] in ("=", "+", "-", "@") and not _sembra_numero(t):
                    t = "'" + t                    # niente "formula injection" nei CSV
                riga.append(t)
            w.writerow(riga)


def _sembra_numero(t: str) -> bool:
    from .valori import numero_da_testo
    return numero_da_testo(t) is not None
