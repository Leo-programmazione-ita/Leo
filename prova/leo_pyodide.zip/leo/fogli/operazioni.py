"""Operazioni sul foglio: copia e incolla, riempimento intelligente, righe e colonne,
ordinamento, filtri, trova e sostituisci, celle unite, testo da mostrare."""

from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass, field
from typing import Any, Iterable

from . import analisi as A
from .calcolo import Cartella, Cella, Foglio
from .formato import GIORNI, MESI, e_formato_data, formatta
from .riferimenti import MAX_COLONNE, MAX_RIGHE
from .valori import RIF, Errore, ErroreFormula, Matrice, confronta, e_numero, testo_generale

__all__ = [
    "Appunti", "copia", "incolla", "incolla_testo", "testo_per_appunti", "riempi", "inserisci_righe",
    "elimina_righe", "inserisci_colonne", "elimina_colonne", "ordina", "imposta_filtro", "filtra_colonna",
    "togli_filtro", "valori_colonna", "trova", "sostituisci", "unisci_celle", "separa_celle", "testo_mostrato",
    "svuota", "sposta_area",
]

Area = tuple[int, int, int, int]


# ===========================================================================
# Testo da mostrare
# ===========================================================================

def testo_mostrato(cartella: Cartella, foglio: Foglio, r: int, c: int) -> tuple[str, str | None, str]:
    """(testo, colore del formato o None, allineamento naturale "sinistra"/"destra"/"centro")."""
    v = foglio.valore(r, c)
    stile = cartella.stile(foglio, r, c)
    if v is None:
        return "", None, "sinistra"
    testo, colore = formatta(v, stile.get("formato"))
    if isinstance(v, bool) or isinstance(v, Errore):
        return testo, colore, "centro"
    if e_numero(v):
        return testo, colore, "destra"
    return testo, colore, "sinistra"


# ===========================================================================
# Copia e incolla
# ===========================================================================

@dataclass
class Appunti:
    foglio: Foglio | None
    area: Area
    celle: list[list[tuple[str | None, dict, str | None]]] = field(default_factory=list)
    tagliate: bool = False


def copia(cartella: Cartella, foglio: Foglio, area: Area, taglia: bool = False) -> Appunti:
    r1, c1, r2, c2 = area
    righe = []
    for r in range(r1, r2 + 1):
        riga = []
        for c in range(c1, c2 + 1):
            cella = foglio.celle.get((r, c))
            if cella is None:
                riga.append((None, {}, None))
            else:
                riga.append((cella.ingresso, dict(cartella.stili[cella.stile]), cella.nota))
        righe.append(riga)
    return Appunti(foglio, area, righe, taglia)


def testo_per_appunti(cartella: Cartella, foglio: Foglio, area: Area) -> str:
    """Il testo da mettere negli appunti di sistema (si incolla in Excel, Word, e-mail)."""
    r1, c1, r2, c2 = area
    righe = []
    for r in range(r1, r2 + 1):
        if r in foglio.righe_filtrate:
            continue
        valori = []
        for c in range(c1, c2 + 1):
            t = testo_mostrato(cartella, foglio, r, c)[0]
            if any(ch in t for ch in '\t\n"'):
                t = '"' + t.replace('"', '""') + '"'
            valori.append(t)
        righe.append("\t".join(valori))
    return "\r\n".join(righe)


def _formula_spostata(ingresso: str, dr: int, dc: int) -> str:
    try:
        return "=" + A.scrivi(A.sposta(A.analizza(ingresso), dr, dc))
    except ErroreFormula:
        return ingresso


def incolla(cartella: Cartella, foglio: Foglio, r: int, c: int, appunti: Appunti, *, valori: bool = False,
            formati: bool = False, trasponi: bool = False, destinazione: Area | None = None) -> Area:
    """Incolla gli appunti con l'angolo in alto a sinistra in (r, c). Restituisce l'area scritta.

    Le formule si spostano come in Excel (i riferimenti relativi seguono). Se ``destinazione``
    è un multiplo esatto della copia, la copia si ripete per riempirla."""
    righe = appunti.celle
    if trasponi:
        righe = [list(x) for x in zip(*righe)]
    h, w = len(righe), len(righe[0])
    ripeti_r = ripeti_c = 1
    if destinazione is not None:
        dh = destinazione[2] - destinazione[0] + 1
        dw = destinazione[3] - destinazione[1] + 1
        if dh % h == 0 and dw % w == 0:
            ripeti_r, ripeti_c = dh // h, dw // w
    with cartella.operazione("Incolla"):
        if appunti.tagliate and appunti.foglio is not None and not valori and not formati:
            sposta_area(cartella, appunti.foglio, appunti.area, foglio, r, c)
            return (r, c, r + h - 1, c + w - 1)
        sr1, sc1 = appunti.area[0], appunti.area[1]
        for ir in range(ripeti_r):
            for ic in range(ripeti_c):
                for i in range(h):
                    for j in range(w):
                        rr, cc = r + ir * h + i, c + ic * w + j
                        if rr >= MAX_RIGHE or cc >= MAX_COLONNE:
                            continue
                        ingresso, stile, nota = righe[i][j]
                        orig_r = sr1 + (j if trasponi else i)
                        orig_c = sc1 + (i if trasponi else j)
                        if not formati:
                            if ingresso is not None and ingresso.startswith("=") and len(ingresso) > 1:
                                if valori:
                                    v = appunti.foglio.valore(orig_r, orig_c) if appunti.foglio else None
                                    cartella._imposta_ingresso(foglio, rr, cc, _testo_valore(v), formato_auto=False)
                                else:
                                    cartella._imposta_ingresso(foglio, rr, cc,
                                                               _formula_spostata(ingresso, rr - orig_r, cc - orig_c))
                            else:
                                cartella._imposta_ingresso(foglio, rr, cc, ingresso, formato_auto=False)
                        if not valori:
                            cartella.sostituisci_stile(foglio, rr, cc, cartella.id_stile(stile))
                            if nota is not None:
                                cella = foglio.celle.get((rr, cc))
                                if cella is not None:
                                    cella.nota = nota
    return (r, c, r + h * ripeti_r - 1, c + w * ripeti_c - 1)


def _testo_valore(v: Any) -> str | None:
    from .calcolo import _testo_di_valore
    if isinstance(v, str):
        from .valori import leggi_inserimento
        if v.startswith("=") or leggi_inserimento(v)[0] != v:
            return "'" + v
    return _testo_di_valore(v)


def leggi_testo_tabellare(testo: str) -> list[list[str]]:
    """Testo copiato da Excel, da una pagina web o da un CSV -> righe di celle."""
    testo = testo.replace("\r\n", "\n").replace("\r", "\n")
    if testo.endswith("\n"):
        testo = testo[:-1]
    sep = "\t" if "\t" in testo else (";" if testo.count(";") > testo.count(",") else ("," if "," in testo and "\n" in testo else "\t"))
    lettore = csv.reader(io.StringIO(testo), delimiter=sep, quotechar='"')
    return [riga for riga in lettore]


def incolla_testo(cartella: Cartella, foglio: Foglio, r: int, c: int, testo: str) -> Area:
    righe = leggi_testo_tabellare(testo)
    if not righe:
        return (r, c, r, c)
    w = max(len(x) for x in righe)
    with cartella.operazione("Incolla"):
        for i, riga in enumerate(righe):
            for j, valore in enumerate(riga):
                if r + i < MAX_RIGHE and c + j < MAX_COLONNE:
                    cartella._imposta_ingresso(foglio, r + i, c + j, valore if valore != "" else None)
    return (r, c, r + len(righe) - 1, c + w - 1)


def svuota(cartella: Cartella, foglio: Foglio, area: Area, *, contenuto: bool = True, formati: bool = False) -> None:
    r1, c1, r2, c2 = area
    with cartella.operazione("Cancella"):
        chiavi = [k for k in list(foglio.celle) if r1 <= k[0] <= r2 and c1 <= k[1] <= c2]
        for (r, c) in chiavi:
            if contenuto:
                cartella._imposta_ingresso(foglio, r, c, None)
            if formati:
                cartella.sostituisci_stile(foglio, r, c, 0)


def sposta_area(cartella: Cartella, da_foglio: Foglio, area: Area, a_foglio: Foglio, r: int, c: int) -> None:
    """Taglia e incolla: sposta le celle e aggiorna le formule che le usavano (come Excel)."""
    r1, c1, r2, c2 = area
    dr, dc = r - r1, c - c1
    if dr == 0 and dc == 0 and da_foglio is a_foglio:
        return
    with cartella.operazione("Sposta"):
        cartella._registra_struttura()
        contenuti = {}
        for rr in range(r1, r2 + 1):
            for cc in range(c1, c2 + 1):
                cella = da_foglio.celle.get((rr, cc))
                contenuti[(rr, cc)] = None if cella is None else (cella.ingresso, cella.stile, cella.nota)
        nome_dest = a_foglio.nome

        def aggiorna(nodo: tuple, foglio_formula: Foglio) -> tuple:
            stesso = (nodo[1] is None and foglio_formula is da_foglio) or (
                nodo[1] is not None and nodo[1].lower() == da_foglio.nome.lower())
            if not stesso:
                return nodo
            if nodo[0] == "c":
                _, f, rr, cc, ar, ac = nodo
                if r1 <= rr <= r2 and c1 <= cc <= c2:
                    nf = f if a_foglio is foglio_formula and f is None else (None if a_foglio is foglio_formula else nome_dest)
                    return ("c", nf, rr + dr, cc + dc, ar, ac)
                return nodo
            _, f, a1, b1, a2, b2, ar1, ac1, ar2, ac2, genere = nodo
            if genere == "celle" and r1 <= a1 and a2 <= r2 and c1 <= b1 and b2 <= c2:
                nf = None if a_foglio is foglio_formula else nome_dest
                return ("a", nf, a1 + dr, b1 + dc, a2 + dr, b2 + dc, ar1, ac1, ar2, ac2, genere)
            return nodo

        for g in cartella.fogli:
            for (rr, cc), cella in list(g.celle.items()):
                if cella.formula is not None and not (g is da_foglio and (rr, cc) in contenuti):
                    nuovo = A.trasforma_riferimenti(cella.formula.albero, lambda n, g=g: aggiorna(n, g))
                    cella.ingresso = "=" + A.scrivi(nuovo)
        # le formule spostate: i riferimenti interni all'area seguono, gli altri restano fermi
        for (rr, cc), dati in contenuti.items():
            if dati is not None and dati[0] and dati[0].startswith("="):
                try:
                    albero = A.analizza(dati[0])

                    def interna(n: tuple) -> tuple:
                        if n[0] == "c" and n[1] is None and r1 <= n[2] <= r2 and c1 <= n[3] <= c2:
                            return ("c", None, n[2] + dr, n[3] + dc, n[4], n[5])
                        if n[0] == "a" and n[1] is None and n[10] == "celle" and r1 <= n[2] and n[4] <= r2 \
                                and c1 <= n[3] and n[5] <= c2:
                            return ("a", None, n[2] + dr, n[3] + dc, n[4] + dr, n[5] + dc) + n[6:]
                        if n[1] is None and a_foglio is not da_foglio:
                            return (n[0], da_foglio.nome) + n[2:]
                        return n
                    contenuti[(rr, cc)] = ("=" + A.scrivi(A.trasforma_riferimenti(albero, interna)),) + dati[1:]
                except ErroreFormula:
                    pass
            da_foglio.celle.pop((rr, cc), None)
        for (rr, cc), dati in contenuti.items():
            a_foglio.celle.pop((rr + dr, cc + dc), None)
        for (rr, cc), dati in contenuti.items():
            if dati is None:
                continue
            cella = Cella()
            cella.ingresso, cella.stile, cella.nota = dati
            if cella.ingresso is not None and not cella.ingresso.startswith("="):
                from .valori import leggi_inserimento
                cella.valore = leggi_inserimento(cella.ingresso)[0]
            a_foglio.celle[(rr + dr, cc + dc)] = cella
        da_foglio._estensione = None
        a_foglio._estensione = None
        cartella._ricompila_tutto()


# ===========================================================================
# Riempimento intelligente (trascina la maniglia)
# ===========================================================================

_ABBR_MESI = [m[:3] for m in MESI]
_ABBR_GIORNI = [g[:3] for g in GIORNI]
_RE_NUMERO_FINALE = re.compile(r"^(.*?)(\d+)(\D*)$")


def _caso(modello: str, testo: str) -> str:
    if modello.isupper():
        return testo.upper()
    if modello[:1].isupper():
        return testo[:1].upper() + testo[1:]
    return testo


def _serie_nomi(valori: list[str]) -> list | None:
    for elenco in (MESI, _ABBR_MESI, GIORNI, _ABBR_GIORNI):
        idx = [elenco.index(v.lower()) if v.lower() in elenco else -1 for v in valori]
        if all(i >= 0 for i in idx):
            passo = (idx[1] - idx[0]) % len(elenco) if len(idx) > 1 else 1
            return [elenco, idx[-1], passo, valori[-1]]
    return None


def _genera_serie(sorgente: list[tuple[str | None, Any, bool]], n: int) -> list[str | None]:
    """sorgente: (ingresso, valore, è_data) delle celle di partenza; n celle da riempire."""
    ingressi = [s[0] for s in sorgente]
    valori = [s[1] for s in sorgente]
    if all(i is None for i in ingressi):
        return [None] * n
    if all(e_numero(v) and not (i or "").startswith("=") for i, v in zip(ingressi, valori)) and ingressi:
        if len(valori) == 1:
            if sorgente[0][2]:          # una data sola: un giorno alla volta
                return [_numero_testo(valori[0] + k + 1, True) for k in range(n)]
            return [ingressi[0]] * n
        # regressione lineare come Excel (con 2 valori è il passo)
        m = len(valori)
        xs = list(range(m))
        mx, my = sum(xs) / m, sum(valori) / m
        sxx = sum((x - mx) ** 2 for x in xs)
        b = sum((x - mx) * (y - my) for x, y in zip(xs, valori)) / sxx
        a = my - b * mx
        data = sorgente[0][2]
        return [_numero_testo(a + b * (m + k), data) for k in range(n)]
    testi = [i for i in ingressi if i is not None]
    if all(isinstance(v, str) for v in valori) and testi:
        nomi = _serie_nomi([str(v) for v in valori])
        if nomi:
            elenco, ultimo, passo, modello = nomi
            out = []
            for k in range(n):
                ultimo = (ultimo + passo) % len(elenco)
                out.append(_caso(modello, elenco[ultimo]))
            return out
        corrispondenze = [_RE_NUMERO_FINALE.match(str(v)) for v in valori]
        if all(corrispondenze) and len({m.group(1) for m in corrispondenze}) == 1:
            numeri = [int(m.group(2)) for m in corrispondenze]
            passo = numeri[-1] - numeri[-2] if len(numeri) > 1 else 1
            pre, suf = corrispondenze[-1].group(1), corrispondenze[-1].group(3)
            larghezza = len(corrispondenze[-1].group(2))
            out = []
            x = numeri[-1]
            for k in range(n):
                x += passo
                s = str(x).zfill(larghezza) if corrispondenze[-1].group(2).startswith("0") else str(x)
                out.append(f"{pre}{s}{suf}")
            return out
    return [ingressi[k % len(ingressi)] for k in range(n)]


def _numero_testo(x: float, data: bool) -> str:
    if isinstance(x, float) and abs(x - round(x)) < 1e-9:
        x = int(round(x))
    if isinstance(x, int):
        return str(x)
    return testo_generale(x)


def riempi(cartella: Cartella, foglio: Foglio, sorgente: Area, destinazione: Area, serie: bool = True) -> None:
    """Riempie ``destinazione`` partendo da ``sorgente`` (che ne è l'inizio o la fine), come la maniglia di Excel."""
    sr1, sc1, sr2, sc2 = sorgente
    dr1, dc1, dr2, dc2 = destinazione
    verticale = (dc1, dc2) == (sc1, sc2)
    with cartella.operazione("Riempi"):
        if verticale:
            indietro = dr1 < sr1
            for c in range(sc1, sc2 + 1):
                rr = list(range(sr1, sr2 + 1))
                _riempi_linea(cartella, foglio, [(r, c) for r in rr],
                              [(r, c) for r in (range(dr1, sr1) if indietro else range(sr2 + 1, dr2 + 1))],
                              indietro, serie)
        else:
            indietro = dc1 < sc1
            for r in range(sr1, sr2 + 1):
                cc = list(range(sc1, sc2 + 1))
                _riempi_linea(cartella, foglio, [(r, c) for c in cc],
                              [(r, c) for c in (range(dc1, sc1) if indietro else range(sc2 + 1, dc2 + 1))],
                              indietro, serie)


def _riempi_linea(cartella: Cartella, foglio: Foglio, sorgenti: list, destinazioni: list, indietro: bool,
                  serie: bool) -> None:
    if not destinazioni:
        return
    if indietro:
        sorgenti = list(reversed(sorgenti))
        destinazioni = list(reversed(destinazioni))
    dati = []
    for (r, c) in sorgenti:
        cella = foglio.celle.get((r, c))
        ingresso = None if cella is None else cella.ingresso
        stile = cartella.stile(foglio, r, c)
        dati.append((ingresso, foglio.valore(r, c), e_formato_data(stile.get("formato"))))
    formule = any(d[0] and d[0].startswith("=") for d in dati)
    if formule or not serie:
        generati = None
    else:
        generati = _genera_serie(dati, len(destinazioni))
        if indietro and generati and all(e_numero(d[1]) for d in dati) and len(dati) > 1:
            pass
    for k, (r, c) in enumerate(destinazioni):
        sr, sc = sorgenti[k % len(sorgenti)]
        cella = foglio.celle.get((sr, sc))
        if generati is None:
            ingresso = None if cella is None else cella.ingresso
            if ingresso and ingresso.startswith("="):
                ingresso = _formula_spostata(ingresso, r - sr, c - sc)
        else:
            ingresso = generati[k]
        cartella._imposta_ingresso(foglio, r, c, ingresso, formato_auto=False)
        cartella.sostituisci_stile(foglio, r, c, 0 if cella is None else cella.stile)


# ===========================================================================
# Righe e colonne
# ===========================================================================

def _cambia_struttura(cartella: Cartella, foglio: Foglio, asse: str, inizio: int, quanti: int) -> None:
    """Inserisce (quanti > 0) o elimina (quanti < 0) righe/colonne e aggiorna tutto il resto."""
    eliminate = quanti < 0
    n = abs(quanti)
    fine_elim = inizio + n - 1
    limite = MAX_RIGHE if asse == "r" else MAX_COLONNE

    def sposta_indice(i: int) -> int | None:
        if eliminate:
            if inizio <= i <= fine_elim:
                return None
            return i - n if i > fine_elim else i
        return i + n if i >= inizio else i

    def sposta_intervallo(a: int, b: int) -> tuple[int, int] | None:
        if eliminate:
            if a >= inizio and b <= fine_elim:
                return None
            na = a if a < inizio else (inizio if a <= fine_elim else a - n)
            nb = b if b < inizio else (inizio - 1 if b <= fine_elim else b - n)
            return na, nb
        na = a + n if a >= inizio else a
        nb = b + n if b >= inizio else b
        return na, min(nb, limite - 1)

    def aggiorna(nodo: tuple, foglio_formula: Foglio) -> tuple:
        stesso = (nodo[1] is None and foglio_formula is foglio) or (
            nodo[1] is not None and nodo[1].lower() == foglio.nome.lower())
        if not stesso:
            return nodo
        if nodo[0] == "c":
            _, f, r, c, ar, ac = nodo
            if asse == "r":
                nr = sposta_indice(r)
                return ("e", RIF) if nr is None or nr >= limite else ("c", f, nr, c, ar, ac)
            nc = sposta_indice(c)
            return ("e", RIF) if nc is None or nc >= limite else ("c", f, r, nc, ar, ac)
        _, f, r1, c1, r2, c2, ar1, ac1, ar2, ac2, genere = nodo
        if asse == "r":
            if genere == "colonne":
                return nodo
            x = sposta_intervallo(min(r1, r2), max(r1, r2))
            if x is None:
                return ("e", RIF)
            return ("a", f, x[0], c1, x[1], c2, ar1, ac1, ar2, ac2, genere)
        if genere == "righe":
            return nodo
        x = sposta_intervallo(min(c1, c2), max(c1, c2))
        if x is None:
            return ("e", RIF)
        return ("a", f, r1, x[0], r2, x[1], ar1, ac1, ar2, ac2, genere)

    with cartella.operazione("Inserisci" if not eliminate else "Elimina"):
        cartella._registra_struttura()
        # 1) le formule di tutta la cartella
        for g in cartella.fogli:
            for cella in g.celle.values():
                if cella.formula is not None:
                    try:
                        nuovo = A.trasforma_riferimenti(cella.formula.albero, lambda x, g=g: aggiorna(x, g))
                        cella.ingresso = "=" + A.scrivi(nuovo)
                    except Exception:  # noqa: BLE001
                        pass
        for nome, testo in list(cartella.nomi.items()):
            try:
                albero = A.analizza(testo)

                def aggiorna_nome(x: tuple) -> tuple:
                    if x[1] is None:
                        return x
                    return aggiorna(x, None)  # type: ignore[arg-type]
                cartella.nomi[nome] = "=" + A.scrivi(A.trasforma_riferimenti(albero, aggiorna_nome))
            except ErroreFormula:
                pass
        # 2) le celle del foglio
        nuove = {}
        for (r, c), cella in foglio.celle.items():
            if asse == "r":
                nr = sposta_indice(r)
                if nr is not None and nr < limite:
                    nuove[(nr, c)] = cella
            else:
                nc = sposta_indice(c)
                if nc is not None and nc < limite:
                    nuove[(r, nc)] = cella
        foglio.celle = nuove
        foglio.spill.clear()
        foglio.aree_spill.clear()
        foglio.spill_bloccati.clear()
        # 3) dimensioni, nascoste, unite, regole
        if asse == "r":
            foglio.altezze = {sposta_indice(r): h for r, h in foglio.altezze.items() if sposta_indice(r) is not None}
            foglio.righe_nascoste = {sposta_indice(r) for r in foglio.righe_nascoste if sposta_indice(r) is not None}
            foglio.righe_filtrate = {sposta_indice(r) for r in foglio.righe_filtrate if sposta_indice(r) is not None}
        else:
            foglio.larghezze = {sposta_indice(c): w for c, w in foglio.larghezze.items() if sposta_indice(c) is not None}
            foglio.colonne_nascoste = {sposta_indice(c) for c in foglio.colonne_nascoste if sposta_indice(c) is not None}

        def area_nuova(a: Iterable[int]) -> list[int] | None:
            r1, c1, r2, c2 = a
            if asse == "r":
                x = sposta_intervallo(r1, r2)
                return None if x is None else [x[0], c1, x[1], c2]
            x = sposta_intervallo(c1, c2)
            return None if x is None else [r1, x[0], r2, x[1]]

        foglio.unite = [tuple(u) for u in (area_nuova(u) for u in foglio.unite) if u is not None]
        for regole in (foglio.condizionali, foglio.convalide):
            tenute = []
            for regola in regole:
                a = area_nuova(regola["area"])
                if a is not None:
                    regola["area"] = a
                    tenute.append(regola)
            regole[:] = tenute
        if foglio.filtro:
            a = area_nuova(foglio.filtro["area"])
            if a is None:
                foglio.filtro = None
            else:
                foglio.filtro["area"] = a
        foglio._estensione = None
        cartella._ricompila_tutto()


def inserisci_righe(cartella: Cartella, foglio: Foglio, riga: int, quante: int = 1) -> None:
    _cambia_struttura(cartella, foglio, "r", riga, quante)


def elimina_righe(cartella: Cartella, foglio: Foglio, riga: int, quante: int = 1) -> None:
    _cambia_struttura(cartella, foglio, "r", riga, -quante)


def inserisci_colonne(cartella: Cartella, foglio: Foglio, colonna: int, quante: int = 1) -> None:
    _cambia_struttura(cartella, foglio, "c", colonna, quante)


def elimina_colonne(cartella: Cartella, foglio: Foglio, colonna: int, quante: int = 1) -> None:
    _cambia_struttura(cartella, foglio, "c", colonna, -quante)


# ===========================================================================
# Ordinamento
# ===========================================================================

def ordina(cartella: Cartella, foglio: Foglio, area: Area, chiavi: list[tuple[int, bool]],
           intestazione: bool = False) -> None:
    """Ordina le righe dell'area. ``chiavi``: [(colonna, crescente), ...] con le colonne del foglio."""
    from functools import cmp_to_key
    r1, c1, r2, c2 = area
    if intestazione:
        r1 += 1
    if r1 > r2:
        return
    righe = []
    for r in range(r1, r2 + 1):
        celle = []
        for c in range(c1, c2 + 1):
            cella = foglio.celle.get((r, c))
            celle.append(None if cella is None else (cella.ingresso, cella.stile, cella.nota))
        righe.append((r, celle, [foglio.valore(r, k) for k, _ in chiavi]))

    def cmp(a, b):
        for i, (_, crescente) in enumerate(chiavi):
            x, y = a[2][i], b[2][i]
            if x is None and y is None:
                continue
            if x is None or x == "":
                return 1
            if y is None or y == "":
                return -1
            try:
                k = confronta(x, y)
            except ErroreFormula:
                k = 0
            if k:
                return k if crescente else -k
        return 0

    ordinate = sorted(righe, key=cmp_to_key(cmp))
    with cartella.operazione("Ordina"):
        for i, (r_orig, celle, _) in enumerate(ordinate):
            r = r1 + i
            for j, dati in enumerate(celle):
                c = c1 + j
                if dati is None:
                    cartella._imposta_ingresso(foglio, r, c, None)
                    cartella.sostituisci_stile(foglio, r, c, 0)
                    continue
                ingresso, stile, nota = dati
                if ingresso and ingresso.startswith("="):
                    ingresso = _formula_spostata(ingresso, r - r_orig, 0)
                cartella._imposta_ingresso(foglio, r, c, ingresso, formato_auto=False)
                cartella.sostituisci_stile(foglio, r, c, stile)
                cella = foglio.celle.get((r, c))
                if cella is not None:
                    cella.nota = nota


# ===========================================================================
# Filtri
# ===========================================================================

def imposta_filtro(cartella: Cartella, foglio: Foglio, area: Area) -> None:
    """Attiva il filtro (la prima riga dell'area è l'intestazione)."""
    with cartella.operazione("Filtro"):
        cartella._registra_struttura()
        foglio.filtro = {"area": list(area), "criteri": {}}
        foglio.righe_filtrate.clear()
    cartella.ricalcola_tutto()


def togli_filtro(cartella: Cartella, foglio: Foglio) -> None:
    with cartella.operazione("Togli filtro"):
        cartella._registra_struttura()
        foglio.filtro = None
        foglio.righe_filtrate.clear()
    cartella.ricalcola_tutto()


def valori_colonna(cartella: Cartella, foglio: Foglio, colonna: int) -> list[str]:
    """I diversi testi (come si vedono) di una colonna del filtro, in ordine."""
    if not foglio.filtro:
        return []
    r1, _c1, r2, _c2 = foglio.filtro["area"]
    mr = min(r2, foglio.estensione()[0])
    visti = {}
    for r in range(r1 + 1, mr + 1):
        t = testo_mostrato(cartella, foglio, r, colonna)[0]
        visti.setdefault(t, foglio.valore(r, colonna))
    from functools import cmp_to_key

    def cmp(a, b):
        va, vb = visti[a], visti[b]
        try:
            return confronta(va, vb)
        except ErroreFormula:
            return 0
    return sorted(visti, key=cmp_to_key(cmp))


def filtra_colonna(cartella: Cartella, foglio: Foglio, colonna: int, criterio: dict | None) -> None:
    """criterio: {"valori": [testi da tenere]} oppure {"condizione": ">10"}; None toglie il criterio della colonna."""
    if not foglio.filtro:
        raise ValueError("Prima attiva il filtro sulla tabella.")
    with cartella.operazione("Filtra"):
        cartella._registra_struttura()
        criteri = foglio.filtro.setdefault("criteri", {})
        if criterio is None:
            criteri.pop(str(colonna), None)
        else:
            criteri[str(colonna)] = criterio
        _applica_filtro(cartella, foglio)
    cartella.ricalcola_tutto()


def _applica_filtro(cartella: Cartella, foglio: Foglio) -> None:
    from .funzioni._aiuti import criterio as crea_criterio
    foglio.righe_filtrate.clear()
    if not foglio.filtro:
        return
    r1, _c1, r2, _c2 = foglio.filtro["area"]
    mr = min(r2, max(foglio.estensione()[0], r1))
    prove = []
    for col, crit in foglio.filtro.get("criteri", {}).items():
        c = int(col)
        if "valori" in crit:
            tenuti = set(crit["valori"])
            prove.append(lambda r, c=c, t=tenuti: testo_mostrato(cartella, foglio, r, c)[0] in t)
        elif "condizione" in crit:
            p = crea_criterio(crit["condizione"])
            prove.append(lambda r, c=c, p=p: p(foglio.valore(r, c)))
    for r in range(r1 + 1, mr + 1):
        if not all(p(r) for p in prove):
            foglio.righe_filtrate.add(r)


# ===========================================================================
# Trova e sostituisci
# ===========================================================================

def trova(cartella: Cartella, cosa: str, *, fogli: list[Foglio] | None = None, nelle_formule: bool = True,
          maiuscole: bool = False, cella_intera: bool = False) -> list[tuple[Foglio, int, int]]:
    if not cosa:
        return []
    ago = cosa if maiuscole else cosa.lower()
    out = []
    for f in fogli or cartella.fogli:
        for (r, c) in sorted(set(f.celle) | set(f.spill)):
            cella = f.celle.get((r, c))
            if nelle_formule and cella is not None and cella.ingresso is not None:
                t = cella.ingresso
            else:
                t = testo_mostrato(cartella, f, r, c)[0]
            if not maiuscole:
                t = t.lower()
            if (t == ago) if cella_intera else (ago in t):
                out.append((f, r, c))
    return out


def sostituisci(cartella: Cartella, cosa: str, con: str, *, fogli: list[Foglio] | None = None,
                maiuscole: bool = False, cella_intera: bool = False) -> int:
    trovate = trova(cartella, cosa, fogli=fogli, nelle_formule=True, maiuscole=maiuscole, cella_intera=cella_intera)
    schema = re.compile(re.escape(cosa), 0 if maiuscole else re.IGNORECASE)
    n = 0
    with cartella.operazione("Sostituisci"):
        for f, r, c in trovate:
            cella = f.celle.get((r, c))
            if cella is None or cella.ingresso is None:
                continue
            nuovo = con if cella_intera else schema.sub(lambda m: con, cella.ingresso)
            if nuovo != cella.ingresso:
                cartella._imposta_ingresso(f, r, c, nuovo)
                n += 1
    return n


# ===========================================================================
# Celle unite
# ===========================================================================

def unisci_celle(cartella: Cartella, foglio: Foglio, area: Area) -> None:
    r1, c1, r2, c2 = area
    if r1 == r2 and c1 == c2:
        return
    with cartella.operazione("Unisci celle"):
        cartella._registra_struttura()
        foglio.unite = [u for u in foglio.unite if u[2] < r1 or u[0] > r2 or u[3] < c1 or u[1] > c2]
        foglio.unite.append((r1, c1, r2, c2))
        for (r, c) in [k for k in list(foglio.celle) if r1 <= k[0] <= r2 and c1 <= k[1] <= c2 and k != (r1, c1)]:
            cartella._imposta_ingresso(foglio, r, c, None)


def separa_celle(cartella: Cartella, foglio: Foglio, area: Area) -> None:
    r1, c1, r2, c2 = area
    with cartella.operazione("Separa celle"):
        cartella._registra_struttura()
        foglio.unite = [u for u in foglio.unite if u[2] < r1 or u[0] > r2 or u[3] < c1 or u[1] > c2]
