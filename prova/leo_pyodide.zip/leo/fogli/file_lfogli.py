"""Il formato di Leo Fogli (.lfogli): JSON leggibile con formule, stili, fogli e storico.

Legge anche la versione 1 (quella del primo Leo Fogli scritto in Leo: solo "celle").
"""

from __future__ import annotations

import json
import os
from typing import Any

from .calcolo import Cartella, Cella, Foglio
from .riferimenti import colonna, leggi_cella, lettere, nome_cella

__all__ = ["salva", "apri", "a_dizionario", "da_dizionario", "FORMATO", "VERSIONE"]

FORMATO = "leo-fogli"
VERSIONE = 2


def a_dizionario(cartella: Cartella, con_storico: bool = True) -> dict:
    fogli = []
    for f in cartella.fogli:
        celle: dict[str, Any] = {}
        for (r, c), cella in sorted(f.celle.items()):
            nome = nome_cella(r, c)
            if cella.stile == 0 and cella.nota is None:
                celle[nome] = cella.ingresso
            else:
                d: dict[str, Any] = {}
                if cella.ingresso is not None:
                    d["i"] = cella.ingresso
                if cella.stile:
                    d["s"] = cella.stile
                if cella.nota:
                    d["n"] = cella.nota
                celle[nome] = d
        fogli.append({
            "nome": f.nome,
            "celle": celle,
            "larghezze": {lettere(c): w for c, w in sorted(f.larghezze.items())},
            "altezze": {str(r + 1): h for r, h in sorted(f.altezze.items())},
            "righe_nascoste": sorted(r + 1 for r in f.righe_nascoste),
            "colonne_nascoste": sorted(lettere(c) for c in f.colonne_nascoste),
            "blocca": list(f.blocca),
            "unite": [list(u) for u in f.unite],
            "condizionali": f.condizionali,
            "convalide": f.convalide,
            "filtro": f.filtro,
            "righe_filtrate": sorted(r + 1 for r in f.righe_filtrate),
            "grafici": f.grafici,
            "colore_scheda": f.colore_scheda,
            "protetto": f.protetto,
            "mostra_griglia": f.mostra_griglia,
        })
    d = {
        "formato": FORMATO,
        "versione": VERSIONE,
        "proprieta": cartella.proprieta,
        "stili": cartella.stili,
        "nomi": cartella.nomi,
        "fogli": fogli,
    }
    if con_storico:
        d["storico"] = cartella.storico
    return d


def da_dizionario(d: dict) -> Cartella:
    if not isinstance(d, dict) or d.get("formato") != FORMATO:
        raise ValueError("Il file non è un foglio di Leo Fogli.")
    cartella = Cartella(nuovo_foglio=False)
    cartella.calcolo_automatico = False
    if d.get("versione", 1) == 1:
        f = cartella.aggiungi_foglio("Foglio1")
        for nome, testo in (d.get("celle") or {}).items():
            p = leggi_cella(str(nome))
            if p and testo not in (None, ""):
                cartella._imposta_ingresso(f, p[0], p[1], str(testo))
        cartella.calcolo_automatico = True
        cartella._ricompila_tutto()
        return cartella
    stili = d.get("stili") or [{}]
    cartella.stili = [dict(s) for s in stili] or [{}]
    cartella._indice_stili = {}
    for i, s in enumerate(cartella.stili):
        cartella._indice_stili.setdefault(tuple(sorted(s.items())), i)
    cartella.proprieta = dict(d.get("proprieta") or {})
    cartella.storico = list(d.get("storico") or [])
    cartella.nomi = {str(k).upper(): str(v) for k, v in (d.get("nomi") or {}).items()}
    for fd in d.get("fogli") or []:
        f = Foglio(cartella, str(fd.get("nome") or f"Foglio{len(cartella.fogli) + 1}"))
        cartella.fogli.append(f)
        cartella.dip_aree[f] = {}
        for nome, v in (fd.get("celle") or {}).items():
            p = leggi_cella(str(nome))
            if not p:
                continue
            cella = Cella()
            if isinstance(v, dict):
                cella.ingresso = v.get("i")
                s = int(v.get("s", 0) or 0)
                cella.stile = s if 0 <= s < len(cartella.stili) else 0
                cella.nota = v.get("n")
            else:
                cella.ingresso = None if v in (None, "") else str(v)
            if cella.ingresso is not None and not cella.ingresso.startswith("="):
                from .valori import leggi_inserimento
                cella.valore = leggi_inserimento(cella.ingresso)[0]
            if not cella.vuota():
                f.celle[p] = cella
        f.larghezze = {colonna(k): int(w) for k, w in (fd.get("larghezze") or {}).items()}
        f.altezze = {int(k) - 1: int(h) for k, h in (fd.get("altezze") or {}).items()}
        f.righe_nascoste = {int(r) - 1 for r in fd.get("righe_nascoste") or []}
        f.colonne_nascoste = {colonna(c) for c in fd.get("colonne_nascoste") or []}
        b = fd.get("blocca") or [0, 0]
        f.blocca = (int(b[0]), int(b[1]))
        f.unite = [tuple(int(x) for x in u) for u in fd.get("unite") or []]
        f.condizionali = list(fd.get("condizionali") or [])
        f.convalide = list(fd.get("convalide") or [])
        f.filtro = fd.get("filtro")
        f.righe_filtrate = {int(r) - 1 for r in fd.get("righe_filtrate") or []}
        f.grafici = list(fd.get("grafici") or [])
        f.colore_scheda = str(fd.get("colore_scheda") or "")
        f.protetto = bool(fd.get("protetto", False))
        f.mostra_griglia = bool(fd.get("mostra_griglia", True))
    if not cartella.fogli:
        cartella.aggiungi_foglio("Foglio1")
    cartella.calcolo_automatico = True
    cartella._ricompila_tutto()
    return cartella


def salva(cartella: Cartella, percorso: str | os.PathLike) -> None:
    dati = a_dizionario(cartella)
    temporaneo = str(percorso) + ".tmp"
    with open(temporaneo, "w", encoding="utf-8") as f:
        json.dump(dati, f, ensure_ascii=False, indent=1)
    os.replace(temporaneo, percorso)


def apri(percorso: str | os.PathLike) -> Cartella:
    with open(percorso, "r", encoding="utf-8-sig") as f:
        dati = json.load(f)
    return da_dizionario(dati)
