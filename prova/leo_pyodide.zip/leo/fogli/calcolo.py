"""Il cuore di Leo Fogli: cartella, fogli, celle, dipendenze e ricalcolo.

Quando una cella cambia si ricalcolano solo le formule che ne dipendono (anche
indirettamente), nell'ordine giusto (ordinamento topologico); i riferimenti
circolari diventano #CICLO!. I risultati a più celle (matrici dinamiche, come
=SEQUENZA(5) o =FILTRO(...)) si "espandono" nelle celle vicine, come in Excel 365.
"""

from __future__ import annotations

import bisect
import math
from contextlib import contextmanager
from typing import Any, Callable, Iterator

from . import analisi as A
from .riferimenti import MAX_COLONNE, MAX_RIGHE, leggi_cella, nome_cella
from .valori import (CICLO, ESPANSIONE, NOME, RIF, SINTASSI, VALORE, Errore, ErroreFormula, Matrice,
                     a_logico, a_numero, a_testo, confronta, errore_da_eccezione, leggi_inserimento)

__all__ = ["Cartella", "Foglio", "Cella", "Rif", "Contesto", "Formula", "RiferimentoFunzione"]

_SOGLIA_RICALCOLO_TOTALE = 3000


# ===========================================================================
# Celle e riferimenti
# ===========================================================================

class Formula:
    __slots__ = ("albero", "fn", "riferimenti", "nomi", "volatile", "dinamica")

    def __init__(self, albero: tuple, fn: Callable, riferimenti: list, nomi: set, volatile: bool,
                 dinamica: bool) -> None:
        self.albero = albero
        self.fn = fn
        self.riferimenti = riferimenti
        self.nomi = nomi
        self.volatile = volatile
        self.dinamica = dinamica


class Cella:
    __slots__ = ("ingresso", "valore", "formula", "stile", "nota")

    def __init__(self) -> None:
        self.ingresso: str | None = None
        self.valore: Any = None
        self.formula: Formula | None = None
        self.stile: int = 0
        self.nota: str | None = None

    def vuota(self) -> bool:
        return self.ingresso is None and self.stile == 0 and self.nota is None


class Rif:
    """Riferimento a un rettangolo di celle (anche una sola) di un foglio."""

    __slots__ = ("foglio", "r1", "c1", "r2", "c2")

    def __init__(self, foglio: "Foglio", r1: int, c1: int, r2: int, c2: int) -> None:
        self.foglio, self.r1, self.c1, self.r2, self.c2 = foglio, r1, c1, r2, c2

    @property
    def altezza(self) -> int:
        return self.r2 - self.r1 + 1

    @property
    def larghezza(self) -> int:
        return self.c2 - self.c1 + 1

    def e_cella(self) -> bool:
        return self.r1 == self.r2 and self.c1 == self.c2

    def valore(self, i: int = 0, j: int = 0) -> Any:
        return self.foglio.valore(self.r1 + i, self.c1 + j)

    def limitata(self) -> "Rif":
        """Lo stesso rettangolo tagliato all'area usata del foglio (per A:A, 1:1...)."""
        mr, mc = self.foglio.estensione()
        r2 = min(self.r2, max(mr, self.r1))
        c2 = min(self.c2, max(mc, self.c1))
        return Rif(self.foglio, self.r1, self.c1, r2, c2)

    def righe(self) -> list[list[Any]]:
        x = self.limitata()
        v = self.foglio.valore
        return [[v(r, c) for c in range(x.c1, x.c2 + 1)] for r in range(x.r1, x.r2 + 1)]

    def valori(self) -> Iterator[Any]:
        x = self.limitata()
        v = self.foglio.valore
        for r in range(x.r1, x.r2 + 1):
            for c in range(x.c1, x.c2 + 1):
                yield v(r, c)

    def non_vuoti(self) -> Iterator[Any]:
        """Solo i valori delle celle non vuote (veloce anche su A:A)."""
        f = self.foglio
        area = (self.r2 - self.r1 + 1) * (self.c2 - self.c1 + 1)
        if area <= 4096:
            for v in self.valori():
                if v is not None:
                    yield v
            return
        chiavi = [k for k in list(f.celle) + list(f.spill)
                  if self.r1 <= k[0] <= self.r2 and self.c1 <= k[1] <= self.c2]
        for k in sorted(set(chiavi)):
            v = f.valore(k[0], k[1])
            if v is not None:
                yield v

    def contiene(self, r: int, c: int) -> bool:
        return self.r1 <= r <= self.r2 and self.c1 <= c <= self.c2

    def testo(self) -> str:
        if self.e_cella():
            return nome_cella(self.r1, self.c1)
        return f"{nome_cella(self.r1, self.c1)}:{nome_cella(self.r2, self.c2)}"

    def __repr__(self) -> str:
        return f"Rif({self.foglio.nome}!{self.testo()})"


class RiferimentoFunzione:
    """Il nome di una funzione usato come valore (RAGGRUPPA.PER(A:A; B:B; SOMMA))."""

    __slots__ = ("nome",)

    def __init__(self, nome: str) -> None:
        self.nome = nome


class Contesto:
    """Dove si sta calcolando: cartella, foglio e cella della formula (e i nomi di LET)."""

    __slots__ = ("cartella", "foglio", "r", "c", "locali")

    def __init__(self, cartella: "Cartella", foglio: "Foglio", r: int, c: int, locali: dict | None = None) -> None:
        self.cartella, self.foglio, self.r, self.c = cartella, foglio, r, c
        self.locali = locali

    def foglio_da_nome(self, nome: str | None) -> "Foglio":
        if nome is None:
            return self.foglio
        f = self.cartella.foglio(nome)
        if f is None:
            raise ErroreFormula(RIF)
        return f


# ===========================================================================
# Valori dentro le formule
# ===========================================================================

def scalare(v: Any) -> Any:
    """Riferimento a una cella -> il suo valore; a più celle -> Matrice."""
    if isinstance(v, Rif):
        if v.e_cella():
            return v.valore()
        return Matrice(v.righe())
    return v


def finale(v: Any) -> Any:
    """Risultato di una formula da mettere nella cella."""
    if isinstance(v, Rif):
        if v.e_cella():
            v = v.valore()
        else:
            v = Matrice(v.righe())
    if isinstance(v, Matrice):
        righe = [[(0 if x is None else x) for x in r] for r in v.righe]
        if len(righe) == 1 and len(righe[0]) == 1:
            return righe[0][0]
        return Matrice(righe)
    if v is None:
        return 0
    if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
        return Errore("#NUM!")
    return v


def _elemento(m: Matrice, i: int, j: int) -> Any:
    h, w = m.altezza, m.larghezza
    if h == 1 and w == 1:
        return m.righe[0][0]
    if h == 1:
        return m.righe[0][j] if j < w else Errore("#N/D")
    if w == 1:
        return m.righe[i][0] if i < h else Errore("#N/D")
    if i < h and j < w:
        return m.righe[i][j]
    return Errore("#N/D")


def applica2(a: Any, b: Any, f: Callable[[Any, Any], Any]) -> Any:
    """Operazione tra due valori, elemento per elemento se c'è una matrice."""
    a = scalare(a)
    b = scalare(b)
    if not isinstance(a, Matrice) and not isinstance(b, Matrice):
        return f(a, b)
    ma = a if isinstance(a, Matrice) else Matrice([[a]])
    mb = b if isinstance(b, Matrice) else Matrice([[b]])
    h = max(ma.altezza, mb.altezza)
    w = max(ma.larghezza, mb.larghezza)
    out = []
    for i in range(h):
        riga = []
        for j in range(w):
            try:
                riga.append(f(_elemento(ma, i, j), _elemento(mb, i, j)))
            except Exception as e:  # noqa: BLE001
                riga.append(errore_da_eccezione(e))
        out.append(riga)
    return Matrice(out)


def applica1(a: Any, f: Callable[[Any], Any]) -> Any:
    a = scalare(a)
    if not isinstance(a, Matrice):
        return f(a)
    out = []
    for r in a.righe:
        riga = []
        for x in r:
            try:
                riga.append(f(x))
            except Exception as e:  # noqa: BLE001
                riga.append(errore_da_eccezione(e))
        out.append(riga)
    return Matrice(out)


def _num(x: Any) -> Any:
    return a_numero(x)


def _somma(a: Any, b: Any) -> Any:
    return _num(a) + _num(b)


def _sottrai(a: Any, b: Any) -> Any:
    return _num(a) - _num(b)


def _moltiplica(a: Any, b: Any) -> Any:
    return _num(a) * _num(b)


def _dividi(a: Any, b: Any) -> Any:
    d = _num(b)
    if d == 0:
        raise ErroreFormula("#DIV/0!")
    return _num(a) / d


def _potenza(a: Any, b: Any) -> Any:
    x, y = _num(a), _num(b)
    if x == 0 and y < 0:
        raise ErroreFormula("#DIV/0!")
    if x < 0 and not float(y).is_integer():
        raise ErroreFormula("#NUM!")
    r = float(x) ** y
    if isinstance(r, complex) or math.isinf(r):
        raise ErroreFormula("#NUM!")
    return r


def _unisci(a: Any, b: Any) -> Any:
    return a_testo(a) + a_testo(b)


def _confronto(op: str) -> Callable[[Any, Any], bool]:
    if op == "=":
        return lambda a, b: confronta(a, b) == 0
    if op == "<>":
        return lambda a, b: confronta(a, b) != 0
    if op == "<":
        return lambda a, b: confronta(a, b) < 0
    if op == ">":
        return lambda a, b: confronta(a, b) > 0
    if op == "<=":
        return lambda a, b: confronta(a, b) <= 0
    return lambda a, b: confronta(a, b) >= 0


_OPERAZIONI: dict[str, Callable[[Any, Any], Any]] = {
    "+": _somma, "-": _sottrai, "*": _moltiplica, "/": _dividi, "^": _potenza, "&": _unisci,
    "=": _confronto("="), "<>": _confronto("<>"), "<": _confronto("<"), ">": _confronto(">"),
    "<=": _confronto("<="), ">=": _confronto(">="),
}


# ===========================================================================
# Compilazione: albero -> funzione Python
# ===========================================================================

def compila(albero: tuple, base: tuple[int, int] | None = None) -> tuple[Callable[[Contesto], Any], bool, bool]:
    """Restituisce (funzione, volatile, dinamica).

    Con ``base`` = (riga, colonna) della cella, i riferimenti relativi si calcolano rispetto alla
    cella in cui gira la formula: la stessa funzione serve a tutte le copie della formula
    (=A1*2 in B1, =A2*2 in B2...). Senza ``base`` i riferimenti sono tutti fissi (nomi definiti).
    """
    from .funzioni import FUNZIONI

    stato = {"volatile": False, "dinamica": False}
    r0, c0 = base if base is not None else (0, 0)
    relativo = base is not None

    def posizione(r: int, ar: bool, base_: int, chi: str) -> Callable[[Contesto], int]:
        if ar or not relativo:
            return lambda ctx: r
        d = r - base_
        if chi == "r":
            return lambda ctx: ctx.r + d
        return lambda ctx: ctx.c + d

    def c(x: tuple) -> Callable[[Contesto], Any]:
        k = x[0]
        if k in ("n", "s", "b"):
            v = x[1]
            if isinstance(v, float) and v.is_integer() and abs(v) < 1e15:
                v = v  # resta decimale
            return lambda ctx: v
        if k == "e":
            codice = x[1]

            def errore(ctx: Contesto) -> Any:
                raise ErroreFormula(codice)
            return errore
        if k == "v":
            return lambda ctx: None
        if k == "c":
            _, nome_f, r, cc, ar, ac = x
            if (ar and ac) or not relativo:
                if nome_f is None:
                    return lambda ctx: Rif(ctx.foglio, r, cc, r, cc)
                return lambda ctx: Rif(ctx.foglio_da_nome(nome_f), r, cc, r, cc)
            pr = posizione(r, ar, r0, "r")
            pc = posizione(cc, ac, c0, "c")

            def cella(ctx: Contesto) -> Rif:
                rr, kk = pr(ctx), pc(ctx)
                if not (0 <= rr < MAX_RIGHE and 0 <= kk < MAX_COLONNE):
                    raise ErroreFormula(RIF)
                f = ctx.foglio if nome_f is None else ctx.foglio_da_nome(nome_f)
                return Rif(f, rr, kk, rr, kk)
            return cella
        if k == "a":
            _, nome_f, r1, c1, r2, c2, ar1, ac1, ar2, ac2, genere = x
            if genere == "colonne":
                ar1 = ar2 = True
            if genere == "righe":
                ac1 = ac2 = True
            if (ar1 and ac1 and ar2 and ac2) or not relativo:
                a1, a2 = min(r1, r2), max(r1, r2)
                b1, b2 = min(c1, c2), max(c1, c2)
                if nome_f is None:
                    return lambda ctx: Rif(ctx.foglio, a1, b1, a2, b2)
                return lambda ctx: Rif(ctx.foglio_da_nome(nome_f), a1, b1, a2, b2)
            p1, q1 = posizione(r1, ar1, r0, "r"), posizione(c1, ac1, c0, "c")
            p2, q2 = posizione(r2, ar2, r0, "r"), posizione(c2, ac2, c0, "c")

            def area(ctx: Contesto) -> Rif:
                a1, b1, a2, b2 = p1(ctx), q1(ctx), p2(ctx), q2(ctx)
                if a1 > a2:
                    a1, a2 = a2, a1
                if b1 > b2:
                    b1, b2 = b2, b1
                if a1 < 0 or b1 < 0 or a2 >= MAX_RIGHE or b2 >= MAX_COLONNE:
                    raise ErroreFormula(RIF)
                f = ctx.foglio if nome_f is None else ctx.foglio_da_nome(nome_f)
                return Rif(f, a1, b1, a2, b2)
            return area
        if k == "par":
            return c(x[1])
        if k == "op":
            op = _OPERAZIONI[x[1]]
            fa, fb = c(x[2]), c(x[3])
            return lambda ctx: applica2(fa(ctx), fb(ctx), op)
        if k == "neg":
            f1 = c(x[1])
            return lambda ctx: applica1(f1(ctx), lambda v: -_num(v))
        if k == "pos":
            f1 = c(x[1])
            return lambda ctx: scalare(f1(ctx))
        if k == "pct":
            f1 = c(x[1])
            return lambda ctx: applica1(f1(ctx), lambda v: _num(v) / 100)
        if k == "rng":
            fa, fb = c(x[1]), c(x[2])

            def unione(ctx: Contesto) -> Rif:
                a, b = fa(ctx), fb(ctx)
                if not isinstance(a, Rif) or not isinstance(b, Rif) or a.foglio is not b.foglio:
                    raise ErroreFormula(VALORE)
                return Rif(a.foglio, min(a.r1, b.r1), min(a.c1, b.c1), max(a.r2, b.r2), max(a.c2, b.c2))
            return unione
        if k == "arr":
            m = Matrice([list(r) for r in x[1]])
            return lambda ctx: m
        if k == "nome":
            nome = x[1]

            def nome_definito(ctx: Contesto) -> Any:
                if ctx.locali is not None and nome in ctx.locali:
                    return ctx.locali[nome]
                if nome in ctx.cartella.nomi:
                    return ctx.cartella.valuta_nome(nome, ctx)
                from .funzioni import FUNZIONI, nome_canonico
                if nome_canonico(nome) in FUNZIONI:
                    return RiferimentoFunzione(nome_canonico(nome))
                raise ErroreFormula(NOME, f"Il nome {nome} non esiste")
            return nome_definito
        if k == "f" and x[1] == "LET":
            argomenti = x[2]
            if len(argomenti) < 3 or len(argomenti) % 2 == 0 or any(argomenti[i][0] != "nome"
                                                                     for i in range(0, len(argomenti) - 1, 2)):
                def let_sbagliata(ctx: Contesto) -> Any:
                    raise ErroreFormula(VALORE, "LET vuole coppie nome; valore e alla fine il calcolo")
                return let_sbagliata
            coppie = [(argomenti[i][1], c(argomenti[i + 1])) for i in range(0, len(argomenti) - 1, 2)]
            corpo = c(argomenti[-1])

            def let(ctx: Contesto) -> Any:
                locali = dict(ctx.locali or {})
                nuovo = Contesto(ctx.cartella, ctx.foglio, ctx.r, ctx.c, locali)
                for n, f in coppie:
                    locali[n] = f(nuovo)
                return corpo(nuovo)
            return let
        if k == "f":
            nome, argomenti = x[1], x[2]
            info = FUNZIONI.get(nome)
            if info is None:
                def sconosciuta(ctx: Contesto) -> Any:
                    raise ErroreFormula(NOME, f"La funzione {nome} non esiste")
                return sconosciuta
            if not (info.minimo <= len(argomenti) <= info.massimo):
                def sbagliata(ctx: Contesto) -> Any:
                    raise ErroreFormula(VALORE, f"{nome} vuole da {info.minimo} a {info.massimo} argomenti")
                return sbagliata
            if info.volatile:
                stato["volatile"] = True
            if info.dinamica:
                stato["dinamica"] = True
            fns = [c(a) for a in argomenti]
            fn = info.fn
            if info.pigra:
                return lambda ctx: fn(ctx, *[(lambda f=f: f(ctx)) for f in fns])
            if info.elementare:
                return _elementare(fn, fns, info.elementare)
            return lambda ctx: fn(ctx, *[f(ctx) for f in fns])
        raise ErroreFormula(SINTASSI)

    fn = c(albero)
    return fn, stato["volatile"], stato["dinamica"]


def _elementare(fn: Callable, fns: list, quanti: int) -> Callable[[Contesto], Any]:
    """Funzione "di un valore" applicata a ogni elemento se riceve un intervallo (es. =MAIUSC(A1:A5))."""
    def chiama(ctx: Contesto) -> Any:
        args = [scalare(f(ctx)) for f in fns]
        matrici = [i for i, a in enumerate(args[:quanti]) if isinstance(a, Matrice)]
        if not matrici:
            return fn(ctx, *args)
        h = max(args[i].altezza for i in matrici)
        w = max(args[i].larghezza for i in matrici)
        out = []
        for r in range(h):
            riga = []
            for cc in range(w):
                elem = [(_elemento(a, r, cc) if (i < quanti and isinstance(a, Matrice)) else a)
                        for i, a in enumerate(args)]
                try:
                    riga.append(fn(ctx, *elem))
                except Exception as e:  # noqa: BLE001
                    riga.append(errore_da_eccezione(e))
            out.append(riga)
        return Matrice(out)
    return chiama


# ===========================================================================
# Foglio
# ===========================================================================

class Foglio:
    def __init__(self, cartella: "Cartella", nome: str) -> None:
        self.cartella = cartella
        self.nome = nome
        self.celle: dict[tuple[int, int], Cella] = {}
        self.formule_col: dict[int, list[int]] = {}          # colonna -> righe con formula (ordinate)
        self.spill: dict[tuple[int, int], tuple[int, int]] = {}   # cella espansa -> origine
        self.aree_spill: dict[tuple[int, int], tuple[int, int]] = {}  # origine -> (altezza, larghezza)
        self.spill_bloccati: dict[tuple[int, int], tuple[int, int, int, int]] = {}
        self.larghezze: dict[int, int] = {}
        self.altezze: dict[int, int] = {}
        self.righe_nascoste: set[int] = set()
        self.colonne_nascoste: set[int] = set()
        self.righe_filtrate: set[int] = set()
        self.blocca: tuple[int, int] = (0, 0)               # righe e colonne bloccate in alto/a sinistra
        self.unite: list[tuple[int, int, int, int]] = []
        self.condizionali: list[dict] = []
        self.convalide: list[dict] = []
        self.filtro: dict | None = None                       # {"area": [r1,c1,r2,c2], "criteri": {col: ...}}
        self.grafici: list[dict] = []
        self.colore_scheda: str = ""
        self.protetto: bool = False
        self.mostra_griglia: bool = True
        self._estensione: tuple[int, int] | None = None

    def __repr__(self) -> str:
        return f"<Foglio {self.nome}>"

    # --- lettura ------------------------------------------------------------
    def valore(self, r: int, c: int) -> Any:
        cella = self.celle.get((r, c))
        if cella is not None and cella.ingresso is not None:
            v = cella.valore
            if isinstance(v, Matrice):
                return v.righe[0][0]
            return v
        origine = self.spill.get((r, c))
        if origine is not None:
            m = self.celle[origine].valore
            if isinstance(m, Matrice):
                return m.righe[r - origine[0]][c - origine[1]]
        return None

    def cella(self, r: int, c: int) -> Cella | None:
        return self.celle.get((r, c))

    def ingresso(self, r: int, c: int) -> str:
        cella = self.celle.get((r, c))
        return "" if cella is None or cella.ingresso is None else cella.ingresso

    def estensione(self) -> tuple[int, int]:
        """(ultima riga, ultima colonna) usate; (-1, -1) se il foglio è vuoto."""
        if self._estensione is None:
            mr = mc = -1
            for (r, c), cella in self.celle.items():
                if cella.ingresso is not None:
                    if r > mr:
                        mr = r
                    if c > mc:
                        mc = c
            for (r, c) in self.spill:
                if r > mr:
                    mr = r
                if c > mc:
                    mc = c
            self._estensione = (mr, mc)
        return self._estensione

    def area_unita(self, r: int, c: int) -> tuple[int, int, int, int] | None:
        for u in self.unite:
            if u[0] <= r <= u[2] and u[1] <= c <= u[3]:
                return u
        return None

    # --- indice delle formule -------------------------------------------------
    def _aggiungi_formula(self, r: int, c: int) -> None:
        righe = self.formule_col.setdefault(c, [])
        i = bisect.bisect_left(righe, r)
        if i >= len(righe) or righe[i] != r:
            righe.insert(i, r)

    def _togli_formula(self, r: int, c: int) -> None:
        righe = self.formule_col.get(c)
        if righe:
            i = bisect.bisect_left(righe, r)
            if i < len(righe) and righe[i] == r:
                righe.pop(i)
                if not righe:
                    del self.formule_col[c]

    def formule_in(self, r1: int, c1: int, r2: int, c2: int) -> Iterator[tuple[int, int]]:
        if c2 - c1 > len(self.formule_col):
            colonne = [c for c in self.formule_col if c1 <= c <= c2]
        else:
            colonne = [c for c in range(c1, c2 + 1) if c in self.formule_col]
        for c in colonne:
            righe = self.formule_col[c]
            i = bisect.bisect_left(righe, r1)
            while i < len(righe) and righe[i] <= r2:
                yield righe[i], c
                i += 1


# ===========================================================================
# Cartella
# ===========================================================================

class Cartella:
    """Una cartella di lavoro: più fogli, stili, nomi definiti, annulla/ripeti."""

    def __init__(self, nuovo_foglio: bool = True) -> None:
        self.fogli: list[Foglio] = []
        self.nomi: dict[str, str] = {}                  # NOME -> "=Foglio1!$A$1:$A$9"
        self._nomi_compilati: dict[str, Callable] = {}
        self.stili: list[dict] = [{}]
        self._indice_stili: dict[tuple, int] = {(): 0}
        self.dipendenti: dict[tuple, set] = {}          # (foglio, r, c) -> formule che la leggono
        self.dip_aree: dict[Foglio, dict[tuple, list]] = {}   # foglio -> {formula: [rettangoli]}
        self.dip_nomi: dict[str, set] = {}
        self.volatili: set[tuple] = set()
        self.osservatori: list[Callable[[set], None]] = []
        self.proprieta: dict[str, Any] = {}             # titolo, autore, ...
        self.storico: list[dict] = []                   # registro delle modifiche (audit)
        self.registra_storico = False
        self.utente = ""
        self._lotto = 0
        self._cambiate: set[tuple] = set()
        self._da_ricalcolare: set[tuple] = set()
        self._annulla: list[dict] = []
        self._ripeti: list[dict] = []
        self._operazione: dict | None = None
        self._in_annulla = False
        self.calcolo_automatico = True
        self._cache_formule: dict[str, tuple] = {}
        if nuovo_foglio:
            self.aggiungi_foglio("Foglio1")

    # --- fogli ----------------------------------------------------------------
    def foglio(self, nome: str | int | Foglio) -> Foglio | None:
        if isinstance(nome, Foglio):
            return nome
        if isinstance(nome, int):
            return self.fogli[nome] if 0 <= nome < len(self.fogli) else None
        n = nome.lower()
        for f in self.fogli:
            if f.nome.lower() == n:
                return f
        return None

    def aggiungi_foglio(self, nome: str | None = None, posizione: int | None = None) -> Foglio:
        if nome is None:
            i = len(self.fogli) + 1
            while self.foglio(f"Foglio{i}") is not None:
                i += 1
            nome = f"Foglio{i}"
        if self.foglio(nome) is not None:
            raise ValueError(f"Esiste già un foglio chiamato «{nome}».")
        _controlla_nome_foglio(nome)
        f = Foglio(self, nome)
        self._registra_struttura()
        if posizione is None:
            self.fogli.append(f)
        else:
            self.fogli.insert(posizione, f)
        self.dip_aree[f] = {}
        self._ricompila_tutto()
        return f

    def rinomina_foglio(self, foglio: Foglio | str, nuovo: str) -> None:
        f = self._foglio_o_errore(foglio)
        if nuovo.lower() != f.nome.lower() and self.foglio(nuovo) is not None:
            raise ValueError(f"Esiste già un foglio chiamato «{nuovo}».")
        _controlla_nome_foglio(nuovo)
        self._registra_struttura()
        vecchio = f.nome

        def cambia(x: tuple) -> tuple:
            if x[1] is not None and x[1].lower() == vecchio.lower():
                return (x[0], nuovo) + x[2:]
            return x
        for g in self.fogli:
            for (r, c), cella in list(g.celle.items()):
                if cella.formula is not None:
                    nuovo_albero = A.trasforma_riferimenti(cella.formula.albero, cambia)
                    cella.ingresso = "=" + A.scrivi(nuovo_albero)
        for n, t in list(self.nomi.items()):
            try:
                self.nomi[n] = "=" + A.scrivi(A.trasforma_riferimenti(A.analizza(t), cambia))
            except ErroreFormula:
                pass
        f.nome = nuovo
        self._ricompila_tutto()

    def elimina_foglio(self, foglio: Foglio | str) -> None:
        f = self._foglio_o_errore(foglio)
        if len(self.fogli) == 1:
            raise ValueError("Una cartella deve avere almeno un foglio.")
        self._registra_struttura()
        self.fogli.remove(f)
        self.dip_aree.pop(f, None)
        self._ricompila_tutto()

    def sposta_foglio(self, foglio: Foglio | str, posizione: int) -> None:
        f = self._foglio_o_errore(foglio)
        self._registra_struttura()
        self.fogli.remove(f)
        self.fogli.insert(max(0, min(posizione, len(self.fogli))), f)

    def _foglio_o_errore(self, foglio: Foglio | str | int) -> Foglio:
        f = self.foglio(foglio)
        if f is None:
            raise ValueError(f"Il foglio «{foglio}» non esiste.")
        return f

    # --- stili ------------------------------------------------------------------
    def id_stile(self, stile: dict) -> int:
        chiave = tuple(sorted((k, v) for k, v in stile.items() if v not in (None, "", False)))
        i = self._indice_stili.get(chiave)
        if i is None:
            i = len(self.stili)
            self.stili.append(dict(chiave))
            self._indice_stili[chiave] = i
        return i

    def stile(self, foglio: Foglio, r: int, c: int) -> dict:
        cella = foglio.celle.get((r, c))
        return self.stili[cella.stile] if cella is not None else self.stili[0]

    # --- nomi definiti ----------------------------------------------------------
    def definisci_nome(self, nome: str, riferimento: str) -> None:
        n = nome.strip().upper()
        if not n or not (n[0].isalpha() or n[0] == "_") or leggi_cella(n) is not None:
            raise ValueError(f"«{nome}» non va bene come nome: usa lettere, cifre e _ (non un nome di cella).")
        if not riferimento.startswith("="):
            riferimento = "=" + riferimento
        A.analizza(riferimento)
        self._registra_struttura()
        self.nomi[n] = riferimento
        self._nomi_compilati.pop(n, None)
        self._ricompila_tutto()

    def elimina_nome(self, nome: str) -> None:
        self._registra_struttura()
        self.nomi.pop(nome.upper(), None)
        self._nomi_compilati.pop(nome.upper(), None)
        self._ricompila_tutto()

    def valuta_nome(self, nome: str, ctx: Contesto) -> Any:
        fn = self._nomi_compilati.get(nome)
        if fn is None:
            testo = self.nomi.get(nome)
            if testo is None:
                raise ErroreFormula(NOME, f"Il nome {nome} non esiste")
            fn = compila(A.analizza(testo), None)[0]
            self._nomi_compilati[nome] = fn
        return fn(ctx)

    # --- lettura ---------------------------------------------------------------
    def valore(self, foglio: Foglio | str | int, r: int, c: int) -> Any:
        return self._foglio_o_errore(foglio).valore(r, c)

    # --- scrittura -------------------------------------------------------------
    def imposta(self, foglio: Foglio | str | int, r: int, c: int, testo: Any) -> None:
        """Scrive in una cella quello che scriverebbe l'utente ("12", "=A1*2", "ciao", "")."""
        f = self._foglio_o_errore(foglio)
        if not (0 <= r < MAX_RIGHE and 0 <= c < MAX_COLONNE):
            raise ValueError("Cella fuori dal foglio.")
        if testo is not None and not isinstance(testo, str):
            testo = _testo_di_valore(testo)
        if testo == "":
            testo = None
        with self.lotto():
            self._imposta_ingresso(f, r, c, testo)

    def imposta_valore(self, foglio: Foglio | str | int, r: int, c: int, valore: Any) -> None:
        """Scrive un valore così com'è (numero, testo, logico): un testo non diventa mai formula."""
        f = self._foglio_o_errore(foglio)
        if valore is None or valore == "":
            self.imposta(f, r, c, None)
            return
        if isinstance(valore, str):
            v, _ = leggi_inserimento(valore)
            if valore.startswith("=") or v != valore:
                valore = "'" + valore          # resta il testo esatto, non diventa formula o numero
            self.imposta(f, r, c, valore)
            return
        self.imposta(f, r, c, _testo_di_valore(valore))

    def _registra_cella(self, f: Foglio, r: int, c: int) -> None:
        op = self._operazione
        if op is None or self._in_annulla:
            return
        chiave = (f, r, c)
        if chiave in op["celle"]:
            return
        cella = f.celle.get((r, c))
        op["celle"][chiave] = None if cella is None else (cella.ingresso, cella.stile, cella.nota)

    def _imposta_ingresso(self, f: Foglio, r: int, c: int, testo: str | None,
                          formato_auto: bool = True) -> None:
        self._registra_cella(f, r, c)
        cella = f.celle.get((r, c))
        vecchio = None if cella is None else cella.ingresso
        if cella is None:
            if testo is None:
                return
            cella = Cella()
            f.celle[(r, c)] = cella
        chiave = (f, r, c)
        if cella.formula is not None:
            self._togli_dipendenze(chiave, cella.formula)
            f._togli_formula(r, c)
            cella.formula = None
            self._togli_spill(f, r, c)
        cella.ingresso = testo
        if testo is None:
            cella.valore = None
        elif testo.startswith("=") and len(testo) > 1:
            try:
                cella.formula, cella.ingresso = self._crea_formula(testo, r, c)
                cella.valore = None
                self._aggiungi_dipendenze(chiave, cella.formula, f)
                f._aggiungi_formula(r, c)
            except ErroreFormula:
                cella.valore = Errore(SINTASSI)
        else:
            v, formato = leggi_inserimento(testo)
            cella.valore = v
            if formato and formato_auto and not self.stili[cella.stile].get("formato"):
                st = dict(self.stili[cella.stile])
                st["formato"] = formato
                cella.stile = self.id_stile(st)
        if cella.vuota():
            del f.celle[(r, c)]
        f._estensione = None
        if self.registra_storico and vecchio != testo and not self._in_annulla:
            import datetime as _dt
            self.storico.append({"quando": _dt.datetime.now().isoformat(timespec="seconds"),
                                 "chi": self.utente, "foglio": f.nome, "cella": nome_cella(r, c),
                                 "prima": vecchio or "", "dopo": testo or ""})
        self._cambiate.add(chiave)
        # chi si espandeva qui (o era bloccato da questa cella) va ricalcolato
        origine = f.spill.get((r, c))
        if origine is not None:
            self._da_ricalcolare.add((f, origine[0], origine[1]))
        for o, (r1, c1, r2, c2) in list(f.spill_bloccati.items()):
            if r1 <= r <= r2 and c1 <= c <= c2:
                self._da_ricalcolare.add((f, o[0], o[1]))

    def imposta_stile(self, foglio: Foglio | str | int, r: int, c: int, **cambi: Any) -> None:
        f = self._foglio_o_errore(foglio)
        self._registra_cella(f, r, c)
        cella = f.celle.get((r, c))
        if cella is None:
            cella = Cella()
            f.celle[(r, c)] = cella
        st = dict(self.stili[cella.stile])
        for k, v in cambi.items():
            if v is None or v == "" or v is False:
                st.pop(k, None)
            else:
                st[k] = v
        cella.stile = self.id_stile(st)
        if cella.vuota():
            del f.celle[(r, c)]
        self._cambiate.add((f, r, c))
        if self._lotto == 0:
            self._avvisa({(f, r, c)})

    def sostituisci_stile(self, foglio: Foglio, r: int, c: int, id_stile: int) -> None:
        self._registra_cella(foglio, r, c)
        cella = foglio.celle.get((r, c))
        if cella is None:
            if id_stile == 0:
                return
            cella = Cella()
            foglio.celle[(r, c)] = cella
        cella.stile = id_stile
        if cella.vuota():
            del foglio.celle[(r, c)]
        self._cambiate.add((foglio, r, c))

    def imposta_nota(self, foglio: Foglio | str | int, r: int, c: int, nota: str | None) -> None:
        f = self._foglio_o_errore(foglio)
        self._registra_cella(f, r, c)
        cella = f.celle.get((r, c))
        if cella is None:
            if not nota:
                return
            cella = Cella()
            f.celle[(r, c)] = cella
        cella.nota = nota or None
        if cella.vuota():
            del f.celle[(r, c)]
        self._cambiate.add((f, r, c))
        if self._lotto == 0:
            self._avvisa({(f, r, c)})

    def _crea_formula(self, testo: str, r: int, c: int) -> tuple[Formula, str]:
        """Analizza e compila una formula, riusando il lavoro fatto per le sue copie (=A1*2, =A2*2...)."""
        chiave = A.chiave_relativa(testo, r, c)
        voce = self._cache_formule.get(chiave) if chiave is not None else None
        if voce is None:
            albero = A.analizza(testo)
            fn, vol, din = compila(albero, (r, c))
            if chiave is not None:
                if len(self._cache_formule) > 50000:
                    self._cache_formule.clear()
                self._cache_formule[chiave] = (albero, r, c, fn, vol, din)
        else:
            base, r0, c0, fn, vol, din = voce
            albero = base if (r0, c0) == (r, c) else A.sposta(base, r - r0, c - c0)
        formula = Formula(albero, fn, A.riferimenti_di(albero), A.nomi_di(albero), vol, din)
        return formula, "=" + A.scrivi(albero)

    # --- lotti (più modifiche, un solo ricalcolo) ------------------------------
    @contextmanager
    def lotto(self) -> Iterator[None]:
        self._lotto += 1
        try:
            yield
        finally:
            self._lotto -= 1
            if self._lotto == 0:
                cambiate = self._cambiate
                self._cambiate = set()
                if self.calcolo_automatico:
                    toccate = self._ricalcola(cambiate)
                else:
                    toccate = cambiate
                self._avvisa(cambiate | toccate)

    @contextmanager
    def operazione(self, descrizione: str) -> Iterator[None]:
        """Raccoglie le modifiche in un solo passo di "Annulla"."""
        if self._operazione is not None or self._in_annulla:
            with self.lotto():
                yield
            return
        self._operazione = {"descrizione": descrizione, "celle": {}, "struttura": None}
        try:
            with self.lotto():
                yield
        finally:
            op = self._operazione
            self._operazione = None
            if op["celle"] or op["struttura"] is not None:
                self._annulla.append(op)
                if len(self._annulla) > 200:
                    self._annulla.pop(0)
                self._ripeti.clear()

    def _avvisa(self, chiavi: set) -> None:
        for o in list(self.osservatori):
            try:
                o(chiavi)
            except Exception:  # noqa: BLE001 - un osservatore rotto non ferma il foglio
                pass

    # --- dipendenze --------------------------------------------------------------
    def _fogli_riferimento(self, f: Foglio, nome: str | None) -> Foglio | None:
        return f if nome is None else self.foglio(nome)

    def _aggiungi_dipendenze(self, chiave: tuple, formula: Formula, f: Foglio) -> None:
        for x in formula.riferimenti:
            g = self._fogli_riferimento(f, x[1])
            if g is None:
                continue
            if x[0] == "c":
                self.dipendenti.setdefault((g, x[2], x[3]), set()).add(chiave)
            else:
                r1, c1, r2, c2 = min(x[2], x[4]), min(x[3], x[5]), max(x[2], x[4]), max(x[3], x[5])
                self.dip_aree.setdefault(g, {}).setdefault(chiave, []).append((r1, c1, r2, c2))
        for n in formula.nomi:
            self.dip_nomi.setdefault(n, set()).add(chiave)
            # le aree dei nomi definiti
            t = self.nomi.get(n)
            if t:
                try:
                    for x in A.riferimenti_di(A.analizza(t)):
                        g = self._fogli_riferimento(f, x[1])
                        if g is None:
                            continue
                        if x[0] == "c":
                            self.dipendenti.setdefault((g, x[2], x[3]), set()).add(chiave)
                        else:
                            self.dip_aree.setdefault(g, {}).setdefault(chiave, []).append(
                                (min(x[2], x[4]), min(x[3], x[5]), max(x[2], x[4]), max(x[3], x[5])))
                except ErroreFormula:
                    pass
        if formula.volatile or formula.dinamica:
            self.volatili.add(chiave)

    def _togli_dipendenze(self, chiave: tuple, formula: Formula) -> None:
        f = chiave[0]
        for x in formula.riferimenti:
            g = self._fogli_riferimento(f, x[1])
            if g is None:
                continue
            if x[0] == "c":
                s = self.dipendenti.get((g, x[2], x[3]))
                if s:
                    s.discard(chiave)
                    if not s:
                        del self.dipendenti[(g, x[2], x[3])]
            else:
                self.dip_aree.get(g, {}).pop(chiave, None)
        for n in formula.nomi:
            s = self.dip_nomi.get(n)
            if s:
                s.discard(chiave)
            t = self.nomi.get(n)
            if t:
                try:
                    for x in A.riferimenti_di(A.analizza(t)):
                        g = self._fogli_riferimento(f, x[1])
                        if g is None:
                            continue
                        if x[0] == "c":
                            s2 = self.dipendenti.get((g, x[2], x[3]))
                            if s2:
                                s2.discard(chiave)
                        else:
                            self.dip_aree.get(g, {}).pop(chiave, None)
                except ErroreFormula:
                    pass
        self.volatili.discard(chiave)

    def _ricompila_tutto(self) -> None:
        """Dopo cambi di struttura (fogli, nomi): ricostruisce formule e dipendenze."""
        self.dipendenti.clear()
        self.dip_aree = {f: {} for f in self.fogli}
        self.dip_nomi.clear()
        self.volatili.clear()
        self._nomi_compilati.clear()
        for f in self.fogli:
            f.formule_col.clear()
            for (r, c), cella in f.celle.items():
                if cella.ingresso is not None and cella.ingresso.startswith("=") and len(cella.ingresso) > 1:
                    try:
                        cella.formula, cella.ingresso = self._crea_formula(cella.ingresso, r, c)
                        self._aggiungi_dipendenze((f, r, c), cella.formula, f)
                        f._aggiungi_formula(r, c)
                    except ErroreFormula:
                        cella.formula = None
                        cella.valore = Errore(SINTASSI)
        self.ricalcola_tutto()

    def _dipendenti_di(self, chiave: tuple) -> set:
        f, r, c = chiave
        out = set(self.dipendenti.get(chiave, ()))
        for dip, rettangoli in self.dip_aree.get(f, {}).items():
            for (r1, c1, r2, c2) in rettangoli:
                if r1 <= r <= r2 and c1 <= c <= c2:
                    out.add(dip)
                    break
        return out

    def tutte_le_formule(self) -> list[tuple]:
        out = []
        for f in self.fogli:
            for c, righe in f.formule_col.items():
                for r in righe:
                    out.append((f, r, c))
        return out

    # --- ricalcolo -----------------------------------------------------------------
    def ricalcola_tutto(self) -> None:
        tutte = set(self.tutte_le_formule())
        for (f, r, c) in tutte:
            self._togli_spill(f, r, c)
        toccate = self._calcola(tutte)
        self._avvisa(toccate | tutte)

    def _ricalcola(self, cambiate: set) -> set:
        sporche: set[tuple] = set()
        da_visitare = list(cambiate | self._da_ricalcolare)
        self._da_ricalcolare = set()
        if len(da_visitare) > _SOGLIA_RICALCOLO_TOTALE:
            sporche = set(self.tutte_le_formule())
        else:
            visti: set[tuple] = set()
            while da_visitare:
                k = da_visitare.pop()
                if k in visti:
                    continue
                visti.add(k)
                cella = k[0].celle.get((k[1], k[2]))
                if cella is not None and cella.formula is not None:
                    sporche.add(k)
                for d in self._dipendenti_di(k):
                    if d not in visti:
                        da_visitare.append(d)
                # le celle in cui si espande una formula cambiano con lei
                if cella is not None and isinstance(cella.valore, Matrice):
                    h, w = cella.valore.altezza, cella.valore.larghezza
                    if h * w <= 10000:
                        for i in range(h):
                            for j in range(w):
                                if i or j:
                                    kk = (k[0], k[1] + i, k[2] + j)
                                    if kk not in visti:
                                        da_visitare.append(kk)
                if len(visti) > 50000:
                    sporche = set(self.tutte_le_formule())
                    break
        sporche |= self.volatili
        if not sporche:
            return set()
        return self._calcola(sporche)

    def _ordine(self, sporche: set) -> tuple[list[tuple], set]:
        """Ordine di calcolo (prima le celle da cui dipendono le altre) e celle in un ciclo."""
        precedenti: dict[tuple, list[tuple]] = {}
        for k in sporche:
            f = k[0]
            cella = f.celle.get((k[1], k[2]))
            if cella is None or cella.formula is None:
                continue
            prec = []
            for x in cella.formula.riferimenti:
                g = f if x[1] is None else self.foglio(x[1])
                if g is None:
                    continue
                if x[0] == "c":
                    kk = (g, x[2], x[3])
                    if kk in sporche:
                        prec.append(kk)
                    o = g.spill.get((x[2], x[3]))
                    if o is not None and (g, o[0], o[1]) in sporche:
                        prec.append((g, o[0], o[1]))
                else:
                    r1, c1, r2, c2 = min(x[2], x[4]), min(x[3], x[5]), max(x[2], x[4]), max(x[3], x[5])
                    for (rr, cc) in g.formule_in(r1, c1, r2, c2):
                        kk = (g, rr, cc)
                        if kk in sporche and kk != k:
                            prec.append(kk)
            for n in cella.formula.nomi:
                t = self.nomi.get(n)
                if not t:
                    continue
                try:
                    for x in A.riferimenti_di(A.analizza(t)):
                        g = f if x[1] is None else self.foglio(x[1])
                        if g is None:
                            continue
                        r1, c1, r2, c2 = (x[2], x[3], x[2], x[3]) if x[0] == "c" else (
                            min(x[2], x[4]), min(x[3], x[5]), max(x[2], x[4]), max(x[3], x[5]))
                        for (rr, cc) in g.formule_in(r1, c1, r2, c2):
                            kk = (g, rr, cc)
                            if kk in sporche and kk != k:
                                prec.append(kk)
                except ErroreFormula:
                    pass
            precedenti[k] = prec
        ordine: list[tuple] = []
        stato: dict[tuple, int] = {}       # 1 = in corso, 2 = fatto
        in_ciclo: set[tuple] = set()

        def chiave_ordine(k: tuple) -> tuple:
            return (self.fogli.index(k[0]) if k[0] in self.fogli else 0, k[1], k[2])

        # volatili e dinamiche per ultime
        radici = sorted(precedenti, key=lambda k: (k in self.volatili, chiave_ordine(k)))
        for radice in radici:
            if stato.get(radice):
                continue
            pila = [(radice, iter(precedenti[radice]))]
            stato[radice] = 1
            while pila:
                nodo, it = pila[-1]
                avanti = False
                for p in it:
                    s = stato.get(p)
                    if s is None:
                        stato[p] = 1
                        pila.append((p, iter(precedenti.get(p, ()))))
                        avanti = True
                        break
                    if s == 1:
                        # ciclo: tutti i nodi della pila da p in su
                        dentro = False
                        for (q, _) in pila:
                            if q == p:
                                dentro = True
                            if dentro:
                                in_ciclo.add(q)
                if not avanti:
                    pila.pop()
                    stato[nodo] = 2
                    ordine.append(nodo)
        return ordine, in_ciclo

    def _calcola(self, sporche: set) -> set:
        toccate: set[tuple] = set()
        for giro in range(20):
            ordine, in_ciclo = self._ordine(sporche)
            prossime: set[tuple] = set()
            for k in ordine:
                f, r, c = k
                cella = f.celle.get((r, c))
                if cella is None or cella.formula is None:
                    continue
                vecchio = cella.valore
                if k in in_ciclo:
                    nuovo = Errore(CICLO)
                else:
                    try:
                        nuovo = finale(cella.formula.fn(Contesto(self, f, r, c)))
                    except Exception as e:  # noqa: BLE001
                        nuovo = errore_da_eccezione(e)
                if isinstance(nuovo, Matrice) or isinstance(vecchio, Matrice) or k in f.spill_bloccati:
                    cambiate = self._metti_spill(f, r, c, nuovo, cella)
                    toccate |= cambiate
                    for kk in cambiate:
                        prossime |= self._dipendenti_di(kk)
                else:
                    cella.valore = nuovo
                toccate.add(k)
            prossime = {d for d in prossime if d[0].celle.get((d[1], d[2])) is not None
                        and d[0].celle[(d[1], d[2])].formula is not None}
            if not prossime:
                break
            sporche = prossime
            # anche chi dipende da queste
            extra = list(prossime)
            visti = set(extra)
            while extra:
                kk = extra.pop()
                for d in self._dipendenti_di(kk):
                    if d not in visti:
                        visti.add(d)
                        extra.append(d)
                        sporche.add(d)
        return toccate

    # --- matrici che si espandono -----------------------------------------------
    def _togli_spill(self, f: Foglio, r: int, c: int) -> set:
        toccate = set()
        dim = f.aree_spill.pop((r, c), None)
        if dim is not None:
            h, w = dim
            for i in range(h):
                for j in range(w):
                    if (i or j) and f.spill.get((r + i, c + j)) == (r, c):
                        del f.spill[(r + i, c + j)]
                        toccate.add((f, r + i, c + j))
            f._estensione = None
        f.spill_bloccati.pop((r, c), None)
        return toccate

    def _metti_spill(self, f: Foglio, r: int, c: int, nuovo: Any, cella: Cella) -> set:
        toccate = self._togli_spill(f, r, c)
        if not isinstance(nuovo, Matrice):
            cella.valore = nuovo
            return toccate
        h, w = nuovo.altezza, nuovo.larghezza
        if r + h > MAX_RIGHE or c + w > MAX_COLONNE:
            cella.valore = Errore(ESPANSIONE)
            return toccate
        bloccata = False
        for i in range(h):
            for j in range(w):
                if not (i or j):
                    continue
                altra = f.celle.get((r + i, c + j))
                if (altra is not None and altra.ingresso is not None) or (r + i, c + j) in f.spill:
                    bloccata = True
                    break
            if bloccata:
                break
        if bloccata:
            cella.valore = Errore(ESPANSIONE)
            f.spill_bloccati[(r, c)] = (r, c, r + h - 1, c + w - 1)
            return toccate
        cella.valore = nuovo
        f.aree_spill[(r, c)] = (h, w)
        for i in range(h):
            for j in range(w):
                if i or j:
                    f.spill[(r + i, c + j)] = (r, c)
                    toccate.add((f, r + i, c + j))
        f._estensione = None
        return toccate

    # --- annulla / ripeti --------------------------------------------------------
    def _registra_struttura(self) -> None:
        """Prima di un cambio di struttura: fotografia della cartella per "Annulla"."""
        op = self._operazione
        if op is None or self._in_annulla or op["struttura"] is not None:
            return
        op["struttura"] = self._fotografia()

    def _fotografia(self) -> dict:
        import copy
        from .file_lfogli import a_dizionario
        return copy.deepcopy(a_dizionario(self, con_storico=False))

    def _ripristina(self, foto: dict) -> None:
        from .file_lfogli import da_dizionario
        osservatori, storico = self.osservatori, self.storico
        annulla, ripeti = self._annulla, self._ripeti
        nuova = da_dizionario(foto)
        self.__dict__.update(nuova.__dict__)
        for f in self.fogli:
            f.cartella = self
        self.osservatori, self.storico = osservatori, storico
        self._annulla, self._ripeti = annulla, ripeti
        self._ricompila_tutto()

    def puo_annullare(self) -> bool:
        return bool(self._annulla)

    def puo_ripetere(self) -> bool:
        return bool(self._ripeti)

    def descrizione_annulla(self) -> str:
        return self._annulla[-1]["descrizione"] if self._annulla else ""

    def annulla(self) -> bool:
        return self._torna(self._annulla, self._ripeti)

    def ripeti(self) -> bool:
        return self._torna(self._ripeti, self._annulla)

    def _torna(self, da: list, a: list) -> bool:
        if not da:
            return False
        op = da.pop()
        inversa = {"descrizione": op["descrizione"], "celle": {}, "struttura": None}
        self._in_annulla = True
        try:
            if op["struttura"] is not None:
                inversa["struttura"] = self._fotografia()
                self._ripristina(op["struttura"])
            else:
                with self.lotto():
                    for (f, r, c), prima in op["celle"].items():
                        if f not in self.fogli:
                            continue
                        cella = f.celle.get((r, c))
                        inversa["celle"][(f, r, c)] = None if cella is None else (cella.ingresso, cella.stile, cella.nota)
                        if prima is None:
                            self._imposta_ingresso(f, r, c, None, formato_auto=False)
                            if (r, c) in f.celle:
                                f.celle[(r, c)].stile = 0
                                f.celle[(r, c)].nota = None
                                if f.celle[(r, c)].vuota():
                                    del f.celle[(r, c)]
                        else:
                            ingresso, stile, nota = prima
                            self._imposta_ingresso(f, r, c, ingresso, formato_auto=False)
                            cella = f.celle.get((r, c))
                            if cella is None:
                                cella = Cella()
                                f.celle[(r, c)] = cella
                            cella.stile = stile
                            cella.nota = nota
                            if cella.vuota():
                                del f.celle[(r, c)]
                        self._cambiate.add((f, r, c))
        finally:
            self._in_annulla = False
        a.append(inversa)
        return True


def _controlla_nome_foglio(nome: str) -> None:
    if not nome or len(nome) > 31 or any(ch in nome for ch in "[]:*?/\\"):
        raise ValueError(f"«{nome}» non va bene come nome di foglio: massimo 31 caratteri, senza [ ] : * ? / \\.")


def _testo_di_valore(v: Any) -> str | None:
    if v is None:
        return None
    if isinstance(v, bool):
        return "VERO" if v else "FALSO"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        if v.is_integer() and abs(v) < 1e15:
            return str(int(v))
        return repr(v).replace(".", ",")
    if isinstance(v, Errore):
        return v.codice
    import datetime as _dt
    if isinstance(v, (_dt.date, _dt.datetime)):
        from .valori import data_in_seriale
        return _testo_di_valore(data_in_seriale(v))
    return str(v)
