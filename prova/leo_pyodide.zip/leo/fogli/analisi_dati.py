"""Analisi "e se...": ricerca obiettivo, scenari, tabella di dati a una variabile."""

from __future__ import annotations

import math
from typing import Any

from .calcolo import Cartella, Foglio
from .valori import Errore, e_numero

__all__ = ["ricerca_obiettivo", "tabella_dati", "applica_scenario"]


def _prova(cartella: Cartella, ff: Foglio, rf: int, cf: int, fv: Foglio, rv: int, cv: int, x: float) -> float | None:
    cartella.imposta_valore(fv, rv, cv, x)
    v = ff.valore(rf, cf)
    if isinstance(v, Errore) or not e_numero(v):
        return None
    return float(v)


def ricerca_obiettivo(cartella: Cartella, ff: Foglio, rf: int, cf: int, obiettivo: float, fv: Foglio, rv: int,
                      cv: int, iterazioni: int = 200, tolleranza: float = 1e-9) -> float:
    """Trova il valore della cella variabile che porta la formula all'obiettivo (come "Ricerca obiettivo" di Excel)."""
    cella_f = ff.celle.get((rf, cf))
    if cella_f is None or cella_f.formula is None:
        raise ValueError("La prima cella deve contenere una formula.")
    cella_v = fv.celle.get((rv, cv))
    if cella_v is not None and cella_v.formula is not None:
        raise ValueError("La cella da cambiare deve contenere un numero, non una formula.")
    partenza = fv.valore(rv, cv)
    ingresso_iniziale = fv.ingresso(rv, cv) or None
    x0 = float(partenza) if e_numero(partenza) else 0.0
    storico = cartella.registra_storico
    cartella.registra_storico = False
    trovato: float | None = None
    try:
        def g(x: float) -> float | None:
            y = _prova(cartella, ff, rf, cf, fv, rv, cv, x)
            return None if y is None else y - obiettivo

        soglia = tolleranza * max(1, abs(obiettivo))
        x1 = x0 * 1.1 + 1 if x0 else 1.0
        y0, y1 = g(x0), g(x1)
        if y0 is not None and abs(y0) <= soglia:
            trovato = x0
        for _ in range(iterazioni):
            if trovato is not None or y1 is None or y0 is None:
                break
            if abs(y1) <= soglia:
                trovato = x1
                break
            if y1 == y0:
                x1 += 1e-6 * max(1, abs(x1))
                y1 = g(x1)
                continue
            x2 = x1 - y1 * (x1 - x0) / (y1 - y0)
            if not math.isfinite(x2):
                break
            x0, y0 = x1, y1
            x1, y1 = x2, g(x2)
        if trovato is None:       # ripiego: bisezione su un intervallo che cambia segno
            a, b = -1e9, 1e9
            ya, yb = g(a), g(b)
            if ya is not None and yb is not None and ya * yb < 0:
                for _ in range(300):
                    m = (a + b) / 2
                    ym = g(m)
                    if ym is None:
                        break
                    if abs(ym) <= soglia:
                        trovato = m
                        break
                    if ya * ym < 0:
                        b, yb = m, ym
                    else:
                        a, ya = m, ym
    finally:
        # si torna al valore di partenza senza lasciare passi di "Annulla"
        cartella._in_annulla = True
        try:
            cartella.imposta(fv, rv, cv, ingresso_iniziale)
        finally:
            cartella._in_annulla = False
        cartella.registra_storico = storico
    if trovato is None:
        raise ValueError("Non ho trovato un valore che porti la formula all'obiettivo.")
    risultato = _pulito(trovato)
    with cartella.operazione("Ricerca obiettivo"):
        cartella.imposta_valore(fv, rv, cv, risultato)
    return risultato


def _pulito(x: float) -> float | int:
    r = round(x, 9)
    return int(r) if float(r).is_integer() and abs(r) < 1e15 else r


def tabella_dati(cartella: Cartella, ff: Foglio, rf: int, cf: int, fv: Foglio, rv: int, cv: int,
                 valori: list[float]) -> list[Any]:
    """Il risultato della formula per ogni valore della cella variabile (che poi torna com'era)."""
    partenza = fv.ingresso(rv, cv)
    out = []
    cartella.registra_storico, prima = False, cartella.registra_storico
    try:
        for x in valori:
            cartella.imposta_valore(fv, rv, cv, x)
            out.append(ff.valore(rf, cf))
    finally:
        cartella.imposta(fv, rv, cv, partenza or None)
        cartella.registra_storico = prima
    return out


def applica_scenario(cartella: Cartella, foglio: Foglio, valori: dict[tuple[int, int], Any]) -> None:
    with cartella.operazione("Scenario"):
        for (r, c), v in valori.items():
            cartella.imposta_valore(foglio, r, c, v)
