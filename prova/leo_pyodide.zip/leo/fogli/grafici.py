"""Grafici collegati alle celle: si aggiornano da soli quando cambiano i dati."""

from __future__ import annotations

import itertools
from typing import Any

from .calcolo import Cartella, Foglio
from .operazioni import testo_mostrato
from .riferimenti import leggi_area, nome_area
from .valori import Errore, e_numero

__all__ = ["TIPI_GRAFICO", "aggiungi_grafico", "dati_grafico", "togli_grafico"]

TIPI_GRAFICO = ("colonne", "barre", "linee", "area", "torta", "anello", "dispersione")
_contatore = itertools.count(1)


def aggiungi_grafico(cartella: Cartella, foglio: Foglio, area: tuple[int, int, int, int], tipo: str = "colonne",
                     titolo: str = "", posizione: tuple[int, int] | None = None) -> dict:
    tipo = tipo.lower()
    if tipo not in TIPI_GRAFICO:
        raise ValueError(f"Il tipo di grafico «{tipo}» non esiste: {', '.join(TIPI_GRAFICO)}.")
    if posizione is None:
        posizione = (area[0], area[3] + 2)
    esistenti = {g.get("id") for f in cartella.fogli for g in f.grafici}
    n = len(esistenti) + 1
    while f"Grafico{n}" in esistenti:
        n += 1
    g = {"id": f"Grafico{n}", "area": nome_area(*area), "tipo": tipo, "titolo": titolo,
         "r": posizione[0], "c": posizione[1], "larghezza": 480, "altezza": 300, "legenda": True}
    with cartella.operazione("Grafico"):
        cartella._registra_struttura()
        foglio.grafici.append(g)
    return g


def togli_grafico(cartella: Cartella, foglio: Foglio, ident: str) -> None:
    with cartella.operazione("Togli grafico"):
        cartella._registra_struttura()
        foglio.grafici[:] = [g for g in foglio.grafici if g.get("id") != ident]


def dati_grafico(cartella: Cartella, foglio: Foglio, g: dict) -> dict:
    """{"categorie": [...], "serie": [{"nome": ..., "valori": [...]}]}: la prima colonna (se è testo)
    dà le categorie, la prima riga (se è testo) i nomi delle serie."""
    a = leggi_area(g.get("area", ""))
    if a is None:
        return {"categorie": [], "serie": []}
    r1, c1, r2, c2 = a
    mr, mc = foglio.estensione()
    r2, c2 = min(r2, max(mr, r1)), min(c2, max(mc, c1))
    indici = [r for r in range(r1, r2 + 1) if r not in foglio.righe_filtrate and r not in foglio.righe_nascoste]
    righe = [[foglio.valore(r, c) for c in range(c1, c2 + 1)] for r in indici]
    if not righe:
        return {"categorie": [], "serie": []}
    intestazione = len(righe) > 1 and all(not e_numero(v) for v in righe[0] if v is not None) and any(
        v is not None for v in righe[0])
    corpo = righe[1:] if intestazione else righe
    corpo_indici = indici[1:] if intestazione else indici
    prima_col_categorie = len(righe[0]) > 1 and any(r[0] is not None for r in corpo) and all(
        not e_numero(r[0]) for r in corpo if r[0] is not None)
    if not prima_col_categorie and len(righe[0]) > 1 and corpo and all(e_numero(r[0]) for r in corpo):
        # una prima colonna di date o di anni fa da categorie
        from .formato import e_formato_data
        if e_formato_data(cartella.stile(foglio, corpo_indici[0], c1).get("formato")) or g.get("categorie_prima_colonna"):
            prima_col_categorie = True
    nomi = [("" if v is None else str(v)) for v in righe[0]] if intestazione else []
    if prima_col_categorie:
        categorie = [testo_mostrato(cartella, foglio, r, c1)[0] for r in corpo_indici]
        dati = [r[1:] for r in corpo]
        nomi = nomi[1:]
    else:
        categorie = [str(i + 1) for i in range(len(corpo))]
        dati = corpo
    serie = []
    larghezza = len(dati[0]) if dati else 0
    for j in range(larghezza):
        valori = [(v if e_numero(v) else None) for v in (r[j] for r in dati)]
        serie.append({"nome": nomi[j] if j < len(nomi) and nomi[j] else f"Serie {j + 1}", "valori": valori})
    return {"categorie": categorie, "serie": serie}
