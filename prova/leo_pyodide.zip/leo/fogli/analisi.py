"""Lettura delle formule: dal testo ("=SOMMA(A1:A3;2,5)") all'albero, e ritorno.

Le formule si scrivono come in Excel italiano: argomenti separati da ``;``, virgola
decimale, nomi italiani (SOMMA, SE, CERCA.VERT). Si accettano anche i nomi inglesi
(SUM, IF, VLOOKUP): l'albero li converte sempre nel nome italiano.

Nodi dell'albero (tuple, per velocità):

    ("n", numero)  ("s", testo)  ("b", logico)  ("e", codice_errore)  ("v",) argomento vuoto
    ("c", foglio, r, c, ass_r, ass_c)                                    una cella
    ("a", foglio, r1, c1, r2, c2, ass_r1, ass_c1, ass_r2, ass_c2, genere) un'area: genere "celle",
                                                                         "colonne" (A:C) o "righe" (2:5)
    ("nome", NOME)  ("f", NOME, [argomenti])  ("op", simbolo, x, y)
    ("neg", x)  ("pos", x)  ("pct", x)  ("par", x)  ("rng", x, y)  ("arr", righe)

``foglio`` è None quando la formula non scrive il foglio (vale il foglio della cella).
"""

from __future__ import annotations

import re
from typing import Any, Callable

from .riferimenti import MAX_COLONNE, MAX_RIGHE, colonna, lettere, nome_foglio_in_formula
from .valori import CODICI_ERRORE, ERRORI_INGLESI, ERRORI_IN_INGLESE, RIF, SINTASSI, ErroreFormula

__all__ = ["analizza", "scrivi", "riferimenti_di", "sposta", "trasforma_riferimenti", "ErroreSintassi", "chiave_relativa",
           "in_inglese", "da_inglese", "pezzi"]


class ErroreSintassi(ErroreFormula):
    def __init__(self, messaggio: str, posizione: int = -1) -> None:
        super().__init__(SINTASSI, messaggio)
        self.posizione = posizione


# ---------------------------------------------------------------------------
# Pezzi (token)
# ---------------------------------------------------------------------------

_SPAZI = re.compile(r"\s+")
_FOGLIO = re.compile(r"('(?:[^']|'')+'|[A-Za-z_À-ÿ][\wÀ-ÿ.]*)!")
_COLONNE = re.compile(r"(\$?)([A-Za-z]{1,3}):(\$?)([A-Za-z]{1,3})(?![\wÀ-ÿ(.!$])")
_RIGHE = re.compile(r"(\$?)(\d{1,7}):(\$?)(\d{1,7})(?![\d\wÀ-ÿ(.,])")
_CELLA = re.compile(r"(\$?)([A-Za-z]{1,3})(\$?)(\d{1,7})(?![\wÀ-ÿ(.!])")
_NUMERO = re.compile(r"(\d+([.,]\d+)?|[.,]\d+)([eE][+-]?\d+)?")
_IDENT = re.compile(r"[A-Za-z_À-ÿ][\wÀ-ÿ.]*")
_OPERATORI = ("<>", "<=", ">=", "+", "-", "*", "/", "^", "&", "=", "<", ">", "%", ":")
_ERRORI = sorted(set(CODICI_ERRORE) | set(ERRORI_INGLESI), key=len, reverse=True)


class Pezzo:
    __slots__ = ("tipo", "testo", "valore", "pos")

    def __init__(self, tipo: str, testo: str, valore: Any, pos: int) -> None:
        self.tipo, self.testo, self.valore, self.pos = tipo, testo, valore, pos

    def __repr__(self) -> str:
        return f"Pezzo({self.tipo}, {self.testo!r})"


def _foglio_da_testo(t: str) -> str:
    if t.startswith("'"):
        return t[1:-1].replace("''", "'")
    return t


def pezzi(formula: str) -> list[Pezzo]:
    """Divide una formula (senza il "=" iniziale) in pezzi."""
    out: list[Pezzo] = []
    i, n = 0, len(formula)
    while i < n:
        ch = formula[i]
        if ch.isspace():
            i = _SPAZI.match(formula, i).end()
            continue
        if ch == '"':
            j, buf = i + 1, []
            while True:
                if j >= n:
                    raise ErroreSintassi("Virgolette non chiuse", i)
                if formula[j] == '"':
                    if j + 1 < n and formula[j + 1] == '"':
                        buf.append('"')
                        j += 2
                        continue
                    break
                buf.append(formula[j])
                j += 1
            out.append(Pezzo("STR", formula[i:j + 1], "".join(buf), i))
            i = j + 1
            continue
        if ch == "#":
            su = formula[i:i + 14].upper()
            for codice in _ERRORI:
                if su.startswith(codice):
                    out.append(Pezzo("ERR", formula[i:i + len(codice)], ERRORI_INGLESI.get(codice, codice), i))
                    i += len(codice)
                    break
            else:
                raise ErroreSintassi("Errore sconosciuto", i)
            continue
        # riferimenti con il foglio: Foglio2!A1, 'Vendite 2026'!B:B
        foglio = None
        inizio = i
        m = _FOGLIO.match(formula, i)
        if m:
            foglio = _foglio_da_testo(m.group(1))
            i = m.end()
        m = _COLONNE.match(formula, i)
        if m:
            c1, c2 = colonna(m.group(2)), colonna(m.group(4))
            out.append(Pezzo("COLONNE", formula[inizio:m.end()],
                             (foglio, c1, c2, bool(m.group(1)), bool(m.group(3))), inizio))
            i = m.end()
            continue
        m = _RIGHE.match(formula, i)
        if m:
            r1, r2 = int(m.group(2)) - 1, int(m.group(4)) - 1
            out.append(Pezzo("RIGHE", formula[inizio:m.end()],
                             (foglio, r1, r2, bool(m.group(1)), bool(m.group(3))), inizio))
            i = m.end()
            continue
        m = _CELLA.match(formula, i)
        if m:
            c = colonna(m.group(2))
            r = int(m.group(4)) - 1
            if 0 <= r < MAX_RIGHE and 0 <= c < MAX_COLONNE:
                out.append(Pezzo("CELLA", formula[inizio:m.end()],
                                 (foglio, r, c, bool(m.group(3)), bool(m.group(1))), inizio))
                i = m.end()
                continue
        if foglio is not None:
            raise ErroreSintassi("Dopo il nome del foglio serve una cella", inizio)
        if ch.isdigit() or (ch in ".," and i + 1 < n and formula[i + 1].isdigit()
                            and (not out or out[-1].tipo in ("OP", "SEP", "(", "{", "SEPC"))):
            m = _NUMERO.match(formula, i)
            testo = m.group(0)
            out.append(Pezzo("NUM", testo, float(testo.replace(",", ".")), i))
            i = m.end()
            continue
        m = _IDENT.match(formula, i)
        if m:
            nome = m.group(0)
            j = m.end()
            while j < n and formula[j] == " ":
                j += 1
            su = nome.upper()
            if j < n and formula[j] == "(":
                out.append(Pezzo("FUNZ", nome, su, i))
            elif su in ("VERO", "TRUE"):
                out.append(Pezzo("BOOL", nome, True, i))
            elif su in ("FALSO", "FALSE"):
                out.append(Pezzo("BOOL", nome, False, i))
            else:
                out.append(Pezzo("NOME", nome, su, i))
            i = m.end()
            continue
        if ch in ";,":
            out.append(Pezzo("SEP", ch, ch, i))
            i += 1
            continue
        if ch in "(){}":
            out.append(Pezzo(ch, ch, ch, i))
            i += 1
            continue
        if ch == "\\":
            out.append(Pezzo("SEPC", ch, ch, i))
            i += 1
            continue
        for op in _OPERATORI:
            if formula.startswith(op, i):
                out.append(Pezzo("OP", op, op, i))
                i += len(op)
                break
        else:
            raise ErroreSintassi(f"Carattere inatteso: {ch}", i)
    out.append(Pezzo("FINE", "", None, n))
    return out


# ---------------------------------------------------------------------------
# Analisi
# ---------------------------------------------------------------------------

_CONFRONTI = ("=", "<>", "<", ">", "<=", ">=")


def _nome_funzione(nome: str) -> str:
    from .funzioni import nome_canonico
    return nome_canonico(nome)


class _Analizzatore:
    def __init__(self, testo: str) -> None:
        self.p = pezzi(testo)
        self.i = 0

    def guarda(self) -> Pezzo:
        return self.p[self.i]

    def prendi(self) -> Pezzo:
        x = self.p[self.i]
        if x.tipo != "FINE":
            self.i += 1
        return x

    def e_op(self, *simboli: str) -> bool:
        x = self.p[self.i]
        return x.tipo == "OP" and x.valore in simboli

    def pretendi(self, tipo: str, cosa: str) -> Pezzo:
        x = self.guarda()
        if x.tipo != tipo:
            raise ErroreSintassi(f"Manca {cosa}", x.pos)
        return self.prendi()

    def tutto(self) -> tuple:
        if self.guarda().tipo == "FINE":
            raise ErroreSintassi("La formula è vuota", 0)
        x = self.confronto()
        if self.guarda().tipo != "FINE":
            q = self.guarda()
            if q.tipo == ")":
                raise ErroreSintassi("Una parentesi chiusa di troppo", q.pos)
            if q.tipo == "SEP":
                raise ErroreSintassi("Punto e virgola fuori da una funzione", q.pos)
            raise ErroreSintassi(f"Non capisco «{q.testo}»: forse manca un operatore", q.pos)
        return x

    def confronto(self) -> tuple:
        x = self.concatena()
        while self.e_op(*_CONFRONTI):
            op = self.prendi().valore
            x = ("op", op, x, self.concatena())
        return x

    def concatena(self) -> tuple:
        x = self.somma()
        while self.e_op("&"):
            self.prendi()
            x = ("op", "&", x, self.somma())
        return x

    def somma(self) -> tuple:
        x = self.prodotto()
        while self.e_op("+", "-"):
            op = self.prendi().valore
            x = ("op", op, x, self.prodotto())
        return x

    def prodotto(self) -> tuple:
        x = self.potenza()
        while self.e_op("*", "/"):
            op = self.prendi().valore
            x = ("op", op, x, self.potenza())
        return x

    def potenza(self) -> tuple:
        x = self.segno()
        while self.e_op("^"):
            self.prendi()
            x = ("op", "^", x, self.segno())
        return x

    def segno(self) -> tuple:
        if self.e_op("-"):
            self.prendi()
            return ("neg", self.segno())
        if self.e_op("+"):
            self.prendi()
            return ("pos", self.segno())
        return self.percento()

    def percento(self) -> tuple:
        x = self.intervallo()
        while self.e_op("%"):
            self.prendi()
            x = ("pct", x)
        return x

    def intervallo(self) -> tuple:
        x = self.primario()
        while self.e_op(":"):
            self.prendi()
            y = self.primario()
            if x[0] == "c" and y[0] == "c" and (y[1] is None or y[1] == x[1]):
                _, f, r1, c1, ar1, ac1 = x
                _, _, r2, c2, ar2, ac2 = y
                x = ("a", f, r1, c1, r2, c2, ar1, ac1, ar2, ac2, "celle")
            else:
                x = ("rng", x, y)
        return x

    def primario(self) -> tuple:
        x = self.prendi()
        t = x.tipo
        if t == "NUM":
            v = x.valore
            return ("n", int(v) if v.is_integer() and abs(v) < 1e15 and "e" not in x.testo.lower()
                    and "," not in x.testo and "." not in x.testo else v)
        if t == "STR":
            return ("s", x.valore)
        if t == "BOOL":
            return ("b", x.valore)
        if t == "ERR":
            return ("e", x.valore)
        if t == "CELLA":
            f, r, c, ar, ac = x.valore
            return ("c", f, r, c, ar, ac)
        if t == "COLONNE":
            f, c1, c2, a1, a2 = x.valore
            return ("a", f, 0, min(c1, c2), MAX_RIGHE - 1, max(c1, c2), True, a1, True, a2, "colonne")
        if t == "RIGHE":
            f, r1, r2, a1, a2 = x.valore
            return ("a", f, min(r1, r2), 0, max(r1, r2), MAX_COLONNE - 1, a1, True, a2, True, "righe")
        if t == "NOME":
            return ("nome", x.valore)
        if t == "FUNZ":
            nome = _nome_funzione(x.valore)
            self.pretendi("(", "la parentesi aperta")
            argomenti: list[tuple] = []
            if self.guarda().tipo != ")":
                while True:
                    if self.guarda().tipo in ("SEP", ")"):
                        argomenti.append(("v",))
                    else:
                        argomenti.append(self.confronto())
                    if self.guarda().tipo == "SEP":
                        self.prendi()
                        if self.guarda().tipo == ")":
                            argomenti.append(("v",))
                        continue
                    break
            if self.guarda().tipo != ")":
                raise ErroreSintassi(f"Manca la parentesi chiusa di {nome}", self.guarda().pos)
            self.prendi()
            return ("f", nome, argomenti)
        if t == "(":
            dentro = self.confronto()
            if self.guarda().tipo != ")":
                raise ErroreSintassi("Manca la parentesi chiusa", self.guarda().pos)
            self.prendi()
            return ("par", dentro)
        if t == "{":
            return self.matrice()
        if t == "OP" and x.valore in ("-", "+"):
            self.i -= 1
            return self.segno()
        if t == "FINE":
            raise ErroreSintassi("La formula finisce troppo presto", x.pos)
        raise ErroreSintassi(f"Non mi aspettavo «{x.testo}»", x.pos)

    def matrice(self) -> tuple:
        righe: list[list[Any]] = [[]]
        while True:
            x = self.prendi()
            neg = False
            if x.tipo == "OP" and x.valore == "-":
                neg = True
                x = self.prendi()
            if x.tipo == "NUM":
                v = -x.valore if neg else x.valore
                righe[-1].append(int(v) if float(v).is_integer() and "," not in x.testo and "." not in x.testo else v)
            elif x.tipo == "STR":
                righe[-1].append(x.valore)
            elif x.tipo == "BOOL":
                righe[-1].append(x.valore)
            elif x.tipo == "ERR":
                from .valori import Errore
                righe[-1].append(Errore(x.valore))
            else:
                raise ErroreSintassi("In una matrice {…} vanno solo numeri, testi o VERO/FALSO", x.pos)
            s = self.prendi()
            if s.tipo == "}":
                break
            if s.tipo == "SEPC" or (s.tipo == "SEP" and s.valore == ","):
                continue
            if s.tipo == "SEP" and s.valore == ";":
                righe.append([])
                continue
            raise ErroreSintassi("Matrice scritta male: separa le colonne con \\ e le righe con ;", s.pos)
        if len({len(r) for r in righe}) != 1:
            raise ErroreSintassi("Le righe della matrice hanno lunghezze diverse", 0)
        return ("arr", righe)


def analizza(testo: str) -> tuple:
    """Testo della formula (con o senza "=") -> albero."""
    if testo.startswith("="):
        testo = testo[1:]
    return _Analizzatore(testo).tutto()


# ---------------------------------------------------------------------------
# Scrittura (albero -> testo italiano)
# ---------------------------------------------------------------------------

def _numero(v: Any, inglese: bool) -> str:
    if isinstance(v, int):
        return str(v)
    s = repr(float(v))
    if s.endswith(".0"):
        s = s[:-2]
    if "e" in s:
        s = s.upper()
    return s if inglese else s.replace(".", ",")


def _foglio_txt(f: str | None) -> str:
    return "" if f is None else nome_foglio_in_formula(f) + "!"


def _cella_txt(r: int, c: int, ar: bool, ac: bool) -> str:
    return f"{'$' if ac else ''}{lettere(c)}{'$' if ar else ''}{r + 1}"


def scrivi(albero: tuple, inglese: bool = False) -> str:
    """Albero -> testo della formula senza "=" (italiano, oppure inglese per i file .xlsx)."""
    sep = "," if inglese else ";"

    def w(x: tuple) -> str:
        k = x[0]
        if k == "n":
            return _numero(x[1], inglese)
        if k == "s":
            return '"' + x[1].replace('"', '""') + '"'
        if k == "b":
            return ("TRUE" if x[1] else "FALSE") if inglese else ("VERO" if x[1] else "FALSO")
        if k == "e":
            return ERRORI_IN_INGLESE.get(x[1], x[1]) if inglese else x[1]
        if k == "v":
            return ""
        if k == "c":
            return _foglio_txt(x[1]) + _cella_txt(x[2], x[3], x[4], x[5])
        if k == "a":
            _, f, r1, c1, r2, c2, ar1, ac1, ar2, ac2, genere = x
            if genere == "colonne":
                return f"{_foglio_txt(f)}{'$' if ac1 else ''}{lettere(c1)}:{'$' if ac2 else ''}{lettere(c2)}"
            if genere == "righe":
                return f"{_foglio_txt(f)}{'$' if ar1 else ''}{r1 + 1}:{'$' if ar2 else ''}{r2 + 1}"
            return f"{_foglio_txt(f)}{_cella_txt(r1, c1, ar1, ac1)}:{_cella_txt(r2, c2, ar2, ac2)}"
        if k == "nome":
            return x[1]
        if k == "f":
            nome = x[1]
            if inglese:
                from .funzioni import nome_inglese
                nome = nome_inglese(nome)
            return nome + "(" + sep.join(w(a) for a in x[2]) + ")"
        if k == "op":
            return w(x[2]) + x[1] + w(x[3])
        if k == "neg":
            return "-" + w(x[1])
        if k == "pos":
            return "+" + w(x[1])
        if k == "pct":
            return w(x[1]) + "%"
        if k == "par":
            return "(" + w(x[1]) + ")"
        if k == "rng":
            return w(x[1]) + ":" + w(x[2])
        if k == "arr":
            sc = "," if inglese else "\\"
            sr = ";"
            return "{" + sr.join(sc.join(_valore_matrice(v, inglese) for v in r) for r in x[1]) + "}"
        raise ValueError(k)

    return w(albero)


def _valore_matrice(v: Any, inglese: bool) -> str:
    if isinstance(v, bool):
        return ("TRUE" if v else "FALSE") if inglese else ("VERO" if v else "FALSO")
    if isinstance(v, (int, float)):
        return _numero(v, inglese)
    if isinstance(v, str):
        return '"' + v.replace('"', '""') + '"'
    return str(v)


# ---------------------------------------------------------------------------
# Riferimenti: elenco e trasformazioni
# ---------------------------------------------------------------------------

def riferimenti_di(albero: tuple) -> list[tuple]:
    """Tutti i nodi "c" e "a" dell'albero (per le dipendenze)."""
    out: list[tuple] = []

    def giro(x: tuple) -> None:
        k = x[0]
        if k in ("c", "a"):
            out.append(x)
        elif k == "f":
            for a in x[2]:
                giro(a)
        elif k == "op":
            giro(x[2])
            giro(x[3])
        elif k in ("neg", "pos", "pct", "par"):
            giro(x[1])
        elif k == "rng":
            giro(x[1])
            giro(x[2])

    giro(albero)
    return out


def nomi_di(albero: tuple) -> set[str]:
    out: set[str] = set()

    def giro(x: tuple) -> None:
        k = x[0]
        if k == "nome":
            out.add(x[1])
        elif k == "f":
            for a in x[2]:
                giro(a)
        elif k == "op":
            giro(x[2])
            giro(x[3])
        elif k in ("neg", "pos", "pct", "par"):
            giro(x[1])
        elif k == "rng":
            giro(x[1])
            giro(x[2])

    giro(albero)
    return out


def funzioni_di(albero: tuple) -> set[str]:
    out: set[str] = set()

    def giro(x: tuple) -> None:
        k = x[0]
        if k == "f":
            out.add(x[1])
            for a in x[2]:
                giro(a)
        elif k == "op":
            giro(x[2])
            giro(x[3])
        elif k in ("neg", "pos", "pct", "par"):
            giro(x[1])
        elif k == "rng":
            giro(x[1])
            giro(x[2])

    giro(albero)
    return out


def trasforma_riferimenti(albero: tuple, cambia: Callable[[tuple], tuple]) -> tuple:
    """Nuovo albero con ``cambia(nodo)`` applicato a ogni nodo "c" e "a"."""
    def giro(x: tuple) -> tuple:
        k = x[0]
        if k in ("c", "a"):
            return cambia(x)
        if k == "f":
            return ("f", x[1], [giro(a) for a in x[2]])
        if k == "op":
            return ("op", x[1], giro(x[2]), giro(x[3]))
        if k in ("neg", "pos", "pct", "par"):
            return (k, giro(x[1]))
        if k == "rng":
            return ("rng", giro(x[1]), giro(x[2]))
        return x

    return giro(albero)


def sposta(albero: tuple, dr: int, dc: int) -> tuple:
    """Copia di una formula spostata di dr righe e dc colonne (i riferimenti relativi seguono)."""
    def cambia(x: tuple) -> tuple:
        if x[0] == "c":
            _, f, r, c, ar, ac = x
            nr = r if ar else r + dr
            nc = c if ac else c + dc
            if not (0 <= nr < MAX_RIGHE and 0 <= nc < MAX_COLONNE):
                return ("e", RIF)
            return ("c", f, nr, nc, ar, ac)
        _, f, r1, c1, r2, c2, ar1, ac1, ar2, ac2, genere = x
        if genere != "colonne":
            r1 = r1 if ar1 else r1 + dr
            r2 = r2 if ar2 else r2 + dr
        if genere != "righe":
            c1 = c1 if ac1 else c1 + dc
            c2 = c2 if ac2 else c2 + dc
        if not (0 <= r1 < MAX_RIGHE and 0 <= r2 < MAX_RIGHE and 0 <= c1 < MAX_COLONNE and 0 <= c2 < MAX_COLONNE):
            return ("e", RIF)
        return ("a", f, r1, c1, r2, c2, ar1, ac1, ar2, ac2, genere)

    return trasforma_riferimenti(albero, cambia)


# ---------------------------------------------------------------------------
# Chiave "relativa": la stessa per tutte le copie di una formula
# ---------------------------------------------------------------------------

_RE_RELATIVA = re.compile(
    r'"(?:[^"]|"")*"'                                              # testi: restano come sono
    r"|'(?:[^']|'')+'!"                                            # fogli tra apici
    r"|(?<![\wÀ-ÿ.$])(\$?)([A-Za-z]{1,3}):(\$?)([A-Za-z]{1,3})(?![\wÀ-ÿ(.!$])"   # A:C
    r"|(?<![\wÀ-ÿ.$,])(\$?)(\d{1,7}):(\$?)(\d{1,7})(?![\d\wÀ-ÿ(.,])"           # 2:5
    r"|(?<![\wÀ-ÿ.$])(\$?)([A-Za-z]{1,3})(\$?)(\d{1,7})(?![\wÀ-ÿ(.!])"            # B3
)


def chiave_relativa(testo: str, r: int, c: int) -> str | None:
    """Testo della formula con i riferimenti relativi scritti come distanza dalla cella.

    Due celle con la stessa chiave hanno la "stessa" formula copiata (in Excel: la stessa
    formula in notazione R1C1), quindi l'analisi e la compilazione si fanno una volta sola."""
    def cambia(m: re.Match) -> str:
        g = m.groups()
        if g[1] is not None:            # colonne
            c1, c2 = colonna(g[1]), colonna(g[3])
            return f"\x00C{'$' + str(c1) if g[0] else c1 - c}:{'$' + str(c2) if g[2] else c2 - c}\x00"
        if g[5] is not None:            # righe
            r1, r2 = int(g[5]) - 1, int(g[7]) - 1
            return f"\x00R{'$' + str(r1) if g[4] else r1 - r}:{'$' + str(r2) if g[6] else r2 - r}\x00"
        if g[9] is not None:            # cella
            cc, rr = colonna(g[9]), int(g[11]) - 1
            return f"\x00{'$' + str(cc) if g[8] else cc - c},{'$' + str(rr) if g[10] else rr - r}\x00"
        return m.group(0)
    try:
        return _RE_RELATIVA.sub(cambia, testo.upper() if '"' not in testo else testo)
    except Exception:  # noqa: BLE001
        return None


# ---------------------------------------------------------------------------
# Inglese <-> italiano (file .xlsx)
# ---------------------------------------------------------------------------

def in_inglese(testo_italiano: str) -> str:
    """"=SOMMA(A1;2,5)" -> "SUM(A1,2.5)" (senza "=", come nei file .xlsx)."""
    return scrivi(analizza(testo_italiano), inglese=True)


def da_inglese(testo_inglese: str) -> str:
    """"SUM(A1,2.5)" (da un .xlsx) -> "=SOMMA(A1;2,5)"."""
    t = testo_inglese[1:] if testo_inglese.startswith("=") else testo_inglese
    return "=" + scrivi(_AnalizzatoreInglese(t).tutto())


class _AnalizzatoreInglese(_Analizzatore):
    """Le formule dei file .xlsx: virgola tra gli argomenti, punto decimale."""

    def __init__(self, testo: str) -> None:
        self.p = _pezzi_inglesi(testo)
        self.i = 0


def _pezzi_inglesi(testo: str) -> list[Pezzo]:
    # stessa lettura, ma "1,5" non è mai un numero decimale: le virgole separano gli argomenti
    out: list[Pezzo] = []
    i, n = 0, len(testo)
    parti = []
    while i < n:
        ch = testo[i]
        if ch == '"':
            j = i + 1
            while j < n:
                if testo[j] == '"':
                    if j + 1 < n and testo[j + 1] == '"':
                        j += 2
                        continue
                    break
                j += 1
            parti.append(testo[i:j + 1])
            i = j + 1
            continue
        if ch == "'":
            j = testo.find("'!", i + 1)
            if j > 0:
                parti.append(testo[i:j + 2])
                i = j + 2
                continue
        if ch == ",":
            parti.append(";")
            i += 1
            continue
        if ch == ";":   # nelle matrici {1,2;3,4}: ";" separa le righe come in italiano
            parti.append(";")
            i += 1
            continue
        if ch == "{":
            j = testo.find("}", i)
            if j > 0:
                dentro = testo[i + 1:j]
                righe = [r.split(",") for r in dentro.split(";")]
                parti.append("{" + ";".join("\\".join(v.replace(".", ",") if re.fullmatch(r"-?[\d.]+(E[+-]?\d+)?", v, re.I) else v
                                                          for v in r) for r in righe) + "}")
                i = j + 1
                continue
        if ch.isdigit() or (ch == "." and i + 1 < n and testo[i + 1].isdigit()):
            m = re.compile(r"(\d+(\.\d+)?|\.\d+)([eE][+-]?\d+)?").match(testo, i)
            prima = testo[i - 1] if i > 0 else ""
            if prima.isalpha() or prima == "$":   # parte di un riferimento (A1)
                parti.append(ch)
                i += 1
                continue
            parti.append(m.group(0).replace(".", ","))
            i = m.end()
            continue
        parti.append(ch)
        i += 1
    out = pezzi("".join(parti))
    return out
