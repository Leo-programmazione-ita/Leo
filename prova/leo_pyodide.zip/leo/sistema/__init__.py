"""Pacchetto ``leo.sistema``: il codice che parla con Windows (senza pacchetti esterni).

Qui c'e' la parte "nativa" delle librerie di sistema di Leo; la registrazione
delle funzioni visibili dai programmi Leo e' in ``leo/libreria/`` (``sistema.py``,
``desktop.py``, ``computer.py``).

Moduli:

* :mod:`leo.sistema._win` - aiuti comuni: caricamento pigro delle DLL,
  ``solo_windows()``, :class:`ErroreSistema`, conferme all'utente,
  PowerShell senza finestra, decodifica dell'uscita dei comandi;
* :mod:`leo.sistema.programmi` - informazioni di sistema, variabili d'ambiente,
  processi, programmi, comandi, appunti, cestino, collegamenti, avvio
  automatico e associazioni (S1);
* ``desktop`` (S2) e ``hardware`` (S3).

Regola: nessun modulo di questo pacchetto chiama Windows quando viene
importato, cosi' tutto si importa (e si prova con i finti) anche su Linux.
"""

from ._win import ErroreSistema, e_windows, solo_windows  # noqa: F401
