"""Desktop di Windows per la libreria di Leo (parte S2).

Qui c'e' il "motore" delle funzioni registrate in ``leo/libreria/desktop.py``:
finestre delle applicazioni aperte, schermi, cattura dello schermo in PNG,
colore di un punto, notifiche, finestre di dialogo native, sfondo del
desktop, tema e colore d'accento, suoni di avviso.

Organizzazione (per poterlo provare anche su Linux):

* le **funzioni pure** (stato di una finestra, ricerca per titolo, calcolo
  delle finestre affiancate, schermo che contiene un punto, conversioni dei
  colori, filtri dei file, encoder PNG, script PowerShell delle notifiche...)
  non toccano il sistema e si provano ovunque;
* le **chiamate native** stanno tutte nella classe :class:`NativoWindows`
  (ctypes con user32, gdi32, shcore, dwmapi, comdlg32, shell32, ole32,
  winmm; ``winreg``; PowerShell senza finestra). Il modulo usa l'istanza
  :data:`nativo`, che i test sostituiscono con un finto.

Niente simulazione di tastiera o mouse: le finestre si comandano solo con le
normali richieste di Windows (``ShowWindow``, ``SetWindowPos``, ``WM_CLOSE``).

Mentre girano i test automatici (``unittest`` caricato) le azioni vere che
cambiano il desktop (spostare o chiudere finestre, sfondo, notifiche, suoni)
sono bloccate; per provarle davvero: ``LEO_SISTEMA_AZIONI_VERE=1``.
"""

from __future__ import annotations

import datetime
import os
import struct
import subprocess
import sys
import zlib
from typing import Any

from ..errori import ErroreValore
from . import _win

# ===========================================================================
# Costanti di Windows
# ===========================================================================

SW_MINIMIZZA = 6      # SW_MINIMIZE
SW_MASSIMIZZA = 3     # SW_MAXIMIZE
SW_RIPRISTINA = 9     # SW_RESTORE

#: classi delle finestre del desktop stesso: non si elencano e non si chiudono
#: (``WM_CLOSE`` a "Progman" aprirebbe la finestra di spegnimento del computer)
CLASSI_DEL_DESKTOP = frozenset({"Progman", "WorkerW", "Shell_TrayWnd", "Shell_SecondaryTrayWnd"})

#: icone di ``MessageBoxW``
ICONE_MESSAGGIO = {"info": 0x40, "informazione": 0x40, "avviso": 0x30, "attenzione": 0x30,
                   "errore": 0x10, "domanda": 0x20, "nessuna": 0}
MB_SINO = 0x04
MB_IN_PRIMO_PIANO = 0x00010000 | 0x00040000  # MB_SETFOREGROUND | MB_TOPMOST
IDSI = 6

#: suoni di sistema: nome italiano -> codice di ``MessageBeep`` (intero) o alias di ``PlaySoundW`` (testo)
SUONI_DI_SISTEMA: dict[str, int | str] = {
    "predefinito": 0x00,
    "informazione": 0x40,
    "avviso": 0x30,
    "errore": 0x10,
    "domanda": 0x20,
    "bip": 0xFFFFFFFF,
    "notifica": "Notification.Default",
    "posta": "MailBeep",
    "promemoria": "Notification.Reminder",
}

#: stili dello sfondo: nome -> (WallpaperStyle, TileWallpaper) in HKCU\Control Panel\Desktop
STILI_SFONDO = {
    "riempi": ("10", "0"),
    "adatta": ("6", "0"),
    "estendi": ("2", "0"),
    "affianca": ("0", "1"),
    "centra": ("0", "0"),
    "estendi_su_schermi": ("22", "0"),
}

CHIAVE_TEMA = r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize"
CHIAVE_DWM = r"Software\Microsoft\Windows\DWM"


# ===========================================================================
# Controlli comuni
# ===========================================================================

def in_prova() -> bool:
    """``True`` mentre girano i test automatici (le azioni vere sono bloccate)."""
    return "unittest" in sys.modules and os.environ.get("LEO_SISTEMA_AZIONI_VERE") != "1"


def blocca_se_in_prova(azione: str) -> None:
    if in_prova():
        raise ErroreValore(f"Azione `{azione}` bloccata: sono in corso i test automatici.",
                           suggerimento="Per eseguirla davvero durante i test imposta "
                                        "la variabile d'ambiente LEO_SISTEMA_AZIONI_VERE=1.")


# ===========================================================================
# Funzioni pure: finestre
# ===========================================================================

def stato_finestra(minimizzata: bool, massimizzata: bool) -> str:
    """"minimizzata", "massimizzata" o "normale"."""
    if minimizzata:
        return "minimizzata"
    if massimizzata:
        return "massimizzata"
    return "normale"


def componi_finestra(grezza: dict, attiva: int = 0) -> dict:
    """Il dizionario Leo di una finestra dai dati grezzi del backend.

    ``grezza`` ha: id, titolo, programma, pid, classe, x, y, larghezza, altezza,
    minimizzata, massimizzata, sempre_davanti.
    """
    return {
        "id": int(grezza["id"]),
        "titolo": str(grezza.get("titolo", "")),
        "programma": str(grezza.get("programma", "")),
        "pid": int(grezza.get("pid", 0)),
        "classe": str(grezza.get("classe", "")),
        "x": int(grezza.get("x", 0)),
        "y": int(grezza.get("y", 0)),
        "larghezza": int(grezza.get("larghezza", 0)),
        "altezza": int(grezza.get("altezza", 0)),
        "stato": stato_finestra(bool(grezza.get("minimizzata")), bool(grezza.get("massimizzata"))),
        "sempre_in_primo_piano": bool(grezza.get("sempre_davanti")),
        "attiva": bool(attiva) and int(grezza["id"]) == int(attiva),
    }


def da_elencare(grezza: dict) -> bool:
    """Vero per le finestre "vere" delle applicazioni (titolo non vuoto, non il desktop)."""
    return bool(str(grezza.get("titolo", "")).strip()) and grezza.get("classe") not in CLASSI_DEL_DESKTOP


def filtra_per_titolo(finestre: list[dict], titolo: str) -> list[dict]:
    """Finestre il cui titolo e' uguale a ``titolo`` (senza badare a maiuscole) e poi quelle che lo contengono.

    Prima le corrispondenze esatte, poi le parziali, ognuna nell'ordine di Windows
    (dalla finestra piu' in alto). Anche il nome del programma conta
    ("notepad" trova le finestre di notepad.exe).
    """
    cerca = titolo.strip().casefold()
    if not cerca:
        return []
    esatte, parziali = [], []
    for f in finestre:
        t = str(f.get("titolo", "")).casefold()
        prog = str(f.get("programma", "")).casefold()
        prog_breve = prog[:-4] if prog.endswith(".exe") else prog
        if t == cerca or cerca in (prog, prog_breve):
            esatte.append(f)
        elif cerca in t:
            parziali.append(f)
    return esatte + parziali


def rettangoli_affiancati(area: tuple[int, int, int, int], divisione: float,
                          bordi_a: tuple[int, int, int, int] = (0, 0, 0, 0),
                          bordi_b: tuple[int, int, int, int] = (0, 0, 0, 0)) -> tuple[tuple, tuple]:
    """Rettangoli (x, y, larghezza, altezza) per due finestre affiancate nell'area di lavoro.

    ``divisione`` e' la frazione (0..1) di larghezza della finestra di sinistra.
    ``bordi_*`` sono i bordi invisibili (sinistra, sopra, destra, sotto) che Windows 10/11
    aggiunge attorno alle finestre: si allargano i rettangoli di quel tanto, cosi' le
    finestre si toccano davvero.
    """
    x, y, larghezza, altezza = area
    sinistra = int(round(larghezza * divisione))
    destra = larghezza - sinistra

    def allarga(rx, ry, rl, ra, bordi):
        bs, bsu, bd, bgi = bordi
        return rx - bs, ry - bsu, rl + bs + bd, ra + bsu + bgi

    return allarga(x, y, sinistra, altezza, bordi_a), allarga(x + sinistra, y, destra, altezza, bordi_b)


# ===========================================================================
# Funzioni pure: schermi
# ===========================================================================

def ordina_schermi(schermi: list[dict]) -> list[dict]:
    """Schermi numerati da 1: prima il principale, poi da sinistra a destra e dall'alto in basso."""
    ordinati = sorted(schermi, key=lambda s: (not s.get("principale"), s.get("x", 0), s.get("y", 0)))
    return [dict(s, numero=i) for i, s in enumerate(ordinati, start=1)]


def scala_da_dpi(dpi: int | None) -> int:
    """Scala in percentuale (100, 125, 150...) dai DPI (96 = 100%)."""
    if not dpi or dpi <= 0:
        return 100
    return int(round(dpi * 100 / 96))


def componi_schermo(s: dict) -> dict:
    """Il dizionario Leo di uno schermo (gia' numerato)."""
    lx, ly, ll, la = s.get("lavoro", (s["x"], s["y"], s["larghezza"], s["altezza"]))
    return {
        "numero": int(s["numero"]),
        "nome": str(s.get("nome", "")),
        "dispositivo": str(s.get("dispositivo", "")),
        "principale": bool(s.get("principale")),
        "x": int(s["x"]),
        "y": int(s["y"]),
        "larghezza": int(s["larghezza"]),
        "altezza": int(s["altezza"]),
        "area_di_lavoro": {"x": int(lx), "y": int(ly), "larghezza": int(ll), "altezza": int(la)},
        "dpi": int(s.get("dpi") or 96),
        "scala": scala_da_dpi(s.get("dpi")),
        "frequenza": int(s.get("frequenza") or 0),
    }


def schermo_del_punto(schermi: list[dict], x: int, y: int) -> dict | None:
    """Lo schermo che contiene il punto (x, y); se nessuno, il piu' vicino; None senza schermi."""
    if not schermi:
        return None
    for s in schermi:
        if s["x"] <= x < s["x"] + s["larghezza"] and s["y"] <= y < s["y"] + s["altezza"]:
            return s

    def distanza(s):
        dx = max(s["x"] - x, 0, x - (s["x"] + s["larghezza"] - 1))
        dy = max(s["y"] - y, 0, y - (s["y"] + s["altezza"] - 1))
        return dx * dx + dy * dy

    return min(schermi, key=distanza)


def area_totale(schermi: list[dict]) -> tuple[int, int, int, int]:
    """Il rettangolo (x, y, larghezza, altezza) che contiene tutti gli schermi (desktop virtuale)."""
    if not schermi:
        return 0, 0, 0, 0
    x0 = min(s["x"] for s in schermi)
    y0 = min(s["y"] for s in schermi)
    x1 = max(s["x"] + s["larghezza"] for s in schermi)
    y1 = max(s["y"] + s["altezza"] for s in schermi)
    return x0, y0, x1 - x0, y1 - y0


# ===========================================================================
# Funzioni pure: colori
# ===========================================================================

def esadecimale(r: int, g: int, b: int) -> str:
    """"#RRGGBB" (come ``rgb()`` della libreria)."""
    return "#{:02X}{:02X}{:02X}".format(r & 0xFF, g & 0xFF, b & 0xFF)


def da_colorref(valore: int) -> tuple[int, int, int]:
    """(r, g, b) da un COLORREF di Windows (0x00BBGGRR)."""
    return valore & 0xFF, (valore >> 8) & 0xFF, (valore >> 16) & 0xFF


def a_colorref(r: int, g: int, b: int) -> int:
    return (r & 0xFF) | ((g & 0xFF) << 8) | ((b & 0xFF) << 16)


def leggi_colore(testo: str) -> tuple[int, int, int] | None:
    """(r, g, b) da "#RRGGBB", "RRGGBB" o "#RGB"; None se il testo non e' un colore."""
    t = testo.strip().lstrip("#")
    if len(t) == 3:
        t = "".join(c * 2 for c in t)
    if len(t) != 6:
        return None
    try:
        n = int(t, 16)
    except ValueError:
        return None
    return (n >> 16) & 0xFF, (n >> 8) & 0xFF, n & 0xFF


def colore_accento_da_dwm(accent_color: int | None, colorization: int | None) -> tuple[int, int, int] | None:
    """Colore d'accento dal registro: ``AccentColor`` (0xAABBGGRR) o ``ColorizationColor`` (0xAARRGGBB)."""
    if accent_color is not None:
        return da_colorref(accent_color & 0xFFFFFF)
    if colorization is not None:
        return (colorization >> 16) & 0xFF, (colorization >> 8) & 0xFF, colorization & 0xFF
    return None


# ===========================================================================
# Funzioni pure: immagini PNG
# ===========================================================================

def bgra_a_rgb(dati: bytes, larghezza: int, altezza: int) -> bytes:
    """Pixel BGRA (32 bit, come li da' ``GetDIBits``) in pixel RGB (24 bit)."""
    n = larghezza * altezza
    rgb = bytearray(n * 3)
    rgb[0::3] = dati[2:n * 4:4]
    rgb[1::3] = dati[1:n * 4:4]
    rgb[2::3] = dati[0:n * 4:4]
    return bytes(rgb)


def ritaglia_rgb(dati: bytes, larghezza: int, altezza: int,
                 x: int, y: int, nuova_larghezza: int, nuova_altezza: int) -> bytes:
    """Ritaglio di un'immagine RGB (i valori fuori dall'immagine si stringono ai bordi)."""
    x = max(0, min(x, larghezza))
    y = max(0, min(y, altezza))
    nuova_larghezza = max(0, min(nuova_larghezza, larghezza - x))
    nuova_altezza = max(0, min(nuova_altezza, altezza - y))
    riga = larghezza * 3
    return b"".join(dati[(y + r) * riga + x * 3:(y + r) * riga + (x + nuova_larghezza) * 3]
                    for r in range(nuova_altezza))


def _blocco_png(tipo: bytes, dati: bytes) -> bytes:
    return struct.pack(">I", len(dati)) + tipo + dati + struct.pack(">I", zlib.crc32(tipo + dati) & 0xFFFFFFFF)


def codifica_png(larghezza: int, altezza: int, rgb: bytes, livello: int = 6) -> bytes:
    """File PNG (RGB, 8 bit per canale) scritto solo con ``zlib``."""
    if larghezza <= 0 or altezza <= 0:
        raise ErroreValore("L'immagine da salvare è vuota.")
    riga = larghezza * 3
    if len(rgb) < riga * altezza:
        raise ErroreValore("I dati dell'immagine sono incompleti.")
    grezzi = b"".join(b"\x00" + rgb[i * riga:(i + 1) * riga] for i in range(altezza))
    intestazione = struct.pack(">IIBBBBB", larghezza, altezza, 8, 2, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + _blocco_png(b"IHDR", intestazione)
            + _blocco_png(b"IDAT", zlib.compress(grezzi, livello)) + _blocco_png(b"IEND", b""))


def salva_png(percorso: str, larghezza: int, altezza: int, rgb: bytes) -> str:
    """Salva l'immagine RGB come PNG (con Pillow se c'e', altrimenti con l'encoder interno)."""
    try:
        from PIL import Image  # facoltativo

        Image.frombytes("RGB", (larghezza, altezza), bytes(rgb)).save(percorso, "PNG")
        return percorso
    except ImportError:
        pass
    with open(percorso, "wb") as f:
        f.write(codifica_png(larghezza, altezza, rgb))
    return percorso


def nome_cattura(adesso: datetime.datetime | None = None) -> str:
    """Nome predefinito di una cattura: "cattura_AAAAMMGG_HHMMSS.png"."""
    adesso = adesso or datetime.datetime.now()
    return adesso.strftime("cattura_%Y%m%d_%H%M%S.png")


# ===========================================================================
# Funzioni pure: filtri dei file
# ===========================================================================

def normalizza_filtri(filtri: Any) -> list[tuple[str, list[str]]] | None:
    """Filtri come lista di (descrizione, [modelli]); None se il formato non e' valido.

    Formati accettati (``nulla`` = tutti i file):

    * testo nel formato di Qt: ``"Immagini (*.png *.jpg);;Testi (*.txt)"``;
    * testo con le sole estensioni: ``"png, jpg"`` o ``"*.png;*.jpg"``;
    * lista di estensioni: ``["png", "jpg"]``;
    * dizionario descrizione -> estensioni: ``{"Immagini": ["png", "jpg"], "Testi": "txt"}``.
    """
    def modelli(valore: Any) -> list[str] | None:
        if isinstance(valore, str):
            pezzi = [p for p in valore.replace(";", " ").replace(",", " ").split() if p]
        elif isinstance(valore, list) and all(isinstance(p, str) for p in valore):
            pezzi = [p.strip() for p in valore if p.strip()]
        else:
            return None
        risultato = []
        for p in pezzi:
            p = p.strip()
            if not p.startswith("*"):
                p = "*." + p.lstrip(".")
            if any(c in p for c in "\0|()\"<>"):
                return None
            risultato.append(p)
        return risultato or None

    if filtri is None:
        return [("Tutti i file", ["*.*"])]
    if isinstance(filtri, dict):
        voci = []
        for descrizione, valore in filtri.items():
            if not isinstance(descrizione, str) or not descrizione.strip() or "\0" in descrizione:
                return None
            m = modelli(valore)
            if m is None:
                return None
            voci.append((descrizione.strip(), m))
        return voci or None
    if isinstance(filtri, list):
        m = modelli(filtri)
        return [("File " + ", ".join(x[2:] if x.startswith("*.") else x for x in m), m)] if m else None
    if isinstance(filtri, str):
        if not filtri.strip() or "\0" in filtri:
            return None
        if "(" in filtri:
            voci = []
            for parte in filtri.split(";;"):
                parte = parte.strip()
                if not parte:
                    continue
                if "(" not in parte or not parte.endswith(")"):
                    return None
                descrizione, _, resto = parte.partition("(")
                m = modelli(resto[:-1])
                if m is None:
                    return None
                voci.append(((descrizione.strip() or "File"), m))
            return voci or None
        m = modelli(filtri)
        return [("File " + ", ".join(x[2:] if x.startswith("*.") else x for x in m), m)] if m else None
    return None


def filtri_qt(voci: list[tuple[str, list[str]]], windows: bool = True) -> str:
    """Filtri nel formato di ``QFileDialog`` (``*.*`` diventa ``*`` fuori da Windows)."""
    parti = []
    for descrizione, modelli in voci:
        m = [("*" if (x == "*.*" and not windows) else x) for x in modelli]
        parti.append(f"{descrizione} ({' '.join(m)})")
    return ";;".join(parti)


def filtri_windows(voci: list[tuple[str, list[str]]]) -> str:
    """Filtri nel formato di ``GetOpenFileNameW``: "Descrizione\\0*.a;*.b\\0...\\0\\0"."""
    return "".join(f"{d} ({';'.join(m)})\0{';'.join(m)}\0" for d, m in voci) + "\0"


def estensione_predefinita(voci: list[tuple[str, list[str]]]) -> str:
    """L'estensione del primo filtro senza "*." ("" se il primo filtro e' "tutti i file")."""
    if not voci:
        return ""
    primo = voci[0][1][0]
    if primo.startswith("*.") and "*" not in primo[2:] and "?" not in primo[2:]:
        return primo[2:]
    return ""


def leggi_scelta_multipla(testo: str) -> list[str]:
    """Percorsi dal buffer di ``GetOpenFileNameW`` con selezione multipla.

    Un file: "C:\\\\cartella\\\\file.txt\\0\\0"; piu' file: "C:\\\\cartella\\0a.txt\\0b.txt\\0\\0".
    """
    parti = []
    for p in testo.split("\0"):
        if not p:
            break
        parti.append(p)
    if not parti:
        return []
    if len(parti) == 1:
        return parti
    cartella = parti[0]
    return [os.path.join(cartella, nome) for nome in parti[1:]]


# ===========================================================================
# Funzioni pure: notifiche
# ===========================================================================

def _xml(testo: str) -> str:
    return (testo.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
            .replace('"', "&quot;").replace("'", "&apos;"))


#: AppUserModelID di PowerShell: le notifiche appaiono a nome di "Windows PowerShell"
ID_APP_NOTIFICHE = r"{1AC14E77-02E7-4E5D-B744-2EB1AE5198B7}\WindowsPowerShell\v1.0\powershell.exe"


def xml_notifica(titolo: str, testo: str, immagine: str | None = None) -> str:
    """Il contenuto XML di una notifica "toast" di Windows 10/11."""
    parti = [f"<text>{_xml(titolo)}</text>"]
    if testo:
        parti.append(f"<text>{_xml(testo)}</text>")
    if immagine:
        indirizzo = "file:///" + immagine.replace("\\", "/")
        parti.append(f'<image placement="appLogoOverride" src="{_xml(indirizzo)}"/>')
    return f'<toast><visual><binding template="ToastGeneric">{"".join(parti)}</binding></visual></toast>'


def script_notifica(titolo: str, testo: str, immagine: str | None = None) -> str:
    """Script PowerShell (WinRT) che mostra una notifica "toast"."""
    return "\n".join([
        "$ErrorActionPreference = 'Stop'",
        "[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null",
        "[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] > $null",
        "$xml = New-Object Windows.Data.Xml.Dom.XmlDocument",
        f"$xml.LoadXml({_win.letterale_ps(xml_notifica(titolo, testo, immagine))})",
        "$toast = New-Object Windows.UI.Notifications.ToastNotification $xml",
        f"[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier({_win.letterale_ps(ID_APP_NOTIFICHE)}).Show($toast)",
    ])


ICONE_FUMETTO = {"info": ("Information", "Info"), "avviso": ("Warning", "Warning"),
                 "errore": ("Error", "Error"), "nessuna": ("Application", "None")}


def script_fumetto(titolo: str, testo: str, icona: str = "info", secondi: int = 6) -> str:
    """Script PowerShell che mostra il fumetto dell'area di notifica (ripiego per i Windows vecchi)."""
    sistema, fumetto = ICONE_FUMETTO.get(icona, ICONE_FUMETTO["info"])
    return "\n".join([
        "Add-Type -AssemblyName System.Windows.Forms",
        "Add-Type -AssemblyName System.Drawing",
        "$n = New-Object System.Windows.Forms.NotifyIcon",
        f"$n.Icon = [System.Drawing.SystemIcons]::{sistema}",
        f"$n.BalloonTipIcon = '{fumetto}'",
        f"$n.BalloonTipTitle = {_win.letterale_ps(titolo)}",
        f"$n.BalloonTipText = {_win.letterale_ps(testo or ' ')}",
        f"$n.Text = {_win.letterale_ps(titolo[:60])}",
        "$n.Visible = $true",
        f"$n.ShowBalloonTip({int(secondi) * 1000})",
        f"Start-Sleep -Seconds {int(secondi)}",
        "$n.Dispose()",
    ])


# ===========================================================================
# Chiamate native (solo Windows)
# ===========================================================================

class NativoWindows:  # pragma: no cover - richiede Windows
    """Tutte le chiamate vere a Windows. I test usano un finto con gli stessi metodi."""

    def __init__(self) -> None:
        self._pronto = False

    # ------------------------------------------------------------------ base
    def _prepara(self) -> None:
        """Prototipi ctypes (gli HWND sono puntatori: senza prototipi si troncano a 32 bit)."""
        if self._pronto:
            return
        import ctypes
        from ctypes import wintypes as w

        u = _win.dll("user32")
        g = _win.dll("gdi32")
        self.WNDENUMPROC = ctypes.WINFUNCTYPE(w.BOOL, w.HWND, w.LPARAM)
        self.MONITORENUMPROC = ctypes.WINFUNCTYPE(w.BOOL, w.HMONITOR, w.HDC, ctypes.POINTER(w.RECT), w.LPARAM)
        prototipi = {
            "EnumWindows": (w.BOOL, [self.WNDENUMPROC, w.LPARAM]),
            "IsWindow": (w.BOOL, [w.HWND]),
            "IsWindowVisible": (w.BOOL, [w.HWND]),
            "IsIconic": (w.BOOL, [w.HWND]),
            "IsZoomed": (w.BOOL, [w.HWND]),
            "GetWindowTextLengthW": (ctypes.c_int, [w.HWND]),
            "GetWindowTextW": (ctypes.c_int, [w.HWND, w.LPWSTR, ctypes.c_int]),
            "GetClassNameW": (ctypes.c_int, [w.HWND, w.LPWSTR, ctypes.c_int]),
            "GetWindowThreadProcessId": (w.DWORD, [w.HWND, ctypes.POINTER(w.DWORD)]),
            "GetWindowRect": (w.BOOL, [w.HWND, ctypes.POINTER(w.RECT)]),
            "GetWindow": (w.HWND, [w.HWND, w.UINT]),
            "GetForegroundWindow": (w.HWND, []),
            "SetForegroundWindow": (w.BOOL, [w.HWND]),
            "BringWindowToTop": (w.BOOL, [w.HWND]),
            "ShowWindow": (w.BOOL, [w.HWND, ctypes.c_int]),
            "SetWindowPos": (w.BOOL, [w.HWND, w.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int,
                                      ctypes.c_int, w.UINT]),
            "PostMessageW": (w.BOOL, [w.HWND, w.UINT, w.WPARAM, w.LPARAM]),
            "AttachThreadInput": (w.BOOL, [w.DWORD, w.DWORD, w.BOOL]),
            "EnumDisplayMonitors": (w.BOOL, [w.HDC, ctypes.c_void_p, self.MONITORENUMPROC, w.LPARAM]),
            "GetMonitorInfoW": (w.BOOL, [w.HMONITOR, ctypes.c_void_p]),
            "EnumDisplaySettingsW": (w.BOOL, [w.LPCWSTR, w.DWORD, ctypes.c_void_p]),
            "EnumDisplayDevicesW": (w.BOOL, [w.LPCWSTR, w.DWORD, ctypes.c_void_p, w.DWORD]),
            "GetDC": (w.HDC, [w.HWND]),
            "GetWindowDC": (w.HDC, [w.HWND]),
            "ReleaseDC": (ctypes.c_int, [w.HWND, w.HDC]),
            "PrintWindow": (w.BOOL, [w.HWND, w.HDC, w.UINT]),
            "MessageBoxW": (ctypes.c_int, [w.HWND, w.LPCWSTR, w.LPCWSTR, w.UINT]),
            "MessageBeep": (w.BOOL, [w.UINT]),
            "SystemParametersInfoW": (w.BOOL, [w.UINT, w.UINT, ctypes.c_void_p, w.UINT]),
            "GetWindowPlacement": (w.BOOL, [w.HWND, ctypes.c_void_p]),
        }
        for nome, (ritorno, argomenti) in prototipi.items():
            f = getattr(u, nome)
            f.restype, f.argtypes = ritorno, argomenti
        lungo = getattr(u, "GetWindowLongPtrW", None) or u.GetWindowLongW
        lungo.restype, lungo.argtypes = ctypes.c_ssize_t, [w.HWND, ctypes.c_int]
        self._stile_esteso = lambda hwnd: int(lungo(hwnd, -20))  # GWL_EXSTYLE
        for nome, (ritorno, argomenti) in {
            "CreateCompatibleDC": (w.HDC, [w.HDC]),
            "CreateCompatibleBitmap": (w.HBITMAP, [w.HDC, ctypes.c_int, ctypes.c_int]),
            "SelectObject": (w.HGDIOBJ, [w.HDC, w.HGDIOBJ]),
            "BitBlt": (w.BOOL, [w.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, w.HDC,
                                ctypes.c_int, ctypes.c_int, w.DWORD]),
            "GetDIBits": (ctypes.c_int, [w.HDC, w.HBITMAP, w.UINT, w.UINT, ctypes.c_void_p, ctypes.c_void_p,
                                         w.UINT]),
            "DeleteObject": (w.BOOL, [w.HGDIOBJ]),
            "DeleteDC": (w.BOOL, [w.HDC]),
            "GetPixel": (w.DWORD, [w.HDC, ctypes.c_int, ctypes.c_int]),
        }.items():
            f = getattr(g, nome)
            f.restype, f.argtypes = ritorno, argomenti
        # coordinate vere (in pixel fisici) anche con la scala di Windows al 125%/150%
        try:
            u.SetProcessDpiAwarenessContext.restype = w.BOOL
            u.SetProcessDpiAwarenessContext.argtypes = [ctypes.c_void_p]
            if not u.SetProcessDpiAwarenessContext(ctypes.c_void_p(-4)):  # PER_MONITOR_AWARE_V2
                raise OSError
        except (AttributeError, OSError):
            try:
                _win.dll("shcore").SetProcessDpiAwareness(2)
            except (AttributeError, OSError, _win.ErroreSistema):
                try:
                    u.SetProcessDPIAware()
                except (AttributeError, OSError):
                    pass
        self._pronto = True

    def _u(self):
        self._prepara()
        return _win.dll("user32")

    def _g(self):
        self._prepara()
        return _win.dll("gdi32")

    # ------------------------------------------------------------------ finestre
    def _testo(self, hwnd) -> str:
        import ctypes

        u = self._u()
        n = u.GetWindowTextLengthW(hwnd)
        if n <= 0:
            return ""
        buf = ctypes.create_unicode_buffer(n + 2)
        u.GetWindowTextW(hwnd, buf, n + 2)
        return buf.value

    def _classe(self, hwnd) -> str:
        import ctypes

        buf = ctypes.create_unicode_buffer(256)
        self._u().GetClassNameW(hwnd, buf, 256)
        return buf.value

    def _pid(self, hwnd) -> int:
        import ctypes
        from ctypes import wintypes as w

        pid = w.DWORD(0)
        self._u().GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        return int(pid.value)

    def _programma(self, pid: int) -> str:
        import ctypes
        from ctypes import wintypes as w

        k = _win.dll("kernel32")
        k.OpenProcess.restype = w.HANDLE
        k.OpenProcess.argtypes = [w.DWORD, w.BOOL, w.DWORD]
        h = k.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return ""
        try:
            k.QueryFullProcessImageNameW.argtypes = [w.HANDLE, w.DWORD, w.LPWSTR, ctypes.POINTER(w.DWORD)]
            buf = ctypes.create_unicode_buffer(1024)
            n = w.DWORD(1024)
            if k.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n)):
                return os.path.basename(buf.value)
            return ""
        finally:
            k.CloseHandle.argtypes = [w.HANDLE]
            k.CloseHandle(h)

    def _nascosta_dwm(self, hwnd) -> bool:
        """Vero per le finestre "nascoste" da Windows (app sospese, altri desktop virtuali)."""
        import ctypes
        from ctypes import wintypes as w

        try:
            dwm = _win.dll("dwmapi")
        except _win.ErroreSistema:
            return False
        valore = w.DWORD(0)
        dwm.DwmGetWindowAttribute.argtypes = [w.HWND, w.DWORD, ctypes.c_void_p, w.DWORD]
        if dwm.DwmGetWindowAttribute(hwnd, 14, ctypes.byref(valore), 4) != 0:  # DWMWA_CLOAKED
            return False
        return bool(valore.value)

    def _rettangolo(self, hwnd) -> tuple[int, int, int, int]:
        import ctypes
        from ctypes import wintypes as w

        r = w.RECT()
        self._u().GetWindowRect(hwnd, ctypes.byref(r))
        return r.left, r.top, r.right - r.left, r.bottom - r.top

    def _cornice(self, hwnd) -> tuple[int, int, int, int] | None:
        """Il rettangolo visibile (senza i bordi invisibili di Windows 10/11)."""
        import ctypes
        from ctypes import wintypes as w

        try:
            dwm = _win.dll("dwmapi")
        except _win.ErroreSistema:
            return None
        r = w.RECT()
        dwm.DwmGetWindowAttribute.argtypes = [w.HWND, w.DWORD, ctypes.c_void_p, w.DWORD]
        if dwm.DwmGetWindowAttribute(hwnd, 9, ctypes.byref(r), ctypes.sizeof(r)) != 0:  # EXTENDED_FRAME_BOUNDS
            return None
        return r.left, r.top, r.right - r.left, r.bottom - r.top

    def _normale(self, hwnd) -> tuple[int, int, int, int] | None:
        """Posizione "normale" di una finestra minimizzata (GetWindowPlacement)."""
        import ctypes
        from ctypes import wintypes as w

        class WINDOWPLACEMENT(ctypes.Structure):
            _fields_ = [("length", w.UINT), ("flags", w.UINT), ("showCmd", w.UINT), ("ptMinPosition", w.POINT),
                        ("ptMaxPosition", w.POINT), ("rcNormalPosition", w.RECT)]

        p = WINDOWPLACEMENT()
        p.length = ctypes.sizeof(p)
        if not self._u().GetWindowPlacement(hwnd, ctypes.byref(p)):
            return None
        r = p.rcNormalPosition
        return r.left, r.top, r.right - r.left, r.bottom - r.top

    def _grezza(self, hwnd) -> dict | None:
        u = self._u()
        if not hwnd or not u.IsWindow(hwnd):
            return None
        minimizzata = bool(u.IsIconic(hwnd))
        rett = (self._normale(hwnd) if minimizzata else None) or self._cornice(hwnd) or self._rettangolo(hwnd)
        pid = self._pid(hwnd)
        return {
            "id": int(hwnd), "titolo": self._testo(hwnd), "classe": self._classe(hwnd), "pid": pid,
            "programma": self._programma(pid), "x": rett[0], "y": rett[1], "larghezza": rett[2],
            "altezza": rett[3], "minimizzata": minimizzata, "massimizzata": bool(u.IsZoomed(hwnd)),
            "sempre_davanti": bool(self._stile_esteso(hwnd) & 0x8),  # WS_EX_TOPMOST
            "visibile": bool(u.IsWindowVisible(hwnd)),
        }

    def finestre(self) -> list[dict]:
        """Le finestre principali visibili, dalla piu' in alto."""
        u = self._u()
        trovate: list[int] = []

        def ciascuna(hwnd, _lparam):
            try:
                if not u.IsWindowVisible(hwnd) or u.GetWindow(hwnd, 4):  # GW_OWNER: finestre secondarie
                    return True
                stile = self._stile_esteso(hwnd)
                if stile & 0x80 and not stile & 0x40000:  # WS_EX_TOOLWINDOW senza WS_EX_APPWINDOW
                    return True
                if self._nascosta_dwm(hwnd):
                    return True
                trovate.append(int(hwnd))
            except Exception:  # noqa: BLE001 - una finestra che sparisce non ferma l'elenco
                pass
            return True

        richiamo = self.WNDENUMPROC(ciascuna)
        u.EnumWindows(richiamo, 0)
        risultato = []
        for hwnd in trovate:
            g = self._grezza(hwnd)
            if g is not None:
                risultato.append(g)
        return risultato

    def finestra(self, hwnd: int) -> dict | None:
        return self._grezza(hwnd)

    def id_finestra_attiva(self) -> int:
        return int(self._u().GetForegroundWindow() or 0)

    def porta_davanti(self, hwnd: int) -> bool:
        blocca_se_in_prova("porta_in_primo_piano")
        u = self._u()
        k = _win.dll("kernel32")
        if u.IsIconic(hwnd):
            u.ShowWindow(hwnd, SW_RIPRISTINA)
        # regola di Windows: si puo' passare il "primo piano" solo se si condivide
        # l'ingresso con la finestra che ce l'ha ora (niente tasti simulati)
        attuale = u.GetForegroundWindow()
        mio = k.GetCurrentThreadId()
        suo = u.GetWindowThreadProcessId(attuale, None) if attuale else 0
        unito = bool(suo and suo != mio and u.AttachThreadInput(mio, suo, True))
        try:
            u.BringWindowToTop(hwnd)
            ok = bool(u.SetForegroundWindow(hwnd))
        finally:
            if unito:
                u.AttachThreadInput(mio, suo, False)
        return ok or int(u.GetForegroundWindow() or 0) == int(hwnd)

    def mostra(self, hwnd: int, comando: int) -> None:
        blocca_se_in_prova("mostra finestra")
        self._u().ShowWindow(hwnd, comando)

    def bordi_invisibili(self, hwnd: int) -> tuple[int, int, int, int]:
        esterno = self._rettangolo(hwnd)
        cornice = self._cornice(hwnd)
        if cornice is None:
            return 0, 0, 0, 0
        return (max(0, cornice[0] - esterno[0]), max(0, cornice[1] - esterno[1]),
                max(0, (esterno[0] + esterno[2]) - (cornice[0] + cornice[2])),
                max(0, (esterno[1] + esterno[3]) - (cornice[1] + cornice[3])))

    def imposta_rettangolo(self, hwnd: int, x: int | None, y: int | None,
                           larghezza: int | None, altezza: int | None, esterno: bool = False) -> None:
        """Sposta/ridimensiona. Le misure sono della parte visibile (salvo ``esterno``)."""
        blocca_se_in_prova("sposta finestra")
        u = self._u()
        if u.IsIconic(hwnd) or u.IsZoomed(hwnd):
            u.ShowWindow(hwnd, SW_RIPRISTINA)
        bs, bsu, bd, bgi = (0, 0, 0, 0) if esterno else self.bordi_invisibili(hwnd)
        attuale = self._rettangolo(hwnd)
        visibile = attuale if esterno else (self._cornice(hwnd) or attuale)
        vx = visibile[0] if x is None else x
        vy = visibile[1] if y is None else y
        vl = visibile[2] if larghezza is None else larghezza
        va = visibile[3] if altezza is None else altezza
        nx, ny, nl, na = vx - bs, vy - bsu, vl + bs + bd, va + bsu + bgi
        flag = 0x0004 | 0x0010  # SWP_NOZORDER | SWP_NOACTIVATE
        if not u.SetWindowPos(hwnd, None, nx, ny, nl, na, flag):
            raise _win.errore_windows("spostare la finestra")

    def imposta_sempre_davanti(self, hwnd: int, attivo: bool) -> None:
        import ctypes

        blocca_se_in_prova("sempre_in_primo_piano")
        dopo = ctypes.c_void_p(-1 if attivo else -2)  # HWND_TOPMOST / HWND_NOTOPMOST
        if not self._u().SetWindowPos(hwnd, dopo, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0010):
            raise _win.errore_windows("cambiare il primo piano della finestra")

    def invia_chiusura(self, hwnd: int) -> bool:
        blocca_se_in_prova("chiudi_finestra_programma")
        return bool(self._u().PostMessageW(hwnd, 0x0010, 0, 0))  # WM_CLOSE

    # ------------------------------------------------------------------ schermi
    def schermi(self) -> list[dict]:
        import ctypes
        from ctypes import wintypes as w

        u = self._u()

        class MONITORINFOEXW(ctypes.Structure):
            _fields_ = [("cbSize", w.DWORD), ("rcMonitor", w.RECT), ("rcWork", w.RECT), ("dwFlags", w.DWORD),
                        ("szDevice", w.WCHAR * 32)]

        class DISPLAY_DEVICEW(ctypes.Structure):
            _fields_ = [("cb", w.DWORD), ("DeviceName", w.WCHAR * 32), ("DeviceString", w.WCHAR * 128),
                        ("StateFlags", w.DWORD), ("DeviceID", w.WCHAR * 128), ("DeviceKey", w.WCHAR * 128)]

        class DEVMODEW(ctypes.Structure):
            _fields_ = [("dmDeviceName", w.WCHAR * 32), ("dmSpecVersion", w.WORD), ("dmDriverVersion", w.WORD),
                        ("dmSize", w.WORD), ("dmDriverExtra", w.WORD), ("dmFields", w.DWORD),
                        ("dmPositionX", w.LONG), ("dmPositionY", w.LONG), ("dmDisplayOrientation", w.DWORD),
                        ("dmDisplayFixedOutput", w.DWORD), ("dmColor", w.SHORT), ("dmDuplex", w.SHORT),
                        ("dmYResolution", w.SHORT), ("dmTTOption", w.SHORT), ("dmCollate", w.SHORT),
                        ("dmFormName", w.WCHAR * 32), ("dmLogPixels", w.WORD), ("dmBitsPerPel", w.DWORD),
                        ("dmPelsWidth", w.DWORD), ("dmPelsHeight", w.DWORD), ("dmDisplayFlags", w.DWORD),
                        ("dmDisplayFrequency", w.DWORD), ("dmICMMethod", w.DWORD), ("dmICMIntent", w.DWORD),
                        ("dmMediaType", w.DWORD), ("dmDitherType", w.DWORD), ("dmReserved1", w.DWORD),
                        ("dmReserved2", w.DWORD), ("dmPanningWidth", w.DWORD), ("dmPanningHeight", w.DWORD)]

        maniglie: list = []

        def ciascuno(hmon, _hdc, _rett, _lparam):
            maniglie.append(hmon)
            return True

        richiamo = self.MONITORENUMPROC(ciascuno)
        u.EnumDisplayMonitors(None, None, richiamo, 0)
        try:
            shcore = _win.dll("shcore")
            shcore.GetDpiForMonitor.argtypes = [w.HMONITOR, ctypes.c_int, ctypes.POINTER(w.UINT),
                                                ctypes.POINTER(w.UINT)]
        except _win.ErroreSistema:
            shcore = None
        risultato = []
        for hmon in maniglie:
            info = MONITORINFOEXW()
            info.cbSize = ctypes.sizeof(info)
            if not u.GetMonitorInfoW(hmon, ctypes.byref(info)):
                continue
            m, lav = info.rcMonitor, info.rcWork
            dpi = 96
            if shcore is not None:
                dx, dy = w.UINT(96), w.UINT(96)
                if shcore.GetDpiForMonitor(hmon, 0, ctypes.byref(dx), ctypes.byref(dy)) == 0:
                    dpi = int(dx.value)
            modo = DEVMODEW()
            modo.dmSize = ctypes.sizeof(modo)
            frequenza = 0
            if u.EnumDisplaySettingsW(info.szDevice, 0xFFFFFFFF, ctypes.byref(modo)):  # ENUM_CURRENT_SETTINGS
                frequenza = int(modo.dmDisplayFrequency)
            disp = DISPLAY_DEVICEW()
            disp.cb = ctypes.sizeof(disp)
            nome = info.szDevice
            if u.EnumDisplayDevicesW(info.szDevice, 0, ctypes.byref(disp), 0) and disp.DeviceString:
                nome = disp.DeviceString
            risultato.append({
                "dispositivo": info.szDevice, "nome": nome, "principale": bool(info.dwFlags & 1),
                "x": m.left, "y": m.top, "larghezza": m.right - m.left, "altezza": m.bottom - m.top,
                "lavoro": (lav.left, lav.top, lav.right - lav.left, lav.bottom - lav.top),
                "dpi": dpi, "frequenza": frequenza,
            })
        return risultato

    # ------------------------------------------------------------------ cattura
    def _bitmap_rgb(self, hdc_mem, hbmp, larghezza: int, altezza: int) -> bytes:
        import ctypes
        from ctypes import wintypes as w

        class BITMAPINFOHEADER(ctypes.Structure):
            _fields_ = [("biSize", w.DWORD), ("biWidth", w.LONG), ("biHeight", w.LONG), ("biPlanes", w.WORD),
                        ("biBitCount", w.WORD), ("biCompression", w.DWORD), ("biSizeImage", w.DWORD),
                        ("biXPelsPerMeter", w.LONG), ("biYPelsPerMeter", w.LONG), ("biClrUsed", w.DWORD),
                        ("biClrImportant", w.DWORD)]

        bih = BITMAPINFOHEADER()
        bih.biSize = ctypes.sizeof(bih)
        bih.biWidth = larghezza
        bih.biHeight = -altezza  # dall'alto in basso
        bih.biPlanes = 1
        bih.biBitCount = 32
        buf = ctypes.create_string_buffer(larghezza * altezza * 4)
        if not self._g().GetDIBits(hdc_mem, hbmp, 0, altezza, buf, ctypes.byref(bih), 0):  # DIB_RGB_COLORS
            raise _win.errore_windows("leggere i pixel dello schermo")
        return bgra_a_rgb(buf.raw, larghezza, altezza)

    def cattura(self, x: int, y: int, larghezza: int, altezza: int) -> bytes:
        """Pixel RGB della zona dello schermo (coordinate del desktop virtuale)."""
        try:
            from PIL import ImageGrab  # facoltativo

            im = ImageGrab.grab(bbox=(x, y, x + larghezza, y + altezza), all_screens=True)
            if im.size == (larghezza, altezza):
                return im.convert("RGB").tobytes()
        except (ImportError, OSError, TypeError, ValueError):
            pass
        u, g = self._u(), self._g()
        schermo = u.GetDC(None)
        mem = g.CreateCompatibleDC(schermo)
        bmp = g.CreateCompatibleBitmap(schermo, larghezza, altezza)
        vecchio = g.SelectObject(mem, bmp)
        try:
            if not g.BitBlt(mem, 0, 0, larghezza, altezza, schermo, x, y, 0x00CC0020 | 0x40000000):
                raise _win.errore_windows("catturare lo schermo")  # SRCCOPY | CAPTUREBLT
            return self._bitmap_rgb(mem, bmp, larghezza, altezza)
        finally:
            g.SelectObject(mem, vecchio)
            g.DeleteObject(bmp)
            g.DeleteDC(mem)
            u.ReleaseDC(None, schermo)

    def cattura_finestra(self, hwnd: int) -> tuple[int, int, bytes] | None:
        """(larghezza, altezza, RGB) della finestra con ``PrintWindow`` (anche se e' coperta); None se non va."""
        u, g = self._u(), self._g()
        ex, ey, el, ea = self._rettangolo(hwnd)
        if el <= 0 or ea <= 0:
            return None
        dc = u.GetWindowDC(hwnd)
        mem = g.CreateCompatibleDC(dc)
        bmp = g.CreateCompatibleBitmap(dc, el, ea)
        vecchio = g.SelectObject(mem, bmp)
        try:
            if not u.PrintWindow(hwnd, mem, 2):  # PW_RENDERFULLCONTENT
                return None
            rgb = self._bitmap_rgb(mem, bmp, el, ea)
        finally:
            g.SelectObject(mem, vecchio)
            g.DeleteObject(bmp)
            g.DeleteDC(mem)
            u.ReleaseDC(hwnd, dc)
        cornice = self._cornice(hwnd)
        if cornice is None:
            return el, ea, rgb
        cx, cy, cl, ca = cornice[0] - ex, cornice[1] - ey, cornice[2], cornice[3]
        return cl, ca, ritaglia_rgb(rgb, el, ea, cx, cy, cl, ca)

    def colore_pixel(self, x: int, y: int) -> tuple[int, int, int] | None:
        u, g = self._u(), self._g()
        dc = u.GetDC(None)
        try:
            valore = g.GetPixel(dc, x, y)
        finally:
            u.ReleaseDC(None, dc)
        if valore == 0xFFFFFFFF:  # CLR_INVALID: punto fuori dagli schermi
            return None
        return da_colorref(valore)

    # ------------------------------------------------------------------ notifiche e PowerShell
    def powershell(self, script: str, tempo_massimo: float = 20) -> tuple[str, str, int]:
        blocca_se_in_prova("notifica")
        return _win.esegui_powershell(script, tempo_massimo)

    def avvia_powershell(self, script: str) -> None:
        """PowerShell nascosto in sottofondo (il programma Leo non aspetta)."""
        blocca_se_in_prova("notifica")
        try:
            subprocess.Popen(_win.comando_powershell(script), stdin=subprocess.DEVNULL,
                             stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, close_fds=True,
                             creationflags=_win.SENZA_FINESTRA)
        except OSError as e:
            raise _win.ErroreSistema("PowerShell non parte: non riesco a mostrare la notifica.",
                                     suggerimento=str(e)) from None

    # ------------------------------------------------------------------ dialoghi
    def _proprietario(self):
        try:
            k = _win.dll("kernel32")
            from ctypes import wintypes as w

            k.GetConsoleWindow.restype = w.HWND
            return k.GetConsoleWindow()
        except (AttributeError, OSError, _win.ErroreSistema):
            return None

    def messaggio(self, testo: str, titolo: str, stile: int) -> int:
        return int(self._u().MessageBoxW(None, testo, titolo, stile | MB_IN_PRIMO_PIANO))

    def _buffer(self, testo: str):
        import ctypes

        return (ctypes.c_wchar * (len(testo) + 1))(*testo)

    def _dialogo_file(self, salva: bool, titolo: str, filtro: str, cartella: str | None, nome: str,
                      estensione: str, multipli: bool) -> list[str] | None:
        import ctypes
        from ctypes import wintypes as w

        class OPENFILENAMEW(ctypes.Structure):
            _fields_ = [("lStructSize", w.DWORD), ("hwndOwner", w.HWND), ("hInstance", w.HINSTANCE),
                        ("lpstrFilter", ctypes.c_void_p), ("lpstrCustomFilter", ctypes.c_void_p),
                        ("nMaxCustFilter", w.DWORD), ("nFilterIndex", w.DWORD), ("lpstrFile", ctypes.c_void_p),
                        ("nMaxFile", w.DWORD), ("lpstrFileTitle", ctypes.c_void_p), ("nMaxFileTitle", w.DWORD),
                        ("lpstrInitialDir", ctypes.c_void_p), ("lpstrTitle", ctypes.c_void_p),
                        ("Flags", w.DWORD), ("nFileOffset", w.WORD), ("nFileExtension", w.WORD),
                        ("lpstrDefExt", ctypes.c_void_p), ("lCustData", w.LPARAM), ("lpfnHook", ctypes.c_void_p),
                        ("lpTemplateName", ctypes.c_void_p), ("pvReserved", ctypes.c_void_p),
                        ("dwReserved", w.DWORD), ("FlagsEx", w.DWORD)]

        comdlg = _win.dll("comdlg32")
        dimensione = 65536
        file_buf = ctypes.create_unicode_buffer(nome, dimensione) if nome else ctypes.create_unicode_buffer(dimensione)
        tieni = [self._buffer(filtro), self._buffer(titolo)]
        ofn = OPENFILENAMEW()
        ofn.lStructSize = ctypes.sizeof(ofn)
        ofn.hwndOwner = self._proprietario()
        ofn.lpstrFilter = ctypes.addressof(tieni[0])
        ofn.nFilterIndex = 1
        ofn.lpstrFile = ctypes.addressof(file_buf)
        ofn.nMaxFile = dimensione
        ofn.lpstrTitle = ctypes.addressof(tieni[1])
        if cartella:
            tieni.append(self._buffer(cartella))
            ofn.lpstrInitialDir = ctypes.addressof(tieni[-1])
        if estensione:
            tieni.append(self._buffer(estensione))
            ofn.lpstrDefExt = ctypes.addressof(tieni[-1])
        flag = 0x0008 | 0x0800 | 0x0004  # NOCHANGEDIR | PATHMUSTEXIST | HIDEREADONLY
        if salva:
            flag |= 0x0002  # OVERWRITEPROMPT
            funzione = comdlg.GetSaveFileNameW
        else:
            flag |= 0x1000 | 0x80000  # FILEMUSTEXIST | EXPLORER
            if multipli:
                flag |= 0x0200  # ALLOWMULTISELECT
            funzione = comdlg.GetOpenFileNameW
        ofn.Flags = flag
        funzione.argtypes = [ctypes.c_void_p]
        if not funzione(ctypes.byref(ofn)):
            codice = comdlg.CommDlgExtendedError()
            if codice == 0:
                return None  # annullato dall'utente
            raise _win.ErroreSistema(f"La finestra per scegliere il file non si è aperta (codice {codice:#x}).")
        grezzo = ctypes.wstring_at(ctypes.addressof(file_buf), dimensione)
        return leggi_scelta_multipla(grezzo) if multipli else [file_buf.value]

    def apri_file(self, titolo: str, filtro: str, cartella: str | None, multipli: bool) -> list[str] | None:
        return self._dialogo_file(False, titolo, filtro, cartella, "", "", multipli)

    def salva_file(self, titolo: str, filtro: str, cartella: str | None, nome: str,
                   estensione: str) -> str | None:
        scelti = self._dialogo_file(True, titolo, filtro, cartella, nome, estensione, False)
        return scelti[0] if scelti else None

    def scegli_cartella(self, titolo: str, cartella: str | None) -> str | None:
        import ctypes
        from ctypes import wintypes as w

        BFFCALLBACK = ctypes.WINFUNCTYPE(ctypes.c_int, w.HWND, w.UINT, w.LPARAM, w.LPARAM)

        class BROWSEINFOW(ctypes.Structure):
            _fields_ = [("hwndOwner", w.HWND), ("pidlRoot", ctypes.c_void_p), ("pszDisplayName", ctypes.c_void_p),
                        ("lpszTitle", ctypes.c_void_p), ("ulFlags", w.UINT), ("lpfn", BFFCALLBACK),
                        ("lParam", w.LPARAM), ("iImage", ctypes.c_int)]

        shell = _win.dll("shell32")
        ole = _win.dll("ole32")
        ole.OleInitialize(None)
        nome = ctypes.create_unicode_buffer(260)
        titolo_buf = self._buffer(titolo)
        iniziale = self._buffer(cartella) if cartella else None
        u = self._u()
        u.SendMessageW.argtypes = [w.HWND, w.UINT, w.WPARAM, w.LPARAM]

        def richiamo(hwnd, messaggio, _lparam, _dati):
            if messaggio == 1 and iniziale is not None:  # BFFM_INITIALIZED -> BFFM_SETSELECTIONW
                u.SendMessageW(hwnd, 0x0467, 1, ctypes.addressof(iniziale))
            return 0

        info = BROWSEINFOW()
        info.hwndOwner = self._proprietario()
        info.pszDisplayName = ctypes.addressof(nome)
        info.lpszTitle = ctypes.addressof(titolo_buf)
        info.ulFlags = 0x0001 | 0x0010 | 0x0040  # RETURNONLYFSDIRS | EDITBOX | NEWDIALOGSTYLE
        info.lpfn = BFFCALLBACK(richiamo)
        shell.SHBrowseForFolderW.restype = ctypes.c_void_p
        shell.SHBrowseForFolderW.argtypes = [ctypes.c_void_p]
        pidl = shell.SHBrowseForFolderW(ctypes.byref(info))
        if not pidl:
            return None
        try:
            percorso = ctypes.create_unicode_buffer(1024)
            shell.SHGetPathFromIDListW.argtypes = [ctypes.c_void_p, w.LPWSTR]
            if not shell.SHGetPathFromIDListW(ctypes.c_void_p(pidl), percorso):
                return None  # una "cartella" che non e' sul disco (es. Pannello di controllo)
            return percorso.value
        finally:
            ole.CoTaskMemFree.argtypes = [ctypes.c_void_p]
            ole.CoTaskMemFree(ctypes.c_void_p(pidl))

    def scegli_colore(self, iniziale: tuple[int, int, int]) -> tuple[int, int, int] | None:
        import ctypes
        from ctypes import wintypes as w

        class CHOOSECOLORW(ctypes.Structure):
            _fields_ = [("lStructSize", w.DWORD), ("hwndOwner", w.HWND), ("hInstance", w.HWND),
                        ("rgbResult", w.DWORD), ("lpCustColors", ctypes.POINTER(w.DWORD)), ("Flags", w.DWORD),
                        ("lCustData", w.LPARAM), ("lpfnHook", ctypes.c_void_p), ("lpTemplateName", ctypes.c_void_p)]

        personalizzati = (w.DWORD * 16)(*([0xFFFFFF] * 16))
        cc = CHOOSECOLORW()
        cc.lStructSize = ctypes.sizeof(cc)
        cc.hwndOwner = self._proprietario()
        cc.rgbResult = a_colorref(*iniziale)
        cc.lpCustColors = personalizzati
        cc.Flags = 0x1 | 0x2  # CC_RGBINIT | CC_FULLOPEN
        comdlg = _win.dll("comdlg32")
        comdlg.ChooseColorW.argtypes = [ctypes.c_void_p]
        if not comdlg.ChooseColorW(ctypes.byref(cc)):
            return None
        return da_colorref(cc.rgbResult)

    # ------------------------------------------------------------------ sfondo, tema, suoni
    def leggi_sfondo(self) -> str:
        import ctypes

        buf = ctypes.create_unicode_buffer(1024)
        if not self._u().SystemParametersInfoW(0x0073, 1024, buf, 0):  # SPI_GETDESKWALLPAPER
            raise _win.errore_windows("leggere lo sfondo del desktop")
        return buf.value

    def imposta_sfondo(self, percorso: str, stile: tuple[str, str] | None) -> None:
        import ctypes
        import winreg

        blocca_se_in_prova("imposta_sfondo_desktop")
        if stile is not None:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Control Panel\Desktop", 0, winreg.KEY_SET_VALUE) as k:
                winreg.SetValueEx(k, "WallpaperStyle", 0, winreg.REG_SZ, stile[0])
                winreg.SetValueEx(k, "TileWallpaper", 0, winreg.REG_SZ, stile[1])
        buf = ctypes.create_unicode_buffer(percorso)
        if not self._u().SystemParametersInfoW(0x0014, 0, buf, 0x01 | 0x02):  # SPI_SETDESKWALLPAPER
            raise _win.errore_windows("cambiare lo sfondo del desktop",
                                      suggerimento="Usa un'immagine JPG, PNG o BMP che esiste.")

    def valore_utente(self, chiave: str, nome: str) -> Any:
        """Un valore di HKEY_CURRENT_USER (solo lettura); None se non c'e'."""
        import winreg

        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, chiave) as k:
                return winreg.QueryValueEx(k, nome)[0]
        except OSError:
            return None

    def suono(self, codice: int | str) -> None:
        import ctypes
        from ctypes import wintypes as w

        blocca_se_in_prova("suono_di_sistema")
        if isinstance(codice, str):
            winmm = _win.dll("winmm")
            winmm.PlaySoundW.argtypes = [w.LPCWSTR, w.HMODULE, w.DWORD]
            if winmm.PlaySoundW(codice, None, 0x00010000 | 0x0001 | 0x0002):  # SND_ALIAS|ASYNC|NODEFAULT
                return
            codice = 0x40
        self._u().MessageBeep(ctypes.c_uint(codice).value)


#: backend in uso (i test lo sostituiscono con un finto)
nativo: Any = NativoWindows()
