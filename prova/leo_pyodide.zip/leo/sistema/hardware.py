"""Hardware e impostazioni di Windows per la libreria di Leo (parte S3).

Qui c'e' il "motore" delle funzioni registrate in ``leo/libreria/computer.py``:
batteria, alimentazione, audio, luminosita', prestazioni, dischi, rete,
stampanti, registro di Windows, servizi, utente, orologio, caratteri,
informazioni sull'hardware e dispositivi USB.

Organizzazione (per poterlo provare anche su Linux):

* le **funzioni pure** (conversioni, lettura dell'uscita di ``netsh``, dei
  risultati JSON di PowerShell, dei percorsi del registro, riepilogo del ping,
  calcolo dell'uso della CPU...) non toccano il sistema e si provano ovunque;
* le **chiamate native** stanno tutte nella classe :class:`NativoWindows`
  (ctypes, ``winreg``, ``subprocess`` con PowerShell senza finestra). Il modulo
  usa l'istanza :data:`nativo`, che i test sostituiscono con un finto;
* le **funzioni pubbliche** (``info_batteria``, ``elenca_unita``, ...)
  uniscono le due cose e restituiscono valori Leo (dizionari, liste, testi,
  numeri).

Sicurezza:

* niente viene fatto su un sistema diverso da Windows: :func:`richiedi_windows`
  da' un errore chiaro "funziona solo su Windows";
* il registro si scrive e si cancella solo in ``HKEY_CURRENT_USER`` e mai
  nelle chiavi usate per aggirare la sicurezza (criteri di gruppo, avvio
  automatico, associazioni dei file, ``Winlogon``...): vedi
  :data:`CHIAVI_PROTETTE`;
* mentre girano i test automatici (``unittest`` caricato) le azioni vere che
  cambiano lo stato del computer (spegnere, bloccare, volume, registro,
  stampa...) sono bloccate, cosi' la suite non spegne mai il PC di chi la
  esegue. Per provarle davvero: variabile d'ambiente
  ``LEO_SISTEMA_AZIONI_VERE=1``.
* la conferma all'utente del programma la chiede ``leo/libreria/computer.py``
  prima di chiamare le azioni pericolose di questo modulo.
"""

from __future__ import annotations

import base64
import datetime
import getpass
import json
import os
import re
import socket
import struct
import subprocess
import sys
import tempfile
import time
import uuid
from typing import Any

from ..errori import ErroreChiave, ErroreFile, ErroreValore
from . import _win

CREATE_NO_WINDOW = 0x08000000
CREATE_NEW_PROCESS_GROUP = 0x00000200

#: ritardo massimo per le azioni programmate (31 giorni, in secondi)
RITARDO_MASSIMO = 31 * 24 * 3600

#: file (nella cartella temporanea) con le azioni di alimentazione programmate
NOME_FILE_PROGRAMMATE = "leo_azioni_programmate.json"


# ===========================================================================
# Controlli comuni
# ===========================================================================

def e_windows() -> bool:
    """``True`` se il programma gira su Windows (i test fingono con ``_win.SOSTITUTI["windows"]``)."""
    return _win.e_windows()


def richiedi_windows(nome_funzione: str) -> None:
    """Errore chiaro "funziona solo su Windows" (aiuto comune di ``leo.sistema._win``)."""
    _win.solo_windows(nome_funzione)


def in_prova() -> bool:
    """``True`` mentre girano i test automatici (le azioni vere sono bloccate)."""
    return "unittest" in sys.modules and os.environ.get("LEO_SISTEMA_AZIONI_VERE") != "1"


def blocca_se_in_prova(azione: str) -> None:
    if in_prova():
        raise ErroreValore(f"Azione `{azione}` bloccata: sono in corso i test automatici.",
                           suggerimento="Per eseguirla davvero durante i test imposta "
                                        "la variabile d'ambiente LEO_SISTEMA_AZIONI_VERE=1.")


# ===========================================================================
# Funzioni pure (si provano su qualunque sistema)
# ===========================================================================

def script_powershell(script: str) -> list[str]:
    """Riga di comando per eseguire ``script`` con PowerShell, senza profilo e senza finestra.

    Lo script passa codificato (``-EncodedCommand``): nessun problema di
    virgolette; l'uscita e' in UTF-8.
    """
    completo = ("$ProgressPreference = 'SilentlyContinue'; $ErrorActionPreference = 'Stop'; "
                "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8; " + script)
    codificato = base64.b64encode(completo.encode("utf-16-le")).decode("ascii")
    return ["powershell.exe", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden",
            "-EncodedCommand", codificato]


def testo_powershell(valore: str) -> str:
    """Testo racchiuso tra apici singoli per PowerShell (gli apici interni raddoppiati)."""
    return "'" + str(valore).replace("'", "''").replace("\u2019", "\u2019\u2019") + "'"


def lista_da_json(testo: str) -> list[dict]:
    """Uscita JSON di PowerShell -> lista di dizionari (un oggetto solo diventa lista di uno)."""
    testo = (testo or "").strip().lstrip("\ufeff")
    if not testo:
        return []
    try:
        dati = json.loads(testo)
    except ValueError:
        raise ErroreValore("Windows ha risposto in un modo che non riesco a leggere.",
                           suggerimento="Riprova; se succede ancora, controlla che PowerShell funzioni.") from None
    if dati is None:
        return []
    if isinstance(dati, dict):
        return [dati]
    if isinstance(dati, list):
        return [d for d in dati if isinstance(d, dict)]
    return []


def comando_json(espressione: str) -> str:
    """Script PowerShell che stampa ``espressione`` come JSON compatto (sempre una lista)."""
    return f"ConvertTo-Json -Compress -Depth 3 -InputObject @({espressione})"


def _intero(valore: Any, predefinito: int | None = None) -> int | None:
    if isinstance(valore, bool):
        return int(valore)
    if isinstance(valore, int):
        return valore
    if isinstance(valore, float) and valore == valore and abs(valore) != float("inf"):
        return int(valore)
    if isinstance(valore, str):
        try:
            return int(valore.strip())
        except ValueError:
            return predefinito
    return predefinito


def _testo(valore: Any) -> str:
    if valore is None:
        return ""
    return str(valore).strip()


# --- batteria --------------------------------------------------------------

def stato_batteria(corrente: int, bandiere: int, percentuale: int, secondi: int, risparmio: int) -> dict:
    """Dizionario Leo dai campi di ``SYSTEM_POWER_STATUS``.

    ``corrente``: 0 a batteria, 1 alla corrente, 255 sconosciuto; ``bandiere``:
    8 in carica, 128 nessuna batteria, 255 sconosciuto; ``percentuale``: 0-100
    o 255; ``secondi``: tempo rimasto o 0xFFFFFFFF/-1 se sconosciuto;
    ``risparmio``: 1 se il risparmio energetico e' attivo.
    """
    presente = bandiere != 255 and not (bandiere & 128)
    if bandiere == 255 and percentuale != 255:
        presente = True  # alcuni portatili non riempiono le bandiere
    perc = percentuale if presente and 0 <= percentuale <= 100 else None
    alla_corrente = corrente == 1
    in_carica = bool(presente and bandiere != 255 and bandiere & 8)
    minuti = None
    if presente and not alla_corrente and 0 <= secondi < 0xFFFFFFFF:
        minuti = secondi // 60
    return {
        "presente": presente,
        "percentuale": perc,
        "in_carica": in_carica,
        "alla_corrente": alla_corrente,
        "minuti_rimasti": minuti,
        "risparmio_energetico": risparmio == 1,
    }


# --- prestazioni -----------------------------------------------------------

def percentuale_cpu(prima: tuple[int, int, int], dopo: tuple[int, int, int]) -> float:
    """Uso della CPU (0-100) da due letture di ``GetSystemTimes`` (inattivo, kernel, utente).

    Il tempo "kernel" comprende anche quello inattivo.
    """
    inattivo = dopo[0] - prima[0]
    totale = (dopo[1] - prima[1]) + (dopo[2] - prima[2])
    if totale <= 0:
        return 0.0
    uso = (totale - inattivo) * 100.0 / totale
    return round(min(100.0, max(0.0, uso)), 1)


def stato_memoria(totale: int, libera: int) -> dict:
    """Dizionario sulla memoria (byte) a partire da totale e libera."""
    totale = max(0, int(totale))
    libera = max(0, min(int(libera), totale))
    usata = totale - libera
    return {
        "totale": totale,
        "libera": libera,
        "usata": usata,
        "percentuale_usata": round(usata * 100.0 / totale, 1) if totale else 0.0,
    }


# --- dischi ----------------------------------------------------------------

TIPI_UNITA = {
    0: "sconosciuto", 1: "non valido", 2: "rimovibile", 3: "disco fisso",
    4: "rete", 5: "CD/DVD", 6: "disco in memoria",
}


def tipo_unita(numero: int) -> str:
    return TIPI_UNITA.get(numero, "sconosciuto")


def normalizza_unita(unita: str) -> str:
    """``"c"``, ``"C:"``, ``"C:\\\\"``, ``"c:/"`` -> ``"C:"``; errore se non e' una lettera di unita'."""
    u = str(unita).strip().replace("/", "\\").rstrip("\\")
    if u.endswith(":"):
        u = u[:-1]
    if len(u) == 1 and "A" <= u.upper() <= "Z":
        return u.upper() + ":"
    raise ErroreValore(f"`{unita}` non è una lettera di unità.",
                       suggerimento="Scrivi per esempio \"C:\" oppure \"D:\"; "
                                    "per vedere tutte le unità usa `elenca_unita()`.")


def dati_unita(unita: str, tipo: int, etichetta: str | None, file_system: str | None,
               totale: int | None, libero: int | None) -> dict:
    pronta = totale is not None and libero is not None
    return {
        "unita": unita,
        "tipo": tipo_unita(tipo),
        "etichetta": etichetta or "",
        "file_system": file_system or "",
        "pronta": pronta,
        "totale": int(totale) if pronta else 0,
        "libero": int(libero) if pronta else 0,
        "usato": int(totale) - int(libero) if pronta else 0,
    }


# --- rete ------------------------------------------------------------------

_CHIAVI_CANALE = {"channel", "canale", "canal", "kanal"}
_CHIAVI_AUTENTICAZIONE = {"authentication", "autenticazione", "authentification", "authentifizierung"}


def analizza_wifi(uscita: str) -> dict | None:
    """Uscita di ``netsh wlan show interfaces`` -> ``{nome, segnale, bssid, canale, autenticazione, scheda}``.

    Funziona in qualunque lingua di Windows: ``SSID`` e ``BSSID`` non si
    traducono e il segnale e' l'unico valore della forma ``80%``.
    ``None`` se nessuna scheda Wi-Fi e' connessa.
    """
    blocchi: list[dict[str, str]] = []
    corrente: dict[str, str] = {}
    for riga in (uscita or "").splitlines():
        if ":" not in riga:
            continue
        chiave, _, valore = riga.partition(":")
        chiave = chiave.strip()
        valore = valore.strip()
        if not chiave:
            continue
        chiave_min = chiave.lower()
        # una nuova scheda comincia con il suo nome (prima riga del blocco)
        if chiave_min in ("name", "nome", "nom") and corrente:
            blocchi.append(corrente)
            corrente = {}
        corrente.setdefault(chiave_min, valore)  # "BSSID : aa:bb:..." resta intero (divide al primo ":")
    if corrente:
        blocchi.append(corrente)
    for blocco in blocchi:
        ssid = blocco.get("ssid")
        if not ssid:
            continue
        segnale = None
        for valore in blocco.values():
            m = re.fullmatch(r"(\d{1,3})\s*%", valore)
            if m:
                segnale = min(100, int(m.group(1)))
                break
        bssid = blocco.get("bssid") or blocco.get("ap bssid") or ""
        canale = next((_intero(v) for k, v in blocco.items() if k in _CHIAVI_CANALE), None)
        autenticazione = next((v for k, v in blocco.items() if k in _CHIAVI_AUTENTICAZIONE), "")
        scheda = blocco.get("name") or blocco.get("nome") or blocco.get("nom") or ""
        return {"nome": ssid, "segnale": segnale, "bssid": bssid, "canale": canale,
                "autenticazione": autenticazione, "scheda": scheda}
    return None


def riepilogo_ping(indirizzo: str, ip: str, tempi: list[int | None]) -> dict:
    """Dizionario Leo con il risultato del ping; ``None`` nei tempi = risposta persa."""
    buoni = [t for t in tempi if t is not None]
    inviati = len(tempi)
    ricevuti = len(buoni)
    return {
        "indirizzo": indirizzo,
        "ip": ip,
        "raggiungibile": ricevuti > 0,
        "inviati": inviati,
        "ricevuti": ricevuti,
        "persi": inviati - ricevuti,
        "percentuale_persi": round((inviati - ricevuti) * 100.0 / inviati, 1) if inviati else 0.0,
        "tempi": buoni,
        "minimo": min(buoni) if buoni else None,
        "massimo": max(buoni) if buoni else None,
        "medio": round(sum(buoni) / ricevuti, 1) if buoni else None,
    }


# --- servizi ---------------------------------------------------------------

STATI_SERVIZIO = {
    "running": "in esecuzione", "stopped": "fermo", "paused": "in pausa",
    "startpending": "in avvio", "stoppending": "in arresto",
    "pausepending": "in pausa (in corso)", "continuepending": "in ripresa",
}
AVVII_SERVIZIO = {
    "automatic": "automatico", "manual": "manuale", "disabled": "disattivato",
    "boot": "avvio di sistema", "system": "sistema",
}
#: gli stessi valori in forma numerica (vecchie versioni di PowerShell)
_STATI_NUMERICI = {1: "stopped", 2: "startpending", 3: "stoppending", 4: "running",
                   5: "continuepending", 6: "pausepending", 7: "paused"}
_AVVII_NUMERICI = {0: "boot", 1: "system", 2: "automatic", 3: "manual", 4: "disabled"}


def stato_servizio_italiano(stato: Any) -> str:
    if isinstance(stato, int) and not isinstance(stato, bool):
        stato = _STATI_NUMERICI.get(stato, "")
    return STATI_SERVIZIO.get(_testo(stato).lower(), _testo(stato).lower() or "sconosciuto")


def avvio_servizio_italiano(avvio: Any) -> str:
    if isinstance(avvio, int) and not isinstance(avvio, bool):
        avvio = _AVVII_NUMERICI.get(avvio, "")
    return AVVII_SERVIZIO.get(_testo(avvio).lower(), _testo(avvio).lower() or "sconosciuto")


def servizio_da_json(d: dict) -> dict:
    return {
        "nome": _testo(d.get("n")),
        "nome_visualizzato": _testo(d.get("d")),
        "stato": stato_servizio_italiano(d.get("s")),
        "avvio": avvio_servizio_italiano(d.get("a")),
    }


_NOME_SERVIZIO = re.compile(r"^[\w .\-$@{}#]{1,256}$")


def controlla_nome_servizio(nome: str) -> str:
    """Il nome di un servizio (senza caratteri jolly di PowerShell)."""
    nome = str(nome).strip()
    if not nome or not _NOME_SERVIZIO.match(nome):
        raise ErroreValore(f"`{nome}` non è un nome di servizio valido.",
                           suggerimento="Usa il nome breve del servizio, per esempio \"Spooler\" o \"wuauserv\"; "
                                        "l'elenco completo lo dà `elenca_servizi()`.")
    return nome


# --- caratteri -------------------------------------------------------------

_TIPO_CARATTERE = re.compile(r"\s*\((TrueType|OpenType|Type 1|VGA res|All res|[^()]*res[^()]*)\)\s*$",
                             re.IGNORECASE)


def nome_carattere(voce: str) -> list[str]:
    """``"Arial Bold (TrueType)"`` -> ``["Arial Bold"]``; ``"Cambria & Cambria Math (TrueType)"`` -> due nomi."""
    nome = _TIPO_CARATTERE.sub("", str(voce)).strip()
    if not nome:
        return []
    return [p.strip() for p in nome.split(" & ") if p.strip()]


# --- registro di Windows -----------------------------------------------------

REG_NONE, REG_SZ, REG_EXPAND_SZ, REG_BINARY, REG_DWORD = 0, 1, 2, 3, 4
REG_MULTI_SZ, REG_QWORD = 7, 11

RADICI_REGISTRO = {
    "HKCU": "HKEY_CURRENT_USER", "HKEY_CURRENT_USER": "HKEY_CURRENT_USER",
    "HKLM": "HKEY_LOCAL_MACHINE", "HKEY_LOCAL_MACHINE": "HKEY_LOCAL_MACHINE",
    "HKCR": "HKEY_CLASSES_ROOT", "HKEY_CLASSES_ROOT": "HKEY_CLASSES_ROOT",
    "HKU": "HKEY_USERS", "HKEY_USERS": "HKEY_USERS",
    "HKCC": "HKEY_CURRENT_CONFIG", "HKEY_CURRENT_CONFIG": "HKEY_CURRENT_CONFIG",
}

#: chiavi di HKCU che non si scrivono ne' si cancellano mai: servono ad
#: aggirare la sicurezza o a far partire programmi di nascosto
CHIAVI_PROTETTE = (
    "software\\policies",
    "software\\microsoft\\windows\\currentversion\\policies",
    "software\\microsoft\\windows\\currentversion\\run",
    "software\\microsoft\\windows\\currentversion\\runonce",
    "software\\microsoft\\windows\\currentversion\\runonceex",
    "software\\microsoft\\windows nt\\currentversion\\winlogon",
    "software\\microsoft\\windows nt\\currentversion\\windows",
    "software\\microsoft\\windows nt\\currentversion\\image file execution options",
    "software\\microsoft\\command processor",
    "software\\classes",
    "environment",
)


def dividi_chiave(chiave: str) -> tuple[str, str]:
    """``"HKCU\\\\Software\\\\Leo"`` (o con ``/``) -> ``("HKEY_CURRENT_USER", "Software\\\\Leo")``."""
    testo = str(chiave).strip().replace("/", "\\")
    while "\\\\" in testo:
        testo = testo.replace("\\\\", "\\")
    testo = testo.strip("\\")
    radice, _, resto = testo.partition("\\")
    nome_radice = RADICI_REGISTRO.get(radice.upper().rstrip(":"))
    if nome_radice is None:
        raise ErroreValore(f"`{chiave}` non comincia con una radice del registro.",
                           suggerimento="Comincia con HKCU (utente), HKLM (computer), HKCR, HKU o HKCC, "
                                        "per esempio \"HKCU/Software/MioProgramma\".")
    return nome_radice, resto


def controlla_scrittura(chiave: str) -> tuple[str, str]:
    """Radice e percorso di una chiave che si puo' modificare (solo HKCU, niente chiavi protette)."""
    radice, sotto = dividi_chiave(chiave)
    if radice != "HKEY_CURRENT_USER":
        raise ErroreValore(f"Posso modificare il registro solo in HKCU, non in `{radice}`.",
                           suggerimento="Scrivi le impostazioni del tuo programma in "
                                        "\"HKCU/Software/NomeDelProgramma\": riguardano solo il tuo utente.")
    if not sotto:
        raise ErroreValore("Non si modifica la radice HKCU del registro.",
                           suggerimento="Usa una chiave tua, per esempio \"HKCU/Software/NomeDelProgramma\".")
    minuscolo = sotto.lower()
    for protetta in CHIAVI_PROTETTE:
        if minuscolo == protetta or minuscolo.startswith(protetta + "\\"):
            if "\\run" in protetta:
                suggerimento = ("Per far partire un programma all'accensione usa `aggiungi_all_avvio(...)`, "
                                "che chiede conferma all'utente.")
            else:
                suggerimento = ("Queste chiavi controllano la sicurezza e l'avvio dei programmi di Windows; "
                                "usa \"HKCU/Software/NomeDelProgramma\" per i tuoi dati.")
            raise ErroreValore(f"La chiave `{sotto}` è protetta: Leo non la modifica.", suggerimento=suggerimento)
    return radice, sotto


def valore_da_registro(valore: Any, tipo: int) -> Any:
    """Valore letto con ``winreg`` -> valore Leo."""
    if tipo in (REG_DWORD, REG_QWORD):
        return int(valore) if isinstance(valore, int) else _intero(valore, 0)
    if tipo == REG_MULTI_SZ:
        return [str(v) for v in (valore or [])]
    if tipo in (REG_SZ, REG_EXPAND_SZ):
        return "" if valore is None else str(valore)
    if isinstance(valore, (bytes, bytearray)):
        return list(valore)
    if valore is None:
        return None
    if isinstance(valore, (int, str)):
        return valore
    return str(valore)


def valore_per_registro(valore: Any) -> tuple[Any, int]:
    """Valore Leo -> (valore, tipo) per ``winreg.SetValueEx``."""
    if isinstance(valore, bool):
        return int(valore), REG_DWORD
    if isinstance(valore, int):
        if 0 <= valore <= 0xFFFFFFFF:
            return valore, REG_DWORD
        if 0 <= valore <= 0xFFFFFFFFFFFFFFFF:
            return valore, REG_QWORD
        raise ErroreValore(f"Il numero {valore} è fuori dai limiti del registro.",
                           suggerimento="Il registro accetta interi da 0 a 18446744073709551615; "
                                        "per altri valori salvali come testo con `testo(...)`.")
    if isinstance(valore, float):
        return repr(valore), REG_SZ
    if isinstance(valore, str):
        if "\0" in valore:
            raise ErroreValore("Un testo del registro non può contenere il carattere nullo.")
        return valore, REG_SZ
    if isinstance(valore, list):
        if all(isinstance(v, str) and "\0" not in v for v in valore):
            return list(valore), REG_MULTI_SZ
        if all(isinstance(v, int) and not isinstance(v, bool) and 0 <= v <= 255 for v in valore):
            return bytes(valore), REG_BINARY
        raise ErroreValore("Nel registro una lista può contenere solo testi oppure byte (interi da 0 a 255).")
    raise ErroreValore("Nel registro si possono scrivere testi, interi, `vero`/`falso` o liste di testi.",
                       suggerimento="Trasforma il valore in testo con `testo(...)` o in JSON con `a_json(...)`.")


# ===========================================================================
# Chiamate native (solo Windows)
# ===========================================================================

class NativoWindows:
    """Tutte le chiamate al sistema. Su Linux non si usa (i test la sostituiscono)."""

    # --- strumenti -----------------------------------------------------------

    def esegui(self, argomenti: list[str], tempo_massimo: float = 30) -> tuple[int, str, str]:
        """Esegue un programma senza finestra: (codice di uscita, uscita, errori)."""
        try:
            r = subprocess.run(argomenti, capture_output=True, timeout=tempo_massimo,
                               stdin=subprocess.DEVNULL, creationflags=CREATE_NO_WINDOW)
        except FileNotFoundError:
            raise ErroreFile(f"Non trovo il programma di Windows `{argomenti[0]}`.") from None
        except subprocess.TimeoutExpired:
            raise ErroreValore("Windows ci sta mettendo troppo a rispondere.",
                               suggerimento="Riprova tra poco.") from None
        except OSError as e:
            raise ErroreFile(f"Non riesco ad avviare `{argomenti[0]}`: {e.strerror or e}.") from None
        return r.returncode, _decodifica(r.stdout), _decodifica(r.stderr)

    def powershell(self, script: str, tempo_massimo: float = 60) -> str:
        codice, uscita, errori = self.esegui(script_powershell(script), tempo_massimo)
        if codice != 0:
            dettaglio = _prima_riga(errori) or _prima_riga(uscita)
            raise ErroreValore("Windows non è riuscito a eseguire l'operazione"
                               + (f": {dettaglio}" if dettaglio else "."))
        return uscita

    def powershell_json(self, espressione: str, tempo_massimo: float = 60) -> list[dict]:
        return lista_da_json(self.powershell(comando_json(espressione), tempo_massimo))

    def _kernel32(self):
        import ctypes
        return ctypes.WinDLL("kernel32", use_last_error=True)

    # --- batteria --------------------------------------------------------------

    def stato_alimentazione(self) -> tuple[int, int, int, int, int]:
        import ctypes
        from ctypes import wintypes

        class SYSTEM_POWER_STATUS(ctypes.Structure):
            _fields_ = [("ACLineStatus", wintypes.BYTE), ("BatteryFlag", wintypes.BYTE),
                        ("BatteryLifePercent", wintypes.BYTE), ("SystemStatusFlag", wintypes.BYTE),
                        ("BatteryLifeTime", wintypes.DWORD), ("BatteryFullLifeTime", wintypes.DWORD)]

        s = SYSTEM_POWER_STATUS()
        if not self._kernel32().GetSystemPowerStatus(ctypes.byref(s)):
            raise ErroreValore("Windows non mi dice lo stato della batteria.")
        # BYTE di wintypes e' con segno: riporto a 0-255
        return (s.ACLineStatus & 0xFF, s.BatteryFlag & 0xFF, s.BatteryLifePercent & 0xFF,
                s.BatteryLifeTime, s.SystemStatusFlag & 0xFF)

    # --- alimentazione -------------------------------------------------------------

    COMANDI_ALIMENTAZIONE = {
        "blocca": "rundll32.exe user32.dll,LockWorkStation",
        "sospendi": ("Add-Type -AssemblyName System.Windows.Forms; "
                     "[void][System.Windows.Forms.Application]::SetSuspendState('Suspend', $false, $false)"),
        "iberna": "shutdown.exe /h",
        "spegni": "shutdown.exe /s /t 0",
        "riavvia": "shutdown.exe /r /t 0",
        "disconnetti": "shutdown.exe /l",
    }

    def esegui_alimentazione(self, azione: str) -> None:
        blocca_se_in_prova(azione)
        if azione == "blocca":
            import ctypes
            if not ctypes.WinDLL("user32").LockWorkStation():
                raise ErroreValore("Windows non ha bloccato il computer.")
            return
        if azione == "sospendi":
            self.powershell(self.COMANDI_ALIMENTAZIONE["sospendi"])
            return
        argomenti = self.COMANDI_ALIMENTAZIONE[azione].split()
        codice, uscita, errori = self.esegui(argomenti)
        if codice != 0:
            dettaglio = _prima_riga(errori) or _prima_riga(uscita)
            raise ErroreValore("Windows ha rifiutato l'operazione" + (f": {dettaglio}" if dettaglio else "."))

    def programma_alimentazione(self, azione: str, secondi: int) -> int:
        """Avvia un PowerShell nascosto che aspetta e poi esegue l'azione; restituisce il suo PID."""
        blocca_se_in_prova(azione)
        script = f"Start-Sleep -Seconds {int(secondi)}; {self.COMANDI_ALIMENTAZIONE[azione]}"
        try:
            p = subprocess.Popen(script_powershell(script), stdin=subprocess.DEVNULL,
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, close_fds=True,
                                 creationflags=CREATE_NO_WINDOW | CREATE_NEW_PROCESS_GROUP)
        except OSError as e:
            raise ErroreFile(f"Non riesco a programmare l'operazione: {e.strerror or e}.") from None
        return p.pid

    def processo_e_powershell(self, pid: int) -> bool:
        codice, uscita, _ = self.esegui(["tasklist", "/FI", f"PID eq {int(pid)}", "/FO", "CSV", "/NH"], 15)
        return codice == 0 and "powershell" in uscita.lower()

    def termina_processo(self, pid: int) -> bool:
        blocca_se_in_prova("annulla_spegnimento")
        codice, _, _ = self.esegui(["taskkill", "/PID", str(int(pid)), "/T", "/F"], 15)
        return codice == 0

    def annulla_shutdown(self) -> bool:
        blocca_se_in_prova("annulla_spegnimento")
        codice, _, _ = self.esegui(["shutdown.exe", "/a"], 15)
        return codice == 0

    def stato_esecuzione(self, sveglio: bool, schermo: bool) -> None:
        import ctypes
        k32 = self._kernel32()
        k32.SetThreadExecutionState.restype = ctypes.c_uint32
        k32.SetThreadExecutionState.argtypes = [ctypes.c_uint32]
        bandiere = 0x80000000  # ES_CONTINUOUS
        if sveglio:
            bandiere |= 0x00000001  # ES_SYSTEM_REQUIRED
            if schermo:
                bandiere |= 0x00000002  # ES_DISPLAY_REQUIRED
        if not k32.SetThreadExecutionState(bandiere):
            raise ErroreValore("Windows non ha accettato la richiesta sullo standby.")

    # --- audio (Core Audio via COM con ctypes) --------------------------------------

    def volume(self) -> float:
        with _AudioPredefinito() as a:
            return a.leggi_volume()

    def imposta_volume(self, livello: float) -> None:
        blocca_se_in_prova("imposta_volume")
        with _AudioPredefinito() as a:
            a.scrivi_volume(livello)

    def muto(self) -> bool:
        with _AudioPredefinito() as a:
            return a.leggi_muto()

    def imposta_muto(self, muto: bool) -> None:
        blocca_se_in_prova("imposta_muto")
        with _AudioPredefinito() as a:
            a.scrivi_muto(muto)

    def dispositivi_audio(self) -> list[dict]:
        return _elenca_dispositivi_audio()

    # --- luminosita' ---------------------------------------------------------------

    def luminosita(self) -> int | None:
        uscita = self.powershell(
            "$b = Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightness "
            "-ErrorAction SilentlyContinue | Select-Object -First 1; "
            "if ($b) { [int]$b.CurrentBrightness } else { 'NESSUNO' }")
        return _intero(uscita.strip())

    def imposta_luminosita(self, livello: int) -> bool:
        blocca_se_in_prova("imposta_luminosita")
        uscita = self.powershell(
            "$m = Get-CimInstance -Namespace root/WMI -ClassName WmiMonitorBrightnessMethods "
            "-ErrorAction SilentlyContinue | Select-Object -First 1; "
            f"if ($m) {{ Invoke-CimMethod -InputObject $m -MethodName WmiSetBrightness "
            f"-Arguments @{{Timeout=[uint32]0; Brightness=[byte]{int(livello)}}} | Out-Null; 'OK' }} "
            "else { 'NESSUNO' }")
        return uscita.strip() == "OK"

    # --- prestazioni -------------------------------------------------------------------

    def tempi_sistema(self) -> tuple[int, int, int]:
        import ctypes
        inattivo, kernel, utente = ctypes.c_ulonglong(), ctypes.c_ulonglong(), ctypes.c_ulonglong()
        if not self._kernel32().GetSystemTimes(ctypes.byref(inattivo), ctypes.byref(kernel), ctypes.byref(utente)):
            raise ErroreValore("Windows non mi dice l'uso del processore.")
        return inattivo.value, kernel.value, utente.value

    def memoria(self) -> tuple[int, int]:
        import ctypes

        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                        ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("ullAvailExtendedVirtual", ctypes.c_ulonglong)]

        m = MEMORYSTATUSEX()
        m.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if not self._kernel32().GlobalMemoryStatusEx(ctypes.byref(m)):
            raise ErroreValore("Windows non mi dice quanta memoria c'è.")
        return m.ullTotalPhys, m.ullAvailPhys

    def millisecondi_accensione(self) -> int:
        import ctypes
        k32 = self._kernel32()
        k32.GetTickCount64.restype = ctypes.c_ulonglong
        return int(k32.GetTickCount64())

    def processi_pesanti(self, quanti: int) -> list[dict]:
        return self.powershell_json(
            "$ErrorActionPreference = 'SilentlyContinue'; "
            "Get-Process -ErrorAction SilentlyContinue | Sort-Object WorkingSet64 -Descending | "
            f"Select-Object -First {int(quanti)} | ForEach-Object {{ $c = $null; "
            "try { $c = $_.TotalProcessorTime.TotalSeconds } catch { }; [pscustomobject]@{"
            "n = $_.ProcessName; p = $_.Id; m = $_.WorkingSet64; c = $c } }")

    # --- dischi -------------------------------------------------------------------------

    def unita(self) -> list[str]:
        import ctypes
        buf = ctypes.create_unicode_buffer(1024)
        n = self._kernel32().GetLogicalDriveStringsW(1024, buf)
        return [u.rstrip("\\") for u in buf[:n].split("\0") if u]

    def info_unita(self, unita: str) -> tuple[int, str | None, str | None, int | None, int | None]:
        import ctypes
        k32 = self._kernel32()
        radice = unita + "\\"
        vecchio = k32.SetErrorMode(0x0001)  # niente finestre "inserisci un disco"
        try:
            tipo = int(k32.GetDriveTypeW(radice))
            etichetta = ctypes.create_unicode_buffer(261)
            fs = ctypes.create_unicode_buffer(261)
            ok = k32.GetVolumeInformationW(radice, etichetta, 261, None, None, None, fs, 261)
            libero, totale, _tot_libero = ctypes.c_ulonglong(), ctypes.c_ulonglong(), ctypes.c_ulonglong()
            spazio = k32.GetDiskFreeSpaceExW(radice, ctypes.byref(libero), ctypes.byref(totale),
                                             ctypes.byref(_tot_libero))
        finally:
            k32.SetErrorMode(vecchio)
        return (tipo, etichetta.value if ok else None, fs.value if ok else None,
                totale.value if spazio else None, libero.value if spazio else None)

    # --- rete ------------------------------------------------------------------------------

    def indirizzi_ip(self) -> list[dict]:
        return self.powershell_json(
            "Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' } | "
            "ForEach-Object { [pscustomobject]@{ i = $_.IPAddress; n = $_.InterfaceAlias } }")

    def ip_uscita(self) -> str | None:
        """IP locale usato per uscire su Internet (UDP senza inviare pacchetti)."""
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("192.0.2.1", 9))  # indirizzo di documentazione: nessun pacchetto parte
            return s.getsockname()[0]
        except OSError:
            return None
        finally:
            s.close()

    def ip_pubblico(self, tempo_massimo: float) -> str:
        import urllib.request
        for sito in ("https://api.ipify.org", "https://icanhazip.com", "https://ifconfig.me/ip"):
            try:
                with urllib.request.urlopen(sito, timeout=tempo_massimo) as r:  # noqa: S310 - https fisso
                    testo = r.read(100).decode("ascii", "replace").strip()
            except (OSError, ValueError):
                continue
            if re.fullmatch(r"[0-9a-fA-F:.]{3,45}", testo):
                return testo
        raise ErroreFile("Non riesco a scoprire l'indirizzo IP pubblico: nessuna risposta da Internet.",
                         suggerimento="Controlla la connessione con `connessione_attiva()`.")

    def wifi(self) -> str:
        codice, uscita, _ = self.esegui(["netsh", "wlan", "show", "interfaces"], 20)
        if codice == 0 and analizza_wifi(uscita):
            return uscita
        # Windows 11 24H2+: netsh wlan chiede il permesso di "Posizione". Ripiego: il nome
        # della rete dal profilo di connessione (senza segnale) nello stesso formato di netsh.
        try:
            profili = self.powershell_json(
                "Get-NetConnectionProfile -ErrorAction SilentlyContinue | Where-Object { "
                "(Get-NetAdapter -InterfaceIndex $_.InterfaceIndex -ErrorAction SilentlyContinue)"
                ".PhysicalMediaType -match '802.11|Wireless' } | ForEach-Object { "
                "[pscustomobject]@{ n = $_.Name; a = $_.InterfaceAlias } }")
        except ErroreValore:
            return ""
        for p in profili:
            if p.get("n"):
                return f"    Name : {p.get('a') or 'Wi-Fi'}\n    SSID : {p['n']}\n"
        return ""

    def schede_rete(self) -> list[dict]:
        return self.powershell_json(
            "Get-NetAdapter | ForEach-Object { [pscustomobject]@{ n = $_.Name; d = $_.InterfaceDescription; "
            "s = [string]$_.Status; m = $_.MacAddress; v = $_.LinkSpeed } }")

    def ping(self, ip: str, volte: int, tempo_massimo_ms: int) -> list[int | None]:
        import ctypes
        iph = ctypes.WinDLL("iphlpapi", use_last_error=True)
        iph.IcmpCreateFile.restype = ctypes.c_void_p
        iph.IcmpCloseHandle.argtypes = [ctypes.c_void_p]
        iph.IcmpSendEcho.restype = ctypes.c_ulong
        iph.IcmpSendEcho.argtypes = [ctypes.c_void_p, ctypes.c_ulong, ctypes.c_void_p, ctypes.c_ushort,
                                     ctypes.c_void_p, ctypes.c_void_p, ctypes.c_ulong, ctypes.c_ulong]
        maniglia = iph.IcmpCreateFile()
        if not maniglia or maniglia == ctypes.c_void_p(-1).value:
            raise ErroreValore("Windows non mi permette di inviare il ping.")
        indirizzo = struct.unpack("=L", socket.inet_aton(ip))[0]
        dati = b"Leo-ping-abcdefghijklmnopqrstuv"
        risposta = ctypes.create_string_buffer(256 + len(dati))
        tempi: list[int | None] = []
        try:
            for i in range(volte):
                n = iph.IcmpSendEcho(maniglia, indirizzo, dati, len(dati), None, risposta,
                                     ctypes.sizeof(risposta), tempo_massimo_ms)
                if n:
                    # Address, Status, RoundTripTime: i primi tre ULONG della risposta
                    _ind, stato, tempo = struct.unpack_from("=LLL", risposta.raw, 0)
                    tempi.append(int(tempo) if stato == 0 else None)
                else:
                    tempi.append(None)
                if i + 1 < volte:
                    time.sleep(0.2)
        finally:
            iph.IcmpCloseHandle(maniglia)
        return tempi

    # --- stampanti --------------------------------------------------------------------------

    def stampanti(self) -> list[dict]:
        return self.powershell_json(
            "Get-CimInstance Win32_Printer | ForEach-Object { [pscustomobject]@{ n = $_.Name; "
            "d = [bool]$_.Default; o = [bool]$_.WorkOffline; p = $_.PortName; r = $_.DriverName; "
            "c = [bool]$_.Shared } }")

    def stampante_predefinita(self) -> str | None:
        import ctypes
        winspool = ctypes.WinDLL("winspool.drv", use_last_error=True)
        dimensione = ctypes.c_ulong(0)
        winspool.GetDefaultPrinterW(None, ctypes.byref(dimensione))
        if not dimensione.value:
            return None
        buf = ctypes.create_unicode_buffer(dimensione.value + 1)
        if not winspool.GetDefaultPrinterW(buf, ctypes.byref(dimensione)):
            return None
        return buf.value or None

    def stampa_file(self, percorso: str) -> None:
        blocca_se_in_prova("stampa_documento")
        import ctypes
        shell32 = ctypes.WinDLL("shell32", use_last_error=True)
        shell32.ShellExecuteW.restype = ctypes.c_void_p
        shell32.ShellExecuteW.argtypes = [ctypes.c_void_p, ctypes.c_wchar_p, ctypes.c_wchar_p,
                                          ctypes.c_wchar_p, ctypes.c_wchar_p, ctypes.c_int]
        esito = shell32.ShellExecuteW(None, "print", percorso, None, os.path.dirname(percorso) or None, 0) or 0
        if esito <= 32:
            if esito in (31, 27):  # SE_ERR_NOASSOC, SE_ERR_ASSOCINCOMPLETE
                raise ErroreFile(f"Nessun programma sa stampare `{os.path.basename(percorso)}`.",
                                 suggerimento="Installa un programma che apra questo tipo di file "
                                              "(per i PDF, per esempio, un lettore PDF).")
            raise ErroreFile(f"Windows non ha avviato la stampa di `{os.path.basename(percorso)}` "
                             f"(codice {esito}).")

    # --- registro --------------------------------------------------------------------------

    def _winreg(self):
        import winreg
        return winreg

    def _apri(self, radice: str, sotto: str, scrittura: bool = False, crea: bool = False):
        wr = self._winreg()
        base = getattr(wr, radice)
        accesso = wr.KEY_READ | getattr(wr, "KEY_WOW64_64KEY", 0)
        if scrittura:
            accesso = wr.KEY_READ | wr.KEY_WRITE | getattr(wr, "KEY_WOW64_64KEY", 0)
        if crea:
            return wr.CreateKeyEx(base, sotto, 0, accesso)
        return wr.OpenKey(base, sotto, 0, accesso)

    def reg_leggi(self, radice: str, sotto: str, nome: str) -> tuple[Any, int] | None:
        try:
            with self._apri(radice, sotto) as k:
                valore, tipo = self._winreg().QueryValueEx(k, nome)
        except FileNotFoundError:
            return None
        except PermissionError:
            raise _errore_permesso(radice, sotto) from None
        except OSError as e:
            raise _errore_registro(e) from None
        return valore, tipo

    def reg_esiste(self, radice: str, sotto: str) -> bool:
        try:
            with self._apri(radice, sotto):
                return True
        except FileNotFoundError:
            return False
        except PermissionError:
            return True  # c'e', ma non si puo' leggere
        except OSError as e:
            raise _errore_registro(e) from None

    def reg_chiavi(self, radice: str, sotto: str) -> list[str]:
        wr = self._winreg()
        nomi = []
        try:
            with self._apri(radice, sotto) as k:
                i = 0
                while True:
                    try:
                        nomi.append(wr.EnumKey(k, i))
                    except OSError:
                        break
                    i += 1
        except FileNotFoundError:
            raise _errore_non_esiste(radice, sotto) from None
        except PermissionError:
            raise _errore_permesso(radice, sotto) from None
        return nomi

    def reg_valori(self, radice: str, sotto: str) -> list[tuple[str, Any, int]]:
        wr = self._winreg()
        valori = []
        try:
            with self._apri(radice, sotto) as k:
                i = 0
                while True:
                    try:
                        nome, valore, tipo = wr.EnumValue(k, i)
                    except OSError:
                        break
                    valori.append((nome, valore, tipo))
                    i += 1
        except FileNotFoundError:
            raise _errore_non_esiste(radice, sotto) from None
        except PermissionError:
            raise _errore_permesso(radice, sotto) from None
        return valori

    def reg_scrivi(self, radice: str, sotto: str, nome: str, valore: Any, tipo: int) -> None:
        blocca_se_in_prova("scrivi_registro")
        try:
            with self._apri(radice, sotto, scrittura=True, crea=True) as k:
                self._winreg().SetValueEx(k, nome, 0, tipo, valore)
        except PermissionError:
            raise _errore_permesso(radice, sotto) from None
        except OSError as e:
            raise _errore_registro(e) from None

    def reg_elimina_valore(self, radice: str, sotto: str, nome: str) -> bool:
        blocca_se_in_prova("elimina_valore_registro")
        try:
            with self._apri(radice, sotto, scrittura=True) as k:
                self._winreg().DeleteValue(k, nome)
        except FileNotFoundError:
            return False
        except PermissionError:
            raise _errore_permesso(radice, sotto) from None
        except OSError as e:
            raise _errore_registro(e) from None
        return True

    def reg_elimina_chiave(self, radice: str, sotto: str) -> bool:
        blocca_se_in_prova("elimina_chiave_registro")
        wr = self._winreg()
        genitore, _, foglia = sotto.rpartition("\\")
        try:
            with self._apri(radice, genitore, scrittura=True) as k:
                wr.DeleteKey(k, foglia)
        except FileNotFoundError:
            return False
        except PermissionError:
            raise _errore_permesso(radice, sotto) from None
        except OSError:
            raise ErroreValore(f"Non posso eliminare `{sotto}`: contiene altre chiavi.",
                               suggerimento="Per sicurezza elimino solo chiavi senza sottochiavi: "
                                            "elimina prima quelle dentro (vedi `elenca_chiavi_registro`).") from None
        return True

    # --- servizi, utente, orologio, caratteri --------------------------------------------------

    def servizi(self, nome: str | None = None) -> list[dict]:
        filtro = f" -Name {testo_powershell(nome)} -ErrorAction SilentlyContinue" if nome else ""
        return self.powershell_json(
            f"Get-Service{filtro} | ForEach-Object {{ [pscustomobject]@{{ n = $_.Name; d = $_.DisplayName; "
            "s = [string]$_.Status; a = [string]$_.StartType } }")

    def e_amministratore(self) -> bool:
        import ctypes
        try:
            return bool(ctypes.WinDLL("shell32").IsUserAnAdmin())
        except (AttributeError, OSError):
            return False

    def sessione_remota(self) -> bool:
        import ctypes
        return bool(ctypes.WinDLL("user32").GetSystemMetrics(0x1000))  # SM_REMOTESESSION

    # --- hardware e USB ---------------------------------------------------------------------------

    def processore(self) -> list[dict]:
        return self.powershell_json(
            "Get-CimInstance Win32_Processor | ForEach-Object { [pscustomobject]@{ n = $_.Name; "
            "p = $_.Manufacturer; c = $_.NumberOfCores; l = $_.NumberOfLogicalProcessors; "
            "f = $_.MaxClockSpeed; a = $_.AddressWidth } }")

    def scheda_madre(self) -> list[dict]:
        return self.powershell_json(
            "$b = Get-CimInstance Win32_BaseBoard | Select-Object -First 1; "
            "$s = Get-CimInstance Win32_BIOS | Select-Object -First 1; "
            "[pscustomobject]@{ p = $b.Manufacturer; m = $b.Product; v = $b.Version; "
            "bp = $s.Manufacturer; bv = $s.SMBIOSBIOSVersion }")

    def schede_video(self) -> list[dict]:
        return self.powershell_json(
            "Get-CimInstance Win32_VideoController | ForEach-Object { [pscustomobject]@{ n = $_.Name; "
            "m = $_.AdapterRAM; d = $_.DriverVersion; p = $_.AdapterCompatibility; "
            "x = $_.CurrentHorizontalResolution; y = $_.CurrentVerticalResolution; f = $_.CurrentRefreshRate } }")

    def computer(self) -> list[dict]:
        return self.powershell_json(
            "$c = Get-CimInstance Win32_ComputerSystem; $o = Get-CimInstance Win32_OperatingSystem; "
            "[pscustomobject]@{ p = $c.Manufacturer; m = $c.Model; t = $c.SystemType; r = $c.TotalPhysicalMemory; "
            "s = $o.Caption; v = $o.Version; a = $o.OSArchitecture }")

    def usb(self) -> list[dict]:
        return self.powershell_json(
            "Get-PnpDevice -PresentOnly | Where-Object { $_.InstanceId -like 'USB*' } | "
            "ForEach-Object { [pscustomobject]@{ n = $_.FriendlyName; c = $_.Class; s = [string]$_.Status; "
            "i = $_.InstanceId } }")


def _decodifica(dati: bytes | None) -> str:
    return _win.decodifica_uscita(dati)


def _prima_riga(testo: str) -> str:
    for riga in (testo or "").splitlines():
        riga = riga.strip()
        if riga:
            return riga[:200]
    return ""


def _errore_non_esiste(radice: str, sotto: str) -> ErroreChiave:
    return ErroreChiave(f"La chiave `{radice}\\{sotto}` non esiste nel registro.",
                        suggerimento="Controlla il percorso; puoi verificare prima con `esiste_chiave_registro(...)`.")


def _errore_permesso(radice: str, sotto: str) -> ErroreFile:
    return ErroreFile(f"Non hai il permesso di usare la chiave `{radice}\\{sotto}` del registro.")


def _errore_registro(e: OSError) -> ErroreFile:
    return ErroreFile(f"Il registro di Windows ha dato un errore: {getattr(e, 'strerror', None) or e}.")


# ---------------------------------------------------------------------------
# Core Audio via COM (solo Windows): vtable chiamate con ctypes
# ---------------------------------------------------------------------------

_CLSID_ENUMERATORE = "{BCDE0395-E52F-467C-8E3D-C4579291692E}"
_IID_ENUMERATORE = "{A95664D2-9614-4F35-A746-DE8DB63617E6}"
_IID_VOLUME = "{5CDF2C82-841E-4546-9722-0CF74078229A}"
_PKEY_NOME = ("{A45C254E-DF1C-4EFD-8020-67D146A850E0}", 14)  # PKEY_Device_FriendlyName
_CLSCTX_ALL = 0x17
_E_NOTFOUND = 0x80070490


def _guid(testo: str):
    import ctypes

    class GUID(ctypes.Structure):
        _fields_ = [("Data1", ctypes.c_uint32), ("Data2", ctypes.c_uint16), ("Data3", ctypes.c_uint16),
                    ("Data4", ctypes.c_ubyte * 8)]

    return GUID.from_buffer_copy(uuid.UUID(testo).bytes_le)


def _metodo_com(oggetto, indice: int, *tipi):
    """Metodo numero ``indice`` della vtable di un oggetto COM (restituisce HRESULT)."""
    import ctypes
    vtable = ctypes.cast(oggetto, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p))).contents
    prototipo = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, *tipi)
    return prototipo(vtable[indice])


def _controlla_hr(hr: int, cosa: str) -> None:
    if hr < 0:
        if (hr & 0xFFFFFFFF) == _E_NOTFOUND:
            raise ErroreValore("Non c'è nessun dispositivo audio di uscita attivo.",
                               suggerimento="Collega casse o cuffie e controlla le impostazioni audio di Windows.")
        raise ErroreValore(f"Windows non ha risposto sull'audio ({cosa}, codice 0x{hr & 0xFFFFFFFF:08X}).")


def _rilascia(oggetto) -> None:
    import ctypes
    if oggetto and oggetto.value:
        try:
            _metodo_com(oggetto, 2)(oggetto)
        except (OSError, ValueError, ctypes.ArgumentError):  # pragma: no cover
            pass


class _SessioneCOM:
    def __enter__(self):
        import ctypes
        self.ole32 = ctypes.WinDLL("ole32")
        hr = self.ole32.CoInitializeEx(None, 0x2)  # COINIT_APARTMENTTHREADED
        self.da_chiudere = hr in (0, 1)  # S_OK, S_FALSE (RPC_E_CHANGED_MODE: gia' inizializzato)
        self.enumeratore = ctypes.c_void_p()
        clsid, iid = _guid(_CLSID_ENUMERATORE), _guid(_IID_ENUMERATORE)
        hr = self.ole32.CoCreateInstance(ctypes.byref(clsid), None, _CLSCTX_ALL, ctypes.byref(iid),
                                         ctypes.byref(self.enumeratore))
        if hr < 0:
            self.__exit__(None, None, None)
            _controlla_hr(hr, "enumeratore")
        return self

    def __exit__(self, *errore):
        _rilascia(getattr(self, "enumeratore", None))
        if self.da_chiudere:
            self.ole32.CoUninitialize()
            self.da_chiudere = False
        return False


class _AudioPredefinito:
    """Volume del dispositivo di uscita predefinito (IAudioEndpointVolume)."""

    def __enter__(self):
        import ctypes
        self.com = _SessioneCOM().__enter__()
        self.dispositivo = ctypes.c_void_p()
        self.volume = ctypes.c_void_p()
        try:
            e = self.com.enumeratore
            hr = _metodo_com(e, 4, ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_void_p))(
                e, 0, 1, ctypes.byref(self.dispositivo))  # eRender, eMultimedia
            _controlla_hr(hr, "dispositivo predefinito")
            iid = _guid(_IID_VOLUME)
            hr = _metodo_com(self.dispositivo, 3, ctypes.c_void_p, ctypes.c_uint32, ctypes.c_void_p,
                             ctypes.POINTER(ctypes.c_void_p))(
                self.dispositivo, ctypes.byref(iid), _CLSCTX_ALL, None, ctypes.byref(self.volume))
            _controlla_hr(hr, "controllo del volume")
        except BaseException:
            self.__exit__(None, None, None)
            raise
        return self

    def __exit__(self, *errore):
        _rilascia(self.volume)
        _rilascia(self.dispositivo)
        self.com.__exit__(None, None, None)
        return False

    def leggi_volume(self) -> float:
        import ctypes
        v = ctypes.c_float()
        _controlla_hr(_metodo_com(self.volume, 9, ctypes.POINTER(ctypes.c_float))(self.volume, ctypes.byref(v)),
                      "lettura del volume")
        return float(v.value)

    def scrivi_volume(self, livello: float) -> None:
        import ctypes
        _controlla_hr(_metodo_com(self.volume, 7, ctypes.c_float, ctypes.c_void_p)(
            self.volume, ctypes.c_float(max(0.0, min(1.0, livello))), None), "impostazione del volume")

    def leggi_muto(self) -> bool:
        import ctypes
        m = ctypes.c_int()
        _controlla_hr(_metodo_com(self.volume, 15, ctypes.POINTER(ctypes.c_int))(self.volume, ctypes.byref(m)),
                      "lettura del muto")
        return bool(m.value)

    def scrivi_muto(self, muto: bool) -> None:
        import ctypes
        _controlla_hr(_metodo_com(self.volume, 14, ctypes.c_int, ctypes.c_void_p)(
            self.volume, 1 if muto else 0, None), "impostazione del muto")


def _elenca_dispositivi_audio() -> list[dict]:
    import ctypes

    class PROPERTYKEY(ctypes.Structure):
        _fields_ = [("fmtid", ctypes.c_ubyte * 16), ("pid", ctypes.c_uint32)]

    class PROPVARIANT(ctypes.Structure):
        _fields_ = [("vt", ctypes.c_ushort), ("r1", ctypes.c_ushort), ("r2", ctypes.c_ushort),
                    ("r3", ctypes.c_ushort), ("valore", ctypes.c_void_p), ("altro", ctypes.c_void_p)]

    chiave = PROPERTYKEY()
    ctypes.memmove(chiave.fmtid, uuid.UUID(_PKEY_NOME[0]).bytes_le, 16)
    chiave.pid = _PKEY_NOME[1]
    risultato: list[dict] = []
    with _SessioneCOM() as com:
        ole32 = com.ole32
        e = com.enumeratore
        # id del predefinito
        id_predefinito = ""
        predefinito = ctypes.c_void_p()
        hr = _metodo_com(e, 4, ctypes.c_int, ctypes.c_int, ctypes.POINTER(ctypes.c_void_p))(
            e, 0, 1, ctypes.byref(predefinito))
        if hr >= 0:
            id_predefinito = _id_dispositivo(predefinito, ole32)
            _rilascia(predefinito)
        raccolta = ctypes.c_void_p()
        hr = _metodo_com(e, 3, ctypes.c_int, ctypes.c_uint32, ctypes.POINTER(ctypes.c_void_p))(
            e, 0, 0x1, ctypes.byref(raccolta))  # eRender, DEVICE_STATE_ACTIVE
        _controlla_hr(hr, "elenco dei dispositivi")
        try:
            quanti = ctypes.c_uint()
            _controlla_hr(_metodo_com(raccolta, 3, ctypes.POINTER(ctypes.c_uint))(raccolta, ctypes.byref(quanti)),
                          "numero dei dispositivi")
            for i in range(quanti.value):
                disp = ctypes.c_void_p()
                if _metodo_com(raccolta, 4, ctypes.c_uint, ctypes.POINTER(ctypes.c_void_p))(
                        raccolta, i, ctypes.byref(disp)) < 0:
                    continue
                try:
                    ident = _id_dispositivo(disp, ole32)
                    nome = ""
                    negozio = ctypes.c_void_p()
                    if _metodo_com(disp, 4, ctypes.c_uint32, ctypes.POINTER(ctypes.c_void_p))(
                            disp, 0, ctypes.byref(negozio)) >= 0:  # STGM_READ
                        try:
                            pv = PROPVARIANT()
                            if _metodo_com(negozio, 5, ctypes.POINTER(PROPERTYKEY), ctypes.POINTER(PROPVARIANT))(
                                    negozio, ctypes.byref(chiave), ctypes.byref(pv)) >= 0:
                                if pv.vt == 31 and pv.valore:  # VT_LPWSTR
                                    nome = ctypes.wstring_at(pv.valore)
                                ole32.PropVariantClear(ctypes.byref(pv))
                        finally:
                            _rilascia(negozio)
                    risultato.append({"nome": nome or "(senza nome)", "predefinito": ident == id_predefinito,
                                      "id": ident})
                finally:
                    _rilascia(disp)
        finally:
            _rilascia(raccolta)
    return risultato


def _id_dispositivo(dispositivo, ole32) -> str:
    import ctypes
    p = ctypes.c_void_p()
    if _metodo_com(dispositivo, 5, ctypes.POINTER(ctypes.c_void_p))(dispositivo, ctypes.byref(p)) < 0 or not p.value:
        return ""
    try:
        return ctypes.wstring_at(p.value)
    finally:
        ole32.CoTaskMemFree(p)


#: backend in uso (i test lo sostituiscono con un finto)
nativo: Any = NativoWindows()


# ===========================================================================
# Funzioni pubbliche (usate da leo/libreria/computer.py)
# ===========================================================================

# --- batteria --------------------------------------------------------------------

def info_batteria() -> dict:
    richiedi_windows("info_batteria")
    return stato_batteria(*nativo.stato_alimentazione())


# --- alimentazione -----------------------------------------------------------------

AZIONI_ALIMENTAZIONE = ("blocca", "sospendi", "iberna", "spegni", "riavvia", "disconnetti")


def _file_programmate() -> str:
    return os.path.join(tempfile.gettempdir(), NOME_FILE_PROGRAMMATE)


def leggi_programmate() -> list[dict]:
    try:
        with open(_file_programmate(), encoding="utf-8") as f:
            dati = json.load(f)
    except (OSError, ValueError):
        return []
    return [d for d in dati if isinstance(d, dict) and isinstance(d.get("pid"), int)] if isinstance(dati, list) else []


def _scrivi_programmate(elenco: list[dict]) -> None:
    try:
        with open(_file_programmate(), "w", encoding="utf-8") as f:
            json.dump(elenco, f)
    except OSError:
        pass


def alimentazione(azione: str, ritardo: int = 0) -> None:
    """Esegue subito (``ritardo`` 0) o programma un'azione di alimentazione."""
    if azione not in AZIONI_ALIMENTAZIONE:  # pragma: no cover - solo errori di programmazione
        raise ErroreValore(f"Azione di alimentazione sconosciuta: `{azione}`.")
    if ritardo <= 0:
        nativo.esegui_alimentazione(azione)
        return
    pid = nativo.programma_alimentazione(azione, ritardo)
    elenco = leggi_programmate()
    elenco.append({"pid": pid, "azione": azione,
                   "quando": (datetime.datetime.now() + datetime.timedelta(seconds=ritardo)).isoformat(timespec="seconds")})
    _scrivi_programmate(elenco)


def annulla_programmate() -> list[str]:
    """Annulla le azioni programmate da Leo e lo spegnimento di Windows in attesa; restituisce cosa e' stato annullato."""
    annullate: list[str] = []
    for voce in leggi_programmate():
        pid = voce["pid"]
        try:
            if nativo.processo_e_powershell(pid) and nativo.termina_processo(pid):
                annullate.append(str(voce.get("azione", "")))
        except ErroreValore:
            raise
        except Exception:  # noqa: BLE001 - un processo gia' finito non e' un problema
            continue
    _scrivi_programmate([])
    if nativo.annulla_shutdown():
        annullate.append("spegnimento di Windows")
    return annullate


# --- audio ---------------------------------------------------------------------------

def volume_percentuale() -> int:
    richiedi_windows("volume_principale")
    return int(round(nativo.volume() * 100))


def imposta_volume_percentuale(livello: float) -> int:
    richiedi_windows("imposta_volume")
    livello = max(0.0, min(100.0, float(livello)))
    nativo.imposta_volume(livello / 100.0)
    return int(round(livello))


# --- dischi ---------------------------------------------------------------------------

def elenca_unita() -> list[dict]:
    richiedi_windows("elenca_unita")
    return [dati_unita(u, *nativo.info_unita(u)) for u in nativo.unita()]


def info_unita(unita: str) -> dict:
    richiedi_windows("info_unita")
    u = normalizza_unita(unita)
    tipo, etichetta, fs, totale, libero = nativo.info_unita(u)
    if tipo in (0, 1) and totale is None:
        raise ErroreValore(f"L'unità `{u}` non esiste su questo computer.",
                           suggerimento="Per vedere le unità presenti usa `elenca_unita()`.")
    return dati_unita(u, tipo, etichetta, fs, totale, libero)


# --- rete ----------------------------------------------------------------------------------

def risolvi_indirizzo(indirizzo: str) -> str:
    try:
        return socket.gethostbyname(indirizzo)
    except (OSError, UnicodeError, ValueError):
        raise ErroreFile(f"Non trovo l'indirizzo `{indirizzo}`.",
                         suggerimento="Controlla di averlo scritto bene (per esempio \"www.google.it\" "
                                      "o \"192.168.1.1\") e che la rete funzioni.") from None


def ping(indirizzo: str, volte: int, tempo_massimo: float) -> dict:
    richiedi_windows("invia_ping")
    ip = risolvi_indirizzo(indirizzo)
    tempi = nativo.ping(ip, volte, max(1, int(tempo_massimo * 1000)))
    return riepilogo_ping(indirizzo, ip, tempi)


def schede_di_rete() -> list[dict]:
    richiedi_windows("schede_di_rete")
    risultato = []
    for d in nativo.schede_rete():
        stato = _testo(d.get("s")).lower()
        risultato.append({
            "nome": _testo(d.get("n")),
            "descrizione": _testo(d.get("d")),
            "stato": {"up": "connessa", "disconnected": "scollegata", "disabled": "disattivata"}.get(stato, stato),
            "connessa": stato == "up",
            "mac": _testo(d.get("m")).replace("-", ":"),
            "velocita": _testo(d.get("v")),
        })
    return risultato


# --- stampanti -----------------------------------------------------------------------------

def elenca_stampanti() -> list[dict]:
    richiedi_windows("elenca_stampanti")
    return [{
        "nome": _testo(d.get("n")),
        "predefinita": bool(d.get("d")),
        "in_linea": not bool(d.get("o")),
        "porta": _testo(d.get("p")),
        "driver": _testo(d.get("r")),
        "condivisa": bool(d.get("c")),
    } for d in nativo.stampanti()]


# --- registro --------------------------------------------------------------------------------

def leggi_registro(chiave: str, nome: str) -> Any:
    richiedi_windows("leggi_registro")
    radice, sotto = dividi_chiave(chiave)
    letto = nativo.reg_leggi(radice, sotto, nome)
    if letto is None:
        return None
    return valore_da_registro(*letto)


def elenca_valori_registro(chiave: str) -> dict:
    richiedi_windows("elenca_valori_registro")
    radice, sotto = dividi_chiave(chiave)
    return {nome: valore_da_registro(valore, tipo) for nome, valore, tipo in nativo.reg_valori(radice, sotto)}


def scrivi_registro(chiave: str, nome: str, valore: Any) -> None:
    radice, sotto = controlla_scrittura(chiave)
    dato, tipo = valore_per_registro(valore)
    nativo.reg_scrivi(radice, sotto, nome, dato, tipo)


# --- servizi -----------------------------------------------------------------------------------

def elenca_servizi() -> list[dict]:
    richiedi_windows("elenca_servizi")
    return sorted((servizio_da_json(d) for d in nativo.servizi()), key=lambda s: s["nome"].lower())


def trova_servizio(nome: str) -> dict:
    richiedi_windows("stato_servizio")
    nome = controlla_nome_servizio(nome)
    trovati = [servizio_da_json(d) for d in nativo.servizi(nome)]
    for s in trovati:
        if s["nome"].lower() == nome.lower() or s["nome_visualizzato"].lower() == nome.lower():
            return s
    if trovati:
        return trovati[0]
    raise ErroreValore(f"Il servizio `{nome}` non esiste su questo computer.",
                       suggerimento="Usa il nome breve (per esempio \"Spooler\"); l'elenco lo dà `elenca_servizi()`.")


# --- utente, orologio, caratteri --------------------------------------------------------------------

def nome_utente() -> str:
    try:
        return getpass.getuser()
    except Exception:  # noqa: BLE001 - getpass puo' fallire senza variabili d'ambiente
        return os.environ.get("USERNAME") or os.environ.get("USER") or ""


def info_sessione() -> dict:
    richiedi_windows("info_sessione")
    return {
        "utente": nome_utente(),
        "dominio": os.environ.get("USERDOMAIN", ""),
        "computer": socket.gethostname(),
        "amministratore": nativo.e_amministratore(),
        "sessione_remota": nativo.sessione_remota(),
        "cartella_profilo": os.environ.get("USERPROFILE", os.path.expanduser("~")),
    }


def fuso_orario() -> dict:
    ora = time.localtime()
    legale = ora.tm_isdst > 0
    scarto = -(time.altzone if legale else time.timezone)
    nome = time.tzname[1 if legale else 0] if time.tzname else ""
    risultato = {"nome": nome, "scarto_ore": round(scarto / 3600, 2), "ora_legale": legale, "id": ""}
    if e_windows():
        try:
            letto = nativo.reg_leggi("HKEY_LOCAL_MACHINE",
                                     "SYSTEM\\CurrentControlSet\\Control\\TimeZoneInformation", "TimeZoneKeyName")
            if letto:
                risultato["id"] = str(valore_da_registro(*letto)).strip("\0 ")
        except Exception:  # noqa: BLE001 - l'id e' solo un dettaglio in piu'
            pass
    return risultato


def ora_utc() -> datetime.datetime:
    return datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None, microsecond=0)


def sincronizzazione_ora() -> dict:
    richiedi_windows("sincronizzazione_ora")
    base = "SYSTEM\\CurrentControlSet\\Services\\W32Time\\Parameters"
    tipo = nativo.reg_leggi("HKEY_LOCAL_MACHINE", base, "Type")
    server = nativo.reg_leggi("HKEY_LOCAL_MACHINE", base, "NtpServer")
    tipo_t = str(valore_da_registro(*tipo)) if tipo else ""
    server_t = str(valore_da_registro(*server)) if server else ""
    servizio = ""
    try:
        servizio = trova_servizio("W32Time")["stato"]
    except Exception:  # noqa: BLE001 - lo stato del servizio e' facoltativo
        pass
    return {
        "attiva": bool(tipo_t) and tipo_t.lower() != "nosync",
        "tipo": tipo_t,
        "server": [s.split(",")[0] for s in server_t.split() if s.split(",")[0]],
        "servizio": servizio,
    }


CHIAVE_CARATTERI = "SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Fonts"


def elenca_caratteri() -> list[str]:
    richiedi_windows("elenca_caratteri")
    nomi: set[str] = set()
    for radice in ("HKEY_LOCAL_MACHINE", "HKEY_CURRENT_USER"):
        try:
            valori = nativo.reg_valori(radice, CHIAVE_CARATTERI)
        except ErroreChiave:
            continue
        for voce, _valore, _tipo in valori:
            nomi.update(nome_carattere(voce))
    return sorted(nomi, key=str.lower)


# --- hardware ----------------------------------------------------------------------------------------

def info_processore() -> dict:
    richiedi_windows("info_processore")
    elenco = nativo.processore()
    if not elenco:
        raise ErroreValore("Windows non mi dà informazioni sul processore.")
    d = elenco[0]
    return {
        "nome": " ".join(_testo(d.get("n")).split()),
        "produttore": _testo(d.get("p")),
        "core": sum(_intero(x.get("c"), 0) or 0 for x in elenco),
        "processori_logici": sum(_intero(x.get("l"), 0) or 0 for x in elenco),
        "frequenza_mhz": _intero(d.get("f"), 0) or 0,
        "bit": _intero(d.get("a"), 0) or 0,
        "processori": len(elenco),
    }


def info_scheda_madre() -> dict:
    richiedi_windows("info_scheda_madre")
    elenco = nativo.scheda_madre()
    d = elenco[0] if elenco else {}
    return {
        "produttore": _testo(d.get("p")),
        "modello": _testo(d.get("m")),
        "versione": _testo(d.get("v")),
        "bios_produttore": _testo(d.get("bp")),
        "bios_versione": _testo(d.get("bv")),
    }


def info_schede_video() -> list[dict]:
    richiedi_windows("info_schede_video")
    risultato = []
    for d in nativo.schede_video():
        x, y = _intero(d.get("x")), _intero(d.get("y"))
        risultato.append({
            "nome": _testo(d.get("n")),
            "produttore": _testo(d.get("p")),
            "memoria": _intero(d.get("m"), 0) or 0,
            "driver": _testo(d.get("d")),
            "risoluzione": f"{x}x{y}" if x and y else "",
            "frequenza_hz": _intero(d.get("f"), 0) or 0,
        })
    return risultato


def info_computer() -> dict:
    richiedi_windows("info_computer")
    elenco = nativo.computer()
    d = elenco[0] if elenco else {}
    return {
        "nome": socket.gethostname(),
        "produttore": _testo(d.get("p")),
        "modello": _testo(d.get("m")),
        "tipo": _testo(d.get("t")),
        "memoria": _intero(d.get("r"), 0) or 0,
        "sistema_operativo": _testo(d.get("s")),
        "versione": _testo(d.get("v")),
        "architettura": _testo(d.get("a")),
    }


def dispositivi_usb() -> list[dict]:
    richiedi_windows("dispositivi_usb")
    risultato = []
    for d in nativo.usb():
        nome = _testo(d.get("n"))
        if not nome:
            continue
        stato = _testo(d.get("s")).lower()
        risultato.append({
            "nome": nome,
            "classe": _testo(d.get("c")),
            "stato": {"ok": "funzionante", "error": "errore", "degraded": "problemi",
                      "unknown": "sconosciuto"}.get(stato, stato),
            "id": _testo(d.get("i")),
        })
    return sorted(risultato, key=lambda x: x["nome"].lower())
