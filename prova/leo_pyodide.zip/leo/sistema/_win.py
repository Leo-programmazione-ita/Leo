"""Aiuti comuni per parlare con Windows (usati da S1, S2 e S3).

Niente qui chiama Windows al momento dell'importazione: le DLL si caricano
alla prima richiesta con :func:`dll`, e su Linux/macOS le funzioni che servono
solo su Windows si fermano con :func:`solo_windows` e un messaggio chiaro.

Contenuto:

* :class:`ErroreSistema` - errore italiano per i problemi di Windows; per il
  programma Leo e' un ``ErroreValore`` (si cattura con ``cattura ErroreValore``);
* :func:`e_windows`, :func:`solo_windows`;
* :func:`dll`, :func:`errore_windows` (con il codice di ``GetLastError``);
* :func:`chiedi_conferma` - domanda Si'/No all'utente del programma (finestra
  se c'e' la grafica, altrimenti nel terminale);
* :func:`letterale_ps`, :func:`esegui_powershell`, :data:`SENZA_FINESTRA`;
* :func:`decodifica_uscita` - testo dall'uscita grezza di un comando.

Per i test: :data:`SOSTITUTI` permette di rimpiazzare ``e_windows`` senza
toccare ``os.name`` (``_win.SOSTITUTI["windows"] = True``).
"""

from __future__ import annotations

import base64
import os
import subprocess
from typing import Any

from ..errori import ErroreValore

#: Flag di ``subprocess`` per non far apparire la finestra nera della console.
SENZA_FINESTRA = 0x08000000  # CREATE_NO_WINDOW

#: Sostituti usati dai test (vuoto = comportamento reale).
SOSTITUTI: dict[str, Any] = {}


class ErroreSistema(ErroreValore):
    """Un'operazione di Windows non e' riuscita (messaggio in italiano).

    Per il programma Leo il tipo e' ``ErroreValore``: cosi' si cattura con
    ``cattura ErroreValore come e`` come gli altri errori della libreria.
    ``codice`` e' il codice di errore di Windows, se c'e'.
    """

    def __init__(self, messaggio: str = "", *args: Any, codice: int | None = None, **kw: Any) -> None:
        super().__init__(messaggio, *args, **kw)
        self.codice = codice

    @property
    def tipo(self) -> str:  # visto da Leo come ErroreValore
        return "ErroreValore"


def e_windows() -> bool:
    """Vero se il programma gira su Windows (i test possono fingere)."""
    if "windows" in SOSTITUTI:
        return bool(SOSTITUTI["windows"])
    return os.name == "nt"


def solo_windows(nome_funzione: str) -> None:
    """Si ferma con un errore chiaro se non siamo su Windows (su Android: "non è disponibile su Android")."""
    if not e_windows():
        from ..piattaforma import MESSAGGIO_ANDROID, SUGGERIMENTO_ANDROID, e_android

        if e_android():
            raise ErroreSistema(MESSAGGIO_ANDROID.format(nome=nome_funzione), suggerimento=SUGGERIMENTO_ANDROID)
        raise ErroreSistema(f"`{nome_funzione}` funziona solo su Windows.",
                            suggerimento="Questa funzione usa parti di Windows che su questo sistema non ci sono. "
                                         "Prova il programma su un computer con Windows.")


_DLL: dict[str, Any] = {}


def dll(nome: str):  # pragma: no cover - solo su Windows
    """La DLL di Windows ``nome`` (``"user32"``, ``"kernel32"``...), caricata una volta sola."""
    if nome not in _DLL:
        import ctypes

        try:
            _DLL[nome] = ctypes.WinDLL(nome, use_last_error=True)
        except (OSError, AttributeError) as e:
            raise ErroreSistema(f"Non riesco a caricare la parte di Windows `{nome}`.",
                                suggerimento=str(e)) from None
    return _DLL[nome]


#: Codici di errore di Windows piu' comuni, spiegati.
MOTIVI_WINDOWS = {
    2: "il file non è stato trovato",
    3: "il percorso non è stato trovato",
    5: "accesso negato (servono permessi che il programma non ha)",
    6: "l'oggetto di Windows non è valido",
    32: "il file è usato da un altro programma",
    87: "un parametro non è valido",
    1223: "l'operazione è stata annullata",
    1460: "è scaduto il tempo",
}


def spiega_codice(codice: int) -> str:
    """Spiegazione italiana di un codice di errore di Windows."""
    return MOTIVI_WINDOWS.get(codice, f"errore di Windows numero {codice}")


def errore_windows(azione: str, codice: int | None = None, suggerimento: str | None = None) -> ErroreSistema:
    """``ErroreSistema`` per "non sono riuscito a <azione>", con il motivo di Windows.

    Se ``codice`` e' None si usa ``ctypes.get_last_error()`` (su Windows).
    """
    if codice is None:
        try:
            import ctypes

            codice = ctypes.get_last_error()
        except (ImportError, AttributeError):  # pragma: no cover
            codice = 0
    motivo = spiega_codice(codice) if codice else "Windows non ha detto il motivo"
    return ErroreSistema(f"Non sono riuscito a {azione}: {motivo}.", suggerimento=suggerimento, codice=codice or None)


# ---------------------------------------------------------------------------
# Conferma all'utente
# ---------------------------------------------------------------------------

def chiedi_conferma(interprete: Any, testo: str, titolo: str = "Leo - conferma") -> bool:
    """Chiede Si'/No all'utente del programma; ``True`` solo se risponde Si'.

    Con la grafica appare una finestra di dialogo (``ponte_grafico.domanda``),
    altrimenti la domanda si fa nel terminale. Senza interprete, o se non si
    puo' chiedere (fine dell'ingresso), la risposta e' No: per le azioni
    pericolose il silenzio non e' un consenso.
    """
    if "conferma" in SOSTITUTI:
        return bool(SOSTITUTI["conferma"](testo))
    if interprete is None:
        return False
    try:
        from ..libreria.grafica import _ponte

        return bool(_ponte(interprete).domanda(testo, titolo))
    except ErroreValore:
        return False


# ---------------------------------------------------------------------------
# PowerShell e comandi
# ---------------------------------------------------------------------------

def letterale_ps(testo: str) -> str:
    """Testo come letterale PowerShell sicuro (tra apici singoli, apici raddoppiati)."""
    return "'" + str(testo).replace("'", "''") + "'"


def comando_powershell(script: str) -> list[str]:
    """La riga di comando per eseguire ``script`` (codificato: niente problemi di virgolette).

    L'uscita e' forzata in UTF-8 cosi' le lettere accentate arrivano intatte.
    """
    completo = "[Console]::OutputEncoding = [System.Text.Encoding]::UTF8\n$ProgressPreference = 'SilentlyContinue'\n" + script
    codificato = base64.b64encode(completo.encode("utf-16-le")).decode("ascii")
    return ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
            "-EncodedCommand", codificato]


def esegui_powershell(script: str, tempo_massimo: float = 30) -> tuple[str, str, int]:
    """Esegue uno script PowerShell senza finestra; restituisce (uscita, errore, codice).

    Per uso interno delle librerie (i programmi Leo usano ``esegui_powershell`` della
    libreria, che chiede conferma). ``ErroreSistema`` se PowerShell non parte o se
    supera ``tempo_massimo`` secondi.
    """
    if "powershell" in SOSTITUTI:
        return SOSTITUTI["powershell"](script)
    solo_windows("PowerShell")
    try:  # pragma: no cover - solo su Windows
        r = subprocess.run(comando_powershell(script), capture_output=True, timeout=tempo_massimo,
                           creationflags=SENZA_FINESTRA, stdin=subprocess.DEVNULL)
    except FileNotFoundError:  # pragma: no cover
        raise ErroreSistema("PowerShell non si trova su questo computer.") from None
    except subprocess.TimeoutExpired:  # pragma: no cover
        raise ErroreSistema(f"PowerShell non ha risposto entro {tempo_massimo:g} secondi.") from None
    return decodifica_uscita(r.stdout), decodifica_uscita(r.stderr), r.returncode  # pragma: no cover


def _codifica_oem() -> str | None:  # pragma: no cover - dipende dal sistema
    if os.name != "nt":
        return None
    try:
        import ctypes

        return f"cp{ctypes.windll.kernel32.GetOEMCP()}"
    except (OSError, AttributeError):
        return None


def decodifica_uscita(dati: bytes | str | None) -> str:
    """Testo dall'uscita di un comando: UTF-8, altrimenti la codifica della console (cp850), altrimenti cp1252.

    I ritorni a capo di Windows (``\\r\\n``) diventano ``\\n``.
    """
    if dati is None:
        return ""
    if isinstance(dati, str):
        testo = dati
    else:
        if dati.startswith(b"\xff\xfe"):
            testo = dati[2:].decode("utf-16-le", errors="replace")
        else:
            try:
                testo = dati.decode("utf-8")
            except UnicodeDecodeError:
                testo = None
                oem = _codifica_oem()
                for codifica in ([oem] if oem else []) + ["cp1252"]:
                    try:
                        testo = dati.decode(codifica)
                        break
                    except (UnicodeDecodeError, LookupError):
                        continue
                if testo is None:  # pragma: no cover
                    testo = dati.decode("utf-8", errors="replace")
    if testo.startswith("﻿"):
        testo = testo[1:]
    return testo.replace("\r\n", "\n")
