"""Parte nativa della libreria "sistema" di Leo (S1): tutto quello che parla con Windows.

Le funzioni visibili dai programmi Leo sono in ``leo/libreria/sistema.py``: li'
ci sono i controlli sui parametri, le conferme e i messaggi. Qui ci sono solo:

* la classe :class:`Nativo`, un metodo per ogni chiamata a Windows (ctypes,
  winreg, subprocess, PowerShell senza finestra). L'istanza in uso e'
  :data:`nativo`; i test la sostituiscono con un finto (``programmi.nativo = Finto()``);
* funzioni pure (senza Windows) che preparano o interpretano i dati:
  :func:`componi_versione`, :func:`normalizza_architettura`, :func:`durata_leggibile`,
  :func:`espandi_variabili`, :func:`uri_impostazioni`, :func:`valore_avvio`,
  :func:`script_crea_collegamento`, :func:`script_leggi_collegamenti`...

Tutti i metodi di :class:`Nativo` che toccano Windows chiamano prima
``solo_windows(...)``: su Linux l'errore e' chiaro e in italiano.
"""

from __future__ import annotations

import datetime
import getpass
import json
import os
import platform
import re
import shlex
import subprocess
import sys
import tempfile
import time
from typing import Any

from ._win import (SENZA_FINESTRA, ErroreSistema, decodifica_uscita, dll, e_windows, errore_windows,
                   esegui_powershell, letterale_ps, solo_windows)

# ===========================================================================
# Dati e funzioni pure (provate anche su Linux)
# ===========================================================================

#: Cartelle note di Windows (KNOWNFOLDERID) per nome italiano.
CARTELLE_NOTE = {
    "desktop": "B4BFCC3A-DB2C-424C-B029-7FE99A87C641",
    "documenti": "FDD39AD0-238F-46AF-ADB4-6C85480369C7",
    "download": "374DE290-123F-4565-9164-39C4925E467B",
    "immagini": "33E28130-4E1E-4676-835A-98395C3BC3BB",
    "musica": "4BD8D571-6D19-48D3-BE97-422220080E43",
    "video": "18989B1D-99B5-455B-841C-AB7C74E4DDFC",
    "appdata": "3EB685DB-65F9-4CF6-A03A-E3EF65729F3D",
    "appdata_locale": "F1B32785-6FBA-4FCF-9D55-7B8E7F157091",
    "programmi": "905E63B6-C1BF-494E-B29C-65B732D3D21A",
    "programmi_x86": "7C5A40EF-A0FB-4BFC-874A-C0F2E0B9FA8E",
    "menu_start": "625B53C3-AB48-4EC1-BA1F-A1EF4146FC19",
    "programmi_menu_start": "A77F5D77-2E2B-44C3-A6A2-ABA601054A51",
    "esecuzione_automatica": "B97D20BB-F46A-4C97-BA10-5E3608430854",
    "recenti": "AE50C081-EBD2-438A-8655-8A092E34987A",
    "preferiti": "1777F761-68AD-4D8A-87BD-30B759FA33DD",
    "modelli": "A63293E8-664E-48DB-A079-DF759E0509F7",
}

#: Altri nomi accettati da ``cartella_speciale`` -> nome canonico.
SINONIMI_CARTELLE = {
    "scrivania": "desktop", "documents": "documenti", "downloads": "download", "scaricati": "download",
    "foto": "immagini", "pictures": "immagini", "music": "musica", "videos": "video", "filmati": "video",
    "dati_applicazioni": "appdata", "roaming": "appdata", "localappdata": "appdata_locale",
    "locale": "appdata_locale", "program_files": "programmi", "start": "menu_start",
    "esecuzione_automatica_utente": "esecuzione_automatica", "esecuzione": "esecuzione_automatica",
    "recent": "recenti", "temp": "temporanea", "tmp": "temporanea", "temporanei": "temporanea",
    "casa": "casa", "home": "casa", "utente": "casa", "personale": "casa",
}

#: Ripieghi fuori da Windows (o se SHGetKnownFolderPath fallisce): (variabile d'ambiente, sottocartelle).
_RIPIEGHI = {
    "appdata": ("APPDATA", None), "appdata_locale": ("LOCALAPPDATA", None),
    "programmi": ("ProgramFiles", None), "programmi_x86": ("ProgramFiles(x86)", None),
    "desktop": (None, "Desktop"), "documenti": (None, "Documents"), "download": (None, "Downloads"),
    "immagini": (None, "Pictures"), "musica": (None, "Music"), "video": (None, "Videos"),
}


def nomi_cartelle_speciali() -> list[str]:
    """I nomi accettati da ``cartella_speciale`` (canonici)."""
    return sorted(set(CARTELLE_NOTE) | {"temporanea", "casa"})


def normalizza_nome_cartella(nome: str) -> str | None:
    n = re.sub(r"[\s\-]+", "_", nome.strip().lower())
    n = SINONIMI_CARTELLE.get(n, n)
    return n if n in CARTELLE_NOTE or n in ("temporanea", "casa") else None


def ripiego_cartella(chiave: str) -> str | None:
    """Percorso della cartella speciale senza API di Windows (variabili d'ambiente o cartella personale)."""
    if chiave == "casa":
        return os.path.expanduser("~")
    if chiave == "temporanea":
        return tempfile.gettempdir()
    variabile, sotto = _RIPIEGHI.get(chiave, (None, None))
    if variabile:
        valore = os.environ.get(variabile)
        return valore or None
    if sotto:
        try:
            from ..libreria.cartelle import _speciale

            if chiave in ("desktop", "documenti", "download"):
                return _speciale(chiave)
        except (ImportError, KeyError):  # pragma: no cover
            pass
        return os.path.join(os.path.expanduser("~"), sotto)
    return None


def componi_versione(dati: dict) -> dict:
    """Dal ramo del registro ``HKLM\\...\\Windows NT\\CurrentVersion`` al dizionario di ``info_windows``.

    Windows 11 scrive ancora "Windows 10" in ``ProductName``: si corregge con il
    numero di build (dalla 22000 in poi e' Windows 11).
    """
    nome = str(dati.get("ProductName") or "Windows")
    try:
        build = int(str(dati.get("CurrentBuildNumber") or dati.get("CurrentBuild") or 0))
    except ValueError:
        build = 0
    if build >= 22000 and "Windows 10" in nome:
        nome = nome.replace("Windows 10", "Windows 11")
    aggiornamento = dati.get("UBR")
    versione = str(dati.get("DisplayVersion") or dati.get("ReleaseId") or "")
    build_completa = f"{build}.{aggiornamento}" if build and aggiornamento is not None else (str(build) if build else "")
    return {
        "nome": nome,
        "versione": versione,
        "build": build_completa,
        "edizione": str(dati.get("EditionID") or ""),
        "numero": 11 if build >= 22000 else (10 if build >= 10240 else 0),
    }


def descrivi_versione(info: dict) -> str:
    """"Windows 11 Pro 23H2 (build 22631.3447)"."""
    testo = info.get("nome") or "Windows"
    if info.get("versione"):
        testo += f" {info['versione']}"
    if info.get("build"):
        testo += f" (build {info['build']})"
    return testo


def normalizza_architettura(macchina: str) -> str:
    """"AMD64" -> "x64", "ARM64"/"aarch64" -> "ARM64", "x86"/"i686" -> "x86"."""
    m = (macchina or "").strip().lower()
    if m in ("amd64", "x86_64", "x64", "em64t"):
        return "x64"
    if m in ("arm64", "aarch64", "armv8", "arm64ec"):
        return "ARM64"
    if m in ("x86", "i386", "i486", "i586", "i686"):
        return "x86"
    if m.startswith("arm"):
        return "ARM"
    return macchina or "sconosciuta"


def durata_leggibile(secondi: int | float) -> str:
    """3 giorni, 2 ore e 5 minuti (i secondi solo se e' meno di un minuto)."""
    s = max(0, int(secondi))
    giorni, s = divmod(s, 86400)
    ore, s = divmod(s, 3600)
    minuti, s = divmod(s, 60)
    parti = []
    for valore, uno, tanti in ((giorni, "giorno", "giorni"), (ore, "ora", "ore"), (minuti, "minuto", "minuti")):
        if valore:
            parti.append(f"{valore} {uno if valore == 1 else tanti}")
    if not parti:
        return f"{s} {'secondo' if s == 1 else 'secondi'}"
    return parti[0] if len(parti) == 1 else ", ".join(parti[:-1]) + " e " + parti[-1]


_VARIABILE = re.compile(r"%([^%\s][^%]*)%")


def espandi_variabili(testo: str, ambiente: dict[str, str] | None = None, *, maiuscole_uguali: bool | None = None) -> str:
    """Sostituisce ``%NOME%`` con il valore della variabile d'ambiente (le sconosciute restano come sono)."""
    amb = dict(os.environ if ambiente is None else ambiente)
    if maiuscole_uguali is None:
        maiuscole_uguali = os.name == "nt"
    if maiuscole_uguali:
        amb = {k.upper(): v for k, v in amb.items()}

    def sostituisci(m: re.Match) -> str:
        nome = m.group(1).upper() if maiuscole_uguali else m.group(1)
        return amb.get(nome, m.group(0))

    return _VARIABILE.sub(sostituisci, testo)


#: Sezioni delle Impostazioni di Windows: nome italiano -> pagina "ms-settings:".
SEZIONI_IMPOSTAZIONI = {
    "home": "",
    "sistema": "system",
    "schermo": "display",
    "suoni": "sound",
    "notifiche": "notifications",
    "alimentazione": "powersleep",
    "batteria": "batterysaver",
    "archiviazione": "storagesense",
    "informazioni": "about",
    "bluetooth": "bluetooth",
    "dispositivi": "connecteddevices",
    "stampanti": "printers",
    "mouse": "mousetouchpad",
    "touchpad": "devices-touchpad",
    "rete": "network",
    "wifi": "network-wifi",
    "ethernet": "network-ethernet",
    "vpn": "network-vpn",
    "proxy": "network-proxy",
    "modalita_aereo": "network-airplanemode",
    "personalizzazione": "personalization",
    "sfondo": "personalization-background",
    "colori": "personalization-colors",
    "temi": "themes",
    "schermata_blocco": "lockscreen",
    "barra_applicazioni": "taskbar",
    "app": "appsfeatures",
    "app_predefinite": "defaultapps",
    "app_avvio": "startupapps",
    "account": "yourinfo",
    "opzioni_accesso": "signinoptions",
    "data_ora": "dateandtime",
    "lingua": "regionlanguage",
    "tastiera": "typing",
    "giochi": "gaming-gamebar",
    "accessibilita": "easeofaccess",
    "privacy": "privacy",
    "posizione": "privacy-location",
    "fotocamera": "privacy-webcam",
    "microfono": "privacy-microphone",
    "aggiornamenti": "windowsupdate",
    "sicurezza": "windowsdefender",
    "backup": "backup",
    "ripristino": "recovery",
    "attivazione": "activation",
}


def uri_impostazioni(sezione: str) -> str | None:
    """"wifi" -> "ms-settings:network-wifi"; accetta anche "ms-settings:..." e le pagine inglesi."""
    s = sezione.strip()
    if s.lower().startswith("ms-settings:"):
        pagina = s[len("ms-settings:"):]
        return "ms-settings:" + pagina if re.fullmatch(r"[A-Za-z0-9\-_.]*", pagina) else None
    chiave = re.sub(r"[\s\-]+", "_", s.lower()).replace("à", "a").replace("è", "e").replace("é", "e")
    chiave = chiave.replace("ì", "i").replace("ò", "o").replace("ù", "u").replace("'", "")
    if chiave in SEZIONI_IMPOSTAZIONI:
        return "ms-settings:" + SEZIONI_IMPOSTAZIONI[chiave]
    if re.fullmatch(r"[a-z0-9\-]+", s.lower()) and s.lower() in SEZIONI_IMPOSTAZIONI.values():
        return "ms-settings:" + s.lower()
    return None


def valore_avvio(programma: str, argomenti: str = "") -> str:
    """Il valore da scrivere in ``HKCU\\...\\Run``: percorso tra virgolette + argomenti."""
    percorso = programma.strip().strip('"')
    valore = f'"{percorso}"'
    if argomenti.strip():
        valore += " " + argomenti.strip()
    return valore


def riga_di_comando(programma: str, argomenti: list[str]) -> str:
    """La riga di comando come la vedrebbe l'utente (per i messaggi e le conferme)."""
    if os.name == "nt" or e_windows():
        return subprocess.list2cmdline([programma, *argomenti])
    return shlex.join([programma, *argomenti])


def script_crea_collegamento(percorso_lnk: str, destinazione: str, argomenti: str, cartella_lavoro: str,
                             icona: str, descrizione: str) -> str:
    """Script PowerShell (con WScript.Shell) che crea il collegamento ``percorso_lnk``."""
    righe = [
        "$ws = New-Object -ComObject WScript.Shell",
        f"$c = $ws.CreateShortcut({letterale_ps(percorso_lnk)})",
        f"$c.TargetPath = {letterale_ps(destinazione)}",
    ]
    if argomenti:
        righe.append(f"$c.Arguments = {letterale_ps(argomenti)}")
    if cartella_lavoro:
        righe.append(f"$c.WorkingDirectory = {letterale_ps(cartella_lavoro)}")
    if icona:
        righe.append(f"$c.IconLocation = {letterale_ps(icona)}")
    if descrizione:
        righe.append(f"$c.Description = {letterale_ps(descrizione)}")
    righe.append("$c.Save()")
    return "\n".join(righe)


def script_leggi_collegamenti(percorsi: list[str]) -> str:
    """Script PowerShell che stampa in JSON le informazioni di ogni collegamento."""
    elenco = ", ".join(letterale_ps(p) for p in percorsi) or "''"
    return (
        "$ws = New-Object -ComObject WScript.Shell\n"
        f"$r = @(foreach ($p in @({elenco})) {{ try {{ $c = $ws.CreateShortcut($p); "
        "[pscustomobject]@{p=$p; d=$c.TargetPath; a=$c.Arguments; w=$c.WorkingDirectory; "
        "i=$c.IconLocation; s=$c.Description} } catch { [pscustomobject]@{p=$p; d=''} } })\n"
        "ConvertTo-Json -InputObject $r -Compress"
    )


def leggi_json_ps(testo: str) -> Any:
    testo = testo.strip()
    if not testo:
        return None
    try:
        return json.loads(testo)
    except json.JSONDecodeError:
        raise ErroreSistema("Windows ha risposto in un modo che non capisco.",
                            suggerimento=testo[:200]) from None


#: Processi di Windows che non si possono chiudere (il sistema si bloccherebbe).
PROCESSI_PROTETTI = frozenset({
    "system", "system idle process", "registry", "smss.exe", "csrss.exe", "wininit.exe", "winlogon.exe",
    "services.exe", "lsass.exe", "lsaiso.exe", "svchost.exe", "fontdrvhost.exe", "memory compression",
    "secure system", "dwm.exe", "sgrmbroker.exe", "msmpeng.exe", "nissrv.exe", "securityhealthservice.exe",
})


def stesso_nome_processo(nome_processo: str, cercato: str) -> bool:
    """"notepad" trova "notepad.exe" (maiuscole e ".exe" non contano)."""
    a, b = nome_processo.strip().lower(), cercato.strip().lower()
    return a == b or a == b + ".exe" or (a.endswith(".exe") and a[:-4] == b)


# ===========================================================================
# Chiamate native
# ===========================================================================

_CHIAVE_RUN = r"Software\Microsoft\Windows\CurrentVersion\Run"
_CHIAVE_VERSIONE = r"SOFTWARE\Microsoft\Windows NT\CurrentVersion"


class Nativo:
    """Le chiamate vere a Windows. I test sostituiscono :data:`nativo` con un finto."""

    # ---------------------------------------------------------------- info
    def nome_computer(self) -> str:
        return os.environ.get("COMPUTERNAME") or platform.node() or "sconosciuto"

    def nome_utente(self) -> str:
        try:
            return getpass.getuser()
        except Exception:  # pragma: no cover - ambiente senza utente
            return os.environ.get("USERNAME") or os.environ.get("USER") or "sconosciuto"

    def dati_versione(self) -> dict:  # pragma: no cover - solo su Windows
        solo_windows("versione_windows")
        import winreg

        dati: dict[str, Any] = {}
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, _CHIAVE_VERSIONE) as k:
                for nome in ("ProductName", "DisplayVersion", "ReleaseId", "CurrentBuildNumber",
                             "CurrentBuild", "UBR", "EditionID"):
                    try:
                        dati[nome] = winreg.QueryValueEx(k, nome)[0]
                    except OSError:
                        pass
        except OSError:
            v = sys.getwindowsversion()
            dati = {"ProductName": f"Windows {v.major}", "CurrentBuildNumber": str(v.build)}
        return dati

    def macchina(self) -> str:
        if os.name == "nt":  # pragma: no cover - Python a 32 bit su Windows a 64 bit
            return os.environ.get("PROCESSOR_ARCHITEW6432") or os.environ.get("PROCESSOR_ARCHITECTURE") \
                or platform.machine()
        return platform.machine()

    def secondi_accensione(self) -> float:
        if e_windows():  # pragma: no cover - solo su Windows
            import ctypes

            k = dll("kernel32")
            k.GetTickCount64.restype = ctypes.c_ulonglong
            return k.GetTickCount64() / 1000.0
        try:
            with open("/proc/uptime", encoding="ascii") as f:
                return float(f.read().split()[0])
        except (OSError, ValueError, IndexError):
            return time.monotonic()

    def cartella_nota(self, chiave: str) -> str | None:
        """Percorso di una cartella nota con ``SHGetKnownFolderPath`` (None se non c'e')."""
        if not e_windows() or chiave not in CARTELLE_NOTE:
            return None
        import ctypes  # pragma: no cover - solo su Windows
        from ctypes import wintypes

        class GUID(ctypes.Structure):
            _fields_ = [("Data1", wintypes.DWORD), ("Data2", wintypes.WORD),
                        ("Data3", wintypes.WORD), ("Data4", ctypes.c_ubyte * 8)]

        import uuid

        u = uuid.UUID(CARTELLE_NOTE[chiave])
        g = GUID(u.fields[0], u.fields[1], u.fields[2], (ctypes.c_ubyte * 8)(*u.bytes[8:]))
        p = ctypes.c_wchar_p()
        shell32 = dll("shell32")
        shell32.SHGetKnownFolderPath.argtypes = [ctypes.POINTER(GUID), wintypes.DWORD, wintypes.HANDLE,
                                                 ctypes.POINTER(ctypes.c_wchar_p)]
        shell32.SHGetKnownFolderPath.restype = ctypes.c_long
        esito = shell32.SHGetKnownFolderPath(ctypes.byref(g), 0, None, ctypes.byref(p))
        try:
            return p.value if esito == 0 and p.value else None
        finally:
            ctypes.windll.ole32.CoTaskMemFree(p)

    # ------------------------------------------------------------ processi
    def elenca_processi(self) -> list[dict]:  # pragma: no cover - solo su Windows
        """[{"nome", "pid", "pid_padre", "memoria" (byte, None se non leggibile)}]."""
        solo_windows("elenca_processi")
        import ctypes
        from ctypes import wintypes

        class PROCESSENTRY32W(ctypes.Structure):
            _fields_ = [("dwSize", wintypes.DWORD), ("cntUsage", wintypes.DWORD),
                        ("th32ProcessID", wintypes.DWORD), ("th32DefaultHeapID", ctypes.c_size_t),
                        ("th32ModuleID", wintypes.DWORD), ("cntThreads", wintypes.DWORD),
                        ("th32ParentProcessID", wintypes.DWORD), ("pcPriClassBase", ctypes.c_long),
                        ("dwFlags", wintypes.DWORD), ("szExeFile", ctypes.c_wchar * 260)]

        class PROCESS_MEMORY_COUNTERS(ctypes.Structure):
            _fields_ = [("cb", wintypes.DWORD), ("PageFaultCount", wintypes.DWORD),
                        ("PeakWorkingSetSize", ctypes.c_size_t), ("WorkingSetSize", ctypes.c_size_t),
                        ("QuotaPeakPagedPoolUsage", ctypes.c_size_t), ("QuotaPagedPoolUsage", ctypes.c_size_t),
                        ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                        ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                        ("PagefileUsage", ctypes.c_size_t), ("PeakPagefileUsage", ctypes.c_size_t)]

        k = dll("kernel32")
        k.CreateToolhelp32Snapshot.restype = wintypes.HANDLE
        k.CreateToolhelp32Snapshot.argtypes = [wintypes.DWORD, wintypes.DWORD]
        k.Process32FirstW.argtypes = [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)]
        k.Process32NextW.argtypes = [wintypes.HANDLE, ctypes.POINTER(PROCESSENTRY32W)]
        k.OpenProcess.restype = wintypes.HANDLE
        k.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        k.CloseHandle.argtypes = [wintypes.HANDLE]
        k.K32GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(PROCESS_MEMORY_COUNTERS),
                                              wintypes.DWORD]
        istantanea = k.CreateToolhelp32Snapshot(0x2, 0)  # TH32CS_SNAPPROCESS
        if not istantanea or istantanea == wintypes.HANDLE(-1).value:
            raise errore_windows("leggere l'elenco dei processi")
        risultato = []
        try:
            voce = PROCESSENTRY32W()
            voce.dwSize = ctypes.sizeof(PROCESSENTRY32W)
            ok = k.Process32FirstW(istantanea, ctypes.byref(voce))
            while ok:
                pid = int(voce.th32ProcessID)
                memoria = None
                h = k.OpenProcess(0x1000, False, pid)  # PROCESS_QUERY_LIMITED_INFORMATION
                if h:
                    pmc = PROCESS_MEMORY_COUNTERS()
                    pmc.cb = ctypes.sizeof(PROCESS_MEMORY_COUNTERS)
                    if k.K32GetProcessMemoryInfo(h, ctypes.byref(pmc), pmc.cb):
                        memoria = int(pmc.WorkingSetSize)
                    k.CloseHandle(h)
                risultato.append({"nome": voce.szExeFile, "pid": pid,
                                  "pid_padre": int(voce.th32ParentProcessID), "memoria": memoria})
                ok = k.Process32NextW(istantanea, ctypes.byref(voce))
        finally:
            k.CloseHandle(istantanea)
        return risultato

    def termina(self, pid: int) -> None:  # pragma: no cover - solo su Windows
        solo_windows("termina_processo")
        from ctypes import wintypes

        k = dll("kernel32")
        k.OpenProcess.restype = wintypes.HANDLE
        k.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        k.TerminateProcess.argtypes = [wintypes.HANDLE, wintypes.UINT]
        k.CloseHandle.argtypes = [wintypes.HANDLE]
        h = k.OpenProcess(0x0001, False, pid)  # PROCESS_TERMINATE
        if not h:
            raise errore_windows(f"chiudere il processo {pid}")
        try:
            if not k.TerminateProcess(h, 1):
                raise errore_windows(f"chiudere il processo {pid}")
        finally:
            k.CloseHandle(h)

    # ----------------------------------------------------------- programmi
    def avvia(self, argv: list[str], cartella: str | None) -> Any:  # pragma: no cover - reale
        return subprocess.Popen(argv, cwd=cartella or None, close_fds=True,
                                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

    def apri_predefinito(self, bersaglio: str) -> None:  # pragma: no cover - solo su Windows
        solo_windows("apri_con_programma_predefinito")
        try:
            os.startfile(bersaglio)  # type: ignore[attr-defined]
        except OSError as e:
            raise errore_windows(f"aprire {bersaglio!r}", getattr(e, "winerror", None) or 0) from None

    def apri_esplora(self, argomenti: list[str]) -> None:  # pragma: no cover - solo su Windows
        solo_windows("apri_in_esplora_file")
        cartella_windows = os.environ.get("SystemRoot", r"C:\Windows")
        explorer = os.path.join(cartella_windows, "explorer.exe")
        # explorer vuole "/select,<percorso>" come un unico argomento, senza virgolette interne
        subprocess.Popen(explorer + " " + " ".join(argomenti), close_fds=True)

    def apri_web(self, indirizzo: str) -> bool:
        import webbrowser

        return bool(webbrowser.open(indirizzo))

    def esegui(self, comando: str | list[str], shell: bool, tempo_massimo: float | None,
               cartella: str | None) -> tuple[bytes, bytes, int | None, bool]:  # pragma: no cover - reale
        """Esegue e raccoglie l'uscita: (uscita, errore, codice, scaduto)."""
        windows = os.name == "nt"
        extra: dict[str, Any] = {"creationflags": SENZA_FINESTRA} if windows else {"start_new_session": True}
        p = subprocess.Popen(comando, shell=shell, cwd=cartella or None, stdin=subprocess.DEVNULL,
                             stdout=subprocess.PIPE, stderr=subprocess.PIPE, **extra)
        try:
            uscita, errore = p.communicate(timeout=tempo_massimo)
            return uscita, errore, p.returncode, False
        except subprocess.TimeoutExpired:
            self._chiudi_albero(p)
            try:
                uscita, errore = p.communicate(timeout=5)
            except subprocess.TimeoutExpired:
                uscita, errore = b"", b""
            return uscita, errore, None, True

    @staticmethod
    def _chiudi_albero(p: Any) -> None:  # pragma: no cover - dipende dal sistema
        """Chiude il processo scaduto e i processi che ha avviato (cmd.exe/sh lanciano figli)."""
        try:
            if os.name == "nt":
                subprocess.run(["taskkill", "/F", "/T", "/PID", str(p.pid)], capture_output=True,
                               creationflags=SENZA_FINESTRA, timeout=10)
            else:
                import signal

                os.killpg(p.pid, signal.SIGKILL)
        except (OSError, subprocess.SubprocessError):
            pass
        try:
            p.kill()
        except OSError:
            pass

    # ------------------------------------------------------------- appunti
    def _apri_appunti(self):  # pragma: no cover - solo su Windows
        from ctypes import wintypes

        u = dll("user32")
        u.OpenClipboard.argtypes = [wintypes.HWND]
        for _ in range(10):  # un altro programma puo' tenerli aperti per un attimo
            if u.OpenClipboard(None):
                return u
            time.sleep(0.05)
        raise errore_windows("aprire gli appunti", suggerimento="Un altro programma li sta usando: riprova.")

    def leggi_appunti(self) -> str | None:  # pragma: no cover - solo su Windows
        solo_windows("leggi_appunti")
        import ctypes
        from ctypes import wintypes

        u = self._apri_appunti()
        k = dll("kernel32")
        u.GetClipboardData.restype = wintypes.HANDLE
        k.GlobalLock.restype = ctypes.c_void_p
        k.GlobalLock.argtypes = [wintypes.HGLOBAL]
        k.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
        try:
            h = u.GetClipboardData(13)  # CF_UNICODETEXT
            if not h:
                return None
            p = k.GlobalLock(h)
            if not p:
                return None
            try:
                return ctypes.wstring_at(p)
            finally:
                k.GlobalUnlock(h)
        finally:
            u.CloseClipboard()

    def scrivi_appunti(self, testo: str) -> None:  # pragma: no cover - solo su Windows
        solo_windows("scrivi_appunti")
        import ctypes
        from ctypes import wintypes

        dati = ctypes.create_unicode_buffer(testo)
        dimensione = ctypes.sizeof(dati)
        k = dll("kernel32")
        k.GlobalAlloc.restype = wintypes.HGLOBAL
        k.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
        k.GlobalLock.restype = ctypes.c_void_p
        k.GlobalLock.argtypes = [wintypes.HGLOBAL]
        k.GlobalUnlock.argtypes = [wintypes.HGLOBAL]
        k.GlobalFree.argtypes = [wintypes.HGLOBAL]
        u = self._apri_appunti()
        u.SetClipboardData.restype = wintypes.HANDLE
        u.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]
        try:
            u.EmptyClipboard()
            h = k.GlobalAlloc(0x0002, dimensione)  # GMEM_MOVEABLE
            if not h:
                raise errore_windows("preparare il testo per gli appunti")
            p = k.GlobalLock(h)
            ctypes.memmove(p, dati, dimensione)
            k.GlobalUnlock(h)
            if not u.SetClipboardData(13, h):
                k.GlobalFree(h)
                raise errore_windows("scrivere negli appunti")
        finally:
            u.CloseClipboard()

    def svuota_appunti(self) -> None:  # pragma: no cover - solo su Windows
        solo_windows("svuota_appunti")
        u = self._apri_appunti()
        try:
            if not u.EmptyClipboard():
                raise errore_windows("svuotare gli appunti")
        finally:
            u.CloseClipboard()

    def formato_appunti_presente(self, formato: int) -> bool:  # pragma: no cover - solo su Windows
        solo_windows("appunti")
        return bool(dll("user32").IsClipboardFormatAvailable(formato))

    def salva_immagine_appunti(self, percorso: str) -> bool:  # pragma: no cover - PowerShell
        script = ("Add-Type -AssemblyName System.Windows.Forms, System.Drawing\n"
                  "$i = [System.Windows.Forms.Clipboard]::GetImage()\n"
                  "if ($i -eq $null) { 'NO'; exit 0 }\n"
                  f"$i.Save({letterale_ps(percorso)}, [System.Drawing.Imaging.ImageFormat]::Png)\n'SI'")
        uscita, errore, codice = esegui_powershell(script)
        if codice != 0:
            raise ErroreSistema("Non sono riuscito a salvare l'immagine degli appunti.",
                                suggerimento=errore.strip()[:200] or None)
        return uscita.strip().endswith("SI")

    def copia_file_appunti(self, percorsi: list[str]) -> None:
        elenco = ", ".join(letterale_ps(p) for p in percorsi)
        uscita, errore, codice = esegui_powershell(f"Set-Clipboard -LiteralPath @({elenco})")
        if codice != 0:
            raise ErroreSistema("Non sono riuscito a copiare i file negli appunti.",
                                suggerimento=errore.strip()[:200] or None)

    # ------------------------------------------------------------- cestino
    def info_cestino(self) -> tuple[int, int]:  # pragma: no cover - solo su Windows
        """(elementi, byte) di tutti i cestini."""
        solo_windows("elementi_nel_cestino")
        import ctypes
        from ctypes import wintypes

        class SHQUERYRBINFO(ctypes.Structure):
            if ctypes.sizeof(ctypes.c_void_p) == 4:
                _pack_ = 1
            _fields_ = [("cbSize", wintypes.DWORD), ("i64Size", ctypes.c_longlong),
                        ("i64NumItems", ctypes.c_longlong)]

        info = SHQUERYRBINFO()
        info.cbSize = ctypes.sizeof(SHQUERYRBINFO)
        s = dll("shell32")
        s.SHQueryRecycleBinW.argtypes = [wintypes.LPCWSTR, ctypes.POINTER(SHQUERYRBINFO)]
        s.SHQueryRecycleBinW.restype = ctypes.c_long
        esito = s.SHQueryRecycleBinW(None, ctypes.byref(info))
        if esito != 0:
            raise errore_windows("leggere il cestino", esito & 0xFFFF)
        return int(info.i64NumItems), int(info.i64Size)

    def svuota_cestino(self) -> None:  # pragma: no cover - solo su Windows
        solo_windows("svuota_cestino")
        import ctypes
        from ctypes import wintypes

        s = dll("shell32")
        s.SHEmptyRecycleBinW.argtypes = [wintypes.HWND, wintypes.LPCWSTR, wintypes.DWORD]
        s.SHEmptyRecycleBinW.restype = ctypes.c_long
        esito = s.SHEmptyRecycleBinW(None, None, 0x1 | 0x2 | 0x4)  # senza conferma/progresso/suono
        if esito != 0 and (esito & 0xFFFF) not in (0, 0xFFFF):  # E_UNEXPECTED = cestino gia' vuoto
            raise errore_windows("svuotare il cestino", esito & 0xFFFF)

    # --------------------------------------------------------- collegamenti
    def crea_collegamento(self, percorso_lnk: str, destinazione: str, argomenti: str, cartella_lavoro: str,
                          icona: str, descrizione: str) -> None:
        solo_windows("crea_collegamento")
        _, errore, codice = esegui_powershell(script_crea_collegamento(
            percorso_lnk, destinazione, argomenti, cartella_lavoro, icona, descrizione))
        if codice != 0:
            raise ErroreSistema("Non sono riuscito a creare il collegamento.",
                                suggerimento=errore.strip()[:200] or None)

    def leggi_collegamenti(self, percorsi: list[str]) -> list[dict]:
        solo_windows("info_collegamento")
        if not percorsi:
            return []
        uscita, errore, codice = esegui_powershell(script_leggi_collegamenti(percorsi), tempo_massimo=60)
        if codice != 0:
            raise ErroreSistema("Non sono riuscito a leggere i collegamenti.",
                                suggerimento=errore.strip()[:200] or None)
        dati = leggi_json_ps(uscita)
        if isinstance(dati, dict):
            dati = [dati]
        return [d for d in (dati or []) if isinstance(d, dict)]

    # --------------------------------------------------------- avvio (HKCU)
    def leggi_avvio(self) -> dict[str, str]:  # pragma: no cover - solo su Windows
        solo_windows("programmi_all_avvio")
        import winreg

        risultato: dict[str, str] = {}
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _CHIAVE_RUN) as k:
                i = 0
                while True:
                    try:
                        nome, valore, _tipo = winreg.EnumValue(k, i)
                    except OSError:
                        break
                    risultato[nome] = str(valore)
                    i += 1
        except FileNotFoundError:
            pass
        return risultato

    def scrivi_avvio(self, nome: str, valore: str) -> None:  # pragma: no cover - solo su Windows
        solo_windows("aggiungi_all_avvio")
        import winreg

        try:
            with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER, _CHIAVE_RUN, 0, winreg.KEY_SET_VALUE) as k:
                winreg.SetValueEx(k, nome, 0, winreg.REG_SZ, valore)
        except OSError as e:
            raise errore_windows("aggiungere il programma all'avvio", getattr(e, "winerror", None) or 0) from None

    def togli_avvio(self, nome: str) -> bool:  # pragma: no cover - solo su Windows
        solo_windows("togli_dall_avvio")
        import winreg

        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _CHIAVE_RUN, 0, winreg.KEY_SET_VALUE) as k:
                winreg.DeleteValue(k, nome)
            return True
        except FileNotFoundError:
            return False
        except OSError as e:
            raise errore_windows("togliere il programma dall'avvio", getattr(e, "winerror", None) or 0) from None

    # ----------------------------------------------------------- associazioni
    def associazione(self, estensione: str, cosa: int) -> str | None:  # pragma: no cover - solo su Windows
        """``AssocQueryStringW``: cosa=2 eseguibile, cosa=4 nome del programma."""
        solo_windows("programma_predefinito")
        import ctypes
        from ctypes import wintypes

        s = dll("shlwapi")
        s.AssocQueryStringW.argtypes = [wintypes.DWORD, wintypes.DWORD, wintypes.LPCWSTR, wintypes.LPCWSTR,
                                        wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
        s.AssocQueryStringW.restype = ctypes.c_long
        dimensione = wintypes.DWORD(1024)
        buf = ctypes.create_unicode_buffer(1024)
        esito = s.AssocQueryStringW(0, cosa, estensione, None, buf, ctypes.byref(dimensione))
        if esito != 0 or not buf.value:
            return None
        return buf.value

    # ------------------------------------------------------------- cestino
    def al_cestino(self, percorso: str) -> None:
        """Sposta nel cestino (Windows, macOS o freedesktop) con il codice di ``cartelle.py``."""
        from ..libreria.cartelle import _al_cestino

        _al_cestino(percorso)

    # ----------------------------------------------------------- file recenti
    def cartella_recenti(self) -> str | None:
        percorso = self.cartella_nota("recenti")
        if percorso:  # pragma: no cover - solo su Windows
            return percorso
        appdata = os.environ.get("APPDATA")
        return os.path.join(appdata, "Microsoft", "Windows", "Recent") if appdata else None


class NativoInerte(Nativo):
    """Nativo che non tocca niente: risponde con dati vuoti e non esegue nulla.

    Per i test che chiamano tutte le funzioni della libreria con valori strani
    (niente cestini svuotati, programmi avviati o appunti cambiati per sbaglio).
    """

    def nome_computer(self):
        return "PC-FINTO"

    def nome_utente(self):
        return "utente"

    def dati_versione(self):
        return {"ProductName": "Windows 11 Pro", "CurrentBuildNumber": "22631"}

    def macchina(self):
        return "AMD64"

    def secondi_accensione(self):
        return 0.0

    def cartella_nota(self, chiave):
        return None

    def elenca_processi(self):
        return []

    def termina(self, pid):
        return None

    def avvia(self, argv, cartella):
        import types

        return types.SimpleNamespace(pid=0, wait=lambda timeout=None: 0)

    def apri_predefinito(self, bersaglio):
        return None

    def apri_esplora(self, argomenti):
        return None

    def apri_web(self, indirizzo):
        return True

    def esegui(self, comando, shell, tempo_massimo, cartella):
        return b"", b"", 0, False

    def leggi_appunti(self):
        return None

    def scrivi_appunti(self, testo):
        return None

    def svuota_appunti(self):
        return None

    def formato_appunti_presente(self, formato):
        return False

    def salva_immagine_appunti(self, percorso):
        return False

    def copia_file_appunti(self, percorsi):
        return None

    def info_cestino(self):
        return 0, 0

    def svuota_cestino(self):
        return None

    def al_cestino(self, percorso):
        return None

    def crea_collegamento(self, *argomenti):
        return None

    def leggi_collegamenti(self, percorsi):
        return []

    def leggi_avvio(self):
        return {}

    def scrivi_avvio(self, nome, valore):
        return None

    def togli_avvio(self, nome):
        return False

    def associazione(self, estensione, cosa):
        return None

    def cartella_recenti(self):
        return None


#: L'implementazione in uso (i test la sostituiscono).
nativo = Nativo()


def data_da_timestamp(secondi: float) -> datetime.datetime:
    return datetime.datetime.fromtimestamp(secondi).replace(microsecond=0)
