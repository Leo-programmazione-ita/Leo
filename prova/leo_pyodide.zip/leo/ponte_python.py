"""Ponte verso Python: usare da Leo qualunque libreria Python installata.

    importa python "requests" come rete
    variabile r = rete.prendi("https://esempio.it/dati.json", attesa_massima: 5)
    stampa(r.stato, r.json()["nome"])

    importa python numpy                  # anche senza virgolette
    importa python "os.path" come percorsi

Regole:

* Ogni nome Python resta usabile così com'è (``rete.get``): tutto l'ecosistema
  Python funziona subito. Un file di traduzione facoltativo
  ``ponti/<pacchetto>.toml`` (nel progetto, poi ``dati/ponti`` di Leo) aggiunge
  nomi, parametri e messaggi d'errore in italiano (formato più sotto).
* Valori da Python a Leo: ``None``, logici, interi, decimali e testi restano
  quello che sono (anche le loro sottoclassi e gli scalari di numpy); tuple,
  insiemi e liste diventano liste; dizionari con chiavi testo/intero/logico
  diventano dizionari; ``bytes``/``bytearray`` diventano il tipo ``byte`` (si
  comporta come una lista di numeri da 0 a 255, come ``leggi_binario``); tutto il
  resto resta un ``oggetto python`` usabile col punto, con ``[ ]``, ``per ogni``,
  ``lunghezza``, gli operatori e i confronti.
  Una lista o un dizionario che non ha bisogno di conversioni passa *senza
  copia*: se Python lo modifica (``random.shuffle(lista)``) Leo lo vede.
* Valori da Leo a Python: il contrario; le funzioni Leo diventano funzioni
  Python (callback: ``sorted(lista, key: mia_funzione)``).
* Gli errori Python diventano errori Leo con un messaggio italiano, la riga del
  programma Leo e il dettaglio tecnico (``e.tipo_python``, ``e.dettaglio``).
* I pacchetti si cercano prima nell'ambiente del progetto (``.leo/ambiente``,
  creato da ``leo aggiungi``, vedi :mod:`leo.pacchetti`), poi nel Python di Leo.

Formato di ``ponti/<pacchetto>.toml`` (tutte le sezioni sono facoltative)::

    [modulo]
    descrizione = "Richieste HTTP"

    [nomi]                  # funzioni e classi del modulo: italiano = "python"
    prendi = "get"

    [attributi]             # attributi e metodi degli oggetti
    stato = "status_code"

    [parametri]             # nomi dei parametri (argomenti per nome)
    attesa_massima = "timeout"

    [errori]                # nome della classe d'eccezione = messaggio italiano
    ConnectionError = "Non riesco a collegarmi al server."

    [tipi.Response.attributi]   # come sopra, ma solo per gli oggetti di una classe
    contenuto = "content"

API:
    importa_modulo(nome, cartelle, interprete=None) -> ModuloPython
    a_leo(valore, traduzione) / a_python(valore, interprete)
    errore_da_python(eccezione, traduzione, dove) -> ErroreDante
    carica_traduzione(percorso) -> dict  (ErroreValore se il file è sbagliato)
    attiva_ambiente(cartelle) ; trova_radice_progetto(cartella)
    ModuloPython, OggettoPython, FunzionePython, Byte
"""

from __future__ import annotations

import difflib
import glob
import importlib
import importlib.util
import os
import re
import sys
import types
from typing import Any

from .errori import (ErroreChiave, ErroreDante, ErroreDivisione, ErroreFile, ErroreIndice, ErroreNome,
                     ErroreRicorsione, ErroreTipo, ErroreValore)
from .valori import Richiamabile

#: Cache delle traduzioni per nome del pacchetto radice (``requests``).
_TRADUZIONI: dict[str, dict] = {}
#: Cartelle ``ponti`` dei progetti già attivati (le più recenti prima).
_CARTELLE_PONTI_PROGETTO: list[str] = []
#: Gli ultimi interpreti che hanno importato un modulo Python (per le callback create
#: fuori da una chiamata, per esempio assegnando una funzione Leo a un attributo).
_INTERPRETE: list[Any] = []

_RE_NOME_MODULO = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*)*$")
_SEZIONI_TABELLA = ("nomi", "attributi", "parametri", "errori")
_CHIAVI_PRIMITIVE = (str, int, bool)


# ===========================================================================
# Ambiente del progetto
# ===========================================================================

def trova_radice_progetto(partenza: str | os.PathLike) -> str | None:
    """La cartella con ``progetto.toml`` che contiene ``partenza`` (o None)."""
    cartella = os.path.abspath(os.fspath(partenza))
    if os.path.isfile(cartella):
        cartella = os.path.dirname(cartella)
    while True:
        if os.path.isfile(os.path.join(cartella, "progetto.toml")):
            return cartella
        su = os.path.dirname(cartella)
        if su == cartella:
            return None
        cartella = su


def cartelle_python_progetto(radice: str) -> list[str]:
    """Le cartelle con i pacchetti Python del progetto, in ordine di preferenza.

    * ``.leo/ambiente/.../site-packages`` (sul PC, creata da ``leo aggiungi``):
      solo quella della stessa versione di Python di Leo;
    * ``.leo/python-<impronta>`` (nelle app per il telefono: solo pacchetti puri;
      la più recente se dopo un aggiornamento dell'app ce n'è più di una).
    """
    risultato: list[str] = []
    ambiente = os.path.join(radice, ".leo", "ambiente")
    versione = f"python{sys.version_info.major}.{sys.version_info.minor}"
    for sp in (os.path.join(ambiente, "lib", versione, "site-packages"),
               os.path.join(ambiente, "Lib", "site-packages")):
        if os.path.isdir(sp):
            risultato.append(sp)
    telefono = sorted(glob.glob(os.path.join(radice, ".leo", "python-*")), key=_data_modifica, reverse=True)
    if telefono:
        risultato.append(telefono[0])
    return risultato


def _data_modifica(percorso: str) -> float:
    try:
        return os.path.getmtime(percorso)
    except OSError:
        return 0.0


def ambiente_di_altra_versione(radice: str) -> str | None:
    """La versione di Python dell'ambiente del progetto, se è diversa da quella di Leo."""
    ambiente = os.path.join(radice, ".leo", "ambiente", "lib")
    versione = f"python{sys.version_info.major}.{sys.version_info.minor}"
    altre = [os.path.basename(p) for p in glob.glob(os.path.join(ambiente, "python3*"))]
    if altre and versione not in altre:
        return altre[0].replace("python", "")
    return None


def attiva_ambiente(cartelle: list[str]) -> str | None:
    """Mette in ``sys.path`` i pacchetti del progetto che contiene una delle ``cartelle``.

    Restituisce la radice del progetto trovato (None se non c'è un progetto).
    """
    for c in cartelle:
        radice = trova_radice_progetto(c)
        if radice is None:
            continue
        ponti = os.path.join(radice, "ponti")
        if ponti in _CARTELLE_PONTI_PROGETTO:
            _CARTELLE_PONTI_PROGETTO.remove(ponti)
        else:
            _TRADUZIONI.clear()                 # un progetto nuovo può avere traduzioni sue
        _CARTELLE_PONTI_PROGETTO.insert(0, ponti)
        for sp in reversed(cartelle_python_progetto(radice)):
            if sp not in sys.path:
                _aggiungi_cartella_python(sp)
        return radice
    return None


def _aggiungi_cartella_python(cartella: str) -> None:
    """Come ``site.addsitedir`` (legge i file ``.pth``, che alcuni pacchetti usano, per esempio
    pywin32), ma la cartella del progetto va in testa: le sue versioni hanno la precedenza."""
    import site

    prima = list(sys.path)
    try:
        site.addsitedir(cartella)
    except Exception:  # noqa: BLE001 - un .pth rovinato non deve impedire l'uso del resto
        if cartella not in sys.path:
            sys.path.append(cartella)
    nuove = [p for p in sys.path if p not in prima]
    if cartella not in nuove:
        nuove.insert(0, cartella)
    sys.path[:] = nuove + [p for p in sys.path if p not in nuove]
    importlib.invalidate_caches()


def cartelle_ponti() -> list[str]:
    """Dove si cercano i file di traduzione: progetti attivati, poi ``dati/ponti`` di Leo."""
    cartelle = list(_CARTELLE_PONTI_PROGETTO)
    try:
        from .percorsi import file_dati

        cartelle.append(str(file_dati("ponti")))
    except Exception:  # noqa: BLE001 - dati di Leo non trovati: solo le traduzioni del progetto
        pass
    return cartelle


# ===========================================================================
# Traduzioni
# ===========================================================================

def carica_traduzione(percorso: str | os.PathLike) -> dict:
    """Legge e controlla un file ``ponti/<pacchetto>.toml``."""
    from .tomlutil import ErroreToml, carica_toml

    nome = os.path.basename(os.fspath(percorso))
    try:
        dati = carica_toml(percorso)
    except ErroreToml as e:
        raise ErroreValore(f"Il file di traduzione `{nome}` non è scritto bene: {e}",
                           suggerimento="Controlla le virgolette e le parentesi quadre delle sezioni.") from None
    except OSError as e:
        raise ErroreFile(f"Non riesco a leggere il file di traduzione `{nome}`: {e.strerror or e}.") from None
    _controlla_tabelle(dati, nome, "")
    tipi = dati.get("tipi", {})
    if not isinstance(tipi, dict):
        raise ErroreValore(f"In `{nome}` la sezione `tipi` deve contenere tabelle come `[tipi.Response.attributi]`.")
    for classe, tabelle in tipi.items():
        if not isinstance(tabelle, dict):
            raise ErroreValore(f"In `{nome}` la voce `tipi.{classe}` deve essere una tabella.")
        _controlla_tabelle(tabelle, nome, f"tipi.{classe}.")
    return dati


def _controlla_tabelle(dati: dict, nome: str, prefisso: str) -> None:
    for sezione in _SEZIONI_TABELLA:
        tabella = dati.get(sezione)
        if tabella is None:
            continue
        if not isinstance(tabella, dict):
            raise ErroreValore(f"In `{nome}` la sezione `[{prefisso}{sezione}]` deve essere una tabella.")
        for chiave, valore in tabella.items():
            if not isinstance(valore, str) or not valore:
                raise ErroreValore(f"In `{nome}`, `[{prefisso}{sezione}]`: il valore di `{chiave}` deve essere "
                                   "un testo tra virgolette.",
                                   suggerimento=f"Per esempio `{chiave} = \"nome_python\"`.")


def traduzione(nome_modulo: str) -> dict:
    """La traduzione del pacchetto radice di ``nome_modulo`` (``{}`` se non c'è)."""
    radice = nome_modulo.split(".")[0]
    if radice in _TRADUZIONI:
        return _TRADUZIONI[radice]
    dati: dict = {}
    for cartella in cartelle_ponti():
        f = os.path.join(cartella, radice + ".toml")
        if os.path.isfile(f):
            dati = carica_traduzione(f)
            break
    _TRADUZIONI[radice] = dati
    return dati


def dimentica_traduzioni() -> None:
    """Svuota la cache (dopo aver modificato un file ``ponti/*.toml``)."""
    _TRADUZIONI.clear()


def _tabella(trad: dict, sezione: str, oggetto: Any = None) -> dict:
    """La tabella ``sezione`` della traduzione, con sopra le voci di ``[tipi.<Classe>]``."""
    base = trad.get(sezione) or {}
    tipi = trad.get("tipi")
    if not tipi or oggetto is None:
        return base
    classe = oggetto if isinstance(oggetto, type) else type(oggetto)
    unite = dict(base)
    for c in reversed(getattr(classe, "__mro__", (classe,))):
        extra = (tipi.get(c.__name__) or {}).get(sezione)
        if extra:
            unite.update(extra)
    return unite


# ===========================================================================
# Conversioni
# ===========================================================================

def a_leo(v: Any, trad: dict | None = None) -> Any:
    """Valore Python -> valore Leo (vedi la docstring del modulo)."""
    t = type(v)
    if v is None or t is bool or t is int or t is float or t is str:
        return v
    if t is list:
        convertiti = [a_leo(x, trad) for x in v]
        return v if all(a is b for a, b in zip(convertiti, v)) else convertiti
    if t is dict:
        if not all(type(k) in _CHIAVI_PRIMITIVE for k in v):
            return OggettoPython(v, trad or {})
        convertiti = {k: a_leo(x, trad) for k, x in v.items()}
        return v if all(convertiti[k] is x for k, x in v.items()) else convertiti
    if isinstance(v, (Richiamabile, ErroreDante, _ConAttributi, Byte)):
        return v
    if isinstance(v, bool):
        return bool(v)
    if isinstance(v, int):                       # IntEnum e simili
        return int(v)
    if isinstance(v, float):                     # numpy.float64 è una sottoclasse di float
        return float(v)
    if isinstance(v, str):
        return str(v)
    if isinstance(v, (bytes, bytearray, memoryview)):
        return Byte(bytes(v))
    if t is tuple or isinstance(v, (set, frozenset)):
        return [a_leo(x, trad) for x in v]
    if getattr(v, "ndim", None) == 0 and hasattr(v, "item") and _da_numpy(v):   # numpy.int64, numpy.bool_
        return a_leo(v.item(), trad)
    if isinstance(v, types.ModuleType):
        return ModuloPython(v, traduzione(v.__name__))
    if callable(v) and not isinstance(v, type) and _e_funzione(v):
        return FunzionePython(getattr(v, "__name__", "funzione"), v, trad or {})
    return OggettoPython(v, trad or {})


def _da_numpy(v: Any) -> bool:
    return type(v).__module__.split(".")[0] == "numpy"


def _e_funzione(v: Any) -> bool:
    """Funzioni e metodi veri (non oggetti qualunque che hanno ``__call__``)."""
    return isinstance(v, (types.FunctionType, types.BuiltinFunctionType, types.MethodType,
                          types.BuiltinMethodType, types.MethodWrapperType)) or type(v).__name__ in (
        "partial", "cython_function_or_method", "ufunc", "fused_cython_function")


def a_python(v: Any, interprete: Any = None) -> Any:
    """Valore Leo -> valore Python."""
    t = type(v)
    if v is None or t is bool or t is int or t is float or t is str:
        return v
    if isinstance(v, OggettoPython):
        return v._ogg
    if isinstance(v, ModuloPython):
        return v._mod
    if isinstance(v, Byte):
        return v.dati
    if isinstance(v, FunzionePython):
        return v._f
    if t is list:
        convertiti = [a_python(x, interprete) for x in v]
        return v if all(a is b for a, b in zip(convertiti, v)) else convertiti
    if t is dict:
        convertiti = {k: a_python(x, interprete) for k, x in v.items()}
        return v if all(convertiti[k] is x for k, x in v.items()) else convertiti
    if isinstance(v, range):
        return v
    if isinstance(v, Richiamabile):
        return _richiamo(v, interprete)
    valore_python = getattr(v, "valore_python", None)       # tipi della libreria che sanno convertirsi
    if callable(valore_python):
        try:
            return valore_python()
        except Exception:  # noqa: BLE001
            return v
    return v


def _richiamo(funzione: Richiamabile, interprete: Any) -> Any:
    """Una funzione Leo vista da Python (callback)."""
    if interprete is None and _INTERPRETE:
        interprete = _INTERPRETE[-1]
    if interprete is None:
        raise ErroreValore(f"Non posso passare la funzione `{funzione.nome}` a Python fuori da un programma.")

    def richiamo(*args: Any, **kw: Any) -> Any:
        risultato = interprete.chiama(funzione, [a_leo(a) for a in args], {k: a_leo(x) for k, x in kw.items()})
        return a_python(risultato, interprete)

    richiamo.__name__ = re.sub(r"\W", "_", getattr(funzione, "nome", "funzione_leo")) or "funzione_leo"
    richiamo.__qualname__ = richiamo.__name__
    richiamo.funzione_leo = funzione            # type: ignore[attr-defined]
    return richiamo


# ===========================================================================
# Errori
# ===========================================================================

#: Classe d'eccezione Python -> (classe d'errore Leo, messaggio). ``{dove}`` = nome Leo della funzione.
_ERRORI_NOTI: tuple[tuple[type, type, str], ...] = (
    (RecursionError, ErroreRicorsione, "`{dove}` si è chiamata troppe volte (ricorsione troppo profonda)."),
    (ZeroDivisionError, ErroreDivisione, "Divisione per zero dentro `{dove}`."),
    (KeyError, ErroreChiave, "`{dove}`: la chiave {dettaglio} non esiste."),
    (IndexError, ErroreIndice, "`{dove}`: posizione fuori dai limiti."),
    (FileNotFoundError, ErroreFile, "`{dove}`: il file o la cartella non esiste."),
    (FileExistsError, ErroreFile, "`{dove}`: il file esiste già."),
    (IsADirectoryError, ErroreFile, "`{dove}`: serviva un file, ma è una cartella."),
    (NotADirectoryError, ErroreFile, "`{dove}`: serviva una cartella, ma è un file."),
    (PermissionError, ErroreFile, "`{dove}`: permesso negato dal sistema."),
    (TimeoutError, ErroreValore, "`{dove}`: tempo scaduto, nessuna risposta in tempo."),
    (ConnectionRefusedError, ErroreValore, "`{dove}`: il server ha rifiutato la connessione."),
    (ConnectionError, ErroreValore, "`{dove}`: problema di connessione."),
    (ModuleNotFoundError, ErroreNome, "`{dove}`: manca un pacchetto Python ({dettaglio})."),
    (ImportError, ErroreNome, "`{dove}`: un pacchetto Python non si è caricato."),
    (AttributeError, ErroreNome, "`{dove}`: nome inesistente ({dettaglio})."),
    (UnicodeError, ErroreValore, "`{dove}`: testo con una codifica sbagliata."),
    (OverflowError, ErroreValore, "`{dove}`: numero troppo grande."),
    (MemoryError, ErroreValore, "`{dove}`: memoria esaurita."),
    (NotImplementedError, ErroreValore, "`{dove}`: operazione non disponibile."),
    (TypeError, ErroreTipo, "Argomenti non adatti per `{dove}`."),
    (ValueError, ErroreValore, "Valore non valido per `{dove}`."),
    (OSError, ErroreFile, "`{dove}`: errore del sistema."),
)


def errore_da_python(e: BaseException, trad: dict | None, dove: str) -> ErroreDante:
    """Eccezione Python -> errore Leo (prima la tabella ``[errori]`` della traduzione)."""
    trad = trad or {}
    dettaglio = str(e).strip() or type(e).__name__
    if isinstance(e, KeyError) and e.args:
        dettaglio = repr(e.args[0])
    tipo_python = f"{type(e).__module__}.{type(e).__qualname__}".removeprefix("builtins.")
    messaggi = trad.get("errori", {})
    errore: ErroreDante | None = None
    for classe in type(e).__mro__:
        testo = messaggi.get(classe.__name__) or messaggi.get(f"{classe.__module__}.{classe.__qualname__}")
        if testo:
            classe_leo = next((c for p, c, _m in _ERRORI_NOTI if isinstance(e, p)), ErroreValore)
            try:
                testo = testo.format(dove=dove, dettaglio=dettaglio)
            except (KeyError, IndexError, ValueError):
                pass
            errore = classe_leo(testo)
            break
    if errore is None:
        for classe_python, classe_leo, modello in _ERRORI_NOTI:
            if isinstance(e, classe_python):
                errore = classe_leo(modello.format(dove=dove, dettaglio=dettaglio))
                break
        else:
            errore = ErroreValore(f"`{dove}` non è riuscita ({type(e).__name__}).")
    suggerimento = f"Dettaglio Python ({tipo_python}): {dettaglio}"
    if len(suggerimento) > 600:
        suggerimento = suggerimento[:597] + "..."
    if isinstance(e, ModuleNotFoundError) and getattr(e, "name", None):
        radice = e.name.split(".")[0]
        suggerimento += f"\nPer installarlo nel progetto: `leo aggiungi {nome_distribuzione(radice)}`."
    errore.suggerimento = suggerimento
    errore.tipo_python = tipo_python              # type: ignore[attr-defined]
    errore.dettaglio = dettaglio                  # type: ignore[attr-defined]
    errore.CAMPI_DANTE = ErroreDante.CAMPI_DANTE + ("tipo_python", "dettaglio")   # type: ignore[misc]
    return errore


#: Nome del modulo importato -> nome del pacchetto da installare, quando sono diversi.
_DISTRIBUZIONI = {"PIL": "pillow", "cv2": "opencv-python", "sklearn": "scikit-learn", "bs4": "beautifulsoup4",
                  "yaml": "pyyaml", "dotenv": "python-dotenv", "dateutil": "python-dateutil",
                  "serial": "pyserial", "usb": "pyusb", "Crypto": "pycryptodome", "jwt": "pyjwt",
                  "magic": "python-magic", "docx": "python-docx", "pptx": "python-pptx", "fitz": "pymupdf",
                  "skimage": "scikit-image", "telegram": "python-telegram-bot",
                  "attr": "attrs", "OpenSSL": "pyopenssl", "nacl": "pynacl", "gi": "pygobject", "zmq": "pyzmq",
                  "win32api": "pywin32", "win32com": "pywin32", "wx": "wxpython", "Levenshtein": "levenshtein"}


def nome_distribuzione(modulo: str) -> str:
    """Il nome da usare con ``leo aggiungi`` per il modulo ``modulo``."""
    return _DISTRIBUZIONI.get(modulo, modulo.replace("_", "-").lower())


# ===========================================================================
# Valori del ponte
# ===========================================================================

class FunzionePython(Richiamabile):
    """Una funzione, un metodo o una classe Python chiamabile da Leo."""

    def __init__(self, nome: str, funzione: Any, trad: dict, *, dove: str | None = None) -> None:
        self.nome = nome
        self._f = funzione
        self._trad = trad
        self._dove = dove or nome
        self._parametri: dict | None = None

    def chiama(self, interprete: Any, argomenti: list, argomenti_nome: dict) -> Any:
        parametri = self._parametri
        if parametri is None:
            parametri = self._parametri = _tabella(self._trad, "parametri", getattr(self._f, "__self__", None))
        args = [a_python(a, interprete) for a in argomenti]
        kw = {parametri.get(k, k): a_python(v, interprete) for k, v in argomenti_nome.items()}
        try:
            risultato = self._f(*args, **kw)
        except ErroreDante:
            raise                                  # errore di una callback Leo: resta com'è
        except Exception as e:  # noqa: BLE001 - qualunque errore della libreria diventa un errore Leo
            raise errore_da_python(e, self._trad, self._dove) from e
        return a_leo(risultato, self._trad)

    def valore_python(self) -> Any:
        return self._f

    def testo_dante(self) -> str:
        return f"<funzione python {self._dove}>"


class _ConAttributi:
    """Base di moduli e oggetti Python: attributi col punto, con i nomi tradotti."""

    NOME_TIPO_DANTE = "oggetto python"
    #: Protocollo dell'interprete: ``x.nome`` chiama ``attributo_dante``, ``x.nome = v`` ``scrivi_attributo_dante``.
    ATTRIBUTI_DANTE = True

    _trad: dict

    def _bersaglio(self) -> Any:  # pragma: no cover - ridefinito
        raise NotImplementedError

    def descrivi(self) -> str:  # pragma: no cover - ridefinito
        raise NotImplementedError

    def _nome_vero(self, nome: str) -> str:
        ogg = self._bersaglio()
        prima, dopo = ("nomi", "attributi") if isinstance(self, ModuloPython) else ("attributi", "nomi")
        vero = _tabella(self._trad, prima, ogg).get(nome)
        if vero is None:
            vero = _tabella(self._trad, dopo, ogg).get(nome, nome)
        return vero

    def attributo_dante(self, nome: str) -> Any:
        cache = self.__dict__.get("_cache")
        if cache is not None:
            valore = cache.get(nome)
            if valore is not None:
                return valore
        ogg = self._bersaglio()
        vero = self._nome_vero(nome)
        try:
            valore = getattr(ogg, vero)
        except AttributeError:
            valore = self._attributo_mancante(nome, vero)
        except ErroreDante:
            raise
        except Exception as e:  # noqa: BLE001 - proprietà che sollevano
            raise errore_da_python(e, self._trad, f"{self.descrivi()}.{nome}") from e
        if isinstance(valore, types.ModuleType):
            risultato: Any = ModuloPython(valore, traduzione(valore.__name__))
        elif callable(valore) and not isinstance(valore, (bytes, str)):
            risultato = FunzionePython(nome, valore, self._trad, dove=f"{self.descrivi()}.{nome}")
        else:
            return a_leo(valore, self._trad)
        if cache is not None:
            cache[nome] = risultato
        return risultato

    def _attributo_mancante(self, nome: str, vero: str) -> Any:
        if isinstance(self, ModuloPython):          # sottomodulo non ancora importato (numpy.linalg)
            try:
                return importlib.import_module(f"{self._mod.__name__}.{vero}")
            except ImportError:
                pass
            except Exception as e:  # noqa: BLE001
                raise errore_da_python(e, self._trad, f"{self.descrivi()}.{nome}") from e
        ogg = self._bersaglio()
        italiani = sorted(set(_tabella(self._trad, "nomi", ogg)) | set(_tabella(self._trad, "attributi", ogg)))
        try:
            python = [n for n in dir(ogg) if not n.startswith("_")]
        except Exception:  # noqa: BLE001
            python = []
        simili = difflib.get_close_matches(nome, italiani + python, n=3, cutoff=0.7)
        if simili:
            suggerimento = "Forse intendevi " + " o ".join(f"`{s}`" for s in simili) + "?"
        elif italiani:
            suggerimento = "Nomi italiani disponibili: " + ", ".join(f"`{n}`" for n in italiani[:15]) + "."
        else:
            suggerimento = f"Nomi Python disponibili: {', '.join(python[:15])}." if python else None
        raise ErroreNome(f"`{self.descrivi()}` non ha `{nome}`.", suggerimento=suggerimento, nome=nome)

    def scrivi_attributo_dante(self, nome: str, valore: Any) -> None:
        ogg = self._bersaglio()
        vero = self._nome_vero(nome)
        try:
            setattr(ogg, vero, a_python(valore))
        except Exception as e:  # noqa: BLE001
            raise errore_da_python(e, self._trad, f"{self.descrivi()}.{nome}") from e
        cache = self.__dict__.get("_cache")
        if cache:
            cache.pop(nome, None)

    # stessi nomi del protocollo dei controlli (leggi/scrivi)
    def leggi(self, nome: str) -> Any:
        return self.attributo_dante(nome)

    def scrivi(self, nome: str, valore: Any) -> None:
        self.scrivi_attributo_dante(nome, valore)


class ModuloPython(_ConAttributi):
    """Un modulo Python importato con ``importa python``."""

    NOME_TIPO_DANTE = "modulo python"

    def __init__(self, modulo: Any, trad: dict) -> None:
        self._mod = modulo
        self._trad = trad
        self._cache: dict = {}

    def _bersaglio(self) -> Any:
        return self._mod

    def descrivi(self) -> str:
        return self._mod.__name__

    def valore_python(self) -> Any:
        return self._mod

    def testo_dante(self) -> str:
        return f"<modulo python {self._mod.__name__}>"


def _operazione(simbolo: str) -> Any:
    import operator

    return {"+": operator.add, "-": operator.sub, "*": operator.mul, "/": operator.truediv,
            "//": operator.floordiv, "%": operator.mod, "^": operator.pow,
            "<": operator.lt, "<=": operator.le, ">": operator.gt, ">=": operator.ge}.get(simbolo)


class OggettoPython(_ConAttributi):
    """Qualunque altro valore Python: si usa col punto, con ``[ ]``, ``per ogni``, gli operatori."""

    def __init__(self, ogg: Any, trad: dict) -> None:
        self._ogg = ogg
        self._trad = trad

    def _bersaglio(self) -> Any:
        return self._ogg

    def descrivi(self) -> str:
        return type(self._ogg).__name__

    def testo_dante(self) -> str:
        try:
            return str(self._ogg)
        except Exception:  # noqa: BLE001
            return f"<oggetto python {type(self._ogg).__name__}>"

    def valore_python(self) -> Any:
        return self._ogg

    # --- protocollo dei contenitori (operazioni.leggi_indice, valori.iterabile, lunghezza) ---
    def indice_dante(self, indice: Any) -> Any:
        try:
            return a_leo(self._ogg[a_python(indice)], self._trad)
        except Exception as e:  # noqa: BLE001
            raise errore_da_python(e, self._trad, f"{self.descrivi()}[...]") from e

    def scrivi_indice_dante(self, indice: Any, valore: Any) -> None:
        try:
            self._ogg[a_python(indice)] = a_python(valore)
        except Exception as e:  # noqa: BLE001
            raise errore_da_python(e, self._trad, f"{self.descrivi()}[...]") from e

    def elementi_per_ogni(self) -> Any:
        try:
            iteratore = iter(self._ogg)
        except TypeError:
            raise ErroreTipo(f"`per ogni` non può percorrere un `{self.descrivi()}` di Python.") from None
        trad = self._trad

        def elementi():
            while True:
                try:
                    x = next(iteratore)
                except StopIteration:
                    return
                except Exception as e:  # noqa: BLE001
                    raise errore_da_python(e, trad, "per ogni") from e
                yield a_leo(x, trad)
        return elementi()

    def lunghezza_dante(self) -> int:
        try:
            return len(self._ogg)
        except TypeError:
            raise ErroreTipo(f"Un `{self.descrivi()}` di Python non ha una lunghezza.") from None

    def contiene_dante(self, valore: Any) -> bool:
        try:
            return bool(a_python(valore) in self._ogg)
        except Exception as e:  # noqa: BLE001
            raise errore_da_python(e, self._trad, "in") from e

    def binaria_dante(self, operatore: str, a: Any, b: Any) -> Any:
        """``a operatore b`` quando almeno uno dei due è un oggetto Python (numpy, Decimal, date...)."""
        f = _operazione(operatore)
        if f is None:
            return NotImplemented
        try:
            return a_leo(f(a_python(a), a_python(b)), self._trad)
        except TypeError:
            return NotImplemented
        except Exception as e:  # noqa: BLE001
            raise errore_da_python(e, self._trad, f"{operatore}") from e

    def unaria_dante(self, operatore: str) -> Any:
        if operatore != "-":
            return NotImplemented
        try:
            return a_leo(-self._ogg, self._trad)
        except TypeError:
            return NotImplemented

    def __eq__(self, altro: object) -> bool:
        b = altro._ogg if isinstance(altro, OggettoPython) else a_python(altro)
        try:
            return bool(self._ogg == b)
        except Exception:  # noqa: BLE001 - numpy: "truth value of an array is ambiguous"
            try:
                import numpy  # type: ignore

                return bool(numpy.array_equal(self._ogg, b))
            except Exception:  # noqa: BLE001
                return self._ogg is b

    def __hash__(self) -> int:
        try:
            return hash(self._ogg)
        except TypeError:
            return id(self._ogg)


class Byte:
    """``bytes`` di Python visti da Leo: come una lista di numeri da 0 a 255 (immutabile)."""

    NOME_TIPO_DANTE = "byte"
    ATTRIBUTI_DANTE = True
    _METODI = ("testo", "lista", "esadecimale", "base64", "salva", "lunghezza")

    __slots__ = ("dati",)

    def __init__(self, dati: bytes) -> None:
        self.dati = bytes(dati)

    def testo_dante(self) -> str:
        n = len(self.dati)
        anteprima = " ".join(f"{b:02x}" for b in self.dati[:16])
        return f"<byte: {n} byte{': ' + anteprima if n else ''}{' ...' if n > 16 else ''}>"

    def valore_python(self) -> bytes:
        return self.dati

    def __eq__(self, altro: object) -> bool:
        return isinstance(altro, Byte) and altro.dati == self.dati

    def __hash__(self) -> int:
        return hash(self.dati)

    def indice_dante(self, indice: Any) -> Any:
        if isinstance(indice, range):
            n = len(self.dati)
            return Byte(bytes(self.dati[i] for i in indice if -n <= i < n))
        if not isinstance(indice, int) or isinstance(indice, bool):
            raise ErroreTipo("La posizione in un `byte` deve essere un intero.")
        try:
            return self.dati[indice]
        except IndexError:
            raise ErroreIndice(f"La posizione {indice} è fuori dai limiti: ci sono {len(self.dati)} byte.") from None

    def scrivi_indice_dante(self, indice: Any, valore: Any) -> None:
        raise ErroreTipo("I `byte` non si possono modificare: usa `.lista()` per averne una copia modificabile.")

    def elementi_per_ogni(self) -> Any:
        return iter(self.dati)

    def lunghezza_dante(self) -> int:
        return len(self.dati)

    def contiene_dante(self, valore: Any) -> bool:
        if isinstance(valore, Byte):
            return valore.dati in self.dati
        if isinstance(valore, int) and not isinstance(valore, bool) and 0 <= valore <= 255:
            return valore in self.dati
        return False

    def binaria_dante(self, operatore: str, a: Any, b: Any) -> Any:
        if operatore == "+" and isinstance(a, Byte) and isinstance(b, Byte):
            return Byte(a.dati + b.dati)
        return NotImplemented

    def attributo_dante(self, nome: str) -> Any:
        if nome not in self._METODI:
            raise ErroreNome(f"Un valore `byte` non ha `{nome}`.",
                             suggerimento="Metodi: " + ", ".join(f"`{m}`" for m in self._METODI) + ".", nome=nome)
        return _MetodoByte(self, nome)

    def scrivi_attributo_dante(self, nome: str, valore: Any) -> None:
        raise ErroreTipo("I `byte` non si possono modificare: creane di nuovi.")

    leggi = attributo_dante
    scrivi = scrivi_attributo_dante


class _MetodoByte(Richiamabile):
    def __init__(self, byte: Byte, nome: str) -> None:
        self.byte = byte
        self.nome = nome

    def chiama(self, interprete: Any, argomenti: list, argomenti_nome: dict) -> Any:
        dati = self.byte.dati
        nome = self.nome
        if nome == "testo":
            codifica = argomenti[0] if argomenti else argomenti_nome.get("codifica", "utf-8")
            try:
                return dati.decode(str(codifica))
            except LookupError:
                raise ErroreValore(f"Codifica `{codifica}` sconosciuta.") from None
            except UnicodeDecodeError as e:
                raise ErroreValore(f"Questi byte non sono un testo {codifica}: il byte {e.start} non è valido.",
                                   suggerimento="Prova con un'altra codifica, per esempio `testo(\"latin-1\")`.") from None
        if nome == "lista":
            return list(dati)
        if nome == "esadecimale":
            return dati.hex()
        if nome == "base64":
            import base64

            return base64.b64encode(dati).decode("ascii")
        if nome == "lunghezza":
            return len(dati)
        if nome == "salva":
            percorso = argomenti[0] if argomenti else argomenti_nome.get("percorso")
            if not isinstance(percorso, str) or not percorso:
                raise ErroreTipo("`salva` vuole il percorso del file, per esempio `dati.salva(\"foto.png\")`.")
            try:
                with open(percorso, "wb") as f:
                    f.write(dati)
            except OSError as e:
                raise ErroreFile(f"Non riesco a scrivere `{percorso}`: {e.strerror or e}.") from None
            return None
        raise ErroreNome(f"Un valore `byte` non ha `{nome}`.")  # pragma: no cover

    def testo_dante(self) -> str:
        return f"<metodo byte {self.nome}>"


# ===========================================================================
# importa python
# ===========================================================================

def _prepara_progetto(radice: str) -> bool:
    from .pacchetti import ErrorePacchetti, prepara_se_serve

    try:
        return prepara_se_serve(radice)
    except ErrorePacchetti as e:
        raise ErroreValore(f"Non riesco a preparare i pacchetti del progetto: {e.messaggio}",
                           suggerimento=e.suggerimento or "Scrivi `leo sincronizza` nel terminale.") from None


def importa_modulo(nome: str, cartelle: list[str], interprete: Any = None) -> ModuloPython:
    """Esegue ``importa python "nome"``: il modulo, pronto per essere usato da Leo."""
    nome = nome.strip()
    if not _RE_NOME_MODULO.match(nome):
        raise ErroreValore(f"`{nome}` non è il nome di un modulo Python.",
                           suggerimento="Per esempio `importa python \"requests\"` oppure `importa python \"os.path\"`.")
    if interprete is not None:
        if interprete in _INTERPRETE:
            _INTERPRETE.remove(interprete)
        _INTERPRETE.append(interprete)
        del _INTERPRETE[:-4]
    radice_progetto = attiva_ambiente(cartelle)
    from .permessi_pacchetti import controlla_import_python

    file_chiamante = getattr(interprete, "_file_corrente", None)
    if file_chiamante:
        file_chiamante = (getattr(interprete, "__dict__", {}).get("file_dei_moduli") or {}).get(file_chiamante,
                                                                                               file_chiamante)
    controlla_import_python(nome, radice_progetto, file_chiamante)
    try:
        try:
            modulo = importlib.import_module(nome)
        except ModuleNotFoundError:
            # progetto ricevuto da altri: l'ambiente si prepara da solo da leo.lock, poi si riprova
            if radice_progetto is None or not _prepara_progetto(radice_progetto):
                raise
            attiva_ambiente(cartelle)
            modulo = importlib.import_module(nome)
    except ModuleNotFoundError as e:
        radice = nome.split(".")[0]
        mancante = (e.name or radice).split(".")[0]
        if mancante != radice:          # il modulo c'è, ma manca una sua dipendenza
            raise ErroreNome(f"Il pacchetto Python `{radice}` ha bisogno di `{mancante}`, che non è installato.",
                             suggerimento=f"Scrivi nel terminale `leo aggiungi {nome_distribuzione(mancante)}`.",
                             nome=nome) from None
        if "." in nome and importlib.util.find_spec(radice) is not None:
            raise ErroreNome(f"Il pacchetto `{radice}` non contiene il modulo `{nome}`.", nome=nome) from None
        suggerimento = (f"Scrivi nel terminale `leo aggiungi {nome_distribuzione(radice)}`: lo installa solo per "
                        "questo progetto e lo annota in `progetto.toml` e `leo.lock`.")
        if radice_progetto is None:
            suggerimento += " Serve un progetto: `leo nuovo NomeProgetto --testuale`."
        else:
            altra = ambiente_di_altra_versione(radice_progetto)
            if altra:
                suggerimento = (f"L'ambiente del progetto è stato creato con Python {altra}, ma Leo usa Python "
                                f"{sys.version_info.major}.{sys.version_info.minor}: scrivi `leo sincronizza`.")
        raise ErroreNome(f"Il pacchetto Python `{radice}` non è installato.", suggerimento=suggerimento,
                         nome=nome) from None
    except ErroreDante:
        raise
    except Exception as e:  # noqa: BLE001 - errore mentre il pacchetto si carica
        raise errore_da_python(e, traduzione(nome), f"importa python \"{nome}\"") from e
    return ModuloPython(modulo, traduzione(nome))
