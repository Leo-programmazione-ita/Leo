"""REPL interattivo di Leo (docs/CONTRATTI.md §12.1).

Esempio di sessione::

    leo> variabile x = 3
    leo> x * 2
    6
    leo> se x > 2 allora
    ....>     stampa("grande")
    ....> fine
    grande

API:
    class Repl(*, rigoroso=False, colori=None, tema="nero", ingresso=input, uscita=print)
        esegui() -> int
    input_completo(testo, *, sinonimi=None, stile=None) -> bool

Regole:
- prompt ``leo> ``; ``....> `` finche' :func:`input_completo` e' falso
  (blocco senza ``fine``, parentesi, testo o commento ``#[`` aperti). Due
  righe vuote di fila durante la continuazione eseguono comunque quanto
  scritto (cosi' si vede l'errore);
- un solo ``Interprete(repl=True)`` per tutta la sessione (si puo' ridichiarare);
- il valore delle espressioni (tranne ``nulla``) si mostra con
  ``rappresenta(dentro=True)``;
- comandi ``:esci``, ``:aiuto``, ``:pulisci`` (in piu' ``:variabili``);
  Ctrl+D esce; Ctrl+C esce dal prompt principale, annulla una riga di
  continuazione e ferma un programma in esecuzione;
- errori formattati con ``messaggi.formatta_errore``; per gli errori di forma
  la stessa domanda di conferma della CLI (solo se si puo' chiedere: ingresso
  interattivo e non ``rigoroso``).
"""

from __future__ import annotations

import sys
from functools import lru_cache
from typing import Any, Callable

from . import __version__, NOME, e_sorgente

PROMPT = "leo> "
PROMPT_CONTINUAZIONE = "....> "

#: Nome di file usato per il codice scritto nel REPL (non compare nei messaggi).
NOME_FILE_REPL = "<sorgente>"

COMANDI_REPL = (":esci", ":aiuto", ":pulisci", ":variabili", ":storia", ":salva", ":spiega", ":consiglio")

GUIDA = """\
Guida rapida di Leo

Scrivi un'istruzione e premi Invio: Leo la esegue subito. Se scrivi
un'espressione, ti mostra il suo valore.

    leo> variabile nome = "Ada"
    leo> "Ciao, {nome}!"
    "Ciao, Ada!"
    leo> 7 * 6
    42

I blocchi (se, mentre, per ogni, ripeti, funzione, prova, quando, scegli) si
scrivono su più righe: il prompt diventa `....>` finché non chiudi con `fine`.
Anche una parentesi aperta continua sulla riga dopo, per esempio una lista
compresa lunga: `[x * 2 per ogni x in voti` e sotto `se x > 5]`.

    leo> funzione doppio(n)
    ....>     restituisci n * 2
    ....> fine
    leo> doppio(21)
    42

    leo> per ogni i in 1..3 fai
    ....>     stampa(i)
    ....> fine

    leo> scegli voto
    ....>     caso 10 allora
    ....>         stampa("Ottimo")
    ....>     altrimenti
    ....>         stampa("Bene")
    ....> fine

`importa "geometria.leo"` carica un file della cartella corrente (o un
modulo, `importa matematica come m`); se cambi il file, importalo di nuovo
e Leo rilegge la versione nuova.

Le variabili restano per tutta la sessione e si possono dichiarare di nuovo.
Se sbagli la forma (per esempio dimentichi `allora`), Leo ti propone la
correzione e aspetta il tuo sì.

Comandi:
    :aiuto           questa guida
    :variabili       le variabili e le funzioni che hai definito
    :storia          tutto quello che hai scritto finora, numerato
    :salva file      salva in un file .leo quello che ha funzionato
    :spiega          racconta a parole l'ultima cosa che hai eseguito
    :spiega tutto    racconta tutta la sessione (--semplice o --dettagli per il livello)
    :spiega codice   racconta a parole il codice (o un file .leo)
    :consiglio       un consiglio per programmare meglio
    :pulisci         pulisce lo schermo
    :esci            esce (anche Ctrl+D)

Tab completa parole chiave, variabili e funzioni (se il terminale lo permette).
Se dimentichi una parola (`allora`, `fai`, `volte`...) Leo te la ricorda.

Ctrl+C: ferma un programma che non finisce, annulla le righe `....>` in corso,
oppure, al prompt `leo>`, esce. Due righe vuote di fila eseguono quello
che hai scritto anche se manca qualcosa (così vedi l'errore)."""


# ---------------------------------------------------------------------------
# input_completo
# ---------------------------------------------------------------------------

class _Scansione:
    """Risultato dell'analisi carattere per carattere di un testo."""

    __slots__ = ("parentesi", "commento", "testo_aperto", "chiusura_sbagliata", "codice")

    def __init__(self) -> None:
        self.parentesi: list[str] = []      # pila delle parentesi aperte
        self.commento = 0                   # profondita' dei commenti #[ ]# aperti
        self.testo_aperto = False           # testo "..." non chiuso sull'ultima riga
        self.chiusura_sbagliata = False     # ) ] } senza apertura: e' un errore, non un seguito
        self.codice = ""                    # testo senza commenti e testi (per il ripiego)


_CHIUSURE = {")": "(", "]": "[", "}": "{"}


def _scandisci(testo: str) -> _Scansione:
    """Parentesi, commenti ``#[ ]#`` (annidabili) e testi ``"..."`` aperti a fine testo.

    I testi stanno su una sola riga: un testo non chiuso conta come "aperto"
    solo se e' sull'ultima riga. Dentro le graffe di un testo interpolato si
    contano le graffe e si saltano i testi annidati.
    """
    s = _Scansione()
    codice: list[str] = []
    i, n = 0, len(testo)
    while i < n:
        c = testo[i]
        if s.commento:
            if testo.startswith("#[", i):
                s.commento += 1
                i += 2
            elif testo.startswith("]#", i):
                s.commento -= 1
                i += 2
            else:
                if c == "\n":
                    codice.append("\n")
                i += 1
            continue
        if c == "#":
            if testo.startswith("#[", i):
                s.commento = 1
                i += 2
                continue
            fine = testo.find("\n", i)
            i = n if fine < 0 else fine
            continue
        if testo.startswith('"""', i):
            # testo su piu' righe: aperto finche' non arrivano le tre virgolette di chiusura
            j = i + 3
            while j < n and not testo.startswith('"""', j):
                j += 2 if testo[j] == "\\" else 1
            if j >= n:
                s.testo_aperto = True
                i = n
            else:
                while j + 3 < n and testo[j + 3] == '"':
                    j += 1
                codice.append(' "" ' + "\n" * testo.count("\n", i, j))
                i = j + 3
            continue
        if c == '"':
            i, chiuso = _salta_testo(testo, i)
            codice.append(' "" ')
            if not chiuso:
                s.testo_aperto = i >= n
            continue
        if c in "([{":
            s.parentesi.append(c)
        elif c in _CHIUSURE:
            if s.parentesi and s.parentesi[-1] == _CHIUSURE[c]:
                s.parentesi.pop()
            else:
                s.chiusura_sbagliata = True
        codice.append(c)
        i += 1
    s.codice = "".join(codice)
    return s


def _salta_testo(testo: str, i: int) -> tuple[int, bool]:
    """Da ``testo[i] == '"'`` alla fine del testo. Restituisce (posizione dopo, chiuso?)."""
    n = len(testo)
    i += 1
    while i < n:
        c = testo[i]
        if c == "\\":
            i += 2
            continue
        if c == "\n":
            return i, False
        if c == '"':
            return i + 1, True
        if c == "{":
            i = _salta_interpolazione(testo, i)
            continue
        i += 1
    return n, False


def _salta_interpolazione(testo: str, i: int) -> int:
    """Da ``{`` dentro un testo alla ``}`` corrispondente (o alla fine della riga)."""
    n = len(testo)
    profondita = 0
    while i < n:
        c = testo[i]
        if c == "\n":
            return i
        if c == "{":
            profondita += 1
        elif c == "}":
            profondita -= 1
            if profondita == 0:
                return i + 1
        elif c == '"':
            i, chiuso = _salta_testo(testo, i)
            if not chiuso:
                return i
            continue
        i += 1
    return n


#: Tipi di token che aprono un blocco chiuso da `fine` (per nome, per non importare tokens qui).
#: ``scegli`` e' una parola di contesto (arriva come NOME): la gestisce :func:`_apre_scegli`.
_APERTURE = ("SE", "MENTRE", "PER_OGNI", "RIPETI", "FUNZIONE", "PROVA", "QUANDO")

#: Nomi dei blocchi del parser (``Parser._apri(nome, ...)``) riconosciuti dal REPL come
#: inizio di un blocco su piu' righe: un test controlla che ogni blocco nuovo sia qui.
BLOCCHI_RICONOSCIUTI = frozenset({"se", "mentre", "per ogni", "ripeti", "funzione", "prova",
                                  "quando", "scegli", "inizio",
                                  # costrutti "potenti" (tokens.teste_di_blocco_potenza)
                                  "ogni", "dopo", "verifica", "aspettati", "in parallelo"})

#: Etichette di `fine` che arrivano come NOME (oltre alle parole chiave dei blocchi).
_ETICHETTE_NOME = ("per", "scegli", "inizio", "ogni", "dopo", "verifica", "aspettati", "parallelo")

#: Dentro parentesi ``se`` e ``per ogni`` sono parti di una lista compresa
#: (``[x per ogni x in l se x > 0]``), non blocchi: aprono un blocco solo
#: fuori dalle parentesi o nel corpo di una funzione anonima.
_APERTURE_SOLO_ISTRUZIONE = ("SE", "MENTRE", "PER_OGNI", "RIPETI", "PROVA", "QUANDO")

#: Tipi di token dopo i quali, sulla stessa riga, comincia un'istruzione.
_PRIMA_DI_ISTRUZIONE = ("FINE_RIGA", "ALLORA", "FAI", "ALTRIMENTI", "VOLTE", "PROVA", "INFINE")

_APRE_PARENTESI = ("PARENTESI_APERTA", "QUADRA_APERTA", "GRAFFA_APERTA")
_CHIUDE_PARENTESI = {"PARENTESI_CHIUSA": "PARENTESI_APERTA", "QUADRA_CHIUSA": "QUADRA_APERTA",
                     "GRAFFA_CHIUSA": "GRAFFA_APERTA"}

#: Parole che aprono un blocco, per il conteggio di ripiego senza lexer.
_PAROLE_APERTURA = {"se", "mentre", "ripeti", "funzione", "prova", "quando"}

#: Parole dopo le quali, sulla stessa riga, comincia un'istruzione (ripiego senza lexer).
_PAROLE_PRIMA_DI_ISTRUZIONE = frozenset({";", "allora", "fai", "altrimenti", "volte", "prova", "infine"})

#: Blocco aperto (nella pila del conteggio); le parentesi usano il nome del loro tipo.
_BLOCCO = "blocco"


@lru_cache(maxsize=4)
def _sinonimi_predefiniti(rigoroso: bool = False) -> Any:
    try:
        from .sinonimi import carica_sinonimi

        return carica_sinonimi(rigoroso=rigoroso)
    except Exception:  # noqa: BLE001 - file dei sinonimi rovinato: si va avanti senza
        return None


def _inizio_valore_scegli() -> frozenset:
    """Nomi dei tipi di token che possono seguire ``scegli`` (stessa regola del parser)."""
    try:
        from .parser import _INIZIO_VALORE_DI_CONTESTO

        return frozenset(t.name for t in _INIZIO_VALORE_DI_CONTESTO)
    except Exception:  # noqa: BLE001 - parser non pronto
        return frozenset({"INTERO", "DECIMALE", "TESTO", "TESTO_INTERPOLATO", "NOME", "VERO",
                          "FALSO", "NULLA", "NON", "E", "GRAFFA_APERTA", "FUNZIONE"})


def _inizio_da_solo(token: list, k: int) -> bool:
    """``inizio`` da solo sulla sua riga apre un blocco (stessa regola del parser)."""
    try:
        from .tokens import e_inizio_da_solo

        return e_inizio_da_solo(token, k)
    except Exception:  # noqa: BLE001 - tokens non pronto
        return False


def _blocchi_aperti_da_token(testo: str, sinonimi: Any, stile: Any) -> int | None:
    """Blocchi aperti meno `fine`, contati sui token del lexer tollerante (None se non disponibile).

    Una pila tiene insieme parentesi e blocchi: ``se``/``per ogni`` dentro
    parentesi (liste comprese) non contano, il corpo di una funzione anonima
    si' (anche dentro una chiamata). ``scegli valore`` conta solo all'inizio di
    un'istruzione, come nel parser (``variabile scegli = 3`` e' un nome).
    """
    try:
        from .lexer import Lexer
        from .stile import Stile

        stile_effettivo = Stile.da_sorgente(testo, stile)
        token = Lexer(testo, NOME_FILE_REPL, sinonimi=sinonimi, stile=stile_effettivo,
                      tollerante=True).tokenizza()
    except Exception:  # noqa: BLE001 - lexer non pronto o intestazione di stile sbagliata
        return None
    valore_scegli = _inizio_valore_scegli()
    try:
        from .tokens import teste_di_blocco_potenza

        teste_potenza = teste_di_blocco_potenza(token)
    except Exception:  # noqa: BLE001 - tokens non pronto
        teste_potenza = set()
    pila: list[str] = []
    fine_troppi = 0
    salta_etichetta_riga = -1
    precedente: Any = None
    for k, t in enumerate(token):
        nome_tipo = getattr(t.tipo, "name", "")
        if nome_tipo in ("COMMENTO", "FINE_FILE"):
            continue
        prec, precedente = precedente, t
        if salta_etichetta_riga == t.riga:
            salta_etichetta_riga = -1
            if nome_tipo in _APERTURE or nome_tipo == "INIZIO" \
                    or (nome_tipo == "NOME" and t.valore in _ETICHETTE_NOME):
                continue                     # `fine se`, `fine per ogni`, `fine scegli`: etichetta
        else:
            salta_etichetta_riga = -1
        in_parentesi = bool(pila) and pila[-1] != _BLOCCO
        if nome_tipo in _APRE_PARENTESI:
            pila.append(nome_tipo)
        elif nome_tipo in _CHIUDE_PARENTESI:
            apre = _CHIUDE_PARENTESI[nome_tipo]
            if apre in pila:                 # chiude anche i blocchi rimasti aperti dentro
                while pila and pila.pop() != apre:
                    pass
        elif nome_tipo == "FUNZIONE":
            pila.append(_BLOCCO)             # funzione con nome o anonima: sempre un blocco
        elif nome_tipo in _APERTURE_SOLO_ISTRUZIONE:
            if not in_parentesi:
                pila.append(_BLOCCO)
        elif k in teste_potenza:
            pila.append(_BLOCCO)             # `ogni ... fai`, `verifica "..." fai`, `in parallelo fai`...
        elif (nome_tipo == "INIZIO" or (nome_tipo == "NOME" and t.valore == "inizio")) \
                and not in_parentesi and _inizio_da_solo(token, k):
            pila.append(_BLOCCO)             # `inizio` da solo sulla riga: blocco facoltativo
        elif nome_tipo == "NOME" and t.valore == "scegli" and not in_parentesi:
            inizio = prec is None or getattr(prec.tipo, "name", "") in _PRIMA_DI_ISTRUZIONE
            succ = token[k + 1] if k + 1 < len(token) else None
            if inizio and succ is not None and succ.riga == t.riga \
                    and getattr(succ.tipo, "name", "") in valore_scegli:
                pila.append(_BLOCCO)
        elif nome_tipo == "FINE":
            salta_etichetta_riga = t.riga
            if pila and pila[-1] == _BLOCCO:
                pila.pop()
            elif not pila:
                fine_troppi += 1
    return pila.count(_BLOCCO) - fine_troppi


def _blocchi_aperti_da_parole(codice: str) -> int:
    """Ripiego senza lexer: conta le parole chiave canoniche (testi e commenti gia' tolti).

    Stesse regole del conteggio sui token: ``se``/``per ogni`` dentro
    parentesi (liste comprese) non contano, il corpo di una funzione anonima
    si', ``scegli valore`` conta all'inizio di un'istruzione.
    """
    import re

    pila: list[str] = []
    fine_troppi = 0
    for riga in codice.split("\n"):
        parole = re.findall(r"[^\W\d]\w*'?|\S", riga)
        k = 0
        precedente = ""
        while k < len(parole):
            p = parole[k]
            successiva = parole[k + 1] if k + 1 < len(parole) else ""
            inizio = k == 0 or precedente in _PAROLE_PRIMA_DI_ISTRUZIONE
            precedente = p
            in_parentesi = bool(pila) and pila[-1] != _BLOCCO
            passo = 1
            if p in "([{":
                pila.append(p)
            elif p in ")]}":
                apre = _CHIUSURE[p]
                if apre in pila:
                    while pila and pila.pop() != apre:
                        pass
            elif p == "fine":
                if pila and pila[-1] == _BLOCCO:
                    pila.pop()
                elif not pila:
                    fine_troppi += 1
                if successiva in _PAROLE_APERTURA | set(_ETICHETTE_NOME):
                    passo = 3 if successiva == "per" and k + 2 < len(parole) and parole[k + 2] == "ogni" else 2
            elif p == "altrimenti" and successiva == "se":
                passo = 2
            elif p == "funzione":
                pila.append(_BLOCCO)
            elif p == "in" and successiva == "parallelo" and k + 2 < len(parole) \
                    and parole[k + 2] in ("fai", "allora"):
                if k == 0 or parole[k - 1] in ("=", "(", ",", "[", "restituisci", *_PAROLE_PRIMA_DI_ISTRUZIONE):
                    pila.append(_BLOCCO)         # `in parallelo fai` (un valore, non `x in parallelo`)
                passo = 3
            elif p == "inizio" and len(parole) == 1 and not in_parentesi:
                pila.append(_BLOCCO)             # `inizio` da solo sulla riga
            elif in_parentesi:
                if p == "per" and successiva == "ogni":
                    passo = 2                    # lista compresa: `se`, `per ogni` non aprono
            elif p in _PAROLE_APERTURA:
                pila.append(_BLOCCO)
            elif p == "per" and successiva == "ogni":
                pila.append(_BLOCCO)
                passo = 2
            elif p == "scegli" and inizio and successiva and (successiva[0].isalnum()
                                                              or successiva[0] in "_{\""):
                pila.append(_BLOCCO)
            elif inizio and _apre_potenza(p, parole[k + 1:]):
                pila.append(_BLOCCO)             # `ogni 2 secondi fai`, `verifica "..." fai`...
            if passo > 1:
                precedente = parole[k + passo - 1]
            k += passo
    return pila.count(_BLOCCO) - fine_troppi


def _apre_potenza(parola: str, resto: list[str]) -> bool:
    """Ripiego senza lexer: ``ogni``/``dopo ... fai``, ``verifica "" fai``,
    ``aspettati errore ... fai`` all'inizio di un'istruzione (testi gia' svuotati)."""
    if parola not in ("ogni", "dopo", "verifica", "aspettati") or len(resto) < 2:
        return False
    if resto[-1] not in ("fai", "allora") or resto[0] in ("=", "(", ".", "[", ","):
        return False
    if parola == "verifica":
        return resto[0] == '"' and len(resto) == 3
    if parola == "aspettati":
        return resto[0] == "errore"
    return True


def input_completo(testo: str, *, sinonimi: Any = None, stile: Any = None) -> bool:
    """False se nel testo c'e' ancora un blocco senza `fine`, una parentesi, un testo
    (sull'ultima riga) o un commento ``#[`` aperti; True altrimenti.

    Un testo con errori evidenti (una `)` di troppo, un `fine` in piu') conta
    come completo: lo si esegue e l'errore si mostra subito. ``sinonimi``:
    oggetto ``Sinonimi`` (None = quelli di serie); ``stile``: ``Stile`` del
    progetto (None = intestazione ``#stile:`` o predefinito).
    """
    if not testo.strip():
        return True
    scansione = _scandisci(testo)
    if scansione.chiusura_sbagliata:
        return True
    if scansione.commento > 0 or scansione.parentesi or scansione.testo_aperto:
        return False
    if sinonimi is None:
        sinonimi = _sinonimi_predefiniti(False)
    aperti = _blocchi_aperti_da_token(testo, sinonimi, stile)
    if aperti is None:
        aperti = _blocchi_aperti_da_parole(scansione.codice)
    return aperti <= 0


# ---------------------------------------------------------------------------
# Repl
# ---------------------------------------------------------------------------

class _UscitaInterprete:
    """Adatta ``uscita`` stile ``print`` (una riga per chiamata) alla scrittura
    dell'interprete (testi che contengono gia' ``\\n``)."""

    def __init__(self, uscita: Callable[[str], Any]) -> None:
        self._uscita = uscita
        self._resto = ""

    def __call__(self, testo: str) -> None:
        dati = self._resto + str(testo)
        *righe, self._resto = dati.split("\n")
        for riga in righe:
            self._uscita(riga)

    def svuota(self) -> None:
        if self._resto:
            resto, self._resto = self._resto, ""
            self._uscita(resto)


def _scrivi_stdout(testo: str) -> None:
    sys.stdout.write(testo)
    sys.stdout.flush()


class Repl:
    """Ciclo leggi-esegui-mostra. Vedi il docstring del modulo."""

    def __init__(self, *, rigoroso: bool = False, colori: bool | None = None, tema: str = "nero",
                 ingresso: Callable[[str], str] = input,
                 uscita: Callable[[str], None] = print) -> None:
        self.rigoroso = rigoroso
        self.ingresso = ingresso
        self.uscita = uscita
        self.nome_tema = tema
        self._su_terminale = ingresso is input and uscita is print
        if colori is None:
            colori = False
            if self._su_terminale:
                try:
                    from .cli import usa_colori

                    colori = usa_colori(sys.stdout)
                except ImportError:
                    colori = False
        self.colori = bool(colori)
        self._tema: Any = None
        self._tema_caricato = False
        self._uscita_interprete: _UscitaInterprete | None = None
        self.interprete: Any = None
        self._sinonimi: Any = None
        self._sinonimi_caricati = False
        #: True quando l'ingresso non e' un terminale (``echo "2+3" | leo``):
        #: niente benvenuto, prompt e saluto; errori su stderr; codice d'uscita 1 se ce ne sono stati.
        self.silenzioso = False
        self.errori = 0
        #: messaggi d'errore per bambini (``leo --semplice``) e consiglio del giorno
        self.semplice = False
        self.consiglio = False
        #: tutte le immissioni (per ``:storia``) e quelle andate a buon fine (per ``:salva``)
        self.storia: list[str] = []
        self.riuscite: list[str] = []
        self._completamento_attivo = False

    # --- proprieta' di servizio ------------------------------------------------
    @property
    def interattivo(self) -> bool:
        """True se si possono fare domande (conferma delle correzioni)."""
        if self.ingresso is not input:
            return True
        try:
            return bool(sys.stdin and sys.stdin.isatty())
        except (AttributeError, ValueError, OSError):
            return False

    @property
    def tema(self) -> Any:
        if not self._tema_caricato:
            self._tema_caricato = True
            try:
                from .temi import carica_tema

                self._tema = carica_tema(self.nome_tema or "nero")
            except Exception:  # noqa: BLE001 - tema sconosciuto o modulo non pronto: colori di riserva
                self._tema = None
        return self._tema

    @property
    def sinonimi(self) -> Any:
        if not self._sinonimi_caricati:
            self._sinonimi_caricati = True
            self._sinonimi = _sinonimi_predefiniti(self.rigoroso)
        return self._sinonimi

    def _crea_interprete(self) -> Any:
        from .interprete import Interprete

        if self.uscita is print:
            scrittura: Callable[[str], None] = _scrivi_stdout
            self._uscita_interprete = None
        else:
            self._uscita_interprete = _UscitaInterprete(self.uscita)
            scrittura = self._uscita_interprete
        ingresso = self.ingresso
        self._console = None
        if self.ingresso is input:
            # `chiedi` legge dall'ingresso standard come nella CLI: con i dati da una
            # pipe, un programma che chiede ancora dopo la fine si ferma (niente cicli infiniti)
            try:
                from .cli import _Console

                self._console = _Console()
                ingresso = self._console.leggi
            except ImportError:
                ingresso = None
        return Interprete(nome_file=NOME_FILE_REPL, uscita=scrittura, ingresso=ingresso, repl=True)

    # --- ciclo principale --------------------------------------------------------
    def esegui(self) -> int:
        """Esegue la sessione finche' l'utente non esce.

        Restituisce 0; con l'ingresso da pipe o da file (modo silenzioso)
        restituisce 1 se almeno un'immissione ha dato errore.
        """
        self.silenzioso = self._su_terminale and not self.interattivo
        self.errori = 0
        if not self.silenzioso:
            self.uscita(f"{NOME} {__version__} - scrivi :aiuto per la guida, :esci per uscire.")
        if self._su_terminale and not self.silenzioso:
            self._completamento_attivo = attiva_completamento(self)
        try:
            self.interprete = self._crea_interprete()
        except Exception as e:  # noqa: BLE001 - nucleo non disponibile
            self._scrivi_errore(f"Non riesco ad avviare l'interprete: {e}")
            return 1
        righe: list[str] = []
        vuote_di_fila = 0
        while True:
            prompt = PROMPT_CONTINUAZIONE if righe else PROMPT
            try:
                riga = self.ingresso("" if self.silenzioso else prompt)
            except EOFError:                       # Ctrl+D (Ctrl+Z su Windows)
                if not self.silenzioso:
                    self.uscita("")
                if righe:                          # quello che resta si esegue (mostra l'errore)
                    self.esegui_testo("\n".join(righe) + "\n")
                break
            except KeyboardInterrupt:              # Ctrl+C
                self.uscita("")
                if righe:
                    righe = []
                    vuote_di_fila = 0
                    self.uscita("(annullato)")
                    continue
                break
            if riga is None:
                break
            riga = str(riga).rstrip("\r\n")

            if not righe:
                comando = riga.strip()
                if comando.startswith(":"):
                    if self._comando(comando):
                        break
                    continue
                if not comando:
                    continue

            righe.append(riga)
            if righe and not riga.strip():
                vuote_di_fila += 1
            else:
                vuote_di_fila = 0
            testo = "\n".join(righe)
            forza = vuote_di_fila >= 2
            if not forza and not input_completo(testo, sinonimi=self.sinonimi):
                self._suggerisci_prossima_parola(riga)
                continue
            righe = []
            vuote_di_fila = 0
            self.esegui_testo(testo.rstrip("\n") + "\n" if testo.strip() else testo)
        if self.silenzioso:
            return 1 if self.errori else 0
        self.uscita("Arrivederci.")
        return 0

    # --- comandi -----------------------------------------------------------------
    def _comando(self, comando: str) -> bool:
        """Esegue un comando `:...`. True se bisogna uscire."""
        nome = comando.split()[0].lower()
        if nome in (":esci", ":exit", ":quit", ":q"):
            return True
        if nome in (":aiuto", ":help", ":?"):
            self.uscita(GUIDA)
        elif nome == ":pulisci":
            self._pulisci_schermo()
        elif nome == ":variabili":
            self._mostra_variabili()
        elif nome == ":storia":
            self._mostra_storia()
        elif nome == ":salva":
            self._salva(comando[len(comando.split()[0]):].strip())
        elif nome == ":spiega":
            self._spiega(comando[len(comando.split()[0]):].strip())
        elif nome == ":consiglio":
            from .errori_umani import consiglio_del_giorno

            self.uscita("Consiglio: " + consiglio_del_giorno())
        else:
            self.uscita(f"Non conosco il comando `{nome}`. Comandi: " + ", ".join(COMANDI_REPL) + ".")
        return False

    def _pulisci_schermo(self) -> None:
        if self.colori or self._su_terminale:
            try:
                sys.stdout.write("\x1b[2J\x1b[H")
                sys.stdout.flush()
                return
            except (AttributeError, ValueError, OSError):
                pass
        self.uscita("\n" * 3)

    def _mostra_variabili(self) -> None:
        from .valori import rappresenta

        voci = getattr(getattr(self.interprete, "globale", None), "voci", {}) or {}
        if not voci:
            self.uscita("Non hai ancora definito niente.")
            return
        for nome, voce in voci.items():
            valore = getattr(voce, "valore", voce)
            costante = " (costante)" if getattr(voce, "costante", False) else ""
            try:
                testo = rappresenta(valore, dentro=True)
            except Exception:  # noqa: BLE001
                testo = repr(valore)
            self.uscita(f"{nome} = {testo}{costante}")

    # --- esecuzione ----------------------------------------------------------------
    def esegui_testo(self, testo: str) -> Any:
        """Analizza ed esegue un'immissione; mostra il valore o l'errore. Restituisce il valore."""
        from .errori import ErroreDante, ErroreSintassi

        if self.interprete is None:
            self.interprete = self._crea_interprete()
        if testo.strip():
            self.storia.append(testo.rstrip("\n"))
        try:
            programma = self._analizza(testo)
        except ErroreSintassi as errore:
            corretto = self._proponi_correzioni(testo)
            if corretto is None:
                self._mostra_errore(errore, testo)
                return None
            testo = corretto
            try:
                programma = self._analizza(testo)
            except ErroreDante as e2:
                self._mostra_errore(e2, testo)
                return None
        except ErroreDante as errore:
            self._mostra_errore(errore, testo)
            return None
        errori_prima = self.errori
        valore = self._esegui_programma(programma, testo)
        if self.errori == errori_prima and testo.strip():
            self._ultimo_programma = (programma, testo)
            if not _solo_da_mostrare(programma):   # `x * 2` serve solo a vedere il valore: non si salva
                self.riuscite.append(testo.rstrip("\n"))
        return valore

    def _analizza(self, testo: str) -> Any:
        from .esecuzione import analizza

        nomi, comandi = self._nomi_definiti()
        return analizza(testo, NOME_FILE_REPL, rigoroso=self.rigoroso, nomi_noti=nomi, comandi_noti=comandi)

    def _nomi_definiti(self) -> tuple[frozenset, frozenset]:
        """Nomi definiti nelle righe precedenti e funzioni senza `restituisci` (comandi
        senza parentesi: `saluta Giulia`)."""
        try:
            globale = self.interprete.globale
            nomi = frozenset(globale.voci)
            from .valori import FunzioneDante
            from .comandi import trova_definizioni
            comandi = set()
            definizioni = trova_definizioni("\n".join(self.riuscite))
            for nome in nomi:
                valore = getattr(globale.voci[nome], "valore", None)
                if isinstance(valore, FunzioneDante) and nome in definizioni.comandi:
                    comandi.add(nome)
            return nomi, frozenset(comandi)
        except Exception:  # noqa: BLE001 - interprete non ancora pronto
            return frozenset(), frozenset()

    def _esegui_programma(self, programma: Any, testo: str) -> Any:
        from .errori import ErroreDante
        from .valori import rappresenta

        interprete = self.interprete
        interprete.nome_file = NOME_FILE_REPL
        interprete.sorgente = testo
        try:
            from .cli import esegui_con_pila_grande

            valore = esegui_con_pila_grande(lambda: interprete.esegui(programma), al_interrupt=interprete.ferma)
        except KeyboardInterrupt:
            self._svuota_uscita()
            self._scrivi_errore("Interrotto.")
            return None
        except ErroreDante as errore:
            self._svuota_uscita()
            self._mostra_errore(errore, testo)
            return None
        except RecursionError:
            self._svuota_uscita()
            self._scrivi_errore("ErroreRicorsione\n\nTroppe chiamate annidate: forse una funzione non si ferma mai.")
            return None
        except Exception as e:  # noqa: BLE001 - errore interno: la sessione continua
            self._svuota_uscita()
            self._scrivi_errore(f"Errore interno di Leo ({type(e).__name__}: {e}). La sessione continua.")
            return None
        self._svuota_uscita()
        console = getattr(self, "_console", None)
        if console is not None and console.fermato_per_fine_dati:
            console.fermato_per_fine_dati = False
            console.fine_dati = 0
            from .cli import errore_fine_dati

            self._mostra_errore(errore_fine_dati(), testo)
            return None
        if valore is not None:
            try:
                self.uscita(self._colora_valore(rappresenta(valore, dentro=True)))
            except Exception:  # noqa: BLE001
                self.uscita(repr(valore))
        return valore

    def _colora_valore(self, testo: str) -> str:
        """Il valore mostrato con i colori del tema (numeri, testi, vero/falso...), se attivi."""
        if not self.colori or "\x1b" in testo:
            return testo
        tema = self.tema
        if tema is not None:
            try:
                from .colorazione import ansi

                colorato = ansi(testo, tema)
                if colorato:
                    return colorato
            except Exception:  # noqa: BLE001
                pass
        return colora_valore_semplice(testo)

    def _svuota_uscita(self) -> None:
        console = getattr(self, "_console", None)
        if console is not None:                    # domanda di `chiedi` rimasta senza a capo
            console.chiudi_riga()
        if self._uscita_interprete is not None:
            self._uscita_interprete.svuota()
        else:
            try:
                sys.stdout.flush()
            except (AttributeError, ValueError, OSError):
                pass

    def _proponi_correzioni(self, testo: str) -> str | None:
        """Come la CLI: propone le correzioni di forma e chiede conferma. Testo corretto o None."""
        if self.rigoroso or not self.interattivo:
            return None
        try:
            from .correzioni import applica_correzioni, chiedi_conferma, proponi_correzioni
        except (ImportError, AttributeError):
            return None
        nomi_noti: list[str] = []
        try:
            nomi_noti = list(self.interprete.globale.nomi_visibili())
        except Exception:  # noqa: BLE001
            pass
        try:
            correzioni = proponi_correzioni(testo, NOME_FILE_REPL, rigoroso=self.rigoroso, nomi_noti=nomi_noti)
        except Exception:  # noqa: BLE001 - l'autocorrezione non deve mai rompere la sessione
            return None
        if not correzioni:
            return None
        dove = "questa riga" if testo.strip().count("\n") == 0 else "queste righe"
        try:
            scelte = chiedi_conferma(correzioni, testo, dove, ingresso=self.ingresso, uscita=self.uscita)
        except (EOFError, KeyboardInterrupt):
            self.uscita("")
            return None
        if not scelte:
            return None
        try:
            corretto = applica_correzioni(testo, scelte)
        except ValueError:
            return None
        if corretto == testo:
            return None
        self.uscita("Eseguo:")
        for riga in corretto.rstrip("\n").split("\n"):
            self.uscita("    " + riga)
        return corretto

    def _mostra_errore(self, errore: Any, testo: str) -> None:
        # errore dentro un file importato o in una funzione scritta in un'immissione
        # precedente: la riga di codice si prende da quel testo
        testo = getattr(errore, "sorgente_file", None) or testo
        try:
            from .messaggi import formatta_errore

            messaggio = formatta_errore(errore, testo, tema=self.tema if self.colori else None,
                                        colori=self.colori)
            try:
                from .errori_umani import arricchisci

                messaggio = arricchisci(messaggio, errore, testo, semplice=self.semplice,
                                        consiglio=self.consiglio)
            except Exception:  # noqa: BLE001 - le aggiunte non devono far perdere il messaggio
                pass
        except (ImportError, AttributeError):
            try:
                messaggio = errore.formatta(testo)
            except Exception:  # noqa: BLE001
                messaggio = f"{type(errore).__name__}: {errore}"
        self._scrivi_errore(messaggio)

    def _scrivi_errore(self, testo: str) -> None:
        """Mostra un errore: sull'uscita normale, o su stderr in modo silenzioso (ingresso da pipe)."""
        self.errori += 1
        if not self.silenzioso:
            self.uscita(testo)
            return
        try:
            sys.stdout.flush()
            print(testo, file=sys.stderr, flush=True)
        except (AttributeError, ValueError, OSError):
            self.uscita(testo)

    # --- tema "innovazione": storia, salva, spiega, suggerimenti ---------------------
    def _suggerisci_prossima_parola(self, riga: str) -> None:
        """Dopo `se x > 3` (senza `allora`) ricorda la parola che manca."""
        if self.silenzioso:
            return
        try:
            from .suggerimenti import prossima_parola

            mancante = prossima_parola(riga)
        except Exception:  # noqa: BLE001
            return
        if mancante and mancante[0] in ("volte", "in"):        # `allora`/`fai` a fine riga: facoltativi
            self.uscita(f"Suggerimento: {mancante[1]}")

    def _mostra_storia(self) -> None:
        if not self.storia:
            self.uscita("La storia è vuota: non hai ancora scritto niente.")
            return
        larghezza = len(str(len(self.storia)))
        for i, voce in enumerate(self.storia, 1):
            righe = voce.split("\n")
            self.uscita(f"{i:>{larghezza}}  {righe[0]}")
            for r in righe[1:]:
                self.uscita(f"{'':>{larghezza}}  {r}")

    def _salva(self, nome: str) -> None:
        if not nome:
            self.uscita("Scrivi il nome del file, per esempio `:salva mio_programma.leo`.")
            return
        from pathlib import Path

        percorso = Path(nome)
        if not percorso.suffix:
            percorso = percorso.with_suffix(".leo")
        if not self.riuscite:
            self.uscita("Non c'è ancora niente da salvare: prima scrivi del codice che funziona.")
            return
        try:
            percorso.write_text("\n".join(self.riuscite) + "\n", encoding="utf-8")
        except OSError as e:
            self._scrivi_errore(f"Non riesco a salvare `{percorso}`: {e.strerror or e}.")
            return
        n = len(self.riuscite)
        self.uscita(f"Salvato in `{percorso}` ({n} {'immissione' if n == 1 else 'immissioni'}). "
                    f"Per eseguirlo: leo {percorso}")

    def _spiega(self, argomento: str) -> None:
        from .errori import ErroreDante
        from .spiega import spiega_programma, spiega_sorgente

        livello = "semplice" if self.semplice else "normale"
        if argomento.startswith("--"):
            opzione, _, argomento = argomento.partition(" ")
            argomento = argomento.strip()
            if opzione in ("--semplice", "--dettagli"):
                livello = opzione[2:]
        if argomento == "tutto":
            if not self.riuscite:
                self.uscita("Non c'è ancora niente da spiegare.")
                return
            testo = "\n".join(self.riuscite) + "\n"
            try:
                programma = self._analizza(testo)
            except ErroreDante as errore:
                self._mostra_errore(errore, testo)
                return
            self.uscita(spiega_programma(programma, livello=livello, sorgente=testo, titolo="la tua sessione"))
            return
        if not argomento:
            ultimo = getattr(self, "_ultimo_programma", None)
            if ultimo is None:
                self.uscita("Non c'è ancora niente da spiegare. Scrivi del codice, oppure `:spiega codice`.")
                return
            programma, testo = ultimo
            self.uscita(spiega_programma(programma, livello=livello, sorgente=testo, titolo="il tuo codice"))
            return
        from pathlib import Path

        testo = argomento
        titolo = None
        if e_sorgente(argomento):
            try:
                testo = Path(argomento).read_text(encoding="utf-8-sig")
                titolo = Path(argomento).name
            except OSError as e:
                self._scrivi_errore(f"Non riesco a leggere `{argomento}`: {e.strerror or e}.")
                return
        try:
            if titolo:
                self.uscita(spiega_sorgente(testo, titolo, livello=livello, rigoroso=self.rigoroso))
            else:
                programma = self._analizza(testo + "\n")
                self.uscita(spiega_programma(programma, livello=livello, sorgente=testo, titolo="questo codice"))
        except ErroreDante as errore:
            self._mostra_errore(errore, testo)


def _solo_da_mostrare(programma: Any) -> bool:
    """True se l'immissione contiene solo espressioni senza chiamate (``x``, ``x * 2``)."""
    from . import nodi

    istruzioni = list(getattr(programma, "istruzioni", []) or [])
    return bool(istruzioni) and all(
        isinstance(i, nodi.IstruzioneEspressione) and not isinstance(i.espressione, nodi.Chiamata)
        for i in istruzioni)


# ---------------------------------------------------------------------------
# Colori dei valori e completamento con Tab
# ---------------------------------------------------------------------------

_ANSI_NUMERO = "\x1b[36m"
_ANSI_TESTO = "\x1b[32m"
_ANSI_LOGICO = "\x1b[35m"
_ANSI_FINE = "\x1b[0m"


def colora_valore_semplice(testo: str) -> str:
    """Colori di riserva (senza tema): numeri in ciano, testi in verde, vero/falso/nulla in viola."""
    import re

    def sostituisci(m: "re.Match[str]") -> str:
        if m.group(1):
            return _ANSI_TESTO + m.group(1) + _ANSI_FINE
        if m.group(2):
            return _ANSI_NUMERO + m.group(2) + _ANSI_FINE
        return _ANSI_LOGICO + m.group(3) + _ANSI_FINE

    return re.sub(r'("(?:\\.|[^"\\])*")|(-?\b\d+(?:\.\d+)?\b)|\b(vero|falso|nulla)\b', sostituisci, testo)


class Completatore:
    """Completamento per ``readline``: parole chiave, nomi definiti, funzioni di libreria.

    La parola suggerita dal contesto (``allora`` dopo ``se x > 3``) viene per prima.
    ``riga_corrente``: funzione che restituisce la riga scritta finora (readline.get_line_buffer).
    """

    def __init__(self, repl: "Repl", riga_corrente: Callable[[], str] = lambda: "") -> None:
        self.repl = repl
        self.riga_corrente = riga_corrente
        self._candidati: list[str] = []

    def nomi(self) -> list[str]:
        nomi: set[str] = set(COMANDI_REPL)
        interprete = getattr(self.repl, "interprete", None)
        ambiente = getattr(interprete, "globale", None)
        try:
            nomi |= set(ambiente.nomi_visibili())
        except Exception:  # noqa: BLE001
            pass
        try:
            from . import registro

            if not registro.FUNZIONI:
                registro.carica_libreria()
            nomi |= set(registro.FUNZIONI)
        except Exception:  # noqa: BLE001
            pass
        return sorted(nomi)

    def candidati(self, prefisso: str, riga: str = "") -> list[str]:
        from .suggerimenti import completa_parola

        prima = riga[: len(riga) - len(prefisso)] if prefisso and riga.endswith(prefisso) else riga
        nomi = self.nomi()
        if not prima.strip() and prefisso.startswith(":"):
            return [c for c in COMANDI_REPL if c.startswith(prefisso)]
        return completa_parola(prefisso, [n for n in nomi if not n.startswith(":")], riga=prima)

    def __call__(self, testo: str, stato: int) -> str | None:
        if stato == 0:
            try:
                self._candidati = self.candidati(testo, self.riga_corrente())
            except Exception:  # noqa: BLE001 - il Tab non deve mai rompere la sessione
                self._candidati = []
        return self._candidati[stato] if stato < len(self._candidati) else None


def attiva_completamento(repl: "Repl") -> bool:
    """Collega :class:`Completatore` a ``readline`` (se c'e'). False se non disponibile.

    Su Windows senza ``readline`` (o ``pyreadline3``) si prosegue senza Tab:
    le frecce e la cronologia della console restano quelle di Windows.
    """
    try:
        import readline
    except ImportError:
        return False
    try:
        completatore = Completatore(repl, readline.get_line_buffer)
        readline.set_completer(completatore)
        readline.set_completer_delims(" \t\n()[]{},+-*/=<>%^\"'")
        documento = getattr(readline, "__doc__", "") or ""
        if "libedit" in documento:                   # macOS
            readline.parse_and_bind("bind ^I rl_complete")
        else:
            readline.parse_and_bind("tab: complete")
    except Exception:  # noqa: BLE001 - readline incompleto: niente Tab, ma la sessione va
        return False
    return True
