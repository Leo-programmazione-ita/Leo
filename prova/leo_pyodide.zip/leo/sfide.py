"""`leo sfida`: piccoli rompicapi di programmazione a livelli, con verifica automatica.

Ogni :class:`Sfida` ha un testo, un aiuto e una o piu' prove: il programma
dello studente viene eseguito con certi dati in ingresso (le risposte a
``chiedi``) e la sua uscita viene confrontata con quella attesa. Alcune sfide
chiedono di usare un certo costrutto (un ciclo, un ``se``, una funzione) o
vietano una funzione di libreria.

Le sfide si sbloccano in ordine: la sfida N si puo' affrontare quando la N-1
e' superata. Il progresso si salva in ``sfide.json`` nella cartella utente
(o nel file indicato dalla variabile d'ambiente ``LEO_SFIDE_PROGRESSO``, o la vecchia ``DANTE_SFIDE_PROGRESSO``).

API:
    SFIDE                                     tuple[Sfida, ...]
    sfida(numero) -> Sfida                    (KeyError se non esiste)
    verifica(sfida, sorgente, *, tempo_massimo=3.0) -> Esito
    percorso_progresso() -> Path
    carica_progresso(percorso=None) -> set[int]
    salva_progresso(superate, percorso=None) -> None
    sbloccata(numero, superate) -> bool
    elenco(superate) -> str
    presentazione(sfida) -> str
"""

from __future__ import annotations

import json
import os
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

from . import nodi as N

__all__ = ["Sfida", "Prova", "Esito", "SFIDE", "sfida", "verifica", "percorso_progresso",
           "carica_progresso", "salva_progresso", "sbloccata", "elenco", "presentazione",
           "VARIABILE_PROGRESSO"]

VARIABILE_PROGRESSO = "LEO_SFIDE_PROGRESSO"
#: Il vecchio nome della variabile (quando Leo si chiamava Dante), letto se manca quella nuova.
VARIABILE_PROGRESSO_VECCHIA = "DANTE_SFIDE_PROGRESSO"

_CICLI = ("PerOgni", "Mentre", "Ripeti")


@dataclass
class Prova:
    """Una prova: dati in ingresso (risposte a ``chiedi``) e uscita attesa."""

    ingressi: list[str]
    attesa: str
    #: codice aggiunto in fondo al programma (per provare le funzioni)
    codice_extra: str = ""


@dataclass
class Sfida:
    numero: int
    titolo: str
    livello: str
    testo: str
    aiuto: str
    prove: list[Prova]
    #: nomi di nodi AST che devono comparire (uno qualsiasi di ogni gruppo)
    richiede: list[tuple[str, ...]] = field(default_factory=list)
    #: nomi di funzioni che non si possono usare
    vietate: tuple[str, ...] = ()
    #: una soluzione di riferimento (usata dai test, mostrata con --soluzione)
    soluzione: str = ""


@dataclass
class Esito:
    superata: bool
    messaggi: list[str]

    def testo(self) -> str:
        return "\n".join(self.messaggi)


_NOMI_COSTRUTTI = {
    "PerOgni": "`per ogni`", "Mentre": "`mentre`", "Ripeti": "`ripeti`", "Se": "`se`",
    "DefinizioneFunzione": "una `funzione`", "Dichiarazione": "una `variabile`",
    "Restituisci": "`restituisci`",
}

SFIDE: tuple[Sfida, ...] = (
    Sfida(1, "Ciao, mondo!", "facile",
          "Scrivi un programma che mostri sullo schermo esattamente:\n    Ciao, mondo!",
          "Usa `stampa(\"...\")` con il testo tra virgolette.",
          [Prova([], "Ciao, mondo!")],
          soluzione='stampa("Ciao, mondo!")\n'),
    Sfida(2, "La mia età", "facile",
          "Crea una variabile `anni` con il valore 10 e poi stampa la frase:\n    Ho 10 anni\n"
          "usando la variabile (non scrivere 10 direttamente nel testo).",
          "Dentro un testo puoi mettere una variabile tra graffe: \"Ho {anni} anni\".",
          [Prova([], "Ho 10 anni")],
          richiede=[("Dichiarazione",)],
          soluzione='variabile anni = 10\nstampa("Ho {anni} anni")\n'),
    Sfida(3, "Conto alla rovescia", "facile",
          "Stampa i numeri da 5 a 1, uno per riga, e poi la parola `Via!`.\nUsa un ciclo.",
          "Con `per ogni i in 5..1 fai` puoi contare all'indietro.",
          [Prova([], "5\n4\n3\n2\n1\nVia!")],
          richiede=[_CICLI],
          soluzione='per ogni i in 5..1 fai\n    stampa(i)\nfine\nstampa("Via!")\n'),
    Sfida(4, "Pari o dispari", "medio",
          "Chiedi un numero con `chiedi` e stampa `pari` se è pari, `dispari` se è dispari.",
          "Trasforma la risposta con `intero(...)`; un numero è pari se `n % 2 == 0`.",
          [Prova(["4"], "pari"), Prova(["7"], "dispari"), Prova(["0"], "pari")],
          richiede=[("Se",)],
          soluzione='variabile n = intero(chiedi("Numero: "))\nse n % 2 == 0 allora\n    stampa("pari")\n'
                    'altrimenti\n    stampa("dispari")\nfine\n'),
    Sfida(5, "La somma da 1 a n", "medio",
          "Chiedi un numero n e stampa la somma di tutti i numeri da 1 a n.\n"
          "Per esempio con 5 stampa 15 (1 + 2 + 3 + 4 + 5). Usa un ciclo.",
          "Crea `variabile totale = 0` e con `per ogni i in 1..n fai` aggiungi `i` al totale.",
          [Prova(["5"], "15"), Prova(["10"], "55"), Prova(["1"], "1")],
          richiede=[_CICLI], vietate=("somma",),
          soluzione='variabile n = intero(chiedi("n: "))\nvariabile totale = 0\nper ogni i in 1..n fai\n'
                    '    totale += i\nfine\nstampa(totale)\n'),
    Sfida(6, "La funzione doppio", "medio",
          "Scrivi una funzione `doppio(n)` che restituisce il doppio di n.\n"
          "La verifica la prova da sola, per esempio con `doppio(4)`, che deve dare 8.",
          "`funzione doppio(n)` ... `restituisci n * 2` ... `fine`.",
          [Prova([], "8", "stampa(doppio(4))"), Prova([], "0", "stampa(doppio(0))"),
           Prova([], "-14", "stampa(doppio(-7))")],
          richiede=[("DefinizioneFunzione",), ("Restituisci",)],
          soluzione='funzione doppio(n)\n    restituisci n * 2\nfine\n'),
    Sfida(7, "La tabellina", "medio",
          "Chiedi un numero n e stampa la sua tabellina da 1 a 10 in questa forma:\n"
          "    3 x 1 = 3\n    3 x 2 = 6\n    ...\n    3 x 10 = 30",
          "Dentro il ciclo: `stampa(\"{n} x {i} = {n * i}\")`.",
          [Prova(["3"], "\n".join(f"3 x {i} = {3 * i}" for i in range(1, 11))),
           Prova(["7"], "\n".join(f"7 x {i} = {7 * i}" for i in range(1, 11)))],
          richiede=[_CICLI],
          soluzione='variabile n = intero(chiedi("n: "))\nper ogni i in 1..10 fai\n'
                    '    stampa("{n} x {i} = {n * i}")\nfine\n'),
    Sfida(8, "Il più grande", "difficile",
          "Scrivi una funzione `piu_grande(lista)` che restituisce il numero più grande della lista,\n"
          "SENZA usare la funzione `massimo`.",
          "Parti dal primo elemento (`lista[0]`) e confrontalo con tutti gli altri in un ciclo.",
          [Prova([], "9", "stampa(piu_grande([3, 9, 2]))"),
           Prova([], "-1", "stampa(piu_grande([-5, -1, -3]))"),
           Prova([], "42", "stampa(piu_grande([42]))")],
          richiede=[("DefinizioneFunzione",), _CICLI], vietate=("massimo",),
          soluzione='funzione piu_grande(lista)\n    variabile grande = lista[0]\n    per ogni x in lista fai\n'
                    '        se x > grande allora\n            grande = x\n        fine\n    fine\n'
                    '    restituisci grande\nfine\n'),
    Sfida(9, "Bim Bum", "difficile",
          "Stampa i numeri da 1 a 15, uno per riga, ma:\n"
          "  - al posto dei multipli di 3 scrivi `Bim`,\n"
          "  - al posto dei multipli di 5 scrivi `Bum`,\n"
          "  - al posto dei multipli di 3 e di 5 scrivi `BimBum`.",
          "Controlla prima il caso `i % 15 == 0`, poi `i % 3`, poi `i % 5` con `altrimenti se`.",
          [Prova([], "\n".join("BimBum" if i % 15 == 0 else "Bim" if i % 3 == 0 else "Bum" if i % 5 == 0
                                else str(i) for i in range(1, 16)))],
          richiede=[_CICLI, ("Se",)],
          soluzione='per ogni i in 1..15 fai\n    se i % 15 == 0 allora\n        stampa("BimBum")\n'
                    '    altrimenti se i % 3 == 0 allora\n        stampa("Bim")\n'
                    '    altrimenti se i % 5 == 0 allora\n        stampa("Bum")\n'
                    '    altrimenti\n        stampa(i)\n    fine\nfine\n'),
    Sfida(10, "Conta le vocali", "difficile",
          "Scrivi una funzione `vocali(parola)` che restituisce quante vocali (a, e, i, o, u)\n"
          "ci sono nella parola. Per esempio `vocali(\"leo\")` dà 2.",
          "Scorri le lettere con `per ogni lettera in parola fai` e controlla `lettera in \"aeiou\"`.",
          [Prova([], "2", 'stampa(vocali("leo"))'), Prova([], "0", 'stampa(vocali("brr"))'),
           Prova([], "5", 'stampa(vocali("aiuole"))')],
          richiede=[("DefinizioneFunzione",), _CICLI],
          soluzione='funzione vocali(parola)\n    variabile conta = 0\n    per ogni lettera in parola fai\n'
                    '        se lettera in "aeiou" allora\n            conta += 1\n        fine\n    fine\n'
                    '    restituisci conta\nfine\n'),
)


def sfida(numero: int) -> Sfida:
    for s in SFIDE:
        if s.numero == numero:
            return s
    raise KeyError(numero)


# ---------------------------------------------------------------------------
# Progresso
# ---------------------------------------------------------------------------

def percorso_progresso() -> Path:
    env = os.environ.get(VARIABILE_PROGRESSO) or os.environ.get(VARIABILE_PROGRESSO_VECCHIA)
    if env:
        return Path(env)
    from .percorsi import cartella_utente

    return cartella_utente() / "sfide.json"


def carica_progresso(percorso: str | os.PathLike | None = None) -> set[int]:
    """Numeri delle sfide superate (insieme vuoto se il file manca o e' rovinato)."""
    p = Path(percorso) if percorso is not None else percorso_progresso()
    try:
        dati = json.loads(p.read_text(encoding="utf-8"))
        return {int(n) for n in dati.get("superate", [])}
    except (OSError, ValueError, TypeError, AttributeError):
        return set()


def salva_progresso(superate: Iterable[int], percorso: str | os.PathLike | None = None) -> None:
    p = Path(percorso) if percorso is not None else percorso_progresso()
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps({"superate": sorted(set(superate))}, ensure_ascii=False, indent=2) + "\n",
                     encoding="utf-8")
    except OSError:
        pass  # niente disco scrivibile: il progresso non si salva, ma la sfida funziona


def sbloccata(numero: int, superate: set[int]) -> bool:
    """La sfida 1 e' sempre aperta; le altre quando la precedente e' superata."""
    return numero == SFIDE[0].numero or (numero - 1) in superate or numero in superate


def elenco(superate: set[int]) -> str:
    righe = ["Le sfide di Leo", ""]
    livello = None
    for s in SFIDE:
        if s.livello != livello:
            livello = s.livello
            righe.append(f"Livello {livello}:")
        if s.numero in superate:
            stato = "[fatta]   "
        elif sbloccata(s.numero, superate):
            stato = "[da fare] "
        else:
            stato = "[chiusa]  "
        righe.append(f"  {s.numero:>2}. {stato}{s.titolo}")
    fatte = len(superate & {s.numero for s in SFIDE})
    righe.append("")
    righe.append(f"Hai superato {fatte} sfide su {len(SFIDE)}.")
    prossima = next((s for s in SFIDE if s.numero not in superate), None)
    if prossima is None:
        righe.append("Tutte le sfide sono superate.")
    else:
        righe.append(f"Prossima: `leo sfida {prossima.numero}`.")
    return "\n".join(righe)


def presentazione(s: Sfida) -> str:
    return (f"Sfida {s.numero} ({s.livello}): {s.titolo}\n\n{s.testo}\n\n"
            f"Aiuto: {s.aiuto}")


# ---------------------------------------------------------------------------
# Verifica
# ---------------------------------------------------------------------------

def _nodi(nodo: Any) -> Iterable[Any]:
    """Tutti i nodi dell'albero (visita in profondita')."""
    pila = [nodo]
    while pila:
        corrente = pila.pop()
        if isinstance(corrente, list):
            pila.extend(corrente)
            continue
        if isinstance(corrente, tuple):
            pila.extend(corrente)
            continue
        if not isinstance(corrente, N.Nodo):
            continue
        yield corrente
        for valore in vars(corrente).values():
            if isinstance(valore, (N.Nodo, list, tuple)):
                pila.append(valore)


def _normalizza(testo: str) -> str:
    righe = [r.rstrip() for r in testo.replace("\r\n", "\n").split("\n")]
    while righe and not righe[-1]:
        righe.pop()
    return "\n".join(righe)


def _esegui(sorgente: str, ingressi: list[str], tempo_massimo: float) -> tuple[str, Any]:
    """Esegue il programma; restituisce (uscita, errore o None)."""
    from .errori import ErroreDante
    from .esecuzione import analizza
    from .interprete import Interprete

    uscita: list[str] = []
    dati = list(ingressi)

    def leggi(_domanda: str) -> str | None:
        return dati.pop(0) if dati else None

    interprete = Interprete(nome_file="sfida.leo", sorgente=sorgente,
                            uscita=uscita.append, ingresso=leggi)
    risultato: dict[str, Any] = {}

    def lavoro() -> None:
        try:
            interprete.esegui(analizza(sorgente, "sfida.leo"))
        except ErroreDante as e:
            risultato["errore"] = e
        except RecursionError:
            risultato["errore"] = "ricorsione"
        except Exception as e:  # noqa: BLE001 - errore interno: si segnala senza traceback
            risultato["errore"] = f"errore interno ({type(e).__name__}: {e})"

    thread = threading.Thread(target=lavoro, daemon=True)
    thread.start()
    thread.join(tempo_massimo)
    if thread.is_alive():
        interprete.ferma()
        thread.join(1.0)
        return "".join(uscita), "tempo"
    return "".join(uscita), risultato.get("errore")


def verifica(s: Sfida, sorgente: str, *, tempo_massimo: float = 3.0) -> Esito:
    """Controlla il programma ``sorgente`` per la sfida ``s``."""
    from .errori import ErroreDante
    from .esecuzione import analizza

    if not sorgente.strip():
        return Esito(False, ["Il programma è vuoto: scrivi almeno un'istruzione."])
    try:
        programma = analizza(sorgente, "sfida.leo")
    except ErroreDante as e:
        from .errori_umani import formatta_umano

        return Esito(False, ["Il programma contiene un errore di scrittura:", "", formatta_umano(e, sorgente)])
    tipi = {type(n).__name__ for n in _nodi(programma.istruzioni)}
    for gruppo in s.richiede:
        if not tipi.intersection(gruppo):
            nomi = " o ".join(_NOMI_COSTRUTTI.get(g, g) for g in gruppo)
            return Esito(False, [f"Requisito mancante: questa sfida chiede di usare {nomi}.", f"Aiuto: {s.aiuto}"])
    usati = {n.funzione.nome for n in _nodi(programma.istruzioni)
             if isinstance(n, N.Chiamata) and isinstance(n.funzione, N.Nome)}
    for nome in s.vietate:
        if nome in usati:
            return Esito(False, [f"In questa sfida non puoi usare `{nome}`: ottieni lo stesso risultato senza."])
    for i, prova in enumerate(s.prove, 1):
        codice = sorgente if not prova.codice_extra else sorgente.rstrip("\n") + "\n" + prova.codice_extra + "\n"
        uscita, errore = _esegui(codice, prova.ingressi, tempo_massimo)
        con = f" con {', '.join(repr(x) for x in prova.ingressi)}" if prova.ingressi else ""
        if prova.codice_extra:
            con = f" (Leo ha provato `{prova.codice_extra}`)"
        if errore == "tempo":
            return Esito(False, [f"Prova {i}{con}: il programma non finisce mai.",
                                 "Controlla che la condizione di ogni `mentre` prima o poi diventi falsa."])
        if errore == "ricorsione":
            return Esito(False, [f"Prova {i}{con}: una funzione chiama se stessa senza fermarsi."])
        if errore is not None:
            if isinstance(errore, ErroreDante):
                from .errori_umani import formatta_umano

                testo = formatta_umano(errore, codice)
            else:
                testo = str(errore)
            return Esito(False, [f"Prova {i}{con}: il programma si è fermato con un errore.", "", testo])
        if _normalizza(uscita) != _normalizza(prova.attesa):
            messaggi = [f"Prova {i}{con}: l'uscita non corrisponde a quella attesa.", "", "Uscita attesa:"]
            messaggi += ["    " + r for r in _normalizza(prova.attesa).split("\n")]
            messaggi += ["", "Uscita del programma:"]
            ottenuta = _normalizza(uscita)
            messaggi += ["    " + r for r in ottenuta.split("\n")] if ottenuta else ["    (niente)"]
            messaggi += ["", f"Aiuto: {s.aiuto}"]
            return Esito(False, messaggi)
    n = len(s.prove)
    return Esito(True, [f"Sfida {s.numero} superata ({n} {'prova riuscita' if n == 1 else 'prove riuscite'} su {n})."])
