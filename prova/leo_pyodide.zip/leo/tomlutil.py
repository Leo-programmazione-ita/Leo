"""Lettura e scrittura di TOML senza dipendenze (CONTRATTO CONDIVISO).

Serve perche' ``tomllib`` esiste solo da Python 3.11 e non sa scrivere.

API pubblica:
    leggi_toml(testo: str) -> dict
    carica_toml(percorso) -> dict            # ErroreFile se non leggibile, ErroreToml se malformato
    scrivi_toml(dati: dict) -> str
    salva_toml(percorso, dati: dict) -> None  # scrittura atomica (file temporaneo + replace)
    ErroreToml(ValueError): .riga, .messaggio

Lettura: prova prima ``tomllib`` (se disponibile); se manca, o se rifiuta il
testo, usa il parser interno, che accetta il sottoinsieme usato da Leo ed e'
un po' piu' tollerante (es. chiavi nude con lettere accentate).
Supportati: commenti, [tabelle], [tabelle.annidate], [[array di tabelle]],
chiavi nude/tra virgolette/puntate, testi "base" e 'letterali' anche su piu'
righe, interi (anche 0x/0o/0b e con _), decimali (anche inf/nan), booleani,
array (anche su piu' righe) e tabelle in linea. Date/ore: NON supportate.

Scrittura: i valori semplici di una tabella vengono prima delle sottotabelle;
un elenco di soli dizionari (non vuoto) diventa un array di tabelle ``[[...]]``;
dizionari dentro array diventano tabelle in linea. ``None`` non e'
rappresentabile in TOML: le chiavi con valore None vengono OMESSE.
"""

from __future__ import annotations

import math
import os
import re
from typing import Any

try:  # Python 3.11+
    import tomllib as _tomllib  # type: ignore[import-not-found]
except ImportError:  # Python 3.10
    _tomllib = None


class ErroreToml(ValueError):
    """TOML non valido. ``riga`` e' 1-based (0 se ignota)."""

    def __init__(self, messaggio: str, riga: int = 0) -> None:
        super().__init__(f"{messaggio} (riga {riga})" if riga else messaggio)
        self.messaggio = messaggio
        self.riga = riga


# ===========================================================================
# Lettura
# ===========================================================================

def leggi_toml(testo: str) -> dict:
    """Analizza un testo TOML e restituisce un dizionario."""
    if testo.startswith("﻿"):
        testo = testo[1:]
    if _tomllib is not None:
        try:
            return _tomllib.loads(testo)
        except _tomllib.TOMLDecodeError:
            pass  # riprova col parser tollerante; se fallisce anche lui, errore suo
    return _ParserToml(testo).analizza()


def carica_toml(percorso: str | os.PathLike) -> dict:
    """Legge e analizza un file TOML (UTF-8)."""
    from .errori import ErroreFile

    try:
        with open(percorso, "r", encoding="utf-8") as f:
            testo = f.read()
    except OSError as e:
        raise ErroreFile(f"Non riesco a leggere il file `{os.fspath(percorso)}`: {e.strerror or e}.") from e
    return leggi_toml(testo)


_CHIAVE_NUDA = re.compile(r"[\w\-]+", re.UNICODE)
_NUMERO = re.compile(
    r"[+-]?(?:0x[0-9A-Fa-f_]+|0o[0-7_]+|0b[01_]+|inf|nan|"
    r"(?:\d[\d_]*)?(?:\.\d[\d_]*)?(?:[eE][+-]?\d[\d_]*)?)"
)
_ESCAPE = {"b": "\b", "t": "\t", "n": "\n", "f": "\f", "r": "\r", '"': '"', "\\": "\\"}


class _ParserToml:
    def __init__(self, testo: str) -> None:
        self.t = testo.replace("\r\n", "\n")
        self.i = 0
        self.n = len(self.t)
        self.radice: dict = {}
        # tabelle definite esplicitamente con [..] (id) per evitare duplicati
        self.definite: set[int] = set()
        self.in_linea: set[int] = set()

    # --- utilita' ---------------------------------------------------------
    @property
    def riga(self) -> int:
        return self.t.count("\n", 0, self.i) + 1

    def errore(self, msg: str) -> ErroreToml:
        return ErroreToml(msg, self.riga)

    def car(self, k: int = 0) -> str:
        j = self.i + k
        return self.t[j] if j < self.n else ""

    def salta_spazi(self) -> None:
        while self.i < self.n and self.t[self.i] in " \t":
            self.i += 1

    def salta_commento(self) -> None:
        if self.car() == "#":
            while self.i < self.n and self.t[self.i] != "\n":
                self.i += 1

    def salta_vuoti_e_commenti(self) -> None:
        """Spazi, a capo e commenti (usato dentro gli array)."""
        while self.i < self.n:
            c = self.t[self.i]
            if c in " \t\n":
                self.i += 1
            elif c == "#":
                self.salta_commento()
            else:
                break

    def fine_riga(self) -> None:
        self.salta_spazi()
        self.salta_commento()
        if self.i < self.n:
            if self.t[self.i] != "\n":
                raise self.errore(f"Carattere inatteso `{self.t[self.i]}` dopo il valore")
            self.i += 1

    # --- struttura --------------------------------------------------------
    def analizza(self) -> dict:
        corrente = self.radice
        while True:
            self.salta_vuoti_e_commenti()
            if self.i >= self.n:
                break
            if self.car() == "[":
                corrente = self.intestazione()
            else:
                chiavi = self.chiave()
                self.salta_spazi()
                if self.car() != "=":
                    raise self.errore("Manca `=` dopo la chiave")
                self.i += 1
                self.salta_spazi()
                valore = self.valore()
                self.assegna(corrente, chiavi, valore)
                self.fine_riga()
        return self.radice

    def intestazione(self) -> dict:
        doppia = self.t.startswith("[[", self.i)
        self.i += 2 if doppia else 1
        self.salta_spazi()
        chiavi = self.chiave()
        self.salta_spazi()
        chiusura = "]]" if doppia else "]"
        if not self.t.startswith(chiusura, self.i):
            raise self.errore(f"Manca `{chiusura}` a chiusura dell'intestazione")
        self.i += len(chiusura)
        self.fine_riga()
        tabella = self.radice
        for k in chiavi[:-1]:
            tabella = self.scendi(tabella, k)
        ultima = chiavi[-1]
        if doppia:
            elenco = tabella.setdefault(ultima, [])
            if not isinstance(elenco, list):
                raise self.errore(f"`{ultima}` non è un array di tabelle")
            nuova: dict = {}
            elenco.append(nuova)
            return nuova
        esistente = tabella.get(ultima)
        if esistente is None:
            esistente = tabella[ultima] = {}
        elif not isinstance(esistente, dict) or id(esistente) in self.definite:
            raise self.errore(f"Tabella `{'.'.join(chiavi)}` definita due volte")
        self.definite.add(id(esistente))
        return esistente

    def scendi(self, tabella: dict, k: str) -> dict:
        v = tabella.get(k)
        if v is None:
            v = tabella[k] = {}
        if isinstance(v, list) and v and isinstance(v[-1], dict):
            return v[-1]
        if not isinstance(v, dict) or id(v) in self.in_linea:
            raise self.errore(f"`{k}` non è una tabella")
        return v

    def assegna(self, tabella: dict, chiavi: list[str], valore: Any) -> None:
        for k in chiavi[:-1]:
            tabella = self.scendi(tabella, k)
        if chiavi[-1] in tabella:
            raise self.errore(f"Chiave `{'.'.join(chiavi)}` ripetuta")
        tabella[chiavi[-1]] = valore

    def chiave(self) -> list[str]:
        parti = []
        while True:
            self.salta_spazi()
            c = self.car()
            if c == '"':
                parti.append(self.testo_base())
            elif c == "'":
                parti.append(self.testo_letterale())
            else:
                m = _CHIAVE_NUDA.match(self.t, self.i)
                if not m:
                    raise self.errore("Chiave mancante o non valida")
                parti.append(m.group(0))
                self.i = m.end()
            self.salta_spazi()
            if self.car() == ".":
                self.i += 1
                continue
            return parti

    # --- valori -----------------------------------------------------------
    def valore(self) -> Any:
        c = self.car()
        if c == '"':
            if self.t.startswith('"""', self.i):
                return self.testo_multiriga_base()
            return self.testo_base()
        if c == "'":
            if self.t.startswith("'''", self.i):
                return self.testo_multiriga_letterale()
            return self.testo_letterale()
        if c == "[":
            return self.array()
        if c == "{":
            return self.tabella_in_linea()
        if self.t.startswith("true", self.i) and not self._continua_parola(4):
            self.i += 4
            return True
        if self.t.startswith("false", self.i) and not self._continua_parola(5):
            self.i += 5
            return False
        return self.numero()

    def _continua_parola(self, k: int) -> bool:
        c = self.car(k)
        return bool(c) and (c.isalnum() or c == "_")

    def numero(self) -> Any:
        m = _NUMERO.match(self.t, self.i)
        grezzo = m.group(0) if m else ""
        if not grezzo or grezzo in "+-":
            raise self.errore("Valore non valido")
        self.i = m.end()
        s = grezzo.replace("_", "")
        segno = -1 if s.startswith("-") else 1
        corpo = s.lstrip("+-")
        try:
            if corpo.startswith("0x"):
                return segno * int(corpo[2:], 16)
            if corpo.startswith("0o"):
                return segno * int(corpo[2:], 8)
            if corpo.startswith("0b"):
                return segno * int(corpo[2:], 2)
            if corpo == "inf":
                return segno * math.inf
            if corpo == "nan":
                return math.nan
            if any(ch in corpo for ch in ".eE"):
                return float(s)
            return int(s)
        except ValueError:
            raise self.errore(f"Numero non valido `{grezzo}`") from None

    def testo_base(self) -> str:
        self.i += 1
        out = []
        while True:
            if self.i >= self.n or self.t[self.i] == "\n":
                raise self.errore("Testo non chiuso: manca `\"`")
            c = self.t[self.i]
            if c == '"':
                self.i += 1
                return "".join(out)
            if c == "\\":
                out.append(self.escape())
                continue
            out.append(c)
            self.i += 1

    def escape(self) -> str:
        e = self.car(1)
        if e in _ESCAPE:
            self.i += 2
            return _ESCAPE[e]
        if e in ("u", "U"):
            lung = 4 if e == "u" else 8
            cifre = self.t[self.i + 2:self.i + 2 + lung]
            try:
                c = chr(int(cifre, 16))
            except ValueError:
                raise self.errore("Sequenza \\u non valida") from None
            self.i += 2 + lung
            return c
        raise self.errore(f"Sequenza di escape `\\{e}` non valida")

    def testo_letterale(self) -> str:
        fine = self.t.find("'", self.i + 1)
        a_capo = self.t.find("\n", self.i + 1)
        if fine < 0 or (0 <= a_capo < fine):
            raise self.errore("Testo non chiuso: manca `'`")
        s = self.t[self.i + 1:fine]
        self.i = fine + 1
        return s

    def testo_multiriga_base(self) -> str:
        self.i += 3
        if self.car() == "\n":
            self.i += 1
        out = []
        while True:
            if self.i >= self.n:
                raise self.errore('Testo multiriga non chiuso: manca `"""`')
            if self.t.startswith('"""', self.i):
                # fino a due virgolette extra fanno parte del testo
                extra = 0
                while self.car(3 + extra) == '"' and extra < 2:
                    extra += 1
                out.append('"' * extra)
                self.i += 3 + extra
                return "".join(out)
            c = self.t[self.i]
            if c == "\\":
                # "\" a fine riga: rimuove a capo e spazi successivi
                j = self.i + 1
                while j < self.n and self.t[j] in " \t":
                    j += 1
                if j < self.n and self.t[j] == "\n":
                    while j < self.n and self.t[j] in " \t\n":
                        j += 1
                    self.i = j
                    continue
                out.append(self.escape())
                continue
            out.append(c)
            self.i += 1

    def testo_multiriga_letterale(self) -> str:
        self.i += 3
        if self.car() == "\n":
            self.i += 1
        fine = self.t.find("'''", self.i)
        if fine < 0:
            raise self.errore("Testo multiriga non chiuso: manca `'''`")
        while self.t.startswith("'", fine + 3) and fine + 3 < self.n:
            fine += 1
        s = self.t[self.i:fine]
        self.i = fine + 3
        return s

    def array(self) -> list:
        self.i += 1
        out = []
        while True:
            self.salta_vuoti_e_commenti()
            if self.car() == "]":
                self.i += 1
                return out
            out.append(self.valore())
            self.salta_vuoti_e_commenti()
            if self.car() == ",":
                self.i += 1
                continue
            if self.car() == "]":
                self.i += 1
                return out
            raise self.errore("Nell'array manca `,` o `]`")

    def tabella_in_linea(self) -> dict:
        self.i += 1
        out: dict = {}
        self.in_linea.add(id(out))
        self.salta_spazi()
        if self.car() == "}":
            self.i += 1
            return out
        while True:
            self.salta_spazi()
            chiavi = self.chiave()
            self.salta_spazi()
            if self.car() != "=":
                raise self.errore("Manca `=` nella tabella in linea")
            self.i += 1
            self.salta_spazi()
            self.assegna(out, chiavi, self.valore())
            self.salta_spazi()
            if self.car() == ",":
                self.i += 1
                continue
            if self.car() == "}":
                self.i += 1
                return out
            raise self.errore("Nella tabella in linea manca `,` o `}`")


# ===========================================================================
# Scrittura
# ===========================================================================

_CHIAVE_NUDA_ASCII = re.compile(r"^[A-Za-z0-9_\-]+$")


def _chiave(k: str) -> str:
    return k if _CHIAVE_NUDA_ASCII.match(k) else _testo(k)


def _testo(s: str) -> str:
    out = ['"']
    for c in s:
        if c == '"':
            out.append('\\"')
        elif c == "\\":
            out.append("\\\\")
        elif c == "\n":
            out.append("\\n")
        elif c == "\t":
            out.append("\\t")
        elif c == "\r":
            out.append("\\r")
        elif ord(c) < 0x20 or ord(c) == 0x7F:
            out.append(f"\\u{ord(c):04X}")
        else:
            out.append(c)
    out.append('"')
    return "".join(out)


def _valore(v: Any) -> str:
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        if math.isnan(v):
            return "nan"
        if math.isinf(v):
            return "inf" if v > 0 else "-inf"
        return repr(v)
    if isinstance(v, str):
        return _testo(v)
    if isinstance(v, (list, tuple)):
        return "[" + ", ".join(_valore(x) for x in v if x is not None) + "]"
    if isinstance(v, dict):
        coppie = [f"{_chiave(str(k))} = {_valore(x)}" for k, x in v.items() if x is not None]
        return "{ " + ", ".join(coppie) + " }" if coppie else "{}"
    raise TypeError(f"Valore non rappresentabile in TOML: {v!r}")


def _e_array_di_tabelle(v: Any) -> bool:
    return isinstance(v, (list, tuple)) and len(v) > 0 and all(isinstance(x, dict) for x in v)


def scrivi_toml(dati: dict) -> str:
    """Converte un dizionario in testo TOML (termina con un a capo)."""
    righe: list[str] = []
    _scrivi_tabella(dati, [], righe)
    testo = "\n".join(righe).strip("\n")
    return testo + "\n" if testo else ""


def _scrivi_tabella(tab: dict, percorso: list[str], righe: list[str]) -> None:
    semplici = []
    sotto = []
    for k, v in tab.items():
        if v is None:
            continue
        if isinstance(v, dict) or _e_array_di_tabelle(v):
            sotto.append((str(k), v))
        else:
            semplici.append(f"{_chiave(str(k))} = {_valore(v)}")
    righe.extend(semplici)
    for k, v in sotto:
        nuovo = percorso + [k]
        nome = ".".join(_chiave(p) for p in nuovo)
        if isinstance(v, dict):
            ha_semplici = any(not (isinstance(x, dict) or _e_array_di_tabelle(x))
                              for x in v.values() if x is not None)
            if ha_semplici or not v:
                righe.append("")
                righe.append(f"[{nome}]")
            _scrivi_tabella(v, nuovo, righe)
        else:
            for elemento in v:
                righe.append("")
                righe.append(f"[[{nome}]]")
                _scrivi_tabella(elemento, nuovo, righe)


def salva_toml(percorso: str | os.PathLike, dati: dict) -> None:
    """Scrive ``dati`` in ``percorso`` in modo atomico (UTF-8, a capo \\n)."""
    from .errori import ErroreFile

    import tempfile  # solo per scrivere: chi legge e basta non lo paga

    testo = scrivi_toml(dati)
    cartella = os.path.dirname(os.path.abspath(percorso)) or "."
    try:
        fd, temporaneo = tempfile.mkstemp(prefix=".tmp_", suffix=".toml", dir=cartella)
        try:
            with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
                f.write(testo)
            os.replace(temporaneo, percorso)
        except BaseException:
            try:
                os.unlink(temporaneo)
            except OSError:
                pass
            raise
    except OSError as e:
        raise ErroreFile(f"Non riesco a scrivere il file `{os.fspath(percorso)}`: {e.strerror or e}.") from e
