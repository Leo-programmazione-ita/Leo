"""Interprete tree-walking di Leo (CONTRATTI.md §6).

Visita l'albero sintattico prodotto dal parser (``leo.nodi``) ed esegue il
programma. Punti chiave della semantica:

* ogni blocco (``se``, ``mentre``, ``ripeti``, ``prova``, ``cattura``,
  ``infine``, corpo di funzione o di ``quando``) si esegue in un ambiente
  figlio; ``per ogni`` crea un ambiente nuovo a ogni iterazione, con la
  variabile del ciclo dichiarata dentro;
* le condizioni devono essere logiche (``vero``/``falso``); ``e``/``o`` sono in
  cortocircuito; i confronti concatenati valutano ogni operando una volta;
* ogni ``ErroreDante`` che attraversa la valutazione di un nodo riceve la
  posizione di quel nodo (la piu' interna vince) e il nome del file;
* nessuna eccezione Python "generica" esce verso l'utente: viene trasformata
  nell'errore Leo piu' vicino;
* ricorsione limitata a ``profondita_massima`` chiamate annidate
  (``ErroreRicorsione``); ``ferma()`` interrompe il programma al prossimo
  ciclo o chiamata.
"""

from __future__ import annotations

import os
import sys
from typing import Any, Callable

from . import permessi as _permessi
from . import e_sorgente, nome_modulo_implicito, nomi_file_modulo, operazioni, potenza
from .ambiente import Ambiente, Voce
from .errori import (TIPI_ERRORE, ErroreChiave, ErroreDante, ErroreDivisione, ErroreIndice, ErroreNome,
                     ErroreRicorsione, ErroreSintassi, ErroreTipo, ErroreValore, SegnaleContinua,
                     SegnaleControllo, SegnaleFermaProgramma, SegnaleInterrompi, SegnaleRestituisci)
from .parser import rigoroso_da_ambiente
from .pila import azzera as azzera_pila, chiudi, esci_da_funzione
from .nodi import (Attributo, Binaria, Chiamata, Confronto, DefinizioneFunzione, Dichiarazione, Espressione, Evento,
                   FunzioneAnonima, Importa, Indice, Intervallo, Istruzione, IstruzioneEspressione, ListaLetterale,
                   Letterale, Nodo, Nome, Parallelo, Programma, Temporizzatore, Unaria, Visitatore)
from .controllo.esecuzione import EsecuzioneTipi, nessun_caso  # noqa: F401 (usato dal compilatore)
from .controllo.strutture import TipoStruttura
from .nodi import DefinizioneStruttura, DefinizioneTipo
from .valori import (FunzioneDante, MetodoLegato, Modulo, OggettoControllo, Richiamabile, crea_intervallo, e_intero,
                     iterabile, nome_tipo, rappresenta, uguali, verifica_chiave, verifica_logico)

__all__ = ["Interprete", "LIMITE_RICORSIONE_PYTHON", "EsecuzioneInterrotta"]

#: Percorso predefinito: ``compilato`` (``leo.compilatore``) oppure ``albero``
#: (solo l'interprete ad albero, con ``LEO_INTERPRETE=albero``).
PERCORSO_PREDEFINITO = "albero" if os.environ.get("LEO_INTERPRETE", "").strip().lower() == "albero" else "compilato"

#: chiamare `nulla`: quasi sempre `vuoto(lista)` scritto al posto di `vuota(lista)`
_SUGG_NULLA = ("Forse intendevi `vuota`? `vuoto`, `niente` e `nulla` vogliono dire «nessun valore» e non "
               "si possono chiamare con `( )`: per sapere se una lista o un testo è vuoto scrivi `vuota(...)`.")


class EsecuzioneInterrotta(ErroreDante):
    """Arresto chiesto dal gancio di tracciamento (:meth:`Interprete.imposta_traccia`).

    Non catturabile: ``prova ... cattura`` non lo ferma (i blocchi ``infine``
    vengono comunque eseguiti)."""

    catturabile = False


#: Il modulo ``registro`` (messo qui al primo uso, per evitare l'import a ogni metodo).
_REGISTRO_METODI: list = []
_NOMI_TIPO_VELOCI = {list: "lista", str: "testo", dict: "dizionario"}

#: Lunghezza massima del testo di una variabile passato al gancio di traccia.
LUNGHEZZA_MASSIMA_TRACCIA = 200

#: Istruzioni che dichiarano nomi nell'ambiente in cui si trovano.
_DICHIARANTI = (Dichiarazione, DefinizioneFunzione, Importa, DefinizioneStruttura, DefinizioneTipo)


def _serve_ambito(corpo: list) -> bool:
    """Vero se il blocco dichiara qualcosa direttamente (serve un ambiente suo)."""
    for istruzione in corpo:
        if isinstance(istruzione, _DICHIARANTI):
            return True
    return False


def _crea_chiusure(nodo: Any) -> bool:
    """Vero se dentro ``nodo`` (a qualunque profondita') nasce una funzione, che
    catturerebbe l'ambiente del giro di un ciclo. Anche ``dopo``/``ogni`` e
    ``in parallelo`` creano una funzione (eseguita piu' tardi) che lo cattura."""
    if isinstance(nodo, (FunzioneAnonima, DefinizioneFunzione, Evento, Temporizzatore, Parallelo)):
        return True
    if isinstance(nodo, (list, tuple)):
        return any(_crea_chiusure(x) for x in nodo)
    if isinstance(nodo, Nodo):
        for valore in vars(nodo).values():
            if isinstance(valore, (Nodo, list, tuple)) and _crea_chiusure(valore):
                return True
    return False


class _PassoVuoto:
    """Istruzione che non fa niente, messa al posto del corpo vuoto di un ciclo
    solo quando c'e' un gancio di traccia: cosi' il gancio viene chiamato a
    ogni giro (con la posizione del ciclo) e il Passo passo puo' fermare anche
    ``mentre vero fai`` + ``fine``. Senza gancio non si crea mai."""

    __slots__ = ("riga", "colonna")

    def __init__(self, ciclo: Any) -> None:
        self.riga = ciclo.riga
        self.colonna = ciclo.colonna


def _corpo_tracciabile(interprete: "Interprete", nodo: Any, corpo: Any) -> Any:
    """``corpo`` stesso, oppure (corpo vuoto e gancio di traccia impostato) un
    corpo di una sola :class:`_PassoVuoto`."""
    if corpo or interprete._traccia is None:
        return corpo
    return (_PassoVuoto(nodo),)


#: Limite minimo della pila Python impostato dall'interprete.
LIMITE_RICORSIONE_PYTHON = 50_000

_SENZA_FILE = "<sorgente>"


def _uscita_predefinita(testo: str) -> None:
    sys.stdout.write(testo)
    sys.stdout.flush()


def _messaggio_ricorsione(nome: str) -> str:
    return f"Troppe chiamate annidate: la funzione `{nome}` forse non si ferma mai."


def _converti_eccezione(eccezione: BaseException, dove: str = "") -> ErroreDante:
    """Trasforma un'eccezione Python (non Leo) nell'errore Leo piu' vicino."""
    in_cosa = f" in `{dove}`" if dove else ""
    dettaglio = str(eccezione)
    suggerimento = f"Dettaglio tecnico: {type(eccezione).__name__}: {dettaglio}" if dettaglio else None
    if isinstance(eccezione, RecursionError):
        return ErroreRicorsione(_messaggio_ricorsione(dove) if dove
                                else "Troppe chiamate annidate: il programma forse non si ferma mai.")
    if isinstance(eccezione, ZeroDivisionError):
        return ErroreDivisione("Divisione per zero.")
    if isinstance(eccezione, OverflowError):
        return ErroreValore(f"Numero troppo grande{in_cosa}.")
    if isinstance(eccezione, MemoryError):
        return ErroreValore(f"Memoria esaurita{in_cosa}: il valore è troppo grande.")
    if isinstance(eccezione, KeyError):
        return ErroreChiave(f"Chiave non trovata{in_cosa}.", suggerimento=suggerimento)
    if isinstance(eccezione, IndexError):
        return ErroreIndice(f"Indice fuori dai limiti{in_cosa}.", suggerimento=suggerimento)
    if isinstance(eccezione, TypeError):
        return ErroreTipo(f"Tipo di valore non adatto{in_cosa}.", suggerimento=suggerimento)
    if isinstance(eccezione, (ValueError, ArithmeticError)):
        return ErroreValore(f"Valore non valido{in_cosa}.", suggerimento=suggerimento)
    return ErroreValore(f"Errore imprevisto{in_cosa}.", suggerimento=suggerimento)


def _importa_suggerimenti():
    try:
        from . import suggerimenti
    except Exception:  # modulo assente o rotto: niente suggerimenti
        return None
    return suggerimenti


def _suggerisci_nome(nome: str, ambiente: Ambiente) -> str | None:
    modulo = _importa_suggerimenti()
    funzione = getattr(modulo, "suggerisci_nome", None) if modulo else None
    if funzione is None:
        return None
    try:
        risultato = funzione(nome, ambiente.nomi_visibili())
    except Exception:
        return None
    return risultato if isinstance(risultato, str) and risultato else None


def _suggerisci_metodo(tipo: str, nome: str) -> str | None:
    modulo = _importa_suggerimenti()
    funzione = getattr(modulo, "suggerisci_metodo", None) if modulo else None
    if funzione is None:
        return None
    try:
        risultato = funzione(tipo, nome)
    except Exception:
        return None
    return risultato if isinstance(risultato, str) and risultato else None


def _simili(nome: str, candidati) -> list[str]:
    modulo = _importa_suggerimenti()
    funzione = getattr(modulo, "simili", None) if modulo else None
    if funzione is None:
        return []
    try:
        return list(funzione(nome, candidati))
    except Exception:
        return []


def _lunghezza_nodo(nodo: Nodo) -> int | None:
    if isinstance(nodo, (Nome, Attributo)):
        return len(nodo.nome)
    if isinstance(nodo, Binaria):
        return len(nodo.operatore)
    return None


_NON_TROVATO = object()

class Interprete(EsecuzioneTipi, Visitatore):
    """Esegue un :class:`~leo.nodi.Programma`.

    Attributi pubblici: ``predefinito`` (libreria), ``globale`` (programma),
    ``gestori_evento`` ((controllo, evento) -> FunzioneDante), ``ponte_grafico``,
    ``nome_file``, ``sorgente``, ``dichiarazione_implicita``, ``profondita_massima``,
    ``compilato``.

    Due percorsi con la stessa semantica: normalmente i corpi delle funzioni e
    le istruzioni vengono tradotti una volta in funzioni Python
    (:mod:`leo.compilatore`, molto piu' veloce); con un gancio di traccia
    (debugger passo passo) le istruzioni le esegue l'interprete ad albero di
    questo modulo, che resta il riferimento. ``compilato = False`` (o la
    variabile d'ambiente ``LEO_INTERPRETE=albero``) usa solo l'albero.
    """

    #: Gli attributi letti e scritti a ogni chiamata e a ogni giro dei cicli dal
    #: codice compilato: come "slot" si leggono e scrivono piu' in fretta che dal
    #: dizionario dell'istanza (che resta, per tutti gli altri attributi).
    __slots__ = ("profondita", "profondita_massima", "_ferma_richiesta", "_file_corrente", "_veloce",
                 "_lento", "_multifile", "_compilatore_")

    #: Usa il percorso compilato quando possibile.
    compilato: bool = PERCORSO_PREDEFINITO == "compilato"

    def __init__(self, *, nome_file: str = _SENZA_FILE, sorgente: str = "",
                 uscita: Callable[[str], None] | None = None,
                 ingresso: Callable[[str], str] | None = None,
                 dichiarazione_implicita: bool = False,
                 profondita_massima: int = 1000,
                 ambiente_predefinito: Ambiente | None = None,
                 repl: bool = False,
                 ponte_grafico: Any = None) -> None:
        if sys.getrecursionlimit() < LIMITE_RICORSIONE_PYTHON:
            sys.setrecursionlimit(LIMITE_RICORSIONE_PYTHON)
        self.nome_file = nome_file
        self.sorgente = sorgente
        self.uscita = uscita if uscita is not None else _uscita_predefinita
        self.ingresso = ingresso if ingresso is not None else input
        self.dichiarazione_implicita = dichiarazione_implicita
        # Modalita' tollerante (predefinita, disattivata da --rigoroso): capisce
        # `finestra1` per `Finestra1` e i colori scritti senza virgolette (`rosso`).
        self.tollerante = not rigoroso_da_ambiente()
        self.profondita_massima = profondita_massima
        self.repl = repl
        self.ponte_grafico = ponte_grafico
        if ambiente_predefinito is None:
            from .registro import crea_ambiente_predefinito

            ambiente_predefinito = crea_ambiente_predefinito(permetti_ridichiarazione=repl)
        self.predefinito: Ambiente = ambiente_predefinito
        self.globale: Ambiente = self.predefinito.figlio("globale")
        self.globale.permetti_ridichiarazione = repl
        self.gestori_evento: dict[tuple[str, str], FunzioneDante] = {}
        self.profondita = 0
        self._ferma_richiesta = False
        self._file_corrente = nome_file
        # Diventa True appena si importa un secondo file: solo allora il percorso
        # compilato delle funzioni pure salva/ripristina `_file_corrente` a ogni
        # chiamata (serve a posizionare gli errori fra piu' file). Nel mono-file
        # resta False e quella spesa per-chiamata sparisce.
        self._multifile = False
        self._metodi: dict[type, Callable[..., Any]] = {}
        self._fine_ingresso = 0  # quante volte di fila `chiedi` ha trovato la fine dell'ingresso
        self._traccia: Callable[[int, int, dict], Any] | None = None
        #: Cartelle in cui ``importa`` cerca i file (prima di quella del programma e di quella corrente).
        self.percorsi_moduli: list[str] = []
        self._moduli: dict[str, Ambiente] = {}      # percorso assoluto -> ambiente del modulo
        #: percorso assoluto -> data di modifica del file quando e' stato eseguito (per il REPL)
        self._date_moduli: dict[str, float] = {}
        self._moduli_in_corso: list[str] = []       # per scoprire le importazioni circolari
        #: Sorgenti dei moduli importati (nome del file -> testo), utili per mostrare gli errori.
        self.sorgenti_moduli: dict[str, str] = {}
        #: Quante ``verifica`` sono riuscite (i test integrati).
        self.verifiche_riuscite = 0
        self._compilatore_: Any = None
        self._veloce = False
        self._aggiorna_veloce()
        if _permessi._ATTIVA is not None:       # la politica dei permessi sa a chi chiedere
            _permessi.nuovo_interprete(self)

    # ======================================================================
    # Percorso compilato
    # ======================================================================

    @property
    def _compilatore(self):
        """Il :class:`~leo.compilatore.Compilatore` di questo interprete (creato al primo uso)."""
        compilatore = self._compilatore_
        if compilatore is None:
            from .compilatore import Compilatore

            compilatore = self._compilatore_ = Compilatore(self)
        else:
            compilatore.controlla_opzioni()
        return compilatore

    def _aggiorna_veloce(self) -> bool:
        """Decide se le istruzioni seguono il percorso compilato: si', se non c'e'
        un gancio di traccia e nessuno ha sostituito sull'istanza i metodi che il
        debugger avvolge (``_esegui_istruzione``, ``chiama_funzione_dante``)."""
        d = self.__dict__
        self._veloce = veloce = bool(self.compilato and self._traccia is None
                                     and "_esegui_istruzione" not in d and "chiama_funzione_dante" not in d)
        # ``_lento`` riassume ``_ferma_richiesta or not _veloce`` in un solo attributo:
        # cosi' la via veloce delle chiamate lo controlla con una lettura invece di due
        # (si mantiene qui e in ``richiedi_stop``, gli unici punti che cambiano i due flag).
        self._lento = self._ferma_richiesta or not veloce
        return veloce

    # ======================================================================
    # API pubblica
    # ======================================================================

    def esegui(self, programma: Programma) -> Any:
        """Esegue il programma nell'ambiente globale.

        Restituisce il valore dell'ultima istruzione se e' un'espressione (per il
        REPL), altrimenti ``None``. Un arresto chiesto con :meth:`ferma` termina
        l'esecuzione senza errori.
        """
        self._ferma_richiesta = False
        if self.nome_file == _SENZA_FILE and getattr(programma, "nome_file", _SENZA_FILE) != _SENZA_FILE:
            self.nome_file = programma.nome_file
        file_precedente = self._file_corrente
        self._file_corrente = self.nome_file
        if (not self._multifile and self.nome_file != file_precedente
                and file_precedente != _SENZA_FILE):
            # il file e' cambiato fra due esecuzioni sullo stesso interprete (REPL,
            # editor, `verifica` di piu' file): le funzioni gia' definite possono stare
            # in un altro file, quindi il percorso compilato deve tornare a tracciare il
            # file corrente a ogni chiamata (vedi la funzione pura nel compilatore).
            self._multifile = True
        risultato = None
        try:
            if self._aggiorna_veloce():
                compilatore = self._compilatore
                globale = self.globale
                for istruzione in programma.istruzioni:
                    risultato = compilatore.istruzione(istruzione)(globale)
                    if not isinstance(istruzione, IstruzioneEspressione):
                        risultato = None
            else:
                for istruzione in programma.istruzioni:
                    risultato = self._esegui_istruzione(istruzione, self.globale)
                    if not isinstance(istruzione, IstruzioneEspressione):
                        risultato = None
            self._ciclo_degli_eventi()
        except ErroreDante as e:
            self._chiudi_errore(e, "principale", "", self.nome_file)
            raise
        except SegnaleFermaProgramma:
            return None
        except (SegnaleInterrompi, SegnaleContinua):
            raise self._completa(ErroreSintassi("`interrompi` e `continua` si usano solo dentro un ciclo."),
                                 None) from None
        except SegnaleRestituisci:
            raise self._completa(ErroreSintassi("`restituisci` si usa solo dentro una funzione."), None) from None
        except RecursionError:
            raise self._completa(_converti_eccezione(RecursionError()), None) from None
        finally:
            self._file_corrente = file_precedente
        return risultato

    def esegui_blocco(self, istruzioni: list, ambiente: Ambiente) -> None:
        """Esegue le istruzioni nell'ambiente dato (senza crearne uno nuovo)."""
        if self._veloce:
            self._compilatore.istruzioni(istruzioni)(ambiente)
            return
        esegui = self._esegui_istruzione
        for istruzione in istruzioni:
            esegui(istruzione, ambiente)

    def valuta(self, espressione: Espressione, ambiente: Ambiente) -> Any:
        """Valore Leo di un'espressione."""
        if self.compilato:
            compilatore = self._compilatore_
            if compilatore is None or compilatore.dichiarazione_implicita != bool(self.dichiarazione_implicita):
                compilatore = self._compilatore
            return compilatore.espressione(espressione)(ambiente)
        tipo = type(espressione)
        if tipo is Nome:
            nome = espressione.nome
            amb = ambiente
            while amb is not None:
                voce = amb.voci.get(nome)
                if voce is not None:
                    return voce.valore
                amb = amb.genitore
        elif tipo is Letterale:
            return espressione.valore
        try:
            metodo = self._metodi.get(type(espressione))
            if metodo is None:
                metodo = self._trova_metodo(espressione)
            return metodo(espressione, ambiente)
        except ErroreDante as e:
            self._posiziona(e, espressione)
            raise
        except (SegnaleControllo, RecursionError, KeyboardInterrupt, SystemExit):
            raise
        except Exception as e:  # eccezione Python sfuggita: diventa un errore Leo
            raise self._posiziona(_converti_eccezione(e), espressione) from e

    def _valuta_albero(self, espressione: Espressione, ambiente: Ambiente) -> Any:
        """Valore di un'espressione con l'interprete ad albero (il riferimento)."""
        tipo = type(espressione)
        if tipo is Nome:  # via veloce: i nomi e i letterali sono la maggior parte delle espressioni
            nome = espressione.nome
            amb = ambiente
            while amb is not None:
                voce = amb.voci.get(nome)
                if voce is not None:
                    return voce.valore
                amb = amb.genitore
        elif tipo is Letterale:
            return espressione.valore
        try:
            metodo = self._metodi.get(type(espressione))
            if metodo is None:
                metodo = self._trova_metodo(espressione)
            return metodo(espressione, ambiente)
        except ErroreDante as e:
            self._posiziona(e, espressione)
            raise
        except (SegnaleControllo, RecursionError, KeyboardInterrupt, SystemExit):
            raise
        except Exception as e:  # eccezione Python sfuggita: diventa un errore Leo
            raise self._posiziona(_converti_eccezione(e), espressione) from e

    def chiama(self, funzione: Any, argomenti: list = (), argomenti_nome: dict | None = None) -> Any:
        """Chiama un valore Leo richiamabile (usato anche dalla libreria)."""
        if type(funzione) is FunzioneDante and not argomenti_nome and self._veloce:
            # via veloce del percorso compilato (``mappa``, ``filtra``, ``ordina``... con una
            # funzione Leo pura): la stessa chiamata che farebbe ``chiama_funzione_dante``
            k = funzione._leo_p
            compilatore = self._compilatore_
            if (k is not None and compilatore is not None and k[0] is compilatore.generazione
                    and k[2] <= len(argomenti) <= k[3]
                    and compilatore.dichiarazione_implicita == bool(self.dichiarazione_implicita)):
                return k[1](funzione, *argomenti)
        if not isinstance(funzione, Richiamabile):
            raise ErroreTipo(f"Un valore di tipo `{nome_tipo(funzione)}` non è una funzione.")
        return self._invoca(funzione, list(argomenti), dict(argomenti_nome or {}))

    def chiamante(self, funzione: Any) -> Callable[[list], Any]:
        """``c(argomenti)``, uguale a ``self.chiama(funzione, argomenti)``, per chi chiama
        la stessa funzione tante volte (``mappa``, ``filtra``, ``ordina_per``...): con una
        funzione Leo pura del percorso compilato salta i passaggi intermedi."""
        chiama = self.chiama
        if type(funzione) is not FunzioneDante or not self.compilato:
            return lambda argomenti: chiama(funzione, argomenti)
        compilatore = self._compilatore

        def chiama_veloce(argomenti: list) -> Any:
            k = funzione._leo_p
            if (k is not None and self._veloce and k[0] is compilatore.generazione
                    and k[2] <= len(argomenti) <= k[3]
                    and compilatore.dichiarazione_implicita == bool(self.dichiarazione_implicita)):
                return k[1](funzione, *argomenti)
            return chiama(funzione, argomenti)
        return chiama_veloce

    def chiama_funzione_dante(self, f: FunzioneDante, argomenti: list, argomenti_nome: dict) -> Any:
        """Esegue una funzione definita dall'utente e ne restituisce il risultato."""
        if self._ferma_richiesta:
            raise SegnaleFermaProgramma()
        if self._veloce:
            return self._compilatore.chiama_dante(f, argomenti, argomenti_nome)
        if self.profondita >= self.profondita_massima:
            raise ErroreRicorsione(_messaggio_ricorsione(f.nome))
        file_precedente = self._file_corrente
        self._file_corrente = getattr(f, "nome_file", None) or self._file_corrente
        self.profondita += 1
        try:
            ambiente = f.chiusura.figlio("funzione " + f.nome)
            semplice = f.__dict__.get("_semplice")
            if semplice is None:
                # parametri senza tipo, senza predefinito e non variadici: si legano al volo
                semplice = f._semplice = all(p.predefinito is None and not p.tipo and not getattr(p, "variadico", False)
                                             for p in f.parametri)
            if semplice and not argomenti_nome and len(argomenti) == len(f.parametri):
                voci = ambiente.voci
                riga = f.riga
                for p, valore in zip(f.parametri, argomenti):
                    voci[p.nome] = Voce(valore, False, p.riga or riga)
            else:
                self._lega_parametri(f, argomenti, argomenti_nome or {}, ambiente)
            esegui = self._esegui_istruzione
            for istruzione in f.corpo:
                esegui(istruzione, ambiente)
        except SegnaleRestituisci as s:
            return s.valore
        except ErroreDante as e:
            esci_da_funzione(e, f, argomenti, argomenti_nome)
            raise
        except RecursionError:
            raise ErroreRicorsione(_messaggio_ricorsione(f.nome)) from None
        finally:
            self.profondita -= 1
            self._file_corrente = file_precedente
        return None

    def trova_gestore(self, controllo: str, evento: str) -> "FunzioneDante | None":
        """Il gestore ``quando controllo.evento`` (None se non c'e').

        Prima si cerca il nome esatto. In modalita' normale (tollerante) si
        accettano anche maiuscole diverse nel nome del controllo/finestra e
        dell'evento (``pulsante1.Clic`` vale ``Pulsante1.clic``) e i sinonimi
        degli eventi (``click`` -> ``clic``); se piu' gestori corrispondono
        (nomi ambigui) non si indovina. Con ``--rigoroso`` conta solo il nome
        esatto (e all'avvio del programma a finestre compare l'avviso).
        """
        gestore = self.gestori_evento.get((controllo, evento))
        if gestore is not None or not self.tollerante:
            return gestore
        from .tokens import SINONIMI_EVENTI

        def _norma(ev: str) -> str:
            ev = str(ev).lower()
            return SINONIMI_EVENTI.get(ev, ev)

        cercato = (str(controllo).lower(), _norma(evento))
        trovati = [g for (c, e), g in self.gestori_evento.items() if (str(c).lower(), _norma(e)) == cercato]
        return trovati[0] if len(trovati) == 1 else None

    def chiama_gestore(self, controllo: str, evento: str, dati: dict | None = None) -> bool:
        """Esegue il gestore ``quando controllo.evento``; False se non esiste.

        Nel corpo e' visibile la variabile ``evento`` (dizionario con i dati).
        Gli errori Leo si propagano al chiamante (il runtime grafico li mostra).
        """
        gestore = self.trova_gestore(controllo, evento)
        if gestore is None:
            return False
        filtri = getattr(gestore, "filtri", None)
        if filtri:
            from .grafica.giochi.dinamiche import corrisponde

            trovato = False
            for oggetto, g in list(filtri):
                if corrisponde(oggetto, dati):
                    trovato = True
                    self._esegui_gestore(g, controllo, evento, dati)
            if trovato:       # `quando Eroe.tocca Moneta` ha risposto: `quando Eroe.tocca` vale per gli altri
                return True
        if getattr(gestore, "solo_filtri", False):
            return True
        self._esegui_gestore(gestore, controllo, evento, dati)
        return True

    def _esegui_gestore(self, gestore: "FunzioneDante", controllo: str, evento: str, dati: dict | None) -> None:
        file_precedente = self._file_corrente
        self._file_corrente = getattr(gestore, "nome_file", None) or self.nome_file
        self.profondita += 1
        try:
            if self._ferma_richiesta:
                raise SegnaleFermaProgramma()
            ambiente = gestore.chiusura.figlio(f"quando {controllo}.{evento}")
            ambiente.dichiara("evento", dict(dati) if dati else {}, riga=gestore.riga)
            if self._aggiorna_veloce():
                self._compilatore.corpo(gestore.corpo, None)[0](ambiente, None)
            else:
                self.esegui_blocco(gestore.corpo, ambiente)
        except (SegnaleRestituisci, SegnaleFermaProgramma):
            pass
        except ErroreDante as e:
            self._chiudi_errore(e, "gestore", gestore.nome, getattr(gestore, "nome_file", None) or self.nome_file)
            raise
        except (SegnaleInterrompi, SegnaleContinua):
            raise self._completa(ErroreSintassi("`interrompi` e `continua` si usano solo dentro un ciclo."),
                                 None) from None
        except RecursionError:
            raise self._completa(ErroreRicorsione(_messaggio_ricorsione(gestore.nome)), None) from None
        finally:
            self.profondita -= 1
            self._file_corrente = file_precedente

    def scrivi(self, testo: str) -> None:
        """Scrive sull'uscita (``stampa`` passa il testo con ``"\\n"`` finale)."""
        self.uscita(testo)

    def leggi(self, domanda: str) -> str:
        """Legge una riga dall'ingresso (``chiedi``).

        Alla fine dell'ingresso solleva ``ErroreValore("Non ci sono più dati da
        leggere.")``, che il programma puo' catturare. Se il programma chiede
        ancora un dato subito dopo (per esempio un ciclo che ripete la domanda
        quando cattura ``ErroreValore``) l'errore diventa non catturabile e
        ferma il programma: altrimenti girerebbe per sempre.
        """
        try:
            risposta = self.ingresso(domanda)
        except EOFError:
            risposta = None
        if risposta is None:
            self._fine_ingresso += 1
            errore = ErroreValore("Non ci sono più dati da leggere.")
            if self._fine_ingresso > 1:
                errore.catturabile = False
                errore.suggerimento = ("Il programma ha chiesto ancora un dato dopo la fine dell'ingresso: "
                                       "per questo si ferma qui.")
            raise errore
        self._fine_ingresso = 0
        return risposta if isinstance(risposta, str) else str(risposta)

    def ferma(self) -> None:
        """Chiede l'arresto: il programma si ferma al prossimo ciclo o chiamata
        (anche i lavori ``in parallelo`` e il ciclo dei temporizzatori)."""
        self._ferma_richiesta = True
        self._lento = True
        if "_lavori" in self.__dict__:
            potenza.ferma_lavori(self)

    # --- temporizzatori e lavori in parallelo ---------------------------------

    @property
    def temporizzatori(self) -> "potenza.Temporizzatori":
        """I temporizzatori ``ogni``/``dopo`` di questo interprete (creati al primo uso)."""
        t = self.__dict__.get("_temporizzatori")
        if t is None:
            t = self._temporizzatori = potenza.Temporizzatori(self)
        return t

    def _ciclo_degli_eventi(self) -> None:
        """Alla fine del programma testuale: finche' ci sono temporizzatori attivi
        (o lavori in parallelo in corso) il programma resta vivo; poi un errore di
        un lavoro mai raccolto con ``aspetta`` ferma il programma. Non vale dentro
        un modulo importato ne' nei programmi a finestre (li' c'e' il ciclo di Qt)."""
        d = self.__dict__
        if "_temporizzatori" not in d and "_lavori" not in d:
            return
        if self._moduli_in_corso or self.ponte_grafico is not None:
            return
        temporizzatori = d.get("_temporizzatori")
        if temporizzatori is not None:
            temporizzatori.ciclo(lambda: potenza.lavori_in_corso(self))
        else:
            while potenza.lavori_in_corso(self):
                if self._ferma_richiesta:
                    raise SegnaleFermaProgramma()
                import time

                time.sleep(potenza.PASSO_ATTESA)
        errore = potenza.errore_non_raccolto(self)
        if errore is not None:
            raise errore

    @property
    def fermato(self) -> bool:
        """Vero se e' stato chiesto l'arresto con :meth:`ferma`."""
        return self._ferma_richiesta

    def imposta_traccia(self, funzione: Callable[[int, int, dict], Any] | None) -> None:
        """Imposta (o toglie, con ``None``) il gancio di tracciamento.

        Prima di ogni istruzione viene chiamato ``funzione(riga, colonna,
        variabili)``; per un ciclo con il corpo vuoto viene chiamato a ogni
        giro con la posizione del ciclo (cosi' anche ``mentre vero fai`` +
        ``fine`` si ferma). ``variabili`` e' un ``dict`` nome -> testo del valore
        (come lo scrive ``stampa``, i testi tra virgolette) con i nomi visibili
        dall'istruzione: locali e globali del programma (e dei moduli), senza la
        libreria. Se la funzione restituisce ``False`` l'esecuzione si ferma con
        :class:`EsecuzioneInterrotta` ("Esecuzione interrotta"), che il programma
        non puo' catturare. Senza gancio l'interprete non paga nessun costo: il
        metodo che esegue le istruzioni viene sostituito solo quando serve.
        """
        if funzione is None:
            self._traccia = None
            self.__dict__.pop("_esegui_istruzione", None)
            self._aggiorna_veloce()
            return
        if not callable(funzione):
            raise TypeError("imposta_traccia vuole una funzione oppure None")
        self._traccia = funzione
        self._esegui_istruzione = self._esegui_istruzione_tracciata  # type: ignore[method-assign]
        self._aggiorna_veloce()

    @property
    def traccia(self) -> Callable[[int, int, dict], Any] | None:
        """Il gancio di tracciamento attuale (``None`` se non impostato)."""
        return self._traccia

    def variabili_visibili(self, ambiente: Ambiente) -> dict[str, str]:
        """Nomi visibili da ``ambiente`` (senza la libreria) -> testo del valore."""
        risultato: dict[str, str] = {}
        predefinito = self.predefinito
        amb: Ambiente | None = ambiente
        while amb is not None and amb is not predefinito:
            for nome, voce in amb.voci.items():
                if nome not in risultato:
                    try:
                        testo = rappresenta(voce.valore, dentro=True)
                    except Exception:  # noqa: BLE001 - un valore strano non deve fermare la traccia
                        testo = "?"
                    if len(testo) > LUNGHEZZA_MASSIMA_TRACCIA:
                        testo = testo[:LUNGHEZZA_MASSIMA_TRACCIA - 1] + "…"
                    risultato[nome] = testo
            amb = amb.genitore
        return risultato

    def _esegui_istruzione_tracciata(self, istruzione: Istruzione, ambiente: Ambiente) -> Any:
        traccia = self._traccia
        if traccia is not None:
            if traccia(istruzione.riga, istruzione.colonna, self.variabili_visibili(ambiente)) is False:
                errore = EsecuzioneInterrotta("Esecuzione interrotta", istruzione.riga, istruzione.colonna,
                                              "L'esecuzione è stata fermata dall'esterno (per esempio dal pulsante "
                                              "Ferma di Leo Studio).")
                raise self._completa(errore, None)
        return Interprete._esegui_istruzione(self, istruzione, ambiente)

    # ======================================================================
    # Supporto
    # ======================================================================

    def _trova_metodo(self, nodo: Nodo) -> Callable[..., Any]:
        tipo = type(nodo)
        metodo = getattr(self, "visita_" + tipo.__name__, None)
        if metodo is None:
            def metodo(n, *argomenti, _self=self):
                return _self.visita_generica(n, *argomenti)
        self._metodi[tipo] = metodo
        return metodo

    def _completa(self, errore: ErroreDante, nodo: Nodo | None) -> ErroreDante:
        """Aggiunge posizione (se manca) e nome del file; restituisce l'errore.

        Ricorda anche la riga del primo nodo attraversato nel passo corrente
        della pila delle chiamate (vedi :mod:`leo.pila`)."""
        if nodo is not None:
            riga = nodo.riga
            if riga:
                if not errore.riga:
                    errore.imposta_posizione(riga, nodo.colonna, _lunghezza_nodo(nodo))
                if not errore._riga_qui:
                    errore._riga_qui = riga
        if errore.nome_file == _SENZA_FILE and self._file_corrente:
            errore.nome_file = self._file_corrente
        return errore

    _posiziona = _completa

    def segna_testo(self, f: FunzioneDante) -> None:
        """Nel REPL ogni immissione ha le sue righe: una funzione ricorda il testo
        in cui e' stata scritta, cosi' un errore al suo interno mostra la riga
        giusta anche quando la funzione si chiama da un'immissione successiva."""
        if self._file_corrente == self.nome_file:
            f.__dict__["_leo_testo"] = self.sorgente

    def _chiudi_errore(self, errore: ErroreDante, genere: str, nome: str, nome_file: str) -> None:
        """Un errore esce dal livello piu' esterno: chiude la pila delle chiamate
        e, se l'errore e' in un file importato, gli attacca il testo di quel file
        (chi lo mostra deve prendere la riga di codice dal file giusto)."""
        chiudi(errore, genere, nome, nome_file)
        if getattr(errore, "sorgente_file", None) is None:
            nome_errore = errore.nome_file
            if nome_errore and nome_errore != self.nome_file:
                sorgente = self.sorgenti_moduli.get(nome_errore)
                if sorgente is not None:
                    errore.sorgente_file = sorgente

    def _esegui_istruzione(self, istruzione: Istruzione, ambiente: Ambiente) -> Any:
        try:
            metodo = self._metodi.get(type(istruzione))
            if metodo is None:
                metodo = self._trova_metodo(istruzione)
            return metodo(istruzione, ambiente)
        except ErroreDante as e:
            self._posiziona(e, istruzione)
            raise
        except (SegnaleControllo, RecursionError, KeyboardInterrupt, SystemExit):
            raise
        except Exception as e:
            raise self._posiziona(_converti_eccezione(e), istruzione) from e

    def _condizione(self, espressione: Espressione, ambiente: Ambiente, contesto: str) -> bool:
        valore = self.valuta(espressione, ambiente)
        if valore is True or valore is False:
            return valore
        try:
            return verifica_logico(valore, contesto)
        except ErroreDante as e:
            self._posiziona(e, espressione)
            raise

    def _controlla_ferma(self) -> None:
        if self._ferma_richiesta:
            raise SegnaleFermaProgramma()

    def _invoca(self, funzione: Richiamabile, argomenti: list, argomenti_nome: dict) -> Any:
        """Chiama ``funzione``; le eccezioni Python della libreria diventano errori Leo."""
        if isinstance(funzione, FunzioneDante):
            return self.chiama_funzione_dante(funzione, argomenti, argomenti_nome)
        try:
            return funzione.chiama(self, argomenti, argomenti_nome)
        except (ErroreDante, SegnaleControllo, KeyboardInterrupt, SystemExit):
            raise
        except RecursionError:
            raise ErroreRicorsione(_messaggio_ricorsione(getattr(funzione, "nome", "?"))) from None
        except Exception as e:
            raise _converti_eccezione(e, getattr(funzione, "nome", "")) from e

    def _errore_non_definito(self, nome: str, ambiente: Ambiente, *, per_assegnare: bool = False) -> ErroreNome:
        suggerimento = _suggerisci_nome(nome, ambiente)
        if suggerimento is None and per_assegnare:
            suggerimento = f"Per creare una nuova variabile scrivi `variabile {nome} = ...`."
        elif suggerimento is None and nome[:1].isupper():
            # `Red`: un nome con la maiuscola mai definito e' quasi sempre un testo senza virgolette
            suggerimento = f'Se volevi il testo "{nome}", scrivilo tra virgolette: "{nome}".'
        return ErroreNome(f"`{nome}` non è definito.", suggerimento=suggerimento, nome=nome)

    def _lega_parametri(self, f: FunzioneDante, argomenti: list, argomenti_nome: dict, ambiente: Ambiente) -> None:
        parametri = f.parametri
        if parametri and getattr(parametri[-1], "variadico", False):
            # `funzione somma(numeri...)`: gli argomenti in piu' finiscono in una lista
            variadico = parametri[-1]
            parametri = parametri[:-1]
            if variadico.nome in argomenti_nome:
                raise ErroreTipo(f"Il parametro `{variadico.nome}...` di `{f.nome}` raccoglie gli argomenti senza "
                                 "nome: non si può passare per nome.")
            extra = list(argomenti[len(parametri):])
            argomenti = argomenti[:len(parametri)]
            self._lega_fissi(f, parametri, argomenti, argomenti_nome, ambiente)
            if variadico.tipo and variadico.tipo != "qualsiasi":
                for valore in extra:
                    self._controlla_tipo_parametro(f, variadico, valore)
            ambiente.dichiara(variadico.nome, extra, riga=variadico.riga or f.riga)
            return
        self._lega_fissi(f, parametri, argomenti, argomenti_nome, ambiente)

    def _controlla_tipo_parametro(self, f: FunzioneDante, p: Any, valore: Any) -> None:
        self._controlla_parametro(f, p, valore)  # anche `testo?`, `lista di intero`, strutture

    def _lega_fissi(self, f: FunzioneDante, parametri: list, argomenti: list, argomenti_nome: dict,
                    ambiente: Ambiente) -> None:
        nomi = [p.nome for p in parametri]
        if len(argomenti) > len(parametri):
            obbligatori = sum(1 for p in parametri if p.predefinito is None)
            if obbligatori == len(parametri):
                attesi = "1 argomento" if len(parametri) == 1 else f"{len(parametri)} argomenti"
            else:
                attesi = f"da {obbligatori} a {len(parametri)} argomenti"
            ricevuti = len(argomenti) + len(argomenti_nome)
            raise ErroreTipo(
                f"`{f.nome}` accetta {attesi}, ma ne ha ricevuti {ricevuti}.",
                suggerimento=(f"Parametri di `{f.nome}`: " + ", ".join(f"`{n}`" for n in nomi) + ".")
                if nomi else f"`{f.nome}` non vuole argomenti: chiamala con `{f.nome}()`.",
            )
        valori: dict[str, Any] = dict(zip(nomi, argomenti))
        for nome, valore in argomenti_nome.items():
            if nome not in nomi:
                simili = _simili(nome, nomi)
                if simili:
                    suggerimento = f"Forse intendevi `{simili[0]}`?"
                elif nomi:
                    suggerimento = f"Parametri di `{f.nome}`: " + ", ".join(f"`{n}`" for n in nomi) + "."
                else:
                    suggerimento = None
                raise ErroreTipo(f"`{f.nome}` non ha un parametro chiamato `{nome}`.", suggerimento=suggerimento)
            if nome in valori:
                raise ErroreTipo(f"Il parametro `{nome}` di `{f.nome}` ha ricevuto due valori.")
            valori[nome] = valore
        for p in parametri:
            if p.nome in valori:
                valore = valori[p.nome]
            elif p.predefinito is not None:
                valore = self.valuta(p.predefinito, ambiente)
            else:
                raise ErroreTipo(f"Manca l'argomento `{p.nome}` nella chiamata di `{f.nome}`.",
                                 suggerimento=f"Parametri di `{f.nome}`: " + ", ".join(f"`{n}`" for n in nomi) + ".")
            if p.tipo and p.tipo != "qualsiasi":
                self._controlla_tipo_parametro(f, p, valore)
            ambiente.dichiara(p.nome, valore, riga=p.riga or f.riga)

    # ======================================================================
    # Espressioni
    # ======================================================================

    def visita_Letterale(self, nodo, ambiente):
        return nodo.valore

    def visita_TestoInterpolato(self, nodo, ambiente):
        pezzi = []
        for parte in nodo.parti:
            if isinstance(parte, str):
                pezzi.append(parte)
            else:
                pezzi.append(rappresenta(self.valuta(parte, ambiente)))
        return "".join(pezzi)

    def visita_Nome(self, nodo, ambiente):
        nome = nodo.nome
        amb = ambiente
        while amb is not None:
            voce = amb.voci.get(nome)
            if voce is not None:
                return voce.valore
            amb = amb.genitore
        if self.tollerante:
            trovato = self._nome_tollerante(nome, ambiente)
            if trovato is not _NON_TROVATO:
                return trovato
        raise self._errore_non_definito(nome, ambiente)

    @staticmethod
    def _cerca_senza_maiuscole(nome: str, ambiente: Ambiente) -> tuple[Ambiente, str] | None | bool:
        """Il nome dichiarato che differisce da ``nome`` solo per maiuscole e
        minuscole, cercato dall'ambiente piu' vicino verso l'esterno (come le
        variabili normali): ``(ambiente, chiave)``; ``None`` se non c'e';
        ``False`` se nell'ambiente piu' vicino ce n'e' piu' d'uno (ambiguo:
        `Totale` e `TOTALE` insieme)."""
        minuscolo = nome.lower()
        amb: Ambiente | None = ambiente
        while amb is not None:
            trovate = [chiave for chiave in amb.voci if chiave.lower() == minuscolo and chiave != nome]
            if len(trovate) == 1:
                return amb, trovate[0]
            if trovate:
                return False
            amb = amb.genitore
        return None

    def _nome_tollerante(self, nome, ambiente):
        """Aiuto per i principianti (disattivato da ``--rigoroso``): maiuscole
        sbagliate (`Finestra1` per `finestra1`) e colori senza virgolette
        (`rosso` per ``"rosso"``). Una variabile, anche scritta con maiuscole
        diverse, vince sempre sul colore; se il nome e' ambiguo non si indovina."""
        trovato = self._cerca_senza_maiuscole(nome, ambiente)
        if trovato is False:
            return _NON_TROVATO
        if trovato is not None:
            amb, chiave = trovato
            return amb.voci[chiave].valore
        minuscolo = nome.lower()
        try:
            from .grafica.colori import COLORI_NOMINATI
        except Exception:  # noqa: BLE001 - grafica assente o rotta: niente colori
            COLORI_NOMINATI = {}
        if minuscolo in COLORI_NOMINATI:
            return minuscolo
        return _NON_TROVATO

    def visita_ListaLetterale(self, nodo, ambiente):
        return [self.valuta(e, ambiente) for e in nodo.elementi]

    def visita_DizionarioLetterale(self, nodo, ambiente):
        risultato: dict = {}
        for espr_chiave, espr_valore in nodo.coppie:
            chiave = self.valuta(espr_chiave, ambiente)
            try:
                verifica_chiave(chiave)
            except ErroreDante as e:
                self._posiziona(e, espr_chiave)
                raise
            valore = self.valuta(espr_valore, ambiente)
            try:
                operazioni.scrivi_indice(risultato, chiave, valore)
            except ErroreDante as e:
                self._posiziona(e, espr_chiave)
                raise
        return risultato

    def visita_Binaria(self, nodo, ambiente):
        a = self.valuta(nodo.sinistra, ambiente)
        b = self.valuta(nodo.destra, ambiente)
        ta = type(a)
        tb = type(b)
        if (ta is int or ta is float) and (tb is int or tb is float):
            # via veloce per i numeri (stessi risultati di operazioni.binaria)
            op = nodo.operatore
            if op == "+":
                return a + b
            if op == "-":
                return a - b
            if ta is int and tb is int:
                if op == "*" and not operazioni.prodotto_troppo_grande(a, b):
                    return a * b
                if b:
                    if op == "%":
                        return a % b
                    if op == "//":
                        return a // b
        return operazioni.binaria(nodo.operatore, a, b)

    def visita_Unaria(self, nodo, ambiente):
        if nodo.operatore == "non":
            valore = self.valuta(nodo.operando, ambiente)
            try:
                return not verifica_logico(valore, "non")
            except ErroreTipo as e:
                if e.suggerimento is None:
                    e.suggerimento = ("`non` vale solo per il valore subito dopo: per negare un confronto "
                                      "usa le parentesi, per esempio `non (x in lista)`.")
                self._posiziona(e, nodo.operando)
                raise
        return operazioni.unaria(nodo.operatore, self.valuta(nodo.operando, ambiente))

    def visita_Logica(self, nodo, ambiente):
        if nodo.operatore == "oppure":
            return self._oppure(nodo, ambiente)
        sinistra = self._condizione(nodo.sinistra, ambiente, nodo.operatore)
        if nodo.operatore == "e":
            if not sinistra:
                return False
        elif nodo.operatore == "o":
            if sinistra:
                return True
        elif nodo.operatore == "oppure":
            return self._oppure(nodo, ambiente)
        else:
            raise ErroreTipo(f"L'operatore logico `{nodo.operatore}` non esiste in Leo.")
        return self._condizione(nodo.destra, ambiente, nodo.operatore)

    def visita_Confronto(self, nodo, ambiente):
        operatori = nodo.operatori
        if len(operatori) == 1:
            a = self.valuta(nodo.operandi[0], ambiente)
            b = self.valuta(nodo.operandi[1], ambiente)
            ta = type(a)
            tb = type(b)
            if (ta is int or ta is float) and (tb is int or tb is float):
                op = operatori[0]
                if op == "<":
                    return a < b
                if op == ">":
                    return a > b
                if op == "==":
                    return a == b
                if op == "<=":
                    return a <= b
                if op == ">=":
                    return a >= b
                if op == "!=":
                    return a != b
            return operazioni.confronta(operatori[0], a, b)
        sinistra = self.valuta(nodo.operandi[0], ambiente)
        for operatore, espressione in zip(nodo.operatori, nodo.operandi[1:]):
            destra = self.valuta(espressione, ambiente)
            if not operazioni.confronta(operatore, sinistra, destra):
                return False
            sinistra = destra
        return True

    def visita_Intervallo(self, nodo, ambiente):
        return crea_intervallo(self.valuta(nodo.inizio, ambiente), self.valuta(nodo.fine, ambiente))

    def visita_Chiamata(self, nodo, ambiente):
        if nodo.catena and type(nodo.funzione) is Nome and ambiente.cerca_ambiente(nodo.funzione.nome) is None:
            return self._catena_metodo(nodo, ambiente)
        funzione = self.valuta(nodo.funzione, ambiente)
        argomenti: list = []
        argomenti_nome: dict[str, Any] = {}
        for argomento in nodo.argomenti:
            valore = self.valuta(argomento.valore, ambiente)
            if argomento.nome is None:
                if argomento.espandi:
                    if not isinstance(valore, (list, range)):
                        raise self._posiziona(ErroreTipo(
                            f"Con `...` si passano gli elementi di una lista, non un valore di tipo "
                            f"`{nome_tipo(valore)}`.", suggerimento="Per esempio `somma(numeri...)`."),
                            argomento.valore)
                    argomenti.extend(valore)
                    continue
                argomenti.append(valore)
            else:
                if argomento.nome in argomenti_nome:
                    raise ErroreTipo(f"L'argomento `{argomento.nome}` è scritto due volte.")
                argomenti_nome[argomento.nome] = valore
        if not isinstance(funzione, Richiamabile):
            if isinstance(nodo.funzione, Nome):
                descrizione = f"`{nodo.funzione.nome}`"
            elif isinstance(nodo.funzione, Attributo):
                descrizione = f"`{nodo.funzione.nome}`"
            else:
                descrizione = "Questo valore"
            raise ErroreTipo(f"{descrizione} non è una funzione.",
                             suggerimento=(_SUGG_NULLA if funzione is None else f"È un valore di tipo `{nome_tipo(funzione)}`: non si può chiamare con `( )`."))
        if self._ferma_richiesta:
            raise SegnaleFermaProgramma()
        return self._invoca(funzione, argomenti, argomenti_nome)

    def _catena_metodo(self, nodo, ambiente):
        """``valore |> nome(...)`` quando ``nome`` non e' una funzione: il metodo
        ``nome`` del valore. Se il metodo non restituisce niente (come
        ``ordina``) la catena prosegue con il valore stesso."""
        nome = nodo.funzione.nome
        argomenti = [self.valuta(a.valore, ambiente) for a in nodo.argomenti if a.nome is None]
        argomenti_nome = {a.nome: self.valuta(a.valore, ambiente) for a in nodo.argomenti if a.nome is not None}
        oggetto = argomenti[0]
        try:
            metodo = self._leggi_attributo(oggetto, nome)
        except ErroreNome:
            errore = self._errore_non_definito(nome, ambiente)
            errore.suggerimento = (errore.suggerimento or
                                   f"Dopo `|>` ci va una funzione o un metodo di `{nome_tipo(oggetto)}`.")
            raise self._posiziona(errore, nodo.funzione) from None
        if not isinstance(metodo, Richiamabile):
            raise ErroreTipo(f"`{nome}` non è una funzione.")
        if self._ferma_richiesta:
            raise SegnaleFermaProgramma()
        risultato = self._invoca(metodo, argomenti[1:], argomenti_nome)
        return oggetto if risultato is None else risultato

    def visita_Indice(self, nodo, ambiente):
        return operazioni.leggi_indice(self.valuta(nodo.oggetto, ambiente), self.valuta(nodo.indice, ambiente))

    def visita_Attributo(self, nodo, ambiente):
        return self._leggi_attributo(self.valuta(nodo.oggetto, ambiente), nodo.nome)

    def _leggi_attributo(self, oggetto: Any, nome: str) -> Any:
        tipo_python = type(oggetto)
        if tipo_python is list or tipo_python is str or tipo_python is dict:
            # via veloce per i metodi di liste, testi e dizionari
            registro_metodi = _REGISTRO_METODI[0].METODI if _REGISTRO_METODI else None
            metodi = registro_metodi.get(_NOMI_TIPO_VELOCI[tipo_python]) if registro_metodi is not None else None
            metodo = metodi.get(nome) if metodi else None
            if metodo is not None:
                return MetodoLegato(oggetto, metodo)
        if isinstance(oggetto, ErroreDante):
            return oggetto.campo(nome)
        if isinstance(oggetto, Modulo):
            try:
                return oggetto.leggi(nome)
            except KeyError:
                if oggetto.privato(nome):
                    raise ErroreNome(
                        f"`{nome}` è privato del modulo `{oggetto.nome}`: si usa solo dentro quel file.",
                        suggerimento=(f"Nel file del modulo scrivi `pubblica` davanti alla sua dichiarazione."
                                      if not nome.startswith("_") else
                                      "I nomi che cominciano con `_` restano dentro il loro file: "
                                      "togli il `_` (e aggiungi `pubblica`) se deve essere visibile."),
                        nome=nome) from None
                simili = _simili(nome, list(oggetto.voci))
                raise ErroreNome(f"Il modulo `{oggetto.nome}` non contiene `{nome}`.",
                                 suggerimento=f"Forse intendevi `{simili[0]}`?" if simili else None,
                                 nome=nome) from None
        if getattr(type(oggetto), "ATTRIBUTI_DANTE", False):
            return oggetto.attributo_dante(nome)   # oggetti del ponte Python (ponte_python)
        if isinstance(oggetto, OggettoControllo):
            metodo = oggetto.metodo(nome)
            if metodo is not None:
                return metodo
            return oggetto.leggi(nome)
        from . import registro

        if not _REGISTRO_METODI:
            _REGISTRO_METODI.append(registro)
        tipo = nome_tipo(oggetto)
        metodo = registro.trova_metodo(tipo, nome)
        if metodo is not None:
            return MetodoLegato(oggetto, metodo)
        suggerimento = _suggerisci_metodo(tipo, nome)
        if isinstance(oggetto, dict) and nome in oggetto:
            suggerimento = f"Per leggere la chiave \"{nome}\" del dizionario scrivi `[\"{nome}\"]`."
        elif suggerimento is None and isinstance(oggetto, dict):
            suggerimento = f"Per leggere una chiave del dizionario scrivi `[\"{nome}\"]`."
        raise ErroreNome(f"Un valore di tipo `{tipo}` non ha il metodo `{nome}`.",
                         suggerimento=suggerimento, nome=nome)

    def visita_FunzioneAnonima(self, nodo, ambiente):
        f = FunzioneDante("<anonima>", nodo.parametri, nodo.corpo, ambiente, nodo.riga, nodo.colonna)
        f.nome_file = self._file_corrente
        if self.repl:
            self.segna_testo(f)
        return f

    # ======================================================================
    # Istruzioni
    # ======================================================================

    def visita_IstruzioneEspressione(self, nodo, ambiente):
        espr = nodo.espressione
        if type(espr) is Attributo:
            # `Finestra1.mostra`, `Eroe.esulta`, `Elenco1.svuota` da soli sulla riga: il metodo si chiama
            # (comandi senza parentesi)
            oggetto = self.valuta(espr.oggetto, ambiente)
            if isinstance(oggetto, OggettoControllo) and oggetto.metodo(espr.nome) is not None:
                return self.valuta(Chiamata(espr, [], riga=espr.riga, colonna=espr.colonna), ambiente)
            valore = self._leggi_attributo(oggetto, espr.nome)
            if isinstance(valore, Richiamabile):
                return self.chiama(valore, [])
            return valore
        return self.valuta(espr, ambiente)

    def visita_Dichiarazione(self, nodo, ambiente):
        if nodo.costante or nodo.tipo is not None:  # tipo dichiarato o costante bloccata
            return self._dichiara_speciale(nodo, ambiente)
        valore = self.valuta(nodo.valore, ambiente)
        ambiente.dichiara(nodo.nome, valore, costante=nodo.costante, riga=nodo.riga)

    def visita_Assegnazione(self, nodo, ambiente):
        operatore = nodo.operatore
        composta = operatore != "="
        op_binario = operatore[:-1] if composta else ""
        bersaglio = nodo.bersaglio

        if type(bersaglio) is Nome:
            nome = bersaglio.nome
            if not composta:
                valore = self.valuta(nodo.valore, ambiente)
            amb = ambiente
            while amb is not None:
                voce = amb.voci.get(nome)
                if voce is not None:
                    break
                amb = amb.genitore
            if voce is not None and not voce.costante:
                # via veloce: la variabile esiste e si puo' cambiare
                if composta:
                    destra = self.valuta(nodo.valore, ambiente)
                    attuale = voce.valore
                    ta = type(attuale)
                    td = type(destra)
                    if (ta is int or ta is float) and (td is int or td is float) and op_binario in ("+", "-"):
                        voce.valore = attuale + destra if op_binario == "+" else attuale - destra
                        return
                    try:
                        voce.valore = operazioni.binaria(op_binario, attuale, destra)
                    except ErroreDante as e:
                        self._posiziona(e, nodo)
                        raise
                    return
                voce.valore = valore
                return
            dove = amb
            if dove is None and self.tollerante and (composta or not self.dichiarazione_implicita):
                # `Contatore = 1` per la variabile `contatore` (maiuscole sbagliate)
                trovato = self._cerca_senza_maiuscole(nome, ambiente)
                if trovato:
                    dove, nome = trovato
            if composta:
                if dove is None:
                    raise self._posiziona(self._errore_non_definito(nome, ambiente), bersaglio)
                attuale = dove.voci[nome].valore
                valore = self._valuta_composta(op_binario, attuale, nodo, ambiente)
            if dove is None:
                if self.dichiarazione_implicita and not composta:
                    ambiente.dichiara(nome, valore, riga=nodo.riga)
                    return
                raise self._posiziona(self._errore_non_definito(nome, ambiente, per_assegnare=True), bersaglio)
            try:
                dove.assegna(nome, valore)
            except ErroreDante as e:
                self._posiziona(e, bersaglio)
                raise
            return

        if isinstance(bersaglio, Indice):
            oggetto = self.valuta(bersaglio.oggetto, ambiente)
            indice = self.valuta(bersaglio.indice, ambiente)
            try:
                if composta:
                    attuale = operazioni.leggi_indice(oggetto, indice)
                    valore = self._valuta_composta(op_binario, attuale, nodo, ambiente)
                else:
                    valore = self.valuta(nodo.valore, ambiente)
                operazioni.scrivi_indice(oggetto, indice, valore)
            except ErroreDante as e:
                self._posiziona(e, bersaglio)
                raise
            return

        if isinstance(bersaglio, Attributo):
            oggetto = self.valuta(bersaglio.oggetto, ambiente)
            try:
                if not (isinstance(oggetto, OggettoControllo) or getattr(type(oggetto), "ATTRIBUTI_DANTE", False)):
                    raise ErroreTipo("Si possono cambiare solo le proprietà dei controlli grafici.",
                                     suggerimento="Per un dizionario scrivi `d[\"chiave\"] = valore`."
                                     if isinstance(oggetto, dict) else None)
                if composta:
                    attuale = oggetto.leggi(bersaglio.nome)
                    valore = self._valuta_composta(op_binario, attuale, nodo, ambiente)
                else:
                    valore = self.valuta(nodo.valore, ambiente)
                oggetto.scrivi(bersaglio.nome, valore)
            except ErroreDante as e:
                self._posiziona(e, bersaglio)
                raise
            return

        raise ErroreSintassi("Non si può assegnare a questa espressione.")

    def _valuta_composta(self, operatore: str, attuale: Any, nodo, ambiente: Ambiente) -> Any:
        """``attuale operatore valore`` per ``+= -= *= /=`` (errori sul nodo dell'assegnazione)."""
        valore = self.valuta(nodo.valore, ambiente)
        try:
            return operazioni.binaria(operatore, attuale, valore)
        except ErroreDante as e:
            self._posiziona(e, nodo)
            raise

    def _ambito(self, nodo: Any, corpo: list, ambiente: Ambiente, nome: str) -> Ambiente:
        """Ambiente per il blocco ``corpo``: un figlio solo se il blocco dichiara
        qualcosa (altrimenti sarebbe vuoto e identico al genitore)."""
        cache = nodo.__dict__.get("_ambiti")
        if cache is None:
            cache = nodo._ambiti = {}
        chiave = id(corpo)
        serve = cache.get(chiave)
        if serve is None:
            serve = cache[chiave] = _serve_ambito(corpo)
        if serve or self.dichiarazione_implicita:
            return ambiente.figlio(nome)
        return ambiente

    def visita_Se(self, nodo, ambiente):
        ambiti = nodo.__dict__.get("_ambiti_se")
        if ambiti is None:
            ambiti = nodo._ambiti_se = [_serve_ambito(r.corpo) for r in nodo.rami] + [
                nodo.altrimenti is not None and _serve_ambito(nodo.altrimenti)]
        contesto = "se"
        for i, ramo in enumerate(nodo.rami):
            condizione = self.valuta(ramo.condizione, ambiente)
            if condizione is not True:
                if condizione is False or not self._verifica_condizione(condizione, ramo.condizione, contesto):
                    contesto = "altrimenti se"
                    continue
            if ambiti[i] or self.dichiarazione_implicita:
                ambiente = ambiente.figlio("se")
            esegui = self._esegui_istruzione
            for istruzione in ramo.corpo:
                esegui(istruzione, ambiente)
            return
        if nodo.altrimenti is not None:
            if ambiti[-1] or self.dichiarazione_implicita:
                ambiente = ambiente.figlio("altrimenti")
            esegui = self._esegui_istruzione
            for istruzione in nodo.altrimenti:
                esegui(istruzione, ambiente)

    def _verifica_condizione(self, valore: Any, espressione: Espressione, contesto: str) -> bool:
        try:
            return verifica_logico(valore, contesto)
        except ErroreDante as e:
            self._posiziona(e, espressione)
            raise

    def visita_Mentre(self, nodo, ambiente):
        corpo = nodo.corpo
        condizione = nodo.condizione
        valuta = self.valuta
        esegui = self._esegui_istruzione
        nuovo = _serve_ambito(corpo) or self.dichiarazione_implicita
        if not corpo:
            corpo = _corpo_tracciabile(self, nodo, corpo)
        while True:
            if self._ferma_richiesta:
                raise SegnaleFermaProgramma()
            valore = valuta(condizione, ambiente)
            if valore is not True:
                if valore is False or not self._verifica_condizione(valore, condizione, "mentre"):
                    return
            giro = ambiente.figlio("mentre") if nuovo else ambiente
            try:
                for istruzione in corpo:
                    esegui(istruzione, giro)
            except SegnaleInterrompi:
                return
            except SegnaleContinua:
                continue

    def _elementi(self, sequenza: Any, nomi: list[str] | None, espressione: Espressione) -> Any:
        """Elementi percorsi da ``per ogni`` (con due nomi un dizionario da' le coppie)."""
        try:
            if nomi is not None and len(nomi) == 2 and isinstance(sequenza, dict):
                return iter([[k, v] for k, v in sequenza.items()])
            return iterabile(sequenza)
        except ErroreDante as e:
            self._posiziona(e, espressione)
            raise

    def _destruttura(self, valore: Any, nomi: list[str], dove: str) -> list:
        """I valori da dare a ``nomi`` (``a, b = [1, 2]``); errori chiari se non tornano."""
        elenco = ", ".join(f"`{n}`" for n in nomi)
        if isinstance(valore, dict):
            raise ErroreTipo(f"Non posso dividere un dizionario tra {elenco}.",
                             suggerimento="Per le coppie chiave-valore usa `per ogni chiave, valore in d fai`.")
        if not isinstance(valore, (list, range, str)):
            raise ErroreTipo(f"Per dare un valore a {elenco} serve una lista, non un valore di tipo "
                             f"`{nome_tipo(valore)}`.", suggerimento=f"Per esempio {dove}.")
        valori = list(valore)
        if len(valori) != len(nomi):
            quanti = "1 valore" if len(valori) == 1 else f"{len(valori)} valori"
            raise ErroreValore(f"Ci sono {len(nomi)} nomi ({elenco}) ma {quanti}.",
                               suggerimento="Il numero dei nomi e dei valori deve essere lo stesso.")
        return valori

    def visita_PerOgni(self, nodo, ambiente):
        sequenza = self.valuta(nodo.iterabile, ambiente)
        nomi = getattr(nodo, "variabili", None)
        elementi = self._elementi(sequenza, nomi, nodo.iterabile)
        corpo = nodo.corpo
        esegui = self._esegui_istruzione
        riga = nodo.riga
        chiusure = nodo.__dict__.get("_chiusure")
        if chiusure is None:
            chiusure = nodo._chiusure = _crea_chiusure(corpo)
        if not corpo:
            corpo = _corpo_tracciabile(self, nodo, corpo)
        if nomi is None and not chiusure and not self.dichiarazione_implicita:
            # via veloce: nessuna funzione nel corpo cattura il giro, quindi un
            # solo ambiente riusato (svuotato a ogni giro se il corpo dichiara)
            giro = ambiente.figlio("per ogni")
            voci = giro.voci
            nome = nodo.variabile
            dichiara = _serve_ambito(nodo.corpo)
            voce = Voce(None, False, riga)
            voci[nome] = voce
            for elemento in elementi:
                if self._ferma_richiesta:
                    raise SegnaleFermaProgramma()
                if dichiara:
                    voci.clear()
                    voce = Voce(elemento, False, riga)
                    voci[nome] = voce
                else:
                    voce.valore = elemento
                try:
                    for istruzione in corpo:
                        esegui(istruzione, giro)
                except SegnaleInterrompi:
                    return
                except SegnaleContinua:
                    continue
            return
        for elemento in elementi:
            if self._ferma_richiesta:
                raise SegnaleFermaProgramma()
            giro = ambiente.figlio("per ogni")
            if nomi is None:
                giro.dichiara(nodo.variabile, elemento, riga=riga)
            else:
                try:
                    valori = self._destruttura(elemento, nomi, "`per ogni a, b in [[1, 2], [3, 4]] fai`")
                except ErroreDante as e:
                    self._posiziona(e, nodo.iterabile)
                    raise
                for n, v in zip(nomi, valori):
                    giro.dichiara(n, v, riga=riga)
            try:
                self.esegui_blocco(corpo, giro)
            except SegnaleInterrompi:
                return
            except SegnaleContinua:
                continue

    def visita_Ripeti(self, nodo, ambiente):
        volte = self.valuta(nodo.volte, ambiente)
        try:
            if not e_intero(volte):
                raise ErroreTipo(
                    f"Il numero di ripetizioni di `ripeti` deve essere un intero, non un valore di tipo "
                    f"`{nome_tipo(volte)}`.",
                    suggerimento="Usa `intero(...)` o `arrotonda(...)`." if isinstance(volte, float) else None)
            if volte < 0:
                raise ErroreValore(f"Il numero di ripetizioni di `ripeti` non può essere negativo (è {volte}).")
        except ErroreDante as e:
            self._posiziona(e, nodo.volte)
            raise
        corpo = nodo.corpo
        if not corpo:
            corpo = _corpo_tracciabile(self, nodo, corpo)
        for _ in range(volte):
            if self._ferma_richiesta:
                raise SegnaleFermaProgramma()
            try:
                self.esegui_blocco(corpo, self._ambito(nodo, nodo.corpo, ambiente, "ripeti"))
            except SegnaleInterrompi:
                return
            except SegnaleContinua:
                continue

    def visita__PassoVuoto(self, nodo, ambiente):
        """Il corpo vuoto di un ciclo tracciato: il gancio e' gia' stato chiamato."""
        return None

    def visita_DefinizioneFunzione(self, nodo, ambiente):
        if "." in nodo.nome or nodo.tipo_risultato is not None or nodo.richiede or nodo.garantisce:
            return self._definisci_funzione(nodo, ambiente)  # metodo, `dà tipo` o contratti
        f = FunzioneDante(nodo.nome, nodo.parametri, nodo.corpo, ambiente, nodo.riga, nodo.colonna)
        f.nome_file = self._file_corrente
        if self.repl:
            self.segna_testo(f)
        ambiente.dichiara(nodo.nome, f, costante=True, riga=nodo.riga)

    def visita_Restituisci(self, nodo, ambiente):
        valore = None if nodo.valore is None else self.valuta(nodo.valore, ambiente)
        raise SegnaleRestituisci(valore)

    def visita_Interrompi(self, nodo, ambiente):
        raise SegnaleInterrompi()

    def visita_Continua(self, nodo, ambiente):
        raise SegnaleContinua()

    def visita_Prova(self, nodo, ambiente):
        for cattura in nodo.catture:  # i tipi si controllano subito, anche senza errori
            if cattura.tipo_errore is not None and cattura.tipo_errore not in TIPI_ERRORE:
                simili = _simili(cattura.tipo_errore, list(TIPI_ERRORE))
                suggerimento = (f"Forse intendevi `{simili[0]}`?" if simili else
                                "I tipi di errore sono: " + ", ".join(f"`{t}`" for t in TIPI_ERRORE) + ".")
                raise self._posiziona(ErroreNome(f"`{cattura.tipo_errore}` non è un tipo di errore.",
                                                 suggerimento=suggerimento, nome=cattura.tipo_errore), cattura)
        try:
            try:
                self.esegui_blocco(nodo.corpo, ambiente.figlio("prova"))
            except ErroreDante as errore:
                if not errore.catturabile:
                    raise
                self._posiziona(errore, nodo)
                for cattura in nodo.catture:
                    if cattura.tipo_errore is not None and errore.tipo != cattura.tipo_errore:
                        continue
                    ambito = ambiente.figlio("cattura")
                    if cattura.nome_variabile:
                        ambito.dichiara(cattura.nome_variabile, errore, riga=cattura.riga)
                    self.esegui_blocco(cattura.corpo, ambito)
                    azzera_pila(errore)
                    break
                else:
                    raise
        finally:
            if nodo.infine is not None:
                self.esegui_blocco(nodo.infine, ambiente.figlio("infine"))

    def visita_Lancia(self, nodo, ambiente):
        valore = self.valuta(nodo.valore, ambiente)
        if not isinstance(valore, ErroreDante):
            raise ErroreTipo("Con `lancia` serve un errore, per esempio `lancia ErroreValore(\"...\")`.")
        if valore.__dict__.pop("_gestito", False):
            # errore gia' catturato e gestito, lanciato di nuovo: vale la posizione nuova
            valore.riga = valore.colonna = 0
            valore.nome_file = _SENZA_FILE
            valore.__dict__.pop("sorgente_file", None)
        if not valore.riga:
            valore.imposta_posizione(nodo.riga, nodo.colonna)
        raise self._completa(valore, None)

    def visita_Evento(self, nodo, ambiente):
        chiave = (nodo.controllo, nodo.evento)
        esistente = self.gestori_evento.get(chiave)
        oggetto = getattr(nodo, "oggetto", "")
        if oggetto:
            # `quando Giocatore.tocca Moneta fai`: gestore "con filtro", appeso a quello dell'evento
            if esistente is None:
                esistente = FunzioneDante(f"{nodo.controllo}.{nodo.evento}", [], [], ambiente, nodo.riga, nodo.colonna)
                esistente.nome_file = self._file_corrente
                esistente.solo_filtri = True
                self.gestori_evento[chiave] = esistente
            filtri = esistente.__dict__.setdefault("filtri", [])
            for altro, g in filtri:
                if altro.lower() == oggetto.lower():
                    dove = f" alla riga {g.riga}" if g.riga else ""
                    raise ErroreNome(f"C'è già un gestore per `{nodo.controllo}.{nodo.evento} {oggetto}`{dove}.",
                                     suggerimento="Unisci il codice in un solo blocco `quando`.",
                                     nome=nodo.controllo)
            gestore = FunzioneDante(f"{nodo.controllo}.{nodo.evento} {oggetto}", [], nodo.corpo, ambiente,
                                    nodo.riga, nodo.colonna)
            gestore.nome_file = self._file_corrente
            filtri.append((oggetto, gestore))
            return
        if esistente is not None and not getattr(esistente, "solo_filtri", False):
            dove = f" alla riga {esistente.riga}" if esistente.riga else ""
            raise ErroreNome(f"C'è già un gestore per `{nodo.controllo}.{nodo.evento}`{dove}.",
                             suggerimento="Unisci il codice in un solo blocco `quando`.", nome=nodo.controllo)
        gestore = FunzioneDante(f"{nodo.controllo}.{nodo.evento}", [], nodo.corpo, ambiente, nodo.riga, nodo.colonna)
        gestore.nome_file = self._file_corrente
        if esistente is not None:
            gestore.filtri = esistente.filtri
        self.gestori_evento[chiave] = gestore

    # ======================================================================
    # Novita' del tema "linguaggio"
    # ======================================================================

    def visita_ListaCompresa(self, nodo, ambiente):
        sequenza = self.valuta(nodo.iterabile, ambiente)
        nomi = nodo.variabili
        elementi = self._elementi(sequenza, nomi if len(nomi) > 1 else None, nodo.iterabile)
        risultato: list = []
        condizione = nodo.condizione
        for elemento in elementi:
            if self._ferma_richiesta:
                raise SegnaleFermaProgramma()
            giro = ambiente.figlio("per ogni")
            if len(nomi) == 1:
                giro.voci[nomi[0]] = Voce(elemento, False, nodo.riga)
            else:
                try:
                    valori = self._destruttura(elemento, nomi, "`[a + b per ogni a, b in coppie]`")
                except ErroreDante as e:
                    self._posiziona(e, nodo.iterabile)
                    raise
                for n, v in zip(nomi, valori):
                    giro.voci[n] = Voce(v, False, nodo.riga)
            if condizione is not None and not self._condizione(condizione, giro, "se"):
                continue
            risultato.append(self.valuta(nodo.elemento, giro))
        return risultato

    def visita_DichiarazioneMultipla(self, nodo, ambiente):
        valore = self.valuta(nodo.valore, ambiente)
        parola = "costante" if nodo.costante else "variabile"
        try:
            valori = self._destruttura(valore, nodo.nomi, f"`{parola} a, b = [1, 2]`")
        except ErroreDante as e:
            self._posiziona(e, nodo.valore)
            raise
        for nome, v in zip(nodo.nomi, valori):
            ambiente.dichiara(nome, v, costante=nodo.costante, riga=nodo.riga)

    def visita_AssegnazioneMultipla(self, nodo, ambiente):
        valore = self.valuta(nodo.valore, ambiente)
        try:
            valori = self._destruttura(valore, [self._descrivi_bersaglio(b) for b in nodo.bersagli],
                                       "`a, b = b, a`")
        except ErroreDante as e:
            self._posiziona(e, nodo.valore)
            raise
        for bersaglio, v in zip(nodo.bersagli, valori):
            # ogni bersaglio riceve un valore gia' calcolato: `a, b = b, a` scambia davvero
            self.visita_Assegnazione(_AssegnaValore(bersaglio, v, nodo), ambiente)

    @staticmethod
    def _descrivi_bersaglio(bersaglio: Any) -> str:
        if isinstance(bersaglio, (Nome, Attributo)):
            return bersaglio.nome
        return "..."

    def _corrisponde(self, valore: Any, schema: Espressione, ambiente: Ambiente) -> bool:
        """Il ``valore`` di ``scegli`` corrisponde allo schema di un ``caso``?"""
        if isinstance(schema, Intervallo):
            inizio = self.valuta(schema.inizio, ambiente)
            fine = self.valuta(schema.fine, ambiente)
            try:
                if operazioni.confronta("<=", inizio, fine):
                    return operazioni.confronta("<=", inizio, valore) and operazioni.confronta("<=", valore, fine)
                return operazioni.confronta("<=", fine, valore) and operazioni.confronta("<=", valore, inizio)
            except ErroreTipo:
                return False  # un testo contro un intervallo di numeri: semplicemente non corrisponde
        atteso = self.valuta(schema, ambiente)
        if isinstance(atteso, TipoStruttura):  # `caso Cerchio allora`: qualunque Cerchio
            return getattr(valore, "tipo_struttura", None) is atteso
        if isinstance(atteso, (list, range)) and not isinstance(valore, (list, range)):
            return any(uguali(valore, x) for x in atteso)
        return uguali(valore, atteso)

    def visita_Scegli(self, nodo, ambiente):
        # anche `caso Cerchio(r) allora` (scompone le varianti): leo/controllo/esecuzione.py
        return self._scegli(nodo, ambiente)

    def visita_Verifica(self, nodo, ambiente):
        condizione = nodo.condizione
        dettaglio = None
        if isinstance(condizione, Confronto) and len(condizione.operatori) == 1:
            a = self.valuta(condizione.operandi[0], ambiente)
            b = self.valuta(condizione.operandi[1], ambiente)
            operatore = condizione.operatori[0]
            try:
                esito = operazioni.confronta(operatore, a, b)
            except ErroreDante as e:
                self._posiziona(e, condizione)
                raise
            dettaglio = f"{rappresenta(a, dentro=True)} {operatore} {rappresenta(b, dentro=True)}"
        else:
            esito = self._condizione(condizione, ambiente, "verifica")
        if esito:
            self.verifiche_riuscite += 1
            return
        if nodo.messaggio is not None:
            testo = rappresenta(self.valuta(nodo.messaggio, ambiente))
            messaggio = f"Verifica non riuscita: {testo}"
            suggerimento = f"Ho controllato {dettaglio}, ma è falso." if dettaglio else None
        elif dettaglio is not None:
            messaggio = f"Verifica non riuscita: {dettaglio} è falso."
            suggerimento = "`verifica` controlla che una condizione sia vera mentre il programma gira."
        else:
            messaggio = "Verifica non riuscita: la condizione è falsa."
            suggerimento = "Puoi aggiungere una spiegazione: `verifica condizione, \"messaggio\"`."
        raise ErroreValore(messaggio, suggerimento=suggerimento)

    # --- costrutti potenti: ogni/dopo, verifiche incorporate, parallelo, formati ---

    def visita_Temporizzatore(self, nodo, ambiente):
        from .tokens import UNITA_TEMPORIZZATORI

        parola = "ogni" if nodo.ripeti else "dopo"
        durata = self.valuta(nodo.durata, ambiente)
        if isinstance(durata, bool) or not isinstance(durata, (int, float)):
            raise self._posiziona(ErroreTipo(
                f"Dopo `{parola}` serve un numero, ma `{rappresenta(durata, dentro=True)}` è di tipo "
                f"`{nome_tipo(durata)}`.",
                suggerimento=f"Per esempio `{parola} 2 secondi fai`; un testo si trasforma con `decimale(...)`."),
                nodo.durata)
        secondi = float(durata) * UNITA_TEMPORIZZATORI.get(nodo.unita, 1.0)
        if secondi != secondi or secondi < 0 or (nodo.ripeti and secondi <= 0):
            raise self._posiziona(ErroreValore(
                f"La durata di `{parola}` deve essere maggiore di zero, non {rappresenta(durata)}."
                if nodo.ripeti else f"La durata di `dopo` non può essere negativa ({rappresenta(durata)}).",
                suggerimento=f"Per esempio `{parola} 0.5 secondi fai`."), nodo.durata)
        if secondi == float("inf"):
            raise self._posiziona(ErroreValore(f"La durata di `{parola}` è infinita."), nodo.durata)
        funzione = FunzioneDante(f"<{parola} {rappresenta(durata)} {nodo.unita}>", [], nodo.corpo, ambiente,
                                 nodo.riga, nodo.colonna)
        funzione.nome_file = self._file_corrente
        self.temporizzatori.pianifica(secondi, funzione, nodo.ripeti)

    def visita_BloccoVerifica(self, nodo, ambiente):
        """Nella normale esecuzione le verifiche non partono (le esegue ``leo verifica``)."""
        return None

    def visita_Aspettati(self, nodo, ambiente):
        condizione = nodo.condizione
        atteso = ottenuto = None
        if isinstance(condizione, Confronto) and len(condizione.operatori) == 1:
            a = self.valuta(condizione.operandi[0], ambiente)
            b = self.valuta(condizione.operandi[1], ambiente)
            operatore = condizione.operatori[0]
            try:
                esito = operazioni.confronta(operatore, a, b)
            except ErroreDante as e:
                self._posiziona(e, condizione)
                raise
            ottenuto = rappresenta(a, dentro=True)
            atteso = rappresenta(b, dentro=True)
            if operatore not in ("==", "è"):
                atteso = f"{operatore} {atteso}"
            dettaglio = f"{ottenuto} {operatore} {rappresenta(b, dentro=True)} è falso."
        else:
            valore = self.valuta(condizione, ambiente)
            esito = valore if isinstance(valore, bool) else verifica_logico(valore, "aspettati")
            if isinstance(condizione, Unaria) and condizione.operatore == "non":
                atteso, ottenuto = "falso", "vero"
            else:
                atteso, ottenuto = "vero", "falso"
            dettaglio = "la condizione è falsa."
        if esito:
            self.verifiche_riuscite += 1
            return
        errore = ErroreValore(f"Aspettativa non rispettata: {dettaglio}",
                              suggerimento="`aspettati` controlla che la condizione sia vera.")
        errore.aspettativa = True
        errore.atteso = atteso
        errore.ottenuto = ottenuto
        raise self._posiziona(errore, nodo)

    def visita_AspettatiErrore(self, nodo, ambiente):
        tipo = nodo.tipo_errore
        if tipo is not None and tipo not in TIPI_ERRORE:
            simili = _simili(tipo, list(TIPI_ERRORE))
            raise self._posiziona(ErroreNome(
                f"`{tipo}` non è un tipo di errore.",
                suggerimento=f"Forse intendevi `{simili[0]}`?" if simili else
                "I tipi di errore sono: " + ", ".join(f"`{t}`" for t in TIPI_ERRORE) + ".", nome=tipo), nodo)
        atteso = f"un errore {tipo}" if tipo else "un errore"
        try:
            self.esegui_blocco(nodo.corpo, ambiente.figlio("aspettati errore"))
        except ErroreDante as e:
            if not e.catturabile or getattr(e, "aspettativa", False):
                raise
            if tipo is None or e.tipo == tipo:
                self.verifiche_riuscite += 1
                return
            errore = ErroreValore(f"Mi aspettavo {atteso}, ma è arrivato {e.tipo}: {e.messaggio}")
            errore.atteso = tipo
            errore.ottenuto = f"{e.tipo}: {e.messaggio}"
        else:
            errore = ErroreValore(f"Mi aspettavo {atteso}, ma il codice non ha dato nessun errore.")
            errore.atteso = tipo or "un errore"
            errore.ottenuto = "nessun errore"
        errore.aspettativa = True
        errore.suggerimento = "Dentro `aspettati errore ... fai` va il codice che deve sbagliare."
        raise self._posiziona(errore, nodo)

    def visita_Parallelo(self, nodo, ambiente):
        funzione = FunzioneDante("<in parallelo>", [], nodo.corpo, ambiente, nodo.riga, nodo.colonna)
        funzione.nome_file = self._file_corrente
        return potenza.avvia_lavoro(self, funzione)

    def visita_ValoreFormattato(self, nodo, ambiente):
        valore = self.valuta(nodo.valore, ambiente)
        try:
            return potenza.formatta_numero(valore, nodo.formato)
        except ErroreDante as e:
            raise self._posiziona(e, nodo.valore)

    # --- importa -------------------------------------------------------------

    def _cartelle_moduli(self) -> list[str]:
        """Dove cercare i file da importare, in ordine."""
        cartelle: list[str] = []

        def aggiungi(cartella: str) -> None:
            if cartella and os.path.isdir(cartella):
                cartella = os.path.abspath(cartella)
                if cartella not in cartelle:
                    cartelle.append(cartella)

        if self._moduli_in_corso:  # un modulo che ne importa un altro: prima la sua cartella
            aggiungi(os.path.dirname(self._moduli_in_corso[-1]))
        for cartella in self.percorsi_moduli:
            aggiungi(cartella)
        for nome in (self._file_corrente, self.nome_file):
            if nome and os.path.dirname(nome):
                aggiungi(os.path.dirname(nome))
        base = os.path.basename(self.nome_file or "")
        for argomento in sys.argv[1:]:  # `leo cartella/programma.leo`
            if base and os.path.basename(argomento) == base and os.path.isfile(argomento):
                aggiungi(os.path.dirname(os.path.abspath(argomento)))
        aggiungi(os.getcwd())
        return cartelle

    def _trova_file_modulo(self, modulo: str) -> str | None:
        nomi = nomi_file_modulo(modulo)
        if os.path.isabs(nomi[0]):
            return next((n for n in nomi if os.path.isfile(n)), None)
        for cartella in self._cartelle_moduli():
            for nome in nomi:
                percorso = os.path.join(cartella, nome)
                if os.path.isfile(percorso):
                    return os.path.abspath(percorso)
        if modulo.isidentifier():   # pacchetto Leo installato con `leo aggiungi leo:nome` (.leo/pacchetti)
            from .pacchetti import file_pacchetto_leo

            return file_pacchetto_leo(modulo, self._cartelle_moduli())
        return None

    @staticmethod
    def _modulo_libreria(nome: str) -> dict[str, Any] | None:
        """Funzioni e costanti del modulo di libreria ``leo/libreria/<nome>.py``."""
        from . import registro

        suffisso = f".libreria.{nome}"
        voci: dict[str, Any] = {}
        for chiave, funzione in registro.FUNZIONI.items():
            # modulo_python non importa i moduli pigri della libreria
            if registro.modulo_python(funzione).endswith(suffisso):
                voci[chiave] = funzione
        if not voci:
            try:
                import importlib

                importlib.import_module(f"{__package__}.libreria.{nome}")
            except Exception:  # noqa: BLE001 - modulo inesistente
                return None
        return voci

    @staticmethod
    def _data_file(percorso: str) -> float | None:
        try:
            return os.path.getmtime(percorso)
        except OSError:
            return None

    def _percorso_principale(self) -> str | None:
        """Percorso assoluto del file del programma principale (None nel REPL o
        senza file). Serve a scoprire un modulo che importa il programma stesso,
        che altrimenti verrebbe eseguito una seconda volta prima dell'errore."""
        d = self.__dict__
        if "_principale" in d:
            return d["_principale"]
        trovato = None
        nome = self.nome_file
        if not self.repl and nome and nome != _SENZA_FILE:
            candidati = [nome] if os.path.isabs(nome) else [nome] + [
                os.path.join(c, os.path.basename(nome)) for c in self.percorsi_moduli]
            base = os.path.basename(nome)
            for argomento in sys.argv[1:]:  # `leo cartella/programma.leo`
                if os.path.basename(argomento) == base:
                    candidati.append(argomento)
            for candidato in candidati:
                if not os.path.isfile(candidato):
                    continue
                if self.sorgente:  # solo se e' davvero il file che sto eseguendo
                    try:
                        with open(candidato, "r", encoding="utf-8-sig") as f:
                            if f.read() != self.sorgente:
                                continue
                    except (OSError, UnicodeDecodeError):
                        continue
                trovato = os.path.abspath(candidato)
                break
        d["_principale"] = trovato
        return trovato

    def _esegui_modulo(self, percorso: str, modulo: str) -> Ambiente:
        if percorso in self._moduli:
            # Nel REPL un file cambiato si rilegge: `importa "geo.leo"` di nuovo
            # dopo averlo modificato da' la versione nuova. In un programma ogni
            # file si esegue una volta sola.
            if not self.repl or self._data_file(percorso) == self._date_moduli.get(percorso):
                return self._moduli[percorso]
        principale = self._percorso_principale()
        if percorso in self._moduli_in_corso or (principale is not None and percorso == principale):
            if percorso in self._moduli_in_corso:
                giro = self._moduli_in_corso[self._moduli_in_corso.index(percorso):]
            else:  # il file importa (anche indirettamente) il programma principale
                giro = [principale] + self._moduli_in_corso
            catena = " → ".join(os.path.splitext(os.path.basename(p))[0] for p in giro + [percorso])
            raise ErroreValore(f"Importazione circolare: {catena}.",
                               suggerimento="Due file non possono importarsi a vicenda: sposta il codice "
                                            "comune in un terzo file.")
        data = self._data_file(percorso)
        try:
            with open(percorso, "r", encoding="utf-8-sig") as f:
                sorgente = f.read()
        except OSError as e:
            from .errori import ErroreFile

            raise ErroreFile(f"Non riesco a leggere `{modulo}`: {e.strerror or e}.") from None
        from .esecuzione import analizza

        nome_file = os.path.basename(percorso)
        programma = analizza(sorgente, nome_file)
        self.sorgenti_moduli[nome_file] = sorgente
        # il percorso vero di ogni file importato (i messaggi usano solo il nome): serve ai permessi
        # per riconoscere il codice dei pacchetti Leo installati (leo/permessi_pacchetti.py)
        self.__dict__.setdefault("file_dei_moduli", {})[nome_file] = percorso
        # `pubblica`: i nomi che il file mostra a chi lo importa (None = tutti tranne `_nome`)
        self.__dict__.setdefault("_pubblici_moduli", {})[percorso] = getattr(programma, "pubblici", None)
        ambiente_modulo = self.predefinito.figlio(f"modulo {nome_file}")
        file_precedente = self._file_corrente
        self._moduli_in_corso.append(percorso)
        self._file_corrente = nome_file
        # da qui in poi gira codice di un altro file: le funzioni pure devono
        # tracciare il file corrente a ogni chiamata (vedi __init__ e il compilatore)
        self._multifile = True
        try:
            if self._veloce:
                compilatore = self._compilatore
                for istruzione in programma.istruzioni:
                    compilatore.istruzione(istruzione)(ambiente_modulo)
            else:
                for istruzione in programma.istruzioni:
                    self._esegui_istruzione(istruzione, ambiente_modulo)
        except ErroreDante as e:
            # l'errore e' in questo file: chi lo mostra deve usare il suo testo
            if e.nome_file == nome_file and getattr(e, "sorgente_file", None) is None:
                e.sorgente_file = sorgente
            chiudi(e, "modulo", nome_file, nome_file, sempre=True)
            raise
        finally:
            self._moduli_in_corso.pop()
            self._file_corrente = file_precedente
        self._moduli[percorso] = ambiente_modulo
        if data is not None:
            self._date_moduli[percorso] = data
        return ambiente_modulo

    def _nomi_visibili(self, percorso: str, ambiente_modulo: Ambiente) -> set[str]:
        """I nomi che il file ``percorso`` mostra: quelli con ``pubblica`` se ne
        usa almeno uno, altrimenti tutti; mai quelli che cominciano con ``_``."""
        pubblici = self.__dict__.get("_pubblici_moduli", {}).get(percorso)
        nomi = ambiente_modulo.voci if pubblici is None else pubblici
        return {n for n in nomi if not n.startswith("_")}

    def visita_Importa(self, nodo, ambiente):
        modulo = nodo.modulo
        if modulo.startswith("python:"):   # importa python "requests" come rete (leo/ponte_python.py)
            from .ponte_python import importa_modulo

            nome_py = modulo[len("python:"):]
            valore = importa_modulo(nome_py, self._cartelle_moduli(), self)
            nome = nodo.alias or nome_py.split(".")[-1]
            esistente = ambiente.voci.get(nome)
            if esistente is not None and getattr(esistente.valore, "_mod", None) is valore._mod:
                return                                  # importato due volte: nessun problema
            ambiente.dichiara(nome, valore, costante=True, riga=nodo.riga)
            return
        e_file = e_sorgente(modulo) or "/" in modulo or "\\" in modulo
        percorso = self._trova_file_modulo(modulo)
        if percorso is not None:
            ambiente_modulo = self._esegui_modulo(percorso, modulo)
            visibili = self._nomi_visibili(percorso, ambiente_modulo)
            voci = {nome: voce.valore for nome, voce in ambiente_modulo.voci.items()
                    if not voce.implicito and nome in visibili}
            costanti = {nome for nome, voce in ambiente_modulo.voci.items()
                        if voce.costante and not hasattr(voce, "controlla_valore")}
            nome_modulo = os.path.splitext(os.path.basename(percorso))[0]
        else:
            voci = None if e_file else self._modulo_libreria(modulo)
            if voci is None:
                cartelle = self._cartelle_moduli()
                dove = f" (ho cercato in `{cartelle[0]}`)" if len(cartelle) == 1 else ""
                raise ErroreNome(
                    f"Non trovo il modulo `{modulo}`{dove}.",
                    suggerimento="Metti il file `.leo` nella stessa cartella del programma, "
                                 "per esempio `importa \"geometria.leo\"`.",
                    nome=modulo)
            nome_modulo = modulo
            ambiente_modulo = None
            costanti = set()
            visibili = None
        if nodo.alias is not None:
            ambiente.dichiara(nodo.alias, Modulo(nome_modulo, voci, ambiente_modulo, visibili), costante=True,
                              riga=nodo.riga)
            return
        if percorso is not None:
            # i nomi del file entrano direttamente nel programma
            for nome, valore in voci.items():
                esistente = ambiente.voci.get(nome)
                if esistente is not None and esistente.valore is valore:
                    continue  # importato due volte: nessun problema
                if (esistente is not None and not esistente.implicito
                        and not (self.repl and ambiente.permetti_ridichiarazione)):
                    raise ErroreNome(f"Il modulo `{modulo}` contiene `{nome}`, che nel programma esiste già.",
                                     suggerimento=f"Importalo con un nome: `importa \"{modulo}\" come {nome_modulo}` "
                                                  f"e poi usa `{nome_modulo}.{nome}`.", nome=nome)
                # costanti e funzioni del file restano non modificabili
                ambiente.dichiara(nome, valore, costante=nome in costanti, riga=nodo.riga)
        # Le funzioni della libreria sono gia' tutte disponibili; in piu' il nome
        # del modulo si puo' usare col punto: `importa matematica` e poi
        # `matematica.radice(9)` (come con `come matematica`). Il nome non
        # copre mai un nome che esiste gia' e si puo' ridichiarare.
        implicito = nome_modulo_implicito(nome_modulo)
        if implicito is not None and not ambiente.esiste(implicito):
            ambiente.dichiara(implicito, Modulo(nome_modulo, voci, ambiente_modulo, visibili), riga=nodo.riga,
                              implicito=True)


class _AssegnaValore:
    """Nodo interno per :meth:`Interprete.visita_AssegnazioneMultipla`: un'assegnazione
    ``bersaglio = valore`` con il valore gia' calcolato."""

    __slots__ = ("bersaglio", "operatore", "valore", "riga", "colonna")

    def __init__(self, bersaglio: Any, valore: Any, origine: Any) -> None:
        self.bersaglio = bersaglio
        self.operatore = "="
        self.valore = Letterale(valore, riga=origine.riga, colonna=origine.colonna)
        self.riga = origine.riga
        self.colonna = origine.colonna
