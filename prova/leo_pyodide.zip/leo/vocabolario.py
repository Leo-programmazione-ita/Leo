"""Vocabolario (livello 3): parole italiane che fanno pensare a una parola chiave.

Queste parole NON sono mai valide nel codice: servono solo ai suggerimenti
negli errori (``"`reiterare` non è definito. Forse intendevi `ripeti`?"``).
Specifica: docs/CONTRATTI.md §8.3.

Fonti, in ordine di priorita':

1. ``dati/vocabolario.toml``, sezione ``[vocabolario]``:
   ``canonica = ["parola", ...]`` (scritto a mano, ha sempre la precedenza);
2. ``dati/thesaurus.dat`` (facoltativo), nel formato dei thesaurus di
   LibreOffice/MyThes (``th_it``)::

       UTF-8
       ripetere|2
       (verbo)|reiterare|rifare|replicare
       (verbo)|ridire|riferire
       ...

   La prima riga e' la codifica; poi ogni voce e' ``parola|n`` seguita da
   ``n`` righe di significati, ognuna con la categoria tra parentesi e i
   sinonimi separati da ``|``. Le voci vengono collegate alle parole chiave
   canoniche cosi':

   - se la parola della voce e' una canonica o una parola gia' nota del
     vocabolario, tutti i suoi sinonimi portano a quella canonica;
   - altrimenti, se tra i sinonimi di un significato compare una canonica (o
     una parola del vocabolario scritto a mano), la parola della voce porta a
     quella canonica.

   Le parole che porterebbero a canoniche diverse vengono scartate (ambigue).

Il confronto ignora maiuscole, accenti e la differenza tra ``_`` e spazio.
Le parole chiave canoniche e i sinonimi ammessi (``sinonimi.toml``) non
entrano mai nel vocabolario: sono gia' gestiti dal lexer.

API:
    Vocabolario.parola_chiave_per(parola) -> str | None   # "reiterare" -> "ripeti"
    carica_vocabolario(percorso=None, *, thesaurus=None) -> Vocabolario
    vocabolario_predefinito() -> Vocabolario              # in cache
    precarica_in_background() -> Thread | None            # per Leo Studio, dopo la comparsa
    normalizza(parola) -> str
    leggi_thesaurus(percorso) -> list[tuple[str, list[list[str]]]]
"""

from __future__ import annotations

import os
import re
import sys
import threading
import unicodedata
from dataclasses import dataclass, field
from pathlib import Path

from . import variabile_ambiente
from typing import Iterable, Iterator

__all__ = [
    "Vocabolario", "carica_vocabolario", "vocabolario_predefinito", "normalizza",
    "leggi_thesaurus", "voci_thesaurus", "azzera_cache", "PAROLE_PER_CONTESTO",
    "precarica_in_background", "pronto",
]

_PARENTESI = re.compile(r"\([^)]*\)")


def normalizza(parola: str) -> str:
    """Minuscole, senza accenti, ``_`` e spazi multipli come uno spazio.

    ``"Finché"`` -> ``"finche"``, ``"per_ogni"`` -> ``"per ogni"``,
    ``"e'"`` -> ``"e"``.
    """
    testo = str(parola).strip().lower().replace("_", " ")
    if testo.endswith("'") and len(testo) > 1:  # e' -> e (accento scritto con apostrofo)
        testo = testo[:-1]
    decomposto = unicodedata.normalize("NFD", testo)
    senza = "".join(c for c in decomposto if unicodedata.category(c) != "Mn")
    return " ".join(senza.split())


#: Parole che fanno pensare alle parole di contesto (``scegli``, ``importa``,
#: ``verifica``): valgono come il vocabolario scritto a mano ma non ne
#: sostituiscono le voci, tranne quelle in ``_PRECEDENZA_CONTESTO``.
PAROLE_PER_CONTESTO: dict[str, tuple[str, ...]] = {
    "scegli": ("seleziona", "selezionare", "scegliere", "smista", "smistare", "commuta",
               "in_base_a", "a_seconda_di"),
    "importa": ("importare", "includi", "includere", "carica_modulo", "usa_modulo",
                "richiedi_modulo", "usa_file"),
    "verifica": ("asserisci", "asserire", "accerta", "accertati", "accertare", "assicurati"),
}

#: Parole del vocabolario scritto a mano che ora portano a una parola di contesto.
_PRECEDENZA_CONTESTO: dict[str, str] = {"verificare": "verifica"}


def _parole_di_contesto() -> frozenset[str]:
    try:
        from .tokens import PAROLE_DI_CONTESTO
        return frozenset(PAROLE_DI_CONTESTO)
    except Exception:  # noqa: BLE001
        return frozenset({"scegli", "caso", "importa", "verifica"})


def _parole_escluse() -> set[str]:
    """Canoniche, parole di contesto e sinonimi ammessi (normalizzati): mai nel vocabolario."""
    escluse: set[str] = {normalizza(p) for p in _parole_di_contesto()}
    try:
        from .tokens import COPPIE_DI_PAROLE, PAROLE_CHIAVE
        escluse.update(normalizza(p) for p in PAROLE_CHIAVE)
        escluse.update(normalizza(" ".join(k)) for k in COPPIE_DI_PAROLE)
    except Exception:  # noqa: BLE001
        pass
    try:
        from .sinonimi import carica_sinonimi
        for chiave in carica_sinonimi().mappa:
            escluse.add(normalizza(" ".join(chiave)))
    except Exception:  # noqa: BLE001 - sinonimi.toml assente o malformato
        pass
    return escluse


def _canoniche_note() -> set[str]:
    note = set(_parole_di_contesto())
    try:
        from .tokens import COPPIE_DI_PAROLE, PAROLE_CHIAVE
        return note | set(PAROLE_CHIAVE) | {" ".join(k) for k in COPPIE_DI_PAROLE}
    except Exception:  # noqa: BLE001
        return note


def _un_errore(a: str, b: str) -> bool:
    """True se ``a`` e ``b`` differiscono per UN errore di battitura (lettera in
    piu', in meno, diversa, o due lettere vicine scambiate)."""
    la, lb = len(a), len(b)
    if a == b or abs(la - lb) > 1:
        return False
    if la == lb:
        diverse = [i for i in range(la) if a[i] != b[i]]
        if len(diverse) == 1:
            return True
        return (len(diverse) == 2 and diverse[1] == diverse[0] + 1
                and a[diverse[0]] == b[diverse[1]] and a[diverse[1]] == b[diverse[0]])
    if la < lb:
        a, b = b, a
    # a e' piu' lunga di una lettera: togliendone una si ottiene b?
    i = 0
    while i < len(b) and a[i] == b[i]:
        i += 1
    return a[i + 1:] == b[i:]


@dataclass
class Vocabolario:
    """Mappa parola normalizzata -> forma canonica (es. ``"ripeti"``).

    ``mappa`` contiene le parole del vocabolario scritto a mano e quelle del
    thesaurus; ``canoniche`` sono le forme canoniche note (le chiavi del
    vocabolario e le parole chiave del linguaggio). La "canonica" puo' essere
    anche il nome di una funzione della libreria (``"visualizza"`` ->
    ``"stampa"``). ``sostantivi`` sono le parole (normalizzate) che potrebbero
    anche essere nomi di variabile non dichiarate (``"dimensione"``).
    """

    mappa: dict[str, str] = field(default_factory=dict)
    canoniche: set[str] = field(default_factory=set)
    escluse: set[str] = field(default_factory=set)
    sostantivi: set[str] = field(default_factory=set)
    _per_lunghezza: dict[int, list[str]] | None = field(default=None, init=False, repr=False,
                                                        compare=False)

    def parola_chiave_per(self, parola: str) -> str | None:
        """Canonica a cui fa pensare ``parola``, o None.

        ``"reiterare"`` -> ``"ripeti"``; ``"Iterare"`` -> ``"ripeti"``.
        """
        if not parola:
            return None
        return self.mappa.get(normalizza(parola))

    def e_sostantivo(self, parola: str) -> bool:
        """True se ``parola`` e' un nome comune che puo' anche essere una variabile."""
        return bool(parola) and normalizza(parola) in self.sostantivi

    def simile(self, parola: str, *, lunghezza_minima: int = 6) -> tuple[str, str] | None:
        """Parola del vocabolario a UN errore di battitura da ``parola``.

        Restituisce ``(parola_del_vocabolario, canonica)``, oppure None se non
        ce n'e' una, se ``parola`` e' piu' corta di ``lunghezza_minima`` o se
        le parole vicine portano a canoniche diverse (``"visualizzs"`` ->
        ``("visualizza", "stampa")``). Un errore = una lettera in piu', in
        meno, diversa, o due lettere vicine scambiate.
        """
        n = normalizza(parola) if parola else ""
        if len(n) < lunghezza_minima or n in self.mappa:
            return None
        indice = self._indice_lunghezze()
        trovate: dict[str, str] = {}
        for lung in (len(n) - 1, len(n), len(n) + 1):
            for candidata in indice.get(lung, ()):
                if _un_errore(n, candidata):
                    trovate[candidata] = self.mappa[candidata]
        canoniche = set(trovate.values())
        if len(canoniche) != 1:
            return None
        return min(trovate), canoniche.pop()

    def _indice_lunghezze(self) -> dict[int, list[str]]:
        if self._per_lunghezza is None:
            indice: dict[int, list[str]] = {}
            for p in self.mappa:
                indice.setdefault(len(p), []).append(p)
            self._per_lunghezza = indice
        return self._per_lunghezza

    def __contains__(self, parola: object) -> bool:
        return isinstance(parola, str) and normalizza(parola) in self.mappa

    def __len__(self) -> int:
        return len(self.mappa)

    def parole_per(self, canonica: str) -> list[str]:
        """Tutte le parole (normalizzate) che portano a ``canonica``, in ordine."""
        return sorted(p for p, c in self.mappa.items() if c == canonica)

    def aggiungi(self, canonica: str, parole: Iterable[str], *, sovrascrivi: bool = False,
                 sostantivi: bool = False) -> None:
        """Collega ``parole`` a ``canonica``; le escluse vengono ignorate.

        Senza ``sovrascrivi`` una parola gia' presente mantiene la sua canonica.
        Con ``sostantivi=True`` le parole sono segnate come nomi comuni che
        possono essere anche variabili (vedi :meth:`e_sostantivo`).
        """
        canonica = str(canonica).strip()
        if not canonica:
            return
        self.canoniche.add(canonica)
        self._per_lunghezza = None
        # `pi_greco` -> `PI_GRECO` si': cambia solo per le maiuscole, ma e' un altro nome
        stessa = normalizza(canonica) if canonica == canonica.lower() else None
        for p in parole:
            n = normalizza(p)
            if not n or n in self.escluse or n == stessa or str(p) == canonica:
                continue
            if sovrascrivi or n not in self.mappa:
                self.mappa[n] = canonica
                if sostantivi:
                    self.sostantivi.add(n)
                else:
                    self.sostantivi.discard(n)

    def aggiungi_da_dizionario(self, dati: dict) -> None:
        """Legge le sezioni ``[vocabolario]`` e ``[sostantivi]`` (o un dizionario
        ``{canonica: [parole]}`` senza sezioni)."""
        if not isinstance(dati, dict):
            return
        if "vocabolario" in dati or "sostantivi" in dati:
            sezioni = [(dati.get("vocabolario", {}), False), (dati.get("sostantivi", {}), True)]
        else:
            sezioni = [(dati, False)]
        for sezione, sostantivi in sezioni:
            if not isinstance(sezione, dict):
                continue
            for canonica, elenco in sezione.items():
                if isinstance(elenco, str):
                    elenco = [elenco]
                if not isinstance(elenco, (list, tuple)):
                    continue
                self.aggiungi(str(canonica), (str(x) for x in elenco), sostantivi=sostantivi)

    def aggiungi_thesaurus(self, voci: Iterable[tuple[str, list[list[str]]]]) -> int:
        """Collega le voci di un thesaurus alle canoniche; restituisce le parole aggiunte.

        Le parole gia' presenti (vocabolario scritto a mano) non cambiano; le
        parole del thesaurus che porterebbero a due canoniche diverse sono
        scartate.
        """
        # parola normalizzata -> canonica, per riconoscere le voci collegate
        chiavi: dict[str, str] = {normalizza(c): c for c in self.canoniche}
        chiavi.update({k: v for k, v in self.mappa.items() if k not in chiavi})
        canoniche_n = {normalizza(c): c for c in self.canoniche}
        proposte: dict[str, set[str]] = {}

        def proponi(parola: str, canonica: str) -> None:
            n = normalizza(parola)
            if not n or n in self.escluse or n in self.mappa or n in canoniche_n:
                return
            proposte.setdefault(n, set()).add(canonica)

        for parola, significati in voci:
            np = normalizza(parola)
            if np in chiavi:
                canonica = chiavi[np]
                for sig in significati:
                    for s in sig:
                        proponi(s, canonica)
                continue
            for sig in significati:
                for s in sig:
                    ns = normalizza(s)
                    if ns in canoniche_n:
                        proponi(parola, canoniche_n[ns])
                    elif ns in chiavi:
                        proponi(parola, chiavi[ns])
        aggiunte = 0
        for n, canoniche in proposte.items():
            if len(canoniche) == 1:
                self.mappa[n] = next(iter(canoniche))
                aggiunte += 1
        return aggiunte


# ---------------------------------------------------------------------------
# Lettura del thesaurus (formato LibreOffice / MyThes)
# ---------------------------------------------------------------------------

_CODIFICHE = {
    "UTF-8": "utf-8", "UTF8": "utf-8",
    "ISO8859-1": "latin-1", "ISO-8859-1": "latin-1",
    "ISO8859-15": "iso8859_15", "ISO-8859-15": "iso8859_15",
    "WINDOWS-1252": "cp1252", "CP1252": "cp1252",
}


def _pulisci_termine(t: str) -> str:
    return " ".join(_PARENTESI.sub(" ", t).split())


def voci_thesaurus(righe: Iterable[str]) -> Iterator[tuple[str, list[list[str]]]]:
    """Analizza le righe (gia' decodificate, SENZA la riga della codifica).

    Restituisce ``(parola, [[sinonimo, ...], ...])`` per ogni voce. Le righe
    malformate vengono saltate; la categoria ``(verbo)`` e le annotazioni tra
    parentesi vengono tolte.
    """
    it = iter(righe)
    for riga in it:
        riga = riga.rstrip("\r\n")
        if not riga.strip() or "|" not in riga:
            continue
        parola, _, numero = riga.partition("|")
        parola = _pulisci_termine(parola)
        try:
            n = int(numero.strip())
        except ValueError:
            continue
        significati: list[list[str]] = []
        for _ in range(max(0, n)):
            try:
                sig = next(it).rstrip("\r\n")
            except StopIteration:
                break
            campi = sig.split("|")
            if campi and campi[0].strip().startswith("("):
                campi = campi[1:]
            termini = [t for t in (_pulisci_termine(c) for c in campi) if t]
            if termini:
                significati.append(termini)
        if parola:
            yield parola, significati


def _decodifica(dati: bytes) -> list[str]:
    prima, _, resto = dati.partition(b"\n")
    nome = prima.decode("ascii", "replace").strip().lstrip("﻿").upper()
    codifica = _CODIFICHE.get(nome)
    if codifica is None:
        # nessuna riga di codifica riconosciuta: la prima riga e' gia' contenuto
        codifica, resto = "utf-8", dati
    try:
        testo = resto.decode(codifica)
    except UnicodeDecodeError:
        testo = resto.decode("latin-1")
    return testo.splitlines()


def leggi_thesaurus(percorso: str | os.PathLike) -> list[tuple[str, list[list[str]]]]:
    """Legge un file ``.dat`` di thesaurus (vedi :func:`voci_thesaurus`)."""
    dati = Path(percorso).read_bytes()
    if dati.startswith(b"\xef\xbb\xbf"):
        dati = dati[3:]
    return list(voci_thesaurus(_decodifica(dati)))


# ---------------------------------------------------------------------------
# Caricamento
# ---------------------------------------------------------------------------

def _file_dati(nome: str) -> Path | None:
    try:
        from .percorsi import file_dati
        return file_dati(nome)
    except Exception:  # noqa: BLE001
        return None


def file_aggiuntivi(file_vocabolario: str | os.PathLike) -> list[Path]:
    """Le raccolte aggiuntive accanto a ``vocabolario.toml``: i file ``*.toml``
    della cartella con lo stesso nome (``dati/vocabolario/``), in ordine alfabetico."""
    cartella = Path(file_vocabolario).with_suffix("")
    try:
        return sorted(p for p in cartella.glob("*.toml") if p.is_file())
    except OSError:
        return []


def _aggiungi_file(voc: Vocabolario, file: Path) -> None:
    try:
        from .tomlutil import carica_toml
        voc.aggiungi_da_dizionario(carica_toml(file))
    except Exception:  # noqa: BLE001 - file malformato: si ignora
        pass


def carica_vocabolario(percorso: str | os.PathLike | None = None, *,
                       thesaurus: str | os.PathLike | None = None) -> Vocabolario:
    """Vocabolario da ``percorso`` (predefinito ``dati/vocabolario.toml``, a cui
    si aggiungono le parole di :data:`PAROLE_PER_CONTESTO`), piu' le raccolte
    della cartella accanto (``dati/vocabolario/*.toml``, vedi
    :func:`file_aggiuntivi`).

    Il thesaurus si cerca in ``thesaurus`` o, se non indicato, accanto al
    file del vocabolario (``thesaurus.dat``). Se un file manca o non si puo'
    leggere viene ignorato: il vocabolario serve solo ai suggerimenti e non
    deve mai impedire di mostrare un errore.
    """
    voc = Vocabolario(escluse=_parole_escluse())
    voc.canoniche.update(_canoniche_note())
    file_voc = Path(percorso) if percorso is not None else _file_dati("vocabolario.toml")
    if file_voc is not None and file_voc.is_file():
        _aggiungi_file(voc, file_voc)
    if percorso is None:
        # vocabolario di sistema: in piu' le parole che portano alle parole di
        # contesto (scegli, importa, verifica), prima del thesaurus cosi' anche
        # le sue voci vi si possono collegare
        for canonica, parole in PAROLE_PER_CONTESTO.items():
            voc.aggiungi(canonica, parole)
        for parola, canonica in _PRECEDENZA_CONTESTO.items():
            voc.aggiungi(canonica, [parola], sovrascrivi=True)
    if file_voc is not None:
        for file in file_aggiuntivi(file_voc):
            _aggiungi_file(voc, file)
    if thesaurus is not None:
        file_th: Path | None = Path(thesaurus)
    elif file_voc is not None:
        file_th = file_voc.with_name("thesaurus.dat")
    else:
        file_th = _file_dati("thesaurus.dat")
    if file_th is not None and file_th.is_file():
        try:
            voc.aggiungi_thesaurus(leggi_thesaurus(file_th))
        except Exception:  # noqa: BLE001
            pass
    return voc


# ---------------------------------------------------------------------------
# Cache (in memoria e su disco)
# ---------------------------------------------------------------------------
#
# Il vocabolario di sistema ha qualche migliaio di voci in piu' file TOML: su
# Python 3.10 (senza tomllib) leggerli costa decine di millisecondi. Il
# risultato si salva quindi in un file JSON nella cartella dell'utente, insieme
# a una "firma" (percorso, data di modifica e dimensione di ogni file da cui
# dipende): se un file cambia la firma non corrisponde piu' e il vocabolario si
# ricostruisce. ``LEO_SENZA_CACHE=1`` (o la vecchia ``DANTE_SENZA_CACHE``) disattiva la cache su disco.

#: Cambia quando cambia il formato del file di cache o il modo di costruire il vocabolario.
FORMATO_CACHE = 1
_NOME_CACHE = "vocabolario.json"


def _cartella_cache() -> Path | None:
    if (variabile_ambiente("SENZA_CACHE") or "").strip() not in ("", "0"):
        return None
    try:
        from .percorsi import cartella_utente
        return cartella_utente() / "cache"
    except Exception:  # noqa: BLE001
        return None


def _file_della_firma() -> list[Path]:
    """I file da cui dipende il vocabolario di sistema."""
    file: list[Path] = []
    voc = _file_dati("vocabolario.toml")
    if voc is not None:
        file.append(voc)
        file.extend(file_aggiuntivi(voc))
        file.append(voc.with_name("thesaurus.dat"))
    sinonimi = _file_dati("sinonimi.toml")
    if sinonimi is not None:
        file.append(sinonimi)
    qui = Path(__file__).resolve().parent
    file.extend([Path(__file__).resolve(), qui / "tokens.py", qui / "sinonimi.py"])
    if getattr(sys, "frozen", False):
        # nell'eseguibile (PyInstaller) i .py non ci sono: conta l'eseguibile, che cambia
        # a ogni nuova versione di Leo (altrimenti la cache vecchia resterebbe buona)
        file.append(Path(sys.executable))
    return file


def firma_vocabolario() -> list[list]:
    """``[[percorso, mtime_ns, dimensione], ...]`` dei file da cui dipende il
    vocabolario di sistema (``-1`` per un file che manca)."""
    firma: list[list] = [["formato", FORMATO_CACHE, 0]]
    for f in _file_della_firma():
        try:
            st = f.stat()
            firma.append([str(f), st.st_mtime_ns, st.st_size])
        except OSError:
            firma.append([str(f), -1, -1])
    return firma


def _leggi_cache(cartella: Path, firma: list[list]) -> Vocabolario | None:
    import json
    try:
        dati = json.loads((cartella / _NOME_CACHE).read_text(encoding="utf-8"))
        if not isinstance(dati, dict) or dati.get("firma") != firma:
            return None
        mappa = dati["mappa"]
        if not isinstance(mappa, dict):
            return None
        return Vocabolario(
            mappa={str(k): str(v) for k, v in mappa.items()},
            canoniche={str(c) for c in dati.get("canoniche", ())},
            escluse={str(e) for e in dati.get("escluse", ())},
            sostantivi={str(s) for s in dati.get("sostantivi", ())},
        )
    except Exception:  # noqa: BLE001 - cache assente, vecchia o rovinata
        return None


def _scrivi_cache(cartella: Path, firma: list[list], voc: Vocabolario) -> None:
    import json
    import tempfile
    dati = {
        "firma": firma,
        "mappa": voc.mappa,
        "canoniche": sorted(voc.canoniche),
        "escluse": sorted(voc.escluse),
        "sostantivi": sorted(voc.sostantivi),
    }
    try:
        cartella.mkdir(parents=True, exist_ok=True)
        fd, temporaneo = tempfile.mkstemp(prefix=".vocabolario-", suffix=".json", dir=str(cartella))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(dati, f, ensure_ascii=False, separators=(",", ":"))
            os.replace(temporaneo, cartella / _NOME_CACHE)
        except BaseException:
            try:
                os.unlink(temporaneo)
            except OSError:
                pass
            raise
    except Exception:  # noqa: BLE001 - cartella non scrivibile: pazienza
        pass


def carica_vocabolario_con_cache() -> Vocabolario:
    """Il vocabolario di sistema, dalla cache su disco se e' aggiornata."""
    cartella = _cartella_cache()
    if cartella is None:
        return carica_vocabolario()
    firma = firma_vocabolario()
    voc = _leggi_cache(cartella, firma)
    if voc is None:
        voc = carica_vocabolario()
        _scrivi_cache(cartella, firma, voc)
    return voc


_CACHE: Vocabolario | None = None
#: un solo caricamento alla volta (Leo Studio lo prepara in un thread dopo la comparsa)
_BLOCCO = threading.RLock()
_THREAD: threading.Thread | None = None


def vocabolario_predefinito() -> Vocabolario:
    """Il vocabolario di sistema, caricato una sola volta (vedi anche la cache su disco).

    Si puo' chiamare da piu' thread: se :func:`precarica_in_background` lo sta
    gia' caricando, si aspetta quel caricamento invece di rifarlo."""
    global _CACHE
    voc = _CACHE
    if voc is not None:
        return voc
    with _BLOCCO:
        if _CACHE is None:
            _CACHE = carica_vocabolario_con_cache()
        return _CACHE


def pronto() -> bool:
    """Vero se il vocabolario di sistema e' gia' in memoria (chiederlo non costa nulla)."""
    return _CACHE is not None


def precarica_in_background() -> threading.Thread | None:
    """Carica il vocabolario di sistema in un thread (demone) a bassa priorita' d'uso.

    Serve a Leo Studio: la finestra compare subito e il vocabolario (con il
    thesaurus, se c'e', anche qualche secondo al primo avvio) e' pronto quando
    arriva il primo errore da spiegare. Restituisce il thread, o ``None`` se il
    vocabolario e' gia' pronto o si sta gia' caricando."""
    global _THREAD
    if _CACHE is not None:
        return None
    with _BLOCCO:
        if _CACHE is not None or (_THREAD is not None and _THREAD.is_alive()):
            return None

        def carica() -> None:
            try:
                vocabolario_predefinito()
            except Exception:  # noqa: BLE001 - riprovera' chi ne ha bisogno, in primo piano
                pass

        _THREAD = threading.Thread(target=carica, name="leo-vocabolario", daemon=True)
        _THREAD.start()
        return _THREAD


def azzera_cache(*, anche_su_disco: bool = False) -> None:
    """Dimentica il vocabolario in cache (per i test o dopo un aggiornamento).

    Con ``anche_su_disco=True`` cancella anche il file di cache dell'utente.
    """
    global _CACHE
    with _BLOCCO:
        _CACHE = None
    if anche_su_disco:
        cartella = _cartella_cache()
        if cartella is not None:
            try:
                (cartella / _NOME_CACHE).unlink()
            except OSError:
                pass
