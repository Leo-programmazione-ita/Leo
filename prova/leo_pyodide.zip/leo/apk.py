"""Creazione di un'app Android (.apk) da un programma Leo, senza Gradle e senza SDK.

Idea: l'app Android di Leo (``android/``) è anche un **guscio**. Quando dentro l'APK
c'è la cartella ``assets/programma/`` con ``avvio.json``, l'app non mostra l'editor ma
esegue subito quel programma. Creare l'app di un programma vuol dire quindi:

1. copiare l'APK di Leo (il guscio) voce per voce, senza ricomprimere nulla;
2. aggiungere ``assets/programma/`` (il programma, i moduli che importa, ``avvio.json``);
3. cambiare nel manifest binario il pacchetto (così l'app si installa accanto a Leo),
   il nome mostrato sotto l'icona, la versione e le autorità dei provider;
4. togliere le architetture non richieste (``lib/x86_64`` serve solo all'emulatore) e, se non si
   chiede l'app completa, ciò che un'app creata non usa (esempi, sito, editor, Python non usato:
   vedi "Alleggerimento");
5. allineare le voci non compresse (4 byte; 16 KB le librerie ``.so``), come ``zipalign``;
6. firmare con lo schema di firma APK v2 (quello che Android controlla dalla 7.0 in poi;
   l'app ha ``minSdk 24``, quindi la vecchia firma JAR non serve).

Tutto è in Python puro, con la sola libreria standard: lo stesso codice gira sul PC
(``leo compila programma.leo --apk``) e sul telefono, dentro l'app di Leo (Chaquopy),
dove il guscio è l'APK di Leo installato.

La chiave di firma (RSA 2048 con certificato autofirmato) si crea la prima volta e si
conserva in ``chiave_apk.json`` nella cartella delle impostazioni di Leo: Android accetta
l'aggiornamento di un'app solo se è firmato con la stessa chiave, quindi va conservata.

API:
    crea_apk(programma, *, guscio, uscita=None, nome=None, pacchetto=None, versione=None,
             codice_versione=None, icona=None, chiave=None, abi=ABI_TELEFONI,
             avvisa=print, leggera=True) -> RisultatoApk
    moduli_leo_da_togliere(sorgenti) -> set[str]   - moduli di leo che l'app creata non usa
    trova_guscio(percorso=None, *, abi=ABI_TELEFONI) -> Path
    pacchetto_da_nome(nome) -> str ; controlla_pacchetto(pacchetto) -> str
    ManifestBinario(dati)  - lettura e modifica di AndroidManifest.xml compilato
    ChiaveFirma, genera_chiave(), carica_chiave(), salva_chiave(), chiave_predefinita()
    verifica_apk(percorso) -> dict   - controlla la firma v2 (digest, firma, certificato)
    ErroreApk
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import secrets
import struct
import tempfile
import time
import sys
import unicodedata
import zipfile
import zlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence

# ---------------------------------------------------------------------------
# Costanti
# ---------------------------------------------------------------------------

#: Voce che segnala un guscio capace di avviare un programma incluso (scritta da
#: ``android/prepara_sorgenti.py``). Il valore di ``formato`` sale se cambia il contratto.
MARCATORE_GUSCIO = "assets/leo_guscio.json"
FORMATO_GUSCIO = 1

#: Dove va il programma dentro l'APK (lo legge ``MainActivity``).
CARTELLA_PROGRAMMA = "assets/programma/"
#: il sito di Leo offline ("Guida e sito" dell'app): le app create non lo portano con se'
#: (lo toglie l'alleggerimento, vedi ``ASSET_SOLO_LEO``; resta solo con ``--app-completa``)
CARTELLA_SITO = "assets/sito/"
FILE_AVVIO = CARTELLA_PROGRAMMA + "avvio.json"
#: Icona dell'app per la schermata di caricamento della pagina (web/index.html la cerca in ../programma/).
FILE_ICONA = CARTELLA_PROGRAMMA + "icona.png"
LATO_ICONA_AVVIO = 288

#: Prefisso dei pacchetti creati da Leo (``it.leo.app.rubrica``).
PREFISSO_PACCHETTO = "it.leo.app"

#: Architetture dei telefoni veri (x86_64 serve solo all'emulatore del PC).
ABI_TELEFONI = ("arm64-v8a", "armeabi-v7a")

#: Nome del file della chiave nella cartella delle impostazioni di Leo.
NOME_FILE_CHIAVE = "chiave_apk.json"
#: Variabile d'ambiente con il percorso del guscio (facoltativa).
VARIABILE_GUSCIO = "LEO_GUSCIO_APK"

#: File del programma mai inclusi (come per l'eseguibile di Windows).
_ESTENSIONI_ESCLUSE = frozenset({".apk", ".exe", ".pyc", ".log", ".tmp", ".lnk", ".jks", ".keystore"})

#: Oltre questa dimensione un file del programma non viene incluso.
LIMITE_FILE = 50 * 1024 * 1024

_PAROLE_JAVA = frozenset("""abstract assert boolean break byte case catch char class const continue default do
double else enum extends final finally float for goto if implements import instanceof int interface long native
new package private protected public return short static strictfp super switch synchronized this throw throws
transient try void volatile while true false null""".split())


class ErroreApk(Exception):
    """Errore nella creazione dell'app, con un messaggio in italiano per chi usa Leo."""

    def __init__(self, messaggio: str, *, codice: int = 1) -> None:
        super().__init__(messaggio)
        self.messaggio = messaggio
        self.codice = codice


def _nulla(_testo: str) -> None:
    return None


# ===========================================================================
# Manifest binario (AndroidManifest.xml compilato da aapt2)
# ===========================================================================

_RES_STRING_POOL = 0x0001
_RES_XML = 0x0003
_RES_XML_START_NS = 0x0100
_RES_XML_END_NS = 0x0101
_RES_XML_START_ELEMENT = 0x0102
_RES_XML_END_ELEMENT = 0x0103
_RES_XML_RESOURCE_MAP = 0x0180
_UTF8 = 0x100
_NESSUNO = 0xFFFFFFFF

TIPO_RIFERIMENTO = 0x01
TIPO_TESTO = 0x03
TIPO_INTERO = 0x10
TIPO_BOOLEANO = 0x12

#: Identificativi degli attributi ``android:`` che servono qui.
ATTR_ETICHETTA = 0x01010001
ATTR_ICONA = 0x01010002
ATTR_NOME = 0x01010003
ATTR_AUTORITA = 0x01010018
ATTR_CODICE_VERSIONE = 0x0101021B
ATTR_NOME_VERSIONE = 0x0101021C
ATTR_ICONA_TONDA = 0x0101052C


def _leggi_lunghezza_utf8(dati: bytes, pos: int) -> tuple[int, int]:
    n = dati[pos]
    if n & 0x80:
        return ((n & 0x7F) << 8) | dati[pos + 1], pos + 2
    return n, pos + 1


def _leggi_lunghezza_utf16(dati: bytes, pos: int) -> tuple[int, int]:
    n = struct.unpack_from("<H", dati, pos)[0]
    if n & 0x8000:
        return ((n & 0x7FFF) << 16) | struct.unpack_from("<H", dati, pos + 2)[0], pos + 4
    return n, pos + 2


def _scrivi_lunghezza_utf8(n: int) -> bytes:
    if n > 0x7FFF:
        raise ErroreApk("Testo troppo lungo per il manifest.")
    return bytes([n]) if n < 0x80 else bytes([0x80 | (n >> 8), n & 0xFF])


def _scrivi_lunghezza_utf16(n: int) -> bytes:
    if n > 0x7FFFFFFF:
        raise ErroreApk("Testo troppo lungo per il manifest.")
    return struct.pack("<H", n) if n < 0x8000 else struct.pack("<HH", 0x8000 | (n >> 16), n & 0xFFFF)


class PoolTesti:
    """Il pool dei testi di un file binario di Android (``ResStringPool``)."""

    def __init__(self, dati: bytes, inizio: int = 0) -> None:
        tipo, testa, dim = struct.unpack_from("<HHI", dati, inizio)
        if tipo != _RES_STRING_POOL:
            raise ErroreApk("Manifest non valido: manca il pool dei testi.")
        quanti, stili, flag, inizio_testi, inizio_stili = struct.unpack_from("<IIIII", dati, inizio + 8)
        self.utf8 = bool(flag & _UTF8)
        self.flag = flag
        self.dimensione = dim
        pos_offset = inizio + testa
        offset = struct.unpack_from(f"<{quanti}I", dati, pos_offset) if quanti else ()
        offset_stili = struct.unpack_from(f"<{stili}I", dati, pos_offset + 4 * quanti) if stili else ()
        base = inizio + inizio_testi
        self.testi: list[str] = [self._leggi(dati, base + o) for o in offset]
        self._offset_stili = list(offset_stili)
        if stili:
            fine = inizio + dim
            self._stili = dati[inizio + inizio_stili:fine]
        else:
            self._stili = b""

    def _leggi(self, dati: bytes, pos: int) -> str:
        if self.utf8:
            _n16, pos = _leggi_lunghezza_utf8(dati, pos)
            n8, pos = _leggi_lunghezza_utf8(dati, pos)
            return dati[pos:pos + n8].decode("utf-8", "replace")
        n, pos = _leggi_lunghezza_utf16(dati, pos)
        return dati[pos:pos + 2 * n].decode("utf-16-le", "replace")

    def indice(self, testo: str, *, aggiungi: bool = True) -> int:
        """Indice di ``testo``; se non c'è lo aggiunge in fondo (non tocca la mappa delle risorse)."""
        for i, t in enumerate(self.testi):
            if t == testo:
                return i
        if not aggiungi:
            return -1
        self.testi.append(testo)
        return len(self.testi) - 1

    def aggiungi(self, testo: str) -> int:
        """Aggiunge sempre un testo nuovo in fondo (anche se ce n'è già uno uguale)."""
        self.testi.append(testo)
        return len(self.testi) - 1

    def in_bytes(self) -> bytes:
        corpo = bytearray()
        offset = []
        for t in self.testi:
            offset.append(len(corpo))
            if self.utf8:
                b = t.encode("utf-8")
                corpo += _scrivi_lunghezza_utf8(len(t.encode("utf-16-le")) // 2)
                corpo += _scrivi_lunghezza_utf8(len(b)) + b + b"\x00"
            else:
                b = t.encode("utf-16-le")
                corpo += _scrivi_lunghezza_utf16(len(b) // 2) + b + b"\x00\x00"
        while len(corpo) % 4:
            corpo += b"\x00"
        quanti, stili = len(self.testi), len(self._offset_stili)
        testa = 28
        inizio_testi = testa + 4 * quanti + 4 * stili
        inizio_stili = inizio_testi + len(corpo) if stili else 0
        dim = inizio_testi + len(corpo) + len(self._stili)
        flag = self.flag & ~0x1                       # il pool non è più ordinato
        out = bytearray(struct.pack("<HHIIIIII", _RES_STRING_POOL, testa, dim, quanti, stili, flag,
                                    inizio_testi, inizio_stili))
        out += struct.pack(f"<{quanti}I", *offset) if quanti else b""
        out += struct.pack(f"<{stili}I", *self._offset_stili) if stili else b""
        out += corpo + self._stili
        return bytes(out)


@dataclass
class Attributo:
    ns: int
    nome: int
    grezzo: int
    tipo: int
    valore: int
    res0: int = 0


@dataclass
class Elemento:
    riga: int
    commento: int
    ns: int
    nome: int
    attributi: list[Attributo]
    indice_id: int
    indice_classe: int
    indice_stile: int
    profondita: int = 0
    nome_testo: str = ""


class ManifestBinario:
    """Legge e modifica un ``AndroidManifest.xml`` compilato (formato binario di aapt2).

    Si conservano tutti i pezzi del file; le modifiche aggiungono testi nuovi in fondo al
    pool, così i testi condivisi (nomi di classi, per esempio) restano quelli di prima.
    """

    def __init__(self, dati: bytes) -> None:
        tipo, testa, dim = struct.unpack_from("<HHI", dati, 0)
        if tipo != _RES_XML or dim > len(dati):
            raise ErroreApk("AndroidManifest.xml non è un manifest binario valido.")
        pos = testa
        self.pool: PoolTesti | None = None
        self.mappa: list[int] = []
        #: pezzi dopo pool e mappa: ("elemento", Elemento) | ("fine", (riga, commento, ns, nome)) | ("grezzo", bytes)
        self.nodi: list[tuple[str, Any]] = []
        profondita = 0
        while pos < dim:
            t, h, d = struct.unpack_from("<HHI", dati, pos)
            if d < 8 or pos + d > len(dati):
                raise ErroreApk("AndroidManifest.xml è rovinato.")
            if t == _RES_STRING_POOL:
                self.pool = PoolTesti(dati, pos)
            elif t == _RES_XML_RESOURCE_MAP:
                n = (d - h) // 4
                self.mappa = list(struct.unpack_from(f"<{n}I", dati, pos + h))
            elif t == _RES_XML_START_ELEMENT:
                riga, commento = struct.unpack_from("<II", dati, pos + 8)
                ns, nome, a_inizio, a_dim, a_quanti, i_id, i_cl, i_st = struct.unpack_from(
                    "<IIHHHHHH", dati, pos + h)
                attributi = []
                base = pos + h + a_inizio
                for k in range(a_quanti):
                    a_ns, a_nome, grezzo, _dim_v, res0, tipo_v, valore = struct.unpack_from(
                        "<IIIHBBI", dati, base + k * a_dim)
                    attributi.append(Attributo(a_ns, a_nome, grezzo, tipo_v, valore, res0))
                self.nodi.append(("elemento", Elemento(riga, commento, ns, nome, attributi, i_id, i_cl, i_st,
                                                        profondita)))
                profondita += 1
            elif t == _RES_XML_END_ELEMENT:
                riga, commento, ns, nome = struct.unpack_from("<IIII", dati, pos + 8)
                profondita -= 1
                self.nodi.append(("fine", (riga, commento, ns, nome)))
            else:
                self.nodi.append(("grezzo", bytes(dati[pos:pos + d])))
            pos += d
        if self.pool is None:
            raise ErroreApk("AndroidManifest.xml non ha il pool dei testi.")
        for tipo_n, n in self.nodi:
            if tipo_n == "elemento":
                n.nome_testo = self.testo(n.nome)

    # --- lettura ---
    def testo(self, indice: int) -> str:
        assert self.pool is not None
        if indice == _NESSUNO or indice >= len(self.pool.testi):
            return ""
        return self.pool.testi[indice]

    def elementi(self, nome: str | None = None) -> list[Elemento]:
        return [n for t, n in self.nodi if t == "elemento" and (nome is None or n.nome_testo == nome)]

    def id_attributo(self, a: Attributo) -> int:
        return self.mappa[a.nome] if a.nome < len(self.mappa) else 0

    def attributo(self, el: Elemento, *, id_risorsa: int | None = None, nome: str | None = None) -> Attributo | None:
        for a in el.attributi:
            if id_risorsa is not None and self.id_attributo(a) == id_risorsa:
                return a
            if nome is not None and a.ns == _NESSUNO and self.testo(a.nome) == nome:
                return a
        return None

    def valore(self, a: Attributo | None) -> Any:
        if a is None:
            return None
        if a.tipo == TIPO_TESTO:
            return self.testo(a.valore)
        if a.grezzo != _NESSUNO:
            return self.testo(a.grezzo)
        if a.tipo == TIPO_BOOLEANO:
            return a.valore != 0
        return a.valore

    @property
    def radice(self) -> Elemento:
        el = self.elementi("manifest")
        if not el:
            raise ErroreApk("Il manifest non ha l'elemento <manifest>.")
        return el[0]

    @property
    def applicazione(self) -> Elemento:
        el = self.elementi("application")
        if not el:
            raise ErroreApk("Il manifest non ha l'elemento <application>.")
        return el[0]

    @property
    def pacchetto(self) -> str:
        return str(self.valore(self.attributo(self.radice, nome="package")) or "")

    def descrivi(self) -> dict[str, Any]:
        """Riassunto leggibile (per i test e per il rapporto)."""
        r, app = self.radice, self.applicazione
        permessi = [str(self.valore(self.attributo(e, id_risorsa=ATTR_NOME)))
                    for e in self.elementi("uses-permission")]
        dichiarati = [str(self.valore(self.attributo(e, id_risorsa=ATTR_NOME))) for e in self.elementi("permission")]
        autorita = [str(self.valore(self.attributo(e, id_risorsa=ATTR_AUTORITA))) for e in self.elementi("provider")]
        icona = self.attributo(app, id_risorsa=ATTR_ICONA)
        return {
            "pacchetto": self.pacchetto,
            "codice_versione": self.valore(self.attributo(r, id_risorsa=ATTR_CODICE_VERSIONE)),
            "nome_versione": self.valore(self.attributo(r, id_risorsa=ATTR_NOME_VERSIONE)),
            "etichetta": self.valore(self.attributo(app, id_risorsa=ATTR_ETICHETTA)),
            "icona": icona.valore if icona is not None and icona.tipo == TIPO_RIFERIMENTO else None,
            "permessi": permessi,
            "permessi_dichiarati": dichiarati,
            "autorita": autorita,
            "attivita": [str(self.valore(self.attributo(e, id_risorsa=ATTR_NOME))) for e in self.elementi("activity")],
        }

    # --- modifica ---
    def _metti_testo(self, a: Attributo, testo: str) -> None:
        assert self.pool is not None
        i = self.pool.aggiungi(testo)
        a.grezzo, a.tipo, a.valore = i, TIPO_TESTO, i

    def imposta_pacchetto(self, nuovo: str) -> None:
        """Cambia il pacchetto e tutto ciò che Android vuole unico per ogni app.

        Cambiano: ``package``, le autorità dei provider e i permessi dichiarati dall'app
        (``<vecchio>.QUALCOSA`` diventa ``<nuovo>.QUALCOSA``). I nomi delle classi restano:
        aapt2 li scrive già completi nel manifest.
        """
        vecchio = self.pacchetto
        a = self.attributo(self.radice, nome="package")
        if a is None or not vecchio:
            raise ErroreApk("Il manifest non indica il pacchetto.")
        self._metti_testo(a, nuovo)

        def rinomina(valore: str) -> str:
            parti = []
            for p in valore.split(";"):
                if p == vecchio:
                    p = nuovo
                elif p.startswith(vecchio + "."):
                    p = nuovo + p[len(vecchio):]
                parti.append(p)
            return ";".join(parti)

        for el in self.elementi("provider"):
            aut = self.attributo(el, id_risorsa=ATTR_AUTORITA)
            if aut is not None and aut.tipo == TIPO_TESTO:
                self._metti_testo(aut, rinomina(self.testo(aut.valore)))
        for nome_el in ("permission", "uses-permission", "permission-tree", "permission-group"):
            for el in self.elementi(nome_el):
                n = self.attributo(el, id_risorsa=ATTR_NOME)
                if n is not None and n.tipo == TIPO_TESTO:
                    valore = self.testo(n.valore)
                    if valore.startswith(vecchio + "."):
                        self._metti_testo(n, rinomina(valore))
        # permessi usati come protezione di un componente (android:permission)
        for el in self.elementi():
            for a2 in el.attributi:
                if self.id_attributo(a2) == 0x01010006 and a2.tipo == TIPO_TESTO:   # android:permission
                    valore = self.testo(a2.valore)
                    if valore.startswith(vecchio + "."):
                        self._metti_testo(a2, rinomina(valore))

    def imposta_etichetta(self, testo: str) -> None:
        """Nome dell'app sotto l'icona: un testo fisso al posto di ``@string/app_name``."""
        for el in [self.applicazione, *self.elementi("activity"), *self.elementi("activity-alias")]:
            a = self.attributo(el, id_risorsa=ATTR_ETICHETTA)
            if a is not None:
                self._metti_testo(a, testo)
        if self.attributo(self.applicazione, id_risorsa=ATTR_ETICHETTA) is None:
            raise ErroreApk("Il manifest non ha android:label nell'applicazione.")

    def imposta_versione(self, codice: int | None = None, nome: str | None = None) -> None:
        r = self.radice
        if codice is not None:
            a = self.attributo(r, id_risorsa=ATTR_CODICE_VERSIONE)
            if a is None:
                raise ErroreApk("Il manifest non ha android:versionCode.")
            a.grezzo, a.tipo, a.valore = _NESSUNO, TIPO_INTERO, int(codice)
        if nome is not None:
            a = self.attributo(r, id_risorsa=ATTR_NOME_VERSIONE)
            if a is None:
                raise ErroreApk("Il manifest non ha android:versionName.")
            self._metti_testo(a, nome)

    def togli_permesso(self, nome: str) -> bool:
        """Toglie ``<uses-permission android:name="nome"/>`` (elemento senza figli)."""
        for i, (t, n) in enumerate(self.nodi):
            if t == "elemento" and n.nome_testo == "uses-permission":
                a = self.attributo(n, id_risorsa=ATTR_NOME)
                if a is not None and self.valore(a) == nome:
                    if i + 1 < len(self.nodi) and self.nodi[i + 1][0] == "fine":
                        del self.nodi[i:i + 2]
                        return True
        return False

    def in_bytes(self) -> bytes:
        assert self.pool is not None
        corpo = bytearray(self.pool.in_bytes())
        if self.mappa:
            corpo += struct.pack("<HHI", _RES_XML_RESOURCE_MAP, 8, 8 + 4 * len(self.mappa))
            corpo += struct.pack(f"<{len(self.mappa)}I", *self.mappa)
        for t, n in self.nodi:
            if t == "elemento":
                attributi = b"".join(struct.pack("<IIIHBBI", a.ns, a.nome, a.grezzo, 8, a.res0, a.tipo, a.valore)
                                     for a in n.attributi)
                testa = struct.pack("<HHIII", _RES_XML_START_ELEMENT, 16, 16 + 20 + len(attributi),
                                    n.riga, n.commento)
                corpo += testa + struct.pack("<IIHHHHHH", n.ns, n.nome, 20, 20, len(n.attributi),
                                             n.indice_id, n.indice_classe, n.indice_stile) + attributi
            elif t == "fine":
                riga, commento, ns, nome = n
                corpo += struct.pack("<HHIIIII", _RES_XML_END_ELEMENT, 16, 24, riga, commento, ns, nome)
            else:
                corpo += n
        return struct.pack("<HHI", _RES_XML, 8, 8 + len(corpo)) + bytes(corpo)


# ===========================================================================
# resources.arsc: quali file contiene una risorsa (serve per l'icona)
# ===========================================================================

def file_della_risorsa(arsc: bytes, id_risorsa: int) -> list[str]:
    """Percorsi (``res/xx.png``) dei file di una risorsa, in tutte le configurazioni."""
    pacchetto_id, tipo_id, voce_id = id_risorsa >> 24, (id_risorsa >> 16) & 0xFF, id_risorsa & 0xFFFF
    tipo, testa, dim = struct.unpack_from("<HHI", arsc, 0)
    if tipo != 0x0002:
        raise ErroreApk("resources.arsc non valido.")
    pos = testa
    pool: PoolTesti | None = None
    risultato: list[str] = []
    while pos < dim:
        t, h, d = struct.unpack_from("<HHI", arsc, pos)
        if d < 8:
            break
        if t == _RES_STRING_POOL and pool is None:
            pool = PoolTesti(arsc, pos)
        elif t == 0x0200:                                    # pacchetto
            pid = struct.unpack_from("<I", arsc, pos + 8)[0]
            if pid == pacchetto_id:
                p2 = pos + h
                while p2 < pos + d:
                    t2, h2, d2 = struct.unpack_from("<HHI", arsc, p2)
                    if d2 < 8:
                        break
                    if t2 == 0x0201 and arsc[p2 + 8] == tipo_id:       # ResTable_type
                        flag = arsc[p2 + 9]
                        quante, inizio_voci = struct.unpack_from("<II", arsc, p2 + 12)
                        off = _offset_voce(arsc, p2 + h2, flag, quante, voce_id)
                        if off is not None:
                            v = p2 + inizio_voci + off
                            _dim_v, flag_v = struct.unpack_from("<HH", arsc, v)
                            if flag_v & 0x0008:                         # voce compatta
                                tipo_dato = flag_v >> 8
                                dato = struct.unpack_from("<I", arsc, v + 4)[0]
                            elif not flag_v & 0x0001:                   # non complessa
                                _s, _r, tipo_dato, dato = struct.unpack_from("<HBBI", arsc, v + 8)
                            else:
                                tipo_dato, dato = 0, 0
                            if tipo_dato == TIPO_TESTO and pool is not None and dato < len(pool.testi):
                                risultato.append(pool.testi[dato])
                    p2 += d2
        pos += d
    return risultato


def _offset_voce(arsc: bytes, inizio: int, flag: int, quante: int, voce: int) -> int | None:
    if flag & 0x01:                                          # sparsa: coppie (indice, offset/4)
        for k in range(quante):
            i, o = struct.unpack_from("<HH", arsc, inizio + 4 * k)
            if i == voce:
                return o * 4
        return None
    if voce >= quante:
        return None
    if flag & 0x02:                                          # offset a 16 bit (/4)
        o = struct.unpack_from("<H", arsc, inizio + 2 * voce)[0]
        return None if o == 0xFFFF else o * 4
    o = struct.unpack_from("<I", arsc, inizio + 4 * voce)[0]
    return None if o == _NESSUNO else o


# ===========================================================================
# RSA, certificato X.509 e chiave di firma (tutto in Python puro)
# ===========================================================================

_PRIMI_PICCOLI = [p for p in range(3, 2000, 2) if all(p % q for q in range(3, int(p ** 0.5) + 1, 2))]


def _probabilmente_primo(n: int, giri: int = 12) -> bool:
    if n < 2:
        return False
    for p in _PRIMI_PICCOLI:
        if n % p == 0:
            return n == p
    d, s = n - 1, 0
    while d % 2 == 0:
        d //= 2
        s += 1
    for _ in range(giri):
        a = secrets.randbelow(n - 3) + 2
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _r in range(s - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True


def _primo_casuale(bit: int, e: int) -> int:
    while True:
        c = secrets.randbits(bit) | (3 << (bit - 2)) | 1
        # si cerca in avanti a passi di 2: molto più veloce che ripartire ogni volta
        for passo in range(0, 2000, 2):
            n = c + passo
            if n.bit_length() != bit:
                break
            if any(n % p == 0 for p in _PRIMI_PICCOLI):
                continue
            if (n - 1) % e == 0:
                continue
            if _probabilmente_primo(n):
                return n


def _der(tag: int, contenuto: bytes) -> bytes:
    n = len(contenuto)
    if n < 0x80:
        lung = bytes([n])
    else:
        b = n.to_bytes((n.bit_length() + 7) // 8, "big")
        lung = bytes([0x80 | len(b)]) + b
    return bytes([tag]) + lung + contenuto


def _intero(n: int) -> bytes:
    b = n.to_bytes(max(1, (n.bit_length() + 8) // 8), "big")      # un byte in più per il segno
    return _der(0x02, b)


def _seq(*parti: bytes) -> bytes:
    return _der(0x30, b"".join(parti))


def _oid(testo: str) -> bytes:
    numeri = [int(x) for x in testo.split(".")]
    corpo = bytearray([40 * numeri[0] + numeri[1]])
    for n in numeri[2:]:
        pezzi = [n & 0x7F]
        n >>= 7
        while n:
            pezzi.append(0x80 | (n & 0x7F))
            n >>= 7
        corpo += bytes(reversed(pezzi))
    return _der(0x06, bytes(corpo))


_NULL = b"\x05\x00"
_OID_RSA = "1.2.840.113549.1.1.1"
_OID_SHA256_RSA = "1.2.840.113549.1.1.11"
_PREFISSO_SHA256 = bytes.fromhex("3031300d060960864801650304020105000420")


def _nome_x509(nome_comune: str, organizzazione: str = "Leo", paese: str = "IT") -> bytes:
    def voce(oid: str, valore: bytes) -> bytes:
        return _der(0x31, _seq(_oid(oid), valore))
    return _seq(voce("2.5.4.6", _der(0x13, paese.encode("ascii"))),
                voce("2.5.4.10", _der(0x0C, organizzazione.encode("utf-8"))),
                voce("2.5.4.3", _der(0x0C, nome_comune.encode("utf-8"))))


def _tempo_x509(secondi: float) -> bytes:
    t = time.gmtime(secondi)
    if 1950 <= t.tm_year < 2050:
        return _der(0x17, time.strftime("%y%m%d%H%M%SZ", t).encode("ascii"))
    return _der(0x18, time.strftime("%Y%m%d%H%M%SZ", t).encode("ascii"))


@dataclass
class ChiaveFirma:
    """Chiave RSA con il suo certificato autofirmato (DER)."""

    n: int
    e: int
    d: int
    p: int
    q: int
    certificato: bytes = b""
    nome: str = ""

    @property
    def bit(self) -> int:
        return self.n.bit_length()

    def chiave_pubblica_der(self) -> bytes:
        """``SubjectPublicKeyInfo`` in DER."""
        rsa = _seq(_intero(self.n), _intero(self.e))
        return _seq(_seq(_oid(_OID_RSA), _NULL), _der(0x03, b"\x00" + rsa))

    def firma_sha256(self, dati: bytes) -> bytes:
        """Firma RSASSA-PKCS1-v1_5 con SHA-256."""
        k = (self.n.bit_length() + 7) // 8
        t = _PREFISSO_SHA256 + hashlib.sha256(dati).digest()
        if k < len(t) + 11:
            raise ErroreApk("Chiave RSA troppo corta.")
        em = b"\x00\x01" + b"\xff" * (k - len(t) - 3) + b"\x00" + t
        m = int.from_bytes(em, "big")
        # teorema cinese del resto: circa 3 volte più veloce
        dp, dq = self.d % (self.p - 1), self.d % (self.q - 1)
        q_inv = pow(self.q, -1, self.p)
        m1, m2 = pow(m, dp, self.p), pow(m, dq, self.q)
        h = (q_inv * (m1 - m2)) % self.p
        s = m2 + h * self.q
        if pow(s, self.e, self.n) != m:                  # controllo contro errori di calcolo
            raise ErroreApk("La firma RSA non torna: la chiave è rovinata.")
        return s.to_bytes(k, "big")

    def impronta_sha256(self) -> str:
        return hashlib.sha256(self.certificato).hexdigest()

    def in_dizionario(self) -> dict[str, Any]:
        import base64

        return {"formato": 1, "tipo": "RSA", "nome": self.nome, "n": hex(self.n), "e": self.e,
                "d": hex(self.d), "p": hex(self.p), "q": hex(self.q),
                "certificato": base64.b64encode(self.certificato).decode("ascii")}

    @classmethod
    def da_dizionario(cls, d: dict[str, Any]) -> "ChiaveFirma":
        import base64

        try:
            chiave = cls(n=int(d["n"], 16), e=int(d["e"]), d=int(d["d"], 16), p=int(d["p"], 16),
                         q=int(d["q"], 16), certificato=base64.b64decode(d["certificato"]),
                         nome=str(d.get("nome", "")))
        except (KeyError, ValueError, TypeError) as e:
            raise ErroreApk(f"Il file della chiave è rovinato ({e}).") from None
        if chiave.p * chiave.q != chiave.n or not chiave.certificato:
            raise ErroreApk("Il file della chiave è rovinato (i numeri non tornano).")
        return chiave


def genera_chiave(nome: str = "Programmi Leo", *, bit: int = 2048, anni: int = 30,
                  avvisa: Callable[[str], Any] = _nulla) -> ChiaveFirma:
    """Crea una chiave RSA e il suo certificato autofirmato (sha256WithRSA)."""
    e = 65537
    while True:
        p = _primo_casuale(bit // 2, e)
        q = _primo_casuale(bit - bit // 2, e)
        if p == q:
            continue
        n = p * q
        if n.bit_length() != bit:
            continue
        phi = (p - 1) * (q - 1)
        try:
            d = pow(e, -1, phi)
        except ValueError:
            continue
        break
    if p < q:
        p, q = q, p
    chiave = ChiaveFirma(n=n, e=e, d=d, p=p, q=q, nome=nome)
    adesso = time.time()
    algoritmo = _seq(_oid(_OID_SHA256_RSA), _NULL)
    nome_x509 = _nome_x509(nome)
    tbs = _seq(
        _der(0xA0, _intero(2)),                                   # versione 3
        _intero(secrets.randbits(63) | 1),                        # numero di serie
        algoritmo,
        nome_x509,
        _seq(_tempo_x509(adesso - 86400), _tempo_x509(adesso + anni * 365.25 * 86400)),
        nome_x509,
        chiave.chiave_pubblica_der(),
    )
    firma = chiave.firma_sha256(tbs)
    chiave.certificato = _seq(tbs, algoritmo, _der(0x03, b"\x00" + firma))
    avvisa(f"Chiave creata (impronta SHA-256 {chiave.impronta_sha256()[:16]}...).")
    return chiave


def salva_chiave(chiave: ChiaveFirma, percorso: str | os.PathLike) -> Path:
    p = Path(percorso)
    p.parent.mkdir(parents=True, exist_ok=True)
    dati = dict(chiave.in_dizionario())
    dati["attenzione"] = ("Chiave di firma delle app Android create con Leo. CONSERVANE UNA COPIA: "
                          "senza, le app già installate non si potranno aggiornare. Non darla a nessuno.")
    temporaneo = p.with_name(p.name + ".tmp")
    temporaneo.write_text(json.dumps(dati, indent=1), encoding="utf-8")
    os.replace(temporaneo, p)
    try:
        os.chmod(p, 0o600)
    except OSError:
        pass
    return p


def carica_chiave(percorso: str | os.PathLike) -> ChiaveFirma:
    p = Path(percorso)
    try:
        dati = json.loads(p.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise ErroreApk(f"Non trovo la chiave `{p}`.", codice=2) from None
    except (OSError, ValueError) as e:
        raise ErroreApk(f"Non riesco a leggere la chiave `{p}`: {e}.") from None
    if not isinstance(dati, dict):
        raise ErroreApk(f"`{p}` non è una chiave di Leo.")
    return ChiaveFirma.da_dizionario(dati)


def percorso_chiave_predefinita() -> Path:
    from .percorsi import cartella_utente

    return cartella_utente() / NOME_FILE_CHIAVE


def chiave_predefinita(avvisa: Callable[[str], Any] = _nulla) -> tuple[ChiaveFirma, Path, bool]:
    """(chiave, percorso, nuova): quella salvata nelle impostazioni di Leo, creata la prima volta."""
    p = percorso_chiave_predefinita()
    if p.is_file():
        return carica_chiave(p), p, False
    avvisa("Creo la chiave di firma delle tue app (solo la prima volta, può volerci qualche secondo)...")
    chiave = genera_chiave(avvisa=avvisa)
    salva_chiave(chiave, p)
    return chiave, p, True


# ===========================================================================
# ZIP allineato e firma APK v2
# ===========================================================================

_ID_FIRMA_V2 = 0x7109871A
_ALGORITMO_RSA_PKCS1_SHA256 = 0x0103
_MAGICO_BLOCCO = b"APK Sig Block 42"
_PEZZO = 1024 * 1024
_ALLINEA_SO = 16384          # pagine da 16 KB (Android 15): va bene anche per quelle da 4 KB
_ID_EXTRA_ALLINEAMENTO = 0xD935


@dataclass
class _Voce:
    nome: str
    metodo: int
    crc: int
    compressa: int
    originale: int
    ora: int
    data: int
    offset: int = 0
    flag: int = 0


class ScrittoreApk:
    """Scrive le voci di un APK, allineate come fa ``zipalign``; poi firma (v2) e chiude."""

    def __init__(self, percorso: str | os.PathLike) -> None:
        self.percorso = Path(percorso)
        self._f = open(self.percorso, "wb")
        self.voci: list[_Voce] = []
        self._nomi: set[str] = set()

    def _allineamento(self, nome: str, metodo: int) -> int:
        if metodo != zipfile.ZIP_STORED:
            return 0
        return _ALLINEA_SO if nome.endswith(".so") else 4

    def aggiungi_grezza(self, nome: str, metodo: int, crc: int, dati: bytes, originale: int,
                        ora: int = 0, data: int = 0x21) -> None:
        """Aggiunge una voce con i dati già compressi (o non compressi se ``metodo`` = 0)."""
        if nome in self._nomi:
            raise ErroreApk(f"Voce doppia nell'APK: {nome}")
        self._nomi.add(nome)
        nome_b = nome.encode("utf-8")
        flag = 0x0800 if any(ord(c) > 127 for c in nome) else 0
        offset = self._f.tell()
        extra = b""
        allinea = self._allineamento(nome, metodo)
        if allinea:
            inizio_dati = offset + 30 + len(nome_b)
            vuoto = (-inizio_dati) % allinea
            if vuoto:
                while vuoto < 6:
                    vuoto += allinea
                extra = struct.pack("<HHH", _ID_EXTRA_ALLINEAMENTO, vuoto - 4, allinea) + b"\x00" * (vuoto - 6)
        versione = 20 if metodo == zipfile.ZIP_DEFLATED else 10
        self._f.write(struct.pack("<IHHHHHIIIHH", 0x04034B50, versione, flag, metodo, ora, data,
                                  crc, len(dati), originale, len(nome_b), len(extra)))
        self._f.write(nome_b + extra)
        self._f.write(dati)
        self.voci.append(_Voce(nome, metodo, crc, len(dati), originale, ora, data, offset, flag))

    def aggiungi(self, nome: str, dati: bytes, *, comprimi: bool = True) -> None:
        crc = zlib.crc32(dati) & 0xFFFFFFFF
        if comprimi and dati:
            c = zlib.compressobj(9, zlib.DEFLATED, -15)
            compressi = c.compress(dati) + c.flush()
            if len(compressi) < len(dati):
                self.aggiungi_grezza(nome, zipfile.ZIP_DEFLATED, crc, compressi, len(dati))
                return
        self.aggiungi_grezza(nome, zipfile.ZIP_STORED, crc, dati, len(dati))

    def _directory_centrale(self) -> bytes:
        out = bytearray()
        for v in self.voci:
            nome_b = v.nome.encode("utf-8")
            versione = 20 if v.metodo == zipfile.ZIP_DEFLATED else 10
            out += struct.pack("<IHHHHHHIIIHHHHHII", 0x02014B50, versione, versione, v.flag, v.metodo, v.ora,
                               v.data, v.crc, v.compressa, v.originale, len(nome_b), 0, 0, 0, 0, 0, v.offset)
            out += nome_b
        return bytes(out)

    def chiudi_firmando(self, chiave: ChiaveFirma) -> None:
        """Scrive blocco di firma v2, directory centrale e fine dell'archivio."""
        fine_voci = self._f.tell()
        self._f.close()
        centrale = self._directory_centrale()
        eocd = struct.pack("<IHHHHIIH", 0x06054B50, 0, 0, len(self.voci), len(self.voci),
                           len(centrale), fine_voci, 0)
        digest = _digest_v2(self.percorso, fine_voci, centrale, eocd)
        blocco = _blocco_firma_v2(digest, chiave)
        eocd = eocd[:16] + struct.pack("<I", fine_voci + len(blocco)) + eocd[20:]
        with open(self.percorso, "ab") as f:
            f.write(blocco)
            f.write(centrale)
            f.write(eocd)

    def annulla(self) -> None:
        try:
            self._f.close()
        finally:
            try:
                self.percorso.unlink()
            except OSError:
                pass


def _digest_pezzi(pezzi: Iterable[bytes]) -> bytes:
    impronte = []
    for pezzo in pezzi:
        impronte.append(hashlib.sha256(b"\xa5" + struct.pack("<I", len(pezzo)) + pezzo).digest())
    return hashlib.sha256(b"\x5a" + struct.pack("<I", len(impronte)) + b"".join(impronte)).digest()


def _pezzi_file(percorso: Path, fine: int) -> Iterable[bytes]:
    with open(percorso, "rb") as f:
        letti = 0
        while letti < fine:
            b = f.read(min(_PEZZO, fine - letti))
            if not b:
                raise ErroreApk("L'APK si è accorciato durante la firma.")
            letti += len(b)
            yield b


def _pezzi_bytes(dati: bytes) -> Iterable[bytes]:
    for i in range(0, len(dati), _PEZZO):
        yield dati[i:i + _PEZZO]


def _digest_v2(percorso: Path, fine_voci: int, centrale: bytes, eocd: bytes) -> bytes:
    """Digest SHA-256 a pezzi da 1 MB delle tre parti dell'APK (schema v2)."""
    # nella fine dell'archivio, l'offset della directory centrale vale l'inizio del blocco di firma
    eocd = eocd[:16] + struct.pack("<I", fine_voci) + eocd[20:]

    def tutti() -> Iterable[bytes]:
        yield from _pezzi_file(percorso, fine_voci)
        yield from _pezzi_bytes(centrale)
        yield from _pezzi_bytes(eocd)
    return _digest_pezzi(tutti())


def _lp(dati: bytes) -> bytes:
    """Prefisso di lunghezza a 32 bit (little endian)."""
    return struct.pack("<I", len(dati)) + dati


def _blocco_firma_v2(digest: bytes, chiave: ChiaveFirma) -> bytes:
    digests = _lp(_lp(struct.pack("<I", _ALGORITMO_RSA_PKCS1_SHA256) + _lp(digest)))
    certificati = _lp(_lp(chiave.certificato))
    attributi = _lp(b"")
    dati_firmati = digests + certificati + attributi
    firma = chiave.firma_sha256(dati_firmati)
    firme = _lp(_lp(struct.pack("<I", _ALGORITMO_RSA_PKCS1_SHA256) + _lp(firma)))
    firmatario = _lp(dati_firmati) + firme + _lp(chiave.chiave_pubblica_der())
    valore = _lp(_lp(firmatario))
    coppia = struct.pack("<I", _ID_FIRMA_V2) + valore
    coppie = struct.pack("<Q", len(coppia)) + coppia
    dim = len(coppie) + 8 + 16
    return struct.pack("<Q", dim) + coppie + struct.pack("<Q", dim) + _MAGICO_BLOCCO


def _leggi_lp(dati: bytes, pos: int) -> tuple[bytes, int]:
    if pos + 4 > len(dati):
        raise ErroreApk("Firma v2 troncata.")
    n = struct.unpack_from("<I", dati, pos)[0]
    if pos + 4 + n > len(dati):
        raise ErroreApk("Firma v2 troncata.")
    return dati[pos + 4:pos + 4 + n], pos + 4 + n


def _elenco_lp(dati: bytes) -> list[bytes]:
    out, pos = [], 0
    while pos < len(dati):
        v, pos = _leggi_lp(dati, pos)
        out.append(v)
    return out


def _leggi_der(dati: bytes, pos: int) -> tuple[int, bytes, int]:
    tag = dati[pos]
    n = dati[pos + 1]
    pos += 2
    if n & 0x80:
        k = n & 0x7F
        n = int.from_bytes(dati[pos:pos + k], "big")
        pos += k
    return tag, dati[pos:pos + n], pos + n


def _rsa_da_spki(spki: bytes) -> tuple[int, int]:
    _t, corpo, _ = _leggi_der(spki, 0)
    _t, _alg, pos = _leggi_der(corpo, 0)
    _t, bitstring, _ = _leggi_der(corpo, pos)
    _t, rsa, _ = _leggi_der(bitstring[1:], 0)
    _t, n_b, pos = _leggi_der(rsa, 0)
    _t, e_b, _ = _leggi_der(rsa, pos)
    return int.from_bytes(n_b, "big"), int.from_bytes(e_b, "big")


def verifica_apk(percorso: str | os.PathLike) -> dict[str, Any]:
    """Controlla la firma v2 di un APK: digest dei contenuti, firma RSA e certificato.

    Restituisce ``{"ok": True, "certificato_sha256": ..., "voci": N}`` oppure solleva
    :class:`ErroreApk` con il motivo.
    """
    p = Path(percorso)
    dati = p.read_bytes()
    fine_eocd = dati.rfind(b"PK\x05\x06")
    if fine_eocd < 0:
        raise ErroreApk("Non è un archivio ZIP.")
    eocd = dati[fine_eocd:]
    voci, dim_cd, off_cd = struct.unpack_from("<HII", eocd, 10)
    if dati[off_cd - 16:off_cd] != _MAGICO_BLOCCO:
        raise ErroreApk("L'APK non ha il blocco di firma v2.")
    dim = struct.unpack_from("<Q", dati, off_cd - 24)[0]
    inizio = off_cd - dim - 8
    if struct.unpack_from("<Q", dati, inizio)[0] != dim:
        raise ErroreApk("Blocco di firma rovinato.")
    pos, fine = inizio + 8, off_cd - 24
    valore_v2 = None
    while pos < fine:
        n = struct.unpack_from("<Q", dati, pos)[0]
        ident = struct.unpack_from("<I", dati, pos + 8)[0]
        if ident == _ID_FIRMA_V2:
            valore_v2 = dati[pos + 12:pos + 8 + n]
        pos += 8 + n
    if valore_v2 is None:
        raise ErroreApk("Manca la firma v2.")
    firmatari = _elenco_lp(_leggi_lp(valore_v2, 0)[0])
    if len(firmatari) != 1:
        raise ErroreApk("Numero di firmatari inatteso.")
    firmatario = firmatari[0]
    dati_firmati, pos = _leggi_lp(firmatario, 0)
    firme_b, pos = _leggi_lp(firmatario, pos)
    spki, _ = _leggi_lp(firmatario, pos)
    n, e = _rsa_da_spki(spki)
    firme = _elenco_lp(firme_b)
    alg = struct.unpack_from("<I", firme[0], 0)[0]
    firma, _ = _leggi_lp(firme[0], 4)
    if alg != _ALGORITMO_RSA_PKCS1_SHA256:
        raise ErroreApk(f"Algoritmo di firma {alg:#x} non gestito.")
    k = (n.bit_length() + 7) // 8
    em = pow(int.from_bytes(firma, "big"), e, n).to_bytes(k, "big")
    atteso = _PREFISSO_SHA256 + hashlib.sha256(dati_firmati).digest()
    if em != b"\x00\x01" + b"\xff" * (k - len(atteso) - 3) + b"\x00" + atteso:
        raise ErroreApk("La firma RSA non è valida.")
    digests_b, pos = _leggi_lp(dati_firmati, 0)
    certificati_b, _ = _leggi_lp(dati_firmati, pos)
    digest_v = _elenco_lp(digests_b)[0]
    digest_firmato, _ = _leggi_lp(digest_v, 4)
    eocd_mod = eocd[:16] + struct.pack("<I", inizio) + eocd[20:]
    calcolato = _digest_pezzi(list(_pezzi_bytes(dati[:inizio])) + list(_pezzi_bytes(dati[off_cd:off_cd + dim_cd]))
                              + list(_pezzi_bytes(eocd_mod)))
    if calcolato != digest_firmato:
        raise ErroreApk("Il contenuto dell'APK non corrisponde alla firma (digest diverso).")
    certificato = _elenco_lp(certificati_b)[0]
    if spki not in certificato:
        raise ErroreApk("La chiave pubblica non è quella del certificato.")
    return {"ok": True, "certificato_sha256": hashlib.sha256(certificato).hexdigest(), "voci": voci}


# ===========================================================================
# Lettura del guscio
# ===========================================================================

def _voci_grezze(percorso: Path) -> tuple[zipfile.ZipFile, list[zipfile.ZipInfo]]:
    try:
        z = zipfile.ZipFile(percorso)
    except (OSError, zipfile.BadZipFile) as e:
        raise ErroreApk(f"`{percorso.name}` non è un APK valido ({e}).") from None
    return z, z.infolist()


def _dati_compressi(f: Any, info: zipfile.ZipInfo) -> bytes:
    f.seek(info.header_offset)
    testa = f.read(30)
    if testa[:4] != b"PK\x03\x04":
        raise ErroreApk(f"Voce rovinata nel guscio: {info.filename}")
    n_nome, n_extra = struct.unpack_from("<HH", testa, 26)
    f.seek(info.header_offset + 30 + n_nome + n_extra)
    dati = f.read(info.compress_size)
    if len(dati) != info.compress_size:
        raise ErroreApk(f"Voce troncata nel guscio: {info.filename}")
    return dati


def _abi_del_file(percorso: Path) -> set[str]:
    """Architetture (``lib/<abi>/``) presenti in un APK; insieme vuoto se non si legge."""
    try:
        with zipfile.ZipFile(percorso) as z:
            return {n.split("/")[1] for n in z.namelist() if n.startswith("lib/") and n.count("/") >= 2}
    except (OSError, zipfile.BadZipFile):
        return set()


#: percorso del guscio dentro ``dati/`` nella distribuzione per Windows (vedi ``costruisci.PERCORSO_GUSCIO``)
NOME_GUSCIO_INSTALLATO = ("android", "guscio.apk")


def _cartella_android() -> Path:
    """``android/`` accanto al pacchetto ``leo`` (dove ``costruisci_apk.bat`` mette gli APK di Leo)."""
    return Path(__file__).resolve().parent.parent / "android"


def trova_guscio(percorso: str | os.PathLike | None = None, *,
                 abi: Sequence[str] | None = ABI_TELEFONI) -> Path:
    """L'APK di Leo da usare come guscio.

    Ordine: ``percorso`` indicato, variabile ``LEO_GUSCIO_APK``, ``android/Leo-*.apk``
    accanto al pacchetto ``leo``, ``dati/android/guscio.apk``.

    ``costruisci_apk.bat`` fa un solo APK, ``Leo-0.1.0.apk``, con arm64-v8a, armeabi-v7a
    (tutti i telefoni veri) e x86_64 (l'emulatore del PC). Se in cartella restano APK vecchi
    (il ``-completo`` o uno per un solo processore) si sceglie quello che contiene più
    architetture tra quelle richieste in ``abi`` (None = tutte), a parità il più recente.
    """
    if percorso:
        p = Path(percorso)
        if not p.is_file():
            raise ErroreApk(f"Non trovo il guscio `{p}`.", codice=2)
        return p
    env = os.environ.get(VARIABILE_GUSCIO)
    if env and Path(env).is_file():
        return Path(env)
    richieste = None if abi is None else set(abi)

    def punteggio(q: Path) -> tuple[int, float]:
        presenti = _abi_del_file(q)
        return (len(presenti) if richieste is None else len(presenti & richieste), q.stat().st_mtime)
    candidati = sorted(_cartella_android().glob("Leo-*.apk"), key=punteggio, reverse=True)
    candidati += percorsi_guscio_noti()
    for c in candidati:
        if c.is_file():
            return c
    raise ErroreApk(
        "Non trovo l'app Android di Leo da usare come base (il \"guscio\").\n"
        "Con Leo installato dal Setup si trova in dati\\android\\guscio.apk: reinstalla Leo con un "
        "installatore che la contiene. Dai sorgenti: costruiscila una volta con android/costruisci_apk.bat, "
        "oppure indica il file con --guscio PERCORSO.apk (o con la variabile LEO_GUSCIO_APK).", codice=2)


def percorsi_guscio_noti() -> list[Path]:
    """Dove l'installatore (e chi lo copia a mano) mette il guscio, nell'ordine di ricerca.

    * ``dati/android/guscio.apk`` (``strumenti/distribuzione/costruisci.py`` lo mette nel pacchetto);
    * ``android/guscio.apk`` accanto all'eseguibile installato (``Leo Studio.exe``);
    * ``<cartella dell'utente>/android/guscio.apk`` (per aggiornarlo senza reinstallare).
    """
    percorsi: list[Path] = []
    try:
        from .percorsi import cartella_dati

        percorsi.append(cartella_dati() / NOME_GUSCIO_INSTALLATO[0] / NOME_GUSCIO_INSTALLATO[1])
    except Exception:  # noqa: BLE001
        pass
    if getattr(sys, "frozen", False):
        percorsi.append(Path(sys.executable).resolve().parent / "android" / "guscio.apk")
    try:
        from .percorsi import cartella_utente

        percorsi.append(cartella_utente() / "android" / "guscio.apk")
    except Exception:  # noqa: BLE001
        pass
    return percorsi


def informazioni_guscio(percorso: str | os.PathLike) -> dict[str, Any]:
    """Controlla che l'APK sia un guscio di Leo e ne restituisce pacchetto, versione e architetture."""
    p = Path(percorso)
    z, voci = _voci_grezze(p)
    with z:
        nomi = {v.filename for v in voci}
        if "AndroidManifest.xml" not in nomi or "classes.dex" not in nomi:
            raise ErroreApk(f"`{p.name}` non sembra un'app Android.")
        if MARCATORE_GUSCIO not in nomi:
            raise ErroreApk(
                f"`{p.name}` è un'app di Leo troppo vecchia: non sa ancora avviare un programma incluso.\n"
                "Ricostruiscila con android/costruisci_apk.bat e riprova.")
        try:
            marcatore = json.loads(z.read(MARCATORE_GUSCIO).decode("utf-8"))
        except ValueError:
            marcatore = {}
        if int(marcatore.get("formato", 0)) < FORMATO_GUSCIO:
            raise ErroreApk(f"`{p.name}` usa un formato di guscio vecchio: ricostruiscilo con costruisci_apk.bat.")
        manifest = ManifestBinario(z.read("AndroidManifest.xml"))
        abi = sorted({n.split("/")[1] for n in nomi if n.startswith("lib/") and n.count("/") >= 2})
    info = manifest.descrivi()
    info.update({"abi": abi, "leo": marcatore.get("leo", "?"), "formato": marcatore.get("formato")})
    return info


# ===========================================================================
# Nomi, pacchetti, versioni
# ===========================================================================

def _ascii(testo: str) -> str:
    return unicodedata.normalize("NFKD", testo).encode("ascii", "ignore").decode("ascii")


def pacchetto_da_nome(nome: str, prefisso: str = PREFISSO_PACCHETTO) -> str:
    """``"Rubrica di Anna"`` -> ``"it.leo.app.rubrica_di_anna"``."""
    parte = re.sub(r"[^a-z0-9]+", "_", _ascii(nome).lower()).strip("_") or "programma"
    if not parte[0].isalpha():
        parte = "app_" + parte
    if parte in _PAROLE_JAVA:
        parte += "_app"
    return f"{prefisso}.{parte[:60]}"


def controlla_pacchetto(pacchetto: str) -> str:
    """Il nome del pacchetto se è valido per Android, altrimenti :class:`ErroreApk`."""
    p = (pacchetto or "").strip()
    parti = p.split(".")
    if len(parti) < 2 or not all(re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", s) for s in parti):
        raise ErroreApk(
            f"`{pacchetto}` non è un nome di pacchetto valido: servono almeno due parti separate da punti, "
            "ognuna fatta di lettere senza accenti, cifre e _ e che inizia con una lettera "
            "(esempio: it.scuola.rubrica).", codice=2)
    for s in parti:
        if s in _PAROLE_JAVA:
            raise ErroreApk(f"`{s}` è una parola riservata di Java e non può stare nel pacchetto `{p}`.", codice=2)
    if p == "it.leo.linguaggio" or p.startswith("it.leo.linguaggio."):
        raise ErroreApk("Il pacchetto `it.leo.linguaggio` è quello dell'app di Leo: scegline un altro.", codice=2)
    if len(p) > 200:
        raise ErroreApk("Il nome del pacchetto è troppo lungo.", codice=2)
    return p


def codice_da_versione(versione: str) -> int:
    """``"1.2.3"`` -> 10203 (cresce con la versione: Android lo usa per gli aggiornamenti)."""
    numeri = [int(x) for x in re.findall(r"\d+", versione)[:3]]
    numeri += [0] * (3 - len(numeri))
    a, b, c = min(numeri[0], 20000), min(numeri[1], 99), min(numeri[2], 99)
    return max(1, a * 10000 + b * 100 + c)


# ===========================================================================
# Il programma da includere
# ===========================================================================

@dataclass
class ProgrammaApk:
    avvio: str                                  # percorso relativo del file da eseguire
    titolo: str
    finestre: bool = False                      # progetto con finestre (.maschera): parte sulla finestra
    file: list[tuple[Path, str]] = field(default_factory=list)
    avvisi: list[str] = field(default_factory=list)
    versione: str = ""
    autore: str = ""
    python_esterno: bool = False                # include pacchetti Python di `leo aggiungi`


def raccogli_programma(percorso: str | os.PathLike, *, controlla_codice: bool = True) -> ProgrammaApk:
    """Controlla il programma (sintassi, moduli importati) e sceglie i file da includere.

    Usa lo stesso esame di ``leo compila`` (:func:`leo.compila.analizza_programma`).
    Un progetto con finestre (maschere) parte sulla sua finestra iniziale, disegnata dall'app
    (``leo.grafica.web`` + ``finestre.js``); i controlli che sul telefono non ci sono diventano avvisi.
    """
    from .compila import ErroreCompilazione, analizza_programma

    try:
        piano = analizza_programma(percorso, controlla_codice=controlla_codice, con_grafica=False)
    except ErroreCompilazione as e:
        raise ErroreApk(e.messaggio, codice=e.codice) from None
    finestre = bool(piano.e_progetto and piano.tipi_controlli)
    avvio = piano.avvio
    # gli avvisi di `leo compila` che riguardano solo l'.exe (PySide6) sul telefono non valgono
    avvisi = [a for a in piano.avvisi if "PySide6" not in a]
    if piano.e_progetto:
        from .progetto import carica_progetto

        progetto = carica_progetto(piano.cartella)
        radice = Path(piano.cartella).resolve()
        if finestre:
            # si parte dalla finestra iniziale: il file da "avviare" e' il suo codice (o progetto.toml)
            iniziale = progetto.finestra_iniziale or ""
            codice = progetto.percorso_codice(iniziale) if iniziale else None
            avvio = (Path(codice).resolve().relative_to(radice).as_posix()
                     if codice is not None and Path(codice).is_file() else "progetto.toml")
            avvisi.extend(_avvisi_finestre(piano.tipi_controlli))
        else:
            avvio = Path(progetto.percorso_principale).resolve().relative_to(radice).as_posix()
    file = []
    for p, rel in piano.file:
        if p.suffix.lower() in _ESTENSIONI_ESCLUSE or rel.startswith(("app_android/", "eseguibile/")):
            continue
        try:
            dim = p.stat().st_size
        except OSError:
            continue
        if dim > LIMITE_FILE:
            avvisi.append(f"`{rel}` è troppo grande ({dim // (1024 * 1024)} MB): non lo includo.")
            continue
        file.append((p, rel))
    if not any(rel == avvio for _p, rel in file):
        raise ErroreApk(f"Non trovo il file da avviare `{avvio}`.")
    # pacchetti di `leo aggiungi` (leo.lock): i pacchetti Leo sono già tra i file; dei pacchetti
    # Python vanno sul telefono solo quelli puri (il Python del telefono non può caricare librerie
    # native compilate per il PC)
    parti = getattr(piano, "dipendenze", None)
    python_esterno = False
    if parti is not None:
        file.extend(parti.python_puri)
        python_esterno = bool(parti.python_puri)
        if parti.non_puri:
            avvisi.append("Questi pacchetti Python contengono codice nativo e non funzioneranno sul telefono: "
                          + ", ".join(parti.non_puri) + ". Il programma partirà, ma `importa python` di quei "
                          "pacchetti darà errore.")
    if (piano.con_grafica and not finestre) or _usa_tartaruga(file):
        avvisi.append("Il programma usa la tartaruga: sul telefono il disegno viene salvato come immagine SVG "
                      "e non mostrato sullo schermo.")
    return ProgrammaApk(avvio=avvio, titolo=piano.titolo or piano.nome, file=file, avvisi=avvisi, finestre=finestre,
                        versione=str(getattr(piano, "versione", "") or ""),
                        autore=str(getattr(piano, "autore", "") or ""), python_esterno=python_esterno)


def _avvisi_finestre(tipi: Any) -> list[str]:
    """Avvisi per i controlli che sul telefono non si disegnano (restano riquadri) o non funzionano."""
    from .grafica.web.programma import TIPI_SUPPORTATI_WEB

    invisibili_ok = {"Timer", "Appunti", "Suggerimento", "Cifratura", "BancaDati", "RichiestaWeb",
                     "BarraMenu", "VoceMenu", "MenuContestuale", "Notifica"}
    mancanti = sorted(t for t in set(tipi) if t not in TIPI_SUPPORTATI_WEB and t not in invisibili_ok)
    if not mancanti:
        return []
    return ["Sul telefono questi controlli non ci sono ancora e compaiono come riquadri vuoti: "
            + ", ".join(f"`{t}`" for t in mancanti) + "."]


def _usa_tartaruga(file: Sequence[tuple[Path, str]]) -> bool:
    from .compila import _usa_tartaruga as usa

    for p, rel in file:
        if rel.lower().endswith((".leo", ".dante")):
            try:
                if usa(p.read_text(encoding="utf-8", errors="replace")):
                    return True
            except OSError:
                pass
    return False


# ===========================================================================
# Icona
# ===========================================================================

def _dimensioni_png(dati: bytes) -> tuple[int, int] | None:
    if dati[:8] != b"\x89PNG\r\n\x1a\n" or dati[12:16] != b"IHDR":
        return None
    return struct.unpack(">II", dati[16:24])


def _ridimensiona_png(dati: bytes, lato: int) -> bytes:
    """PNG quadrato ``lato`` x ``lato`` (con Pillow o PySide6 se ci sono, altrimenti invariato)."""
    import io

    try:
        from PIL import Image  # type: ignore[import-not-found]

        with Image.open(io.BytesIO(dati)) as im:
            im = im.convert("RGBA").resize((lato, lato), Image.LANCZOS)
            out = io.BytesIO()
            im.save(out, "PNG", optimize=True)
            return out.getvalue()
    except Exception:  # noqa: BLE001
        pass
    try:
        from PySide6.QtCore import QBuffer, QByteArray, QIODevice, Qt  # type: ignore[import-not-found]
        from PySide6.QtGui import QImage  # type: ignore[import-not-found]

        im = QImage.fromData(dati)
        if not im.isNull():
            im = im.scaled(lato, lato, Qt.AspectRatioMode.IgnoreAspectRatio, Qt.TransformationMode.SmoothTransformation)
            buffer = QByteArray()
            dispositivo = QBuffer(buffer)
            dispositivo.open(QIODevice.OpenModeFlag.WriteOnly)
            im.save(dispositivo, "PNG")
            return bytes(buffer.data())
    except Exception:  # noqa: BLE001
        pass
    return dati


# ===========================================================================
# Alleggerimento: l'app creata non porta con sé ciò che serve solo a Leo
# ===========================================================================
#
# Il guscio è l'app di Leo intera: editor, esempi, sito, disegnatore di finestre, "Crea app
# Android" e un Python completo. Un'app creata esegue un solo programma, quindi (se non si chiede
# l'app completa) si tolgono le parti che non può usare. Le regole sono prudenti: nel dubbio
# un file resta. Il formato di Chaquopy (``assets/chaquopy``):
#
# * ``build.json`` elenca ogni asset con il suo SHA-1: all'avvio Chaquopy estrae ``stdlib-common.imy``,
#   ``bootstrap.imy``, ``bootstrap-native/<abi>/`` e ``cacert.pem`` (devono esserci) e ricorda l'impronta
#   per non rifarlo; ``app.imy``, ``requirements-*.imy`` e ``stdlib-<abi>.imy`` li legge come ZIP
#   quando servono e, se l'impronta cambia, butta la cache estratta. Quindi ogni ``.imy`` rifatto
#   va con la sua impronta nuova in ``build.json``, e le voci tolte si tolgono anche da lì.
# * L'ABI di Python la sceglie il primo di ``Build.SUPPORTED_ABIS`` che ha ``stdlib-<abi>.imy``:
#   i file per le ABI tolte da ``lib/`` vanno tolti anche qui (altrimenti su un emulatore x86_64
#   che traduce ARM Chaquopy sceglierebbe x86_64 senza averne le librerie).

CARTELLA_CHAQUOPY = "assets/chaquopy/"
FILE_BUILD_JSON = CARTELLA_CHAQUOPY + "build.json"

#: Tutte le ABI di Android (per riconoscere i file di Chaquopy di un'architettura).
ABI_ANDROID = ("arm64-v8a", "armeabi-v7a", "armeabi", "x86", "x86_64", "riscv64", "mips", "mips64")

#: Cartelle di ``assets/`` che servono solo all'app di Leo (esempi, sito offline, guida, corso...).
ASSET_SOLO_LEO = ("esempi", "sito", "guida", "manuale", "corso", "lezioni", "tutorial", "video", "aiuto",
                  "galleria")   # la galleria intera: l'app creata ha solo i suoi elementi in programma/galleria/
#: Parti di ``assets/dati`` che un programma non usa mai (le lezioni sono del corso di Leo).
DATI_MAI_USATI = ("lezioni", "studio", "pico", "cursori", "leone", "caratteri", "proposte")
#: Parti di ``assets/dati`` usate solo dai programmi con finestre (stemma, comuni per i controlli Italia).
DATI_SOLO_FINESTRE = ("icone",)
#: File della pagina che servono solo all'editor (il disegnatore di finestre, i comandi pronti).
WEB_SOLO_EDITOR = ("disegna.js", "comandi.js", "galleria.js", "galleria.css", "icone_controlli.js")

#: Moduli di ``leo`` che servono solo all'editor e a "Crea app Android": in ``leo_android`` li
#: importano solo ``crea_apk``, ``copia_chiave``, ``formatta``, ``completa`` e il disegnatore, che
#: un'app creata non chiama mai. Si tolgono solo se nessun altro modulo rimasto li importa.
LEO_SOLO_EDITOR = (
    "leo.apk", "leo.compila", "leo.formattatore", "leo.correzioni", "leo.completamento", "leo.editor_telefono",
    "leo.grafica.web.disegnatore", "leo.grafica.web.modelli_app",
    "leo.lezioni", "leo.sfide", "leo.spiega", "leo.studio", "leo.cli", "leo.repl", "leo.__main__",
    "leo.firma", "leo.licenza",
)

#: Parti della libreria standard di Python che né Leo né il Python di Chaquopy importano, neanche
#: dentro le funzioni (analisi degli import su tutto ``leo``, ``leo_android`` e il bootstrap di
#: Chaquopy: vedi tests/test_apk.py). Strumenti di sviluppo (test, profilazione, 2to3,
#: distutils), protocolli di posta e formati audio vecchi. Restano i piccoli moduli utili
#: (argparse, zoneinfo, statistics, concurrent...).
STDLIB_NON_USATA = (
    "distutils", "lib2to3", "unittest", "asyncio", "doctest", "idlelib", "tkinter", "turtledemo",
    "ensurepip", "venv", "wsgiref", "_pyio", "mailbox", "optparse", "pickletools", "nntplib", "poplib",
    "smtpd", "telnetlib", "asyncore", "asynchat", "cgi", "cgitb", "pstats", "profile", "cProfile", "trace",
    "timeit", "modulefinder", "compileall", "pyclbr", "symtable", "tabnanny", "zipapp", "dbm", "shelve",
    "aifc", "sunau", "sndhdr", "imghdr", "chunk", "xdrlib", "uu", "pipes", "crypt", "mailcap", "filecmp",
    "fileinput", "sched", "pty", "netrc",
)
#: Moduli nativi (``stdlib-<abi>.imy``) di prova o di sistemi che il telefono non ha.
STDLIB_NATIVA_NON_USATA = ("_xxsubinterpreters", "_xxtestfuzz", "xxlimited", "xxlimited_35", "_lsprof", "ossaudiodev")
#: Codifiche cinesi, giapponesi e coreane (circa 400 KB per architettura): restano se il programma
#: nomina una di queste codifiche.
CODIFICHE_ASIATICHE = ("_codecs_cn", "_codecs_hk", "_codecs_iso2022", "_codecs_jp", "_codecs_kr", "_codecs_tw",
                       "_multibytecodec")
_RE_CODIFICHE_ASIATICHE = re.compile(
    r"big5|gb2312|gbk|gb18030|\bhz\b|shift.?jis|\bsjis|euc.?(jp|kr|cn|tw|jis)|iso.?2022|\bcp9(32|36|49|50)\b"
    r"|\bms9(32|36|49|50)\b|johab|\buhc\b|ks.?c.?5601|\bcp1361\b", re.IGNORECASE)
#: Il programma potrebbe usare i comuni italiani (``dati/italia``) anche senza finestre.
_RE_ITALIA = re.compile(r"comun|catast|italia|codice.?fiscale", re.IGNORECASE)


@dataclass
class Alleggerimento:
    """Che cosa è stato tolto dall'app creata: byte risparmiati (compressi) per parte."""

    parti: dict[str, int] = field(default_factory=dict)
    file_tolti: int = 0
    note: list[str] = field(default_factory=list)

    def conta(self, parte: str, byte: int, file: int = 1) -> None:
        if byte > 0 or file:
            self.parti[parte] = self.parti.get(parte, 0) + max(0, byte)
            self.file_tolti += file

    @property
    def risparmiati(self) -> int:
        return sum(self.parti.values())

    def testo(self) -> str:
        mb = f"{self.risparmiati / (1024 * 1024):.1f}".replace(".", ",")
        grandi = [p for p, b in sorted(self.parti.items(), key=lambda x: -x[1]) if b >= 1024]
        return f"{mb} MB in meno" + (f" ({', '.join(grandi)})" if grandi else "")


@dataclass
class _UsoProgramma:
    """Che cosa il programma potrebbe usare (analisi prudente del testo dei suoi file)."""

    finestre: bool = False
    italia: bool = False
    codifiche_asiatiche: bool = False
    python_esterno: bool = False                      # pacchetti Python di `leo aggiungi`

    @classmethod
    def da(cls, prog: "ProgrammaApk") -> "_UsoProgramma":
        uso = cls(finestre=bool(prog.finestre), python_esterno=bool(prog.python_esterno))
        for p, _rel in prog.file:
            try:
                if p.stat().st_size > 4 * 1024 * 1024:
                    continue                                   # immagini, suoni, archivi: non codice
                testo = p.read_bytes().decode("utf-8", "replace")
            except OSError:
                continue
            uso.italia = uso.italia or bool(_RE_ITALIA.search(testo))
            uso.codifiche_asiatiche = uso.codifiche_asiatiche or bool(_RE_CODIFICHE_ASIATICHE.search(testo))
        uso.italia = uso.italia or uso.finestre
        return uso


_RE_IMPORT = re.compile(r"(?<![\w.])(?:from[ \t]+([\w.]+)[ \t]+import[ \t]*(\([^)]*\)|[^\n;#]*)"
                        r"|import[ \t]+([^\n;#]*))")
_RE_IMPORT_PER_NOME = re.compile(r"(?:import_module|__import__)\(\s*[\"']([\w.]+)[\"']")


def _importati(sorgente: str, modulo: str, e_pacchetto: bool) -> set[str]:
    """Moduli importati da un sorgente Python (anche dentro le funzioni), con i nomi assoluti.

    Per ``from x import y`` ci sono sia ``x`` sia ``x.y`` (y può essere un modulo); anche
    ``import_module("nome")`` e ``__import__("nome")`` con un testo fisso. Si cercano le righe
    con ``import`` (anche nei commenti e nei testi: nel dubbio un modulo conta come importato),
    senza costruire l'albero del codice: sul telefono deve essere veloce. Se una riga non si
    capisce (spezzata con la barra rovesciata) il risultato contiene ``"?"``: chi chiama tiene tutto.
    """
    pacchetto = modulo if e_pacchetto else modulo.rpartition(".")[0]
    nomi: set[str] = set()
    righe = "\n".join(_righe_con_import(sorgente))
    for m in _RE_IMPORT.finditer(righe):
        da, elenco, semplice = m.group(1), m.group(2), m.group(3)
        testo = (elenco if da is not None else semplice or "").strip()
        if testo.endswith("\\"):
            nomi.add("?")
            continue
        voci = [v.strip().split()[0] for v in testo.strip("()").split(",") if v.strip()]
        if da is None:
            nomi.update(voci)
            continue
        punti = len(da) - len(da.lstrip("."))
        if punti:
            base = pacchetto.split(".") if pacchetto else []
            base = base[:max(0, len(base) - (punti - 1))]
            radice = ".".join(base + ([da.lstrip(".")] if da.lstrip(".") else []))
        else:
            radice = da
        nomi.add(radice)
        nomi.update(f"{radice}.{v}" for v in voci if v != "*")
    nomi.update(_RE_IMPORT_PER_NOME.findall(righe))
    return nomi


def _righe_con_import(sorgente: str) -> Iterable[str]:
    """Le righe che contengono ``import``, senza commenti, con le righe seguenti finché una parentesi
    resta aperta (``from x import (a,`` a capo ``b)``)."""
    pos = sorgente.find("import")
    while pos >= 0:
        inizio = sorgente.rfind("\n", 0, pos) + 1
        fine = sorgente.find("\n", pos)
        fine = len(sorgente) if fine < 0 else fine
        parti = [_senza_commento(sorgente[inizio:fine])]
        aperte = parti[0].count("(") - parti[0].count(")")
        while aperte > 0 and fine < len(sorgente):
            seguente = sorgente.find("\n", fine + 1)
            seguente = len(sorgente) if seguente < 0 else seguente
            riga = _senza_commento(sorgente[fine + 1:seguente])
            parti.append(riga)
            aperte += riga.count("(") - riga.count(")")
            fine = seguente
        yield "\n".join(parti)
        pos = sorgente.find("import", fine)


def _senza_commento(riga: str) -> str:
    """La riga senza il commento finale (solo se prima del ``#`` non ci sono virgolette: nel dubbio intera)."""
    cancelletto = riga.find("#")
    if cancelletto < 0 or "'" in riga[:cancelletto] or '"' in riga[:cancelletto]:
        return riga
    return riga[:cancelletto]


def _modulo_del_file(nome: str) -> tuple[str, bool] | None:
    """``leo/grafica/colori.py`` -> (``leo.grafica.colori``, False); ``leo/__init__.py`` -> (``leo``, True)."""
    if not nome.endswith(".py"):
        return None
    parti = nome[:-3].split("/")
    if parti[-1] == "__init__":
        return ".".join(parti[:-1]), True
    return ".".join(parti), False


def _del_candidato(nome: str, candidati: Iterable[str]) -> str | None:
    for c in candidati:
        if nome == c or nome.startswith(c + "."):
            return c
    return None


def moduli_leo_da_togliere(sorgenti: dict[str, str], candidati: Sequence[str] = LEO_SOLO_EDITOR,
                           ignora_importatori: Iterable[str] = ("leo_android",)) -> set[str]:
    """Quali ``candidati`` (``leo.apk``...) si possono togliere da ``sorgenti`` ({nome file: testo}).

    Un candidato resta se un modulo che resta lo importa (anche dentro una funzione) o ne scrive il
    nome in un testo (``"leo.compila"``, ``'formattatore'``: potrebbe importarlo per nome). Si
    ripete finché serve: un candidato che resta tiene quelli che importa. ``ignora_importatori``:
    moduli i cui import dei candidati non contano (``leo_android`` li importa solo nelle funzioni
    dell'editor).
    """
    ignorati = set(ignora_importatori)
    moduli: dict[str, tuple[str, bool]] = {}
    for nome, testo in sorgenti.items():
        info = _modulo_del_file(nome)
        if info is not None:
            moduli[info[0]] = (testo, info[1])
    presenti = {c for c in candidati if any(_del_candidato(m, [c]) for m in moduli)}
    tenuti: set[str] = set()
    cambiato = True
    importati_di: dict[str, set[str]] = {}
    while cambiato:
        cambiato = False
        da_togliere = presenti - tenuti
        parole = {c.rpartition(".")[2] for c in da_togliere}
        if not parole:
            break
        for modulo, (testo, e_pacchetto) in moduli.items():
            if modulo in ignorati or _del_candidato(modulo, da_togliere):
                continue
            if not any(p in testo for p in parole):
                continue
            if modulo not in importati_di:
                importati_di[modulo] = _importati(testo, modulo, e_pacchetto)
            importati = importati_di[modulo]
            for c in list(da_togliere):
                ultimo = c.rpartition(".")[2]
                if ultimo not in testo:
                    continue
                # nominato per intero ("leo.compila", ".compila"): potrebbe essere importato per nome
                nominato = any(f"{a}{c}{q}" in testo or f"{a}.{ultimo}{q}" in testo for a in "\"'" for q in "\"'")
                if "?" in importati or nominato or any(_del_candidato(i, [c]) for i in importati):
                    tenuti.add(c)
                    cambiato = True
            da_togliere = presenti - tenuti
    return presenti - tenuti


def _filtra_zip(dati: bytes, togli: Callable[[str], bool]) -> tuple[bytes, int]:
    """Lo ZIP ``dati`` senza le voci per cui ``togli(nome)`` è vero, copiando i byte compressi così come
    sono (niente ricompressione). Restituisce (nuovo ZIP, voci tolte); se non toglie nulla, ``dati``."""
    import io

    with zipfile.ZipFile(io.BytesIO(dati)) as z:
        voci = z.infolist()
        tenute = [v for v in voci if not togli(v.filename)]
        if len(tenute) == len(voci):
            return dati, 0
        uscita = io.BytesIO()
        centrale = bytearray()
        for v in tenute:
            if v.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED) or v.flag_bits & 0x1:
                raise ErroreApk(f"Voce ZIP non gestita: {v.filename}")
            testa = dati[v.header_offset:v.header_offset + 30]
            if testa[:4] != b"PK\x03\x04":
                raise ErroreApk(f"Voce ZIP rovinata: {v.filename}")
            n_nome, n_extra = struct.unpack_from("<HH", testa, 26)
            inizio = v.header_offset + 30 + n_nome + n_extra
            compressi = dati[inizio:inizio + v.compress_size]
            nome_b = v.filename.encode("utf-8")
            flag = v.flag_bits & 0x0800
            ora = (v.date_time[3] << 11) | (v.date_time[4] << 5) | (v.date_time[5] // 2)
            data = ((v.date_time[0] - 1980) << 9) | (v.date_time[1] << 5) | v.date_time[2]
            offset = uscita.tell()
            versione = 20 if v.compress_type == zipfile.ZIP_DEFLATED else 10
            uscita.write(struct.pack("<IHHHHHIIIHH", 0x04034B50, versione, flag, v.compress_type, ora, data,
                                     v.CRC, v.compress_size, v.file_size, len(nome_b), 0) + nome_b)
            uscita.write(compressi)
            centrale += struct.pack("<IHHHHHHIIIHHHHHII", 0x02014B50, versione, versione, flag, v.compress_type,
                                    ora, data, v.CRC, v.compress_size, v.file_size, len(nome_b), 0, 0, 0, 0,
                                    v.external_attr, offset) + nome_b
        inizio_centrale = uscita.tell()
        uscita.write(bytes(centrale))
        uscita.write(struct.pack("<IHHHHIIH", 0x06054B50, 0, 0, len(tenute), len(tenute), len(centrale),
                                 inizio_centrale, 0))
    nuovo = uscita.getvalue()
    with zipfile.ZipFile(io.BytesIO(nuovo)) as prova:                # controllo: si rilegge uguale
        if prova.namelist() != [v.filename for v in tenute]:
            raise ErroreApk("ZIP alleggerito non valido.")
    return nuovo, len(voci) - len(tenute)


def _nome_in_zip_python(nome: str) -> str:
    """``asyncio/tasks.pyc`` -> ``asyncio``; ``_codecs_cn.so`` -> ``_codecs_cn`` (nome di primo livello)."""
    primo = nome.split("/", 1)[0]
    for suffisso in (".pyc", ".py", ".so"):
        if primo.endswith(suffisso):
            return primo[:-len(suffisso)].split(".", 1)[0]
    return primo


@dataclass
class _PianoLeggero:
    """Che cosa togliere o rifare nella copia del guscio (calcolato da :func:`_prepara_alleggerimento`)."""

    togli: dict[str, str] = field(default_factory=dict)          # voce -> parte (per il rapporto)
    rifatte: dict[str, bytes] = field(default_factory=dict)      # voce -> nuovo contenuto
    parti_rifatte: dict[str, str] = field(default_factory=dict)  # voce rifatta -> parte
    rapporto: Alleggerimento = field(default_factory=Alleggerimento)


def _prepara_alleggerimento(z: zipfile.ZipFile, voci: Sequence[zipfile.ZipInfo], abi_tenute: Sequence[str],
                            uso: _UsoProgramma) -> _PianoLeggero:
    """Decide che cosa togliere dal guscio per un'app creata. Ogni passo che non riesce (formato
    inatteso) lascia le cose come sono: l'app viene solo meno leggera."""
    piano = _PianoLeggero()
    nomi = {v.filename: v for v in voci}

    # --- asset dell'app di Leo, dati non usati, pagina dell'editor -------------------------
    dati_via = set(DATI_MAI_USATI) | (set() if uso.finestre else set(DATI_SOLO_FINESTRE))
    if not uso.italia:
        dati_via.add("italia")
    indice = ""
    try:
        indice = z.read("assets/web/index.html").decode("utf-8", "replace")
    except KeyError:
        pass
    for n in nomi:
        parti = n.split("/")
        if len(parti) < 3 or parti[0] != "assets" or n.endswith("/"):
            continue
        if parti[1] in ASSET_SOLO_LEO:
            piano.togli[n] = parti[1]
        elif parti[1] == "dati" and parti[2] in dati_via and len(parti) > 3:
            piano.togli[n] = "dati"
        elif (parti[1] == "web" and len(parti) == 3 and parti[2] in WEB_SOLO_EDITOR
              and f'<script src="{parti[2]}"></script>' not in indice):
            # la pagina lo carica solo senza programma incluso (index.html): nell'app creata non serve
            piano.togli[n] = "editor"

    # --- Python (Chaquopy) -----------------------------------------------------------------
    try:
        build = json.loads(z.read(FILE_BUILD_JSON).decode("utf-8"))
        asset_py = build["assets"]
        if not isinstance(asset_py, dict):
            raise ValueError("assets")
    except (KeyError, ValueError, TypeError):
        piano.rapporto.note.append("Python non alleggerito: build.json di Chaquopy mancante o diverso dal solito.")
        return piano
    tolte_abi = [a for a in ABI_ANDROID if a not in set(abi_tenute)]
    modificato = False
    for chiave in list(asset_py):
        voce = CARTELLA_CHAQUOPY + chiave
        radice = chiave.split("/")[0]
        di_abi = next((a for a in tolte_abi if chiave.startswith(f"bootstrap-native/{a}/")
                       or radice.endswith(f"-{a}.imy")), None)
        if di_abi is None:
            continue
        del asset_py[chiave]
        modificato = True
        if voce in nomi:
            piano.togli[voce] = "architetture"

    def rifai(chiave: str, togli: Callable[[str], bool], parte: str) -> None:
        nonlocal modificato
        voce = CARTELLA_CHAQUOPY + chiave
        if chiave not in asset_py or voce not in nomi:
            return
        try:
            nuovo, quante = _filtra_zip(z.read(voce), togli)
        except (zipfile.BadZipFile, ErroreApk, struct.error, KeyError, ValueError, OSError):
            piano.rapporto.note.append(f"{chiave} non alleggerito (formato inatteso).")
            return
        if quante:
            piano.rifatte[voce] = nuovo
            piano.parti_rifatte[voce] = parte
            asset_py[chiave] = hashlib.sha1(nuovo).hexdigest()
            piano.rapporto.file_tolti += quante
            modificato = True

    # moduli di leo solo per l'editor (dentro app.imy, con gli altri file Python dell'app)
    sorgenti: dict[str, str] = {}
    if "app.imy" in asset_py and CARTELLA_CHAQUOPY + "app.imy" in nomi:
        import io

        try:
            with zipfile.ZipFile(io.BytesIO(z.read(CARTELLA_CHAQUOPY + "app.imy"))) as app:
                for info in app.infolist():
                    if info.filename.endswith(".py"):
                        sorgenti[info.filename] = app.read(info).decode("utf-8", "replace")
        except (zipfile.BadZipFile, KeyError, OSError, ValueError):
            sorgenti = {}
    if sorgenti:
        via_leo = moduli_leo_da_togliere(sorgenti)
        percorsi_via = tuple(m.replace(".", "/") for m in via_leo)

        def togli_leo(nome: str) -> bool:
            return any(nome == p + ".py" or nome.startswith(p + "/") for p in percorsi_via)
        if via_leo:
            rifai("app.imy", togli_leo, "Leo per l'editor")
            if CARTELLA_CHAQUOPY + "app.imy" in piano.rifatte:
                sorgenti = {n: t for n, t in sorgenti.items() if not togli_leo(n)}
    # libreria standard: le parti non usate, salvo quelle che un modulo rimasto importa per nome
    usati_std: set[str] = set()
    for nome, testo in sorgenti.items():
        info = _modulo_del_file(nome)
        if info is not None:
            usati_std.update(i.split(".")[0] for i in _importati(testo, info[0], info[1]))
    if "?" in usati_std or uso.python_esterno:
        # librerie Python aggiunte con `leo aggiungi`: possono usare qualunque parte della libreria standard
        usati_std = set(STDLIB_NON_USATA)
    via_std = set(STDLIB_NON_USATA) - usati_std
    rifai("stdlib-common.imy", lambda n: _nome_in_zip_python(n) in via_std, "Python non usato")
    via_nativi = set(STDLIB_NATIVA_NON_USATA) | (
        set() if uso.codifiche_asiatiche or uso.python_esterno else set(CODIFICHE_ASIATICHE))
    for abi in abi_tenute:
        rifai(f"stdlib-{abi}.imy", lambda n: "/" not in n and _nome_in_zip_python(n) in via_nativi,
              "Python non usato")
    if modificato:
        piano.rifatte[FILE_BUILD_JSON] = (json.dumps(build, indent=4) + "\n").encode("utf-8")
    return piano


# ===========================================================================
# Creazione dell'APK
# ===========================================================================

@dataclass
class RisultatoApk:
    percorso: Path
    pacchetto: str
    nome: str
    dimensione: int
    versione: str
    codice_versione: int
    abi: list[str]
    chiave: Path | None
    chiave_nuova: bool
    certificato_sha256: str
    avvisi: list[str] = field(default_factory=list)
    #: che cosa è stato tolto dal guscio (None = app completa, senza alleggerimento)
    alleggerimento: Alleggerimento | None = None

    def testo(self) -> str:
        mb = self.dimensione / (1024 * 1024)
        righe = [
            "App Android pronta:",
            f"  File:        {self.percorso}",
            f"  Nome:        {self.nome}",
            f"  Pacchetto:   {self.pacchetto}",
            f"  Versione:    {self.versione} (codice {self.codice_versione})",
            f"  Dimensione:  {mb:.1f} MB".replace(".", ","),
            f"  Telefoni:    {', '.join(self.abi)}",
        ]
        if self.alleggerimento is not None and self.alleggerimento.risparmiati:
            righe.append(f"  Alleggerita: {self.alleggerimento.testo()}")
        if self.chiave is not None:
            righe.append(f"  Firmata con: {self.chiave}")
        if self.chiave_nuova:
            righe.append("  ATTENZIONE: ho creato una chiave di firma nuova. Conservane una copia: senza, "
                         "le app già installate non si potranno aggiornare.")
        return "\n".join(righe)


def crea_apk(programma: str | os.PathLike, *, guscio: str | os.PathLike | None = None,
             uscita: str | os.PathLike | None = None, nome: str | None = None,
             pacchetto: str | None = None, versione: str | None = None,
             codice_versione: int | None = None, icona: str | os.PathLike | None = None,
             chiave: str | os.PathLike | ChiaveFirma | None = None,
             abi: Sequence[str] | None = ABI_TELEFONI, controlla_codice: bool = True,
             avvisa: Callable[[str], Any] = print, aspetto: dict[str, Any] | None = None,
             icona_primo_piano: str | os.PathLike | None = None, leggera: bool = True) -> RisultatoApk:
    """Crea l'APK di un programma ``.leo`` (o di un progetto testuale) e lo restituisce.

    ``guscio``: APK di Leo (None = :func:`trova_guscio`). ``uscita``: file ``.apk`` o
    cartella (predefinita: ``app_android`` accanto al programma). ``nome``: nome dell'app
    (predefinito: quello del progetto o del file). ``pacchetto``: identificativo Android
    (predefinito: ``it.leo.app.<nome>``). ``versione``: ``"1.2"`` (predefinita: quella del
    progetto o ``1.0``); ``codice_versione`` si ricava dalla versione se manca.
    ``icona``: PNG (idealmente quadrato, 512x512). ``chiave``: file di chiave o
    :class:`ChiaveFirma` (None = quella nelle impostazioni di Leo, creata la prima volta).
    ``abi``: architetture da tenere (None = tutte quelle del guscio).
    ``aspetto``: grafica dell'app, ``{"colore": "#D7132A", "tema": "scuro"|"chiaro"}`` (va in
    ``avvio.json``; la applica l'interfaccia). ``icona_primo_piano``: PNG per l'icona adattiva
    (Android 8+), con l'immagine già rimpicciolita al centro; se manca si ricava da ``icona``.
    ``leggera``: toglie dal guscio ciò che l'app non usa (esempi, sito, editor, Python non usato,
    file delle architetture tolte: vedi ``_prepara_alleggerimento``); False = copia tutto il guscio
    (``leo compila --apk --app-completa``), da usare se l'app alleggerita non funzionasse.
    """
    aspetto = normalizza_aspetto(aspetto)
    if pacchetto:
        pacchetto = controlla_pacchetto(pacchetto)
    percorso_guscio = trova_guscio(guscio, abi=abi)
    info = informazioni_guscio(percorso_guscio)
    avvisa(f"Controllo il programma `{Path(programma).name}`...")
    prog = raccogli_programma(programma, controlla_codice=controlla_codice)
    for a in prog.avvisi:
        avvisa("Attenzione: " + a)

    nome_app = (nome or prog.titolo or "Programma").strip()[:50] or "Programma"
    pacchetto = pacchetto or pacchetto_da_nome(nome_app)
    versione = (versione or prog.versione or "1.0").strip()
    if codice_versione is None:
        codice_versione = codice_da_versione(versione)
    if not 1 <= int(codice_versione) <= 2_100_000_000:
        raise ErroreApk("Il codice di versione deve essere tra 1 e 2100000000.", codice=2)

    abi_guscio = list(info["abi"])
    if abi is None:
        abi_tenute = abi_guscio
    else:
        abi_tenute = [a for a in abi_guscio if a in set(abi)]
        if not abi_tenute:
            raise ErroreApk(f"Il guscio non ha le architetture richieste ({', '.join(abi)}); "
                            f"ha: {', '.join(abi_guscio) or 'nessuna'}.", codice=2)
    attese = list(abi) if abi is not None else [*ABI_TELEFONI, "x86_64"]
    mancanti = [a for a in attese if a not in abi_guscio]
    # Senza avviso se il guscio ha tutti i processori dei telefoni veri (il Leo "telefono",
    # arm64 + arm32, sul telefono o sul PC): l'app creata va su qualunque telefono.
    mancano_telefoni = [a for a in mancanti if a in ABI_TELEFONI]
    avviso = ""
    if mancano_telefoni:
        # guscio per un solo processore (per esempio un vecchio APK di Leo fatto per arm64)
        quali = f"{'il processore' if len(abi_tenute) == 1 else 'i processori'} {', '.join(abi_tenute)}"
        if _su_android():
            avviso = (f"l'app creata funziona solo sui telefoni con {quali}, come questo: il Leo installato qui "
                      f"è fatto per un solo tipo di processore (mancano {', '.join(mancanti)}). Per un'app che va "
                      "su tutti i telefoni installa Leo-<versione>.apk, che li ha tutti, oppure creala dal PC "
                      "con `leo compila --apk`.")
        else:
            avviso = (f"il guscio `{Path(percorso_guscio).name}` ha solo {', '.join(abi_tenute)}: l'app creata "
                      f"funzionerà solo sui dispositivi con {quali} (mancano {', '.join(mancanti)}). Per un'app "
                      "che va su tutti i telefoni usa il guscio android/Leo-<versione>.apk "
                      "(lo costruisce costruisci_apk.bat).")
    elif mancanti and not _su_android():
        # guscio vecchio senza x86_64: va su tutti i telefoni, solo non sull'emulatore
        avviso = (f"l'app creata va su tutti i telefoni, ma non sull'emulatore del PC: il guscio "
                  f"`{Path(percorso_guscio).name}` non ha {', '.join(mancanti)}. Ricostruisci Leo con "
                  "android/costruisci_apk.bat: il nuovo Leo-<versione>.apk ha anche x86_64.")
    if avviso:
        prog.avvisi.append(avviso[0].upper() + avviso[1:])
        avvisa("Attenzione: " + avviso)

    icona_dati = None
    if icona is not None:
        try:
            icona_dati = Path(icona).read_bytes()
        except OSError as e:
            raise ErroreApk(f"Non riesco a leggere l'icona `{icona}`: {e.strerror or e}.", codice=2) from None
        if _dimensioni_png(icona_dati) is None:
            raise ErroreApk("L'icona dell'app deve essere un'immagine PNG.", codice=2)
    primo_piano_dati = None
    if icona_primo_piano is not None:
        try:
            primo_piano_dati = Path(icona_primo_piano).read_bytes()
        except OSError as e:
            raise ErroreApk(f"Non riesco a leggere l'icona `{icona_primo_piano}`: {e.strerror or e}.", codice=2) from None
        if _dimensioni_png(primo_piano_dati) is None:
            raise ErroreApk("L'icona dell'app deve essere un'immagine PNG.", codice=2)

    # uscita
    if uscita is None:
        base = Path(programma)
        base = base.parent if base.is_file() else base
        destinazione = base / "app_android" / f"{_nome_file(nome_app)}.apk"
    else:
        destinazione = Path(uscita)
        if destinazione.suffix.lower() != ".apk":
            destinazione = destinazione / f"{_nome_file(nome_app)}.apk"
    try:
        destinazione.parent.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise ErroreApk(f"Non riesco a creare la cartella `{destinazione.parent}`: {e.strerror or e}.") from None
    if destinazione.resolve() == Path(percorso_guscio).resolve():
        raise ErroreApk("L'app da creare non può sovrascrivere il guscio.", codice=2)

    # chiave
    percorso_chiave: Path | None = None
    chiave_nuova = False
    if isinstance(chiave, ChiaveFirma):
        chiave_firma = chiave
    elif chiave is not None:
        percorso_chiave = Path(chiave)
        if percorso_chiave.is_file():
            chiave_firma = carica_chiave(percorso_chiave)
        else:
            avvisa(f"La chiave `{percorso_chiave}` non esiste: la creo.")
            chiave_firma = genera_chiave(avvisa=avvisa)
            salva_chiave(chiave_firma, percorso_chiave)
            chiave_nuova = True
    else:
        chiave_firma, percorso_chiave, chiave_nuova = chiave_predefinita(avvisa)

    avvisa(f"Creo l'app `{nome_app}` ({pacchetto})...")
    avvio = {
        "formato": 1,
        "titolo": nome_app,
        "avvio": prog.avvio,
        "file": [rel for _p, rel in prog.file],
        "pacchetto": pacchetto,
        "versione": versione,
        "autore": prog.autore,
        "leo": info.get("leo", "?"),
        "creato": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "aspetto": aspetto,
        "finestre": bool(prog.finestre),
        "leggera": bool(leggera),
    }
    if icona_dati is not None:
        # la schermata di caricamento dell'interfaccia mostra l'icona dell'app (non lo stemma di Leo)
        avvio["icona"] = FILE_ICONA[len(CARTELLA_PROGRAMMA):]
    temporaneo = destinazione.with_name(destinazione.name + ".tmp")
    scrittore = ScrittoreApk(temporaneo)
    try:
        alleggerimento = _copia_guscio(percorso_guscio, scrittore, nome_app=nome_app, pacchetto=pacchetto,
                                       versione=versione, codice_versione=int(codice_versione),
                                       abi_tenute=abi_tenute, icona=icona_dati, avvisa=avvisa,
                                       icona_primo_piano=primo_piano_dati,
                                       uso=_UsoProgramma.da(prog) if leggera else None)
        if alleggerimento is not None and alleggerimento.risparmiati:
            avvisa(f"App alleggerita: {alleggerimento.testo()}.")
        for p, rel in prog.file:
            scrittore.aggiungi(CARTELLA_PROGRAMMA + "file/" + rel, p.read_bytes())
        if icona_dati is not None:
            scrittore.aggiungi(FILE_ICONA, _ridimensiona_png(icona_dati, LATO_ICONA_AVVIO), comprimi=False)
        scrittore.aggiungi(FILE_AVVIO, json.dumps(avvio, ensure_ascii=False, indent=1).encode("utf-8"))
        avvisa("Firmo l'app...")
        scrittore.chiudi_firmando(chiave_firma)
        esito = verifica_apk(temporaneo)
        os.replace(temporaneo, destinazione)
    except BaseException:
        scrittore.annulla()
        raise
    risultato = RisultatoApk(percorso=destinazione, pacchetto=pacchetto, nome=nome_app,
                             dimensione=destinazione.stat().st_size, versione=versione,
                             codice_versione=int(codice_versione), abi=abi_tenute, chiave=percorso_chiave,
                             chiave_nuova=chiave_nuova, certificato_sha256=esito["certificato_sha256"],
                             avvisi=prog.avvisi, alleggerimento=alleggerimento)
    return risultato


def _su_android() -> bool:
    try:
        from .piattaforma import e_android

        return bool(e_android())
    except Exception:  # noqa: BLE001
        return False


def _nome_file(nome: str) -> str:
    n = re.sub(r'[<>:"/\\|?*\x00-\x1f]+', "_", nome).strip(" .") or "Programma"
    return n[:80]


def _copia_guscio(percorso: Path, scrittore: ScrittoreApk, *, nome_app: str, pacchetto: str, versione: str,
                  codice_versione: int, abi_tenute: Sequence[str], icona: bytes | None,
                  avvisa: Callable[[str], Any], icona_primo_piano: bytes | None = None,
                  uso: _UsoProgramma | None = None) -> Alleggerimento | None:
    """Copia il guscio nello ``scrittore``; con ``uso`` (analisi del programma) lo alleggerisce
    e restituisce che cosa ha tolto."""
    z, voci = _voci_grezze(percorso)
    with z, open(percorso, "rb") as f:
        leggero = _prepara_alleggerimento(z, voci, abi_tenute, uso) if uso is not None else None
        manifest = ManifestBinario(z.read("AndroidManifest.xml"))
        icone: dict[str, bytes] = {}
        if icona is not None:
            icone = _icone_da_sostituire(z, manifest, icona, avvisa, icona_primo_piano)
        manifest.imposta_pacchetto(pacchetto)
        manifest.imposta_etichetta(nome_app)
        manifest.imposta_versione(codice_versione, versione)
        # l'app creata non installa altre app: il permesso serve solo a Leo
        manifest.togli_permesso("android.permission.REQUEST_INSTALL_PACKAGES")
        # INTERNET serve solo alla Galleria di Leo (elementi extra): l'app creata ha gia' i suoi elementi
        manifest.togli_permesso("android.permission.INTERNET")
        tenute = set(abi_tenute)
        for info in voci:
            n = info.filename
            if n.endswith("/") or n.startswith(CARTELLA_PROGRAMMA):
                continue
            if n.startswith("META-INF/") and (n.upper().endswith((".SF", ".RSA", ".DSA", ".EC"))
                                              or n.upper() == "META-INF/MANIFEST.MF"):
                continue                                             # vecchie firme JAR
            if n.startswith("lib/") and n.count("/") >= 2 and n.split("/")[1] not in tenute:
                continue
            if leggero is not None and _copia_leggera(n, info, leggero, scrittore):
                continue
            if n == "AndroidManifest.xml":
                scrittore.aggiungi(n, manifest.in_bytes())
                continue
            if n in icone:
                scrittore.aggiungi(n, icone[n], comprimi=False)
                continue
            if info.compress_type not in (zipfile.ZIP_STORED, zipfile.ZIP_DEFLATED):
                raise ErroreApk(f"Voce del guscio con compressione non gestita: {n}")
            scrittore.aggiungi_grezza(n, info.compress_type, info.CRC, _dati_compressi(f, info), info.file_size)
    return leggero.rapporto if leggero is not None else None


def _copia_leggera(nome: str, info: zipfile.ZipInfo, piano: _PianoLeggero, scrittore: ScrittoreApk) -> bool:
    """Voce tolta o rifatta dall'alleggerimento (vero = già gestita)."""
    if nome in piano.togli:
        piano.rapporto.conta(piano.togli[nome], info.compress_size)
        return True
    if nome in piano.rifatte:
        prima = len(scrittore.voci)
        # gli .imy restano non compressi (Chaquopy li legge come ZIP direttamente dall'APK)
        scrittore.aggiungi(nome, piano.rifatte[nome], comprimi=info.compress_type == zipfile.ZIP_DEFLATED)
        dopo = scrittore.voci[prima].compressa
        if nome in piano.parti_rifatte:
            piano.rapporto.conta(piano.parti_rifatte[nome], info.compress_size - dopo, file=0)
        return True
    return False


#: android:drawable (in <foreground> e <background> di un'icona adattiva).
ATTR_DISEGNO = 0x01010199
#: Parte del lato occupata dall'immagine nel primo piano di un'icona adattiva (zona sicura).
QUOTA_PRIMO_PIANO = 0.60

COLORI_ASPETTO = ("#D7132A", "#0A84FF", "#30A46C", "#F5A524", "#8E4EC6", "#E54D9A", "#1D1D1F")


def normalizza_aspetto(aspetto: dict[str, Any] | None) -> dict[str, str]:
    """``{"colore": "#RRGGBB", "tema": "scuro"|"chiaro"}`` con valori validi (predefiniti di Leo)."""
    a = aspetto if isinstance(aspetto, dict) else {}
    colore = str(a.get("colore") or "#D7132A").strip()
    if not re.fullmatch(r"#[0-9A-Fa-f]{6}", colore):
        raise ErroreApk(f"`{colore}` non è un colore valido: usa il formato #RRGGBB (esempio #D7132A).", codice=2)
    tema = str(a.get("tema") or "scuro").strip().lower()
    if tema not in ("scuro", "chiaro"):
        raise ErroreApk(f"Tema `{tema}` sconosciuto: usa `scuro` oppure `chiaro`.", codice=2)
    return {"colore": colore.upper(), "tema": tema}


def _primo_piano_png(dati: bytes, lato: int) -> bytes:
    """Icona al centro di un quadrato trasparente (zona sicura dell'icona adattiva)."""
    import io

    interno = max(1, round(lato * QUOTA_PRIMO_PIANO))
    try:
        from PIL import Image  # type: ignore[import-not-found]

        with Image.open(io.BytesIO(dati)) as im:
            logo = im.convert("RGBA").resize((interno, interno), Image.LANCZOS)
            tela = Image.new("RGBA", (lato, lato), (0, 0, 0, 0))
            tela.alpha_composite(logo, ((lato - interno) // 2, (lato - interno) // 2))
            out = io.BytesIO()
            tela.save(out, "PNG", optimize=True)
            return out.getvalue()
    except Exception:  # noqa: BLE001
        pass
    try:
        from PySide6.QtCore import QBuffer, QByteArray, QIODevice, Qt  # type: ignore[import-not-found]
        from PySide6.QtGui import QImage, QPainter  # type: ignore[import-not-found]

        im = QImage.fromData(dati)
        if not im.isNull():
            logo = im.scaled(interno, interno, Qt.AspectRatioMode.IgnoreAspectRatio,
                             Qt.TransformationMode.SmoothTransformation)
            tela = QImage(lato, lato, QImage.Format.Format_ARGB32)
            tela.fill(Qt.GlobalColor.transparent)
            pittore = QPainter(tela)
            pittore.drawImage((lato - interno) // 2, (lato - interno) // 2, logo)
            pittore.end()
            buffer = QByteArray()
            dispositivo = QBuffer(buffer)
            dispositivo.open(QIODevice.OpenModeFlag.WriteOnly)
            tela.save(dispositivo, "PNG")
            return bytes(buffer.data())
    except Exception:  # noqa: BLE001
        pass
    return dati          # niente Pillow ne' Qt: l'immagine intera (il bordo puo' essere tagliato)


def _primo_piano_adattivo(z: zipfile.ZipFile, arsc: bytes, nome_xml: str) -> list[str]:
    """PNG del primo piano di un'icona adattiva (``res/xx.xml`` compilato)."""
    try:
        xml = ManifestBinario(z.read(nome_xml))
    except (KeyError, ErroreApk, struct.error):
        return []
    for el in xml.elementi("foreground"):
        a = xml.attributo(el, id_risorsa=ATTR_DISEGNO)
        if a is not None and a.tipo == TIPO_RIFERIMENTO:
            return [f for f in file_della_risorsa(arsc, a.valore) if f.lower().endswith(".png")]
    return []


def _icone_da_sostituire(z: zipfile.ZipFile, manifest: ManifestBinario, icona: bytes,
                         avvisa: Callable[[str], Any], primo_piano: bytes | None = None) -> dict[str, bytes]:
    """Nuovi PNG per l'icona: quelle classiche (Android 7) e il primo piano di quella adattiva."""
    risultato: dict[str, bytes] = {}
    arsc = z.read("resources.arsc")
    for attr in (ATTR_ICONA, ATTR_ICONA_TONDA):
        a = manifest.attributo(manifest.applicazione, id_risorsa=attr)
        if a is None or a.tipo != TIPO_RIFERIMENTO:
            continue
        for nome_file in file_della_risorsa(arsc, a.valore):
            if nome_file.lower().endswith(".xml"):                 # icona adattiva
                for png in _primo_piano_adattivo(z, arsc, nome_file):
                    dim = _dimensioni_png(z.read(png))
                    if primo_piano is not None:
                        risultato[png] = _ridimensiona_png(primo_piano, dim[0]) if dim else primo_piano
                    else:
                        risultato[png] = _primo_piano_png(icona, dim[0]) if dim else icona
                continue
            if not nome_file.lower().endswith(".png"):
                continue
            try:
                vecchia = z.read(nome_file)
            except KeyError:
                continue
            dim = _dimensioni_png(vecchia)
            risultato[nome_file] = _ridimensiona_png(icona, dim[0]) if dim else icona
    if not risultato:
        avvisa("Attenzione: non ho trovato l'icona nel guscio: l'app avrà l'icona di Leo.")
    return risultato
