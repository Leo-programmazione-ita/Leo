"""Firma digitale: eseguibili di Leo su Windows (Authenticode) e sorgenti/progetti Leo (Ed25519).

Sorgenti e progetti (ogni sistema, anche il telefono per la verifica): il lavoro vero
lo fa :mod:`leo.firma_codice` (che resta negli eseguibili e nell'app, mentre questo
modulo no); qui ci sono le stesse funzioni con nomi comodi e la riga di comando::

    firma_sorgente(percorso, autore=None) -> EsitoFirma      # riga "#firma-leo:" in fondo al .leo
    verifica_sorgente(percorso) -> EsitoFirma | None
    firma_progetto(cartella, autore=None) -> EsitoFirma      # file progetto.firma
    verifica_progetto(cartella) -> EsitoFirma | None

    python -m leo.firma --sorgente programma.leo [--verifica]   (oppure: leo firma ...)

Eseguibili (solo Windows)::

    firma_eseguibile(percorso, certificato=None, password=None,
                     marca_temporale="http://timestamp.digicert.com") -> (bool, messaggio)
    crea_certificato_personale(nome="Rosario Zappalà") -> (bool, messaggio)
    verifica_firma(percorso) -> (bool, messaggio)
    configurazione_firma() -> dict            # da LEO_CERTIFICATO / firma.toml
    trova_signtool() -> str | None

Come si firma
-------------
* Con ``signtool.exe`` (Windows SDK) se c'e': e' lo strumento ufficiale.
* Altrimenti con PowerShell ``Set-AuthenticodeSignature`` (c'e' in ogni Windows).

``certificato`` puo' essere:

* il percorso di un file ``.pfx`` (con ``password`` se protetto);
* l'impronta (thumbprint, 40 cifre esadecimali) di un certificato gia' presente
  nell'archivio dell'utente (``Cert:\\CurrentUser\\My``);
* ``None`` oppure ``"archivio"``: il certificato di firma codice piu' recente e
  ancora valido dell'archivio dell'utente.

Se il server della marca temporale non risponde (niente Internet) si riprova
una volta senza marca temporale, avvisando: la firma resta valida solo fino alla
scadenza del certificato.

Su Linux e macOS non si firma nulla: le funzioni restituiscono ``(False, spiegazione)``.

Certificato personale e avviso "App non riconosciuta"
-------------------------------------------------------
:func:`crea_certificato_personale` crea un certificato *auto-firmato*: vale solo sui
PC dove e' stato dichiarato attendibile (il tuo). Per togliere a tutti l'avviso di
SmartScreen serve un certificato di firma codice rilasciato da un'autorita' di
certificazione (a pagamento) oppure Microsoft Trusted Signing: vedi
``docs/DISTRIBUZIONE.md``.

Solo libreria standard. Tutte le funzioni accettano (per parola chiave) ``esegui``,
``sistema`` e altri punti di aggancio usati dai test al posto dei comandi veri.
"""

from __future__ import annotations

import base64
import glob
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence

#: Server della marca temporale predefinito (gratuito, RFC 3161).
MARCA_TEMPORALE_PREDEFINITA = "http://timestamp.digicert.com"

#: Valore di ``certificato`` che significa "cerca nell'archivio dell'utente".
ARCHIVIO = "archivio"

#: Nome del file di configurazione facoltativo (in ``strumenti/distribuzione``
#: oppure in ``%APPDATA%\\Leo``).
FILE_CONFIGURAZIONE = "firma.toml"

#: Variabili d'ambiente lette da :func:`configurazione_firma`.
VARIABILE_CERTIFICATO = "LEO_CERTIFICATO"
VARIABILE_PASSWORD = "LEO_CERTIFICATO_PASSWORD"
VARIABILE_MARCA = "LEO_MARCA_TEMPORALE"
VARIABILE_SIGNTOOL = "LEO_SIGNTOOL"

#: Variabile con cui la password passa a PowerShell (mai sulla riga di comando).
_VARIABILE_PASSWORD_FIGLIO = "LEO_FIRMA_PASSWORD_INTERNA"

TIMEOUT_FIRMA = 300
TIMEOUT_CERTIFICATO = 300

_IMPRONTA = re.compile(r"^[0-9A-Fa-f]{40}$")

#: (codice di uscita, testo) di un comando eseguito.
Esito = tuple[int, str]
Esecutore = Callable[..., Esito]


# ---------------------------------------------------------------------------
# Servizi
# ---------------------------------------------------------------------------

def _esegui_vero(comando: Sequence[str], *, ambiente: Mapping[str, str] | None = None,
                 timeout: int = TIMEOUT_FIRMA) -> Esito:
    """Esegue ``comando`` e restituisce (codice, stdout+stderr). Mai eccezioni."""
    opzioni: dict[str, Any] = {}
    if os.name == "nt":
        opzioni["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)
    try:
        # stdin=DEVNULL: senza, powershell.exe lanciato da una console aspetta l'ingresso
        # e la firma restava ferma fino al limite di tempo (5 minuti per file)
        esito = subprocess.run(list(comando), capture_output=True, stdin=subprocess.DEVNULL,
                               timeout=timeout, check=False,
                               env=dict(ambiente) if ambiente is not None else None, **opzioni)
    except FileNotFoundError:
        return 127, f"Programma non trovato: {comando[0]}"
    except subprocess.TimeoutExpired:
        return 124, f"Il comando non ha finito entro {timeout} secondi."
    except OSError as e:
        return 126, f"Non riesco ad avviare {comando[0]}: {e}"
    testo = _decodifica(esito.stdout) + _decodifica(esito.stderr)
    return esito.returncode, testo


def _decodifica(dati: bytes | str | None) -> str:
    if dati is None:
        return ""
    if isinstance(dati, str):
        return dati
    for codifica in ("utf-8", "cp850", "cp1252"):
        try:
            return dati.decode(codifica)
        except UnicodeDecodeError:
            continue
    return dati.decode("latin-1", errors="replace")


def testo_ps(testo: str) -> str:
    """Testo PowerShell tra apici singoli (l'apice si raddoppia)."""
    return "'" + str(testo).replace("'", "''") + "'"


def comando_powershell(script: str) -> list[str]:
    """Riga di comando che esegue ``script`` (codificato: niente problemi di virgolette)."""
    codificato = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
    return ["powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
            "-EncodedCommand", codificato]


def _nasconde(testo: str, segreto: str | None) -> str:
    """Toglie la password dai messaggi (non deve finire nei registri)."""
    if segreto:
        testo = testo.replace(segreto, "********")
    return testo


def _ultime_righe(testo: str, quante: int = 8) -> str:
    righe = [r.rstrip() for r in str(testo).splitlines() if r.strip()]
    return "\n".join(righe[-quante:])


# ---------------------------------------------------------------------------
# Configurazione
# ---------------------------------------------------------------------------

def _file_configurazione_predefiniti() -> list[Path]:
    radice = Path(__file__).resolve().parent.parent
    candidati = [radice / "strumenti" / "distribuzione" / FILE_CONFIGURAZIONE]
    if os.environ.get("APPDATA"):
        candidati.append(Path(os.environ["APPDATA"]) / "Leo" / FILE_CONFIGURAZIONE)
    return candidati


def configurazione_firma(ambiente: Mapping[str, str] | None = None,
                         file: Sequence[str | os.PathLike] | None = None) -> dict[str, Any]:
    """Certificato, password e marca temporale da usare.

    Ordine: variabili d'ambiente (``LEO_CERTIFICATO``, ``LEO_CERTIFICATO_PASSWORD``,
    ``LEO_MARCA_TEMPORALE``), poi il primo ``firma.toml`` che esiste (chiavi
    ``certificato``, ``password``, ``marca_temporale``). Restituisce un dizionario con
    ``certificato`` (None = non configurato), ``password``, ``marca_temporale``,
    ``origine`` (da dove arriva) e ``configurato`` (bool).
    """
    ambiente = os.environ if ambiente is None else ambiente
    dati: dict[str, Any] = {"certificato": None, "password": None,
                            "marca_temporale": MARCA_TEMPORALE_PREDEFINITA, "origine": None}
    for percorso in (_file_configurazione_predefiniti() if file is None else [Path(f) for f in file]):
        try:
            if not Path(percorso).is_file():
                continue
            from .tomlutil import carica_toml
            letti = carica_toml(percorso)
        except Exception:  # noqa: BLE001 - un file rovinato non deve fermare la costruzione
            continue
        sezione = letti.get("firma", letti) if isinstance(letti, dict) else {}
        if not isinstance(sezione, dict):
            continue
        if sezione.get("certificato"):
            dati["certificato"] = str(sezione["certificato"])
            dati["origine"] = str(percorso)
        if sezione.get("password"):
            dati["password"] = str(sezione["password"])
        if sezione.get("marca_temporale") is not None:
            dati["marca_temporale"] = str(sezione["marca_temporale"])
        break
    if ambiente.get(VARIABILE_CERTIFICATO):
        dati["certificato"] = ambiente[VARIABILE_CERTIFICATO]
        dati["origine"] = VARIABILE_CERTIFICATO
    if ambiente.get(VARIABILE_PASSWORD):
        dati["password"] = ambiente[VARIABILE_PASSWORD]
    if ambiente.get(VARIABILE_MARCA) is not None:
        dati["marca_temporale"] = ambiente[VARIABILE_MARCA]
    dati["configurato"] = bool(dati["certificato"])
    return dati


def tipo_certificato(certificato: str | os.PathLike | None) -> str:
    """``"archivio"``, ``"impronta"`` oppure ``"pfx"``."""
    if certificato is None or str(certificato).strip().lower() in ("", ARCHIVIO, "store", "auto"):
        return "archivio"
    testo = str(certificato).strip().replace(" ", "")
    if _IMPRONTA.match(testo):
        return "impronta"
    return "pfx"


# ---------------------------------------------------------------------------
# signtool.exe
# ---------------------------------------------------------------------------

def _chiave_versione(percorso: str) -> tuple[int, ...]:
    trovato = re.search(r"(\d+)\.(\d+)\.(\d+)\.(\d+)", percorso)
    return tuple(int(n) for n in trovato.groups()) if trovato else (0,)


def trova_signtool(ambiente: Mapping[str, str] | None = None, *,
                   cerca: Callable[[str], str | None] = shutil.which,
                   elenca: Callable[[str], list[str]] = glob.glob,
                   esiste: Callable[[str], bool] = os.path.isfile) -> str | None:
    """Percorso di ``signtool.exe`` o None.

    Ordine: ``LEO_SIGNTOOL``, il PATH, poi le cartelle del Windows SDK
    (``Windows Kits\\10\\bin\\<versione>\\x64``, la versione piu' recente per prima).
    """
    ambiente = os.environ if ambiente is None else ambiente
    esplicito = ambiente.get(VARIABILE_SIGNTOOL)
    if esplicito and esiste(esplicito):
        return esplicito
    nel_path = cerca("signtool.exe") or cerca("signtool")
    if nel_path:
        return nel_path
    basi = []
    for variabile in ("ProgramFiles(x86)", "ProgramFiles"):
        if ambiente.get(variabile):
            basi.append(os.path.join(ambiente[variabile], "Windows Kits", "10"))
    for base in basi:
        candidati = []
        for architettura in ("x64", "x86", "arm64"):
            candidati += elenca(os.path.join(base, "bin", "10.*", architettura, "signtool.exe"))
        candidati.sort(key=_chiave_versione, reverse=True)
        candidati += elenca(os.path.join(base, "bin", "x64", "signtool.exe"))
        candidati += elenca(os.path.join(base, "App Certification Kit", "signtool.exe"))
        for c in candidati:
            if esiste(c):
                return c
    return None


def comando_signtool(signtool: str, percorso: str | os.PathLike, *, certificato: str | None = None,
                     password: str | None = None, marca_temporale: str | None = MARCA_TEMPORALE_PREDEFINITA,
                     descrizione: str | None = None) -> list[str]:
    """Riga di comando di ``signtool sign`` (SHA-256, marca temporale RFC 3161)."""
    comando = [signtool, "sign", "/fd", "SHA256"]
    tipo = tipo_certificato(certificato)
    if tipo == "pfx":
        comando += ["/f", str(certificato)]
        if password:
            comando += ["/p", password]
    elif tipo == "impronta":
        comando += ["/s", "My", "/sha1", str(certificato).strip().replace(" ", "").upper()]
    else:
        comando += ["/s", "My", "/a"]          # il migliore dell'archivio dell'utente
    if marca_temporale:
        comando += ["/tr", marca_temporale, "/td", "SHA256"]
    if descrizione:
        comando += ["/d", descrizione]
    comando.append(str(percorso))
    return comando


# ---------------------------------------------------------------------------
# PowerShell Set-AuthenticodeSignature
# ---------------------------------------------------------------------------

def script_firma_powershell(percorso: str | os.PathLike, *, certificato: str | None = None,
                            marca_temporale: str | None = MARCA_TEMPORALE_PREDEFINITA) -> str:
    """Script PowerShell che firma ``percorso``.

    La password del .pfx NON sta nello script: la legge dalla variabile d'ambiente
    interna passata solo al processo figlio. Ultima riga dell'uscita:
    ``ESITO=<stato>`` (``Valid``, ``UnknownError``...) oppure ``ERRORE=<testo>``.
    """
    tipo = tipo_certificato(certificato)
    righe = ["$ErrorActionPreference = 'Stop'", "try {"]
    if tipo == "pfx":
        righe += [
            f"    $pw = $env:{_VARIABILE_PASSWORD_FIGLIO}",
            "    if ($pw) { $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2("
            + testo_ps(str(certificato)) + ", $pw) }",
            "    else { $cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2("
            + testo_ps(str(certificato)) + ") }",
        ]
    elif tipo == "impronta":
        impronta = str(certificato).strip().replace(" ", "").upper()
        righe.append("    $cert = Get-ChildItem Cert:\\CurrentUser\\My -CodeSigningCert | "
                     f"Where-Object {{ $_.Thumbprint -eq {testo_ps(impronta)} }} | Select-Object -First 1")
    else:
        righe.append("    $cert = Get-ChildItem Cert:\\CurrentUser\\My -CodeSigningCert | "
                     "Where-Object { $_.HasPrivateKey -and $_.NotAfter -gt (Get-Date) } | "
                     "Sort-Object NotAfter -Descending | Select-Object -First 1")
    righe += [
        "    if (-not $cert) { Write-Output 'ERRORE=Nessun certificato di firma codice trovato.'; exit 3 }",
        "    $parametri = @{ FilePath = " + testo_ps(str(percorso)) + "; Certificate = $cert; HashAlgorithm = 'SHA256' }",
    ]
    if marca_temporale:
        righe.append(f"    $parametri['TimestampServer'] = {testo_ps(marca_temporale)}")
    righe += [
        "    $r = Set-AuthenticodeSignature @parametri",
        "    Write-Output ('CERTIFICATO=' + $cert.Subject + ' | ' + $cert.Thumbprint)",
        "    if ($r.SignerCertificate) { Write-Output ('ESITO=' + $r.Status) } "
        "else { Write-Output ('ERRORE=' + $r.StatusMessage); exit 2 }",
        "} catch {",
        "    Write-Output ('ERRORE=' + $_.Exception.Message); exit 1",
        "}",
    ]
    return "\r\n".join(righe) + "\r\n"


def _valore_riga(testo: str, chiave: str) -> str | None:
    valore = None
    for riga in str(testo).splitlines():
        riga = riga.strip()
        if riga.startswith(chiave + "="):
            valore = riga[len(chiave) + 1:].strip()
    return valore


def _interpreta_powershell(codice: int, testo: str) -> tuple[bool, str]:
    esito = _valore_riga(testo, "ESITO")
    errore = _valore_riga(testo, "ERRORE")
    if esito == "Valid":
        return True, "firmato (firma valida)"
    if esito:
        # La firma c'e', ma Windows non si fida del certificato (tipico di quello personale).
        return True, (f"firmato, ma Windows segnala lo stato '{esito}': il certificato non è "
                      "considerato attendibile su questo PC (normale per un certificato personale "
                      "non ancora dichiarato attendibile)")
    return False, errore or _ultime_righe(testo) or f"PowerShell ha restituito il codice {codice}"


# ---------------------------------------------------------------------------
# Firma
# ---------------------------------------------------------------------------

def _sembra_errore_marca(testo: str) -> bool:
    t = testo.lower()
    return any(p in t for p in ("timestamp", "marca temporale", "time stamp", "0x80072ee7",
                                "0x80072efd", "0x80190194", "remote server", "server remoto"))


def firma_eseguibile(percorso: str | os.PathLike, certificato: str | os.PathLike | None = None,
                     password: str | None = None,
                     marca_temporale: str | None = MARCA_TEMPORALE_PREDEFINITA, *,
                     descrizione: str | None = "Leo",
                     sistema: str | None = None,
                     esegui: Esecutore | None = None,
                     signtool: str | None | bool = None,
                     ambiente: Mapping[str, str] | None = None) -> tuple[bool, str]:
    """Firma ``percorso`` con Authenticode. Restituisce ``(riuscito, messaggio in italiano)``.

    ``signtool``: percorso di signtool.exe; None = cercalo; False = non usarlo
    (solo PowerShell). ``sistema``/``esegui``/``ambiente`` servono ai test.
    Non solleva eccezioni.
    """
    sistema = os.name if sistema is None else sistema
    if sistema != "nt":
        return False, ("La firma digitale degli eseguibili (Authenticode) si fa solo su Windows: "
                       "su questo sistema non ho firmato nulla.")
    p = Path(percorso)
    if not p.is_file():
        return False, f"Non trovo il file da firmare: {p}"
    certificato = None if certificato is None else str(certificato)
    if tipo_certificato(certificato) == "pfx" and not Path(certificato).is_file():
        return False, f"Non trovo il certificato {certificato} (serve un file .pfx)."
    esegui = esegui or _esegui_vero
    ambiente = dict(os.environ if ambiente is None else ambiente)

    def tentativo(marca: str | None) -> tuple[bool, str]:
        strumento = trova_signtool(ambiente) if signtool is None else (signtool or None)
        if strumento:
            comando = comando_signtool(strumento, p, certificato=certificato, password=password,
                                       marca_temporale=marca, descrizione=descrizione)
            codice, testo = esegui(comando, ambiente=ambiente, timeout=TIMEOUT_FIRMA)
            testo = _nasconde(testo, password)
            if codice == 0:
                return True, "firmato con signtool"
            return False, f"signtool non è riuscito (codice {codice}): {_ultime_righe(testo)}"
        figlio = dict(ambiente)
        if password:
            figlio[_VARIABILE_PASSWORD_FIGLIO] = password
        script = script_firma_powershell(p, certificato=certificato, marca_temporale=marca)
        codice, testo = esegui(comando_powershell(script), ambiente=figlio, timeout=TIMEOUT_FIRMA)
        riuscito, messaggio = _interpreta_powershell(codice, _nasconde(testo, password))
        return riuscito, ("firmato con PowerShell: " + messaggio) if riuscito else \
            f"PowerShell non è riuscito a firmare: {messaggio}"

    riuscito, messaggio = tentativo(marca_temporale or None)
    if not riuscito and marca_temporale and _sembra_errore_marca(messaggio):
        riuscito2, messaggio2 = tentativo(None)
        if riuscito2:
            return True, (f"{p.name}: {messaggio2} SENZA marca temporale (il server {marca_temporale} "
                          "non ha risposto: la firma vale solo fino alla scadenza del certificato)")
        messaggio = messaggio + " | senza marca temporale: " + messaggio2
    return riuscito, f"{p.name}: {messaggio}"


def verifica_firma(percorso: str | os.PathLike, *, sistema: str | None = None,
                   esegui: Esecutore | None = None) -> tuple[bool, str]:
    """Controlla la firma di ``percorso`` (``Get-AuthenticodeSignature``).

    ``(True, "Valid")`` solo se la firma e' valida e attendibile su questo PC.
    """
    sistema = os.name if sistema is None else sistema
    if sistema != "nt":
        return False, "La verifica della firma Authenticode si fa solo su Windows."
    esegui = esegui or _esegui_vero
    script = ("$ErrorActionPreference = 'Stop'\r\ntry {\r\n"
              f"    $r = Get-AuthenticodeSignature -FilePath {testo_ps(str(percorso))}\r\n"
              "    Write-Output ('ESITO=' + $r.Status)\r\n"
              "} catch { Write-Output ('ERRORE=' + $_.Exception.Message); exit 1 }\r\n")
    codice, testo = esegui(comando_powershell(script), ambiente=None, timeout=60)
    esito = _valore_riga(testo, "ESITO")
    if esito:
        return esito == "Valid", esito
    return False, _valore_riga(testo, "ERRORE") or _ultime_righe(testo) or f"codice {codice}"


# ---------------------------------------------------------------------------
# Certificato personale (auto-firmato)
# ---------------------------------------------------------------------------

def script_certificato_personale(nome: str, *, anni: int = 5, rendi_attendibile: bool = True,
                                 esporta_cer: str | os.PathLike | None = None,
                                 esporta_pfx: str | os.PathLike | None = None) -> str:
    """Script PowerShell che crea un certificato di firma codice PERSONALE.

    Il certificato va in ``Cert:\\CurrentUser\\My``. Con ``rendi_attendibile`` viene
    copiato (solo la parte pubblica) anche in ``CurrentUser\\Root`` e
    ``CurrentUser\\TrustedPublisher``: Windows chiede conferma con una finestra sua.
    Con ``esporta_pfx`` si salva anche il file .pfx (password nella variabile interna).
    """
    soggetto = "CN=" + str(nome).replace(",", " ").replace("=", " ").strip()
    righe = [
        "$ErrorActionPreference = 'Stop'",
        "try {",
        "    $cert = New-SelfSignedCertificate -Type CodeSigningCert -Subject "
        + testo_ps(soggetto) + " -CertStoreLocation Cert:\\CurrentUser\\My -KeyAlgorithm RSA -KeyLength 3072 "
        "-HashAlgorithm SHA256 -KeyExportPolicy Exportable -NotAfter (Get-Date).AddYears("
        + str(int(anni)) + ")",
        "    Write-Output ('IMPRONTA=' + $cert.Thumbprint)",
        "    $cer = " + (testo_ps(str(esporta_cer)) if esporta_cer else
                        "Join-Path $env:TEMP ('leo_certificato_' + $cert.Thumbprint + '.cer')"),
        "    Export-Certificate -Cert $cert -FilePath $cer -Type CERT | Out-Null",
        "    Write-Output ('CER=' + $cer)",
    ]
    if rendi_attendibile:
        righe += [
            "    Import-Certificate -FilePath $cer -CertStoreLocation Cert:\\CurrentUser\\TrustedPublisher | Out-Null",
            "    try { Import-Certificate -FilePath $cer -CertStoreLocation Cert:\\CurrentUser\\Root | Out-Null; "
            "Write-Output 'ATTENDIBILE=si' } catch { Write-Output 'ATTENDIBILE=no' }",
        ]
    if esporta_pfx:
        righe += [
            f"    $pw = ConvertTo-SecureString -String $env:{_VARIABILE_PASSWORD_FIGLIO} -AsPlainText -Force",
            "    Export-PfxCertificate -Cert $cert -FilePath " + testo_ps(str(esporta_pfx))
            + " -Password $pw | Out-Null",
            "    Write-Output ('PFX=' + " + testo_ps(str(esporta_pfx)) + ")",
        ]
    righe += [
        "} catch {",
        "    Write-Output ('ERRORE=' + $_.Exception.Message); exit 1",
        "}",
    ]
    return "\r\n".join(righe) + "\r\n"


def crea_certificato_personale(nome: str = "Rosario Zappalà", *, anni: int = 5,
                               rendi_attendibile: bool = True,
                               esporta_pfx: str | os.PathLike | None = None,
                               password: str | None = None,
                               sistema: str | None = None,
                               esegui: Esecutore | None = None) -> tuple[bool, str]:
    """Crea un certificato di firma codice personale (auto-firmato) con PowerShell.

    ATTENZIONE: vale solo sul tuo PC (e su quelli dove lo importi a mano). Non toglie
    l'avviso "App non riconosciuta" agli altri: per quello serve un certificato di
    un'autorita' di certificazione o Microsoft Trusted Signing.

    Restituisce ``(riuscito, messaggio)``; nel messaggio c'e' l'impronta da usare come
    ``LEO_CERTIFICATO``.
    """
    sistema = os.name if sistema is None else sistema
    if sistema != "nt":
        return False, "I certificati di firma codice si creano solo su Windows (serve PowerShell)."
    if esporta_pfx and not password:
        return False, "Per salvare il certificato in un file .pfx serve una password."
    esegui = esegui or _esegui_vero
    ambiente = dict(os.environ)
    if password:
        ambiente[_VARIABILE_PASSWORD_FIGLIO] = password
    script = script_certificato_personale(nome, anni=anni, rendi_attendibile=rendi_attendibile,
                                          esporta_pfx=esporta_pfx)
    codice, testo = esegui(comando_powershell(script), ambiente=ambiente, timeout=TIMEOUT_CERTIFICATO)
    testo = _nasconde(testo, password)
    impronta = _valore_riga(testo, "IMPRONTA")
    if not impronta:
        errore = _valore_riga(testo, "ERRORE") or _ultime_righe(testo) or f"codice {codice}"
        return False, f"Non sono riuscito a creare il certificato: {errore}"
    parti = [f"Certificato personale creato per '{nome}'. Impronta: {impronta}.",
             f"Per usarlo: set {VARIABILE_CERTIFICATO}={impronta}"]
    if rendi_attendibile:
        if _valore_riga(testo, "ATTENDIBILE") == "si":
            parti.append("È attendibile su QUESTO PC (e solo qui).")
        else:
            parti.append("Non è stato aggiunto ai certificati attendibili (hai risposto No?): "
                         "la firma ci sarà lo stesso, ma Windows la segnalerà come non attendibile.")
    if _valore_riga(testo, "PFX"):
        parti.append(f"Salvato anche in {_valore_riga(testo, 'PFX')} (tienilo al sicuro, non condividerlo).")
    parti.append("Sugli altri PC l'avviso 'App non riconosciuta' resta: serve un certificato di "
                 "un'autorità di certificazione (vedi docs/DISTRIBUZIONE.md).")
    return True, "\n".join(parti)


# ---------------------------------------------------------------------------
# Sorgenti e progetti Leo (Ed25519, leo.firma_codice)
# ---------------------------------------------------------------------------

def firma_sorgente(percorso: str | os.PathLike, autore: str | None = None) -> Any:
    """Firma un programma ``.leo`` (o un progetto, se ``percorso`` è una cartella)."""
    from .firma_codice import firma_file

    return firma_file(percorso, autore)


def verifica_sorgente(percorso: str | os.PathLike) -> Any:
    """Verifica la firma di un programma ``.leo`` o di un progetto; None se non è firmato."""
    from .firma_codice import verifica_file

    return verifica_file(percorso)


def firma_progetto(cartella: str | os.PathLike, autore: str | None = None) -> Any:
    from .firma_codice import firma_progetto as firma

    return firma(cartella, autore)


def verifica_progetto(cartella: str | os.PathLike) -> Any:
    from .firma_codice import verifica_progetto as verifica

    return verifica(cartella)


# ---------------------------------------------------------------------------
# Riga di comando: python -m leo.firma [file.exe ...] | --crea-certificato | --sorgente
# ---------------------------------------------------------------------------

def main(argv: Sequence[str] | None = None) -> int:
    import argparse

    p = argparse.ArgumentParser(prog="python -m leo.firma",
                                description="Firma gli eseguibili di Leo (solo Windows).")
    p.add_argument("file", nargs="*", help="eseguibili da firmare")
    p.add_argument("--certificato", help="file .pfx, impronta, oppure 'archivio'")
    p.add_argument("--password", help="password del .pfx (meglio la variabile LEO_CERTIFICATO_PASSWORD)")
    p.add_argument("--marca-temporale", default=None, help="server RFC 3161 (vuoto = nessuna)")
    p.add_argument("--crea-certificato", metavar="NOME", nargs="?", const="Rosario Zappalà",
                   help="crea un certificato personale (vale solo su questo PC)")
    p.add_argument("--verifica", action="store_true", help="controlla la firma invece di firmare")
    p.add_argument("--sorgente", action="store_true",
                   help="i file sono programmi .leo o cartelle di progetti (firma Ed25519, ogni sistema)")
    p.add_argument("--autore", default=None, help="con --sorgente: nome dell'autore nella firma")
    args = p.parse_args(argv)
    if args.sorgente:
        from .errori import ErroreDante

        tutto_ok = True
        for f in args.file:
            try:
                esito = verifica_sorgente(f) if args.verifica else firma_sorgente(f, args.autore)
            except ErroreDante as e:
                print(f"NO  {f}: {e.messaggio}")
                tutto_ok = False
                continue
            ok = esito is not None and esito.valida
            print(("OK  " if ok else "NO  ") + f"{f}: " + (esito.descrizione() if esito else "non è firmato."))
            tutto_ok = tutto_ok and ok
        return 0 if tutto_ok else 1
    if args.crea_certificato:
        ok, testo = crea_certificato_personale(args.crea_certificato)
        print(testo)
        return 0 if ok else 1
    if not args.file:
        p.print_help()
        return 2
    conf = configurazione_firma()
    certificato = args.certificato or conf["certificato"]
    password = args.password or conf["password"]
    marca = conf["marca_temporale"] if args.marca_temporale is None else args.marca_temporale
    tutto_ok = True
    for f in args.file:
        ok, testo = verifica_firma(f) if args.verifica else firma_eseguibile(f, certificato, password, marca)
        print(("OK  " if ok else "NO  ") + testo)
        tutto_ok = tutto_ok and ok
    return 0 if tutto_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
