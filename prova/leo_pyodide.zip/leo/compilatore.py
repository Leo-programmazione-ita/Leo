"""Compilatore di Leo: dall'albero sintattico a funzioni Python.

L'interprete ad albero (:mod:`leo.interprete`) visita i nodi uno per uno: a
ogni passo cerca il metodo giusto, apre un ``try``, controlla i tipi. Questo
modulo invece traduce, UNA volta sola, ogni corpo di funzione e ogni
istruzione del programma in una funzione Python vera (testo Python generato e
compilato con ``compile``/``exec``), gia' specializzata sul programma:

* le costanti sono gia' pronte, i nomi delle variabili sono scritti nel codice
  (con la ricerca nei primi due ambienti fatta sul posto);
* gli operatori hanno una via veloce per i casi comuni (interi con interi,
  decimali con decimali, testi con testi) e, per tutto il resto, chiamano le
  stesse funzioni dell'interprete (``operazioni.binaria``...), quindi i
  risultati e i messaggi d'errore sono identici;
* ``interrompi``/``continua``/``restituisci`` diventano ``break``/``continue``/
  ``return`` di Python (niente eccezioni per il controllo del flusso);
* ogni istruzione ha il suo ``try`` (in Python 3.11 non costa niente finche'
  non c'e' un errore; un solo ``except`` compatto, vedi ``RIP``) che mette la
  posizione giusta agli errori, come fa
  l'interprete ad albero; ogni aiutante che puo' sollevare un errore conosce
  il suo nodo, cosi' vince sempre la posizione piu' interna.

Le vie piu' veloci (tutte con lo stesso risultato e gli stessi errori, righe e
colonne comprese; le controllano ``tests/test_prestazioni_*.py`` confrontando
ogni programma con l'interprete ad albero):

* **variabili locali di Python**: i blocchi creati da un'unita' (cicli, ``se``,
  ``prova``...) che nessun altro puo' vedere (niente funzioni che nascono dentro,
  niente istruzioni delegate all'interprete) tengono le variabili in locali di
  Python invece che in un ``Ambiente`` (:class:`_Ambito`); gli errori che
  hanno bisogno dell'ambiente lo ricostruiscono identico (:func:`_ricostruisci`);
* **funzioni pure** (:meth:`Compilatore.pura`): una funzione Leo senza
  funzioni che nascono nel corpo diventa una funzione Python con parametri
  veri, senza ambiente e voci a ogni chiamata;
* **memoria nei punti di chiamata**: dove si chiama sempre la stessa funzione
  (Leo pura, di libreria o un metodo di liste/testi/dizionari) basta un
  confronto ``is`` per chiamare direttamente la funzione Python giusta;
* **nomi sollevati**: i nomi esterni (globali, libreria) usati in un ciclo si
  cercano una volta all'ingresso; nei cicli senza chiamate, se nessun altro filo
  puo' toccare le variabili, si copiano in locali di Python e si riscrivono
  all'uscita;
* **tipi noti**: le variabili locali che contengono sempre un intero (e i
  confronti, che danno sempre un logico) non si controllano a ogni operazione;
* il codice compilato si ricorda su disco (:mod:`leo.avvio_rapido`).

La semantica e' quella dell'interprete ad albero, che resta il riferimento:
gli ambienti (``Ambiente``/``Voce``) sono gli stessi oggetti, quindi chiusure,
moduli, gestori di eventi, REPL e debugger vedono esattamente le stesse cose.
Il percorso compilato si usa quando non c'e' un gancio di traccia (il debugger
passo passo usa l'interprete ad albero, con le espressioni compilate).

Se per qualunque motivo la generazione fallisce (per esempio un programma
annidato oltre i limiti di Python) l'unita' viene eseguita dall'interprete ad
albero: il risultato e' lo stesso, solo piu' lento.
"""

from __future__ import annotations

import os
import re
import sys
import warnings
from functools import partial
from typing import Any, Callable

from . import operazioni
from .ambiente import Ambiente, Voce
from .errori import (ErroreDante, ErroreRicorsione, ErroreSintassi, ErroreTipo, ErroreValore, SegnaleContinua,
                     SegnaleControllo, SegnaleFermaProgramma, SegnaleInterrompi, SegnaleRestituisci)
from .pila import azzera as azzera_pila, esci_da_funzione
from .nodi import (Espressione, Istruzione, Nodo, Attributo, Binaria, Chiamata, Confronto, DefinizioneFunzione, Dichiarazione,
                   DizionarioLetterale, FunzioneAnonima, Indice, Interrompi, Intervallo, IstruzioneEspressione,
                   Letterale, ListaCompresa, ListaLetterale, Logica, Mentre, Nome, PerOgni, Prova, Restituisci,
                   Ripeti, Scegli, Se, TestoInterpolato, Unaria, Continua, Assegnazione)
from .valori import (FunzioneDante, FunzioneNativa, MetodoLegato, OggettoControllo, Richiamabile, crea_intervallo,
                     e_intero, nome_tipo, rappresenta, uguali, verifica_chiave, verifica_logico)

__all__ = ["Compilatore", "UnitaNonCompilata"]

#: Eccezioni che attraversano i gestori degli errori senza essere toccate.
_PASSA = (SegnaleControllo, RecursionError)

#: Blocchi Python annidati al massimo in una funzione generata (CPython ne
#: ammette 20): oltre, l'istruzione composta diventa una funzione a parte.
LIMITE_BLOCCHI = 14
#: Rami ``altrimenti se`` scritti uno dentro l'altro (oltre: una funzione per condizione).
LIMITE_RAMI_ANNIDATI = 12

#: Sentinella per ``dict.get``.
_MANCA = object()


#: La riga di codice generato usa ``ch`` o ``cv`` (la chiusura di una funzione pura)?
_USA_CHIUSURA = re.compile(r"\b(?:ch|cv)\b").search


class _NessunTipo:
    """Tipo che nessun valore ha (memoria vuota dei punti di chiamata dei metodi)."""

#: Con ``LEO_COMPILATORE_RIGOROSO=1`` un errore di generazione non ripiega
#: sull'interprete ad albero ma viene sollevato (serve ai test).
RIGOROSO = os.environ.get("LEO_COMPILATORE_RIGOROSO", "") not in ("", "0")
#: Il codice Python compilato si ricorda su disco (``leo/avvio_rapido.py``); con
#: ``LEO_SENZA_CACHE=1`` no.
CACHE_SU_DISCO = True
#: Con ``LEO_COMPILATORE_MOSTRA=1`` il codice Python generato viene stampato (per il debug).
MOSTRA = os.environ.get("LEO_COMPILATORE_MOSTRA", "") not in ("", "0")

#: chiamare `nulla`: quasi sempre `vuoto(lista)` scritto al posto di `vuota(lista)`
_SUGG_NULLA = ("Forse intendevi `vuota`? `vuoto`, `niente` e `nulla` vogliono dire «nessun valore» e non "
               "si possono chiamare con `( )`: per sapere se una lista o un testo è vuoto scrivi `vuota(...)`.")


#: Crea un ``Ambiente`` senza ``__init__`` (gli attributi li scrive chi lo usa,
#: gli stessi di ``Ambiente.figlio``): e' la parte piu' costosa di una chiamata.
_nuovo_ambiente = Ambiente.__new__


class UnitaNonCompilata(Exception):
    """Interno: la generazione del codice Python non e' riuscita."""


class _SenzaLocali(Exception):
    """Interno: l'unita' contiene qualcosa che ha bisogno degli ambienti veri
    (una funzione che nasce dentro, un'istruzione delegata all'interprete...):
    si rigenera senza variabili locali di Python."""


#: Con ``LEO_COMPILATORE_LOCALI=0`` le variabili dei blocchi restano negli
#: ambienti anche quando potrebbero essere variabili locali di Python (per i test).
LOCALI = os.environ.get("LEO_COMPILATORE_LOCALI", "1").strip() not in ("0", "no")


class _Locale:
    """Una variabile Leo tenuta in una variabile locale di Python."""

    __slots__ = ("py", "riga", "costante", "chiave")

    def __init__(self, py: str, riga: int, costante: bool, chiave: Any = None) -> None:
        self.py = py
        self.riga = riga
        self.costante = costante
        #: Identita' stabile tra una generazione e l'altra (nodo che dichiara, nome):
        #: serve a sapere quali variabili contengono sempre un intero.
        self.chiave = chiave


class _Ambito:
    """Dove si trova il codice che si sta generando, rispetto ai nomi.

    ``a``/``v``: nomi Python dell'ultimo ambiente VERO (``Ambiente``) e delle
    sue voci: i nomi che non sono locali si cercano li' (e nei genitori).

    ``locali``: ``None`` per un ambiente vero; per un blocco "locale" i nomi
    dichiarati nel blocco fino a questo punto -> :class:`_Locale`. Un blocco e'
    locale quando nessuno, oltre al codice generato, puo' vedere il suo
    ambiente (niente funzioni che nascono dentro, niente istruzioni delegate
    all'interprete): allora le sue variabili sono variabili locali di Python,
    molto piu' veloci delle voci di un dizionario. Gli errori che hanno bisogno
    dell'ambiente (nome non definito, suggerimenti) lo ricostruiscono al volo
    con :func:`_ricostruisci`, identico a quello che avrebbe l'interprete.

    Si comporta anche come la coppia ``(a, v)`` di prima (``a, v = ambito``).
    """

    __slots__ = ("a", "v", "locali", "padre")

    def __init__(self, a: str, v: str, locali: dict | None = None, padre: "_Ambito | None" = None) -> None:
        self.a = a
        self.v = v
        self.locali = locali
        self.padre = padre

    def __iter__(self):
        return iter((self.a, self.v))

    def __getitem__(self, i: int) -> str:
        return (self.a, self.v)[i]

    @property
    def locale(self) -> bool:
        return self.locali is not None

    def cerca(self, nome: str) -> _Locale | None:
        ambito: _Ambito | None = self
        while ambito is not None and ambito.locali is not None:
            trovato = ambito.locali.get(nome)
            if trovato is not None:
                return trovato
            ambito = ambito.padre
        return None

    def livelli(self) -> list[dict]:
        """I blocchi locali dal piu' esterno al piu' interno."""
        livelli = []
        ambito: _Ambito | None = self
        while ambito is not None and ambito.locali is not None:
            livelli.append(ambito.locali)
            ambito = ambito.padre
        livelli.reverse()
        return livelli

    def descrizione(self) -> tuple:
        """Fotografia dei nomi locali visibili qui (per :func:`_ricostruisci`):
        per ogni blocco, dal piu' esterno, ``(nome, variabile Python, costante, riga)``."""
        return tuple(tuple((nome, l.py, l.costante, l.riga) for nome, l in livello.items())
                     for livello in self.livelli())

    def simile_locale(self, nome: str) -> bool:
        """Vero se un nome locale visibile differisce da ``nome`` solo per le maiuscole."""
        minuscolo = nome.lower()
        return any(chiave.lower() == minuscolo for livello in self.livelli() for chiave in livello)


def _gestori_riposiziona(completa: Callable) -> tuple[Callable, Callable]:
    """``RIP(e, nodo)`` e ``RIPN(e, nodo, nativa)``: l'eccezione ``e`` uscita dal codice di
    ``nodo``, pronta da rilanciare (``raise RIP(e, nodo)``), esattamente come i tre
    gestori di una volta::

        except ErroreDante as e:        COMPLETA(e, nodo); raise
        except (segnali, RecursionError): raise
        except Exception as e:          raise COMPLETA(CONVERTI(e), nodo) from e

    ``RIPN`` e' la versione per una funzione di libreria chiamata direttamente:
    ``RecursionError`` diventa ``ErroreRicorsione`` e le eccezioni Python prendono il
    nome della funzione (come in ``FunzioneNativa.chiama``)."""

    def riposiziona(e: BaseException, nodo: Any) -> BaseException:
        if isinstance(e, ErroreDante):
            completa(e, nodo)
            return e
        if isinstance(e, _PASSA) or not isinstance(e, Exception):
            return e
        nuovo = completa(_converti(e), nodo)
        nuovo.__cause__ = e
        nuovo.__suppress_context__ = True
        return nuovo

    def riposiziona_nativa(e: BaseException, nodo: Any, nativa: Any) -> BaseException:
        if isinstance(e, ErroreDante):
            completa(e, nodo)
            return e
        if isinstance(e, RecursionError):
            nuovo = completa(ErroreRicorsione(_messaggio_ricorsione(nativa.nome)), nodo)
            nuovo.__cause__ = None
            nuovo.__suppress_context__ = True
            return nuovo
        if isinstance(e, SegnaleControllo) or not isinstance(e, Exception):
            return e
        nuovo = completa(_converti(e, nativa.nome), nodo)
        nuovo.__cause__ = e
        nuovo.__suppress_context__ = True
        return nuovo

    return riposiziona, riposiziona_nativa


def _ricostruisci(descrizione: tuple, base: Ambiente, variabili: dict) -> Ambiente:
    """Gli ambienti che l'interprete avrebbe in questo punto: ``base`` (vero) e
    sopra un ambiente per ogni blocco locale, con le voci dei nomi locali gia'
    dichiarati (valori presi da ``variabili``, le locali del codice generato)."""
    ambiente = base
    permetti = base.permetti_ridichiarazione
    for livello in descrizione:
        figlio = _nuovo_ambiente(Ambiente)
        figlio.genitore = ambiente
        figlio.nome = ""
        figlio.permetti_ridichiarazione = permetti
        voci = figlio.voci = {}
        for nome, py, costante, riga in livello:
            if py in variabili:
                voci[nome] = Voce(variabili[py], costante, riga)
        ambiente = figlio
    return ambiente


def _ricostruttore(descrizione: tuple) -> Callable[[Ambiente], Ambiente]:
    """``R(base)`` chiamata dal codice generato: l'ambiente ricostruito nel punto
    in cui si trova (le variabili locali le legge dal quadro di chi la chiama)."""
    getframe = sys._getframe

    def ricostruisci(base: Ambiente) -> Ambiente:
        return _ricostruisci(descrizione, base, getframe(1).f_locals)
    return ricostruisci


def _converti(eccezione: BaseException, dove: str = "") -> ErroreDante:
    from .interprete import _converti_eccezione

    return _converti_eccezione(eccezione, dove)


def _messaggio_ricorsione(nome: str) -> str:
    return f"Troppe chiamate annidate: la funzione `{nome}` forse non si ferma mai."


def _parametri_semplici(parametri: list) -> bool:
    return all(p.predefinito is None and not p.tipo and not getattr(p, "variadico", False) for p in parametri)


def _cerca_voce(a: str, v: str, nome: str, voce: str) -> str:
    """Condizione Python che cerca la ``Voce`` di ``nome`` nei primi tre ambienti
    (``a`` e' l'ambiente, ``v`` le sue voci) e la mette in ``voce``; se e' falsa
    decide il percorso lento, che rifa' la ricerca completa."""
    return (f"(({voce} := {v}.get({nome})) is not None or ((_g := {a}.genitore) is not None and "
            f"(({voce} := _g.voci.get({nome})) is not None or ((_g := _g.genitore) is not None and "
            f"({voce} := _g.voci.get({nome})) is not None))))")


def _letterale_python(valore: Any) -> str | None:
    """Il testo Python di una costante semplice (per scriverla nel codice), o None."""
    tipo = type(valore)
    if valore is None or tipo is bool:
        return repr(valore)
    if tipo is int and -(10 ** 15) < valore < 10 ** 15:
        return f"({valore})" if valore < 0 else repr(valore)
    if tipo is str and len(valore) <= 200:
        return repr(valore)
    return None


class _Codice:
    """Il testo Python di una funzione generata, con le sue costanti."""

    def __init__(self, base: dict, *, funzione: bool) -> None:
        self.ns = dict(base)
        self.righe: list[str] = []
        self.contatore = 0
        #: ``restituisci`` diventa ``return`` (corpo di funzione)?
        self.funzione = funzione
        #: Cicli Python aperti che corrispondono a cicli Leo (``interrompi`` -> ``break``).
        self.cicli = 0
        #: Blocchi Python annidati in questo punto (``try``, ``while``, ``for``...).
        self.blocchi = 0
        #: Nomi dichiarati direttamente nell'ambiente della funzione generata
        #: (parametri, ``variabile`` al primo livello) -> variabile Python con la
        #: loro ``Voce``: dopo la dichiarazione la Voce non cambia piu' (ogni nuova
        #: dichiarazione dello stesso nome la rilegge), quindi chi legge o scrive
        #: il nome nell'ambiente radice la usa senza cercarla.
        self.fisse: dict[str, str] = {}
        #: I blocchi nuovi possono tenere le loro variabili in locali di Python?
        self.locali = False
        #: Nomi esterni risolti una volta all'ingresso del ciclo piu' esterno:
        #: nome -> (variabile Python con la Voce da leggere, quella da scrivere).
        self.sollevate: dict[str, tuple[str, str]] = {}
        #: Nomi esterni copiati in locali di Python per tutto un ciclo senza chiamate
        #: (vedi :meth:`Compilatore._ciclo_copiabile`): nome -> variabile Python.
        self.copiate: dict[str, str] = {}
        #: Nome copiato -> chiave per sapere se resta intero (come :attr:`_Locale.chiave`).
        self.copiate_chiavi: dict[str, tuple] = {}
        #: Nomi copiati che il ciclo legge / scrive davvero come esterni.
        self.copiate_lette: set[str] = set()
        self.copiate_scritte: set[str] = set()
        #: Variabili locali che NON contengono sempre un intero (chiavi di
        #: :class:`_Locale`): le altre si considerano intere (vedi :meth:`Compilatore._intere`).
        #: ``None``: nessuna variabile si considera intera.
        self.non_intere: set | None = None
        #: Variabili locali a cui la generazione ha visto dare un valore non intero.
        self.viste_non_intere: set = set()

    def nuovo(self, prefisso: str = "t") -> str:
        self.contatore += 1
        return f"{prefisso}{self.contatore}"

    def cost(self, valore: Any, prefisso: str = "K") -> str:
        nome = self.nuovo(prefisso)
        self.ns[nome] = valore
        return nome

    def riga(self, livello: int, testo: str) -> None:
        self.righe.append("    " * livello + testo)

    def crea(self, nome: str) -> Callable:
        testo = "\n".join(self.righe)
        if MOSTRA:
            print(testo)
        # con una costante nella condizione (``se 5 allora``) il codice generato
        # contiene ``5 is not True``: corretto, ma Python avviserebbe con un
        # SyntaxWarning che l'utente vedrebbe sul terminale
        cache = self.ns.get("CACHE_DISCO")
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", SyntaxWarning)
            if cache is not None:
                # lo stesso testo compilato in un'esecuzione precedente (leo/avvio_rapido.py)
                codice = cache.compila(testo, f"<leo compilato {nome}>")
            else:
                codice = compile(testo, f"<leo compilato {nome}>", "exec", dont_inherit=True)
        exec(codice, self.ns)  # noqa: S102 - codice generato da noi, senza testi dell'utente
        return self.ns[nome]


class Compilatore:
    """Traduce i nodi di Leo in funzioni Python per un :class:`~leo.interprete.Interprete`.

    Le funzioni generate si ricordano (per nodo) e usano l'interprete a cui il
    compilatore appartiene.
    """

    def __init__(self, interprete: Any) -> None:
        from . import registro

        self.it = interprete
        self.completa = interprete._completa
        self.dichiarazione_implicita = bool(interprete.dichiarazione_implicita)
        self._espressioni: dict[int, tuple[Any, Callable]] = {}
        self._unita: dict[tuple, tuple[Any, Any, Callable, bool]] = {}
        #: Cambia quando le unita' si ricompilano (invalida i dati di :meth:`prepara`).
        self.generazione = object()
        #: Quante unita' sono state eseguite dall'interprete ad albero (per i test).
        self.ripieghi = 0
        self._base = {
            "__builtins__": __builtins__,
            "IT": interprete,
            "COMPLETA": interprete._completa,
            "RIP": _gestori_riposiziona(interprete._completa)[0],
            "RIPN": _gestori_riposiziona(interprete._completa)[1],
            "AZZERA_PILA": azzera_pila,
            "CONVERTI": _converti,
            "ErroreDante": ErroreDante,
            "PASSA": _PASSA,
            "SegnaleFermaProgramma": SegnaleFermaProgramma,
            "SegnaleInterrompi": SegnaleInterrompi,
            "SegnaleContinua": SegnaleContinua,
            "SegnaleRestituisci": SegnaleRestituisci,
            "ErroreRicorsione": ErroreRicorsione,
            "MSG_RICORSIONE": _messaggio_ricorsione,
            "ESCI": esci_da_funzione,
            "Voce": Voce,
            "FunzioneDante": FunzioneDante,
            "BINARIA": operazioni.binaria,
            "DIVISIBILE": 2 ** 1000,
            # interi che ``str`` scrive senza superare il limite di cifre di Python
            "CIFRE": 10 ** 4000,
            "NCIFRE": -(10 ** 4000),
            "NDIVISIBILE": -(2 ** 1000),
            "MANCA": _MANCA,
            "REGM": registro.METODI,
            "NOMI_TIPO": {list: "lista", str: "testo", dict: "dizionario"},
            "CACHE_DISCO": self._cache_disco(interprete),
        }

    @staticmethod
    def _cache_disco(interprete: Any) -> Any:
        """La cache su disco del codice compilato di questo programma (None nel REPL o
        se la cache e' disattivata)."""
        if interprete.repl or not CACHE_SU_DISCO:
            return None
        try:
            from .avvio_rapido import cache_programma

            nome = str(getattr(interprete, "nome_file", "") or "programma")
            cartelle = getattr(interprete, "percorsi_moduli", None) or ()
            identita = os.path.join(str(cartelle[0]), nome) if cartelle else nome
            return cache_programma(identita)
        except Exception:  # noqa: BLE001 - senza cache si compila e basta
            return None

    # ======================================================================
    # API usata dall'interprete
    # ======================================================================

    def controlla_opzioni(self) -> None:
        """Se l'interprete ha cambiato ``dichiarazione_implicita`` si ricompila tutto."""
        attuale = bool(self.it.dichiarazione_implicita)
        if attuale != self.dichiarazione_implicita:
            self.dichiarazione_implicita = attuale
            self._espressioni.clear()
            self._unita.clear()
            self.generazione = object()

    def espressione(self, nodo: Any) -> Callable[[Ambiente], Any]:
        """Funzione ``f(ambiente) -> valore`` dell'espressione (errori con la posizione giusta)."""
        voce = self._espressioni.get(id(nodo))
        if voce is not None and voce[0] is nodo:
            return voce[1]
        funzione = self._genera_espressione(nodo)
        self._espressioni[id(nodo)] = (nodo, funzione)
        return funzione

    def corpo(self, corpo: list, parametri: list | None) -> tuple[Callable, bool]:
        """Unita' del corpo di una funzione: ``(u(ambiente, argomenti), lega)``.

        ``u`` restituisce il valore di ``restituisci`` (o ``None``). Se ``lega`` e'
        vero, ``u(ambiente, argomenti)`` lega da sola i parametri (argomenti tutti
        posizionali e nel numero giusto); con ``argomenti=None`` li deve aver gia'
        legati il chiamante.
        """
        chiave = (id(corpo), id(parametri), "corpo")
        voce = self._unita.get(chiave)
        if voce is not None and voce[0] is corpo and voce[1] is parametri:
            return voce[2], voce[3]
        lega = bool(parametri) and _parametri_semplici(parametri) and all(p.riga for p in parametri)
        funzione = self._genera_unita(list(corpo), funzione=True, parametri=parametri if lega else None)
        self._unita[chiave] = (corpo, parametri, funzione, lega)
        return funzione, lega

    def istruzioni(self, istruzioni: list) -> Callable[[Ambiente], Any]:
        """Unita' di un blocco eseguito nell'ambiente dato (``esegui_blocco``)."""
        chiave = (id(istruzioni), 0, "blocco")
        voce = self._unita.get(chiave)
        if voce is not None and voce[0] is istruzioni:
            return voce[2]
        funzione = self._genera_unita(list(istruzioni), funzione=False)
        self._unita[chiave] = (istruzioni, None, funzione, False)
        return funzione

    def istruzione(self, nodo: Any) -> Callable[[Ambiente], Any]:
        """Unita' di un'istruzione del programma principale o di un modulo; per
        un'istruzione-espressione restituisce il valore (per il REPL)."""
        chiave = (id(nodo), 0, "istruzione")
        voce = self._unita.get(chiave)
        if voce is not None and voce[0] is nodo:
            return voce[2]
        funzione = self._genera_unita([nodo], funzione=False, valore=True)
        self._unita[chiave] = (nodo, None, funzione, False)
        return funzione

    # ======================================================================
    # Generazione delle unita'
    # ======================================================================

    def _genera_unita(self, istruzioni: list, *, funzione: bool, parametri: list | None = None,
                      valore: bool = False) -> Callable:
        try:
            if LOCALI and not self.dichiarazione_implicita:
                try:
                    return self._con_interi(lambda non_intere: self._scrivi_unita(
                        istruzioni, funzione, parametri, valore, locali=True, non_intere=non_intere)).crea("_unita")
                except _SenzaLocali:
                    pass
            return self._scrivi_unita(istruzioni, funzione, parametri, valore, locali=False).crea("_unita")
        except Exception as e:  # noqa: BLE001 - si ripiega sull'interprete ad albero
            if RIGOROSO:
                raise UnitaNonCompilata(f"{type(e).__name__}: {e}") from e
            return self._unita_albero(istruzioni, funzione=funzione, valore=valore)

    @staticmethod
    def _con_interi(genera: Callable[[set | None], _Codice]) -> _Codice:
        """Genera il codice finche' quello che si sa sulle variabili intere non si
        ferma: si parte supponendo intere tutte le variabili locali e si tolgono
        quelle a cui la generazione vede dare un valore che potrebbe non essere
        intero (di solito bastano due passate)."""
        non_intere: set = set()
        for _ in range(4):
            c = genera(non_intere)
            if c.viste_non_intere <= non_intere:
                return c
            non_intere = non_intere | c.viste_non_intere
        return genera(None)

    def _scrivi_unita(self, istruzioni: list, funzione: bool, parametri: list | None, valore: bool, *,
                      locali: bool, non_intere: set | None = None) -> _Codice:
        if locali:
            from .interprete import _crea_chiusure

            if _crea_chiusure(istruzioni):
                raise _SenzaLocali("funzioni che nascono nell'unità")
        c = _Codice(self._base, funzione=funzione)
        c.locali = locali
        c.non_intere = non_intere if locali else None
        if parametri is not None:
            c.riga(0, "def _unita(amb, argomenti=None):")
            c.riga(1, "v0 = amb.voci")
            c.riga(1, "if argomenti is not None:")
            fisse = []
            for i, p in enumerate(parametri):
                locale = c.nuovo("vl")
                fisse.append((p.nome, locale))
                c.riga(2, f"v0[{p.nome!r}] = {locale} = Voce(argomenti[{i}], False, {int(p.riga)})")
            c.riga(1, "else:")
            for nome, locale in fisse:
                c.riga(2, f"{locale} = v0[{nome!r}]")
            c.fisse.update(fisse)
        else:
            c.riga(0, "def _unita(amb, argomenti=None):" if funzione else "def _unita(amb):")
            c.riga(1, "v0 = amb.voci")
        ambito = _Ambito("amb", "v0")
        if valore and len(istruzioni) == 1 and type(istruzioni[0]) is IstruzioneEspressione:
            self._istruzione(c, istruzioni[0], ambito, 1, ritorna=True)
        else:
            self._blocco(c, istruzioni, ambito, 1)
        return c

    # --- funzioni "pure": variabili locali di Python, niente ambiente ------------

    def pura(self, corpo: list, parametri: list) -> Callable | None:
        """La funzione Python ``p(f, a0, a1, ..., _orig=None, _nomi=None)`` che esegue
        una chiamata di una funzione Leo con questo corpo, o ``None`` se il corpo
        ha bisogno di un ambiente vero (una funzione che nasce dentro, ``importa``...).

        Fa tutto quello che fa una chiamata (stop, profondita', file corrente,
        pila degli errori), ma parametri e variabili sono locali di Python e
        l'ambiente della chiamata non si crea. ``_orig``/``_nomi``: gli argomenti
        come li ha scritti il chiamante, per la pila degli errori (se mancano sono
        i parametri stessi)."""
        chiave = (id(corpo), id(parametri), "pura")
        voce = self._unita.get(chiave)
        if voce is not None and voce[0] is corpo and voce[1] is parametri:
            return voce[2]
        funzione = None
        if LOCALI and not self.dichiarazione_implicita:
            try:
                funzione = self._con_interi(
                    lambda non_intere: self._scrivi_pura(list(corpo), parametri, non_intere)).crea("_pura")
            except _SenzaLocali:
                funzione = None
            except Exception as e:  # noqa: BLE001 - resta il percorso con l'ambiente
                if RIGOROSO:
                    raise UnitaNonCompilata(f"{type(e).__name__}: {e}") from e
                funzione = None
        self._unita[chiave] = (corpo, parametri, funzione, False)
        return funzione

    def _scrivi_pura(self, corpo: list, parametri: list, non_intere: set | None) -> _Codice:
        from .interprete import _crea_chiusure

        nomi = [p.nome for p in parametri]
        if len(set(nomi)) != len(nomi):
            raise _SenzaLocali("parametri ripetuti")
        if _crea_chiusure(corpo):
            raise _SenzaLocali("funzioni che nascono nel corpo")
        c = _Codice(self._base, funzione=True)
        c.locali = True
        c.non_intere = non_intere
        argomenti = [f"p{i}" for i in range(len(parametri))]
        posizionale, minimo = _posizionale_veloce(parametri)
        firma = [a + ("=MANCA" if posizionale and i >= minimo else "") for i, a in enumerate(argomenti)]
        # `_it`: l'interprete come locale (piu' veloce da leggere della globale IT).
        # `_pmax`: il limite di ricorsione catturato all'ingresso come locale (non cambia
        # durante un'esecuzione), cosi' il controllo e' una lettura di locale invece di un
        # attributo; e' una costante dello spazio dei nomi, quindi resta giusto anche con la
        # cache su disco (lo spazio dei nomi si ricostruisce a ogni esecuzione).
        pmax = c.cost(int(self.it.profondita_massima), "PMAX")
        c.riga(0, f"def _pura(f, {''.join(a + ', ' for a in firma)}_orig=None, _nomi=None, "
                  f"_it=IT, _pmax={pmax}):")
        if posizionale and minimo < len(parametri):
            # gli argomenti non passati (predefiniti) non contano per la pila degli errori
            lista = f"[_x for _x in ({', '.join(argomenti)},) if _x is not MANCA]"
        else:
            lista = f"[{', '.join(argomenti)}]"
        # `_lento` riassume `_ferma_richiesta or not _veloce`: una lettura invece di due
        c.riga(1, "if _it._lento:")
        c.riga(2, "if _it._ferma_richiesta: raise SegnaleFermaProgramma()")
        c.riga(2, f"return _it.chiama_funzione_dante(f, {lista} if _orig is None else _orig, "
                  f"{{}} if _nomi is None else _nomi)")
        c.riga(1, "_p = _it.profondita")
        c.riga(1, "if _p >= _pmax: raise ErroreRicorsione(MSG_RICORSIONE(f.nome))")
        c.riga(1, "_it.profondita = _p + 1")
        # Il file corrente serve solo a posizionare gli errori fra piu' file. Finche' il
        # programma e' un solo file (`_multifile` False, il caso normale) il vecchio
        # `_file_corrente = f.nome_file or _prec` era un no-op: lo si salta del tutto. Dal
        # primo `importa` in poi `_multifile` e' True e si salva/ripristina, ma solo quando
        # il file cambia davvero (`f.nome_file` diverso dal corrente, come il vecchio `or`).
        c.riga(1, "if _it._multifile:")
        c.riga(2, "_prec = _it._file_corrente")
        c.riga(2, "_nf = f.nome_file")
        c.riga(2, "if _nf and _nf is not _prec:")
        c.riga(3, "_it._file_corrente = _nf")
        c.riga(3, "_rip = True")
        c.riga(2, "else: _rip = False")
        c.riga(1, "else: _rip = False")
        c.riga(1, "try:")
        prima_chiusura = len(c.righe)
        c.riga(2, "ch = f.chiusura")
        c.riga(2, "cv = ch.voci")
        locali: dict[str, _Locale] = {}
        radice = _Ambito("ch", "cv", locali, None)
        c.blocchi = 1
        for i, (p, a) in enumerate(zip(parametri, argomenti)):
            py = c.nuovo("l")
            if posizionale and i >= minimo:
                # predefinito: calcolato nella chiamata, con i parametri precedenti gia' visibili
                c.riga(2, f"if {a} is MANCA:")
                c.riga(3, "try:")
                c.blocchi += 1
                valore = self._espr(c, p.predefinito, radice, 4, ())
                c.riga(4, f"{py} = {valore}")
                c.blocchi -= 1
                self._gestori(c, p.predefinito, 3)
                c.riga(2, f"else: {py} = {a}")
            else:
                c.riga(2, f"{py} = {a}")
            locali[p.nome] = _Locale(py, int(p.riga or 0), False)
        self._blocco(c, corpo, radice, 2)
        if not any(_USA_CHIUSURA(riga) for riga in c.righe[prima_chiusura + 2:]):
            # il corpo non usa nomi esterni: niente letture della chiusura a ogni chiamata
            del c.righe[prima_chiusura:prima_chiusura + 2]
        c.riga(1, "except SegnaleRestituisci as _s:")
        c.riga(2, "return _s.valore")
        c.riga(1, "except ErroreDante as _e:")
        c.riga(2, f"ESCI(_e, f, {lista} if _orig is None else _orig, _nomi)")
        c.riga(2, "raise")
        c.riga(1, "except RecursionError:")
        c.riga(2, "raise ErroreRicorsione(MSG_RICORSIONE(f.nome)) from None")
        c.riga(1, "finally:")
        # come `profondita -= 1` (le chiamate aumentano e diminuiscono la profondita' in coppia)
        c.riga(2, "_it.profondita = _p")
        c.riga(2, "if _rip: _it._file_corrente = _prec")
        return c

    def _unita_albero(self, istruzioni: list, *, funzione: bool, valore: bool) -> Callable:
        """Ripiego: l'unita' la esegue l'interprete ad albero."""
        from .interprete import Interprete

        it = self.it
        esegui = Interprete._esegui_istruzione
        compilatore = self

        if funzione:
            def unita(amb, argomenti=None):
                compilatore.ripieghi += 1
                for istruzione in istruzioni:
                    esegui(it, istruzione, amb)
                return None
        elif valore:
            def unita(amb):
                compilatore.ripieghi += 1
                risultato = None
                for istruzione in istruzioni:
                    risultato = esegui(it, istruzione, amb)
                return risultato
        else:
            def unita(amb):
                compilatore.ripieghi += 1
                for istruzione in istruzioni:
                    esegui(it, istruzione, amb)
                return None
        return unita

    def _genera_espressione(self, nodo: Any) -> Callable:
        try:
            c = _Codice(self._base, funzione=False)
            c.riga(0, "def _espressione(amb):")
            c.riga(1, "v0 = amb.voci")
            c.riga(1, "try:")
            c.blocchi = 1
            risultato = self._espr(c, nodo, _Ambito("amb", "v0"), 2, ())
            c.riga(2, f"return {risultato}")
            self._gestori(c, nodo, 1)
            return c.crea("_espressione")
        except Exception as e:  # noqa: BLE001
            if RIGOROSO:
                raise UnitaNonCompilata(f"{type(e).__name__}: {e}") from e
            return self._espressione_albero(nodo)

    def _espressione_albero(self, nodo: Any) -> Callable:
        from .interprete import Interprete

        it = self.it
        valuta = Interprete._valuta_albero
        compilatore = self

        def espressione(amb):
            compilatore.ripieghi += 1
            return valuta(it, nodo, amb)

        return espressione

    # ======================================================================
    # Supporto alla generazione
    # ======================================================================

    @staticmethod
    def _pos(nodo: Any, catena: tuple) -> Any:
        """Il nodo a cui va la posizione di un errore nato in ``nodo``: il primo
        con una riga tra ``nodo`` e i suoi antenati (come fa l'interprete, dove
        la posizione piu' interna vince)."""
        if getattr(nodo, "riga", 0):
            return nodo
        for antenato in catena:
            if getattr(antenato, "riga", 0):
                return antenato
        return nodo

    def _gestori(self, c: _Codice, nodo: Any, livello: int) -> None:
        """L'``except`` che mette posizione e file agli errori di ``nodo`` (vedi
        :func:`_riposiziona`: una riga sola invece di tre gestori, il codice
        generato e' piu' corto e si compila prima)."""
        n = c.cost(nodo, "S")
        c.riga(livello, f"except BaseException as _e: raise RIP(_e, {n})")

    def _posizionatore(self, funzione: Callable, pos: Any, *, grezze: bool = True) -> Callable:
        """Avvolge ``funzione``: gli errori Leo ricevono la posizione di ``pos`` e
        (se ``grezze``) le eccezioni Python diventano errori Leo in ``pos``."""
        completa = self.completa
        if grezze:
            def avvolta(*argomenti):
                try:
                    return funzione(*argomenti)
                except ErroreDante as e:
                    completa(e, pos)
                    raise
                except _PASSA:
                    raise
                except Exception as e:
                    raise completa(_converti(e), pos) from e
        else:
            def avvolta(*argomenti):
                try:
                    return funzione(*argomenti)
                except ErroreDante as e:
                    completa(e, pos)
                    raise
        return avvolta

    def _verifica_logico(self, contesto: str, pos: Any) -> Callable:
        """``V(valore)``: ``verifica_logico`` con l'errore in ``pos`` (solleva sempre
        per un valore non logico)."""
        completa = self.completa

        def verifica(valore):
            try:
                return verifica_logico(valore, contesto)
            except ErroreDante as e:
                completa(e, pos)
                raise
        return verifica

    def _nuovo_ambito(self, c: _Codice, ambito: _Ambito, livello: int, nome: str) -> _Ambito:
        if c.locali:
            # nessun ambiente vero: le variabili del blocco saranno locali di Python
            return _Ambito(ambito.a, ambito.v, {}, ambito)
        a = c.nuovo("a")
        v = c.nuovo("v")
        c.riga(livello, f"{a} = {ambito[0]}.figlio({nome!r})")
        c.riga(livello, f"{v} = {a}.voci")
        return _Ambito(a, v)

    def _ambiente(self, c: _Codice, ambito: _Ambito) -> str:
        """Espressione Python che vale l'ambiente in questo punto: quello vero o,
        in un blocco locale, quello ricostruito (solo per i percorsi lenti)."""
        if ambito.locali is None:
            return ambito.a
        r = c.cost(_ricostruttore(ambito.descrizione()), "R")
        return f"{r}({ambito.a})"

    @staticmethod
    def _dichiara_locale(c: _Codice, ambito: _Ambito, nome: str, riga: int, costante: bool = False, *,
                         nodo: Any = None, intero: bool = False) -> str:
        """Nuova variabile locale di Python per ``nome`` nel blocco ``ambito``
        (``nodo``: chi la dichiara; ``intero``: il primo valore e' di sicuro un intero)."""
        if nome in ambito.locali:
            # dichiarato due volte nello stesso blocco: l'errore lo da' l'ambiente vero
            raise _SenzaLocali(f"`{nome}` dichiarato due volte")
        py = c.nuovo("l")
        chiave = (id(nodo), nome) if nodo is not None else None
        ambito.locali[nome] = _Locale(py, int(riga or 0), costante, chiave)
        if not intero and chiave is not None:
            c.viste_non_intere.add(chiave)
        return py

    @staticmethod
    def _intera(c: _Codice, locale: _Locale) -> bool:
        """La variabile locale contiene sempre un intero (``int``, mai ``vero``/``falso``)?"""
        return c.non_intere is not None and locale.chiave is not None and locale.chiave not in c.non_intere

    @staticmethod
    def _copia_intera(c: _Codice, nome: str) -> bool:
        """Il nome esterno copiato in una locale si suppone intero per tutto il ciclo?
        (se si', all'ingresso si controlla che lo sia davvero)"""
        return c.non_intere is not None and c.copiate_chiavi[nome] not in c.non_intere

    @staticmethod
    def _assegna_locale(c: _Codice, locale: _Locale, intero: bool) -> None:
        """Una nuova assegnazione alla variabile locale (per sapere se resta intera)."""
        if not intero and locale.chiave is not None:
            c.viste_non_intere.add(locale.chiave)

    def _tipo(self, c: _Codice, nodo: Any, ambito: _Ambito) -> type | None:
        """Il tipo che il valore di ``nodo`` ha di sicuro (``int``, ``float``, ``str``,
        ``bool``...) o ``None`` se non si sa. ``int`` vuol dire proprio ``int``."""
        tipo = type(nodo)
        if tipo is Letterale:
            return type(nodo.valore)
        if tipo is Nome:
            if ambito.locali is not None:
                locale = ambito.cerca(nodo.nome)
                if locale is not None:
                    return int if self._intera(c, locale) else None
            if nodo.nome in c.copiate and self._copia_intera(c, nodo.nome):
                return int
            return None
        if tipo is Binaria:
            if nodo.operatore in ("+", "-", "*", "//", "%"):
                if self._tipo(c, nodo.sinistra, ambito) is int and self._tipo(c, nodo.destra, ambito) is int:
                    return int  # intero con intero da' un intero (o un errore)
            return None
        if tipo is Unaria:
            if nodo.operatore == "-" and self._tipo(c, nodo.operando, ambito) is int:
                return int
            if nodo.operatore == "non":
                return bool
            return None
        if tipo is Confronto:
            return bool  # i confronti danno sempre un logico (o un errore)
        if tipo is Logica and nodo.operatore in ("e", "o"):
            return bool
        return None

    def _ambito_blocco(self, c: _Codice, corpo: list, ambito: tuple, livello: int, nome: str) -> tuple:
        from .interprete import _serve_ambito

        if _serve_ambito(corpo) or self.dichiarazione_implicita:
            return self._nuovo_ambito(c, ambito, livello, nome)
        return ambito

    # ======================================================================
    # Istruzioni
    # ======================================================================

    def _blocco(self, c: _Codice, istruzioni: list, ambito: tuple, livello: int) -> None:
        inizio = len(c.righe)
        for istruzione in istruzioni:
            self._istruzione(c, istruzione, ambito, livello)
        if len(c.righe) == inizio:
            c.riga(livello, "pass")

    _COMPOSTE = (Se, Mentre, PerOgni, Ripeti, Prova, Scegli)

    def _istruzione(self, c: _Codice, nodo: Any, ambito: tuple, livello: int, *, ritorna: bool = False) -> None:
        tipo = type(nodo)
        if tipo in self._COMPOSTE and c.blocchi + 6 > LIMITE_BLOCCHI:
            # troppo annidata per una sola funzione Python: diventa un'unita' a parte
            # (interrompi/continua/restituisci dentro usano i segnali, come l'interprete)
            if ambito.locali is not None:
                raise _SenzaLocali("troppi blocchi annidati")
            u = c.cost(self._genera_unita([nodo], funzione=False), "U")
            c.riga(livello, f"{u}({ambito[0]})")
            return
        c.riga(livello, "try:")
        c.blocchi += 1
        inizio = len(c.righe)
        metodo = self._METODI_ISTRUZIONI.get(tipo)
        sollevate = False
        if (tipo is Mentre or tipo is Ripeti or tipo is PerOgni) and c.locali and not c.sollevate:
            sollevate = self._solleva_nomi(c, nodo, ambito, livello + 1)
        if sollevate and c.blocchi < 12 and self._ciclo_copiabile(nodo):
            self._ciclo_con_copie(c, nodo, ambito, livello + 1, metodo)
        elif metodo is None:
            self._delega_istruzione(c, nodo, ambito, livello + 1)
        elif tipo is IstruzioneEspressione and type(nodo.espressione) is Attributo:
            # `Finestra1.mostra`, `Eroe.esulta` da soli sulla riga: il metodo si chiama (vedi l'interprete)
            if ambito.locali is not None:
                raise _SenzaLocali("metodo da solo sulla riga")
            m_v = c.cost(self.it._trova_metodo(nodo), "M")
            n_v = c.cost(nodo, "D")
            c.riga(livello + 1, f"{'return ' if ritorna else ''}{m_v}({n_v}, {ambito[0]})")
        elif tipo is IstruzioneEspressione:
            valore = self._espr(c, nodo.espressione, ambito, livello + 1, ())
            if ritorna:
                c.riga(livello + 1, f"return {valore}")
        else:
            metodo(self, c, nodo, ambito, livello + 1)
        if sollevate:
            c.sollevate = {}
        if len(c.righe) == inizio:
            c.riga(livello + 1, "pass")
        c.blocchi -= 1
        self._gestori(c, nodo, livello)

    #: Istruzioni che in un ciclo non possono aggiungere nomi agli ambienti veri.
    _SICURE_PER_SOLLEVARE = (IstruzioneEspressione, Assegnazione, Se, Scegli, Mentre, Ripeti, PerOgni,
                             Restituisci, Interrompi, Continua, Prova)

    def _solleva_nomi(self, c: _Codice, ciclo: Any, ambito: _Ambito, livello: int) -> bool:
        """All'ingresso del ciclo piu' esterno cerca UNA volta le voci dei nomi
        esterni che il ciclo usa (variabili globali, funzioni, libreria), invece
        di cercarle a ogni giro.

        Si puo' perche' durante il ciclo nessuno aggiunge nomi agli ambienti
        veri che li contengono: i blocchi del ciclo sono locali (``c.locali``),
        le istruzioni del ciclo non dichiarano niente nell'ambiente dell'unita'
        (lo controlla :meth:`_nomi_del_ciclo`), le funzioni chiamate dichiarano
        nei loro ambienti e una ``Voce`` resta la stessa finche' esiste (un
        assegnamento cambia solo il suo ``valore``). Le voci dei controlli
        grafici e i nomi della libreria quando ci sono finestre (che possono
        aggiungere controlli all'ambiente globale) non si sollevano. Un nome che
        all'ingresso non c'e' segue la via normale."""
        if ambito.a not in ("amb", "ch"):
            return False
        nomi: set[str] = set()
        if not self._nomi_del_ciclo(ciclo, nomi):
            return False
        sollevate: dict[str, tuple[str, str]] = {}
        risolvi = c.cost(self._risolvi, "RIS")
        for nome in sorted(nomi):
            if ambito.cerca(nome) is not None or (ambito.v == "v0" and nome in c.fisse):
                continue
            lettura = c.nuovo("h")
            scrittura = c.nuovo("hw")
            c.riga(livello, f"{lettura} = {risolvi}({ambito.a}, {nome!r})")
            c.riga(livello, f"{scrittura} = {lettura} if {lettura} is not None and not {lettura}.costante else None")
            sollevate[nome] = (lettura, scrittura)
        c.sollevate = sollevate
        return True

    #: Nodi che in un ciclo "copiabile" non eseguono codice di altri (niente chiamate,
    #: niente proprieta' dei controlli, niente istruzioni delegate all'interprete).
    _COPIABILI = (Nome, Letterale, Binaria, Unaria, Confronto, Logica, Indice, ListaLetterale,
                  DizionarioLetterale, TestoInterpolato, Intervallo, ListaCompresa, Assegnazione, Dichiarazione,
                  Se, Mentre, Ripeti, PerOgni, Interrompi, Continua, IstruzioneEspressione, Restituisci)

    def _ciclo_copiabile(self, nodo: Any) -> bool:
        """Vero se nel ciclo gira solo codice generato qui: nessuna chiamata (di
        funzioni Leo, della libreria o di metodi), nessuna proprieta' di un oggetto,
        niente istruzioni delegate. Allora, se nessun altro filo puo' toccare le
        variabili (vedi ``_copia_possibile``), i nomi esterni del ciclo si possono
        copiare in locali di Python all'ingresso e riscrivere all'uscita."""
        if isinstance(nodo, list):
            return all(self._ciclo_copiabile(x) for x in nodo)
        if not isinstance(nodo, Nodo):
            return True
        tipo = type(nodo)
        if isinstance(nodo, (Espressione, Istruzione)) and tipo not in self._COPIABILI:
            return False
        if tipo is Se and len(nodo.rami) > LIMITE_RAMI_ANNIDATI:
            return False
        if tipo is Logica and nodo.operatore not in ("e", "o"):
            return False
        if tipo is Assegnazione and type(nodo.bersaglio) not in (Nome, Indice):
            return False
        for valore in vars(nodo).values():
            if isinstance(valore, (Nodo, list)) and not self._ciclo_copiabile(valore):
                return False
        return True

    def _ciclo_con_copie(self, c: _Codice, nodo: Any, ambito: _Ambito, livello: int, metodo: Callable) -> None:
        """Il ciclo in due versioni: con i nomi esterni copiati in locali di Python
        (scritti di nuovo nelle loro voci all'uscita, anche con un errore o un
        ``interrompi``) quando si puo', altrimenti quello normale.

        Contano solo i nomi che il ciclo usa davvero come esterni (non la variabile
        del ciclo o quelle dichiarate dentro): l'intestazione si scrive dopo il corpo."""
        copiate = {nome: c.nuovo("g") for nome in sorted(c.sollevate)}
        intestazione = len(c.righe)
        c.copiate = copiate
        # chiavi per i tipi noti: una copia si suppone intera finche' il ciclo le da' solo interi
        c.copiate_chiavi = {nome: ("copia", id(nodo), nome) for nome in copiate}
        c.copiate_lette = set()
        c.copiate_scritte = set()
        c.blocchi += 1
        inizio = len(c.righe)
        metodo(self, c, nodo, ambito, livello + 2)
        if len(c.righe) == inizio:
            c.riga(livello + 2, "pass")
        c.blocchi -= 1
        lette = c.copiate_lette
        scritte = c.copiate_scritte
        c.copiate = {}
        usate = sorted(lette | scritte)
        possibile = c.cost(self._copia_possibile, "CP")
        controlli = [c.sollevate[n][1] if n in scritte else c.sollevate[n][0] for n in usate]
        # le copie supposte intere devono esserlo davvero all'ingresso (altrimenti il ciclo normale)
        interi = "".join(f" and type({c.sollevate[n][0]}.valore) is int" for n in usate if self._copia_intera(c, n))
        c.copiate_chiavi = {}
        righe = [f"if {possibile}({', '.join(controlli)}){interi}:"]
        righe += ["    " + f"{copiate[n]} = {c.sollevate[n][0]}.valore" for n in usate]
        righe.append("    try:")
        c.righe[intestazione:intestazione] = ["    " * livello + r for r in righe]
        c.riga(livello + 1, "finally:")
        for nome in usate:
            if nome in scritte:
                c.riga(livello + 2, f"{c.sollevate[nome][1]}.valore = {copiate[nome]}")
        if not scritte:
            c.riga(livello + 2, "pass")
        c.riga(livello, "else:")
        inizio = len(c.righe)
        metodo(self, c, nodo, ambito, livello + 1)
        if len(c.righe) == inizio:
            c.riga(livello + 1, "pass")

    @staticmethod
    def _nomi_scritti(nodo: Any, nomi: set) -> None:
        if isinstance(nodo, list):
            for x in nodo:
                Compilatore._nomi_scritti(x, nomi)
            return
        if not isinstance(nodo, Nodo):
            return
        if type(nodo) is Assegnazione and type(nodo.bersaglio) is Nome:
            nomi.add(nodo.bersaglio.nome)
        for valore in vars(nodo).values():
            if isinstance(valore, (Nodo, list)):
                Compilatore._nomi_scritti(valore, nomi)

    def _copia_possibile(self, *voci: Any) -> bool:
        """Si possono copiare le voci in locali per tutto il ciclo? Servono tutte
        (trovate e, se il ciclo le cambia, non costanti) e nessun altro deve poter
        leggere o scrivere le variabili mentre il ciclo gira: niente finestre (i
        gestori degli eventi) e nessun altro filo di Python oltre a quello del
        programma (lavori ``in parallelo``, temporizzatori in un filo...)."""
        for voce in voci:
            if voce is None:
                return False
        if self.it.ponte_grafico is not None:
            return False
        import threading

        return threading.active_count() <= (1 if threading.current_thread() is threading.main_thread() else 2)

    def _nomi_del_ciclo(self, nodo: Any, nomi: set) -> bool:
        """Raccoglie i nomi usati nel ciclo; falso se il ciclo contiene istruzioni
        che potrebbero dichiarare nell'ambiente dell'unita'."""
        if isinstance(nodo, list):
            return all(self._nomi_del_ciclo(x, nomi) for x in nodo)
        if not isinstance(nodo, Nodo):
            return True
        tipo = type(nodo)
        if isinstance(nodo, Istruzione) and tipo is not Dichiarazione and tipo not in self._SICURE_PER_SOLLEVARE:
            return False
        if tipo is Nome:
            nomi.add(nodo.nome)
            return True
        for valore in vars(nodo).values():
            if isinstance(valore, (Nodo, list)) and not self._nomi_del_ciclo(valore, nomi):
                return False
        return True

    def _risolvi(self, ambiente: Ambiente, nome: str) -> Voce | None:
        """La voce di ``nome`` vista da ``ambiente`` da usare per tutto un ciclo (None:
        il nome segue la via normale a ogni uso)."""
        it = self.it
        fino_a = it.predefinito if it.ponte_grafico is not None else None
        amb = ambiente
        while amb is not None and amb is not fino_a:
            voce = amb.voci.get(nome)
            if voce is not None:
                return None if isinstance(voce.valore, OggettoControllo) else voce
            amb = amb.genitore
        return None

    #: Istruzioni delegate che leggono soltanto l'ambiente (vanno bene anche in un blocco locale).
    _DELEGATE_SOLO_LETTURA = frozenset({"Lancia"})

    def _delega_istruzione(self, c: _Codice, nodo: Any, ambito: tuple, livello: int) -> None:
        """Istruzioni rare: le esegue il metodo ``visita_*`` dell'interprete ad
        albero (che valuta le espressioni con il percorso compilato)."""
        if ambito.locali is not None and type(nodo).__name__ not in self._DELEGATE_SOLO_LETTURA:
            raise _SenzaLocali(type(nodo).__name__)
        metodo = c.cost(self.it._trova_metodo(nodo), "M")
        n = c.cost(nodo, "D")
        c.riga(livello, f"{metodo}({n}, {self._ambiente(c, ambito)})")
        if ambito[1] == "v0":
            # puo' dichiarare (``importa``, ``variabile a, b = ...``): si torna a cercare
            c.fisse.clear()

    def _i_dichiarazione(self, c: _Codice, nodo: Any, ambito: tuple, livello: int) -> None:
        if type(nodo) is not Dichiarazione or nodo.costante or nodo.tipo is not None:
            # DichiarazioneMultipla, tipo dichiarato, costante bloccata: le fa l'interprete
            self._delega_istruzione(c, nodo, ambito, livello)
            return
        a, v = ambito
        valore = self._espr(c, nodo.valore, ambito, livello, ())
        if ambito.locali is not None:
            intero = self._tipo(c, nodo.valore, ambito) is int
            py = self._dichiara_locale(c, ambito, nodo.nome, nodo.riga, bool(nodo.costante), nodo=nodo,
                                       intero=intero)
            c.riga(livello, f"{py} = {valore}")
            return
        nome = repr(nodo.nome)
        costante = bool(nodo.costante)
        c.riga(livello, f"if {nome} in {v}: {a}.dichiara({nome}, {valore}, costante={costante}, "
                        f"riga={int(nodo.riga or 0)})")
        c.riga(livello, f"else: {v}[{nome}] = Voce({valore}, {costante}, {int(nodo.riga or 0)}, False)")
        if v == "v0":
            locale = c.nuovo("vl")
            c.riga(livello, f"{locale} = {v}[{nome}]")
            c.fisse[nodo.nome] = locale

    def _i_definizione(self, c: _Codice, nodo: Any, ambito: tuple, livello: int) -> None:
        if ambito.locali is not None:
            raise _SenzaLocali("funzione dentro un blocco locale")
        if "." in nodo.nome or nodo.tipo_risultato is not None or nodo.richiede or nodo.garantisce:
            # metodo di una struttura, `dà tipo` o contratti (leo/controllo/esecuzione.py)
            self._delega_istruzione(c, nodo, ambito, livello)
            return
        a, _ = ambito
        nome = repr(nodo.nome)
        parametri = c.cost(nodo.parametri, "P")
        corpo = c.cost(nodo.corpo, "C")
        f = c.nuovo("f")
        c.riga(livello, f"{f} = FunzioneDante({nome}, {parametri}, {corpo}, {a}, {int(nodo.riga or 0)}, "
                        f"{int(nodo.colonna or 0)})")
        c.riga(livello, f"{f}.nome_file = IT._file_corrente")
        if self.it.repl:
            c.riga(livello, f"IT.segna_testo({f})")
        c.riga(livello, f"{a}.dichiara({nome}, {f}, costante=True, riga={int(nodo.riga or 0)})")
        if a == "amb":
            locale = c.nuovo("vl")
            c.riga(livello, f"{locale} = amb.voci[{nome}]")
            c.fisse[nodo.nome] = locale

    # --- assegnazioni ----------------------------------------------------------

    def _i_assegnazione(self, c: _Codice, nodo: Any, ambito: tuple, livello: int) -> None:
        bersaglio = nodo.bersaglio
        if type(bersaglio) is Nome:
            if nodo.operatore == "=":
                self._assegna_nome(c, nodo, ambito, livello)
            else:
                self._assegna_nome_composta(c, nodo, ambito, livello)
            return
        if isinstance(bersaglio, Indice):
            self._assegna_indice(c, nodo, ambito, livello)
            return
        if isinstance(bersaglio, Attributo):
            h = c.cost(self._assegna_attributo_lenta(nodo), "H")
            c.riga(livello, f"{h}({self._ambiente(c, ambito)})")
            return
        h = c.cost(_solleva(ErroreSintassi, "Non si può assegnare a questa espressione."), "H")
        c.riga(livello, f"{h}()")

    def _assegna_nome(self, c: _Codice, nodo: Any, ambito: tuple, livello: int) -> None:
        a, v = ambito
        valore = self._espr(c, nodo.valore, ambito, livello, ())
        nome = repr(nodo.bersaglio.nome)
        lento = c.cost(self._assegna_nome_lenta(nodo), "H")
        if ambito.locali is not None:
            locale = ambito.cerca(nodo.bersaglio.nome)
            if locale is not None:
                if locale.costante:  # errore "e' una costante", con l'ambiente ricostruito
                    c.riga(livello, f"{lento}({self._ambiente(c, ambito)}, {valore})")
                else:
                    self._assegna_locale(c, locale, self._tipo(c, nodo.valore, ambito) is int)
                    c.riga(livello, f"{locale.py} = {valore}")
                return
            if ambito.simile_locale(nodo.bersaglio.nome):
                raise _SenzaLocali("nome simile a una variabile locale")
        copiata = c.copiate.get(nodo.bersaglio.nome)
        if copiata is not None:
            c.copiate_scritte.add(nodo.bersaglio.nome)
            if self._tipo(c, nodo.valore, ambito) is not int:
                c.viste_non_intere.add(c.copiate_chiavi[nodo.bersaglio.nome])
            c.riga(livello, f"{copiata} = {valore}")
            return
        if v == "v0" and nodo.bersaglio.nome in c.fisse:
            cerca = f"(_v := {c.fisse[nodo.bersaglio.nome]}) is not None"
        else:
            cerca = _cerca_voce(a, v, nome, "_v")
        sollevata = c.sollevate.get(nodo.bersaglio.nome)
        if sollevata:
            c.riga(livello, f"if {sollevata[1]} is not None: {sollevata[1]}.valore = {valore}")
            c.riga(livello, f"elif {cerca} and not _v.costante: _v.valore = {valore}")
        else:
            c.riga(livello, f"if {cerca} and not _v.costante: _v.valore = {valore}")
        c.riga(livello, f"else: {lento}({self._ambiente(c, ambito)}, {valore})")

    def _assegna_nome_lenta(self, nodo: Any) -> Callable:
        """``nome = valore`` quando la variabile non e' nell'ambiente corrente (o e'
        una costante): la stessa logica dell'interprete ad albero."""
        it = self.it
        completa = self.completa
        bersaglio = nodo.bersaglio
        nome0 = bersaglio.nome
        riga = nodo.riga

        def lenta(ambiente, valore):
            nome = nome0
            amb = ambiente
            voce = None
            while amb is not None:
                voce = amb.voci.get(nome)
                if voce is not None:
                    break
                amb = amb.genitore
            if voce is not None and not voce.costante:
                voce.valore = valore
                return
            dove = amb
            if dove is None and it.tollerante and not it.dichiarazione_implicita:
                trovato = it._cerca_senza_maiuscole(nome, ambiente)
                if trovato:
                    dove, nome = trovato
            if dove is None:
                if it.dichiarazione_implicita:
                    ambiente.dichiara(nome, valore, riga=riga)
                    return
                raise completa(it._errore_non_definito(nome, ambiente, per_assegnare=True), bersaglio)
            try:
                dove.assegna(nome, valore)
            except ErroreDante as e:
                completa(e, bersaglio)
                raise
        return lenta

    def _assegna_nome_composta(self, c: _Codice, nodo: Any, ambito: tuple, livello: int) -> None:
        a, v = ambito
        op = nodo.operatore[:-1]
        nome = repr(nodo.bersaglio.nome)
        lento = c.cost(self._assegna_composta_lenta(nodo), "H")
        if ambito.locali is not None:
            locale = ambito.cerca(nodo.bersaglio.nome)
            if locale is not None:
                if locale.costante:
                    c.riga(livello, f"{lento}({self._ambiente(c, ambito)})")
                    return
                destra = self._espr(c, nodo.valore, ambito, livello, ())
                td = self._tipo(c, nodo.valore, ambito)
                intera = self._intera(c, locale)
                self._assegna_locale(c, locale, intera and td is int and op in ("+", "-", "*", "//", "%"))
                self._composta(c, op, locale.py, locale.py, destra, td, nodo.valore, livello,
                               int if intera else None)
                return
            if ambito.simile_locale(nodo.bersaglio.nome):
                raise _SenzaLocali("nome simile a una variabile locale")
        copiata = c.copiate.get(nodo.bersaglio.nome)
        if copiata is not None:
            c.copiate_scritte.add(nodo.bersaglio.nome)
            destra = self._espr(c, nodo.valore, ambito, livello, ())
            td = self._tipo(c, nodo.valore, ambito)
            intera = self._copia_intera(c, nodo.bersaglio.nome)
            if not (intera and td is int and op in ("+", "-", "*", "//", "%")):
                c.viste_non_intere.add(c.copiate_chiavi[nodo.bersaglio.nome])
            self._composta(c, op, copiata, copiata, destra, td, nodo.valore, livello, int if intera else None)
            return
        vv = c.nuovo("vv")
        if v == "v0" and nodo.bersaglio.nome in c.fisse:
            cerca = f"({vv} := {c.fisse[nodo.bersaglio.nome]}) is not None"
        else:
            cerca = _cerca_voce(a, v, nome, vv)
        sollevata = c.sollevate.get(nodo.bersaglio.nome)
        if sollevata:
            cerca = f"({vv} := {sollevata[1]}) is not None or ({cerca} and not {vv}.costante)"
        else:
            cerca = f"{cerca} and not {vv}.costante"
        c.riga(livello, f"if {cerca}:")
        destra = self._espr(c, nodo.valore, ambito, livello + 1, ())
        attuale = c.nuovo("t")
        c.riga(livello + 1, f"{attuale} = {vv}.valore")
        self._composta(c, op, attuale, f"{vv}.valore", destra, self._tipo(c, nodo.valore, ambito), nodo.valore,
                       livello + 1)
        c.riga(livello, "else:")
        c.riga(livello + 1, f"{lento}({self._ambiente(c, ambito)})")

    def _composta(self, c: _Codice, op: str, attuale: str, bersaglio: str, destra: str, td: type | None,
                  nodo_destra: Any, livello: int, ta: type | None = None) -> None:
        """``bersaglio = attuale op destra`` per ``+= -= *= /=``... con le vie veloci dei
        numeri (gli errori di ``BINARIA`` prendono la posizione dell'istruzione)."""
        kop = c.cost(op, "O")
        rami = self._rami_aritmetici(op, attuale, destra, ta, td, None, nodo_destra)
        self._scrivi_rami(c, rami, bersaglio, f"BINARIA({kop}, {attuale}, {destra})", livello)

    def _assegna_composta_lenta(self, nodo: Any) -> Callable:
        """``nome += valore`` nel caso generale (stessa logica dell'interprete)."""
        it = self.it
        completa = self.completa
        bersaglio = nodo.bersaglio
        nome0 = bersaglio.nome
        op = nodo.operatore[:-1]
        compilatore = self
        binaria = operazioni.binaria

        def destra_f(ambiente):
            # compilata solo se serve (questa e' la via rara: nome non trovato o costante)
            return compilatore.espressione(nodo.valore)(ambiente)

        def lenta(ambiente):
            nome = nome0
            amb = ambiente
            voce = None
            while amb is not None:
                voce = amb.voci.get(nome)
                if voce is not None:
                    break
                amb = amb.genitore
            if voce is not None and not voce.costante:
                destra = destra_f(ambiente)
                attuale = voce.valore
                ta = type(attuale)
                td = type(destra)
                if (ta is int or ta is float) and (td is int or td is float) and op in ("+", "-"):
                    voce.valore = attuale + destra if op == "+" else attuale - destra
                    return
                try:
                    voce.valore = binaria(op, attuale, destra)
                except ErroreDante as e:
                    completa(e, nodo)
                    raise
                return
            dove = amb
            if dove is None and it.tollerante:
                trovato = it._cerca_senza_maiuscole(nome, ambiente)
                if trovato:
                    dove, nome = trovato
            if dove is None:
                raise completa(it._errore_non_definito(nome, ambiente), bersaglio)
            attuale = dove.voci[nome].valore
            valore = it._valuta_composta(op, attuale, nodo, ambiente)
            try:
                dove.assegna(nome, valore)
            except ErroreDante as e:
                completa(e, bersaglio)
                raise
        return lenta

    def _assegna_indice(self, c: _Codice, nodo: Any, ambito: tuple, livello: int) -> None:
        bersaglio = nodo.bersaglio
        composta = nodo.operatore != "="
        oggetto = self._espr(c, bersaglio.oggetto, ambito, livello, ())
        indice = self._espr(c, bersaglio.indice, ambito, livello, ())
        completa = self.completa
        scrivi = c.cost(self._posizionatore(operazioni.scrivi_indice, bersaglio, grezze=False), "H")
        if composta:
            op = nodo.operatore[:-1]
            leggi = c.cost(self._posizionatore(operazioni.leggi_indice, bersaglio, grezze=False), "H")
            attuale = c.nuovo("t")
            c.riga(livello, f"if (_tp := type({oggetto})) is dict and type({indice}) is str and "
                            f"({attuale} := {oggetto}.get({indice}, MANCA)) is not MANCA: pass")
            c.riga(livello, f"elif _tp is list and type({indice}) is int and 0 <= {indice} < len({oggetto}): "
                            f"{attuale} = {oggetto}[{indice}]")
            c.riga(livello, f"else: {attuale} = {leggi}({oggetto}, {indice})")
            destra = self._espr(c, nodo.valore, ambito, livello, (bersaglio,))
            pos = self._pos(nodo, (bersaglio,))
            binaria = operazioni.binaria

            def calcola(a, b):
                try:
                    return binaria(op, a, b)
                except ErroreDante as e:
                    completa(e, pos)
                    raise
            h = c.cost(calcola, "H")
            valore = c.nuovo("t")
            if op in ("+", "-"):
                c.riga(livello, f"if type({attuale}) is int and type({destra}) is int: "
                                f"{valore} = {attuale} {op} {destra}")
                c.riga(livello, f"else: {valore} = {h}({attuale}, {destra})")
            else:
                c.riga(livello, f"{valore} = {h}({attuale}, {destra})")
        else:
            valore = self._espr(c, nodo.valore, ambito, livello, (bersaglio,))
        c.riga(livello, f"if (_tp := type({oggetto})) is dict and type({indice}) is str: "
                        f"{oggetto}[{indice}] = {valore}")
        c.riga(livello, f"elif _tp is list and type({indice}) is int and 0 <= {indice} < len({oggetto}): "
                        f"{oggetto}[{indice}] = {valore}")
        c.riga(livello, f"else: {scrivi}({oggetto}, {indice}, {valore})")

    def _assegna_attributo_lenta(self, nodo: Any) -> Callable:
        it = self.it
        completa = self.completa
        bersaglio = nodo.bersaglio
        oggetto_f = self.espressione(bersaglio.oggetto)
        valore_f = self.espressione(nodo.valore)
        composta = nodo.operatore != "="
        op = nodo.operatore[:-1] if composta else ""

        def lenta(ambiente):
            oggetto = oggetto_f(ambiente)
            try:
                if not (isinstance(oggetto, OggettoControllo) or getattr(type(oggetto), "ATTRIBUTI_DANTE", False)):
                    raise ErroreTipo("Si possono cambiare solo le proprietà dei controlli grafici.",
                                     suggerimento="Per un dizionario scrivi `d[\"chiave\"] = valore`."
                                     if isinstance(oggetto, dict) else None)
                if composta:
                    attuale = oggetto.leggi(bersaglio.nome)
                    valore = it._valuta_composta(op, attuale, nodo, ambiente)
                else:
                    valore = valore_f(ambiente)
                oggetto.scrivi(bersaglio.nome, valore)
            except ErroreDante as e:
                completa(e, bersaglio)
                raise
        return lenta

    # --- se / scegli -------------------------------------------------------------

    def _i_se(self, c: _Codice, nodo: Any, ambito: tuple, livello: int) -> None:
        rami = nodo.rami
        if len(rami) > LIMITE_RAMI_ANNIDATI:
            self._se_piatto(c, nodo, ambito, livello)
            return
        contesto = "se"
        for ramo in rami:
            valore = self._espr(c, ramo.condizione, ambito, livello, ())
            if self._tipo(c, ramo.condizione, ambito) is not bool:
                verifica = c.cost(self._verifica_logico(contesto, ramo.condizione), "V")
                c.riga(livello, f"if {valore} is not True and {valore} is not False: {verifica}({valore})")
            c.riga(livello, f"if {valore}:")
            interno = self._ambito_blocco(c, ramo.corpo, ambito, livello + 1, "se")
            self._blocco(c, ramo.corpo, interno, livello + 1)
            c.riga(livello, "else:")
            livello += 1
            contesto = "altrimenti se"
        if nodo.altrimenti is not None:
            interno = self._ambito_blocco(c, nodo.altrimenti, ambito, livello, "altrimenti")
            self._blocco(c, nodo.altrimenti, interno, livello)
        else:
            c.riga(livello, "pass")

    def _se_piatto(self, c: _Codice, nodo: Any, ambito: tuple, livello: int) -> None:
        """Molti ``altrimenti se``: una funzione per condizione, rami allo stesso livello."""
        parola = "if"
        contesto = "se"
        for ramo in nodo.rami:
            condizione = c.cost(self._condizione(ramo.condizione, contesto), "Q")
            c.riga(livello, f"{parola} {condizione}({self._ambiente(c, ambito)}):")
            interno = self._ambito_blocco(c, ramo.corpo, ambito, livello + 1, "se")
            self._blocco(c, ramo.corpo, interno, livello + 1)
            parola = "elif"
            contesto = "altrimenti se"
        if nodo.altrimenti is not None:
            c.riga(livello, "else:")
            interno = self._ambito_blocco(c, nodo.altrimenti, ambito, livello + 1, "altrimenti")
            self._blocco(c, nodo.altrimenti, interno, livello + 1)

    def _condizione(self, espressione: Any, contesto: str) -> Callable:
        valuta = self.espressione(espressione)
        verifica = self._verifica_logico(contesto, espressione)

        def condizione(amb):
            valore = valuta(amb)
            if valore is True or valore is False:
                return valore
            return verifica(valore)
        return condizione

    def _i_scegli(self, c: _Codice, nodo: Any, ambito: tuple, livello: int) -> None:
        if any(type(schema) is Chiamata for caso in nodo.casi for schema in caso.schemi):
            # `caso Cerchio(r) allora` scompone una variante: lo fa l'interprete
            self._delega_istruzione(c, nodo, ambito, livello)
            return
        valore = self._espr(c, nodo.valore, ambito, livello, ())
        parola = "if"
        for caso in nodo.casi:
            prove = [self._corrisponde(c, valore, schema, ambito) for schema in caso.schemi] or ["False"]
            c.riga(livello, f"{parola} {' or '.join(prove)}:")
            interno = self._ambito_blocco(c, caso.corpo, ambito, livello + 1, "caso")
            self._blocco(c, caso.corpo, interno, livello + 1)
            parola = "elif"
        if nodo.altrimenti is not None:
            if parola == "if":
                c.riga(livello, "if True:")
            else:
                c.riga(livello, "else:")
            interno = self._ambito_blocco(c, nodo.altrimenti, ambito, livello + 1, "altrimenti")
            self._blocco(c, nodo.altrimenti, interno, livello + 1)
        elif parola != "if":
            # una variante senza il suo `caso`: errore (come l'interprete)
            from .controllo.esecuzione import nessun_caso
            nc = c.cost(self._posizionatore(nessun_caso, nodo, grezze=False), "H")
            c.riga(livello, f"else: {nc}({valore})")

    def _corrisponde(self, c: _Codice, valore: str, schema: Any, ambito: _Ambito) -> str:
        """Espressione Python che dice se ``valore`` corrisponde allo schema di un ``caso``."""
        if type(schema) is Letterale:
            k = schema.valore
            if type(k) is int:
                return f"((type({valore}) is int or type({valore}) is float) and {valore} == {_letterale_python(k) or c.cost(k)})"
            if type(k) is str:
                return f"(type({valore}) is str and {valore} == {c.cost(k)})"
        it = self.it
        completa = self.completa

        def corrisponde(v, amb):
            try:
                return it._corrisponde(v, schema, amb)
            except ErroreDante as e:
                completa(e, schema)
                raise
        h = c.cost(corrisponde, "H")
        return f"{h}({valore}, {self._ambiente(c, ambito)})"

    # --- cicli ---------------------------------------------------------------------

    def _corpo_ciclo(self, c: _Codice, corpo: list, ambito: tuple, livello: int) -> None:
        """``try: corpo except interrompi/continua`` dentro un ciclo Python."""
        c.riga(livello, "try:")
        c.blocchi += 1
        c.cicli += 1
        self._blocco(c, corpo, ambito, livello + 1)
        c.cicli -= 1
        c.blocchi -= 1
        c.riga(livello, "except SegnaleInterrompi:")
        c.riga(livello + 1, "break")
        c.riga(livello, "except SegnaleContinua:")
        c.riga(livello + 1, "continue")

    def _i_mentre(self, c: _Codice, nodo: Any, ambito: tuple, livello: int) -> None:
        from .interprete import _serve_ambito

        nuovo = _serve_ambito(nodo.corpo) or self.dichiarazione_implicita
        c.riga(livello, "while True:")
        c.blocchi += 1
        c.riga(livello + 1, "if IT._ferma_richiesta: raise SegnaleFermaProgramma()")
        valore = self._espr(c, nodo.condizione, ambito, livello + 1, ())
        if self._tipo(c, nodo.condizione, ambito) is bool:
            c.riga(livello + 1, f"if not {valore}: break")
        else:
            verifica = c.cost(self._verifica_logico("mentre", nodo.condizione), "V")
            c.riga(livello + 1, f"if {valore} is not True:")
            c.riga(livello + 2, f"if {valore} is False: break")
            c.riga(livello + 2, f"{verifica}({valore})")
        interno = self._nuovo_ambito(c, ambito, livello + 1, "mentre") if nuovo else ambito
        self._corpo_ciclo(c, nodo.corpo, interno, livello + 1)
        c.blocchi -= 1

    def _i_ripeti(self, c: _Codice, nodo: Any, ambito: tuple, livello: int) -> None:
        from .interprete import _serve_ambito

        volte = self._espr(c, nodo.volte, ambito, livello, ())
        controllo = c.cost(self._controlla_ripeti(nodo), "H")
        c.riga(livello, f"if type({volte}) is not int or {volte} < 0: {controllo}({volte})")
        nuovo = _serve_ambito(nodo.corpo) or self.dichiarazione_implicita
        c.riga(livello, f"for _ in range({volte}):")
        c.blocchi += 1
        c.riga(livello + 1, "if IT._ferma_richiesta: raise SegnaleFermaProgramma()")
        interno = self._nuovo_ambito(c, ambito, livello + 1, "ripeti") if nuovo else ambito
        self._corpo_ciclo(c, nodo.corpo, interno, livello + 1)
        c.blocchi -= 1

    def _controlla_ripeti(self, nodo: Any) -> Callable:
        completa = self.completa

        def controlla(volte):
            try:
                if not e_intero(volte):
                    raise ErroreTipo(
                        f"Il numero di ripetizioni di `ripeti` deve essere un intero, non un valore di tipo "
                        f"`{nome_tipo(volte)}`.",
                        suggerimento="Usa `intero(...)` o `arrotonda(...)`." if isinstance(volte, float) else None)
                if volte < 0:
                    raise ErroreValore(f"Il numero di ripetizioni di `ripeti` non può essere negativo (è {volte}).")
            except ErroreDante as e:
                completa(e, nodo.volte)
                raise
        return controlla

    def _i_per_ogni(self, c: _Codice, nodo: Any, ambito: tuple, livello: int) -> None:
        from .interprete import _crea_chiusure, _serve_ambito

        a, v = ambito
        sequenza = self._espr(c, nodo.iterabile, ambito, livello, ())
        nomi = getattr(nodo, "variabili", None)
        k_nomi = c.cost(nomi, "K")
        k_iterabile = c.cost(nodo.iterabile, "K")
        elementi = c.nuovo("t")
        c.riga(livello, f"{elementi} = IT._elementi({sequenza}, {k_nomi}, {k_iterabile})")
        riga = int(nodo.riga or 0)
        elemento = c.nuovo("t")
        if c.locali:
            # variabili del ciclo e del corpo: locali di Python (un blocco nuovo a ogni giro)
            giro = self._nuovo_ambito(c, ambito, livello, "per ogni")
            if nomi is None:
                elemento = self._dichiara_locale(c, giro, nodo.variabile, riga, nodo=nodo,
                                                 intero=type(nodo.iterabile) is Intervallo)
                c.riga(livello, f"for {elemento} in {elementi}:")
                c.blocchi += 1
                c.riga(livello + 1, "if IT._ferma_richiesta: raise SegnaleFermaProgramma()")
            else:
                c.riga(livello, f"for {elemento} in {elementi}:")
                c.blocchi += 1
                c.riga(livello + 1, "if IT._ferma_richiesta: raise SegnaleFermaProgramma()")
                destruttura = c.cost(self._destruttura(nomi, "`per ogni a, b in [[1, 2], [3, 4]] fai`",
                                                       nodo.iterabile), "H")
                valori = c.nuovo("t")
                c.riga(livello + 1, f"{valori} = {destruttura}({elemento})")
                for i, n in enumerate(nomi):
                    py = self._dichiara_locale(c, giro, n, riga, nodo=nodo)
                    c.riga(livello + 1, f"{py} = {valori}[{i}]")
            self._corpo_ciclo(c, nodo.corpo, giro, livello + 1)
            c.blocchi -= 1
            return
        if nomi is None and not _crea_chiusure(nodo.corpo) and not self.dichiarazione_implicita:
            # un solo ambiente riusato (come la via veloce dell'interprete)
            g, gv = self._nuovo_ambito(c, ambito, livello, "per ogni")
            voce = c.nuovo("vc")
            nome = repr(nodo.variabile)
            c.riga(livello, f"{voce} = Voce(None, False, {riga})")
            c.riga(livello, f"{gv}[{nome}] = {voce}")
            dichiara = _serve_ambito(nodo.corpo)
            c.riga(livello, f"for {elemento} in {elementi}:")
            c.blocchi += 1
            c.riga(livello + 1, "if IT._ferma_richiesta: raise SegnaleFermaProgramma()")
            if dichiara:
                c.riga(livello + 1, f"{gv}.clear()")
                c.riga(livello + 1, f"{voce} = Voce({elemento}, False, {riga})")
                c.riga(livello + 1, f"{gv}[{nome}] = {voce}")
            else:
                c.riga(livello + 1, f"{voce}.valore = {elemento}")
            self._corpo_ciclo(c, nodo.corpo, _Ambito(g, gv), livello + 1)
            c.blocchi -= 1
            return
        c.riga(livello, f"for {elemento} in {elementi}:")
        c.blocchi += 1
        c.riga(livello + 1, "if IT._ferma_richiesta: raise SegnaleFermaProgramma()")
        g, gv = self._nuovo_ambito(c, ambito, livello + 1, "per ogni")
        if nomi is None:
            c.riga(livello + 1, f"{g}.dichiara({nodo.variabile!r}, {elemento}, riga={riga})")
        else:
            destruttura = c.cost(self._destruttura(nomi, "`per ogni a, b in [[1, 2], [3, 4]] fai`",
                                                   nodo.iterabile), "H")
            valori = c.nuovo("t")
            c.riga(livello + 1, f"{valori} = {destruttura}({elemento})")
            for i, n in enumerate(nomi):
                c.riga(livello + 1, f"{g}.dichiara({n!r}, {valori}[{i}], riga={riga})")
        self._corpo_ciclo(c, nodo.corpo, _Ambito(g, gv), livello + 1)
        c.blocchi -= 1

    def _destruttura(self, nomi: list, dove: str, pos: Any) -> Callable:
        it = self.it
        completa = self.completa

        def destruttura(valore):
            try:
                return it._destruttura(valore, nomi, dove)
            except ErroreDante as e:
                completa(e, pos)
                raise
        return destruttura

    # --- salti ---------------------------------------------------------------------

    def _i_restituisci(self, c: _Codice, nodo: Any, ambito: tuple, livello: int) -> None:
        valore = "None" if nodo.valore is None else self._espr(c, nodo.valore, ambito, livello, ())
        if c.funzione:
            c.riga(livello, f"return {valore}")
        else:
            c.riga(livello, f"raise SegnaleRestituisci({valore})")

    def _i_interrompi(self, c: _Codice, nodo: Any, ambito: tuple, livello: int) -> None:
        c.riga(livello, "break" if c.cicli else "raise SegnaleInterrompi()")

    def _i_continua(self, c: _Codice, nodo: Any, ambito: tuple, livello: int) -> None:
        c.riga(livello, "continue" if c.cicli else "raise SegnaleContinua()")

    # --- prova ---------------------------------------------------------------------

    def _i_prova(self, c: _Codice, nodo: Any, ambito: tuple, livello: int) -> None:
        from .errori import TIPI_ERRORE

        for cattura in nodo.catture:  # tipi sbagliati: errore subito, come l'interprete
            if cattura.tipo_errore is not None and cattura.tipo_errore not in TIPI_ERRORE:
                h = c.cost(self._tipo_errore_sbagliato(cattura), "H")
                c.riga(livello, f"{h}()")
                return
        a, _ = ambito
        infine = nodo.infine is not None
        if infine:
            c.riga(livello, "try:")
            c.blocchi += 1
            livello += 1
        c.riga(livello, "try:")
        c.blocchi += 1
        interno = self._nuovo_ambito(c, ambito, livello + 1, "prova")
        self._blocco(c, nodo.corpo, interno, livello + 1)
        c.blocchi -= 1
        e = c.nuovo("_err")
        n = c.cost(nodo, "S")
        c.riga(livello, f"except ErroreDante as {e}:")
        c.blocchi += 2
        c.riga(livello + 1, f"if not {e}.catturabile: raise")
        c.riga(livello + 1, f"COMPLETA({e}, {n})")
        parola = "if"
        for cattura in nodo.catture:
            prova = "True" if cattura.tipo_errore is None else f"{e}.tipo == {cattura.tipo_errore!r}"
            c.riga(livello + 1, f"{parola} {prova}:")
            dentro = self._nuovo_ambito(c, ambito, livello + 2, "cattura")
            if cattura.nome_variabile and dentro.locali is not None:
                py = self._dichiara_locale(c, dentro, cattura.nome_variabile, cattura.riga)
                c.riga(livello + 2, f"{py} = {e}")
            elif cattura.nome_variabile:
                c.riga(livello + 2, f"{dentro[0]}.dichiara({cattura.nome_variabile!r}, {e}, "
                                    f"riga={int(cattura.riga or 0)})")
            self._blocco(c, cattura.corpo, dentro, livello + 2)
            c.riga(livello + 2, f"AZZERA_PILA({e})")
            parola = "elif"
        if parola == "if":
            c.riga(livello + 1, "raise")
        else:
            c.riga(livello + 1, "else:")
            c.riga(livello + 2, "raise")
        c.blocchi -= 2
        if infine:
            livello -= 1
            c.blocchi -= 1
            c.riga(livello, "finally:")
            c.blocchi += 2
            dentro = self._nuovo_ambito(c, ambito, livello + 1, "infine")
            self._blocco(c, nodo.infine, dentro, livello + 1)
            c.blocchi -= 2

    def _tipo_errore_sbagliato(self, cattura: Any) -> Callable:
        it = self.it

        def solleva():
            from .errori import TIPI_ERRORE, ErroreNome
            from .interprete import _simili

            simili = _simili(cattura.tipo_errore, list(TIPI_ERRORE))
            suggerimento = (f"Forse intendevi `{simili[0]}`?" if simili else
                            "I tipi di errore sono: " + ", ".join(f"`{t}`" for t in TIPI_ERRORE) + ".")
            raise it._posiziona(ErroreNome(f"`{cattura.tipo_errore}` non è un tipo di errore.",
                                           suggerimento=suggerimento, nome=cattura.tipo_errore), cattura)
        return solleva

    # ======================================================================
    # Espressioni
    # ======================================================================

    def _espr(self, c: _Codice, nodo: Any, ambito: tuple, livello: int, catena: tuple) -> str:
        """Scrive il codice che calcola ``nodo`` e restituisce il nome Python
        (variabile temporanea o costante) che contiene il valore."""
        tipo = type(nodo)
        if tipo is Letterale:
            testo = _letterale_python(nodo.valore)
            return testo if testo is not None else c.cost(nodo.valore)
        if tipo is Nome:
            return self._e_nome(c, nodo, ambito, livello, catena)
        metodo = self._METODI_ESPRESSIONI.get(tipo)
        if metodo is None:
            return self._delega_espressione(c, nodo, ambito, livello, catena)
        return metodo(self, c, nodo, ambito, livello, catena)

    def _delega_espressione(self, c: _Codice, nodo: Any, ambito: tuple, livello: int, catena: tuple) -> str:
        metodo = self.it._trova_metodo(nodo)
        h = c.cost(self._posizionatore(lambda amb: metodo(nodo, amb), self._pos(nodo, catena)), "H")
        t = c.nuovo("t")
        c.riga(livello, f"{t} = {h}({self._ambiente(c, ambito)})")
        return t

    def _e_nome(self, c: _Codice, nodo: Any, ambito: tuple, livello: int, catena: tuple) -> str:
        a, v = ambito
        if ambito.locali is not None:
            locale = ambito.cerca(nodo.nome)
            if locale is not None:
                # una locale di Python: nessuno puo' cambiarla tra la lettura e l'uso
                return locale.py
        copiata = c.copiate.get(nodo.nome)
        if copiata is not None:
            c.copiate_lette.add(nodo.nome)
            return copiata
        if v == "v0" and nodo.nome in c.fisse:
            # letto subito (come l'interprete): una chiamata dopo potrebbe cambiarlo
            t = c.nuovo("t")
            c.riga(livello, f"{t} = {c.fisse[nodo.nome]}.valore")
            return t
        lento = c.cost(self._nome_lento(nodo, self._pos(nodo, catena),
                                        ambito.descrizione() if ambito.locali is not None else None), "N")
        nome = repr(nodo.nome)
        t = c.nuovo("t")
        sollevata = c.sollevate.get(nodo.nome)
        prima = f"{sollevata[0]}.valore if {sollevata[0]} is not None else " if sollevata else ""
        c.riga(livello, f"{t} = {prima}_v.valore if (_v := {v}.get({nome})) is not None else "
                        f"(_v.valore if (_g := {a}.genitore) is not None and (_v := _g.voci.get({nome})) is not None "
                        f"else (_v.valore if _g is not None and (_g := _g.genitore) is not None "
                        f"and (_v := _g.voci.get({nome})) is not None else {lento}(_g, {a})))")
        return t

    def _nome_lento(self, nodo: Any, pos: Any, descrizione: tuple | None = None) -> Callable:
        """Un nome non trovato nei primi tre ambienti: cerca piu' fuori, poi (se
        non c'e') la stessa gestione dell'interprete (tolleranza, errore). In un
        blocco locale ``amb`` e' l'ultimo ambiente vero e quello completo si
        ricostruisce (``descrizione``) solo se il nome non c'e'."""
        it = self.it
        completa = self.completa
        nome = nodo.nome
        getframe = sys._getframe

        def lento(g, amb):
            if g is not None:
                a = g.genitore
                while a is not None:
                    voce = a.voci.get(nome)
                    if voce is not None:
                        return voce.valore
                    a = a.genitore
            if descrizione is not None:
                amb = _ricostruisci(descrizione, amb, getframe(1).f_locals)
            try:
                return it.visita_Nome(nodo, amb)
            except ErroreDante as e:
                completa(e, pos)
                raise
            except _PASSA:
                raise
            except Exception as e:
                raise completa(_converti(e), pos) from e
        return lento

    def _e_testo(self, c: _Codice, nodo: Any, ambito: tuple, livello: int, catena: tuple) -> str:
        catena2 = (nodo,) + catena
        rappresenta_h = c.cost(self._posizionatore(rappresenta, self._pos(nodo, catena)), "H")
        pezzi = []
        for parte in nodo.parti:
            if isinstance(parte, str):
                pezzi.append(c.cost(parte))
            else:
                valore = self._espr(c, parte, ambito, livello, catena2)
                testo = c.nuovo("t")
                if self._tipo(c, parte, ambito) is int:
                    c.riga(livello, f"{testo} = str({valore}) if NCIFRE < {valore} < CIFRE else {rappresenta_h}({valore})")
                else:
                    c.riga(livello, f"{testo} = {valore} if (_tt := type({valore})) is str else (str({valore}) "
                                    f"if _tt is int and NCIFRE < {valore} < CIFRE else {rappresenta_h}({valore}))")
                pezzi.append(testo)
        t = c.nuovo("t")
        c.riga(livello, f"{t} = ''.join(({', '.join(pezzi)}{',' if len(pezzi) == 1 else ''}))")
        return t

    def _e_lista(self, c: _Codice, nodo: Any, ambito: tuple, livello: int, catena: tuple) -> str:
        catena2 = (nodo,) + catena
        valori = [self._espr(c, e, ambito, livello, catena2) for e in nodo.elementi]
        t = c.nuovo("t")
        c.riga(livello, f"{t} = [{', '.join(valori)}]")
        return t

    def _e_dizionario(self, c: _Codice, nodo: Any, ambito: tuple, livello: int, catena: tuple) -> str:
        catena2 = (nodo,) + catena
        t = c.nuovo("t")
        c.riga(livello, f"{t} = {{}}")
        for espr_chiave, espr_valore in nodo.coppie:
            pos = self._pos(espr_chiave, catena2)
            chiave = self._espr(c, espr_chiave, ambito, livello, catena2)
            verifica = c.cost(self._posizionatore(verifica_chiave, pos, grezze=False), "H")
            c.riga(livello, f"if type({chiave}) is not str: {verifica}({chiave})")
            valore = self._espr(c, espr_valore, ambito, livello, catena2)
            scrivi = c.cost(self._posizionatore(operazioni.scrivi_indice, pos, grezze=False), "H")
            c.riga(livello, f"if type({chiave}) is str: {t}[{chiave}] = {valore}")
            c.riga(livello, f"else: {scrivi}({t}, {chiave}, {valore})")
        return t

    def _e_binaria(self, c: _Codice, nodo: Any, ambito: tuple, livello: int, catena: tuple) -> str:
        catena2 = (nodo,) + catena
        a = self._espr(c, nodo.sinistra, ambito, livello, catena2)
        b = self._espr(c, nodo.destra, ambito, livello, catena2)
        op = nodo.operatore
        lento = c.cost(self._binaria_lenta(op, self._pos(nodo, catena)), "B")
        t = c.nuovo("t")
        rami = self._rami_aritmetici(op, a, b, self._tipo(c, nodo.sinistra, ambito),
                                     self._tipo(c, nodo.destra, ambito), nodo.sinistra, nodo.destra)
        self._scrivi_rami(c, rami, t, f"{lento}({a}, {b})", livello)
        return t

    @staticmethod
    def _scrivi_rami(c: _Codice, rami: list[tuple[str, str]], t: str, lento: str, livello: int) -> None:
        if not rami:
            c.riga(livello, f"{t} = {lento}")
            return
        if rami[0][0] == "True":
            c.riga(livello, f"{t} = {rami[0][1]}")
            return
        parola = "if"
        for cond, calcolo in rami:
            c.riga(livello, f"{parola} {cond}: {t} = {calcolo}")
            parola = "elif"
        c.riga(livello, f"else: {t} = {lento}")

    @staticmethod
    def _rami_aritmetici(op: str, a: str, b: str, ta: type | None, tb: type | None, na: Any, nb: Any
                         ) -> list[tuple[str, str]]:
        """Le vie veloci di ``a op b``: coppie (condizione Python, calcolo) che danno
        esattamente il risultato di ``operazioni.binaria`` quando la condizione e' vera
        (altrimenti si passa dalla via normale, che da' anche gli errori).
        ``ta``/``tb``: tipi gia' noti; ``na``/``nb``: i nodi (per i letterali)."""
        la = na.valore if type(na) is Letterale and type(na.valore) is int else None
        lb = nb.valore if type(nb) is Letterale and type(nb.valore) is int else None

        def condizione(tipo: type) -> str | None:
            parti = []
            for nome, noto in ((a, ta), (b, tb)):
                if noto is None:
                    parte = f"type({nome}) is {tipo.__name__}"
                    if parte not in parti:  # `x * x`: un controllo solo
                        parti.append(parte)
                elif noto is not tipo:
                    return None
            return " and ".join(parti) or "True"

        def e(*parti: str) -> str:
            parti = [p for p in parti if p != "True"]
            return " and ".join(parti) or "True"

        rami: list[tuple[str, str]] = []
        if op in ("+", "-"):
            numerici = (int, float)
            if ta in numerici and tb in numerici:
                return [("True", f"{a} {op} {b}")]
            if (ta is None or ta in numerici) and (tb is None or tb in numerici):
                parti = [f"((_t{i} := type({nome})) is int or _t{i} is float)"
                         for i, (nome, noto) in enumerate(((a, ta), (b, tb))) if noto is None]
                rami.append((e(*parti), f"{a} {op} {b}"))
            if op == "+":
                # testi con testi e liste con liste (una lista nuova)
                for tipo in (str, list):
                    cond = condizione(tipo)
                    if cond is not None:
                        rami.append((cond, f"{a} + {b}"))
        elif op == "*":
            cond = condizione(int)
            if cond is not None and not (la is not None and lb is not None):
                limite = operazioni.LIMITE_BIT_POTENZA
                if lb is not None:
                    guardia = f"{a}.bit_length() <= {limite - abs(lb).bit_length()}"
                elif la is not None:
                    guardia = f"{b}.bit_length() <= {limite - abs(la).bit_length()}"
                elif a == b:
                    guardia = f"{a}.bit_length() <= {limite // 2}"
                else:
                    guardia = f"{a}.bit_length() + {b}.bit_length() <= {limite}"
                rami.append((e(cond, guardia), f"{a} * {b}"))
            cond = condizione(float)
            if cond is not None:
                rami.append((cond, f"{a} * {b}"))
        elif op in ("%", "//"):
            cond = condizione(int)
            if cond is not None:
                if lb is not None:
                    if lb != 0:
                        rami.append((cond, f"{a} {op} {b}"))
                else:
                    rami.append((e(cond, b), f"{a} {op} {b}"))
        elif op == "/":
            # tra decimali e tra interi non enormi (il risultato sta in un decimale)
            cond = condizione(float)
            if cond is not None:
                rami.append((e(cond, b), f"{a} / {b}"))
            cond = condizione(int)
            if cond is not None:
                guardia = "True" if la is not None and abs(la) < 2 ** 1000 else f"NDIVISIBILE < {a} < DIVISIBILE"
                if lb is not None:
                    if lb != 0:
                        rami.append((e(cond, guardia), f"{a} / {b}"))
                else:
                    rami.append((e(cond, b, guardia), f"{a} / {b}"))
        return rami

    def _binaria_lenta(self, op: str, pos: Any) -> Callable:
        """Il resto di ``visita_Binaria`` (valori gia' calcolati), errori in ``pos``."""
        completa = self.completa
        binaria = operazioni.binaria
        troppo_grande = operazioni.prodotto_troppo_grande

        def lenta(a, b):
            try:
                ta = type(a)
                tb = type(b)
                if (ta is int or ta is float) and (tb is int or tb is float):
                    if op == "+":
                        return a + b
                    if op == "-":
                        return a - b
                    if ta is int and tb is int:
                        if op == "*" and not troppo_grande(a, b):
                            return a * b
                        if b:
                            if op == "%":
                                return a % b
                            if op == "//":
                                return a // b
                return binaria(op, a, b)
            except ErroreDante as e:
                completa(e, pos)
                raise
            except _PASSA:
                raise
            except Exception as e:
                raise completa(_converti(e), pos) from e
        return lenta

    _NUMERICI = ("<", "<=", ">", ">=", "==", "!=")

    def _e_confronto(self, c: _Codice, nodo: Any, ambito: tuple, livello: int, catena: tuple) -> str:
        pos = self._pos(nodo, catena)
        catena2 = (nodo,) + catena
        if len(nodo.operatori) != 1:
            return self._confronto_catena(c, nodo, ambito, livello, catena)
        op = nodo.operatori[0]
        a = self._espr(c, nodo.operandi[0], ambito, livello, catena2)
        b = self._espr(c, nodo.operandi[1], ambito, livello, catena2)
        lento = c.cost(self._posizionatore(lambda x, y: operazioni.confronta(op, x, y), pos), "B")
        t = c.nuovo("t")
        if op not in self._NUMERICI:
            c.riga(livello, f"{t} = {lento}({a}, {b})")
            return t
        ta = self._tipo(c, nodo.operandi[0], ambito)
        tb = self._tipo(c, nodo.operandi[1], ambito)
        parti = []
        possibile = True
        for nome, noto, var in ((a, ta, "_ta"), (b, tb, "_tb")):
            if noto is None:
                parti.append(f"(({var} := type({nome})) is int or {var} is float)")
            elif noto is not int and noto is not float:
                possibile = False
        parola = "if"
        if possibile and not parti:  # due numeri gia' noti
            c.riga(livello, f"{t} = {a} {op} {b}")
            return t
        if possibile:
            cond = " and ".join(parti)
            c.riga(livello, f"if {cond}: {t} = {a} {op} {b}")
            parola = "elif"
        if op in ("==", "!=") and ta in (None, str) and tb in (None, str):
            parti = [f"type({nome}) is str" for nome, noto in ((a, ta), (b, tb)) if noto is None] or ["True"]
            c.riga(livello, f"{parola} {' and '.join(parti)}: {t} = {a} {op} {b}")
            parola = "elif"
        if parola == "if":
            c.riga(livello, f"{t} = {lento}({a}, {b})")
        else:
            c.riga(livello, f"else: {t} = {lento}({a}, {b})")
        return t

    def _confronto_catena(self, c: _Codice, nodo: Any, ambito: tuple, livello: int, catena: tuple) -> str:
        """``0 < x <= 10``: ogni operando si valuta una volta, con cortocircuito."""
        catena2 = (nodo,) + catena
        pos = self._pos(nodo, catena)
        confronta = c.cost(self._posizionatore(operazioni.confronta, pos), "B")
        t = c.nuovo("t")
        sinistra = self._espr(c, nodo.operandi[0], ambito, livello, catena2)
        c.riga(livello, f"{t} = True")
        profondita = livello
        for operatore, espressione in zip(nodo.operatori, nodo.operandi[1:]):
            destra = self._espr(c, espressione, ambito, profondita, catena2)
            c.riga(profondita, f"if not {confronta}({operatore!r}, {sinistra}, {destra}): {t} = False")
            c.riga(profondita, "else:")
            profondita += 1
            sinistra = destra
        c.riga(profondita, "pass")
        return t

    def _e_unaria(self, c: _Codice, nodo: Any, ambito: tuple, livello: int, catena: tuple) -> str:
        catena2 = (nodo,) + catena
        x = self._espr(c, nodo.operando, ambito, livello, catena2)
        t = c.nuovo("t")
        pos = self._pos(nodo, catena)
        completa = self.completa
        if nodo.operatore == "non":
            pos_operando = self._pos(nodo.operando, catena2)

            def non(valore):
                try:
                    try:
                        return not verifica_logico(valore, "non")
                    except ErroreTipo as e:
                        if e.suggerimento is None:
                            e.suggerimento = ("`non` vale solo per il valore subito dopo: per negare un confronto "
                                              "usa le parentesi, per esempio `non (x in lista)`.")
                        completa(e, pos_operando)
                        raise
                except ErroreDante as e:
                    completa(e, pos)
                    raise
                except _PASSA:
                    raise
                except Exception as e:
                    raise completa(_converti(e), pos) from e
            h = c.cost(non, "H")
            c.riga(livello, f"if {x} is True: {t} = False")
            c.riga(livello, f"elif {x} is False: {t} = True")
            c.riga(livello, f"else: {t} = {h}({x})")
            return t
        op = nodo.operatore
        h = c.cost(self._posizionatore(lambda v: operazioni.unaria(op, v), pos), "H")
        if op == "-":
            c.riga(livello, f"if (_ta := type({x})) is int or _ta is float: {t} = -{x}")
            c.riga(livello, f"else: {t} = {h}({x})")
        else:
            c.riga(livello, f"{t} = {h}({x})")
        return t

    def _e_logica(self, c: _Codice, nodo: Any, ambito: tuple, livello: int, catena: tuple) -> str:
        op = nodo.operatore
        if op not in ("e", "o"):
            return self._delega_espressione(c, nodo, ambito, livello, catena)
        catena2 = (nodo,) + catena
        x = self._espr(c, nodo.sinistra, ambito, livello, catena2)
        if self._tipo(c, nodo.sinistra, ambito) is not bool:
            vs = c.cost(self._verifica_logico(op, self._pos(nodo.sinistra, catena2)), "V")
            c.riga(livello, f"if {x} is not True and {x} is not False: {vs}({x})")
        t = c.nuovo("t")
        if op == "e":
            c.riga(livello, f"if not {x}: {t} = False")
        else:
            c.riga(livello, f"if {x}: {t} = True")
        c.riga(livello, "else:")
        y = self._espr(c, nodo.destra, ambito, livello + 1, catena2)
        if self._tipo(c, nodo.destra, ambito) is not bool:
            vd = c.cost(self._verifica_logico(op, self._pos(nodo.destra, catena2)), "V")
            c.riga(livello + 1, f"if {y} is not True and {y} is not False: {vd}({y})")
        c.riga(livello + 1, f"{t} = {y}")
        return t

    def _e_intervallo(self, c: _Codice, nodo: Any, ambito: tuple, livello: int, catena: tuple) -> str:
        catena2 = (nodo,) + catena
        a = self._espr(c, nodo.inizio, ambito, livello, catena2)
        b = self._espr(c, nodo.fine, ambito, livello, catena2)
        h = c.cost(self._posizionatore(crea_intervallo, self._pos(nodo, catena)), "H")
        t = c.nuovo("t")
        c.riga(livello, f"{t} = {h}({a}, {b})")
        return t

    def _e_indice(self, c: _Codice, nodo: Any, ambito: tuple, livello: int, catena: tuple) -> str:
        catena2 = (nodo,) + catena
        o = self._espr(c, nodo.oggetto, ambito, livello, catena2)
        i = self._espr(c, nodo.indice, ambito, livello, catena2)
        h = c.cost(self._posizionatore(operazioni.leggi_indice, self._pos(nodo, catena)), "H")
        t = c.nuovo("t")
        c.riga(livello, f"if (_tp := type({o})) is list and type({i}) is int and 0 <= {i} < len({o}): {t} = {o}[{i}]")
        c.riga(livello, f"elif _tp is dict and type({i}) is str and ({t} := {o}.get({i}, MANCA)) is not MANCA: pass")
        c.riga(livello, f"else: {t} = {h}({o}, {i})")
        return t

    def _e_attributo(self, c: _Codice, nodo: Any, ambito: tuple, livello: int, catena: tuple) -> str:
        catena2 = (nodo,) + catena
        o = self._espr(c, nodo.oggetto, ambito, livello, catena2)
        it = self.it
        nome = nodo.nome
        h = c.cost(self._posizionatore(lambda x: it._leggi_attributo(x, nome), self._pos(nodo, catena)), "H")
        t = c.nuovo("t")
        c.riga(livello, f"{t} = {h}({o})")
        return t

    def _e_anonima(self, c: _Codice, nodo: Any, ambito: tuple, livello: int, catena: tuple) -> str:
        it = self.it

        if ambito.locali is not None:
            raise _SenzaLocali("funzione anonima in un blocco locale")

        def crea(amb):
            f = FunzioneDante("<anonima>", nodo.parametri, nodo.corpo, amb, nodo.riga, nodo.colonna)
            f.nome_file = it._file_corrente
            if it.repl:
                it.segna_testo(f)
            return f
        h = c.cost(crea, "H")
        t = c.nuovo("t")
        c.riga(livello, f"{t} = {h}({ambito[0]})")
        return t

    def _e_lista_compresa(self, c: _Codice, nodo: Any, ambito: tuple, livello: int, catena: tuple) -> str:
        from .interprete import _crea_chiusure

        catena2 = (nodo,) + catena
        pos = self._pos(nodo, catena)
        nomi = list(nodo.variabili)
        sequenza = self._espr(c, nodo.iterabile, ambito, livello, catena2)
        it = self.it
        completa = self.completa
        iterabile = nodo.iterabile
        chiave_nomi = nomi if len(nomi) > 1 else None

        def elementi(s):
            try:
                return it._elementi(s, chiave_nomi, iterabile)
            except ErroreDante as e:
                completa(e, pos)
                raise
            except _PASSA:
                raise
            except Exception as e:
                raise completa(_converti(e), pos) from e
        h = c.cost(elementi, "H")
        el = c.nuovo("t")
        c.riga(livello, f"{el} = {h}({sequenza})")
        risultato = c.nuovo("t")
        c.riga(livello, f"{risultato} = []")
        riga = int(nodo.riga or 0)
        if c.locali:
            giro = self._nuovo_ambito(c, ambito, livello, "per ogni")
            if len(nomi) == 1:
                x = self._dichiara_locale(c, giro, nomi[0], riga, nodo=nodo,
                                          intero=type(nodo.iterabile) is Intervallo)
                c.riga(livello, f"for {x} in {el}:")
                c.blocchi += 1
                dentro = livello + 1
                c.riga(dentro, "if IT._ferma_richiesta: raise SegnaleFermaProgramma()")
            else:
                x = c.nuovo("t")
                c.riga(livello, f"for {x} in {el}:")
                c.blocchi += 1
                dentro = livello + 1
                c.riga(dentro, "if IT._ferma_richiesta: raise SegnaleFermaProgramma()")
                destruttura = self._destruttura(nomi, "`[a + b per ogni a, b in coppie]`", iterabile)
                d = c.cost(self._posizionatore(destruttura, pos), "H")
                valori = c.nuovo("t")
                c.riga(dentro, f"{valori} = {d}({x})")
                for i, n in enumerate(nomi):
                    py = self._dichiara_locale(c, giro, n, riga)
                    c.riga(dentro, f"{py} = {valori}[{i}]")
            if nodo.condizione is not None:
                valore = self._espr(c, nodo.condizione, giro, dentro, catena2)
                if self._tipo(c, nodo.condizione, giro) is bool:
                    c.riga(dentro, f"if not {valore}: continue")
                else:
                    v = c.cost(self._verifica_logico("se", self._pos(nodo.condizione, catena2)), "V")
                    c.riga(dentro, f"if {valore} is not True:")
                    c.riga(dentro + 1, f"if {valore} is False: continue")
                    c.riga(dentro + 1, f"{v}({valore})")
            y = self._espr(c, nodo.elemento, giro, dentro, catena2)
            c.riga(dentro, f"{risultato}.append({y})")
            c.blocchi -= 1
            return risultato
        x = c.nuovo("t")
        riusa = not _crea_chiusure([nodo.elemento, nodo.condizione])
        if riusa:
            g, gv = self._nuovo_ambito(c, ambito, livello, "per ogni")
        c.riga(livello, f"for {x} in {el}:")
        c.blocchi += 1
        dentro = livello + 1
        c.riga(dentro, "if IT._ferma_richiesta: raise SegnaleFermaProgramma()")
        if not riusa:
            g, gv = self._nuovo_ambito(c, ambito, dentro, "per ogni")
        if len(nomi) == 1:
            c.riga(dentro, f"{gv}[{nomi[0]!r}] = Voce({x}, False, {riga})")
        else:
            destruttura = self._destruttura(nomi, "`[a + b per ogni a, b in coppie]`", iterabile)
            d = c.cost(self._posizionatore(destruttura, pos), "H")
            valori = c.nuovo("t")
            c.riga(dentro, f"{valori} = {d}({x})")
            for i, n in enumerate(nomi):
                c.riga(dentro, f"{gv}[{n!r}] = Voce({valori}[{i}], False, {riga})")
        if nodo.condizione is not None:
            valore = self._espr(c, nodo.condizione, _Ambito(g, gv), dentro, catena2)
            v = c.cost(self._verifica_logico("se", self._pos(nodo.condizione, catena2)), "V")
            c.riga(dentro, f"if {valore} is not True:")
            c.riga(dentro + 1, f"if {valore} is False: continue")
            c.riga(dentro + 1, f"{v}({valore})")
        y = self._espr(c, nodo.elemento, _Ambito(g, gv), dentro, catena2)
        c.riga(dentro, f"{risultato}.append({y})")
        c.blocchi -= 1
        return risultato

    # --- chiamate ------------------------------------------------------------------

    def _e_chiamata(self, c: _Codice, nodo: Any, ambito: tuple, livello: int, catena: tuple) -> str:
        if nodo.catena:  # `valore |> nome`: regole speciali, le segue l'interprete
            return self._delega_espressione(c, nodo, ambito, livello, catena)
        catena2 = (nodo,) + catena
        pos = self._pos(nodo, catena)
        funzione = nodo.funzione
        metodo = None
        oggetto = None
        if type(funzione) is Attributo:
            # `oggetto.metodo(...)`: per liste, testi e dizionari niente MetodoLegato
            catena3 = (funzione,) + catena2
            oggetto = self._espr(c, funzione.oggetto, ambito, livello, catena3)
            metodo = c.nuovo("m")
            f = c.nuovo("f")
            it = self.it
            nome = funzione.nome
            leggi = c.cost(self._posizionatore(lambda x: it._leggi_attributo(x, nome),
                                               self._pos(funzione, catena2)), "H")
            memoria = not any(a.nome is not None or a.espandi for a in nodo.argomenti) and c.blocchi < 18
            if memoria:
                # memoria del punto di chiamata: tipo dell'oggetto -> metodo della libreria
                mt = c.cost(_NessunTipo, "MT")
                mm = c.cost(_MANCA, "MM")
                c.riga(livello, f"if type({oggetto}) is {mt}: {metodo} = {mm}")
                c.riga(livello, "else:")
                livello += 1
            c.riga(livello, f"_md = REGM.get(NOMI_TIPO[_tp]) if ((_tp := type({oggetto})) is list or _tp is str "
                            f"or _tp is dict) else None")
            c.riga(livello, f"{metodo} = _md.get({nome!r}) if _md is not None else None")
            c.riga(livello, f"if {metodo} is None: {f} = {leggi}({oggetto})")
            if memoria:
                livello -= 1
        else:
            f = self._espr(c, funzione, ambito, livello, catena2)
        posizionali: list[str] = []
        per_nome: list[tuple[str, str]] = []
        generica = any(a.nome is not None or a.espandi for a in nodo.argomenti)
        lista = c.nuovo("l") if generica else None
        diz = c.nuovo("d") if generica else None
        if generica:
            c.riga(livello, f"{lista} = []")
            c.riga(livello, f"{diz} = {{}}")
        visti: set[str] = set()
        for argomento in nodo.argomenti:
            valore = self._espr(c, argomento.valore, ambito, livello, catena2)
            if not generica:
                posizionali.append(valore)
            elif argomento.nome is None:
                if argomento.espandi:
                    h = c.cost(self._espandi(argomento.valore, catena2), "H")
                    c.riga(livello, f"{h}({lista}, {valore})")
                else:
                    c.riga(livello, f"{lista}.append({valore})")
            else:
                if argomento.nome in visti:
                    h = c.cost(self._posizionatore(
                        _solleva(ErroreTipo, f"L'argomento `{argomento.nome}` è scritto due volte."), pos), "H")
                    c.riga(livello, f"{h}()")
                visti.add(argomento.nome)
                c.riga(livello, f"{diz}[{argomento.nome!r}] = {valore}")
        if not generica:
            lista = f"[{', '.join(posizionali)}]"
            diz = "None"
        chiama = c.cost(self._chiamata(nodo, pos), "CH")
        t = c.nuovo("t")
        if metodo is not None and not generica and c.blocchi < 18:
            chiama_metodo = c.cost(self._chiamata_metodo(pos), "CM")
            mp = c.cost(None, "MP")
            p = c.cost(pos, "S")
            e = c.nuovo("_e")
            c.riga(livello, f"if {metodo} is {mm}:")
            c.riga(livello + 1, "if IT._ferma_richiesta: raise SegnaleFermaProgramma()")
            c.riga(livello + 1, f"try: {t} = {mp}({', '.join([oggetto] + posizionali)})")
            c.riga(livello + 1, f"except BaseException as _e: raise RIPN(_e, {p}, {mm})")
            ricorda = c.cost(self._ricorda_metodo(c.ns, len(posizionali), mt, mm, mp), "CR")
            c.riga(livello, f"elif {metodo} is not None: {t} = {ricorda}({chiama_metodo}, {oggetto}, {metodo}, "
                            f"{lista})")
            c.riga(livello, f"else: {t} = {chiama}({f}, {lista}, {diz})")
        elif metodo is not None:
            chiama_metodo = c.cost(self._chiamata_metodo(pos), "CM")
            c.riga(livello, f"if {metodo} is not None: {t} = {chiama_metodo}({oggetto}, {metodo}, {lista}, {diz})")
            c.riga(livello, f"else: {t} = {chiama}({f}, {lista}, {diz})")
        elif not generica and c.blocchi < 18:
            self._chiamata_con_memoria(c, nodo, pos, f, posizionali, chiama, t, livello)
        else:
            c.riga(livello, f"{t} = {chiama}({f}, {lista}, {diz})")
        return t

    def _chiamata_con_memoria(self, c: _Codice, nodo: Any, pos: Any, f: str, posizionali: list[str],
                              chiama: str, t: str, livello: int) -> None:
        """Chiamata ``f(a, b)`` con una memoria nel punto di chiamata.

        Quasi sempre in un punto del programma si chiama sempre la stessa
        funzione: la prima volta passa dalla via normale (``chiama``), che se la
        funzione e' una funzione Leo pura o una funzione di libreria semplice con
        questo numero di argomenti se la ricorda; dalla volta dopo basta
        confrontare l'oggetto (``is``) e chiamare direttamente la funzione Python
        che fa il lavoro, con la stessa gestione degli errori della via normale."""
        n = len(posizionali)
        kf = c.cost(_MANCA, "KF")      # funzione Leo pura ricordata
        kp = c.cost(None, "KP")        # ...e la sua funzione Python
        nf = c.cost(_MANCA, "NF")      # funzione di libreria ricordata
        np_ = c.cost(None, "NP")       # ...e la funzione Python da chiamare
        p = c.cost(pos, "S")
        gen = c.cost(self.generazione, "G")
        e = c.nuovo("_e")
        argomenti = ", ".join(posizionali)
        c.riga(livello, f"if {f} is {kf}:")
        c.riga(livello + 1, f"try: {t} = {kp}({f}{', ' + argomenti if n else ''})")
        c.riga(livello + 1, f"except BaseException as _e: raise RIP(_e, {p})")
        c.riga(livello, f"elif {f} is {nf}:")
        c.riga(livello + 1, "if IT._ferma_richiesta: raise SegnaleFermaProgramma()")
        c.riga(livello + 1, f"try: {t} = {np_}({argomenti})")
        c.riga(livello + 1, f"except BaseException as _e: raise RIPN(_e, {p}, {nf})")
        k = c.nuovo("k")
        c.riga(livello, f"elif type({f}) is FunzioneDante and ({k} := {f}._leo_p) is not None and {k}[0] is {gen} "
                        f"and {k}[2] <= {n} <= {k}[3]:")
        c.riga(livello + 1, f"try: {t} = {k}[1]({f}{', ' + argomenti if n else ''})")
        c.riga(livello + 1, f"except BaseException as _e: raise RIP(_e, {p})")
        ricorda = c.cost(self._ricorda_chiamata(c.ns, n, kf, kp, nf, np_), "CR")
        c.riga(livello, f"else: {t} = {ricorda}({chiama}, {f}, [{argomenti}])")

    def _ricorda_chiamata(self, ns: dict, n: int, kf: str, kp: str, nf: str, np_: str) -> Callable:
        """La via normale di un punto di chiamata con memoria (vedi
        :meth:`_chiamata_con_memoria`): chiama e poi, se si puo', ricorda."""
        compilatore = self
        it = self.it
        veloci = _NATIVE_VELOCI

        def ricorda(chiama, f, argomenti):
            risultato = chiama(f, argomenti, None)
            tf = type(f)
            if tf is FunzioneDante:
                k = f._leo_p
                if k is not None and k[0] is compilatore.generazione and k[2] <= n <= k[3]:
                    ns[kf] = f
                    ns[kp] = k[1]
            elif tf in veloci or (tf is not FunzioneDante and _nativa_semplice(tf)):
                m = f.__dict__.get("_memo_limiti")
                if m is not None and m[0] is not None and m[0] is f.firma and (lim := m[1]) is not None:
                    if f.vuole_interprete:
                        if lim[0] <= n + 1 <= lim[1]:
                            ns[nf] = f
                            ns[np_] = partial(f.funzione, it)
                    elif lim[0] <= n <= lim[1]:
                        ns[nf] = f
                        ns[np_] = f.funzione
            return risultato
        return ricorda

    def _ricorda_metodo(self, ns: dict, n: int, mt: str, mm: str, mp: str) -> Callable:
        """La via normale di una chiamata di metodo con memoria: chiama e poi, se il
        metodo e' una funzione di libreria semplice con questo numero di
        argomenti, ricorda il tipo dell'oggetto, il metodo e la funzione Python."""
        it = self.it
        veloci = _NATIVE_VELOCI

        def ricorda(chiama_metodo, oggetto, metodo, argomenti):
            risultato = chiama_metodo(oggetto, metodo, argomenti, None)
            tm = type(metodo)
            if tm in veloci or _nativa_semplice(tm):
                m = metodo.__dict__.get("_memo_limiti")
                if m is not None and m[0] is not None and m[0] is metodo.firma and (lim := m[1]) is not None:
                    if metodo.vuole_interprete:
                        if lim[0] <= n + 2 <= lim[1]:
                            ns[mt] = type(oggetto)
                            ns[mm] = metodo
                            ns[mp] = partial(metodo.funzione, it)
                    elif lim[0] <= n + 1 <= lim[1]:
                        ns[mt] = type(oggetto)
                        ns[mm] = metodo
                        # ``equivalente_veloce``: lo stesso metodo scritto in C (``list.append``...)
                        ns[mp] = getattr(metodo.funzione, "equivalente_veloce", None) or metodo.funzione
            return risultato
        return ricorda

    def _espandi(self, espressione: Any, catena: tuple) -> Callable:
        completa = self.completa
        pos = self._pos(espressione, catena)

        def espandi(lista, valore):
            if not isinstance(valore, (list, range)):
                raise completa(ErroreTipo(
                    f"Con `...` si passano gli elementi di una lista, non un valore di tipo "
                    f"`{nome_tipo(valore)}`.", suggerimento="Per esempio `somma(numeri...)`."), pos)
            lista.extend(valore)
        return espandi

    def _chiamata(self, nodo: Any, pos: Any) -> Callable:
        """``chiama(f, argomenti, argomenti_nome)`` per un punto di chiamata: stessa
        semantica di ``visita_Chiamata`` + ``_invoca`` + ``chiama_funzione_dante``
        (dopo la valutazione degli argomenti), errori in ``pos``."""
        it = self.it
        completa = self.completa
        compilatore = self
        nuovo_ambiente = Ambiente.__new__
        native_semplici = _NATIVE_VELOCI
        pmax = int(it.profondita_massima)  # non cambia durante un'esecuzione
        if isinstance(nodo.funzione, (Nome, Attributo)):
            descrizione = f"`{nodo.funzione.nome}`"
        else:
            descrizione = "Questo valore"

        def chiama(f, argomenti, argomenti_nome):
            try:
                if type(f) is FunzioneDante:
                    if it._lento:
                        if it._ferma_richiesta:
                            raise SegnaleFermaProgramma()
                        return it.chiama_funzione_dante(f, argomenti, argomenti_nome or {})
                    # --- chiama_funzione_dante, percorso compilato -------------
                    profondita = it.profondita
                    if profondita >= pmax:
                        raise ErroreRicorsione(_messaggio_ricorsione(f.nome))
                    d = f.__dict__
                    k = d.get("_leo_k")
                    if k is None or k[0] is not compilatore.generazione or k[1] is not f.corpo:
                        k = compilatore.prepara(f)
                    if k[6] is not None:
                        return compilatore.chiama_pura(f, k, argomenti, argomenti_nome)
                    it.profondita = profondita + 1
                    # file corrente: tracciato solo fra piu' file (vedi `_multifile`)
                    if it._multifile:
                        precedente = it._file_corrente
                        nf = d.get("nome_file")
                        if nf and nf is not precedente:
                            it._file_corrente = nf
                            ripristina_file = True
                        else:
                            ripristina_file = False
                    else:
                        ripristina_file = False
                    try:
                        # come ``f.chiusura.figlio(...)``, senza passare da __init__
                        chiusura = f.chiusura
                        ambiente = nuovo_ambiente(Ambiente)
                        ambiente.genitore = chiusura
                        ambiente.nome = k[4]
                        ambiente.voci = {}
                        ambiente.permetti_ridichiarazione = chiusura.permetti_ridichiarazione
                        if k[3] and not argomenti_nome and len(argomenti) == k[5]:
                            return k[2](ambiente, argomenti)
                        compilatore._lega(f, argomenti, argomenti_nome, ambiente)
                        return k[2](ambiente, None)
                    except SegnaleRestituisci as s:
                        return s.valore
                    except ErroreDante as e:
                        esci_da_funzione(e, f, argomenti, argomenti_nome)
                        raise
                    except RecursionError:
                        raise ErroreRicorsione(_messaggio_ricorsione(f.nome)) from None
                    finally:
                        it.profondita -= 1
                        if ripristina_file:
                            it._file_corrente = precedente
                tf = type(f)
                if tf is FunzioneNativa or tf in native_semplici or _nativa_semplice(tf):
                    # funzione di libreria: niente controlli ``isinstance`` (lenti con le ABC)
                    if it._ferma_richiesta:
                        raise SegnaleFermaProgramma()
                    try:
                        if not argomenti_nome:
                            # via veloce: argomenti posizionali in numero giusto secondo
                            # i limiti gia' calcolati da ``FunzioneNativa._limiti_posizionali``
                            m = f.__dict__.get("_memo_limiti")
                            if m is not None and m[0] is f.firma and m[0] is not None and (lim := m[1]) is not None:
                                if f.vuole_interprete:
                                    if lim[0] <= len(argomenti) + 1 <= lim[1]:
                                        return f.funzione(it, *argomenti)
                                elif lim[0] <= len(argomenti) <= lim[1]:
                                    return f.funzione(*argomenti)
                        return f.chiama(it, argomenti, argomenti_nome if argomenti_nome is not None else {})
                    except (ErroreDante, SegnaleControllo):
                        raise
                    except RecursionError:
                        raise ErroreRicorsione(_messaggio_ricorsione(getattr(f, "nome", "?"))) from None
                    except Exception as e:
                        raise _converti(e, getattr(f, "nome", "")) from e
                if not isinstance(f, Richiamabile):
                    raise ErroreTipo(f"{descrizione} non è una funzione.",
                                     suggerimento=(_SUGG_NULLA if f is None else f"È un valore di tipo `{nome_tipo(f)}`: non si può chiamare con `( )`."))
                if it._ferma_richiesta:
                    raise SegnaleFermaProgramma()
                if isinstance(f, FunzioneDante):
                    return it.chiama_funzione_dante(f, argomenti, argomenti_nome or {})
                try:
                    return f.chiama(it, argomenti, argomenti_nome if argomenti_nome is not None else {})
                except (ErroreDante, SegnaleControllo):
                    raise
                except RecursionError:
                    raise ErroreRicorsione(_messaggio_ricorsione(getattr(f, "nome", "?"))) from None
                except Exception as e:
                    raise _converti(e, getattr(f, "nome", "")) from e
            except ErroreDante as e:
                completa(e, pos)
                raise
            except _PASSA:
                raise
            except Exception as e:
                raise completa(_converti(e), pos) from e
        return chiama

    def _chiamata_metodo(self, pos: Any) -> Callable:
        """Chiamata di un metodo di libreria su lista, testo o dizionario (come
        ``MetodoLegato`` + ``_invoca``, senza creare il MetodoLegato)."""
        it = self.it
        completa = self.completa

        def chiama_metodo(oggetto, metodo, argomenti, argomenti_nome):
            try:
                if it._ferma_richiesta:
                    raise SegnaleFermaProgramma()
                try:
                    if type(metodo) in _NATIVE_VELOCI or _nativa_semplice(type(metodo)):
                        if not argomenti_nome:
                            # via veloce come in ``chiama`` (l'oggetto conta come argomento)
                            m = metodo.__dict__.get("_memo_limiti")
                            if m is not None and m[0] is metodo.firma and m[0] is not None and (lim := m[1]) is not None:
                                if metodo.vuole_interprete:
                                    if lim[0] <= len(argomenti) + 2 <= lim[1]:
                                        return metodo.funzione(it, oggetto, *argomenti)
                                elif lim[0] <= len(argomenti) + 1 <= lim[1]:
                                    return metodo.funzione(oggetto, *argomenti)
                        return metodo.chiama_su(it, oggetto, argomenti,
                                                argomenti_nome if argomenti_nome is not None else {}, chi=None)
                    return MetodoLegato(oggetto, metodo).chiama(
                        it, argomenti, argomenti_nome if argomenti_nome is not None else {})
                except (ErroreDante, SegnaleControllo):
                    raise
                except RecursionError:
                    raise ErroreRicorsione(_messaggio_ricorsione(getattr(metodo, "nome", "?"))) from None
                except Exception as e:
                    raise _converti(e, getattr(metodo, "nome", "")) from e
            except ErroreDante as e:
                completa(e, pos)
                raise
            except _PASSA:
                raise
            except Exception as e:
                raise completa(_converti(e), pos) from e
        return chiama_metodo

    def _lega(self, f: Any, argomenti: list, argomenti_nome: dict | None, ambiente: Ambiente) -> None:
        """Lega i parametri come ``chiama_funzione_dante`` dell'interprete."""
        semplice = f.__dict__.get("_semplice")
        if semplice is None:
            semplice = f._semplice = _parametri_semplici(f.parametri)
        if semplice and not argomenti_nome and len(argomenti) == len(f.parametri):
            voci = ambiente.voci
            riga = f.riga
            for p, valore in zip(f.parametri, argomenti):
                voci[p.nome] = Voce(valore, False, p.riga or riga)
            return
        if not argomenti_nome:
            # parametri senza tipo (anche con predefinito): come ``_lega_fissi``,
            # con i predefiniti compilati
            parametri = f.parametri
            n = len(argomenti)
            nomi = f.__dict__.get("_leo_nomi")
            if nomi is None:
                # nomi dei parametri se sono tutti senza tipo, non variadici e diversi
                nomi = [p.nome for p in parametri]
                if len(set(nomi)) != len(nomi) or any(p.tipo or getattr(p, "variadico", False) for p in parametri):
                    nomi = False
                f._leo_nomi = nomi
            if nomi and n <= len(parametri) and all(p.predefinito is not None for p in parametri[n:]):
                voci = ambiente.voci
                riga = f.riga
                for i, p in enumerate(parametri):
                    valore = argomenti[i] if i < n else self.espressione(p.predefinito)(ambiente)
                    voci[p.nome] = Voce(valore, False, p.riga or riga)
                return
        self.it._lega_parametri(f, argomenti, argomenti_nome or {}, ambiente)

    def prepara(self, f: Any) -> tuple:
        """Dati della chiamata veloce di ``f``, ricordati sulla funzione stessa:
        ``(generazione, corpo, unita, lega, nome_ambiente, numero_parametri, pura)``.

        ``pura`` (vedi :meth:`pura`) e' la via piu' veloce: se c'e', ``unita`` non
        si usa. Per le chiamate scritte nel codice generato c'e' anche
        ``f._leo_p = (generazione, pura, numero_parametri)`` (``None`` se la
        funzione non e' pura): basta un confronto per sapere se si puo' usare."""
        pura = self.pura(f.corpo, f.parametri)
        minimo = len(f.parametri)
        if pura is not None:
            u = None
            lega, minimo = _posizionale_veloce(f.parametri)
            f._leo_p = (self.generazione, pura, minimo, len(f.parametri)) if lega else None
        else:
            u, lega = self.corpo(f.corpo, f.parametri)
            f._leo_p = None
        k = (self.generazione, f.corpo, u, lega, "funzione " + f.nome, len(f.parametri), pura, minimo)
        f.__dict__["_leo_k"] = k
        return k

    def chiama_pura(self, f: Any, k: tuple, argomenti: list, argomenti_nome: dict | None) -> Any:
        """Chiamata di una funzione pura con argomenti qualsiasi: se non sono gia'
        i parametri nell'ordine giusto, si legano come fa l'interprete (predefiniti,
        tipi, argomenti per nome, variadici) e poi si passano alla funzione pura."""
        pura = k[6]
        if k[3] and not argomenti_nome and k[7] <= len(argomenti) <= k[5]:
            return pura(f, *argomenti)
        it = self.it
        if it._ferma_richiesta:
            raise SegnaleFermaProgramma()
        if not it._veloce:
            return it.chiama_funzione_dante(f, argomenti, argomenti_nome or {})
        profondita = it.profondita
        if profondita >= it.profondita_massima:
            raise ErroreRicorsione(_messaggio_ricorsione(f.nome))
        it.profondita = profondita + 1
        if it._multifile:  # file corrente: solo fra piu' file (vedi `_multifile`)
            precedente = it._file_corrente
            nf = f.nome_file
            if nf and nf is not precedente:
                it._file_corrente = nf
                ripristina_file = True
            else:
                ripristina_file = False
        else:
            ripristina_file = False
        try:
            chiusura = f.chiusura
            ambiente = _nuovo_ambiente(Ambiente)
            ambiente.genitore = chiusura
            ambiente.nome = k[4]
            ambiente.voci = {}
            ambiente.permetti_ridichiarazione = chiusura.permetti_ridichiarazione
            self._lega(f, argomenti, argomenti_nome, ambiente)
            voci = ambiente.voci
            valori = [voci[p.nome].valore for p in f.parametri]
        except ErroreDante as e:
            esci_da_funzione(e, f, argomenti, argomenti_nome)
            raise
        except RecursionError:
            raise ErroreRicorsione(_messaggio_ricorsione(f.nome)) from None
        finally:
            it.profondita -= 1
            if ripristina_file:
                it._file_corrente = precedente
        return pura(f, *valori, argomenti, argomenti_nome)

    def chiama_dante(self, f: Any, argomenti: list, argomenti_nome: dict | None) -> Any:
        """``Interprete.chiama_funzione_dante`` nel percorso compilato (dopo il
        controllo dello stop): stessa semantica, meno passaggi."""
        it = self.it
        profondita = it.profondita
        if profondita >= it.profondita_massima:
            raise ErroreRicorsione(_messaggio_ricorsione(f.nome))
        d = f.__dict__
        k = d.get("_leo_k")
        if k is None or k[0] is not self.generazione or k[1] is not f.corpo:
            k = self.prepara(f)
        if k[6] is not None:
            return self.chiama_pura(f, k, argomenti, argomenti_nome)
        it.profondita = profondita + 1
        if it._multifile:  # file corrente: solo fra piu' file (vedi `_multifile`)
            precedente = it._file_corrente
            nf = d.get("nome_file")
            if nf and nf is not precedente:
                it._file_corrente = nf
                ripristina_file = True
            else:
                ripristina_file = False
        else:
            ripristina_file = False
        try:
            chiusura = f.chiusura
            ambiente = _nuovo_ambiente(Ambiente)
            ambiente.genitore = chiusura
            ambiente.nome = k[4]
            ambiente.voci = {}
            ambiente.permetti_ridichiarazione = chiusura.permetti_ridichiarazione
            if k[3] and not argomenti_nome and len(argomenti) == k[5]:
                return k[2](ambiente, argomenti)
            self._lega(f, argomenti, argomenti_nome, ambiente)
            return k[2](ambiente, None)
        except SegnaleRestituisci as s:
            return s.valore
        except ErroreDante as e:
            esci_da_funzione(e, f, argomenti, argomenti_nome)
            raise
        except RecursionError:
            raise ErroreRicorsione(_messaggio_ricorsione(f.nome)) from None
        finally:
            it.profondita -= 1
            if ripristina_file:
                it._file_corrente = precedente

    _METODI_ISTRUZIONI: dict = {}
    _METODI_ESPRESSIONI: dict = {}


#: tipo -> la via veloce delle funzioni native vale anche per lui?
_NATIVE_SEMPLICI: dict[type, bool] = {FunzioneNativa: True}
#: I tipi per cui :func:`_nativa_semplice` e' vera (controllo piu' rapido).
_NATIVE_VELOCI: set[type] = {FunzioneNativa}


def _posizionale_veloce(parametri: list) -> tuple[bool, int]:
    """``(si', minimo)``: i parametri si legano per posizione senza controlli
    (niente tipi, niente variadici) e bastano ``minimo`` argomenti (dopo, tutti
    hanno un predefinito)."""
    if any(p.tipo or getattr(p, "variadico", False) for p in parametri):
        return False, len(parametri)
    minimo = 0
    for i, p in enumerate(parametri):
        if p.predefinito is None:
            minimo = i + 1
    return True, minimo


def _nativa_semplice(tipo: type) -> bool:
    """Vero per :class:`FunzioneNativa` e per le sottoclassi che non cambiano
    il modo di chiamare e di controllare gli argomenti (``NativaLibreria``)."""
    esito = _NATIVE_SEMPLICI.get(tipo)
    if esito is None:
        esito = _NATIVE_SEMPLICI[tipo] = issubclass(tipo, FunzioneNativa) and all(
            getattr(tipo, n) is getattr(FunzioneNativa, n)
            for n in ("chiama", "chiama_su", "_controlla_argomenti", "_limiti_posizionali"))
        if esito:
            _NATIVE_VELOCI.add(tipo)
    return esito


def _solleva(classe: type, messaggio: str) -> Callable:
    def solleva():
        raise classe(messaggio)
    return solleva


Compilatore._METODI_ISTRUZIONI = {
    IstruzioneEspressione: None,  # gestita direttamente in _istruzione
    Dichiarazione: Compilatore._i_dichiarazione,
    DefinizioneFunzione: Compilatore._i_definizione,
    Assegnazione: Compilatore._i_assegnazione,
    Se: Compilatore._i_se,
    Scegli: Compilatore._i_scegli,
    Mentre: Compilatore._i_mentre,
    Ripeti: Compilatore._i_ripeti,
    PerOgni: Compilatore._i_per_ogni,
    Restituisci: Compilatore._i_restituisci,
    Interrompi: Compilatore._i_interrompi,
    Continua: Compilatore._i_continua,
    Prova: Compilatore._i_prova,
}
Compilatore._METODI_ISTRUZIONI[IstruzioneEspressione] = Compilatore._i_restituisci  # segnaposto (mai usato)

Compilatore._METODI_ESPRESSIONI = {
    TestoInterpolato: Compilatore._e_testo,
    ListaLetterale: Compilatore._e_lista,
    DizionarioLetterale: Compilatore._e_dizionario,
    Binaria: Compilatore._e_binaria,
    Unaria: Compilatore._e_unaria,
    Logica: Compilatore._e_logica,
    Confronto: Compilatore._e_confronto,
    Intervallo: Compilatore._e_intervallo,
    Chiamata: Compilatore._e_chiamata,
    Indice: Compilatore._e_indice,
    Attributo: Compilatore._e_attributo,
    FunzioneAnonima: Compilatore._e_anonima,
    ListaCompresa: Compilatore._e_lista_compresa,
}
