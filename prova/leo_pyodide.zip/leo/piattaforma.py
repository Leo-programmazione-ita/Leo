"""Su quale piattaforma gira Leo (PC oppure app Android).

API:
    e_android() -> bool                  # Leo gira dentro l'app Android (Chaquopy)
    non_su_android(nome_funzione)        # ErroreValore chiaro se siamo su Android
    MESSAGGIO_ANDROID                    # "`{nome}` non è disponibile su Android."

Come si capisce di essere su Android, nell'ordine:

1. la variabile d'ambiente ``LEO_PIATTAFORMA`` (la imposta l'app): ``android``
   = si'; qualsiasi altro valore non vuoto (``pc``, ``windows``...) = no;
2. ``sys.platform == "android"`` (Python 3.13 e successivi su Android);
3. Chaquopy: c'e' ``ANDROID_ROOT`` tra le variabili d'ambiente e il modulo
   ``java`` che Chaquopy fornisce.

Niente qui importa Qt, tkinter o moduli di Windows; su PC (Windows, Linux,
macOS) :func:`e_android` e' sempre falso e il comportamento non cambia.
Per i test: ``SOSTITUTI["android"] = True`` finge di essere su Android.
"""

from __future__ import annotations

import os
import sys
from typing import Any

from . import variabile_ambiente

#: Sostituti usati dai test (vuoto = comportamento reale).
SOSTITUTI: dict[str, Any] = {}

MESSAGGIO_ANDROID = "`{nome}` non è disponibile su Android."
SUGGERIMENTO_ANDROID = ("Questa funzione usa parti del computer (finestre, suoni, programmi di Windows...) "
                        "che nell'app per telefono non ci sono. Prova il programma su un computer.")

_CHAQUOPY: bool | None = None


def _chaquopy() -> bool:
    global _CHAQUOPY
    if _CHAQUOPY is None:
        presente = False
        if "ANDROID_ROOT" in os.environ and "ANDROID_DATA" in os.environ:
            try:
                import importlib.util

                presente = importlib.util.find_spec("java") is not None
            except (ImportError, ValueError):
                presente = False
        _CHAQUOPY = presente
    return _CHAQUOPY


def e_android() -> bool:
    """Vero se Leo gira nell'app Android (vedi l'ordine nel docstring del modulo)."""
    if "android" in SOSTITUTI:
        return bool(SOSTITUTI["android"])
    scelta = (variabile_ambiente("PIATTAFORMA") or "").strip().lower()
    if scelta:
        return scelta == "android"
    if sys.platform == "android":
        return True
    return _chaquopy()


def errore_android(nome_funzione: str):
    """L'``ErroreValore`` "`nome` non è disponibile su Android." (da sollevare)."""
    from .errori import ErroreValore

    return ErroreValore(MESSAGGIO_ANDROID.format(nome=nome_funzione), suggerimento=SUGGERIMENTO_ANDROID)


def non_su_android(nome_funzione: str) -> None:
    """Si ferma con ``ErroreValore`` chiaro se siamo su Android; altrimenti non fa niente."""
    if e_android():
        raise errore_android(nome_funzione)
