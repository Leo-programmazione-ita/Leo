"""Sinonimi ammessi delle parole chiave (livello 2) - CONTRATTO CONDIVISO.

Formato di ``dati/sinonimi.toml`` (e dei ``sinonimi.toml`` di progetto, oppure
della sezione ``[sinonimi]`` di ``progetto.toml``)::

    [sinonimi]
    se = ["qualora", "nel caso"]
    "altrimenti" = ["sennò", "in caso contrario"]

La chiave e' la forma canonica (anche di piu' parole, tra virgolette); il
valore e' l'elenco dei sinonimi, ognuno di una o piu' parole separate da spazi.

API:
    carica_sinonimi(extra=(), *, rigoroso=False, dizionari_extra=()) -> Sinonimi
    Sinonimi.mappa: dict[tuple[str, ...], TipoToken]   # parole -> tipo canonico
    Sinonimi.tipo_di(parole: tuple[str, ...]) -> TipoToken | None
    Sinonimi.lunghezza_massima -> int                  # parole nella sequenza piu' lunga
    Sinonimi.sinonimi_di(tipo) -> list[str]
    Sinonimi.canonica_di(testo: str) -> str | None    # "finché" -> "mentre"
    Sinonimi.vuoti() -> Sinonimi                       # per --rigoroso
    azzera_cache()                                     # rilegge dati/sinonimi.toml

Regole di validita' (ErroreValore se violate): un sinonimo non puo' essere una
parola chiave canonica ne' essere associato a due parole chiave diverse.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Iterable

from .errori import ErroreValore
from .percorsi import file_dati
from .tokens import TipoToken, tipo_da_canonica, PAROLE_CHIAVE
from .tomlutil import carica_toml


def _normalizza(parola: str) -> str:
    """``e'`` -> ``è``; minuscole NON forzate (Leo distingue maiuscole)."""
    return "è" if parola == "e'" else parola


@dataclass
class Sinonimi:
    mappa: dict[tuple[str, ...], TipoToken] = field(default_factory=dict)

    @classmethod
    def vuoti(cls) -> "Sinonimi":
        return cls({})

    @property
    def lunghezza_massima(self) -> int:
        return max((len(k) for k in self.mappa), default=0)

    def tipo_di(self, parole: tuple[str, ...]) -> TipoToken | None:
        return self.mappa.get(tuple(_normalizza(p) for p in parole))

    def sinonimi_di(self, tipo: TipoToken) -> list[str]:
        return [" ".join(k) for k, t in self.mappa.items() if t is tipo]

    def canonica_di(self, testo: str) -> str | None:
        tipo = self.tipo_di(tuple(testo.split()))
        return tipo.value if tipo else None

    def aggiungi(self, canonica: str, sinonimi: Iterable[str], fonte: str = "") -> None:
        tipo = tipo_da_canonica(canonica)
        dove = f" in {fonte}" if fonte else ""
        if tipo is None:
            raise ErroreValore(f"`{canonica}` non è una parola chiave di Leo{dove}.")
        for s in sinonimi:
            parole = tuple(_normalizza(p) for p in str(s).split())
            if not parole:
                continue
            if len(parole) == 1 and parole[0] in PAROLE_CHIAVE:
                raise ErroreValore(
                    f"`{s}` è già una parola chiave: non può essere sinonimo di `{canonica}`{dove}.")
            gia = self.mappa.get(parole)
            if gia is not None and gia is not tipo:
                raise ErroreValore(
                    f"`{s}` è già sinonimo di `{gia.value}`: non può esserlo anche di `{canonica}`{dove}.")
            self.mappa[parole] = tipo

    def aggiungi_da_dizionario(self, dati: dict, fonte: str = "") -> None:
        sezione = dati.get("sinonimi", dati)
        for canonica, elenco in sezione.items():
            if isinstance(elenco, str):
                elenco = [elenco]
            self.aggiungi(canonica, elenco, fonte)


#: Cache dei sinonimi di sistema: (percorso, mtime_ns, dimensione) -> mappa.
_CACHE_SISTEMA: tuple[tuple, dict[tuple[str, ...], TipoToken]] | None = None


def _mappa_di_sistema() -> dict[tuple[str, ...], TipoToken]:
    """Sinonimi di ``dati/sinonimi.toml``, letti una volta sola finche' il file
    non cambia (il lexer li chiede per ogni sorgente). Restituisce una copia.
    Gli errori del file (sinonimo che e' una parola chiave, doppione) vengono
    sollevati ogni volta, come senza cache."""
    global _CACHE_SISTEMA
    sistema = file_dati("sinonimi.toml")
    try:
        if not sistema.is_file():
            return {}
        st = sistema.stat()
    except OSError:
        return {}
    firma = (str(sistema), st.st_mtime_ns, st.st_size)
    if _CACHE_SISTEMA is None or _CACHE_SISTEMA[0] != firma:
        s = Sinonimi()
        s.aggiungi_da_dizionario(carica_toml(sistema), fonte=str(sistema))
        _CACHE_SISTEMA = (firma, s.mappa)
    return dict(_CACHE_SISTEMA[1])


def azzera_cache() -> None:
    """Dimentica i sinonimi di sistema letti (per i test)."""
    global _CACHE_SISTEMA
    _CACHE_SISTEMA = None


def carica_sinonimi(
    extra: Iterable[str | os.PathLike] = (),
    *,
    rigoroso: bool = False,
    dizionari_extra: Iterable[dict] = (),
) -> Sinonimi:
    """Sinonimi di sistema + eventuali file/dizionari di progetto.

    Con ``rigoroso=True`` restituisce sempre un insieme vuoto.
    Se ``dati/sinonimi.toml`` manca, si parte da un insieme vuoto.
    """
    s = Sinonimi()
    if rigoroso:
        return s
    s.mappa.update(_mappa_di_sistema())
    for percorso in extra:
        s.aggiungi_da_dizionario(carica_toml(percorso), fonte=os.fspath(percorso))
    for d in dizionari_extra:
        s.aggiungi_da_dizionario(d, fonte="progetto.toml")
    return s
