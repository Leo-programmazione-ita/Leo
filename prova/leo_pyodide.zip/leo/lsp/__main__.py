"""`python -m leo.lsp` equivale a `leo lsp`."""

import sys

from . import comando_lsp

if __name__ == "__main__":
    sys.exit(comando_lsp(sys.argv[1:]))
