"""Diagnostica mentre scrivi: errori del parser, correzioni sicure e avvisi.

Tutto viene dai motori che usa gia' Leo (riga di comando, Studio, telefono):

* l'**errore di sintassi** e' quello del parser (``leo.esecuzione.analizza``
  con ``recupero=True``), con il suo messaggio italiano e il suggerimento;
* le **correzioni** vengono da ``leo.correzioni.proponi_correzioni``, che le
  restituisce solo se il file corretto passa il parser: sono quindi *sicure*
  e diventano "correzioni rapide" (quick fix) dell'editor. Le forme che Leo
  capisce comunque (``se x fai``, ``rosso`` senza virgolette) arrivano da
  ``proponi_correzioni`` come correzioni facoltative: diventano informazioni,
  con la loro correzione;
* se il motore delle correzioni non arriva a un file valido, si prova la
  correzione allegata all'errore e la "riga corretta proposta" dei messaggi
  (``leo.errori_umani.riga_corretta``), ma si propongono solo se dopo la
  correzione quella riga passa il parser (mai una riga che non passa);
* gli avvisi del **controllo statico** (``leo controlla``) si aggiungono
  attraverso :mod:`leo.lsp.controllo_statico`.

API::

    diagnostica(sorgente, nome_file, opzioni_lessico=None, *, controlli=None,
                statico=True) -> Diagnosi
    intervallo_correzione(sorgente, correzione) -> (riga, colonna, riga_fine, colonna_fine, testo)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping

__all__ = ["Avviso", "Diagnosi", "diagnostica", "intervallo_correzione", "GRAVITA"]

#: Gravita' dei messaggi -> ``DiagnosticSeverity`` del protocollo.
GRAVITA = {"errore": 1, "avviso": 2, "informazione": 3, "suggerimento": 4}


@dataclass
class Avviso:
    """Un messaggio dell'editor. Righe e colonne di Leo (da 1, caratteri)."""

    riga: int
    colonna: int
    riga_fine: int
    colonna_fine: int
    messaggio: str
    gravita: str = "errore"
    codice: str = ""
    fonte: str = "leo"
    correzioni: list = field(default_factory=list)          # leo.errori.Correzione
    da_confermare: bool = False


@dataclass
class Diagnosi:
    avvisi: list[Avviso] = field(default_factory=list)
    #: correzioni sicure da applicare tutte insieme ("Correggi tutto")
    correggi_tutto: list = field(default_factory=list)
    analizzabile: bool = True


# ---------------------------------------------------------------------------
# Posizioni delle correzioni
# ---------------------------------------------------------------------------

def intervallo_correzione(sorgente: str, c: Any) -> tuple[int, int, int, int, str]:
    """(riga, colonna, riga_fine, colonna_fine, testo nuovo) di una ``Correzione`` su ``sorgente``.

    Solleva ``ValueError`` se la correzione non corrisponde al testo.
    """
    from ..correzioni import _inizi_righe, _intervallo, _riga_colonna

    inizi = _inizi_righe(sorgente)
    inizio, fine, dopo = _intervallo(sorgente, c, inizi)
    r1, c1 = _riga_colonna(sorgente, inizio, inizi)
    r2, c2 = _riga_colonna(sorgente, fine, inizi)
    return r1, c1, r2, c2, dopo


def _zona_da_segnare(sorgente: str, righe: list[str], c: Any) -> tuple[int, int, int, int]:
    """Dove sottolineare una correzione: il testo che cambia, oppure (inserimento)
    la riga interessata, senza il rientro."""
    try:
        r1, c1, r2, c2, _dopo = intervallo_correzione(sorgente, c)
    except Exception:  # noqa: BLE001
        r1, c1, r2, c2 = c.riga, c.colonna, c.riga, c.colonna + len(c.prima or "")
    if (r1, c1) != (r2, c2):
        return r1, c1, r2, c2
    riga = r1
    if c1 == 1 and str(c.dopo).endswith("\n") and riga > 1:
        riga -= 1                                    # riga nuova (es. `fine`): si segna quella sopra
    riga = max(1, min(riga, len(righe)))
    while riga > 1 and not righe[riga - 1].strip():
        riga -= 1
    testo = righe[riga - 1] if righe else ""
    if not testo.strip():
        return riga, 1, riga, 1
    inizio = len(testo) - len(testo.lstrip()) + 1
    return riga, inizio, riga, len(testo.rstrip()) + 1


# ---------------------------------------------------------------------------
# Analisi
# ---------------------------------------------------------------------------

def _analizza(sorgente: str, nome_file: str, opzioni: dict[str, Any]):
    from ..esecuzione import analizza

    return analizza(sorgente, nome_file, recupero=True, **opzioni)


def _primo_errore(sorgente: str, nome_file: str, opzioni: dict[str, Any]):
    from ..errori import ErroreDante

    try:
        _analizza(sorgente, nome_file, opzioni)
        return None
    except ErroreDante as e:
        return e
    except RecursionError:
        return None


def _correzione_sicura(sorgente: str, nome_file: str, opzioni: dict[str, Any], c: Any, riga: int) -> bool:
    """Vero se dopo ``c`` il file passa il parser, o almeno il primo errore e' piu' avanti di ``riga``."""
    from ..correzioni import applica_correzioni

    try:
        nuovo = applica_correzioni(sorgente, [c])
    except Exception:  # noqa: BLE001
        return False
    if nuovo == sorgente:
        return False
    errore = _primo_errore(nuovo, nome_file, opzioni)
    if errore is None:
        return True
    delta = nuovo.count("\n") - sorgente.count("\n")
    return int(getattr(errore, "riga", 0) or 0) > riga + max(0, delta)


def _correzione_da_riga(righe: list[str], proposta: tuple[int, str, str]):
    from ..errori import Correzione

    numero, prima, dopo = proposta
    if not 1 <= numero <= len(righe):
        return None
    attuale = righe[numero - 1]
    rientro = attuale[:len(attuale) - len(attuale.lstrip())]
    corpo = attuale[len(rientro):]
    nuovo = str(dopo).strip()
    if not nuovo or nuovo == corpo.strip():
        return None
    return Correzione(numero, len(rientro) + 1, corpo.rstrip(), nuovo,
                      "riga corretta proposta da Leo")


def _testo_errore(e: Any) -> str:
    messaggio = str(getattr(e, "messaggio", "") or e).strip()
    suggerimento = str(getattr(e, "suggerimento", "") or "").strip()
    if suggerimento and suggerimento not in messaggio:
        messaggio = f"{messaggio}\n{suggerimento}"
    return messaggio


def _chiave(c: Any) -> tuple:
    return (c.riga, c.colonna, c.prima, c.dopo)


def diagnostica(sorgente: str, nome_file: str = "<editor>", opzioni: Mapping[str, Any] | None = None, *,
                controlli: Mapping[str, str | None] | None = None, statico: bool = True,
                completa: bool = True) -> Diagnosi:
    """Tutti i messaggi per ``sorgente`` (mai eccezioni).

    ``completa=False``: solo l'errore del parser con la sua correzione (veloce, si
    mostra subito); la diagnosi completa (motore delle correzioni, forme
    facoltative, controllo statico) puo' richiedere qualche decimo di secondo sui
    file lunghi e il server la calcola in sottofondo.
    """
    from ..correzioni import _da_confermare, proponi_correzioni

    opzioni = dict(opzioni or {})
    sorgente = sorgente or ""
    righe = sorgente.split("\n")
    diagnosi = Diagnosi()
    errore = _primo_errore(sorgente, nome_file, opzioni)
    diagnosi.analizzabile = errore is None
    correzioni: list = []
    if completa:
        try:
            correzioni = proponi_correzioni(sorgente, nome_file, controlli=dict(controlli or {}), **opzioni)
        except Exception:  # noqa: BLE001 - le correzioni sono un aiuto, mai un ostacolo
            correzioni = []
    usate: set[tuple] = set()

    if errore is not None:
        riga = int(getattr(errore, "riga", 0) or 0) or 1
        colonna = int(getattr(errore, "colonna", 0) or 0) or 1
        lunghezza = max(1, int(getattr(errore, "lunghezza", 1) or 1))
        testo_riga = righe[riga - 1] if 1 <= riga <= len(righe) else ""
        if colonna > len(testo_riga):
            # errore a fine riga (manca qualcosa): si segna l'ultima parola
            colonna = max(1, len(testo_riga.rstrip()))
            lunghezza = 1
        avviso = Avviso(riga, colonna, riga, min(colonna + lunghezza, len(testo_riga) + 1) or colonna + 1,
                        _testo_errore(errore), "errore", str(getattr(errore, "tipo", "") or type(errore).__name__))
        # correzioni sicure sulla riga dell'errore
        for c in correzioni:
            if c.riga == riga and not c.facoltativa:
                avviso.correzioni.append(c)
                usate.add(_chiave(c))
        if not avviso.correzioni:
            candidate = list(getattr(errore, "correzioni", None) or [])
            try:
                from ..errori_umani import riga_corretta

                proposta = riga_corretta(errore, sorgente)
            except Exception:  # noqa: BLE001
                proposta = None
            if proposta:
                da_riga = _correzione_da_riga(righe, proposta)
                if da_riga is not None:
                    candidate.append(da_riga)
            for c in candidate:
                if _correzione_sicura(sorgente, nome_file, opzioni, c, riga):
                    avviso.correzioni.append(c)
                    break
        diagnosi.avvisi.append(avviso)

    for c in correzioni:
        if _chiave(c) in usate:
            continue
        usate.add(_chiave(c))
        r1, c1, r2, c2 = _zona_da_segnare(sorgente, righe, c)
        codice = "forma" if c.facoltativa else "correzione"
        if c.facoltativa:
            gravita = "informazione"
        elif errore is not None:
            gravita = "errore"
        else:
            gravita = "avviso"
        motivo = str(c.motivo or "correzione proposta").strip()
        diagnosi.avvisi.append(Avviso(r1, c1, r2, c2, _maiuscola(motivo), gravita, codice,
                                      correzioni=[c] + list(c.alternative or []),
                                      da_confermare=_da_confermare(c)))

    diagnosi.correggi_tutto = [c for c in correzioni if not c.facoltativa and not _da_confermare(c)]

    if statico and completa:
        try:
            from .controllo_statico import esegui_controlli

            diagnosi.avvisi.extend(esegui_controlli(sorgente, nome_file, opzioni, analizzabile=errore is None))
        except Exception:  # noqa: BLE001
            pass
    diagnosi.avvisi.sort(key=lambda a: (a.riga, a.colonna))
    return diagnosi


def _maiuscola(testo: str) -> str:
    return testo[:1].upper() + testo[1:] if testo else testo
