"""Server del linguaggio Leo (Language Server Protocol) per gli editor esterni.

``leo lsp`` avvia il server su stdin/stdout; l'estensione per Visual Studio Code
e' in ``strumenti/vscode``; le istruzioni per gli altri editor in
``docs/EDITOR_ESTERNI.md``. Solo libreria standard di Python.

Moduli:

* :mod:`leo.lsp.protocollo`  JSON-RPC con intestazioni ``Content-Length``;
* :mod:`leo.lsp.documenti`   documenti aperti, posizioni UTF-16 <-> colonne di Leo;
* :mod:`leo.lsp.simboli`     dichiarazioni, usi, ambiti e blocchi (dai token);
* :mod:`leo.lsp.diagnostica` errori del parser, correzioni sicure, avvisi;
* :mod:`leo.lsp.controllo_statico` aggancio per ``leo controlla``;
* :mod:`leo.lsp.lingua`      completamento, descrizioni, firme, rinomina, struttura...;
* :mod:`leo.lsp.server`      il server vero e proprio.
"""

from __future__ import annotations

__all__ = ["comando_lsp"]


def comando_lsp(argv: list[str] | None = None) -> int:
    """Punto d'ingresso di ``leo lsp``."""
    from .server import avvia

    return avvia(list(argv or []))
