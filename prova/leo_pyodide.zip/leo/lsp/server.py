"""Il server del linguaggio Leo (Language Server Protocol 3.17) su stdin/stdout.

Avvio: ``leo lsp`` (oppure ``python -m leo lsp`` / ``python -m leo.lsp``).
Funziona con qualunque editor che parla LSP: Visual Studio Code (estensione in
``strumenti/vscode``), Neovim, Sublime Text, Helix, Emacs, gli IDE JetBrains.
Istruzioni: ``docs/EDITOR_ESTERNI.md``.

Funzioni offerte:

* diagnostica mentre scrivi (errori del parser con i messaggi italiani di Leo,
  correzioni sicure come correzioni rapide, avvisi del controllo statico);
* completamento con frammenti, descrizione al passaggio del mouse, firma della
  chiamata, vai alla definizione, riferimenti, evidenziazione, rinomina,
  struttura del documento, piegatura, formattazione, colorazione semantica;
* comandi ``leo.eseguiFile`` (esegue il file e ne riporta l'uscita) e
  ``leo.correggiTutto`` (applica tutte le correzioni sicure).

Un solo thread lavora sui documenti; un secondo thread legge i messaggi, cosi'
la diagnostica si calcola solo quando chi scrive si ferma un attimo (300 ms) e
le richieste annullate (``$/cancelRequest``) non si calcolano nemmeno.
Niente esce su stdout tranne il protocollo: le ``print`` finiscono su stderr,
che gli editor mostrano nel registro del server.
"""

from __future__ import annotations

import os
import queue
import subprocess
import sys
import threading
import time
import traceback
from typing import Any, BinaryIO, Callable

from .documenti import Codifica, Documento, uri_a_percorso
from .protocollo import (
    INTERNAL_ERROR, INVALID_PARAMS, INVALID_REQUEST, METHOD_NOT_FOUND, PARSE_ERROR, REQUEST_CANCELLED,
    REQUEST_FAILED, SERVER_NOT_INITIALIZED, ErroreRPC, MessaggioIllegibile, leggi_messaggio, scrivi_messaggio,
)

__all__ = ["ServerLeo", "avvia", "COMANDI", "ATTESA_DIAGNOSTICA"]

#: Pausa (secondi) dopo l'ultima modifica prima di ricalcolare la diagnostica.
ATTESA_DIAGNOSTICA = 0.3

#: Comandi eseguibili con ``workspace/executeCommand``.
COMANDI = ("leo.eseguiFile", "leo.correggiTutto")

_FINE = object()


def _versione() -> str:
    try:
        from .. import __version__

        return str(__version__)
    except Exception:  # noqa: BLE001
        return "?"


class _Stato:
    """Cio' che il server ricorda di un documento (ricalcolato quando cambia)."""

    def __init__(self, doc: Documento) -> None:
        self.doc = doc
        self.versione_analisi: int | None = None
        self.analisi = None
        self.segmenti: list | None = None
        self.diagnosi = None
        self.versione_diagnosi: int | None = None
        self.diagnosi_completa = False
        self.rifare = False
        self.diagnostiche_lsp: list[dict[str, Any]] = []
        self.da_diagnosticare = 0.0         # momento (monotonic) dopo cui ricalcolare; 0 = niente


class ServerLeo:
    """Server LSP. ``ingresso``/``uscita`` sono flussi binari (``sys.stdin.buffer``...)."""

    def __init__(self, ingresso: BinaryIO, uscita: BinaryIO, *, registro: Callable[[str], None] | None = None,
                 sincrono: bool = False) -> None:
        #: ``sincrono``: la diagnosi completa si calcola subito (test e strumenti), non in sottofondo
        self.sincrono = sincrono
        self._in_corso: set[str] = set()
        self.ingresso = ingresso
        self.uscita = uscita
        self._blocco_uscita = threading.Lock()
        self._coda: queue.Queue = queue.Queue()
        self._annullate: set[Any] = set()
        self.documenti: dict[str, _Stato] = {}
        self.inizializzato = False
        self.spento = False
        self.finito = False
        self.codice_uscita = 0
        self.codifica = Codifica.UTF16
        self.frammenti = True
        self.controllo_statico = True
        self.tempo_massimo_esecuzione = 120.0
        self.cartelle: list[str] = []
        self._registro = registro or (lambda testo: print(testo, file=sys.stderr, flush=True))
        self._id_richieste = 0
        self._esecuzioni: dict[str, subprocess.Popen] = {}
        self._gestori: dict[str, Callable[[Any], Any]] = {
            "initialize": self._initialize,
            "shutdown": self._shutdown,
            "textDocument/completion": self._completion,
            "completionItem/resolve": lambda p: p,
            "textDocument/hover": self._hover,
            "textDocument/signatureHelp": self._signature_help,
            "textDocument/definition": self._definition,
            "textDocument/declaration": self._definition,
            "textDocument/references": self._references,
            "textDocument/documentHighlight": self._document_highlight,
            "textDocument/prepareRename": self._prepare_rename,
            "textDocument/rename": self._rename,
            "textDocument/documentSymbol": self._document_symbol,
            "textDocument/foldingRange": self._folding_range,
            "textDocument/formatting": self._formatting,
            "textDocument/semanticTokens/full": self._semantic_tokens,
            "textDocument/codeAction": self._code_action,
            "textDocument/diagnostic": self._diagnostic,
            "workspace/executeCommand": self._execute_command,
        }
        self._notifiche: dict[str, Callable[[Any], None]] = {
            "initialized": self._initialized,
            "exit": self._exit,
            "textDocument/didOpen": self._did_open,
            "textDocument/didChange": self._did_change,
            "textDocument/didClose": self._did_close,
            "textDocument/didSave": self._did_save,
            "workspace/didChangeConfiguration": self._did_change_configuration,
            "$/cancelRequest": self._cancel,
            "$/setTrace": lambda p: None,
        }

    # ------------------------------------------------------------------
    # ciclo principale
    # ------------------------------------------------------------------

    def _lettore(self) -> None:
        while True:
            try:
                messaggio = leggi_messaggio(self.ingresso)
            except MessaggioIllegibile as e:
                self._coda.put(("illegibile", str(e)))
                continue
            except (OSError, ValueError):
                messaggio = None
            if messaggio is None:
                self._coda.put(_FINE)
                return
            if messaggio.get("method") == "$/cancelRequest":
                self._annullate.add((messaggio.get("params") or {}).get("id"))
            self._coda.put(messaggio)

    def esegui(self) -> int:
        """Serve finche' il client non chiude (``exit`` o fine dell'ingresso). Codice d'uscita."""
        threading.Thread(target=self._lettore, name="leo-lsp-lettore", daemon=True).start()
        while not self.finito:
            attesa = self._prossima_attesa()
            try:
                voce = self._coda.get(timeout=attesa)
            except queue.Empty:
                self._diagnostica_in_attesa()
                continue
            if voce is _FINE:
                self.codice_uscita = 0 if self.spento else 1
                break
            if isinstance(voce, tuple) and voce and voce[0] == "diagnosi":
                self._diagnosi_pronta(voce[1], voce[2], voce[3])
                continue
            if isinstance(voce, tuple) and voce and voce[0] == "illegibile":
                self._invia({"jsonrpc": "2.0", "id": None,
                             "error": {"code": PARSE_ERROR, "message": f"Messaggio illeggibile: {voce[1]}"}})
                continue
            self.gestisci(voce)
            if self._coda.empty():
                self._diagnostica_in_attesa()
        self._ferma_esecuzioni()
        return self.codice_uscita

    def _prossima_attesa(self) -> float | None:
        prossima = [s.da_diagnosticare for s in self.documenti.values() if s.da_diagnosticare]
        if not prossima:
            return None
        return max(0.0, min(prossima) - time.monotonic())

    def gestisci(self, messaggio: dict[str, Any]) -> None:
        """Smista un messaggio (pubblico per i test, che lo chiamano senza thread)."""
        metodo = messaggio.get("method")
        ident = messaggio.get("id")
        if metodo is None:
            return                                   # risposta a una nostra richiesta: non serve
        parametri = messaggio.get("params")
        if "id" not in messaggio:
            gestore = self._notifiche.get(metodo)
            if gestore is None:
                return
            if not self.inizializzato and metodo != "exit":
                return
            try:
                gestore(parametri)
            except Exception:  # noqa: BLE001
                self._registro(f"leo lsp: errore interno in {metodo}:\n{traceback.format_exc()}")
            return
        if ident in self._annullate:
            self._annullate.discard(ident)
            self._rispondi_errore(ident, REQUEST_CANCELLED, "Richiesta annullata.")
            return
        if not self.inizializzato and metodo != "initialize":
            self._rispondi_errore(ident, SERVER_NOT_INITIALIZED, "Il server non è ancora inizializzato.")
            return
        if self.spento and metodo != "shutdown":
            self._rispondi_errore(ident, INVALID_REQUEST, "Il server è stato spento.")
            return
        gestore = self._gestori.get(metodo)
        if gestore is None:
            self._rispondi_errore(ident, METHOD_NOT_FOUND, f"Metodo non disponibile: {metodo}")
            return
        try:
            risultato = gestore(parametri or {})
        except ErroreRPC as e:
            self._invia({"jsonrpc": "2.0", "id": ident, "error": e.come_dizionario()})
            return
        except (KeyError, TypeError, ValueError) as e:
            self._registro(f"leo lsp: parametri non validi per {metodo}:\n{traceback.format_exc()}")
            self._rispondi_errore(ident, INVALID_PARAMS, f"Parametri non validi: {e}")
            return
        except Exception as e:  # noqa: BLE001
            self._registro(f"leo lsp: errore interno in {metodo}:\n{traceback.format_exc()}")
            self._rispondi_errore(ident, INTERNAL_ERROR, f"Errore interno di Leo: {type(e).__name__}: {e}")
            return
        self._invia({"jsonrpc": "2.0", "id": ident, "result": risultato})

    # ------------------------------------------------------------------
    # invio
    # ------------------------------------------------------------------

    def _invia(self, messaggio: dict[str, Any]) -> None:
        messaggio.setdefault("jsonrpc", "2.0")
        with self._blocco_uscita:
            try:
                scrivi_messaggio(self.uscita, messaggio)
            except (OSError, ValueError):
                self.finito = True

    def _rispondi_errore(self, ident: Any, codice: int, testo: str) -> None:
        self._invia({"jsonrpc": "2.0", "id": ident, "error": {"code": codice, "message": testo}})

    def notifica(self, metodo: str, parametri: Any) -> None:
        self._invia({"jsonrpc": "2.0", "method": metodo, "params": parametri})

    def richiesta(self, metodo: str, parametri: Any) -> None:
        """Richiesta al client (la risposta non serve e viene ignorata)."""
        self._id_richieste += 1
        self._invia({"jsonrpc": "2.0", "id": f"leo-{self._id_richieste}", "method": metodo, "params": parametri})

    def messaggio(self, testo: str, tipo: int = 3) -> None:
        """``window/showMessage``: 1 errore, 2 avviso, 3 informazione."""
        self.notifica("window/showMessage", {"type": tipo, "message": testo})

    def registra(self, testo: str, tipo: int = 4) -> None:
        self.notifica("window/logMessage", {"type": tipo, "message": testo})

    # ------------------------------------------------------------------
    # ciclo di vita
    # ------------------------------------------------------------------

    def _initialize(self, p: dict[str, Any]) -> dict[str, Any]:
        capacita = p.get("capabilities") or {}
        generale = capacita.get("general") or {}
        self.codifica = Codifica.scegli(generale.get("positionEncodings"))
        completamento = ((capacita.get("textDocument") or {}).get("completion") or {}).get("completionItem") or {}
        self.frammenti = bool(completamento.get("snippetSupport", False))
        self._leggi_opzioni(p.get("initializationOptions") or {})
        for cartella in p.get("workspaceFolders") or []:
            percorso = uri_a_percorso(cartella.get("uri", ""))
            if percorso:
                self.cartelle.append(percorso)
        if not self.cartelle and p.get("rootUri"):
            percorso = uri_a_percorso(p["rootUri"])
            if percorso:
                self.cartelle.append(percorso)
        from .lingua import LEGENDA_SEMANTICA

        self.inizializzato = True
        return {
            "capabilities": {
                "positionEncoding": self.codifica,
                "textDocumentSync": {"openClose": True, "change": 2, "save": {"includeText": False}},
                "completionProvider": {"triggerCharacters": ["."], "resolveProvider": False},
                "hoverProvider": True,
                "signatureHelpProvider": {"triggerCharacters": ["(", ","], "retriggerCharacters": [","]},
                "definitionProvider": True,
                "declarationProvider": True,
                "referencesProvider": True,
                "documentHighlightProvider": True,
                "renameProvider": {"prepareProvider": True},
                "documentSymbolProvider": True,
                "foldingRangeProvider": True,
                "documentFormattingProvider": True,
                "codeActionProvider": {"codeActionKinds": ["quickfix", "source.fixAll", "source.fixAll.leo"]},
                "semanticTokensProvider": {"legend": LEGENDA_SEMANTICA, "full": True, "range": False},
                "executeCommandProvider": {"commands": list(COMANDI)},
            },
            "serverInfo": {"name": "leo", "version": _versione()},
        }

    def _leggi_opzioni(self, opzioni: dict[str, Any]) -> None:
        if not isinstance(opzioni, dict):
            return
        if "controlloStatico" in opzioni:
            self.controllo_statico = bool(opzioni["controlloStatico"])
            from .controllo_statico import attivo

            attivo(self.controllo_statico)
        if "tempoMassimoEsecuzione" in opzioni:
            try:
                self.tempo_massimo_esecuzione = max(1.0, float(opzioni["tempoMassimoEsecuzione"]))
            except (TypeError, ValueError):
                pass

    def _initialized(self, _p: Any) -> None:
        # si prepara la libreria in anticipo: la prima richiesta sara' gia' veloce
        try:
            from .. import completamento as c

            c.funzioni_libreria()
        except Exception:  # noqa: BLE001
            pass

    def _shutdown(self, _p: Any) -> None:
        self.spento = True
        return None

    def _exit(self, _p: Any) -> None:
        self.codice_uscita = 0 if self.spento else 1
        self.finito = True

    def _did_change_configuration(self, p: dict[str, Any]) -> None:
        impostazioni = (p or {}).get("settings") or {}
        leo = impostazioni.get("leo", impostazioni) if isinstance(impostazioni, dict) else {}
        self._leggi_opzioni(leo if isinstance(leo, dict) else {})
        for stato in self.documenti.values():
            stato.versione_diagnosi = None
            stato.da_diagnosticare = time.monotonic()

    # ------------------------------------------------------------------
    # documenti
    # ------------------------------------------------------------------

    def _did_open(self, p: dict[str, Any]) -> None:
        voce = p["textDocument"]
        doc = Documento(voce["uri"], voce.get("text", ""), int(voce.get("version", 0) or 0),
                        voce.get("languageId", "leo"), self.codifica)
        self.documenti[doc.uri] = _Stato(doc)
        self._diagnostica_subito(self.documenti[doc.uri])

    def _did_change(self, p: dict[str, Any]) -> None:
        voce = p["textDocument"]
        stato = self.documenti.get(voce["uri"])
        if stato is None:
            return
        stato.doc.applica(p.get("contentChanges") or [], voce.get("version"))
        stato.da_diagnosticare = time.monotonic() + ATTESA_DIAGNOSTICA

    def _did_save(self, p: dict[str, Any]) -> None:
        stato = self.documenti.get(p["textDocument"]["uri"])
        if stato is not None:
            stato.versione_diagnosi = None             # la maschera o il progetto possono essere cambiati
            stato.da_diagnosticare = time.monotonic()

    def _did_close(self, p: dict[str, Any]) -> None:
        uri = p["textDocument"]["uri"]
        if self.documenti.pop(uri, None) is not None:
            self.notifica("textDocument/publishDiagnostics", {"uri": uri, "diagnostics": []})

    def _stato(self, p: dict[str, Any]) -> _Stato:
        uri = (p.get("textDocument") or {}).get("uri")
        stato = self.documenti.get(uri)
        if stato is None:
            percorso = uri_a_percorso(uri or "")
            if percorso and os.path.isfile(percorso):
                with open(percorso, encoding="utf-8-sig", errors="replace") as f:
                    doc = Documento(uri, f.read(), 0, "leo", self.codifica)
                return _Stato(doc)
            raise ErroreRPC(INVALID_PARAMS, f"Documento non aperto: {uri}")
        return stato

    def leggi_testo(self, percorso: str) -> str | None:
        """Testo di un file: quello nell'editor se e' aperto, altrimenti None."""
        for stato in self.documenti.values():
            if stato.doc.percorso and os.path.normcase(os.path.abspath(stato.doc.percorso)) == \
                    os.path.normcase(os.path.abspath(percorso)):
                return stato.doc.testo
        return None

    # --- analisi in cache ---------------------------------------------------------

    def _opzioni_lessico(self, doc: Documento) -> dict[str, Any]:
        percorso = doc.percorso
        if not percorso:
            return {}
        try:
            from ..esecuzione import opzioni_lessico_file

            return opzioni_lessico_file(percorso)
        except Exception:  # noqa: BLE001 - progetto.toml rotto: si va avanti con le opzioni di serie
            return {}

    def _controlli(self, doc: Documento) -> dict[str, str | None]:
        controlli: dict[str, str | None] = {}
        try:
            from ..editor_telefono import controlli_dal_codice

            controlli.update(controlli_dal_codice(doc.testo))
        except Exception:  # noqa: BLE001
            pass
        percorso = doc.percorso
        if percorso:
            try:
                from ..correzioni import controlli_da_maschera

                controlli.update(controlli_da_maschera(percorso) or {})
            except Exception:  # noqa: BLE001
                pass
        return controlli

    def _analisi(self, stato: _Stato):
        if stato.analisi is None or stato.versione_analisi != stato.doc.versione or stato.segmenti is None:
            from .simboli import analizza_simboli

            doc = stato.doc
            opzioni = self._opzioni_lessico(doc)
            stato.analisi = analizza_simboli(doc.testo, doc.nome_file, **opzioni)
            try:
                from ..colorazione import colora

                stato.segmenti = colora(doc.testo, controlli=list(self._controlli(doc)))
            except Exception:  # noqa: BLE001
                stato.segmenti = []
            stato.versione_analisi = doc.versione
        return stato.analisi, stato.segmenti

    # ------------------------------------------------------------------
    # diagnostica
    # ------------------------------------------------------------------

    def _diagnostica_in_attesa(self) -> None:
        adesso = time.monotonic()
        for stato in list(self.documenti.values()):
            if stato.da_diagnosticare and stato.da_diagnosticare <= adesso:
                if not self._coda.empty():
                    return                               # arriva altro: prima quello
                self._diagnostica_subito(stato)

    def _calcola_diagnosi(self, stato: _Stato, *, completa: bool | None = None):
        """La diagnosi della versione attuale del documento.

        ``completa=None``: va bene quella che c'e' (veloce o completa); se manca, si
        calcola quella completa in modo sincrono, altrimenti quella veloce (e la
        completa parte in sottofondo). ``completa=True``: serve quella completa.
        """
        doc = stato.doc
        attuale = stato.diagnosi is not None and stato.versione_diagnosi == doc.versione
        if attuale and (stato.diagnosi_completa or not completa):
            return stato.diagnosi
        from .diagnostica import diagnostica

        voglio_completa = bool(completa) or self.sincrono
        stato.diagnosi = diagnostica(doc.testo, doc.nome_file, self._opzioni_lessico(doc),
                                     controlli=self._controlli(doc), statico=self.controllo_statico,
                                     completa=voglio_completa)
        stato.versione_diagnosi = doc.versione
        stato.diagnosi_completa = voglio_completa
        stato.diagnostiche_lsp = [self._diagnostica_lsp(doc, a, k) for k, a in enumerate(stato.diagnosi.avvisi)]
        if not voglio_completa:
            self._avvia_diagnosi_completa(stato)
        return stato.diagnosi

    def _avvia_diagnosi_completa(self, stato: _Stato) -> None:
        """Calcola la diagnosi completa in un thread; il risultato torna nella coda."""
        uri = stato.doc.uri
        if uri in self._in_corso:
            stato.rifare = True
            return
        doc = stato.doc
        versione, testo, nome_file = doc.versione, doc.testo, doc.nome_file
        opzioni, controlli = self._opzioni_lessico(doc), self._controlli(doc)
        statico = self.controllo_statico
        self._in_corso.add(uri)

        def lavoro() -> None:
            from .diagnostica import diagnostica

            try:
                diagnosi = diagnostica(testo, nome_file, opzioni, controlli=controlli, statico=statico)
            except Exception:  # noqa: BLE001
                diagnosi = None
            self._coda.put(("diagnosi", uri, versione, diagnosi))

        threading.Thread(target=lavoro, name="leo-lsp-diagnosi", daemon=True).start()

    def _diagnosi_pronta(self, uri: str, versione: int, diagnosi: Any) -> None:
        self._in_corso.discard(uri)
        stato = self.documenti.get(uri)
        if stato is None:
            return
        if diagnosi is not None and stato.doc.versione == versione:
            stato.diagnosi = diagnosi
            stato.versione_diagnosi = versione
            stato.diagnosi_completa = True
            stato.diagnostiche_lsp = [self._diagnostica_lsp(stato.doc, a, k) for k, a in enumerate(diagnosi.avvisi)]
            self.notifica("textDocument/publishDiagnostics",
                          {"uri": uri, "version": versione, "diagnostics": stato.diagnostiche_lsp})
            stato.rifare = False
        elif stato.rifare or stato.doc.versione != versione:
            stato.rifare = False
            if not stato.da_diagnosticare:          # se sta per ricalcolare comunque, ci pensera' lui
                self._avvia_diagnosi_completa(stato)

    def _diagnostica_subito(self, stato: _Stato) -> None:
        stato.da_diagnosticare = 0.0
        try:
            self._calcola_diagnosi(stato)
        except Exception:  # noqa: BLE001
            self._registro(f"leo lsp: diagnostica non riuscita:\n{traceback.format_exc()}")
            return
        self.notifica("textDocument/publishDiagnostics",
                      {"uri": stato.doc.uri, "version": stato.doc.versione, "diagnostics": stato.diagnostiche_lsp})

    def _diagnostica_lsp(self, doc: Documento, a: Any, indice: int) -> dict[str, Any]:
        from .diagnostica import GRAVITA

        diagnostica: dict[str, Any] = {
            "range": doc.intervallo_tra(a.riga, a.colonna, a.riga_fine, a.colonna_fine),
            "severity": GRAVITA.get(a.gravita, 1),
            "source": a.fonte,
            "message": a.messaggio,
            "data": {"indice": indice, "versione": doc.versione},
        }
        if a.codice:
            diagnostica["code"] = a.codice
        return diagnostica

    def _diagnostic(self, p: dict[str, Any]) -> dict[str, Any]:
        """Diagnostica a richiesta (``textDocument/diagnostic``, LSP 3.17)."""
        stato = self._stato(p)
        self._calcola_diagnosi(stato)
        return {"kind": "full", "items": stato.diagnostiche_lsp}

    # ------------------------------------------------------------------
    # richieste
    # ------------------------------------------------------------------

    def _posizione(self, stato: _Stato, p: dict[str, Any]) -> tuple[int, int]:
        return stato.doc.da_lsp(p["position"])

    def _completion(self, p: dict[str, Any]) -> dict[str, Any]:
        from .lingua import completamento

        stato = self._stato(p)
        riga, colonna = self._posizione(stato, p)
        return completamento(stato.doc, riga, colonna, self._controlli(stato.doc), frammenti=self.frammenti)

    def _hover(self, p: dict[str, Any]) -> dict[str, Any] | None:
        from .lingua import hover

        stato = self._stato(p)
        analisi, segmenti = self._analisi(stato)
        riga, colonna = self._posizione(stato, p)
        return hover(stato.doc, riga, colonna, analisi, segmenti, self._controlli(stato.doc))

    def _signature_help(self, p: dict[str, Any]) -> dict[str, Any] | None:
        from .lingua import firma

        stato = self._stato(p)
        analisi, _ = self._analisi(stato)
        riga, colonna = self._posizione(stato, p)
        return firma(stato.doc, riga, colonna, analisi, self._controlli(stato.doc))

    def _definition(self, p: dict[str, Any]) -> list[dict[str, Any]]:
        from .lingua import definizione

        stato = self._stato(p)
        analisi, _ = self._analisi(stato)
        riga, colonna = self._posizione(stato, p)
        return definizione(stato.doc, riga, colonna, analisi, self.leggi_testo)

    def _references(self, p: dict[str, Any]) -> list[dict[str, Any]]:
        from .lingua import riferimenti

        stato = self._stato(p)
        analisi, _ = self._analisi(stato)
        riga, colonna = self._posizione(stato, p)
        dichiarazione = bool((p.get("context") or {}).get("includeDeclaration", True))
        return riferimenti(stato.doc, riga, colonna, analisi, dichiarazione)

    def _document_highlight(self, p: dict[str, Any]) -> list[dict[str, Any]]:
        from .lingua import evidenzia

        stato = self._stato(p)
        analisi, _ = self._analisi(stato)
        riga, colonna = self._posizione(stato, p)
        return evidenzia(stato.doc, riga, colonna, analisi)

    def _prepare_rename(self, p: dict[str, Any]) -> dict[str, Any]:
        from .lingua import RinominaImpossibile, prepara_rinomina

        stato = self._stato(p)
        analisi, _ = self._analisi(stato)
        riga, colonna = self._posizione(stato, p)
        try:
            return prepara_rinomina(stato.doc, riga, colonna, analisi)
        except RinominaImpossibile as e:
            raise ErroreRPC(REQUEST_FAILED, str(e)) from None

    def _rename(self, p: dict[str, Any]) -> dict[str, Any]:
        from .lingua import RinominaImpossibile, rinomina

        stato = self._stato(p)
        analisi, _ = self._analisi(stato)
        riga, colonna = self._posizione(stato, p)
        try:
            return rinomina(stato.doc, riga, colonna, str(p.get("newName", "")), analisi)
        except RinominaImpossibile as e:
            raise ErroreRPC(REQUEST_FAILED, str(e)) from None

    def _document_symbol(self, p: dict[str, Any]) -> list[dict[str, Any]]:
        from .lingua import simboli_documento

        stato = self._stato(p)
        analisi, _ = self._analisi(stato)
        return simboli_documento(stato.doc, analisi)

    def _folding_range(self, p: dict[str, Any]) -> list[dict[str, Any]]:
        from .lingua import piegature

        stato = self._stato(p)
        analisi, _ = self._analisi(stato)
        return piegature(stato.doc, analisi)

    def _formatting(self, p: dict[str, Any]) -> list[dict[str, Any]] | None:
        from ..errori import ErroreDante
        from .lingua import formatta

        stato = self._stato(p)
        try:
            return formatta(stato.doc, p.get("options") or {})
        except ErroreDante as e:
            riga = getattr(e, "riga", 0) or 0
            dove = f" (riga {riga})" if riga else ""
            self.messaggio(f"Leo non può formattare il file finché c'è questo errore{dove}: "
                           f"{getattr(e, 'messaggio', e)}", 2)
            return None

    def _semantic_tokens(self, p: dict[str, Any]) -> dict[str, Any]:
        from .lingua import token_semantici

        stato = self._stato(p)
        analisi, segmenti = self._analisi(stato)
        dichiarazioni = {(o.riga, o.colonna) for o in analisi.occorrenze if o.dichiarazione}
        return token_semantici(stato.doc, segmenti or [], dichiarazioni)

    # --- correzioni rapide ----------------------------------------------------------

    def _modifica(self, doc: Documento, correzione: Any) -> dict[str, Any] | None:
        from .diagnostica import intervallo_correzione

        try:
            r1, c1, r2, c2, testo = intervallo_correzione(doc.testo, correzione)
        except Exception:  # noqa: BLE001
            return None
        return {"range": doc.intervallo_tra(r1, c1, r2, c2), "newText": testo}

    def _azione(self, doc: Documento, titolo: str, correzioni: list, tipo: str = "quickfix",
                diagnostiche: list | None = None, preferita: bool = False) -> dict[str, Any] | None:
        modifiche = []
        for c in correzioni:
            m = self._modifica(doc, c)
            if m is None:
                return None
            modifiche.append(m)
        if not modifiche:
            return None
        azione: dict[str, Any] = {"title": titolo, "kind": tipo,
                                  "edit": {"changes": {doc.uri: modifiche}}}
        if diagnostiche:
            azione["diagnostics"] = diagnostiche
        if preferita:
            azione["isPreferred"] = True
        return azione

    def _code_action(self, p: dict[str, Any]) -> list[dict[str, Any]]:
        stato = self._stato(p)
        richieste = (p.get("context") or {}).get("only") or []
        # "correggi tutto" (anche al salvataggio) vuole la diagnosi completa; la lampadina no
        diagnosi = self._calcola_diagnosi(stato, completa=any(r.startswith("source") for r in richieste) or None)
        doc = stato.doc

        def voluto(tipo: str) -> bool:
            return not richieste or any(tipo == r or tipo.startswith(r + ".") for r in richieste)

        intervallo = p.get("range") or {"start": {"line": 0, "character": 0}, "end": {"line": 0, "character": 0}}
        da = intervallo["start"]["line"] + 1
        a = intervallo["end"]["line"] + 1
        azioni: list[dict[str, Any]] = []
        if voluto("quickfix"):
            for k, avviso in enumerate(diagnosi.avvisi):
                if avviso.riga_fine < da or avviso.riga > a or not avviso.correzioni:
                    continue
                diagnostica = stato.diagnostiche_lsp[k] if k < len(stato.diagnostiche_lsp) else None
                for n, c in enumerate(avviso.correzioni):
                    motivo = str(c.motivo or "correzione").strip()
                    titolo = f"Correggi: {motivo}"
                    nuovo = str(c.dopo).strip()
                    if nuovo and "\n" not in nuovo and len(nuovo) <= 60:
                        titolo += f" → `{nuovo}`"
                    if avviso.da_confermare:
                        titolo += " (controlla che sia il nome giusto)"
                    if n > 0:
                        titolo = "In alternativa: " + titolo[len("Correggi: "):]
                    azione = self._azione(doc, titolo, [c], "quickfix",
                                          [diagnostica] if diagnostica else None,
                                          preferita=(n == 0 and not avviso.da_confermare))
                    if azione is not None:
                        azioni.append(azione)
        tutte = list(diagnosi.correggi_tutto)
        if tutte and len(tutte) > 1 and voluto("quickfix"):
            azione = self._azione(doc, f"Correggi tutto il file ({len(tutte)} correzioni sicure)", tutte)
            if azione is not None:
                azioni.append(azione)
        if tutte and richieste and voluto("source.fixAll.leo"):
            azione = self._azione(doc, "Leo: correggi tutto il file", tutte, "source.fixAll.leo")
            if azione is not None:
                azioni.append(azione)
        return azioni

    # --- comandi --------------------------------------------------------------------

    def _execute_command(self, p: dict[str, Any]) -> Any:
        comando = p.get("command")
        argomenti = p.get("arguments") or []
        uri = argomenti[0] if argomenti else None
        if isinstance(uri, dict):
            uri = uri.get("uri") or (uri.get("textDocument") or {}).get("uri")
        if comando == "leo.correggiTutto":
            stato = self._stato({"textDocument": {"uri": uri}})
            diagnosi = self._calcola_diagnosi(stato, completa=True)
            azione = self._azione(stato.doc, "Correggi tutto", list(diagnosi.correggi_tutto))
            if azione is None:
                self.messaggio("Non ci sono correzioni sicure da applicare.")
                return {"applicate": 0}
            self.richiesta("workspace/applyEdit", {"label": "Leo: correggi tutto", "edit": azione["edit"]})
            return {"applicate": len(diagnosi.correggi_tutto)}
        if comando == "leo.eseguiFile":
            return self._esegui_file(str(uri or ""))
        raise ErroreRPC(INVALID_PARAMS, f"Comando sconosciuto: {comando}")

    def comando_esecuzione(self, percorso: str) -> list[str]:
        """La riga di comando che esegue un programma Leo con lo stesso Leo del server."""
        if getattr(sys, "frozen", False):
            return [sys.executable, percorso]
        return [sys.executable, "-m", "leo", percorso]

    def _esegui_file(self, uri: str) -> dict[str, Any]:
        percorso = uri_a_percorso(uri)
        if not percorso or not os.path.isfile(percorso):
            raise ErroreRPC(INVALID_PARAMS, "Salva il file prima di eseguirlo: Leo esegue i file sul disco.")
        cartella_leo = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        ambiente = dict(os.environ)
        ambiente["PYTHONPATH"] = cartella_leo + (os.pathsep + ambiente["PYTHONPATH"]
                                                 if ambiente.get("PYTHONPATH") else "")
        ambiente["PYTHONIOENCODING"] = "utf-8"
        ambiente["NO_COLOR"] = "1"
        precedente = self._esecuzioni.pop(percorso, None)
        if precedente is not None and precedente.poll() is None:
            precedente.kill()
        try:
            processo = subprocess.Popen(
                self.comando_esecuzione(percorso), cwd=os.path.dirname(percorso), env=ambiente,
                stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        except OSError as e:
            raise ErroreRPC(REQUEST_FAILED, f"Non riesco ad avviare Leo: {e}") from None
        self._esecuzioni[percorso] = processo
        nome = os.path.basename(percorso)
        self.registra(f"▶ {nome}", 3)
        threading.Thread(target=self._segui_esecuzione, args=(processo, nome),
                         name="leo-lsp-esecuzione", daemon=True).start()
        return {"avviato": True, "pid": processo.pid}

    def _segui_esecuzione(self, processo: subprocess.Popen, nome: str) -> None:
        inizio = time.monotonic()
        righe: list[str] = []
        guardiano = threading.Timer(self.tempo_massimo_esecuzione, processo.kill)
        guardiano.daemon = True
        guardiano.start()
        try:
            assert processo.stdout is not None
            for riga in iter(processo.stdout.readline, b""):
                testo = riga.decode("utf-8", errors="replace").rstrip("\r\n")
                righe.append(testo)
                self.notifica("window/logMessage", {"type": 4, "message": testo})
                self.notifica("leo/uscita", {"file": nome, "testo": testo})
            codice = processo.wait()
        finally:
            guardiano.cancel()
            if processo.stdout is not None:
                processo.stdout.close()
        durata = time.monotonic() - inizio
        if codice == 0:
            self.messaggio(f"{nome}: finito in {durata:.1f} s.", 3)
        elif durata >= self.tempo_massimo_esecuzione:
            self.messaggio(f"{nome}: fermato dopo {self.tempo_massimo_esecuzione:.0f} s "
                           "(per i programmi lunghi o che chiedono qualcosa usa il terminale).", 2)
        else:
            self.messaggio(f"{nome}: finito con un errore (codice {codice}). I dettagli sono nell'uscita di Leo.", 1)
        self.notifica("leo/finito", {"file": nome, "codice": codice, "durata": round(durata, 3)})

    def _ferma_esecuzioni(self) -> None:
        for processo in self._esecuzioni.values():
            if processo.poll() is None:
                try:
                    processo.kill()
                except OSError:
                    pass

    def _cancel(self, p: dict[str, Any]) -> None:
        # gia' registrata dal lettore; se la richiesta e' gia' stata servita la si dimentica
        self._annullate.discard((p or {}).get("id"))


def _flussi_binari() -> tuple[BinaryIO, BinaryIO]:
    ingresso = sys.stdin.buffer
    uscita = sys.stdout.buffer
    if os.name == "nt":
        try:
            import msvcrt

            msvcrt.setmode(ingresso.fileno(), os.O_BINARY)
            msvcrt.setmode(uscita.fileno(), os.O_BINARY)
        except (ImportError, OSError, ValueError):
            pass
    return ingresso, uscita


def avvia(argv: list[str] | None = None) -> int:
    """``leo lsp``: serve il protocollo su stdin/stdout finche' l'editor non chiude."""
    argomenti = list(argv or [])
    if any(a in ("-h", "--aiuto", "--help") for a in argomenti):
        print("leo lsp: server del linguaggio Leo (Language Server Protocol) su stdin/stdout.\n"
              "Non si usa a mano: lo avvia l'editor (Visual Studio Code, Neovim, Sublime Text, IDE JetBrains...).\n"
              "Opzioni: --stdio (predefinito, accettato per compatibilità).\n"
              "Istruzioni: docs/EDITOR_ESTERNI.md")
        return 0
    sconosciute = [a for a in argomenti if a not in ("--stdio",)]
    if sconosciute:
        print(f"leo lsp: opzione sconosciuta {sconosciute[0]!r}. Scrivi `leo lsp --aiuto`.", file=sys.stderr)
        return 2
    ingresso, uscita = _flussi_binari()
    vecchio_stdout = sys.stdout
    sys.stdout = sys.stderr                  # nessuna print deve sporcare il protocollo
    try:
        codice = ServerLeo(ingresso, uscita).esegui()
    finally:
        sys.stdout = vecchio_stdout
    # Il thread che legge stdin e' ancora fermo su una lettura: un'uscita normale
    # farebbe attendere (o fallire) la chiusura dell'interprete. Si esce subito.
    for flusso in (sys.stderr, sys.stdout):
        try:
            flusso.flush()
        except (OSError, ValueError):
            pass
    try:
        uscita.flush()
    except (OSError, ValueError):
        pass
    os._exit(codice)
