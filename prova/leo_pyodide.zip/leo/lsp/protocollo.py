"""JSON-RPC 2.0 sui flussi standard, come lo vuole il Language Server Protocol.

Ogni messaggio e' preceduto da un'intestazione ``Content-Length: N`` seguita da
una riga vuota (``\\r\\n\\r\\n``) e poi da N byte di JSON in UTF-8. Solo libreria
standard: funziona sul PC, negli exe e ovunque ci sia Python 3.10+.

API::

    leggi_messaggio(flusso) -> dict | None        # None = flusso chiuso
    scrivi_messaggio(flusso, messaggio)           # thread-safe con un Lock esterno
    codifica(messaggio) -> bytes
    ErroreRPC(codice, messaggio, dati=None)       # errore da restituire al client
"""

from __future__ import annotations

import json
from typing import Any, BinaryIO

__all__ = [
    "leggi_messaggio", "scrivi_messaggio", "codifica", "ErroreRPC",
    "PARSE_ERROR", "INVALID_REQUEST", "METHOD_NOT_FOUND", "INVALID_PARAMS", "INTERNAL_ERROR",
    "SERVER_NOT_INITIALIZED", "REQUEST_CANCELLED", "REQUEST_FAILED",
]

PARSE_ERROR = -32700
INVALID_REQUEST = -32600
METHOD_NOT_FOUND = -32601
INVALID_PARAMS = -32602
INTERNAL_ERROR = -32603
SERVER_NOT_INITIALIZED = -32002
REQUEST_FAILED = -32803
REQUEST_CANCELLED = -32800

#: Messaggi piu' grandi di cosi' (in byte) si rifiutano: un file .leo da 64 MB non esiste.
LIMITE_MESSAGGIO = 64 * 1024 * 1024


class ErroreRPC(Exception):
    """Errore da restituire come risposta JSON-RPC (``error``)."""

    def __init__(self, codice: int, messaggio: str, dati: Any = None) -> None:
        super().__init__(messaggio)
        self.codice = codice
        self.messaggio = messaggio
        self.dati = dati

    def come_dizionario(self) -> dict[str, Any]:
        errore: dict[str, Any] = {"code": self.codice, "message": self.messaggio}
        if self.dati is not None:
            errore["data"] = self.dati
        return errore


class MessaggioIllegibile(Exception):
    """Intestazione o JSON non validi (il server risponde con PARSE_ERROR e prosegue)."""


def leggi_messaggio(flusso: BinaryIO) -> dict[str, Any] | None:
    """Legge un messaggio intero. ``None`` se il flusso e' finito.

    Solleva :class:`MessaggioIllegibile` se il contenuto non e' JSON valido
    (l'intestazione e il corpo sono comunque consumati, cosi' si puo' andare avanti).
    """
    lunghezza: int | None = None
    while True:
        riga = flusso.readline()
        if not riga:
            return None
        riga = riga.rstrip(b"\r\n")
        if not riga:
            if lunghezza is None:
                continue                      # righe vuote spurie tra un messaggio e l'altro
            break
        nome, _, valore = riga.partition(b":")
        if nome.strip().lower() == b"content-length":
            try:
                lunghezza = int(valore.strip())
            except ValueError:
                raise MessaggioIllegibile("Content-Length non è un numero") from None
    if lunghezza < 0 or lunghezza > LIMITE_MESSAGGIO:
        raise MessaggioIllegibile(f"messaggio troppo grande ({lunghezza} byte)")
    corpo = b""
    while len(corpo) < lunghezza:
        pezzo = flusso.read(lunghezza - len(corpo))
        if not pezzo:
            return None
        corpo += pezzo
    try:
        messaggio = json.loads(corpo.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as e:
        raise MessaggioIllegibile(f"JSON non valido: {e}") from None
    if not isinstance(messaggio, dict):
        raise MessaggioIllegibile("il messaggio non è un oggetto JSON")
    return messaggio


def codifica(messaggio: dict[str, Any]) -> bytes:
    corpo = json.dumps(messaggio, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return b"Content-Length: " + str(len(corpo)).encode("ascii") + b"\r\n\r\n" + corpo


def scrivi_messaggio(flusso: BinaryIO, messaggio: dict[str, Any]) -> None:
    flusso.write(codifica(messaggio))
    flusso.flush()
