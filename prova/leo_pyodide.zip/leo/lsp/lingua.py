"""Le funzioni dell'editor, una per richiesta del protocollo, in termini di Leo.

Ogni funzione riceve un :class:`leo.lsp.documenti.Documento` (e cio' che serve)
e restituisce gia' le strutture JSON del protocollo. Le posizioni dentro Leo
sono (riga, colonna) da 1 in caratteri; la conversione la fa il documento.

Motori riusati: ``leo.completamento`` (completamento, firme, descrizioni),
``leo.colorazione`` (colorazione semantica), ``leo.formattatore``
(formattazione), :mod:`leo.lsp.simboli` (definizioni, riferimenti, rinomina,
struttura, piegatura).
"""

from __future__ import annotations

import os
import re
from typing import Any, Iterable, Mapping

from .documenti import Documento, percorso_a_uri
from .simboli import Analisi, Simbolo, analizza_simboli, nome_valido

__all__ = [
    "LEGENDA_SEMANTICA", "completamento", "hover", "firma", "definizione", "riferimenti",
    "evidenzia", "prepara_rinomina", "rinomina", "simboli_documento", "piegature",
    "formatta", "token_semantici", "parola_in",
]

_RE_PAROLA = re.compile(r"[^\W\d]\w*", re.UNICODE)

# ---------------------------------------------------------------------------
# Completamento
# ---------------------------------------------------------------------------

#: tipo di Suggerimento -> CompletionItemKind
_TIPI_COMPLETAMENTO = {
    "parola_chiave": 14, "frammento": 15, "controllo": 7, "proprieta": 10, "evento": 23,
    "metodo": 2, "funzione": 3, "funzione_utente": 3, "variabile": 6, "costante": 21, "errore": 7,
}


def _escape_frammento(testo: str) -> str:
    return testo.replace("\\", "\\\\").replace("$", "\\$").replace("}", "\\}")


def frammento(s: Any) -> str:
    """Il testo da inserire di un ``Suggerimento`` come snippet del protocollo
    (``${1:campo}``, copie collegate con lo stesso numero, ``$0`` alla fine)."""
    testo = s.testo_da_inserire
    pezzi: list[tuple[int, int, int]] = []           # (inizio, lunghezza, numero)
    for k, (inizio, lunghezza) in enumerate(s.campi or (), start=1):
        pezzi.append((inizio, lunghezza, k))
        if s.collegati and k - 1 < len(s.collegati):
            for a, n in s.collegati[k - 1]:
                if (a, n) != (inizio, lunghezza):
                    pezzi.append((a, n, k))
    if not pezzi and 0 <= s.posizione_cursore < len(testo):
        pezzi.append((s.posizione_cursore, 0, 0))
    pezzi.sort()
    finale = s.cursore_finale if s.campi else -1
    metti_finale = finale >= 0 and not any(n == 0 for _a, _l, n in pezzi) and \
        not any(a < finale < a + lun for a, lun, _n in pezzi)
    risultato: list[str] = []
    pos = 0
    for inizio, lunghezza, numero in pezzi:
        if inizio < pos:
            continue                                  # campi sovrapposti: si tiene il primo
        if metti_finale and pos <= finale <= inizio:
            risultato.append(_escape_frammento(testo[pos:finale]) + "$0")
            pos = finale
            metti_finale = False
        risultato.append(_escape_frammento(testo[pos:inizio]))
        segnaposto = _escape_frammento(testo[inizio:inizio + lunghezza])
        risultato.append(f"${{{numero}:{segnaposto}}}" if lunghezza else f"${numero}")
        pos = inizio + lunghezza
    if metti_finale and finale >= pos:
        risultato.append(_escape_frammento(testo[pos:finale]) + "$0")
        pos = finale
    risultato.append(_escape_frammento(testo[pos:]))
    return "".join(risultato)


def completamento(doc: Documento, riga: int, colonna: int, controlli: Mapping[str, str | None],
                  *, frammenti: bool = True, limite: int = 100) -> dict[str, Any]:
    from .. import completamento as c

    testo_riga = doc.riga(riga)
    try:
        trovati = c.suggerimenti(doc.testo, riga, colonna, maschera=dict(controlli), limite=limite)
    except Exception:  # noqa: BLE001
        trovati = []
    voci = []
    for k, s in enumerate(trovati):
        inizio = max(1, s.inizio)
        fine = max(inizio, s.fine)
        intervallo = doc.intervallo_tra(riga, inizio, riga, fine)
        con_campi = bool(s.campi) or s.posizione_cursore < len(s.testo_da_inserire)
        voce: dict[str, Any] = {
            "label": s.testo,
            "kind": _TIPI_COMPLETAMENTO.get(s.tipo, 1),
            "detail": s.dettaglio or s.etichetta_tipo,
            "sortText": f"{k:04d}",
            "textEdit": {"range": intervallo,
                         "newText": frammento(s) if (frammenti and con_campi) else s.testo_da_inserire},
            "insertTextFormat": 2 if (frammenti and con_campi) else 1,
        }
        if "\n" in s.testo_da_inserire:
            voce["insertTextMode"] = 1                 # il rientro e' gia' giusto
        if s.descrizione:
            voce["documentation"] = {"kind": "markdown", "value": s.descrizione}
        scritto = testo_riga[inizio - 1:fine - 1]
        if s.corrispondenza != "prefisso" and scritto:
            voce["filterText"] = scritto + " " + s.testo   # refusi e parti interne: l'editor non li scarta
        if s.dettaglio and s.tipo in ("funzione", "funzione_utente", "metodo"):
            voce["labelDetails"] = {"description": s.etichetta_tipo}
        voci.append(voce)
    return {"isIncomplete": True, "items": voci}


# ---------------------------------------------------------------------------
# Parole e descrizioni
# ---------------------------------------------------------------------------

def parola_in(testo_riga: str, colonna: int) -> tuple[str, int]:
    """(parola sotto il cursore o subito prima, colonna d'inizio da 1); ``("", colonna)`` se nessuna."""
    for m in _RE_PAROLA.finditer(testo_riga):
        if m.start() + 1 <= colonna <= m.end() + 1:
            return m.group(0), m.start() + 1
    return "", colonna


def _descrizione_libreria(nome: str) -> tuple[str, str] | None:
    """(firma, documentazione completa) di una funzione della libreria."""
    from .. import completamento as c

    voce = c.funzioni_libreria().get(nome)
    if voce is None:
        return None
    firma, breve = voce
    try:
        from .. import registro

        doc = str(getattr(registro.FUNZIONI.get(nome), "descrizione", "") or "").strip()
    except Exception:  # noqa: BLE001
        doc = ""
    if doc:
        prima, _, resto = doc.partition("\n")
        if prima.strip().startswith(nome + "(") and ":" in prima:
            prima = prima.split(":", 1)[1].strip()
        doc = (prima + ("\n" + resto if resto else "")).strip()
    return firma, doc or breve


def _blocco_codice(codice: str) -> str:
    return f"```leo\n{codice}\n```"


def _commenti_sopra(doc: Documento, riga: int) -> str:
    """Le righe di commento ``#`` subito sopra una dichiarazione (la sua documentazione)."""
    righe: list[str] = []
    r = riga - 1
    while r >= 1:
        testo = doc.riga(r).strip()
        if testo.startswith("#") and not testo.startswith("#["):
            righe.append(testo.lstrip("#").strip())
            r -= 1
            continue
        break
    return "\n".join(reversed([x for x in righe if not x.lower().startswith("stile:")]))


_NOMI_TIPI = {"variabile": "variabile", "costante": "costante", "funzione": "funzione",
              "parametro": "parametro", "ciclo": "variabile del ciclo", "cattura": "errore catturato"}


def _descrivi_simbolo(doc: Documento, s: Simbolo, riferimenti: int) -> str:
    parti = [_blocco_codice(s.dettaglio or doc.riga(s.riga).strip())]
    dove = f"riga {s.riga}"
    tipo = _NOMI_TIPI.get(s.tipo, s.tipo)
    if s.ambito.blocco is not None and s.tipo != "funzione":
        dove += f", dentro `{s.ambito.blocco.titolo.split('(')[0].strip()}`"
    usi = "nessun uso" if riferimenti == 0 else ("1 uso" if riferimenti == 1 else f"{riferimenti} usi")
    parti.append(f"**{tipo.capitalize()}** del tuo programma ({dove}) · {usi}")
    commento = _commenti_sopra(doc, s.riga)
    if commento:
        parti.append(commento)
    return "\n\n".join(parti)


def hover(doc: Documento, riga: int, colonna: int, analisi: Analisi, segmenti: list,
          controlli: Mapping[str, str | None]) -> dict[str, Any] | None:
    from .. import completamento as c

    testo_riga = doc.riga(riga)
    parola, inizio = parola_in(testo_riga, colonna)
    if not parola:
        return None
    segmento = next((g for g in segmenti if g.riga == riga and g.colonna <= colonna < g.colonna + g.lunghezza),
                    None)
    if segmento is None:
        segmento = next((g for g in segmenti if g.riga == riga and g.colonna <= inizio < g.colonna + g.lunghezza),
                        None)
    categoria = getattr(getattr(segmento, "categoria", None), "value", "")
    if categoria in ("commenti",) or (categoria == "testi" and "{" not in testo_riga):
        return None
    intervallo = doc.intervallo(riga, inizio, len(parola))
    parti: list[str] = []
    prima = testo_riga[:inizio - 1]
    # parola chiave (anche di due parole, e i sinonimi)
    sinonimo = getattr(segmento, "sinonimo_di", None)
    if sinonimo and segmento is not None:
        scritto = testo_riga[segmento.colonna - 1:segmento.colonna - 1 + segmento.lunghezza]
        parti.append(f"`{scritto}` è un sinonimo di `{sinonimo}`.")
        if sinonimo in c.PAROLE_CHIAVE:
            parti.append(c.PAROLE_CHIAVE[sinonimo])
        intervallo = doc.intervallo(riga, segmento.colonna, segmento.lunghezza)
    elif categoria in ("flusso", "dichiarazioni", "errori", "logici", "valori_speciali") and segmento is not None:
        scritto = testo_riga[segmento.colonna - 1:segmento.colonna - 1 + segmento.lunghezza]
        for chiave in (scritto, scritto.lower(), parola, parola.lower()):
            if chiave in c.PAROLE_CHIAVE:
                parti.append(f"**`{chiave}`**: {c.PAROLE_CHIAVE[chiave]}")
                break
    if not parti:
        simbolo = analisi.simbolo_in(riga, colonna) or analisi.simbolo_in(riga, inizio)
        if simbolo is not None and not prima.rstrip().endswith("."):
            parti.append(_descrivi_simbolo(doc, simbolo, len(analisi.riferimenti(simbolo, False))))
    if not parti and not prima.endswith(".") and parola in ("evento",):
        parti.append("**`evento`**: i dettagli dell'evento dentro `quando` (per esempio `evento.x`, `evento.tasto`).")
    if not parti and not prima.endswith("."):
        libreria = _descrizione_libreria(parola)
        if libreria is not None and parola not in controlli:
            firma, descrizione = libreria
            parti.append(_blocco_codice(firma))
            if descrizione:
                parti.append(descrizione)
            parti.append("*Funzione della libreria di Leo.*")
    if not parti:
        dati = c.DatiCompletamento.da_sorgente(doc.testo, dict(controlli))
        testo = c.descrivi_parola(parola, prima, dati)
        if testo:
            testa, _, resto = testo.partition("\n")
            parti.append(_blocco_codice(testa))
            if resto.strip():
                parti.append(resto.strip())
    if not parti:
        return None
    return {"contents": {"kind": "markdown", "value": "\n\n".join(parti)}, "range": intervallo}


# ---------------------------------------------------------------------------
# Firma della chiamata (signature help)
# ---------------------------------------------------------------------------

def _parametri(firma: str) -> list[str]:
    """``nome(a, b = 1, resto...)`` -> ``["a", "b = 1", "resto..."]``."""
    if "(" not in firma:
        return []
    dentro = firma[firma.index("(") + 1:]
    if dentro.endswith(")"):
        dentro = dentro[:-1]
    parti, livello, attuale, testo = [], 0, "", False
    for ch in dentro:
        if ch == '"':
            testo = not testo
        if not testo:
            if ch in "([{":
                livello += 1
            elif ch in ")]}":
                livello -= 1
            elif ch == "," and livello == 0:
                parti.append(attuale.strip())
                attuale = ""
                continue
        attuale += ch
    if attuale.strip():
        parti.append(attuale.strip())
    return parti


def firma(doc: Documento, riga: int, colonna: int, analisi: Analisi,
          controlli: Mapping[str, str | None]) -> dict[str, Any] | None:
    from .. import completamento as c

    prima = doc.riga(riga)[:colonna - 1]
    chiamata = c.chiamata_in_corso(prima)
    if chiamata is None:
        return None
    nome, indice = chiamata
    posizione = prima.rfind(nome + "(")
    davanti = prima[:posizione] if posizione >= 0 else ""
    etichetta = descrizione = ""
    if davanti.endswith(".") and not davanti.endswith(".."):
        dati = c.DatiCompletamento.da_sorgente(doc.testo, dict(controlli))
        testo = c.descrivi_parola(nome, davanti, dati)
        if testo:
            etichetta, _, descrizione = testo.partition("\n")
    else:
        simbolo = analisi.globale.cerca(nome, riga, colonna) if analisi.globale else None
        if simbolo is not None and simbolo.tipo == "funzione":
            etichetta = simbolo.dettaglio or f"{nome}()"
            descrizione = _commenti_sopra(doc, simbolo.riga) or "Funzione del tuo programma."
        else:
            libreria = _descrizione_libreria(nome)
            if libreria is not None:
                etichetta, descrizione = libreria
    if not etichetta or "(" not in etichetta:
        return None
    parametri = _parametri(etichetta)
    attivo = indice
    if parametri and indice >= len(parametri):
        attivo = len(parametri) - 1 if parametri[-1].endswith("...") else indice
    informazioni = []
    cerca_da = etichetta.index("(") + 1
    for p in parametri:
        a = etichetta.find(p, cerca_da)
        if a < 0:
            informazioni.append({"label": p})
            continue
        informazioni.append({"label": [_u16(etichetta[:a]), _u16(etichetta[:a + len(p)])]})
        cerca_da = a + len(p)
    segnatura: dict[str, Any] = {"label": etichetta, "parameters": informazioni}
    if descrizione.strip():
        segnatura["documentation"] = {"kind": "markdown", "value": descrizione.strip()}
    return {"signatures": [segnatura], "activeSignature": 0, "activeParameter": max(0, attivo)}


def _u16(testo: str) -> int:
    # Gli scostamenti di ParameterInformation.label sono sempre in UTF-16 (specifica 3.17)
    return len(testo.encode("utf-16-le")) // 2


# ---------------------------------------------------------------------------
# Definizioni, riferimenti, rinomina
# ---------------------------------------------------------------------------

def _posizione_nella_maschera(percorso: str, nome: str) -> tuple[str, int, int] | None:
    """(file .maschera, riga, colonna) della riga ``nome = "Nome"`` del controllo."""
    cartella = os.path.dirname(percorso)
    base = os.path.splitext(os.path.basename(percorso))[0]
    candidati = [os.path.join(cartella, base + ".maschera")]
    try:
        candidati += sorted(os.path.join(cartella, f) for f in os.listdir(cartella) if f.endswith(".maschera"))
    except OSError:
        pass
    modello = re.compile(r'^\s*nome\s*=\s*"' + re.escape(nome) + r'"\s*$')
    for file in dict.fromkeys(candidati):
        try:
            with open(file, encoding="utf-8-sig") as f:
                for numero, riga in enumerate(f, start=1):
                    if modello.match(riga):
                        return file, numero, riga.index('"') + 2
        except OSError:
            continue
    return None


def _file_importati(percorso: str, analisi: Analisi) -> list[str]:
    cartella = os.path.dirname(percorso)
    trovati = []
    for nome in analisi.importati:
        nome = nome.strip()
        candidati = [nome] if nome.endswith(".leo") else [nome + ".leo", nome]
        for candidato in candidati:
            p = os.path.join(cartella, candidato)
            if os.path.isfile(p):
                trovati.append(p)
                break
    return trovati


def definizione(doc: Documento, riga: int, colonna: int, analisi: Analisi,
                leggi: Any = None) -> list[dict[str, Any]]:
    """Dove e' definito il nome sotto il cursore (anche in un file importato o nella maschera).

    ``leggi(percorso) -> str | None`` da' il testo dei file aperti nell'editor.
    """
    occorrenza = analisi.occorrenza_in(riga, colonna)
    if occorrenza is not None and occorrenza.simbolo is not None:
        s = occorrenza.simbolo
        return [{"uri": doc.uri, "range": doc.intervallo(s.riga, s.colonna, s.lunghezza)}]
    parola, inizio = parola_in(doc.riga(riga), colonna)
    percorso = doc.percorso
    if not parola or not percorso:
        return []
    prima = doc.riga(riga)[:inizio - 1]
    if prima.endswith("."):
        return []
    for file in _file_importati(percorso, analisi):
        testo = leggi(file) if leggi else None
        if testo is None:
            try:
                with open(file, encoding="utf-8-sig") as f:
                    testo = f.read()
            except OSError:
                continue
        altra = analizza_simboli(testo, os.path.basename(file))
        s = altra.globali(parola)
        if s is not None:
            altro_doc = Documento(percorso_a_uri(file), testo, codifica=doc.codifica)
            return [{"uri": altro_doc.uri, "range": altro_doc.intervallo(s.riga, s.colonna, s.lunghezza)}]
    if parola[:1].isupper():
        trovato = _posizione_nella_maschera(percorso, parola)
        if trovato is not None:
            file, numero, col = trovato
            try:
                with open(file, encoding="utf-8-sig") as f:
                    testo = f.read()
            except OSError:
                testo = ""
            altro_doc = Documento(percorso_a_uri(file), testo, codifica=doc.codifica)
            return [{"uri": altro_doc.uri, "range": altro_doc.intervallo(numero, col, len(parola))}]
    return []


def _occorrenze_uguali(analisi: Analisi, riga: int, colonna: int):
    occorrenza = analisi.occorrenza_in(riga, colonna)
    if occorrenza is None:
        return None, []
    if occorrenza.simbolo is not None:
        return occorrenza, analisi.riferimenti(occorrenza.simbolo)
    # nome senza dichiarazione (libreria, controllo): tutte le volte che compare uguale
    return occorrenza, [o for o in analisi.occorrenze if o.simbolo is None and o.nome == occorrenza.nome]


def riferimenti(doc: Documento, riga: int, colonna: int, analisi: Analisi,
                dichiarazione: bool = True) -> list[dict[str, Any]]:
    _occ, tutte = _occorrenze_uguali(analisi, riga, colonna)
    return [{"uri": doc.uri, "range": doc.intervallo(o.riga, o.colonna, o.lunghezza)}
            for o in tutte if dichiarazione or not o.dichiarazione]


def evidenzia(doc: Documento, riga: int, colonna: int, analisi: Analisi) -> list[dict[str, Any]]:
    _occ, tutte = _occorrenze_uguali(analisi, riga, colonna)
    return [{"range": doc.intervallo(o.riga, o.colonna, o.lunghezza), "kind": 3 if o.scrittura else 2}
            for o in tutte]


class RinominaImpossibile(Exception):
    """La rinomina non si puo' fare: il messaggio spiega perche' (in italiano)."""


def prepara_rinomina(doc: Documento, riga: int, colonna: int, analisi: Analisi) -> dict[str, Any]:
    occorrenza = analisi.occorrenza_in(riga, colonna)
    if occorrenza is None:
        raise RinominaImpossibile("Qui non c'è un nome da rinominare.")
    if occorrenza.simbolo is None:
        raise RinominaImpossibile(
            f"`{occorrenza.nome}` non è dichiarato in questo file (è della libreria, un controllo "
            "della finestra o un nome sconosciuto): si possono rinominare solo i nomi del tuo programma.")
    return {"range": doc.intervallo(occorrenza.riga, occorrenza.colonna, occorrenza.lunghezza),
            "placeholder": occorrenza.nome}


def rinomina(doc: Documento, riga: int, colonna: int, nuovo: str, analisi: Analisi) -> dict[str, Any]:
    from .. import completamento as c

    prepara_rinomina(doc, riga, colonna, analisi)
    occorrenza = analisi.occorrenza_in(riga, colonna)
    simbolo = occorrenza.simbolo
    nuovo = (nuovo or "").strip()
    if not nome_valido(nuovo):
        raise RinominaImpossibile(
            f"`{nuovo}` non può essere un nome: usa lettere, cifre e `_`, comincia con una lettera "
            "e non usare le parole del linguaggio.")
    if nuovo == simbolo.nome:
        return {"changes": {}}
    if any(s.nome == nuovo for s in analisi.simboli):
        raise RinominaImpossibile(f"Nel programma c'è già un nome `{nuovo}`: scegline un altro.")
    if nuovo in c.funzioni_libreria():
        raise RinominaImpossibile(
            f"`{nuovo}` è una funzione della libreria di Leo: il tuo nome la nasconderebbe. Scegline un altro.")
    modifiche = [{"range": doc.intervallo(o.riga, o.colonna, o.lunghezza), "newText": nuovo}
                 for o in analisi.riferimenti(simbolo)]
    return {"changes": {doc.uri: modifiche}}


# ---------------------------------------------------------------------------
# Struttura del documento e piegatura
# ---------------------------------------------------------------------------

_SIMBOLI_LSP = {"funzione": 12, "variabile": 13, "costante": 14, "ciclo": 13, "cattura": 13, "parametro": 13}


def simboli_documento(doc: Documento, analisi: Analisi) -> list[dict[str, Any]]:
    def intervallo_blocco(b) -> dict[str, Any]:
        fine = b.riga_fine or b.riga
        return doc.intervallo_tra(b.riga, 1, fine, len(doc.riga(fine)) + 1)

    contenitori: dict[int, dict[str, Any]] = {}

    def da_blocco(b) -> dict[str, Any] | None:
        figli: list[dict[str, Any]] = []
        for f in b.figli:
            voce = da_blocco(f)
            if voce is not None:
                figli.append(voce)
        if b.tipo == "funzione":
            s = b.simbolo
            nome = s.nome if s else (b.titolo or "funzione")
            voce = {"name": nome, "detail": s.dettaglio if s else b.titolo, "kind": 12,
                    "range": intervallo_blocco(b),
                    "selectionRange": doc.intervallo(s.riga, s.colonna, s.lunghezza) if s
                    else doc.intervallo(b.riga, b.colonna, 8),
                    "children": figli}
        elif b.tipo == "quando":
            voce = {"name": b.titolo.rstrip(":").removesuffix(" fai").strip() or "quando", "kind": 24,
                    "range": intervallo_blocco(b), "selectionRange": doc.intervallo(b.riga, b.colonna, 6),
                    "children": figli}
        elif b.tipo == "inizio":
            voce = {"name": "inizio", "detail": "programma principale", "kind": 2,
                    "range": intervallo_blocco(b), "selectionRange": doc.intervallo(b.riga, b.colonna, 6),
                    "children": figli}
        elif b.tipo == "verifica":
            voce = {"name": b.titolo, "kind": 6, "range": intervallo_blocco(b),
                    "selectionRange": doc.intervallo(b.riga, b.colonna, 8), "children": figli}
        else:
            if figli:
                contenitori.setdefault(id(b), {"children": []})["children"].extend(figli)
            return None
        contenitori[id(b)] = voce
        return voce

    radici: list[dict[str, Any]] = []
    for b in analisi.radici:
        voce = da_blocco(b)
        if voce is not None:
            radici.append(voce)
        elif id(b) in contenitori:
            radici.extend(contenitori[id(b)]["children"])

    viste: set[tuple[int, str]] = set()
    for s in analisi.simboli:
        if s.tipo not in ("variabile", "costante"):
            continue
        chiave = (id(s.ambito), s.nome)
        if chiave in viste:
            continue
        viste.add(chiave)
        voce = {"name": s.nome, "detail": doc.riga(s.riga).strip(), "kind": _SIMBOLI_LSP[s.tipo],
                "range": doc.intervallo_tra(s.riga, 1, s.riga, len(doc.riga(s.riga)) + 1),
                "selectionRange": doc.intervallo(s.riga, s.colonna, s.lunghezza)}
        blocco = s.ambito.blocco
        if blocco is not None and id(blocco) in contenitori and "name" in contenitori[id(blocco)]:
            contenitori[id(blocco)].setdefault("children", []).append(voce)
        else:
            radici.append(voce)

    def ordina(voci: list[dict[str, Any]]) -> list[dict[str, Any]]:
        voci.sort(key=lambda v: (v["range"]["start"]["line"], v["range"]["start"]["character"]))
        for v in voci:
            if v.get("children"):
                ordina(v["children"])
        return voci

    return ordina(radici)


def piegature(doc: Documento, analisi: Analisi) -> list[dict[str, Any]]:
    risultato = []
    for b in analisi.blocchi:
        fine = (b.riga_fine - 1) if b.chiuso else b.riga_fine      # `fine` resta visibile
        if fine > b.riga:
            risultato.append({"startLine": b.riga - 1, "endLine": fine - 1})
    # commenti su piu' righe consecutive
    righe = doc.righe
    inizio = None
    for i, testo in enumerate(righe + [""]):
        commento = testo.strip().startswith("#")
        if commento and inizio is None:
            inizio = i
        elif not commento and inizio is not None:
            if i - 1 > inizio:
                risultato.append({"startLine": inizio, "endLine": i - 1, "kind": "comment"})
            inizio = None
    return risultato


# ---------------------------------------------------------------------------
# Formattazione
# ---------------------------------------------------------------------------

def formatta(doc: Documento, opzioni_editor: Mapping[str, Any] | None = None) -> list[dict[str, Any]]:
    """Un'unica modifica con il testo formattato da ``leo formatta`` ([] se non cambia nulla).

    Solleva ``ErroreDante`` se il file non si puo' leggere (il server lo dice all'utente).
    """
    from ..formattatore import formatta as formatta_leo, opzioni_da_progetto

    opzioni: dict[str, Any] = {}
    percorso = doc.percorso
    if percorso:
        opzioni.update(opzioni_da_progetto(percorso))
        opzioni["nome_file"] = percorso
    rientro = (opzioni_editor or {}).get("tabSize")
    if isinstance(rientro, int) and 1 <= rientro <= 8 and (opzioni_editor or {}).get("insertSpaces", True):
        opzioni["indentazione"] = rientro
    nuovo = formatta_leo(doc.testo, **opzioni)
    if nuovo == doc.testo:
        return []
    return [{"range": doc.tutto(), "newText": nuovo}]


# ---------------------------------------------------------------------------
# Colorazione semantica
# ---------------------------------------------------------------------------

#: Tipi di token semantici (indici nella legenda) e modificatori.
TIPI_SEMANTICI = ["keyword", "variable", "string", "number", "comment", "function", "parameter",
                  "property", "operator", "class", "event", "enumMember", "type"]
MODIFICATORI_SEMANTICI = ["declaration", "readonly", "defaultLibrary"]
LEGENDA_SEMANTICA = {"tokenTypes": TIPI_SEMANTICI, "tokenModifiers": MODIFICATORI_SEMANTICI}

#: Categoria di leo.colorazione -> (tipo, modificatori)
_CATEGORIE_SEMANTICHE: dict[str, tuple[str, tuple[str, ...]]] = {
    "flusso": ("keyword", ()), "dichiarazioni": ("keyword", ()), "errori": ("keyword", ()),
    "logici": ("keyword", ()), "valori_speciali": ("enumMember", ("readonly", "defaultLibrary")),
    "numeri": ("number", ()), "testi": ("string", ()), "interpolazione": ("variable", ()),
    "libreria": ("function", ("defaultLibrary",)), "funzioni_utente": ("function", ()),
    "controlli": ("class", ()), "proprieta": ("property", ()), "commenti": ("comment", ()),
    "variabili": ("variable", ()), "costanti": ("variable", ("readonly",)),
    "parametri": ("parameter", ()), "campi": ("property", ()), "eventi": ("event", ()),
    "operatori": ("operator", ()),
}


def token_semantici(doc: Documento, segmenti: Iterable[Any], dichiarazioni: set[tuple[int, int]] = frozenset()
                    ) -> dict[str, Any]:
    dati: list[int] = []
    riga_prec, col_prec = 0, 0
    for g in segmenti:
        categoria = getattr(getattr(g, "categoria", None), "value", "")
        voce = _CATEGORIE_SEMANTICHE.get(categoria)
        if voce is None or g.lunghezza <= 0:
            continue
        tipo, modificatori = voce
        mod = 0
        for m in modificatori:
            mod |= 1 << MODIFICATORI_SEMANTICI.index(m)
        if (g.riga, g.colonna) in dichiarazioni:
            mod |= 1
        inizio = doc.a_lsp(g.riga, g.colonna)
        fine = doc.a_lsp(g.riga, g.colonna + g.lunghezza)
        lunghezza = fine["character"] - inizio["character"]
        if lunghezza <= 0:
            continue
        linea, carattere = inizio["line"], inizio["character"]
        delta_riga = linea - riga_prec
        delta_col = carattere - col_prec if delta_riga == 0 else carattere
        if delta_riga < 0 or (delta_riga == 0 and delta_col < 0):
            continue                                   # sovrapposizione: si salta
        dati.extend((delta_riga, delta_col, lunghezza, TIPI_SEMANTICI.index(tipo), mod))
        riga_prec, col_prec = linea, carattere
    return {"data": dati}
