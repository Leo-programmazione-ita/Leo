"""Simboli di un programma Leo: dichiarazioni, usi, blocchi e ambiti.

Serve a "vai alla definizione", "trova i riferimenti", "rinomina", "evidenzia
le occorrenze", la struttura del documento e la piegatura dei blocchi.

L'analisi lavora sui **token** del lexer in modalita' tollerante (la stessa
della colorazione), non sull'albero del parser: cosi' funziona anche mentre il
file contiene errori, cioe' quasi sempre mentre si scrive.

Regole (le stesse dell'interprete):

* ``funzione`` e ``quando`` aprono un ambito nuovo: i parametri e le variabili
  dichiarate dentro valgono solo li'; ``evento`` e' il parametro implicito di
  ``quando``;
* ``variabile``, ``costante``, ``per ogni``, ``cattura ... come`` e i parametri
  dichiarano un nome; la prima assegnazione ``x = ...`` di un nome mai visto
  vale come dichiarazione (stile implicito, o codice ancora da correggere);
* un uso si collega alla dichiarazione piu' vicina risalendo gli ambiti; nello
  stesso ambito vince l'ultima dichiarazione che lo precede (due ``per ogni i``
  sono due variabili diverse), altrimenti la prima;
* ``oggetto.nome`` non e' un uso di ``nome`` (e' una proprieta'), un argomento
  con nome ``f(separatore = " ")`` nemmeno; dentro ``"Ciao {nome}"`` si'.

API::

    analizza_simboli(sorgente, nome_file="<editor>", **opzioni_lessico) -> Analisi
    Analisi.simbolo_in(riga, colonna) -> Simbolo | None
    Analisi.riferimenti(simbolo, dichiarazione=True) -> list[Occorrenza]
    nome_valido(nome) -> bool
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Iterable

__all__ = ["Simbolo", "Occorrenza", "Blocco", "Ambito", "Analisi", "analizza_simboli", "nome_valido",
           "PAROLE_RISERVATE"]

_RE_NOME = re.compile(r"^[^\W\d]\w*$", re.UNICODE)


@dataclass(eq=False)
class Simbolo:
    """Un nome dichiarato. ``tipo``: variabile, costante, funzione, parametro, ciclo, cattura."""

    nome: str
    tipo: str
    riga: int
    colonna: int
    ambito: "Ambito"
    dettaglio: str = ""
    blocco: "Blocco | None" = None          # per le funzioni: il loro blocco (fino a `fine`)

    @property
    def lunghezza(self) -> int:
        return len(self.nome)


@dataclass
class Occorrenza:
    """Un punto del testo in cui compare un nome (dichiarazione o uso)."""

    nome: str
    riga: int
    colonna: int
    simbolo: Simbolo | None = None
    dichiarazione: bool = False
    scrittura: bool = False                 # assegnazione (per l'evidenziazione)

    @property
    def lunghezza(self) -> int:
        return len(self.nome)


@dataclass(eq=False)
class Blocco:
    """Un blocco chiuso da ``fine`` (o non ancora chiuso: ``riga_fine`` = ultima riga)."""

    tipo: str                               # se, mentre, per ogni, ripeti, funzione, quando, prova, inizio, scegli...
    riga: int
    colonna: int
    riga_fine: int = 0
    titolo: str = ""
    chiuso: bool = False
    figli: list["Blocco"] = field(default_factory=list)
    simbolo: Simbolo | None = None


@dataclass(eq=False)
class Ambito:
    inizio: int
    fine: int
    genitore: "Ambito | None" = None
    nomi: dict[str, list[Simbolo]] = field(default_factory=dict)
    blocco: Blocco | None = None
    impliciti: frozenset[str] = frozenset()

    def aggiungi(self, simbolo: Simbolo) -> None:
        self.nomi.setdefault(simbolo.nome, []).append(simbolo)

    def cerca_qui(self, nome: str, riga: int, colonna: int) -> Simbolo | None:
        candidati = self.nomi.get(nome)
        if not candidati:
            return None
        prima = [s for s in candidati if (s.riga, s.colonna) <= (riga, colonna)]
        return prima[-1] if prima else candidati[0]

    def cerca(self, nome: str, riga: int, colonna: int) -> Simbolo | None:
        ambito: Ambito | None = self
        while ambito is not None:
            trovato = ambito.cerca_qui(nome, riga, colonna)
            if trovato is not None:
                return trovato
            ambito = ambito.genitore
        return None

    def ha_implicito(self, nome: str) -> bool:
        ambito: Ambito | None = self
        while ambito is not None:
            if nome in ambito.impliciti:
                return True
            ambito = ambito.genitore
        return False


@dataclass
class Analisi:
    simboli: list[Simbolo] = field(default_factory=list)
    occorrenze: list[Occorrenza] = field(default_factory=list)
    blocchi: list[Blocco] = field(default_factory=list)          # in ordine di apertura
    radici: list[Blocco] = field(default_factory=list)           # blocchi di primo livello
    globale: Ambito | None = None
    importati: list[str] = field(default_factory=list)           # nomi dopo `importa`

    def occorrenza_in(self, riga: int, colonna: int) -> Occorrenza | None:
        """L'occorrenza sotto il cursore (anche col cursore subito dopo il nome)."""
        migliore = None
        for o in self.occorrenze:
            if o.riga == riga and o.colonna <= colonna <= o.colonna + o.lunghezza:
                if migliore is None or o.colonna <= colonna < o.colonna + o.lunghezza:
                    migliore = o
        return migliore

    def simbolo_in(self, riga: int, colonna: int) -> Simbolo | None:
        o = self.occorrenza_in(riga, colonna)
        return o.simbolo if o is not None else None

    def riferimenti(self, simbolo: Simbolo, dichiarazione: bool = True) -> list[Occorrenza]:
        return [o for o in self.occorrenze if o.simbolo is simbolo and (dichiarazione or not o.dichiarazione)]

    def globali(self, nome: str) -> Simbolo | None:
        if self.globale is None:
            return None
        candidati = self.globale.nomi.get(nome)
        return candidati[0] if candidati else None


#: Parole che non possono diventare nomi (rinomina).
def _parole_riservate() -> frozenset[str]:
    try:
        from ..tokens import COPPIE_DI_PAROLE, PAROLE_CHIAVE, PAROLE_DI_CONTESTO

        parole = set(PAROLE_CHIAVE) | set(PAROLE_DI_CONTESTO)
        for coppia in COPPIE_DI_PAROLE:
            parole.update(coppia)
        return frozenset(parole)
    except Exception:  # noqa: BLE001
        return frozenset()


PAROLE_RISERVATE = _parole_riservate()


def nome_valido(nome: str) -> bool:
    return bool(nome) and bool(_RE_NOME.match(nome)) and nome not in PAROLE_RISERVATE


# ---------------------------------------------------------------------------
# Analisi
# ---------------------------------------------------------------------------

def _token(sorgente: str, nome_file: str, opzioni: dict[str, Any]) -> list:
    from ..esecuzione import tokenizza

    try:
        return tokenizza(sorgente, nome_file, conserva_commenti=True, tollerante=True, **opzioni)
    except Exception:  # noqa: BLE001 - opzioni di progetto rotte: si riprova senza
        return tokenizza(sorgente, nome_file, conserva_commenti=True, tollerante=True)


def analizza_simboli(sorgente: str, nome_file: str = "<editor>", **opzioni: Any) -> Analisi:
    """Analisi dei simboli di ``sorgente`` (mai eccezioni: al peggio un'analisi vuota)."""
    try:
        token = _token(sorgente or "", nome_file, opzioni)
    except Exception:  # noqa: BLE001
        return Analisi(globale=Ambito(1, 1))
    try:
        return _Analizzatore(token, (sorgente or "").split("\n")).esegui()
    except Exception:  # noqa: BLE001 - un caso non previsto non deve spegnere l'editor
        return Analisi(globale=Ambito(1, 1))


class _Analizzatore:
    def __init__(self, token: list, righe: list[str]) -> None:
        from ..tokens import TipoToken as T

        self.T = T
        self.righe = righe
        self.tutti = token
        self.sig = [t for t in token if t.tipo not in (T.COMMENTO, T.ERRORE, T.FINE_FILE)]
        ultima = max(len(righe), max((t.riga for t in self.sig), default=1))
        self.ultima = ultima
        self.globale = Ambito(1, ultima)
        self.analisi = Analisi(globale=self.globale)
        self.usi: list[tuple[Occorrenza, Ambito]] = []
        try:
            from ..tokens import teste_di_blocco_potenza

            teste = teste_di_blocco_potenza(token)
            self.teste_potenza = {id(token[k]) for k in teste}
        except Exception:  # noqa: BLE001
            self.teste_potenza = set()
        self.apri = {T.SE: "se", T.MENTRE: "mentre", T.PER_OGNI: "per ogni", T.RIPETI: "ripeti",
                     T.FUNZIONE: "funzione", T.PROVA: "prova", T.QUANDO: "quando"}
        inizio = getattr(T, "INIZIO", None)
        if inizio is not None:
            self.apri[inizio] = "inizio"
        self.etichette = {T.SE, T.MENTRE, T.PER_OGNI, T.RIPETI, T.FUNZIONE, T.PROVA, T.QUANDO}
        if inizio is not None:
            self.etichette.add(inizio)
        self.assegnazioni = {T.ASSEGNA, T.PIU_ASSEGNA, T.MENO_ASSEGNA, T.PER_ASSEGNA, T.DIVISO_ASSEGNA}

    # --- utilita' --------------------------------------------------------------

    def _testo_riga(self, riga: int) -> str:
        return self.righe[riga - 1].strip() if 1 <= riga <= len(self.righe) else ""

    def _dichiara(self, tok, tipo: str, ambito: Ambito, dettaglio: str = "") -> Simbolo:
        nome = str(tok.valore)
        simbolo = Simbolo(nome, tipo, tok.riga, tok.colonna, ambito, dettaglio)
        ambito.aggiungi(simbolo)
        self.analisi.simboli.append(simbolo)
        self.analisi.occorrenze.append(Occorrenza(nome, tok.riga, tok.colonna, simbolo, True, True))
        return simbolo

    def _usa(self, tok, ambito: Ambito, scrittura: bool = False) -> None:
        occ = Occorrenza(str(tok.valore), tok.riga, tok.colonna, None, False, scrittura)
        self.analisi.occorrenze.append(occ)
        self.usi.append((occ, ambito))

    def _nomi_elenco(self, i: int) -> tuple[list, int]:
        """``a, b, c`` da ``sig[i]``: token dei nomi e indice dopo l'elenco."""
        T = self.T
        nomi = []
        sig = self.sig
        while i < len(sig) and sig[i].tipo is T.NOME:
            nomi.append(sig[i])
            i += 1
            if i < len(sig) and sig[i].tipo is T.VIRGOLA:
                i += 1
            else:
                break
        return nomi, i

    def _interpolazioni(self, tok, ambito: Ambito) -> None:
        T = self.T
        for parte in tok.valore or ():
            for t in getattr(parte, "token", None) or ():
                if t.tipo is T.NOME:
                    self._usa(t, ambito)
                elif t.tipo is T.TESTO_INTERPOLATO:
                    self._interpolazioni(t, ambito)

    # --- giro principale -------------------------------------------------------

    def esegui(self) -> Analisi:
        T = self.T
        sig = self.sig
        n = len(sig)
        pila: list[tuple[Blocco, Ambito | None]] = []
        ambito = self.globale
        profondita = 0                          # parentesi aperte nella riga
        inizio_istruzione = True
        salta: set[int] = set()
        i = 0
        while i < n:
            tok = sig[i]
            tipo = tok.tipo
            if i in salta:
                i += 1
                inizio_istruzione = False
                continue
            a_inizio = inizio_istruzione
            inizio_istruzione = tipo in (T.FINE_RIGA, T.ALLORA, T.FAI, T.ALTRIMENTI, T.PROVA, T.INFINE)
            if tipo is T.FINE_RIGA:
                profondita = 0
                i += 1
                continue
            if tipo in (T.PARENTESI_APERTA, T.QUADRA_APERTA, T.GRAFFA_APERTA):
                profondita += 1
            elif tipo in (T.PARENTESI_CHIUSA, T.QUADRA_CHIUSA, T.GRAFFA_CHIUSA):
                profondita = max(0, profondita - 1)
            elif tipo is T.TESTO_INTERPOLATO:
                self._interpolazioni(tok, ambito)
            elif tipo is T.FINE:
                # `fine se`, `fine per ogni`, `fine in parallelo`: l'etichetta non apre nulla
                j = i + 1
                while j < n and sig[j].riga == tok.riga and (
                        sig[j].tipo in self.etichette or sig[j].tipo is T.IN or
                        (sig[j].tipo is T.NOME and sig[j].valore in (
                            "per", "ogni", "scegli", "dopo", "verifica", "aspettati", "parallelo", "inizio"))):
                    salta.add(j)
                    j += 1
                    if j - i > 2:
                        break
                if pila:
                    blocco, nuovo = pila.pop()
                    blocco.riga_fine = tok.riga
                    blocco.chiuso = True
                    if nuovo is not None:
                        nuovo.fine = tok.riga
                        ambito = nuovo.genitore or self.globale
            elif tipo in self.apri or id(tok) in self.teste_potenza or (
                    tipo is T.NOME and tok.valore == "scegli" and a_inizio and i + 1 < n
                    and sig[i + 1].tipo not in self.assegnazioni and sig[i + 1].tipo is not T.FINE_RIGA
                    and sig[i + 1].riga == tok.riga
                    and not (sig[i + 1].tipo is T.PARENTESI_APERTA
                             and sig[i + 1].colonna == tok.colonna + len(str(tok.valore)))):
                nome_blocco = self.apri.get(tipo) or str(tok.valore)
                blocco = Blocco(nome_blocco, tok.riga, tok.colonna, titolo=self._testo_riga(tok.riga))
                (pila[-1][0].figli if pila else self.analisi.radici).append(blocco)
                self.analisi.blocchi.append(blocco)
                nuovo_ambito: Ambito | None = None
                if tipo is T.FUNZIONE:
                    nuovo_ambito = Ambito(tok.riga, self.ultima, ambito, blocco=blocco)
                    i = self._funzione(i, ambito, nuovo_ambito, blocco)
                    ambito = nuovo_ambito
                    pila.append((blocco, nuovo_ambito))
                    inizio_istruzione = True
                    continue
                if tipo is T.QUANDO:
                    nuovo_ambito = Ambito(tok.riga, self.ultima, ambito, blocco=blocco,
                                          impliciti=frozenset({"evento"}))
                    ambito = nuovo_ambito
                pila.append((blocco, nuovo_ambito))
                if tipo is T.PER_OGNI:
                    nomi, j = self._nomi_elenco(i + 1)
                    for t in nomi:
                        self._dichiara(t, "ciclo", ambito, self._testo_riga(t.riga))
                    i = j
                    continue
            elif tipo is T.VARIABILE or tipo is T.COSTANTE:
                nomi, j = self._nomi_elenco(i + 1)
                for t in nomi:
                    self._dichiara(t, "variabile" if tipo is T.VARIABILE else "costante", ambito,
                                   self._testo_riga(t.riga))
                i = j
                continue
            elif tipo is T.CATTURA:
                j = i + 1
                while j < n and sig[j].riga == tok.riga and sig[j].tipo is not T.FINE_RIGA:
                    if sig[j].tipo is T.NOME and sig[j - 1].tipo is T.COME:
                        self._dichiara(sig[j], "cattura", ambito, self._testo_riga(sig[j].riga))
                    elif sig[j].tipo is T.NOME:
                        pass                                    # tipo d'errore (ErroreValore)
                    j += 1
                i = j
                continue
            elif tipo is T.NOME:
                if tok.valore == "importa" and a_inizio and i + 1 < n and sig[i + 1].riga == tok.riga:
                    seguente = sig[i + 1]
                    if seguente.tipo in (T.TESTO, T.NOME):
                        self.analisi.importati.append(str(seguente.valore))
                    i += 1
                    continue
                precedente = sig[i - 1] if i > 0 else None
                if precedente is not None and precedente.tipo is T.PUNTO:
                    i += 1
                    continue                                    # proprieta' o metodo
                seguente = sig[i + 1] if i + 1 < n else None
                if (profondita > 0 and seguente is not None and seguente.tipo is T.ASSEGNA and precedente is not None
                        and precedente.tipo in (T.PARENTESI_APERTA, T.VIRGOLA)):
                    i += 1
                    continue                                    # argomento con nome
                if a_inizio and profondita == 0:
                    nomi, j = self._nomi_elenco(i)
                    if j < n and sig[j].tipo in self.assegnazioni and sig[j].riga == tok.riga:
                        for t in nomi:
                            nome = str(t.valore)
                            if (sig[j].tipo is T.ASSEGNA and ambito.cerca(nome, t.riga, t.colonna) is None
                                    and not ambito.ha_implicito(nome) and not self._dichiarato_dopo(nome, ambito)):
                                self._dichiara(t, "variabile", ambito, self._testo_riga(t.riga))
                            else:
                                self._usa(t, ambito, scrittura=True)
                        i = j
                        continue
                self._usa(tok, ambito)
            i += 1
        for blocco, nuovo in pila:                               # blocchi non chiusi
            blocco.riga_fine = self.ultima
            if nuovo is not None:
                nuovo.fine = self.ultima
        self._risolvi()
        self.analisi.occorrenze.sort(key=lambda o: (o.riga, o.colonna))
        return self.analisi

    def _dichiarato_dopo(self, nome: str, ambito: Ambito) -> bool:
        """Vero se ``variabile nome`` arriva piu' avanti nello stesso ambito (non e' una
        dichiarazione implicita: e' un uso prima della dichiarazione)."""
        T = self.T
        for k, t in enumerate(self.sig):
            if t.tipo in (T.VARIABILE, T.COSTANTE) and k + 1 < len(self.sig) and \
                    self.sig[k + 1].tipo is T.NOME and self.sig[k + 1].valore == nome and \
                    ambito.inizio <= t.riga <= ambito.fine:
                return True
        return False

    def _funzione(self, i: int, esterno: Ambito, interno: Ambito, blocco: Blocco) -> int:
        """``funzione nome(a, b = 1, resto...)``: dichiara nome e parametri; indice dopo la riga."""
        T = self.T
        sig = self.sig
        n = len(sig)
        tok = sig[i]
        j = i + 1
        firma = self._testo_riga(tok.riga)
        if firma.startswith("funzione "):
            firma = firma[len("funzione "):]
        simbolo = None
        if j < n and sig[j].tipo is T.NOME and sig[j].riga == tok.riga:
            simbolo = self._dichiara(sig[j], "funzione", esterno, firma)
            simbolo.blocco = blocco
            blocco.simbolo = simbolo
            j += 1
        if j < n and sig[j].tipo is T.PARENTESI_APERTA:
            livello = 0
            while j < n and sig[j].tipo is not T.FINE_RIGA:
                t = sig[j]
                if t.tipo in (T.PARENTESI_APERTA, T.QUADRA_APERTA, T.GRAFFA_APERTA):
                    livello += 1
                elif t.tipo in (T.PARENTESI_CHIUSA, T.QUADRA_CHIUSA, T.GRAFFA_CHIUSA):
                    livello -= 1
                    if livello <= 0:
                        j += 1
                        break
                elif t.tipo is T.NOME and livello == 1 and sig[j - 1].tipo in (
                        T.PARENTESI_APERTA, T.VIRGOLA, T.TRE_PUNTI):
                    self._dichiara(t, "parametro", interno, firma)
                elif t.tipo is T.NOME:
                    self._usa(t, esterno)                       # valori predefiniti
                j += 1
        return j

    def _risolvi(self) -> None:
        for occ, ambito in self.usi:
            occ.simbolo = ambito.cerca(occ.nome, occ.riga, occ.colonna)


def simboli_globali(analisi: Analisi) -> Iterable[Simbolo]:
    if analisi.globale is None:
        return []
    return [lista[0] for lista in analisi.globale.nomi.values() if lista]
