"""Documenti aperti nell'editor e conversione delle posizioni.

Leo conta righe e colonne **da 1, in caratteri** (punti di codice Unicode);
il Language Server Protocol conta **da 0** e, salvo accordi diversi, le colonne
sono in **unita' UTF-16** (quelle di JavaScript e di Visual Studio Code). Una
lettera accentata vale 1 in entrambi; un'emoji vale 1 per Leo e 2 per UTF-16.
Qui sta tutta la conversione: il resto del server ragiona come Leo.

Il testo si conserva con i soli ``\\n`` (``\\r\\n`` e ``\\r`` diventano ``\\n``),
come fa il lexer: righe e colonne restano le stesse.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from urllib.parse import quote, unquote, urlparse
import os
import sys

__all__ = ["Documento", "Codifica", "uri_a_percorso", "percorso_a_uri", "normalizza"]


def normalizza(testo: str) -> str:
    testo = (testo or "").replace("\r\n", "\n").replace("\r", "\n")
    return testo[1:] if testo.startswith("\ufeff") else testo


class Codifica:
    """Unita' delle colonne concordata con il client: ``utf-16`` (predefinita), ``utf-32`` o ``utf-8``."""

    UTF16 = "utf-16"
    UTF32 = "utf-32"
    UTF8 = "utf-8"

    @staticmethod
    def scegli(offerte: Any) -> str:
        """La codifica da usare tra quelle offerte dal client (``general.positionEncodings``).

        Si preferisce ``utf-32`` (colonne uguali a quelle di Leo), poi ``utf-16``.
        """
        if isinstance(offerte, list):
            if Codifica.UTF32 in offerte:
                return Codifica.UTF32
            if Codifica.UTF16 in offerte or not offerte:
                return Codifica.UTF16
            if Codifica.UTF8 in offerte:
                return Codifica.UTF8
        return Codifica.UTF16


def _unita(testo: str, codifica: str) -> int:
    """Lunghezza di ``testo`` nelle unita' della codifica."""
    if codifica == Codifica.UTF32 or testo.isascii():
        return len(testo)
    if codifica == Codifica.UTF8:
        return len(testo.encode("utf-8"))
    return len(testo.encode("utf-16-le")) // 2


def _caratteri(riga: str, unita: int, codifica: str) -> int:
    """Quanti caratteri di ``riga`` occupano ``unita`` unita' (arrotondando in basso)."""
    if unita <= 0:
        return 0
    if codifica == Codifica.UTF32 or riga.isascii():
        return min(unita, len(riga))
    contate = 0
    for i, ch in enumerate(riga):
        passo = _unita(ch, codifica)
        if contate + passo > unita:
            return i
        contate += passo
    return len(riga)


@dataclass
class Documento:
    """Un file aperto nell'editor."""

    uri: str
    testo: str
    versione: int = 0
    lingua: str = "leo"
    codifica: str = Codifica.UTF16
    _righe: list[str] | None = field(default=None, repr=False)

    def __post_init__(self) -> None:
        self.testo = normalizza(self.testo)

    # --- righe -----------------------------------------------------------------

    @property
    def righe(self) -> list[str]:
        if self._righe is None:
            self._righe = self.testo.split("\n")
        return self._righe

    def riga(self, numero: int) -> str:
        """Testo della riga ``numero`` (da 1); ``""`` fuori dal documento."""
        righe = self.righe
        return righe[numero - 1] if 1 <= numero <= len(righe) else ""

    @property
    def percorso(self) -> str | None:
        return uri_a_percorso(self.uri)

    @property
    def nome_file(self) -> str:
        percorso = self.percorso
        return percorso if percorso else (self.uri.rsplit("/", 1)[-1] or "<editor>")

    # --- posizioni -------------------------------------------------------------

    def a_lsp(self, riga: int, colonna: int) -> dict[str, int]:
        """Da (riga, colonna) di Leo (da 1, caratteri) a ``Position`` del protocollo."""
        righe = self.righe
        if riga < 1:
            return {"line": 0, "character": 0}
        if riga > len(righe):
            ultima = righe[-1] if righe else ""
            return {"line": max(0, len(righe) - 1), "character": _unita(ultima, self.codifica)}
        testo = righe[riga - 1]
        colonna = max(1, min(colonna, len(testo) + 1))
        return {"line": riga - 1, "character": _unita(testo[:colonna - 1], self.codifica)}

    def da_lsp(self, posizione: dict[str, Any]) -> tuple[int, int]:
        """Da ``Position`` del protocollo a (riga, colonna) di Leo, dentro il documento."""
        righe = self.righe
        linea = int(posizione.get("line", 0) or 0)
        carattere = int(posizione.get("character", 0) or 0)
        if linea < 0:
            return 1, 1
        if linea >= len(righe):
            ultima = righe[-1] if righe else ""
            return len(righe), len(ultima) + 1
        testo = righe[linea]
        return linea + 1, _caratteri(testo, carattere, self.codifica) + 1

    def intervallo(self, riga: int, colonna: int, lunghezza: int) -> dict[str, Any]:
        """``Range`` di ``lunghezza`` caratteri (sulla stessa riga, tagliato a fine riga)."""
        testo = self.riga(riga)
        fine = max(colonna, min(colonna + max(lunghezza, 0), len(testo) + 1))
        return {"start": self.a_lsp(riga, colonna), "end": self.a_lsp(riga, fine)}

    def intervallo_tra(self, riga: int, colonna: int, riga_fine: int, colonna_fine: int) -> dict[str, Any]:
        return {"start": self.a_lsp(riga, colonna), "end": self.a_lsp(riga_fine, colonna_fine)}

    def tutto(self) -> dict[str, Any]:
        """``Range`` dell'intero documento."""
        righe = self.righe
        return {"start": {"line": 0, "character": 0},
                "end": {"line": max(0, len(righe) - 1), "character": _unita(righe[-1] if righe else "", self.codifica)}}

    def scostamento(self, riga: int, colonna: int) -> int:
        """Indice nel testo di (riga, colonna) di Leo."""
        righe = self.righe
        riga = max(1, min(riga, len(righe)))
        base = sum(len(r) + 1 for r in righe[:riga - 1])
        return base + max(0, min(colonna - 1, len(righe[riga - 1])))

    def lunghezza_lsp(self, testo: str) -> int:
        return _unita(testo, self.codifica)

    # --- modifiche -------------------------------------------------------------

    def applica(self, modifiche: list[dict[str, Any]], versione: int | None = None) -> None:
        """Applica ``contentChanges`` di ``didChange`` (complete o a intervalli)."""
        testo = self.testo
        for modifica in modifiche or []:
            nuovo = normalizza(str(modifica.get("text", "")))
            intervallo = modifica.get("range")
            if not intervallo:
                testo = nuovo
                self._imposta(testo)
                continue
            self._imposta(testo)
            a = self.scostamento(*self.da_lsp(intervallo["start"]))
            b = self.scostamento(*self.da_lsp(intervallo["end"]))
            if b < a:
                a, b = b, a
            testo = testo[:a] + nuovo + testo[b:]
            self._imposta(testo)
        self._imposta(testo)
        if versione is not None:
            self.versione = versione

    def _imposta(self, testo: str) -> None:
        if testo is not self.testo:
            self.testo = testo
            self._righe = None


# ---------------------------------------------------------------------------
# URI <-> percorsi
# ---------------------------------------------------------------------------

def uri_a_percorso(uri: str) -> str | None:
    """``file:///C:/Users/a/x.leo`` -> ``C:\\Users\\a\\x.leo``; ``None`` per gli URI non ``file:``."""
    if not uri:
        return None
    analisi = urlparse(uri)
    if analisi.scheme != "file":
        return None
    percorso = unquote(analisi.path)
    if analisi.netloc and analisi.netloc != "localhost":
        percorso = f"//{analisi.netloc}{percorso}"          # percorso di rete UNC
    if os.name == "nt" or sys.platform == "win32":
        if len(percorso) >= 3 and percorso[0] == "/" and percorso[2] == ":":
            percorso = percorso[1:]
        percorso = percorso.replace("/", "\\")
    return percorso


def percorso_a_uri(percorso: str) -> str:
    assoluto = os.path.abspath(percorso)
    if os.name == "nt":
        assoluto = "/" + assoluto.replace("\\", "/")
    return "file://" + quote(assoluto, safe="/:")
