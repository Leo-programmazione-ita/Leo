"""Aggancio del controllo statico (``leo controlla``) al server del linguaggio.

Il server non sa nulla di come funziona il controllo statico: chiede soltanto
a chi si e' registrato un elenco di avvisi per il file aperto e li mostra
nell'editor insieme agli errori del parser. Cosi' il controllo statico si
puo' scrivere, cambiare o togliere senza toccare il server.

Due modi per agganciarsi:

1. **Automatico**: il server usa :func:`leo.controllo.diagnostica_editor` (le
   diagnostiche di ``leo controlla``, :meth:`leo.controllo.Diagnostica.come_lsp`),
   oppure il modulo indicato dalla variabile d'ambiente
   ``LEO_LSP_CONTROLLO="pacchetto.modulo:funzione"`` (senza funzione: la prima
   che trova tra :data:`NOMI_CERCATI`).
2. **Esplicito**: il modulo chiama ``leo.lsp.controllo_statico.registra(funzione)``.

Contratto della funzione::

    funzione(sorgente: str, nome_file: str, **opzioni_lessico) -> Iterable[avviso]

``opzioni_lessico`` sono quelle di ``leo.esecuzione.analizza`` (``rigoroso``,
``stile``, ``sinonimi_extra``, ``dizionari_sinonimi``); la funzione puo'
ignorarle (se non le accetta il server la richiama senza). Ogni avviso puo'
essere un dizionario o un oggetto con questi campi (gli altri si ignorano):

    riga, colonna            da 1, in caratteri (obbligatori; colonna 0 = riga intera)
    lunghezza                caratteri da sottolineare (oppure riga_fine/colonna_fine)
    messaggio                frase in italiano (obbligatorio)
    gravita                  "errore" | "avviso" | "informazione" | "suggerimento"
                             (anche livello/severita; predefinito "avviso")
    codice                   identificativo breve (es. "variabile-non-usata"; anche tipo)
    suggerimento             frase aggiunta sotto il messaggio
    correzioni               elenco di leo.errori.Correzione (diventano correzioni rapide)

Se la funzione solleva un'eccezione, il server la ignora per quel file (e la
scrive nel registro dell'editor): il controllo statico non deve mai spegnere
la diagnostica di base.
"""

from __future__ import annotations

import importlib
import inspect
import os
import sys
from typing import Any, Callable, Iterable, Mapping

__all__ = ["registra", "togli", "controlli_registrati", "esegui_controlli", "NOMI_CERCATI", "attivo"]

#: Funzioni cercate nel modulo del controllo statico, in ordine.
NOMI_CERCATI = ("diagnostica_editor", "controlla_sorgente", "controlla_testo", "controlla")

_registrati: list[Callable[..., Iterable[Any]]] = []
_scoperta_fatta = False
_attivo = True


def registra(funzione: Callable[..., Iterable[Any]]) -> Callable[..., Iterable[Any]]:
    """Aggiunge un controllo (usabile anche come decoratore)."""
    if funzione not in _registrati:
        _registrati.append(funzione)
    return funzione


def togli(funzione: Callable[..., Iterable[Any]]) -> None:
    if funzione in _registrati:
        _registrati.remove(funzione)


def attivo(valore: bool | None = None) -> bool:
    """Accende o spegne il controllo statico (impostazione ``leo.controlloStatico``)."""
    global _attivo
    if valore is not None:
        _attivo = bool(valore)
    return _attivo


def _scopri() -> None:
    """Cerca una volta il modulo del controllo statico."""
    global _scoperta_fatta
    if _scoperta_fatta:
        return
    _scoperta_fatta = True
    indicato = os.environ.get("LEO_LSP_CONTROLLO", "").strip()
    candidati: list[tuple[str, str | None]] = []
    if indicato:
        modulo, _, nome = indicato.partition(":")
        candidati.append((modulo.strip(), nome.strip() or None))
    candidati.append(("leo.controllo", "diagnostica_editor"))   # leo controlla (leo/controllo/)
    for nome_modulo, nome_funzione in candidati:
        try:
            modulo = importlib.import_module(nome_modulo)
        except ImportError:
            continue
        except Exception as e:  # noqa: BLE001
            print(f"leo lsp: non riesco a caricare il controllo statico `{nome_modulo}`: {e}", file=sys.stderr)
            continue
        nomi = (nome_funzione,) if nome_funzione else NOMI_CERCATI
        for nome in nomi:
            funzione = getattr(modulo, nome, None)
            if callable(funzione):
                registra(funzione)
                break


def controlli_registrati() -> list[Callable[..., Iterable[Any]]]:
    _scopri()
    return list(_registrati)


def _campo(voce: Any, *nomi: str, predefinito: Any = None) -> Any:
    for nome in nomi:
        if isinstance(voce, Mapping):
            if nome in voce and voce[nome] is not None:
                return voce[nome]
        else:
            valore = getattr(voce, nome, None)
            if valore is not None:
                return valore
    return predefinito


_GRAVITA = {
    "errore": "errore", "error": "errore", "1": "errore",
    "avviso": "avviso", "attenzione": "avviso", "warning": "avviso", "2": "avviso",
    "informazione": "informazione", "info": "informazione", "nota": "informazione", "3": "informazione",
    "suggerimento": "suggerimento", "consiglio": "suggerimento", "hint": "suggerimento", "4": "suggerimento",
}


def _chiama(funzione: Callable[..., Iterable[Any]], sorgente: str, nome_file: str,
            opzioni: Mapping[str, Any]) -> Iterable[Any]:
    try:
        parametri = inspect.signature(funzione).parameters
        accetta_tutto = any(p.kind is inspect.Parameter.VAR_KEYWORD for p in parametri.values())
        extra = {k: v for k, v in opzioni.items() if accetta_tutto or k in parametri}
    except (TypeError, ValueError):
        extra = {}
    return funzione(sorgente, nome_file, **extra) or ()


def esegui_controlli(sorgente: str, nome_file: str, opzioni: Mapping[str, Any] | None = None, *,
                     analizzabile: bool = True) -> list:
    """Avvisi (:class:`leo.lsp.diagnostica.Avviso`) di tutti i controlli registrati."""
    from .diagnostica import Avviso

    if not _attivo:
        return []
    righe = (sorgente or "").split("\n")
    risultato: list = []
    for funzione in controlli_registrati():
        try:
            voci = list(_chiama(funzione, sorgente, nome_file, dict(opzioni or {})))
        except Exception as e:  # noqa: BLE001
            nome = getattr(funzione, "__qualname__", repr(funzione))
            print(f"leo lsp: il controllo statico `{nome}` si è fermato: {type(e).__name__}: {e}", file=sys.stderr)
            continue
        for voce in voci:
            try:
                riga = int(_campo(voce, "riga", predefinito=0) or 0)
                messaggio = str(_campo(voce, "messaggio", "message", predefinito="") or "").strip()
                if riga < 1 or not messaggio:
                    continue
                testo = righe[riga - 1] if riga <= len(righe) else ""
                colonna = int(_campo(voce, "colonna", predefinito=0) or 0)
                if colonna < 1:
                    colonna = len(testo) - len(testo.lstrip()) + 1
                    riga_fine, colonna_fine = riga, len(testo.rstrip()) + 1
                else:
                    riga_fine = int(_campo(voce, "riga_fine", predefinito=riga) or riga)
                    colonna_fine = _campo(voce, "colonna_fine")
                    if colonna_fine is None:
                        lunghezza = int(_campo(voce, "lunghezza", predefinito=1) or 1)
                        colonna_fine = colonna + max(1, lunghezza)
                    colonna_fine = int(colonna_fine)
                gravita = str(_campo(voce, "gravita", "livello", "severita", predefinito="avviso")).lower()
                suggerimento = str(_campo(voce, "suggerimento", predefinito="") or "").strip()
                if suggerimento and suggerimento not in messaggio:
                    messaggio += "\n" + suggerimento
                correzioni = _campo(voce, "correzioni", predefinito=None)
                if correzioni is None:
                    singola = _campo(voce, "correzione")
                    correzioni = [singola] if singola is not None else []
                risultato.append(Avviso(riga, colonna, riga_fine, colonna_fine, messaggio,
                                        _GRAVITA.get(gravita, "avviso"),
                                        str(_campo(voce, "codice", "tipo", predefinito="") or ""),
                                        fonte="leo controlla", correzioni=list(correzioni)))
            except Exception:  # noqa: BLE001 - una voce strana non ferma le altre
                continue
    return risultato
