"""Stile delle dichiarazioni (sezione ``[stile]`` di progetto.toml) - CONTRATTO CONDIVISO.

Formato in ``progetto.toml``::

    [stile]
    variabili = "variabile"     # "crea variabile" | "variabile" | "sia" | "implicita" | parola propria
    costanti = "costante"       # "crea costante" | "costante" | "fissa" | parola propria
    funzioni = "funzione"       # "funzione" | "crea funzione" | "procedura" | parola propria
    parametri = "parentesi"     # "parentesi" -> somma(a, b) | "con" -> somma con a, b | "tipi" -> somma(a: intero, b: intero)
    predefiniti = "="           # "=" -> saluto = "Ciao" | "vale" -> saluto vale "Ciao"
    eventi = "quando"           # "quando" -> quando P.clic fai | "al" -> al clic di P fai

File sciolti: prima riga del sorgente ``#stile: variabile implicita, parametri con``
(elementi separati da virgola, ognuno ``<categoria> <valore>``; categorie:
``variabile(i)``, ``costante(i)``, ``funzione(i)``, ``parametri``,
``predefiniti``, ``eventi``).

Le forme CANONICHE (``crea variabile``/``variabile``, ``crea costante``/
``costante``, ``funzione``, ``(a, b)``, ``=``, ``quando``) sono SEMPRE accettate
dal lexer; lo stile aggiunge le forme scelte. Come le usa il lexer:
  * ``forme_lessicali()``: sequenze di parole da tradurre in un token canonico
    (es. ``("sia",) -> VARIABILE``, ``("vale",) -> ASSEGNA``);
  * ``parametri_con``: dopo ``funzione NOME`` la parola ``con`` apre una lista
    di parametri che finisce a fine riga -> il lexer emette ``(`` ... ``)`` sintetici;
  * ``eventi_al``: ``al EVENTO di CONTROLLO fai`` -> il lexer emette
    ``quando CONTROLLO . EVENTO fai``.
Solo l'interprete usa ``dichiarazione_implicita`` (``x = 0`` dichiara ``x`` se
non esiste). Il parser accetta sempre ``nome: tipo`` nei parametri.
"""

from __future__ import annotations

from dataclasses import dataclass, fields

from .errori import ErroreValore
from .tokens import TipoToken, PAROLE_CHIAVE

#: Valori ammessi "di serie" per ogni campo (il primo e' il predefinito).
SCELTE: dict[str, tuple[str, ...]] = {
    "variabili": ("variabile", "crea variabile", "sia", "implicita"),
    "costanti": ("costante", "crea costante", "fissa"),
    "funzioni": ("funzione", "crea funzione", "procedura"),
    "parametri": ("parentesi", "con", "tipi"),
    "predefiniti": ("=", "vale"),
    "eventi": ("quando", "al"),
}

#: Campi in cui l'utente puo' scegliere una parola propria.
CAMPI_PERSONALIZZABILI = ("variabili", "costanti", "funzioni")

_CATEGORIE_INTESTAZIONE = {
    "variabile": "variabili", "variabili": "variabili",
    "costante": "costanti", "costanti": "costanti",
    "funzione": "funzioni", "funzioni": "funzioni",
    "parametri": "parametri", "parametro": "parametri",
    "predefiniti": "predefiniti", "predefinito": "predefiniti",
    "eventi": "eventi", "evento": "eventi",
}

_TIPO_PER_CAMPO = {
    "variabili": TipoToken.VARIABILE,
    "costanti": TipoToken.COSTANTE,
    "funzioni": TipoToken.FUNZIONE,
}

#: Forme canoniche, che NON richiedono traduzione.
_CANONICHE = {"variabile", "crea variabile", "costante", "crea costante", "funzione"}


@dataclass
class Stile:
    variabili: str = "variabile"
    costanti: str = "costante"
    funzioni: str = "funzione"
    parametri: str = "parentesi"
    predefiniti: str = "="
    eventi: str = "quando"

    # --- costruzione --------------------------------------------------------
    @classmethod
    def da_dizionario(cls, dati: dict | None) -> "Stile":
        """Da ``progetto.toml`` intero o dalla sola sezione ``[stile]``."""
        if not dati:
            return cls()
        sezione = dati.get("stile", dati)
        valori = {}
        for f in fields(cls):
            if f.name in sezione:
                valori[f.name] = str(sezione[f.name]).strip()
        s = cls(**valori)
        s.valida()
        return s

    def a_dizionario(self) -> dict:
        return {f.name: getattr(self, f.name) for f in fields(self)}

    @classmethod
    def da_intestazione(cls, riga: str) -> "Stile | None":
        """``#stile: variabile implicita, parametri con`` -> Stile; None se la riga non e' un'intestazione."""
        testo = riga.strip()
        if not testo.startswith("#"):
            return None
        testo = testo[1:].strip()
        if not testo.lower().startswith("stile:"):
            return None
        valori: dict[str, str] = {}
        for elemento in testo[len("stile:"):].split(","):
            parole = elemento.split()
            if not parole:
                continue
            campo = _CATEGORIE_INTESTAZIONE.get(parole[0].lower())
            if campo is None or len(parole) < 2:
                raise ErroreValore(
                    f"Nell'intestazione `#stile:` non capisco `{elemento.strip()}`.",
                    suggerimento="Scrivi per esempio `#stile: variabile implicita, parametri con`.")
            valori[campo] = " ".join(parole[1:])
        s = cls(**valori)
        s.valida()
        return s

    @classmethod
    def da_sorgente(cls, sorgente: str, predefinito: "Stile | None" = None) -> "Stile":
        """Legge l'intestazione dalla prima riga non vuota del sorgente, se c'e'."""
        for riga in sorgente.splitlines():
            if riga.strip():
                trovato = cls.da_intestazione(riga)
                if trovato is not None:
                    return trovato
                break
        return predefinito or cls()

    # --- controlli ------------------------------------------------------------
    def valida(self, nomi_in_uso: set[str] | frozenset[str] = frozenset()) -> list[str]:
        """Controlla i valori; ErroreValore se non validi. Restituisce avvisi (testi)."""
        avvisi: list[str] = []
        for campo, scelte in SCELTE.items():
            valore = getattr(self, campo)
            if valore in scelte:
                continue
            if campo not in CAMPI_PERSONALIZZABILI:
                raise ErroreValore(
                    f"Per `{campo}` lo stile `{valore}` non esiste.",
                    suggerimento="Scegli tra " + ", ".join(f"`{s}`" for s in scelte) + ".")
            for parola in valore.split():
                if parola in PAROLE_CHIAVE:
                    raise ErroreValore(f"`{parola}` è già una parola chiave: scegli un'altra parola per `{campo}`.")
                if parola in nomi_in_uso:
                    raise ErroreValore(f"`{parola}` è già usato come nome nel progetto: scegli un'altra parola.")
                if not parola.replace("_", "a").isalpha():
                    raise ErroreValore(f"`{parola}` non è una parola valida per lo stile.")
        if self.variabili == "implicita":
            avvisi.append("Con la dichiarazione implicita (`x = 0`) Leo non può più "
                          "segnalare i refusi nei nomi: `tottale = 5` crea una variabile nuova.")
        return avvisi

    # --- uso da parte di lexer / interprete ------------------------------------
    @property
    def dichiarazione_implicita(self) -> bool:
        return self.variabili == "implicita"

    @property
    def parametri_con(self) -> bool:
        return self.parametri == "con"

    @property
    def eventi_al(self) -> bool:
        return self.eventi == "al"

    def forme_lessicali(self) -> dict[tuple[str, ...], TipoToken]:
        """Sequenze di parole di stile -> tipo canonico (oltre alle canoniche)."""
        forme: dict[tuple[str, ...], TipoToken] = {}
        for campo, tipo in _TIPO_PER_CAMPO.items():
            valore = getattr(self, campo)
            if valore in _CANONICHE or valore == "implicita":
                continue
            forme[tuple(valore.split())] = tipo
        if self.predefiniti == "vale":
            forme[("vale",)] = TipoToken.ASSEGNA
        return forme

    def forma_scritta(self, campo: str) -> str:
        """Testo da scrivere per un campo (usato dal formattatore).

        Per ``variabili = "implicita"`` restituisce "" (nessuna parola).
        """
        valore = getattr(self, campo)
        return "" if valore == "implicita" else valore
