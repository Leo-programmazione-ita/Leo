"""Avvio piu' rapido: il codice Python compilato si ricorda su disco.

Due usi, con lo stesso meccanismo (testo Python -> codice compilato, salvato
con ``marshal`` nella cartella dell'utente, ``.../leo/cache/``, e riletto agli
avvii successivi):

* **le classi** (:func:`installa`): ogni ``@dataclass`` (i nodi dell'albero
  sintattico, gli errori, i valori...) genera il testo di ``__init__``,
  ``__repr__``, ``__eq__``... e lo compila con ``exec``: a ogni avvio di Leo
  sono circa duecento piccole compilazioni, una parte importante del tempo di
  avvio (soprattutto nell'eseguibile e sul telefono). Qui ``exec`` del modulo
  ``dataclasses`` passa dalla cache (file ``classi-<python>.marshal``);
* **i programmi** (:func:`cache_programma`): il compilatore di Leo
  (:mod:`leo.compilatore`) traduce ogni istruzione e ogni funzione in testo
  Python da compilare; il codice compilato di un programma si ricorda
  (file ``programmi/<programma>-<python>.marshal``), cosi' rieseguire lo stesso
  programma, o un programma appena modificato (le parti uguali), non ricompila.

Il risultato e' identico: si usa il codice compilato dallo stesso testo, con lo
stesso nome di file e le stesse opzioni. Se la cartella non e' scrivibile, o la
cache e' rovinata o di un'altra versione di Python, si compila come sempre.

``LEO_SENZA_CACHE=1`` (come per il vocabolario) disattiva la cache su disco.
"""

from __future__ import annotations

import os
import sys

__all__ = ["installa", "cartella_cache", "cache_programma", "CacheCodice"]

#: Cambia se cambia il formato dei file.
FORMATO = 1
#: Voci al massimo in un file (oltre si ricomincia da capo).
MASSIMO_VOCI = 5000
#: Dimensione massima di un file della cache dei programmi (oltre si ricomincia da capo).
MASSIMI_BYTE_PROGRAMMA = 512 * 1024
#: Programmi ricordati al massimo: oltre si cancellano i file usati meno di recente.
MASSIMO_PROGRAMMI = 200

_stato: dict = {"installata": False, "salvataggio": False}
#: nome del file -> cache aperta in questo processo
_CACHE: dict[str, "CacheCodice"] = {}


def cartella_cache() -> str | None:
    """La cartella della cache (senza crearla), o None se la cache e' disattivata."""
    for nome in ("LEO_SENZA_CACHE", "DANTE_SENZA_CACHE"):
        if (os.environ.get(nome) or "").strip() not in ("", "0"):
            return None
    try:
        if os.name == "nt" and os.environ.get("APPDATA"):
            base = os.path.join(os.environ["APPDATA"], "Leo")
        else:
            base = os.path.join(os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config"),
                                "leo")
        return os.path.join(base, "cache")
    except Exception:  # noqa: BLE001 - nessuna cartella: si compila e basta
        return None


def _etichetta() -> str:
    """Versione di Python (e livello di ottimizzazione) nel nome dei file."""
    etichetta = getattr(sys.implementation, "cache_tag", None) or "python"
    return etichetta + (f"-O{sys.flags.optimize}" if sys.flags.optimize else "")


class CacheCodice:
    """Testo Python -> codice compilato, letto da ``percorso`` alla prima richiesta
    e riscritto all'uscita del processo se si e' aggiunto qualcosa."""

    def __init__(self, percorso: str, massimi_byte: int | None = None, massimo_file: int | None = None) -> None:
        self.percorso = percorso
        self.massimi_byte = massimi_byte
        #: file al massimo nella cartella di questa cache (None: nessun limite)
        self.massimo_file = massimo_file
        self.codici: dict | None = None
        self.nuovi = 0

    def _carica(self) -> dict:
        codici: dict = {}
        try:
            if self.massimi_byte is None or os.path.getsize(self.percorso) <= self.massimi_byte:
                import marshal

                with open(self.percorso, "rb") as f:
                    dati = marshal.loads(f.read())
                if (isinstance(dati, tuple) and len(dati) == 3 and dati[0] == FORMATO and dati[1] == sys.version
                        and isinstance(dati[2], dict)):
                    codici = dati[2]
        except Exception:  # noqa: BLE001 - cache assente, vecchia o rovinata
            codici = {}
        self.codici = codici
        return codici

    def compila(self, testo: str, nome_file: str) -> object:
        """``compile(testo, nome_file, "exec", dont_inherit=True)``, dalla cache se c'e'."""
        codici = self.codici if self.codici is not None else self._carica()
        chiave = nome_file + "\0" + testo
        codice = codici.get(chiave)
        if codice is None:
            codice = compile(testo, nome_file, "exec", dont_inherit=True)
            if len(codici) >= MASSIMO_VOCI:
                codici.clear()
            codici[chiave] = codice
            self.nuovi += 1
        return codice

    def salva(self) -> None:
        if not self.nuovi or self.codici is None:
            return
        import marshal

        temporaneo = f"{self.percorso}.{os.getpid()}.tmp"
        try:
            dati = marshal.dumps((FORMATO, sys.version, self.codici))
            if self.massimi_byte is not None and len(dati) > self.massimi_byte:
                return
            os.makedirs(os.path.dirname(self.percorso), exist_ok=True)
            with open(temporaneo, "wb") as f:
                f.write(dati)
            os.replace(temporaneo, self.percorso)
            self.nuovi = 0
        except Exception:  # noqa: BLE001 - cartella non scrivibile: pazienza
            try:
                os.unlink(temporaneo)
            except Exception:  # noqa: BLE001
                pass
            return
        if self.massimo_file is not None:
            self._sfoltisci()

    def _sfoltisci(self) -> None:
        """Tiene nella cartella solo i ``massimo_file`` file usati piu' di recente."""
        try:
            cartella = os.path.dirname(self.percorso)
            with os.scandir(cartella) as voci:
                file = [(v.stat().st_mtime, v.path) for v in voci if v.is_file() and v.name.endswith(".marshal")]
            if len(file) <= self.massimo_file:
                return
            file.sort()
            for _, percorso in file[:len(file) - self.massimo_file]:
                try:
                    os.unlink(percorso)
                except OSError:
                    pass
        except OSError:
            pass


def _salva_tutte() -> None:
    for cache in list(_CACHE.values()):
        cache.salva()


def _apri(percorso: str, massimi_byte: int | None = None, massimo_file: int | None = None) -> CacheCodice:
    cache = _CACHE.get(percorso)
    if cache is None:
        cache = _CACHE[percorso] = CacheCodice(percorso, massimi_byte, massimo_file)
        if not _stato["salvataggio"]:
            _stato["salvataggio"] = True
            import atexit

            atexit.register(_salva_tutte)
    return cache


def cache_programma(identita: str) -> CacheCodice | None:
    """La cache del codice compilato del programma ``identita`` (per esempio il suo
    percorso), o None se la cache e' disattivata."""
    cartella = cartella_cache()
    if cartella is None:
        return None
    import zlib

    impronta = f"{zlib.crc32(identita.encode('utf-8', 'replace')):08x}"
    nome = "".join(c for c in os.path.basename(identita) if c.isalnum() or c in "-_")[:40] or "programma"
    return _apri(os.path.join(cartella, "programmi", f"{nome}-{impronta}-{_etichetta()}.marshal"),
                 MASSIMI_BYTE_PROGRAMMA, MASSIMO_PROGRAMMI)


def installa() -> None:
    """Mette la cache davanti a ``exec`` nel modulo ``dataclasses`` (una volta sola)."""
    if _stato["installata"]:
        return
    _stato["installata"] = True
    cartella = cartella_cache()
    if cartella is None:
        return
    try:
        import dataclasses
    except ImportError:  # pragma: no cover
        return
    if "exec" in vars(dataclasses):
        return  # qualcun altro ha gia' sostituito exec: non si tocca
    cache = _apri(os.path.join(cartella, f"classi-{_etichetta()}.marshal"))
    esegui = exec
    globali_dataclasses = vars(dataclasses)

    def exec_con_cache(sorgente, globali=None, locali=None, /):
        if globali is None:  # come `exec` chiamato dentro dataclasses
            globali = globali_dataclasses
        if type(sorgente) is str:
            # dont_inherit: le stesse opzioni di `exec(testo)` chiamato da dataclasses
            return esegui(cache.compila(sorgente, "<string>"), globali, locali)
        return esegui(sorgente, globali, locali)

    dataclasses.exec = exec_con_cache
