"""`leo formatta`: forma canonica e conversione di stile (docs/CONTRATTI.md, sezione 10).

API del contratto::

    formatta(sorgente, *, stile=None, sinonimi=None, stile_origine=None, indentazione=4) -> str
    formatta_file(percorso, **opzioni) -> bool          # True se il file e' cambiato
    avvisi_stile_misto(sorgente, stile) -> list[str]
    parole_di_blocco_scambiate(token) -> list[tuple[Token, str]]   # anche per correzioni.py

Funzione pubblica in piu' (usata da Leo Studio per la conversione di stile
con anteprima delle differenze)::

    converti_progetto(cartella, stile_nuovo, stile_vecchio) -> dict[str, tuple[str, str]]

Come lavora :func:`formatta`
----------------------------
Il sorgente viene diviso in token dal lexer con ``conserva_commenti=True``
usando lo stile di partenza (``stile_origine``); poi, grazie alle posizioni
dei token (``riga``, ``colonna``, ``lunghezza``, ``testo_originale``), si
calcolano delle *modifiche* sulle singole righe:

* sinonimi -> forma canonica (``finché`` -> ``mentre``), ``e'`` -> ``è``,
  spazi doppi dentro le coppie di parole (``per  ogni`` -> ``per ogni``);
* forme di stile -> forme dello stile di arrivo: ``sia``/``variabile``/
  dichiarazione implicita, ``fissa``/``costante``, ``procedura``/``funzione``,
  ``vale``/``=``, ``al clic di P fai``/``quando P.clic fai``,
  ``somma con a, b``/``somma(a, b)``;
* con lo stile implicito si toglie ``variabile`` dalle dichiarazioni; nel
  passaggio inverso (da implicito a esplicito) si aggiunge ``variabile`` alla
  prima assegnazione di ogni nome mai dichiarato (serve il parser).

* ``allora``/``fai`` scambiati (tollerati dal parser) tornano alla forma
  canonica: ``se x fai`` -> ``se x allora``, ``quando P.clic allora`` ->
  ``quando P.clic fai``, ``caso 1 fai`` -> ``caso 1 allora``.

Infine si rifà il rientro: ``indentazione`` spazi per ogni livello di blocco
(``scegli`` ne apre due: i rami ``caso``/``altrimenti`` e i loro corpi; le
parole chiave dentro parentesi, come nelle liste compresse, non aprono
blocchi; le righe di continuazione dentro parentesi si spostano quanto la riga
che le apre; le righe che cominciano con ``|>`` rientrano di un livello
rispetto all'istruzione), si tolgono gli spazi a fine riga, si lasciano al massimo due righe vuote
di fila e il file termina con un solo a capo. Commenti e testi non si toccano.
Il risultato e' idempotente: ``formatta(formatta(x)) == formatta(x)``.

Regola sulle forme canoniche: se lo stile di partenza e quello di arrivo sono
uguali per un campo (semplice formattazione), ``crea variabile`` e
``variabile`` (come ``crea costante`` e ``costante``) restano come sono
scritti, perché sono entrambe forme canoniche: così un file già canonico non
cambia. In una conversione di stile vera e propria vengono invece portate
tutte alla forma scelta.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from . import e_sorgente
from .errori import ErroreDante
from .stile import Stile
from .tokens import TIPI_PAROLA_CHIAVE, TipoToken, Token, e_in_parallelo, frase_potenza, teste_di_blocco_potenza

__all__ = [
    "formatta",
    "formatta_file",
    "avvisi_stile_misto",
    "converti_progetto",
    "parole_di_blocco_scambiate",
]

T = TipoToken

#: Forme canoniche delle dichiarazioni (sempre accettate dal lexer).
_FORME_CANONICHE = frozenset({"variabile", "crea variabile", "costante", "crea costante", "funzione"})

#: Parole chiave che aprono un blocco chiuso da ``fine``.
_APRONO_BLOCCO = frozenset({T.SE, T.MENTRE, T.PER_OGNI, T.RIPETI, T.FUNZIONE, T.PROVA, T.QUANDO,
                            T.INIZIO})

#: Parole che, a inizio riga, stanno al livello del blocco che le contiene.
_RIENTRANO = frozenset({T.FINE, T.ALTRIMENTI, T.ALTRIMENTI_SE, T.CATTURA, T.INFINE})

#: Etichette ammesse dopo ``fine`` (non aprono blocchi); in piu' i NOME ``per``,
#: ``scegli`` e ``inizio`` (``fine inizio``).
_ETICHETTE = frozenset({T.SE, T.MENTRE, T.PER_OGNI, T.RIPETI, T.FUNZIONE, T.PROVA, T.QUANDO})
_ETICHETTE_NOME = frozenset({"per", "scegli", "inizio", "ogni", "dopo", "verifica", "aspettati", "parallelo"})

#: Dopo ``scegli`` questi token fanno capire che la parola e' il comando
#: (``scegli voto``) e non un nome (``scegli(3)``, ``scegli = 1``): come nel parser.
_INIZIO_VALORE_SCEGLI = frozenset({
    T.INTERO, T.DECIMALE, T.TESTO, T.TESTO_INTERPOLATO, T.NOME, T.VERO, T.FALSO,
    T.NULLA, T.NON, T.E, T.GRAFFA_APERTA, T.FUNZIONE,
})

#: Dopo ``caso`` (dentro ``scegli``) questi token cominciano uno schema.
_INIZIO_SCHEMA_CASO = frozenset({
    T.INTERO, T.DECIMALE, T.TESTO, T.TESTO_INTERPOLATO, T.NOME, T.VERO, T.FALSO,
    T.NULLA, T.GRAFFA_APERTA, T.FUNZIONE, T.MENO, T.NON,
})

#: Parola che chiude l'intestazione di ogni blocco: ``se ... allora``, ``mentre ... fai``...
_PAROLA_DI_BLOCCO = {
    T.SE: T.ALLORA, T.ALTRIMENTI_SE: T.ALLORA, T.MENTRE: T.FAI, T.PER_OGNI: T.FAI, T.QUANDO: T.FAI,
}

#: Larghezza (in livelli) dei blocchi: ``scegli`` ne apre due (i ``caso`` e i loro corpi).
_LARGHEZZA_BLOCCO = 1
_LARGHEZZA_SCEGLI = 2

_APERTE = frozenset({T.PARENTESI_APERTA, T.QUADRA_APERTA, T.GRAFFA_APERTA})
_CHIUSE = frozenset({T.PARENTESI_CHIUSA, T.QUADRA_CHIUSA, T.GRAFFA_CHIUSA})

#: Campo di stile -> tipo del token della parola che dichiara.
_CAMPO_PER_TIPO = {T.VARIABILE: "variabili", T.COSTANTE: "costanti", T.FUNZIONE: "funzioni"}

#: Nome della categoria nell'intestazione ``#stile:``.
_CATEGORIA_INTESTAZIONE = {
    "variabili": "variabile",
    "costanti": "costante",
    "funzioni": "funzione",
    "parametri": "parametri",
    "predefiniti": "predefiniti",
    "eventi": "eventi",
}


# ---------------------------------------------------------------------------
# Modifiche di riga
# ---------------------------------------------------------------------------

@dataclass
class ModificaStile:
    """Una sostituzione nella riga ``riga``: colonne ``[inizio, fine)`` (1-based) -> ``testo``.

    ``campo``: campo di stile coinvolto (``"variabili"``, ``"eventi"``, ...)
    oppure ``""`` per le normalizzazioni che non riguardano lo stile
    (sinonimi, ``e'``). ``trovato``: la forma scritta nel sorgente, ``voluto``:
    la forma dello stile di arrivo (servono ad avvisi e correzioni).
    """

    riga: int
    inizio: int
    fine: int
    testo: str
    campo: str = ""
    trovato: str = ""
    voluto: str = ""


def _normalizza_spazi(testo: str | None) -> str:
    return " ".join((testo or "").split())


def _significativi(token: list[Token]) -> list[Token]:
    """Token senza commenti, con in piu' (subito dopo ogni testo interpolato) i
    token delle parti ``{...}``: anche li' dentro c'e' codice da uniformare
    (sinonimi, ``vale`` negli argomenti per nome...)."""
    risultato: list[Token] = []
    for t in token:
        if t.tipo is T.COMMENTO:
            continue
        risultato.append(t)
        if t.tipo is T.TESTO_INTERPOLATO and isinstance(t.valore, list):
            for parte in t.valore:
                interni = getattr(parte, "token", None)
                if interni:
                    risultato.extend(x for x in _significativi(interni) if x.tipo is not T.FINE_FILE)
    return risultato


def _fine_colonna(t: Token) -> int:
    return t.colonna + t.lunghezza


def _e_etichetta(t: Token) -> bool:
    """``t`` (subito dopo ``fine``) e' l'etichetta del blocco chiuso (``fine se``, ``fine scegli``)?"""
    return t.tipo in _ETICHETTE or (t.tipo is T.NOME and t.valore in _ETICHETTE_NOME)


def _apre_blocco_tipi(elenco: list[Token], k: int) -> bool:
    """``struttura Nome`` / ``tipo Nome è uno di`` (leo/controllo/sintassi.py)."""
    from .controllo.sintassi import apre_blocco_tipi

    return apre_blocco_tipi(elenco, k)


def _apre_scegli(elenco: list[Token], k: int) -> bool:
    """``elenco[k]`` (all'inizio di un'istruzione) e' il comando ``scegli valore``?"""
    t = elenco[k]
    if t.tipo is not T.NOME or t.valore != "scegli":
        return False
    succ = elenco[k + 1] if k + 1 < len(elenco) else None
    return succ is not None and succ.riga == t.riga and succ.tipo in _INIZIO_VALORE_SCEGLI


def _e_caso(elenco: list[Token], k: int) -> bool:
    """``elenco[k]`` (all'inizio di un'istruzione dentro ``scegli``) comincia un ramo ``caso``?

    Stessa regola del parser: dopo ``caso`` c'e' uno schema sulla stessa riga
    (non un'assegnazione), oppure la riga finisce con ``allora``/``fai``.
    """
    from .tokens import TIPI_ASSEGNAZIONE

    t = elenco[k]
    if t.tipo is not T.NOME or t.valore != "caso":
        return False
    succ = elenco[k + 1] if k + 1 < len(elenco) else None
    if succ is None or succ.riga != t.riga or succ.tipo in (T.FINE_RIGA, T.FINE_FILE) \
            or succ.tipo in TIPI_ASSEGNAZIONE:
        return False
    if succ.tipo in _INIZIO_SCHEMA_CASO:
        return True
    for x in elenco[k + 1:]:
        if x.tipo in (T.FINE_RIGA, T.FINE_FILE):
            break
        if x.tipo in (T.ALLORA, T.FAI):
            return True
    return False


def parole_di_blocco_scambiate(token: list[Token]) -> list[tuple[Token, str]]:
    """Intestazioni chiuse dalla parola "sbagliata" ma tollerata: ``se x fai``,
    ``quando P.clic allora``, ``caso 1 fai``...

    Il parser le accetta (``allora`` e ``fai`` vogliono dire entrambi "e adesso
    fai questo"); qui si trova il token da riportare alla forma canonica.
    Restituisce (token scritto, parola canonica).
    """
    significativi = [t for t in token if t.tipo is not T.COMMENTO]
    risultato: list[tuple[Token, str]] = []
    parentesi = 0
    inizio = True
    atteso: TipoToken | None = None
    ultimo: Token | None = None
    for k, t in enumerate(significativi):
        if t.tipo in (T.FINE_RIGA, T.FINE_FILE) and parentesi == 0:
            if atteso is not None and ultimo is not None and ultimo.tipo in (T.ALLORA, T.FAI) \
                    and ultimo.tipo is not atteso:
                risultato.append((ultimo, atteso.value))
            inizio, atteso, ultimo = True, None, None
            continue
        if inizio and parentesi == 0:
            inizio = False
            if t.tipo in _PAROLA_DI_BLOCCO:
                atteso = _PAROLA_DI_BLOCCO[t.tipo]
            elif _e_caso(significativi, k):
                atteso = T.ALLORA
            else:
                frase = frase_potenza(significativi, k)
                if frase is not None and frase[0] != "aspettati":
                    atteso = T.FAI       # `ogni 2 secondi allora` -> `ogni 2 secondi fai`
        if parentesi == 0 and t.tipo is T.IN and e_in_parallelo(significativi, k):
            atteso = T.FAI
        if t.tipo in _APERTE:
            parentesi += 1
        elif t.tipo in _CHIUSE:
            parentesi = max(0, parentesi - 1)
        if parentesi == 0:
            ultimo = t
    return risultato


def parole_in_piu_dopo_volte(token: list[Token]) -> list[tuple[Token, Token]]:
    """``ripeti 3 volte fai`` (tollerato dal parser): coppie (token ``volte``,
    parola in piu' ``fai``/``allora``) da togliere per tornare a ``ripeti 3 volte``.

    Solo quando la parola in piu' chiude la riga (dopo puo' esserci un commento)."""
    significativi = [t for t in token if t.tipo is not T.COMMENTO]
    risultato: list[tuple[Token, Token]] = []
    parentesi = 0
    inizio = True
    in_ripeti = False
    for k, t in enumerate(significativi):
        if t.tipo in (T.FINE_RIGA, T.FINE_FILE) and parentesi == 0:
            inizio, in_ripeti = True, False
            continue
        if inizio and parentesi == 0:
            inizio = False
            in_ripeti = t.tipo is T.RIPETI
            continue
        if t.tipo in _APERTE:
            parentesi += 1
        elif t.tipo in _CHIUSE:
            parentesi = max(0, parentesi - 1)
        elif in_ripeti and parentesi == 0 and t.tipo is T.VOLTE:
            in_ripeti = False
            extra = significativi[k + 1] if k + 1 < len(significativi) else None
            dopo = significativi[k + 2] if k + 2 < len(significativi) else None
            if (extra is not None and extra.tipo in (T.FAI, T.ALLORA) and extra.lunghezza > 0
                    and extra.riga == t.riga and dopo is not None
                    and dopo.tipo in (T.FINE_RIGA, T.FINE_FILE)):
                risultato.append((t, extra))
    return risultato


#: Parole chiave che sono valori: un loro sinonimo seguito da ``(`` e' una
#: chiamata (``vuoto(lista)``) e non si traduce (sarebbe ``nulla(lista)``).
_VALORI = frozenset({T.NULLA, T.VERO, T.FALSO})


class _Analisi:
    """Calcola le modifiche di stile e di forma su una lista di token."""

    def __init__(self, token: list[Token], righe: list[str], stile: Stile, origine: Stile,
                 *, solo_stile: bool = False, dichiarazioni_implicite: Iterable[tuple[int, int]] = ()):
        self.token = _significativi(token)
        self.righe = righe
        self.stile = stile
        self.origine = origine
        self.solo_stile = solo_stile
        self.nuove_dichiarazioni = set(dichiarazioni_implicite)
        self.modifiche: list[ModificaStile] = []
        self.gestiti: set[int] = set()          # id() dei token gia' trattati

    # --- utilita' -------------------------------------------------------------
    def _succ(self, i: int) -> Token | None:
        return self.token[i + 1] if i + 1 < len(self.token) else None

    def _prec(self, i: int) -> Token | None:
        return self.token[i - 1] if i > 0 else None

    def _aggiungi(self, riga: int, inizio: int, fine: int, testo: str, campo: str = "",
                  trovato: str = "", voluto: str = "") -> None:
        self.modifiche.append(ModificaStile(riga, inizio, fine, testo, campo, trovato, voluto))

    def _carattere(self, riga: int, colonna: int) -> str:
        """Carattere alla colonna (1-based) della riga, "" se fuori."""
        if 1 <= riga <= len(self.righe):
            testo = self.righe[riga - 1]
            if 1 <= colonna <= len(testo):
                return testo[colonna - 1]
        return ""

    # --- analisi ----------------------------------------------------------------
    def esegui(self) -> list[ModificaStile]:
        contesti_assegna = self._contesti_assegna()
        if not self.solo_stile:
            for t, voluto in parole_di_blocco_scambiate(self.token):
                if t.lunghezza > 0:
                    scritto = t.testo_originale if t.testo_originale is not None else t.tipo.value
                    self._aggiungi(t.riga, t.colonna, _fine_colonna(t), voluto, "", scritto, voluto)
                    self.gestiti.add(id(t))
            for volte, extra in parole_in_piu_dopo_volte(self.token):
                # `ripeti 3 volte fai` -> `ripeti 3 volte`
                self._aggiungi(extra.riga, _fine_colonna(volte), _fine_colonna(extra), "", "",
                               extra.testo_originale or extra.tipo.value, "")
                self.gestiti.add(id(extra))
        if not self.solo_stile:
            for i, t in enumerate(self.token):
                if t.tipo is T.ANIMA:
                    self._frase_anima(i)
        for i, t in enumerate(self.token):
            if id(t) in self.gestiti:
                continue
            if t.tipo is T.QUANDO and self._evento(i):
                continue
            if t.tipo is T.FUNZIONE:
                self._funzione(i)
                continue
            if t.tipo in (T.VARIABILE, T.COSTANTE):
                self._dichiarazione(i)
                continue
            if t.tipo is T.ASSEGNA:
                self._assegna(i, contesti_assegna.get(i, ""))
                continue
            if not self.solo_stile and t.lunghezza > 0 and self._forma_canonica_scritta(t):
                continue
            if t.tipo is T.NOME and (t.riga, t.colonna) in self.nuove_dichiarazioni:
                forma = self.stile.forma_scritta("variabili")
                if forma:
                    self._aggiungi(t.riga, t.colonna, t.colonna, forma + " ", "variabili",
                                   "implicita", forma)
                continue
            if not self.solo_stile and t.tipo in _TIPI_SEMPLICI and t.lunghezza > 0:
                prec, succ = self._prec(i), self._succ(i)
                if prec is not None and prec.tipo is T.PUNTO:
                    continue      # `l.vuoto()`: nome di un metodo o di una proprieta'
                if (t.tipo in _VALORI and succ is not None and succ.tipo is T.PARENTESI_APERTA
                        and succ.riga == t.riga):
                    continue      # `vuoto(lista)`: una chiamata, non il valore `nulla`
                scritto = t.testo_originale if t.testo_originale is not None else t.tipo.value
                if t.tipo is T.O and scritto.lower() == "oppure":
                    continue      # `x oppure riserva`: operatore a se' (leo/controllo), non solo `o`
                if scritto != t.tipo.value:
                    self._aggiungi(t.riga, t.colonna, _fine_colonna(t), t.tipo.value, "",
                                   scritto, t.tipo.value)
        return self.modifiche

    def _forma_canonica_scritta(self, t: Token) -> bool:
        """``Stampa Ciao`` -> ``stampa Ciao`` (maiuscola sulla prima parola della riga) e
        ``≥ ≤ ≠ × ÷`` -> ``>= <= != * /``. Vero se ha aggiunto la modifica."""
        scritto = t.testo_originale
        if not scritto or not isinstance(t.valore, str) or scritto == t.valore:
            return False
        if t.tipo is T.NOME:
            if scritto[:1].isupper() and scritto[0].lower() + scritto[1:] == t.valore:
                self._aggiungi(t.riga, t.colonna, _fine_colonna(t), t.valore, "", scritto, t.valore)
                return True
            return False
        if scritto in _SIMBOLI_UNICODE and _SIMBOLI_UNICODE[scritto] == t.valore:
            self._aggiungi(t.riga, t.colonna, _fine_colonna(t), t.valore, "", scritto, t.valore)
            return True
        if t.tipo in (T.VARIABILE, T.COSTANTE, T.FUNZIONE) and scritto[:1].isupper() \
                and scritto.lower() == t.tipo.value:
            self._aggiungi(t.riga, t.colonna, _fine_colonna(t), t.tipo.value, "", scritto, t.tipo.value)
            return True
        return False

    # --- anima: tolleranze riportate alla forma canonica ------------------------
    def _frase_anima(self, i: int) -> None:
        """``anima P.x fino a 10 in 2 con la curva "r"`` ->
        ``anima P.x a 10 in 2 secondi con curva "r"`` (``fino a`` -> ``a``, unita'
        di tempo mancante -> ``secondi``, ``con la curva``/``con "r"``/``curva "r"``
        -> ``con curva "r"``). ``aumenta``/``diminuisci`` non hanno tolleranze."""
        from .tokens import UNITA_DI_TEMPO

        riga: list[Token] = []
        for t in self.token[i + 1:]:
            if t.tipo in (T.FINE_RIGA, T.FINE_FILE):
                break
            riga.append(t)

        def parola(t: Token | None) -> str | None:
            return str(t.valore) if t is not None and t.tipo is T.PAROLA_DI_FRASE else None

        def togli(da: Token, fino: Token) -> None:
            if da.riga == fino.riga:
                self._aggiungi(da.riga, da.colonna, fino.colonna, "", "", da.testo_originale or "", "")

        indice_in = None
        inizio_curva = None
        for k, t in enumerate(riga):
            p = parola(t)
            succ = riga[k + 1] if k + 1 < len(riga) else None
            if p == "fino" and parola(succ) == "a":
                togli(t, succ)
            elif p == "in":
                indice_in = k
            elif p == "con" and inizio_curva is None:
                inizio_curva = k
                if parola(succ) == "la" and k + 2 < len(riga):
                    togli(succ, riga[k + 2])
                elif succ is not None and parola(succ) != "curva" and succ.tipo is not T.PAROLA_DI_FRASE:
                    self._aggiungi(succ.riga, succ.colonna, succ.colonna, "curva ", "", "con", "con curva")
            elif p == "curva" and inizio_curva is None:
                inizio_curva = k
                self._aggiungi(t.riga, t.colonna, t.colonna, "con ", "", "curva", "con curva")
        if indice_in is None:
            return
        durata = riga[indice_in + 1:inizio_curva if inizio_curva is not None else len(riga)]
        if not durata or parola(durata[-1]) in UNITA_DI_TEMPO:
            return
        ultimo = durata[-1]
        self._aggiungi(ultimo.riga, _fine_colonna(ultimo), _fine_colonna(ultimo), " secondi", "",
                       "", "secondi")

    # --- eventi: quando P.clic fai <-> al clic di P fai --------------------------
    def _evento(self, i: int) -> bool:
        pezzi = self.token[i:i + 5]
        if len(pezzi) < 5:
            return False
        quando, controllo, punto, evento, fai = pezzi
        if not (controllo.tipo is T.NOME and punto.tipo is T.PUNTO and evento.tipo is T.NOME
                and fai.tipo is T.FAI):
            return False
        if len({quando.riga, controllo.riga, punto.riga, evento.riga, fai.riga}) != 1:
            return False
        forma_al = quando.origine == "stile" and punto.origine == "sintetico"
        for x in pezzi:
            self.gestiti.add(id(x))
        if forma_al and not self.stile.eventi_al:
            self._aggiungi(quando.riga, quando.colonna, fai.colonna,
                           f"quando {controllo.valore}.{evento.valore} ", "eventi",
                           f"al {evento.valore} di {controllo.valore} fai",
                           f"quando {controllo.valore}.{evento.valore} fai")
        elif not forma_al and self.stile.eventi_al:
            self._aggiungi(quando.riga, quando.colonna, fai.colonna,
                           f"al {evento.valore} di {controllo.valore} ", "eventi",
                           f"quando {controllo.valore}.{evento.valore} fai",
                           f"al {evento.valore} di {controllo.valore} fai")
        return True

    # --- dichiarazioni -----------------------------------------------------------
    def _forma_voluta(self, t: Token, campo: str) -> str | None:
        """Testo da scrivere al posto di ``t`` (None = lascia com'e')."""
        scritto = _normalizza_spazi(t.testo_originale) or t.tipo.value
        if campo == "variabili" and self.stile.dichiarazione_implicita:
            return ""
        voluto = self.stile.forma_scritta(campo)
        if (scritto in _FORME_CANONICHE and voluto in _FORME_CANONICHE
                and getattr(self.origine, campo) == getattr(self.stile, campo)):
            voluto = scritto
        if voluto == (t.testo_originale or ""):
            return None
        if voluto == scritto and self.solo_stile:
            return None
        return voluto

    def _dichiarazione(self, i: int) -> None:
        t = self.token[i]
        campo = _CAMPO_PER_TIPO[t.tipo]
        voluto = self._forma_voluta(t, campo)
        if voluto is None:
            return
        scritto = _normalizza_spazi(t.testo_originale) or t.tipo.value
        if voluto == "":
            # dichiarazione implicita: si toglie la parola e lo spazio che la segue
            succ = self._succ(i)
            fine = succ.colonna if succ is not None and succ.riga == t.riga else _fine_colonna(t)
            self._aggiungi(t.riga, t.colonna, fine, "", campo, scritto, "implicita")
        else:
            self._aggiungi(t.riga, t.colonna, _fine_colonna(t), voluto,
                           campo if voluto != scritto else "", scritto, voluto)

    # --- funzioni e parametri ----------------------------------------------------
    def _funzione(self, i: int) -> None:
        t = self.token[i]
        succ = self._succ(i)
        prec = self._prec(i)
        e_etichetta = prec is not None and prec.tipo is T.FINE and prec.riga == t.riga
        e_definizione = (not e_etichetta and succ is not None and succ.tipo is T.NOME
                         and succ.riga == t.riga)
        if e_definizione:
            voluto = self._forma_voluta(t, "funzioni")
            if voluto is not None:
                scritto = _normalizza_spazi(t.testo_originale) or "funzione"
                self._aggiungi(t.riga, t.colonna, _fine_colonna(t), voluto,
                               "funzioni" if voluto != scritto else "", scritto, voluto)
        elif not self.solo_stile and t.lunghezza > 0 and t.testo_originale != "funzione":
            self._aggiungi(t.riga, t.colonna, _fine_colonna(t), "funzione", "",
                           t.testo_originale or "", "funzione")
        if not e_etichetta:
            self._parametri(i, e_definizione)

    def _parametri(self, i: int, e_definizione: bool) -> None:
        """Conversione ``somma(a, b)`` <-> ``somma con a, b``."""
        inizio = i + 2 if e_definizione else i + 1
        if inizio >= len(self.token):
            return
        aperta = self.token[inizio]
        if aperta.tipo is not T.PARENTESI_APERTA:
            return
        # parentesi corrispondente
        profondita = 0
        chiusa_i = None
        for j in range(inizio, len(self.token)):
            x = self.token[j]
            if x.tipo in _APERTE:
                profondita += 1
            elif x.tipo in _CHIUSE:
                profondita -= 1
                if profondita == 0:
                    chiusa_i = j
                    break
        if chiusa_i is None:
            return
        chiusa = self.token[chiusa_i]
        precedente = self.token[inizio - 1]
        con_origine = aperta.origine == "sintetico"
        if con_origine and not self.stile.parametri_con:
            # "somma con a, b" -> "somma(a, b)"
            primo = self.token[inizio + 1] if inizio + 1 < chiusa_i else None
            attacco = "(" if e_definizione else " ("
            fine_con = primo.colonna if primo is not None and primo.riga == aperta.riga else (
                aperta.colonna + len(aperta.testo_originale or "con"))
            self._aggiungi(aperta.riga, _fine_colonna(precedente), fine_con, attacco,
                           "parametri", "con", "parentesi")
            self._aggiungi(chiusa.riga, chiusa.colonna, chiusa.colonna, ")", "parametri",
                           "con", "parentesi")
            self.gestiti.update({id(aperta), id(chiusa)})
        elif not con_origine and self.stile.parametri_con:
            # "somma(a, b)" -> "somma con a, b" solo se la lista sta su una riga e
            # la parentesi chiusa e' l'ultima cosa della riga
            if chiusa.riga != aperta.riga or chiusa_i == inizio + 1:
                return
            dopo = self._succ(chiusa_i)
            if dopo is not None and dopo.tipo not in (T.FINE_RIGA, T.FINE_FILE):
                return
            if dopo is not None and dopo.tipo is T.FINE_RIGA and dopo.valore == ";":
                return
            primo = self.token[inizio + 1]
            ultimo = self.token[chiusa_i - 1]
            if primo.riga != aperta.riga or ultimo.riga != aperta.riga:
                return
            self._aggiungi(aperta.riga, _fine_colonna(precedente), primo.colonna, " con ",
                           "parametri", "parentesi", "con")
            self._aggiungi(chiusa.riga, _fine_colonna(ultimo), _fine_colonna(chiusa), "",
                           "parametri", "parentesi", "con")
            self.gestiti.update({id(aperta), id(chiusa)})

    # --- = / vale ------------------------------------------------------------------
    def _contesti_assegna(self) -> dict[int, str]:
        """Indice di ogni ``=`` che introduce un valore iniziale -> "dichiarazione"/"parametro"."""
        contesti: dict[int, str] = {}
        n = len(self.token)
        for i, t in enumerate(self.token):
            if t.tipo in (T.VARIABILE, T.COSTANTE) and i + 2 < n:
                if self.token[i + 1].tipo is T.NOME and self.token[i + 2].tipo is T.ASSEGNA:
                    contesti[i + 2] = "dichiarazione"
            elif (t.tipo is T.NOME and (t.riga, t.colonna) in self.nuove_dichiarazioni
                  and i + 1 < n and self.token[i + 1].tipo is T.ASSEGNA):
                contesti[i + 1] = "dichiarazione"
            elif t.tipo is T.FUNZIONE:
                j = i + 1
                if j < n and self.token[j].tipo is T.NOME and self.token[j].riga == t.riga:
                    j += 1
                if j < n and self.token[j].tipo is T.PARENTESI_APERTA:
                    profondita = 0
                    for k in range(j, n):
                        x = self.token[k]
                        if x.tipo in _APERTE:
                            profondita += 1
                        elif x.tipo in _CHIUSE:
                            profondita -= 1
                            if profondita == 0:
                                break
                        elif x.tipo is T.ASSEGNA and profondita == 1:
                            contesti[k] = "parametro"
        return contesti

    def _assegna(self, i: int, contesto: str) -> None:
        t = self.token[i]
        scritto = t.testo_originale or "="
        if self.stile.predefiniti == "vale":
            if scritto == "=" and contesto:
                prima = self._carattere(t.riga, t.colonna - 1)
                dopo = self._carattere(t.riga, t.colonna + 1)
                testo = ("" if prima in (" ", "\t") else " ") + "vale" + ("" if dopo in (" ", "\t") else " ")
                self._aggiungi(t.riga, t.colonna, _fine_colonna(t), testo, "predefiniti", "=", "vale")
        elif scritto != "=":
            self._aggiungi(t.riga, t.colonna, _fine_colonna(t), "=", "predefiniti", scritto, "=")


#: Parole chiave trattate dalla regola generica (sinonimi, ``e'``, spazi doppi):
#: le dichiarazioni e ``quando`` hanno regole proprie.
_TIPI_SEMPLICI = frozenset(TIPI_PAROLA_CHIAVE) - {T.VARIABILE, T.COSTANTE, T.FUNZIONE}
#: Simboli matematici accettati dal lexer e la loro forma canonica.
_SIMBOLI_UNICODE = {"≥": ">=", "≤": "<=", "≠": "!=", "×": "*", "÷": "/", "−": "-"}


def _applica_modifiche(righe: list[str], modifiche: list[ModificaStile]) -> list[str]:
    """Applica le modifiche (non sovrapposte) riga per riga, da destra a sinistra."""
    per_riga: dict[int, list[ModificaStile]] = {}
    for m in modifiche:
        per_riga.setdefault(m.riga, []).append(m)
    nuove = list(righe)
    for riga, elenco in per_riga.items():
        if not 1 <= riga <= len(nuove):
            continue
        testo = nuove[riga - 1]
        limite = len(testo) + 1
        for m in sorted(elenco, key=lambda m: (m.inizio, m.fine), reverse=True):
            if m.fine > limite:   # sovrapposta a una modifica gia' applicata: si salta
                continue
            testo = testo[:m.inizio - 1] + m.testo + testo[m.fine - 1:]
            limite = m.inizio
        nuove[riga - 1] = testo
    return nuove


# ---------------------------------------------------------------------------
# Rientri
# ---------------------------------------------------------------------------

@dataclass
class _InfoRiga:
    livello: int | None = None       # livello di blocco se la riga inizia con codice o commento
    continuazione: bool = False      # la riga inizia dentro parentesi aperte
    dentro_commento: bool = False    # la riga inizia dentro un commento #[ ]#
    tocca_commento: bool = False     # una parte della riga appartiene a un commento su piu' righe
    riga_madre: int = 0              # per le continuazioni: riga dell'istruzione
    catena: bool = False             # la riga comincia con `|>` (catena su piu' righe)


def _analizza_righe(token: list[Token], numero_righe: int) -> list[_InfoRiga]:
    """Livello di blocco di ogni riga, continuazioni e commenti su piu' righe.

    Regole dei blocchi:

    * ``se``, ``mentre``, ``per ogni``, ``ripeti``, ``funzione``, ``prova``,
      ``quando`` e ``inizio`` (da solo sulla riga) aprono un livello; ``fine`` lo chiude; ``altrimenti``,
      ``altrimenti se``, ``cattura`` e ``infine`` stanno al livello della
      parola che apre il blocco;
    * ``scegli valore`` apre due livelli: i rami ``caso ... allora`` e
      ``altrimenti`` stanno un livello sotto ``scegli``, i loro corpi due;
      ``fine`` torna al livello di ``scegli``;
    * le parole chiave dentro parentesi (liste compresse ``[x per ogni x in l
      se x > 0]``, funzioni anonime in una chiamata) non aprono blocchi;
    * una riga che comincia con ``|>`` continua la catena della riga sopra e
      rientra di un livello rispetto all'istruzione.
    """
    info = [_InfoRiga() for _ in range(numero_righe + 2)]
    per_riga: dict[int, list[Token]] = {}
    #: `ogni ... fai`, `dopo ... fai`, `verifica "..." fai`, `aspettati errore fai`, `in parallelo fai`
    teste_potenza = {id(token[k]) for k in teste_di_blocco_potenza(token)}
    for t in token:
        if t.tipo is T.FINE_FILE:
            continue
        per_riga.setdefault(t.riga, []).append(t)
        if t.tipo in (T.TESTO, T.TESTO_INTERPOLATO) and "\n" in (t.testo_originale or ""):
            # testo su piu' righe (`"""`): le sue righe non si toccano (ne' rientro ne' spazi finali)
            ultima = t.riga + (t.testo_originale or "").count("\n")
            for r in range(t.riga, min(ultima, numero_righe) + 1):
                info[r].tocca_commento = True
                if r > t.riga:
                    info[r].dentro_commento = True
        if t.tipo is T.COMMENTO and "\n" in (t.valore or ""):
            ultima = t.riga + t.valore.count("\n")
            for r in range(t.riga, min(ultima, numero_righe) + 1):
                info[r].tocca_commento = True
                if r > t.riga:
                    info[r].dentro_commento = True

    pila: list[int] = []    # larghezza di ogni blocco aperto (1, oppure 2 per `scegli`)
    senza_casi: set[int] = set()   # indici in `pila` dei `scegli` che non hanno ancora un `caso`
    parentesi = 0           # parentesi aperte
    riga_istruzione = 0     # riga dell'ultima istruzione (per le continuazioni tra parentesi)
    livello_istruzione = 0  # suo livello (per le righe `|>`)
    inizio = True           # il prossimo token comincia un'istruzione
    for r in range(1, numero_righe + 1):
        elenco = [t for t in per_riga.get(r, []) if t.tipo is not T.COMMENTO]
        voce = info[r]
        if parentesi > 0 and not voce.dentro_commento:
            voce.continuazione = True
            voce.riga_madre = riga_istruzione
        primo = next((t for t in elenco if t.tipo is not T.FINE_RIGA), None)
        if primo is None:
            primo_commento = next((t for t in per_riga.get(r, []) if t.tipo is T.COMMENTO), None)
            if primo_commento is not None and not voce.dentro_commento and not voce.continuazione:
                # un commento prima del primo `caso` sta al livello dei rami
                voce.livello = sum(pila) - (1 if pila and len(pila) - 1 in senza_casi else 0)
        elif not voce.dentro_commento and not voce.continuazione:
            profondita = sum(pila)
            k = elenco.index(primo)
            if primo.tipo is T.CATENA:
                voce.catena = True
                voce.livello = livello_istruzione + 1
            else:
                if primo.tipo is T.FINE:
                    livello = profondita - (pila[-1] if pila else 1)
                elif primo.tipo in _RIENTRANO:
                    livello = profondita - 1
                elif pila and pila[-1] == _LARGHEZZA_SCEGLI and _e_caso(elenco, k):
                    livello = profondita - 1
                    senza_casi.discard(len(pila) - 1)
                else:
                    livello = profondita
                voce.livello = max(0, livello)
                livello_istruzione = voce.livello
            riga_istruzione = r
        salta_etichetta = False
        for k, t in enumerate(elenco):
            if salta_etichetta:
                salta_etichetta = False
                if _e_etichetta(t):
                    continue
            if t.tipo is T.FINE_RIGA:
                if parentesi == 0:
                    inizio = True
                continue
            all_inizio, inizio = inizio, False
            if t.tipo in _APERTE:
                parentesi += 1
            elif t.tipo in _CHIUSE:
                parentesi = max(0, parentesi - 1)
            elif parentesi > 0:
                continue          # liste compresse, funzioni anonime dentro una chiamata
            elif t.tipo in _APRONO_BLOCCO or id(t) in teste_potenza or _apre_blocco_tipi(elenco, k):
                pila.append(_LARGHEZZA_BLOCCO)
            elif all_inizio and _apre_scegli(elenco, k):
                pila.append(_LARGHEZZA_SCEGLI)
                senza_casi.add(len(pila) - 1)
            elif t.tipo is T.FINE:
                if pila:
                    senza_casi.discard(len(pila) - 1)
                    pila.pop()
                salta_etichetta = True
    return info


def _larghezza(spazi: str, tabulazione: int) -> int:
    larghezza = 0
    for c in spazi:
        larghezza += tabulazione if c == "\t" else 1
    return larghezza


def _rientro(testo: str) -> str:
    return testo[:len(testo) - len(testo.lstrip(" \t"))]


# ---------------------------------------------------------------------------
# Intestazione #stile:
# ---------------------------------------------------------------------------

def _intestazione(stile: Stile) -> str | None:
    """Testo dell'intestazione ``#stile:`` per ``stile`` (None se e' lo stile predefinito)."""
    predefinito = Stile().a_dizionario()
    parti = [f"{_CATEGORIA_INTESTAZIONE[campo]} {valore}"
             for campo, valore in stile.a_dizionario().items() if predefinito.get(campo) != valore]
    if not parti:
        return None
    return "#stile: " + ", ".join(parti)


def _riga_intestazione(righe: list[str]) -> int:
    """Numero (1-based) della riga con l'intestazione ``#stile:``, 0 se non c'e'."""
    for n, riga in enumerate(righe, 1):
        if riga.strip():
            try:
                return n if Stile.da_intestazione(riga) is not None else 0
            except ErroreDante:
                return 0
    return 0


# ---------------------------------------------------------------------------
# Preparazione del lessico
# ---------------------------------------------------------------------------

def _sinonimi_predefiniti():
    try:
        from .sinonimi import carica_sinonimi

        return carica_sinonimi()
    except (ErroreDante, OSError):  # pragma: no cover - file di sistema rovinato
        from .sinonimi import Sinonimi

        return Sinonimi.vuoti()


def _stili(sorgente: str, stile: Stile | None, stile_origine: Stile | None) -> tuple[Stile, Stile]:
    if stile_origine is None:
        stile_origine = Stile.da_sorgente(sorgente, stile)
    if stile is None:
        stile = Stile.da_sorgente(sorgente)
    return stile, stile_origine


def _lessico(sorgente: str, stile: Stile, sinonimi, *, commenti: bool = True,
             tollerante: bool = False) -> list[Token]:
    from .lexer import Lexer

    return Lexer(sorgente, "<formatta>", sinonimi=sinonimi, stile=stile,
                 conserva_commenti=commenti, tollerante=tollerante).tokenizza()


def _dichiarazioni_mancanti(sorgente: str, stile_origine: Stile, sinonimi) -> set[tuple[int, int]]:
    """Posizioni delle prime assegnazioni (stile implicito) da trasformare in dichiarazioni."""
    try:
        from .correzioni import assegnazioni_multiple_senza_dichiarazione, assegnazioni_senza_dichiarazione
        from .parser import Parser

        token = _lessico(sorgente, stile_origine, sinonimi, commenti=False)
        programma = Parser(token, "<formatta>").analizza()
        # stile implicito: `X = 1` crea sempre un nome nuovo (niente tolleranza delle maiuscole)
        posizioni = {(a.riga, a.colonna)
                     for a in assegnazioni_senza_dichiarazione(programma, maiuscole_tollerate=False)}
        posizioni |= {(a.riga, a.colonna)
                      for a in assegnazioni_multiple_senza_dichiarazione(programma, maiuscole_tollerate=False)}
        return posizioni
    except (ErroreDante, ImportError, NotImplementedError):
        return set()


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------

def _applica_tolleranze(testo: str, stile_origine: Stile, nome_file: str | None,
                        opzioni: dict[str, Any]) -> str:
    """Riporta alla forma canonica le tolleranze (GUIDA §15: ``ripeti 3 volte fai``,
    ``Contatore += 1``, ``Stampa(...)``, ``colore(Blu)``, ``quando P.click fai``...)
    usando i suggerimenti facoltativi dell'autocorrezione, solo quelli che non
    cambiano il significato del programma (``correzioni.tolleranze_da_formattare``).
    Se il sorgente non si analizza senza errori resta com'e'."""
    try:
        from .correzioni import applica_correzioni, tolleranze_da_formattare
        from .parser import rigoroso_da_ambiente
    except ImportError:          # pragma: no cover - installazione ridotta
        return testo
    if rigoroso_da_ambiente() or opzioni.get("rigoroso"):
        return testo             # con --rigoroso le tolleranze sono errori: non si toccano
    opzioni = dict(opzioni)
    opzioni.setdefault("stile", stile_origine)
    correzioni = tolleranze_da_formattare(testo, nome_file or "<formatta>", **opzioni)
    if not correzioni:
        return testo
    try:
        return applica_correzioni(testo, correzioni)
    except ValueError:
        return testo


def formatta(sorgente: str, *, stile: Stile | None = None, sinonimi=None,
             stile_origine: Stile | None = None, indentazione: int = 4,
             nome_file: str | os.PathLike | None = None,
             tolleranze: bool | dict[str, Any] | None = None) -> str:
    """Restituisce il sorgente in forma canonica nello stile ``stile``.

    ``stile``: stile di arrivo (None = intestazione ``#stile:`` del sorgente o
    predefinito). ``stile_origine``: stile in cui e' scritto il sorgente (None
    = intestazione del sorgente, altrimenti ``stile``). ``sinonimi``: None =
    sinonimi di sistema (``dati/sinonimi.toml``). ``indentazione``: spazi per
    livello. Solleva ``ErroreSintassi`` se il lexer non riesce a leggere il file.

    Le tolleranze (GUIDA §15) tornano alla forma canonica solo quando non
    cambia nulla di cio' che fa il programma. ``tolleranze``: None = si' se
    ``sinonimi`` e' None (lessico di sistema), False = mai, un dizionario = si',
    con queste opzioni di lessico (``sinonimi_extra``, ``dizionari_sinonimi``,
    ``rigoroso``) per analizzare il programma. ``nome_file``: il file (per la
    maschera accanto, con i nomi dei controlli, e per i moduli importati).
    """
    if sorgente is None:
        sorgente = ""
    indentazione = max(0, int(indentazione))
    testo = sorgente.replace("\r\n", "\n").replace("\r", "\n")
    if testo.startswith("﻿"):
        testo = testo[1:]
    stile, stile_origine = _stili(testo, stile, stile_origine)
    if tolleranze is None:
        tolleranze = {} if sinonimi is None else False
    if tolleranze is not False:
        testo = _applica_tolleranze(testo, stile_origine, str(nome_file) if nome_file else None,
                                    tolleranze if isinstance(tolleranze, dict) else {})
    if sinonimi is None:
        sinonimi = _sinonimi_predefiniti()
    conversione = stile.a_dizionario() != stile_origine.a_dizionario()

    token = _lessico(testo, stile_origine, sinonimi)
    righe = testo.split("\n")

    nuove_dichiarazioni: set[tuple[int, int]] = set()
    if stile_origine.dichiarazione_implicita and not stile.dichiarazione_implicita:
        nuove_dichiarazioni = _dichiarazioni_mancanti(testo, stile_origine, sinonimi)

    modifiche = _Analisi(token, righe, stile, stile_origine,
                         dichiarazioni_implicite=nuove_dichiarazioni).esegui()
    info = _analizza_righe(token, len(righe))
    modificate = _applica_modifiche(righe, modifiche)

    # intestazione #stile: da aggiornare in una conversione
    riga_int = _riga_intestazione(righe) if conversione else 0
    da_togliere = set()
    if riga_int:
        nuova = _intestazione(stile)
        if nuova is None:
            da_togliere.add(riga_int)
        else:
            modificate[riga_int - 1] = nuova

    # rientri
    risultato: list[tuple[str, bool]] = []   # (riga, protetta: dentro un commento su piu' righe)
    spostamento: dict[int, int] = {}          # riga -> nuova larghezza - vecchia larghezza
    for r in range(1, len(righe) + 1):
        if r in da_togliere:
            continue
        voce = info[r]
        riga = modificate[r - 1]
        if voce.dentro_commento:
            risultato.append((riga, True))
            continue
        corpo = riga.lstrip(" \t")
        vecchio = _rientro(riga)
        if voce.livello is not None:
            nuovo = " " * (voce.livello * indentazione)
            spostamento[r] = len(nuovo) - _larghezza(vecchio, indentazione)
        elif voce.continuazione and corpo:
            delta = spostamento.get(voce.riga_madre, 0)
            nuovo = " " * max(0, _larghezza(vecchio, indentazione) + delta)
        else:
            nuovo = vecchio
        riga = nuovo + corpo
        if not voce.tocca_commento:
            riga = riga.rstrip()
        risultato.append((riga, voce.tocca_commento))

    # righe vuote: al massimo due di fila, nessuna all'inizio e alla fine
    finali: list[str] = []
    vuote = 0
    for riga, protetta in risultato:
        if not protetta and not riga.strip():
            vuote += 1
            if vuote > 2 or not finali:
                continue
            finali.append("")
            continue
        vuote = 0
        finali.append(riga)
    while finali and not finali[-1].strip():
        finali.pop()
    if not finali:
        return ""
    return "\n".join(finali) + "\n"


def _leggi(percorso: Path) -> tuple[str, str, bool]:
    """Legge un sorgente: (testo con soli \\n, stile di a capo, BOM presente)."""
    dati = percorso.read_bytes()
    bom = dati.startswith(b"\xef\xbb\xbf")
    testo = dati.decode("utf-8-sig")
    a_capo = "\r\n" if "\r\n" in testo else "\n"
    return testo.replace("\r\n", "\n").replace("\r", "\n"), a_capo, bom


def _scrivi(percorso: Path, testo: str, a_capo: str, bom: bool) -> None:
    if a_capo != "\n":
        testo = testo.replace("\n", a_capo)
    with open(percorso, "w", encoding="utf-8-sig" if bom else "utf-8", newline="") as f:
        f.write(testo)


def opzioni_da_progetto(percorso: str | os.PathLike) -> dict[str, Any]:
    """Stile e sinonimi del progetto che contiene ``percorso`` (dizionario vuoto se non c'e').

    Restituisce ``{"stile": Stile, "sinonimi": Sinonimi, "tolleranze": ...}``
    pronti per :func:`formatta` (``tolleranze``: le opzioni di lessico del
    progetto, oppure False se il progetto e' rigoroso).
    """
    p = Path(percorso)
    cartella = p if p.is_dir() else p.parent
    try:
        from .progetto import carica_progetto, e_progetto
        from .sinonimi import carica_sinonimi

        if not e_progetto(cartella):
            return {}
        progetto = carica_progetto(cartella)
        extra = [progetto.file_sinonimi] if progetto.file_sinonimi else []
        dizionari = [progetto.sinonimi] if progetto.sinonimi else []
        sinonimi = carica_sinonimi(extra, rigoroso=progetto.rigoroso, dizionari_extra=dizionari)
        tolleranze: dict[str, Any] | bool = (
            False if progetto.rigoroso else {"sinonimi_extra": extra, "dizionari_sinonimi": dizionari})
        return {"stile": progetto.stile, "sinonimi": sinonimi, "tolleranze": tolleranze}
    except (ErroreDante, OSError, ImportError):
        return {}


def formatta_file(percorso: str | os.PathLike, **opzioni: Any) -> bool:
    """Formatta un file ``.leo`` sul posto; True se il contenuto e' cambiato.

    Le opzioni sono quelle di :func:`formatta`; con ``controlla=True`` il file
    non viene scritto (serve a ``leo formatta --controlla``). Se il file sta
    in un progetto e le opzioni non indicano ``stile``/``sinonimi``, si usano
    quelli di ``progetto.toml``.
    """
    percorso = Path(percorso)
    controlla = bool(opzioni.pop("controlla", False))
    if "sinonimi" in opzioni and "tolleranze" not in opzioni:
        # sinonimi scelti da chi chiama (`leo formatta --rigoroso`): il programma
        # non si puo' analizzare come lo eseguirebbe Leo, le tolleranze restano
        opzioni["tolleranze"] = False
    for chiave, valore in opzioni_da_progetto(percorso).items():
        opzioni.setdefault(chiave, valore)
    opzioni.setdefault("nome_file", str(percorso))
    testo, a_capo, bom = _leggi(percorso)
    nuovo = formatta(testo, **opzioni)
    if nuovo == testo:
        return False
    if not controlla:
        _scrivi(percorso, nuovo, a_capo, bom)
    return True


_DESCRIZIONI_CAMPO = {
    "variabili": "le variabili si dichiarano con {voluto}",
    "costanti": "le costanti si dichiarano con {voluto}",
    "funzioni": "le funzioni si definiscono con {voluto}",
    "parametri": "i parametri si scrivono {voluto}",
    "predefiniti": "i valori iniziali si scrivono con {voluto}",
    "eventi": "gli eventi si scrivono {voluto}",
}


def _descrivi_forma(campo: str, forma: str, stile: Stile) -> str:
    if campo == "variabili" and forma == "implicita":
        return "la dichiarazione implicita (`x = 0`)"
    if campo == "parametri":
        return "con `con` (`somma con a, b`)" if forma == "con" else "tra parentesi (`somma(a, b)`)"
    if campo == "eventi":
        return ("nella forma `al clic di Pulsante1 fai`" if forma.startswith("al ") or forma == "al"
                else "nella forma `quando Pulsante1.clic fai`")
    return f"`{forma}`"


def _elenco_righe(righe: list[int]) -> str:
    righe = sorted(set(righe))
    if len(righe) == 1:
        return f"alla riga {righe[0]}"
    return "alle righe " + ", ".join(str(r) for r in righe[:-1]) + f" e {righe[-1]}"


def modifiche_di_stile(sorgente: str, stile: Stile, *, sinonimi=None,
                       tollerante: bool = False) -> list[ModificaStile]:
    """Forme che non seguono ``stile`` (usata da avvisi e da ``correzioni.uniforma_stile``).

    Solo le differenze di stile: niente sinonimi, rientri o ``e'``.
    """
    testo = sorgente.replace("\r\n", "\n").replace("\r", "\n")
    if sinonimi is None:
        sinonimi = _sinonimi_predefiniti()
    token = _lessico(testo, stile, sinonimi, tollerante=tollerante)
    righe = testo.split("\n")
    modifiche = _Analisi(token, righe, stile, stile, solo_stile=True).esegui()
    return [m for m in modifiche if m.campo]


def avvisi_stile_misto(sorgente: str, stile: Stile) -> list[str]:
    """Avvisi in italiano quando nel sorgente convivono forme di stili diversi.

    Si basa su ``Token.origine``: con uno stile non canonico (``sia``,
    ``vale``, ``al``, ``con``, ...) le forme canoniche scritte al suo posto sono
    uno stile diverso da quello del progetto; con lo stile implicito, ogni
    ``variabile`` scritto e' fuori stile. ``crea variabile`` e ``variabile``
    sono entrambe canoniche e non producono avvisi.
    """
    stile = stile or Stile()
    try:
        modifiche = modifiche_di_stile(sorgente, stile, tollerante=True)
    except ErroreDante:
        return []
    gruppi: dict[tuple[str, str, str], list[int]] = {}
    for m in modifiche:
        chiave = (m.campo, _descrivi_forma(m.campo, m.trovato, stile),
                  _descrivi_forma(m.campo, m.voluto, stile))
        gruppi.setdefault(chiave, []).append(m.riga)
    avvisi: list[str] = []
    for (campo, trovato, voluto), righe in gruppi.items():
        if campo == "variabili" and stile.dichiarazione_implicita:
            avvisi.append(
                "Stili misti: il progetto usa la dichiarazione implicita (`x = 0`), ma "
                f"{_elenco_righe(righe)} c'è `variabile`.")
            continue
        regola = _DESCRIZIONI_CAMPO[campo].format(voluto=voluto)
        avvisi.append(f"Stili misti: nello stile del progetto {regola}, ma "
                      f"{_elenco_righe(righe)} hai scritto {trovato}.")
    return avvisi


def converti_progetto(cartella: str | os.PathLike, stile_nuovo: Stile,
                      stile_vecchio: Stile | None) -> dict[str, tuple[str, str]]:
    """Anteprima della conversione di stile di tutti i ``.leo`` di un progetto.

    Restituisce ``{percorso: (prima, dopo)}`` per i soli file che cambiano;
    non scrive nulla (Leo Studio mostra le differenze e chiede conferma).
    ``stile_vecchio`` None = stile scritto in ``progetto.toml``. I file che il
    lexer non riesce a leggere vengono saltati.
    """
    cartella = Path(cartella)
    opzioni = opzioni_da_progetto(cartella)
    if stile_vecchio is None:
        stile_vecchio = opzioni.get("stile") or Stile()
    sinonimi = opzioni.get("sinonimi")
    risultato: dict[str, tuple[str, str]] = {}
    for percorso in sorted(p for p in cartella.rglob("*") if e_sorgente(p.name)):
        if not percorso.is_file():
            continue
        try:
            prima, _, _ = _leggi(percorso)
            dopo = formatta(prima, stile=stile_nuovo, stile_origine=stile_vecchio, sinonimi=sinonimi,
                            tolleranze=False)
        except (ErroreDante, OSError, UnicodeDecodeError):
            continue
        if dopo != prima:
            risultato[str(percorso)] = (prima, dopo)
    return risultato
