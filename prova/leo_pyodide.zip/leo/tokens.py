"""Definizione dei token di Leo (CONTRATTO CONDIVISO: non modificare senza
aggiornare docs/CONTRATTI.md).

Il lexer (``leo.lexer``) produce una lista di :class:`Token`. Ogni token ha
un :class:`TipoToken`; sinonimi e forme di stile vengono gia' normalizzati nel
tipo canonico, mentre il testo scritto davvero dall'utente resta in
``testo_originale``.

Posizioni: ``riga`` e ``colonna`` partono da 1; ``lunghezza`` e' il numero di
caratteri occupati nel sorgente (per un token di piu' parole, dalla prima
lettera della prima parola all'ultima lettera dell'ultima).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class TipoToken(Enum):
    """Tutti i tipi di token. Il valore e' la forma canonica (per le parole
    chiave) o una descrizione leggibile (per gli altri)."""

    # --- letterali e nomi -------------------------------------------------
    INTERO = "intero"                # valore: int
    DECIMALE = "decimale"            # valore: float
    TESTO = "testo"                  # valore: str (escape gia' risolti)
    TESTO_INTERPOLATO = "testo interpolato"  # valore: list[str | ParteInterpolata]
    NOME = "nome"                    # valore: str (identificatore)

    # --- parole chiave (valore = forma canonica) ----------------------------
    VARIABILE = "variabile"          # anche "crea variabile" (un solo token)
    COSTANTE = "costante"            # anche "crea costante"
    SE = "se"
    ALLORA = "allora"
    ALTRIMENTI_SE = "altrimenti se"  # coppia di parole: un solo token
    ALTRIMENTI = "altrimenti"
    FINE = "fine"
    MENTRE = "mentre"
    FAI = "fai"
    PER_OGNI = "per ogni"            # coppia di parole: un solo token
    IN = "in"
    RIPETI = "ripeti"
    VOLTE = "volte"
    INTERROMPI = "interrompi"
    CONTINUA = "continua"
    FUNZIONE = "funzione"
    RESTITUISCI = "restituisci"
    E = "e"
    O = "o"
    NON = "non"
    VERO = "vero"
    FALSO = "falso"
    NULLA = "nulla"
    PROVA = "prova"
    CATTURA = "cattura"
    INFINE = "infine"
    LANCIA = "lancia"
    COME = "come"
    E_ACCENTATA = "è"                # anche "e'"
    NON_E_ACCENTATA = "non è"        # coppia: "non è" / "non e'"
    QUANDO = "quando"

    # --- frasi di "zucchero" (parole chiave morbide, vedi FRASI_DI_ZUCCHERO) ---
    # Il lexer le produce SOLO all'inizio di un'istruzione nella forma della
    # frase (``aumenta x di 1``, ``anima P.sinistra a 300 in 1 secondi``);
    # altrove le stesse parole restano NOME e si usano come prima.
    AUMENTA = "aumenta"
    DIMINUISCI = "diminuisci"
    ANIMA = "anima"
    PAROLA_DI_FRASE = "parola di frase"  # valore: la parola ("di", "a", "in", "secondi"...)

    # --- blocco del programma principale (parola chiave morbida) -------------
    # ``inizio`` diventa INIZIO solo quando e' DA SOLO sulla sua riga
    # (``inizio`` ... ``fine``); altrove resta NOME (``variabile inizio = 1``,
    # ``enumera(l, inizio = 1)``). Vedi :func:`e_inizio_da_solo`.
    INIZIO = "inizio"

    # --- operatori aritmetici ----------------------------------------------
    PIU = "+"
    MENO = "-"
    ASTERISCO = "*"
    BARRA = "/"
    DOPPIA_BARRA = "//"
    PERCENTUALE = "%"
    CIRCONFLESSO = "^"
    PUNTO_PUNTO = ".."
    TRE_PUNTI = "..."                # parametri variadici e argomenti espansi
    CATENA = "|>"                    # operatore di catena: x |> f  ==  f(x)

    # --- confronto -----------------------------------------------------------
    UGUALE_UGUALE = "=="
    DIVERSO = "!="
    MINORE = "<"
    MINORE_UGUALE = "<="
    MAGGIORE = ">"
    MAGGIORE_UGUALE = ">="

    # --- assegnazione ----------------------------------------------------
    ASSEGNA = "="
    PIU_ASSEGNA = "+="
    MENO_ASSEGNA = "-="
    PER_ASSEGNA = "*="
    DIVISO_ASSEGNA = "/="

    # --- punteggiatura -----------------------------------------------------
    PARENTESI_APERTA = "("
    PARENTESI_CHIUSA = ")"
    QUADRA_APERTA = "["
    QUADRA_CHIUSA = "]"
    GRAFFA_APERTA = "{"
    GRAFFA_CHIUSA = "}"
    VIRGOLA = ","
    PUNTO = "."
    DUE_PUNTI = ":"
    #: ``testo?`` (tipo che puo' valere ``nulla``): solo attaccato a un nome o a ``)``;
    #: altrove ``?`` resta un carattere che non fa parte di Leo.
    PUNTO_INTERROGATIVO = "?"

    # --- struttura -------------------------------------------------------
    FINE_RIGA = "fine riga"          # a capo o ";" (valore: "\n" oppure ";")
    FINE_FILE = "fine file"

    # --- solo in modalita' "tollerante"/"conserva_commenti" (editor) ---------
    COMMENTO = "commento"            # valore: testo del commento incluso "#"
    ERRORE = "errore"                # valore: messaggio; solo con tollerante=True


@dataclass
class ParteInterpolata:
    """Una parte ``{espressione}`` dentro un testo interpolato.

    ``sorgente``: il testo tra le graffe (senza graffe).
    ``riga``/``colonna``: posizione del primo carattere DOPO ``{``.
    ``token``: i token dell'espressione, gia' prodotti dal lexer, terminati da
    un token FINE_FILE. Il parser li analizza con ``Parser(token).espressione_isolata()``.
    ``formato``: il formato scritto dopo i due punti (``{prezzo:2}`` -> ``"2"``,
    ``{n:migliaia}`` -> ``"migliaia"``), None se manca; ``sorgente`` resta il
    testo intero tra le graffe, i ``token`` sono solo quelli dell'espressione.
    """

    sorgente: str
    riga: int
    colonna: int
    token: list["Token"] = field(default_factory=list)
    formato: str | None = None


@dataclass
class Token:
    """Un token del sorgente.

    ``origine`` vale ``"canonica"`` (scritto nella forma canonica),
    ``"sinonimo"`` (da sinonimi.toml, es. ``finché``) oppure ``"stile"`` (forma
    di stile del progetto, es. ``sia`` per ``variabile``). In questi ultimi due
    casi ``testo_originale`` contiene il testo effettivamente scritto.
    Per i token canonici ``testo_originale`` contiene comunque il testo
    sorgente (es. ``"crea variabile"`` oppure ``"e'"``), utile a formattatore e
    colorazione; puo' essere ``None`` solo per token sintetici (FINE_FILE,
    token inseriti dal lexer per le forme di stile).
    """

    tipo: TipoToken
    valore: Any
    riga: int
    colonna: int
    testo_originale: str | None = None
    lunghezza: int = 0
    origine: str = "canonica"   # "canonica" | "sinonimo" | "stile" | "sintetico"

    def e(self, *tipi: TipoToken) -> bool:
        """Vero se il token e' di uno dei tipi indicati."""
        return self.tipo in tipi

    def __repr__(self) -> str:  # compatto, utile nei test
        return f"Token({self.tipo.name}, {self.valore!r}, {self.riga}:{self.colonna})"


# ---------------------------------------------------------------------------
# Tabelle delle parole chiave canoniche
# ---------------------------------------------------------------------------

#: Parole chiave di UNA parola -> tipo. ("crea" da solo NON e' riservato.)
PAROLE_CHIAVE: dict[str, TipoToken] = {
    "variabile": TipoToken.VARIABILE,
    "costante": TipoToken.COSTANTE,
    "se": TipoToken.SE,
    "allora": TipoToken.ALLORA,
    "altrimenti": TipoToken.ALTRIMENTI,
    "fine": TipoToken.FINE,
    "mentre": TipoToken.MENTRE,
    "fai": TipoToken.FAI,
    "in": TipoToken.IN,
    "ripeti": TipoToken.RIPETI,
    "volte": TipoToken.VOLTE,
    "interrompi": TipoToken.INTERROMPI,
    "continua": TipoToken.CONTINUA,
    "funzione": TipoToken.FUNZIONE,
    "restituisci": TipoToken.RESTITUISCI,
    "e": TipoToken.E,
    "o": TipoToken.O,
    "non": TipoToken.NON,
    "vero": TipoToken.VERO,
    "falso": TipoToken.FALSO,
    "nulla": TipoToken.NULLA,
    "prova": TipoToken.PROVA,
    "cattura": TipoToken.CATTURA,
    "infine": TipoToken.INFINE,
    "lancia": TipoToken.LANCIA,
    "come": TipoToken.COME,
    "è": TipoToken.E_ACCENTATA,
    "quando": TipoToken.QUANDO,
}

#: Parole chiave "di contesto": il lexer le lascia come NOME (si possono
#: ancora usare come nomi di variabile, per esempio ``variabile caso = 3``) e
#: il parser le riconosce solo all'inizio di un'istruzione, nella forma giusta:
#: ``scegli valore``, ``caso ... allora`` (dentro ``scegli``),
#: ``importa "file.leo"`` / ``importa nome``, ``verifica condizione``.
PAROLE_DI_CONTESTO: frozenset[str] = frozenset({"scegli", "caso", "importa", "verifica"})

#: Frasi di "zucchero sintattico" (parole chiave morbide). La prima parola vale
#: come parola chiave solo all'inizio di un'istruzione e se subito dopo, sulla
#: stessa riga, c'e' un nome (``aumenta punti``, ``anima Pulsante1.alto``):
#: ``aumenta(3)``, ``aumenta = 2``, ``Oggetto.anima()`` restano nomi normali.
#: Il parser le traduce in nodi gia' esistenti:
#: ``aumenta X di N`` -> ``X += N``; ``diminuisci X di N`` -> ``X -= N`` (senza
#: ``di``: 1); ``anima O.p a V in D secondi con curva C`` -> ``anima(O, "p", V, D, C)``.
FRASI_DI_ZUCCHERO: dict[str, TipoToken] = {
    "aumenta": TipoToken.AUMENTA,
    "diminuisci": TipoToken.DIMINUISCI,
    "anima": TipoToken.ANIMA,
}

#: Unita' di tempo dopo la durata di ``anima ... in DURATA <unita'>`` -> divisore
#: per ottenere i secondi.
UNITA_DI_TEMPO: dict[str, int] = {
    "secondi": 1, "secondo": 1, "s": 1,
    "millisecondi": 1000, "millisecondo": 1000, "ms": 1000,
}

#: Durata predefinita (secondi) di ``anima`` senza ``in ...``.
DURATA_ANIMA_PREDEFINITA = 0.3

#: Sequenze di PIU' parole riconosciute come un unico token (parole separate da
#: spazi o tabulazioni sulla stessa riga). Il lexer cerca sempre la sequenza
#: piu' lunga. "e'" viene trattato come la parola "è" prima di questa ricerca.
COPPIE_DI_PAROLE: dict[tuple[str, ...], TipoToken] = {
    ("crea", "variabile"): TipoToken.VARIABILE,
    ("crea", "costante"): TipoToken.COSTANTE,
    ("per", "ogni"): TipoToken.PER_OGNI,
    ("altrimenti", "se"): TipoToken.ALTRIMENTI_SE,
    ("non", "è"): TipoToken.NON_E_ACCENTATA,
}

#: Dopo la normalizzazione dei sinonimi il lexer fonde anche queste coppie di
#: TOKEN adiacenti sulla stessa riga (es. sinonimo "sennò" + "se").
FUSIONI_DI_TOKEN: dict[tuple[TipoToken, TipoToken], TipoToken] = {
    (TipoToken.ALTRIMENTI, TipoToken.SE): TipoToken.ALTRIMENTI_SE,
    (TipoToken.NON, TipoToken.E_ACCENTATA): TipoToken.NON_E_ACCENTATA,
}

#: Parole che possono seguire ``fine`` come etichetta facoltativa di chiusura
#: (``fine se``, ``fine mentre``, ``fine per``/``fine per ogni``, ...). Il
#: lexer NON le tratta in modo speciale: ``per`` arriva come NOME "per", le
#: altre come parole chiave; e' il parser a riconoscerle se sono sulla stessa
#: riga di ``fine``.
ETICHETTE_FINE: dict[str, str] = {
    "se": "se",
    "mentre": "mentre",
    "per": "per ogni",
    "per ogni": "per ogni",
    "ripeti": "ripeti",
    "funzione": "funzione",
    "prova": "prova",
    "quando": "quando",
    "scegli": "scegli",
    "inizio": "inizio",
    # costrutti "potenti": `fine ogni`, `fine verifica`, `fine parallelo`...
    "ogni": "ogni",
    "dopo": "dopo",
    "verifica": "verifica",
    "aspettati": "aspettati",
    "parallelo": "in parallelo",
}

#: Nomi di eventi scritti "all'inglese" accettati per tolleranza (``quando
#: Pulsante1.click fai`` vale ``quando Pulsante1.clic fai``). Con ``--rigoroso``
#: sono un errore con la correzione. Chiave: la forma scritta in minuscolo.
SINONIMI_EVENTI: dict[str, str] = {
    "click": "clic",
    "doppio_click": "doppio_clic",
    "doppioclick": "doppio_clic",
    "doppioclic": "doppio_clic",
}

#: Operatori simbolici, dal piu' lungo al piu' corto (ordine di ricerca).
OPERATORI: tuple[tuple[str, TipoToken], ...] = (
    ("==", TipoToken.UGUALE_UGUALE),
    ("!=", TipoToken.DIVERSO),
    ("<=", TipoToken.MINORE_UGUALE),
    (">=", TipoToken.MAGGIORE_UGUALE),
    ("+=", TipoToken.PIU_ASSEGNA),
    ("-=", TipoToken.MENO_ASSEGNA),
    ("*=", TipoToken.PER_ASSEGNA),
    ("/=", TipoToken.DIVISO_ASSEGNA),
    ("//", TipoToken.DOPPIA_BARRA),
    ("...", TipoToken.TRE_PUNTI),
    ("|>", TipoToken.CATENA),
    ("..", TipoToken.PUNTO_PUNTO),
    ("+", TipoToken.PIU),
    ("-", TipoToken.MENO),
    ("*", TipoToken.ASTERISCO),
    ("/", TipoToken.BARRA),
    ("%", TipoToken.PERCENTUALE),
    ("^", TipoToken.CIRCONFLESSO),
    ("<", TipoToken.MINORE),
    (">", TipoToken.MAGGIORE),
    ("=", TipoToken.ASSEGNA),
    ("(", TipoToken.PARENTESI_APERTA),
    (")", TipoToken.PARENTESI_CHIUSA),
    ("[", TipoToken.QUADRA_APERTA),
    ("]", TipoToken.QUADRA_CHIUSA),
    ("{", TipoToken.GRAFFA_APERTA),
    ("}", TipoToken.GRAFFA_CHIUSA),
    (",", TipoToken.VIRGOLA),
    (".", TipoToken.PUNTO),
    (":", TipoToken.DUE_PUNTI),
)

#: Tipi che rappresentano parole chiave (utile a colorazione e suggerimenti).
TIPI_PAROLA_CHIAVE: frozenset[TipoToken] = frozenset(PAROLE_CHIAVE.values()) | frozenset(
    COPPIE_DI_PAROLE.values()
)

#: Operatori di confronto (livello 7, concatenabili).
TIPI_CONFRONTO: frozenset[TipoToken] = frozenset({
    TipoToken.UGUALE_UGUALE, TipoToken.DIVERSO, TipoToken.MINORE,
    TipoToken.MINORE_UGUALE, TipoToken.MAGGIORE, TipoToken.MAGGIORE_UGUALE,
    TipoToken.IN, TipoToken.E_ACCENTATA, TipoToken.NON_E_ACCENTATA,
})

#: Operatori di assegnazione.
TIPI_ASSEGNAZIONE: frozenset[TipoToken] = frozenset({
    TipoToken.ASSEGNA, TipoToken.PIU_ASSEGNA, TipoToken.MENO_ASSEGNA,
    TipoToken.PER_ASSEGNA, TipoToken.DIVISO_ASSEGNA,
})

#: Forma canonica stampabile di ogni tipo di parola chiave (per messaggi e formattatore).
def forma_canonica(tipo: TipoToken) -> str:
    """Restituisce la forma canonica di un tipo di token (es. ``"per ogni"``)."""
    return tipo.value


def tipo_da_canonica(parola: str) -> TipoToken | None:
    """Da forma canonica (anche di piu' parole, es. ``"altrimenti se"``) al tipo."""
    if parola in PAROLE_CHIAVE:
        return PAROLE_CHIAVE[parola]
    parti = tuple(parola.split())
    return COPPIE_DI_PAROLE.get(parti)


def e_parola_riservata(parola: str) -> bool:
    """Vero se ``parola`` (una sola parola) e' una parola chiave canonica."""
    return parola in PAROLE_CHIAVE or parola == "e'"


# ---------------------------------------------------------------------------
# Blocco ``inizio ... fine``: riconoscimento condiviso da lexer e parser
# ---------------------------------------------------------------------------

def e_inizio_da_solo(token: list[Token], i: int) -> bool:
    """Vero se ``token[i]`` e' la parola ``inizio`` da sola sulla sua riga
    (commenti a parte): allora apre il blocco del programma principale.

    ``variabile inizio = 3``, ``inizio = 2``, ``stampa(inizio)``, ``x; inizio``
    non la riguardano: li' ``inizio`` resta un nome qualsiasi."""
    t = token[i]
    if t.tipo is TipoToken.INIZIO:
        return True
    if t.tipo is not TipoToken.NOME or t.valore != "inizio":
        return False
    j = i - 1
    while j >= 0 and token[j].tipo is TipoToken.COMMENTO:
        j -= 1
    if j >= 0 and token[j].riga == t.riga and token[j].tipo is not TipoToken.FINE_FILE:
        return False           # qualcosa prima, sulla stessa riga (anche `;`)
    k = i + 1
    while k < len(token) and token[k].tipo is TipoToken.COMMENTO:
        k += 1
    if k >= len(token):
        return True
    succ = token[k]
    if succ.tipo is TipoToken.FINE_FILE:
        return True
    return succ.tipo is TipoToken.FINE_RIGA and succ.valore != ";"


# ---------------------------------------------------------------------------
# Frasi di zucchero: riconoscimento condiviso da lexer e parser
# ---------------------------------------------------------------------------

_APRE = frozenset({TipoToken.PARENTESI_APERTA, TipoToken.QUADRA_APERTA, TipoToken.GRAFFA_APERTA})
_CHIUDE = frozenset({TipoToken.PARENTESI_CHIUSA, TipoToken.QUADRA_CHIUSA, TipoToken.GRAFFA_CHIUSA})
_TESTI = frozenset({TipoToken.TESTO, TipoToken.TESTO_INTERPOLATO})


def _parola_di(tok: Token) -> str | None:
    """La parola scritta se ``tok`` e' un nome (o gia' una parola di frase)."""
    if tok.tipo in (TipoToken.NOME, TipoToken.PAROLA_DI_FRASE) and isinstance(tok.valore, str):
        return tok.valore
    if tok.tipo is TipoToken.IN:
        return "in"
    return None


def testa_di_frase(token: list[Token], i: int) -> str | None:
    """Se ``token[i]`` (all'inizio di un'istruzione) comincia una frase di
    zucchero restituisce la parola (``"aumenta"``, ``"diminuisci"``, ``"anima"``).

    Serve un nome subito dopo, sulla stessa riga (i commenti si saltano)."""
    t = token[i]
    if t.tipo in (TipoToken.AUMENTA, TipoToken.DIMINUISCI, TipoToken.ANIMA):
        return t.tipo.value
    if t.tipo is not TipoToken.NOME or t.valore not in FRASI_DI_ZUCCHERO:
        return None
    j = i + 1
    while j < len(token) and token[j].tipo is TipoToken.COMMENTO:
        j += 1
    if j >= len(token):
        return None
    succ = token[j]
    if succ.riga != t.riga or succ.tipo is not TipoToken.NOME:
        return None
    return str(t.valore)


def parole_di_frase(token: list[Token], i: int) -> dict[int, str]:
    """Indici delle parole di collegamento della frase che comincia in ``i``
    (``testa_di_frase`` deve essere vera): indice -> parola.

    ``aumenta``/``diminuisci``: il primo ``di`` fuori dalle parentesi.
    ``anima``: ``a`` (anche ``fino a``), poi ``in``, l'unita' di tempo in fondo
    alla durata, ``con curva`` (anche ``con la curva``, ``con "..."``,
    ``curva "..."``). Le parole dopo un punto (``x.di``) non contano."""
    testa = testa_di_frase(token, i)
    if testa is None:
        return {}
    # indici dei token della riga logica (senza commenti), con profondita' 0
    riga: list[tuple[int, int]] = []   # (indice, profondita')
    livello = 0
    for k in range(i + 1, len(token)):
        t = token[k]
        if t.tipo is TipoToken.COMMENTO:
            continue
        if t.tipo in (TipoToken.FINE_RIGA, TipoToken.FINE_FILE) and livello <= 0:
            break
        if t.tipo in _CHIUDE:
            livello -= 1
        riga.append((k, livello))
        if t.tipo in _APRE:
            livello += 1
    esterni = [k for n, (k, liv) in enumerate(riga) if liv == 0]
    posizione = {k: n for n, k in enumerate(esterni)}

    def parola(k: int) -> str | None:
        n = posizione[k]
        if n > 0 and token[esterni[n - 1]].tipo is TipoToken.PUNTO:
            return None
        return _parola_di(token[k])

    def seguente(k: int) -> Token | None:
        n = posizione[k] + 1
        return token[esterni[n]] if n < len(esterni) else None

    trovate: dict[int, str] = {}
    candidati = esterni[1:]  # il primo e' l'inizio del bersaglio
    if testa in ("aumenta", "diminuisci"):
        for k in candidati:
            if parola(k) == "di":
                trovate[k] = "di"
                break
        return trovate
    # anima
    k_a = next((k for k in candidati if parola(k) == "a"), None)
    if k_a is None:
        return trovate
    trovate[k_a] = "a"
    n_a = posizione[k_a]
    if n_a >= 2 and parola(esterni[n_a - 1]) == "fino":
        trovate[esterni[n_a - 1]] = "fino"
    dopo = [k for k in esterni if posizione[k] > n_a]
    # curva
    k_curva = None
    for k in dopo:
        p = parola(k)
        succ = seguente(k)
        if p == "con" and succ is not None:
            ps = _parola_di(succ)
            if ps == "curva":
                trovate[k] = "con"
                trovate[esterni[posizione[k] + 1]] = "curva"
                k_curva = k
                break
            if ps == "la":
                terzo = seguente(esterni[posizione[k] + 1])
                if terzo is not None and _parola_di(terzo) == "curva":
                    trovate[k] = "con"
                    trovate[esterni[posizione[k] + 1]] = "la"
                    trovate[esterni[posizione[k] + 2]] = "curva"
                    k_curva = k
                    break
            if succ.tipo in _TESTI:
                trovate[k] = "con"
                k_curva = k
                break
        if p == "curva" and succ is not None and succ.tipo in _TESTI:
            trovate[k] = "curva"
            k_curva = k
            break
    fino_a = [k for k in dopo if k_curva is None or posizione[k] < posizione[k_curva]]
    k_in = next((k for k in fino_a if parola(k) == "in"), None)
    if k_in is not None:
        trovate[k_in] = "in"
        durata = [k for k in fino_a if posizione[k] > posizione[k_in]]
        if len(durata) >= 2 and parola(durata[-1]) in UNITA_DI_TEMPO:
            trovate[durata[-1]] = str(parola(durata[-1]))
    return trovate


def segna_frase(token: list[Token], i: int) -> bool:
    """Ritipizza sul posto la frase di zucchero che comincia in ``token[i]``:
    la prima parola diventa ``AUMENTA``/``DIMINUISCI``/``ANIMA``, le parole di
    collegamento ``PAROLA_DI_FRASE`` (valore = la parola). Vero se c'era una frase."""
    testa = testa_di_frase(token, i)
    if testa is None:
        return False
    for k, p in parole_di_frase(token, i).items():
        t = token[k]
        if t.tipo is not TipoToken.PAROLA_DI_FRASE:
            token[k] = Token(TipoToken.PAROLA_DI_FRASE, p, t.riga, t.colonna, t.testo_originale,
                             t.lunghezza, t.origine)
    t = token[i]
    tipo = FRASI_DI_ZUCCHERO[testa]
    if t.tipo is not tipo:
        token[i] = Token(tipo, testa, t.riga, t.colonna, t.testo_originale, t.lunghezza, t.origine)
    return True


# ---------------------------------------------------------------------------
# Costrutti "potenti": temporizzatori, verifiche incorporate, lavori in parallelo
# ---------------------------------------------------------------------------
#
# Come ``scegli``/``verifica`` sono parole di contesto: il lexer le lascia NOME
# (``variabile dopo = 3``, ``ogni(3)`` restano validi) e diventano comandi solo
# all'inizio di un'istruzione e nella forma giusta. Il riconoscimento e' qui,
# condiviso da parser, formattatore e colorazione, cosi' non possono essere in
# disaccordo:
#
# * ``ogni 2 secondi fai`` / ``dopo 300 millisecondi fai`` / ``ogni secondo fai``
#   (serve ``fai``, tollerato ``allora``, oppure l'unita' di tempo in fondo);
# * ``verifica "nome del test" fai`` (senza ``fai`` resta la vecchia ``verifica
#   condizione``);
# * ``aspettati condizione`` e ``aspettati errore [TipoErrore] fai``;
# * ``in parallelo fai`` (anche come valore: ``variabile l = in parallelo fai``).

#: Unita' di tempo di ``ogni``/``dopo`` -> secondi per unita'.
UNITA_TEMPORIZZATORI: dict[str, float] = {
    "secondi": 1.0, "secondo": 1.0, "s": 1.0,
    "millisecondi": 0.001, "millisecondo": 0.001, "ms": 0.001,
    "minuti": 60.0, "minuto": 60.0,
}

#: Prime parole dei costrutti di questa sezione (NOME all'inizio dell'istruzione).
PAROLE_POTENZA: frozenset[str] = frozenset({"ogni", "dopo", "verifica", "aspettati"})

_BLOCCO_FAI = frozenset({TipoToken.FAI, TipoToken.ALLORA})
_NON_VALORE_DOPO_TESTA = frozenset({
    TipoToken.ASSEGNA, TipoToken.PIU_ASSEGNA, TipoToken.MENO_ASSEGNA, TipoToken.PER_ASSEGNA,
    TipoToken.DIVISO_ASSEGNA, TipoToken.PUNTO, TipoToken.QUADRA_APERTA, TipoToken.VIRGOLA,
    TipoToken.CATENA, TipoToken.FINE_RIGA, TipoToken.FINE_FILE,
})
_INIZIO_ASPETTATIVA = frozenset({
    TipoToken.INTERO, TipoToken.DECIMALE, TipoToken.TESTO, TipoToken.TESTO_INTERPOLATO, TipoToken.NOME,
    TipoToken.VERO, TipoToken.FALSO, TipoToken.NULLA, TipoToken.NON, TipoToken.MENO,
    TipoToken.QUADRA_APERTA, TipoToken.GRAFFA_APERTA, TipoToken.FUNZIONE,
})
#: Token dopo i quali ``in`` non puo' essere l'operatore ``x in lista``: li'
#: ``in parallelo fai`` comincia un valore.
_PRIMA_DI_UN_VALORE = frozenset({
    TipoToken.FINE_RIGA, TipoToken.ASSEGNA, TipoToken.PIU_ASSEGNA, TipoToken.MENO_ASSEGNA,
    TipoToken.PER_ASSEGNA, TipoToken.DIVISO_ASSEGNA, TipoToken.PARENTESI_APERTA, TipoToken.QUADRA_APERTA,
    TipoToken.VIRGOLA, TipoToken.RESTITUISCI, TipoToken.FAI, TipoToken.ALLORA, TipoToken.ALTRIMENTI,
    TipoToken.DUE_PUNTI,
})


def _riga_logica(token: list[Token], i: int) -> list[int]:
    """Indici dei token (senza commenti) della riga logica che comincia in ``i``,
    fuori dalle parentesi (``i`` compreso)."""
    indici: list[int] = []
    livello = 0
    for k in range(i, len(token)):
        t = token[k]
        if t.tipo in (TipoToken.COMMENTO, TipoToken.ERRORE):
            continue
        if t.tipo in (TipoToken.FINE_RIGA, TipoToken.FINE_FILE) and livello <= 0:
            break
        if t.tipo in _CHIUDE:
            livello -= 1
        if livello <= 0:
            indici.append(k)
        if t.tipo in _APRE:
            livello += 1
    return indici


def frase_potenza(token: list[Token], i: int) -> tuple[str, dict[int, str]] | None:
    """Se ``token[i]`` (all'inizio di un'istruzione) comincia uno dei costrutti di
    questa sezione restituisce ``(genere, parole)``: ``genere`` e' ``"ogni"``,
    ``"dopo"``, ``"verifica"``, ``"aspettati"`` o ``"aspettati errore"``;
    ``parole`` = indice -> parola dei token che fanno da parola chiave
    (la prima parola, l'unita' di tempo, ``errore``)."""
    t = token[i]
    if t.tipo is not TipoToken.NOME or t.valore not in PAROLE_POTENZA:
        return None
    riga = _riga_logica(token, i)
    if len(riga) < 2:
        return None
    secondo = token[riga[1]]
    if secondo.riga != t.riga:
        return None
    ultimo = token[riga[-1]]
    parola = str(t.valore)
    if parola in ("ogni", "dopo"):
        if secondo.tipo in _NON_VALORE_DOPO_TESTA or secondo.tipo in _BLOCCO_FAI:
            return None
        unita_in_fondo = (ultimo.tipo is TipoToken.NOME and ultimo.valore in UNITA_TEMPORIZZATORI
                          and len(riga) >= 2)
        if ultimo.tipo not in _BLOCCO_FAI and not unita_in_fondo:
            return None
        if secondo.tipo is TipoToken.PARENTESI_APERTA and ultimo.tipo not in _BLOCCO_FAI:
            return None   # `ogni(3) secondi`? meglio lasciarlo com'e'
        parole = {i: parola}
        k_unita = riga[-1] if unita_in_fondo else (riga[-2] if len(riga) >= 3 else None)
        if k_unita is not None and token[k_unita].tipo is TipoToken.NOME \
                and token[k_unita].valore in UNITA_TEMPORIZZATORI:
            parole[k_unita] = str(token[k_unita].valore)
        return parola, parole
    if parola == "verifica":
        if len(riga) == 3 and secondo.tipo in _TESTI and ultimo.tipo in _BLOCCO_FAI:
            return "verifica", {i: "verifica"}
        return None
    # aspettati
    if secondo.tipo is TipoToken.NOME and secondo.valore == "errore":
        resto = [token[k] for k in riga[2:]]
        if (resto and resto[-1].tipo in _BLOCCO_FAI) or len(resto) <= 1 and all(
                x.tipo is TipoToken.NOME for x in resto):
            return "aspettati errore", {i: "aspettati", riga[1]: "errore"}
    if secondo.tipo in _INIZIO_ASPETTATIVA:
        return "aspettati", {i: "aspettati"}
    return None


def e_in_parallelo(token: list[Token], i: int) -> bool:
    """Vero se ``token[i]`` e' ``in`` di ``in parallelo fai`` (un valore: dopo
    ``=``, ``(``, ``,``, ``restituisci`` o all'inizio dell'istruzione), non
    l'operatore di ``x in lista`` ne' il ``in`` di ``per ogni x in parallelo``."""
    t = token[i]
    if t.tipo is not TipoToken.IN:
        return False
    successivi = [k for k in range(i + 1, min(len(token), i + 6))
                  if token[k].tipo is not TipoToken.COMMENTO][:2]
    if len(successivi) < 2:
        return False
    p, f = token[successivi[0]], token[successivi[1]]
    if not (p.tipo is TipoToken.NOME and p.valore == "parallelo" and p.riga == t.riga):
        return False
    if f.tipo not in _BLOCCO_FAI or f.riga != t.riga:
        return False
    j = i - 1
    while j >= 0 and token[j].tipo is TipoToken.COMMENTO:
        j -= 1
    if j < 0:
        return True
    prec = token[j]
    return prec.riga != t.riga or prec.tipo in _PRIMA_DI_UN_VALORE


def parole_potenza(token: list[Token]) -> dict[int, str]:
    """Tutte le parole dei costrutti di questa sezione in una lista di token
    (per colorazione e formattatore): indice -> parola. ``in`` e ``parallelo``
    compresi. Le parole vengono cercate all'inizio di ogni istruzione (a inizio
    riga, dopo ``;`` o dopo ``allora``/``fai``/``altrimenti``)."""
    trovate: dict[int, str] = {}
    inizio = True
    for k, t in enumerate(token):
        if t.tipo in (TipoToken.COMMENTO, TipoToken.ERRORE):
            continue
        if inizio and t.tipo is TipoToken.NOME:
            frase = frase_potenza(token, k)
            if frase is not None:
                trovate.update(frase[1])
        if t.tipo is TipoToken.IN and e_in_parallelo(token, k):
            trovate[k] = "in"
            n = k + 1
            while n < len(token) and token[n].tipo is TipoToken.COMMENTO:
                n += 1
            if n < len(token):
                trovate[n] = "parallelo"
        inizio = t.tipo in (TipoToken.FINE_RIGA, TipoToken.ALLORA, TipoToken.FAI, TipoToken.ALTRIMENTI)
    return trovate


def teste_di_blocco_potenza(token: list[Token]) -> set[int]:
    """Indici dei token che aprono un blocco chiuso da ``fine`` tra i costrutti di
    questa sezione (``ogni``/``dopo``/``verifica "..."``/``aspettati errore``/
    ``in`` di ``in parallelo``)."""
    teste: set[int] = set()
    inizio = True
    for k, t in enumerate(token):
        if t.tipo in (TipoToken.COMMENTO, TipoToken.ERRORE):
            continue
        if inizio and t.tipo is TipoToken.NOME:
            frase = frase_potenza(token, k)
            if frase is not None and frase[0] != "aspettati":
                riga = _riga_logica(token, k)
                if token[riga[-1]].tipo in _BLOCCO_FAI:
                    teste.add(k)
        if t.tipo is TipoToken.IN and e_in_parallelo(token, k):
            teste.add(k)
        inizio = t.tipo in (TipoToken.FINE_RIGA, TipoToken.ALLORA, TipoToken.FAI, TipoToken.ALTRIMENTI)
    return teste
