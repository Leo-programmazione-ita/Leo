"""`leo spiega`: racconta in italiano semplice che cosa fa un programma.

Parte dall'albero sintattico (``leo.nodi``) e produce una frase per ogni
istruzione, con i blocchi rientrati. Tre livelli:

- ``"semplice"``  frasi brevi, per chi inizia, senza numeri di riga;
- ``"normale"``   una frase per istruzione con il numero di riga;
- ``"dettagli"``  come normale, piu' il codice di ogni riga e qualche nota
  ("`+=` e' una scorciatoia", "gli indici partono da 0"...) e un riepilogo.

API:
    spiega_sorgente(sorgente, nome_file="<sorgente>", *, livello="normale", rigoroso=False) -> str
    spiega_programma(programma, *, livello="normale", sorgente=None, titolo=None) -> str
    descrivi_espressione(espressione, *, semplice=False) -> str
    codice_espressione(espressione) -> str
    LIVELLI

Esempio::

    >>> print(spiega_sorgente("variabile totale = 0\\n", livello="semplice"))
    Ecco cosa fa il programma:
    <BLANKLINE>
    - Crea la variabile totale e le dà il valore 0.
"""

from __future__ import annotations

from typing import Any

from . import nodi as N

__all__ = ["LIVELLI", "spiega_sorgente", "spiega_programma", "descrivi_espressione",
           "codice_espressione"]

LIVELLI = ("semplice", "normale", "dettagli")

_RIENTRO = "    "

# ---------------------------------------------------------------------------
# Codice (ricostruito dall'albero) per le espressioni complesse
# ---------------------------------------------------------------------------

_PRECEDENZA = {"o": 1, "e": 2, "non": 3, "cmp": 4, "..": 5, "+": 6, "-": 6,
               "*": 7, "/": 7, "//": 7, "%": 7, "neg": 8, "^": 9}


def _testo_letterale(valore: Any) -> str:
    if valore is True:
        return "vero"
    if valore is False:
        return "falso"
    if valore is None:
        return "nulla"
    if isinstance(valore, str):
        return '"' + valore.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n") + '"'
    if isinstance(valore, float):
        return repr(valore)
    return str(valore)


def _prec(e: Any) -> int:
    if isinstance(e, N.Logica):
        return _PRECEDENZA[e.operatore]
    if isinstance(e, N.Unaria):
        return _PRECEDENZA["non"] if e.operatore == "non" else _PRECEDENZA["neg"]
    if isinstance(e, N.Confronto):
        return _PRECEDENZA["cmp"]
    if isinstance(e, N.Intervallo):
        return _PRECEDENZA[".."]
    if isinstance(e, N.Binaria):
        return _PRECEDENZA.get(e.operatore, 6)
    return 99


def _tra_parentesi(e: Any, minima: int) -> str:
    testo = codice_espressione(e)
    return f"({testo})" if _prec(e) < minima else testo


def _testo_di_comando(e: Any) -> str:
    """Il testo di un comando senza parentesi con i calcoli tra parentesi tonde."""
    parti = []
    for p in e.parti:
        if isinstance(p, str):
            parti.append(p)
        elif isinstance(p, N.ValoreFormattato):
            parti.append("(" + codice_espressione(p.valore) + ":" + p.formato + ")")
        elif isinstance(p, N.Chiamata):
            parti.append(codice_espressione(p))
        else:
            parti.append("(" + codice_espressione(p) + ")")
    return "".join(parti)


def codice_espressione(e: Any) -> str:
    """Ricostruisce il codice Leo di un'espressione (senza commenti ne' sinonimi)."""
    if isinstance(e, N.Letterale):
        return _testo_letterale(e.valore)
    if isinstance(e, N.Nome):
        return e.nome
    if isinstance(e, N.TestoInterpolato):
        parti = []
        for p in e.parti:
            if isinstance(p, str):
                parti.append(p.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n"))
            elif isinstance(p, N.ValoreFormattato):
                parti.append("{" + codice_espressione(p.valore) + ":" + p.formato + "}")
            else:
                parti.append("{" + codice_espressione(p) + "}")
        return '"' + "".join(parti) + '"'
    if isinstance(e, N.ListaLetterale):
        return "[" + ", ".join(codice_espressione(x) for x in e.elementi) + "]"
    if isinstance(e, N.DizionarioLetterale):
        return "{" + ", ".join(f"{codice_espressione(k)}: {codice_espressione(v)}" for k, v in e.coppie) + "}"
    if isinstance(e, N.Binaria):
        p = _prec(e)
        destra_min = p + 1 if e.operatore != "^" else p
        sinistra_min = p if e.operatore != "^" else p + 1
        return f"{_tra_parentesi(e.sinistra, sinistra_min)} {e.operatore} {_tra_parentesi(e.destra, destra_min)}"
    if isinstance(e, N.Logica):
        p = _prec(e)
        return f"{_tra_parentesi(e.sinistra, p)} {e.operatore} {_tra_parentesi(e.destra, p + 1)}"
    if isinstance(e, N.Unaria):
        if e.operatore == "non":
            return "non " + _tra_parentesi(e.operando, _PRECEDENZA["non"])
        return "-" + _tra_parentesi(e.operando, _PRECEDENZA["neg"])
    if isinstance(e, N.Confronto):
        pezzi = [_tra_parentesi(e.operandi[0], _PRECEDENZA["cmp"] + 1)]
        for op, x in zip(e.operatori, e.operandi[1:]):
            pezzi.append(f"{op} {_tra_parentesi(x, _PRECEDENZA['cmp'] + 1)}")
        return " ".join(pezzi)
    if isinstance(e, N.Intervallo):
        return f"{_tra_parentesi(e.inizio, 6)}..{_tra_parentesi(e.fine, 6)}"
    if isinstance(e, N.Chiamata):
        return f"{_tra_parentesi(e.funzione, 99)}({_codice_argomenti(e.argomenti)})"
    if isinstance(e, N.Indice):
        return f"{_tra_parentesi(e.oggetto, 99)}[{codice_espressione(e.indice)}]"
    if isinstance(e, N.Attributo):
        return f"{_tra_parentesi(e.oggetto, 99)}.{e.nome}"
    if isinstance(e, N.FunzioneAnonima):
        return f"funzione ({_codice_parametri(e.parametri)}) ... fine"
    if isinstance(e, N.Parallelo):
        return "in parallelo fai ... fine"
    if isinstance(e, N.ValoreFormattato):
        return codice_espressione(e.valore)
    if isinstance(e, N.HaValore):
        return f"{_tra_parentesi(e.valore, 99)} {'non ' if e.negato else ''}ha valore"
    return "..."


def _codice_argomenti(argomenti: list) -> str:
    pezzi = []
    for a in argomenti:
        valore = codice_espressione(a.valore)
        pezzi.append(f"{a.nome} = {valore}" if a.nome else valore)
    return ", ".join(pezzi)


def _codice_parametri(parametri: list) -> str:
    pezzi = []
    for p in parametri:
        testo = p.nome
        if p.tipo:
            testo += f": {p.tipo}"
        if p.predefinito is not None:
            testo += f" = {codice_espressione(p.predefinito)}"
        pezzi.append(testo)
    return ", ".join(pezzi)


# ---------------------------------------------------------------------------
# Espressioni a parole
# ---------------------------------------------------------------------------

_BINARIE = {
    "+": "{a} più {b}", "-": "{a} meno {b}", "*": "{a} per {b}", "/": "{a} diviso {b}",
    "//": "la divisione intera di {a} per {b}", "%": "il resto di {a} diviso {b}",
    "^": "{a} elevato alla {b}",
}

_CONFRONTI = {
    "==": "è uguale a", "!=": "è diverso da", "<": "è minore di", "<=": "è minore o uguale a",
    ">": "è maggiore di", ">=": "è maggiore o uguale a", "in": "si trova in",
    "è": "è", "non è": "non è",
}

#: Funzioni di libreria raccontate in modo speciale: {nome: modello con {0}, {1}...}.
_FUNZIONI_NOTE = {
    "lunghezza": "la lunghezza di {0}",
    "massimo": "il più grande tra {tutti}",
    "minimo": "il più piccolo tra {tutti}",
    "somma": "la somma di {0}",
    "radice": "la radice quadrata di {0}",
    "assoluto": "il valore assoluto di {0}",
    "arrotonda": "{0} arrotondato a {1} cifre dopo la virgola",
    "chiedi": "la risposta alla domanda {0}",
    "casuale": "un numero a caso tra {0} e {1}",
    "testo": "{0} trasformato in testo",
    "intero": "{0} trasformato in numero intero",
    "decimale": "{0} trasformato in numero decimale",
    "tipo": "il tipo di {0}",
    "oggi": "la data di oggi",
    "ora": "l'ora attuale",
    "leggi_file": "il contenuto del file {0}",
}

#: Istruzioni-chiamata raccontate in modo speciale.
_AZIONI_NOTE = {
    "stampa": "Scrive sullo schermo {tutti}",
    "attendi": "Aspetta {0} secondi",
    "avanti": "Fa andare avanti la tartaruga di {0} passi",
    "indietro": "Fa andare indietro la tartaruga di {0} passi",
    "destra": "Fa girare la tartaruga a destra di {0} gradi",
    "sinistra": "Fa girare la tartaruga a sinistra di {0} gradi",
    "punta_verso": "Gira la tartaruga verso {0} gradi",
    "vai_a": "Porta la tartaruga al punto {0}, {1}",
    "cerchio": "Disegna un cerchio di raggio {0}",
    "colore": "Cambia il colore della penna ({tutti})",
    "sfondo": "Cambia il colore dello sfondo ({tutti})",
    "spessore": "Usa una penna spessa {0}",
    "casa": "Riporta la tartaruga al centro",
    "penna_su": "Alza la penna (la tartaruga si muove senza disegnare)",
    "penna_giu": "Abbassa la penna (la tartaruga torna a disegnare)",
    "penna_giù": "Abbassa la penna (la tartaruga torna a disegnare)",
    "pulisci_disegno": "Cancella il disegno",
    "chiedi": "Chiede {0} e aspetta la risposta",
    "domanda": "Chiede {0} e aspetta la risposta",
    "scrivi_file": "Scrive nel file {0} il testo {1}",
    "messaggio": "Mostra un messaggio con {tutti}",
    "apri_finestra": "Apre la finestra {0}",
    "chiudi_finestra": "Chiude la finestra {0}",
}

_METODI_NOTI = {
    "aggiungi": "Aggiunge {0} in fondo a {ogg}",
    "inserisci": "Inserisce {1} in {ogg} alla posizione {0}",
    "rimuovi": "Toglie {0} da {ogg}",
    "ordina": "Mette in ordine {ogg}",
    "svuota": "Svuota {ogg}",
    "inverti": "Rovescia l'ordine di {ogg}",
}

_TROPPO_LUNGO = 60


def _elenco(parole: list[str]) -> str:
    if not parole:
        return "niente"
    if len(parole) == 1:
        return parole[0]
    return ", ".join(parole[:-1]) + " e " + parole[-1]


def _numero_parola(n: int, singolare: str, plurale: str) -> str:
    return f"{n} {singolare if n == 1 else plurale}"


def descrivi_espressione(e: Any, *, semplice: bool = False) -> str:
    """Un'espressione raccontata a parole (``"totale più 1"``, ``"la lunghezza di voti"``)."""
    d = lambda x: descrivi_espressione(x, semplice=semplice)  # noqa: E731
    if isinstance(e, N.Letterale):
        if isinstance(e.valore, str):
            return f'il testo "{e.valore}"' if len(e.valore) <= _TROPPO_LUNGO else "un testo lungo"
        return _testo_letterale(e.valore)
    if isinstance(e, N.Nome):
        return e.nome
    if isinstance(e, N.TestoInterpolato):
        if getattr(e, "da_comando", False):
            # `stampa Ciao (nome)`: come l'ha scritto chi programma, con le parentesi che calcolano
            return f'il testo "{_testo_di_comando(e)}"'
        return f"il testo {codice_espressione(e)}"
    if isinstance(e, N.ListaLetterale):
        n = len(e.elementi)
        if n == 0:
            return "una lista vuota"
        if semplice or n > 6:
            return "una lista di " + _numero_parola(n, "elemento", "elementi")
        return "la lista con " + _elenco([d(x) for x in e.elementi])
    if isinstance(e, N.DizionarioLetterale):
        n = len(e.coppie)
        if n == 0:
            return "un dizionario vuoto"
        chiavi = [codice_espressione(k) for k, _ in e.coppie]
        if semplice or n > 5:
            return "un dizionario con " + _numero_parola(n, "coppia", "coppie") + " chiave-valore"
        return "un dizionario con le chiavi " + _elenco(chiavi)
    if isinstance(e, N.Binaria):
        modello = _BINARIE.get(e.operatore, "{a} " + e.operatore + " {b}")
        return modello.format(a=_sotto(e.sinistra, semplice), b=_sotto(e.destra, semplice))
    if isinstance(e, N.Logica):
        legame = "e" if e.operatore == "e" else "oppure"
        return f"{d(e.sinistra)} {legame} {d(e.destra)}"
    if isinstance(e, N.Unaria):
        if e.operatore == "non":
            return f"non è vero che {d(e.operando)}"
        return f"meno {_sotto(e.operando, semplice)}"
    if isinstance(e, N.Confronto):
        return _confronto_catena(e, semplice)
    if isinstance(e, N.Intervallo):
        return f"i numeri da {d(e.inizio)} a {d(e.fine)}"
    if isinstance(e, N.Chiamata):
        return _descrivi_chiamata(e, semplice)
    if isinstance(e, N.Indice):
        if isinstance(e.indice, N.Letterale) and isinstance(e.indice.valore, str):
            return f"il valore della chiave {d(e.indice)} in {d(e.oggetto)}"
        if isinstance(e.indice, N.Unaria) and e.indice.operatore == "-" and \
                isinstance(e.indice.operando, N.Letterale) and e.indice.operando.valore == 1:
            return f"l'ultimo elemento di {d(e.oggetto)}"
        return f"l'elemento di {d(e.oggetto)} in posizione {d(e.indice)}"
    if isinstance(e, N.Attributo):
        return f"la proprietà {e.nome} di {d(e.oggetto)}"
    if isinstance(e, N.FunzioneAnonima):
        nomi = [p.nome for p in e.parametri]
        return "una funzione senza nome che riceve " + _elenco(nomi) if nomi else "una funzione senza nome"
    if isinstance(e, N.Parallelo):
        return "un lavoro che parte in parallelo"
    if isinstance(e, N.HaValore):
        return f"{d(e.valore)} {'non ' if e.negato else ''}ha un valore (non è nulla)"
    return codice_espressione(e)


def _confronto_catena(e: Any, semplice: bool) -> str:
    frasi = []
    for i, op in enumerate(e.operatori):
        a = descrivi_espressione(e.operandi[i], semplice=semplice)
        b = descrivi_espressione(e.operandi[i + 1], semplice=semplice)
        frasi.append(f"{a} {_CONFRONTI.get(op, op)} {b}")
    return " e ".join(frasi)


def _sotto(e: Any, semplice: bool) -> str:
    """Operando di un'operazione: le operazioni annidate si mettono tra parentesi."""
    testo = descrivi_espressione(e, semplice=semplice)
    if isinstance(e, (N.Binaria, N.Logica, N.Confronto)):
        return f"({testo})"
    return testo


def _argomenti(argomenti: list, semplice: bool) -> list[str]:
    risultato = []
    for a in argomenti:
        testo = _sotto(a.valore, semplice)
        risultato.append(f"{a.nome} = {testo}" if a.nome else testo)
    return risultato


def _riempi(modello: str, argomenti: list[str], **altro: str) -> str | None:
    """Riempie un modello con {0}, {1}, {tutti}; None se mancano argomenti."""
    try:
        return modello.format(*argomenti, tutti=_elenco(argomenti), **altro)
    except (IndexError, KeyError):
        return None


def _descrivi_chiamata(e: Any, semplice: bool) -> str:
    args = _argomenti(e.argomenti, semplice)
    if isinstance(e.funzione, N.Nome):
        nome = e.funzione.nome
        if nome == "chiedi" and e.argomenti and isinstance(e.argomenti[0].valore, (N.Letterale, N.TestoInterpolato)):
            return f"la risposta alla domanda {codice_espressione(e.argomenti[0].valore)}"
        modello = _FUNZIONI_NOTE.get(nome)
        if modello:
            testo = _riempi(modello, args)
            if testo:
                return testo
        if not args:
            return f"il risultato di {nome}()"
        return f"il risultato di {nome} con {_elenco(args)}"
    if isinstance(e.funzione, N.Attributo):
        ogg = descrivi_espressione(e.funzione.oggetto, semplice=semplice)
        metodo = e.funzione.nome
        if not args:
            return f"il risultato di {metodo} su {ogg}"
        return f"il risultato di {metodo} su {ogg} con {_elenco(args)}"
    return f"il risultato della chiamata {codice_espressione(e)}"


# ---------------------------------------------------------------------------
# Istruzioni a parole
# ---------------------------------------------------------------------------

class _Narratore:
    def __init__(self, livello: str, righe_sorgente: list[str] | None) -> None:
        if livello not in LIVELLI:
            raise ValueError(f"Livello sconosciuto: {livello!r} (usa {', '.join(LIVELLI)}).")
        self.livello = livello
        self.semplice = livello == "semplice"
        self.dettagli = livello == "dettagli"
        self.righe_sorgente = righe_sorgente or []
        self.uscita: list[str] = []
        self.variabili: list[str] = []
        self.funzioni: list[str] = []
        self.costanti: list[str] = []
        self.cicli = 0
        self.decisioni = 0
        self._note_date: set[str] = set()

    # --- utilita' ---
    def e(self, espressione: Any) -> str:
        return descrivi_espressione(espressione, semplice=self.semplice)

    def scrivi(self, profondita: int, frase: str, nodo: Any = None, note: tuple[str, ...] = ()) -> None:
        rientro = _RIENTRO * profondita
        frase = frase[0].upper() + frase[1:] if frase else frase
        riga = getattr(nodo, "riga", 0) if nodo is not None else 0
        if self.semplice or not riga:
            self.uscita.append(f"{rientro}- {frase}")
        else:
            self.uscita.append(f"{rientro}- Riga {riga}: {frase}")
        if self.dettagli:
            if riga and 0 < riga <= len(self.righe_sorgente):
                codice = self.righe_sorgente[riga - 1].strip()
                if codice:
                    self.uscita.append(f"{rientro}    codice: {codice}")
            for nota in note:
                if nota not in self._note_date:
                    self._note_date.add(nota)
                    self.uscita.append(f"{rientro}    nota: {nota}")

    def blocco(self, istruzioni: list, profondita: int) -> None:
        if not istruzioni:
            self.scrivi(profondita, "Non fa niente (il blocco è vuoto).")
            return
        for istruzione in istruzioni:
            self.istruzione(istruzione, profondita)

    def istruzione(self, nodo: Any, profondita: int) -> None:
        metodo = getattr(self, "_" + type(nodo).__name__, None)
        if metodo is None:
            self.scrivi(profondita, f"Esegue {type(nodo).__name__}.", nodo)
            return
        metodo(nodo, profondita)

    # --- istruzioni ---
    def _Dichiarazione(self, n: Any, p: int) -> None:
        valore = n.valore
        if isinstance(valore, N.Parallelo) and not n.costante:
            if n.nome not in self.variabili:
                self.variabili.append(n.nome)
            self._parallelo(valore, p, n, n.nome)
            return
        note: list[str] = []
        if n.costante:
            self.costanti.append(n.nome)
            frase = f"Crea la costante {n.nome} con il valore {self.e(valore)}"
            frase += ", che non si potrà più cambiare." if not self.semplice else " (non cambia mai)."
        else:
            if n.nome not in self.variabili:
                self.variabili.append(n.nome)
            if isinstance(valore, N.Letterale) and not isinstance(valore.valore, str):
                frase = f"Crea la variabile {n.nome} e le dà il valore {self.e(valore)}."
            else:
                frase = f"Crea la variabile {n.nome} e ci mette dentro {self.e(valore)}."
        if isinstance(valore, N.Chiamata) and isinstance(valore.funzione, N.Nome) and valore.funzione.nome == "chiedi":
            note.append("`chiedi` aspetta che chi usa il programma scriva qualcosa e prema Invio.")
        if isinstance(valore, N.Binaria) and valore.operatore == "/":
            note.append("`/` dà sempre un numero decimale; `//` invece dà la divisione intera.")
        self.scrivi(p, frase, n, tuple(note))

    def _Assegnazione(self, n: Any, p: int) -> None:
        bersaglio = self.e(n.bersaglio)
        valore = self.e(n.valore)
        op = n.operatore
        note: tuple[str, ...] = ()
        if op == "+=":
            if isinstance(n.valore, N.Letterale) and n.valore.valore == 1:
                frase = f"Aumenta {bersaglio} di 1."
            else:
                frase = f"Aggiunge {valore} a {bersaglio}."
            note = (f"`{codice_espressione(n.bersaglio)} += ...` è una scorciatoia per "
                    f"`{codice_espressione(n.bersaglio)} = {codice_espressione(n.bersaglio)} + ...`.",)
        elif op == "-=":
            if isinstance(n.valore, N.Letterale) and n.valore.valore == 1:
                frase = f"Diminuisce {bersaglio} di 1."
            else:
                frase = f"Toglie {valore} da {bersaglio}."
        elif op == "*=":
            frase = f"Moltiplica {bersaglio} per {valore}."
        elif op == "/=":
            frase = f"Divide {bersaglio} per {valore}."
        else:
            if isinstance(n.bersaglio, N.Attributo):
                frase = f"Cambia {bersaglio}: ora è {valore}."
            else:
                frase = f"Cambia {bersaglio}: adesso vale {valore}."
        if isinstance(n.bersaglio, N.Indice) and not self.semplice:
            note = note + ("Le posizioni delle liste partono da 0: il primo elemento è in posizione 0.",)
        self.scrivi(p, frase, n, note)

    def _Se(self, n: Any, p: int) -> None:
        self.decisioni += 1
        for i, ramo in enumerate(n.rami):
            condizione = self.e(ramo.condizione)
            if i == 0:
                frase = f"Controlla se {condizione}. Se è così:"
            else:
                frase = f"Altrimenti, se {condizione}:"
            self.scrivi(p, frase, ramo if i else n)
            self.blocco(ramo.corpo, p + 1)
        if n.altrimenti is not None:
            self.scrivi(p, "Altrimenti (in tutti gli altri casi):")
            self.blocco(n.altrimenti, p + 1)

    def _DefinizioneStruttura(self, n: Any, p: int) -> None:
        campi = [c.nome for c in n.campi]
        frase = f"Definisce la struttura {n.nome}" + (f", con i campi {_elenco(campi)}." if campi else ".")
        self.scrivi(p, frase, n, ("Una struttura raccoglie dati che vanno insieme: "
                                  f"`{n.nome}(...)` ne crea uno nuovo.",))
        for m in n.metodi:
            self.scrivi(p + 1, f"Ha il metodo {m.nome} (dentro, `questo` è il valore prima del punto).", m)

    def _DefinizioneTipo(self, n: Any, p: int) -> None:
        self.scrivi(p, f"Definisce il tipo {n.nome}, che può essere {_elenco([v.nome for v in n.varianti])}.", n)

    def _Mentre(self, n: Any, p: int) -> None:
        self.cicli += 1
        if getattr(n, "per_sempre", False):
            self.scrivi(p, "Ripete per sempre queste istruzioni (si esce con `interrompi`):", n)
            self.blocco(n.corpo, p + 1)
            return
        self.scrivi(p, f"Finché {self.e(n.condizione)}, ripete queste istruzioni:", n,
                    ("Se la condizione resta sempre vera, il ciclo non finisce mai: "
                     "dentro qualcosa deve cambiare.",))
        self.blocco(n.corpo, p + 1)

    def _PerOgni(self, n: Any, p: int) -> None:
        self.cicli += 1
        it = n.iterabile
        note: tuple[str, ...] = ()
        if isinstance(it, N.Intervallo):
            frase = f"Conta con {n.variabile} da {self.e(it.inizio)} a {self.e(it.fine)} e ogni volta:"
            note = ("Un intervallo `a..b` comprende anche l'ultimo numero.",)
        elif isinstance(it, N.Nome):
            frase = f"Per ogni {n.variabile} in {it.nome}, uno alla volta:"
        else:
            frase = f"Per ogni {n.variabile} in {self.e(it)}, uno alla volta:"
        self.scrivi(p, frase, n, note)
        self.blocco(n.corpo, p + 1)

    def _Ripeti(self, n: Any, p: int) -> None:
        self.cicli += 1
        volte = self.e(n.volte)
        if isinstance(n.volte, N.Letterale) and n.volte.valore == 1:
            frase = "Fa una volta sola:"
        else:
            frase = f"Ripete {volte} volte:"
        self.scrivi(p, frase, n)
        self.blocco(n.corpo, p + 1)

    def _DefinizioneFunzione(self, n: Any, p: int) -> None:
        self.funzioni.append(n.nome)
        nomi = [q.nome for q in n.parametri]
        if nomi:
            riceve = "riceve " + _elenco(nomi)
        else:
            riceve = "non riceve niente"
        if self.semplice:
            frase = f"Definisce una nuova funzione, {n.nome}, che {riceve}. Quando la usi:"
        else:
            frase = f"Definisce la funzione {n.nome}, che {riceve}. Quando viene chiamata:"
        predefiniti = [q.nome for q in n.parametri if q.predefinito is not None]
        note = ()
        if predefiniti:
            note = ("I parametri con `=` hanno un valore predefinito: si possono non passare.",)
        self.scrivi(p, frase, n, note + ("Il corpo della funzione non viene eseguito adesso, "
                                         "ma solo quando qualcuno la chiama.",))
        self.blocco(n.corpo, p + 1)

    def _Restituisci(self, n: Any, p: int) -> None:
        if n.valore is None:
            self.scrivi(p, "Esce dalla funzione.", n)
        else:
            self.scrivi(p, f"Dà come risultato {self.e(n.valore)} (e la funzione finisce qui).", n)

    def _Interrompi(self, n: Any, p: int) -> None:
        self.scrivi(p, "Esce subito dal ciclo.", n)

    def _Continua(self, n: Any, p: int) -> None:
        self.scrivi(p, "Salta al giro successivo del ciclo.", n)

    def _Prova(self, n: Any, p: int) -> None:
        self.scrivi(p, "Prova a fare queste istruzioni:", n,
                    ("Se qualcosa va storto dentro `prova`, il programma non si ferma: passa a `cattura`.",))
        self.blocco(n.corpo, p + 1)
        for c in n.catture:
            tipo = f"un errore di tipo {c.tipo_errore}" if c.tipo_errore else "un errore"
            nome = f" (lo chiama {c.nome_variabile})" if c.nome_variabile else ""
            self.scrivi(p, f"Se succede {tipo}{nome}:", c)
            self.blocco(c.corpo, p + 1)
        if n.infine is not None:
            self.scrivi(p, "Alla fine, in ogni caso:")
            self.blocco(n.infine, p + 1)

    def _Lancia(self, n: Any, p: int) -> None:
        self.scrivi(p, f"Segnala un errore: {self.e(n.valore)}.", n)

    def _Evento(self, n: Any, p: int) -> None:
        self.scrivi(p, f"Quando succede «{n.evento}» su {n.controllo}, fa questo:", n,
                    ("Le istruzioni di un evento partono solo quando l'evento succede (per esempio un clic).",))
        self.blocco(n.corpo, p + 1)

    def _Temporizzatore(self, n: Any, p: int) -> None:
        durata = self.e(n.durata)
        unita = n.unita
        if isinstance(n.durata, N.Letterale) and n.durata.valore == 1:
            quanto = {"secondi": "secondo", "s": "secondo", "millisecondi": "millisecondo", "ms": "millisecondo",
                      "minuti": "minuto"}.get(unita, unita)
            tempo = f"1 {quanto}"
        else:
            quanto = {"secondo": "secondi", "s": "secondi", "millisecondo": "millisecondi", "ms": "millisecondi",
                      "minuto": "minuti"}.get(unita, unita)
            tempo = f"{durata} {quanto}"
        if n.ripeti:
            frase = f"Avvia un temporizzatore: ogni {tempo}, finché il programma è vivo, fa questo:"
            note = ("Un programma con un temporizzatore `ogni` resta acceso finché non lo fermi "
                    "(Ctrl+C, oppure `ferma_temporizzatori()`).",)
        else:
            frase = f"Avvia un temporizzatore: tra {tempo} (una volta sola) farà questo:"
            note = ("Il programma intanto va avanti: il blocco di `dopo` parte più tardi.",)
        self.scrivi(p, frase, n, note)
        self.blocco(n.corpo, p + 1)

    def _BloccoVerifica(self, n: Any, p: int) -> None:
        nome = (f"«{n.nome.valore}»" if isinstance(n.nome, N.Letterale) and isinstance(n.nome.valore, str)
                else self.e(n.nome))
        self.scrivi(p, f"Prepara la verifica {nome} (parte solo con `leo verifica`):", n,
                    ("Le verifiche non partono quando esegui il programma: le esegue `leo verifica programma.leo`.",))
        self.blocco(n.corpo, p + 1)

    def _Aspettati(self, n: Any, p: int) -> None:
        self.scrivi(p, f"Si aspetta questo: {self.e(n.condizione)}.", n)

    def _AspettatiErrore(self, n: Any, p: int) -> None:
        tipo = f"un errore {n.tipo_errore}" if n.tipo_errore else "un errore"
        self.scrivi(p, f"Si aspetta che queste istruzioni diano {tipo}:", n)
        self.blocco(n.corpo, p + 1)

    def _parallelo(self, e: Any, p: int, n: Any, nome: str | None = None) -> None:
        chi = f" (il lavoro si chiama {nome})" if nome else ""
        self.scrivi(p, f"Fa partire un lavoro in parallelo{chi}: mentre il programma va avanti, fa questo:", n,
                    ("Il risultato del lavoro (quello di `restituisci`) si raccoglie con `aspetta(lavoro)`.",))
        self.blocco(e.corpo, p + 1)

    def _IstruzioneEspressione(self, n: Any, p: int) -> None:
        e = n.espressione
        if isinstance(e, N.Parallelo):
            self._parallelo(e, p, n)
            return
        if isinstance(e, N.Chiamata):
            args = _argomenti(e.argomenti, self.semplice)
            if isinstance(e.funzione, N.Nome):
                nome = e.funzione.nome
                if nome == "anima" and nome not in self.funzioni:
                    frase = self._anima(e)
                    if frase is not None:
                        self.scrivi(p, frase, n)
                        return
                modello = _AZIONI_NOTE.get(nome)
                if nome == "stampa" and self.semplice:
                    modello = "Mostra sullo schermo {tutti}"
                testo = _riempi(modello, args) if modello else None
                if nome == "stampa" and (not args or (len(e.argomenti) == 1 and isinstance(
                        e.argomenti[0].valore, N.Letterale) and e.argomenti[0].valore.valore == "")):
                    testo = "Va a capo (scrive una riga vuota)"
                if testo is None:
                    if nome in self.funzioni:
                        testo = f"Usa la funzione {nome}" + (f" con {_elenco(args)}" if args else "")
                    else:
                        testo = f"Chiama {nome}" + (f" con {_elenco(args)}" if args else "")
                self.scrivi(p, testo + ".", n)
                return
            if isinstance(e.funzione, N.Attributo):
                ogg = self.e(e.funzione.oggetto)
                modello = _METODI_NOTI.get(e.funzione.nome)
                testo = _riempi(modello, args, ogg=ogg) if modello else None
                if testo is None:
                    testo = f"Usa {e.funzione.nome} su {ogg}" + (f" con {_elenco(args)}" if args else "")
                self.scrivi(p, testo + ".", n)
                return
        self.scrivi(p, f"Calcola il valore di {self.e(e)}.", n)

    def _anima(self, e: Any) -> str | None:
        """``anima P.alto a 10 in 1 secondi`` (cioe' ``anima(P, "alto", 10, 1)``) a parole."""
        valori = [a.valore for a in e.argomenti if a.nome is None and not a.espandi]
        if len(valori) < 3 or not (isinstance(valori[1], N.Letterale) and isinstance(valori[1].valore, str)):
            return None
        frase = (f"Anima {self.e(valori[0])}: porta pian piano la proprietà {valori[1].valore} "
                 f"a {self.e(valori[2])}")
        if len(valori) >= 4:
            durata = valori[3]
            if (isinstance(durata, N.Binaria) and durata.operatore == "/"
                    and isinstance(durata.destra, N.Letterale) and durata.destra.valore == 1000):
                frase += f" in {self.e(durata.sinistra)} millisecondi"
            elif isinstance(durata, N.Letterale) and durata.valore == 1:
                frase += " in 1 secondo"
            else:
                frase += f" in {self.e(durata)} secondi"
        if len(valori) >= 5:
            curva = valori[4]
            nome_curva = (f'"{curva.valore}"' if isinstance(curva, N.Letterale) and isinstance(curva.valore, str)
                          else self.e(curva))
            frase += f", con la curva {nome_curva}"
        return frase + "."

    # --- riepilogo ---
    def riepilogo(self) -> list[str]:
        righe: list[str] = []
        if self.variabili:
            righe.append("Variabili create: " + ", ".join(self.variabili) + ".")
        if self.costanti:
            righe.append("Costanti: " + ", ".join(self.costanti) + ".")
        if self.funzioni:
            righe.append("Funzioni nuove: " + ", ".join(self.funzioni) + ".")
        righe.append(f"Cicli: {self.cicli}. Decisioni (`se`): {self.decisioni}.")
        return righe


def spiega_programma(programma: Any, *, livello: str = "normale", sorgente: str | None = None,
                     titolo: str | None = None) -> str:
    """Racconta un :class:`leo.nodi.Programma` gia' analizzato."""
    righe_sorgente = None
    if sorgente is not None:
        righe_sorgente = sorgente.lstrip("\ufeff").replace("\r\n", "\n").replace("\r", "\n").split("\n")
    narratore = _Narratore(livello, righe_sorgente)
    istruzioni = list(getattr(programma, "istruzioni", []) or [])
    nome = titolo
    if nome is None:
        nome_file = getattr(programma, "nome_file", "") or ""
        nome = "il programma" if nome_file in ("", "<sorgente>") else nome_file
    if not istruzioni:
        return f"{nome[0].upper() + nome[1:]} è vuoto: non fa niente."
    intestazione = f"Ecco cosa fa {nome}:"
    blocco_inizio = getattr(programma, "blocco_inizio", None)
    try:
        riga_inizio, indice_inizio = blocco_inizio if blocco_inizio else (0, None)
        indice_inizio = int(indice_inizio) if indice_inizio is not None else None
    except (TypeError, ValueError):
        riga_inizio, indice_inizio = 0, None
    if indice_inizio is None or not 0 <= indice_inizio <= len(istruzioni):
        for istruzione in istruzioni:
            narratore.istruzione(istruzione, 0)
    else:
        # `inizio ... fine`: prima si prepara tutto (funzioni, variabili, `quando`),
        # poi parte il programma principale
        for istruzione in istruzioni[:indice_inizio]:
            narratore.istruzione(istruzione, 0)
        if narratore.semplice:
            frase = "Poi parte il programma principale (il blocco `inizio`):"
        else:
            frase = ("Poi parte il programma principale (il blocco `inizio`), quando funzioni, variabili "
                     "e gestori sono già pronti, anche quelli scritti dopo il blocco:")
        nodo = N.Nodo(riga=int(riga_inizio or 0))
        narratore.scrivi(0, frase, nodo if riga_inizio else None)
        narratore.blocco(istruzioni[indice_inizio:], 1)
    parti = [intestazione, ""] + narratore.uscita
    if narratore.dettagli:
        parti += ["", "Riepilogo:"] + ["  " + r for r in narratore.riepilogo()]
    elif narratore.semplice:
        parti += ["", "Fine del programma."]
    return "\n".join(parti)


def spiega_sorgente(sorgente: str, nome_file: str = "<sorgente>", *, livello: str = "normale",
                    rigoroso: bool = False, **opzioni: Any) -> str:
    """Analizza ``sorgente`` e lo racconta. Solleva ``ErroreDante`` se il codice ha errori."""
    from .esecuzione import analizza

    programma = analizza(sorgente, nome_file, rigoroso=rigoroso, **opzioni)
    return spiega_programma(programma, livello=livello, sorgente=sorgente)
