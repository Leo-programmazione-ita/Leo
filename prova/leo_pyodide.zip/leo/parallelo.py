"""Parallelismo vero e sicuro di Leo: lavori isolati, canali, attese, annullamento.

Il modello (vedi docs/PARALLELISMO.md):

* **Lavori isolati.** ``in parallelo fai ... fine`` fa partire un *lavoro*. Il
  lavoro riceve, nel momento in cui parte, una **copia** delle variabili del
  programma che usa (anche quelle usate dalle funzioni che chiama, a qualunque
  profondita'): le legge liberamente, ma non le puo' cambiare. Chi ci prova ha
  un errore chiaro, prima di eseguire quando si vede dal testo (lo controlla
  :mod:`leo.parallelo_controllo`) oppure appena succede. Due lavori non
  toccano mai gli stessi dati: niente corse fra fili, niente blocchi da
  mettere a mano. I risultati tornano con ``restituisci`` e ``aspetta``; i
  messaggi passano con i **canali** (``canale()``, ``invia``, ``ricevi``,
  ``chiudi``, ``per ogni messaggio in canale``).
* **Piu' processori per davvero.** Poiche' il lavoro e' isolato, puo' girare
  in un altro *processo* (un Python tutto suo, con il suo GIL): lo fa
  :mod:`leo.parallelo_processi`, con lavoratori tenuti pronti e riusati. Se i
  processi non ci sono (Android, ``LEO_PARALLELO=fili``) o il lavoro usa
  qualcosa che non si puo' copiare in un altro processo (un file aperto, un
  altro lavoro) gira in un *filo* dello stesso processo, con la stessa identica
  semantica: sempre isolato. Con un Python senza GIL anche i fili lavorano
  insieme.
* **Attese e annullamento.** ``aspetta(lavoro, secondi)``,
  ``aspetta_tutti(lavori)``, ``aspetta_il_primo(lavori)``,
  ``ricevi_dal_primo(canali)``, ``annulla(lavoro)``: niente ``async``/``await``,
  nessuna funzione "colorata": qualunque funzione si puo' chiamare da un
  lavoro e qualunque lavoro si puo' aspettare da qualunque punto.

Questo modulo contiene il motore comune (analisi dei nomi, isolamento, lavori
nei fili, canali, attese); i processi sono in :mod:`leo.parallelo_processi`, le
funzioni Leo in :mod:`leo.libreria.parallelismo` (e ``aspetta`` in
:mod:`leo.potenza`).
"""

from __future__ import annotations

import collections
import copy
import itertools
import os
import sys
import threading
import time
import weakref
from typing import Any, Callable, Iterable, Iterator

from .ambiente import Ambiente, Voce
from .errori import (ErroreDante, ErroreNome, ErroreRicorsione, ErroreTipo, ErroreValore,
                     SegnaleFermaProgramma)
from .nodi import Nodo, Nome
from .valori import (FunzioneDante, FunzioneNativa, MetodoLegato, Modulo, OggettoControllo, Richiamabile,
                     nome_tipo, rappresenta, tipo_con_articolo)

__all__ = [
    "Lavoro", "Canale", "avvia_lavoro", "lavori_in_corso", "errore_non_raccolto", "ferma_lavori",
    "aspetta", "aspetta_tutti", "aspetta_il_primo", "ricevi_dal_primo", "annulla",
    "nomi_usati", "Isolatore", "AmbienteIsolato", "modo_richiesto", "informazioni",
]

#: Variabile d'ambiente che sceglie come girano i lavori: ``automatico`` (predefinito),
#: ``processi`` o ``fili``.
VARIABILE_MODO = "LEO_PARALLELO"
#: Pila dei fili dei lavori (le chiamate annidate dell'interprete sono profonde).
DIMENSIONE_PILA_LAVORO = 64 * 1024 * 1024
#: Ogni quanto chi aspetta controlla se il programma e' stato fermato.
PASSO_ATTESA = 0.05

_CONSIGLIO_RISULTATO = ("Fai restituire il risultato al lavoro (`restituisci ...`) e usalo nel programma "
                        "principale dopo `aspetta(lavoro)`, oppure mandalo con un canale.")


def modo_richiesto() -> str:
    """``"fili"``, ``"processi"`` o ``"automatico"`` (da ``LEO_PARALLELO``)."""
    valore = os.environ.get(VARIABILE_MODO, "").strip().lower()
    if valore in ("fili", "filo", "thread", "threads", "0", "no", "uno"):
        return "fili"
    if valore in ("processi", "processo", "process", "processes", "si", "sì", "1"):
        return "processi"
    return "automatico"


def gil_attivo() -> bool:
    """Falso solo con un Python "senza GIL" (3.13t e successivi): li' i fili lavorano davvero insieme."""
    controlla = getattr(sys, "_is_gil_enabled", None)
    try:
        return bool(controlla()) if callable(controlla) else True
    except Exception:  # noqa: BLE001
        return True


def processori() -> int:
    """Quanti processori puo' usare questo programma."""
    try:
        return max(1, len(os.sched_getaffinity(0)))       # type: ignore[attr-defined]
    except (AttributeError, OSError):
        return max(1, os.cpu_count() or 1)


# ===========================================================================
# Analisi: quali nomi usa un pezzo di programma
# ===========================================================================

_NOMI_CACHE: dict[int, tuple[Any, frozenset[str]]] = {}
_BLOCCO_CACHE = threading.Lock()


def nomi_usati(nodi: Any) -> frozenset[str]:
    """Tutti i nomi (``Nome``) scritti in ``nodi`` (un nodo, una lista di nodi), anche
    dentro le funzioni annidate. E' piu' di quanto serve (anche i nomi locali), mai meno:
    l'isolamento copia solo quelli che esistono fuori."""
    chiave = id(nodi)
    trovato = _NOMI_CACHE.get(chiave)
    if trovato is not None and trovato[0] is nodi:
        return trovato[1]
    nomi: set[str] = set()
    pila = [nodi]
    visti: set[int] = set()
    while pila:
        x = pila.pop()
        if isinstance(x, Nodo):
            if id(x) in visti:
                continue
            visti.add(id(x))
            if type(x) is Nome:
                nomi.add(x.nome)
                continue
            for valore in vars(x).values():
                if isinstance(valore, (Nodo, list, tuple)):
                    pila.append(valore)
        elif isinstance(x, (list, tuple)):
            for valore in x:
                if isinstance(valore, (Nodo, list, tuple)):
                    pila.append(valore)
    risultato = frozenset(nomi)
    with _BLOCCO_CACHE:
        if len(_NOMI_CACHE) > 20_000:
            _NOMI_CACHE.clear()
        _NOMI_CACHE[chiave] = (nodi, risultato)
    return risultato


def nomi_della_funzione(f: FunzioneDante) -> frozenset[str]:
    """I nomi usati dal corpo e dai valori predefiniti dei parametri di ``f``."""
    corpo = nomi_usati(f.corpo)
    predefiniti = [p.predefinito for p in (f.parametri or ()) if getattr(p, "predefinito", None) is not None]
    return corpo | nomi_usati(predefiniti) if predefiniti else corpo


# ===========================================================================
# Isolamento: la copia del mondo che vede un lavoro
# ===========================================================================

class AmbienteIsolato(Ambiente):
    """Copia, in sola lettura, di un ambiente del programma vista da un lavoro.

    Le voci sono tutte costanti per l'interprete (cosi' le vie veloci, anche
    quelle compilate, passano da :meth:`assegna`), che le rifiuta con un
    messaggio che spiega il perche'. Gli ambienti figli (corpo del lavoro,
    chiamate di funzione) sono ambienti normali: le variabili del lavoro si
    dichiarano e si cambiano liberamente."""

    def __init__(self, genitore: Ambiente | None = None, *, nome: str = "") -> None:
        super().__init__(genitore, nome=nome)
        self.costanti_vere: set[str] = set()

    def figlio(self, nome: str = "") -> Ambiente:
        return Ambiente(self, nome=nome)

    def assegna(self, nome: str, valore: Any) -> None:
        if nome in self.voci and nome not in self.costanti_vere and not isinstance(
                self.voci[nome].valore, (Richiamabile, ControlloVietato)):
            raise ErroreValore(
                f"Un lavoro `in parallelo` non può cambiare `{nome}`: è una variabile del programma "
                "e il lavoro ne ha solo una copia.",
                suggerimento=(f"Dentro il lavoro usa una variabile sua (`variabile {nome}_lavoro = {nome}`), "
                              "poi " + _CONSIGLIO_RISULTATO[0].lower() + _CONSIGLIO_RISULTATO[1:]))
        super().assegna(nome, valore)

    def dichiara(self, nome: str, valore: Any, *, costante: bool = False, riga: int = 0,
                 implicito: bool = False) -> None:
        super().dichiara(nome, valore, costante=True, riga=riga, implicito=implicito)
        if costante:
            self.costanti_vere.add(nome)


class ControlloVietato(OggettoControllo):
    """Al posto di un controllo grafico nella copia di un lavoro: usarlo e' un errore chiaro
    (Qt vuole che l'interfaccia si tocchi solo dal programma principale)."""

    E_VALORE_LIBRERIA = False

    def __init__(self, nome: str, tipo: str = "controllo") -> None:
        self.nome = nome
        self.tipo_controllo = tipo

    def _errore(self) -> ErroreValore:
        return ErroreValore(
            f"Da un lavoro `in parallelo` non si può usare `{self.nome}`: i controlli grafici si "
            "toccano solo dal programma principale.",
            suggerimento="Fai restituire il risultato al lavoro (`restituisci ...`) e scrivilo nel "
                         "controllo dopo `aspetta(lavoro)`, oppure controlla `lavoro.finito()` con "
                         "un temporizzatore `ogni` (o manda i dati con un canale).")

    def leggi(self, proprieta: str) -> Any:
        raise self._errore()

    def scrivi(self, proprieta: str, valore: Any) -> None:
        raise self._errore()

    def metodo(self, nome: str) -> Any:
        raise self._errore()

    def elenco_proprieta(self) -> list[str]:
        return []

    def elenco_metodi(self) -> list[str]:
        return []

    def testo_dante(self) -> str:
        return f"<{self.tipo_controllo} {self.nome}>"


#: Tipi che non cambiano mai: si passano cosi' come sono.
_IMMUTABILI = (int, float, str, bool, type(None), range, bytes, complex, frozenset)


class Isolatore:
    """Costruisce la copia isolata del mondo per un lavoro.

    Per ogni ambiente del programma raggiunto (quello in cui nasce il lavoro e
    le chiusure delle funzioni che usa) crea un :class:`AmbienteIsolato` con i
    soli nomi che servono, copiati in profondita' (liste e dizionari nuovi,
    funzioni richiuse sulla copia). Gli oggetti fatti per essere condivisi
    (canali, lavori) restano gli stessi; i controlli grafici diventano un
    :class:`ControlloVietato`. Il predefinito (la libreria, l'ambiente senza
    genitore) e' condiviso: e' di sola lettura."""

    def __init__(self, copia: bool = True) -> None:
        #: Falso per i processi: liste, dizionari e altri dati non si copiano qui (li copia ``pickle``
        #: subito dopo); si rifanno solo i contenitori con dentro funzioni o controlli.
        self.copia = copia
        self._puliti: set[int] = set()
        self._ambienti: dict[int, tuple[Ambiente, AmbienteIsolato]] = {}
        self._valori: dict[int, tuple[Any, Any]] = {}
        self._sopra: dict[int, tuple[Ambiente, AmbienteIsolato]] = {}
        #: Oggetti condivisi per riferimento (non copiabili in profondita'): il lavoro li usa cosi' come sono.
        self.condivisi: list[Any] = []

    # --- ambienti ---
    def sopra_predefinito(self, radice: Ambiente | None) -> Ambiente:
        """L'ambiente appena sopra il predefinito ``radice`` (l'ambiente senza genitore, la
        libreria): ci finiscono i controlli vietati."""
        if radice is None:
            radice = Ambiente(nome="predefinito vuoto")
        trovato = self._sopra.get(id(radice))
        if trovato is None:
            trovato = (radice, AmbienteIsolato(radice, nome="predefinito (copia)"))
            self._sopra[id(radice)] = trovato
        return trovato[1]

    @staticmethod
    def _radice(amb: Ambiente | None) -> Ambiente | None:
        while amb is not None and amb.genitore is not None:
            amb = amb.genitore
        return amb

    def ambiente(self, originale: Ambiente | None) -> Ambiente:
        if originale is None or originale.genitore is None:
            return self.sopra_predefinito(originale)
        trovato = self._ambienti.get(id(originale))
        if trovato is not None:
            return trovato[1]
        copia = AmbienteIsolato(None, nome=originale.nome)
        self._ambienti[id(originale)] = (originale, copia)
        copia.genitore = self.ambiente(originale.genitore)
        return copia

    def aggiungi_nome(self, partenza: Ambiente | None, nome: str) -> None:
        """Copia nella copia giusta il valore che ``nome`` ha visto da ``partenza``."""
        amb = partenza
        voce = None
        while amb is not None:
            voce = amb.voci.get(nome)
            if voce is not None:
                break
            amb = amb.genitore
        if voce is None or amb is None:
            return
        if amb.genitore is None:
            valore = voce.valore
            if isinstance(valore, OggettoControllo) and not getattr(valore, "E_VALORE_LIBRERIA", False):
                sopra = self.sopra_predefinito(amb)
                if nome not in sopra.voci:
                    sopra.voci[nome] = Voce(ControlloVietato(nome, getattr(valore, "tipo_controllo", "controllo")),
                                            True, voce.riga)
            return
        copia = self.ambiente(amb)
        if nome in copia.voci:
            return
        nuova = Voce(None, True, voce.riga, voce.implicito)
        copia.voci[nome] = nuova
        if voce.costante:
            copia.costanti_vere.add(nome)
        valore = voce.valore
        if isinstance(valore, OggettoControllo) and not getattr(valore, "E_VALORE_LIBRERIA", False):
            nuova.valore = ControlloVietato(nome, getattr(valore, "tipo_controllo", "controllo"))
        else:
            nuova.valore = self.valore(valore)

    # --- valori ---
    def valore(self, v: Any) -> Any:
        tipo = type(v)
        if tipo in _IMMUTABILI:
            return v
        trovato = self._valori.get(id(v))
        if trovato is not None:
            return trovato[1]
        if (tipo is list or tipo is dict) and not self.copia and self._solo_dati(v):
            self._valori[id(v)] = (v, v)
            return v
        if tipo is list:
            nuova: list = []
            self._valori[id(v)] = (v, nuova)
            nuova.extend([self.valore(x) for x in v])
            return nuova
        if tipo is dict:
            nuovo: dict = {}
            self._valori[id(v)] = (v, nuovo)
            for k, x in list(v.items()):
                nuovo[k] = self.valore(x)
            return nuovo
        if isinstance(v, FunzioneDante):
            return self.funzione(v)
        if isinstance(v, MetodoLegato):
            oggetto = self.valore(v.oggetto)
            copia = MetodoLegato(oggetto, v.metodo) if oggetto is not v.oggetto else v
            self._valori[id(v)] = (v, copia)
            return copia
        if isinstance(v, (Richiamabile, ErroreDante)) or getattr(v, "CONDIVISO_TRA_LAVORI", False):
            self._valori[id(v)] = (v, v)
            return v
        if isinstance(v, Modulo):
            return self._modulo(v)
        if isinstance(v, OggettoControllo) and not getattr(v, "E_VALORE_LIBRERIA", False):
            copia = ControlloVietato(getattr(v, "nome", "controllo"), getattr(v, "tipo_controllo", "controllo"))
            self._valori[id(v)] = (v, copia)
            return copia
        if not self.copia:
            self._valori[id(v)] = (v, v)          # lo copiera' pickle (o non passa: allora filo)
            return v
        try:
            copia = copy.deepcopy(v)
        except Exception:  # noqa: BLE001 - risorse del sistema (file aperti, connessioni): si condividono
            copia = v
            self.condivisi.append(v)
        self._valori[id(v)] = (v, copia)
        return copia

    def _solo_dati(self, radice: Any) -> bool:
        """Vero se ``radice`` (lista o dizionario) contiene solo dati: niente funzioni, controlli,
        oggetti (che vanno rifatti per la copia)."""
        puliti = self._puliti
        pila = [radice]
        visti: set[int] = set()
        while pila:
            x = pila.pop()
            if id(x) in puliti or id(x) in visti:
                continue
            visti.add(id(x))
            tipo = type(x)
            if tipo is list:
                elementi: Iterable = x
            elif tipo is dict:
                elementi = x.values()
            else:
                return False
            for y in elementi:
                if type(y) not in _IMMUTABILI:
                    pila.append(y)
        puliti.update(visti)
        return True

    def funzione(self, f: FunzioneDante) -> FunzioneDante:
        trovato = self._valori.get(id(f))
        if trovato is not None:
            return trovato[1]
        g = FunzioneDante(f.nome, f.parametri, f.corpo, None, f.riga, f.colonna)  # type: ignore[arg-type]
        self._valori[id(f)] = (f, g)
        for chiave, valore in f.__dict__.items():
            if chiave not in ("nome", "parametri", "corpo", "chiusura", "riga", "colonna") \
                    and not chiave.startswith("_"):
                setattr(g, chiave, valore)
        g.chiusura = self.ambiente(f.chiusura)
        for nome in nomi_della_funzione(f):
            self.aggiungi_nome(f.chiusura, nome)
        return g

    def _modulo(self, m: Modulo) -> Modulo:
        ambiente = getattr(m, "_ambiente", None)
        if ambiente is None:
            copia = Modulo(m.nome, {k: self.valore(x) for k, x in m.voci.items()})
            self._valori[id(m)] = (m, copia)
            return copia
        copia = Modulo(m.nome, {}, ambiente=self.ambiente(ambiente))
        self._valori[id(m)] = (m, copia)
        for nome in list(ambiente.voci):
            self.aggiungi_nome(ambiente, nome)
        return copia


class Mondo:
    """La copia isolata pronta per un lavoro: la funzione da chiamare e l'ambiente globale."""

    def __init__(self, funzione: FunzioneDante, globale: Ambiente, condivisi: list) -> None:
        self.funzione = funzione
        self.globale = globale
        self.condivisi = condivisi


def isola(interprete: Any, funzione: FunzioneDante, copia: bool = True) -> Mondo:
    """Copia del mondo vista da ``funzione`` (nel momento in cui il lavoro parte). Con
    ``copia=False`` i dati restano quelli del programma: va impacchettata subito."""
    isolatore = Isolatore(copia)
    f = isolatore.funzione(funzione)
    globale = isolatore.ambiente(interprete.globale)
    return Mondo(f, globale, isolatore.condivisi)


# ===========================================================================
# L'interprete di un lavoro
# ===========================================================================

class _PonteParallelo:
    """Ponte grafico visto da un lavoro: niente finestre ne' dialoghi."""

    def __init__(self, ponte: Any = None) -> None:
        self._ponte = ponte

    @staticmethod
    def _vietato(cosa: str) -> ErroreValore:
        return ErroreValore(f"Da un lavoro `in parallelo` non si può {cosa}.", suggerimento=_CONSIGLIO_RISULTATO)

    def messaggio(self, testo: str, titolo: str = "Leo") -> None:
        raise self._vietato("mostrare un messaggio")

    def domanda(self, testo: str, titolo: str = "Leo") -> bool:
        raise self._vietato("fare una domanda con una finestrella")

    def apri_finestra(self, nome: str) -> None:
        raise self._vietato("aprire una finestra")

    def chiudi_finestra(self, nome: str) -> None:
        raise self._vietato("chiudere una finestra")

    def attendi(self, secondi: float) -> None:
        fine = time.monotonic() + max(0.0, float(secondi))
        while True:
            resta = fine - time.monotonic()
            if resta <= 0:
                return
            interprete = getattr(_QUI, "interprete", None)
            if interprete is not None and interprete.fermato:
                raise SegnaleFermaProgramma()
            time.sleep(min(resta, PASSO_ATTESA))

    def __getattr__(self, nome: str) -> Any:
        raise AttributeError(nome)


def _ingresso_vietato(domanda: str) -> str:
    raise ErroreValore("Da un lavoro `in parallelo` non si può usare `chiedi`: i lavori non leggono dalla "
                       "tastiera.", suggerimento="Chiedi i dati prima di avviare il lavoro (il lavoro li vede), "
                                                 "oppure mandaglieli con un canale.")


_CLASSE_INTERPRETE: list = []


def classe_interprete_lavoro() -> type:
    """La classe dell'interprete dei lavori (creata al primo uso: importa l'interprete)."""
    if _CLASSE_INTERPRETE:
        return _CLASSE_INTERPRETE[0]
    from .interprete import Interprete

    class InterpreteParallelo(Interprete):
        """Interprete di un lavoro: lavora sulla copia isolata del mondo."""

        def visita_Temporizzatore(self, nodo, ambiente):  # noqa: D102
            raise ErroreValore("Dentro un lavoro `in parallelo` non si avviano temporizzatori.",
                               suggerimento="Scrivi `ogni`/`dopo` nel programma principale.")

        @property
        def temporizzatori(self):  # noqa: D102
            raise ErroreValore("Dentro un lavoro `in parallelo` non si avviano temporizzatori.",
                               suggerimento="Scrivi `ogni`/`dopo` nel programma principale.")

    _CLASSE_INTERPRETE.append(InterpreteParallelo)
    return InterpreteParallelo


#: Uscita condivisa dai lavori: una `stampa` alla volta, mai mescolate a meta'.
BLOCCO_USCITA = threading.RLock()

#: Dati del filo corrente: ``interprete`` (quello del lavoro che gira qui).
_QUI = threading.local()


def interprete_del_filo(riserva: Any = None) -> Any:
    """L'interprete del lavoro che gira in questo filo (o ``riserva``)."""
    return getattr(_QUI, "interprete", None) or riserva


def crea_interprete_lavoro(*, predefinito: Ambiente, globale: Ambiente, uscita: Callable[[str], None],
                           nome_file: str, sorgente: str = "", dichiarazione_implicita: bool = False,
                           profondita_massima: int = 1000, con_grafica: bool = False, tollerante: bool = True,
                           percorsi_moduli: Iterable[str] = (), file_corrente: str | None = None) -> Any:
    """Un interprete per un lavoro (nei fili e nei processi lavoratori)."""
    classe = classe_interprete_lavoro()

    def scrivi(testo: str) -> None:
        with BLOCCO_USCITA:
            uscita(testo)

    figlio = classe(nome_file=nome_file, sorgente=sorgente, uscita=scrivi, ingresso=_ingresso_vietato,
                    dichiarazione_implicita=dichiarazione_implicita, profondita_massima=profondita_massima,
                    ambiente_predefinito=predefinito, ponte_grafico=_PonteParallelo() if con_grafica else None)
    figlio.globale = globale
    figlio.tollerante = tollerante
    figlio.percorsi_moduli = list(percorsi_moduli)
    if file_corrente:
        figlio._file_corrente = file_corrente
    figlio._aggiorna_veloce()
    return figlio


def esegui_nel_filo(interprete: Any, funzione: Any, argomenti: list) -> Any:
    """Chiama ``funzione`` nell'interprete di un lavoro (gli errori Python diventano errori Leo)."""
    _QUI.interprete = interprete
    try:
        return interprete.chiama(funzione, argomenti)
    except RecursionError:
        raise ErroreRicorsione("Troppe chiamate annidate nel lavoro `in parallelo`.") from None
    finally:
        _QUI.interprete = None


# ===========================================================================
# Lavori
# ===========================================================================

_NUMERI_LAVORO = itertools.count(1)

IN_CORSO = "in corso"
FINITO = "finito"
CON_ERRORE = "errore"
ANNULLATO = "annullato"


class Lavoro(OggettoControllo):
    """Un lavoro avviato con ``in parallelo fai ... fine`` (tipo Leo ``lavoro``).

    Proprieta': ``finito``, ``stato`` ("in corso", "finito", "errore",
    "annullato"), ``annullato``, ``modo`` ("processo" o "filo"), ``riga``.
    Metodi: ``aspetta(secondi)``, ``risultato()``, ``finito()``, ``annulla()``.
    Si puo' passare a un altro lavoro (che gira allora in un filo)."""

    NOME_TIPO_DANTE = "lavoro"
    E_VALORE_LIBRERIA = True
    CONDIVISO_TRA_LAVORI = True
    nome = "lavoro"
    tipo_controllo = "lavoro"
    _METODI: dict[str, FunzioneNativa] = {}
    _PROPRIETA = ("finito", "stato", "annullato", "modo", "riga")

    # --- protocollo OggettoControllo ---
    def metodo(self, nome: str) -> Any:
        f = self._METODI.get(nome)
        return MetodoLegato(self, f) if f is not None else None

    def leggi(self, proprieta: str) -> Any:
        if proprieta in self._PROPRIETA:
            return getattr(self, proprieta)
        raise ErroreNome(f"Un valore di tipo `lavoro` non ha `{proprieta}`.",
                         suggerimento="Puoi usare: `finito`, `stato`, `annullato`, `modo`, `aspetta()`, "
                                      "`risultato()`, `annulla()`.", nome=proprieta)

    def scrivi(self, proprieta: str, valore: Any) -> None:
        raise ErroreTipo("Un lavoro `in parallelo` non si può modificare.",
                         suggerimento="Per il suo risultato usa `aspetta(lavoro)`; per fermarlo `annulla(lavoro)`.")

    def elenco_proprieta(self) -> list[str]:
        return list(self._PROPRIETA)

    def elenco_metodi(self) -> list[str]:
        return sorted(self._METODI)

    def __init__(self, genitore: Any, funzione: Any, *, riga: int | None = None) -> None:
        self._genitore = genitore
        self._funzione = funzione
        self.numero = next(_NUMERI_LAVORO)
        self._fatto = threading.Event()
        self._blocco = threading.Lock()
        self._osservatori: list[threading.Event] = []
        self.risultato: Any = None
        self.errore: ErroreDante | None = None
        self.raccolto = False
        self.stato = IN_CORSO
        self.modo = ""
        self.riga = riga if riga is not None else getattr(funzione, "riga", 0)
        self._in_attesa = False
        self._esecuzione: Any = None          # _EsecuzioneFilo o parallelo_processi.IncaricoLavoro
        self._annulla_richiesto = False

    # --- ciclo di vita ---
    def avvia(self) -> None:
        """Copia il mondo e fa partire il lavoro in un processo (se si puo') o in un filo."""
        from . import parallelo_processi

        esecuzione: Any = None
        if parallelo_processi.vuole_processi():
            esecuzione = parallelo_processi.prova_in_processo(self, isola(self._genitore, self._funzione, False))
        if esecuzione is None:
            esecuzione = _EsecuzioneFilo(self, isola(self._genitore, self._funzione))
            self.modo = "filo"
        else:
            self.modo = "processo"
        self._esecuzione = esecuzione
        esecuzione.avvia()

    def concludi(self, *, risultato: Any = None, errore: ErroreDante | None = None, annullato: bool = False) -> None:
        """Chiamato dall'esecuzione quando il lavoro e' finito (in qualunque modo)."""
        with self._blocco:
            if self._fatto.is_set():
                return
            if annullato:
                self.stato = ANNULLATO
                self.raccolto = True         # un lavoro annullato non ferma il programma alla fine
            elif errore is not None:
                self.errore = errore
                self.stato = CON_ERRORE
            else:
                self.risultato = risultato
                self.stato = FINITO
            self._fatto.set()
            osservatori, self._osservatori = self._osservatori, []
        for evento in osservatori:
            evento.set()
        if errore is not None and not annullato and getattr(self._genitore, "ponte_grafico", None) is not None \
                and not self._in_attesa:
            # nei programmi a finestre nessun ciclo testuale lo raccoglie: lo si scrive subito
            try:
                sys.stderr.write(errore.breve() + "\n")
            except Exception:  # noqa: BLE001
                pass

    def osserva(self, evento: threading.Event) -> None:
        """``evento`` si accende quando il lavoro finisce (subito, se ha gia' finito)."""
        with self._blocco:
            if not self._fatto.is_set():
                if evento not in self._osservatori:
                    self._osservatori.append(evento)
                return
        evento.set()

    def smetti_di_osservare(self, evento: threading.Event) -> None:
        with self._blocco:
            try:
                self._osservatori.remove(evento)
            except ValueError:
                pass

    def annulla(self) -> bool:
        """Chiede di fermare il lavoro; vero se era ancora in corso."""
        if self._fatto.is_set():
            return False
        self._annulla_richiesto = True
        esecuzione = self._esecuzione
        if esecuzione is not None:
            esecuzione.annulla()
        # da qui il lavoro e' annullato (anche se il suo filo o processo si ferma un attimo dopo:
        # quello che produce ancora non arriva piu' a nessuno)
        self.concludi(annullato=True)
        return True

    def ferma(self) -> None:
        self.annulla()

    @property
    def finito(self) -> bool:  # type: ignore[override]
        return self._fatto.is_set()

    @property
    def annullato(self) -> bool:
        return self.stato == ANNULLATO

    def aspetta(self, interprete: Any = None, secondi: float | None = None, annulla: bool = False) -> Any:
        """Aspetta la fine del lavoro (al massimo ``secondi``) e ne da' il risultato."""
        it = interprete or self._genitore
        limite = _limite(secondi, "aspetta")
        self._in_attesa = True
        try:
            if not attendi_evento(it, self._fatto, limite):
                if annulla:
                    self.annulla()
                raise ErroreValore(
                    f"Il lavoro `in parallelo` (riga {self.riga}) non è finito entro {rappresenta(secondi)} "
                    "secondi." + (" L'ho annullato." if annulla else ""),
                    suggerimento="Aspetta più a lungo, controlla prima `lavoro.finito()` oppure usa "
                                 "`aspetta(lavoro, secondi, annulla = vero)` per fermarlo quando il tempo scade.")
        finally:
            self._in_attesa = False
        return self.esito(it)

    def esito(self, interprete: Any = None) -> Any:
        """Il risultato di un lavoro finito (ripete il suo errore; errore chiaro se annullato)."""
        self.raccolto = True
        if self.stato == ANNULLATO:
            if getattr(interprete, "fermato", False):
                raise SegnaleFermaProgramma()     # annullato perche' si ferma tutto il programma
            raise ErroreValore(f"Il lavoro `in parallelo` (riga {self.riga}) è stato annullato: non ha un "
                               "risultato.", suggerimento="Controlla prima `lavoro.annullato`.")
        if self.errore is not None:
            raise self.errore
        return self.risultato

    def testo_dante(self) -> str:
        if self.stato == IN_CORSO:
            return "<lavoro in parallelo: in corso>"
        return "<lavoro in parallelo: finito>" if self.stato in (FINITO, CON_ERRORE) else \
            "<lavoro in parallelo: annullato>"

    def __reduce__(self):  # un lavoro non si copia in un altro processo
        import pickle

        raise pickle.PicklingError("un lavoro non passa da un processo all'altro")


class _EsecuzioneFilo:
    """Un lavoro che gira in un filo di questo processo, sulla sua copia del mondo."""

    def __init__(self, lavoro: Lavoro, mondo: Mondo) -> None:
        genitore = lavoro._genitore
        self.lavoro = lavoro
        self.mondo = mondo
        uscita = genitore.uscita

        def scrivi(testo: str) -> None:
            if not lavoro._annulla_richiesto:
                uscita(testo)

        self.figlio = crea_interprete_lavoro(
            predefinito=genitore.predefinito, globale=mondo.globale, uscita=scrivi,
            nome_file=genitore.nome_file, sorgente=getattr(genitore, "sorgente", ""),
            dichiarazione_implicita=genitore.dichiarazione_implicita,
            profondita_massima=genitore.profondita_massima,
            con_grafica=getattr(genitore, "ponte_grafico", None) is not None,
            tollerante=getattr(genitore, "tollerante", True),
            percorsi_moduli=getattr(genitore, "percorsi_moduli", ()),
            file_corrente=getattr(mondo.funzione, "nome_file", None) or getattr(genitore, "_file_corrente", None))
        figlio_genitore = genitore.__dict__.get("sorgenti_moduli")
        if figlio_genitore:
            self.figlio.sorgenti_moduli = dict(figlio_genitore)
        self._filo: threading.Thread | None = None

    def avvia(self) -> None:
        in_un_filo(self._corpo)

    def _corpo(self) -> None:
        lavoro = self.lavoro
        try:
            if lavoro._annulla_richiesto:
                raise SegnaleFermaProgramma()
            risultato = esegui_nel_filo(self.figlio, self.mondo.funzione, [])
        except SegnaleFermaProgramma:
            lavoro.concludi(annullato=True)
        except ErroreDante as e:
            if lavoro._annulla_richiesto and not e.catturabile:
                lavoro.concludi(annullato=True)
            else:
                lavoro.concludi(errore=e)
        except Exception as e:  # noqa: BLE001 - errore interno: diventa un errore Leo
            lavoro.concludi(errore=ErroreValore(f"Errore interno di Leo nel lavoro `in parallelo`: {e}"))
        else:
            if lavoro._annulla_richiesto and self.figlio.fermato:
                lavoro.concludi(annullato=True)
            else:
                lavoro.concludi(risultato=risultato)

    def annulla(self) -> None:
        self.figlio.ferma()


def avvia_filo(corpo: Callable[[], None], nome: str) -> threading.Thread:
    """Un filo demone con la pila grande (l'interprete annida molte chiamate Python)."""
    try:
        precedente = threading.stack_size(DIMENSIONE_PILA_LAVORO)
    except (ValueError, RuntimeError, OverflowError):
        precedente = None
    try:
        filo = threading.Thread(target=corpo, name=nome, daemon=True)
        filo.start()
    finally:
        if precedente is not None:
            try:
                threading.stack_size(precedente)
            except (ValueError, RuntimeError):
                pass
    return filo


class _FiliPronti:
    """Fili riusati per i lavori (avviare un filo costa: con il GIL chi lo avvia aspetta che parta).

    Un compito va a un filo libero; se non ce n'e' se ne avvia un altro (nessun limite: un
    lavoro puo' restare fermo su un canale e non deve mai bloccare gli altri). Un filo libero
    da piu' di :attr:`RIPOSO` secondi finisce."""

    RIPOSO = 30.0

    def __init__(self) -> None:
        import queue

        self._coda: Any = queue.SimpleQueue()
        self._blocco = threading.Lock()
        self._liberi = 0

    def esegui(self, corpo: Callable[[], None]) -> None:
        with self._blocco:
            if self._liberi > 0:
                self._liberi -= 1
                self._coda.put(corpo)
                return
        self._coda.put(corpo)
        avvia_filo(self._gira, "leo-filo-lavoro")

    def _gira(self) -> None:
        import queue

        while True:
            try:
                corpo = self._coda.get(timeout=self.RIPOSO)
            except queue.Empty:
                with self._blocco:
                    if self._coda.empty():
                        self._liberi -= 1
                        return
                continue
            try:
                corpo()
            except BaseException:  # noqa: BLE001 - un compito rotto non uccide il filo
                pass
            with self._blocco:
                self._liberi += 1


FILI_PRONTI = _FiliPronti()


def in_un_filo(corpo: Callable[[], None]) -> None:
    """Esegue ``corpo`` in uno dei fili riusati (con la pila grande)."""
    FILI_PRONTI.esegui(corpo)


def avvia_lavoro(interprete: Any, funzione: Any) -> Lavoro:
    """Avvia ``funzione`` (senza parametri) come lavoro isolato e lo registra
    nell'interprete (per ``ferma``, la fine del programma e gli errori mai raccolti)."""
    lavoro = Lavoro(interprete, funzione)
    lavori = interprete.__dict__.setdefault("_lavori", [])
    lavori[:] = [l for l in lavori if not (l.finito and (l.raccolto or l.errore is None))]
    lavori.append(lavoro)
    lavoro.avvia()
    return lavoro


def lavori_in_corso(interprete: Any) -> bool:
    return any(not l.finito for l in interprete.__dict__.get("_lavori", ()))


def errore_non_raccolto(interprete: Any) -> ErroreDante | None:
    """Il primo errore di un lavoro finito che nessuno ha raccolto con ``aspetta``."""
    for lavoro in interprete.__dict__.get("_lavori", ()):
        if lavoro.finito and lavoro.errore is not None and not lavoro.raccolto:
            lavoro.raccolto = True
            return lavoro.errore
    return None


def ferma_lavori(interprete: Any) -> None:
    for lavoro in list(interprete.__dict__.get("_lavori", ())):
        lavoro.annulla()


# ===========================================================================
# Attese
# ===========================================================================

def _limite(secondi: Any, chi: str) -> float | None:
    if secondi is None:
        return None
    if isinstance(secondi, bool) or not isinstance(secondi, (int, float)):
        raise ErroreTipo(f"Il tempo massimo di `{chi}` è un numero di secondi, non {tipo_con_articolo(secondi)}.",
                         suggerimento=f"Per esempio `{chi}(..., 5)`.")
    if secondi != secondi or secondi < 0:
        raise ErroreValore(f"Il tempo massimo di `{chi}` non può essere negativo ({rappresenta(secondi)}).")
    return time.monotonic() + float(min(secondi, 10 ** 9))


def attendi_evento(interprete: Any, evento: threading.Event, limite: float | None) -> bool:
    """Aspetta ``evento`` fino a ``limite`` (monotonic); falso se scade. Si ferma se il
    programma viene fermato; nei programmi a finestre l'interfaccia resta viva."""
    ponte = getattr(interprete, "ponte_grafico", None)
    attendi = getattr(ponte, "attendi", None) if ponte is not None and not isinstance(ponte, _PonteParallelo) \
        else None
    while not evento.is_set():
        if getattr(interprete, "fermato", False):
            raise SegnaleFermaProgramma()
        adesso = time.monotonic()
        if limite is not None and adesso >= limite:
            return False
        passo = PASSO_ATTESA if limite is None else max(0.0, min(PASSO_ATTESA, limite - adesso))
        if callable(attendi):
            attendi(min(passo, 0.02))   # finestre: l'interfaccia resta viva mentre si aspetta
        else:
            evento.wait(passo)
    return True


def richiedi_lavori(valore: Any, chi: str) -> list[Lavoro]:
    if isinstance(valore, Lavoro):
        return [valore]
    if not isinstance(valore, list):
        raise ErroreTipo(f"`{chi}` vuole una lista di lavori avviati con `in parallelo`, non "
                         f"{tipo_con_articolo(valore)}.", suggerimento=f"Per esempio `{chi}([l1, l2])`.")
    for i, elemento in enumerate(valore):
        if not isinstance(elemento, Lavoro):
            raise ErroreTipo(
                f"`{chi}` vuole solo lavori avviati con `in parallelo`, ma l'elemento {i} della lista è "
                f"{tipo_con_articolo(elemento)} ({rappresenta(elemento, dentro=True)}).",
                suggerimento=f"Metti nella lista solo i lavori, per esempio `{chi}([l1, l2])`.")
    return list(valore)


def aspetta(interprete: Any, lavoro: Any, secondi: Any = None, annulla: bool = False) -> Any:
    """``aspetta(lavoro)`` / ``aspetta([l1, l2])`` (gli argomenti sono gia' controllati)."""
    if isinstance(lavoro, list):
        lavori = richiedi_lavori(lavoro, "aspetta")
        limite = _limite(secondi, "aspetta")
        risultati = []
        for l in lavori:
            resta = None if limite is None else max(0.0, limite - time.monotonic())
            risultati.append(l.aspetta(interprete, resta if secondi is not None else None, annulla))
        return risultati
    return lavoro.aspetta(interprete, secondi, annulla)


def aspetta_tutti(interprete: Any, lavori: Any, secondi: Any = None) -> list:
    """Aspetta tutti i lavori; al primo errore annulla gli altri e ripete l'errore; se il tempo
    scade li annulla tutti. Da' la lista dei risultati, nell'ordine della lista."""
    elenco = richiedi_lavori(lavori, "aspetta_tutti")
    limite = _limite(secondi, "aspetta_tutti")
    evento = threading.Event()
    for l in elenco:
        l.osserva(evento)
    try:
        while True:
            evento.clear()
            for l in elenco:
                if l.finito and (l.errore is not None or l.annullato):
                    for altro in elenco:
                        altro.annulla()
                    l.esito(interprete)             # solleva il suo errore
            if all(l.finito for l in elenco):
                return [l.esito(interprete) for l in elenco]
            for l in elenco:
                if not l.finito:
                    l.osserva(evento)
            if not attendi_evento(interprete, evento, limite):
                for l in elenco:
                    l.annulla()
                quanti = sum(1 for l in elenco if not l.finito)
                raise ErroreValore(
                    f"`aspetta_tutti`: {quanti} lavori su {len(elenco)} non sono finiti entro "
                    f"{rappresenta(secondi)} secondi; li ho annullati.",
                    suggerimento="Dai più tempo, oppure dividi il lavoro in parti più piccole.")
    finally:
        for l in elenco:
            l.smetti_di_osservare(evento)


def aspetta_il_primo(interprete: Any, lavori: Any, secondi: Any = None, annulla_gli_altri: bool = False) -> Lavoro:
    """Il primo lavoro della lista che finisce (in qualunque modo)."""
    elenco = richiedi_lavori(lavori, "aspetta_il_primo")
    if not elenco:
        raise ErroreValore("`aspetta_il_primo` ha ricevuto una lista vuota: non c'è nessun lavoro da aspettare.")
    limite = _limite(secondi, "aspetta_il_primo")
    evento = threading.Event()
    for l in elenco:
        l.osserva(evento)
    try:
        while True:
            for l in elenco:
                if l.finito:
                    if annulla_gli_altri:
                        for altro in elenco:
                            if altro is not l:
                                altro.annulla()
                    return l
            evento.clear()
            if any(l.finito for l in elenco):
                continue
            if not attendi_evento(interprete, evento, limite):
                raise ErroreValore(f"`aspetta_il_primo`: nessun lavoro è finito entro {rappresenta(secondi)} secondi.",
                                   suggerimento="Dai più tempo, oppure annulla i lavori con `annulla(lavori)`.")
    finally:
        for l in elenco:
            l.smetti_di_osservare(evento)


def annulla(valore: Any) -> Any:
    """``annulla(lavoro)`` o ``annulla([l1, l2])``: vero (o quanti) se erano ancora in corso."""
    if isinstance(valore, Lavoro):
        return valore.annulla()
    elenco = richiedi_lavori(valore, "annulla")
    return sum(1 for l in elenco if l.annulla())


# ===========================================================================
# Canali
# ===========================================================================

_NUMERI_CANALE = itertools.count(1)
#: I canali vivi di questo processo, per numero (i processi lavoratori li chiamano per numero).
CANALI: "weakref.WeakValueDictionary[int, Canale]" = weakref.WeakValueDictionary()


class CanaleChiuso(Exception):
    """Interno: il canale e' chiuso e vuoto."""


class TempoScaduto(Exception):
    """Interno: l'attesa e' scaduta."""


class Canale(OggettoControllo):
    """Un canale (tipo Leo ``canale``): fa passare messaggi fra lavori, in ordine.

    ``invia(messaggio)`` (aspetta se il canale ha una capacita' ed e' pieno),
    ``ricevi(secondi)`` (aspetta il prossimo), ``chiudi()``; ``per ogni m in
    canale`` riceve finche' il canale e' chiuso e vuoto. Ogni messaggio e' una
    copia (come fra processi): chi lo riceve non tocca i dati di chi l'ha
    mandato. Funziona fra fili e fra processi."""

    NOME_TIPO_DANTE = "canale"
    E_VALORE_LIBRERIA = True
    CONDIVISO_TRA_LAVORI = True
    nome = "canale"
    tipo_controllo = "canale"
    _METODI: dict[str, FunzioneNativa] = {}
    _PROPRIETA = ("lunghezza", "chiuso", "capacità", "numero")
    #: Come si chiama il suo tipo quando passa in un processo lavoratore.
    TIPO_REMOTO = "canale"

    def __init__(self, capacita: int = 0) -> None:
        self.capacita = int(capacita)
        self.numero = next(_NUMERI_CANALE)
        self._coda: collections.deque = collections.deque()
        self._condizione = threading.Condition()
        self._chiuso = False
        self._osservatori: list[threading.Event] = []
        self.interprete: Any = None          # chi l'ha creato (per accorgersi dell'arresto nel `per ogni`)
        CANALI[self.numero] = self

    # --- protocollo OggettoControllo ---
    def metodo(self, nome: str) -> Any:
        f = self._METODI.get(nome)
        return MetodoLegato(self, f) if f is not None else None

    def leggi(self, proprieta: str) -> Any:
        if proprieta == "lunghezza":
            return self.lunghezza()
        if proprieta == "chiuso":
            return self.chiuso()
        if proprieta in ("capacità", "capacita"):
            return self.capacita
        if proprieta == "numero":
            return self.numero
        raise ErroreNome(f"Un valore di tipo `canale` non ha `{proprieta}`.",
                         suggerimento="Puoi usare: `invia(messaggio)`, `ricevi()`, `chiudi()`, `lunghezza`, "
                                      "`chiuso`, `capacità`.", nome=proprieta)

    def scrivi(self, proprieta: str, valore: Any) -> None:
        raise ErroreTipo("Le proprietà di un canale non si cambiano.",
                         suggerimento="Per mandare un messaggio usa `canale.invia(messaggio)`.")

    def elenco_proprieta(self) -> list[str]:
        return list(self._PROPRIETA)

    def elenco_metodi(self) -> list[str]:
        return sorted(self._METODI)

    def testo_dante(self) -> str:
        stato = ", chiuso" if self._chiuso else ""
        quanti = len(self._coda)
        return f"<canale con {quanti} messaggi{stato}>" if quanti != 1 else f"<canale con 1 messaggio{stato}>"

    # --- operazioni (``interprete`` serve per accorgersi dell'arresto) ---
    def lunghezza(self) -> int:
        with self._condizione:
            return len(self._coda)

    def chiuso(self) -> bool:
        return self._chiuso

    def _avvisa(self) -> None:
        osservatori, self._osservatori = self._osservatori, []
        for evento in osservatori:
            evento.set()

    def osserva(self, evento: threading.Event) -> None:
        with self._condizione:
            if self._coda or self._chiuso:
                evento.set()
            elif evento not in self._osservatori:
                self._osservatori.append(evento)

    def smetti_di_osservare(self, evento: threading.Event) -> None:
        with self._condizione:
            try:
                self._osservatori.remove(evento)
            except ValueError:
                pass

    def invia_dato(self, messaggio: Any, fermato: Callable[[], bool], limite: float | None = None) -> None:
        """Mette ``messaggio`` (gia' copiato) in fondo; aspetta se il canale e' pieno."""
        with self._condizione:
            while True:
                if self._chiuso:
                    raise CanaleChiuso()
                if self.capacita <= 0 or len(self._coda) < self.capacita:
                    break
                if fermato():
                    raise SegnaleFermaProgramma()
                adesso = time.monotonic()
                if limite is not None and adesso >= limite:
                    raise TempoScaduto()
                self._condizione.wait(PASSO_ATTESA if limite is None else min(PASSO_ATTESA, limite - adesso))
            self._coda.append(messaggio)
            self._condizione.notify_all()
            self._avvisa()

    def prendi_dato(self, fermato: Callable[[], bool], limite: float | None = None) -> Any:
        """Toglie e da' il primo messaggio; CanaleChiuso se chiuso e vuoto, TempoScaduto se scade."""
        with self._condizione:
            while not self._coda:
                if self._chiuso:
                    raise CanaleChiuso()
                if fermato():
                    raise SegnaleFermaProgramma()
                adesso = time.monotonic()
                if limite is not None and adesso >= limite:
                    raise TempoScaduto()
                self._condizione.wait(PASSO_ATTESA if limite is None else min(PASSO_ATTESA, limite - adesso))
            messaggio = self._coda.popleft()
            self._condizione.notify_all()
            return messaggio

    def prova_a_prendere(self) -> tuple[bool, Any]:
        """(vero, messaggio) se ce n'e' uno pronto; (falso, chiuso?) altrimenti."""
        with self._condizione:
            if self._coda:
                messaggio = self._coda.popleft()
                self._condizione.notify_all()
                return True, messaggio
            return False, self._chiuso

    def chiudi(self) -> bool:
        with self._condizione:
            era_aperto = not self._chiuso
            self._chiuso = True
            self._condizione.notify_all()
            self._avvisa()
            return era_aperto

    # --- per ogni messaggio in canale ---
    def elementi_per_ogni(self) -> Iterator[Any]:
        interprete = interprete_del_filo(getattr(self, "interprete", None))

        def fermato() -> bool:
            return bool(interprete is not None and interprete.fermato)

        while True:
            try:
                yield self.prendi_dato(fermato)
            except CanaleChiuso:
                return

    def __reduce__(self):
        # verso un processo lavoratore viaggia solo il numero (vedi parallelo_processi)
        from .parallelo_processi import riduci_canale

        return riduci_canale(self)


def copia_messaggio(valore: Any) -> Any:
    """La copia di un messaggio che passa in un canale (i dati di chi lo manda restano suoi)."""
    tipo = type(valore)
    if tipo in _IMMUTABILI:
        return valore
    return Isolatore().valore(valore)


def seleziona(canali: list, fermato: Callable[[], bool], limite: float | None) -> tuple[int, Any]:
    """(indice, messaggio) del primo messaggio pronto in uno dei canali; CanaleChiuso se sono tutti
    chiusi e vuoti, TempoScaduto se il tempo finisce."""
    evento = threading.Event()
    try:
        while True:
            evento.clear()
            chiusi = 0
            for i, c in enumerate(canali):
                pronto, valore = c.prova_a_prendere()
                if pronto:
                    return i, valore
                if valore:
                    chiusi += 1
            if chiusi == len(canali):
                raise CanaleChiuso()
            for c in canali:
                c.osserva(evento)
            while not evento.is_set():
                if fermato():
                    raise SegnaleFermaProgramma()
                adesso = time.monotonic()
                if limite is not None and adesso >= limite:
                    raise TempoScaduto()
                evento.wait(PASSO_ATTESA if limite is None else min(PASSO_ATTESA, limite - adesso))
    finally:
        for c in canali:
            c.smetti_di_osservare(evento)


def ricevi_dal_primo(interprete: Any, canali: list, secondi: Any = None) -> list:
    """Il primo messaggio che arriva da uno dei canali: ``[canale, messaggio]``."""
    limite = _limite(secondi, "ricevi_dal_primo")
    it = interprete_del_filo(interprete)

    def fermato() -> bool:
        return bool(getattr(it, "fermato", False))

    remoti = [type(c).__name__ == "CanaleRemoto" for c in canali]
    try:
        if canali and all(remoti):
            from .parallelo_processi import seleziona_remoto

            indice, messaggio = seleziona_remoto(canali, fermato, limite)
        elif any(remoti):
            raise ErroreValore("`ricevi_dal_primo` non può mescolare canali del programma e canali creati "
                               "dentro il lavoro.", suggerimento="Crea tutti i canali nel programma principale.")
        else:
            indice, messaggio = seleziona(canali, fermato, limite)
    except CanaleChiuso:
        raise ErroreValore("`ricevi_dal_primo`: tutti i canali sono chiusi e vuoti.",
                           suggerimento="Controlla `canale.chiuso` prima di aspettare.") from None
    except TempoScaduto:
        raise ErroreValore(f"`ricevi_dal_primo`: nessun messaggio entro {rappresenta(secondi)} secondi.",
                           suggerimento="Dai più tempo, oppure controlla prima `canale.lunghezza`.") from None
    return [canali[indice], messaggio]


# ===========================================================================
# Informazioni
# ===========================================================================

def informazioni() -> dict:
    """Come lavorano i lavori qui: ``modo``, ``processori``, ``processi``, ``motivo``, ``gil``, ``lavoratori``."""
    from . import parallelo_processi

    disponibili, motivo = parallelo_processi.processi_disponibili()
    richiesto = modo_richiesto()
    if richiesto == "fili" or not disponibili:
        modo = "fili"
    else:
        modo = "processi"
    return {"modo": modo, "richiesto": richiesto, "processori": processori(), "processi": disponibili,
            "motivo": motivo, "gil": gil_attivo(), "lavoratori": parallelo_processi.quanti_lavoratori()}


# ===========================================================================
# Metodi Leo dei lavori e dei canali
# ===========================================================================

def _metodo(classe: type, nome: str, *, interprete: bool = False) -> Callable:
    def decora(f: Callable) -> Callable:
        classe._METODI[nome] = FunzioneNativa(nome, f, vuole_interprete=interprete, e_metodo=True)
        return f

    return decora


@_metodo(Lavoro, "aspetta", interprete=True)
def _lavoro_aspetta(interprete, lavoro, secondi=None, annulla=False):
    """lavoro.aspetta(secondi = nulla, annulla = falso): come `aspetta(lavoro)`."""
    return lavoro.aspetta(interprete, secondi, bool(annulla))


@_metodo(Lavoro, "risultato", interprete=True)
def _lavoro_risultato(interprete, lavoro):
    """lavoro.risultato(): il risultato del lavoro (aspetta che finisca)."""
    return lavoro.aspetta(interprete)


@_metodo(Lavoro, "finito")
def _lavoro_finito(lavoro):
    """lavoro.finito(): vero se il lavoro ha finito (bene, con un errore o perché annullato)."""
    return lavoro.finito


@_metodo(Lavoro, "annulla")
def _lavoro_annulla(lavoro):
    """lavoro.annulla(): ferma il lavoro; vero se era ancora in corso."""
    return lavoro.annulla()


def _fermato_da(interprete: Any) -> Callable[[], bool]:
    it = interprete_del_filo(interprete)
    return lambda: bool(getattr(it, "fermato", False))


def _limite_canale(secondi: Any, chi: str) -> float | None:
    return _limite(secondi, chi)


@_metodo(Canale, "invia", interprete=True)
def _canale_invia(interprete, canale, messaggio, secondi=None):
    """canale.invia(messaggio, secondi = nulla): manda una copia del messaggio in fondo al canale.

    Se il canale ha una capacità ed è pieno aspetta che si liberi un posto (al massimo
    `secondi`). Un canale chiuso non accetta altri messaggi."""
    limite = _limite_canale(secondi, "invia")
    if not type(canale).__name__ == "CanaleRemoto":
        messaggio = copia_messaggio(messaggio)
    try:
        canale.invia_dato(messaggio, _fermato_da(interprete), limite)
    except CanaleChiuso:
        raise ErroreValore("Il canale è chiuso: non si possono mandare altri messaggi.",
                           suggerimento="Chiudi il canale solo quando hai finito di mandare messaggi.") from None
    except TempoScaduto:
        raise ErroreValore(f"Il canale è pieno e non si è liberato un posto entro {rappresenta(secondi)} secondi.",
                           suggerimento="Qualcuno deve ricevere i messaggi (`canale.ricevi()`), oppure crea il "
                                        "canale con una capacità più grande.") from None
    return None


@_metodo(Canale, "ricevi", interprete=True)
def _canale_ricevi(interprete, canale, secondi=None):
    """canale.ricevi(secondi = nulla): toglie e restituisce il primo messaggio, aspettando se non ce n'è.

    Con `secondi` aspetta al massimo quel tempo (poi c'è un errore). Se il canale è chiuso
    e vuoto c'è un errore: per ricevere finché ce ne sono usa `per ogni messaggio in canale`."""
    limite = _limite_canale(secondi, "ricevi")
    try:
        return canale.prendi_dato(_fermato_da(interprete), limite)
    except CanaleChiuso:
        raise ErroreValore("Il canale è chiuso e non ha più messaggi.",
                           suggerimento="Per ricevere finché ce ne sono usa `per ogni messaggio in canale fai`, "
                                        "oppure controlla prima `canale.chiuso`.") from None
    except TempoScaduto:
        raise ErroreValore(f"Nessun messaggio nel canale entro {rappresenta(secondi)} secondi.",
                           suggerimento="Dai più tempo, oppure controlla prima `canale.lunghezza`.") from None


@_metodo(Canale, "chiudi")
def _canale_chiudi(canale):
    """canale.chiudi(): niente più messaggi nuovi; chi riceve prende quelli rimasti, poi `per ogni` finisce."""
    return canale.chiudi()
