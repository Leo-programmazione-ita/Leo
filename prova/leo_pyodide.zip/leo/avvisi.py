"""Avvisi prima di eseguire: programmi validi che quasi certamente non fanno quello che si vuole.

Il programma parte comunque; l'avviso (sulla riga di comando nel canale degli
errori, sul telefono nell'uscita) dice il problema e la soluzione, con la riga
gia' corretta quando Leo la sa scrivere (e solo se passa il parser):

* **testo confrontato con un numero** (``"5" == 5`` e' sempre falso): una
  risposta letta con ``chiedi`` confrontata con un numero -> ``chiedi_numero``
  (o ``intero(chiedi(...))``) nella riga che la legge;
* **``domanda`` usata per un testo** (``variabile nome = domanda("Come ti chiami?")``):
  ``domanda`` risponde solo sì/no -> ``chiedi``;
* **``quando`` senza finestra**: ``quando Pulsante1.clic`` in un programma senza
  finestra (nessuna maschera accanto, nessun controllo con quel nome) non
  verra' mai eseguito.

API:
    Avviso(riga, colonna, messaggio, suggerimento, proposta=None)
    avvisi(sorgente, nome_file="<sorgente>", **opzioni_lessico) -> list[Avviso]
    formatta_avvisi(lista, sorgente, *, semplice=False) -> str
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import Any

from . import nodi

__all__ = ["Avviso", "avvisi", "formatta_avvisi", "testo_avvisi"]


@dataclass
class Avviso:
    """Un avviso: il problema (``messaggio``), la soluzione (``suggerimento``) e, se c'e',
    la riga corretta ``proposta = (numero, prima, dopo)``."""

    riga: int
    colonna: int
    messaggio: str
    suggerimento: str
    proposta: tuple[int, str, str] | None = None
    semplice: str | None = None
    soluzione_semplice: str | None = None


# ---------------------------------------------------------------------------
# Visita dell'albero
# ---------------------------------------------------------------------------

def _figli(nodo: Any):
    if isinstance(nodo, list):
        for x in nodo:
            yield x
        return
    if not isinstance(nodo, nodi.Nodo):
        return
    for nome in getattr(nodo, "__dataclass_fields__", {}):
        valore = getattr(nodo, nome, None)
        if isinstance(valore, (nodi.Nodo, list)):
            yield valore
        elif isinstance(valore, tuple):
            for x in valore:
                if isinstance(x, (nodi.Nodo, list)):
                    yield x


def _tutti(nodo: Any):
    pila = [nodo]
    while pila:
        n = pila.pop()
        if isinstance(n, list):
            pila.extend(reversed(n))
            continue
        if isinstance(n, tuple):
            pila.extend(x for x in n if isinstance(x, (nodi.Nodo, list, tuple)))
            continue
        if not isinstance(n, nodi.Nodo):
            continue
        yield n
        pila.extend(reversed(list(_figli(n))))


def _nome_chiamata(nodo: Any) -> str | None:
    if isinstance(nodo, nodi.Chiamata) and isinstance(nodo.funzione, nodi.Nome):
        return nodo.funzione.nome
    return None


_FUNZIONI_NUMERO = frozenset({"intero", "decimale", "casuale", "chiedi_numero", "lunghezza", "arrotonda",
                              "assoluto", "radice", "minimo", "massimo", "somma"})


def _genere(valore: Any, generi: dict[str, str]) -> str:
    """``"testo"``, ``"chiedi"`` (testo letto con chiedi), ``"numero"`` o ``"?"``."""
    if isinstance(valore, nodi.Letterale):
        v = valore.valore
        if isinstance(v, bool) or v is None:
            return "?"
        if isinstance(v, (int, float)):
            return "numero"
        if isinstance(v, str):
            return "testo"
        return "?"
    if isinstance(valore, nodi.TestoInterpolato):
        return "testo"
    if isinstance(valore, nodi.Unaria) and valore.operatore == "-":
        return "numero" if _genere(valore.operando, generi) == "numero" else "?"
    if isinstance(valore, nodi.Binaria) and valore.operatore in ("-", "*", "/", "//", "%", "^"):
        if _genere(valore.sinistra, generi) == "numero" and _genere(valore.destra, generi) == "numero":
            return "numero"
        return "?"
    funzione = _nome_chiamata(valore)
    if funzione == "chiedi":
        return "chiedi"
    if funzione in _FUNZIONI_NUMERO:
        return "numero"
    if funzione == "testo":
        return "testo"
    if isinstance(valore, nodi.Nome):
        return generi.get(valore.nome, "?")
    return "?"


def _generi(programma: nodi.Programma) -> dict[str, str]:
    """Nome -> genere dei valori che riceve (``"?"`` se cambia o non si sa)."""
    generi: dict[str, str] = {}
    assegnazioni: list[tuple[str, Any]] = []
    for n in _tutti(programma):
        if isinstance(n, nodi.Dichiarazione) and not isinstance(n, nodi.DichiarazioneMultipla):
            assegnazioni.append((n.nome, n.valore))
        elif isinstance(n, nodi.Assegnazione) and isinstance(n.bersaglio, nodi.Nome):
            if n.operatore == "=":
                assegnazioni.append((n.bersaglio.nome, n.valore))
            else:
                assegnazioni.append((n.bersaglio.nome, None))
        elif isinstance(n, (nodi.DichiarazioneMultipla, nodi.AssegnazioneMultipla)):
            for nome in getattr(n, "nomi", None) or [getattr(b, "nome", "") for b in getattr(n, "bersagli", [])]:
                assegnazioni.append((nome, None))
        elif isinstance(n, nodi.PerOgni):
            for nome in [n.variabile] + list(n.variabili or []):
                assegnazioni.append((nome, None))
        elif isinstance(n, (nodi.DefinizioneFunzione, nodi.FunzioneAnonima)):
            for p in n.parametri:
                assegnazioni.append((p.nome, None))
    for _giro in range(2):
        nuovi: dict[str, str] = {}
        for nome, valore in assegnazioni:
            g = _genere(valore, generi) if valore is not None else "?"
            precedente = nuovi.get(nome)
            nuovi[nome] = g if precedente in (None, g) else "?"
        generi = nuovi
    return generi


# ---------------------------------------------------------------------------
# Avvisi
# ---------------------------------------------------------------------------

def _righe(sorgente: str) -> list[str]:
    return sorgente.lstrip("﻿").replace("\r\n", "\n").replace("\r", "\n").split("\n")


def _sicura(sorgente: str, numero: int, nuova: str, opzioni: dict) -> bool:
    # validazione centrale (leo.correttore_sicuro): la proposta deve lasciare il
    # programma analizzabile, altrimenti non si mostra (decisioni sul linguaggio, §6)
    try:
        from .correttore_sicuro import suggerimento_valido

        return suggerimento_valido(nuova, sorgente=sorgente, numero=numero, opzioni=opzioni)
    except Exception:  # noqa: BLE001
        return False


def _descrivi(nodo: Any) -> str:
    if isinstance(nodo, nodi.Nome):
        return f"`{nodo.nome}`"
    if isinstance(nodo, nodi.Letterale):
        v = nodo.valore
        return f'`"{v}"`' if isinstance(v, str) else f"`{v}`"
    return "un valore"


def _confronti_testo_numero(programma: nodi.Programma, sorgente: str, opzioni: dict) -> list[Avviso]:
    from .forme_parlate import proposta_chiedi_numero, riga_della_variabile

    generi = _generi(programma)
    righe = _righe(sorgente)
    risultato: list[Avviso] = []
    visti: set[int] = set()
    for n in _tutti(programma):
        if not isinstance(n, nodi.Confronto):
            continue
        for i, operatore in enumerate(n.operatori):
            if operatore not in ("==", "!=", "è", "non è"):
                continue
            a, b = n.operandi[i], n.operandi[i + 1]
            ga, gb = _genere(a, generi), _genere(b, generi)
            coppia = {ga, gb}
            if "numero" not in coppia or not coppia & {"testo", "chiedi"}:
                continue
            testo_lato, numero_lato = (a, b) if ga in ("testo", "chiedi") else (b, a)
            riga = n.riga or getattr(a, "riga", 0)
            if riga in visti:
                continue
            visti.add(riga)
            sempre = "sempre falso" if operatore in ("==", "è") else "sempre vero"
            messaggio = (f"Confronti un testo ({_descrivi(testo_lato)}) con un numero ({_descrivi(numero_lato)}) "
                         f"con `{operatore}`: per Leo un testo e un numero sono sempre diversi, "
                         f"quindi il confronto è {sempre}.")
            proposta = None
            if isinstance(testo_lato, nodi.Nome) and _genere(testo_lato, generi) == "chiedi":
                origine = riga_della_variabile(sorgente, testo_lato.nome, "chiedi")
                nuova = proposta_chiedi_numero(origine[1]) if origine else None
                if nuova and _sicura(sorgente, origine[0], nuova, opzioni):
                    proposta = (origine[0], origine[1], nuova)
                    suggerimento = (f"`{testo_lato.nome}` viene da `chiedi`, che dà sempre un testo: leggilo già "
                                    f"come numero (riga {origine[0]}): `{nuova.strip()}`.")
                else:
                    suggerimento = (f"Trasforma il testo in numero prima di confrontarlo: "
                                    f"`intero({testo_lato.nome})`.")
            elif isinstance(testo_lato, nodi.Nome):
                suggerimento = f"Trasforma il testo in numero prima di confrontarlo: `intero({testo_lato.nome})`."
            else:
                suggerimento = "Confronta valori dello stesso tipo: togli le virgolette al numero, o usa `intero(...)`."
                v = getattr(testo_lato, "valore", None)
                if isinstance(v, str) and re.fullmatch(r"-?\d+(?:\.\d+)?", v.strip()) and 1 <= riga <= len(righe):
                    testo_riga = righe[riga - 1]
                    nuova = testo_riga.replace(f'"{v}"', v.strip(), 1)
                    if nuova != testo_riga and _sicura(sorgente, riga, nuova, opzioni):
                        proposta = (riga, testo_riga, nuova)
                        suggerimento = f"Togli le virgolette al numero: `{nuova.strip()}`."
            if proposta is None and isinstance(testo_lato, nodi.Nome) and 1 <= riga <= len(righe):
                testo_riga = righe[riga - 1]
                m = re.search(rf"(?<![\w.]){re.escape(testo_lato.nome)}(?![\w(])", testo_riga)
                if m:
                    nuova = testo_riga[:m.start()] + f"intero({testo_lato.nome})" + testo_riga[m.end():]
                    if _sicura(sorgente, riga, nuova, opzioni):
                        proposta = (riga, testo_riga, nuova)
            risultato.append(Avviso(riga, n.colonna or 1, messaggio, suggerimento, proposta,
                                    semplice=f"{_descrivi(testo_lato)} è un testo e {_descrivi(numero_lato)} un "
                                             "numero: non saranno mai uguali."))
    return risultato


def _domande_per_un_testo(sorgente: str, opzioni: dict) -> list[Avviso]:
    from .forme_parlate import domanda_per_un_testo

    risultato = []
    for numero, riga in enumerate(_righe(sorgente), 1):
        if "domanda" not in riga or not domanda_per_un_testo(riga):
            continue
        nuova = re.sub(r"\bdomanda([ \t]*\()", r"chiedi\1", riga, count=1)
        proposta = (numero, riga, nuova) if _sicura(sorgente, numero, nuova, opzioni) else None
        colonna = riga.find("domanda") + 1
        risultato.append(Avviso(
            numero, colonna,
            "`domanda` aspetta una risposta sì o no e dà `vero` o `falso`, non il testo scritto.",
            f"Per farti scrivere un nome o una frase usa `chiedi`: `{nuova.strip()}`.", proposta,
            semplice="`domanda` serve per le risposte sì/no; per un testo usa `chiedi`."))
    return risultato


_APRE_FINESTRE = re.compile(r"\b(apri_finestra|Finestra|crea_finestra|mostra_finestra)\s*\(")


def _quando_senza_finestra(programma: nodi.Programma, sorgente: str, nome_file: str) -> list[Avviso]:
    eventi = [n for n in _tutti(programma) if isinstance(n, nodi.Evento)]
    if not eventi or _APRE_FINESTRE.search(sorgente):
        return []
    if nome_file and not nome_file.startswith("<"):
        cartella = os.path.dirname(os.path.abspath(nome_file))
        base = os.path.splitext(os.path.basename(nome_file))[0]
        if os.path.exists(os.path.join(cartella, base + ".maschera")) or \
                os.path.exists(os.path.join(cartella, "progetto.toml")):
            return []
    definiti: set[str] = set()
    for n in _tutti(programma):
        if isinstance(n, nodi.Dichiarazione):
            definiti.add(n.nome)
            definiti.update(getattr(n, "nomi", None) or [])
        elif isinstance(n, nodi.Assegnazione) and isinstance(n.bersaglio, nodi.Nome):
            definiti.add(n.bersaglio.nome)
        elif isinstance(n, nodi.Importa):
            definiti.add(n.alias or n.modulo)
    risultato = []
    for e in eventi:
        if e.controllo in definiti or e.controllo.split(".")[0] in definiti:
            continue
        risultato.append(Avviso(
            e.riga or 1, e.colonna or 1,
            f"`quando {e.controllo}.{e.evento}`: in questo programma non c'è nessuna finestra con "
            f"`{e.controllo}`, quindi il blocco non verrà mai eseguito.",
            "Gli eventi arrivano dai controlli di una finestra: crea un progetto con una finestra "
            "(`leo nuovo NomeProgetto`, oppure Nuovo progetto in Leo Studio e nell'app) e scrivi questo "
            f"codice nel suo file `Finestra1.leo`, dove `{e.controllo}` è il nome del controllo.",
            semplice=f"`{e.controllo}` non esiste: questo blocco `quando` non partirà mai senza una finestra.",
            soluzione_semplice="Crea un progetto con una finestra e scrivi questo blocco nel suo codice."))
    return risultato


#: Senza almeno una di queste forme non c'e' nessun avviso possibile (si evita la seconda analisi).
_PUO_SERVIRE = re.compile(r'\b(?:chiedi|domanda|quando)\b|"[^"\n]*"[ \t]*(?:==|!=|è)[ \t]*-?\d|'
                          r'\d[ \t]*(?:==|!=)[ \t]*"')


def avvisi(sorgente: str, nome_file: str = "<sorgente>", **opzioni: Any) -> list[Avviso]:
    """Gli avvisi del programma (lista vuota se non si analizza: gli errori li dice il parser)."""
    if not sorgente or not _PUO_SERVIRE.search(sorgente):
        return []          # niente `chiedi`, `domanda`, `quando` ne' confronti testo/numero: nessuna analisi
    lessico = {k: v for k, v in opzioni.items() if k in ("stile", "rigoroso", "sinonimi_extra",
                                                        "dizionari_sinonimi")}
    try:
        from .esecuzione import analizza

        programma = analizza(sorgente, os.path.basename(nome_file) if nome_file else "<sorgente>", **lessico)
    except Exception:  # noqa: BLE001 - un programma che non si analizza non ha avvisi
        return []
    risultato: list[Avviso] = []
    for funzione, argomenti in ((_confronti_testo_numero, (programma, sorgente, lessico)),
                                (_domande_per_un_testo, (sorgente, lessico)),
                                (_quando_senza_finestra, (programma, sorgente, nome_file))):
        try:
            risultato.extend(funzione(*argomenti))
        except Exception:  # noqa: BLE001 - un avviso in meno, mai un programma fermato
            continue
    risultato.sort(key=lambda a: (a.riga, a.colonna))
    return risultato


def formatta_avvisi(lista: list[Avviso], sorgente: str, *, semplice: bool = False) -> str:
    """Il testo degli avvisi, come lo scrive la riga di comando."""
    righe = _righe(sorgente or "")
    blocchi = []
    for a in lista:
        parti = [f"Avviso alla riga {a.riga}:"]
        if 1 <= a.riga <= len(righe):
            parti.append(f"    {a.riga} | {righe[a.riga - 1]}")
        parti.append((a.semplice if semplice and a.semplice else a.messaggio))
        if a.proposta:
            numero, _prima, dopo = a.proposta
            parti.append(("Correzione proposta:" if semplice else "Riga corretta proposta:"))
            parti.append(f"    {numero} | {dopo}")
            if not semplice:
                parti.insert(-2, "Suggerimento: " + a.suggerimento)
        elif semplice and a.soluzione_semplice:
            parti.append(a.soluzione_semplice)
        else:
            parti.append("Suggerimento: " + a.suggerimento)
        blocchi.append("\n".join(parti))
    return "\n\n".join(blocchi)


def testo_avvisi(sorgente: str, nome_file: str = "<sorgente>", *, semplice: bool = False, **opzioni: Any) -> str:
    """Gli avvisi gia' scritti (``""`` se non ce ne sono): per la riga di comando e il telefono."""
    try:
        lista = avvisi(sorgente, nome_file, **opzioni)
        return formatta_avvisi(lista, sorgente, semplice=semplice) if lista else ""
    except Exception:  # noqa: BLE001 - gli avvisi non devono mai fermare il programma
        return ""
