"""Pacchetti Leo puri: formato, registro, versioni ed estrazione sicura.

Un pacchetto Leo è una cartella (o un archivio ``.zip`` della cartella) con::

    meteo_facile/
        pacchetto.toml
        meteo_facile.leo        # il file importato da `importa meteo_facile`
        icone/sole.png          # altri file: dati, immagini, suoni, maschere

``pacchetto.toml``::

    [pacchetto]
    nome = "meteo_facile"
    versione = "1.2.0"
    descrizione = "Previsioni del tempo in due righe"
    autore = "Anna Rossi"
    licenza = "MIT"
    principale = "meteo_facile.leo"     # facoltativo: <nome>.leo o principale.leo
    permessi = ["rete"]                 # vedi leo.permessi_pacchetti

    [dipendenze]                        # pacchetti Python
    requests = ">=2.31"

    [dipendenze_leo]                    # altri pacchetti Leo
    unita_misura = ">=1.0"

Regole di sicurezza: un pacchetto Leo contiene solo codice Leo e dati (niente
programmi, script o librerie native) e all'installazione non si esegue niente:
si controlla l'impronta sha256, si estrae e basta.

Registro (``LEO_INDICE_LEO``, ``[registro] leo`` in progetto.toml o ``--indice-leo``):
una cartella o un indirizzo http(s) con ``<nome>/indice.json``::

    {"nome": "meteo_facile",
     "versioni": {"1.2.0": {"file": "meteo_facile-1.2.0.zip", "sha256": "...", "permessi": ["rete"]}}}

``file`` è relativo a ``<nome>/`` (o un indirizzo completo).
"""

from __future__ import annotations

import io
import json
import os
import re
import shutil
import stat
import tempfile
import urllib.parse
import urllib.request
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from .pacchetti_sicurezza import impronta_file

FILE_DESCRITTORE = "pacchetto.toml"
#: Estensioni ammesse in un pacchetto Leo (solo codice Leo e dati).
ESTENSIONI_AMMESSE = frozenset("""
.leo .dante .maschera .toml .json .csv .tsv .txt .md .ini .xml .yaml .yml
.png .jpg .jpeg .gif .bmp .webp .svg .ico .wav .mp3 .ogg .flac .mid .midi .ttf .otf .woff .woff2
.html .css .pdf .db .sqlite .glb .gltf .obj .mtl
""".split())
NOMI_SENZA_ESTENSIONE = frozenset({"LICENSE", "LICENZA", "COPYING", "NOTICE", "AUTHORS", "README", "LEGGIMI"})
#: Chiavi vietate in ``pacchetto.toml``: un pacchetto Leo non esegue nulla all'installazione.
CHIAVI_VIETATE = ("script", "installa", "dopo_installazione", "prima_installazione", "esegui", "comandi", "hook")
LIMITE_ARCHIVIO = 100 * 1024 * 1024          # byte scaricati
LIMITE_ESTRATTO = 200 * 1024 * 1024          # byte estratti
LIMITE_FILE = 5000

_RE_NOME = re.compile(r"^[a-z_][a-z0-9_]{1,63}$")
_RE_VERSIONE = re.compile(r"^\d+(\.\d+){0,3}([-.]?[a-z]+\d*)?$")


def _errore(messaggio: str, suggerimento: str | None = None) -> Exception:
    from .pacchetti import ErrorePacchetti

    return ErrorePacchetti(messaggio, suggerimento=suggerimento)


# ===========================================================================
# Versioni e vincoli
# ===========================================================================

def versione(testo: str) -> tuple:
    """``"1.2.10"`` -> ``(1, 2, 10, ...)`` confrontabile; le pre-release vengono prima."""
    testo = str(testo).strip().lower().lstrip("v")
    m = re.match(r"^(\d+(?:\.\d+)*)(.*)$", testo)
    if not m:
        raise _errore(f"`{testo}` non è una versione (per esempio `1.2.0`).")
    numeri = [int(x) for x in m.group(1).split(".")]
    while len(numeri) < 4:
        numeri.append(0)
    resto = m.group(2).strip(".-")
    return (*numeri, 0 if resto else 1, resto)


def soddisfa(ver: str, vincolo: str) -> bool:
    """La versione ``ver`` rispetta ``vincolo``? (``*``, ``1.2``, ``==1.2``, ``>=1,<2``, ``~=1.4``, ``^1.2``)."""
    vincolo = (vincolo or "*").strip()
    if vincolo in ("*", ""):
        return True
    v = versione(ver)
    for parte in vincolo.split(","):
        parte = parte.strip()
        m = re.match(r"^(==|!=|>=|<=|>|<|~=|\^)?\s*(.+)$", parte)
        if not m:
            raise _errore(f"Vincolo di versione non valido: `{parte}`.")
        op, valore = m.group(1) or "==", m.group(2)
        w = versione(valore)
        if op == "==" and v != w:
            return False
        if op == "!=" and v == w:
            return False
        if op == ">=" and v < w:
            return False
        if op == "<=" and v > w:
            return False
        if op == ">" and v <= w:
            return False
        if op == "<" and v >= w:
            return False
        if op in ("~=", "^"):
            numeri = [int(x) for x in re.findall(r"\d+", valore)]
            if v < w:
                return False
            if op == "^":
                prefisso = numeri[:1] if numeri[0] != 0 else numeri[:2]
            else:
                prefisso = numeri[:-1] if len(numeri) > 1 else numeri
            if list(v[:len(prefisso)]) != prefisso:
                return False
    return True


# ===========================================================================
# Descrittore
# ===========================================================================

@dataclass
class Descrittore:
    nome: str
    versione: str
    principale: str
    descrizione: str = ""
    autore: str = ""
    licenza: str = ""
    permessi: list[str] = field(default_factory=list)
    dipendenze: dict[str, str] = field(default_factory=dict)          # Python
    dipendenze_leo: dict[str, str] = field(default_factory=dict)


def leggi_descrittore(cartella: str | os.PathLike, *, origine: str = "") -> Descrittore:
    """Legge e controlla ``pacchetto.toml`` di un pacchetto già estratto."""
    from .permessi_pacchetti import controlla_dichiarati
    from .tomlutil import ErroreToml, carica_toml

    cartella = Path(cartella)
    dove = origine or str(cartella)
    file = cartella / FILE_DESCRITTORE
    if not file.is_file():
        raise _errore(f"`{dove}` non è un pacchetto Leo: manca `{FILE_DESCRITTORE}`.",
                      "Un pacchetto Leo è una cartella con `pacchetto.toml` e i suoi file `.leo`.")
    try:
        dati = carica_toml(file)
    except ErroreToml as e:
        raise _errore(f"`{FILE_DESCRITTORE}` di `{dove}` non è scritto bene: {e}") from None
    info = dati.get("pacchetto")
    if not isinstance(info, dict):
        raise _errore(f"`{FILE_DESCRITTORE}` di `{dove}` deve avere la sezione `[pacchetto]` con `nome` e `versione`.")
    for chiave in CHIAVI_VIETATE:
        if chiave in info or chiave in dati:
            raise _errore(f"Il pacchetto `{dove}` chiede di eseguire `{chiave}` all'installazione: rifiutato.",
                          "I pacchetti Leo non eseguono mai niente quando si installano: contengono solo "
                          "codice Leo e dati.")
    nome = str(info.get("nome", "")).strip()
    controlla_nome_leo(nome, dove)
    ver = str(info.get("versione", "")).strip()
    if not _RE_VERSIONE.match(ver.lower()):
        raise _errore(f"Il pacchetto `{nome}` ha una versione non valida: `{ver}` (per esempio `1.0.0`).")
    principale = str(info.get("principale", "")).strip()
    if not principale:
        principale = next((c for c in (f"{nome}.leo", "principale.leo") if (cartella / c).is_file()), f"{nome}.leo")
    if not _percorso_relativo_sicuro(principale):
        raise _errore(f"Il pacchetto `{nome}`: `principale` deve essere un file dentro il pacchetto.")
    if not (cartella / principale).is_file():
        raise _errore(f"Il pacchetto `{nome}` non contiene il file principale `{principale}`.")
    permessi = controlla_dichiarati(info.get("permessi", []), nome)
    dip = dati.get("dipendenze", {}) or {}
    dip_leo = dati.get("dipendenze_leo", {}) or {}
    if not isinstance(dip, dict) or not isinstance(dip_leo, dict):
        raise _errore(f"Il pacchetto `{nome}`: `[dipendenze]` e `[dipendenze_leo]` devono essere tabelle.")
    return Descrittore(nome=nome, versione=ver, principale=principale,
                       descrizione=str(info.get("descrizione", "")), autore=str(info.get("autore", "")),
                       licenza=str(info.get("licenza", "")), permessi=permessi,
                       dipendenze={str(k): str(v) for k, v in dip.items()},
                       dipendenze_leo={str(k): str(v) for k, v in dip_leo.items()})


def controlla_nome_leo(nome: str, dove: str = "") -> None:
    """Il nome di un pacchetto Leo: minuscole, cifre e ``_``; non uguale a un modulo della libreria."""
    if not _RE_NOME.match(nome or ""):
        raise _errore(f"`{nome}` non è un nome valido per un pacchetto Leo{' (' + dove + ')' if dove else ''}.",
                      "Usa lettere minuscole senza accenti, cifre e `_`, per esempio `meteo_facile`.")
    from .libreria import MODULI

    if nome in {m for m, _p in MODULI} or nome in ("python", "leo"):
        raise _errore(f"`{nome}` è già il nome di un modulo di Leo: un pacchetto non può chiamarsi così.")


def _percorso_relativo_sicuro(rel: str) -> bool:
    if not rel or rel.startswith(("/", "\\")) or re.match(r"^[A-Za-z]:", rel) or "\\" in rel:
        return False
    parti = rel.split("/")
    return all(p not in ("", ".", "..") for p in parti) and not any(ord(c) < 0x20 for c in rel)


def _file_ammesso(rel: str) -> bool:
    nome = rel.rsplit("/", 1)[-1]
    if nome.upper() in NOMI_SENZA_ESTENSIONE or nome == FILE_DESCRITTORE:
        return True
    base, punto, est = nome.rpartition(".")
    return bool(punto) and f".{est.lower()}" in ESTENSIONI_AMMESSE


# ===========================================================================
# Estrazione e copia sicure
# ===========================================================================

def estrai_archivio(dati: bytes, arrivo: Path, *, origine: str) -> None:
    """Estrae un archivio .zip di pacchetto in ``arrivo`` controllando ogni voce. Non esegue nulla."""
    try:
        z = zipfile.ZipFile(io.BytesIO(dati))
    except zipfile.BadZipFile:
        raise _errore(f"`{origine}` non è un archivio .zip valido.") from None
    voci = [v for v in z.infolist() if not v.is_dir()]
    if len(voci) > LIMITE_FILE:
        raise _errore(f"`{origine}` contiene troppi file ({len(voci)}).")
    nomi = [v.filename for v in voci]
    # archivio con una sola cartella in cima (meteo_facile-1.2.0/pacchetto.toml): la si toglie
    prefisso = ""
    if FILE_DESCRITTORE not in nomi:
        cime = {n.split("/", 1)[0] for n in nomi if "/" in n}
        if len(cime) == 1 and all("/" in n for n in nomi):
            prefisso = next(iter(cime)) + "/"
    totale = 0
    for v in voci:
        rel = v.filename[len(prefisso):] if v.filename.startswith(prefisso) else v.filename
        modo = (v.external_attr >> 16) & 0xFFFF
        if stat.S_ISLNK(modo):
            raise _errore(f"`{origine}` contiene un collegamento simbolico (`{v.filename}`): rifiutato.")
        if not _percorso_relativo_sicuro(rel):
            raise _errore(f"`{origine}` contiene un percorso pericoloso: `{v.filename}`.",
                          "Un pacchetto non può scrivere fuori dalla sua cartella.")
        if not _file_ammesso(rel):
            raise _errore(f"`{origine}` contiene `{rel}`, che non è codice Leo né un file di dati: rifiutato.",
                          "Un pacchetto Leo contiene solo file .leo, maschere, testi, dati, immagini, suoni e "
                          "caratteri: niente programmi o script.")
        totale += v.file_size
        if totale > LIMITE_ESTRATTO:
            raise _errore(f"`{origine}` estratto supera {LIMITE_ESTRATTO // (1024 * 1024)} MB: rifiutato.")
    arrivo.mkdir(parents=True, exist_ok=True)
    for v in voci:
        rel = v.filename[len(prefisso):] if v.filename.startswith(prefisso) else v.filename
        destinazione = arrivo / rel
        destinazione.parent.mkdir(parents=True, exist_ok=True)
        with z.open(v) as sorgente, open(destinazione, "wb") as f:
            letti = 0
            for pezzo in iter(lambda: sorgente.read(1 << 16), b""):
                letti += len(pezzo)
                if letti > v.file_size:            # dimensione dichiarata falsa (bomba zip)
                    raise _errore(f"`{origine}`: la voce `{rel}` è più grande di quanto dichiara.")
                f.write(pezzo)


def copia_cartella(origine: Path, arrivo: Path) -> None:
    """Copia un pacchetto locale (cartella) controllando i file, come per gli archivi."""
    if arrivo.exists():
        shutil.rmtree(arrivo)
    totale = 0
    conteggio = 0
    for p in sorted(origine.rglob("*")):
        rel = p.relative_to(origine).as_posix()
        if any(parte.startswith(".") or parte == "__pycache__" for parte in rel.split("/")):
            continue
        if p.is_symlink():
            raise _errore(f"Il pacchetto `{origine}` contiene un collegamento simbolico (`{rel}`): rifiutato.")
        if p.is_dir():
            continue
        if not _file_ammesso(rel):
            raise _errore(f"Il pacchetto `{origine}` contiene `{rel}`, che non è codice Leo né un file di dati.",
                          "Un pacchetto Leo contiene solo file .leo, maschere, testi, dati, immagini, suoni e "
                          "caratteri: niente programmi o script.")
        conteggio += 1
        totale += p.stat().st_size
        if conteggio > LIMITE_FILE or totale > LIMITE_ESTRATTO:
            raise _errore(f"Il pacchetto `{origine}` è troppo grande.")
        destinazione = arrivo / rel
        destinazione.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, destinazione)


# ===========================================================================
# Registro
# ===========================================================================

def leggi_url(indirizzo: str, *, limite: int = LIMITE_ARCHIVIO) -> bytes:
    """Contenuto di un file locale o di un indirizzo http(s)/file://."""
    analisi = urllib.parse.urlparse(indirizzo)
    if analisi.scheme in ("", "file") or re.match(r"^[A-Za-z]:[\\/]", indirizzo):
        percorso = urllib.request.url2pathname(analisi.path) if analisi.scheme == "file" else indirizzo
        try:
            if os.path.getsize(percorso) > limite:
                raise _errore(f"`{indirizzo}` è troppo grande.")
            with open(percorso, "rb") as f:
                return f.read()
        except OSError as e:
            raise _errore(f"Non riesco a leggere `{indirizzo}`: {e.strerror or e}.") from None
    if analisi.scheme not in ("http", "https"):
        raise _errore(f"Indirizzo non supportato: `{indirizzo}` (servono http, https o una cartella).")
    richiesta = urllib.request.Request(indirizzo, headers={"User-Agent": "Leo-pacchetti/1"})
    try:
        with urllib.request.urlopen(richiesta, timeout=60) as risposta:  # noqa: S310 - http/https soltanto
            dati = risposta.read(limite + 1)
    except Exception as e:  # noqa: BLE001
        raise _errore(f"Non riesco a scaricare `{indirizzo}`: {e}.",
                      "Controlla la connessione e l'indirizzo del registro.") from None
    if len(dati) > limite:
        raise _errore(f"`{indirizzo}` è troppo grande.")
    return dati


def _unisci(base: str, *parti: str) -> str:
    if re.match(r"^https?://", base):
        return base.rstrip("/") + "/" + "/".join(urllib.parse.quote(p) for p in parti)
    return os.path.join(base, *parti)


@dataclass
class Scelta:
    """Una versione di un pacchetto Leo scelta dal registro."""

    nome: str
    versione: str
    url: str
    sha256: str
    permessi: list[str]


def scegli_dal_registro(registro: str, nome: str, vincolo: str) -> Scelta:
    """La versione più alta di ``nome`` che rispetta ``vincolo``."""
    if not registro:
        raise _errore(f"Per installare il pacchetto Leo `{nome}` serve un registro.",
                      "Indica una cartella o un indirizzo con `--indice-leo`, con la variabile LEO_INDICE_LEO "
                      "o in progetto.toml (`[registro]` `leo = \"...\"`); per un pacchetto sul disco scrivi "
                      "il suo percorso: `leo aggiungi ./meteo_facile`.")
    indirizzo = _unisci(registro, nome, "indice.json")
    try:
        indice = json.loads(leggi_url(indirizzo, limite=4 * 1024 * 1024).decode("utf-8"))
    except Exception as e:  # noqa: BLE001
        if getattr(e, "messaggio", "").startswith("Non riesco a"):
            raise _errore(f"Il pacchetto Leo `{nome}` non è nel registro `{registro}`.") from None
        raise _errore(f"L'indice del pacchetto `{nome}` nel registro non è valido: {e}.") from None
    versioni = indice.get("versioni") if isinstance(indice, dict) else None
    if not isinstance(versioni, dict) or not versioni:
        raise _errore(f"L'indice del pacchetto `{nome}` non elenca nessuna versione.")
    candidate = sorted((v for v in versioni if soddisfa(v, vincolo)), key=versione, reverse=True)
    if not candidate:
        raise _errore(f"Nessuna versione di `{nome}` rispetta `{vincolo}`.",
                      "Versioni disponibili: " + ", ".join(sorted(versioni, key=versione)) + ".")
    scelta = candidate[0]
    voce = versioni[scelta]
    sha = str(voce.get("sha256", "")).lower()
    if not re.fullmatch(r"[0-9a-f]{64}", sha):
        raise _errore(f"Il registro non dà l'impronta sha256 di `{nome}` {scelta}: non lo installo.",
                      "Le impronte sono obbligatorie: chiedi a chi gestisce il registro di aggiungerla.")
    file = str(voce.get("file", ""))
    url = file if re.match(r"^https?://", file) else _unisci(registro, nome, file)
    return Scelta(nome=nome, versione=scelta, url=url, sha256=sha, permessi=list(voce.get("permessi", [])))


def scarica_ed_estrai(scelta_o_url: Any, sha256: str, arrivo: Path, *, origine: str) -> None:
    """Scarica l'archivio, controlla l'impronta (obbligatoria) e lo estrae in ``arrivo``."""
    import hashlib

    from .pacchetti_sicurezza import controlla_impronta

    url = scelta_o_url.url if isinstance(scelta_o_url, Scelta) else str(scelta_o_url)
    dati = leggi_url(url)
    controlla_impronta(sha256, hashlib.sha256(dati).hexdigest(), origine)
    temporanea = Path(tempfile.mkdtemp(prefix=".nuovo_", dir=str(arrivo.parent)))
    try:
        estrai_archivio(dati, temporanea, origine=origine)
        if arrivo.exists():
            shutil.rmtree(arrivo)
        os.replace(temporanea, arrivo)
    except BaseException:
        shutil.rmtree(temporanea, ignore_errors=True)
        raise


def impronta_locale(percorso: Path) -> str:
    """Impronta di un pacchetto locale: del file .zip o del contenuto della cartella."""
    if percorso.is_file():
        return impronta_file(percorso)
    return impronta_cartella_pacchetto(percorso)


def impronta_cartella_pacchetto(cartella: Path) -> str:
    """Come :func:`impronta_cartella`, ignorando file e cartelle nascosti e ``__pycache__``."""
    import hashlib

    h = hashlib.sha256()
    for p in sorted(cartella.rglob("*")):
        rel = p.relative_to(cartella).as_posix()
        if p.is_dir() or any(parte.startswith(".") or parte == "__pycache__" for parte in rel.split("/")):
            continue
        h.update(rel.encode("utf-8") + b"\0" + impronta_file(p).encode("ascii") + b"\n")
    return h.hexdigest()


def crea_archivio(cartella: str | os.PathLike, uscita: str | os.PathLike | None = None) -> tuple[Path, str]:
    """Crea ``<nome>-<versione>.zip`` di un pacchetto (per pubblicarlo in un registro): (file, sha256)."""
    cartella = Path(cartella)
    d = leggi_descrittore(cartella)
    uscita = Path(uscita) if uscita else cartella.parent
    uscita.mkdir(parents=True, exist_ok=True)
    archivio = uscita / f"{d.nome}-{d.versione}.zip"
    with zipfile.ZipFile(archivio, "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(cartella.rglob("*")):
            rel = p.relative_to(cartella).as_posix()
            if p.is_dir() or any(parte.startswith(".") or parte == "__pycache__" for parte in rel.split("/")):
                continue
            if not _file_ammesso(rel):
                raise _errore(f"`{rel}` non può stare in un pacchetto Leo.")
            info = zipfile.ZipInfo(rel, date_time=(2020, 1, 1, 0, 0, 0))   # archivio riproducibile
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            z.writestr(info, p.read_bytes())
    return archivio, impronta_file(archivio)


__all__ = ["Descrittore", "Scelta", "crea_archivio", "copia_cartella", "controlla_nome_leo", "estrai_archivio",
           "impronta_cartella_pacchetto", "impronta_locale", "leggi_descrittore", "leggi_url", "scarica_ed_estrai",
           "scegli_dal_registro", "soddisfa", "versione"]
