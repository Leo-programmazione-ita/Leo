"""Compilazione di un programma o di un progetto in un eseguibile Windows autonomo.

Uso dalla riga di comando::

    leo compila programma.leo
    leo compila CartellaProgetto --uscita C:\\Consegne --nome Rubrica --icona rubrica.ico
    leo compila CartellaProgetto --console        # anche la console (utile per i messaggi di stampa)
    leo compila CartellaProgetto --un-file        # un solo .exe (si decomprime a ogni avvio: più lento)
    leo compila programma.leo --installa         # installa PyInstaller se manca (chiede conferma)
    leo compila Rubrica --autore "Anna Rossi" --versione-programma 1.2   # Proprietà dell'exe
    leo compila Rubrica --firma certificato.pfx  # firma digitale (password: LEO_PASSWORD_CERTIFICATO)
    leo compila Rubrica --upx                    # comprime con UPX, se l'eseguibile upx è nel PATH
    leo compila Rubrica --senza-schermata-avvio  # niente icona su fondo nero mentre il programma parte
    leo compila programma.leo --apk              # app Android (.apk): vedi leo/apk.py

Come funziona. La compilazione ha due fasi ben separate:

1. **Preparazione** (pura, senza PyInstaller): si controlla il programma (errori di
   sintassi, maschere, file mancanti), si crea una *cartella di lavoro* con

   * ``avvio_programma.py``  - il piccolo programma Python di avvio (``MODELLO_AVVIO``);
   * ``avvio.json``          - che cosa avviare (file o progetto, modalità, icona);
   * ``leo/``                - copia dell'interprete (senza Studio, lezioni, sfide, compilatore, REPL);
   * ``dati/``               - sinonimi, vocabolario, temi, stemma (solo ciò che serve a runtime);
   * ``programma/``          - i sorgenti del programma o del progetto (maschere,
     ``.leo``, immagini, suoni, ``progetto.toml``);
   * ``risorse/icona.ico``   - l'icona, usata anche per le finestre;
   * ``versione_windows.txt`` - la risorsa di versione (Proprietà > Dettagli dell'exe):
     nome del programma, descrizione, autore del programma se indicato, "Creato con Leo";
   * ``costruisci_eseguibile.py`` + ``filtro_binari.json`` - avviano PyInstaller togliendo
     dai file raccolti le DLL, i plugin e le traduzioni di Qt che il programma non usa
     (``MODELLO_COSTRUZIONE``, regole di :func:`regole_filtro`).

   Il programma di avvio funziona anche senza PyInstaller: ``python avvio_programma.py``
   dalla cartella di lavoro esegue il programma esattamente come farà l'eseguibile.

2. **Invocazione di PyInstaller** con gli argomenti calcolati da
   :func:`argomenti_pyinstaller`: una cartella (predefinita, avvio veloce) o un solo file,
   finestra o console, icona, dati inclusi, moduli nascosti (l'interprete importa parti
   della libreria per nome), moduli esclusi (Leo Studio, e di PySide6 tutto ciò che il
   programma non usa; PySide6 intero per i programmi solo testuali), ``--optimize``.

Schermata di avvio. I programmi con finestre mostrano, appena PySide6 è caricato,
una schermata leggera su fondo nero con l'icona del programma e il suo nome; sparisce
da sola (dissolvenza breve) quando compare la prima finestra del programma. È la
sorella piccola di quella di Leo Studio: niente animazioni, nessun file in più,
nessun ritardo (non ha una durata minima). ``--senza-schermata-avvio`` la toglie.
Lo splash nativo di PyInstaller (``--splash``, che comparirebbe ancora prima) NON si
usa per i programmi: richiede Tcl/Tk nel Python che compila (spesso manca negli
ambienti virtuali), aggiunge alcuni MB e con la cartella unica può rubare il primo
piano alla finestra del programma; Leo Studio e l'installatore invece lo usano
(vedi ``strumenti/distribuzione/costruisci.py``).

Alla fine: firma facoltativa (``leo.firma.firma_eseguibile``) e un rapporto con dimensione,
cartella, parti incluse ed escluse (:class:`Rapporto`).

API (usata anche da Leo Studio):
    compila_progetto(percorso, *, uscita=None, nome=None, icona=None, modalita=None,
                     un_file=False, avvisa=print, autore=None, descrizione=None,
                     versione=None, upx=False, filtra=True, ottimizza=None,
                     certificato=None, password_certificato=None, ...) -> Path
    analizza_programma(percorso, *, nome=None, modalita=None, con_grafica=None, uscita=None) -> Piano
    prepara_cartella(piano, lavoro, *, icona=None, un_file=False, autore=None,
                     descrizione=None, versione=None, filtra=True, ottimizza=None,
                     upx_dir=None) -> Preparazione
    regole_filtro(piano) -> dict;  da_scartare(nome, regole) -> bool
    testo_versione_windows(nome_file, *, titolo, autore, descrizione, versione) -> str
    argomenti_pyinstaller(preparazione, *, uscita, sistema=None, versione_pyinstaller=None) -> list[str]
    crea_rapporto(preparazione, eseguibile, *, tolti=(), firma=None) -> Rapporto
    comando_compila(argv) -> int                                   # `leo compila ...`
    (``--apk`` passa a ``leo.apk.crea_apk``: app Android senza PyInstaller, Gradle o SDK)
    ErroreCompilazione, PyInstallerMancante
"""

from __future__ import annotations

import fnmatch
import inspect
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence

from . import NOME, __version__, e_sorgente, nomi_file_modulo

# ---------------------------------------------------------------------------
# Costanti
# ---------------------------------------------------------------------------

#: Nome dello script di avvio nella cartella di lavoro (è anche lo script di PyInstaller).
NOME_SCRIPT_AVVIO = "avvio_programma.py"
#: File di configurazione letto dallo script di avvio.
NOME_CONFIGURAZIONE = "avvio.json"
#: Risorsa di versione di Windows (``--version-file`` di PyInstaller).
NOME_FILE_VERSIONE = "versione_windows.txt"
#: Sottocartelle della cartella di lavoro (e, con gli stessi nomi, dentro l'eseguibile).
CARTELLA_PROGRAMMA = "programma"
CARTELLA_DATI = "dati"
CARTELLA_RISORSE = "risorse"

MODALITA = ("finestra", "console")

#: Cartelle mai incluse quando si copia un progetto.
CARTELLE_ESCLUSE = frozenset({
    ".git", ".hg", ".svn", "__pycache__", ".venv", "venv", "env", "node_modules",
    ".idea", ".vscode", "build", "dist", "eseguibile", "app_android",
})
#: Estensioni mai incluse (prodotti di compilazione, temporanei).
ESTENSIONI_ESCLUSE = frozenset({".exe", ".spec", ".pyc", ".pyo", ".log", ".tmp", ".lnk", ".apk"})
#: File di dati che il programma potrebbe leggere con un percorso relativo:
#: dopo la compilazione vengono copiati anche accanto all'eseguibile.
ESTENSIONI_DATI = frozenset({".txt", ".csv", ".json", ".db", ".sqlite", ".sqlite3", ".xml", ".dat", ".ini"})
#: Estensioni che, come valore di una proprietà di una maschera, indicano un file da includere.
ESTENSIONI_RISORSE = frozenset({
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".svg", ".webp",
    ".wav", ".mp3", ".ogg", ".mp4", ".avi", ".mov", ".webm", ".m4a",
}) | ESTENSIONI_DATI

#: Oltre questa dimensione un singolo file del progetto non viene incluso (con avviso).
LIMITE_FILE = 200 * 1024 * 1024
#: Oltre questa dimensione totale si avvisa che l'eseguibile sarà grande.
SOGLIA_AVVISO_TOTALE = 100 * 1024 * 1024

#: Parti di ``dati/`` che un programma compilato non usa mai (nomi a qualunque livello).
#: ``thesaurus.dat`` (anche decine di MB) serve solo ai suggerimenti "forse intendevi"
#: dei messaggi d'errore: il programma è già stato controllato, quindi non si include.
#: I sinonimi delle parole chiave (``sinonimi.toml``) invece restano: il lessico li usa.
#: Come nell'app per il telefono (``android/prepara_sorgenti.py``) restano fuori anche i
#: cursori rossi di Leo Studio (3 MB di immagini), gli script che generano il leone e
#: ``caratteri`` (solo un LEGGIMI).
DATI_ESCLUSI = frozenset({"lezioni", "studio", "proposte", "__pycache__", "thesaurus.dat",
                          "stemma.py", "stemma_512.png", "stemma_1024.png", "stemma.svg", "dante.ico",
                          "avvio_studio.png", "cursori", "leone", "caratteri",
                          "galleria"})   # della galleria vanno solo gli elementi usati (galleria/ del programma)
#: Parti di ``dati/`` usate solo dalla grafica (stemma, comuni italiani per i controlli,
#: programma MicroPython della Pico): escluse dai programmi solo testuali.
DATI_SOLO_GRAFICI = frozenset({"icone", "italia", "pico"})
#: ``dati/pico`` serve solo ai controlli della scheda Pico (gruppo "seriale").
DATI_SOLO_SERIALE = frozenset({"pico"})

#: Moduli di PySide6 che nessun programma Leo usa: sempre esclusi (eseguibile più piccolo).
MODULI_QT_ESCLUSI = (
    "PySide6.Qt3DAnimation", "PySide6.Qt3DCore", "PySide6.Qt3DExtras", "PySide6.Qt3DInput",
    "PySide6.Qt3DLogic", "PySide6.Qt3DRender", "PySide6.QtAxContainer", "PySide6.QtBluetooth",
    "PySide6.QtCharts", "PySide6.QtConcurrent", "PySide6.QtDataVisualization", "PySide6.QtDBus",
    "PySide6.QtDesigner", "PySide6.QtGraphs", "PySide6.QtGraphsWidgets", "PySide6.QtHelp",
    "PySide6.QtHttpServer", "PySide6.QtLocation", "PySide6.QtNetworkAuth", "PySide6.QtNfc",
    "PySide6.QtOpenGL", "PySide6.QtOpenGLWidgets", "PySide6.QtPdf", "PySide6.QtPdfWidgets",
    "PySide6.QtPositioning", "PySide6.QtPrintSupport", "PySide6.QtQml", "PySide6.QtQuick",
    "PySide6.QtQuick3D", "PySide6.QtQuickControls2", "PySide6.QtQuickTest", "PySide6.QtQuickWidgets",
    "PySide6.QtRemoteObjects", "PySide6.QtScxml", "PySide6.QtSensors", "PySide6.QtSerialBus",
    "PySide6.QtSerialPort", "PySide6.QtSpatialAudio", "PySide6.QtSql", "PySide6.QtStateMachine",
    "PySide6.QtTest", "PySide6.QtUiTools", "PySide6.QtWebChannel", "PySide6.QtWebEngineCore",
    "PySide6.QtWebEngineQuick", "PySide6.QtWebEngineWidgets", "PySide6.QtWebSockets", "PySide6.QtWebView",
    "PySide6.QtXml", "PySide6.QtSvgWidgets", "PySide6.QtAsyncio",
)

#: Moduli facoltativi (di PySide6 o di terze parti): inclusi solo se il programma usa uno
#: di questi controlli; altrimenti esclusi, per un eseguibile più piccolo.
MODULI_QT_FACOLTATIVI: dict[str, tuple[tuple[str, ...], frozenset[str]]] = {
    "multimedia": (("PySide6.QtMultimedia", "PySide6.QtMultimediaWidgets"),
                   frozenset({"Video", "Suono", "Fotocamera", "LettoreQR"})),
    "voce": (("PySide6.QtTextToSpeech",), frozenset({"Voce", "Assistente"})),
    "rete": (("PySide6.QtNetwork",), frozenset({"Mappa"})),
    # non di Qt, ma usati solo da questi controlli (e pesanti, se installati)
    "qr": (("pyzbar", "cv2", "numpy"), frozenset({"LettoreQR"})),
    "seriale": (("serial",), frozenset({"SchedaPico", "Led", "PulsanteFisico", "Sensore",
                                        "Oscilloscopio", "PortaSeriale"})),
}

#: Gruppi che ne richiedono altri. I moduli di PySide6 importano all'avvio quelli da cui
#: dipendono: QtMultimedia importa QtNetwork, QtTextToSpeech (Qt >= 6.6) importa
#: QtMultimedia. Escludere la dipendenza farebbe fallire l'import (e, siccome Leo li
#: importa in modo protetto, il controllo sparirebbe senza errori).
DIPENDENZE_GRUPPI: dict[str, tuple[str, ...]] = {
    "multimedia": ("rete",),
    "voce": ("multimedia",),
    "qr": ("multimedia",),
}

#: Moduli di PySide6 che non vanno MAI esclusi: PyInstaller, tramite i loro hook, include
#: i plugin necessari (platforms, styles, imageformats, iconengines, platformthemes).
MODULI_QT_ESSENZIALI = ("PySide6", "PySide6.QtCore", "PySide6.QtGui", "PySide6.QtWidgets",
                        "PySide6.QtSvg", "shiboken6")

#: Sottopacchetti di ``leo`` caricati anche per nome (``importlib``): oltre ai singoli
#: ``--hidden-import`` si passano a ``--collect-submodules``. Quelli grafici solo con PySide6.
PACCHETTI_DINAMICI = ("leo.libreria", "leo.grafica.servizi")
PACCHETTI_DINAMICI_GRAFICI = ("leo.grafica", "leo.grafica.qt")

#: Versione minima di PyInstaller consigliata (struttura ``_internal``, Python 3.12).
VERSIONE_PYINSTALLER_MINIMA = (6, 0)

#: Moduli della libreria standard che un programma Leo non usa (verificato sugli import di
#: ``leo`` senza Studio). ``email``, ``http`` e ``urllib`` restano: li importano
#: ``xml.sax.saxutils`` (tartaruga) e i controlli di rete.
MODULI_PYTHON_ESCLUSI = ("tkinter", "_tkinter", "turtle", "turtledemo", "unittest", "test", "idlelib",
                         "lib2to3", "pydoc", "pydoc_data", "doctest", "distutils", "setuptools",
                         "pkg_resources", "pip", "ensurepip", "venv", "xmlrpc", "curses", "_curses",
                         "lzma", "_lzma", "bz2", "_bz2")
#: Nota: ``ssl``, ``sqlite3`` e ``email`` NON si escludono nemmeno dai programmi testuali:
#: la libreria (``internet``, ``database``) li importa; quei moduli della libreria sono
#: pigri (``leo/libreria/_indice.py``: si importano alla prima chiamata di una loro
#: funzione, come sul telefono), ma le funzioni si chiamano per nome, quindi devono esserci.

#: Parti del pacchetto ``leo`` mai incluse nell'eseguibile: l'ambiente di sviluppo, le
#: lezioni e le sfide, il compilatore stesso, la firma, il REPL e la spiegazione del codice
#: (``leo.cli`` li importa solo per i rispettivi comandi, mai per eseguire un programma).
#: ``leo.apk`` crea le app Android: lo usa solo ``leo compila --apk``.
PACCHETTI_LEO_ESCLUSI = ("leo.studio", "leo.lezioni", "leo.sfide", "leo.compila", "leo.firma",
                         "leo.repl", "leo.spiega", "leo.licenza", "leo.apk")
#: Parti di ``leo`` escluse dai programmi solo testuali. ``leo.grafica`` (puro) e
#: ``leo.grafica.servizi`` restano: li usano la libreria (colori, forme, banca dati, rete).
PACCHETTI_LEO_SOLO_GRAFICI = ("leo.grafica.qt",)

#: Livello di ottimizzazione del bytecode (``--optimize`` di PyInstaller >= 6.6): 2 toglie
#: ``assert`` e docstring (Leo non li usa per far funzionare i programmi).
OTTIMIZZAZIONE_PREDEFINITA = 2
VERSIONE_PYINSTALLER_OPTIMIZE = (6, 6)

#: Variabile d'ambiente con la password del certificato (meglio che scriverla nel comando).
VARIABILE_PASSWORD = "LEO_PASSWORD_CERTIFICATO"

#: File della cartella di lavoro per il filtro dei binari.
NOME_SCRIPT_COSTRUZIONE = "costruisci_eseguibile.py"
NOME_FILTRO = "filtro_binari.json"
NOME_RAPPORTO_FILTRO = "filtro_rapporto.json"

#: File che UPX non deve comprimere: runtime di Visual C++, Python, il plugin delle
#: finestre e le librerie di PySide6 (compressi si rompono o allarmano gli antivirus).
ESCLUSI_UPX = ("vcruntime140.dll", "vcruntime140_1.dll", "msvcp140.dll", "msvcp140_1.dll",
               "msvcp140_2.dll", "python3.dll", f"python3{sys.version_info[1]}.dll", "qwindows.dll",
               "qmodernwindowsstyle.dll", "qwindowsvistastyle.dll", "pyside6.abi3.dll",
               "shiboken6.abi3.dll")

#: Funzioni della tartaruga: un programma testuale che le usa apre una finestra (serve PySide6).
FUNZIONI_TARTARUGA = frozenset({
    "avanti", "indietro", "penna_su", "penna_giu", "penna_giù", "mostra_disegno", "punta_verso",
    "vai_a", "nascondi_tartaruga", "mostra_tartaruga", "riempi", "fine_riempi", "scrivi_qui",
    "colore_casuale", "pulisci_disegno",
})

_NOMI_RISERVATI_WINDOWS = frozenset(
    {"CON", "PRN", "AUX", "NUL"} | {f"COM{i}" for i in range(1, 10)} | {f"LPT{i}" for i in range(1, 10)})

_RE_IMPORTA_TESTO = re.compile(r'^[ \t]*importa[ \t]+"([^"\n]+)"', re.MULTILINE)
_RE_IMPORTA_NOME = re.compile(r'^[ \t]*importa[ \t]+([^\W\d]\w*)', re.MULTILINE)


# ---------------------------------------------------------------------------
# Errori
# ---------------------------------------------------------------------------

class ErroreCompilazione(Exception):
    """La compilazione non si può fare: ``messaggio`` spiega perché (in italiano).

    ``codice`` è il codice d'uscita del comando: 1 (errore) o 2 (uso sbagliato).
    """

    def __init__(self, messaggio: str, *, codice: int = 1) -> None:
        super().__init__(messaggio)
        self.messaggio = messaggio
        self.codice = codice


class PyInstallerMancante(ErroreCompilazione):
    """PyInstaller non è installato nell'ambiente Python di Leo."""


# ---------------------------------------------------------------------------
# Piccoli aiuti puri
# ---------------------------------------------------------------------------

def nome_valido(nome: str) -> str:
    """Nome di file accettabile su Windows per l'eseguibile (senza estensione).

    Sostituisce i caratteri vietati con ``_``, toglie punti e spazi finali,
    evita i nomi riservati (``CON``, ``COM1``...) e limita la lunghezza.
    """
    testo = "".join("_" if (c in '<>:"/\\|?*' or ord(c) < 32) else c for c in str(nome or ""))
    testo = testo.strip().rstrip(". ").strip()
    if testo.lower().endswith(".exe"):
        testo = testo[:-4].rstrip(". ")
    if not testo or set(testo) <= {"_", "."}:
        testo = "Programma"
    if testo.split(".")[0].upper() in _NOMI_RISERVATI_WINDOWS:
        testo = testo + "_"
    return testo[:64].rstrip(". ") or "Programma"


def formatta_dimensione(byte: int) -> str:
    """Dimensione leggibile, con la virgola decimale: ``845 KB``, ``12,4 MB``."""
    if byte < 1024:
        return f"{byte} byte"
    if byte < 1024 * 1024:
        return f"{byte / 1024:.0f} KB"
    if byte < 1024 ** 3:
        return f"{byte / 1024 / 1024:.1f} MB".replace(".", ",")
    return f"{byte / 1024 ** 3:.2f} GB".replace(".", ",")


def dimensione_cartella(cartella: Path) -> int:
    totale = 0
    for radice, _cartelle, file in os.walk(cartella):
        for nome in file:
            try:
                totale += os.path.getsize(os.path.join(radice, nome))
            except OSError:
                pass
    return totale


def separatore_dati(sistema: str | None = None) -> str:
    """Separatore di ``--add-data`` di PyInstaller: ``;`` su Windows, ``:`` altrove."""
    return ";" if (sistema or os.name) == "nt" else ":"


def _testo_risorsa(testo: Any, massimo: int = 200) -> str:
    """Testo adatto a una voce della risorsa di versione: una riga, niente caratteri di controllo."""
    pulito = " ".join("".join(c if ord(c) >= 32 and c != "\x7f" else " " for c in str(testo or "")).split())
    return pulito[:massimo].rstrip()


def numeri_versione(versione: Any) -> tuple[int, int, int, int]:
    """``"1.2"`` -> ``(1, 2, 0, 0)``; ``"2.0 beta"`` -> ``(2, 0, 0, 0)``; vuota o strana -> ``(1, 0, 0, 0)``.

    Windows vuole quattro numeri da 0 a 65535.
    """
    numeri = [int(n) for n in re.findall(r"\d+", str(versione or ""))[:4]]
    if not numeri:
        return (1, 0, 0, 0)
    numeri = [min(n, 65535) for n in numeri] + [0] * (4 - len(numeri))
    return (numeri[0], numeri[1], numeri[2], numeri[3])


def testo_versione_windows(nome_file: str, *, titolo: str = "", autore: str = "", descrizione: str = "",
                           versione: str = "", anno: int | None = None) -> str:
    """Contenuto del file di versione per ``pyinstaller --version-file`` (``VSVersionInfo``).

    Sono i dati mostrati da Windows in *Proprietà > Dettagli* dell'eseguibile:
    ProductName (``titolo``), FileDescription (``descrizione`` o il titolo),
    CompanyName e LegalCopyright (solo se c'è ``autore``: il programma è di chi lo ha
    scritto, non di chi ha scritto Leo), Comments = "Creato con Leo".

    Il testo è un'espressione Python che PyInstaller valuta: le stringhe sono scritte con
    ``ascii()``, quindi il file è ASCII puro (accenti e © come ``\\xe0``, ``\\xa9``) e non
    dipende dalla codifica con cui viene letto.
    """
    import datetime

    titolo = _testo_risorsa(titolo) or _testo_risorsa(nome_file) or "Programma"
    autore = _testo_risorsa(autore)
    descrizione = _testo_risorsa(descrizione, 500) or titolo
    numeri = numeri_versione(versione)
    testo_numeri = ".".join(str(n) for n in numeri)
    anno = anno or datetime.date.today().year
    voci: list[tuple[str, str]] = []
    if autore:
        voci.append(("CompanyName", autore))
    voci += [
        ("FileDescription", descrizione),
        ("FileVersion", testo_numeri),
        ("InternalName", _testo_risorsa(nome_file) or titolo),
    ]
    if autore:
        voci.append(("LegalCopyright", f"Copyright © {anno} {autore}"))
    voci += [
        ("OriginalFilename", (_testo_risorsa(nome_file) or titolo) + ".exe"),
        ("ProductName", titolo),
        ("ProductVersion", testo_numeri),
        ("Comments", f"Creato con {NOME}"),
    ]
    righe_voci = ",\n".join(f"          StringStruct({ascii(k)}, {ascii(v)})" for k, v in voci)
    tupla = f"({numeri[0]}, {numeri[1]}, {numeri[2]}, {numeri[3]})"
    # 0x0410 = italiano, 1200 (0x04B0) = Unicode: la tabella si chiama "041004B0".
    return (
        "# UTF-8\n"
        f"# Risorsa di versione generata da `{NOME.lower()} compila`: non modificarla a mano.\n"
        "VSVersionInfo(\n"
        "  ffi=FixedFileInfo(\n"
        f"    filevers={tupla},\n"
        f"    prodvers={tupla},\n"
        "    mask=0x3f,\n"
        "    flags=0x0,\n"
        "    OS=0x40004,\n"
        "    fileType=0x1,\n"
        "    subtype=0x0,\n"
        "    date=(0, 0)\n"
        "  ),\n"
        "  kids=[\n"
        "    StringFileInfo(\n"
        "      [\n"
        "        StringTable(\n"
        "          '041004B0',\n"
        "          [\n"
        f"{righe_voci}\n"
        "          ])\n"
        "      ]),\n"
        "    VarFileInfo([VarStruct('Translation', [0x0410, 1200])])\n"
        "  ]\n"
        ")\n"
    )


def _cartella_pacchetto() -> Path:
    return Path(__file__).resolve().parent


def _e_dentro(percorso: Path, cartella: Path) -> bool:
    try:
        percorso.resolve().relative_to(cartella.resolve())
        return True
    except (ValueError, OSError):
        return False


# ---------------------------------------------------------------------------
# Analisi del programma
# ---------------------------------------------------------------------------

@dataclass
class Piano:
    """Che cosa compilare: risultato di :func:`analizza_programma` (nessun file scritto)."""

    tipo: str                                  # "file" oppure "progetto"
    sorgente: Path                             # file .leo o cartella del progetto
    cartella: Path                             # cartella che contiene i file del programma
    nome: str                                  # nome dell'eseguibile (già valido)
    modalita: str                              # "finestra" oppure "console"
    avvio: str                                 # percorso relativo del file da avviare ("" = progetto)
    file: list[tuple[Path, str]] = field(default_factory=list)   # (origine, percorso relativo)
    con_grafica: bool = False                  # includere PySide6
    moduli_qt: list[str] = field(default_factory=list)           # moduli Qt facoltativi inclusi
    tipi_controlli: set[str] = field(default_factory=set)
    file_dati: list[str] = field(default_factory=list)           # da copiare accanto all'exe
    avvisi: list[str] = field(default_factory=list)
    # Informazioni per la risorsa di versione di Windows (Proprietà > Dettagli dell'exe).
    titolo: str = ""                           # nome leggibile del programma (ProductName)
    autore: str = ""                           # CompanyName / LegalCopyright ("" = omessi)
    descrizione: str = ""                      # FileDescription ("" = il titolo)
    versione: str = ""                         # es. "1.2" ("" = 1.0.0.0)
    # pacchetti aggiunti con `leo aggiungi` (leo.lock): leo.pacchetti.PartiDipendenze o None
    dipendenze: Any = None

    @property
    def e_progetto(self) -> bool:
        return self.tipo == "progetto"

    @property
    def dimensione_file(self) -> int:
        totale = 0
        for origine, _rel in self.file:
            try:
                totale += origine.stat().st_size
            except OSError:
                pass
        return totale


def _leggi_testo(percorso: Path) -> str:
    try:
        with open(percorso, "r", encoding="utf-8-sig") as f:
            return f.read()
    except UnicodeDecodeError:
        raise ErroreCompilazione(
            f"Il file `{percorso.name}` non è scritto in UTF-8: aprilo con Leo Studio e salvalo di nuovo.") from None
    except OSError as e:
        raise ErroreCompilazione(f"Non riesco a leggere `{percorso}`: {e.strerror or e}.") from None


def _moduli_importati(sorgente: str, cartella: Path) -> list[Path]:
    """File ``.leo`` importati da un sorgente (``importa "x.leo"`` o ``importa x``) che esistono."""
    trovati: list[Path] = []
    for nome in _RE_IMPORTA_TESTO.findall(sorgente):
        nome = nome.strip().replace("\\", "/")
        for candidato in nomi_file_modulo(nome):
            p = Path(candidato) if os.path.isabs(candidato) else cartella / candidato
            if p.is_file():
                trovati.append(p)
                break
    for nome in _RE_IMPORTA_NOME.findall(sorgente):
        for candidato in nomi_file_modulo(nome):
            p = cartella / candidato
            if p.is_file():
                trovati.append(p)
                break
    return trovati


def _informazioni_progetto(cartella: Path) -> dict[str, str]:
    """``autore``, ``descrizione`` e ``versione`` facoltativi della sezione ``[progetto]``."""
    try:
        from .tomlutil import carica_toml

        info = carica_toml(cartella / "progetto.toml").get("progetto", {})
    except Exception:  # noqa: BLE001 - file già controllato altrove; qui sono solo extra
        return {}
    if not isinstance(info, dict):
        return {}
    risultato: dict[str, str] = {}
    for chiave in ("autore", "descrizione", "versione"):
        valore = info.get(chiave)
        if isinstance(valore, list):                   # autore = ["Anna", "Bruno"]
            valore = ", ".join(str(v) for v in valore)
        if isinstance(valore, (str, int, float)) and str(valore).strip():
            risultato[chiave] = str(valore).strip()
    return risultato


def _usa_tartaruga(sorgente: str) -> bool:
    for nome in re.findall(r"([^\W\d]\w*)\s*\(", sorgente):
        if nome in FUNZIONI_TARTARUGA:
            return True
    return False


def _opzioni_lessico_progetto(progetto: Any) -> dict[str, Any]:
    opzioni: dict[str, Any] = {"stile": progetto.stile, "rigoroso": bool(progetto.rigoroso)}
    if progetto.sinonimi:
        opzioni["dizionari_sinonimi"] = [progetto.sinonimi]
    if progetto.file_sinonimi:
        opzioni["sinonimi_extra"] = [progetto.file_sinonimi]
    return opzioni


def _controlla_sintassi(percorso: Path, sorgente: str, opzioni: dict[str, Any]) -> None:
    """Analizza il sorgente: un errore di sintassi ferma la compilazione (prima di PyInstaller)."""
    from .errori import ErroreDante
    from .esecuzione import analizza

    try:
        analizza(sorgente, percorso.name, **opzioni)
    except ErroreDante as e:
        try:
            dettaglio = e.formatta(sorgente)
        except Exception:  # noqa: BLE001 - il messaggio breve basta
            dettaglio = e.breve()
        raise ErroreCompilazione(
            f"Il file `{percorso.name}` contiene un errore, quindi non lo compilo.\n"
            f"Correggilo e riprova:\n\n{dettaglio}") from None


def _file_raggiungibili(iniziali: Iterable[Path], opzioni: dict[str, Any] | None,
                        controlla: bool) -> tuple[list[Path], list[str]]:
    """I file .leo di partenza più tutti quelli che importano (ricorsivamente).

    Se ``controlla`` è vero ne verifica la sintassi. Restituisce anche i sorgenti letti.
    """
    visti: dict[Path, None] = {}
    sorgenti: list[str] = []
    da_fare = [p.resolve() for p in iniziali]
    while da_fare:
        p = da_fare.pop(0)
        if p in visti:
            continue
        visti[p] = None
        sorgente = _leggi_testo(p)
        sorgenti.append(sorgente)
        if controlla:
            _controlla_sintassi(p, sorgente, dict(opzioni or {}))
        for importato in _moduli_importati(sorgente, p.parent):
            if importato.resolve() not in visti:
                da_fare.append(importato.resolve())
    return list(visti), sorgenti


def _file_del_progetto(cartella: Path, escludi: Sequence[Path], avvisi: list[str]) -> list[tuple[Path, str]]:
    """Tutti i file del progetto da includere, con il percorso relativo (``/``)."""
    risultato: list[tuple[Path, str]] = []
    escludi_risolti = [e.resolve() for e in escludi]
    for radice, cartelle, file in os.walk(cartella):
        radice_p = Path(radice)
        cartelle[:] = sorted(
            c for c in cartelle
            if c not in CARTELLE_ESCLUSE and not c.startswith(".")
            and (radice_p / c).resolve() not in escludi_risolti)
        for nome in sorted(file):
            p = radice_p / nome
            if nome.startswith(".") or p.suffix.lower() in ESTENSIONI_ESCLUSE or nome.startswith("~$"):
                continue
            try:
                dimensione = p.stat().st_size
            except OSError:
                continue
            relativo = p.relative_to(cartella).as_posix()
            if dimensione > LIMITE_FILE:
                avvisi.append(f"Il file `{relativo}` è troppo grande ({formatta_dimensione(dimensione)}): "
                              "non lo includo nell'eseguibile.")
                continue
            risultato.append((p, relativo))
    return risultato


def _risorse_maschera(maschera: Any) -> list[str]:
    """Valori delle proprietà che sembrano nomi di file (immagini, suoni, dati)."""
    valori: list[str] = []

    def raccogli(v: Any) -> None:
        if isinstance(v, str):
            testo = v.strip()
            if testo and "\n" not in testo and Path(testo).suffix.lower() in ESTENSIONI_RISORSE \
                    and not testo.lower().startswith(("http://", "https://")):
                valori.append(testo)
        elif isinstance(v, (list, tuple)):
            for x in v:
                raccogli(x)
        elif isinstance(v, dict):
            for x in v.values():
                raccogli(x)

    for controllo in [maschera.finestra, *maschera.controlli]:
        raccogli(controllo.proprieta)
    return valori


def _moduli_qt_facoltativi(tipi: set[str], sorgenti: Iterable[str]) -> list[str]:
    """Gruppi di moduli Qt facoltativi che servono (controlli nelle maschere o nomi nel codice)."""
    testo = "\n".join(sorgenti)
    necessari: set[str] = set()
    for gruppo, (_moduli, controlli) in MODULI_QT_FACOLTATIVI.items():
        if tipi & controlli or any(re.search(rf"\b{re.escape(c)}\b", testo) for c in controlli):
            necessari.add(gruppo)
    return chiusura_gruppi(necessari)


def chiusura_gruppi(gruppi: Iterable[str]) -> list[str]:
    """I gruppi indicati più quelli da cui dipendono (:data:`DIPENDENZE_GRUPPI`), in ordine fisso."""
    tutti: set[str] = set()
    da_fare = list(gruppi)
    while da_fare:
        g = da_fare.pop()
        if g not in tutti:
            tutti.add(g)
            da_fare.extend(DIPENDENZE_GRUPPI.get(g, ()))
    return [g for g in MODULI_QT_FACOLTATIVI if g in tutti]


# ---------------------------------------------------------------------------
# Filtro dei file raccolti da PyInstaller (DLL, plugin e traduzioni di Qt)
# ---------------------------------------------------------------------------
#
# ``--exclude-module`` toglie i moduli Python, ma gli hook di QtCore/QtGui/QtWidgets
# raccolgono comunque file che un programma Leo non usa: ``opengl32sw.dll`` (OpenGL
# software, ~20 MB), le traduzioni di Qt in tutte le lingue, e plugin che trascinano con
# sé intere librerie (``imageformats/qpdf.dll`` porta ``Qt6Pdf.dll``; il plugin della
# tastiera virtuale porta ``Qt6VirtualKeyboard``, ``Qt6Quick`` e ``Qt6Qml``; ``tls`` e
# ``networkinformation`` portano ``Qt6Network``). Le regole seguenti li tolgono dalla
# ``Analysis`` di PyInstaller prima che l'eseguibile venga assemblato.

#: Librerie di Qt (nome senza estensione, minuscolo) dei moduli mai usati da Leo.
QT_DLL_ESCLUSE = (
    "qt6pdf", "qt6qml", "qt6quick", "qt6virtualkeyboard", "qt63d", "qt6webengine", "qt6webchannel",
    "qt6websockets", "qt6webview", "qt6charts", "qt6datavisualization", "qt6graphs", "qt6bluetooth",
    "qt6nfc", "qt6sensors", "qt6serialport", "qt6serialbus", "qt6sql", "qt6test", "qt6designer",
    "qt6help", "qt6uitools", "qt6positioning", "qt6location", "qt6remoteobjects", "qt6scxml",
    "qt6statemachine", "qt6spatialaudio", "qt6httpserver", "qt6networkauth", "qt6printsupport",
    "qt6concurrent", "qt6xml", "qt6dbus", "qt6shadertools", "qt6svgwidgets", "qt6labs",
    "qt6multimediaquick", "qt6quickcontrols2", "qt6quicktemplates2",
)
#: Cartelle di plugin di Qt mai usate.
PLUGIN_QT_ESCLUSI = (
    "qmltooling", "qmllint", "qmlls", "scenegraph", "renderers", "renderplugins", "sceneparsers",
    "geometryloaders", "assetimporters", "sqldrivers", "canbus", "sensors", "position", "geoservices",
    "designer", "webview", "virtualkeyboard", "generic", "printsupport",
)
#: Plugin di formati d'immagine inutili (PNG, BMP, ICO, GIF, JPEG e SVG restano).
FORMATI_IMMAGINE_ESCLUSI = ("qpdf", "qtiff", "qwbmp", "qicns", "qtga", "qjp2", "qmng")
#: Plugin delle piattaforme diverse dalle finestre di Windows.
PIATTAFORME_ESCLUSE = ("qdirect2d", "qminimal", "qoffscreen", "qvnc")
#: Librerie FFmpeg usate solo da QtMultimedia (video, suoni, fotocamera).
FFMPEG = ("avcodec", "avformat", "avutil", "avfilter", "avdevice", "swresample", "swscale")


def regole_filtro(piano: Piano) -> dict[str, list[str]]:
    """Regole ``{"scarta": [...], "tieni": [...]}`` per i file raccolti da PyInstaller.

    Ogni regola è un modello ``fnmatch`` (minuscolo, con ``/``) confrontato con il
    percorso del file dentro l'eseguibile (es. ``pyside6/opengl32sw.dll``); ``tieni``
    vince su ``scarta``. Senza grafica non c'è nulla da togliere (PySide6 è già escluso).
    """
    if not piano.con_grafica:
        return {"scarta": [], "tieni": []}
    gruppi = set(piano.moduli_qt)
    scarta: list[str] = ["pyside6/*opengl32sw*", "pyside6/qml/*", "pyside6/resources/*",
                         "pyside6/*translations/*",
                         "pyside6/*plugins/platforminputcontexts/qtvirtualkeyboard*"]
    scarta += [f"pyside6/*{nome}*" for nome in QT_DLL_ESCLUSE]
    scarta += [f"pyside6/*plugins/{cartella}/*" for cartella in PLUGIN_QT_ESCLUSI]
    scarta += [f"pyside6/*plugins/imageformats/{nome}*" for nome in FORMATI_IMMAGINE_ESCLUSI]
    scarta += [f"pyside6/*plugins/platforms/{nome}*" for nome in PIATTAFORME_ESCLUSE]
    if not any(rel.lower().endswith(".webp") for _p, rel in piano.file):
        scarta.append("pyside6/*plugins/imageformats/qwebp*")
    if "multimedia" not in gruppi:
        # (Qt6OpenGL e d3dcompiler restano con QtMultimedia: il video può usarli)
        scarta += ["pyside6/*qt6opengl*", "pyside6/*qt6multimedia*", "pyside6/*plugins/multimedia/*", "pyside6/*d3dcompiler_*"]
        scarta += [f"pyside6/*{nome}-*" for nome in FFMPEG]
    if "voce" not in gruppi:
        scarta += ["pyside6/*qt6texttospeech*", "pyside6/*plugins/texttospeech/*"]
    if "rete" not in gruppi:
        scarta += ["pyside6/*qt6network*", "pyside6/*plugins/tls/*", "pyside6/*plugins/networkinformation/*"]
    # Traduzioni: solo l'italiano (finestre di dialogo standard di Qt).
    tieni = ["pyside6/*translations/*_it.qm"]
    return {"scarta": scarta, "tieni": tieni}


def da_scartare(nome, regole):
    """Vero se il file ``nome`` (percorso dentro l'eseguibile) va tolto secondo ``regole``.

    Usata anche da ``costruisci_eseguibile.py``: solo ``fnmatch`` e ``os``.
    """
    testo = str(nome).replace("\\", "/").lower()
    if not any(fnmatch.fnmatchcase(testo, modello) for modello in regole.get("scarta") or ()):
        return False
    return not any(fnmatch.fnmatchcase(testo, modello) for modello in regole.get("tieni") or ())


def filtra_voci(voci, regole, tolti):
    """Voci ``(destinazione, origine, tipo)`` di PyInstaller da tenere; quelle tolte vanno
    in ``tolti`` come ``[destinazione, byte]``. Usata anche da ``costruisci_eseguibile.py``."""
    tenute = []
    for voce in voci:
        try:
            destinazione, origine = voce[0], voce[1]
        except (TypeError, IndexError):
            tenute.append(voce)
            continue
        if da_scartare(destinazione, regole):
            try:
                byte = os.path.getsize(origine)
            except (OSError, TypeError, ValueError):
                byte = 0
            tolti.append([str(destinazione).replace("\\", "/"), byte])
        else:
            tenute.append(voce)
    return tenute


def analizza_programma(percorso: str | os.PathLike, *, nome: str | None = None,
                       modalita: str | None = None, con_grafica: bool | None = None,
                       uscita: str | os.PathLike | None = None, controlla_codice: bool = True) -> Piano:
    """Controlla il programma o il progetto e decide che cosa includere. Non scrive nulla.

    ``percorso``: file ``.leo``, cartella di un progetto o il suo ``progetto.toml``.
    ``modalita``: "finestra", "console" o None (finestra per i progetti con finestre).
    ``con_grafica``: includere PySide6 (None = deciso dal programma).
    ``uscita``: cartella di destinazione, esclusa dai file del progetto se ci sta dentro.
    """
    from .errori import ErroreDante

    if modalita is not None and modalita not in MODALITA:
        raise ErroreCompilazione(f"Modalità `{modalita}` sconosciuta: usa `finestra` oppure `console`.",
                                 codice=2)
    sorgente = Path(percorso)
    if not sorgente.exists():
        raise ErroreCompilazione(f"Non trovo `{os.fspath(percorso)}`.", codice=2)
    if sorgente.is_file() and sorgente.name == "progetto.toml":
        sorgente = sorgente.parent
    sorgente = sorgente.resolve()
    escludi = [Path(uscita)] if uscita is not None else []
    avvisi: list[str] = []

    try:
        from .progetto import carica_progetto, e_progetto
    except ImportError as e:  # pragma: no cover - installazione rotta
        raise ErroreCompilazione(f"Installazione di {NOME} incompleta: {e}.") from None

    if sorgente.is_dir():
        if not e_progetto(sorgente):
            raise ErroreCompilazione(
                f"La cartella `{sorgente}` non è un progetto {NOME} (manca `progetto.toml`).\n"
                f"Per compilare un solo programma indica il file `.leo`; per creare un progetto: "
                f"leo nuovo {sorgente.name}", codice=2)
        try:
            progetto = carica_progetto(sorgente)
        except ErroreDante as e:
            raise ErroreCompilazione(f"Non riesco a leggere `progetto.toml`: {e.messaggio}") from None
        opzioni = _opzioni_lessico_progetto(progetto)
        tipi: set[str] = set()
        risorse: list[str] = []
        if progetto.e_grafico:
            finestre = progetto.finestre
            iniziale = progetto.finestra_iniziale or (finestre[0] if finestre else "")
            if not iniziale or not progetto.percorso_maschera(iniziale).is_file():
                raise ErroreCompilazione(
                    f"Il progetto `{progetto.nome}` indica la finestra iniziale `{iniziale}`, "
                    f"ma il file `{iniziale}.maschera` non c'è.\n"
                    "Aprilo con Leo Studio e scegli la finestra iniziale.")
            from .grafica.maschera import carica_maschera

            iniziali: list[Path] = []
            for finestra in finestre:
                file_maschera = progetto.percorso_maschera(finestra)
                if not file_maschera.is_file():
                    avvisi.append(f"La finestra `{finestra}` è elencata in progetto.toml ma manca "
                                  f"`{finestra}.maschera`.")
                    continue
                try:
                    maschera = carica_maschera(file_maschera)
                except ErroreDante as e:
                    raise ErroreCompilazione(
                        f"La maschera `{file_maschera.name}` è rovinata, quindi non compilo: {e.messaggio}") from None
                tipi.add(maschera.finestra.tipo)
                tipi.update(c.tipo for c in maschera.controlli)
                risorse.extend(_risorse_maschera(maschera))
                codice = progetto.percorso_codice(finestra)
                if codice.is_file():
                    iniziali.append(codice)
            eseguiti, sorgenti = _file_raggiungibili(iniziali, opzioni, controlla_codice)
            modalita_auto = "finestra"
            grafica_auto = True
        else:
            principale = progetto.percorso_principale
            if not principale.is_file():
                raise ErroreCompilazione(
                    f"Il progetto `{progetto.nome}` non ha finestre e manca il file `{progetto.principale}`.\n"
                    "Crea quel file oppure aggiungi una finestra con Leo Studio.")
            eseguiti, sorgenti = _file_raggiungibili([principale], opzioni, controlla_codice)
            modalita_auto = "console"
            grafica_auto = any(_usa_tartaruga(s) for s in sorgenti)
        file = _file_del_progetto(sorgente, escludi, avvisi)
        inclusi = {rel for _p, rel in file}
        for risorsa in risorse:
            p = Path(risorsa)
            if p.is_absolute():
                if not _e_dentro(p, sorgente):
                    avvisi.append(f"Una maschera usa `{risorsa}`, che sta fuori dalla cartella del progetto: "
                                  "nell'eseguibile non ci sarà. Copia il file nel progetto e sceglilo da lì.")
            elif risorsa.replace("\\", "/") not in inclusi and not (sorgente / p).exists():
                avvisi.append(f"Una maschera usa `{risorsa}`, ma nel progetto quel file non c'è.")
        for p in eseguiti:
            if not _e_dentro(p, sorgente):
                avvisi.append(f"`{p.name}` è importato da fuori della cartella del progetto: "
                              "nell'eseguibile non ci sarà. Copialo nel progetto.")
        nome_base = progetto.nome or sorgente.name
        piano = Piano(tipo="progetto", sorgente=sorgente, cartella=sorgente, nome=nome_valido(nome or nome_base),
                      modalita=modalita or modalita_auto, avvio="", file=file, tipi_controlli=tipi,
                      titolo=_testo_risorsa(nome or nome_base), **_informazioni_progetto(sorgente))
    else:
        if not e_sorgente(sorgente.name):
            raise ErroreCompilazione(
                f"`{sorgente.name}` non è un programma {NOME}: indica un file `.leo` "
                "oppure la cartella di un progetto.", codice=2)
        cartella = sorgente.parent
        opzioni = {}
        file_extra: list[Path] = []
        if e_progetto(cartella):
            try:
                progetto = carica_progetto(cartella)
                opzioni = _opzioni_lessico_progetto(progetto)
                file_extra.append(cartella / "progetto.toml")
                if progetto.file_sinonimi:
                    file_extra.append(progetto.file_sinonimi)
            except ErroreDante:
                opzioni = {}
        eseguiti, sorgenti = _file_raggiungibili([sorgente], opzioni, controlla_codice)
        file = []
        for p in [*eseguiti, *file_extra]:
            if _e_dentro(p, cartella):
                file.append((p, p.resolve().relative_to(cartella.resolve()).as_posix()))
            else:
                avvisi.append(f"`{p.name}` è importato da fuori della cartella del programma: "
                              "nell'eseguibile non ci sarà. Copialo accanto al programma.")
        modalita_auto = "console"
        grafica_auto = any(_usa_tartaruga(s) for s in sorgenti)
        piano = Piano(tipo="file", sorgente=sorgente, cartella=cartella, nome=nome_valido(nome or sorgente.stem),
                      modalita=modalita or modalita_auto, avvio=sorgente.name, file=file, tipi_controlli=set(),
                      titolo=_testo_risorsa(nome or sorgente.stem))

    # elementi della galleria ("galleria:personaggi/cavaliere" nel codice o nelle maschere): solo quelli
    # usati, con il loro indice e i crediti, nella cartella galleria/ accanto al programma
    try:
        from .galleria import prepara_per_programma

        piano.file.extend(prepara_per_programma(piano.cartella, [p for p, _rel in piano.file], avvisi=avvisi))
    except ImportError:  # pragma: no cover - installazione senza galleria
        pass
    piano.con_grafica = grafica_auto if con_grafica is None else bool(con_grafica)
    if piano.e_progetto and piano.tipi_controlli and not piano.con_grafica:
        piano.con_grafica = True                       # un progetto con finestre non gira senza PySide6
        avvisi.append("Il progetto ha delle finestre: PySide6 viene incluso comunque.")
    piano.moduli_qt = _moduli_qt_facoltativi(piano.tipi_controlli, sorgenti) if piano.con_grafica else []
    piano.titolo = piano.titolo or piano.nome
    piano.file_dati = [rel for p, rel in piano.file
                       if p.suffix.lower() in ESTENSIONI_DATI and "/" not in rel]
    if piano.modalita == "finestra" and not piano.e_progetto and not piano.con_grafica:
        avvisi.append("Il programma è testuale ma hai scelto `--finestra`: senza console non potrà "
                      "mostrare né chiedere nulla. Di solito serve `--console`.")
    if piano.dimensione_file > SOGLIA_AVVISO_TOTALE:
        avvisi.append(f"I file del programma occupano {formatta_dimensione(piano.dimensione_file)}: "
                      "l'eseguibile sarà grande e partirà più lentamente.")
    _aggiungi_dipendenze(piano, avvisi)
    piano.avvisi = avvisi
    return piano


def _aggiungi_dipendenze(piano: Piano, avvisi: list[str]) -> None:
    """Pacchetti di ``leo.lock``: i pacchetti Leo vanno tra i file (``.leo/pacchetti/...``), quelli
    Python li raccoglie PyInstaller dall'ambiente del progetto (vedi :func:`argomenti_pyinstaller`).
    ``leo.lock`` non serve a chi esegue: non si include."""
    piano.file = [(p, rel) for p, rel in piano.file if rel != "leo.lock"]
    try:
        from .pacchetti import parti_per_distribuzione

        parti = parti_per_distribuzione(piano.cartella)
    except Exception as e:  # noqa: BLE001 - il gestore di pacchetti non deve impedire la compilazione
        avvisi.append(f"Non riesco a leggere i pacchetti del progetto (leo.lock): {e}")
        return
    if parti is None:
        return
    if parti.radice.resolve() != Path(piano.cartella).resolve():
        avvisi.append("Il programma usa i pacchetti di un progetto che sta in una cartella superiore: "
                      "compila la cartella del progetto per includerli.")
        return
    avvisi.extend(parti.avvisi)
    piano.dipendenze = parti
    piano.file.extend(parti.file_leo)


# ---------------------------------------------------------------------------
# Preparazione della cartella di lavoro
# ---------------------------------------------------------------------------

@dataclass
class Preparazione:
    """Cartella di lavoro pronta per PyInstaller (vedi :func:`prepara_cartella`)."""

    piano: Piano
    lavoro: Path
    script: Path
    configurazione: Path
    cartella_programma: Path
    cartella_dati: Path
    cartella_pacchetto: Path
    icona: Path | None
    un_file: bool
    moduli_nascosti: list[str] = field(default_factory=list)
    moduli_esclusi: list[str] = field(default_factory=list)
    pacchetti_raccolti: list[str] = field(default_factory=list)   # --collect-submodules
    file_versione: Path | None = None                              # --version-file
    regole_filtro: dict[str, list[str]] = field(default_factory=dict)
    script_costruzione: Path | None = None                         # avvia PyInstaller col filtro
    ottimizza: int = OTTIMIZZAZIONE_PREDEFINITA                    # --optimize
    upx_dir: str | None = None                                     # --upx-dir (None = --noupx)
    pacchetti_leo_esclusi: list[str] = field(default_factory=list)
    dati_esclusi: list[str] = field(default_factory=list)


def _ignora_copia(_cartella: str, nomi: list[str]) -> set[str]:
    return {n for n in nomi if n == "__pycache__" or n.endswith((".pyc", ".pyo"))}


def pacchetti_leo_esclusi(piano: Piano) -> list[str]:
    """Parti di ``leo`` da non includere per questo programma."""
    esclusi = list(PACCHETTI_LEO_ESCLUSI) + ["leo.__main__"]
    if not piano.con_grafica:
        esclusi += list(PACCHETTI_LEO_SOLO_GRAFICI)
    return esclusi


def dati_esclusi(piano: Piano) -> list[str]:
    """Nomi di file e cartelle di ``dati/`` da non includere per questo programma."""
    esclusi = set(DATI_ESCLUSI)
    if not piano.con_grafica:
        esclusi |= DATI_SOLO_GRAFICI
    elif "seriale" not in piano.moduli_qt:
        esclusi |= DATI_SOLO_SERIALE
    return sorted(esclusi)


def _copia_pacchetto(destinazione: Path, esclusi: Sequence[str] = PACCHETTI_LEO_ESCLUSI) -> None:
    """Copia il pacchetto ``leo`` (senza le parti ``esclusi``, senza cache) in ``destinazione/leo``."""
    origine = _cartella_pacchetto()
    percorsi_esclusi = {tuple(p.split(".")[1:]) for p in esclusi if p.startswith("leo.")}

    def ignora(cartella: str, nomi: list[str]) -> set[str]:
        via = _ignora_copia(cartella, nomi)
        try:
            relativa = Path(cartella).resolve().relative_to(origine).parts
        except ValueError:
            return via
        for n in nomi:
            base = n[:-3] if n.endswith(".py") else n
            if relativa + (base,) in percorsi_esclusi:
                via.add(n)
        return via

    shutil.copytree(origine, destinazione / "leo", ignore=ignora)


def _copia_dati(destinazione: Path, esclusi: Iterable[str] = DATI_ESCLUSI) -> Path:
    from .percorsi import cartella_dati

    esclusi = frozenset(esclusi)
    origine = cartella_dati()
    arrivo = destinazione / CARTELLA_DATI
    if origine.is_dir():
        shutil.copytree(origine, arrivo, ignore=lambda c, nomi: {n for n in nomi if n in esclusi}
                        | _ignora_copia(c, nomi))
    else:
        arrivo.mkdir(parents=True, exist_ok=True)
    return arrivo


def _moduli_del_pacchetto(cartella_pacchetto: Path) -> list[str]:
    """Nomi dei moduli Python del pacchetto copiato (``leo``, ``leo.cli``, ...)."""
    moduli: list[str] = []
    base = cartella_pacchetto.parent
    for p in sorted(cartella_pacchetto.rglob("*.py")):
        parti = list(p.relative_to(base).with_suffix("").parts)
        if parti[-1] == "__init__":
            parti.pop()
        moduli.append(".".join(parti))
    return moduli


def icona_predefinita() -> Path | None:
    """``dati/icone/leo.ico`` (o il vecchio ``dante.ico``), se c'è."""
    try:
        from .percorsi import file_dati

        candidati = [file_dati("icone", "leo.ico"), file_dati("icone", "dante.ico")]
    except Exception:  # noqa: BLE001
        return None
    return next((p for p in candidati if p.is_file()), None)


def ottimizzazione_per(piano: Piano, richiesta: int | None = None) -> int:
    """Livello di ``--optimize``: quello richiesto (0-2) o, se None, 2; 1 con numpy/OpenCV
    (lettore QR), che con le docstring tolte potrebbero non caricarsi."""
    if richiesta is not None:
        return max(0, min(2, int(richiesta)))
    return 1 if "qr" in piano.moduli_qt else OTTIMIZZAZIONE_PREDEFINITA


def moduli_esclusi_per(piano: Piano, esclusi_leo: Sequence[str]) -> list[str]:
    """Tutti i ``--exclude-module`` per questo programma (senza ripetizioni)."""
    esclusi_totali = list(esclusi_leo) + list(MODULI_PYTHON_ESCLUSI)
    parti = getattr(piano, "dipendenze", None)
    if parti is not None and parti.moduli_python:
        # le librerie Python aggiunte possono usare parti della libreria standard che Leo non usa
        servono = set(parti.moduli_python) | {"lzma", "_lzma", "bz2", "_bz2", "xmlrpc", "pydoc", "pydoc_data"}
        esclusi_totali = [m for m in esclusi_totali if m not in servono]
    if piano.con_grafica:
        esclusi_totali += list(MODULI_QT_ESCLUSI)
        for gruppo, (moduli_qt, _controlli) in MODULI_QT_FACOLTATIVI.items():
            if gruppo not in piano.moduli_qt:
                esclusi_totali += list(moduli_qt)
        # Salvaguardia: i moduli essenziali di Qt (e quindi i loro plugin) non si escludono mai.
        esclusi_totali = [m for m in esclusi_totali if m not in MODULI_QT_ESSENZIALI]
    else:
        esclusi_totali += ["PySide6", "shiboken6"]
        for moduli_qt, _controlli in MODULI_QT_FACOLTATIVI.values():
            esclusi_totali += [m for m in moduli_qt if not m.startswith("PySide6.")]
    return list(dict.fromkeys(esclusi_totali))


def prepara_cartella(piano: Piano, lavoro: str | os.PathLike, *, icona: str | os.PathLike | None = None,
                     un_file: bool = False, autore: str | None = None, descrizione: str | None = None,
                     versione: str | None = None, filtra: bool = True, ottimizza: int | None = None,
                     upx_dir: str | None = None, schermata_avvio: bool = True) -> Preparazione:
    """Scrive nella cartella ``lavoro`` (creata se manca, deve essere vuota) tutto ciò che serve.

    Dopo questa funzione ``python <lavoro>/avvio_programma.py`` esegue il programma.
    ``autore``, ``descrizione``, ``versione``: dati della risorsa di versione di Windows
    (None = quelli del piano, cioè di ``progetto.toml``; l'autore predefinito è vuoto).
    ``filtra``: scrivere ``costruisci_eseguibile.py`` e le regole che tolgono i file di Qt
    non usati (False = tutto ciò che PyInstaller raccoglie). ``ottimizza``: livello di
    ``--optimize`` (None = automatico). ``upx_dir``: cartella di ``upx`` (None = niente UPX).
    """
    lavoro = Path(lavoro).resolve()
    if lavoro.exists() and any(lavoro.iterdir()):
        raise ErroreCompilazione(f"La cartella di lavoro `{lavoro}` non è vuota.")
    lavoro.mkdir(parents=True, exist_ok=True)

    # 1. Il programma (o il progetto)
    cartella_programma = lavoro / CARTELLA_PROGRAMMA
    cartella_programma.mkdir()
    for origine, relativo in piano.file:
        arrivo = cartella_programma / relativo
        arrivo.parent.mkdir(parents=True, exist_ok=True)
        try:
            shutil.copy2(origine, arrivo)
        except OSError as e:
            raise ErroreCompilazione(f"Non riesco a copiare `{relativo}`: {e.strerror or e}.") from None

    # 2. L'interprete (solo le parti usate a runtime) e i suoi dati
    esclusi = pacchetti_leo_esclusi(piano)
    _copia_pacchetto(lavoro, esclusi)
    esclusi_dati = dati_esclusi(piano)
    cartella_dati = _copia_dati(lavoro, esclusi_dati)

    # 3. L'icona (anche per le finestre del programma)
    percorso_icona: Path | None = None
    sorgente_icona = Path(icona) if icona else icona_predefinita()
    if sorgente_icona is not None:
        if not sorgente_icona.is_file():
            raise ErroreCompilazione(f"Non trovo l'icona `{sorgente_icona}`.", codice=2)
        risorse = lavoro / CARTELLA_RISORSE
        risorse.mkdir()
        estensione = sorgente_icona.suffix.lower() or ".ico"
        percorso_icona = risorse / ("icona" + estensione)
        shutil.copy2(sorgente_icona, percorso_icona)

    # 4. Configurazione e script di avvio
    configurazione = lavoro / NOME_CONFIGURAZIONE
    dati_conf = {
        "nome": piano.nome,
        "tipo": piano.tipo,
        "avvio": piano.avvio,
        "modalita": piano.modalita,
        "un_file": bool(un_file),
        "icona": f"{CARTELLA_RISORSE}/{percorso_icona.name}" if percorso_icona else "",
        "versione_leo": __version__,
        "id_applicazione": "Leo.Programma." + re.sub(r"[^A-Za-z0-9]", "", piano.nome)[:40],
        "grafica": bool(piano.con_grafica),
        # icona e nome su fondo nero finché non compare la prima finestra (solo programmi con finestre)
        "schermata_avvio": bool(schermata_avvio and piano.modalita == "finestra" and piano.con_grafica),
        # file di dati del programma: l'eseguibile li copia (se mancano) nella sua cartella,
        # dove il programma li legge e li scrive (mai nella cartella temporanea di PyInstaller)
        "file_dati": sorted(rel for p, rel in piano.file if p.suffix.lower() in ESTENSIONI_DATI),
    }
    configurazione.write_text(json.dumps(dati_conf, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    script = lavoro / NOME_SCRIPT_AVVIO
    script.write_text(MODELLO_AVVIO, encoding="utf-8")

    # 5. Risorsa di versione di Windows (Proprietà > Dettagli)
    file_versione = lavoro / NOME_FILE_VERSIONE
    file_versione.write_text(testo_versione_windows(
        piano.nome, titolo=piano.titolo or piano.nome,
        autore=piano.autore if autore is None else autore,
        descrizione=piano.descrizione if descrizione is None else descrizione,
        versione=piano.versione if versione is None else versione), encoding="ascii")

    # 6. Filtro dei file di Qt non usati (DLL, plugin, traduzioni, opengl32sw.dll)
    regole = regole_filtro(piano) if filtra else {"scarta": [], "tieni": []}
    script_costruzione: Path | None = None
    if regole["scarta"]:
        (lavoro / NOME_FILTRO).write_text(json.dumps(regole, indent=1) + "\n", encoding="utf-8")
        script_costruzione = lavoro / NOME_SCRIPT_COSTRUZIONE
        script_costruzione.write_text(modello_costruzione(), encoding="utf-8")

    cartella_pacchetto = lavoro / "leo"
    moduli = _moduli_del_pacchetto(cartella_pacchetto)
    nascosti = [m for m in moduli
                if not any(m == e or m.startswith(e + ".") for e in esclusi)]
    raccolti = [p for p in PACCHETTI_DINAMICI + (PACCHETTI_DINAMICI_GRAFICI if piano.con_grafica else ())
                if p in moduli and not any(p == e or p.startswith(e + ".") for e in esclusi)]
    return Preparazione(piano=piano, lavoro=lavoro, script=script, configurazione=configurazione,
                        cartella_programma=cartella_programma, cartella_dati=cartella_dati,
                        cartella_pacchetto=cartella_pacchetto, icona=percorso_icona, un_file=bool(un_file),
                        moduli_nascosti=nascosti, moduli_esclusi=moduli_esclusi_per(piano, esclusi),
                        pacchetti_raccolti=raccolti, file_versione=file_versione,
                        regole_filtro=regole, script_costruzione=script_costruzione,
                        ottimizza=ottimizzazione_per(piano, ottimizza), upx_dir=upx_dir,
                        pacchetti_leo_esclusi=esclusi, dati_esclusi=esclusi_dati)


def optimize_supportato(versione: str | None) -> bool:
    """Vero se PyInstaller ``versione`` conosce ``--optimize`` (dalla 6.6; None = si presume di sì)."""
    numeri = [int(n) for n in re.findall(r"\d+", str(versione or ""))[:2]]
    if not numeri:
        return True
    return tuple(numeri + [0] * (2 - len(numeri))) >= VERSIONE_PYINSTALLER_OPTIMIZE


def argomenti_pyinstaller(prep: Preparazione, *, uscita: str | os.PathLike,
                          sistema: str | None = None, versione_pyinstaller: str | None = None) -> list[str]:
    """Argomenti per ``python -m PyInstaller`` 6.x (tutti i percorsi assoluti).

    ``sistema``: ``"nt"`` per Windows (predefinito: il sistema attuale); decide il
    separatore di ``--add-data`` (``;`` su Windows). Oltre ai dati e all'icona:
    ``--version-file`` (risorsa di versione), ``--hidden-import`` per ogni modulo di
    ``leo`` incluso e ``--collect-submodules`` per i pacchetti caricati per nome,
    ``--exclude-module`` per Studio e i moduli non usati (mai QtCore/QtGui/QtWidgets/QtSvg,
    i cui hook portano i plugin platforms, styles, imageformats), ``--optimize`` se la
    versione di PyInstaller lo conosce (``versione_pyinstaller``, None = sì), UPX solo se
    ``prep.upx_dir`` è indicata (altrimenti ``--noupx``).
    """
    sep = separatore_dati(sistema)
    lavoro = prep.lavoro
    uscita = Path(uscita).resolve()
    argomenti = [
        str(prep.script),
        "--noconfirm",
        "--clean",
        "--log-level", "WARN",
        "--name", prep.piano.nome,
        "--onefile" if prep.un_file else "--onedir",
        "--noconsole" if prep.piano.modalita == "finestra" else "--console",
        "--distpath", str(uscita),
        "--workpath", str(lavoro / "build"),
        "--specpath", str(lavoro),
        "--paths", str(lavoro),
    ]
    if prep.upx_dir:
        argomenti += ["--upx-dir", str(prep.upx_dir)]
        for nome in ESCLUSI_UPX:
            argomenti += ["--upx-exclude", nome]
    else:
        argomenti.append("--noupx")    # predefinito: UPX rovina alcune DLL di Qt e allarma gli antivirus
    if prep.ottimizza and optimize_supportato(versione_pyinstaller):
        argomenti += ["--optimize", str(prep.ottimizza)]
    if prep.icona is not None:
        argomenti += ["--icon", str(prep.icona)]
    if prep.file_versione is not None:
        argomenti += ["--version-file", str(prep.file_versione)]
    dati = [(prep.configurazione, "."), (prep.cartella_dati, CARTELLA_DATI),
            (prep.cartella_programma, CARTELLA_PROGRAMMA)]
    if prep.icona is not None:
        dati.append((prep.icona.parent, CARTELLA_RISORSE))
    for origine, destinazione in dati:
        argomenti += ["--add-data", f"{origine}{sep}{destinazione}"]
    for modulo in prep.moduli_nascosti:
        argomenti += ["--hidden-import", modulo]
    for pacchetto in prep.pacchetti_raccolti:
        argomenti += ["--collect-submodules", pacchetto]
    parti = getattr(prep.piano, "dipendenze", None)
    if parti is not None and parti.site_packages is not None and parti.moduli_python:
        # pacchetti di `leo aggiungi`: dall'ambiente del progetto, interi (moduli, dati, librerie native),
        # perché `importa python "..."` li carica per nome mentre il programma gira
        argomenti += ["--paths", str(parti.site_packages)]
        for modulo in parti.moduli_python:
            argomenti += ["--collect-all", modulo]
    for modulo in prep.moduli_esclusi:
        argomenti += ["--exclude-module", modulo]
    return argomenti


# ---------------------------------------------------------------------------
# PyInstaller: verifica, installazione, esecuzione
# ---------------------------------------------------------------------------

_SONDA = (
    "import json, importlib.util as u\n"
    "try:\n"
    "    import PyInstaller\n"
    "    v = str(getattr(PyInstaller, '__version__', '?'))\n"
    "except Exception:\n"
    "    v = None\n"
    "print(json.dumps({'pyinstaller': v, 'pyside6': u.find_spec('PySide6') is not None}))\n"
)


def _opzioni_processo() -> dict[str, Any]:
    """Su Windows i processi figli (pip, PyInstaller) non aprono una console propria:
    da Leo Studio (pythonw.exe) si vedrebbe lampeggiare una finestra nera."""
    if os.name == "nt":
        return {"creationflags": getattr(subprocess, "CREATE_NO_WINDOW", 0x08000000)}
    return {}


def versione_troppo_vecchia(versione: str | None) -> bool:
    """Vero se ``versione`` (es. ``"5.13.2"``) è precedente a :data:`VERSIONE_PYINSTALLER_MINIMA`."""
    numeri = [int(n) for n in re.findall(r"\d+", str(versione or ""))[:2]]
    if not numeri:
        return False
    return tuple(numeri + [0] * (2 - len(numeri))) < VERSIONE_PYINSTALLER_MINIMA


def sonda_ambiente(python: str | None = None) -> dict[str, Any]:
    """Versione di PyInstaller (None se manca) e presenza di PySide6 nell'ambiente ``python``."""
    python = python or sys.executable
    try:
        r = subprocess.run([python, "-c", _SONDA], capture_output=True, text=True, timeout=120,
                           **_opzioni_processo())
    except (OSError, subprocess.SubprocessError) as e:
        raise ErroreCompilazione(f"Non riesco ad avviare Python (`{python}`): {e}.") from None
    for riga in reversed(r.stdout.strip().splitlines()):
        try:
            dati = json.loads(riga)
            if isinstance(dati, dict):
                return {"pyinstaller": dati.get("pyinstaller"), "pyside6": bool(dati.get("pyside6"))}
        except ValueError:
            continue
    return {"pyinstaller": None, "pyside6": False}


def comando_installazione(python: str | None = None) -> str:
    """Il comando da scrivere per installare PyInstaller nell'ambiente di Leo."""
    python = python or sys.executable
    return f'"{python}" -m pip install pyinstaller'


def messaggio_pyinstaller_mancante(python: str | None = None) -> str:
    return ("Per creare l'eseguibile serve PyInstaller, che in questo ambiente non è installato.\n"
            f"Installalo con:\n    {comando_installazione(python)}\n"
            "oppure ripeti il comando aggiungendo `--installa`.")


def installa_pyinstaller(python: str | None = None, *, avvisa: Callable[[str], Any] = print) -> None:
    """``<python> -m pip install pyinstaller`` con il Python dell'ambiente attuale.

    ``python`` predefinito: ``sys.executable``, cioè proprio l'interprete che sta eseguendo
    Leo (con la .venv attiva è ``.venv\\Scripts\\python.exe``): PyInstaller finisce nello
    stesso ambiente di PySide6, dove la compilazione lo cercherà.
    """
    python = python or sys.executable
    avvisa(f"Installo PyInstaller con pip nell'ambiente di {python} (serve la connessione a Internet)...")
    try:
        r = subprocess.run([python, "-m", "pip", "install", "pyinstaller"], capture_output=True, text=True,
                           encoding="utf-8", errors="replace", **_opzioni_processo())
    except (OSError, subprocess.SubprocessError) as e:
        raise ErroreCompilazione(f"Non riesco ad avviare pip: {e}.") from None
    if r.returncode != 0:
        testo = ((r.stdout or "") + (r.stderr or "")).strip()
        coda = "\n".join(testo.splitlines()[-12:])
        suggerimento = ""
        if "No module named pip" in testo:
            suggerimento = f"\n\nIn questo Python manca pip: prima scrivi\n    \"{python}\" -m ensurepip --upgrade"
        raise ErroreCompilazione("L'installazione di PyInstaller non è riuscita:\n" + coda + suggerimento
                                 + f"\n\nPuoi provare a mano con:\n    {comando_installazione(python)}")


def esegui_pyinstaller(argomenti: Sequence[str], *, lavoro: Path, python: str | None = None,
                       registro: Path | None = None,
                       script_costruzione: Path | None = None) -> tuple[int, str]:
    """Lancia ``python -m PyInstaller``; restituisce (codice d'uscita, testo prodotto).

    Con ``script_costruzione`` (``costruisci_eseguibile.py``) lancia invece quello, che
    installa il filtro dei file di Qt e poi esegue PyInstaller con gli stessi argomenti.
    Il testo viene anche salvato in ``registro`` (se indicato).
    """
    python = python or sys.executable
    ambiente = dict(os.environ)
    ambiente.setdefault("PYTHONIOENCODING", "utf-8")
    # La copia di `leo` nella cartella di lavoro deve precedere un eventuale `leo` installato
    # nell'ambiente: vale anche per i sottoprocessi di PyInstaller (--collect-submodules).
    ambiente["PYTHONPATH"] = os.pathsep.join(
        [str(lavoro)] + ([ambiente["PYTHONPATH"]] if ambiente.get("PYTHONPATH") else []))
    try:
        comando = [python, str(script_costruzione)] if script_costruzione is not None \
            else [python, "-m", "PyInstaller"]
        r = subprocess.run([*comando, *argomenti], cwd=str(lavoro), env=ambiente,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                           encoding="utf-8", errors="replace", **_opzioni_processo())
    except (OSError, subprocess.SubprocessError) as e:
        raise ErroreCompilazione(f"Non riesco ad avviare PyInstaller: {e}.") from None
    testo = r.stdout or ""
    if registro is not None:
        try:
            registro.write_text(testo, encoding="utf-8")
        except OSError:
            pass
    return r.returncode, testo


def percorso_eseguibile(uscita: str | os.PathLike, nome: str, *, un_file: bool = True) -> Path | None:
    """Dove PyInstaller ha messo l'eseguibile (``Nome.exe`` o ``Nome/Nome.exe``); None se non c'è."""
    base = Path(uscita)
    if not un_file:
        base = base / nome
    for candidato in (base / f"{nome}.exe", base / nome):
        if candidato.is_file():
            return candidato
    return None


def _controlla_non_in_uso(uscita: Path, nome: str, un_file: bool) -> None:
    """Se l'eseguibile precedente è aperto, Windows non permette di sostituirlo: meglio dirlo subito."""
    base = uscita if un_file else uscita / nome
    exe = base / f"{nome}.exe"
    if exe.is_file():
        try:
            with open(exe, "r+b"):
                pass
        except PermissionError:
            raise ErroreCompilazione(
                f"`{exe}` è in uso (il programma è ancora aperto?). Chiudilo e riprova.") from None
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Firma e rapporto finale
# ---------------------------------------------------------------------------

def password_del_certificato(password: str | None = None) -> str | None:
    """La password indicata o, se manca, quella della variabile ``LEO_PASSWORD_CERTIFICATO``."""
    if password:
        return password
    return os.environ.get(VARIABILE_PASSWORD) or None


def firma_eseguibile(percorso: Path, certificato: str | os.PathLike,
                     password: str | None = None) -> tuple[bool, str]:
    """Firma l'eseguibile con ``leo.firma.firma_eseguibile``; (riuscita, messaggio).

    Il modulo della firma è facoltativo: se manca, la risposta lo spiega (niente eccezioni).
    """
    try:
        from .firma import firma_eseguibile as firma
    except ImportError as e:
        return False, (f"la firma non è disponibile in questa installazione di {NOME} "
                       f"(manca il modulo leo.firma: {e}).")
    try:
        esito = firma(Path(percorso), certificato=str(certificato), password=password)
    except Exception as e:  # noqa: BLE001 - un errore della firma non deve perdere l'eseguibile
        return False, f"errore durante la firma: {e}"
    try:
        riuscita, messaggio = esito
    except (TypeError, ValueError):
        riuscita, messaggio = bool(esito), ""
    return bool(riuscita), str(messaggio or "")


@dataclass
class Rapporto:
    """Riassunto di una compilazione, mostrato alla fine (vedi :meth:`testo`)."""

    eseguibile: Path
    cartella: Path                       # cartella da distribuire (onedir) o dell'exe (onefile)
    un_file: bool
    modalita: str
    dimensione_exe: int
    dimensione_totale: int               # onedir: tutta la cartella; onefile: l'exe
    numero_file: int
    qt_inclusi: list[str] = field(default_factory=list)       # vuoto = niente PySide6
    esclusi: list[str] = field(default_factory=list)          # descrizioni leggibili
    tolti: list[tuple[str, int]] = field(default_factory=list)
    ottimizza: int = 0
    upx: bool = False
    firma: str = ""                      # "" = non richiesta; altrimenti l'esito

    @property
    def byte_tolti(self) -> int:
        return sum(b for _n, b in self.tolti)

    def principali_tolti(self, quanti: int = 5) -> list[tuple[str, int]]:
        """I file tolti più grandi (nome senza cartella), dal più grande."""
        ordinati = sorted(self.tolti, key=lambda v: (-v[1], v[0]))
        return [(n.rsplit("/", 1)[-1], b) for n, b in ordinati[:quanti]]

    def testo(self) -> str:
        righe = ["", "Rapporto della compilazione"]
        if self.un_file:
            righe.append(f"  Formato:     un solo file ({formatta_dimensione(self.dimensione_exe)}); "
                         "a ogni avvio si decomprime in una cartella temporanea")
        else:
            righe.append(f"  Formato:     cartella ({self.numero_file} file, "
                         f"{formatta_dimensione(self.dimensione_totale)}): avvio veloce; "
                         "va distribuita tutta la cartella")
        righe.append(f"  Eseguibile:  {self.eseguibile}")
        righe.append(f"  Cartella:    {self.cartella}")
        righe.append("  Tipo:        " + ("a finestre (senza console)" if self.modalita == "finestra"
                                          else "con console"))
        righe.append("  Qt incluso:  " + (", ".join(self.qt_inclusi) if self.qt_inclusi
                                          else "nessuno (programma testuale: niente PySide6)"))
        if self.esclusi:
            righe.append("  Escluso:     " + "; ".join(self.esclusi))
        if self.tolti:
            dettaglio = ", ".join(f"{n} {formatta_dimensione(b)}" for n, b in self.principali_tolti())
            righe.append(f"  Tolti:       {len(self.tolti)} file di Qt non usati, "
                         f"{formatta_dimensione(self.byte_tolti)} (i più grandi: {dettaglio})")
        righe.append(f"  Bytecode:    ottimizzato (livello {self.ottimizza})" if self.ottimizza
                     else "  Bytecode:    non ottimizzato")
        righe.append("  UPX:         " + ("sì" if self.upx else "no"))
        if self.firma:
            righe.append(f"  Firma:       {self.firma}")
        return "\n".join(righe)


def qt_inclusi(piano: Piano) -> list[str]:
    """Moduli di Qt inclusi (nomi brevi), in ordine: vuoto se il programma è testuale."""
    if not piano.con_grafica:
        return []
    nomi = [m.split(".", 1)[1] for m in MODULI_QT_ESSENZIALI if m.startswith("PySide6.")]
    for gruppo in piano.moduli_qt:
        for modulo in MODULI_QT_FACOLTATIVI.get(gruppo, ((), frozenset()))[0]:
            if modulo.startswith("PySide6.") and modulo.split(".", 1)[1] not in nomi:
                nomi.append(modulo.split(".", 1)[1])
    return nomi


def descrivi_esclusi(prep: Preparazione) -> list[str]:
    """Descrizione breve di ciò che è stato escluso (per il rapporto)."""
    esclusi = set(prep.moduli_esclusi)
    voci: list[str] = []
    if "PySide6" in esclusi:
        voci.append("PySide6 intero")
    else:
        qt = sorted(m.split(".", 1)[1] for m in esclusi if m.startswith("PySide6."))
        if qt:
            esempi = [n for n in ("QtWebEngineCore", "QtQml", "QtQuick", "QtPdf", "Qt3DCore",
                                  "QtMultimedia", "QtNetwork") if n in qt]
            voci.append(f"{len(qt)} moduli di Qt (" + ", ".join(esempi[:5]) + (", ..." if len(qt) > 5 else "") + ")")
    parti_leo = {"leo.studio": "Leo Studio", "leo.lezioni": "lezioni", "leo.sfide": "sfide",
                 "leo.compila": "compilatore", "leo.repl": "REPL", "leo.grafica.qt": "motore grafico"}
    leo = [parti_leo[m] for m in prep.pacchetti_leo_esclusi if m in parti_leo]
    if leo:
        voci.append("di Leo: " + ", ".join(leo))
    stdlib = [m for m in ("tkinter", "unittest", "pydoc", "doctest", "lzma") if m in esclusi]
    if stdlib:
        voci.append("di Python: " + ", ".join(stdlib) + ", ...")
    if "thesaurus.dat" in prep.dati_esclusi:
        voci.append("dati non usati (thesaurus, lezioni, stemmi grandi)")
    return voci


def leggi_tolti(lavoro: Path) -> list[tuple[str, int]]:
    """File tolti dal filtro, letti da ``filtro_rapporto.json`` (vuoto se manca)."""
    try:
        dati = json.loads((Path(lavoro) / NOME_RAPPORTO_FILTRO).read_text(encoding="utf-8"))
        return [(str(n), int(b)) for n, b in dati.get("tolti", [])]
    except (OSError, ValueError, TypeError, AttributeError):
        return []


def crea_rapporto(prep: Preparazione, eseguibile: str | os.PathLike, *,
                  tolti: Iterable[tuple[str, int]] = (), firma: str = "") -> Rapporto:
    """Rapporto finale: misura l'eseguibile (e, con la cartella, tutti i suoi file)."""
    exe = Path(eseguibile)
    try:
        dimensione_exe = exe.stat().st_size
    except OSError:
        dimensione_exe = 0
    if prep.un_file:
        totale, numero = dimensione_exe, 1
    else:
        totale = dimensione_cartella(exe.parent)
        numero = sum(len(file) for _r, _c, file in os.walk(exe.parent))
    return Rapporto(eseguibile=exe, cartella=exe.parent, un_file=prep.un_file,
                    modalita=prep.piano.modalita, dimensione_exe=dimensione_exe,
                    dimensione_totale=totale, numero_file=numero, qt_inclusi=qt_inclusi(prep.piano),
                    esclusi=descrivi_esclusi(prep), tolti=list(tolti), ottimizza=prep.ottimizza,
                    upx=bool(prep.upx_dir), firma=firma)



# ---------------------------------------------------------------------------
# API principale
# ---------------------------------------------------------------------------

def compila_progetto(percorso: str | os.PathLike, *, uscita: str | os.PathLike | None = None,
                     nome: str | None = None, icona: str | os.PathLike | None = None,
                     modalita: str | None = None, un_file: bool = False,
                     avvisa: Callable[[str], Any] = print,
                     installa: bool = False, conferma: Callable[[str], bool] | None = None,
                     con_grafica: bool | None = None, conserva_lavoro: bool = False,
                     controlla_codice: bool = True, python: str | None = None,
                     lavoro: str | os.PathLike | None = None, autore: str | None = None,
                     descrizione: str | None = None, versione: str | None = None,
                     upx: bool = False, filtra: bool = True, ottimizza: int | None = None,
                     certificato: str | os.PathLike | None = None,
                     password_certificato: str | None = None, schermata_avvio: bool = True) -> Path:
    """Compila un programma ``.leo`` o un progetto in un eseguibile; restituisce il suo percorso.

    ``uscita``: cartella dell'eseguibile (predefinita: ``eseguibile`` accanto al programma,
    o dentro la cartella del progetto). ``nome``: nome dell'eseguibile (predefinito: nome
    del progetto o del file). ``icona``: file ``.ico`` (predefinita: lo stemma di Leo).
    ``modalita``: ``"finestra"`` (niente console), ``"console"`` o None (automatica).
    ``un_file``: un solo ``.exe`` (True: comodo, ma a ogni avvio si decomprime in una
    cartella temporanea, quindi parte più lentamente) o una cartella con l'exe e le
    librerie (False, predefinito: avvio immediato).
    ``avvisa``: riceve i messaggi di avanzamento. ``installa``: se PyInstaller manca lo
    installa con pip, dopo ``conferma(domanda)`` se data. ``conserva_lavoro``: non
    cancellare la cartella di lavoro. ``autore``, ``descrizione``, ``versione``: dati
    mostrati da Windows in *Proprietà > Dettagli* (None = quelli di ``progetto.toml``, se
    ci sono; l'autore predefinito è vuoto). ``upx``: comprimere con UPX se l'eseguibile
    ``upx`` è nel PATH (altrimenti si avvisa e si continua senza). ``filtra``: togliere i
    file di Qt non usati (False = tutto ciò che PyInstaller raccoglie, se l'exe non
    partisse). ``ottimizza``: livello di ``--optimize`` (None = automatico, di solito 2).
    ``certificato``: file ``.pfx`` per firmare l'eseguibile (``leo.firma``), con
    ``password_certificato`` o la variabile ``LEO_PASSWORD_CERTIFICATO``. Alla fine
    ``avvisa`` riceve il rapporto (dimensione, cartella, parti incluse ed escluse).
    Solleva :class:`ErroreCompilazione` (o :class:`PyInstallerMancante`) con un messaggio
    in italiano; se solo la firma non riesce, l'errore dice dov'è l'eseguibile creato.
    """
    if getattr(sys, "frozen", False):
        raise ErroreCompilazione("La compilazione non è disponibile da un programma già compilato.")
    # prova gratuita finita e nessuna licenza: niente eseguibili nuovi (quelli gia' creati funzionano)
    from .licenza import messaggio_blocco_compilazione

    blocco = messaggio_blocco_compilazione()
    if blocco:
        raise ErroreCompilazione(blocco, codice=1)
    sorgente = Path(percorso)
    if not sorgente.exists():
        raise ErroreCompilazione(f"Non trovo `{os.fspath(percorso)}`.", codice=2)
    if uscita is None:
        base = sorgente if sorgente.is_dir() else sorgente.parent
        if sorgente.is_file() and sorgente.name == "progetto.toml":
            base = sorgente.parent
        uscita_p = base / "eseguibile"
    else:
        uscita_p = Path(uscita)
    uscita_p = uscita_p.resolve() if uscita_p.exists() else Path(os.path.abspath(uscita_p))

    avvisa(f"Controllo {'il progetto' if sorgente.is_dir() else 'il programma'} `{sorgente.name}`...")
    piano = analizza_programma(sorgente, nome=nome, modalita=modalita, con_grafica=con_grafica,
                               uscita=uscita_p, controlla_codice=controlla_codice)
    for avviso in piano.avvisi:
        avvisa("Attenzione: " + avviso)
    if icona is not None and not Path(icona).is_file():
        raise ErroreCompilazione(f"Non trovo l'icona `{icona}`.", codice=2)
    if icona is not None and Path(icona).suffix.lower() != ".ico":
        avvisa("Attenzione: l'icona non è un file .ico; PyInstaller la converte solo se è installato Pillow.")
    if certificato is not None and not Path(certificato).is_file():
        raise ErroreCompilazione(f"Non trovo il certificato `{certificato}`.", codice=2)
    if icona is None and icona_predefinita() is None:
        avvisa("Attenzione: non trovo l'icona di Leo (dati/icone/leo.ico): l'eseguibile avrà l'icona generica.")

    # PyInstaller (e PySide6 se serve) nell'ambiente
    ambiente = sonda_ambiente(python)
    if not ambiente["pyinstaller"]:
        if not installa:
            raise PyInstallerMancante(messaggio_pyinstaller_mancante(python))
        domanda = "PyInstaller non è installato. Lo installo ora con pip?"
        if conferma is not None and not conferma(domanda):
            raise PyInstallerMancante("Installazione annullata.\n" + messaggio_pyinstaller_mancante(python))
        installa_pyinstaller(python, avvisa=avvisa)
        ambiente = sonda_ambiente(python)
        if not ambiente["pyinstaller"]:
            raise PyInstallerMancante("PyInstaller risulta ancora mancante dopo l'installazione.\n"
                                      + messaggio_pyinstaller_mancante(python))
    if versione_troppo_vecchia(ambiente["pyinstaller"]):
        avvisa(f"Attenzione: PyInstaller {ambiente['pyinstaller']} è vecchio; è consigliata la versione "
               f"{'.'.join(map(str, VERSIONE_PYINSTALLER_MINIMA))} o successiva:\n"
               f"    {comando_installazione(python)} --upgrade")
    if piano.con_grafica and not ambiente["pyside6"]:
        raise ErroreCompilazione(
            "Questo programma usa le finestre, ma in questo ambiente PySide6 non è installato.\n"
            f"Installalo con:\n    \"{python or sys.executable}\" -m pip install PySide6")
    if os.name != "nt":
        avvisa("Attenzione: PyInstaller crea eseguibili solo per il sistema su cui gira; "
               "per un .exe di Windows compila su Windows.")

    upx_dir: str | None = None
    if upx:
        programma_upx = shutil.which("upx")
        if programma_upx:
            upx_dir = str(Path(programma_upx).resolve().parent)
        else:
            avvisa("Attenzione: hai chiesto UPX, ma il programma `upx` non è nel PATH: "
                   "continuo senza comprimere.")

    # Preparazione
    if lavoro is None:
        cartella_lavoro = Path(tempfile.mkdtemp(prefix="leo_compila_"))
    else:
        cartella_lavoro = Path(lavoro)
    riuscito = False
    try:
        avvisa("Preparo i file del programma...")
        prep = prepara_cartella(piano, cartella_lavoro, icona=icona, un_file=un_file,
                                autore=autore, descrizione=descrizione, versione=versione,
                                filtra=filtra, ottimizza=ottimizza, upx_dir=upx_dir,
                                schermata_avvio=schermata_avvio)
        try:
            uscita_p.mkdir(parents=True, exist_ok=True)
        except OSError as e:
            raise ErroreCompilazione(f"Non riesco a creare la cartella `{uscita_p}`: {e.strerror or e}.") from None
        _controlla_non_in_uso(uscita_p, piano.nome, un_file)
        argomenti = argomenti_pyinstaller(prep, uscita=uscita_p, versione_pyinstaller=ambiente["pyinstaller"])
        tipo = "con finestre" if piano.modalita == "finestra" else "con console"
        formato = "un solo file" if un_file else "cartella"
        avvisa(f"Creo l'eseguibile {tipo} ({formato}) con PyInstaller {ambiente['pyinstaller']} "
               "(può richiedere qualche minuto)...")
        registro = prep.lavoro / "pyinstaller.log"
        codice, testo = esegui_pyinstaller(argomenti, lavoro=prep.lavoro, python=python, registro=registro,
                                           script_costruzione=prep.script_costruzione)
        if codice != 0:
            coda = "\n".join(testo.strip().splitlines()[-25:])
            raise ErroreCompilazione(
                f"PyInstaller si è fermato con un errore (codice {codice}).\n"
                f"Ultime righe:\n{coda}\n\nRegistro completo: {registro}")
        exe = percorso_eseguibile(uscita_p, piano.nome, un_file=un_file)
        if exe is None:
            raise ErroreCompilazione(
                f"PyInstaller ha terminato, ma non trovo l'eseguibile in `{uscita_p}`.\n"
                f"Registro completo: {registro}")
        tolti = leggi_tolti(prep.lavoro)
        riuscito = True
    finally:
        if riuscito and not conserva_lavoro:
            shutil.rmtree(cartella_lavoro, ignore_errors=True)
        elif not riuscito and cartella_lavoro.exists():
            avvisa(f"La cartella di lavoro resta in `{cartella_lavoro}` per controllare cosa è successo.")

    # File di dati accanto all'eseguibile (per i percorsi relativi del programma)
    copiati: list[str] = []
    for relativo in piano.file_dati:
        arrivo = exe.parent / relativo
        if not arrivo.exists():
            try:
                shutil.copy2(piano.cartella / relativo, arrivo)
                copiati.append(relativo)
            except OSError:
                pass
    if copiati:
        avvisa("Ho copiato accanto all'eseguibile i file di dati: " + ", ".join(copiati) + ".")

    # Firma (facoltativa): dopo UPX e prima di distribuire
    esito_firma = ""
    errore_firma = ""
    if certificato is not None:
        avvisa("Firmo l'eseguibile...")
        firmato, messaggio = firma_eseguibile(exe, certificato, password_del_certificato(password_certificato))
        if firmato:
            esito_firma = "firmato" + (f" ({messaggio})" if messaggio else "")
        else:
            errore_firma = messaggio or "motivo sconosciuto"
            esito_firma = "NON riuscita: " + errore_firma

    dimensione = exe.stat().st_size
    if un_file:
        avvisa(f"Eseguibile pronto: {exe} ({formatta_dimensione(dimensione)}).")
    else:
        totale = dimensione_cartella(exe.parent)
        avvisa(f"Eseguibile pronto: {exe} ({formatta_dimensione(dimensione)}; cartella completa "
               f"{formatta_dimensione(totale)}: va distribuita tutta la cartella `{exe.parent.name}`).")
    avvisa(crea_rapporto(prep, exe, tolti=tolti, firma=esito_firma).testo())
    if conserva_lavoro:
        avvisa(f"Cartella di lavoro conservata: {cartella_lavoro}")
    if errore_firma:
        raise ErroreCompilazione(f"L'eseguibile è pronto in `{exe}`, ma la firma non è riuscita: {errore_firma}")
    return exe


# ---------------------------------------------------------------------------
# Riga di comando: leo compila
# ---------------------------------------------------------------------------

def _parser_compila() -> Any:
    from .cli import _Analizzatore

    p = _Analizzatore(
        prog="leo compila",
        description="Crea un eseguibile Windows autonomo (.exe) da un programma .leo o da un progetto.\n"
                    "Serve PyInstaller nell'ambiente di Leo; chi usa l'eseguibile non ha bisogno "
                    "di installare nulla.",
        epilog="Esempi:\n"
               "  leo compila saluto.leo\n"
               "  leo compila Rubrica --uscita C:\\Consegne --icona rubrica.ico\n"
               "  leo compila Rubrica --console      (finestre più console per i messaggi di stampa)\n"
               "  leo compila Rubrica --un-file      (un solo .exe: comodo, ma parte più lentamente)\n"
               "  leo compila Rubrica --firma certificato.pfx\n"
               "  leo compila saluto.leo --apk       (app Android: si installa sul telefono)\n"
               "  leo compila Rubrica --apk --icona rubrica.png --versione-programma 1.2\n")
    p.add_argument("percorso", help="programma .leo o cartella di un progetto")
    p.add_argument("--uscita", default=None, metavar="CARTELLA",
                   help="dove mettere l'eseguibile (predefinito: la cartella `eseguibile` accanto al programma)")
    p.add_argument("--nome", default=None, help="nome dell'eseguibile (predefinito: nome del progetto o del file)")
    p.add_argument("--icona", default=None, metavar="FILE.ico",
                   help="icona dell'eseguibile (predefinita: lo stemma di Leo); con --apk un'immagine PNG")
    finestra = p.add_mutually_exclusive_group()
    finestra.add_argument("--console", dest="modalita", action="store_const", const="console",
                          help="con la finestra della console (predefinito per i programmi testuali)")
    finestra.add_argument("--finestra", dest="modalita", action="store_const", const="finestra",
                          help="senza console (predefinito per i progetti con finestre)")
    formato = p.add_mutually_exclusive_group()
    formato.add_argument("--cartella", "--piu-file", dest="un_file", action="store_false", default=False,
                         help="una cartella con l'exe e le librerie (predefinito: parte subito)")
    formato.add_argument("--un-file", dest="un_file", action="store_true",
                         help="un solo file .exe: comodo da spedire, ma a ogni avvio si decomprime "
                              "in una cartella temporanea, quindi parte più lentamente")
    p.add_argument("--autore", default=None, metavar="NOME",
                   help="autore del programma, mostrato nelle proprietà dell'exe (Copyright); "
                        "predefinito: `autore` di progetto.toml, altrimenti nessuno")
    p.add_argument("--descrizione", default=None, metavar="TESTO",
                   help="descrizione mostrata nelle proprietà dell'exe (predefinita: il nome)")
    p.add_argument("--versione-programma", default=None, metavar="X.Y.Z",
                   help="versione del programma nelle proprietà dell'exe (predefinita: 1.0.0.0)")
    p.add_argument("--upx", action="store_true",
                   help="comprime con UPX se il programma `upx` è nel PATH (facoltativo)")
    p.add_argument("--senza-schermata-avvio", dest="schermata_avvio", action="store_false", default=True,
                   help="niente schermata di avvio (l'icona del programma su fondo nero finché "
                        "non compare la sua prima finestra)")
    p.add_argument("--senza-filtro", dest="filtra", action="store_false",
                   help="non togliere le DLL, i plugin e le traduzioni di Qt non usati "
                        "(solo se l'eseguibile non parte)")
    p.add_argument("--ottimizza", type=int, choices=(0, 1, 2), default=None, metavar="{0,1,2}",
                   help="livello di ottimizzazione del bytecode (predefinito: 2)")
    p.add_argument("--firma", default=None, metavar="CERTIFICATO.pfx",
                   help="firma l'eseguibile con questo certificato")
    p.add_argument("--password-certificato", default=None, metavar="PASSWORD",
                   help=f"password del certificato (meglio la variabile {VARIABILE_PASSWORD})")
    android = p.add_argument_group("app Android (--apk)")
    android.add_argument("--apk", action="store_true",
                         help="crea un'app Android (.apk) invece dell'eseguibile di Windows: il programma "
                              "viene messo dentro l'app di Leo per Android (niente PyInstaller, Gradle o SDK)")
    android.add_argument("--guscio", default=None, metavar="LEO.apk",
                         help="app Android di Leo da usare come base (predefinita: android/Leo-*.apk)")
    android.add_argument("--pacchetto", default=None, metavar="it.scuola.rubrica",
                         help="identificativo dell'app su Android (predefinito: it.leo.app.<nome>)")
    android.add_argument("--codice-versione", type=int, default=None, metavar="N",
                         help="numero di versione per gli aggiornamenti (predefinito: ricavato dalla versione)")
    android.add_argument("--chiave", default=None, metavar="FILE.json",
                         help="chiave di firma (predefinita: chiave_apk.json nelle impostazioni di Leo, "
                              "creata la prima volta)")
    android.add_argument("--colore", default=None, metavar="#RRGGBB",
                         help="colore principale dell'app (predefinito: il rosso di Leo #D7132A)")
    android.add_argument("--tema", default=None, choices=("scuro", "chiaro"),
                         help="fondo dell'app: scuro (predefinito) o chiaro")
    android.add_argument("--tutte-le-architetture", dest="tutte_abi", action="store_true",
                         help="tiene tutti i processori del guscio (è già così: resta per compatibilità)")
    android.add_argument("--solo-telefoni", dest="solo_telefoni", action="store_true",
                         help="toglie x86_64 (l'emulatore del PC): l'app è più piccola e va comunque "
                              "su tutti i telefoni veri")
    android.add_argument("--app-completa", dest="app_completa", action="store_true",
                         help="non alleggerisce l'app: tiene tutto ciò che c'è nell'app di Leo (esempi, sito, "
                              "editor, tutto Python). Serve solo se l'app alleggerita non funzionasse")
    p.add_argument("--installa", action="store_true",
                   help="se PyInstaller manca, lo installa con pip nell'ambiente Python attuale")
    p.add_argument("--si", action="store_true", help="non chiedere conferme")
    p.add_argument("--conserva-lavoro", action="store_true",
                   help="non cancellare la cartella di lavoro (per controllare i file preparati)")
    return p


def _chiedi_conferma(domanda: str) -> bool:
    try:
        risposta = input(f"{domanda} [s/N] ")
    except (EOFError, KeyboardInterrupt):
        print()
        return False
    return risposta.strip().lower() in ("s", "si", "sì", "y", "yes")


def _comando_apk(args: Any, avvisa: Callable[[str], Any]) -> int:
    """``leo compila ... --apk``: app Android con :func:`leo.apk.crea_apk`."""
    from .apk import ABI_TELEFONI, ErroreApk, crea_apk
    from .licenza import messaggio_blocco_compilazione

    ignorate = [o for o, attiva in (("--un-file", args.un_file), ("--upx", args.upx), ("--firma", args.firma),
                                    ("--console/--finestra", args.modalita)) if attiva]
    if ignorate:
        avvisa("Attenzione: con --apk queste opzioni non servono e vengono ignorate: " + ", ".join(ignorate) + ".")
    blocco = messaggio_blocco_compilazione()
    if blocco:
        sys.stdout.flush()
        sys.stderr.write(f"leo compila: {blocco}\n")
        return 1
    try:
        risultato = crea_apk(args.percorso, guscio=args.guscio, uscita=args.uscita, nome=args.nome,
                             pacchetto=args.pacchetto, versione=args.versione_programma,
                             codice_versione=args.codice_versione, icona=args.icona, chiave=args.chiave,
                             abi=ABI_TELEFONI if getattr(args, "solo_telefoni", False) else None, avvisa=avvisa,
                             aspetto={"colore": args.colore, "tema": args.tema},
                             leggera=not getattr(args, "app_completa", False))
    except ErroreApk as e:
        sys.stdout.flush()
        sys.stderr.write(f"leo compila: {e.messaggio}\n")
        return e.codice
    except OSError as e:
        sys.stdout.flush()
        sys.stderr.write(f"leo compila: errore del disco: {e.strerror or e}.\n")
        return 1
    avvisa(risultato.testo())
    avvisa("Per installarla: copia il file sul telefono e aprilo (consenti \"Installa app sconosciute\"), "
           "oppure, con il cavo, adb install -r \"" + str(risultato.percorso) + "\".")
    return 0


def comando_compila(argv: Sequence[str]) -> int:
    """``leo compila ...``: restituisce il codice d'uscita (0, 1 o 2).

    Gli errori d'uso delle opzioni vengono gestiti da chi chiama (``leo.cli``).
    """
    args = _parser_compila().parse_args(list(argv))

    def avvisa(testo: str) -> None:
        print(testo, flush=True)

    if args.apk:
        return _comando_apk(args, avvisa)
    try:
        compila_progetto(args.percorso, uscita=args.uscita, nome=args.nome, icona=args.icona,
                         modalita=args.modalita, un_file=args.un_file, avvisa=avvisa,
                         installa=args.installa, conferma=None if args.si else _chiedi_conferma,
                         conserva_lavoro=args.conserva_lavoro, autore=args.autore,
                         descrizione=args.descrizione, versione=args.versione_programma,
                         upx=args.upx, filtra=args.filtra, ottimizza=args.ottimizza,
                         certificato=args.firma, password_certificato=args.password_certificato,
                         schermata_avvio=args.schermata_avvio)
    except ErroreCompilazione as e:
        sys.stdout.flush()
        sys.stderr.write(f"leo compila: {e.messaggio}\n")
        return e.codice
    return 0


# ---------------------------------------------------------------------------
# Il programma che avvia PyInstaller con il filtro dei file di Qt
# ---------------------------------------------------------------------------

_TESTA_COSTRUZIONE = '''# -*- coding: utf-8 -*-
"""Avvia PyInstaller togliendo i file che il programma non usa (generato da `leo compila`).

Legge le regole da `filtro_binari.json` (accanto a questo file), aggiunge il filtro
all'`Analysis` di PyInstaller (dopo che gli hook hanno raccolto DLL, plugin e
traduzioni) e poi esegue PyInstaller con gli argomenti ricevuti, come
`python -m PyInstaller ...`. I file tolti finiscono in `filtro_rapporto.json`.
Se PyInstaller cambia e il filtro non si puo' installare, la compilazione continua
senza filtro (con un avviso nel registro).
"""

import fnmatch
import json
import os
import runpy
import sys

QUI = os.path.dirname(os.path.abspath(__file__))


'''

_CORPO_COSTRUZIONE = '''

def carica_regole():
    try:
        with open(os.path.join(QUI, "filtro_binari.json"), "r", encoding="utf-8") as f:
            regole = json.load(f)
        return regole if isinstance(regole, dict) else {}
    except Exception:
        return {}


def installa_filtro(regole, rapporto):
    """Avvolge `Analysis.__init__` di PyInstaller: alla fine toglie da binari e dati
    i file che le regole scartano. Restituisce True se il filtro e' installato."""
    if not regole.get("scarta"):
        return False
    try:
        from PyInstaller.building import build_main
    except Exception:
        return False
    analisi = getattr(build_main, "Analysis", None)
    if analisi is None or getattr(analisi, "_filtro_leo", False):
        return False
    originale = analisi.__init__

    def __init__(self, *argomenti, **opzioni):
        originale(self, *argomenti, **opzioni)
        tolti = []
        for nome in ("binaries", "datas"):
            voci = getattr(self, nome, None)
            if voci is None:
                continue
            tenute = filtra_voci(list(voci), regole, tolti)
            try:
                voci[:] = tenute
            except TypeError:
                setattr(self, nome, tenute)
        try:
            with open(rapporto, "w", encoding="utf-8") as f:
                json.dump({"tolti": tolti}, f, indent=1)
        except Exception:
            pass
        byte = sum(b for _n, b in tolti)
        print("INFO: filtro di Leo: tolti %d file (%.1f MB) non usati dal programma"
              % (len(tolti), byte / 1048576.0), flush=True)

    analisi.__init__ = __init__
    analisi._filtro_leo = True
    return True


def main():
    regole = carica_regole()
    try:
        installato = installa_filtro(regole, os.path.join(QUI, "filtro_rapporto.json"))
    except Exception as e:
        installato = False
        print("WARNING: filtro di Leo non installato: %s" % e, flush=True)
    if regole.get("scarta") and not installato:
        print("WARNING: filtro di Leo non disponibile con questa versione di PyInstaller: "
              "l'eseguibile conterra' tutti i file raccolti.", flush=True)
    sys.argv = ["pyinstaller"] + sys.argv[1:]
    runpy.run_module("PyInstaller", run_name="__main__", alter_sys=True)


if __name__ == "__main__":
    main()
'''


def modello_costruzione() -> str:
    """Testo di ``costruisci_eseguibile.py``: contiene :func:`da_scartare` e :func:`filtra_voci`
    (le stesse funzioni di questo modulo: il filtro testato è quello che gira davvero)."""
    return (_TESTA_COSTRUZIONE + inspect.getsource(da_scartare) + "\n\n"
            + inspect.getsource(filtra_voci) + _CORPO_COSTRUZIONE)


# ---------------------------------------------------------------------------
# Il programma di avvio (copiato così com'è nella cartella di lavoro)
# ---------------------------------------------------------------------------

MODELLO_AVVIO = r'''# -*- coding: utf-8 -*-
"""Programma di avvio generato da `leo compila`: non modificarlo a mano.

Avvia il programma (o il progetto) che si trova nella cartella `programma`
accanto a questo file, con l'interprete della cartella `leo` e i dati della
cartella `dati`. Funziona sia dentro l'eseguibile creato da PyInstaller sia
lanciato con `python avvio_programma.py`.

Dentro l'eseguibile (`sys.frozen`) i file stanno nella cartella di PyInstaller
(`sys._MEIPASS`): con un solo file .exe e' una cartella temporanea, cancellata
alla chiusura. Per questo li' non si scrive mai: i file di dati del programma
vengono copiati (se mancano) accanto all'eseguibile e letti e scritti da li'.
"""

import io
import json
import os
import shutil
import sys
import time

CONGELATO = bool(getattr(sys, "frozen", False))


def _base():
    if CONGELATO:
        return getattr(sys, "_MEIPASS", None) or os.path.dirname(os.path.abspath(sys.executable))
    return os.path.dirname(os.path.abspath(__file__))


BASE = _base()
CARTELLA_PROGRAMMA = os.path.join(BASE, "programma")
#: Questo eseguibile sa fare da processo figlio di `mappa_in_parallelo` (`--leo-lavoratore`).
LAVORATORE_LEO = True


class _Raccolta(io.TextIOBase):
    """stderr di un eseguibile senza console: tiene solo le ultime righe (memoria limitata)."""

    LIMITE = 20000

    def __init__(self):
        super().__init__()
        self._testo = ""

    @property
    def encoding(self):
        return "utf-8"

    def writable(self):
        return True

    def isatty(self):
        return False

    def write(self, testo):
        testo = str(testo)
        self._testo = (self._testo + testo)[-self.LIMITE:]
        return len(testo)

    def getvalue(self):
        return self._testo


def _flussi():
    """Senza console (eseguibile a finestre) stdout/stderr/stdin sono None: li sostituiamo.

    stdout va nel nulla (un programma a finestre puo' stampare molto: niente memoria
    che cresce), stderr viene raccolto per mostrare gli errori in una finestra.
    """
    raccolta = None
    if sys.stdout is None:
        try:
            sys.stdout = open(os.devnull, "w", encoding="utf-8")
        except Exception:
            sys.stdout = _Raccolta()
    if sys.stderr is None:
        raccolta = _Raccolta()
        sys.stderr = raccolta
    if sys.stdin is None:
        sys.stdin = io.StringIO()
    return raccolta


def _avviso(titolo, testo):
    """Mostra un messaggio d'errore: finestra di Windows se possibile, altrimenti stderr."""
    testo = testo.strip() or "Errore sconosciuto."
    if len(testo) > 3000:
        testo = "...\n" + testo[-3000:]
    if os.name == "nt":
        try:
            import ctypes

            ctypes.windll.user32.MessageBoxW(None, testo, titolo, 0x10)
            return
        except Exception:
            pass
    flusso = sys.__stderr__ or sys.stderr
    try:
        flusso.write(titolo + ": " + testo + "\n")
    except Exception:
        pass


def _console_propria(un_file):
    """Vero se la console e' stata aperta solo per questo programma (doppio clic)."""
    if os.name != "nt" or not CONGELATO:
        return False
    try:
        import ctypes

        elenco = (ctypes.c_uint32 * 16)()
        quanti = ctypes.windll.kernel32.GetConsoleProcessList(elenco, 16)
        return 0 < quanti <= (2 if un_file else 1)
    except Exception:
        return False


# ---------------------------------------------------------------------------
# File scritti dal programma: mai nella cartella di PyInstaller
# ---------------------------------------------------------------------------

def _relativo(percorso, cartella):
    """Percorso relativo di `percorso` dentro `cartella` (None se sta fuori).

    Confronta sia i percorsi assoluti sia quelli risolti (su Windows la cartella
    temporanea puo' comparire con il nome corto, per esempio GENER~1).
    """
    for trasforma in (os.path.abspath, os.path.realpath):
        try:
            p = os.path.normcase(trasforma(percorso))
            c = os.path.normcase(trasforma(cartella))
            if p != c and os.path.commonpath([p, c]) == c:
                return os.path.relpath(p, c)
        except (ValueError, OSError, TypeError):
            continue
    return None


def _si_scrive(cartella):
    try:
        import tempfile

        os.makedirs(cartella, exist_ok=True)
        with tempfile.TemporaryFile(dir=cartella):
            pass
        return True
    except Exception:
        return False


def cartella_scrivibile(nome):
    """Dove il programma compilato tiene i suoi file: la cartella dell'eseguibile se ci si
    puo' scrivere, altrimenti la cartella `nome` in quella dell'utente."""
    accanto = os.path.dirname(os.path.abspath(sys.executable))
    candidate = []
    if _relativo(accanto, BASE) is None and os.path.normcase(accanto) != os.path.normcase(BASE):
        candidate.append(accanto)
    candidate.append(os.path.join(os.path.expanduser("~"), nome))
    for cartella in candidate:
        if _si_scrive(cartella):
            return cartella
    return candidate[0]


def fuori_dal_pacchetto(percorso, scrivibile):
    """Un percorso dentro la cartella `programma` inclusa diventa quello corrispondente
    nella cartella scrivibile, se li' il file c'e' o se non c'e' nemmeno nel pacchetto
    (file nuovo). Le risorse solo da leggere (immagini, suoni) restano nel pacchetto."""
    if not percorso or not scrivibile:
        return percorso
    try:
        testo = os.fspath(percorso)
    except TypeError:
        return percorso
    if not isinstance(testo, str):
        return percorso
    relativo = _relativo(testo, CARTELLA_PROGRAMMA)
    if relativo is None or relativo.split(os.sep)[0] == os.pardir:
        return percorso
    arrivo = os.path.join(scrivibile, relativo)
    if not os.path.exists(arrivo) and os.path.exists(testo):
        return percorso
    cartella_arrivo = os.path.dirname(arrivo)
    if not os.path.isdir(cartella_arrivo) and os.path.isdir(os.path.dirname(os.path.abspath(testo))):
        try:
            os.makedirs(cartella_arrivo, exist_ok=True)
        except OSError:
            pass
    if isinstance(percorso, str):
        return arrivo
    try:
        return type(percorso)(arrivo)
    except Exception:
        return arrivo


def copia_file_dati(configurazione, scrivibile):
    """Copia accanto all'eseguibile i file di dati del programma che ancora non ci sono."""
    copiati = []
    for relativo in configurazione.get("file_dati") or []:
        parti = [p for p in str(relativo).split("/") if p]
        if not parti or os.pardir in parti or os.path.isabs(str(relativo)):
            continue
        origine = os.path.join(CARTELLA_PROGRAMMA, *parti)
        arrivo = os.path.join(scrivibile, *parti)
        if os.path.exists(arrivo) or not os.path.isfile(origine):
            continue
        try:
            os.makedirs(os.path.dirname(arrivo), exist_ok=True)
            shutil.copy2(origine, arrivo)
            copiati.append(relativo)
        except Exception:
            pass
    return copiati


def _con_percorso_scrivibile(funzione, scrivibile):
    def funzione_scrivibile(*argomenti, **opzioni):
        return fuori_dal_pacchetto(funzione(*argomenti, **opzioni), scrivibile)

    funzione_scrivibile._avvio_originale = funzione
    funzione_scrivibile.__name__ = getattr(funzione, "__name__", "funzione")
    funzione_scrivibile.__doc__ = getattr(funzione, "__doc__", None)
    return funzione_scrivibile


#: (modulo, oggetto, attributo): funzioni di Leo che calcolano dove scrivere un file
#: relativo alla cartella del programma. Quelle grafiche solo se c'e' la grafica.
PUNTI_DI_SCRITTURA = (
    ("leo.tartaruga", None, "nome_svg"),
    ("leo.grafica.catalogo_dante", None, "_percorso"),
)
PUNTI_DI_SCRITTURA_GRAFICI = (
    ("leo.grafica.qt.widget_dante", None, "percorso_progetto"),
    ("leo.grafica.qt.widget_dispositivi", "_WidgetFotocamera", "_percorso_scatto"),
)


def _modifica(modulo, nome_oggetto, attributo, scrivibile):
    """Sostituisce la funzione con quella che scrive nella cartella scrivibile. Vero se fatto."""
    try:
        oggetto = getattr(modulo, nome_oggetto) if nome_oggetto else modulo
        funzione = getattr(oggetto, attributo)
    except Exception:
        return False
    if not callable(funzione) or getattr(funzione, "_avvio_originale", None) is not None:
        return False
    setattr(oggetto, attributo, _con_percorso_scrivibile(funzione, scrivibile))
    return True


class _CaricatoreConAzioni(object):
    """Carica il modulo come il caricatore vero, poi esegue le azioni prenotate."""

    def __init__(self, caricatore, azioni):
        self._caricatore = caricatore
        self._azioni = azioni

    def __getattr__(self, nome):
        return getattr(self._caricatore, nome)

    def create_module(self, spec):
        crea = getattr(self._caricatore, "create_module", None)
        return crea(spec) if crea is not None else None

    def exec_module(self, modulo):
        self._caricatore.exec_module(modulo)
        for azione in self._azioni:
            try:
                azione(modulo)
            except Exception:
                pass


class _DopoImportazione(object):
    """Cercatore di moduli (``sys.meta_path``) che non trova niente da se': lascia cercare
    agli altri e, per i moduli prenotati, esegue le azioni appena il modulo e' caricato.
    Cosi' i moduli grafici pesanti (widget_dante, fotocamera) si modificano solo se il
    programma li usa davvero, e non rallentano l'avvio."""

    def __init__(self):
        self.azioni = {}

    def prenota(self, nome_modulo, azione):
        self.azioni.setdefault(nome_modulo, []).append(azione)

    def find_spec(self, nome, percorso=None, bersaglio=None):
        azioni = self.azioni.get(nome)
        if not azioni:
            return None
        spec = None
        for cercatore in list(sys.meta_path):
            trova = getattr(cercatore, "find_spec", None)
            if cercatore is self or trova is None:
                continue
            try:
                spec = trova(nome, percorso, bersaglio)
            except Exception:
                spec = None
            if spec is not None:
                break
        if spec is None or spec.loader is None or not hasattr(spec.loader, "exec_module"):
            return spec
        del self.azioni[nome]
        spec.loader = _CaricatoreConAzioni(spec.loader, azioni)
        return spec


_DOPO_IMPORTAZIONE = _DopoImportazione()
_PRENOTATI = set()


def installa_percorsi_scrivibili(scrivibile, grafica):
    """Fa scrivere a Leo i file del programma nella cartella scrivibile. Restituisce i punti
    modificati: subito quelli dei moduli gia' importati, gli altri appena il programma
    importa il loro modulo (niente import in piu' all'avvio)."""
    import importlib.util

    modificati = []
    for nome_modulo, nome_oggetto, attributo in PUNTI_DI_SCRITTURA + (PUNTI_DI_SCRITTURA_GRAFICI if grafica else ()):
        punto = nome_modulo + ("." + nome_oggetto if nome_oggetto else "") + "." + attributo
        modulo = sys.modules.get(nome_modulo)
        if modulo is not None:
            if _modifica(modulo, nome_oggetto, attributo, scrivibile):
                modificati.append(punto)
            continue
        if punto in _PRENOTATI:
            continue
        try:
            if importlib.util.find_spec(nome_modulo) is None:     # c'e' (senza eseguirlo)?
                continue
        except Exception:
            continue

        def azione(modulo, nome_oggetto=nome_oggetto, attributo=attributo):
            _modifica(modulo, nome_oggetto, attributo, scrivibile)

        _DOPO_IMPORTAZIONE.prenota(nome_modulo, azione)
        _PRENOTATI.add(punto)
        modificati.append(punto)
    if _DOPO_IMPORTAZIONE.azioni and _DOPO_IMPORTAZIONE not in sys.meta_path:
        sys.meta_path.insert(0, _DOPO_IMPORTAZIONE)
    return modificati


# ---------------------------------------------------------------------------
# Avvio
# ---------------------------------------------------------------------------

def _cartella_per_importa(cartella):
    """`importa "file.leo"` cerca anche nella cartella del programma incluso."""
    try:
        from leo import interprete as modulo
    except Exception:
        return
    classe = getattr(modulo, "Interprete", None)
    originale = getattr(classe, "__init__", None)
    if classe is None or originale is None or getattr(classe, "_avvio_compilato", False):
        return

    def __init__(self, *argomenti, **opzioni):
        originale(self, *argomenti, **opzioni)
        try:
            if cartella not in self.percorsi_moduli:
                self.percorsi_moduli.append(cartella)
        except Exception:
            pass

    classe.__init__ = __init__
    classe._avvio_compilato = True


def _prepara_finestre(configurazione):
    """Icona delle finestre e raggruppamento nella barra delle applicazioni di Windows."""
    if os.name == "nt":
        try:
            import ctypes

            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                configurazione.get("id_applicazione") or "Leo.Programma")
        except Exception:
            pass
    icona = configurazione.get("icona") or ""
    if not icona:
        return
    try:
        from PySide6.QtGui import QIcon
        from PySide6.QtWidgets import QApplication

        app = QApplication.instance() or QApplication([sys.argv[0] if sys.argv else "programma"])
        app.setWindowIcon(QIcon(os.path.join(BASE, icona)))
        if configurazione.get("nome"):
            app.setApplicationName(configurazione["nome"])
    except Exception:
        pass


#: colori della schermata di avvio (gli stessi di Leo Studio: nero, grafite, rosso Leo)
COLORI_SCHERMATA = {"sfondo": "#0B0B0D", "bordo": "#2B2B31", "testo": "#ECECEF", "accento": "#E0182D"}
LATO_SCHERMATA = 300
LATO_ICONA_SCHERMATA = 128
#: la schermata sparisce da sola dopo questo tempo anche se non compare nessuna finestra
DURATA_MASSIMA_SCHERMATA = 20.0
DURATA_DISSOLVENZA = 0.18


def _schermata_avvio(configurazione):
    """Schermata di avvio leggera: icona e nome del programma su fondo nero.

    Compare appena PySide6 e' caricato e sparisce (dissolvenza breve) quando il
    programma mostra la sua prima finestra; mai piu' di DURATA_MASSIMA_SCHERMATA.
    Restituisce la schermata (o None: il programma parte comunque).
    """
    try:
        from PySide6.QtCore import QRectF, QSize, Qt, QTimer
        from PySide6.QtGui import QColor, QFont, QIcon, QPainter, QPen
        from PySide6.QtWidgets import QApplication, QWidget
    except Exception:
        return None
    try:
        app = QApplication.instance() or QApplication([sys.argv[0] if sys.argv else "programma"])
        schermo = app.primaryScreen()
        rapporto = max(1.0, float(schermo.devicePixelRatio())) if schermo is not None else 1.0
        nome = str(configurazione.get("nome") or "")
        immagine = None
        file_icona = configurazione.get("icona") or ""
        if file_icona:
            icona = QIcon(os.path.join(BASE, *file_icona.split("/")))
            if not icona.isNull():
                lato_px = int(LATO_ICONA_SCHERMATA * rapporto)
                immagine = icona.pixmap(QSize(lato_px, lato_px))
                if immagine.isNull():
                    immagine = None
                else:
                    immagine.setDevicePixelRatio(rapporto)
        lato = LATO_SCHERMATA

        class SchermataAvvio(QWidget):
            def __init__(self):
                super().__init__(None)
                tipo = Qt.WindowType
                self.setWindowFlags(tipo.SplashScreen | tipo.FramelessWindowHint | tipo.WindowStaysOnTopHint)
                self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
                self.setAttribute(Qt.WidgetAttribute.WA_QuitOnClose, False)
                self.setWindowTitle(nome or "Avvio")
                self.setFixedSize(lato, lato)
                if schermo is not None:
                    area = schermo.availableGeometry()
                    self.move(area.x() + (area.width() - lato) // 2, area.y() + (area.height() - lato) // 2)
                self._inizio = time.monotonic()
                self._uscita = None
                self._chiusa = False
                self._timer = QTimer(self)
                self._timer.setInterval(40)
                self._timer.timeout.connect(self._controlla)
                self._timer.start()

            def _altre_finestre(self):
                return [w for w in QApplication.topLevelWidgets()
                        if w is not self and w.isVisible() and w.isWindow()]

            def _controlla(self):
                if self._chiusa:
                    return
                adesso = time.monotonic()
                if self._uscita is None:
                    if self._altre_finestre() or adesso - self._inizio > DURATA_MASSIMA_SCHERMATA:
                        self._uscita = adesso
                    return
                frazione = (adesso - self._uscita) / DURATA_DISSOLVENZA
                if frazione >= 1.0:
                    self.chiudi()
                else:
                    self.setWindowOpacity(max(0.0, 1.0 - frazione))

            def chiudi(self):
                if self._chiusa:
                    return
                self._chiusa = True
                self._timer.stop()
                self.close()

            def paintEvent(self, _evento):
                p = QPainter(self)
                try:
                    p.setRenderHint(QPainter.RenderHint.Antialiasing)
                    p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
                    p.fillRect(QRectF(0, 0, lato, lato), QColor(COLORI_SCHERMATA["sfondo"]))
                    p.setPen(QPen(QColor(COLORI_SCHERMATA["bordo"]), 1))
                    p.drawRect(QRectF(0.5, 0.5, lato - 1, lato - 1))
                    alto = 58
                    if immagine is not None:
                        x = (lato - LATO_ICONA_SCHERMATA) / 2
                        p.drawPixmap(QRectF(x, alto, LATO_ICONA_SCHERMATA, LATO_ICONA_SCHERMATA), immagine,
                                     QRectF(0, 0, immagine.width(), immagine.height()))
                    y = alto + LATO_ICONA_SCHERMATA + 22
                    if nome:
                        carattere = QFont(self.font())
                        carattere.setPointSizeF(12.0)
                        carattere.setBold(True)
                        p.setFont(carattere)
                        p.setPen(QColor(COLORI_SCHERMATA["testo"]))
                        p.drawText(QRectF(16, y, lato - 32, 28),
                                   int(Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignVCenter), nome)
                    p.fillRect(QRectF((lato - 32) / 2, y + 40, 32, 2), QColor(COLORI_SCHERMATA["accento"]))
                finally:
                    p.end()

        schermata = SchermataAvvio()
        schermata.show()
        schermata.repaint()
        app.processEvents()
        return schermata
    except Exception:
        return None


def _chiudi_schermata(schermata):
    if schermata is None:
        return
    try:
        schermata.chiudi()
    except Exception:
        pass


def avvia():
    argomenti_programma = list(sys.argv[1:])
    if argomenti_programma[:1] == ["--leo-lavoratore"]:
        # processo lavoratore dei lavori `in parallelo` e di `mappa_in_parallelo` (con `--servizio`,
        # leo/parallelo_processi.py) o della forma "a file" (leo/libreria/programmi.py): niente programma
        if BASE not in sys.path:
            sys.path.insert(0, BASE)
        from leo.libreria.programmi import lavoratore_processo
        return lavoratore_processo(argomenti_programma[1:])
    raccolta = _flussi()
    if CONGELATO:
        sys.dont_write_bytecode = True        # nessun __pycache__ nella cartella di PyInstaller
    try:
        with open(os.path.join(BASE, "avvio.json"), "r", encoding="utf-8") as f:
            configurazione = json.load(f)
    except Exception as e:
        _avviso("Programma", "File di avvio mancante o rovinato: %s" % e)
        return 1
    nome = configurazione.get("nome") or "Programma"
    os.environ["LEO_DATI"] = os.path.join(BASE, "dati")
    if BASE not in sys.path:
        sys.path.insert(0, BASE)
    cartella = CARTELLA_PROGRAMMA
    avvio = configurazione.get("avvio") or ""
    bersaglio = os.path.join(cartella, *avvio.split("/")) if avvio else cartella
    sys.argv = [sys.argv[0] if sys.argv else nome, bersaglio]
    finestra = configurazione.get("modalita") == "finestra"
    grafica = bool(configurazione.get("grafica", finestra))
    codice = 1
    schermata = None
    try:
        _cartella_per_importa(cartella)
        if CONGELATO:
            scrivibile = cartella_scrivibile(nome)
            copia_file_dati(configurazione, scrivibile)
            installa_percorsi_scrivibili(scrivibile, grafica)
        if finestra:
            _prepara_finestre(configurazione)
            if grafica and configurazione.get("schermata_avvio"):
                schermata = _schermata_avvio(configurazione)
        from leo.cli import main

        codice = main([bersaglio, "--correggi=no", "--", *argomenti_programma])
    except SystemExit as e:
        codice = e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
    except BaseException:
        import traceback

        _chiudi_schermata(schermata)
        testo = traceback.format_exc()
        if raccolta is not None:
            _avviso(nome, "Errore imprevisto:\n\n" + raccolta.getvalue() + testo)
            raccolta = None
        else:
            sys.stderr.write(testo)
        codice = 1
    _chiudi_schermata(schermata)
    # Il motore grafico mostra da se' i suoi errori in una finestra: qui si avvisa solo
    # di cio' che e' successo prima (per esempio PySide6 mancante), senza doppioni.
    motore_avviato = "leo.grafica.qt.applicazione" in sys.modules
    if codice and raccolta is not None and raccolta.getvalue().strip() and not motore_avviato:
        _avviso(nome, raccolta.getvalue())
    if not finestra and _console_propria(configurazione.get("un_file", True)):
        try:
            sys.stdout.flush()
            input("\nPremi Invio per chiudere...")
        except Exception:
            pass
    return codice


if __name__ == "__main__":
    sys.exit(avvia())
'''
