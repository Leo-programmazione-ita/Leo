"""Licenza di Leo Studio: prova gratuita di 90 giorni e chiavi di licenza firmate.

Regole decise dal proprietario:

* dal primo avvio ci sono :data:`GIORNI_PROVA` giorni di prova completa;
* poi serve una **chiave di licenza** per usare Leo Studio e per ``leo compila``;
* i programmi gia' compilati e ``leo programma.leo`` funzionano SEMPRE: qui non c'e'
  niente che l'interprete controlli (questo modulo non entra negli eseguibili).

Chiavi (``LEO-XXXXXX-XXXXXX-...``): dati del cliente (nome, email, tipo, emissione,
scadenza facoltativa, versione massima facoltativa, identificativo) firmati con
**Ed25519**. Per verificarle basta la libreria standard: l'algoritmo e' scritto qui
in Python puro, seguendo la RFC 8032 (l'app congelata non ha ``cryptography``). Ogni
blocco di 6 caratteri termina con un carattere di controllo: un errore di battitura
viene riconosciuto e indicato col numero del blocco.

Prova: la data del primo avvio e l'ultima data vista sono salvate due volte (file
``licenza.dat`` nella cartella utente di Leo e, su Windows, ``HKCU\\Software\\Leo``),
con un'impronta HMAC contro le modifiche casuali (il segreto e' nel codice: NON e'
una protezione forte, vedi ``docs/LICENZE.md``). Se l'orologio viene portato indietro
si contano i giorni dall'ultima data vista.

Sviluppo: con ``LEO_LICENZA_SVILUPPO=1`` e il file ``strumenti/licenze/sviluppo.cfg``
nella cartella del sorgente (mai nell'app installata) i controlli sono spenti.

API principale::

    GestoreLicenza(archivi=None, oggi=None, versione=None, sviluppo=None)
        .stato() -> StatoLicenza          # in_prova / scaduta / attiva / sviluppo
        .attiva(testo) -> Licenza         # accetta anche un'intera email
        .togli() -> None
        .promemoria(stato=None) -> int | None
    verifica_chiave(testo, oggi=None, versione=None) -> Licenza   # ChiaveNonValida
    estrai_chiave(testo) -> str | None
    messaggio_blocco_compilazione() -> str   # "" se si puo' compilare
    comando_licenza(argv) -> int             # `leo licenza ...`
"""

from __future__ import annotations

import base64
import datetime as _dt
import hashlib
import hmac
import json
import os
import re
import struct
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable, Sequence

# ===========================================================================
# Impostazioni del proprietario
# ===========================================================================

#: giorni di prova gratuita completa dal primo avvio
GIORNI_PROVA = 90
#: promemoria (non invadenti) quando mancano questi giorni, al massimo uno al giorno
SOGLIE_PROMEMORIA = (14, 7, 3, 1)
#: negli ultimi giorni l'etichetta della barra di stato cambia colore
GIORNI_ARANCIONE = 14
GIORNI_ROSSO = 3
#: pagina dove acquistare una licenza; vuoto = si mostra l'email di contatto
URL_ACQUISTO = ""
#: email a cui scrivere per acquistare (vuota = si rimanda al titolare, vedi LICENZA.txt)
EMAIL_CONTATTO = ""
#: la chiave di licenza si richiede SOLO per telefono (numero comunicato dal titolare)
TELEFONO_CONTATTO = "+39 350 059 0978"
#: titolare (per i messaggi)
TITOLARE = "Rosario Zappalà"

#: chiave PUBBLICA Ed25519 (64 cifre esadecimali). La scrive
#: ``strumenti/licenze/genera_chiave.py`` quando crea la coppia di chiavi.
#: Vuota = nessuna chiave puo' essere verificata (solo la prova funziona).
CHIAVE_PUBBLICA = "ca95180bbefcae65f9f38d4dad480014dd3d601c34a047c9b0618dc255c4df3f"

#: segreto dell'impronta HMAC dei dati della prova. E' nel codice: chiunque legga il
#: sorgente lo trova. Serve solo contro le modifiche casuali del file.
_SEGRETO_IMPRONTA = b"Leo/prova/impronta/v1:ruggito-rosso-su-nero"

NOME_FILE = "licenza.dat"
CHIAVE_REGISTRO = r"Software\Leo"
VALORE_REGISTRO = "Licenza"
VARIABILE_SVILUPPO = "LEO_LICENZA_SVILUPPO"
#: file che, nel sorgente, abilita la modalita' sviluppo (non esiste nell'app installata)
FILE_SVILUPPO = Path(__file__).resolve().parent.parent / "strumenti" / "licenze" / "sviluppo.cfg"

TIPI = ("personale", "scuola", "azienda")
NOMI_TIPI = {"personale": "Personale", "scuola": "Scuola", "azienda": "Azienda",
             "promozionale": "Promozionale (senza scadenza)"}

# Codici promozionali: nel programma c'e' solo l'impronta (PBKDF2), mai il codice in chiaro.
# Si confrontano senza spazi e senza distinguere maiuscole/minuscole.
_SALE_PROMOZIONE = b"leo-codice-promozionale-v1"
_CICLI_PROMOZIONE = 20000
CODICI_PROMOZIONALI = {
    # impronta -> (intestatario, identificativo)
    "d7dbf6d6d6be77a4156c9279f1f1e99274df9c090d71991da03c4c6a7a99c230": ("Codice promozionale RZ81", "PROMO-RZ81"),
}

PREFISSO = "LEO"
ALFABETO = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
#: caratteri facili da confondere: zero -> O, uno -> I, otto -> B
_SOSTITUZIONI = str.maketrans({"0": "O", "1": "I", "8": "B"})
#: caratteri di dati per blocco (+1 di controllo)
DATI_PER_BLOCCO = 5
_EPOCA = _dt.date(2024, 1, 1)
_FORMATO = 1
_DOMINIO_FIRMA = b"LEO-LICENZA\x00"
_TESTA = struct.Struct(">BBHHBB6s")
LUNGHEZZA_FIRMA = 64
_NESSUNA_VERSIONE = 0xFF


# ===========================================================================
# Ed25519 in Python puro (RFC 8032, sezioni 5.1 e 6)
# ===========================================================================

_P = 2 ** 255 - 19
_L = 2 ** 252 + 27742317777372353535851937790883648493
_D = -121665 * pow(121666, _P - 2, _P) % _P
_D2 = 2 * _D % _P
_RADICE_MENO_UNO = pow(2, (_P - 1) // 4, _P)


def _somma(a: tuple, b: tuple) -> tuple:
    x1, y1, z1, t1 = a
    x2, y2, z2, t2 = b
    p = _P
    aa = (y1 - x1) * (y2 - x2) % p
    bb = (y1 + x1) * (y2 + x2) % p
    cc = t1 * _D2 * t2 % p
    dd = 2 * z1 * z2 % p
    e, f, g, h = bb - aa, dd - cc, dd + cc, bb + aa
    return e * f % p, g * h % p, f * g % p, e * h % p


def _doppio(a: tuple) -> tuple:
    x1, y1, z1, _t1 = a
    p = _P
    aa = x1 * x1 % p
    bb = y1 * y1 % p
    cc = 2 * z1 * z1 % p
    h = aa + bb
    e = h - (x1 + y1) * (x1 + y1)
    g = aa - bb
    f = cc + g
    return e * f % p, g * h % p, f * g % p, e * h % p


_NEUTRO = (0, 1, 1, 0)


def _recupera_x(y: int, segno: int) -> int | None:
    if y >= _P:
        return None
    x2 = (y * y - 1) * pow(_D * y * y + 1, _P - 2, _P) % _P
    if x2 == 0:
        return None if segno else 0
    x = pow(x2, (_P + 3) // 8, _P)
    if (x * x - x2) % _P != 0:
        x = x * _RADICE_MENO_UNO % _P
    if (x * x - x2) % _P != 0:
        return None
    if (x & 1) != segno:
        x = _P - x
    return x


_BY = 4 * pow(5, _P - 2, _P) % _P
_BX = _recupera_x(_BY, 0)
_BASE = (_BX, _BY, 1, _BX * _BY % _P)


def _comprimi(punto: tuple) -> bytes:
    x, y, z, _t = punto
    inv = pow(z, _P - 2, _P)
    x, y = x * inv % _P, y * inv % _P
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _decomprimi(dati: bytes) -> tuple | None:
    if len(dati) != 32:
        return None
    y = int.from_bytes(dati, "little")
    segno = y >> 255
    y &= (1 << 255) - 1
    x = _recupera_x(y, segno)
    if x is None:
        return None
    return x, y, 1, x * y % _P


def _moltiplica(k: int, punto: tuple) -> tuple:
    risultato = _NEUTRO
    for bit in bin(k)[2:]:
        risultato = _doppio(risultato)
        if bit == "1":
            risultato = _somma(risultato, punto)
    return risultato


def _doppia_moltiplicazione(a: int, p: tuple, b: int, q: tuple) -> tuple:
    """[a]P + [b]Q con il metodo di Straus (una sola serie di raddoppi)."""
    pq = _somma(p, q)
    risultato = _NEUTRO
    for i in range(max(a.bit_length(), b.bit_length()) - 1, -1, -1):
        risultato = _doppio(risultato)
        ba, bb = (a >> i) & 1, (b >> i) & 1
        if ba and bb:
            risultato = _somma(risultato, pq)
        elif ba:
            risultato = _somma(risultato, p)
        elif bb:
            risultato = _somma(risultato, q)
    return risultato


def _sha512_intero(*parti: bytes) -> int:
    h = hashlib.sha512()
    for parte in parti:
        h.update(parte)
    return int.from_bytes(h.digest(), "little")


def _espandi_segreto(segreto: bytes) -> tuple[int, bytes]:
    if len(segreto) != 32:
        raise ValueError("La chiave privata Ed25519 deve essere di 32 byte.")
    h = hashlib.sha512(segreto).digest()
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def ed25519_pubblica(segreto: bytes) -> bytes:
    """Chiave pubblica (32 byte) dalla chiave privata (32 byte)."""
    a, _prefisso = _espandi_segreto(segreto)
    return _comprimi(_moltiplica(a, _BASE))


def ed25519_firma(segreto: bytes, messaggio: bytes) -> bytes:
    """Firma Ed25519 (64 byte) di ``messaggio`` (RFC 8032, 5.1.6)."""
    a, prefisso = _espandi_segreto(segreto)
    pubblica = _comprimi(_moltiplica(a, _BASE))
    r = _sha512_intero(prefisso, messaggio) % _L
    rr = _comprimi(_moltiplica(r, _BASE))
    k = _sha512_intero(rr, pubblica, messaggio) % _L
    s = (r + k * a) % _L
    return rr + int.to_bytes(s, 32, "little")


def ed25519_verifica(pubblica: bytes, messaggio: bytes, firma: bytes) -> bool:
    """Vero se ``firma`` e' una firma Ed25519 valida di ``messaggio`` (RFC 8032, 5.1.7).

    Controlla ``[S]B == R + [k]A`` calcolando ``[S]B - [k]A`` e confrontandone la
    codifica con ``R`` (come fa OpenSSL); rifiuta ``S >= L`` e punti non validi.
    """
    if len(pubblica) != 32 or len(firma) != 64:
        return False
    punto_a = _decomprimi(pubblica)
    if punto_a is None:
        return False
    rr, s = firma[:32], int.from_bytes(firma[32:], "little")
    if s >= _L or _decomprimi(rr) is None:
        return False
    k = _sha512_intero(rr, pubblica, messaggio) % _L
    x, y, z, t = punto_a
    meno_a = ((-x) % _P, y, z, (-t) % _P)
    return _comprimi(_doppia_moltiplicazione(s, _BASE, k, meno_a)) == rr


# ===========================================================================
# Chiavi di licenza
# ===========================================================================

class ChiaveNonValida(ValueError):
    """Chiave rifiutata. ``codice``: vuota, formato, battitura, firma, scaduta, versione,
    nessuna_chiave_pubblica. ``messaggio``: spiegazione in italiano."""

    def __init__(self, codice: str, messaggio: str) -> None:
        super().__init__(messaggio)
        self.codice = codice
        self.messaggio = messaggio


@dataclass(frozen=True)
class Licenza:
    nome: str
    email: str
    tipo: str
    emissione: _dt.date
    scadenza: _dt.date | None
    versione_massima: tuple | None
    identificativo: str
    chiave: str

    @property
    def perpetua(self) -> bool:
        return self.scadenza is None

    @property
    def testo_versione(self) -> str:
        return "" if self.versione_massima is None else "%d.%d" % self.versione_massima

    @property
    def intestatario(self) -> str:
        return self.nome or self.email

    def descrizione(self) -> str:
        """Righe leggibili (per Informazioni e ``leo licenza``)."""
        righe = [f"Intestata a: {self.nome}" + (f" <{self.email}>" if self.email else ""),
                 f"Tipo: {NOMI_TIPI.get(self.tipo, self.tipo)}",
                 f"Emessa il: {_data_it(self.emissione)}",
                 "Scadenza: " + ("nessuna (perpetua)" if self.scadenza is None else _data_it(self.scadenza))]
        if self.versione_massima is not None:
            righe.append(f"Valida fino alla versione: {self.testo_versione}")
        righe.append(f"Codice: {self.identificativo}")
        return "\n".join(righe)


def _data_it(data: _dt.date) -> str:
    return data.strftime("%d/%m/%Y")


def _giorni(data: _dt.date) -> int:
    n = (data - _EPOCA).days
    if not 0 <= n <= 0xFFFF:
        raise ValueError(f"Data fuori intervallo: {data}")
    return n


def componi_dati(nome: str, email: str, tipo: str, emissione: _dt.date, scadenza: _dt.date | None = None,
                 versione_massima: tuple | None = None, identificativo: bytes | None = None) -> bytes:
    """I byte firmati di una chiave (usata dal generatore)."""
    if tipo not in TIPI:
        raise ValueError(f"Tipo sconosciuto: {tipo} (validi: {', '.join(TIPI)})")
    nome_b = (nome or "").strip().encode("utf-8")
    email_b = (email or "").strip().encode("utf-8")
    if len(nome_b) > 80 or len(email_b) > 80:
        raise ValueError("Nome ed email devono stare in 80 byte ciascuno.")
    if identificativo is None:
        identificativo = os.urandom(6)
    if len(identificativo) != 6:
        raise ValueError("L'identificativo deve essere di 6 byte.")
    if versione_massima is None:
        vmax = (_NESSUNA_VERSIONE, _NESSUNA_VERSIONE)
    else:
        vmax = (int(versione_massima[0]), int(versione_massima[1]))
        if not all(0 <= v < _NESSUNA_VERSIONE for v in vmax):
            raise ValueError("Versione massima non valida.")
    testa = _TESTA.pack(_FORMATO, TIPI.index(tipo), _giorni(emissione),
                        0 if scadenza is None else _giorni(scadenza), vmax[0], vmax[1], identificativo)
    return testa + bytes([len(nome_b)]) + nome_b + bytes([len(email_b)]) + email_b


def _leggi_dati(dati: bytes) -> tuple:
    """(nome, email, tipo, emissione, scadenza, versione, identificativo, lunghezza) o ValueError."""
    if len(dati) < _TESTA.size + 2:
        raise ValueError("troppo corta")
    formato, tipo, em, sc, vmaj, vmin, ident = _TESTA.unpack_from(dati)
    if formato != _FORMATO or tipo >= len(TIPI):
        raise ValueError("formato")
    pos = _TESTA.size
    n = dati[pos]
    nome = dati[pos + 1:pos + 1 + n]
    pos += 1 + n
    if pos >= len(dati):
        raise ValueError("troppo corta")
    m = dati[pos]
    email = dati[pos + 1:pos + 1 + m]
    pos += 1 + m
    if len(nome) != n or len(email) != m:
        raise ValueError("troppo corta")
    versione = None if (vmaj, vmin) == (_NESSUNA_VERSIONE, _NESSUNA_VERSIONE) else (vmaj, vmin)
    return (nome.decode("utf-8"), email.decode("utf-8"), TIPI[tipo], _EPOCA + _dt.timedelta(days=em),
            None if sc == 0 else _EPOCA + _dt.timedelta(days=sc), versione, ident.hex().upper(), pos)


def _controllo(indice: int, blocco: str) -> str:
    impronta = hashlib.sha256(f"{indice}:{blocco}".encode("ascii")).digest()
    return ALFABETO[impronta[0] % 32]


def formatta_chiave(byte_chiave: bytes) -> str:
    """``LEO-`` + blocchi di 5 caratteri base32 + 1 di controllo, separati da trattini."""
    testo = base64.b32encode(byte_chiave).decode("ascii").rstrip("=")
    blocchi = []
    for i in range(0, len(testo), DATI_PER_BLOCCO):
        parte = testo[i:i + DATI_PER_BLOCCO]
        blocchi.append(parte + _controllo(len(blocchi) + 1, parte))
    return PREFISSO + "-" + "-".join(blocchi)


def componi_chiave(dati: bytes, firma: bytes) -> str:
    if len(firma) != LUNGHEZZA_FIRMA:
        raise ValueError("La firma Ed25519 deve essere di 64 byte.")
    return formatta_chiave(dati + firma)


def messaggio_da_firmare(dati: bytes) -> bytes:
    return _DOMINIO_FIRMA + dati


def _decodifica_caratteri(caratteri: str) -> bytes:
    """Dai caratteri (senza separatori) ai byte, controllando ogni blocco."""
    passo = DATI_PER_BLOCCO + 1
    if not caratteri or len(caratteri) % passo == 1:
        raise ChiaveNonValida("formato", "La chiave è incompleta: controlla di averla copiata tutta.")
    dati = []
    for n, i in enumerate(range(0, len(caratteri), passo), start=1):
        blocco = caratteri[i:i + passo]
        parte, controllo = blocco[:-1], blocco[-1]
        if any(c not in ALFABETO for c in blocco) or _controllo(n, parte) != controllo:
            raise ChiaveNonValida("battitura", f"Nel blocco {n} della chiave (\"{blocco}\") c'è un errore di "
                                               "battitura: controllalo, oppure copia e incolla la chiave dall'email.")
        dati.append(parte)
    testo = "".join(dati)
    try:
        grezzo = base64.b32decode(testo + "=" * (-len(testo) % 8))
    except (ValueError, TypeError):
        raise ChiaveNonValida("formato", "La chiave è incompleta: controlla di averla copiata tutta.") from None
    if base64.b32encode(grezzo).decode("ascii").rstrip("=") != testo:
        raise ChiaveNonValida("formato", "La chiave è incompleta: controlla di averla copiata tutta.")
    return grezzo


_RE_PREFISSO = re.compile(r"(?<![A-Za-z0-9])LE[O0]", re.IGNORECASE)
_RE_PEZZO = re.compile(r"[\s\-‐-―−>]*([A-Za-z0-9]+)")


def _pezzi_dopo(testo: str, inizio: int, massimo: int = 120) -> list[str]:
    pezzi = []
    pos = inizio
    while len(pezzi) < massimo:
        m = _RE_PEZZO.match(testo, pos)
        if m is None:
            break
        pezzi.append(m.group(1).upper().translate(_SOSTITUZIONI))
        pos = m.end()
    return pezzi


def _analizza_pezzi(pezzi: Sequence[str]) -> tuple[bytes, str]:
    """(byte della chiave, chiave in forma canonica) dai pezzi dopo ``LEO``."""
    grezzo = _decodifica_caratteri("".join(pezzi))
    if len(grezzo) <= LUNGHEZZA_FIRMA:
        raise ChiaveNonValida("formato", "La chiave è incompleta: controlla di averla copiata tutta.")
    try:
        lunghezza = _leggi_dati(grezzo[:-LUNGHEZZA_FIRMA])[-1]
    except (ValueError, UnicodeDecodeError, IndexError, struct.error):
        raise ChiaveNonValida("formato", "Questo testo non è una chiave di licenza di Leo.") from None
    if lunghezza + LUNGHEZZA_FIRMA != len(grezzo):
        raise ChiaveNonValida("formato", "Questo testo non è una chiave di licenza di Leo.")
    return grezzo, formatta_chiave(grezzo)


def _candidati(testo: str) -> Iterable[list[str]]:
    for m in _RE_PREFISSO.finditer(testo):
        yield _pezzi_dopo(testo, m.end())
    # senza "LEO": forse sono solo i blocchi
    yield _pezzi_dopo(testo, 0)


def _trova(testo: str) -> tuple[bytes, str]:
    """Cerca la chiave in un testo qualsiasi (anche un'email intera)."""
    if not (testo or "").strip():
        raise ChiaveNonValida("vuota", "Incolla la chiave di licenza (inizia con LEO-).")
    errori: list[ChiaveNonValida] = []
    for pezzi in _candidati(testo):
        # la chiave puo' essere seguita da altro testo: si prova dal piu' lungo al piu' corto
        for fine in range(len(pezzi), 0, -1):
            try:
                return _analizza_pezzi(pezzi[:fine])
            except ChiaveNonValida as e:
                if fine == len(pezzi):
                    errori.append(e)
    if not errori or not _RE_PREFISSO.search(testo):
        raise ChiaveNonValida("formato", "Non trovo una chiave di licenza di Leo in questo testo "
                                         "(la chiave inizia con LEO-).")
    raise next((e for e in errori if e.codice == "battitura"), errori[0])


def estrai_chiave(testo: str) -> str | None:
    """La chiave (in forma canonica) trovata in ``testo``, o None. Non controlla la firma."""
    try:
        return _trova(testo)[1]
    except ChiaveNonValida:
        return None


def _versione_tupla(versione: str) -> tuple:
    numeri = re.findall(r"\d+", str(versione))
    return tuple(int(n) for n in (numeri + ["0", "0"])[:2])


def _versione_leo() -> str:
    try:
        from . import __version__
        return __version__
    except ImportError:  # pragma: no cover
        return "0.0.0"


def _normalizza_promozione(testo: str) -> str:
    return re.sub(r"\s+", "", testo or "").lower()


def licenza_promozionale(testo: str) -> "Licenza | None":
    """La licenza perpetua di un codice promozionale (``testo`` = solo il codice), o None."""
    codice = _normalizza_promozione(testo)
    if not codice or len(codice) > 64 or codice.startswith("leo-"):
        return None
    impronta = hashlib.pbkdf2_hmac("sha256", codice.encode("utf-8"), _SALE_PROMOZIONE,
                                   _CICLI_PROMOZIONE).hex()
    for nota, (intestatario, ident) in CODICI_PROMOZIONALI.items():
        if hmac.compare_digest(nota, impronta):
            return Licenza(intestatario, "", "promozionale", _dt.date(2026, 9, 27), None, None, ident,
                           (testo or "").strip())
    return None


def verifica_chiave(testo: str, oggi: _dt.date | None = None, versione: str | None = None,
                    chiave_pubblica: str | None = None) -> Licenza:
    """Controlla una chiave (anche dentro un testo piu' lungo): firma, scadenza, versione.

    Restituisce la :class:`Licenza`; solleva :class:`ChiaveNonValida` con un messaggio chiaro.
    """
    promozione = licenza_promozionale(testo)
    if promozione is not None:
        return promozione
    grezzo, canonica = _trova(testo)
    pubblica_hex = CHIAVE_PUBBLICA if chiave_pubblica is None else chiave_pubblica
    try:
        pubblica = bytes.fromhex(pubblica_hex)
    except ValueError:
        pubblica = b""
    if len(pubblica) != 32:
        raise ChiaveNonValida("nessuna_chiave_pubblica",
                              "Questa copia di Leo non ha ancora la chiave per verificare le licenze: "
                              "scarica la versione ufficiale più recente.")
    dati, firma = grezzo[:-LUNGHEZZA_FIRMA], grezzo[-LUNGHEZZA_FIRMA:]
    if not ed25519_verifica(pubblica, messaggio_da_firmare(dati), firma):
        raise ChiaveNonValida("firma", "La chiave non è valida: non è stata emessa per Leo oppure è stata "
                                       "modificata. Copiala di nuovo dall'email ricevuta.")
    nome, email, tipo, emissione, scadenza, vmax, ident, _n = _leggi_dati(dati)
    licenza = Licenza(nome, email, tipo, emissione, scadenza, vmax, ident, canonica)
    oggi = oggi or _dt.date.today()
    if scadenza is not None and oggi > scadenza:
        raise ChiaveNonValida("scaduta", f"La chiave di {licenza.intestatario} è scaduta il {_data_it(scadenza)}: "
                                         "per continuare serve una licenza nuova.")
    attuale = versione or _versione_leo()
    if vmax is not None and _versione_tupla(attuale) > vmax:
        raise ChiaveNonValida("versione", f"Questa chiave vale per Leo fino alla versione {licenza.testo_versione}, "
                                          f"ma questa è la versione {attuale}: serve una licenza per la versione "
                                          "nuova.")
    return licenza


# ===========================================================================
# Archivio (file + registro di Windows), con impronta HMAC
# ===========================================================================

class ArchivioMemoria:
    """Archivio in memoria (per le prove)."""

    def __init__(self, testo: str | None = None) -> None:
        self.testo = testo

    def leggi(self) -> str | None:
        return self.testo

    def scrivi(self, testo: str) -> None:
        self.testo = testo


class ArchivioFile:
    def __init__(self, percorso: str | os.PathLike) -> None:
        self.percorso = Path(percorso)

    def leggi(self) -> str | None:
        try:
            return self.percorso.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            return None

    def scrivi(self, testo: str) -> None:
        try:
            self.percorso.parent.mkdir(parents=True, exist_ok=True)
            temporaneo = self.percorso.with_name(self.percorso.name + ".tmp")
            temporaneo.write_text(testo, encoding="utf-8")
            os.replace(temporaneo, self.percorso)
        except OSError:
            pass


class ArchivioRegistro:
    """``HKCU\\Software\\Leo``, valore ``Licenza`` (solo Windows)."""

    def __init__(self, chiave: str = CHIAVE_REGISTRO, valore: str = VALORE_REGISTRO) -> None:
        self.chiave = chiave
        self.valore = valore

    def leggi(self) -> str | None:
        try:
            import winreg

            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, self.chiave) as k:
                testo, _tipo = winreg.QueryValueEx(k, self.valore)
            return str(testo)
        except (ImportError, OSError):
            return None

    def scrivi(self, testo: str) -> None:
        try:
            import winreg

            with winreg.CreateKey(winreg.HKEY_CURRENT_USER, self.chiave) as k:
                winreg.SetValueEx(k, self.valore, 0, winreg.REG_SZ, testo)
        except (ImportError, OSError):
            pass


def archivi_predefiniti() -> list:
    from .percorsi import cartella_utente

    archivi: list = [ArchivioFile(cartella_utente() / NOME_FILE)]
    if os.name == "nt":
        archivi.append(ArchivioRegistro())
    return archivi


_CAMPI = ("primo", "ultimo", "chiave", "promemoria", "data_promemoria")


def impronta(dati: dict) -> str:
    corpo = json.dumps({k: dati.get(k) for k in _CAMPI}, sort_keys=True, ensure_ascii=True,
                       separators=(",", ":"))
    return hmac.new(_SEGRETO_IMPRONTA, corpo.encode("ascii"), hashlib.sha256).hexdigest()[:32]


def codifica_registro(dati: dict) -> str:
    completo = {k: dati.get(k) for k in _CAMPI}
    completo["v"] = 1
    completo["impronta"] = impronta(completo)
    return json.dumps(completo, sort_keys=True, ensure_ascii=True)


def decodifica_registro(testo: str | None) -> tuple[dict | None, bool]:
    """(dati, alterato). ``alterato``: c'era qualcosa ma l'impronta non torna."""
    if testo is None or not testo.strip():
        return None, False
    try:
        dati = json.loads(testo)
        if not isinstance(dati, dict):
            return None, True
        if not hmac.compare_digest(str(dati.get("impronta", "")), impronta(dati)):
            return None, True
        primo = _dt.date.fromisoformat(dati["primo"])
        ultimo = _dt.date.fromisoformat(dati["ultimo"])
    except (ValueError, KeyError, TypeError):
        return None, True
    promemoria = dati.get("promemoria") or []
    return {"primo": primo, "ultimo": ultimo, "chiave": str(dati.get("chiave") or ""),
            "promemoria": sorted({int(p) for p in promemoria if isinstance(p, int)}),
            "data_promemoria": str(dati.get("data_promemoria") or "")}, False


# ===========================================================================
# Stato e gestore
# ===========================================================================

@dataclass
class StatoLicenza:
    stato: str                        # in_prova, scaduta, attiva, sviluppo
    giorni_rimasti: int | None = None
    licenza: Licenza | None = None
    avviso: str = ""                  # es. "la chiave memorizzata e' scaduta"
    primo_avvio: _dt.date | None = None
    extra: dict = field(default_factory=dict)

    @property
    def bloccato(self) -> bool:
        """Vero se Studio e ``leo compila`` si fermano (prova finita, nessuna licenza valida)."""
        return self.stato == "scaduta"

    @property
    def livello(self) -> str:
        """``normale``, ``arancione`` (ultimi 14 giorni) o ``rosso`` (ultimi 3, o scaduta)."""
        if self.stato == "scaduta":
            return "rosso"
        if self.stato == "in_prova" and self.giorni_rimasti is not None:
            if self.giorni_rimasti <= GIORNI_ROSSO:
                return "rosso"
            if self.giorni_rimasti <= GIORNI_ARANCIONE:
                return "arancione"
        return "normale"

    @property
    def testo_breve(self) -> str:
        if self.stato == "in_prova":
            g = self.giorni_rimasti or 0
            return f"Prova: {g} giorn{'o' if g == 1 else 'i'}"
        if self.stato == "scaduta":
            return "Prova scaduta"
        if self.stato == "attiva":
            return "Licenza attiva"
        return "Sviluppo"

    def descrizione(self) -> str:
        if self.stato == "attiva" and self.licenza is not None:
            return "Licenza attiva.\n" + self.licenza.descrizione()
        if self.stato == "in_prova":
            g = self.giorni_rimasti or 0
            testo = (f"Prova gratuita: mancano {g} giorn{'o' if g == 1 else 'i'} "
                     f"(su {GIORNI_PROVA}, dal {_data_it(self.primo_avvio)})." if self.primo_avvio else
                     f"Prova gratuita: mancano {g} giorni.")
        elif self.stato == "scaduta":
            testo = (f"La prova gratuita di {GIORNI_PROVA} giorni è finita: per continuare a usare Leo Studio "
                     "e per creare eseguibili serve una chiave di licenza.")
        else:
            testo = "Modalità sviluppo: i controlli della licenza sono spenti."
        return testo + (f"\n{self.avviso}" if self.avviso else "")


def modalita_sviluppo() -> bool:
    """Controlli spenti: variabile ``LEO_LICENZA_SVILUPPO=1`` E file di sviluppo nel sorgente
    E non e' un'app congelata (PyInstaller)."""
    if os.environ.get(VARIABILE_SVILUPPO) != "1" or getattr(sys, "frozen", False):
        return False
    try:
        return FILE_SVILUPPO.is_file()
    except OSError:
        return False


class GestoreLicenza:
    """Legge e aggiorna lo stato della licenza.

    ``archivi``: oggetti con ``leggi()``/``scrivi(testo)`` (predefiniti: file + registro).
    ``oggi``: funzione che restituisce la data di oggi (per le prove con orologio finto).
    ``sviluppo``: None = :func:`modalita_sviluppo`.
    """

    def __init__(self, archivi: Sequence | None = None, oggi: Callable[[], _dt.date] | None = None,
                 versione: str | None = None, sviluppo: bool | None = None,
                 chiave_pubblica: str | None = None) -> None:
        self._archivi = list(archivi) if archivi is not None else None
        self._oggi = oggi or _dt.date.today
        self.versione = versione or _versione_leo()
        self.sviluppo = modalita_sviluppo() if sviluppo is None else bool(sviluppo)
        self.chiave_pubblica = chiave_pubblica

    # ---- archivio
    @property
    def archivi(self) -> list:
        if self._archivi is None:
            self._archivi = archivi_predefiniti()
        return self._archivi

    def _leggi(self) -> tuple[dict | None, bool, bool]:
        """(dati uniti, alterato, da_riscrivere)."""
        validi, alterato, mancanti = [], False, False
        for archivio in self.archivi:
            dati, rovinato = decodifica_registro(archivio.leggi())
            if dati is not None:
                validi.append(dati)
            else:
                mancanti = True
                alterato = alterato or rovinato
        if not validi:
            return None, alterato, False
        unito = dict(validi[0])
        unito["primo"] = min(d["primo"] for d in validi)
        unito["ultimo"] = max(d["ultimo"] for d in validi)
        unito["chiave"] = next((d["chiave"] for d in validi if d["chiave"]), "")
        unito["promemoria"] = sorted({p for d in validi for p in d["promemoria"]})
        unito["data_promemoria"] = max(d["data_promemoria"] for d in validi)
        diversi = any(codifica_registro(_serializzabile(d)) != codifica_registro(_serializzabile(unito))
                      for d in validi)
        return unito, alterato, mancanti or diversi

    def _scrivi(self, dati: dict) -> None:
        testo = codifica_registro(_serializzabile(dati))
        for archivio in self.archivi:
            archivio.scrivi(testo)

    def _verifica(self, chiave: str, oggi: _dt.date) -> Licenza:
        return verifica_chiave(chiave, oggi=oggi, versione=self.versione, chiave_pubblica=self.chiave_pubblica)

    # ---- stato
    def stato(self) -> StatoLicenza:
        if self.sviluppo:
            return StatoLicenza("sviluppo")
        oggi = self._oggi()
        dati, alterato, riscrivi = self._leggi()
        if dati is None:
            if alterato:
                return StatoLicenza("scaduta", 0, avviso="I dati della prova sono stati modificati: "
                                                         "per continuare serve una chiave di licenza.")
            dati = {"primo": oggi, "ultimo": oggi, "chiave": "", "promemoria": [], "data_promemoria": ""}
            riscrivi = True
        if oggi > dati["ultimo"]:
            dati["ultimo"] = oggi
            riscrivi = True
        if riscrivi:
            self._scrivi(dati)
        # orologio portato indietro: si conta dall'ultima data vista
        riferimento = max(oggi, dati["ultimo"])
        trascorsi = max(0, (riferimento - dati["primo"]).days)
        rimasti = max(0, GIORNI_PROVA - trascorsi)
        avviso = ""
        if dati["chiave"]:
            try:
                licenza = self._verifica(dati["chiave"], riferimento)
                return StatoLicenza("attiva", rimasti, licenza, primo_avvio=dati["primo"])
            except ChiaveNonValida as e:
                avviso = e.messaggio
        if rimasti > 0:
            return StatoLicenza("in_prova", rimasti, avviso=avviso, primo_avvio=dati["primo"])
        return StatoLicenza("scaduta", 0, avviso=avviso, primo_avvio=dati["primo"])

    def attiva(self, testo: str) -> Licenza:
        """Verifica e salva la chiave (``testo`` puo' essere un'email intera)."""
        oggi = self._oggi()
        dati, _alterato, _r = self._leggi()
        riferimento = max(oggi, dati["ultimo"]) if dati else oggi
        licenza = self._verifica(testo, riferimento)
        if dati is None:
            # dati della prova mancanti o alterati: la prova resta finita (primo avvio lontano)
            primo = oggi if not _alterato else oggi - _dt.timedelta(days=GIORNI_PROVA)
            dati = {"primo": primo, "ultimo": oggi, "chiave": "", "promemoria": [], "data_promemoria": ""}
        dati["chiave"] = licenza.chiave
        dati["ultimo"] = max(dati["ultimo"], oggi)
        self._scrivi(dati)
        return licenza

    def togli(self) -> None:
        """Toglie la chiave memorizzata (la prova resta dov'era)."""
        dati, _alterato, _r = self._leggi()
        if dati is None:
            return
        dati["chiave"] = ""
        self._scrivi(dati)

    def promemoria(self, stato: StatoLicenza | None = None) -> int | None:
        """La soglia (14, 7, 3, 1) da ricordare adesso, o None. Al massimo una volta al giorno
        e una volta per soglia; la segna come mostrata."""
        stato = stato or self.stato()
        if stato.stato != "in_prova" or stato.giorni_rimasti is None:
            return None
        soglie = [s for s in SOGLIE_PROMEMORIA if stato.giorni_rimasti <= s]
        if not soglie:
            return None
        soglia = min(soglie)
        dati, _alterato, _r = self._leggi()
        if dati is None:
            return None
        oggi = self._oggi().isoformat()
        if soglia in dati["promemoria"] or dati["data_promemoria"] == oggi:
            return None
        dati["promemoria"] = sorted(set(dati["promemoria"]) | {soglia})
        dati["data_promemoria"] = oggi
        self._scrivi(dati)
        return soglia


def _serializzabile(dati: dict) -> dict:
    return {"primo": dati["primo"].isoformat(), "ultimo": dati["ultimo"].isoformat(),
            "chiave": dati.get("chiave") or "", "promemoria": list(dati.get("promemoria") or []),
            "data_promemoria": dati.get("data_promemoria") or ""}


# ===========================================================================
# Testi comuni (Studio, riga di comando, compilazione)
# ===========================================================================

def testo_acquisto() -> str:
    if TELEFONO_CONTATTO:
        return (f"La chiave di licenza si richiede solo per telefono: chiama il {TELEFONO_CONTATTO} "
                f"({TITOLARE}).")
    if URL_ACQUISTO:
        return f"Puoi acquistare una licenza qui: {URL_ACQUISTO}"
    if EMAIL_CONTATTO:
        return f"Per acquistare una licenza scrivi a {EMAIL_CONTATTO}"
    return f"Per acquistare una licenza contatta {TITOLARE}, titolare di Leo (vedi LICENZA.txt)."


def testo_promemoria(giorni: int) -> str:
    quando = "domani" if giorni <= 1 else f"fra {giorni} giorni"
    return (f"La prova gratuita di Leo Studio finisce {quando}. Quando vuoi, attiva una chiave di licenza "
            "da Aiuto > Attiva licenza. I tuoi progetti e i programmi già creati restano tuoi e "
            "continuano a funzionare.")


def messaggio_blocco_compilazione(gestore: GestoreLicenza | None = None) -> str:
    """Messaggio d'errore se ``leo compila`` e' bloccato (prova finita, niente licenza); "" se si puo'."""
    try:
        stato = (gestore or GestoreLicenza()).stato()
    except Exception:  # noqa: BLE001 - un problema dell'archivio non deve fermare chi ha pagato
        return ""
    if not stato.bloccato:
        return ""
    righe = [f"La prova gratuita di {GIORNI_PROVA} giorni è finita: per creare nuovi eseguibili (.exe) serve una "
             "chiave di licenza."]
    if stato.avviso:
        righe.append(stato.avviso)
    righe += ["I programmi già creati continuano a funzionare, e i file .leo si eseguono ancora con "
              "`leo programma.leo`.",
              "Per attivare la licenza: in Leo Studio scegli Aiuto > Attiva licenza..., oppure scrivi",
              "  leo licenza attiva LEO-XXXXXX-XXXXXX-...",
              testo_acquisto()]
    return "\n".join(righe)


USO_COMANDO = """\
Uso:
  leo licenza                  mostra lo stato (prova, licenza attiva, prova scaduta)
  leo licenza attiva CHIAVE    attiva una chiave di licenza (LEO-XXXXXX-...)
  leo licenza togli            toglie la chiave da questo computer"""


def comando_licenza(argv: Sequence[str], gestore: GestoreLicenza | None = None,
                    stampa: Callable[[str], None] = print,
                    errore: Callable[[str], None] | None = None) -> int:
    """``leo licenza [attiva CHIAVE | togli]``: 0 bene, 1 chiave rifiutata, 2 uso sbagliato."""
    if errore is None:
        def errore(testo: str) -> None:
            sys.stdout.flush()
            sys.stderr.write(testo + "\n")
    argv = list(argv)
    if argv and argv[0] in ("-h", "--help", "--aiuto", "aiuto"):
        stampa(USO_COMANDO)
        return 0
    gestore = gestore or GestoreLicenza()
    if not argv or argv[0] in ("stato", "mostra"):
        stato = gestore.stato()
        stampa(stato.descrizione())
        if stato.stato in ("in_prova", "scaduta"):
            stampa(testo_acquisto())
        return 0
    comando, resto = argv[0], argv[1:]
    if comando == "attiva":
        testo = " ".join(resto).strip()
        if not testo and not sys.stdin.isatty():
            testo = sys.stdin.read()
        if not testo:
            errore("leo licenza attiva: manca la chiave.\n" + USO_COMANDO)
            return 2
        try:
            licenza = gestore.attiva(testo)
        except ChiaveNonValida as e:
            errore(f"leo licenza: {e.messaggio}")
            return 1
        stampa("Licenza attivata. Grazie!\n" + licenza.descrizione())
        return 0
    if comando == "togli":
        gestore.togli()
        stampa("Chiave tolta da questo computer. Puoi riattivarla quando vuoi con `leo licenza attiva`.")
        return 0
    errore(f"leo licenza: non conosco `{comando}`.\n{USO_COMANDO}")
    return 2
