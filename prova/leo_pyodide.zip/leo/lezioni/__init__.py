"""`leo impara`: lezioni guidate per imparare Leo (pensate per chi comincia, anche giovanissimo).

Le lezioni sono file TOML in ``dati/lezioni/`` (vedi :mod:`leo.lezioni.modello`);
il motore che controlla le soluzioni è in :mod:`leo.lezioni.controllo` (per le
lezioni con le finestre :mod:`leo.lezioni.finestre`); la conversazione nel
terminale è in :mod:`leo.lezioni.sessione`. Le stesse lezioni formano il corso
"Impara Leo" dell'app per telefono (``leo_android.corso``).

API:
    carica_lezioni(cartella=None) -> list[Lezione]
    verifica(lezione, codice) -> Esito
    Progresso(cartella=None)                        # lezioni completate (JSON nella cartella utente)
    Sessione(lezioni, progresso, leggi, scrivi).avvia(numero=None) -> int
    comando_impara(argv) -> int                     # usato da `leo impara`
"""

from __future__ import annotations

from .controllo import Esito, esegui_codice, verifica
from .modello import Lezione, carica_lezione, carica_lezioni
from .progresso import Progresso
from .sessione import Sessione, comando_impara

__all__ = ["Esito", "Lezione", "Progresso", "Sessione", "carica_lezione", "carica_lezioni",
           "comando_impara", "esegui_codice", "verifica"]
