"""Lezioni con le finestre: la finestra della lezione e la prova "senza schermo".

Una lezione con le finestre ha una tabella ``[finestra]`` con i controlli, messi
uno sotto l'altro in una finestra da telefono (360 x 640)::

    [finestra]
    titolo = "Saluto"
    controlli = [
        { nome = "Etichetta1", tipo = "Etichetta", testo = "Come ti chiami?" },
        { nome = "CasellaNome", tipo = "CasellaTesto" },
        { nome = "PulsanteSaluta", tipo = "Pulsante", testo = "Saluta" },
    ]

Il codice dello studente è il codice degli eventi di ``Finestra1``.
:func:`esegui_finestra` crea il progetto in una cartella temporanea, lo esegue con
il motore delle finestre dell'app per telefono (``leo.grafica.web``) e, al posto di
chi usa l'app, scrive nelle caselle e tocca i pulsanti indicati dalla prova::

    [[controllo.prove]]
    scrivi = { CasellaNome = "Ada" }        # testi scritti nelle caselle
    clic = ["PulsanteSaluta"]               # pulsanti toccati, in ordine
    attese = { Etichetta1 = "Ciao, Ada!" }  # testo finale (maiuscole e spazi non contano)
    attese_contengono = { Etichetta1 = "Ada" }
    valori_diversi = ["Dado"]               # il programma deve mostrare almeno due valori diversi

Nelle attese una chiave senza punto indica la proprietà ``testo``; con il punto
si sceglie la proprietà (``"Etichetta1.colore"``). Un valore lista vuol dire
"uno di questi".
"""

from __future__ import annotations

import os
import tempfile
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

#: misura della finestra per il telefono (come i modelli di "Nuova app con finestre")
LARGHEZZA, ALTEZZA = 360, 640
#: altezza predefinita dei controlli messi in colonna
_ALTEZZE = {"Etichetta": 32, "CasellaTesto": 44, "CasellaNumero": 44, "Pulsante": 48, "Elenco": 200,
            "AreaTesto": 120}
NOME_FINESTRA = "Finestra1"


@dataclass
class EsecuzioneFinestra:
    uscita: str = ""
    errore: str | None = None
    scaduto: bool = False
    #: valori finali: {"Etichetta1": {"testo": "Ciao"}}
    valori: dict[str, dict[str, Any]] = field(default_factory=dict)
    #: cosa è successo, in italiano ("Scrivo \"Ada\" in CasellaNome.", ...)
    racconto: list[str] = field(default_factory=list)
    finestra_aperta: bool = False
    #: tutti i valori dati dal programma: {"Dado.testo": ["3", "5", ...]}
    storico: dict[str, list[str]] = field(default_factory=dict)


def maschera_lezione(finestra: dict[str, Any]) -> dict[str, Any]:
    """Il modello della finestra (come lo usa il disegnatore) dalla tabella ``[finestra]``."""
    controlli = []
    alto = 28
    for c in finestra.get("controlli", []) or []:
        tipo = str(c.get("tipo", "Etichetta"))
        altezza = int(c.get("altezza", _ALTEZZE.get(tipo, 40)))
        voce = {"nome": str(c["nome"]), "tipo": tipo, "contenitore": "", "sinistra": 20, "alto": alto,
                "larghezza": LARGHEZZA - 40, "altezza": altezza, "ancoraggio": ["alto", "sinistra", "destra"]}
        voce.update({k: v for k, v in c.items() if k not in ("nome", "tipo")})
        if tipo == "Etichetta" and "dimensione_carattere" not in voce and altezza >= 60:
            voce["dimensione_carattere"] = 28
        controlli.append(voce)
        alto = int(voce["alto"]) + int(voce["altezza"]) + 14
    return {"versione": 1,
            "finestra": {"nome": NOME_FINESTRA, "tipo": "Finestra", "testo": str(finestra.get("titolo", "La mia app")),
                         "larghezza": LARGHEZZA, "altezza": ALTEZZA},
            "controlli": controlli}


def crea_progetto_lezione(cartella: str | os.PathLike, finestra: dict[str, Any], codice: str,
                          nome: str = "Lezione") -> Path:
    """Scrive in ``cartella`` un progetto con la finestra della lezione e il ``codice`` degli eventi."""
    from ..grafica.web.disegnatore import salva_maschera_json
    from ..progetto import crea_progetto

    cartella = Path(cartella)
    crea_progetto(cartella, nome, con_finestra=True)
    salva_maschera_json(cartella / f"{NOME_FINESTRA}.maschera", maschera_lezione(finestra))
    (cartella / f"{NOME_FINESTRA}.leo").write_text(codice if codice.endswith("\n") else codice + "\n",
                                                   encoding="utf-8")
    return cartella


def _valori_iniziali(finestra: dict[str, Any]) -> dict[str, dict[str, Any]]:
    valori: dict[str, dict[str, Any]] = {}
    for c in finestra.get("controlli", []) or []:
        valori[str(c["nome"])] = {k: v for k, v in c.items() if k not in ("nome", "tipo")}
        valori[str(c["nome"])].setdefault("testo", "")
    return valori


def _testo_valore(v: Any) -> str:
    if v is None:
        return ""
    if isinstance(v, bool):
        return "vero" if v else "falso"
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    return str(v)


def esegui_finestra(finestra: dict[str, Any], codice: str, prova: dict[str, Any] | None = None, *,
                    tempo_massimo: float = 5.0) -> EsecuzioneFinestra:
    """Esegue il codice degli eventi con la finestra della lezione, facendo i gesti della ``prova``."""
    from ..grafica.web import CanaleWeb, ProgrammaWeb

    prova = prova or {}
    risultato = EsecuzioneFinestra(valori=_valori_iniziali(finestra))
    scritti = {str(k): _testo_valore(v) for k, v in (prova.get("scrivi") or {}).items()}
    clic = [str(c) for c in (prova.get("clic") or [])]
    eventi: list[dict] = []
    for i, nome in enumerate(clic):
        ev = {"tipo": "evento", "f": NOME_FINESTRA, "c": nome, "e": "clic", "d": {}}
        if i == 0 and scritti:
            ev["agg"] = {c: {"testo": t} for c, t in scritti.items()}
        eventi.append(ev)
    if scritti and not clic:
        eventi.append({"tipo": "sincronizza", "f": NOME_FINESTRA, "agg": {c: {"testo": t} for c, t in scritti.items()}})
    for c, t in scritti.items():
        risultato.racconto.append(f"Scrivo \"{t}\" in {c}.")
    pezzi: list[str] = []
    errori: list[str] = []

    class Canale(CanaleWeb):
        def __init__(self) -> None:
            self.aperta = False
            self.risposte: list[dict] = []

        def invia(self, messaggi: list[dict]) -> None:
            for m in messaggi:
                op = m.get("op")
                if op == "finestra":
                    self.aperta = True
                elif op == "imposta" and isinstance(m.get("p"), dict):
                    risultato.valori.setdefault(str(m.get("c", "")), {}).update(m["p"])
                    for k, v in m["p"].items():
                        risultato.storico.setdefault(f"{m.get('c', '')}.{k}", []).append(_testo_valore(v))
                elif op == "dialogo":
                    if m.get("tipo") != "errore" and m.get("testo"):
                        risultato.racconto.append(f"Si apre il messaggio: \"{m.get('testo')}\".")
                    self.risposte.append({"tipo": "risposta", "id": m.get("id"), "valore": None})

        def ricevi(self, attesa: float) -> list[dict] | None:
            if self.risposte:
                return [self.risposte.pop(0)]
            if not self.aperta:
                time.sleep(min(attesa, 0.005))
                return []
            if eventi:
                ev = eventi.pop(0)
                for c, v in (ev.get("agg") or {}).items():
                    risultato.valori.setdefault(c, {}).update(v)
                if ev.get("tipo") == "evento":
                    risultato.racconto.append(f"Tocco {ev['c']}.")
                return [ev]
            return None

    def errore(err: Any, sorgente: Any, _fatale: bool) -> None:
        from .controllo import _formatta_errore

        errori.append(_formatta_errore(err, sorgente or codice))

    with tempfile.TemporaryDirectory(prefix="leo_lezione_") as tmp:
        try:
            crea_progetto_lezione(Path(tmp) / "Lezione", finestra, codice)
        except Exception as e:  # noqa: BLE001 - finestra della lezione sbagliata: si dice e basta
            risultato.errore = f"Non riesco a preparare la finestra della lezione: {e}"
            return risultato
        canale = Canale()
        programma = ProgrammaWeb(Path(tmp) / "Lezione", canale, uscita=pezzi.append, errore=errore,
                                 avviso=lambda _t: None, riduci_animazioni=True)

        def lavoro() -> None:
            try:
                programma.esegui()
            except Exception as e:  # noqa: BLE001 - mai un traceback per chi impara
                errori.append(f"Errore interno durante l'esecuzione: {e}")

        filo = threading.Thread(target=lavoro, name="leo-lezione-finestra", daemon=True)
        filo.start()
        filo.join(tempo_massimo)
        if filo.is_alive():
            programma.ferma()
            filo.join(2.0)
            risultato.scaduto = True
        risultato.finestra_aperta = canale.aperta
    risultato.uscita = "".join(pezzi)
    if errori:
        risultato.errore = errori[0]
    return risultato


def valore(esecuzione: EsecuzioneFinestra, chiave: str) -> tuple[str, str, str]:
    """(controllo, proprietà, valore come testo) per ``"Etichetta1"`` o ``"Etichetta1.colore"``."""
    controllo, _, proprieta = chiave.partition(".")
    proprieta = proprieta or "testo"
    return controllo, proprieta, _testo_valore(esecuzione.valori.get(controllo, {}).get(proprieta, ""))


__all__ = ["EsecuzioneFinestra", "maschera_lezione", "crea_progetto_lezione", "esegui_finestra", "valore",
           "LARGHEZZA", "ALTEZZA", "NOME_FINESTRA"]
