"""Controllo automatico delle soluzioni di `leo impara`.

:func:`esegui_codice` esegue il programma dello studente in un thread separato
(con un tempo massimo, così un ciclo infinito non blocca la lezione),
raccogliendo l'uscita e il disegno della tartaruga. :func:`verifica` confronta
il risultato con il ``[controllo]`` della lezione e prepara un messaggio
breve e preciso che spiega cosa manca.
"""

from __future__ import annotations

import re
import threading
from dataclasses import dataclass, field
from typing import Any

from .modello import Lezione

TEMPO_MASSIMO = 5.0


@dataclass
class Esecuzione:
    uscita: str = ""
    #: solo ciò che il programma ha stampato (senza domande di `chiedi` e risposte)
    stampato: str = ""
    errore: str | None = None
    scaduto: bool = False
    tartaruga: Any = None
    domande: list[str] = field(default_factory=list)


@dataclass
class Esito:
    ok: bool
    messaggio: str
    uscita: str = ""
    tartaruga: Any = None
    #: lezioni con le finestre: che cosa è successo nella finestra (gesti e valori finali)
    racconto: list[str] = field(default_factory=list)


def _formatta_errore(errore: Any, codice: str) -> str:
    try:
        from ..messaggi import formatta_errore

        return formatta_errore(errore, codice, colori=False)
    except Exception:  # noqa: BLE001 - il messaggio non deve perdersi
        return f"{getattr(errore, 'tipo', type(errore).__name__)}: {getattr(errore, 'messaggio', errore)}"


def esegui_codice(codice: str, ingresso: list[str] | None = None, *,
                  tempo_massimo: float = TEMPO_MASSIMO) -> Esecuzione:
    """Esegue ``codice`` e restituisce uscita, errore (già formattato) e tartaruga."""
    from ..errori import ErroreDante, SegnaleControllo
    from ..esecuzione import analizza
    from ..interprete import Interprete
    from ..stile import Stile
    from .. import tartaruga as logica

    risultato = Esecuzione()
    pezzi: list[str] = []
    stampati: list[str] = []

    def scrivi(testo: str) -> None:
        pezzi.append(testo)
        stampati.append(testo)
    risposte = [str(r) for r in (ingresso or [])]

    def leggi(domanda: str) -> str | None:
        risultato.domande.append(domanda)
        if domanda:
            pezzi.append(domanda)
        if not risposte:
            return None
        risposta = risposte.pop(0)
        pezzi.append(risposta + "\n")
        return risposta

    try:
        programma = analizza(codice, "esercizio.leo")
    except ErroreDante as e:
        risultato.errore = _formatta_errore(e, codice)
        return risultato
    stile = Stile.da_sorgente(codice, None)
    interprete = Interprete(nome_file="esercizio.leo", sorgente=codice, uscita=scrivi,
                            ingresso=leggi, dichiarazione_implicita=stile.dichiarazione_implicita)

    def lavoro() -> None:
        try:
            interprete.esegui(programma)
        except ErroreDante as e:
            risultato.errore = _formatta_errore(e, codice)
        except SegnaleControllo:
            pass
        except RecursionError:
            risultato.errore = "Troppe chiamate annidate: probabilmente una funzione chiama sé stessa senza fermarsi."
        except Exception as e:  # noqa: BLE001 - mai un traceback per chi impara
            risultato.errore = f"Errore interno durante l'esecuzione: {e}"

    filo = threading.Thread(target=lavoro, name="leo-impara", daemon=True)
    filo.start()
    filo.join(tempo_massimo)
    if filo.is_alive():
        interprete.ferma()
        filo.join(2.0)
        risultato.scaduto = True
    risultato.uscita = "".join(pezzi)
    risultato.stampato = "".join(stampati)
    t = logica.tartaruga_di(interprete, crea=False)
    if t is not None:
        if t.colore_riempimento is not None:
            try:
                t.finisci_riempimento()
            except logica.ErroreTartaruga:
                pass
        logica.scarta(t)
    risultato.tartaruga = t
    return risultato


# ---------------------------------------------------------------------------
# Confronti
# ---------------------------------------------------------------------------

def normalizza(testo: str) -> str:
    """Minuscole, spazi ridotti, righe vuote in fondo tolte: per confronti gentili."""
    righe = [re.sub(r"\s+", " ", r).strip().lower() for r in testo.replace("\r", "").split("\n")]
    while righe and not righe[-1]:
        righe.pop()
    while righe and not righe[0]:
        righe.pop(0)
    return "\n".join(righe)


def _parola_nel_codice(parola: str, codice: str) -> bool:
    codice_min = codice.lower()
    p = parola.lower()
    if re.fullmatch(r"[\wàèéìòù ]+", p):
        return re.search(r"(?<![\w])" + re.escape(p) + r"(?![\w])", codice_min) is not None
    return p in codice_min


def _codice_senza_commenti(codice: str) -> str:
    righe = []
    for riga in codice.split("\n"):
        dentro: str | None = None
        taglio = len(riga)
        for i, c in enumerate(riga):
            if dentro:
                if c == dentro:
                    dentro = None
            elif c in "\"'":
                dentro = c
            elif c == "#":
                taglio = i
                break
        righe.append(riga[:taglio])
    return "\n".join(righe)


def _mostra_righe(testo: str) -> str:
    righe = testo.split("\n") if testo else ["(niente)"]
    return "\n".join("    " + r for r in righe[:12]) + ("\n    ..." if len(righe) > 12 else "")


def _controlla_prova(prova: dict[str, Any], codice: str, *, tempo_massimo: float) -> Esito:
    esecuzione = esegui_codice(codice, prova.get("ingresso"), tempo_massimo=tempo_massimo)
    uscita = esecuzione.stampato
    if esecuzione.scaduto:
        return Esito(False, "Il programma non finisce mai: probabilmente un ciclo non si ferma.\n"
                            "Controlla le condizioni dei `mentre` e che ogni ciclo abbia la sua `fine`.", uscita)
    if esecuzione.errore:
        return Esito(False, "Il programma contiene un errore:\n\n" + esecuzione.errore, uscita)
    uscita_norm = normalizza(uscita)
    attesa = prova.get("uscita")
    if isinstance(attesa, str):
        attesa_norm = normalizza(attesa)
        if uscita_norm != attesa_norm:
            messaggio = ("Il programma funziona, ma l'uscita non è quella attesa. Ha scritto:\n" + _mostra_righe(uscita.rstrip("\n"))
                         + "\ninvece di:\n" + _mostra_righe(attesa.strip("\n")))
            righe_u, righe_a = uscita_norm.split("\n"), attesa_norm.split("\n")
            if len(righe_u) != len(righe_a):
                messaggio += f"\n(Hai scritto {len(righe_u)} {'riga' if len(righe_u) == 1 else 'righe'}, ne servono {len(righe_a)}.)"
            elif uscita_norm.replace(" ", "") == attesa_norm.replace(" ", ""):
                messaggio += "\n(Controlla gli spazi tra le parole.)"
            else:
                for n, (u, a) in enumerate(zip(righe_u, righe_a), start=1):
                    if u != a:
                        messaggio += f"\n(La prima differenza è nella riga {n}.)"
                        break
            return Esito(False, messaggio, uscita)
    for pezzo in prova.get("uscita_contiene", []) or []:
        if normalizza(pezzo) not in uscita_norm:
            ingresso = prova.get("ingresso")
            quando = f" quando la risposta è {', '.join(map(str, ingresso))}" if ingresso else ""
            return Esito(False, f"Uscita attesa: \"{pezzo}\"{quando}. Il programma ha scritto invece:\n"
                         + _mostra_righe(uscita.rstrip("\n")), uscita)
    for pezzo in prova.get("uscita_non_contiene", []) or []:
        if normalizza(pezzo) in uscita_norm:
            ingresso = prova.get("ingresso")
            quando = f" quando la risposta è {', '.join(map(str, ingresso))}" if ingresso else ""
            return Esito(False, f"Il programma ha scritto \"{pezzo}\"{quando}, ma non dovrebbe comparire.", uscita)
    t = esecuzione.tartaruga
    tratti = t.tratti if t is not None else []
    minimi = prova.get("tratti_minimi")
    if isinstance(minimi, int) and len(tratti) < minimi:
        if not tratti:
            return Esito(False, "La tartaruga non ha disegnato niente: usa `avanti(...)` per farla muovere.",
                         uscita)
        return Esito(False, f"La tartaruga ha disegnato {len(tratti)} righe, ma ne servono almeno {minimi}.",
                     uscita)
    if prova.get("figura_chiusa") and tratti:
        inizio = (tratti[0].x1, tratti[0].y1)
        fine_ = (t.x, t.y)
        if abs(inizio[0] - fine_[0]) > 0.5 or abs(inizio[1] - fine_[1]) > 0.5:
            return Esito(False, "La figura non si chiude: la tartaruga non è tornata al punto di partenza.\n"
                                "Controlla gli angoli e la lunghezza dei lati.", uscita)
    riempimenti = prova.get("riempimenti_minimi")
    if isinstance(riempimenti, int) and riempimenti > 0:
        from ..tartaruga import Macchia

        n = sum(1 for e in (t.elementi if t is not None else []) if isinstance(e, Macchia))
        if n < riempimenti:
            return Esito(False, "La figura non è colorata dentro: usa `riempi(\"giallo\")` prima di disegnare "
                                "e `fine_riempi()` alla fine.", uscita)
    return Esito(True, "", uscita, t)


def verifica(lezione: Lezione, codice: str, *, tempo_massimo: float = TEMPO_MASSIMO) -> Esito:
    """Controlla la soluzione; ``Esito.ok`` è vero se è corretta."""
    if not codice.strip():
        return Esito(False, "Il programma è vuoto: scrivi almeno un'istruzione.")
    codice_pulito = _codice_senza_commenti(codice)
    for parola in lezione.controllo.get("codice_contiene", []) or []:
        if not _parola_nel_codice(parola, codice_pulito):
            return Esito(False, f"Per questo esercizio devi usare `{parola.strip()}`.")
    primo: Esito | None = None
    for prova in lezione.prove:
        if lezione.con_finestra:
            esito = _controlla_prova_finestra(lezione, prova, codice, tempo_massimo=tempo_massimo)
        else:
            esito = _controlla_prova(prova, codice, tempo_massimo=tempo_massimo)
        if not esito.ok:
            return esito
        primo = primo or esito
    return Esito(True, "Soluzione corretta.", primo.uscita if primo else "", primo.tartaruga if primo else None,
                 primo.racconto if primo else [])


# ---------------------------------------------------------------------------
# Lezioni con le finestre
# ---------------------------------------------------------------------------

def racconta_finestra(esecuzione: Any, attese: dict[str, Any] | None = None) -> list[str]:
    """I gesti fatti e, alla fine, i valori dei controlli che la prova guarda."""
    from .finestre import valore

    righe = list(esecuzione.racconto)
    for chiave in attese or {}:
        controllo, proprieta, testo = valore(esecuzione, chiave)
        righe.append(f"Adesso {controllo}.{proprieta} è \"{testo}\".")
    return righe


def _gesti(prova: dict[str, Any]) -> str:
    """"dopo aver scritto "3" in CasellaA, "4" in CasellaB e toccato PulsanteSomma"."""
    scritti = [(k, str(v)) for k, v in (prova.get("scrivi") or {}).items()]
    parti = []
    pieni = [f"\"{v}\" in {k}" for k, v in scritti if v]
    if pieni:
        parti.append("scritto " + ", ".join(pieni))
    parti += [f"lasciato vuota {k}" for k, v in scritti if not v]
    clic = list(prova.get("clic") or [])
    if clic:
        gruppi: list[list] = []                  # tocchi uguali di fila: [nome, quante volte]
        for c in clic:
            if gruppi and gruppi[-1][0] == c:
                gruppi[-1][1] += 1
            else:
                gruppi.append([c, 1])
        parti.append("toccato " + ", poi ".join(c + (f" {n} volte" if n > 1 else "") for c, n in gruppi))
    if not parti:
        return "all'apertura della finestra"
    return "dopo aver " + (" e ".join(parti) if len(parti) < 3 else ", ".join(parti[:-1]) + " e " + parti[-1])


def _maiuscola(frase: str) -> str:
    return frase[:1].upper() + frase[1:]


def _controlla_prova_finestra(lezione: Lezione, prova: dict[str, Any], codice: str, *,
                              tempo_massimo: float) -> Esito:
    from .finestre import esegui_finestra, valore

    esecuzione = esegui_finestra(lezione.finestra, codice, prova, tempo_massimo=tempo_massimo)
    attese = dict(prova.get("attese") or {})
    contengono = dict(prova.get("attese_contengono") or {})
    racconto = racconta_finestra(esecuzione, {**attese, **contengono})
    uscita = esecuzione.uscita
    if esecuzione.scaduto:
        return Esito(False, "Il programma non finisce mai: probabilmente un ciclo non si ferma.", uscita,
                     racconto=racconto)
    if esecuzione.errore:
        return Esito(False, "Il programma contiene un errore:\n\n" + esecuzione.errore, uscita, racconto=racconto)
    if not esecuzione.finestra_aperta:
        return Esito(False, "La finestra non si è aperta.", uscita, racconto=racconto)
    quando = _gesti(prova)
    for chiave, atteso in attese.items():
        controllo, proprieta, testo = valore(esecuzione, chiave)
        possibili = atteso if isinstance(atteso, list) else [atteso]
        if normalizza(testo) not in [normalizza(str(p)) for p in possibili]:
            desiderio = " oppure ".join(f"\"{p}\"" for p in possibili)
            return Esito(False, f"{_maiuscola(quando)}, {controllo}.{proprieta} dovrebbe essere "
                                f"{desiderio}, invece è \"{testo}\".", uscita, racconto=racconto)
    for chiave, pezzo in contengono.items():
        controllo, proprieta, testo = valore(esecuzione, chiave)
        if normalizza(str(pezzo)) not in normalizza(testo):
            return Esito(False, f"{_maiuscola(quando)}, in {controllo}.{proprieta} dovrebbe comparire "
                                f"\"{pezzo}\", invece c'è \"{testo}\".", uscita, racconto=racconto)
    for chiave in prova.get("valori_diversi", []) or []:
        controllo, _, proprieta = str(chiave).partition(".")
        visti = set(esecuzione.storico.get(f"{controllo}.{proprieta or 'testo'}", []))
        if len(visti) < 2:
            return Esito(False, f"{_maiuscola(quando)}, {controllo}.{proprieta or 'testo'} mostra sempre "
                                "lo stesso valore: dovrebbe cambiare a ogni tocco.", uscita, racconto=racconto)
    for pezzo in prova.get("uscita_contiene", []) or []:
        if normalizza(pezzo) not in normalizza(uscita):
            return Esito(False, f"Uscita attesa: \"{pezzo}\". Il programma ha scritto invece:\n"
                         + _mostra_righe(uscita.rstrip("\n")), uscita, racconto=racconto)
    return Esito(True, "", uscita, None, racconto)
