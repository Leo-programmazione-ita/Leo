"""Le lezioni di `leo impara`: formato dei file TOML e caricamento.

Formato di una lezione (``dati/lezioni/01_stampa.toml``)::

    numero = 1
    titolo = "Parla con il computer: stampa"
    spiegazione = '''...'''          # breve, con un esempio
    esempio = '''stampa("Ciao!")'''  # codice che viene eseguito e mostrato
    esercizio = '''...'''            # cosa deve fare lo studente
    soluzione = '''...'''            # una soluzione giusta (verificata dai test)
    aiuti = ["...", "..."]           # aiuti gentili, dal più vago al più preciso
    capitolo = "Primi passi"         # facoltativo: gruppo di lezioni (il percorso dell'app)
    minuti = 3                       # facoltativo: durata indicativa
    sbagliati = ["..."]              # facoltativo: programmi sbagliati che il controllo boccia (test)

    [controllo]                      # tutte le chiavi sono facoltative
    uscita = '''...'''               # l'uscita attesa (maiuscole e spazi non contano)
    uscita_contiene = ["..."]        # testi che devono comparire nell'uscita
    uscita_non_contiene = ["..."]
    codice_contiene = ["ripeti"]     # parole che devono esserci nel codice
    ingresso = ["15"]                # risposte date a `chiedi`
    tratti_minimi = 4                # tartaruga: almeno tanti tratti disegnati
    figura_chiusa = true             # tartaruga: torna al punto di partenza
    riempimenti_minimi = 1           # tartaruga: figure colorate con riempi

    [[controllo.prove]]              # più esecuzioni con ingressi diversi
    ingresso = ["3"]
    uscita_contiene = ["Piccolo!"]

Le lezioni con le finestre hanno anche una tabella ``[finestra]`` e prove con
``scrivi``, ``clic`` e ``attese``: vedi :mod:`leo.lezioni.finestre`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from ..percorsi import file_dati
from ..tomlutil import carica_toml


@dataclass
class Lezione:
    numero: int
    titolo: str
    spiegazione: str
    esercizio: str
    esempio: str = ""
    soluzione: str = ""
    aiuti: list[str] = field(default_factory=list)
    controllo: dict[str, Any] = field(default_factory=dict)
    ident: str = ""
    capitolo: str = ""
    minuti: int = 3
    #: la finestra della lezione (vuota: lezione senza finestre)
    finestra: dict[str, Any] = field(default_factory=dict)
    sbagliati: list[str] = field(default_factory=list)

    @property
    def con_finestra(self) -> bool:
        return bool(self.finestra)

    @property
    def prove(self) -> list[dict[str, Any]]:
        """Le esecuzioni da fare: ``[[controllo.prove]]`` o una sola con il controllo principale."""
        base = {k: v for k, v in self.controllo.items() if k != "prove"}
        prove = self.controllo.get("prove") or []
        if not prove:
            return [base]
        return [{**base, **p} for p in prove]


def _testo(dati: dict, chiave: str, percorso: Path, obbligatorio: bool = True) -> str:
    valore = dati.get(chiave, "")
    if not isinstance(valore, str) or (obbligatorio and not valore.strip()):
        raise ValueError(f"La lezione {percorso.name} non ha un `{chiave}` valido.")
    return valore.strip("\n")


def carica_lezione(percorso: str | Path) -> Lezione:
    """Legge una lezione (ValueError se il file è sbagliato)."""
    percorso = Path(percorso)
    dati = carica_toml(percorso)
    numero = dati.get("numero")
    if not isinstance(numero, int) or isinstance(numero, bool):
        raise ValueError(f"La lezione {percorso.name} non ha un `numero` intero.")
    aiuti = dati.get("aiuti", [])
    if not isinstance(aiuti, list) or not all(isinstance(a, str) for a in aiuti):
        raise ValueError(f"Gli `aiuti` della lezione {percorso.name} devono essere una lista di testi.")
    controllo = dati.get("controllo", {})
    if not isinstance(controllo, dict):
        raise ValueError(f"Il `controllo` della lezione {percorso.name} deve essere una tabella.")
    finestra = dati.get("finestra", {})
    if not isinstance(finestra, dict) or (finestra and not all(
            isinstance(c, dict) and c.get("nome") for c in finestra.get("controlli", []) or [])):
        raise ValueError(f"La `finestra` della lezione {percorso.name} deve avere dei controlli con un nome.")
    minuti = dati.get("minuti", 3)
    sbagliati = dati.get("sbagliati", [])
    if not isinstance(sbagliati, list) or not all(isinstance(x, str) for x in sbagliati):
        raise ValueError(f"I `sbagliati` della lezione {percorso.name} devono essere una lista di testi.")
    return Lezione(
        numero=numero,
        titolo=_testo(dati, "titolo", percorso),
        spiegazione=_testo(dati, "spiegazione", percorso),
        esercizio=_testo(dati, "esercizio", percorso),
        esempio=_testo(dati, "esempio", percorso, obbligatorio=False),
        soluzione=_testo(dati, "soluzione", percorso, obbligatorio=False),
        aiuti=list(aiuti),
        controllo=controllo,
        ident=percorso.stem,
        capitolo=str(dati.get("capitolo", "") or ""),
        minuti=minuti if isinstance(minuti, int) and not isinstance(minuti, bool) and minuti > 0 else 3,
        finestra=finestra,
        sbagliati=[x.strip("\n") for x in sbagliati],
    )


def carica_lezioni(cartella: str | Path | None = None) -> list[Lezione]:
    """Tutte le lezioni della cartella (predefinita: ``dati/lezioni``), in ordine di numero."""
    cartella = Path(cartella) if cartella is not None else file_dati("lezioni")
    if not cartella.is_dir():
        return []
    lezioni = [carica_lezione(p) for p in sorted(cartella.glob("*.toml"))]
    return sorted(lezioni, key=lambda lz: lz.numero)
