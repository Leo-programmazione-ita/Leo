"""Progresso di `leo impara`: quali lezioni sono state completate.

Si salva in JSON nella cartella dell'utente (``%APPDATA%\\Leo`` su Windows,
``~/.config/leo`` altrove), nel file ``impara.json``. Un file rovinato non
blocca le lezioni: si ricomincia da capo.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

NOME_FILE = "impara.json"


class Progresso:
    def __init__(self, cartella: str | Path | None = None) -> None:
        if cartella is None:
            from ..percorsi import cartella_utente

            cartella = cartella_utente()
        self.percorso = Path(cartella) / NOME_FILE
        self.completate: list[str] = []
        self.carica()

    def carica(self) -> None:
        try:
            dati = json.loads(self.percorso.read_text(encoding="utf-8"))
            completate = dati.get("completate", [])
            self.completate = [c for c in completate if isinstance(c, str)]
        except (OSError, ValueError, AttributeError):
            self.completate = []

    def salva(self) -> bool:
        """Scrive il file; falso se non è possibile (le lezioni continuano lo stesso)."""
        try:
            self.percorso.parent.mkdir(parents=True, exist_ok=True)
            temporaneo = self.percorso.with_suffix(".tmp")
            temporaneo.write_text(json.dumps({"completate": self.completate}, ensure_ascii=False, indent=2),
                                  encoding="utf-8")
            os.replace(temporaneo, self.percorso)
            return True
        except OSError:
            return False

    def completa(self, ident: str) -> None:
        if ident not in self.completate:
            self.completate.append(ident)
        self.salva()

    def fatta(self, ident: str) -> bool:
        return ident in self.completate

    def azzera(self) -> None:
        self.completate = []
        self.salva()
