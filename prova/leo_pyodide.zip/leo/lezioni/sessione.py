"""La conversazione di `leo impara` nel terminale.

Funziona anche con l'ingresso da una pipe o da un file (per i test e per le
classi): a fine ingresso salva il progresso e saluta.

Comandi che si possono scrivere al posto del programma:
    aiuto      un suggerimento (ogni volta uno più preciso)
    soluzione  mostra una soluzione (dopo almeno un tentativo)
    rileggi    rilegge la spiegazione
    salta      passa alla lezione dopo
    elenco     mostra tutte le lezioni
    esci       chiude (il progresso è già salvato)
"""

from __future__ import annotations

import sys
from typing import Callable, Sequence

from .controllo import Esito, esegui_codice, verifica
from .modello import Lezione, carica_lezioni
from .progresso import Progresso

COMANDI = ("aiuto", "soluzione", "rileggi", "salta", "elenco", "esci")
_FINE = object()


class _Uscita(Exception):
    """È stato scritto `esci` o l'ingresso è finito."""


#: Segni "fatta" / "da fare" dell'elenco delle lezioni: testo semplice, leggibile
#: su ogni console (anche cp1252 di Windows) e senza emoji decorative.
SEGNO_FATTA = "[x]"
SEGNO_DA_FARE = "[ ]"


def _segni_elenco(scrivi: Callable[[str], None] | None = None) -> tuple[str, str]:
    """Segni "fatta" e "da fare" dell'elenco delle lezioni: sempre ``[x]``/``[ ]``."""
    return SEGNO_FATTA, SEGNO_DA_FARE


def _scrivi_stdout(testo: str) -> None:
    sys.stdout.write(testo)
    sys.stdout.flush()


def _rientra(testo: str, spazi: int = 4) -> str:
    return "\n".join((" " * spazi + r) if r.strip() else "" for r in testo.split("\n"))


class Sessione:
    def __init__(self, lezioni: list[Lezione], progresso: Progresso, *,
                 leggi: Callable[[str], str] | None = None,
                 scrivi: Callable[[str], None] | None = None,
                 tempo_massimo: float = 5.0, mostra_disegni: bool | None = None) -> None:
        self.lezioni = lezioni
        self.progresso = progresso
        self._leggi = leggi or input
        self._scrivi = scrivi or _scrivi_stdout
        self.tempo_massimo = tempo_massimo
        if mostra_disegni is None:
            try:
                mostra_disegni = sys.stdin.isatty()
            except (AttributeError, ValueError):
                mostra_disegni = False
        self.mostra_disegni = mostra_disegni

    # ------------------------------------------------------------ ingresso/uscita
    def scrivi(self, testo: str = "") -> None:
        self._scrivi(testo + "\n")

    def leggi(self, domanda: str) -> str:
        try:
            risposta = self._leggi(domanda)
        except (EOFError, KeyboardInterrupt):
            raise _Uscita() from None
        if risposta is None:
            raise _Uscita()
        return risposta.rstrip("\r\n")

    # ------------------------------------------------------------------ elenco
    def successiva(self) -> Lezione | None:
        for lz in self.lezioni:
            if not self.progresso.fatta(lz.ident):
                return lz
        return None

    def mostra_elenco(self) -> None:
        fatte = sum(1 for lz in self.lezioni if self.progresso.fatta(lz.ident))
        self.scrivi(f"Le lezioni ({fatte} di {len(self.lezioni)} completate):")
        fatta, da_fare = _segni_elenco(self._scrivi)
        for lz in self.lezioni:
            segno = fatta if self.progresso.fatta(lz.ident) else da_fare
            self.scrivi(f"  {segno} {lz.numero:>2}. {lz.titolo}")

    def _trova(self, numero: int) -> Lezione | None:
        for lz in self.lezioni:
            if lz.numero == numero:
                return lz
        return None

    # ------------------------------------------------------------------ avvio
    def avvia(self, numero: int | None = None) -> int:
        if not self.lezioni:
            self.scrivi("Non trovo le lezioni: la cartella dati/lezioni è vuota.")
            return 1
        self.scrivi("Leo impara: lezioni guidate, un argomento alla volta.")
        try:
            if numero is None:
                lezione = self._scegli()
            else:
                lezione = self._trova(numero)
                if lezione is None:
                    self.scrivi(f"La lezione {numero} non esiste. Le lezioni vanno da "
                                f"{self.lezioni[0].numero} a {self.lezioni[-1].numero}.")
                    return 2
            while lezione is not None:
                risultato = self.fai_lezione(lezione)
                if risultato == "esci":
                    break
                indice = self.lezioni.index(lezione)
                if indice + 1 >= len(self.lezioni):
                    if all(self.progresso.fatta(lz.ident) for lz in self.lezioni):
                        self.scrivi("\nTutte le lezioni sono completate.")
                        self.scrivi("Per continuare: `leo sfida` oppure gli esempi nella cartella `esempi`.")
                    else:
                        self.scrivi("\nQuesta era l'ultima lezione. Le lezioni saltate si riprendono con `leo impara`.")
                    break
                prossima = self.lezioni[indice + 1]
                risposta = self.leggi(f"\nPassiamo alla lezione {prossima.numero}? (s/n) ").strip().lower()
                if risposta in ("n", "no", "esci"):
                    break
                lezione = prossima
        except _Uscita:
            pass
        self.scrivi("\nA presto. Il progresso è salvato.")
        return 0

    def _scegli(self) -> Lezione | None:
        self.mostra_elenco()
        proposta = self.successiva() or self.lezioni[0]
        while True:
            risposta = self.leggi(f"\nQuale lezione vuoi fare? (Invio = {proposta.numero}) ").strip().lower()
            if not risposta:
                return proposta
            if risposta == "esci":
                raise _Uscita()
            try:
                lezione = self._trova(int(risposta))
            except ValueError:
                lezione = None
            if lezione is not None:
                return lezione
            self.scrivi(f"Scrivi un numero da {self.lezioni[0].numero} a {self.lezioni[-1].numero}, "
                        "oppure `esci`.")

    # ---------------------------------------------------------------- lezione
    def mostra_spiegazione(self, lezione: Lezione) -> None:
        self.scrivi("")
        self.scrivi("=" * 60)
        self.scrivi(f"Lezione {lezione.numero}: {lezione.titolo}")
        self.scrivi("=" * 60)
        self.scrivi(lezione.spiegazione)
        if lezione.esempio and lezione.con_finestra:
            from .controllo import racconta_finestra
            from .finestre import esegui_finestra

            self.scrivi("\nLa finestra ha questi controlli: "
                        + ", ".join(f"{c['nome']} ({c.get('tipo', 'Etichetta')})"
                                    for c in lezione.finestra.get("controlli", [])) + ".")
            self.scrivi("\nUn esempio:")
            self.scrivi(_rientra(lezione.esempio))
            prova = lezione.prove[0] if lezione.prove else {}
            esecuzione = esegui_finestra(lezione.finestra, lezione.esempio, prova, tempo_massimo=self.tempo_massimo)
            righe = racconta_finestra(esecuzione, prova.get("attese") or prova.get("attese_contengono"))
            if righe:
                self.scrivi("Prova della finestra:")
                self.scrivi(_rientra("\n".join(righe)))
        elif lezione.esempio:
            self.scrivi("\nUn esempio:")
            self.scrivi(_rientra(lezione.esempio))
            esecuzione = esegui_codice(lezione.esempio, tempo_massimo=self.tempo_massimo)
            if esecuzione.uscita.strip():
                self.scrivi("Uscita del programma:")
                self.scrivi(_rientra(esecuzione.uscita.rstrip("\n")))
            if esecuzione.tartaruga is not None and esecuzione.tartaruga.tratti:
                self.scrivi(f"(Disegno della tartaruga: {len(esecuzione.tartaruga.tratti)} tratti.)")
        self.scrivi("\nEsercizio:")
        self.scrivi(_rientra(lezione.esercizio, 3))

    def leggi_programma(self) -> str | tuple[str, str]:
        """Legge le righe fino a una riga vuota. Un comando da solo -> ("comando", nome)."""
        self.scrivi("\nScrivi il programma; per finire lascia una riga vuota."
                    " (Comandi: aiuto, soluzione, rileggi, salta, elenco, esci)")
        righe: list[str] = []
        while True:
            try:
                riga = self.leggi("> " if not righe else ". ")
            except _Uscita:
                if righe:
                    return "\n".join(righe)
                raise
            if not righe:
                comando = riga.strip().lower()
                if comando in COMANDI:
                    return ("comando", comando)
                if not comando:
                    continue
            if not riga.strip():
                return "\n".join(righe)
            righe.append(riga)

    def fai_lezione(self, lezione: Lezione) -> str:
        """Svolge una lezione: "fatta", "saltata" o "esci"."""
        self.mostra_spiegazione(lezione)
        aiuti_dati = 0
        tentativi = 0
        while True:
            try:
                letto = self.leggi_programma()
            except _Uscita:
                return "esci"
            if isinstance(letto, tuple):
                comando = letto[1]
                if comando == "esci":
                    return "esci"
                if comando == "salta":
                    self.scrivi(f"Lezione {lezione.numero} saltata: si riprende con `leo impara {lezione.numero}`.")
                    return "saltata"
                if comando == "rileggi":
                    self.mostra_spiegazione(lezione)
                elif comando == "elenco":
                    self.mostra_elenco()
                elif comando == "aiuto":
                    aiuti_dati = self._dai_aiuto(lezione, aiuti_dati)
                elif comando == "soluzione":
                    if tentativi == 0:
                        self.scrivi("La soluzione si vede dopo il primo tentativo. Per un suggerimento scrivi `aiuto`.")
                    else:
                        self.scrivi("Una soluzione possibile (non è l'unica):")
                        self.scrivi(_rientra(lezione.soluzione))
                        self.scrivi("Riscrivila a mano: così si ricorda meglio.")
                continue
            tentativi += 1
            esito = verifica(lezione, letto, tempo_massimo=self.tempo_massimo)
            if esito.ok:
                self._festeggia(lezione, esito)
                return "fatta"
            self.scrivi("\n" + esito.messaggio)
            if tentativi >= 2 and aiuti_dati < len(lezione.aiuti):
                self.scrivi("Dopo due tentativi, un suggerimento:")
                aiuti_dati = self._dai_aiuto(lezione, aiuti_dati)
            else:
                self.scrivi("Correggi il programma e riprova (oppure scrivi `aiuto`).")

    def _dai_aiuto(self, lezione: Lezione, dati: int) -> int:
        if not lezione.aiuti:
            self.scrivi("Suggerimento: rileggi l'esercizio riga per riga.")
            return dati
        if dati >= len(lezione.aiuti):
            self.scrivi("Suggerimento: " + lezione.aiuti[-1])
            self.scrivi("Per vedere una soluzione scrivi `soluzione`.")
            return dati
        self.scrivi("Suggerimento: " + lezione.aiuti[dati])
        return dati + 1

    def _festeggia(self, lezione: Lezione, esito: Esito) -> None:
        self.progresso.completa(lezione.ident)
        if esito.uscita.strip():
            self.scrivi("Il tuo programma ha scritto:")
            self.scrivi(_rientra(esito.uscita.rstrip("\n")))
        if esito.racconto:
            self.scrivi("Nella finestra:")
            self.scrivi(_rientra("\n".join(esito.racconto)))
        t = esito.tartaruga
        if t is not None and t.elementi:
            self._mostra_disegno(lezione, t)
        fatte = sum(1 for lz in self.lezioni if self.progresso.fatta(lz.ident))
        self.scrivi(f"\nLezione {lezione.numero} completata ({fatte} di {len(self.lezioni)}).")

    def _mostra_disegno(self, lezione: Lezione, t) -> None:
        from .. import tartaruga as logica

        if self.mostra_disegni and logica.modalita_finestra() and logica.mostra_finestra(t):
            return
        percorso = self.progresso.percorso.parent / f"lezione_{lezione.numero:02d}.svg"
        try:
            t.salva_svg(percorso)
            self.scrivi(f"Disegno salvato in \"{percorso}\" (si apre con il browser).")
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Riga di comando
# ---------------------------------------------------------------------------

def comando_impara(argv: Sequence[str]) -> int:
    """`leo impara [numero] [--elenco] [--azzera]`."""
    import argparse

    try:
        from ..cli import _Analizzatore as Analizzatore
    except ImportError:  # pragma: no cover
        Analizzatore = argparse.ArgumentParser  # type: ignore[misc,assignment]
    p = Analizzatore(prog="leo impara",
                     description="Lezioni guidate per imparare a programmare con Leo, un passo alla volta.")
    p.add_argument("numero", nargs="?", type=int, default=None, help="la lezione da cui cominciare")
    p.add_argument("--elenco", action="store_true", help="mostra le lezioni e quali hai completato")
    p.add_argument("--azzera", action="store_true", help="ricomincia da capo (cancella il progresso)")
    args = p.parse_args(list(argv))
    lezioni = carica_lezioni()
    progresso = Progresso()
    sessione = Sessione(lezioni, progresso)
    if args.azzera:
        progresso.azzera()
        sessione.scrivi("Progresso azzerato: si riparte dalla lezione 1.")
        return 0
    if args.elenco:
        sessione.mostra_elenco()
        return 0
    return sessione.avvia(args.numero)
