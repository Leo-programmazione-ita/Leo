"""Lavori su piu' processori: i processi lavoratori di Leo.

Python esegue il codice di un processo su un processore alla volta (il GIL).
Per lavorare davvero insieme, un lavoro ``in parallelo`` (gia' isolato da
:mod:`leo.parallelo`) puo' girare in un **processo lavoratore**: un altro
Python, avviato una volta e poi riusato, che riceve la copia del mondo del
lavoro, lo esegue e rimanda indietro risultato, errori e ``stampa``.

* **Avvio.** Il lavoratore e' lo stesso Python (o lo stesso eseguibile) del
  programma: ``python -c ...`` da sorgente, ``leo.exe``/``Leo Studio.exe``
  con ``-c``, i programmi fatti con ``leo compila`` con ``--leo-lavoratore``
  (vedi :func:`comando_lavoratore`). Non si usa ``multiprocessing``: dentro gli
  eseguibili di PyInstaller rilancerebbe il programma intero; qui il figlio sa
  subito di essere un lavoratore. Su Android (Chaquopy) non c'e' un Python da
  avviare: i lavori girano nei fili (stessa semantica, un processore).
* **Collegamento.** ``multiprocessing.connection`` (socket Unix, pipe con nome
  su Windows: niente rete, niente avvisi del firewall) con una chiave segreta
  casuale passata nell'ambiente: solo i figli di questo programma si collegano.
* **Copia.** ``pickle`` con riferimenti "persistenti": la libreria (ambiente
  predefinito e funzioni native) viaggia per nome, i canali per numero (nel
  lavoratore diventano :class:`CanaleRemoto`, che chiede al programma
  principale), i lavori non viaggiano (quel lavoro gira allora in un filo).
* **Annullamento.** Prima con le buone (il lavoratore ferma l'interprete, come
  il pulsante "Ferma"), poi, se non basta entro :data:`GRAZIA_ANNULLAMENTO`,
  il processo si chiude con la forza e se ne avvia un altro quando serve.
* **Quanti.** I lavoratori liberi si riusano; se sono tutti occupati se ne
  avvia un altro, fino a :func:`massimo_lavoratori`; oltre, il lavoro gira in un
  filo (cosi' due lavori che si parlano con un canale non restano mai ad
  aspettarsi a vicenda).
"""

from __future__ import annotations

import atexit
import collections
import io
import itertools
import os
import pickle
import secrets
import subprocess
import sys
import tempfile
import threading
import time
from typing import Any, Callable

from . import parallelo as P
from .ambiente import Ambiente
from .errori import TIPI_ERRORE, ErroreDante, ErroreValore, SegnaleFermaProgramma
from .valori import FunzioneNativa, OggettoControllo

#: Variabile d'ambiente presente nei processi lavoratori (niente processi dentro i processi).
VARIABILE_LAVORATORE = "LEO_PROCESSO_LAVORATORE"
_VARIABILE_INDIRIZZO = "LEO_SERVIZIO_INDIRIZZO"
_VARIABILE_FAMIGLIA = "LEO_SERVIZIO_FAMIGLIA"
_VARIABILE_CHIAVE = "LEO_SERVIZIO_CHIAVE"
_VARIABILE_GETTONE = "LEO_SERVIZIO_GETTONE"
#: Secondi concessi a un lavoratore per partire e collegarsi.
TEMPO_AVVIO = 60.0
#: Un lavoratore libero da piu' di tanti secondi si chiude (in Leo Studio i programmi durano a lungo).
RIPOSO_LAVORATORE = 600.0
#: Secondi concessi a un lavoro annullato per fermarsi da solo prima di chiuderne il processo.
GRAZIA_ANNULLAMENTO = 1.5
_PROTOCOLLO = pickle.HIGHEST_PROTOCOL


def massimo_lavoratori() -> int:
    """Quanti processi lavoratori al massimo (oltre, i lavori girano nei fili)."""
    try:
        valore = int(os.environ.get("LEO_PARALLELO_MASSIMO", "0"))
    except ValueError:
        valore = 0
    if valore > 0:
        return min(valore, 128)
    return min(32, max(4, 2 * P.processori()))


# ===========================================================================
# Come si avvia un lavoratore
# ===========================================================================

def comando_lavoratore() -> list[str] | None:
    """Il comando che avvia un processo lavoratore (None = processi non disponibili qui).

    Al comando si aggiungono gli argomenti del lavoratore: ``--servizio`` per i
    lavoratori di questo modulo, ``ingresso uscita`` per quelli "a file" di
    ``mappa_in_parallelo`` della prima versione (``leo.libreria.programmi``)."""
    if os.environ.get(VARIABILE_LAVORATORE) == "1":
        return None                      # gia' dentro un lavoratore: niente processi annidati
    if P.modo_richiesto() == "fili":
        return None
    from .piattaforma import e_android

    if e_android():
        return None                      # Chaquopy: nessun Python da avviare
    eseguibile = sys.executable
    if not eseguibile or not os.path.exists(eseguibile):
        return None
    codice = ("import sys; sys.path.insert(0, sys.argv[1]); "
              "from leo.parallelo_processi import principale_lavoratore; "
              "sys.exit(principale_lavoratore(sys.argv[2:]))")
    radice = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    if getattr(sys, "frozen", False):
        principale = sys.modules.get("__main__")
        if getattr(principale, "LAVORATORE_LEO", False):
            return [eseguibile, "--leo-lavoratore"]          # programma compilato con `leo compila`
        avvio = sys.modules.get("avvio")
        if avvio is not None and hasattr(avvio, "main_leo"):
            return [eseguibile, "-c", codice, radice]        # leo.exe / Leo Studio.exe
        return None
    return [eseguibile, "-c", codice, radice]


def principale_lavoratore(argomenti: list[str]) -> int:
    """Punto d'ingresso di ogni processo lavoratore (``--servizio`` o la forma "a file")."""
    if argomenti[:1] == ["--servizio"]:
        return servizio_lavoratore(argomenti[1:])
    from .libreria.programmi import lavoratore_processo

    return lavoratore_processo(argomenti)


_STATO: dict[str, Any] = {"motivo": "", "fallimenti": 0}
#: Dopo quanti avvii falliti di fila i processi non si usano piu' (fino alla fine del programma).
AVVII_FALLITI_MASSIMI = 3


def _avvio_fallito(motivo: str) -> None:
    """Un lavoratore non e' partito: dopo :data:`AVVII_FALLITI_MASSIMI` volte di fila i lavori
    girano nei fili (e ``informazioni_parallelismo()`` dice perche')."""
    _STATO["fallimenti"] = _STATO.get("fallimenti", 0) + 1
    if _STATO["fallimenti"] >= AVVII_FALLITI_MASSIMI:
        _STATO["motivo"] = motivo


def processi_disponibili() -> tuple[bool, str]:
    """(si possono usare i processi, perche' no)."""
    if os.environ.get(VARIABILE_LAVORATORE) == "1":
        return False, "questo è già un processo lavoratore: i lavori annidati girano nei fili"
    if P.modo_richiesto() == "fili":
        return False, f"{P.VARIABILE_MODO}=fili"
    from .piattaforma import e_android

    if e_android():
        return False, "su Android (Chaquopy) non si avviano altri processi Python: i lavori girano nei fili"
    if comando_lavoratore() is None:
        return False, "questo eseguibile non sa avviare processi lavoratori"
    if _STATO["motivo"]:
        return False, _STATO["motivo"]
    return True, ""


def vuole_processi() -> bool:
    """Vero se i lavori dovrebbero girare nei processi."""
    richiesto = P.modo_richiesto()
    if richiesto == "fili":
        return False
    if richiesto == "automatico" and not P.gil_attivo():
        return False                      # Python senza GIL: i fili lavorano gia' insieme
    return processi_disponibili()[0]


# ===========================================================================
# Copia fra processi: pickle con riferimenti alla libreria e ai canali
# ===========================================================================

class NonTrasportabile(Exception):
    """Il lavoro usa qualcosa che non passa in un altro processo."""


#: Classi con metodi propri (``_METODI``) i cui metodi viaggiano per nome.
CLASSI_CON_METODI: dict[str, type] = {"Canale": P.Canale, "Lavoro": P.Lavoro}
#: Tipo di canale (``TIPO_REMOTO``) -> classe che lo rappresenta in un processo lavoratore.
TIPI_REMOTI: dict[str, type] = {}
#: Moduli da importare per conoscere un tipo di canale o una classe con metodi.
_MODULI_DEI_TIPI = {"coda": "leo.libreria.programmi", "Coda": "leo.libreria.programmi"}


def _classe(registro_classi: dict[str, type], nome: str) -> type:
    if nome not in registro_classi and nome in _MODULI_DEI_TIPI:
        import importlib

        importlib.import_module(_MODULI_DEI_TIPI[nome])
    return registro_classi[nome]


def _nome_metodo_registrato(f: FunzioneNativa) -> tuple | None:
    from . import registro

    for tipo, metodi in registro.METODI.items():
        if metodi.get(f.nome) is f:
            return ("M", tipo, f.nome)
    for nome, classe in CLASSI_CON_METODI.items():
        if classe._METODI.get(f.nome) is f:
            return ("K", nome, f.nome)
    return None


#: Contesto della copia in corso in questo filo: ``canali`` (raccolti mentre si impacchetta),
#: ``predefinito`` e ``collegamento`` (mentre si spacchetta).
_CONTESTO = threading.local()


def _riferimento_nativa(f: FunzioneNativa) -> tuple:
    from . import registro

    if registro.FUNZIONI.get(f.nome) is f:
        return ("N", f.nome)
    riferimento = _nome_metodo_registrato(f)
    if riferimento is not None:
        return riferimento
    raise NonTrasportabile(f"la funzione `{f.nome}` non passa in un altro processo")


def _riduci_nativa(f: FunzioneNativa) -> tuple:
    return (_nativa, (_riferimento_nativa(f),))


def _nativa(rif: tuple) -> Any:
    """Ricostruisce una funzione della libreria dal suo nome (nel processo che spacchetta)."""
    from . import registro

    genere = rif[0]
    if genere == "N":
        predefinito = getattr(_CONTESTO, "predefinito", None)
        voce = predefinito.voci.get(rif[1]) if predefinito is not None else None
        if voce is not None:
            return voce.valore
        registro.carica_libreria()
        return registro.FUNZIONI[rif[1]]
    if genere == "M":
        registro.carica_libreria()
        return registro.METODI[rif[1]][rif[2]]
    return _classe(CLASSI_CON_METODI, rif[1])._METODI[rif[2]]


def _riduci_ambiente(a: Ambiente) -> Any:
    if a.genitore is None:
        return (_predefinito, ())            # la libreria: quella del processo che spacchetta
    return object.__reduce_ex__(a, _PROTOCOLLO)


def _predefinito() -> Ambiente:
    predefinito = getattr(_CONTESTO, "predefinito", None)
    if predefinito is None:
        raise pickle.UnpicklingError("manca l'ambiente della libreria")
    return predefinito


def riduci_canale(c: Any) -> tuple:
    """Come passa un canale: per numero (nel lavoratore diventa un :class:`CanaleRemoto`)."""
    if not isinstance(c, CanaleRemoto):
        if _LAVORATORE["collegamento"] is not None:
            raise NonTrasportabile("un canale creato dentro un lavoro che gira in un processo non ne esce")
        raccolti = getattr(_CONTESTO, "canali", None)
        if raccolti is not None:
            raccolti.append(c)
    return (_canale, (c.numero, c.capacita, c.TIPO_REMOTO))


def _canale(numero: int, capacita: int, tipo: str) -> Any:
    collegamento = getattr(_CONTESTO, "collegamento", None)
    if collegamento is not None:
        return _classe(TIPI_REMOTI, tipo)(numero, collegamento, capacita)
    canale = P.CANALI.get(numero)
    if canale is None:
        raise pickle.UnpicklingError(f"il canale {numero} non esiste più")
    return canale


def _tabella() -> dict:
    """Le regole di copia (``dispatch_table`` del pickler): libreria per nome, predefinito come segno."""
    tabella = dict(copyreg_tabella())
    da_vedere = [FunzioneNativa]
    while da_vedere:
        classe = da_vedere.pop()
        tabella[classe] = _riduci_nativa
        da_vedere.extend(classe.__subclasses__())
    tabella[Ambiente] = _riduci_ambiente
    return tabella


def copyreg_tabella() -> dict:
    import copyreg

    return copyreg.dispatch_table


def impacchetta(valore: Any) -> tuple[bytes, list]:
    """(byte, canali usati); NonTrasportabile se qualcosa non passa in un altro processo."""
    flusso = io.BytesIO()
    p = pickle.Pickler(flusso, protocol=_PROTOCOLLO)
    p.dispatch_table = _tabella()
    precedenti = getattr(_CONTESTO, "canali", None)
    _CONTESTO.canali = canali = []
    try:
        p.dump(valore)
    except NonTrasportabile:
        raise
    except RecursionError:
        raise NonTrasportabile("dati annidati troppo in profondità") from None
    except Exception as e:  # noqa: BLE001 - qualunque cosa non copiabile
        raise NonTrasportabile(str(e)) from None
    finally:
        _CONTESTO.canali = precedenti
    return flusso.getvalue(), canali


def spacchetta(dati: bytes, predefinito: Ambiente, collegamento: Any = None) -> Any:
    """Il valore dai byte di :func:`impacchetta`, con la libreria ``predefinito`` di questo processo."""
    precedenti = (getattr(_CONTESTO, "predefinito", None), getattr(_CONTESTO, "collegamento", None))
    _CONTESTO.predefinito, _CONTESTO.collegamento = predefinito, collegamento
    try:
        return pickle.loads(dati)
    finally:
        _CONTESTO.predefinito, _CONTESTO.collegamento = precedenti


def _errore_in_dati(e: ErroreDante) -> bytes:
    try:
        return impacchetta(e)[0]
    except NonTrasportabile:
        return pickle.dumps(("errore", e.tipo, e.messaggio, e.suggerimento, e.riga, e.colonna,
                             getattr(e, "nome_file", "<sorgente>")), protocol=_PROTOCOLLO)


def _errore_da_dati(dati: bytes, predefinito: Ambiente) -> ErroreDante:
    try:
        valore = spacchetta(dati, predefinito)
    except Exception as e:  # noqa: BLE001
        return ErroreValore(f"Errore interno di Leo: l'errore del lavoro non si legge ({e}).")
    if isinstance(valore, ErroreDante):
        return valore
    if isinstance(valore, tuple) and valore[:1] == ("errore",):
        _, tipo, messaggio, suggerimento, riga, colonna, nome_file = valore
        classe = TIPI_ERRORE.get(tipo, ErroreValore)
        return classe(messaggio, riga=riga or 0, colonna=colonna or 0, suggerimento=suggerimento,
                      nome_file=nome_file)
    return ErroreValore("Errore interno di Leo: il lavoro ha mandato un errore che non capisco.")


# ===========================================================================
# Lato del programma: i lavoratori
# ===========================================================================

#: Sotto questa frazione di processore un lavoratore occupato "sta aspettando" (rete, canali, attese):
#: se ci sono lavori in coda conviene avviarne un altro.
CARICO_IN_ATTESA = 0.25
#: Lavoratori al massimo, anche quando quelli occupati stanno solo aspettando.
MASSIMO_ASSOLUTO = 64


class _Lavoratore:
    """Un processo lavoratore visto dal programma principale."""

    def __init__(self, servizio: "_Servizio", gettone: str) -> None:
        self.servizio = servizio
        self.gettone = gettone
        self.processo: subprocess.Popen | None = None
        self.collegamento: Any = None
        self.pronto = threading.Event()
        self.vivo = True
        self.libero = False
        self.destinatario: Any = None           # l'incarico in corso
        self._invio = threading.Lock()
        self._richieste: dict[int, threading.Event] = {}   # richieste aperte (evento acceso = lasciata)
        self.registro_errori: str | None = None
        self.pid = 0
        self.lanciato = 0.0
        self.carico = 1.0                       # frazione di processore usata (dai battiti)
        self._finito = False
        self._fine_blocco = threading.Lock()

    # --- avvio ---
    def lancia(self, comando: list[str]) -> bool:
        ambiente = dict(os.environ)
        ambiente[VARIABILE_LAVORATORE] = "1"
        ambiente["PYTHONIOENCODING"] = "utf-8"
        ambiente["PYINSTALLER_SUPPRESS_SPLASH_SCREEN"] = "1"
        ambiente[_VARIABILE_INDIRIZZO] = self.servizio.indirizzo_testo
        ambiente[_VARIABILE_FAMIGLIA] = self.servizio.famiglia
        ambiente[_VARIABILE_CHIAVE] = self.servizio.chiave.hex()
        ambiente[_VARIABILE_GETTONE] = self.gettone
        opzioni: dict[str, Any] = {}
        if os.name == "nt":
            opzioni["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        try:
            descrittore, self.registro_errori = tempfile.mkstemp(prefix="leo_lavoratore_", suffix=".txt")
            with os.fdopen(descrittore, "wb") as errori:
                self.processo = subprocess.Popen([*comando, "--servizio"], stdin=subprocess.DEVNULL,
                                                 stdout=subprocess.DEVNULL, stderr=errori, env=ambiente,
                                                 close_fds=True, **opzioni)
        except OSError as e:
            self._togli_registro()
            self.vivo = False
            _avvio_fallito(f"non riesco ad avviare un processo lavoratore ({e})")
            return False
        self.pid = self.processo.pid
        self.lanciato = time.monotonic()
        return True

    def collega(self, collegamento: Any) -> None:
        self.collegamento = collegamento
        self.pronto.set()
        P.avvia_filo(self._ascolta, "leo-lavoratore-ascolta")

    def ultime_righe_errori(self) -> str:
        if not self.registro_errori:
            return ""
        try:
            with open(self.registro_errori, "rb") as f:
                righe = f.read().decode("utf-8", errors="replace").strip().splitlines()
        except OSError:
            return ""
        return " / ".join(righe[-3:])

    def _togli_registro(self) -> None:
        if self.registro_errori:
            try:
                os.remove(self.registro_errori)
            except OSError:
                pass
            self.registro_errori = None

    def in_attesa(self) -> bool:
        """Vero se e' occupato ma non sta calcolando (aspetta la rete, un canale, il tempo)."""
        return bool(self._richieste) or self.carico < CARICO_IN_ATTESA

    # --- messaggi ---
    def invia(self, messaggio: tuple) -> bool:
        if not self.vivo or self.collegamento is None:
            return False
        try:
            with self._invio:
                self.collegamento.send(messaggio)
            return True
        except (OSError, EOFError, ValueError):
            P.avvia_filo(self._morto, "leo-lavoratore-fine")
            return False

    def _ascolta(self) -> None:
        while self.vivo:
            try:
                messaggio = self.collegamento.recv()
            except Exception:  # noqa: BLE001 - collegamento chiuso o rotto: il processo e' finito
                break
            try:
                self._smista(messaggio)
            except Exception:  # noqa: BLE001 - un messaggio rotto non ferma l'ascolto
                pass
        self._morto()

    def _smista(self, messaggio: tuple) -> None:
        genere = messaggio[0]
        destinatario = self.destinatario
        if genere == "stampa":
            if destinatario is not None and destinatario.numero == messaggio[1]:
                destinatario.stampa(messaggio[2])
        elif genere == "battito":
            self.carico = float(messaggio[1])
        elif genere == "fine":
            if destinatario is not None and destinatario.numero == messaggio[1]:
                self.destinatario = None
                self.carico = 1.0
                destinatario.fine(messaggio[2], messaggio[3])
                self.servizio.restituisci(self)
        elif genere == "richiesta":
            _, numero, operazione, dati = messaggio
            lasciata = threading.Event()
            self._richieste[numero] = lasciata
            # prima si prova subito (quasi sempre il canale e' pronto); se dovrebbe aspettare,
            # l'attesa si fa in un altro filo e questo continua ad ascoltare
            if not self._servi(numero, operazione, dati, lasciata, destinatario, subito=True):
                P.in_un_filo(lambda: self._servi(numero, operazione, dati, lasciata, destinatario))
        elif genere == "lascia":
            evento = self._richieste.get(messaggio[1])
            if evento is not None:
                evento.set()

    def _servi(self, numero: int, operazione: str, dati: bytes, lasciata: threading.Event,
               destinatario: Any, subito: bool = False) -> bool:
        """Esegue la richiesta e risponde; con ``subito`` solo se non deve aspettare (falso se no)."""
        def fermato() -> bool:
            return lasciata.is_set() or not self.vivo

        predefinito = destinatario.predefinito if destinatario is not None else Ambiente()
        try:
            try:
                argomenti = spacchetta(dati, predefinito)
                esito, valore = servi_richiesta(operazione, argomenti, fermato, subito)
            except _DeveAspettare:
                return False
            except SegnaleFermaProgramma:
                self._richieste.pop(numero, None)
                return True
            except ErroreDante as e:
                esito, valore = "errore", e
            except Exception as e:  # noqa: BLE001
                esito, valore = "errore", ErroreValore(f"Errore interno di Leo con un canale: {e}")
            try:
                carico = impacchetta(valore)[0] if esito != "errore" else _errore_in_dati(valore)
            except NonTrasportabile as e:
                esito, carico = "errore", _errore_in_dati(ErroreValore(
                    f"Il messaggio non può arrivare al lavoro: {e}.",
                    suggerimento="Nei canali manda numeri, testi, liste e dizionari."))
            self.invia(("risposta", numero, esito, carico))
            self._richieste.pop(numero, None)
            return True
        finally:
            if not subito:
                self._richieste.pop(numero, None)

    # --- fine ---
    def uccidi(self) -> None:
        processo = self.processo
        if processo is not None and processo.poll() is None:
            try:
                processo.kill()
            except OSError:
                pass
        self._morto()

    def _morto(self) -> None:
        with self._fine_blocco:
            if self._finito:
                return
            self._finito = True
        self.vivo = False
        for evento in list(self._richieste.values()):
            evento.set()
        try:
            if self.collegamento is not None:
                self.collegamento.close()
        except OSError:
            pass
        if self.processo is not None and self.processo.poll() is None:
            try:
                self.processo.kill()
            except OSError:
                pass
        self.servizio.togli(self)
        with self.servizio.blocco:
            destinatario, self.destinatario = self.destinatario, None
        codice = None
        if self.processo is not None:
            try:
                codice = self.processo.wait(timeout=2)
            except subprocess.TimeoutExpired:
                codice = None
        if destinatario is not None:
            destinatario.morto(codice, self.ultime_righe_errori())
        self._togli_registro()
        self.servizio.distribuisci()


class _DeveAspettare(Exception):
    """L'operazione sul canale dovrebbe aspettare: la si rifa' in un filo a parte."""


def servi_richiesta(operazione: str, argomenti: Any, fermato: Callable[[], bool],
                    subito: bool = False) -> tuple[str, Any]:
    """Esegue nel programma principale un'operazione chiesta da un lavoratore su un canale. Con
    ``subito`` solleva :class:`_DeveAspettare` invece di aspettare."""
    def limite_da(secondi: Any) -> float | None:
        if subito:
            return time.monotonic()
        return None if secondi is None else time.monotonic() + float(secondi)

    try:
        return _servi_canale(operazione, argomenti, fermato, limite_da)
    except P.TempoScaduto:
        if subito:
            raise _DeveAspettare() from None
        return "scaduto", None


def _servi_canale(operazione: str, argomenti: Any, fermato: Callable[[], bool],
                  limite_da: Callable[[Any], float | None]) -> tuple[str, Any]:
    try:
        if operazione == "invia":
            canale, messaggio, secondi = argomenti
            canale.invia_dato(messaggio, fermato, limite_da(secondi))
            return "ok", None
        if operazione == "ricevi":
            canale, secondi = argomenti
            return "ok", canale.prendi_dato(fermato, limite_da(secondi))
        if operazione == "chiudi":
            return "ok", argomenti.chiudi()
        if operazione == "lunghezza":
            return "ok", argomenti.lunghezza()
        if operazione == "chiuso":
            return "ok", argomenti.chiuso()
        if operazione == "seleziona":
            canali, secondi = argomenti
            indice, messaggio = P.seleziona(canali, fermato, limite_da(secondi))
            return "ok", [indice, messaggio]
    except P.CanaleChiuso:
        return "chiuso", None
    raise ErroreValore(f"Operazione sconosciuta su un canale: {operazione}.")


# ===========================================================================
# Lato del programma: il servizio (coda degli incarichi e lavoratori)
# ===========================================================================

class _Servizio:
    """I processi lavoratori di questo programma (uno solo per processo) e la coda degli incarichi.

    Un incarico va a un lavoratore libero; se non ce n'e' aspetta in coda e, finche' i
    lavoratori sono meno di :func:`massimo_lavoratori` (uno per processore), se ne avvia un
    altro. Se tutti quelli occupati stanno solo aspettando (rete, canali, ``attendi``) se ne
    avvia uno in piu' (fino a :data:`MASSIMO_ASSOLUTO`); oltre, l'incarico piu' vecchio gira
    in un filo di questo processo: cosi' nessun lavoro resta in coda per sempre."""

    def __init__(self) -> None:
        from multiprocessing.connection import Listener

        self.blocco = threading.RLock()
        self.lavoratori: list[_Lavoratore] = []
        self.in_avvio: dict[str, _Lavoratore] = {}
        self.coda: "collections.deque[Incarico]" = collections.deque()
        self.chiave = secrets.token_bytes(32)
        self.famiglia = "AF_PIPE" if os.name == "nt" else "AF_UNIX"
        self.ascoltatore = Listener(family=self.famiglia, authkey=self.chiave)
        self.indirizzo_testo = str(self.ascoltatore.address)
        self.chiuso = False
        self._sorvegliante: threading.Thread | None = None
        self._ultimo_progresso = time.monotonic()
        self.minimo = 0                       # lavoratori da tenere pronti (chiesti da `prepara`)
        P.avvia_filo(self._accetta, "leo-lavoratori-accetta")

    # --- collegamenti in arrivo ---
    def _accetta(self) -> None:
        while not self.chiuso:
            try:
                collegamento = self.ascoltatore.accept()
            except Exception:  # noqa: BLE001 - autenticazione fallita o ascoltatore chiuso
                if self.chiuso:
                    return
                time.sleep(0.01)
                continue
            P.avvia_filo(lambda c=collegamento: self._saluta(c), "leo-lavoratori-saluto")

    def _saluta(self, collegamento: Any) -> None:
        try:
            if not collegamento.poll(TEMPO_AVVIO):
                collegamento.close()
                return
            saluto = collegamento.recv()
        except Exception:  # noqa: BLE001
            return
        if not (isinstance(saluto, tuple) and len(saluto) == 3 and saluto[0] == "ciao"):
            collegamento.close()
            return
        with self.blocco:
            lavoratore = self.in_avvio.pop(saluto[1], None)
            if lavoratore is not None:
                lavoratore.libero = True
        if lavoratore is None:
            collegamento.close()
            return
        _STATO["fallimenti"] = 0
        lavoratore.collega(collegamento)
        self.distribuisci()

    # --- incarichi ---
    def affida(self, incarichi: list["Incarico"]) -> None:
        """Mette in coda gli incarichi (senza aspettare): partono appena c'e' un lavoratore."""
        with self.blocco:
            for incarico in incarichi:
                incarico.stato = "in coda"
                self.coda.append(incarico)
        self.distribuisci()

    def togli_dalla_coda(self, incarico: "Incarico") -> bool:
        with self.blocco:
            try:
                self.coda.remove(incarico)
            except ValueError:
                return False
            return True

    def distribuisci(self) -> None:
        """Da' gli incarichi in coda ai lavoratori liberi e avvia i lavoratori che servono."""
        assegnati: list[tuple[_Lavoratore, Incarico]] = []
        nuovi: list[_Lavoratore] = []
        comando = comando_lavoratore()
        with self.blocco:
            if self.chiuso:
                return
            liberi = [l for l in self.lavoratori if l.vivo and l.libero and l.pronto.is_set()]
            while self.coda and liberi:
                lavoratore = liberi.pop(0)
                incarico = self.coda.popleft()
                lavoratore.libero = False
                lavoratore.carico = 1.0
                lavoratore.destinatario = incarico
                incarico.lavoratore = lavoratore
                incarico.stato = "nel processo"
                assegnati.append((lavoratore, incarico))
            if assegnati:
                self._ultimo_progresso = time.monotonic()
            vivi = sum(1 for l in self.lavoratori if l.vivo)
            mancano = max(len(self.coda) - len(self.in_avvio), self.minimo - vivi)
            limite = max(massimo_lavoratori(), self.minimo)
            while mancano > 0 and vivi < limite and comando is not None and not _STATO["motivo"]:
                l = _Lavoratore(self, secrets.token_hex(16))
                self.lavoratori.append(l)
                self.in_avvio[l.gettone] = l
                nuovi.append(l)
                vivi += 1
                mancano -= 1
        for lavoratore, incarico in assegnati:
            if not lavoratore.invia(("esegui", incarico.numero, incarico.dati)):
                pass                                  # il lavoratore e' morto: l'incarico lo sa da `morto`
        for l in nuovi:
            if not l.lancia(comando):
                self.togli(l)
        if self.coda or self.in_avvio:
            self._assicura_sorvegliante()

    def _assicura_sorvegliante(self) -> None:
        with self.blocco:
            if self._sorvegliante is not None and self._sorvegliante.is_alive():
                return
            self._sorvegliante = threading.Thread(target=self._sorveglia, name="leo-lavoratori-sorvegliante",
                                                  daemon=True)
            self._sorvegliante.start()

    def _sorveglia(self) -> None:
        """Finche' c'e' qualcosa in coda o in avvio: controlla gli avvii e chi aspetta troppo."""
        while not self.chiuso:
            time.sleep(0.03)
            adesso = time.monotonic()
            da_far_girare_qui: list[Incarico] = []
            falliti: list[_Lavoratore] = []
            avvia_uno = False
            with self.blocco:
                for l in list(self.in_avvio.values()):
                    finito = l.processo is not None and l.processo.poll() is not None
                    if finito or adesso - l.lanciato > TEMPO_AVVIO:
                        falliti.append(l)
                        self.in_avvio.pop(l.gettone, None)
                if not self.coda and not self.in_avvio:
                    self._sorvegliante = None
                    if not falliti:
                        return
                vivi = [l for l in self.lavoratori if l.vivo and l not in falliti]
                if self.coda and not self.in_avvio:
                    liberi = [l for l in vivi if l.libero and l.pronto.is_set()]
                    occupati = [l for l in vivi if not l.libero]
                    if not vivi:
                        da_far_girare_qui = list(self.coda)
                        self.coda.clear()
                    elif not liberi and occupati and all(l.in_attesa() for l in occupati) \
                            and adesso - self._ultimo_progresso > 0.1:
                        if len(vivi) < MASSIMO_ASSOLUTO and not _STATO["motivo"]:
                            avvia_uno = True
                            self._ultimo_progresso = adesso
                        elif adesso - self._ultimo_progresso > 0.5:
                            da_far_girare_qui = [self.coda.popleft()]
                            self._ultimo_progresso = adesso
            for l in falliti:
                dettaglio = l.ultime_righe_errori()
                l.uccidi()
                _avvio_fallito("il processo lavoratore non è partito" + (f": {dettaglio}" if dettaglio else ""))
            if avvia_uno:
                self._avvia_extra()
            for incarico in da_far_girare_qui:
                incarico.riparti_qui()
            if falliti:
                self.distribuisci()

    def _avvia_extra(self) -> None:
        comando = comando_lavoratore()
        if comando is None:
            return
        with self.blocco:
            l = _Lavoratore(self, secrets.token_hex(16))
            self.lavoratori.append(l)
            self.in_avvio[l.gettone] = l
        if not l.lancia(comando):
            self.togli(l)

    def prepara(self, quanti: int, aspetta: bool = True) -> int:
        """Tiene pronti almeno ``quanti`` lavoratori (aspetta che partano); quanti sono pronti."""
        with self.blocco:
            self.minimo = max(self.minimo, min(quanti, MASSIMO_ASSOLUTO))
        self.distribuisci()
        limite = time.monotonic() + TEMPO_AVVIO
        while aspetta and time.monotonic() < limite:
            with self.blocco:
                pronti = sum(1 for l in self.lavoratori if l.vivo and l.pronto.is_set())
                in_avvio = len(self.in_avvio)
            if pronti >= quanti or (in_avvio == 0 and pronti + in_avvio < quanti):
                break
            time.sleep(0.01)
        with self.blocco:
            self.minimo = 0
            return sum(1 for l in self.lavoratori if l.vivo and l.pronto.is_set())

    def restituisci(self, lavoratore: _Lavoratore) -> None:
        with self.blocco:
            if lavoratore.vivo:
                lavoratore.destinatario = None
                lavoratore.libero = True
                self._ultimo_progresso = time.monotonic()
        self.distribuisci()

    def togli(self, lavoratore: _Lavoratore) -> None:
        with self.blocco:
            if lavoratore in self.lavoratori:
                self.lavoratori.remove(lavoratore)
            self.in_avvio.pop(lavoratore.gettone, None)

    def chiudi(self) -> None:
        with self.blocco:
            self.chiuso = True
            coda = list(self.coda)
            self.coda.clear()
        for incarico in coda:
            incarico.riparti_qui()
        for l in list(self.lavoratori):
            l.invia(("esci",))
        limite = time.monotonic() + 0.5
        for l in list(self.lavoratori):
            if l.processo is not None:
                try:
                    l.processo.wait(timeout=max(0.0, limite - time.monotonic()))
                except subprocess.TimeoutExpired:
                    pass
            l.uccidi()
        try:
            self.ascoltatore.close()
        except Exception:  # noqa: BLE001
            pass


_SERVIZIO: list[_Servizio] = []
_BLOCCO_SERVIZIO = threading.Lock()


def servizio() -> _Servizio | None:
    """Il servizio dei lavoratori (creato al primo uso); None se non si puo' creare."""
    if _SERVIZIO:
        return _SERVIZIO[0]
    with _BLOCCO_SERVIZIO:
        if not _SERVIZIO:
            try:
                _SERVIZIO.append(_Servizio())
            except Exception as e:  # noqa: BLE001
                _STATO["motivo"] = f"non riesco a preparare il collegamento con i processi lavoratori ({e})"
                return None
            atexit.register(chiudi_servizio)
    return _SERVIZIO[0]


def chiudi_servizio() -> None:
    """Chiude tutti i processi lavoratori (alla fine del programma)."""
    with _BLOCCO_SERVIZIO:
        servizi = list(_SERVIZIO)
        _SERVIZIO.clear()
    for s in servizi:
        s.chiudi()


def quanti_lavoratori() -> int:
    return sum(1 for l in _SERVIZIO[0].lavoratori if l.vivo) if _SERVIZIO else 0


def prepara_lavoratori(quanti: int = 1, aspetta: bool = True) -> int:
    """Avvia in anticipo ``quanti`` lavoratori (cosi' i lavori partono subito); quanti sono pronti."""
    if not vuole_processi():
        return 0
    s = servizio()
    if s is None:
        return 0
    return s.prepara(quanti, aspetta)


# ===========================================================================
# Lato del programma: un incarico (un lavoro, o un pezzo di una mappa)
# ===========================================================================

_NUMERI = itertools.count(1)


def pacchetto_lavoro(genitore: Any, funzione: Any, globale: Ambiente, chiamate: list | None) -> dict:
    """Quello che il lavoratore deve sapere per eseguire ``funzione``."""
    return {
        "funzione": funzione,
        "globale": globale,
        "chiamate": chiamate,
        "cartella": os.getcwd(),
        "nome_file": getattr(genitore, "nome_file", "<sorgente>"),
        "file_corrente": getattr(funzione, "nome_file", None) or getattr(genitore, "_file_corrente", None),
        "dichiarazione_implicita": bool(getattr(genitore, "dichiarazione_implicita", False)),
        "tollerante": bool(getattr(genitore, "tollerante", True)),
        "profondita_massima": int(getattr(genitore, "profondita_massima", 1000)),
        "con_grafica": getattr(genitore, "ponte_grafico", None) is not None,
        "percorsi_moduli": list(getattr(genitore, "percorsi_moduli", ()) or ()),
        "sorgenti_moduli": dict(getattr(genitore, "sorgenti_moduli", {}) or {}),
    }


class Incarico:
    """Un pacchetto da eseguire in un lavoratore (o, se serve, in un filo di questo processo).

    Le sottoclassi ricevono l'esito in :meth:`concluso` (``"ok"`` con il valore,
    ``"errore"`` con l'errore, ``"annullato"``)."""

    def __init__(self, dati: bytes, canali: list, predefinito: Ambiente, uscita: Callable[[str], None]) -> None:
        self.numero = next(_NUMERI)
        self.dati = dati
        self.canali = canali                    # restano vivi finche' l'incarico gira
        self.predefinito = predefinito
        self.uscita = uscita
        self.stato = "nuovo"
        self.lavoratore: _Lavoratore | None = None
        self.annullato = False
        self.tentativi = 0
        self._locale: dict[str, Any] | None = None
        self._concluso = False
        self._blocco = threading.Lock()

    # --- dal lavoratore ---
    def stampa(self, testo: str) -> None:
        with P.BLOCCO_USCITA:
            try:
                self.uscita(testo)
            except Exception:  # noqa: BLE001
                pass

    def fine(self, esito: str, dati: bytes) -> None:
        if esito == "ok":
            try:
                valore = spacchetta(dati, self.predefinito)
            except Exception as e:  # noqa: BLE001
                self._chiudi("errore", ErroreValore(f"Errore interno di Leo: il risultato del lavoro non si "
                                                   f"legge ({e})."))
                return
            self._chiudi("ok", valore)
        elif esito == "annullato":
            self._chiudi("annullato", None)
        else:
            self._chiudi("errore", _errore_da_dati(dati, self.predefinito))

    def morto(self, codice: int | None, dettaglio: str) -> None:
        if self.annullato:
            self._chiudi("annullato", None)
            return
        self.tentativi += 1
        if self.tentativi < 3 and self.stato == "nel processo" and codice in (None, 0):
            # il lavoratore si e' chiuso da solo (era libero da troppo tempo) proprio mentre gli
            # arrivava l'incarico: l'incarico non e' mai partito, va a un altro lavoratore
            self.lavoratore = None
            s = servizio()
            if s is not None and not s.chiuso:
                s.affida([self])
            else:
                self.riparti_qui()
            return
        testo = f" (codice {codice})" if codice not in (None, 0) else ""
        self._chiudi("errore", ErroreValore(
            f"Il processo del lavoro `in parallelo` si è fermato all'improvviso{testo}.",
            suggerimento=("Dettaglio: " + dettaglio) if dettaglio else
            "Forse la memoria non basta: prova a dividere il lavoro in parti più piccole."))

    def _chiudi(self, esito: str, valore: Any) -> None:
        with self._blocco:
            if self._concluso:
                return
            self._concluso = True
        self.stato = "finito"
        self.canali = []
        self.concluso(esito, valore)

    def concluso(self, esito: str, valore: Any) -> None:  # pragma: no cover - nelle sottoclassi
        raise NotImplementedError

    # --- dal programma ---
    def annulla(self) -> None:
        if self.annullato or self._concluso:
            return
        self.annullato = True
        s = _SERVIZIO[0] if _SERVIZIO else None
        if self.stato == "in coda" and s is not None and s.togli_dalla_coda(self):
            self._chiudi("annullato", None)
            return
        locale = self._locale
        if locale is not None:
            locale["annullato"] = True
            if locale.get("interprete") is not None:
                locale["interprete"].ferma()
            return
        lavoratore = self.lavoratore
        if lavoratore is None:
            return
        lavoratore.invia(("annulla", self.numero))

        def forza() -> None:
            limite = time.monotonic() + GRAZIA_ANNULLAMENTO
            while time.monotonic() < limite:
                if self._concluso:
                    return
                time.sleep(0.02)
            if not self._concluso and lavoratore.destinatario is self:
                lavoratore.uccidi()

        threading.Thread(target=forza, name="leo-annulla", daemon=True).start()

    def riparti_qui(self) -> None:
        """Esegue l'incarico in un filo di questo processo (stessa copia isolata)."""
        if self._concluso:
            return
        self.stato = "qui"
        self.lavoratore = None
        stato: dict[str, Any] = {"interprete": None, "annullato": self.annullato}
        self._locale = stato

        def manda(messaggio: tuple) -> None:
            if messaggio[0] == "stampa":
                self.stampa(messaggio[2])
            elif messaggio[0] == "fine":
                self.fine(messaggio[2], messaggio[3])

        P.in_un_filo(lambda: esegui_pacchetto(self.numero, self.dati, stato, self.predefinito, None, manda))


class IncaricoLavoro(Incarico):
    """L'incarico di un lavoro ``in parallelo``: l'esito va al :class:`~leo.parallelo.Lavoro`."""

    def __init__(self, lavoro: Any, dati: bytes, canali: list) -> None:
        genitore = lavoro._genitore
        super().__init__(dati, canali, genitore.predefinito, genitore.uscita)
        self.lavoro = lavoro

    def avvia(self) -> None:
        s = servizio()
        if s is None:
            self.riparti_qui()
            return
        s.affida([self])

    def riparti_qui(self) -> None:
        self.lavoro.modo = "filo"
        super().riparti_qui()

    def stampa(self, testo: str) -> None:
        if not self.lavoro._annulla_richiesto:
            super().stampa(testo)

    def concluso(self, esito: str, valore: Any) -> None:
        if esito == "ok":
            self.lavoro.concludi(risultato=valore)
        elif esito == "annullato":
            self.lavoro.concludi(annullato=True)
        else:
            self.lavoro.concludi(errore=valore)


def prova_in_processo(lavoro: Any, mondo: Any) -> IncaricoLavoro | None:
    """Prepara il lavoro per un processo lavoratore; None se deve girare in un filo (non si puo'
    copiare in un altro processo, oppure i processi non ci sono)."""
    if not vuole_processi():
        return None
    try:
        dati, canali = impacchetta(pacchetto_lavoro(lavoro._genitore, mondo.funzione, mondo.globale, None))
    except NonTrasportabile:
        return None
    if servizio() is None:
        return None
    return IncaricoLavoro(lavoro, dati, canali)


# ===========================================================================
# mappa su piu' processi (usata da mappa_in_parallelo)
# ===========================================================================

class _Pezzo(Incarico):
    """Un pezzo di una mappa: raccoglie l'esito e accende l'evento comune."""

    def __init__(self, dati: bytes, canali: list, predefinito: Ambiente, uscita: Callable[[str], None],
                 evento: threading.Event) -> None:
        super().__init__(dati, canali, predefinito, uscita)
        self.evento = evento
        self.esito: tuple | None = None

    def concluso(self, esito: str, valore: Any) -> None:
        self.esito = (esito, valore)
        self.evento.set()


class MappaNonPossibile(Exception):
    """La mappa non puo' usare i processi: si fa in un altro modo."""


def mappa_nei_processi(interprete: Any, funzione: Any, dati: list, quanti: int,
                       tempo_massimo: float | None) -> list:
    """``funzione`` su ogni elemento di ``dati`` con ``quanti`` processi (l'ordine resta quello di
    ``dati``). La funzione vede una copia isolata del programma. MappaNonPossibile se i processi
    non si possono usare."""
    from .valori import FunzioneDante

    if not processi_disponibili()[0] or not hasattr(interprete, "globale"):
        raise MappaNonPossibile()
    isolatore = P.Isolatore(copia=False)
    f = isolatore.funzione(funzione) if isinstance(funzione, FunzioneDante) else funzione
    globale = isolatore.ambiente(interprete.globale)
    elenco = [isolatore.valore(x) for x in dati]
    gruppi = [[(i, [elenco[i]]) for i in range(n, len(elenco), quanti)] for n in range(quanti)]
    gruppi = [g for g in gruppi if g]
    evento = threading.Event()
    pezzi: list[_Pezzo] = []
    try:
        for gruppo in gruppi:
            carico, usati = impacchetta(pacchetto_lavoro(interprete, f, globale, gruppo))
            pezzi.append(_Pezzo(carico, usati, interprete.predefinito, interprete.uscita, evento))
    except NonTrasportabile:
        raise MappaNonPossibile() from None
    s = servizio()
    if s is None:
        raise MappaNonPossibile()
    if s.prepara(len(pezzi)) < 1:
        raise MappaNonPossibile()
    limite = None if tempo_massimo is None else time.monotonic() + tempo_massimo
    s.affida(pezzi)
    risultati: dict[int, Any] = {}
    errori: list[tuple[int, ErroreDante]] = []
    try:
        while True:
            evento.clear()
            for pezzo in pezzi:
                if pezzo.esito is None or pezzo.esito == "letto":
                    continue
                esito, valore = pezzo.esito
                pezzo.esito = "letto"  # type: ignore[assignment]
                if esito == "ok":
                    for indice, ok, v in valore:
                        if ok:
                            risultati[indice] = v
                        else:
                            errori.append((indice, v))
                elif esito == "annullato":
                    raise SegnaleFermaProgramma()
                else:
                    errori.append((-1, valore))
            if errori:
                indice, errore = min(errori, key=lambda e: e[0])
                raise errore
            if all(p.esito == "letto" for p in pezzi):
                return [risultati[i] for i in range(len(dati))]
            if any(p.esito not in (None, "letto") for p in pezzi):
                continue
            if not P.attendi_evento(interprete, evento, limite):
                raise ErroreValore(
                    f"`mappa_in_parallelo` non ha finito entro {_numero(tempo_massimo)} secondi.",
                    suggerimento="Dai più tempo con `tempo_massimo`, oppure dividi il lavoro in parti più piccole.")
    finally:
        for pezzo in pezzi:
            if pezzo.esito is None:
                pezzo.annulla()


def _numero(x: Any) -> str:
    from .valori import rappresenta

    return rappresenta(x)


# ===========================================================================
# Lato del lavoratore
# ===========================================================================

_LAVORATORE: dict[str, Any] = {"collegamento": None, "invio": None, "predefinito": None}


class CanaleRemoto(P.Canale):
    """Un canale del programma principale visto da un processo lavoratore: ogni operazione
    e' una richiesta al programma principale, che la esegue sul canale vero."""

    TIPO_REMOTO = "canale"

    def __init__(self, numero: int, collegamento: Any, capacita: int = 0) -> None:  # noqa: D107
        self.numero = numero
        self.capacita = capacita
        self._collegamento = collegamento

    def testo_dante(self) -> str:
        return f"<canale {self.numero}>"

    def lunghezza(self) -> int:
        return richiesta_al_programma("lunghezza", self, _fermato_qui)[1]

    def chiuso(self) -> bool:
        return bool(richiesta_al_programma("chiuso", self, _fermato_qui)[1])

    def osserva(self, evento: threading.Event) -> None:
        evento.set()

    def smetti_di_osservare(self, evento: threading.Event) -> None:
        pass

    def invia_dato(self, messaggio: Any, fermato: Callable[[], bool], limite: float | None = None) -> None:
        secondi = None if limite is None else max(0.0, limite - time.monotonic())
        esito, _ = richiesta_al_programma("invia", (self, messaggio, secondi), fermato)
        if esito == "chiuso":
            raise P.CanaleChiuso()
        if esito == "scaduto":
            raise P.TempoScaduto()

    def prendi_dato(self, fermato: Callable[[], bool], limite: float | None = None) -> Any:
        secondi = None if limite is None else max(0.0, limite - time.monotonic())
        esito, valore = richiesta_al_programma("ricevi", (self, secondi), fermato)
        if esito == "chiuso":
            raise P.CanaleChiuso()
        if esito == "scaduto":
            raise P.TempoScaduto()
        return valore

    def prova_a_prendere(self) -> tuple[bool, Any]:
        try:
            return True, self.prendi_dato(_fermato_qui, time.monotonic())
        except P.TempoScaduto:
            return False, False
        except P.CanaleChiuso:
            return False, True

    def chiudi(self) -> bool:
        return bool(richiesta_al_programma("chiudi", self, _fermato_qui)[1])


TIPI_REMOTI["canale"] = CanaleRemoto


def seleziona_remoto(canali: list, fermato: Callable[[], bool], limite: float | None) -> tuple[int, Any]:
    """``ricevi_dal_primo`` su canali del programma principale, da un lavoratore."""
    secondi = None if limite is None else max(0.0, limite - time.monotonic())
    esito, valore = richiesta_al_programma("seleziona", (list(canali), secondi), fermato)
    if esito == "chiuso":
        raise P.CanaleChiuso()
    if esito == "scaduto":
        raise P.TempoScaduto()
    return valore[0], valore[1]


def _fermato_qui() -> bool:
    interprete = P.interprete_del_filo()
    return bool(interprete is not None and interprete.fermato)


_RICHIESTE: dict[int, list] = {}
_NUMERI_RICHIESTE = itertools.count(1)


def richiesta_al_programma(operazione: str, argomenti: Any, fermato: Callable[[], bool]) -> tuple[str, Any]:
    """Nel lavoratore: chiede al programma principale un'operazione su un canale e ne aspetta l'esito."""
    collegamento = _LAVORATORE["collegamento"]
    if collegamento is None:
        raise ErroreValore("Questo canale appartiene a un altro processo.")
    numero = next(_NUMERI_RICHIESTE)
    attesa: list = [threading.Event(), None, None]
    try:
        dati = impacchetta(argomenti)[0]
    except NonTrasportabile as e:
        raise ErroreValore(f"Questo valore non può passare nel canale: {e}.",
                           suggerimento="Nei canali manda numeri, testi, liste e dizionari.") from None
    _RICHIESTE[numero] = attesa
    try:
        _invia_al_programma(("richiesta", numero, operazione, dati))
        while not attesa[0].wait(P.PASSO_ATTESA):
            if fermato():
                _invia_al_programma(("lascia", numero))
                raise SegnaleFermaProgramma()
    finally:
        _RICHIESTE.pop(numero, None)
    esito, carico = attesa[1], attesa[2]
    predefinito = _LAVORATORE["predefinito"]
    if esito == "errore":
        raise _errore_da_dati(carico, predefinito)
    return esito, spacchetta(carico, predefinito, collegamento)


def _invia_al_programma(messaggio: tuple) -> None:
    with _LAVORATORE["invio"]:
        _LAVORATORE["collegamento"].send(messaggio)


def servizio_lavoratore(argomenti: list[str]) -> int:
    """Corpo di un processo lavoratore: si collega al programma ed esegue i lavori che riceve."""
    import signal
    from multiprocessing.connection import Client

    os.environ[VARIABILE_LAVORATORE] = "1"
    try:
        signal.signal(signal.SIGINT, signal.SIG_IGN)     # Ctrl+C lo gestisce il programma principale
    except (ValueError, OSError, AttributeError):
        pass
    indirizzo = os.environ.pop(_VARIABILE_INDIRIZZO, "")
    famiglia = os.environ.pop(_VARIABILE_FAMIGLIA, "AF_UNIX")
    chiave = bytes.fromhex(os.environ.pop(_VARIABILE_CHIAVE, ""))
    gettone = os.environ.pop(_VARIABILE_GETTONE, "")
    if sys.stdout is None:
        sys.stdout = open(os.devnull, "w", encoding="utf-8")  # noqa: SIM115
    if sys.stderr is None:
        sys.stderr = open(os.devnull, "w", encoding="utf-8")  # noqa: SIM115
    collegamento = Client(indirizzo, family=famiglia, authkey=chiave)
    from . import interprete as _interprete  # noqa: F401 - registra anche `aspetta` (leo.potenza)
    from . import registro
    from .registro import crea_ambiente_predefinito

    registro.carica_libreria()
    predefinito = crea_ambiente_predefinito()
    _LAVORATORE.update(collegamento=collegamento, invio=threading.Lock(), predefinito=predefinito)
    in_corso: dict[int, dict] = {}

    def manda(messaggio: tuple) -> None:
        try:
            _invia_al_programma(messaggio)
        except (OSError, EOFError, ValueError):
            os._exit(0)                    # il programma non c'e' piu'

    def battiti() -> None:
        """Ogni tanto dice al programma quanto processore usa (per capire chi sta solo aspettando)."""
        prima_cpu, prima = time.process_time(), time.monotonic()
        while True:
            time.sleep(0.1)
            cpu, adesso = time.process_time(), time.monotonic()
            if in_corso:
                manda(("battito", round((cpu - prima_cpu) / max(1e-6, adesso - prima), 3)))
            prima_cpu, prima = cpu, adesso

    threading.Thread(target=battiti, name="leo-battiti", daemon=True).start()
    manda(("ciao", gettone, os.getpid()))
    while True:
        try:
            if not collegamento.poll(RIPOSO_LAVORATORE):
                if in_corso:
                    continue
                break                      # libero da troppo tempo: si chiude (il programma ne avvia un altro)
            messaggio = collegamento.recv()
        except (EOFError, OSError):
            break
        genere = messaggio[0]
        if genere == "esegui":
            numero, dati = messaggio[1], messaggio[2]
            stato: dict[str, Any] = {"interprete": None, "annullato": False}
            in_corso[numero] = stato

            def corpo(n: int = numero, d: bytes = dati, s: dict = stato) -> None:
                try:
                    esegui_pacchetto(n, d, s, predefinito, collegamento, manda)
                finally:
                    in_corso.pop(n, None)

            P.in_un_filo(corpo)
        elif genere == "annulla":
            stato = in_corso.get(messaggio[1])
            if stato is not None:
                stato["annullato"] = True
                if stato["interprete"] is not None:
                    stato["interprete"].ferma()
        elif genere == "risposta":
            attesa = _RICHIESTE.get(messaggio[1])
            if attesa is not None:
                attesa[1], attesa[2] = messaggio[2], messaggio[3]
                attesa[0].set()
        elif genere == "esci":
            break
    try:
        sys.stdout.flush()
    except Exception:  # noqa: BLE001
        pass
    os._exit(0)


def esegui_pacchetto(numero: int, dati: bytes, stato: dict, predefinito: Ambiente, collegamento: Any,
                     manda: Callable[[tuple], None]) -> None:
    """Esegue un pacchetto (in un lavoratore, o in un filo del programma se ``collegamento`` e'
    None) e manda ``("stampa", numero, testo)`` e alla fine ``("fine", numero, esito, dati)``."""
    try:
        pacchetto = spacchetta(dati, predefinito, collegamento)
    except Exception as e:  # noqa: BLE001
        manda(("fine", numero, "errore", _errore_in_dati(ErroreValore(
            f"Errore interno di Leo: il lavoro non si legge ({e})."))))
        return
    if collegamento is not None:
        try:
            os.chdir(pacchetto["cartella"])
        except (OSError, KeyError, TypeError):
            pass
    interprete = P.crea_interprete_lavoro(
        predefinito=predefinito, globale=pacchetto["globale"],
        uscita=lambda testo: manda(("stampa", numero, testo)),
        nome_file=pacchetto["nome_file"], dichiarazione_implicita=pacchetto["dichiarazione_implicita"],
        profondita_massima=pacchetto["profondita_massima"], con_grafica=pacchetto["con_grafica"],
        tollerante=pacchetto["tollerante"], percorsi_moduli=pacchetto["percorsi_moduli"],
        file_corrente=pacchetto["file_corrente"])
    interprete.sorgenti_moduli = pacchetto.get("sorgenti_moduli") or {}
    stato["interprete"] = interprete
    if stato["annullato"]:
        interprete.ferma()
    f = pacchetto["funzione"]
    chiamate = pacchetto["chiamate"]
    try:
        if interprete.fermato:
            raise SegnaleFermaProgramma()
        if chiamate is None:
            risultato = P.esegui_nel_filo(interprete, f, [])
            if interprete.fermato and stato["annullato"]:
                raise SegnaleFermaProgramma()
        else:
            risultato = []
            for indice, argomenti in chiamate:
                try:
                    risultato.append((indice, True, P.esegui_nel_filo(interprete, f, list(argomenti))))
                except ErroreDante as e:
                    if interprete.fermato:
                        raise SegnaleFermaProgramma() from None
                    risultato.append((indice, False, e))
                    break
        try:
            carico = impacchetta(risultato)[0]
        except NonTrasportabile as e:
            raise ErroreValore(
                f"Il lavoro ha restituito un valore che non può tornare al programma principale ({e}).",
                suggerimento="Restituisci numeri, testi, liste, dizionari o funzioni.") from None
        manda(("fine", numero, "ok", carico))
    except SegnaleFermaProgramma:
        manda(("fine", numero, "annullato", b""))
    except ErroreDante as e:
        if interprete.fermato and stato["annullato"]:
            manda(("fine", numero, "annullato", b""))
        else:
            manda(("fine", numero, "errore", _errore_in_dati(e)))
    except Exception as e:  # noqa: BLE001
        manda(("fine", numero, "errore", _errore_in_dati(
            ErroreValore(f"Errore interno di Leo nel lavoro `in parallelo`: {e}"))))
