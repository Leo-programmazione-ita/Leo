"""Validazione centrale dei suggerimenti con codice (decisioni sul linguaggio, §6).

> Il CORRETTORE non propone né applica MAI una riga che non passa il parser.

Questo modulo è l'UNICO punto che decide se uno snippet di codice proposto è
valido. Tutti i generatori di proposte con codice (la riga corretta di
:mod:`leo.errori_umani`, gli avvisi di :mod:`leo.avvisi`, l'autocorrezione di
:mod:`leo.correzioni`, "Leo scrive con te" di :mod:`leo.lettura_righe`) passano
di qui prima di mostrare una riga: una proposta che non supera lexer + parser
viene scartata (si ripiega su un messaggio esplicativo senza codice).

Due livelli di controllo, entrambi "in silenzio" (gli errori sono catturati e
non arrivano mai all'utente, riusando il parser già esistente):

* :func:`riga_valida` - lo snippet, da solo, è una riga di Leo sintatticamente
  valida? Prova alcune incorniciature minime (blocco aperto da chiudere con
  ``fine``, un ramo ``altrimenti``/``caso``, ``restituisci`` dentro una
  funzione...), così accetta anche le righe che hanno senso solo dentro un
  blocco (``fine``, ``altrimenti``, ``caso 6..9 allora``).
* :func:`suggerimento_valido` - la proposta, messa al posto della riga ``numero``
  del programma ``sorgente``, lascia il programma analizzabile (controllo "nel
  contesto", delega a :func:`leo.forme_parlate.proposta_sicura`). Senza contesto
  ricade su :func:`riga_valida`.

API::

    programma_valido(sorgente, **opzioni) -> bool
    riga_valida(testo) -> bool
    suggerimento_valido(testo, *, sorgente=None, numero=None, opzioni=None) -> bool
    codice_proposto(messaggio) -> str | None
"""

from __future__ import annotations

import re
from typing import Any

__all__ = [
    "programma_valido",
    "riga_valida",
    "suggerimento_valido",
    "codice_proposto",
]

_NL = "\n"


def _analizza_ok(sorgente: str, opzioni: dict | None = None) -> bool:
    """True se ``sorgente`` supera lexer + parser di Leo (errori catturati)."""
    try:
        from .esecuzione import analizza
    except Exception:  # noqa: BLE001 - senza parser non possiamo garantire nulla
        return False
    try:
        analizza(sorgente, "<correttore_sicuro>", **(opzioni or {}))
        return True
    except Exception:  # noqa: BLE001 - qualunque errore = non valido
        return False


def programma_valido(sorgente: str, **opzioni: Any) -> bool:
    """True se l'intero ``sorgente`` si analizza senza errori."""
    if sorgente is None:
        return False
    return _analizza_ok(sorgente, opzioni or None)


def _incorniciature(corpo: str) -> list[str]:
    """Le prove per capire se ``corpo`` è una riga di Leo valida in qualche contesto.

    Una riga proposta può essere valida solo dentro un blocco (``fine`` chiude,
    ``altrimenti`` e ``caso`` sono rami, ``restituisci`` sta in una funzione,
    ``interrompi``/``continua`` in un ciclo): per questo non basta analizzarla
    da sola, la si prova anche dentro la cornice minima che la rende lecita.
    """
    c = corpo.strip()
    # `altrimenti se ... allora` da solo non è una riga: diventa `se ... allora`
    c1 = c[len("altrimenti "):] if c.startswith("altrimenti se ") else c
    return [
        c,
        c + _NL + "fine",
        # il corpo CHIUDE un blocco aperto sopra (`fine`, `fine scegli`)
        "se vero allora" + _NL + "    stampa(1)" + _NL + c,
        # il corpo è un ramo in mezzo a un blocco (`altrimenti`, `altrimenti se`)
        "se vero allora" + _NL + "    stampa(1)" + _NL + c + _NL + "    stampa(1)" + _NL + "fine",
        # rami e chiusura di `scegli` (`caso 1 allora`, `fine scegli`)
        "scegli 1" + _NL + "    caso 0 allora" + _NL + "        stampa(1)" + _NL + "    " + c,
        "scegli 1" + _NL + "    caso 0 allora" + _NL + "        stampa(1)" + _NL + "    " + c
        + _NL + "        stampa(1)" + _NL + "fine",
        # `restituisci ...` dentro una funzione
        "funzione f()" + _NL + "    " + c + _NL + "fine",
        # `interrompi` / `continua` dentro un ciclo
        "mentre vero fai" + _NL + "    " + c + _NL + "fine",
        c1,
        c1 + _NL + "fine",
    ]


def riga_valida(testo: str) -> bool:
    """True se ``testo`` è una riga/snippet di Leo che supera lexer + parser.

    Prova alcune incorniciature minime (vedi :func:`_incorniciature`), così
    accetta anche le righe lecite solo dentro un blocco. Una riga vuota o di solo
    spazio è valida (non è codice da scartare). Multiriga: ogni riga deve essere
    valida *insieme* (si prova il blocco intero).

    >>> riga_valida("stampa(3 + 4)")
    True
    >>> riga_valida("stampa(3 più 4)")
    False
    >>> riga_valida("fine")
    True
    """
    if testo is None:
        return False
    if not testo.strip():
        return True
    if _NL in testo:
        # snippet su più righe: deve stare in piedi da solo o appena chiuso
        return _analizza_ok(testo) or _analizza_ok(testo + _NL + "fine")
    return any(_analizza_ok(prova) for prova in _incorniciature(testo))


def suggerimento_valido(testo: str, *, sorgente: str | None = None,
                        numero: int | None = None, opzioni: dict | None = None,
                        errore: Any = None) -> bool:
    """True se la proposta ``testo`` si può mostrare all'utente.

    Con ``sorgente`` e ``numero`` fa il controllo "nel contesto" (la riga
    ``numero`` sostituita da ``testo`` lascia il programma analizzabile), che è
    quello corretto per le righe di blocco (``fine``, ``altrimenti``, ``caso``);
    ``errore`` (l'errore già avvenuto) permette di accettare una riga giusta a
    cui manca solo un ``fine`` più in basso. Senza contesto ricade sul controllo
    isolato :func:`riga_valida`.
    """
    if testo is None:
        return False
    if sorgente is not None and numero is not None:
        try:
            from .forme_parlate import proposta_sicura

            return bool(proposta_sicura(sorgente, numero, testo, errore=errore, opzioni=opzioni))
        except Exception:  # noqa: BLE001
            return False
    return riga_valida(testo)


#: "...: `codice`." oppure "Scrivi `codice`." — la riga applicabile in fondo a un messaggio.
_CODICE_FINALE = re.compile(r"(?:[Ss]crivi|:)\s*`([^`]+)`\s*\.?\s*$")


def codice_proposto(messaggio: str | None) -> str | None:
    """Il codice applicabile citato in fondo a un messaggio/suggerimento, o None.

    Serve a controllare che anche la riga mostrata dentro un suggerimento
    testuale (``"... `ripeti 5 volte`."``) sia valida. Niente backtick in fondo
    con la forma giusta -> None (il messaggio non contiene una riga da scrivere).
    """
    if not messaggio:
        return None
    m = _CODICE_FINALE.search(messaggio.strip())
    if not m:
        return None
    codice = m.group(1).strip()
    # i `...` segnano un pezzo da completare (``variabile nome = ...``): non è una
    # riga da scrivere così com'è, quindi non la si tratta come proposta applicabile
    if "..." in codice:
        return None
    return codice
