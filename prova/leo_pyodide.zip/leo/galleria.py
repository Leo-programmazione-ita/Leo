"""Galleria delle risorse di Leo: personaggi, nemici, oggetti, piastrelle, sfondi, suoni, musiche...

Un elemento si indica con un percorso ``galleria:categoria/nome`` (per esempio
``galleria:personaggi/cavaliere`` o ``galleria:suoni/moneta``); con un terzo pezzo si sceglie
un'animazione (``galleria:personaggi/cavaliere/cammina``: il suo primo fotogramma; tutti con
:func:`fotogrammi`). Questo modulo è il **risolutore unico**: trasforma il percorso nel file vero,
estraendo il pacchetto se serve. Lo usano la libreria (``suona``, ``galleria.file``...), il motore
delle finestre del telefono e del PC, il disegnatore del telefono, Leo Studio, ``leo compila`` e
``leo compila --apk`` (che copiano nel programma solo gli elementi usati).

Dove stanno i file (``dati/galleria``, vedi docs/GALLERIA.md):

    indice.json                 gli elementi della parte base (categoria, sottocategoria, nome,
                                titolo, file, animazioni, licenza, autore, fonte, pacchetto)
    aperti/<file>               gli elementi "aperti", pronti subito
    pacchetti/<nome>.zip        gli altri, compressi per tema, con il manifesto dentro
    miniature/<nome>.json       le miniature degli elementi di ogni pacchetto (si vedono subito)
    risorse_extra.json          l'indice della parte extra (versione 2, formato in
                                docs/RISORSE_ELENCO.md): un file per elemento sulle Release di GitHub
                                del repository Leo-programmazione-ita/leo, con peso e impronta SHA-256
    _miniature_extra/...        le miniature degli extra (la galleria li mostra e li cerca senza rete)

Un pacchetto compresso si estrae al primo uso nella cartella dell'utente
(``cartella_utente()/galleria/pacchetti/<nome>``; sul telefono: nella cartella dei dati dell'app,
leggendo il file dagli asset dell'APK). Un elemento extra ("nuvola") si scarica **da solo**, solo dopo
la conferma dell'utente (nella galleria: nome e peso), si verifica (byte e SHA-256 dell'indice) e
resta sul dispositivo in ``cartella_utente()/galleria/extra/<percorso>``. "Scarica tutto il
pacchetto" scarica gli elementi del pacchetto uno per uno.

I programmi creati (``.exe`` e app Android) hanno i loro elementi in ``galleria/`` accanto al
programma, con un ``galleria/indice.json`` ridotto e ``galleria/CREDITI.txt``: il risolutore guarda
prima lì (cartella del progetto, cartella di lavoro, ``LEO_GALLERIA_LOCALE``).
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import shutil
import threading
import time
import unicodedata
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable

from . import variabile_ambiente

PREFISSO = "galleria:"
FORMATO = 1
#: Cartella degli elementi in un programma creato (accanto al programma).
CARTELLA_LOCALE = "galleria"
#: Repository GitHub delle Release con la parte extra, nome e versione del suo indice.
REPO = "Leo-programmazione-ita/leo"
INDIRIZZO_RELEASE = f"https://github.com/{REPO}/releases/download/"
INDICE_EXTRA = "risorse_extra.json"
VERSIONE_EXTRA = 2
#: Peso oltre il quale un elemento extra non diventa un data URI per l'anteprima del telefono.
LIMITE_ANTEPRIMA = 12 * 1024 * 1024

#: Le categorie, nell'ordine in cui si mostrano: (nome, titolo).
CATEGORIE: tuple[tuple[str, str], ...] = (
    ("personaggi", "Personaggi"), ("nemici", "Nemici"), ("armi", "Armi"), ("oggetti", "Oggetti"),
    ("piastrelle", "Piastrelle"), ("veicoli", "Veicoli"), ("sfondi", "Sfondi"), ("decorazioni", "Decorazioni"),
    ("pulsanti", "Pulsanti"), ("interfaccia", "Interfaccia di gioco"), ("effetti", "Effetti"),
    ("suoni", "Suoni"), ("musiche", "Musiche"), ("icone", "Icone"), ("caratteri", "Caratteri"),
)
TITOLI_CATEGORIE = dict(CATEGORIE)
#: Altri nomi accettati per le categorie (al singolare, in inglese, quelli dell'elenco delle risorse).
ALIAS_CATEGORIE = {
    "piattaforme": "piastrelle", "piattaforma": "piastrelle", "piastrella": "piastrelle", "tiles": "piastrelle",
    "personaggio": "personaggi", "nemico": "nemici", "arma": "armi", "oggetto": "oggetti", "veicolo": "veicoli",
    "sfondo": "sfondi", "ambienti": "sfondi", "decorazione": "decorazioni", "pulsante": "pulsanti",
    "ui": "interfaccia", "effetto": "effetti", "suono": "suoni", "musica": "musiche", "carattere": "caratteri",
    "font": "caratteri", "icona": "icone",
}


def categoria_vera(nome: str) -> str:
    """Il nome canonico di una categoria (``piattaforme`` -> ``piastrelle``)."""
    n = nome_elemento(nome)
    return ALIAS_CATEGORIE.get(n, n)

ESTENSIONI_IMMAGINE = (".svg", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp")
ESTENSIONI_SUONO = (".wav", ".ogg", ".mp3", ".flac", ".m4a")
ESTENSIONI_CARATTERE = (".ttf", ".otf", ".woff", ".woff2")

TIPI_MIME = {
    ".svg": "image/svg+xml", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
    ".gif": "image/gif", ".webp": "image/webp", ".bmp": "image/bmp", ".wav": "audio/wav", ".ogg": "audio/ogg",
    ".mp3": "audio/mpeg", ".flac": "audio/flac", ".m4a": "audio/mp4", ".ttf": "font/ttf", ".otf": "font/otf",
    ".woff": "font/woff", ".woff2": "font/woff2", ".json": "application/json",
}

#: Riconosce i riferimenti alla galleria nei file di un progetto (codice, maschere, toml).
RE_RIFERIMENTO = re.compile(r"galleria:([A-Za-zÀ-ÿ0-9_\-]+(?:/[A-Za-zÀ-ÿ0-9_\-]+){0,3})")

_BLOCCO = threading.RLock()


# ===========================================================================
# Errori
# ===========================================================================

def _errore(messaggio: str, suggerimento: str | None = None, *, file: bool = False) -> Exception:
    from .errori import ErroreFile, ErroreValore

    return (ErroreFile if file else ErroreValore)(messaggio, suggerimento=suggerimento)


# ===========================================================================
# Nomi: senza accenti, minuscoli, con _ al posto degli spazi
# ===========================================================================

_NON_ALFANUMERICI = re.compile(r"[^a-z0-9]+")
_CIFRE = re.compile(r"\d+")


def semplice(testo: Any) -> str:
    """Testo per confronti e ricerche: minuscolo, senza accenti, spazi singoli."""
    t = str(testo or "")
    if not t.isascii():
        t = unicodedata.normalize("NFKD", t).encode("ascii", "ignore").decode("ascii")
    return " ".join(_NON_ALFANUMERICI.sub(" ", t.lower()).split())


_NOME_GIUSTO = re.compile(r"[a-z0-9]+(?:_[a-z0-9]+)*")


def nome_elemento(testo: Any) -> str:
    """Nome valido per un elemento o una categoria: ``"Moneta d'oro"`` -> ``moneta_d_oro``."""
    if isinstance(testo, str) and _NOME_GIUSTO.fullmatch(testo):
        return testo
    return semplice(testo).replace(" ", "_")


def testo_ricerca(titolo: str, nome: str, categoria: str, parole: Iterable[str], sotto: str = "") -> str:
    """Il testo in cui si cerca un elemento: " parola parola ... " senza accenti né doppioni (il nome con
    gli _ resta anche intero, per riconoscerlo)."""
    altro = semplice(" ".join([nome.replace("_", " "), categoria, *parole]))
    return " " + " ".join(dict.fromkeys(f"{semplice(titolo)} {altro} {sotto} {nome}".split())) + " "


def _naturale(testo: str) -> str:
    """Chiave per l'ordine "naturale": "stella 2" prima di "stella 10" (i numeri con gli zeri davanti)."""
    return _CIFRE.sub(lambda m: m.group().zfill(12), testo)


def e_percorso_galleria(valore: Any) -> bool:
    return isinstance(valore, str) and valore.strip().lower().startswith(PREFISSO)


def separa_fotogramma(percorso: str) -> tuple[str, int]:
    """``galleria:personaggi/cavaliere/cammina/2`` -> (``galleria:personaggi/cavaliere/cammina``, 2);
    senza numero in fondo il fotogramma è 0 (= il primo)."""
    testo = str(percorso or "").strip().rstrip("/")
    testa, _sep, coda = testo.rpartition("/")
    corpo = testa[len(PREFISSO):] if testa.lower().startswith(PREFISSO) else testa
    if coda.isdigit() and corpo.count("/") >= 1:
        return testa, int(coda)
    return testo, 0


def dividi(percorso: str) -> tuple[str, str, str]:
    """``galleria:personaggi/cavaliere/cammina`` -> (``personaggi``, ``cavaliere``, ``cammina``).

    La categoria può mancare (``galleria:cavaliere``): torna "" e si cerca in tutte."""
    testo = str(percorso or "").strip()
    if testo.lower().startswith(PREFISSO):
        testo = testo[len(PREFISSO):]
    parti = [nome_elemento(p) for p in re.split(r"[/\\]+", testo) if p.strip()]
    if not parti:
        return "", "", ""
    if len(parti) == 1:
        return "", parti[0], ""
    if len(parti) == 2:
        if categoria_vera(parti[0]) in TITOLI_CATEGORIE or not _sembra_animazione(parti[1]):
            return categoria_vera(parti[0]), parti[1], ""
        return "", parti[0], parti[1]
    return categoria_vera(parti[0]), parti[1], parti[2]


def _sembra_animazione(nome: str) -> bool:
    return nome in ("fermo", "cammina", "corre", "salta", "attacca", "cade", "vola", "nuota", "gira", "anima")


# ===========================================================================
# Elementi e pacchetti
# ===========================================================================

@dataclass
class Elemento:
    id: str                                    # "categoria/nome"
    categoria: str
    nome: str
    titolo: str
    file: str                                  # percorso relativo (nel pacchetto o in aperti/)
    sottocategoria: str = ""
    tipo: str = "immagine"                     # immagine, animazione, suono, musica, carattere
    animazioni: dict[str, list[str]] = field(default_factory=dict)
    fps: float = 8.0
    larghezza: int = 0
    altezza: int = 0
    durata: float = 0.0
    licenza: str = ""
    autore: str = ""
    fonte: str = ""
    parole: list[str] = field(default_factory=list)
    pacchetto: str = ""                        # "" = aperto
    miniatura: str = ""                        # file della miniatura (aperti) o "" (dal pacchetto)
    onda: list[int] = field(default_factory=list)   # profilo dei suoni (0..100) per la miniatura
    #: Solo per gli elementi extra (risorse_extra.json): url, sha256, byte, percorso, id, tag, asset.
    extra: dict[str, Any] = field(default_factory=dict)
    marchio: str = ""                          # provenienza da mostrare (per esempio "Da Poly Haven")
    cerca: str = ""                            # testo della ricerca già pronto (costruisci.py), vedi testo_ricerca
    peso: int = 0                              # byte del file (extra)

    @property
    def percorso(self) -> str:
        return PREFISSO + self.id

    def tutti_i_file(self) -> list[str]:
        visti: list[str] = []
        for f in [self.file, *[x for l in self.animazioni.values() for x in l]]:
            if f and f not in visti:
                visti.append(f)
        return visti

    def in_dizionario(self) -> dict[str, Any]:
        d: dict[str, Any] = {"id": self.id, "categoria": self.categoria, "nome": self.nome, "titolo": self.titolo,
                             "file": self.file, "tipo": self.tipo}
        for k in ("sottocategoria", "licenza", "autore", "fonte", "pacchetto", "miniatura"):
            if getattr(self, k):
                d[k] = getattr(self, k)
        if self.animazioni:
            d["animazioni"] = self.animazioni
            d["fps"] = self.fps
        for k in ("larghezza", "altezza"):
            if getattr(self, k):
                d[k] = getattr(self, k)
        if self.durata:
            d["durata"] = round(self.durata, 3)
        if self.parole:
            d["parole"] = self.parole
        if self.onda:
            d["onda"] = self.onda
        return d

    @classmethod
    def da_indice(cls, d: dict[str, Any]) -> "Elemento":
        """Lettura veloce di una voce scritta da costruisci.py (nomi già a posto): migliaia di elementi
        si caricano in un attimo anche sul telefono. Le voci di altra provenienza: :meth:`da_dizionario`."""
        ident, file = d["id"], d["file"]
        categoria, _sep, nome = ident.partition("/")
        if not nome or not file or d.get("categoria") != categoria:
            return cls.da_dizionario(d)
        animazioni = d.get("animazioni") or {}
        tipo = d.get("tipo") or ""
        if not tipo:
            estensione = file[file.rfind("."):].lower() if "." in file else ""
            tipo = ("musica" if categoria == "musiche" else "suono") if estensione in ESTENSIONI_SUONO else \
                "carattere" if estensione in ESTENSIONI_CARATTERE else "animazione" if animazioni else "immagine"
        return cls(id=ident, categoria=categoria, nome=nome, titolo=d.get("titolo") or nome, file=file,
                   sottocategoria=d.get("sottocategoria") or "", tipo=tipo, animazioni=animazioni,
                   fps=float(d.get("fps") or 8.0), larghezza=int(d.get("larghezza") or 0),
                   altezza=int(d.get("altezza") or 0), durata=float(d.get("durata") or 0.0),
                   licenza=d.get("licenza") or "", autore=d.get("autore") or "", fonte=d.get("fonte") or "",
                   parole=d.get("parole") or [], pacchetto=d.get("pacchetto") or "", miniatura=d.get("miniatura") or "",
                   onda=d.get("onda") or [], marchio=d.get("marchio") or "", cerca=d.get("cerca") or "")

    @classmethod
    def da_dizionario(cls, d: dict[str, Any]) -> "Elemento":
        """Legge un elemento; accetta anche i nomi alternativi dell'indice dei pacchetti scaricati
        (``nome_italiano``, ``percorso``, ``fotogrammi``...)."""
        categoria = categoria_vera(d.get("categoria") or "oggetti")
        titolo = str(d.get("titolo") or d.get("nome_italiano") or d.get("nome") or "").strip()
        nome = nome_elemento(d.get("nome") or titolo or Path(str(d.get("file") or "x")).stem)
        file = str(d.get("file") or d.get("percorso") or "").replace("\\", "/").strip("/")
        animazioni: dict[str, list[str]] = {}
        grezze = d.get("animazioni") or {}
        if isinstance(grezze, dict):
            for k, v in grezze.items():
                if isinstance(v, dict):
                    v = v.get("fotogrammi") or v.get("file") or []
                if isinstance(v, (list, tuple)) and v:
                    animazioni[nome_elemento(k) or "anima"] = [str(x).replace("\\", "/").strip("/") for x in v]
        elif isinstance(grezze, list) and grezze:
            animazioni["anima"] = [str(x).replace("\\", "/").strip("/") for x in grezze]
        fot = d.get("fotogrammi")
        if isinstance(fot, list) and fot and not animazioni:
            animazioni["anima"] = [str(x).replace("\\", "/").strip("/") for x in fot]
        if not file and animazioni:
            file = next(iter(animazioni.values()))[0]
        estensione = Path(file).suffix.lower()
        tipo = str(d.get("tipo") or "").strip().lower()
        if not tipo:
            if estensione in ESTENSIONI_SUONO:
                tipo = "musica" if categoria == "musiche" else "suono"
            elif estensione in ESTENSIONI_CARATTERE:
                tipo = "carattere"
            elif animazioni:
                tipo = "animazione"
            else:
                tipo = "immagine"
        parole = d.get("parole") or d.get("parole_chiave") or d.get("etichette") or []
        if isinstance(parole, str):
            parole = [p.strip() for p in parole.split(",") if p.strip()]

        def numero(k: str, tipo_n: type = int) -> Any:
            try:
                return tipo_n(d.get(k) or 0)
            except (TypeError, ValueError):
                return tipo_n(0)

        return cls(id=f"{categoria}/{nome}", categoria=categoria, nome=nome, titolo=titolo or nome.replace("_", " "),
                   file=file, sottocategoria=nome_elemento(d.get("sottocategoria") or ""), tipo=tipo,
                   animazioni=animazioni, fps=numero("fps", float) or 8.0, larghezza=numero("larghezza"),
                   altezza=numero("altezza"), durata=numero("durata", float), licenza=str(d.get("licenza") or ""),
                   autore=str(d.get("autore") or ""), fonte=str(d.get("fonte") or d.get("url") or ""),
                   parole=[str(p) for p in parole], pacchetto=str(d.get("pacchetto") or ""),
                   miniatura=str(d.get("miniatura") or ""),
                   onda=[int(x) for x in d.get("onda") or [] if isinstance(x, (int, float))][:64],
                   marchio=str(d.get("marchio") or ""), cerca=str(d.get("cerca") or ""))


@dataclass
class Pacchetto:
    nome: str
    titolo: str
    tipo: str = "compresso"                    # compresso (incluso nell'app) o nuvola (da scaricare)
    file: str = ""                             # pacchetti/<nome>.zip oppure <nome>.zip (nuvola)
    peso: int = 0
    sha256: str = ""
    elementi: list[str] = field(default_factory=list)
    miniature: str = ""                        # miniature/<nome>.json
    # pacchetti extra (risorse_extra.json): provenienza e licenza
    autore: str = ""
    pagina: str = ""
    licenza: str = ""
    licenza_url: str = ""
    licenza_file: str = ""
    marchio: str = ""

    def in_dizionario(self) -> dict[str, Any]:
        d = {"nome": self.nome, "titolo": self.titolo, "tipo": self.tipo, "file": self.file, "peso": self.peso,
             "sha256": self.sha256, "elementi": list(self.elementi), "miniature": self.miniature}
        for k in ("autore", "pagina", "licenza", "licenza_url", "licenza_file", "marchio"):
            if getattr(self, k):
                d[k] = getattr(self, k)
        return d


#: Le licenze dell'indice extra (identificatori SPDX) in parole.
LICENZE_LEGGIBILI = {
    "CC0-1.0": "CC0 1.0 (pubblico dominio)", "OFL-1.1": "SIL Open Font License 1.1", "Apache-2.0": "Apache 2.0",
    "MIT": "MIT", "ISC": "ISC",
}


def licenza_leggibile(licenza: str) -> str:
    return LICENZE_LEGGIBILI.get(str(licenza or "").strip(), str(licenza or ""))


def marchio_di(pacchetto: str, autore: str = "") -> str:
    """La provenienza che la galleria deve mostrare: Poly Haven chiede "Da Poly Haven"."""
    if "polyhaven" in nome_elemento(pacchetto).replace("_", "") or "poly haven" in semplice(autore):
        return "Da Poly Haven"
    return ""


# ===========================================================================
# Sorgenti: una cartella vera (PC) o gli asset dell'APK (telefono)
# ===========================================================================

class SorgenteCartella:
    """I file della galleria in una cartella del disco."""

    def __init__(self, cartella: str | os.PathLike) -> None:
        self.cartella = Path(cartella)

    def __repr__(self) -> str:
        return f"SorgenteCartella({str(self.cartella)!r})"

    def percorso(self, rel: str) -> Path | None:
        p = self.cartella.joinpath(*_parti_sicure(rel))
        return p if p.is_file() else None

    def esiste(self, rel: str) -> bool:
        return self.percorso(rel) is not None

    def leggi(self, rel: str) -> bytes | None:
        p = self.percorso(rel)
        if p is None:
            return None
        try:
            return p.read_bytes()
        except OSError:
            return None

    def copia(self, rel: str, destinazione: Path, impronta: Any = None) -> None:
        p = self.percorso(rel)
        if p is None:
            raise _errore(f"Nella galleria manca il file `{rel}`.", file=True)
        with open(p, "rb") as f, open(destinazione, "wb") as g:
            while True:
                pezzo = f.read(1 << 20)
                if not pezzo:
                    break
                if impronta is not None:
                    impronta.update(pezzo)
                g.write(pezzo)

    def data_modifica(self) -> float:
        try:
            return (self.cartella / "indice.json").stat().st_mtime
        except OSError:
            return 0.0


class SorgenteAsset:
    """I file della galleria negli asset dell'APK (``assets/galleria``), letti con Chaquopy."""

    def __init__(self, prefisso: str = "galleria") -> None:
        self.prefisso = prefisso.strip("/")
        self._am = None

    def __repr__(self) -> str:
        return f"SorgenteAsset({self.prefisso!r})"

    def _asset(self):  # pragma: no cover - solo su Android
        if self._am is None:
            from java import cast, jclass  # type: ignore[import-not-found]

            python = jclass("com.chaquo.python.Python")
            piattaforma = jclass("com.chaquo.python.android.AndroidPlatform")
            self._am = cast(piattaforma, python.getPlatform()).getApplication().getAssets()
        return self._am

    def _pezzi(self, rel: str):  # pragma: no cover - solo su Android
        from java import jarray, jbyte  # type: ignore[import-not-found]

        flusso = self._asset().open(self.prefisso + "/" + "/".join(_parti_sicure(rel)))
        try:
            buf = jarray(jbyte)(1 << 18)
            while True:
                n = flusso.read(buf)
                if n is None or n <= 0:
                    break
                yield bytes(buf)[:n]
        finally:
            flusso.close()

    def percorso(self, rel: str) -> Path | None:
        return None

    def esiste(self, rel: str) -> bool:  # pragma: no cover - solo su Android
        try:
            self._asset().open(self.prefisso + "/" + "/".join(_parti_sicure(rel))).close()
            return True
        except Exception:  # noqa: BLE001
            return False

    def leggi(self, rel: str) -> bytes | None:  # pragma: no cover - solo su Android
        try:
            return b"".join(self._pezzi(rel))
        except Exception:  # noqa: BLE001
            return None

    def copia(self, rel: str, destinazione: Path, impronta: Any = None) -> None:  # pragma: no cover
        try:
            with open(destinazione, "wb") as g:
                for pezzo in self._pezzi(rel):
                    if impronta is not None:
                        impronta.update(pezzo)
                    g.write(pezzo)
        except OSError:
            raise
        except Exception as e:  # noqa: BLE001 - eccezione Java
            raise _errore(f"Nella galleria dell'app manca il file `{rel}` ({e}).", file=True) from None

    def data_modifica(self) -> float:
        return 0.0


def _json(dati: bytes | None) -> Any:
    if not dati:
        return None
    try:
        return json.loads(dati.decode("utf-8-sig"))
    except (ValueError, UnicodeDecodeError):
        return None


def _intero(valore: Any) -> int:
    try:
        return max(0, int(valore or 0))
    except (TypeError, ValueError):
        return 0


def _extra_valido(indice: Any) -> bool:
    return isinstance(indice, dict) and indice.get("versione") == VERSIONE_EXTRA and isinstance(indice.get("elementi"), list)


def unisci_extra(vecchio: dict[str, Any], nuovo: dict[str, Any]) -> dict[str, Any]:
    """Due indici extra in uno: per ogni elemento e pacchetto vince quello di ``nuovo``; gli elementi che
    ``nuovo`` non ha (per esempio quelli originali di Leo dentro la copia interna) restano."""
    if not vecchio:
        return nuovo
    uscita = dict(vecchio)
    uscita.update({k: v for k, v in nuovo.items() if k not in ("pacchetti", "elementi", "release")})
    for chiave in ("pacchetti", "elementi"):
        voci = {str(d.get("id")): d for d in vecchio.get(chiave) or [] if isinstance(d, dict)}
        voci.update({str(d.get("id")): d for d in nuovo.get(chiave) or [] if isinstance(d, dict)})
        uscita[chiave] = list(voci.values())
    release = {str(r.get("tag")): r for r in vecchio.get("release") or [] if isinstance(r, dict)}
    release.update({str(r.get("tag")): r for r in nuovo.get("release") or [] if isinstance(r, dict)})
    uscita["release"] = list(release.values())
    return uscita


def _parti_sicure(rel: str) -> list[str]:
    parti = [p for p in str(rel).replace("\\", "/").split("/") if p not in ("", ".")]
    if not parti or any(p == ".." or ":" in p for p in parti):
        raise _errore(f"`{rel}` non è un percorso valido della galleria.")
    return parti


# ===========================================================================
# La galleria
# ===========================================================================

class Galleria:
    """Una galleria: indice, elementi, pacchetti; estrae e scarica nella cartella dell'utente."""

    def __init__(self, sorgente: Any, cartella_utente: str | os.PathLike | None = None, *,
                 locale: bool = False) -> None:
        self.sorgente = sorgente
        self.locale = locale                   # galleria ridotta di un programma creato (tutto aperto)
        self._utente = Path(cartella_utente) if cartella_utente is not None else None
        self._caricata = -1.0
        self.elementi: dict[str, Elemento] = {}
        self.pacchetti: dict[str, Pacchetto] = {}
        self.titoli_sotto: dict[str, str] = {}
        self.alias: dict[str, str] = {}        # id dell'indice extra ("pacchetto/nome") -> id della galleria
        self.extra_info: dict[str, Any] = {}   # versione, generato, indice_url, repo dell'indice extra
        self._miniature: dict[str, dict[str, str]] = {}
        self._indice_controllato = False
        self._ricerca: dict[str, tuple[str, tuple, tuple[str, ...], int]] | None = None
        self._ultima: tuple[tuple[str, str, str], list[Elemento]] | None = None

    # --- indice -----------------------------------------------------------------
    def carica(self, *, forza: bool = False) -> "Galleria":
        with _BLOCCO:
            modifica = self.sorgente.data_modifica()
            if not forza and self._caricata >= 0 and modifica <= self._caricata:
                return self
            self.elementi, self.pacchetti, self.titoli_sotto = {}, {}, {}
            self._miniature, self.alias, self.extra_info = {}, {}, {}
            self._ricerca, self._ultima = None, None
            indice = _json(self.sorgente.leggi("indice.json"))
            self._leggi_indice(indice if isinstance(indice, dict) else {})
            if not self.locale:
                self._leggi_extra(self.indice_extra())
            self._caricata = max(modifica, 0.0)
            return self

    def indice_extra(self) -> dict[str, Any]:
        """L'indice della parte extra: la copia dentro Leo, oppure quella più recente scaricata
        (``cartella_utente/risorse_extra.json``) unita alla copia (vince la più recente)."""
        interno = _json(self.sorgente.leggi(INDICE_EXTRA))
        interno = interno if _extra_valido(interno) else {}
        try:
            utente = _json((self.cartella_utente / INDICE_EXTRA).read_bytes())
        except OSError:
            utente = None
        if not _extra_valido(utente) or str(utente.get("generato") or "") <= str(interno.get("generato") or ""):
            return interno
        return unisci_extra(interno, utente)

    def _leggi_extra(self, indice: dict[str, Any]) -> None:
        """Aggiunge gli elementi extra (``risorse_extra.json`` versione 2) come elementi "nuvola"."""
        if not indice:
            return
        self.extra_info = {k: indice.get(k) for k in ("versione", "repo", "indice_url", "generato", "totale")}
        for d in indice.get("pacchetti") or []:
            if not isinstance(d, dict) or not d.get("id"):
                continue
            nome = str(d["id"])
            self.pacchetti[nome] = Pacchetto(
                nome=nome, titolo=str(d.get("nome_it") or d.get("nome") or nome), tipo="nuvola",
                peso=_intero(d.get("byte")), autore=str(d.get("autore") or ""), pagina=str(d.get("pagina") or ""),
                licenza=str(d.get("licenza") or ""), licenza_url=str(d.get("licenza_url") or ""),
                licenza_file=str(d.get("licenza_file") or ""), marchio=marchio_di(nome, str(d.get("autore") or "")))
        presi = set(self.elementi)
        self._per_pacchetto: dict[str, tuple[str, str, str]] = {}
        for d in indice.get("elementi") or []:
            if not isinstance(d, dict):
                continue
            try:
                e = self._elemento_extra(d, presi)
            except Exception:  # noqa: BLE001 - un elemento rovinato non ferma la galleria
                continue
            if e is None:
                continue
            presi.add(e.id)
            self.elementi[e.id] = e
            pacchetto, _sep, coda = e.extra["id"].partition("/")
            self.alias[f"{nome_elemento(pacchetto)}/{nome_elemento(coda)}"] = e.id
            p = self.pacchetti.get(e.pacchetto)
            if p is None:
                p = self.pacchetti[e.pacchetto] = Pacchetto(nome=e.pacchetto, titolo=e.pacchetto, tipo="nuvola",
                                                            marchio=e.marchio)
            p.elementi.append(e.id)
        for p in self.pacchetti.values():
            if p.tipo == "nuvola" and not p.peso:
                p.peso = sum(self.elementi[i].peso for i in p.elementi if i in self.elementi)

    def _elemento_extra(self, d: dict[str, Any], presi: set[str]) -> "Elemento | None":
        ident = str(d.get("id") or "")
        url, impronta, percorso = str(d.get("url") or ""), str(d.get("sha256") or "").lower(), str(d.get("percorso") or "")
        if "/" not in ident or not url or not re.fullmatch(r"[0-9a-f]{64}", impronta) or not percorso:
            return None
        _parti_sicure(percorso)                                     # niente percorsi pericolosi
        pacchetto, _sep, coda = ident.partition("/")
        categoria = categoria_vera(d.get("categoria") or "oggetti")
        base = nome_elemento(coda) or "elemento"
        nome = base
        if f"{categoria}/{nome}" in presi:                          # stesso nome in un altro pacchetto
            nome = f"{base}_{nome_elemento(pacchetto)}"
            k = 2
            while f"{categoria}/{nome}" in presi:
                nome, k = f"{base}_{nome_elemento(pacchetto)}_{k}", k + 1
        formato = str(d.get("formato") or Path(percorso).suffix.lstrip(".")).lower()
        tipo = str(d.get("tipo") or "").lower()
        if tipo not in ("immagine", "suono", "musica", "carattere", "icona", "animazione"):
            tipo = "suono" if "." + formato in ESTENSIONI_SUONO else "carattere" if "." + formato in ESTENSIONI_CARATTERE \
                else "immagine"
        if tipo == "icona":
            tipo = "immagine"
        if tipo == "suono" and categoria == "musiche":
            tipo = "musica"
        parole = d.get("parole_chiave") or []
        autore = str(d.get("autore") or "")
        gia = self._per_pacchetto.get(pacchetto)
        if gia is None:                                  # una volta per pacchetto, non per elemento
            info = self.pacchetti.get(pacchetto)
            gia = self._per_pacchetto[pacchetto] = (nome_elemento(pacchetto), marchio_di(pacchetto, autore),
                                                     info.pagina if info is not None else "")
            if info is not None and info.titolo:
                self.titoli_sotto.setdefault(gia[0], info.titolo)
        sotto_pacchetto, marchio, pagina = gia
        e = Elemento(id=f"{categoria}/{nome}", categoria=categoria, nome=nome,
                     titolo=str(d.get("nome") or base.replace("_", " ").capitalize()), file=percorso,
                     sottocategoria=nome_elemento(d["sottocategoria"]) if d.get("sottocategoria") else sotto_pacchetto,
                     tipo=tipo, larghezza=_intero(d.get("larghezza")),
                     altezza=_intero(d.get("altezza")), licenza=licenza_leggibile(d.get("licenza")), autore=autore,
                     parole=[str(x) for x in parole] if isinstance(parole, list) else [],
                     pacchetto=pacchetto, miniatura=str(d.get("miniatura") or ""),
                     extra={"id": ident, "url": url, "sha256": impronta, "byte": _intero(d.get("byte")),
                            "percorso": percorso, "tag": str(d.get("tag") or ""), "asset": str(d.get("asset") or "")},
                     marchio=marchio, peso=_intero(d.get("byte")), fonte=pagina or url)
        if d.get("atmosfera"):
            e.parole.append(str(d["atmosfera"]))
        try:
            e.durata = float(d.get("durata") or 0)
        except (TypeError, ValueError):
            e.durata = 0.0
        onda = d.get("onda")
        if isinstance(onda, list):
            e.onda = [int(x) for x in onda if isinstance(x, (int, float))][:64]
        return e

    def _leggi_indice(self, indice: dict[str, Any]) -> None:
        for nome, p in (indice.get("pacchetti") or {}).items():
            if isinstance(p, dict):
                self.pacchetti[nome] = Pacchetto(
                    nome=nome, titolo=str(p.get("titolo") or nome), tipo=str(p.get("tipo") or "compresso"),
                    file=str(p.get("file") or ""), peso=int(p.get("peso") or 0), sha256=str(p.get("sha256") or ""),
                    elementi=[str(x) for x in p.get("elementi") or []], miniature=str(p.get("miniature") or ""))
        for k, v in (indice.get("sottocategorie") or {}).items():
            self.titoli_sotto[str(k)] = str(v)
        elementi = indice.get("elementi") or []
        veloce = indice.get("formato") == FORMATO
        if isinstance(elementi, dict):
            elementi = list(elementi.values())
        for d in elementi:
            if not isinstance(d, dict):
                continue
            try:
                e = Elemento.da_indice(d) if veloce and "cerca" in d else Elemento.da_dizionario(d)
            except Exception:  # noqa: BLE001 - un elemento rovinato non ferma la galleria
                continue
            if not e.file:
                continue
            if self.locale:
                e.pacchetto = ""
            base, k = e.id, 2
            while e.id in self.elementi:          # nomi doppi nella stessa categoria: cavaliere_2...
                e.nome = f"{base.split('/', 1)[1]}_{k}"
                e.id = f"{e.categoria}/{e.nome}"
                k += 1
            self.elementi[e.id] = e
            origine = str(d.get("origine") or "")
            if "/" in origine:
                pacchetto, _sep, coda = origine.partition("/")
                self.alias.setdefault(f"{nome_elemento(pacchetto)}/{nome_elemento(coda)}", e.id)

    # --- cartella dell'utente -------------------------------------------------------
    @property
    def cartella_utente(self) -> Path:
        if self._utente is None:
            from .percorsi import cartella_utente

            self._utente = cartella_utente() / "galleria"
        return self._utente

    def cartella_pacchetto(self, nome: str) -> Path:
        return self.cartella_utente / "pacchetti" / nome_elemento(nome)

    # --- ricerca --------------------------------------------------------------------
    def trova(self, percorso: str) -> tuple[Elemento, str]:
        """L'elemento del percorso (e l'animazione chiesta, "" = nessuna); errore chiaro se non c'è."""
        self.carica()
        categoria, nome, animazione = dividi(separa_fotogramma(percorso)[0])
        if not nome:
            raise _errore(f"`{percorso}` non indica un elemento della galleria.",
                          "Scrivi per esempio \"galleria:personaggi/cavaliere\".")
        e = self.elementi.get(f"{categoria}/{nome}") if categoria else None
        if e is None and categoria and f"{categoria}/{nome}" in self.alias:     # "pacchetto/nome" dell'indice extra
            e = self.elementi.get(self.alias[f"{categoria}/{nome}"])
        if e is None:
            candidati = [x for x in self.elementi.values()
                         if x.nome == nome and (not categoria or x.categoria == categoria)]
            if not candidati and categoria:
                # "galleria:personaggio/cavaliere": categoria al singolare o scritta diversa
                candidati = [x for x in self.elementi.values() if x.nome == nome
                             and (x.categoria.startswith(categoria[:5]) or categoria.startswith(x.categoria[:5]))]
            if not candidati and not categoria:
                candidati = [x for x in self.elementi.values() if nome_elemento(x.titolo) == nome]
            if len(candidati) == 1 or (candidati and not categoria):
                e = candidati[0]
        if e is None:
            vicini = self.simili(nome, categoria)
            consiglio = ("Forse cercavi " + ", ".join(f"`galleria:{v}`" for v in vicini) + "?") if vicini else \
                "Apri la Galleria per vedere i nomi degli elementi."
            raise _errore(f"Nella galleria non c'è `{percorso.strip()}`.", consiglio, file=True)
        if animazione and animazione not in e.animazioni:
            elenco = ", ".join(f"`{a}`" for a in e.animazioni) or "nessuna"
            raise _errore(f"`{e.titolo}` non ha l'animazione `{animazione}` (animazioni: {elenco}).")
        return e, animazione

    def simili(self, nome: str, categoria: str = "", quanti: int = 3) -> list[str]:
        import difflib

        ids = [x.id for x in self.elementi.values() if not categoria or x.categoria == categoria] or list(self.elementi)
        nomi = {i.split("/", 1)[1]: i for i in ids}
        return [nomi[n] for n in difflib.get_close_matches(nome, list(nomi), n=quanti, cutoff=0.6)]

    def _dati_ricerca(self) -> dict[str, tuple[str, str, str, int]]:
        """Per ogni elemento, calcolati una volta: titolo semplice, chiave dell'ordine naturale, le parole
        in cui cercare in un solo testo " parola parola ..." (titolo, nome, sottocategoria, categoria,
        parole chiave: "inizia con" diventa un `in` veloce) e posto della categoria."""
        with _BLOCCO:
            return self._dati_ricerca_bloccato()

    def _dati_ricerca_bloccato(self) -> dict[str, tuple[str, str, str, int]]:
        if self._ricerca is None:
            ordine_cat = {c: k for k, (c, _t) in enumerate(CATEGORIE)}
            titoli_cat = {c: t for c, t in CATEGORIE}
            sotto_titoli: dict[str, str] = {}
            dati: dict[str, tuple[str, str, str, int]] = {}
            for e in self.elementi.values():
                testo = e.cerca
                if not testo or e.nome not in testo:      # non c'è (o il nome è cambiato): si calcola
                    st = sotto_titoli.get(e.sottocategoria)
                    if st is None:
                        st = sotto_titoli[e.sottocategoria] = semplice(
                            " ".join([e.sottocategoria, self.titoli_sotto.get(e.sottocategoria, "")]))
                    testo = testo_ricerca(e.titolo, e.nome, titoli_cat.get(e.categoria, e.categoria), e.parole, st)
                dati[e.id] = ("", _naturale(e.titolo.lower()), testo, ordine_cat.get(e.categoria, 99))
            self._ricerca = dati
        return self._ricerca

    def elenca(self, categoria: str = "", sottocategoria: str = "", testo: str = "") -> list[Elemento]:
        """Elementi di una categoria (e sottocategoria), filtrati dal testo cercato, in ordine.

        Ogni parola cercata deve essere l'inizio di una parola del titolo, delle parole chiave o della
        categoria (senza accenti; "monete" trova anche "moneta", "draghi" anche "drago"); se così non
        si trova niente, basta che compaia in mezzo a una parola. Veloce anche con decine di migliaia di
        elementi: i dati della ricerca si calcolano una volta e l'ultima ricerca resta pronta (pagine)."""
        self.carica()
        cat, sotto = categoria_vera(categoria) if categoria else "", nome_elemento(sottocategoria)
        cercato = semplice(testo)
        chiave = (cat, sotto, cercato)
        if self._ultima is not None and self._ultima[0] == chiave:
            return self._ultima[1]
        dati = self._dati_ricerca()
        parole = cercato.split()

        def radice(q: str) -> str:              # "monete" -> "monet", "draghi" -> "drag"
            r = q.rstrip("aeiou") if len(q) >= 4 else q
            return r[:-1] if len(r) >= 4 and r.endswith(("gh", "ch")) else r

        inizi = [(q, radice(q) if len(q) >= 4 else q) for q in parole]
        candidati = [e for e in self.elementi.values()
                     if (not cat or e.categoria == cat) and (not sotto or e.sottocategoria == sotto)]

        cerca_inizi = [" " + r for _q, r in inizi]

        def scegli(dentro: bool) -> list[tuple[int, int, str, Elemento]]:
            uscita = []
            for e in candidati:
                _t, naturale, testo_e, posto = dati[e.id]
                punti = 0
                if parole:
                    if dentro:
                        if not all(q in testo_e for q in parole):
                            continue
                    elif not all(r in testo_e for r in cerca_inizi):
                        continue
                    titolo = semplice(e.titolo)
                    punti = 0 if titolo == cercato else 1 if titolo.startswith(cercato) else \
                        2 if cerca_inizi[0] in " " + titolo else 3
                uscita.append((punti, posto, naturale, e))
            return uscita

        risultato = scegli(False)
        if parole and not risultato and min(len(q) for q in parole) >= 5:
            risultato = scegli(True)
        risultato.sort(key=lambda x: x[:3])
        elenco = [x[3] for x in risultato]
        self._ultima = (chiave, elenco)
        return elenco

    def categorie(self) -> list[dict[str, Any]]:
        """Categorie con le sottocategorie e quanti elementi hanno (anche le categorie vuote)."""
        self.carica()
        conta: dict[str, dict[str, int]] = {}
        for e in self.elementi.values():
            conta.setdefault(e.categoria, {})
            conta[e.categoria][e.sottocategoria] = conta[e.categoria].get(e.sottocategoria, 0) + 1
        nomi = [c for c, _t in CATEGORIE] + sorted(c for c in conta if c not in TITOLI_CATEGORIE)
        uscita = []
        for c in nomi:
            sotto = conta.get(c, {})
            uscita.append({
                "nome": c, "titolo": TITOLI_CATEGORIE.get(c, c.replace("_", " ").capitalize()),
                "quanti": sum(sotto.values()),
                "sotto": [{"nome": s, "titolo": self.titoli_sotto.get(s) or s.replace("_", " ").capitalize(),
                           "quanti": n} for s, n in sorted(sotto.items()) if s],
            })
        return uscita

    # --- stato e file --------------------------------------------------------------
    def stato(self, e: Elemento) -> str:
        """``aperto`` (pronto nella galleria), ``compresso`` (nel pacchetto, da estrarre), ``pronto``
        (pacchetto già estratto), ``nuvola`` (extra da scaricare) o ``scaricato`` (extra già scaricato)."""
        if e.extra:
            return "scaricato" if self.scaricato(e) else "nuvola"
        if not e.pacchetto:
            return "aperto"
        return "pronto" if self.pacchetto_pronto(e.pacchetto) else "compresso"

    def file_extra(self, e: Elemento) -> Path:
        """Dove sta (o starà) il file di un elemento extra: ``cartella_utente/extra/<percorso>``."""
        return self.cartella_utente.joinpath("extra", *_parti_sicure(e.extra["percorso"]))

    def scaricato(self, e: Elemento) -> bool:
        """Vero se il file dell'elemento extra c'è già con il peso giusto (l'impronta si controlla
        quando arriva)."""
        try:
            return self.file_extra(e).stat().st_size == e.extra["byte"] or not e.extra["byte"]
        except OSError:
            return False

    def pacchetto_pronto(self, nome: str) -> bool:
        """Pacchetto compresso già estratto, o pacchetto extra con tutti gli elementi scaricati."""
        p = self.pacchetti.get(nome)
        if p is not None and p.tipo == "nuvola":
            elementi = [self.elementi[i] for i in p.elementi if i in self.elementi]
            return bool(elementi) and all(self.scaricato(e) for e in elementi)
        segno = self.cartella_pacchetto(nome) / ".pronto"
        try:
            scritto = segno.read_text(encoding="utf-8").strip()
        except OSError:
            return False
        return p is None or not p.sha256 or scritto == p.sha256

    def file_di(self, e: Elemento, rel: str | None = None, *, estrai: bool = True) -> Path:
        """Il file vero di un elemento (``rel`` = uno dei suoi file; None = quello principale)."""
        rel = rel or e.file
        if e.extra:
            if self.scaricato(e):
                return self.file_extra(e)
            raise _errore(f"`{e.titolo}` (galleria:{e.id}) è un elemento extra non ancora scaricato.",
                          f"Apri la Galleria e toccalo: Leo chiede se scaricarlo ({formatta_peso(e.peso)}), poi "
                          "resta sul dispositivo e funziona anche senza Internet.", file=True)
        if not e.pacchetto:
            p = self.sorgente.percorso(("" if self.locale else "aperti/") + rel)
            if p is not None:
                return p
            # telefono: dagli asset alla cartella dei dati, una volta sola
            arrivo = self.cartella_utente.joinpath("aperti", *_parti_sicure(rel))
            if not arrivo.is_file():
                with _BLOCCO:
                    if not arrivo.is_file():
                        arrivo.parent.mkdir(parents=True, exist_ok=True)
                        temporaneo = arrivo.with_name(arrivo.name + ".tmp")
                        self.sorgente.copia(("" if self.locale else "aperti/") + rel, temporaneo)
                        os.replace(temporaneo, arrivo)
            return arrivo
        stato = self.stato(e)
        if stato == "compresso":
            if not estrai:
                raise _errore(f"`{e.titolo}` è ancora compresso nel pacchetto `{e.pacchetto}`.", file=True)
            self.estrai(e.pacchetto)
        p = self.cartella_pacchetto(e.pacchetto).joinpath(*_parti_sicure(rel))
        if not p.is_file():
            raise _errore(f"Nel pacchetto `{e.pacchetto}` manca il file `{rel}`.", file=True)
        return p

    def risolvi(self, percorso: str, *, estrai: bool = True) -> Path:
        """Il file di ``galleria:cat/nome`` (principale), ``.../animazione`` (il primo fotogramma) o
        ``.../animazione/N`` (il fotogramma N, da 1)."""
        e, animazione = self.trova(percorso)
        numero = separa_fotogramma(percorso)[1]
        if animazione:
            elenco = e.animazioni[animazione]
            if numero > len(elenco):
                raise _errore(f"L'animazione `{animazione}` di `{e.titolo}` ha {len(elenco)} fotogrammi, non {numero}.")
            return self.file_di(e, elenco[max(1, numero) - 1], estrai=estrai)
        return self.file_di(e, estrai=estrai)

    def fotogrammi(self, percorso: str) -> list[Path]:
        e, animazione = self.trova(percorso)
        if not animazione:
            if not e.animazioni:
                return [self.file_di(e)]
            animazione = next(iter(e.animazioni))
        return [self.file_di(e, f) for f in e.animazioni[animazione]]

    # --- pacchetti compressi ---------------------------------------------------------
    def estrai(self, nome: str) -> Path:
        """Estrae un pacchetto compresso nella cartella dell'utente (una volta sola, mai a metà)."""
        with _BLOCCO:
            self.carica()
            p = self.pacchetti.get(nome)
            if p is None:
                raise _errore(f"Nella galleria non c'è il pacchetto `{nome}`.")
            destinazione = self.cartella_pacchetto(nome)
            if self.pacchetto_pronto(nome):
                return destinazione
            if p.tipo == "nuvola":
                raise _errore(f"Il pacchetto `{nome}` va prima scaricato dalla Galleria.", file=True)
            base = self.cartella_utente / "pacchetti"
            base.mkdir(parents=True, exist_ok=True)
            temporaneo = base / f".{nome}.zip.tmp"
            impronta = hashlib.sha256()
            try:
                self.sorgente.copia(p.file, temporaneo, impronta)
                if p.sha256 and impronta.hexdigest() != p.sha256:
                    raise _errore(f"Il pacchetto `{nome}` è rovinato (impronta diversa): reinstalla Leo.", file=True)
                _estrai_zip(temporaneo, destinazione, p.sha256 or impronta.hexdigest())
            finally:
                try:
                    temporaneo.unlink()
                except OSError:
                    pass
            return destinazione

    def dimentica(self, nome: str) -> None:
        """Toglie dalla cartella dell'utente un pacchetto estratto o gli elementi scaricati di un
        pacchetto extra (si possono riprendere)."""
        with _BLOCCO:
            p = self.pacchetti.get(nome)
            if p is not None and p.tipo == "nuvola":
                for i in p.elementi:
                    e = self.elementi.get(i)
                    if e is not None and e.extra:
                        try:
                            self.file_extra(e).unlink()
                        except OSError:
                            pass
                return
            shutil.rmtree(self.cartella_pacchetto(nome), ignore_errors=True)

    # --- miniature e anteprime -------------------------------------------------------------
    def miniatura(self, e: Elemento) -> str:
        """Data URI della miniatura ("" se non c'è: l'interfaccia mostra l'icona del tipo)."""
        if e.extra:
            dati = self.sorgente.leggi(e.miniatura) if e.miniatura else None
            if not dati and e.tipo == "immagine" and e.peso <= 64 * 1024 and self.scaricato(e):
                rel, dati = e.file, self.file_extra(e).read_bytes()
                return uri_dati(rel, dati)
            return uri_dati(e.miniatura, dati) if dati and len(dati) <= 256 * 1024 else ""
        if not e.pacchetto:
            rel = e.miniatura or (e.file if Path(e.file).suffix.lower() in ESTENSIONI_IMMAGINE else "")
            if not rel:
                return ""
            dati = self.sorgente.leggi(("" if self.locale else "aperti/") + rel)
            return uri_dati(rel, dati) if dati and len(dati) <= 256 * 1024 else ""
        tabella = self._miniature.get(e.pacchetto)
        if tabella is None:
            p = self.pacchetti.get(e.pacchetto)
            tabella = {}
            if p is not None and p.miniature:
                dati = self.sorgente.leggi(p.miniature)
                try:
                    tabella = json.loads(dati.decode("utf-8")) if dati else {}
                except (ValueError, UnicodeDecodeError):
                    tabella = {}
            self._miniature[e.pacchetto] = tabella if isinstance(tabella, dict) else {}
        return str(self._miniature[e.pacchetto].get(e.id, ""))

    def uri(self, e: Elemento, rel: str | None = None, *, limite: int = 12 * 1024 * 1024) -> str:
        p = self.file_di(e, rel)
        if p.stat().st_size > limite:
            return ""
        return uri_dati(p.name, p.read_bytes())

    # --- crediti -------------------------------------------------------------------------
    def crediti(self, ids: Iterable[str] | None = None) -> str:
        """Testo con titolo, autore, licenza e fonte di ogni elemento (tutti se ``ids`` è None)."""
        self.carica()
        scelti = [self.elementi[i] for i in (ids if ids is not None else sorted(self.elementi)) if i in self.elementi]
        righe = ["Crediti delle risorse della galleria di Leo", "=" * 44, ""]
        per_autore: dict[tuple[str, str, str], list[Elemento]] = {}
        for e in scelti:
            per_autore.setdefault((e.autore or "Autore non indicato", e.licenza or "Licenza non indicata",
                                   e.fonte), []).append(e)
        for (autore, licenza, fonte), elementi in sorted(per_autore.items()):
            righe.append(f"{autore} - {licenza}" + (f" - {fonte}" if fonte else ""))
            for e in sorted(elementi, key=lambda x: x.id):
                righe.append(f"  - {e.titolo} (galleria:{e.id})")
            righe.append("")
        return "\n".join(righe).rstrip() + "\n"

    # --- programmi creati: solo gli elementi usati ----------------------------------------
    def copia_elementi(self, ids: Iterable[str], cartella: str | os.PathLike, *,
                       avvisi: list[str] | None = None) -> list[tuple[Path, str]]:
        """Copia gli elementi ``ids`` in ``cartella`` (la ``galleria/`` di un programma creato), con
        un ``indice.json`` ridotto e ``CREDITI.txt``. Restituisce (file, percorso relativo). Un elemento
        che non si può copiare (extra non ancora scaricato...) diventa un avviso."""
        self.carica()
        base = Path(cartella)
        base.mkdir(parents=True, exist_ok=True)
        scritti: list[tuple[Path, str]] = []
        voci = []
        for i in sorted(set(ids)):
            e = self.elementi.get(i)
            if e is None:
                continue
            try:
                coppie = [(self.file_di(e, rel), rel) for rel in e.tutti_i_file()]
            except Exception as ex:  # noqa: BLE001
                if avvisi is not None:
                    avvisi.append(f"`galleria:{e.id}` non entra nel programma: {getattr(ex, 'messaggio', ex)}")
                continue
            for sorgente, rel in coppie:
                arrivo = base.joinpath(*_parti_sicure(rel))
                arrivo.parent.mkdir(parents=True, exist_ok=True)
                if not arrivo.is_file() or arrivo.stat().st_size != sorgente.stat().st_size:
                    shutil.copyfile(sorgente, arrivo)
                scritti.append((arrivo, rel))
            d = e.in_dizionario()
            d.pop("pacchetto", None)
            d.pop("miniatura", None)
            voci.append(d)
        indice = base / "indice.json"
        indice.write_text(json.dumps({"formato": FORMATO, "locale": True, "elementi": voci}, ensure_ascii=False,
                                     indent=1) + "\n", encoding="utf-8")
        crediti = base / "CREDITI.txt"
        crediti.write_text(self.crediti([v["id"] for v in voci]), encoding="utf-8")
        return [*scritti, (indice, "indice.json"), (crediti, "CREDITI.txt")]

    # --- extra: un elemento alla volta dalle Release di GitHub -----------------------------------
    def indirizzo(self, url: str) -> str:
        """L'indirizzo vero di un file extra: quello dell'indice, oppure lo stesso file su uno specchio
        indicato da ``LEO_GALLERIA_URL`` (che sostituisce ``https://github.com/<repo>/releases/download/``)."""
        specchio = variabile_ambiente("GALLERIA_URL")
        if specchio:
            m = re.match(r"^https://github\.com/[^/]+/[^/]+/releases/download/(.+)$", url)
            if m:
                return specchio.rstrip("/") + "/" + m.group(1)
        return url

    def _apri(self, apri: Callable[..., Any] | None) -> Callable[..., Any]:
        if apri is not None:
            return apri
        import urllib.request

        def apri_url(u: str, timeout: float = 30):  # noqa: ANN202
            richiesta = urllib.request.Request(u, headers={"User-Agent": "Leo-galleria/2"})
            return urllib.request.urlopen(richiesta, timeout=timeout)  # noqa: S310 - solo https (controllato)
        return apri_url

    def aggiorna_indice(self, *, apri: Callable[..., Any] | None = None, massimo: int = 32 * 1024 * 1024) -> bool:
        """Scarica ``indice_url`` (piccolo): se è la versione 2 e più recente della copia, lo salva nella
        cartella dell'utente e lo usa (gli indirizzi si prendono sempre dall'indice). Vero se è cambiato.
        Si chiama solo quando l'utente ha già confermato uno scaricamento."""
        self.carica()
        self._indice_controllato = True
        url = str(self.extra_info.get("indice_url") or "")
        if not url:
            return False
        url = self.indirizzo(url)
        _controlla_indirizzo(url)
        try:
            with self._apri(apri)(url, timeout=15) as risposta:
                dati = risposta.read(massimo + 1)
        except Exception:  # noqa: BLE001 - senza indice nuovo si usa la copia
            return False
        nuovo = _json(dati) if len(dati) <= massimo else None
        if not _extra_valido(nuovo) or str(nuovo.get("generato") or "") <= str(self.extra_info.get("generato") or ""):
            return False
        with _BLOCCO:
            self.cartella_utente.mkdir(parents=True, exist_ok=True)
            temporaneo = self.cartella_utente / (INDICE_EXTRA + ".tmp")
            temporaneo.write_bytes(dati)
            os.replace(temporaneo, self.cartella_utente / INDICE_EXTRA)
        self.carica(forza=True)
        self._indice_controllato = True
        return True

    def scarica(self, elemento: str, *, conferma: bool = False, avanzamento: Callable[[int, int], Any] | None = None,
                fermato: Callable[[], bool] | None = None, apri: Callable[..., Any] | None = None,
                aggiorna: bool = True) -> Path:
        """Scarica un elemento extra (``galleria:...``, nome o id dell'indice), controlla byte e SHA-256
        e lo mette in ``cartella_utente/extra/<percorso>``. ``conferma`` deve essere vero: l'utente ha
        visto nome e peso e ha detto sì. ``apri`` sostituisce ``urllib.request.urlopen`` (prove)."""
        if conferma is not True:
            raise _errore("Per scaricare un elemento serve la conferma di chi usa Leo.")
        e, _a = self.trova(elemento)
        if not e.extra:
            return self.file_di(e)
        if aggiorna and not self._indice_controllato:
            if self.aggiorna_indice(apri=apri):
                e, _a = self.trova(elemento)
        return self._scarica_elemento(e, apri=apri, avanzamento=avanzamento, fermato=fermato)

    def _scarica_elemento(self, e: Elemento, *, apri: Callable[..., Any] | None = None,
                          avanzamento: Callable[[int, int], Any] | None = None,
                          fermato: Callable[[], bool] | None = None) -> Path:
        arrivo = self.file_extra(e)
        byte, impronta_attesa = e.extra["byte"], e.extra["sha256"]
        if arrivo.is_file():
            if (not byte or arrivo.stat().st_size == byte) and _impronta_file(arrivo) == impronta_attesa:
                return arrivo                                       # c'è già con la stessa impronta
        url = self.indirizzo(e.extra["url"])
        _controlla_indirizzo(url)
        arrivo.parent.mkdir(parents=True, exist_ok=True)
        parziale = arrivo.with_name(f".{arrivo.name}.{os.getpid()}.{threading.get_ident()}.part")
        impronta = hashlib.sha256()
        fatti = 0
        try:
            try:
                risposta = self._apri(apri)(url, timeout=30)
            except Exception as ex:  # noqa: BLE001
                raise _errore(f"Non riesco a scaricare `{e.titolo}`: {getattr(ex, 'reason', None) or ex}.",
                              "Controlla la connessione a Internet e riprova.", file=True) from None
            with risposta, open(parziale, "wb") as f:
                while True:
                    if fermato is not None and fermato():
                        raise _errore("Scaricamento annullato.")
                    pezzo = risposta.read(1 << 16)
                    if not pezzo:
                        break
                    fatti += len(pezzo)
                    if byte and fatti > byte:
                        raise _errore(f"`{e.titolo}` è più grande di quanto dice l'indice: lo scarto.", file=True)
                    impronta.update(pezzo)
                    f.write(pezzo)
                    if avanzamento is not None:
                        avanzamento(fatti, byte)
            if byte and fatti != byte:
                raise _errore(f"`{e.titolo}` è arrivato incompleto ({fatti} byte su {byte}): lo scarto.",
                              "Riprova: lo scaricamento riparte da capo.", file=True)
            if impronta.hexdigest() != impronta_attesa:
                raise _errore(f"`{e.titolo}` scaricato non corrisponde all'impronta SHA-256 dell'indice: lo scarto.",
                              "Riprova più tardi; se succede ancora, il file sul server è cambiato.", file=True)
            os.replace(parziale, arrivo)
        finally:
            try:
                parziale.unlink()
            except OSError:
                pass
        return arrivo

    def da_scaricare(self, nome: str) -> list[Elemento]:
        """Gli elementi di un pacchetto extra non ancora scaricati (per "scarica tutto il pacchetto")."""
        self.carica()
        p = self.pacchetti.get(nome)
        if p is None or p.tipo != "nuvola":
            raise _errore(f"`{nome}` non è un pacchetto extra della galleria.")
        return [self.elementi[i] for i in p.elementi if i in self.elementi and not self.scaricato(self.elementi[i])]

    def scarica_pacchetto(self, nome: str, *, conferma: bool = False,
                          avanzamento: Callable[[int, int, int, int], Any] | None = None,
                          fermato: Callable[[], bool] | None = None, apri: Callable[..., Any] | None = None) -> int:
        """Scarica, uno per uno, gli elementi di un pacchetto extra che mancano. ``avanzamento(byte fatti,
        byte totali, elementi fatti, elementi totali)``. Restituisce quanti ne ha scaricati."""
        if conferma is not True:
            raise _errore("Per scaricare un pacchetto serve la conferma di chi usa Leo.")
        if not self._indice_controllato:
            self.aggiorna_indice(apri=apri)
        mancanti = self.da_scaricare(nome)
        totale = sum(e.peso for e in mancanti)
        fatti = 0
        for k, e in enumerate(mancanti):
            if fermato is not None and fermato():
                raise _errore("Scaricamento annullato.")
            base = fatti

            def avanza(n: int, _t: int, base: int = base, k: int = k) -> None:
                if avanzamento is not None:
                    avanzamento(base + n, totale, k, len(mancanti))
            self._scarica_elemento(e, apri=apri, avanzamento=avanza, fermato=fermato)
            fatti += e.peso
            if avanzamento is not None:
                avanzamento(fatti, totale, k + 1, len(mancanti))
        return len(mancanti)


def _controlla_indirizzo(url: str) -> None:
    if not url.lower().startswith(("https://", "http://127.0.0.1", "http://localhost")):
        raise _errore("Gli elementi extra si scaricano solo da indirizzi https://.")


def _impronta_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for pezzo in iter(lambda: f.read(1 << 20), b""):
            h.update(pezzo)
    return h.hexdigest()


def _estrai_zip(zip_file: Path, destinazione: Path, segno: str) -> None:
    """Estrae in una cartella temporanea e la mette al suo posto solo alla fine (mai a metà)."""
    temporanea = destinazione.with_name("." + destinazione.name + ".tmp")
    shutil.rmtree(temporanea, ignore_errors=True)
    temporanea.mkdir(parents=True)
    try:
        with zipfile.ZipFile(zip_file) as z:
            for info in z.infolist():
                if info.is_dir():
                    continue
                arrivo = temporanea.joinpath(*_parti_sicure(info.filename))
                arrivo.parent.mkdir(parents=True, exist_ok=True)
                with z.open(info) as sorgente, open(arrivo, "wb") as f:
                    shutil.copyfileobj(sorgente, f, 1 << 20)
        (temporanea / ".pronto").write_text(segno, encoding="utf-8")
        shutil.rmtree(destinazione, ignore_errors=True)
        os.replace(temporanea, destinazione)
    except zipfile.BadZipFile:
        raise _errore(f"Il pacchetto `{destinazione.name}` è rovinato.", file=True) from None
    finally:
        shutil.rmtree(temporanea, ignore_errors=True)


def uri_dati(nome: str, dati: bytes) -> str:
    tipo = TIPI_MIME.get(Path(nome).suffix.lower(), "application/octet-stream")
    return f"data:{tipo};base64,{base64.b64encode(dati).decode('ascii')}"


def formatta_peso(byte: int) -> str:
    if byte < 1024 * 1024:
        return f"{max(1, round(byte / 1024))} KB"
    return f"{byte / (1024 * 1024):.1f} MB".replace(".", ",")


# ===========================================================================
# La galleria di Leo e quelle dei programmi creati
# ===========================================================================

_GALLERIA: Galleria | None = None
_LOCALI: dict[str, tuple[float, Galleria]] = {}


def cartella_galleria() -> Path:
    """``dati/galleria`` (o ``LEO_GALLERIA``)."""
    scelta = variabile_ambiente("GALLERIA")
    if scelta:
        return Path(scelta)
    from .percorsi import cartella_dati

    return cartella_dati() / "galleria"


def galleria() -> Galleria:
    """La galleria di Leo (cartella ``dati/galleria``; sul telefono gli asset dell'APK)."""
    global _GALLERIA
    if _GALLERIA is None:
        cartella = cartella_galleria()
        sorgente: Any = SorgenteCartella(cartella)
        if not (cartella / "indice.json").is_file() and not variabile_ambiente("GALLERIA"):
            try:
                from .piattaforma import e_android

                if e_android():
                    sorgente = SorgenteAsset()
            except Exception:  # noqa: BLE001
                pass
        _GALLERIA = Galleria(sorgente)
    return _GALLERIA


def azzera() -> None:
    """Dimentica le gallerie caricate (prove, cambio di ``LEO_GALLERIA``)."""
    global _GALLERIA
    _GALLERIA = None
    _LOCALI.clear()


def galleria_locale(cartella: str | os.PathLike) -> Galleria | None:
    """La galleria ridotta di un programma creato (``<cartella>/galleria/indice.json``), se c'è."""
    base = Path(cartella) / CARTELLA_LOCALE
    indice = base / "indice.json"
    try:
        modifica = indice.stat().st_mtime
    except OSError:
        return None
    chiave = str(base.resolve())
    gia = _LOCALI.get(chiave)
    if gia is not None and gia[0] == modifica:
        return gia[1]
    g = Galleria(SorgenteCartella(base), base, locale=True).carica(forza=True)
    _LOCALI[chiave] = (modifica, g)
    return g


def _cartella_argomento() -> str | None:
    """La cartella del programma in esecuzione (``leo programma.leo``, eseguibili creati)."""
    import sys

    if len(sys.argv) > 1 and sys.argv[1] and not sys.argv[1].startswith("-"):
        p = Path(sys.argv[1])
        try:
            if p.is_file():
                return str(p.resolve().parent)
            if p.is_dir():
                return str(p.resolve())
        except OSError:
            return None
    return None


def _cartelle_locali(cartella: Any = None) -> list[Path]:
    uscita: list[Path] = []
    try:
        lavoro = os.getcwd()
    except OSError:
        lavoro = None
    for c in (cartella, variabile_ambiente("GALLERIA_LOCALE"), _cartella_argomento(), lavoro):
        if not c:
            continue
        p = Path(c)
        if p.name == CARTELLA_LOCALE and (p / "indice.json").is_file():
            p = p.parent
        if p not in uscita:
            uscita.append(p)
    return uscita


def risolvi(percorso: str, cartella: Any = None, *, estrai: bool = True) -> Path:
    """Il file vero di ``galleria:categoria/nome``: prima nella galleria del programma (cartella del
    progetto, ``LEO_GALLERIA_LOCALE``, cartella di lavoro), poi in quella di Leo. Errori in italiano."""
    for c in _cartelle_locali(cartella):
        g = galleria_locale(c)
        if g is None:
            continue
        try:
            return g.risolvi(percorso)
        except Exception:  # noqa: BLE001 - non c'è nella galleria del programma: si prova quella di Leo
            pass
    return galleria().risolvi(percorso, estrai=estrai)


def percorso_vero(valore: Any, cartella: Any = None) -> str | None:
    """Per i motori grafici: il file di ``galleria:...`` o None (mai eccezioni)."""
    if not e_percorso_galleria(valore):
        return None
    try:
        return str(risolvi(str(valore), cartella))
    except Exception:  # noqa: BLE001
        return None


def fotogrammi(percorso: str, cartella: Any = None) -> list[Path]:
    for c in _cartelle_locali(cartella):
        g = galleria_locale(c)
        if g is not None:
            try:
                return g.fotogrammi(percorso)
            except Exception:  # noqa: BLE001
                pass
    return galleria().fotogrammi(percorso)


def riferimenti(testi: Iterable[str]) -> set[str]:
    """I percorsi ``galleria:...`` scritti nei testi (codice, maschere), senza il prefisso."""
    trovati: set[str] = set()
    for t in testi:
        for m in RE_RIFERIMENTO.finditer(t or ""):
            trovati.add(m.group(1))
    return trovati


def riferimenti_progetto(cartella: str | os.PathLike, file: Iterable[Path] | None = None) -> set[str]:
    """I riferimenti alla galleria nei file di testo di un progetto (.leo, .maschera, .toml, .json)."""
    base = Path(cartella)
    if file is None:
        file = [p for p in base.rglob("*") if p.is_file() and CARTELLA_LOCALE not in p.relative_to(base).parts[:1]]
    testi = []
    for p in file:
        if p.suffix.lower() in (".leo", ".dante", ".maschera", ".toml", ".json", ".txt", ".csv"):
            try:
                if p.stat().st_size <= 4 * 1024 * 1024:
                    testi.append(p.read_text(encoding="utf-8", errors="ignore"))
            except OSError:
                pass
    return riferimenti(testi)


def elementi_usati(riferiti: Iterable[str], *, avvisi: list[str] | None = None) -> list[str]:
    """Gli id degli elementi indicati dai riferimenti (quelli sconosciuti diventano avvisi)."""
    g = galleria()
    ids: list[str] = []
    for r in sorted(set(riferiti)):
        try:
            e, _a = g.trova(r)
        except Exception as ex:  # noqa: BLE001
            if avvisi is not None:
                avvisi.append(f"Il programma usa `galleria:{r}`, che non trovo: "
                              f"{getattr(ex, 'messaggio', ex)}")
            continue
        if e.id not in ids:
            ids.append(e.id)
    return ids


def prepara_per_programma(cartella_progetto: str | os.PathLike, file: Iterable[Path] | None = None, *,
                          avvisi: list[str] | None = None) -> list[tuple[Path, str]]:
    """Per ``leo compila`` e ``leo compila --apk``: copia gli elementi usati dal programma (e solo
    quelli) in una cartella di appoggio e restituisce (file, ``galleria/...``) da includere."""
    usati = elementi_usati(riferimenti_progetto(cartella_progetto, file), avvisi=avvisi)
    if not usati:
        return []
    g = galleria()
    impronta = hashlib.sha1(("\n".join(usati) + str(Path(cartella_progetto).resolve())).encode("utf-8")).hexdigest()
    appoggio = g.cartella_utente / "per_programmi" / impronta[:16]
    shutil.rmtree(appoggio, ignore_errors=True)
    uscita: list[tuple[Path, str]] = []
    try:
        for p, rel in g.copia_elementi(usati, appoggio, avvisi=avvisi):
            uscita.append((p, f"{CARTELLA_LOCALE}/{rel}"))
    except Exception as ex:  # noqa: BLE001
        if avvisi is not None:
            avvisi.append(f"Non riesco a preparare gli elementi della galleria: {getattr(ex, 'messaggio', ex)}")
        return []
    return uscita


# ===========================================================================
# Interfaccia (telefono e Leo Studio): azioni con risposte JSON
# ===========================================================================

_STATO_SCARICAMENTI: dict[str, dict[str, Any]] = {}


def _breve(g: Galleria, e: Elemento, *, miniatura: bool = True) -> dict[str, Any]:
    d: dict[str, Any] = {"id": e.id, "percorso": e.percorso, "titolo": e.titolo, "categoria": e.categoria,
                         "sotto": e.sottocategoria, "tipo": e.tipo, "stato": g.stato(e), "pacchetto": e.pacchetto,
                         "animato": bool(e.animazioni), "larghezza": e.larghezza, "altezza": e.altezza}
    if e.durata:
        d["durata"] = round(e.durata, 2)
    if e.onda:
        d["onda"] = e.onda
    if e.pacchetto and e.pacchetto in g.pacchetti:
        d["pacchetto_titolo"] = g.pacchetti[e.pacchetto].titolo
    if e.extra:
        d["peso"] = e.peso
        d["peso_testo"] = formatta_peso(e.peso)
    if e.marchio:
        d["marchio"] = e.marchio
    if miniatura:
        d["miniatura"] = g.miniatura(e)
    return d


def controllo_per(e: Elemento, tipi: Any = ()) -> dict[str, Any]:
    """Quale oggetto diventa l'elemento trascinato su una finestra: ``{"tipo", "proprieta", "valori"}``
    (``valori``: le proprietà da impostare). ``tipi``: i tipi di oggetto disponibili (nomi, oppure
    {nome: [proprieta']}); ``{"tipo": "Finestra", ...}`` per gli sfondi; {} se non si trascina."""
    disponibili: dict[str, list[str]] = {}
    if isinstance(tipi, dict):
        disponibili = {str(k): [str(x) for x in (v or [])] for k, v in tipi.items()}
    else:
        disponibili = {str(k): [] for k in tipi or ()}
    if e.tipo in ("suono", "musica"):
        return {"tipo": "Suono", "proprieta": "file", "valori": {"file": e.percorso}}
    if e.tipo == "carattere":
        return {}
    if e.categoria == "sfondi":
        return {"tipo": "Finestra", "proprieta": "immagine_sfondo", "valori": {"immagine_sfondo": e.percorso}}
    if e.categoria == "pulsanti" and (not disponibili or "PulsanteImmagine" in disponibili):
        return {"tipo": "PulsanteImmagine", "proprieta": "immagine", "valori": {"immagine": e.percorso}}
    if e.categoria in ("personaggi", "nemici", "veicoli"):
        # oggetti da gioco (scheda Giochi): i nemici diventano Nemico, gli altri Personaggio
        preferiti = ("Nemico", "Personaggio", "Sprite") if e.categoria == "nemici" else ("Personaggio", "Sprite")
    elif e.animazioni:
        preferiti = ("Sprite",)       # una moneta che gira resta un'immagine animata, non un personaggio
    else:
        preferiti = ()
    if preferiti:
        for t in preferiti:
            if t in disponibili:
                valori: dict[str, Any] = {"immagine": e.percorso}
                if "dinamiche" in disponibili[t] and t in ("Personaggio", "Nemico"):
                    valori["dinamiche"] = []      # fermo dove lo metti: le dinamiche si aggiungono dopo
                if "fotogrammi" in disponibili[t] and e.animazioni:
                    nome = "cammina" if "cammina" in e.animazioni else next(iter(e.animazioni))
                    elenco = e.animazioni[nome]
                    valori["fotogrammi"] = [f"{e.percorso}/{nome}/{k}" for k in range(1, len(elenco) + 1)]
                return {"tipo": t, "proprieta": "immagine", "valori": valori}
    return {"tipo": "Immagine", "proprieta": "immagine", "valori": {"immagine": e.percorso}}


def misura_per(e: Elemento) -> tuple[int, int]:
    """Misura proposta per l'oggetto creato trascinando l'elemento (lato lungo al massimo 96/160)."""
    w, h = e.larghezza or 96, e.altezza or 96
    massimo = 160 if e.categoria in ("interfaccia", "decorazioni", "veicoli") else 64 if e.categoria in (
        "pulsanti", "icone", "oggetti", "armi") else 96
    s = min(1.0, massimo / max(w, h, 1))
    return max(16, round(w * s)), max(16, round(h * s))


def azione(nome: str, argomenti: dict[str, Any] | None = None) -> dict[str, Any]:
    """Le azioni della galleria per l'interfaccia (vedi android/CONTRATTO.md, "Galleria")."""
    a = argomenti or {}
    if nome == "prepara":
        # all'apertura del disegnatore: indice e ricerca pronti in sottofondo (migliaia di elementi);
        # chi chiede la galleria intanto aspetta il blocco, senza rifare il lavoro
        g0 = galleria()

        def prepara() -> None:
            try:
                g0.carica()
                g0._dati_ricerca()
            except Exception:  # noqa: BLE001 - si riproverà alla prima richiesta vera
                pass
        threading.Thread(target=prepara, name="galleria-prepara", daemon=True).start()
        return {}
    g = galleria().carica()
    if nome == "categorie":
        categorie = g.categorie()
        for c in categorie:
            c["miniatura"] = _icona_categoria(g, c["nome"])
        return {"categorie": categorie, "totale": len(g.elementi), "nuvola": _nuvola_breve(g)}
    if nome == "elenca":
        tutti = g.elenca(str(a.get("categoria") or ""), str(a.get("sotto") or ""), str(a.get("testo") or ""))
        gruppo = str(a.get("tipo") or "")               # "immagine" o "suono": solo quelli (scelta di una proprietà)
        if gruppo:
            tipi_ok = ("suono", "musica") if gruppo == "suono" else ("immagine", "animazione") \
                if gruppo == "immagine" else (gruppo,)
            tutti = [e for e in tutti if e.tipo in tipi_ok]
        da = max(0, int(a.get("da") or 0))
        quanti = max(1, min(200, int(a.get("quanti") or 60)))
        return {"elementi": [_breve(g, e) for e in tutti[da:da + quanti]], "totale": len(tutti)}
    if nome in ("dettaglio", "apri", "usa"):
        e, _anim = g.trova(str(a.get("id") or a.get("percorso") or ""))
        if nome in ("apri", "usa") and g.stato(e) == "compresso":
            g.estrai(e.pacchetto)
        d = _breve(g, e)
        d.update({"licenza": e.licenza, "autore": e.autore, "fonte": e.fonte, "parole": e.parole,
                  "titolo_categoria": TITOLI_CATEGORIE.get(e.categoria, e.categoria),
                  "titolo_sotto": g.titoli_sotto.get(e.sottocategoria, e.sottocategoria.replace("_", " ")),
                  "fps": e.fps, "animazioni": {k: len(v) for k, v in e.animazioni.items()}})
        p = g.pacchetti.get(e.pacchetto)
        if p is not None:
            d["pacchetto_titolo"], d["pacchetto_peso"] = p.titolo, p.peso
            d["pacchetto_elementi"] = len(p.elementi)
            if p.tipo == "nuvola":
                mancanti = g.da_scaricare(p.nome)
                d["pacchetto_mancanti"] = len(mancanti)
                d["pacchetto_mancanti_peso"] = sum(x.peso for x in mancanti)
                d["pacchetto_mancanti_testo"] = formatta_peso(d["pacchetto_mancanti_peso"])
                for k in ("pagina", "licenza_url", "licenza_file"):
                    if getattr(p, k):
                        d[k] = getattr(p, k)
                d["pacchetto_autore"] = p.autore
        if e.extra:
            d["fonte_file"] = e.extra["url"]
            d["sha256"] = e.extra["sha256"]
        if g.stato(e) in ("aperto", "pronto", "scaricato"):
            d["uri"] = g.uri(e, limite=int(a.get("limite") or LIMITE_ANTEPRIMA))
            d["risorse"] = {e.percorso: d["uri"]} if d["uri"] else {}
            if a.get("fotogrammi", True) and e.animazioni:
                d["fotogrammi"] = {k: [g.uri(e, f) for f in v] for k, v in e.animazioni.items()}
        d["controllo"] = controllo_per(e, a.get("tipi") or ())
        d["misura"] = list(misura_per(e))
        return d
    if nome == "nuvola":
        return {"pacchetti": _nuvola_breve(g), "repo": str(g.extra_info.get("repo") or REPO),
                "generato": str(g.extra_info.get("generato") or "")}
    if nome == "scarica":
        if a.get("pacchetto") and not a.get("id"):
            return _avvia_scaricamento(g, "", str(a.get("pacchetto")), a.get("conferma") is True)
        return _avvia_scaricamento(g, str(a.get("id") or a.get("percorso") or ""), "", a.get("conferma") is True)
    if nome == "avanzamento":
        stato = _STATO_SCARICAMENTI.get(_chiave_scarico(str(a.get("id") or a.get("percorso") or ""),
                                                        str(a.get("pacchetto") or "")))
        return dict(stato) if stato else {"stato": "fermo"}
    if nome == "annulla":
        stato = _STATO_SCARICAMENTI.get(_chiave_scarico(str(a.get("id") or ""), str(a.get("pacchetto") or "")))
        if stato:
            stato["annulla"] = True
        return {}
    if nome == "dimentica":
        g.dimentica(str(a.get("pacchetto") or ""))
        return {}
    if nome == "crediti":
        return {"testo": g.crediti(a.get("ids"))}
    raise _errore(f"Azione della galleria sconosciuta: `{nome}`.")


#: L'elemento che fa da icona a ogni categoria (se c'è; altrimenti il primo con un'immagine).
ICONE_CATEGORIE = {
    "personaggi": "personaggi/cavaliere", "nemici": "nemici/drago", "armi": "armi/spada", "oggetti": "oggetti/moneta",
    "piastrelle": "piastrelle/erba", "veicoli": "veicoli/automobile_rossa", "sfondi": "sfondi/prato",
    "decorazioni": "decorazioni/albero", "pulsanti": "pulsanti/gioca", "interfaccia": "interfaccia/cuore_pieno",
    "effetti": "effetti/esplosione", "icone": "icone/stella", "caratteri": "caratteri/leo_pixel",
}


def _icona_categoria(g: Galleria, categoria: str) -> str:
    scelto = g.elementi.get(ICONE_CATEGORIE.get(categoria, ""))
    candidati = [scelto] if scelto is not None else []
    candidati += sorted((e for e in g.elementi.values() if e.categoria == categoria and e.tipo in ("immagine", "animazione", "carattere")),
                        key=lambda e: (bool(e.pacchetto), e.nome))[:3]
    for e in candidati:
        try:
            uri = g.miniatura(e)
        except Exception:  # noqa: BLE001
            uri = ""
        if uri:
            return uri
    return ""


def _nuvola_breve(g: Galleria) -> list[dict[str, Any]]:
    """I pacchetti extra: titolo, peso, quanti elementi, quanti già scaricati, provenienza."""
    uscita = []
    for p in g.pacchetti.values():
        if p.tipo != "nuvola":
            continue
        elementi = [g.elementi[i] for i in p.elementi if i in g.elementi]
        scaricati = sum(1 for e in elementi if g.scaricato(e))
        stato = _STATO_SCARICAMENTI.get(_chiave_scarico("", p.nome), {})
        uscita.append({"nome": p.nome, "titolo": p.titolo, "peso": p.peso, "peso_testo": formatta_peso(p.peso),
                       "elementi": len(elementi), "scaricati": scaricati, "scaricato": scaricati == len(elementi) > 0,
                       "autore": p.autore, "licenza": p.licenza, "marchio": p.marchio,
                       "categorie": sorted({e.categoria for e in elementi}),
                       "in_corso": stato.get("stato") in ("scarico", "verifico")})
    return uscita


def _chiave_scarico(elemento: str, pacchetto: str) -> str:
    if pacchetto:
        return "pacchetto:" + pacchetto
    try:
        return "elemento:" + galleria().trova(elemento)[0].id
    except Exception:  # noqa: BLE001
        return "elemento:" + elemento


def _avvia_scaricamento(g: Galleria, elemento: str, pacchetto: str, conferma: bool) -> dict[str, Any]:
    """Scarica in un thread (l'interfaccia segue con ``avanzamento``): un elemento o tutto un pacchetto."""
    if not conferma:
        raise _errore("Per scaricare serve la conferma di chi usa Leo.")
    if pacchetto:
        mancanti = g.da_scaricare(pacchetto)
        totale, quanti = sum(e.peso for e in mancanti), len(mancanti)
    else:
        e, _a = g.trova(elemento)
        if not e.extra:
            raise _errore(f"`{e.titolo}` non è un elemento extra: è già nella galleria.")
        totale, quanti = e.peso, 1
    chiave = _chiave_scarico(elemento, pacchetto)
    corrente = _STATO_SCARICAMENTI.get(chiave)
    if corrente and corrente.get("stato") in ("scarico", "verifico"):
        return {"avviato": False, "gia": True}
    stato: dict[str, Any] = {"stato": "scarico", "fatti": 0, "totale": totale, "elementi_fatti": 0,
                             "elementi": quanti, "inizio": time.time()}
    _STATO_SCARICAMENTI[chiave] = stato

    def lavora() -> None:
        try:
            if pacchetto:
                def avanza(fatti: int, tot: int, k: int, n: int) -> None:
                    stato.update(fatti=fatti, totale=tot, elementi_fatti=k, elementi=n)
                g.scarica_pacchetto(pacchetto, conferma=True, avanzamento=avanza,
                                    fermato=lambda: bool(stato.get("annulla")))
            else:
                def avanza1(fatti: int, tot: int) -> None:
                    stato["fatti"], stato["totale"] = fatti, tot
                    if tot and fatti >= tot:
                        stato["stato"] = "verifico"
                g.scarica(elemento, conferma=True, avanzamento=avanza1, fermato=lambda: bool(stato.get("annulla")))
                stato["elementi_fatti"] = 1
            stato["stato"] = "fatto"
        except BaseException as ex:  # noqa: BLE001
            stato["stato"] = "errore"
            stato["errore"] = getattr(ex, "messaggio", None) or str(ex)
            suggerimento = getattr(ex, "suggerimento", None)
            if suggerimento:
                stato["suggerimento"] = suggerimento

    threading.Thread(target=lavora, name=f"galleria-{chiave}", daemon=True).start()
    return {"avviato": True, "totale": totale, "elementi": quanti}


__all__ = [
    "PREFISSO", "CATEGORIE", "Elemento", "Pacchetto", "Galleria", "SorgenteCartella", "SorgenteAsset",
    "galleria", "galleria_locale", "azzera", "risolvi", "percorso_vero", "fotogrammi", "riferimenti",
    "riferimenti_progetto", "elementi_usati", "prepara_per_programma", "e_percorso_galleria", "dividi",
    "azione", "controllo_per", "misura_per", "uri_dati", "formatta_peso", "semplice", "nome_elemento",
    "categoria_vera", "unisci_extra", "marchio_di",
]
