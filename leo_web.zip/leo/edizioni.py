"""Edizioni di Leo: la Suite completa e le edizioni mirate, più leggere.

Il **modo di scrivere Leo è identico in ogni edizione**: la base del linguaggio
(``stampa``, variabili, condizioni, cicli, matematica, testi, liste, dizionari...)
è sempre la stessa, ovunque. Non si impara un Leo diverso.

Ogni edizione però **abilita solo le funzioni della sua categoria**: in "Leo Dati"
le funzioni dei giochi sono **bloccate** (e i loro contenuti non ci sono), così non
si creano bug e ogni edizione è a sé. **Leo Suite ha tutte le categorie dentro di sé,
già interconnesse** (web + dati + giochi insieme): è un unico Leo completo, non un
ponte tra edizioni separate.

Due assi, un unico manifesto ``dati/edizioni.toml``:

* le **categorie** raggruppano le funzioni (moduli di libreria) per argomento;
* i **contenuti** sono gli asset pesanti di ``dati/`` (per esempio i personaggi dei
  giochi) che non servono a tutte le edizioni.

Questo modulo offre: :func:`edizione_corrente`; per la compilazione
:func:`moduli_esclusi` (funzioni bloccate) e :func:`cartelle_dati_escluse`
(contenuti non impacchettati); per il messaggio a runtime
:func:`spiega_fuori_edizione`; e :func:`nome_edizione`/:func:`icona_edizione`.
"""

from __future__ import annotations

import os
from functools import lru_cache
from typing import Any

#: Edizione completa (tutte le categorie, tutti i contenuti). Valore predefinito.
SUITE = "suite"


@lru_cache(maxsize=1)
def _dati() -> dict[str, Any]:
    from .percorsi import file_dati
    from .tomlutil import carica_toml

    return carica_toml(file_dati("edizioni.toml"))


def ricarica() -> None:
    """Dimentica il manifesto in cache (utile ai test)."""
    _dati.cache_clear()
    edizione_corrente.cache_clear()


# ---------------------------------------------------------------------------
# Lettura del manifesto
# ---------------------------------------------------------------------------
def nucleo() -> frozenset[str]:
    """I moduli base, sempre presenti: il modo di scrivere Leo, uguale ovunque."""
    return frozenset(_dati().get("nucleo", {}).get("moduli", ()))


def categorie() -> dict[str, dict[str, Any]]:
    """Le categorie di funzioni: ``{id: {"nome", "descrizione", "moduli": [...]}}``."""
    return dict(_dati().get("categorie", {}))


def contenuti() -> dict[str, dict[str, Any]]:
    """I pacchetti di contenuto (asset): ``{id: {"nome", "cartelle": [...]}}``.

    ``cartelle`` sono sottocartelle di ``dati/`` (asset facoltativi e pesanti)."""
    return dict(_dati().get("contenuti", {}))


def edizioni() -> dict[str, dict[str, Any]]:
    """Le edizioni: ``{id: {"nome", "descrizione", "categorie": [...] o ["*"]}}``.

    I contenuti di un'edizione seguono le sue categorie (una categoria porta con sé
    il suo pacchetto di contenuto, se esiste con lo stesso id)."""
    return dict(_dati().get("edizioni", {}))


def edizione_valida(edizione: str) -> bool:
    return edizione in edizioni()


def nome_edizione(edizione: str) -> str:
    """Nome leggibile, es. ``"Leo Web"`` (o l'id se ignota)."""
    return edizioni().get(edizione, {}).get("nome", f"Leo {edizione}")


def icona_edizione(edizione: str) -> str:
    """Nome del file icona dell'edizione (stesso leone, un colore per edizione)."""
    return f"leo_{edizione}.ico"


def _categorie_di(edizione: str) -> list[str]:
    cat = edizioni().get(edizione, {}).get("categorie", [])
    if "*" in cat:
        return list(categorie().keys())
    return [c for c in cat if c in categorie()]


def categoria_del_modulo(modulo: str) -> tuple[str, str] | None:
    """``(id, nome)`` della categoria che contiene ``modulo``, o ``None`` (nucleo/ignoto)."""
    base = modulo.rsplit(".", 1)[-1]
    for idc, dati in categorie().items():
        if base in dati.get("moduli", ()):
            return idc, dati.get("nome", idc)
    return None


# ---------------------------------------------------------------------------
# Asse 1: le funzioni (moduli di libreria) — cosa è abilitato, cosa è bloccato
# ---------------------------------------------------------------------------
def moduli_di_edizione(edizione: str) -> frozenset[str]:
    """I moduli abilitati in ``edizione``: il nucleo più le sue categorie."""
    moduli = set(nucleo())
    cat = categorie()
    for idc in _categorie_di(edizione):
        moduli.update(cat[idc].get("moduli", ()))
    return frozenset(moduli)


def moduli_esclusi(edizione: str) -> frozenset[str]:
    """I moduli delle categorie NON incluse: funzioni bloccate (tolte dal pacchetto)."""
    if edizione == SUITE or not edizione_valida(edizione):
        return frozenset()
    tutti = set(nucleo())
    for dati in categorie().values():
        tutti.update(dati.get("moduli", ()))
    return frozenset(tutti - moduli_di_edizione(edizione))


def modulo_incluso(modulo: str, edizione: str | None = None) -> bool:
    ed = edizione or edizione_corrente()
    if ed == SUITE or not edizione_valida(ed):
        return True
    return modulo.rsplit(".", 1)[-1] in moduli_di_edizione(ed)


# ---------------------------------------------------------------------------
# Asse 2: i contenuti (asset di dati/) — cosa viaggia nel download
# ---------------------------------------------------------------------------
def cartelle_dati_escluse(edizione: str) -> frozenset[str]:
    """Le cartelle di ``dati/`` (asset) da NON impacchettare per questa edizione.

    Un contenuto si include se la sua categoria è nell'edizione (stesso id). Per la
    Suite non si esclude nulla."""
    if edizione == SUITE or not edizione_valida(edizione):
        return frozenset()
    incluse_cat = set(_categorie_di(edizione))
    cont = contenuti()
    tenute: set[str] = set()
    for idc, dati in cont.items():
        if idc in incluse_cat:
            tenute.update(dati.get("cartelle", ()))
    tutte: set[str] = set()
    for dati in cont.values():
        tutte.update(dati.get("cartelle", ()))
    return frozenset(tutte - tenute)


# ---------------------------------------------------------------------------
# L'edizione in esecuzione
# ---------------------------------------------------------------------------
@lru_cache(maxsize=1)
def edizione_corrente() -> str:
    """L'edizione che sta girando ora.

    Nell'ordine: la variabile d'ambiente ``LEO_EDIZIONE``; poi il file
    ``dati/edizione_corrente.txt`` (scritto quando si compila un'edizione mirata);
    altrimenti :data:`SUITE`. In sviluppo e nella Suite è ``"suite"``.
    """
    env = os.environ.get("LEO_EDIZIONE", "").strip()
    if env:
        return env if edizione_valida(env) else SUITE
    try:
        from .percorsi import file_dati

        marcatore = file_dati("edizione_corrente.txt")
        if marcatore.is_file():
            testo = marcatore.read_text(encoding="utf-8").strip()
            if edizione_valida(testo):
                return testo
    except Exception:  # noqa: BLE001 - un marcatore assente o illeggibile = Suite
        pass
    return SUITE


# ---------------------------------------------------------------------------
# Il messaggio gentile a runtime (funzione di un'altra categoria)
# ---------------------------------------------------------------------------
def errore_fuori_edizione(nome_funzione: str, modulo: str, edizione: str | None = None):
    """Costruisce (non solleva) l'``ErroreNome`` chiaro per una funzione di un'altra
    categoria. Lo usa lo stub che ``leo/libreria`` mette al posto delle funzioni
    bloccate: quando l'utente la chiama, lo stub solleva questo errore."""
    from .errori import ErroreNome

    ed = edizione or edizione_corrente()
    cat = categoria_del_modulo(modulo)
    categoria = cat[1] if cat else modulo.rsplit(".", 1)[-1]
    questa = nome_edizione(ed)
    messaggio = (f"La funzione `{nome_funzione}` fa parte della categoria {categoria}, "
                 f"che {questa} non include.")
    suggerimento = ("Leo Suite le ha tutte dentro di sé, già interconnesse. "
                    "Il modo di scrivere Leo è lo stesso: cambia solo cosa è incluso.")
    return ErroreNome(messaggio, suggerimento=suggerimento, nome=nome_funzione)


def spiega_fuori_edizione(nome_funzione: str, modulo: str, edizione: str | None = None):
    """Se ``modulo`` è di una categoria non inclusa, solleva l'errore chiaro; altrimenti
    restituisce ``None``. (Comodità per i test; a runtime il blocco è fatto dagli stub.)"""
    ed = edizione or edizione_corrente()
    if ed == SUITE or not edizione_valida(ed) or modulo_incluso(modulo, ed):
        return None
    raise errore_fuori_edizione(nome_funzione, modulo, ed)
