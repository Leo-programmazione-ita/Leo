"""Libreria: pagine web in italiano (si scrivono in Leo, diventano HTML/CSS veri).

Con ``pagina(...)`` costruisci una pagina aggiungendo elementi in ordine
(``titolo``, ``paragrafo``, ``immagine``, ``collegamento``, ``elenco``...), e con
``.salva("index.html")`` la scrivi come file **HTML5 valido**, con uno stile già
curato incluso: si apre in qualsiasi browser e si carica su qualsiasi sito.

Il linguaggio non cambia: questo modulo aggiunge solo funzioni e un tipo nuovo
(``pagina``). Ogni parola del web vive **dentro** la pagina (sono metodi), quindi
non tocca nessun nome globale. I testi che dai vengono protetti in automatico
(niente pagine rotte o rischi di HTML indesiderato); per inserire HTML a mano c'è
``.grezzo(...)``.
"""

from __future__ import annotations

import html as _html
from typing import Any

from ..valori import rappresenta
from .generali import funzione_libreria, richiedi_lista, richiedi_testo
from .oggetti import OggettoLibreria, metodo_oggetto, proprieta

# ---------------------------------------------------------------------------
# Stile predefinito: pulito, leggibile, responsivo. La bellezza è gratis.
# ---------------------------------------------------------------------------
_CSS_BASE = """*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--fg);
  font:17px/1.65 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
  -webkit-font-smoothing:antialiased}
main{max-width:720px;margin:0 auto;padding:44px 20px 80px}
h1{font-size:2.3em;line-height:1.12;margin:.1em 0 .45em;letter-spacing:-.01em}
h2{font-size:1.5em;line-height:1.2;margin:1.6em 0 .4em}
p{margin:0 0 1.05em}
a{color:var(--acc);text-underline-offset:2px}
img{max-width:100%;height:auto;border-radius:12px;display:block;margin:1.2em 0}
ul,ol{margin:0 0 1.1em;padding-left:1.4em}
li{margin:.25em 0}
blockquote{margin:1.3em 0;padding:.5em 1.1em;border-left:4px solid var(--acc);
  color:var(--mut);font-style:italic}
pre{background:var(--cod);border:1px solid var(--line);border-radius:10px;
  padding:14px 16px;overflow:auto;font:14.5px/1.55 ui-monospace,"Cascadia Mono",Consolas,monospace}
code{font-family:ui-monospace,"Cascadia Mono",Consolas,monospace}
:not(pre)>code{background:var(--cod);border:1px solid var(--line);border-radius:5px;padding:.08em .35em;font-size:.9em}
.pulsante{display:inline-block;background:var(--acc);color:#fff;padding:12px 22px;
  border-radius:11px;text-decoration:none;font-weight:600;margin:.2em 0 1.1em}
.pulsante:hover{filter:brightness(1.07)}
table{border-collapse:collapse;width:100%;margin:0 0 1.2em;font-size:.97em}
th,td{border:1px solid var(--line);padding:9px 12px;text-align:left}
th{background:var(--cod);font-weight:600}
hr{border:0;border-top:1px solid var(--line);margin:2.2em 0}
.sottotitolo{color:var(--mut);font-size:1.15em;margin-top:-.2em}
footer{margin-top:3em;padding-top:1.2em;border-top:1px solid var(--line);color:var(--mut);font-size:.92em}
"""

_TEMI = {
    "chiaro": "--fg:#1a1712;--bg:#ffffff;--acc:#E6111A;--mut:#6b655e;--line:#e7e4df;--cod:#f6f5f2",
    "scuro":  "--fg:#f4ecea;--bg:#0f0d0e;--acc:#FF4D5E;--mut:#a79a98;--line:#2a2422;--cod:#17110f",
}


def _t(v: Any, nome: str) -> str:
    """Testo protetto (sicuro da mettere nell'HTML)."""
    return _html.escape(richiedi_testo(v, "pagina", nome))


class Pagina(OggettoLibreria):
    """Valore Leo di tipo ``pagina``: una pagina web che costruisci pezzo per pezzo."""

    NOME_TIPO_DANTE = "pagina"
    SUGGERIMENTO_MODIFICA = "Aggiungi contenuti con metodi come `.titolo(...)` e `.paragrafo(...)`."

    def __init__(self, titolo: str = "") -> None:
        self.titolo_pagina = titolo
        self.tema_nome = "chiaro"
        self.lingua = "it"
        self.corpo: list[str] = []
        self.piede: str | None = None

    # -- costruzione del documento -----------------------------------------
    def _documento(self) -> str:
        titolo = _html.escape(self.titolo_pagina or "Pagina")
        tema = _TEMI.get(self.tema_nome, _TEMI["chiaro"])
        corpo = "\n".join(self.corpo)
        piede = f"\n<footer>{self.piede}</footer>" if self.piede else ""
        return (
            "<!doctype html>\n"
            f'<html lang="{_html.escape(self.lingua)}">\n<head>\n'
            '<meta charset="utf-8">\n'
            '<meta name="viewport" content="width=device-width, initial-scale=1">\n'
            f"<title>{titolo}</title>\n"
            f"<style>\n:root{{{tema}}}\n{_CSS_BASE}</style>\n"
            "</head>\n<body>\n<main>\n"
            f"{corpo}{piede}\n"
            "</main>\n</body>\n</html>\n"
        )

    def testo_dante(self) -> str:
        return f"<pagina «{self.titolo_pagina}», {len(self.corpo)} elementi>"


# ===========================================================================
# Costruttore
# ===========================================================================
@funzione_libreria("pagina")
def pagina(titolo=""):
    """pagina(titolo = ""): crea una pagina web vuota, con un titolo.

    Poi aggiungi i contenuti in ordine e la salvi:
    `variabile p = pagina("Il mio sito")` ... `p.titolo("Ciao")` ... `p.salva("index.html")`.
    Metodi: `titolo`, `sottotitolo`, `paragrafo`, `immagine`, `collegamento`, `pulsante`,
    `elenco`, `elenco_numerato`, `tabella`, `citazione`, `codice`, `riga`, `grezzo`,
    `tema`, `in_fondo`, `html`, `salva`.
    """
    richiedi_testo(titolo, "pagina", "titolo")
    return Pagina(titolo)


# ===========================================================================
# Metodi che aggiungono contenuti (restituiscono la pagina: si possono concatenare)
# ===========================================================================
@metodo_oggetto(Pagina, "titolo")
def pag_titolo(p, testo):
    """pagina.titolo(testo): un titolo grande (il titolo principale della pagina)."""
    p.corpo.append(f"<h1>{_t(testo, 'titolo')}</h1>")
    return p


@metodo_oggetto(Pagina, "sottotitolo")
def pag_sottotitolo(p, testo):
    """pagina.sottotitolo(testo): una riga più piccola, sotto il titolo."""
    p.corpo.append(f'<p class="sottotitolo">{_t(testo, "sottotitolo")}</p>')
    return p


@metodo_oggetto(Pagina, "sezione")
def pag_sezione(p, testo):
    """pagina.sezione(testo): un titoletto che apre una nuova sezione della pagina."""
    p.corpo.append(f"<h2>{_t(testo, 'sezione')}</h2>")
    return p


@metodo_oggetto(Pagina, "paragrafo")
def pag_paragrafo(p, testo):
    """pagina.paragrafo(testo): un paragrafo di testo normale.

    Esempio: `p.paragrafo("Benvenuto nel mio sito, scritto in italiano.")`.
    """
    p.corpo.append(f"<p>{_t(testo, 'paragrafo')}</p>")
    return p


@metodo_oggetto(Pagina, "immagine")
def pag_immagine(p, percorso, alt=""):
    """pagina.immagine(percorso, alt = ""): mostra un'immagine (un file o un indirizzo web).

    `alt` è la descrizione per chi non la vede. Esempio: `p.immagine("foto.jpg", alt = "io al mare")`.
    """
    src = _html.escape(richiedi_testo(percorso, "immagine", "percorso"))
    descr = _html.escape(richiedi_testo(alt, "immagine", "alt"))
    p.corpo.append(f'<img src="{src}" alt="{descr}">')
    return p


@metodo_oggetto(Pagina, "collegamento")
def pag_collegamento(p, testo, indirizzo):
    """pagina.collegamento(testo, indirizzo): un collegamento cliccabile verso un indirizzo.

    Esempio: `p.collegamento("Vai a Leo", "https://leoitalia.com")`.
    """
    t = _t(testo, "collegamento")
    href = _html.escape(richiedi_testo(indirizzo, "collegamento", "indirizzo"), quote=True)
    p.corpo.append(f'<p><a href="{href}">{t}</a></p>')
    return p


@metodo_oggetto(Pagina, "pulsante")
def pag_pulsante(p, testo, indirizzo):
    """pagina.pulsante(testo, indirizzo): un collegamento a forma di pulsante colorato.

    Esempio: `p.pulsante("Scarica", "https://leoitalia.com/scarica.html")`.
    """
    t = _t(testo, "pulsante")
    href = _html.escape(richiedi_testo(indirizzo, "pulsante", "indirizzo"), quote=True)
    p.corpo.append(f'<a class="pulsante" href="{href}">{t}</a>')
    return p


def _voci_html(lista, nome):
    voci = richiedi_lista(lista, nome, "voci")
    return "".join(f"<li>{_html.escape(rappresenta(v) if not isinstance(v, str) else v)}</li>" for v in voci)


@metodo_oggetto(Pagina, "elenco")
def pag_elenco(p, voci):
    """pagina.elenco(voci): un elenco puntato, da una lista di testi.

    Esempio: `p.elenco(["Veloce", "In italiano", "Gratis"])`.
    """
    p.corpo.append(f"<ul>{_voci_html(voci, 'elenco')}</ul>")
    return p


@metodo_oggetto(Pagina, "elenco_numerato")
def pag_elenco_numerato(p, voci):
    """pagina.elenco_numerato(voci): un elenco numerato, da una lista di testi."""
    p.corpo.append(f"<ol>{_voci_html(voci, 'elenco_numerato')}</ol>")
    return p


@metodo_oggetto(Pagina, "tabella")
def pag_tabella(p, righe, intestazione=None):
    """pagina.tabella(righe, intestazione = nulla): una tabella da una lista di righe.

    Ogni riga è una lista di celle. `intestazione` (facoltativa) è la prima riga in grassetto.
    Esempio: `p.tabella([["Ada", "30"], ["Bruno", "27"]], intestazione = ["Nome", "Voto"])`.
    """
    righe = richiedi_lista(righe, "tabella", "righe")
    parti = ["<table>"]
    if intestazione is not None:
        celle = richiedi_lista(intestazione, "tabella", "intestazione")
        parti.append("<thead><tr>" + "".join(f"<th>{_html.escape(_cella(c))}</th>" for c in celle) + "</tr></thead>")
    parti.append("<tbody>")
    for r in righe:
        celle = r if isinstance(r, list) else [r]
        parti.append("<tr>" + "".join(f"<td>{_html.escape(_cella(c))}</td>" for c in celle) + "</tr>")
    parti.append("</tbody></table>")
    p.corpo.append("".join(parti))
    return p


def _cella(c: Any) -> str:
    return c if isinstance(c, str) else rappresenta(c)


@metodo_oggetto(Pagina, "citazione")
def pag_citazione(p, testo):
    """pagina.citazione(testo): una frase in evidenza, rientrata, come una citazione."""
    p.corpo.append(f"<blockquote>{_t(testo, 'citazione')}</blockquote>")
    return p


@metodo_oggetto(Pagina, "codice")
def pag_codice(p, testo):
    """pagina.codice(testo): un blocco di codice, a larghezza fissa (monospazio)."""
    p.corpo.append(f"<pre><code>{_t(testo, 'codice')}</code></pre>")
    return p


@metodo_oggetto(Pagina, "riga")
def pag_riga(p):
    """pagina.riga(): una linea orizzontale di separazione."""
    p.corpo.append("<hr>")
    return p


@metodo_oggetto(Pagina, "in_fondo")
def pag_in_fondo(p, testo):
    """pagina.in_fondo(testo): una scritta piccola in fondo alla pagina (il piè di pagina)."""
    p.piede = _t(testo, "in_fondo")
    return p


@metodo_oggetto(Pagina, "grezzo")
def pag_grezzo(p, html):
    """pagina.grezzo(html): inserisce HTML scritto a mano, così com'è (per i casi avanzati).

    Attenzione: questo NON viene protetto. Usalo solo con HTML di cui ti fidi.
    """
    p.corpo.append(richiedi_testo(html, "grezzo", "html"))
    return p


@metodo_oggetto(Pagina, "tema")
def pag_tema(p, nome):
    """pagina.tema(nome): imposta l'aspetto, "chiaro" (predefinito) o "scuro"."""
    n = richiedi_testo(nome, "tema", "nome").strip().lower()
    if n not in _TEMI:
        from ..errori import ErroreValore
        raise ErroreValore(f'Il tema «{n}» non esiste.', suggerimento='I temi sono "chiaro" e "scuro".')
    p.tema_nome = n
    return p


@metodo_oggetto(Pagina, "html")
def pag_html(p):
    """pagina.html(): la pagina intera come testo HTML (per servirla, incollarla o controllarla)."""
    return p._documento()


@metodo_oggetto(Pagina, "salva", interprete=True)
def pag_salva(interprete, p, percorso="index.html"):
    """pagina.salva(percorso = "index.html"): scrive la pagina in un file HTML pronto da aprire.

    Esempio: `p.salva("index.html")`. Il file si apre con un doppio clic in qualsiasi browser.
    """
    perc = richiedi_testo(percorso, "salva", "percorso")
    with open(perc, "w", encoding="utf-8") as f:
        f.write(p._documento())
    return perc


# proprietà di sola lettura comode
proprieta(Pagina, "titolo_pagina")(lambda p: p.titolo_pagina)
proprieta(Pagina, "quanti_elementi")(lambda p: len(p.corpo))
