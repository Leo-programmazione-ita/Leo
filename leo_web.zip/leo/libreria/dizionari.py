"""Libreria: metodi dei dizionari.

``chiavi``, ``valori``, ``coppie``, ``prendi``, ``ha``, ``rimuovi``.
Le chiavi sono testi, interi o logici; ``vero`` e ``1`` sono chiavi diverse.
"""

from __future__ import annotations

from typing import Any

from ..errori import ErroreChiave, ErroreTipo
from ..operazioni import scrivi_indice
from ..valori import e_intero, verifica_chiave
from .generali import articolo, metodo_libreria, mostra


def _cerca(d: dict, chiave: Any) -> tuple[bool, Any]:
    """(trovata, chiave effettiva nel dizionario), distinguendo ``vero`` da ``1``."""
    if isinstance(chiave, bool) or (e_intero(chiave) and chiave in (0, 1)):
        for k in d:
            if isinstance(k, bool) == isinstance(chiave, bool) and k == chiave:
                return True, k
        return False, None
    if chiave in d:
        return True, chiave
    return False, None


@metodo_libreria("dizionario", "chiavi")
def dizionario_chiavi(dizionario):
    """dizionario.chiavi(): la lista delle chiavi, nell'ordine in cui sono state aggiunte.

    Esempio: `{"nome": "Ada", "età": 36}.chiavi()` è ["nome", "età"].
    """
    return list(dizionario.keys())


@metodo_libreria("dizionario", "valori")
def dizionario_valori(dizionario):
    """dizionario.valori(): la lista dei valori.

    Esempio: `{"nome": "Ada", "età": 36}.valori()` è ["Ada", 36].
    """
    return list(dizionario.values())


@metodo_libreria("dizionario", "coppie")
def dizionario_coppie(dizionario):
    """dizionario.coppie(): la lista delle coppie [chiave, valore].

    Esempio: `per ogni c in rubrica.coppie() fai stampa(c[0], c[1]) fine`.
    """
    return [[k, v] for k, v in dizionario.items()]


@metodo_libreria("dizionario", "prendi")
def dizionario_prendi(dizionario, chiave, predefinito=None):
    """dizionario.prendi(chiave, predefinito = nulla): il valore della chiave, o `predefinito` se non c'è.

    Esempio: `rubrica.prendi("Anna", "sconosciuto")`. A differenza di `rubrica["Anna"]`
    non dà errore se la chiave manca.
    """
    if type(chiave) is str:  # via veloce
        return dizionario.get(chiave, predefinito)
    verifica_chiave(chiave)
    trovata, k = _cerca(dizionario, chiave)
    return dizionario[k] if trovata else predefinito


@metodo_libreria("dizionario", "ha")
def dizionario_ha(dizionario, chiave):
    """dizionario.ha(chiave): `vero` se il dizionario contiene la chiave.

    Esempio: `se rubrica.ha("Anna") allora stampa(rubrica["Anna"]) fine`. Si può scrivere anche `"Anna" in rubrica`.
    """
    if type(chiave) is str:  # via veloce: un testo non si confonde con interi e logici
        return chiave in dizionario
    verifica_chiave(chiave)
    return _cerca(dizionario, chiave)[0]


@metodo_libreria("dizionario", "rimuovi")
def dizionario_rimuovi(dizionario, chiave):
    """dizionario.rimuovi(chiave): toglie la chiave (e il suo valore) dal dizionario.

    Esempio: `rubrica.rimuovi("Anna")`. Se la chiave non c'è ricevi un `ErroreChiave`.
    """
    verifica_chiave(chiave)
    trovata, k = _cerca(dizionario, chiave)
    if not trovata:
        raise ErroreChiave(f"La chiave {mostra(chiave)} non è nel dizionario.",
                           suggerimento="Controlla prima con `.ha(chiave)`.")
    del dizionario[k]
    return None


@metodo_libreria("dizionario", "estrai")
def dizionario_estrai(dizionario, chiave):
    """dizionario.estrai(chiave): toglie la chiave dal dizionario e restituisce il suo valore.

    Esempio: `variabile v = rubrica.estrai("Anna")`. Se la chiave non c'è ricevi un `ErroreChiave`
    (per non dare errore usa prima `.ha(chiave)` oppure `.prendi(chiave, predefinito)`).
    """
    verifica_chiave(chiave)
    trovata, k = _cerca(dizionario, chiave)
    if not trovata:
        raise ErroreChiave(f"La chiave {mostra(chiave)} non è nel dizionario.",
                           suggerimento="Controlla prima con `.ha(chiave)`.")
    valore = dizionario[k]
    del dizionario[k]
    return valore


@metodo_libreria("dizionario", "aggiorna")
def dizionario_aggiorna(dizionario, altro):
    """dizionario.aggiorna(altro): copia dentro il dizionario tutte le coppie di `altro`.

    Le chiavi già presenti prendono il valore nuovo, le altre si aggiungono.
    Esempio: dopo `rubrica.aggiorna({"Bea": 2})` la chiave "Bea" c'è col valore 2.
    """
    if not isinstance(altro, dict):
        raise ErroreTipo(f"`aggiorna` vuole un altro dizionario, non {articolo(altro)}.")
    for chiave, valore in list(altro.items()):
        scrivi_indice(dizionario, chiave, valore)
    return None


@metodo_libreria("dizionario", "svuota")
def dizionario_svuota(dizionario):
    """dizionario.svuota(): toglie tutte le coppie, lasciando il dizionario vuoto.

    Esempio: dopo `rubrica.svuota()` il dizionario è {}. Utile per riusare lo stesso dizionario.
    """
    dizionario.clear()
    return None
